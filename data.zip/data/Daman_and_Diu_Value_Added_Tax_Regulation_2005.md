Daman and Diu Value Added Tax Regulation, 2005
DAMAN AND DIU
India
Daman and Diu Value Added Tax Regulation, 2005
Rule DAMAN-AND-DIU-VALUE-ADDED-TAX-REGULATION-2005
of 2005
Published on 1 January 2005• 
Commenced on 1 January 2005• 
[This is the version of this document from 1 January 2005.]• 
[Note: The original publication document is not available and this content could not be
verified.]• 
Daman and Diu Value Added Tax Regulation, 2005Last Updated 12th February, 2020In exercise of
the powers conferred by article 240 of the Constitution, the President is pleased to promulgate the
following Regulation made by him:-
Chapter I
Preliminary
1. Short title, extent and commencement.
(1)This Regulation may be called the Daman and Diu Value Added Tax Regulation, 2005.(2)It
extends to the whole of the Union territory of Daman and Diu.(3)It shall come into force on such
date as the Administrator may, by notification, appoint, and different dates may be appointed for
different provisions of this Regulation and any reference in any such provision to the
commencement of this Regulation shall be construed as a reference to the coming into force of that
provision.
2. Definitions.
- In this Regulation, unless the context otherwise requires,-(a)"accountant" means -(i)a chartered
accountant as defined in clause (b) of sub-section (1) of section 2 of the Chartered Accountants Act,
1949 and who has obtained a (38 of 1949) certificate of practice under sub-section (1) of section 6 of
that Act; or(ii)a person, who, by virtue of the provisions of sub-section (2) of section 226 of the
Companies Act, 1956, (1 of 1956) is entitled to be appointed to act as an auditor under that
sub-section; or(iii)an auditor appointed in pursuance of sub-section (2) of section 619 of the
Companies Act, 1956 (1 of 1956);(b)"Administrator" means the Administrator of the Union territory
of Daman and Diu appointed by the President under article 239 of the Constitution;(c)"AppellateDaman and Diu Value Added Tax Regulation, 2005

Tribunal" means the Appellate Tribunal constituted under section 73;(d)"business" includes -(i)any
trade, commerce or manufacture,(ii)any adventure or concern in the nature of trade, commerce or
manufacture,(iii)any transaction in connection with, or incidental or ancillary to, such trade,
commerce, manufacture, adventure or concern,(iv)any occasional transaction in the nature of such
trade, commerce, manufacture, adventure or concern whether or not there is volume, frequency,
continuity or regularity of such transaction, andwhether or not such trade, commerce, manufacture,
adventure or concern transaction is carried on with a motive to make gain or profit and whether or
not any gain or profit accrues from such trade, commerce, manufacture, adventure, concern or
transaction.Explanation. - For the purposes of this clause -(A)any transaction of sale or purchase of
capital assets pertaining to such trade, commerce, manufacture, adventure, concern or transaction
referred to in subclauses (i) to (iv) shall be deemed to be business;(B)purchase of any goods, the
price of which is debited in the books of account of the dealer and sale of any goods, the proceeds of
which are credited in the books of account of the dealer shall be deemed to be business;(e)"business
premises" means -(i)the address of a dealer or, the place at which a dealer carries on the business
and which is registered as such;(ii)any building or place used by a person for carrying on his
business, but does not include the building or place used for residential purposes;(f)"capital goods"
means plant, machinery and equipment used in the trade or manufacturing of goods;(g)"casual
trader" means a person who, whether as principal, agent or in any other capacity undertakes
occasional transactions in the nature of business involving buying, selling, supply or distribution of
goods or conducting any exhibition-cum-sale in Daman and Diu whether for cash, deferred
payment, commission, remuneration or other valuable consideration;(h)"Commissioner" means the
Commissioner of Value Added Tax appointed under sub-section (1) of section 66;(i)"dealer" means
any person who carries on business in Daman and Diu and includes-(i)any person who for the
purposes of, or in connection with, or incidental to, or in the course of, his business buys, sells,
supplies or distributes goods directly or otherwise, whether for cash or for deferred payment or for
commission, remuneration or other valuable consideration;(ii)any department of the Central
Government or a State Government, a local authority, Panchayat, Municipality, Development
Authority, Cantonment Board and an autonomous or a statutory body or an industrial, commercial,
banking, insurance or trading undertaking whether or not of the Central Government or any of the
State Governments or of a local authority, if it buys, sells, supplies or distributes goods, in the course
of activities which may by notification specified from time to time;(iii)a factor, commission agent,
broker, del credere agent, or any other mercantile agent by whatever name called, who carries on the
business of buying, selling, supplying or distributing goods on behalf of any principal, whether
disclosed or not;(iv)an agent of any of the persons referred to in subclauses (iii) or (vi) or (vii) or
(viii) or (ix) of clause (i), whether or not the person referred to in the said subclauses is a dealer
residing in Daman and Diu;(v)a local branch of a firm or company or association of persons, outside
Daman and Diu where such firm, company, association of persons is a dealer within the meaning of
sub-clause (i), or sub-clause (iii), or sub-clause (vi), or sub-clause (vii), or sub-clause (viii), or
sub-clause (ix) of this clause;(vi)a club, association, society, trust, or co-operative society, whether
incorporated or not, which buys goods from, or sells goods to, its members for price, fee or
subscription, whether or not in the course of business;(vii)an auctioneer, who sells or auctions
goods belonging to any principal, whether disclosed or not and whether the offer of the intending
purchaser is accepted by him or by the principal or a nominee of the principal;(viii)a casual trader;
or(ix)any person who, for the purposes of, or in connection with, or incidental to, or in the course of,Daman and Diu Value Added Tax Regulation, 2005

his business, disposes of any goods as unclaimed or confiscated, or unserviceable or scrap, surplus,
old, obsolete or as discarded material or waste products by way of sale;(j)"Daman and Diu" means
the Union territory of Daman and Diu;(k)"fair market value" means the value at which goods of like
kind and quality are ordinarily sold or would be sold in the same quantities between unrelated
parties in the open market at the same time in Daman and Diu;(l)"goods" means every kind of
movable property (other than newspapers, actionable claims, stocks, shares and securities) and
includes -(i)livestock, all materials, articles or commodities including standing trees and things
attached to or forming part of the land which are agreed to be severed before sale or under a
contract of sale; and(ii)property in goods (whether as goods or in some other form) involved in the
execution of a works contract, lease or hire-purchase or those to be used in the fitting out,
improvement or repair of movable property;(m)"goods vehicle" means a motor vehicle, vessel, boat,
animal and any other form of conveyance used for carrying goods;(n)"Government" means the
Administrator;(o)"import" means sale or purchase in the course of the import of goods into the
territory of India if the sale or purchase either occasions such import or is effected by transfer of
document of title to the goods before the goods have crossed the customs frontiers of India and
includes procurement of goods from outside the Daman and Diu either as a result of purchase or
otherwise.Explanation. - In the case of goods arriving in Daman and Diu from a foreign country
through customs, the "import of the goods in Daman and Diu" shall occur at the place where the
goods are cleared by Customs for home consumption;(p)"in the course of" includes activities done
for the purposes of, in connection with, or incidental to and activities done as part of, the
preparation for the activity and in the termination of, the activity;(q)"input tax" in relation to the
purchase of goods, means the proportion of the price paid by the buyer for the goods which
represents tax under this Regulation;(r)"net tax" means the amount calculated for a tax period
under section 11;(s)"non-creditable goods" means the goods listed in the Sixth
Schedule;(t)"notification" means a notification published in the Official Gazette and the expression
"notify" shall be construed accordingly;(u)"Official Gazette" means the Daman and Diu
Gazette;(v)"prescribed" means prescribed by rules made under this Regulation;(w)"registered
dealer" means a dealer who has been granted a certificate of registration under section
19;(x)"related person" means a person who is related to another person (referred to in this definition
as a "dealer") if the person -(i)is a relative of the dealer;(ii)is a partnership of which the dealer is a
partner;(iii)is a company in which the dealer [either alone or along-with another person who is, or
persons who are, related to the dealer under any of the sub-clauses (i), (ii), (iv), (v) or (vi) of this
clause] directly or indirectly holds forty per cent. or more of stock or shares or voting rights;(iv)is a
person who [either alone or along-with another person who is, or other persons who are, related to
the person under any of the sub-clauses (i), (ii), (iv), (v) or (vi) of this clause] directly or indirectly
owns forty per cent. or more of outstanding voting stock or shares of the dealer or voting rights;(v)is
a company in which forty per cent. or more of outstanding voting stock is held directly or indirectly
by a person [either alone or along-with another person who is, or other persons who are, related to
the person under any of the sub-clauses (i), (ii), (iv), (v) or (vi) of this clause] who also holds forty
per cent. or more of the outstanding voting stock or shares of the dealer; or(vi)is controlled by the
dealer, or a person whom the dealer controls, or is a person who is controlled by the same person
who controls the dealer;(y)"relative" means a relative as defined in clause (41) of section 2 of the
Companies Act, 1956 (1 of 1956);(z)"sale", with its grammatical variations and cognate expression,
means any transfer of property in goods by one person to another for cash or for deferred paymentDaman and Diu Value Added Tax Regulation, 2005

or for other valuable consideration and includes-(i)a transfer of goods on hire-purchase or other
system of payment by installments, but does not include a mortgage or hypothecation of, or a
charge, or pledge, on goods;(ii)supply of goods by a society (including a cooperative society), club,
firm, or any association to its members for cash or for deferred payment or for commission,
remuneration or other valuable consideration, whether or not in the course of business;(iii)transfer
of property in goods by an auctioneer referred to in sub-clause (vii) of clause (i) of this section, or
sale of goods in the course of any other activity in the nature of banking, insurance which in the
course of their main activity also sells goods possession of which has been taken from borrower or
reclaimed;(iv)transfer, otherwise than in pursuance of a contract, of property in any goods for cash,
deferred payment or other valuable consideration;(v)transfer of property in goods (whether as
goods or in some other form) involved in the execution of a works contract;(vi)transfer of the right
to use any goods for any purpose (whether or not for a specified period) for cash, deferred payment
or other valuable consideration;(vii)supply, by way of or as part of any service or in any other
manner whatsoever, of goods, being food or any other article for human consumption or any drink
(whether or not intoxicating), where such supply or service is for cash, deferred payment or other
valuable consideration;(viii)every disposal of goods referred to in sub-clause (ix) of clause (i) of this
section,and the expressions "sell", "buy" and "purchase", shall, with all their grammatical variations
and cognate expressions, be construed accordingly;(za)"sale price" means the amount paid or
payable as valuable consideration for any sale, and includes -(i)the amount of tax, if any, for which
the dealer is liable under section 3;(ii)in relation to the transaction, being delivery of goods on
hire-purchase or any system of payment by installments, the amount of valuable consideration
payable to a person for such delivery including hire-charges, interest and other charges incidental to
such transaction;(iii)in relation to transfer of the right to use any goods for any purpose (whether or
not for a specified period), the valuable consideration or charges received or receivable for such
transfer;(iv)any sum charged for anything done by the dealer in respect of goods at the time of, or
before, the delivery thereof;(v)the amount of duties levied or leviable on the goods under the Central
Excise Act, 1944 (1 of 1944) or the Customs Act, 1962 (52 of 1962), or the Goa, Daman and Diu
Excise Duty Act, 1964 (5 of 1964), as extended to the Union territory of Daman and Diu, whether
such duties are payable by the seller or any other person;(vi)the amount received or receivable by
the seller by way of non-refundable deposit which has been received or is receivable whether by way
of separate agreement or not, in connection with, or incidental to or ancillary to the sale of goods;
and(vii)in relation to works contract, the amount of valuable consideration paid or payable to a
dealer for the execution of the works contract,but does not include -(a)any sum allowed as discount
which reduces the sale price according to the practice normally prevailing in the trade;(b)the cost of
freight or delivery or the cost of installation in cases where such cost is separately
charged;(zb)"Schedule" means a Schedule appended to this Regulation;(zc)"sufficient proof" means
such documents, testimony or other evidence relevant for deposit of tax, filing of return or
proceedings under this Regulation and which may be prescribed;(zd)"tax" means tax leviable and
payable under this Regulation;(ze)"taxable quantum" means the amount specified in subsection (2)
of section 18 ;(zf)"tax invoice" means a tax invoice of the nature referred to in section 50;(zg)"tax
period" means such period as may be prescribed;(zh)"tax fraction" means the fraction calculated in
accordance with formula given below:-r / (r+100)where 'r' is the percentage rate of tax applicable to
the sale under this Regulation;(zi)"transporter" means any person who, for the purposes of, or in
connection with, or incidental to, or in the course of, his business, transports or causes to transportDaman and Diu Value Added Tax Regulation, 2005

goods, and includes any person whose business consists of shipping, air cargo, inland container
depot, container freight station, courier service, airline or railways;(zj)"turnover of purchases"
means the aggregate of the amounts of purchase price (including any input tax) paid or payable by a
person in any tax period;(zk)"turnover" means the aggregate of the amounts of sale price received or
receivable by the person in any tax period, as reduced by any tax for which the person is liable under
section 3;(zl)"value of goods" means the fair market value of the goods and includes insurance
charges, excise duties, countervailing duties, tax paid or payable under the Central Sales Tax Act,
1956, transport charges, freight charges and all other charges incidental to the sale of the
goods;(zm)"works contract" includes any agreement for carrying out, the construction of building,
manufacture, processing, fabrication, erection, installation, fitting out, improvement, repair or
commissioning of any movable or immovable property, whether for cash or the deferred payment or
for other valuable consideration;(zn)"year" means the financial year.
Chapter II
Incidence and Levy of Tax
3. Incidence of tax.
(1)Every dealer, who is registered under this Regulation or required to be registered under this
Regulation, shall be liable to pay tax calculated in accordance with section 11.(2)The tax calculated
under sub-section (1) shall be payable on every sale of goods effected by a dealer -(a)on and from the
day on which the dealer was required to be registered under this Regulation; or(b)during the period
he is registered as a dealer under this Regulation.(3)The liability to pay tax shall be on the sales
effected after a dealer exceeds the taxable quantum.(4)The net tax shall be paid by a dealer within
twenty-eight days from the last day of his tax period.(5)Tax shall be paid in the manner specified in
section 36.(6)Every dealer, who becomes liable to pay tax under this Regulation on the sale of goods,
shall continue to be so liable unless his taxable turnover during any preceding consecutive twelve
months or such further period as may be prescribed, has remained below the taxable quantum and
on the expiry of such twelve months or further period his liability to pay tax shall cease:Provided
that any dealer, whose liability to pay tax under this Regulation ceases for any other reason, may
apply for the cancellation of his certificate of registration on or after the date on which his liability to
pay tax ceases, and on such cancellation, his liability to pay tax shall cease:Provided further that a
dealer shall remain liable to pay tax until the date on which his certificate of registration is
cancelled.(7)Every dealer, whose liability to pay tax under this Regulation has ceased or whose
certificate of registration has been cancelled, shall, if his turnover calculated from the
commencement of any year (including the year in which the registration has been cancelled), at any
subsequent day exceeds the taxable quantum within such year, be liable to pay such tax on and from
the date on which his turnover subsequently exceeds the taxable quantum, on all sales effected by
him on and after that day.(8)Where it is found that any person registered as a dealer ought not to
have been so registered, then notwithstanding anything contained in this Regulation, such person
shall be liable to pay tax for the period during which he was so registered.(9)If any person who
transports goods or holds goods in custody for delivery to, or on behalf of any person, on being
required by the Commissioner -(a)to furnish any information in his possession in respect of theDaman and Diu Value Added Tax Regulation, 2005

goods; or(b)to permit inspection thereof,fails to furnish such information or permit such inspection,
then, without prejudice to any other action which may be taken against such person, under this
Regulation or any other law for the time being in force, a presumption may be raised that the goods
in respect of which he has failed to furnish such information or permit such inspection, are owned
by him and are held by him for sale in Daman and Diu and the provisions of this Regulation shall
apply accordingly.Explanation. - For the removal of doubts it is hereby declared that the tax levied
under this section shall apply to every -(a)sale (including a sale by way of installment or hire
purchase) of goods, made on and after the date of commencement of this Regulation;(b)sale by way
of the transfer of a right to use goods, to the extent that the right to use goods is exercised after the
date of commencement of this Regulation.
4. Rates of tax.
(1)The rates of tax payable on the taxable turnover of a dealer shall be-(a)in respect of goods
specified in the Second Schedule, at the rate of one per cent.;(b)in respect of goods specified in the
Third Schedule, at the rate of four per cent.;(c)in respect of goods specified in the Fourth Schedule,
at the rate of twenty per cent.;(d)in the case of any other goods, not specified in the First, Second,
Third and Fourth Schedules, at the rate of twelve and a half per cent.:Provided that the rate of tax on
packing materials or containers shall be the same as the rate at which the goods so packed or
contained are chargeable to tax.(2)Subject to such conditions as it may impose, the Government
may, if it considers it necessary so to do in the public interest, by notification, specify a lower rate of
tax than rate of tax specified under clauses (a) to (d) of sub-section (1).(3)Every notification made
under sub-section (2) shall be laid, as soon as may be after it is made, before each House of
Parliament, while it is in session, for a total period of thirty days which may be comprised in one
session or in two or more successive sessions, and if, before the expiry of the session immediately
following the session or the successive sessions aforesaid, both Houses agree in making any
modification in the notification or both Houses agree that the notification should not be made, the
notification shall thereafter have effect only in such modified form or be of no effect, as the case may
be, so, however, that, any such modification or annulment shall be without prejudice to the validity
of anything previously done under that notification.
5. Determination of taxable turnover.
(1)For the purposes of this Regulation, taxable turnover means the turnover of a dealer during the
tax period which remains after deducting therefrom -(a)the turnover of sales not liable to tax under
section 7; and(b)the turnover of sales of such goods which are exempt under section 6.(2)(a)In the
case of turnover arising from the execution of a works contract, the taxable turnover means so much
of turnover which represents the price and other charges in relation to goods in such works contract
subject to such conditions as may be prescribed.(b)Where the amount of price and other charges in
relation to the goods in such contract is not ascertainable from the terms and conditions of the
contract, the amount of such price and other charges shall be calculated as the sale price stipulated
in the contract as reduced by the prescribed percentage.Explanation. - For the removal of doubts, it
is hereby declared that where an amount is paid or received prior to the date of commencement of
this Regulation in respect of a sale or purchase occurring after the date of commencement of thisDaman and Diu Value Added Tax Regulation, 2005

Regulation, and the person calculates his turnover or turnover of purchases based on amounts paid
and received, the amount shall be treated as forming part of the person's turnover or turnover of
purchases in the tax period in which the sale or purchase occurs.
6. Sale of certain goods exempt from levy of tax.
(1)The sale of goods specified in the First Schedule shall be exempt from tax:Provided that the
Government may, by notification, specify the conditions and exceptions, if any, for the purposes of
such exemptions.(2)Where a dealer sells capital goods used by him on and from the time of
purchase exclusively for purposes other than making non-taxed sale of goods, and has not claimed a
tax credit in respect of such capital goods under section 9, the sale of such capital goods shall be
exempt from tax.(3)Where any dealer has purchased any goods on the basis of a declaration or
certificate under any order or scheme referred to in sub-section (5) and -(a)any of the conditions
subject to which such exemption was granted, or(b)any of the recitals or the conditions of the
declaration, or certificate,are not complied with for any reason whatsoever, then, without prejudice
to the other provisions of this Regulation, such dealer, shall, notwithstanding that such dealer or
person was not liable to pay tax under any other provisions of this Regulation, be liable to pay tax on
the sale price of the goods at the rates specified in section 4 and accordingly the dealer, who has
become liable to pay tax under this sub-section shall, file a return in the prescribed form to the
prescribed authority within a prescribed time, and include the sale price of such turnover in his
return, and pay the tax in the prescribed manner.(4)The tax due from any dealer referred to in
sub-section (3) shall be assessed and tax recovered as if the dealer is a dealer liable to be proceeded
against under the provisions of this Regulation.(5)Subject to such conditions as the Government
may, by notification, specify, all exports from the export, oriented unit, electronic hardware and
technology park, software technology park unit and the special economic zone located within
Daman and Diu, shall be exempted from the levy of tax.Explanation. - For the purposes of this
sub-section, "export oriented unit", "electronic hardware and technology park", "software
technology park unit" and the "special economic zone" shall mean the delineated area as may be
notified by the Central Government to be such 'Unit' or 'Park' or 'Zone', as the case may be.(6)In a
case where a dealer or a class of dealers had been granted exemption before the commencement of
this Regulation from levy of tax under the Daman and Diu Sales Tax Act, 1964 (4 of 1964) repealed
by section 106, the Government may, by general or special order, published in the Official Gazette,
provide for a deferral scheme (including a scheme providing the manner in which such exemption
from tax shall be continued) or grant exemption from levy of tax to such dealer or class of dealers
and such deferral scheme or exemption shall be for the remaining period for which the dealer or
class of dealers had been exempted under the Act so repealed.
7. Certain sales not liable to tax.
- Nothing contained in this Regulation or the rules made thereunder shall be deemed to impose or
authorize the imposition of tax on any sale of goods when such sale takes place -(a)in the course of
inter-state trade or commerce; or(b)outside Daman and Diu; or(c)in the course of import of the
goods into, or, export of the goods out of, the territory of India.Explanation. - Sections 3, 4 and 5 of
the Central Sales Tax Act, 1956 (74 of 1956) shall apply for determining whether or not a particularDaman and Diu Value Added Tax Regulation, 2005

sale takes place in the manner specified in clause (a) or clause (b) or clause (c) of this section.
8. Adjustments to tax.
(1)The provisions of this section shall apply -(i)where, in relation to the sale of goods by any dealer
-(A)such sale has been cancelled; or(B)the nature of such sale has been varied or altered; or(C)the
consideration agreed for such sale has been altered by agreement with the recipient, whether due to
the offer of a discount or for any other reason; or(D)the goods or part of the goods sold have been
returned to the dealer; or(E)the whole or part of the price payable by the buyer for the purchase of
the goods has been written-off by the dealer as a bad debt; and(ii)the dealer has, in relation to the
sale of goods, -(A)provided a tax invoice in relation to such sale and the amount shown therein is not
the tax properly chargeable on that sale; or(B)furnished a return in relation to such sale and has
accounted for an amount of tax on that sale which is not the amount properly chargeable on that
sale.(2)Where a dealer has accounted for an amount of tax improperly charged as referred to in
sub-section (1), the dealer shall make an adjustment in calculating the tax payable in the return for
the tax period during which it has become apparent that the tax is improperly charged.(3)If the tax
payable in relation to the sale referred to in sub-section (1), exceeds the tax actually accounted for by
the dealer, the amount of the excess tax shall be deemed to accrue during the tax period in which the
adjustment is made, and such excess tax shall not be attributable to any earlier tax period.(4)If the
tax actually accounted for exceeds the tax payable in relation to the sale referred to in sub-section
(1), the amount of shortfall in tax shall be reduced from the tax payable by the dealer during the tax
period in which the adjustment is made, and such shortfall in tax shall not be attributable to any
earlier tax period.(5)Where a dealer sells goods which have been used -(a)partly for making the sales
subject to tax under this Regulation or sales not liable to tax under section 7; and(b)partly for other
purposes,the amount of tax on the sale of the goods shall be the higher of the following : -(i)A - (A x
B / C); or(ii)A - B;whereA = the tax for which the dealer shall be liable in respect of the sales other
than the tax liability arising under this section;B = the amount by which the tax credit of the dealer
in respect of the goods was reduced under sub-section (4) of section 9;C = the amount of the tax
credit before reducing tax credit under sub-section (4) of section 9.
9. Tax credit.
(1)Subject to the provisions contained in sub-section (2), a dealer, who is registered or is required to
be registered under this Regulation, shall be entitled to a tax credit in respect of the turnover of
purchases made during the tax period where the purchase have been made as a dealer and the goods
are meant to be used directly or indirectly by him for the purpose of making -(a)the sales which are
liable to tax under section 3; or(b)the sales which are not liable to tax under section 7.(2)No tax
credit shall be allowed -(a)in the case of purchase of goods from a person who is not a registered
dealer;(b)for the purchase of non-creditable goods specified in the Sixth Schedule;(c)for the
purchase of goods by a person which are to be used as a part of the structure of a building owned or
occupied by such person.Explanation. - For the removal of doubts, it is hereby declared that a tax
credit shall be allowed in respect of the goods and building materials which are purchased by a
person either for the purposes of re-sale without any alteration, or for the performance of a works
contract in respect of a building owned or occupied by another person; and(d)for the goodsDaman and Diu Value Added Tax Regulation, 2005

purchased from a dealer who has opted to pay tax under section 16;(3)The amount of the tax credit
to which a dealer is entitled in respect of the purchase of goods shall be the amount of input tax
arising during the tax period as reduced in the manner specified in sub-sections (4) and
(6).(4)Where a dealer has purchased goods and the goods are to be used partly for the purpose of
making the sales referred to in sub-section (1) and partly for other purposes, the amount of the tax
credit shall be reduced proportionately.(5)Every dealer shall determine, in fair and reasonable
manner, the extent to which the goods are used in the manner specified in sub-section (4):Provided
that in case the Commissioner is of the opinion that the manner determined by the dealer is not fair
and reasonable, he may -(a)after recording the reasons in writing, reject the method adopted by the
dealer and calculate the amount of tax credit after determining such extent in a fair and reasonable
manner; or(b)in consultation with the Government, specify, by notification, the methods for
calculating the amount of tax credit or the amount of any adjustment or reduction of a tax credit in a
case or a class of cases.(6)Where -(a)a dealer has purchased goods (other than capital goods) for
which a tax credit arises under sub-section (1); and(b)the goods so purchased or goods
manufactured out of such goods so purchased are to be exported from Daman and Diu, by way of
transfer to a -(i)consignment agent who is not residing in Daman and Diu and such transfer is not
by way of sale in the Daman and Diu; or(ii)branch of the dealer when such branch is located outside
Daman and Diu and such transfer is not by way of sale in the Daman an Diu,the amount of the tax
credit shall be reduced by such percentage as may be prescribed.(7)No tax credit shall be allowed
under this section for -(a)the purchase of goods from an unregistered dealer;(b)the purchase of
goods which are used exclusively for the manufacture, processing or packing of goods specified in
the First Schedule.(8)The tax credit shall be claimed by a dealer only if he possesses a tax invoice at
the time, prescribed under section 26 or section 27, for filing the return for the tax
period.Explanation. - For the removal of doubts, it is hereby declared that-(i)tax credits arising
under this section shall be allowed only for -(a)a purchase, including a purchase under an
installment sale and hire-purchase of goods, made on and after the date of commencement of this
Regulation; or(b)a purchase by way of the acquisition of a right to use goods, to the extent that the
right to use goods is exercised after the date of commencement of this Regulation;(ii)Nothing
contained in this section shall prevent any person from claiming tax credit allowed under section 14.
10. Adjustment to tax credit.
(1)Where any purchaser has been provided by the seller with a credit note or debit note under
section 51 or if he returns or rejects goods purchased, as a consequence of which the tax credit,
claimed by him in any tax period in respect of which the purchase of goods relates, becomes short or
excess, he shall compensate such shortfall or excess by adjusting the amount of the tax credit
allowed to him in respect of the tax period in which the credit note or debit note had been issued or
goods are returned.(2)If goods which have been purchased were, -(a)intended to be used for any of
the purposes specified under sub-section (1) of section 9 but are subsequently used, fully or partly,
for purposes other than those specified under the said sub-section; or(b)intended for purposes other
than those specified under sub-section (1) of section 9, but are subsequently used, fully or partly, for
any of the purposes specified in the said sub-section,the tax credit claimed in respect of such
purchase shall be reduced or increased, as the case may be, for the tax period during which the said
utilization has taken place.(3)Where -(a)the goods were purchased by a dealer;(b)the dealer claimedDaman and Diu Value Added Tax Regulation, 2005

a tax credit in respect of the goods, and the amount of tax credit has not been reduced under
sub-section (6) of section 9; and(c)the goods are exported from Daman and Diu, other than by way
of a sale, to a branch of the dealer or to a consignment agent,the dealer shall reduce, by the
proportion prescribed under subsection (6) of section 9, the amount of tax credit initially claimed by
him.(4)If goods, which have been purchased by a dealer, -(a)were intended to be used for any of the
purposes specified under sub-section (1) of section 9; and(b)are subsequently used as a part of
structure of a building owned or occupied by him, the tax credit claimed in respect of such purchase
shall be reduced in the tax period during which such use takes place.
11. Calculation of net tax.
(1)The net tax payable by a dealer for a tax period shall be the amount calculated by the formula
given below:-Net Tax = O - I - CWhere -O = the amount of tax payable by the person at the rates
specified in section 4 in respect of the taxable turnover arising during tax period, after making any
adjustments to the tax as required by section 8;I = the amount of the tax credit arising during the
tax period to which the person is entitled under section 9, after making any adjustments to the tax
credit as required by section 10;C = the amount, if any, brought forward from the previous tax
period under sub-section (2).(2)Where the net tax of a dealer calculated for a tax period under
sub-section (1) amounts to a negative value, the dealer shall-(a)adjust the said amount in the same
tax period against the tax payable by him under the Central Sales Tax Act, 1956 (74 of 1956), if any;
and(b)carry forward the surplus amount, if any, after making adjustments under clause (a) to the
next tax period within the same financial year.(3)Where the net tax of the dealer at the end of the
financial year is a negative value, the dealer shall be entitled to claim a refund of any excess amount
of tax and the Commissioner shall deal with claim of refund in the manner specified in sections 38
and 39:Provided that the dealer may opt to adjust the refund under this sub-section as a tax credit in
any succeeding tax period falling in the next financial year.
12. Time at which turnover, turnover of purchases and adjustments arise.
(1)Subject to sub-sections (2), (3) and (4), the amount of the turnover and the turnover of purchases
of a dealer during any tax period shall be the amount recorded in the books of account of the dealer,
where those accounts are regularly and properly prepared and maintained, under this sub-section so
as to give a true and fair view of his business.(2)The Commissioner may, having regard to trade or
accounting practice, by notification, -(a)allow certain classes of dealer to record turnover on the
basis of the amounts paid or received by such dealer; or(b)require certain classes of dealer to record
turnover on the basis of the amounts payable or receivable by such dealer.(3)Where a dealer intends
to change the method of determining the turnover and turnover of purchases, he shall make the
change with the approval of the Commissioner and the Commissioner may grant such approval,
subject to such terms and conditions as he may, having regard to trade or accounting practice, deem
fit.(4)The Government may prescribe the period for which turnover of a dealer, turnover of
purchases made by a dealer and adjustment of tax or adjustment to a tax credit by a dealer shall be
treated as arising for a class of transactions during that period.Daman and Diu Value Added Tax Regulation, 2005

Chapter III
Special Provisions Relating To Used Goods, Composition of
Tax, and Transaction Between Related Persons, etc.
13. Provisions of this Chapter to override provisions of Chapter II.
- The provisions of this Chapter shall have effect, notwithstanding anything inconsistent therewith
contained in any provisions of Chapter II.
14. Treatment of stock brought forward during transition.
(1)Within a period of four months of the commencement of this Regulation, all registered dealers
desirous to claim the tax credit referred to in sub-section (2), shall furnish to the Commissioner a
statement, in the form as may be prescribed, containing details of their trading stock, raw materials
and packaging materials for trading stock (in this section referred to as "opening stock") which -(a)is
held in Daman and Diu on the date of the commencement of this Regulation;(b)was purchased by
the dealer after the 1st day of April,(2)If -(a)the dealer has furnished the statement referred to in
sub-section (1);(b)the tax has been paid in respect of opening stock in accordance with the
provisions of the Daman and Diu Sales Tax Act, 1964 (4 of 1964), as it stood before its repeal by
section 106, at the point specified by the Government under section 8 of the said Act at full rate of
tax specified in the Schedules to that Act; and(c)the opening stock has been purchased by the dealer
from a registered dealer for any of the purposes as are specified in sub-section (1) of section 9,the
amount of tax paid under the Daman and Diu Sales Tax Act, 1964 (4 of 1964), as it stood before its
repeal by section 106, on such opening stock, determined in such manner and subject to such
conditions and restrictions and to the extent as may be prescribed, shall be credited to the registered
dealer as a tax credit under section 9:Provided that no tax credit under this section shall be allowed
unless the dealer has in his possession, invoices issued by a dealer registered under the Daman and
Diu Sales Tax Act, 1964 (4 of 1964), as it stood before its repeal by section 106, in respect of the
purchases of such stock:Provided further that the dealer shall be eligible to claim the entire amount
of credit to which he is entitled if such entire credit is indicated and claimed in a single statement,
which accompanies a return furnished under this Regulation.(3)No tax credit under sub-section (2)
shall be claimed -(a)for finished goods manufactured out of raw material or capital goods on which
tax had been paid;(b)for any goods, which were taxable at last point under the Daman and Diu Sales
Tax Act, 1964 (4 of 1964) as it stood before its repeal by section 106, held at the time of the
commencement of this Regulation;(c)in any statement furnished after the expiry of four months
after the commencement of this Regulation; or(d)for opening stock which is held outside Daman
and Diu.(4)Every dealer, desirous to claim a tax credit for more than one lakh rupees in respect of
the opening stock referred to in sub-section (1), shall furnish along-with the statement a certificate
signed by an accountant in the prescribed form certifying that the net credit claim specified in such
statement is true and correct.(5)Notwithstanding anything contained in section 3, if -(a)a person
was registered as a dealer under the Daman and Diu Sales Tax Act, 1964 (4 of 1964), as it stood
before its repeal by section 106;(b)the person is not registered as a dealer under this Regulation inDaman and Diu Value Added Tax Regulation, 2005

pursuance of section 24, and such person has not made an application for grant of certificate of
registration as a dealer within one month of the date of the commencement of this Regulation;
and(c)on the date of the commencement of this Regulation, the dealer held opening stock of
finished goods in respect of which tax has not been paid under the Daman and Diu Sales Tax Act,
1964 (4 of 1964), as it stood before its repeal by section 106, the person shall be liable to pay tax
under this Regulation at the rate or rates specified in section 4 on the fair market value of the
opening stock of finished goods held on the date of the commencement of this Regulation.(6)The tax
due under sub-section (5) shall be paid within two months from the date of the commencement of
this Regulation.
15. Levy of tax and availing of tax credit on used goods.
(1)This section applies where -(a)a registered dealer sells used goods;(b)the registered dealer has
purchased goods from a resident seller who was not registered under this Regulation;(c)the goods
were purchased either as trading stock for resale without any alteration, or for use as raw
materials;(d)the registered dealer is liable to tax under section 3 on the sale of the goods or the
goods which were manufactured after use of such goods as raw material or part of such goods so
manufactured, as the case may be; and(e)the registered dealer has sufficient proof of the amount
paid for the goods.(2)Subject to the provisions of sub-section (1), the registered dealer shall be
entitled to an amount of tax credit which shall be the lowest of the following, namely: -(a)the input
tax borne by the seller who was residing in Daman and Diu when he purchased the goods;(b)the tax
fraction of the initial cost of the goods to the seller residing in the Daman and Diu;(c)the tax fraction
of the fair market value of the goods at the time of their purchase by the registered dealer;(d)the tax
fraction of the consideration paid by the registered dealer for the goods.(3)Where the amount paid
by the registered dealer for the goods exceeds two thousand rupees, the tax credit shall be allowed in
the tax period during which such goods are sold by the registered dealer or the goods into which
they have been used are sold by the registered dealer.
16. Composition scheme for specified dealers.
(1)Notwithstanding anything contained in this Regulation, every dealer, whose turnover in the year
immediately preceding the commencement of this Regulation or in any subsequent year exceeds the
taxable quantum under this Regulation but does not exceed twenty five lakh rupees or such other
amount as may be specified by the Government by notification, shall have an option to pay tax
under this section:Provided that this section shall not apply to any dealer, who is registered as a
dealer under the Central Sales Tax Act, 1956 (74 of 1956) or who procures goods from any place
outside the Daman and Diu or sells or supplies goods to any place outside the Daman and Diu
during the year in which he opts to pay tax under this section.(2)Every dealer, referred to in
sub-section (1), at the time of making an application for grant of certificate of registration under
section 19, shall be required to specify whether he intends to pay tax under this section:Provided
that in case a dealer opts to pay tax under this section, he may, by an application made to the
Commissioner within such time and in such manner as may be prescribed, withdraw his option at
any time after the end of the year in which such option was made:Provided further that in a case
where a dealer withdraws his option to pay tax under this section, he shall be entitled to claim creditDaman and Diu Value Added Tax Regulation, 2005

of the tax paid under this Regulation on the trading stock, raw material and packaging material held
by him in the Daman and Diu on the date when such option was made subject to the condition or
conditions specified in section 20 and applicable to such dealer.(3)In case a person who intends to
pay tax under this section and -(a)who was registered under the Daman and Diu Sales Tax Act, 1964
(4 of 1964), at the time of the commencement of this Regulation;(b)whose turnover in the year
preceding the commencement of this Regulation or any subsequent year exceeds the taxable
quantum under this Regulation but does not exceed twenty five lakh rupees or such other amount as
may be specified by the Government by notification,he shall specify his intention, within such time
and in such manner as may be prescribed, to pay tax under this section.(4)Where a dealer opts or
intends to pay tax under this section, net tax payable by the dealer shall be the amount determined
at the rate of one per cent. of the turnover of the dealer.(5)A dealer, who opts or intends to pay tax
under this section shall, -(a)not compute his net tax under section 11;(b)not be entitled to claim
credit under section 9 or section 14 or section 15;(c)not be entitled to issue tax invoice;(d)not collect
any amount by way of tax under this Regulation; and(e)retain tax invoices and retail invoices for all
of his purchases, as required under section 48.(6)Every dealer, who opts or intends to pay tax under
this section, shall be required to pay tax on the trading stock, raw material, packaging material (in
this sub-section referred to as "opening stock") and finished goods,-(a)in the case of a dealer
referred to in sub-section (3), held on the date of the commencement of this Regulation; or(b)in the
case of any other dealer, on the date on which he exercises his option or specifies intention under
this section,at the rates specified in section 4 on the fair market value of such opening stock and
finished goods where no tax has been paid which was payable on such opening stock and finished
goods under the Daman and Diu Sales Tax Act, 1964 (4 of 1964), repealed by section 106 or under
this Regulation.(7)Every dealer shall pay the tax due under sub-section (6) at any time before he
opts to pay tax under this section.(8)Every dealer, who opts or intends to pay tax under this section,
shall furnish to the Commissioner the proof of payment of tax referred to in sub-section (6) along
with a statement of opening stock and finished goods, in such form as may be prescribed.
17. Transactions between related persons.
- If -(a)a registered dealer enters into a transaction with the related person for sale of goods or sells
or gives otherwise goods without adequate consideration to a related person; or(b)the terms or
conditions of such transaction or sale or giving of goods have been influenced by seller being related
with such person,the dealer shall not be entitled to a tax credit for the purchase of the goods or he
shall be entitled to the proportionately reduced tax credit under sub-section (3) of section 9 and the
transaction or sale or giving of goods shall be deemed to be a sale made by the registered dealer and
the sale price of the goods shall be deemed to be their fair market value.
Chapter IV
Registration and SecurityDaman and Diu Value Added Tax Regulation, 2005

18. Compulsory and voluntary registration.
(1)Every dealer shall apply for grant of certificate of registration under this Regulation if -(a)the
turnover of the dealer in the year immediately preceding the commencement of this Regulation
exceeded the taxable quantum; or(b)the turnover of the dealer in the year during which this
Regulation comes into force or any year thereafter, exceeds the taxable quantum; or(c)the dealer is
liable to pay tax, or is registered or required to be registered under the Central Sales Tax Act, 1956
(74 of 1956):Provided that a dealer dealing exclusively in goods mentioned in the First Schedule
shall not be required to obtain certificate of registration under this Regulation.(2)For the purposes
of this Regulation, "taxable quantum" of a dealer shall be five lakh rupees, or such other amount as
may be specified, by the Government, by notification:Provided that in the case of a dealer who
imports for sale any goods into the Daman and Diu, the taxable quantum shall be "Nil" or such other
amount as may be specified, by notification, by the Government.(3)For the purposes of this section,
in case of dealers involved in execution of works contracts, the taxable quantum shall be calculated
with reference to the total contract amount received.(4)The taxable quantum of a dealer shall not
include turnover from(a)the sales of capital assets;(b)the sales made in the course of winding up
business of the dealer.(5)Any person, who is not required by sub-section (1) to be registered, but
who is a dealer; or intends from a particular date to undertake the business which would make him a
dealer, may apply for grant of certificate of registration.
19. Registration.
(1)An application for grant of certificate of registration shall, be made in the prescribed form, within
such time, and containing such particulars and information and be accompanied by such fee,
security and other documents as may be prescribed.(2)The Administrator may, by order to be
published in the Official Gazette, specify certain classes of persons who may not be required to
furnish a security.(3)Where -(a)an applicant furnishes, in the prescribed manner, the security for
the amount as may be prescribed; and(b)all requirements and provisions of this Regulation for
grant of certificate of registration have been complied with,such applicant shall be granted a
certificate of registration under this Regulation.(4)Where the certificate of registration has not been
granted to the applicant within fifteen days from the date on which the application is made, the
Commissioner shall, after making such inquiries as he deems fit, either -(a)grant certificate of
registration forthwith to the applicant; or(b)issue a notice to the applicant, clearly stating the
grounds on which his application is proposed to be rejected and allowing him to show cause in
writing, within further fifteen days, why his application should not be rejected:Provided that where
the certificate of registration has not been granted to the applicant or such applicant has not been
issued a notice by the required date, the applicant shall be deemed to be registered for the purposes
of this Regulation, and the Commissioner shall grant a certificate of registration to such
applicant.(5)Where the applicant submits a reply to the notice, under clause (b) of sub-section (4),
the Commissioner may, either accept the application and grant a certificate of registration to the
applicant, or reject the application for reasons to be recorded in writing.(6)If the applicant fails to
submit any reply to the notice issued under clause (b) of sub-section (4) within the stipulated time,
the application for grant of certificate of registration shall stand rejected.(7)Where a registered
dealer has furnished a security as a condition for grant of certificate of registration, such securityDaman and Diu Value Added Tax Regulation, 2005

shall be necessary for the continuance in effect of the certificate of registration, unless otherwise
provided by the Commissioner.
20. Effect of registration.
(1)If a certificate of registration is granted at any time after the commencement of this Regulation
and -(a)the dealer holds trading stock for the purpose of sale, or for use as raw materials for the
production of trading stock;(b)the dealer has paid input tax on the purchase of the trading stock or
raw materials;(c)the dealer furnishes a statement of its trading stock and raw materials in the
prescribed form to the Commissioner; and(d)the dealer possesses sufficient proof of the amount of
input tax in respect of the purchases,such dealer shall be entitled to a tax credit for the trading stock
or raw materials held by the dealer on the date on which the certificate of registration come into
force:Provided that the dealer shall claim the entire amount of tax credit to which he is entitled, in a
single claim which accompanies the first return furnished by the dealer under this Regulation.(2)For
the purposes of sub-section (1), the amount of the tax credit shall be the least of the following,
namely: -(a)the amount of input tax disclosed in the proof referred to in clause (d) of sub-section
(1); or(b)the tax fraction of the cost of the goods; or(c)the tax fraction of the fair market value of the
goods at the time of registration; or(d)the amount specified under sub-section (3) of section
9.(3)Where the registered dealer specifies in his books of account the turnover on the basis of
amounts received and amounts paid, he shall exclude from his turnover -(a)any amount received
after he has been granted a certificate of registration in respect of sales made and such amount
relates to the period during which he had not been granted a certificate of registration under this
Regulation; and(b)any amount paid after he is registered in respect of purchases made and such
amount relates to the period during which he had not been granted a certificate of registration
under this Regulation.
21. Amendment of registration.
(1)A registered dealer shall inform, the Commissioner in the prescribed manner, within one month,
if he -(a)sells or otherwise disposes of his business or any part of his business or any place of
business, or effects, or comes to know of, any other change in the ownership of the business;
or(b)discontinues his business or changes his place of business or warehouse, or opens a new place
of business, or closes the business for a period of more than one month; or(c)changes the name,
style, constitution or nature of his business; or(d)enters into partnership or other association in
regard to his business or adds, deletes or changes the particulars of the persons having interest in
his business.(2)If any such registered dealer dies, his legal representative shall, in like manner
specified under sub-section (1), inform the Commissioner.(3)The Commissioner may, after
considering any information furnished under this Regulation or otherwise received and after
making such inquiry as he may deem fit, amend from time to time any certificate of registration
granted under this Regulation.(4)An amendment to certificate of registration made under
sub-section (3) shall take effect from the date of contingency which necessitates the amendment
whether or not information in that behalf is furnished within the time prescribed under subsection
(1).(5)Any amendment to a certificate of registration under this section shall be without prejudice to
any liability for tax or interest or penalty imposable or for any prosecution for an offence under thisDaman and Diu Value Added Tax Regulation, 2005

Regulation.(6)For the removal of doubts, it is hereby declared that where a registered dealer
-(a)effects a change to the nature of the goods ordinarily sold; or(b)is a firm and there is a change in
the constitution of the firm without dissolution thereof; or(c)is a trustee of a trust and there is a
change in the trustees thereof; or(d)is a Hindu undivided family and the business of such family is
converted into a partnership business with all or any of the members of the family as partners
thereof; or(e)is a firm or a company or a trust or other organization, and a change occurs in the
management of the organization,then, merely by reason of the circumstances aforesaid, it shall not
be necessary for the registered dealer to apply for a fresh certificate of registration and on
information being furnished the certificate of registration shall be amended.
22. Cancellation of certificate of registration.
(1)Where -(a)a registered dealer, who is required to furnish security under the provisions of this
Regulation, has failed to furnish or maintain such security; or(b)a registered dealer has ceased to
carry on any activity or business which would entitle him to be registered as a dealer under this
Regulation; or(c)an incorporated body has been wound up or otherwise ceases to exist; or(d)the
owner of a proprietorship business dies leaving no successor to carry on the business; or(e)in the
case of a firm or association of persons, it is dissolved; or(f)registered dealer has ceased to be liable
to pay tax under this Regulation; or(g)a registered dealer knowingly furnishes a return which is
misleading or deceptive in a material particular; or(h)a registered dealer has committed one or more
offences or contravened the provisions of this Regulation; or(i)the Commissioner, after conducting
proper inquiries, is of the view that it is necessary to do so,the Commissioner may, after service of a
notice in the prescribed form and after giving the dealer an opportunity of being heard, cancel the
certificate of registration of the dealer with effect from the date, as may be, specified by him in the
notice.(2)Where -(a)a registered dealer has ceased to carry on any activity which would entitle him
to be registered as a dealer under this Regulation; or(b)an incorporated body has been wound up or
otherwise ceases to exist; or(c)the owner of a proprietorship business dies leaving no successor to
carry on business; or(d)in the case of a firm or association of persons, it is dissolved; or(e)a
registered dealer has ceased to be liable to pay tax under this Regulation,the registered dealer or the
dealer's legal representative in case of clause (c) above, shall make an application for cancellation of
his certificate of registration to the Commissioner in the manner and within the time as may be
prescribed.Explanation. - For the purpose of this sub-section, "legal representative" has the same
meaning as assigned to it in clause (11) of section 2 of the Code of Civil Procedure, 1908 (5 of
1908).(3)On receipt of such application, if the Commissioner is satisfied that the dealer has ceased
to be entitled to be registered, he may cancel the certificate of registration.(4)If a registered dealer
ceases to be registered, the Commissioner shall cancel the certificate of registration of the
dealer.(5)If certificate of registration of a dealer, which has been cancelled under this section, has
been restored as a result of an appeal or other proceeding under this Regulation, the certificate of
registration of such dealer shall be restored and he shall be liable to pay tax as if his registration had
never been cancelled.(6)If any registered dealer, whose certificate of registration has been restored
under sub-section (5), satisfies the Commissioner that an excess tax has been paid by him during the
period of his certificate of registration was not in force which, but for the cancellation of his
certificate of registration, he would not have paid, then the amount of such tax shall be adjusted or
refunded in such manner, as may be prescribed.(7)Every registered dealer, who applies forDaman and Diu Value Added Tax Regulation, 2005

cancellation of his certificate of registration, shall surrender with his application the certificate of
registration granted to him and every registered dealer whose certificate of registration is cancelled
otherwise than on the basis of his application shall surrender the certificate of registration within
seven days of the date of communication to him of the cancellation.(8)The Commissioner shall, at
intervals not exceeding three months, publish in the Official Gazette, such particulars as may be
prescribed, of registered dealers whose certificate of registration has been cancelled.(9)The
cancellation of certificate of registration shall not affect the liability of any person to pay tax due for
any period and unpaid as on the date of such cancellation or which is assessed thereafter
notwithstanding that he is not otherwise liable to pay tax under this Regulation.
23. Effect of cancellation of certificate of registration.
(1)Every person, whose certificate of registration has been cancelled, shall pay in respect of all goods
held on the date of cancellation an amount equal to the amount of -(a)the tax which would be
payable in respect of those goods if the goods were sold at their fair market value on that date;
or(b)the tax credit previously claimed in respect of those goods,whichever is higher.(2)Where the
dealer has specified in his books of account the turnover on the basis of amounts received and
amounts paid, he shall include in the turnover of his last return -(a)any amount not yet received in
respect of sales made while he was registered as a dealer under this Regulation; and(b)any amount
not yet paid in respect of purchases made while he was registered as a dealer under this Regulation.
24. Registration during transition.
(1)Every dealer -(a)who has been registered under the Daman and Diu Sales Tax Act, 1964 (4 of
1964), on or before the commencement of this Regulation; and(b)whose turnover, in the year
preceding the year in which this Regulation comes into force, exceeds the taxable quantum,shall be
deemed to be registered under this Regulation from the date on which this Regulation comes into
force.(2)The security furnished by a dealer registered under the Daman and Diu Sales Tax Act, 1964
(4 of 1964), and such security being valid on the date of the commencement of this Regulation, shall
be deemed to have been furnished under this Regulation and shall be valid under this Regulation for
a period of six months from the commencement of this Regulation or till a fresh security as required
under sub-section (3) is furnished, whichever is later.(3)Every dealer referred to in sub-section (1)
shall, within a period of six months of the commencement of this Regulation, be required to furnish
a fresh security under this Regulation:Provided that the Commissioner may, having regard to the
financial position of the dealer and any other matter which the Commissioner considers relevant, by
notification, exempt a class or classes of dealers from the requirement of furnishing a fresh security
under this sub-section.
25. Requirement of furnishing security.
(1)The Commissioner may, for the purpose of -(a)granting a certificate of registration to a person as
a dealer; or(b)making a refund under section 38,require such person to furnish security, for the
proper discharge of obligations by him under this Regulation or under the Central Sales Tax Act,
1956 (74 of 1956), for such amount equivalent to the amount which may be prescribed and in theDaman and Diu Value Added Tax Regulation, 2005

manner and within such time, as may be prescribed.(2)Notwithstanding anything contained in
sub-section (1), the Commissioner may increase, reduce or waive the prescribed amount of the
security, having regard to -(a)the nature and size of the business activities of the person;(b)the
amount of any tax, interest or penalty for which the person may be, or is likely to become, liable at
any time under this Regulation;(c)the creditworthiness of the person;(d)the nature of the security;
and(e)any other matter which the Commissioner considers relevant.(3)Where the security or
additional security furnished by a person is in the form of a surety bond and the surety dies or
becomes insolvent, the person shall, within one month of the occurrence of such event, inform the
death or insolvency of such surety to the Commissioner and execute a fresh surety bond within three
months of such occurrence.(4)Where the surety bond has been executed in favour of a person by
another registered dealer and the certificate of registration of such dealer has been either cancelled
or he has closed down his business, the person shall furnish a fresh surety as may be prescribed and
in the manner as stated in sub-section (3).(5)The Commissioner may, for good and sufficient cause,
order the forfeiture of the whole or any part of the security furnished by a person.(6)Where the
security furnished by any person is forfeited in whole or is rendered insufficient, he shall furnish a
fresh security of the requisite amount or, as the case may be, shall make up the deficiency in such
manner and within such period as may be specified.
Chapter V
Returns
26. Furnishing of periodical returns.
- Every registered dealer, who is liable to pay tax under this Regulation, shall furnish to the
Commissioner such returns in the prescribed form for each tax period and by such dates as may be
prescribed.
27. Furnishing of other returns.
- In addition to the returns specified in section 26, the Commissioner may require any person
(including an agent or trustee of such person), whether a registered dealer or not, to furnish him
with such other returns as the Commissioner may specify and such other returns shall be furnished
within such time and in such form as may be prescribed.
28. Furnishing of revised return for rectification of mistake.
(1)If, within four years of the making of an assessment, any person discovers any mistake or error in
any return furnished by him under this Regulation, and he has, as a result of the mistake, or error,
paid less tax than was due under this Regulation, he shall, within one month after the discovery,
furnish a revised return and pay the tax owed and interest thereon.(2)If, within four years of the
making of an assessment, any person discovers any mistake or error in any return furnished by him
under this Regulation, and he has, as a result of the mistake or error, paid more tax than was due
under this Regulation, he may file an appeal against the assessment in the manner and subject toDaman and Diu Value Added Tax Regulation, 2005

the conditions stipulated in section 74.
29. Signing returns.
(1)Every return under this Chapter shall be signed and verified -(a)in the case of an individual, by
the individual himself, and where the individual is absent from India, either by the individual or by
some person duly authorised by him in this behalf and where the individual is mentally
incapacitated from attending to his affairs, by his guardian or by any other person competent to act
on his behalf;(b)in the case of a Hindu undivided family, by a Karta and where the Karta is absent
from India or is mentally incapacitated from attending to his affairs, by any other adult member of
such family;(c)in the case of a company or local authority, by the principal officer thereof;(d)in the
case of a firm, by any partner thereof, not being a minor;(e)in the case of any other association, by
any member of the association or persons;(f)in the case of a trust, by the trustee or any trustee;
and(g)in the case of any other person, by some person competent to act on his behalf.(2)For the
purposes of this section, -(a)the expression "principal officer" shall have the meaning assigned to it
under clause (35) of section 2 of the Income-tax Act, 1961 (43 of 1961);(b)any return signed by a
person, who is not authorised under this section, to sign and verify the return, shall be treated as if
no return has been furnished.
Chapter VI
Assessment and Payment of Tax, Interest and Penalties and
Making Refunds
30. Assessment of tax, interest or penalty.
- The Commissioner shall direct any person to pay any amount of tax, interest or penalty or other
amount due under this Regulation after making of an assessment for such amount payable by such
person.
31. Self assessment.
(1)Where a return is furnished by a person as required under section 26 or section 27 and which
contains the prescribed information and accompanies the relevant documents required to
accompanied under this Regulation and such person has complied with the other requirements
specified under this Regulation and the rules and orders made thereunder, an assessment of the tax
payable of the amount specified in the return shall be deemed to have been made, under this
Regulation, on the day on which such return was furnished.(2)No assessment shall be deemed to
have been made under sub-section (1), if the Commissioner has already made an assessment of tax
in respect of the same tax period under any other provision of this Regulation.Daman and Diu Value Added Tax Regulation, 2005

32. Default assessment of tax payable.
(1)If any person -(a)has not furnished returns required under this Regulation by the prescribed date;
or(b)has furnished incomplete or incorrect returns; or(c)has furnished a return which is not
accompanied by the documents required to be filed along-with the return under this Regulation or
rules made thereunder; or(d)has furnished a return which is not in conformity with the provisions
of this Regulation or rules made thereunder,the Commissioner may, for reasons to be recorded in
writing, assess or re-assess to the best of his judgment the amount of net tax due for any tax period
or tax periods.(2)Where the Commissioner has made an assessment under sub-section (1), the
Commissioner shall forthwith serve on concerned person a notice of assessment of the amount of
any additional tax due for that tax period.(3)Where the Commissioner has made an assessment
under sub-section (1) and subsequently any further tax is assessed as due, the amount of further tax
so assessed as due shall also be payable on the same date being the date on which the net tax for the
tax period was due.
33. Assessment of penalty.
(1)Where the Commissioner has reason to believe that a liability to pay a penalty under section 86
has arisen, the Commissioner, after recording the reason in writing, shall serve on the person
concerned a notice of assessment of the penalty which has become due under this Regulation.(2)The
amount of any penalty assessed under this section shall become due on the date on which the notice
of assessment has been served by the Commissioner.
34. Limitation on assessment and re-assessment.
(1)No assessment or re-assessment shall be made by the Commissioner after the expiry of four years
from -(a)the date on which the person furnished a return under section 26 or sub-section (I) of
section 28; or(b)the date on which the Commissioner made an assessment of tax under section
32,whichever is the earlier:Provided that where the Commissioner has reason to believe that tax was
not paid by reason of concealment, omission or failure to disclose material particulars on the part of
the person, the assessment or re-assessment may be made by the Commissioner within six years
from the dates specified in clause (a) or clause (b), as the case may be.(2)Notwithstanding anything
contained in sub-section (1), the Commissioner may make an assessment of tax within one year
from the date of any decision of the Appellate Tribunal or court where the assessment is required to
be made in consequence of, or to give effect to, the decision of the Appellate Tribunal or court which
requires the re-assessment of the person.
35. Collection of assessed tax and penalties.
(1)Subject to the provisions of sub-sections (2) and (4), where an amount of tax or penalty has been
assessed under section 32 or section 33, the Commissioner may not proceed to enforce payment of
the amount assessed until two months after 36 the date of service of the notice of
assessment.(2)Where a person has made an appeal to an assessment or part of an assessment in theDaman and Diu Value Added Tax Regulation, 2005

manner provided in section 74, the Commissioner shall not enforce the payment of any amount in
dispute under that assessment until the appeal is decided by the Commissioner.(3)Nothing in this
section shall stay any proceedings by the Commissioner or before a court for the recovery of any
amount due under this Regulation -(a)which are not the subject of a dispute before the
Commissioner; or(b)which has not been stayed by the Appellate Tribunal or
Court.(4)Notwithstanding anything contained in sub-section (1), where an amount of tax or penalty
has been assessed by the Commissioner and he is satisfied that it may not be possible to recover the
amount assessed if collection of such amount is delayed, or it will be detrimental to revenue if the
full period of two months referred to in sub-section (1) is allowed, the Commissioner may specify a
date in the notice of assessment as the date being earlier than said two months after the date of
service of the notice of assessment.
36. Manner of payment of tax, penalties and interest.
- Every person, liable to pay tax, interest, penalty or any other amount under this Regulation, shall
pay the amount to the Government Treasury of Daman and Diu, or a branch in Daman and Diu of a
bank which may be prescribed, or at such other place or in such other manner as may be prescribed.
37. Order of application of payments.
- Where an amount of tax, interest, or penalty is payable by any person under this Regulation and
such person pays in part, or the Commissioner recovers in part, an amount of such tax, interest, or
penalty due under this Regulation, the amount of tax, interest, or penalty so paid or recovered shall
be adjusted from interest, penalty and tax payable under this Regulation and thereafter from the
interest, penalty and tax payable under the Central Sales Tax Act, 1956 (74 of 1956) if such interest,
penalty and tax payable relate to the sale of goods from the Daman and Diu under that Act.
38. Refunds.
(1)Subject to the other provisions of this section and the rules made thereunder, the Commissioner
shall refund to a person the amount of tax, penalty and interest, if any, paid by such person in excess
of the amount assessed or deemed to have been assessed and due from him.(2)Before making any
refund, the Commissioner shall first apply such excess referred to in sub-section (1) towards the
recovery of any other amount due under this Regulation, or thereafter from the dues under the
Central Sales Tax Act, 1956 (74 of 1956) if such dues relate to sale of goods from the Daman and Diu
under that Act.(3)Subject to the provisions of sub-section (4), any amount remaining at the end of
the financial year after the application of the excess amount referred to in sub-section (2) shall, at
the option of the dealer, either -(a)be refunded to the person within one year after the date on which
the claim was made for the refund; or(b)be carried forward to the next tax period as a tax credit in
that period.(4)Where the Commissioner has issued a notice to the person under section 58
informing him that an audit, investigation or inquiry into his business affairs shall be undertaken,
the excess amount referred to in sub-section (2) shall be carried forward to the next tax period as a
tax credit in that period.(5)The Commissioner may, as a condition of the payment of a refund under
this section, demand security from the person pursuant to the powers conferred in sectionDaman and Diu Value Added Tax Regulation, 2005

25.(6)Notwithstanding anything contained in this section, where -(a)a registered dealer has sold
goods to a person who is not registered as a dealer under this Regulation;(b)the price charged for
the goods includes an amount of tax payable under this Regulation; and(c)the dealer claims refund
of this amount or to apply this amount under clause (b) of sub-section (3),no amount shall be
refunded to the dealer or may be applied by the dealer under clause (b) of sub-section (3) unless the
Commissioner is satisfied that the dealer has refunded the amount to the purchaser.(7)Where -(a)a
registered dealer (hereafter referred to as seller) has sold goods to another registered dealer
(hereafter referred to as the buyer); and(b)the price charged for the goods expressly includes an
amount of tax payable under this Regulation,the amount of tax may be refunded to the seller or may
be applied by the seller under clause (b) of sub-section (3) and in that case the Commissioner may
reassess the buyer to disallow him the amount of the corresponding tax credit claimed by such
buyer, whether or not the seller refunds the amount to the buyer.(8)Where a registered dealer sells
goods and the price charged for the goods expressly indicate inclusion of an amount of tax payable
under this Regulation, the amount of the tax may be refunded to the seller or may be applied by the
seller under clause (b) of sub-section (3) without the seller being required to refund an amount of
the tax to the purchaser.(9)Notwithstanding anything contained in this section, if a registered dealer
has filed any return as required under this Regulation and the return shows any amount of the tax as
refundable to the dealer on account of sales in course of export out of the territory of India, then, the
dealer may apply in the manner and form prescribed, to the Commissioner for grant of provisional
refund pending audit and investigation to establish the correctness of the claim and consequent
assessment, if any, subject to the provisions of sub-section (10).(10)Subject to the provisions of
sub-section (3), the Commissioner may require the dealer to furnish a bank guarantee or other
security, as may be prescribed, for an amount equal to the amount of refund of tax and on receipt of
such guarantee or other security, the Commissioner shall grant the dealer a provisional refund
which may be determined as refundable within ninety days of application of claim of such
refund.(11)The Commissioner may direct the assessment or reassessment of such dealer in respect
of the year containing the period covered by the said return as expeditiously as possible and adjust
the grant of provisional refund against tax due, if any, as a result of such assessment.(12)If, on
assessment or reassessment, the provisional refund granted under sub-section (2) is found to be in
excess, then the excess shall be recovered as if it is tax due from the dealer under this
Regulation.(13)In a case the excess amount of tax has been refunded under sub-section (3), the
interest shall be payable on such excess amount at the rate of two per cent. per month from the date
of grant of provisional refund till the date of assessment or reassessment, as the case may be.
39. Power to withhold refund in certain cases.
(1)Where a person is entitled to a refund and any proceeding under this Regulation is pending
against him, or a notice under section 58 had been issued and assessment or reassessment in
pursuance of the notice is pending and the Commissioner is of the opinion that payment of such
refund is likely to adversely affect the revenue and that it may not be possible to recover the amount
later, the Commissioner may for reasons to be recorded in writing, either obtain a security equal to
the amount to be refunded to the person or withhold the refund till such time the proceeding or the
assessment or re-assessment has been concluded or made.(2)Where a refund is withheld under
sub-section (1), the person shall be entitled to interest as provided under sub-section (1) of sectionDaman and Diu Value Added Tax Regulation, 2005

42 if, as a result of the appeal, or any other proceeding he becomes entitled to the refund.
40. Collection of tax only by registered dealers.
(1)No person who is not a registered dealer shall collect in respect of any sale of goods by him in
Daman and Diu any amount by way of tax under this Regulation and no registered dealer shall make
any such collection except in accordance with this Regulation and the rules made thereunder and at
the rates specified under this Regulation.(2)Tax collected by a person who is not a registered dealer
shall, without prejudice to any penalty or prosecution under this Regulation, stand forfeited to the
Government.
41. Refund of tax for Embassies, officials, international and public
organizations.
(1)The Embassies, diplomatic officials and international or public organizations specified in the
Fifth Schedule shall be entitled to claim a refund of tax paid on goods purchased in the Daman and
Diu, subject to such restrictions and conditions as may be prescribed.(2)Any person entitled to a
refund under sub-section (1) may apply to the Commissioner in the manner and within the time, as
may be prescribed.
42. Interest.
(1)(a)A person entitled to a refund under this Regulation, shall be entitled to receive, in addition to
the refund, simple interest at such rate, as may be notified by the Government from time to
time.(b)The simple interest at the rate specified under sub-section (1) shall be calculated from
-(i)the date from which the refund was due to be paid to the person; or(ii)the date on which the
person paid the excess amount,whichever is later, and such interest shall be calculated upto the date
on which the refund is given.(c)The interest shall be calculated on the amount of refund due after
deducting therefrom any tax, interest, penalty or any other dues under this Regulation, or under the
Central Sales Tax Act, 1956 (74 of 1956), if such dues relate to the sale of goods from Daman and
Diu.(d)If the amount of such refund is enhanced or reduced, as the case may be, such interest shall
be enhanced or reduced accordingly.(e)If the delay in granting the refund is attributable to the said
person, whether wholly or in part, the period of the delay attributable to him shall be excluded from
the period for which the interest is payable.(2)When a person is in default in making the payment of
any tax, penalty or other amount due under this Regulation, he shall, in addition to the amount
assessed, be liable to pay simple interest on such amount at such rate, as may be notified by the
Government from time to time from the date of such default until he makes such payment of tax,
penalty or other amount.(3)Where the amount of tax (including any penalty due) is wholly reduced,
the amount of interest, if any, paid shall be refunded, or if such amount is varied, the interest due
shall be calculated accordingly.(4)Where the collection of any amount is stayed by the order of the
Appellate Tribunal or any court or any other authority and the order is subsequently vacated,
interest shall be payable for any period during which such order remained in operation.(5)The
interest payable by a person under this Regulation may be collected as tax due under this RegulationDaman and Diu Value Added Tax Regulation, 2005

and shall be due and payable on and from the date on which the obligation to pay the interest has
arisen.
Chapter VII
Recovery of Tax, Interest and Penalties
43. Recovery of tax.
(1)The amount of any tax, interest, penalty or other amount due under this Regulation shall be paid
in the manner specified in section 36 and a notice of assessment served on the person for such an
amount shall constitute a demand for payment of the amount stated in the assessment by the time
stipulated in the notice of assessment.(2)On an application made before the expiry of the period
under section 35, the Commissioner may, in respect of any dealer or person and for reasons to be
recorded in writing, extend the time for payment or allow payment by installments, subject to such
conditions as he may think fit to impose in the circumstances of the case.(3)Any amount of tax,
interest or penalty or other amount due under this Regulation which remains unpaid, shall be
recoverable as arrears of land revenue.(4)Where security, other than in the form of surety bond, has
been furnished under the Regulation, the Commissioner may, for reasons to be recorded in writing,
recover any amount of tax, interest, penalty or other amount due or part thereof by ordering the
forfeiture of the whole or any part of the security.(5)Where any security tendered for the purposes of
this Regulation is to be sold, it shall be sold in the manner stipulated in section 63.
44. Application of Goa, Daman and Diu Land Revenue Code, 1968 for
purposes of recovery.
- For the purposes of recovery of any amount recoverable as arrears of land revenue under this
Regulation, the provisions of the Goa, Daman and Diu Land Revenue Code, 1968 (9 of 1969), or any
other law made applicable to Daman and Diu as to the recovery of arrears of land revenue in the
Daman and Diu shall, notwithstanding anything contained in that Act or in any other enactment, be
deemed to be in force throughout the Daman and Diu.
45. Continuation of certain recovery proceedings.
- Where an assessment or notice of demand in respect of any tax, penalty or other amount payable
under this Regulation (hereinafter in this section referred to as "Government dues") is served upon
any person and any appeal has been filed by the person against the assessment or demand for such
government dues, then -(a)if the appeal is disallowed in whole or in part, any recovery proceedings
taken for the recovery of such Government dues before the making of the appeal, may, without the
service of any fresh assessment or notice of demand, be continued from the stage at which such
recovery proceedings stood immediately before the person filed the appeal; and(b)where such
Government dues are reduced in any appeal -(i)it shall not be necessary for the Commissioner to
serve upon the person a fresh assessment or notice of demand; and(ii)the Commissioner shall giveDaman and Diu Value Added Tax Regulation, 2005

intimation of such reduction to him and to the person with whom recovery proceedings are pending.
46. Special mode of recovery.
(1)Notwithstanding anything contained in any law or contract to the contrary, the Commissioner
may, at any time, by notice in writing, a copy of which shall be forwarded to the person at his last
known address, require, -(a)any person from whom any amount of money is due, or may become
due, to the person (in this section called "the taxpayer") liable to pay tax, interest or penalties under
section 45, or(b)any person who holds or may subsequently hold money, for or, on account of, the
taxpayer,to pay, either forthwith upon the money becoming due or being held or within the time
specified in the first mentioned notice (but not before the money becomes due or is held as
aforesaid) so much of the money as is sufficient to pay the amount due by the taxpayer in respect of
the arrears of tax, interest and penalty under this Regulation, or the whole of the money when it is
equal to or less than that amount.Explanation. - For the purposes of this sub-section, the amount
due to a taxpayer from, or money held for or on account of a taxpayer by any person, shall be
calculated by the Commissioner after deducting therefrom such claims, if any, lawfully subsisting, as
may have fallen due for payment by such taxpayer to such person.(2)The Commissioner may amend
or revoke any such notice referred to in this section or extend the time for making any payment in
pursuance of the notice.(3)Any person making any payment in compliance with a notice under this
section shall be deemed to have made the payment under the authority of the taxpayer, and the
receipt thereof by the Commissioner shall constitute a good and sufficient discharge of the liability
of such person to the extent of the amount specified in the receipt.(4)Any person discharging any
liability to the taxpayer after receipt of the notice referred to in this section, shall be personally liable
to the Commissioner to the extent of the liability discharged or to the extent of the liability of the
dealer for tax and penalty, whichever is less.(5)Where a person to whom a notice under this section
is sent, proves to the satisfaction of the Commissioner that the sum demanded or any part thereof is
not due to the taxpayer or that he does not hold any money for or on account of the taxpayer, then,
nothing contained in this section shall be deemed to require such person to pay any such sum or
part thereof, as the case may be, to the Commissioner.(6)Any amount of money which the aforesaid
person is required to pay to the Commissioner, or for which he is personally liable to the
Commissioner under this section shall, if it remains unpaid, be recoverable as if arrears of land
revenue.(7)The Commissioner may apply to the court in whose custody there is money belonging to
the taxpayer for payment to him of the entire amount of such money or if it is more than the tax,
interest and penalty, if any, due, an amount sufficient to discharge such tax and the penalty.
47. Transfer of assets during pendency of proceedings void.
- Where, during the pendency of any proceedings for the recovery of an amount due by a person
under this Regulation, that person creates a charge on, or parts with the possession by way of sale,
mortgage, gift or exchange or any other mode of transfer whatsoever, any of his assets in favour of
any other person, such charge or transfer shall be void against any claim by the Commissioner in
respect of the amount which is the subject of proceedings, unless the other person -(a)acted bona
fide and without notice of the recovery proceedings; and(b)has paid the fair market value for the
assets.Daman and Diu Value Added Tax Regulation, 2005

Chapter VIII
Accounts and Records
48. Accounts and records.
(1)Every -(a)dealer; and(b)person on whom a notice has been served to furnish returns under
section 27,shall prepare and retain sufficient records to allow the Commissioner to ascertain the
amount of tax due under this Regulation, and to explain all transactions, events and other acts
engaged in by the person that are relevant for any purposes of this Regulation.(2)Notwithstanding
the generality of sub-section (1) -(a)every registered dealer shall preserve a copy of all tax invoices
issued by him;(b)every dealer shall preserve the original of all tax invoices received by him;
and(c)every person who has paid an amount of tax, interest, penalty or other amount due under this
Regulation, shall preserve a copy of the challan evidencing the making of the payment.(3)Every
dealer shall prepare and maintain the accounts and records in the manner and form as may be
prescribed.(4)If the Commissioner considers that such records are not properly maintained to
enable him to ascertain discharge of the obligations by the person under this Regulation, he may
require such person by notice in writing to maintain such accounts (including records of purchases
and sales) as may be specified in the notice.(5)The Commissioner may, by notification, direct any
class of dealers, transporters or operators of warehouses to maintain such accounts (including
records of purchases and sales) as may be specified in the notification.(6)Every person required to
prepare or preserve accounts and records shall retain the required accounts and records for seven
years after the conclusion of the events or transactions which they record unless any proceedings in
respect of any event or transaction is pending in that case they shall be preserved till the final
decision in those proceedings.(7)Any loss, if any, of accounts and records referred to in sub-section
(6) shall be reported to the Police and the Commissioner within a period of fifteen days from the
date of such loss.
49. Accounts to be audited in certain cases.
- If in respect of any particular year, the gross turnover of a dealer exceeds forty lakh rupees or such
other amount as may be prescribed, then, such dealer shall get his accounts in respect of such year
audited by an accountant within six months from the end of that year and obtain within that period
a report of such audit in the prescribed form duly signed and verified by such accountant and setting
forth such particulars as may be prescribed and a true copy of such report shall be furnished by such
dealer to the Commissioner by the prescribed date.
50. Tax invoices.
(1)A registered dealer, making a sale liable to tax under this Regulation, shall, at the request of the
purchaser, provide the purchaser at the time of sale a tax invoice containing the particulars specified
in sub-section (2) and retain a copy thereof:Provided that a tax invoice shall not be issued-(a)by a
dealer who opts to pay tax under section 16; or(b)for the sale in the course of inter-state trade or
commerce or export by a dealerand in such cases a retail invoice shall be issued:Provided furtherDaman and Diu Value Added Tax Regulation, 2005

that not more than one tax invoice shall be issued for each such sale:Provided also that if an invoice
has been issued under the provisions of the Central Excise Act, 1944 (1 of 1944), it shall be deemed
to be a tax invoice if it contains the particulars specified in sub-section (2).Explanation. - For
removal of doubts, a registered dealer shall be authorised to issue tax invoices only after a certificate
of registration has been granted under this Regulation.(2)The tax invoice issued under sub-section
(1) shall contain the following particulars on the original as well as copies thereof, namely :-(a)the
words 'tax invoice' in a prominent place;(b)the name, address and registration number of the selling
registered dealer;(c)the name and address of the purchaser and his registration number, where the
purchaser is a registered dealer;(d)an individual pre-printed serialized number and the date on
which the tax invoice is issued;(e)description, quantity, volume and value of goods sold and services
provided and the amount of tax charged thereon indicated separately;(f)the signature of the selling
dealer or his manager, agent or servant duly authorised by him; and(g)the name and address of the
printer and first and last serial number of tax invoices printed and supplied by him to the
dealer.(3)A tax invoice in respect of a sale shall be issued in duplicate and the original of which shall
be issued to the purchaser (or the person taking the delivery, as the case may be) and the duplicate
shall be retained by the selling dealer.(4)Except when a tax invoice is issued under sub-section (1), if
a dealer sells any goods exceeding such amount in value as may be prescribed, in any one
transaction to any person, he shall issue to the purchaser a retail invoice containing the particulars
specified in sub-section (5) and retain a copy thereof.(5)The retail invoice issued under sub-section
(4) shall contain the following particulars on the original as well as copies thereof, namely : -(a)the
words 'retail invoice' or 'cash memorandum' or 'bill' in a prominent place;(b)the name, address and
registration number of the selling dealer, if registered;(c)in case the sale is in the course of
inter-state trade or commerce, the name, registration number and address of the purchasing dealer
and type of any form, under the Central Sales Tax Act, 1956 (74 of 1956), if any, against which the
sale has been made;(d)an individual pre-printed serialized number and the date on which the retail
invoice is issued;(e)description, quantity, volume and value of goods sold and services provided,
inclusive of amount of tax charged thereon; and(f)the signature of the selling dealer or his servant,
manager or agent, duly authorised by him.(6)The retail invoice shall be issued in duplicate, and the
original of which shall be issued to the purchaser and the duplicate copy of which shall be retained
by the selling dealer.(7)The Commissioner may, by notification, specify the manner and form in
which the particulars on a tax invoice or retail invoice are to be recorded.(8)If a purchaser claims to
have lost the original tax invoice, the selling dealer may, subject to such conditions and restrictions
as may be prescribed, provide a copy of such tax invoice clearly marked as a copy of original tax
invoice.
51. Credit and debit notes.
- Where a tax invoice has been issued in respect of a sale and -(a)the amount shown as tax in that tax
invoice exceeds the tax payable in respect of the sale, the dealer shall provide the purchaser with a
credit note, containing such particulars as may be prescribed; or(b)the tax payable in respect of the
sale exceeds the amount shown as tax on the tax invoice, the dealer shall provide the purchaser with
a debit note, containing such particulars as may be prescribed.Daman and Diu Value Added Tax Regulation, 2005

Chapter IX
Liability In Special Cases
52. Liability in case of transfer of business.
(1)Where a dealer, liable to pay tax under this Regulation, transfers his business in whole or in part,
by sale, gift, lease, leave or licence, hire or in any other manner whatsoever, the dealer and the
person to whom the business is so transferred shall jointly and severally be liable to pay the tax,
interest or penalty due from the dealer up to the time of such transfer, whether such tax, interest or
penalty has been assessed before such transfer, but has remained unpaid or is assessed
thereafter.(2)Where the transferee or the lessee of a business referred to in sub-section (1) carries on
such business either in his own name or in some other name, he shall be liable to pay tax on the sale
of goods effected by him with effect from the date of such transfer and shall, if he is registered as a
dealer, apply within the time specified in section 21 for the amendment of his certificate of
registration.
53. Liability in case of company in liquidation.
(1)Every person -(a)who is a liquidator of any company which is being wound up, whether under the
orders of a court or otherwise; or(b)who has been appointed the receiver of any assets of a company
(hereinafter referred to as the "liquidator"), shall, within one month after he has become such
liquidator, give notice of his appointment as such to the Commissioner.(2)The Commissioner shall,
after making such inquiries or calling for such information as he may deem fit, notify the liquidator
within three months from the date on which he received notice of the appointment of the liquidator,
the amount which, in the opinion of the Commissioner, would be sufficient to provide for any tax,
interest or penalty which is then, or is likely thereafter, to become payable by the company.(3)The
liquidator shall not part with any of the assets of the company or the properties in his hand until he
has been notified by the Commissioner under sub-section (2) and on being so notified, the
liquidator shall set aside an amount equal to the amount notified and, until he so sets aside such
amount, he shall not part with any of the assets of the company or the properties in his
hand:Provided that nothing contained in this sub-section shall debar the liquidator from parting
with such assets or properties in compliance with any order of a court or for the purpose of the
payment of the tax, interest and penalty, if any, payable by the company under this Regulation or for
making any payment to secured creditors whose debts are entitled under law to priority of payments
over debts due to Government on the date of liquidation or for meeting such costs and expenses of
the winding up of the company as are in the opinion of the Commissioner reasonable.(4)If the
liquidator fails to give notice in accordance with sub-section (1) or fails to set aside the amount as
required by sub-section (3) or parts with any assets of the company or the properties in his hand in
contravention of the provisions of that sub-section, he shall be personally liable for the payment of
tax, interest and penalty, if any, which the company would be liable to pay under this
Regulation:Provided that if the amount of tax, interest and penalty, if any, payable by the company
is notified under sub-section (2), the personal liability of the liquidator under this sub-section shall
be to the extent of such amount.(5)Where there is more than one liquidator, the obligations andDaman and Diu Value Added Tax Regulation, 2005

liabilities attached to a liquidator under this section shall attach to all the liquidators jointly and
severally.(6)When any private company is wound up and any tax, interest and penalty, if any,
assessed under this Regulation on the company for any period, whether before or in the course of or
after its liquidation, cannot be recovered, then every person who was a director of the private
company at any time during the period for which the tax is due, shall be jointly and severally liable
for the payment of such tax, interest and penalty, if any, unless he proves to the satisfaction of the
Commissioner that non-recovery cannot be attributed to any gross neglect, misfeasance or breach of
duty on his part in relation to the affairs of the company.(7)The provisions of this section shall have
effect notwithstanding anything to the contrary contained in any other law for the time being in
force.(8)For the purposes of this section, the expressions "company" and "private company" shall
have the meanings respectively assigned to them under clauses (i) and (iii) of subsection (1) of
section 3 of the Companies Act, 1956 (1 of 1956).
54. Liability of partners of firm to pay tax.
- Notwithstanding any contract to the contrary, where any firm is liable to pay any tax, interest or
penalty under this Regulation, the firm and each of the partners of the firm shall be jointly and
severally liable for such payment:Provided that where any such partner retires from the firm, he
shall intimate the date of his retirement to the Commissioner by a notice to that effect in writing and
he shall be liable to pay tax, interest or penalty remaining unpaid at the time of his retirement and
any tax, interest or penalty due up to the date of his retirement though un-assessed on that
date:Provided further that if no such intimation is given within fifteen days from the date of
retirement, the liability of the partner under the first proviso shall continue until the date on which
such intimation is received by the Commissioner.
55. Liability of guardians, trustees, etc.
- Where the business in respect of which tax is payable under this Regulation is carried on by, or is
in the charge of any guardian, trustee or agent of a minor or other incapacitated person on his behalf
and for the benefit of such minor or other incapacitated person, the tax, interest or penalty shall be
levied upon and recoverable from such guardian, trustee or agent, as the case may be, in like manner
and to the same extent as it would be assessed upon and recoverable from any such minor or other
incapacitated person, if he were of full age and of sound mind and if he were conducting the
business himself, and all the provisions of this Regulation shall, so far as may be, apply accordingly.
56. Liability of Court of Wards, etc.
- Where the estate or any portion of the estate of a dealer owning a business in respect of which tax
is payable under this Regulation is under the control of the Court of Wards, the
Administrator-General, the Official Trustee or any receiver or manager (including any person,
whatever be his designation, who in fact manages the business) appointed by or under any order of a
court, the tax, interest or penalty shall be levied upon and be recoverable from such Court of Wards,
Administrator- General, Official Trustee, receiver or manager in like manner and to the same extent
as it would be assessable upon and be recoverable from the dealer if he were conducting theDaman and Diu Value Added Tax Regulation, 2005

business himself, and all the provisions of this Regulation shall, so far as may be, apply accordingly.
57. Liability in other cases.
(1)Where a dealer is a firm or an association of persons or a Hindu undivided family, and such firm,
association or family has discontinued business -(a)the tax payable under this Regulation, by such
firm, association or family up to the date of such discontinuance may be assessed as if no such
discontinuance had taken place; and(b)every person who was at the time of such discontinuance a
partner of such firm, or a member of such association or family, shall, notwithstanding such
discontinuance, be liable jointly and severally for the payment of tax assessed and penalty imposed
and payable by such firm, association or family, whether such tax, interest or penalty has been
assessed prior to or after such discontinuance, and subject as aforesaid, the provisions of this
Regulation shall, so far as may be, apply as if every such person or partner or member were himself
a dealer:Provided that where the partner of a firm liable to pay such tax, interest or penalty, dies, the
provisions of sub-section (4) shall, so far as may be, apply.(2)Where a change has occurred in the
constitution of a firm or an association of persons, the partners of the firm or members of the
association as it existed before and as it exists after its reconstitution shall, without prejudice to the
provisions of section 54, jointly and severally be liable to pay tax, interest or penalty due from such
firm or association for any period before its re-constitution.(3)The provisions of sub-section (1)
shall, so far as may be, apply where the dealer, being a firm or association of persons is dissolved or,
being a Hindu undivided family, has effected partition with respect to the business carried on by it
and accordingly references in that sub-section to discontinuance shall be construed as references to
dissolution or, as the case may be, to partition.(4)Where a dealer liable to pay tax under this
Regulation dies, then -(a)if a business carried on by the dealer is continued after his death by his
legal representative or any other person, such legal representative or other person, shall be liable to
pay the tax, interest or penalty due from the dealer under this Regulation, whether such tax, interest
or penalty had been assessed before his death but has remained unpaid, or is assessed after his
death;(b)if the business carried on by the dealer is discontinued after his death, his legal
representative shall be liable to pay out of the estate of the deceased, to the extent the estate is
capable of meeting the charge, the tax, interest or penalty due from the dealer under this Regulation,
whether such tax, interest or penalty had been assessed before his death but has remained unpaid,
or is assessed after his death,and the provisions of this Regulation shall, so far as may be, apply to
such legal representative or other person as if he were the dealer himself.Explanation. - For the
purposes of this section "legal representative" has the meaning assigned to it in clause (11) of section
2 of the Code of Civil Procedure, 1908 (5 of 1908).
Chapter X
Audit, Investigation and Enforcement
58. Audit.
(1)The Commissioner may, serve on any person in the prescribed manner, a notice informing him
that an audit of the affairs of his business shall be conducted and in a case where an assessment hadDaman and Diu Value Added Tax Regulation, 2005

already been concluded under this Regulation, reassessment may be made or assessment already
made may be confirmed.Explanation. - A notice may be served notwithstanding the fact that the
person may already have been assessed under sections 31 or section 32 or section 33.(2)A notice
served under sub-section (1) may require the person on whom it is served, to appear on a date and
place specified therein, which may be at his business premises or at a place specified in the notice, to
either attend and produce or cause to be produced the books of account and all evidence on which
the dealer relies in support of his returns (including tax invoices, if any), or to produce such
evidence as is specified in the notice.(3)The person on whom a notice is served under subsection (1)
shall provide all co-operation and reasonable assistance to the Commissioner as may be required to
conduct the proceedings under this section at his business premises.(4)The Commissioner shall,
after considering the return, the evidence furnished along with the returns, if any, the evidence
acquired in the course of the audit, if any, or any information otherwise available to him, either
-(a)confirm the assessment; or(b)serve a notice of the assessment or re-assessment of the amount of
tax, interest and penalty, if any, pursuant to sections 32 and 33.(5)Any assessment pursuant to an
audit of the affairs of the business of the person referred to in sub-section (1) shall be without
prejudice to prosecution for any offence under this Regulation.
59. Inspection of records.
(1)All records, books of account, registers and other documents, maintained by a dealer, transporter
or operator of a warehouse shall, at all reasonable times, be open to inspection by the
Commissioner.(2)The Commissioner may, for the proper administration of this Regulation and
subject to such conditions as may be prescribed, require -(a)any dealer; or(b)any other person,
including a banking company, post office, a person who transports goods or holds goods in custody
for delivery to, or, on behalf of, any dealer, who maintains or has in his possession any books of
account, registers or documents relating to the business of a dealer, and, in the case of a person
which is an organization, any officer thereof -(i)to produce before him such records, books of
account, registers and other documents;(ii)to submit such clarifications; and(iii)to prepare and
furnish such additional information,relating to his affairs of business or to the activities of any other
person connected with the affairs of his business, as the Commissioner may deem necessary.(3)The
Commissioner may require a person referred to in sub-section (2), to -(a)prepare and provide any
documents; and(b)verify the clarifications submitted to the Commissioner,in the manner specified
by him.(4)The Commissioner may retain, remove, take copies or extracts, or cause copies or extracts
to be made of the said records, books of account, registers and documents without fee by the person
in whose custody the records, books of account, registers and documents are held.
60. Power to enter premises and seize records and goods.
(1)All goods kept at any business premises by a dealer, transporter or operator of a warehouse shall,
at all reasonable times, be open to inspection by the Commissioner.(2)Where the Commissioner,
upon information in his possession or otherwise has reasonable grounds to believe that any person
or dealer is attempting to evade tax or is concealing his tax liability in any manner and it is
necessary so to do, for the purposes of administration of this Regulation, the Commissioner may
--(a)enter and search any business premises or any other place or building;(b)break open the lock ofDaman and Diu Value Added Tax Regulation, 2005

any door, box, locker, safe, almirah or other receptacle for exercising the powers conferred by clause
(a) where the keys thereof are not readily available;(c)seize and remove any records, books of
account, registers, other documents or goods;(d)place marks of identification on any records, books
of account, registers and other documents or make or cause to be made extracts or copies thereof
without charge;(e)make a note or any inventory of any such money or goods found as a result of
such search or place marks of identification on such goods; and(f)seal the premises including the
office, shop, godown, box, locker, safe, almirah or other receptacle.(3)Where it is not feasible to
remove any records, books of account, registers, other documents or goods, the Commissioner may
serve on the owner and any person who is in immediate possession or control thereof, an order
directing that he shall not remove or part with or otherwise deal with them except with the previous
permission of the Commissioner.(4)Where any premises have been sealed under clause (f) of
sub-section (2), or an order made under sub-section (3), the Commissioner may, on an application
made by the owner or the person in occupation or in charge of such shop, godown, box, locker, safe,
almirah or other receptacle, permit the de-sealing or release thereof, as the case may be, on such
terms and conditions including furnishing of security for such sum in such form and manner as may
be directed.(5)The Commissioner may requisition the services of any police officer or any public
servant, or of both, to assist him for all or any of the purposes specified in sub-section (2).(6)Save as
otherwise provided in this section, every search or seizure made under this section shall, as far as
possible, be carried out in accordance with the provisions of the Code of Criminal Procedure, 1973 (2
of 1974) relating to searches or seizures made under that Code.(7)The powers under this section may
also be exercised in respect of a dealer or a third party for the purposes of undertaking an audit or to
assist in recovery of dues under this Regulation.
61. Power to stop, search and detain goods vehicles.
(1)The Commissioner may, at any check-post or barrier or at any other place, to enable proper
administration of this Regulation, require the driver or person in charge of a goods vehicle to stop
the vehicle to examine the contents therein and inspect all records relating to the goods carried,
which are in the possession of such driver or person in charge.(2)The owner or person in charge of a
goods vehicle shall carry with him such records, as may be prescribed, in respect of the goods
carried in the goods vehicle and produce the same to the Commissioner on demand.(3)The driver or
person in charge of the goods vehicle shall, if required, inform the Commissioner of -(a)his name
and address;(b)the name and address of the owner of the vehicle;(c)the name and address of the
consignor of the goods;(d)the name and address of the consignee of the goods; and(e)the name and
address of the transporter.(4)If, on an examination of the contents of a goods vehicle or the
inspection of documents relating to the goods carried, the Commissioner has reason to believe that
the owner or person in-charge of such goods vehicle is not carrying the documents as required by
sub-section (2) or is not carrying proper and genuine documents or is attempting to evade payment
of tax due under this Regulation, he may, for reasons to be recorded in writing, do any one or more
of the following, namely:-(a)refuse to allow the goods or the goods vehicle to enter Daman and
Diu;(b)seize the goods and any documents relating to the goods; and(c)seize the goods vehicle and
any documents relating to the goods vehicle.(5)Where the owner or the person in charge of the
goods vehicle -(a)requests for time to adduce evidence of payment of tax or the goods being
exempted under this Regulation, in respect of the goods to be detained or impounded;Daman and Diu Value Added Tax Regulation, 2005

and(b)furnishes security for the prescribed amount to the satisfaction of the Commissioner in such
form and in such manner as may be prescribed,the goods vehicle, the goods and the documents so
seized may be released.(6)The Commissioner may permit the owner or person in charge of goods
vehicle to remove any goods or goods vehicle seized under sub-section (4) subject to an undertaking
-(a)that the goods and goods vehicle shall be kept in the office, godown or other place within Daman
and Diu, belonging to the owner of the goods vehicle and in the custody of such owner; and(b)that
the goods shall not be delivered to the consignor, consignee or any other person without the
approval in writing of the Commissioner,and for this purpose the person in charge of the goods
vehicle shall furnish an authorization from the owner of the goods vehicle authorizing him to give
such undertaking on his behalf.(7)Save as otherwise provided in this section, every search or seizure
made under this section shall, as far as possible, be carried out in accordance with the provisions of
the Code of Criminal Procedure, 1973 (2 of 1974) relating to searches or seizures made under that
Code.(8)Nothing contained in this section shall apply to the rolling stock as defined in the Railway
Act, 1989 (24 of 1989).
62. Custody and release of records.
(1)Where the Commissioner seizes any books of account or other documents, he shall give the dealer
or the person present on his behalf, as the case may be, a receipt for the same and obtain
acknowledgement of the receipt so given to him:Provided that if the dealer or person from whose
custody the books of account or other documents are seized refuses to give an acknowledgement, the
Commissioner may leave the Custody and release of records. receipt at the premises and record this
fact.(2)The Commissioner shall keep in his custody the books of account, registers, other documents
seized under section 60 for a period not exceeding one year, and thereafter shall return the same to
the dealer or person from whose custody or power they were seized:Provided that the Commissioner
may, before returning the books of account, registers and other documents, require the dealer or the
person, as the case may be, to give a written undertaking that the books of account, registers and
other documents shall be presented whenever required by the Commissioner for any proceedings
under this Regulation:Provided further that the Commissioner shall, when requested, allow the
person whose books of account, registers and documents have been seized, reasonable access to the
books of account, registers and documents for the purpose of inspection and shall give the person
the opportunity to make copies thereof at the person's own expense:Provided also that the period of
custody of the books of account, registers and other documents seized under section 60 may be
extended beyond one year if any proceedings under this Regulation are pending or for reasons to be
recorded by the Commissioner in writing.
63. Custody, return and disposal of goods, goods vehicle and security.
(1)Where the Commissioner seizes any goods or goods vehicle, he shall give the dealer, person in
charge of the goods vehicle or a person present on his behalf, as the case may be, a receipt for the
same and obtain acknowledgment of the receipt so given to him:Provided that if the person, from
whose custody the goods or goods vehicle have been seized, refuses to give an acknowledgment, the
Commissioner may leave the receipt in his presence and record this fact.(2)The Commissioner
-(a)shall keep any goods or goods vehicle seized under section 61 in his custody;(b)may retain themDaman and Diu Value Added Tax Regulation, 2005

for such time as he considers reasonable; and(c)subject to sub-section (3), shall return the goods or
goods vehicle to the dealer or other person from whose custody or power they were seized.(3)Where
the Commissioner -(a)has seized any goods; or(b)has seized a goods vehicle; or(c)holds any goods as
security for the performance of an obligation under this Regulation,the Commissioner may, not
sooner than one month after the service of notice on -(i)the person from whom the goods were
seized;(ii)the person from whom the goods vehicle was seized;(iii)the person for whom the security
was given; and(iv)any person against whom the security is to be enforced,as the case may be, of his
intention to sell the goods, direct the auction of such goods or goods vehicle to recover any arrears of
tax, interest or penalty due under this Regulation.(4)An auction of goods or a goods vehicle shall be
carried out in the manner prescribed for the sale of property held by the Commissioner.
64. Detention of goods pending disclosure.
(1)If any person on being required by the Commissioner, fails to give any information in respect of
any goods in his possession or fails to permit the inspection thereof, the Commissioner may seize
any goods in his custody or possession in respect of which the default is committed.(2)The seizure
shall remain in force until it is revoked or the person concerned furnishes the information required
or makes proper arrangements for the inspection of the goods, whichever occurs first.
65. Obligation to provide reasonable assistance.
- Every person shall provide all co-operation and reasonable assistance to the Commissioner as may
be required to discharge his functions under the Regulation.
Chapter XI
Value Added Tax Authorities and Appellate Tribunal
66. Value Added Tax Authorities.
(1)For carrying out the purposes of this Regulation, the Government shall appoint a person to be the
Commissioner of Value Added Tax.(2)The Government may, to assist Commissioner in the
administration of this Regulation, appoint as many Joint Commissioners of Value Added Tax,
Deputy Commissioners of Value Added Tax, Assistant Commissioners of Value Added Tax, Value
Added Tax Officers and such other persons with such designations as the Government thinks
necessary (hereinafter in this Chapter referred to as the "Value Added Tax Authority").(3)The
Commissioner may, with the previous sanction of the Government, engage other persons to assist
him in discharge of his duties.(4)The Commissioner and the Value Added Tax Authorities shall
exercise such powers as may be conferred upon them, and perform such duties as may be required,
by or under this Regulation.Daman and Diu Value Added Tax Regulation, 2005

67. Powers and responsibilities of Commissioner.
(1)The Commissioner shall have responsibility for the due and proper administration of this
Regulation and have jurisdiction over the whole of Daman and Diu.(2)Subject to sub-section (3), the
Commissioner may, from time to time, issue such orders, instructions and directions to any Value
Added Tax Authorities or persons referred to in subsection (3) of section 66 as he thinks fit for the
due and proper administration of this Regulation and all such persons engaged in the
administration of this Regulation shall observe and follow such orders, instructions and directions
of the Commissioner.(3)No order, instruction or direction shall be issued by the Commissioner to
any person or authority under this Regulation exercising the power under this Regulation to
-(a)dispose of an appeal filed or to be filed under section 74 in a particular manner; or(b)determine
a particular question under section 84 in a particular manner.(4)Nothing in sub-section (3) shall
prevent the Commissioner from issuing general orders, instructions and directions being
clarificatory in nature on any issue or matter under this Regulation.
68. Delegation of Commissioner's powers.
(1)Subject to such restrictions and conditions as may be prescribed, the Commissioner may delegate
any of his powers under this Regulation to any Value Added Tax Authorities.(2)Where the
Commissioner delegates his powers under Chapter X, the person, to whom such power has been
delegated, shall carry and produce on demand evidence in the prescribed form of the delegation of
these powers when exercising the powers.(3)Where the Commissioner has delegated a power to any
Value Added Tax Authority, the Commissioner may supervise, review and rectify any decision made
or action taken by that Authority.(4)The exercise of power of supervision, review or rectification
referred to in sub-section (3) shall not be construed as power to make an assessment or
re-assessment after the expiry of the time referred to in section 34.
69. Change of an incumbent of an office.
- Whenever in respect of any proceeding under this Regulation a person being the Commissioner or
any Value Added Tax Authority is succeeded by another person-(a)the person so succeeding shall
exercise all such powers under this Regulation which were exercised by the preceding person;
and(b)the person so succeeding may continue the proceeding from the stage at which the
proceeding was left by his predecessor.
70. Power of Commissioner to notify certain forms.
(1)The Commissioner may notify and publish any forms which may be necessary for the reporting of
information to the Value Added Tax authorities.(2)Where the Commissioner has notified a form for
a particular purpose, all persons shall be required to report the information using the form.(3)In
particular and without prejudice to the generality of the foregoing power, a notification issued by the
Commissioner may stipulate all or any of the matters which in the opinion of the Commissioner are
necessary or convenient for the proper administration of this Regulation.Daman and Diu Value Added Tax Regulation, 2005

71. Persons to be public servants.
- The Commissioner, all Value Added Tax authorities and all members of the Appellate Tribunal
shall be deemed to be public servants within the meaning of section 21 of the Indian Penal Code,
1860 (45 of 1860).
72. Immunity from civil suit.
- No suit, prosecution or other legal proceedings shall lie against the Government, the
Administrator, the Commissioner, any Value Added Tax Authorities, or member of the Appellate
Tribunal for anything which is done or intended to be done under this Regulation or rules made
thereunder.
73. Appellate Tribunal.
(1)The Government shall, as soon as may be after the commencement of this Regulation, constitute
an Appellate Tribunal consisting of one or more members, as it thinks fit, to exercise the powers and
discharge the functions conferred on the Appellate Tribunal by or under this Regulation:Provided
that where the Appellate Tribunal consists of one member, that member shall be a person who has
held a civil judicial post for at least ten years or who has been a member of the Indian Legal Service
not below Grade III for at least three years or who has been in practice as an advocate for at least ten
years, and where the Appellate Tribunal consists of more than one member, one such member shall
be a person qualified as aforesaid:Provided further that the Government may, until the Appellate
Tribunal is constituted under this Regulation, notify any other Appellate Tribunal constituted or
established, under any State law for the time being in force, with the consent of the concerned State
Government and such other Appellate Tribunal shall hear and dispose of the appeal in accordance
with the provisions of this Regulation till such time the Appellate Tribunal is constituted under this
Regulation.(2)Where the number of members of the Appellate Tribunal is more than one, the
Government shall appoint one of those members to be the Chairperson of the Appellate
Tribunal.(3)Subject to the provisions of sub-section (1), the qualifications and other conditions of
service of the member or members constituting the Appellate Tribunal and the period for which
such member or members shall hold office, shall be such as may be prescribed.(4)The members of
the Appellate Tribunal shall be appointed by the Government on the recommendation of a selection
committee consisting of such person as may be prescribed.(5)Any vacancy in the membership of the
Appellate Tribunal shall be filled up by the Government as soon as practicable.(6)Where the number
of members of the Appellate Tribunal is more than one and if the members differ in opinion on any
point, such point shall be decided according to the opinion of the majority, if there is a majority, but
if the members are equally divided, the decision of the Chairperson of the Appellate Tribunal
thereon shall be final.(7)Subject to the previous sanction of the Government, the Appellate Tribunal
shall, for the purpose of regulating its procedure and disposal of its business, make regulations in
consistent with the provisions of this Regulation and the rules made thereunder.(8)The regulations
made under sub-section (6) shall be published in the Official Gazette.(9)The Appellate Tribunal
shall, for the purpose of discharging its functions, have all the powers which are vested in the
Commissioner under section 75 and any proceeding before the Appellate Tribunal shall be deemedDaman and Diu Value Added Tax Regulation, 2005

to be a judicial proceeding within the meaning of sections 193 and 228, and for the purposes of
section 196 of the Indian Penal Code, 1860 (45 of 1860) and the Appellate Tribunal shall be deemed
to be a Civil Court for all the purposes of section 195 and Chapter XXVI of the Code of Criminal
Procedure, 1973 (2 of 1974).
Chapter XII
Appeals, Disputes and Questions
74. Appeals.
(1)Any person who is aggrieved by an assessment under this Regulation or any other order or
decision made under this Regulation (including an assessment of penalty under section 33 or
penalty imposed under this regulations) may,-(a)file an appeal to the Joint Commissioner or Deputy
Commissioner or Assistant Commissioner, having jurisdiction, when such decision has been made
or order has been passed or assessment has been made by any Value Added Tax Officer or Assistant
Value Added Tax Officer;(b)file an appeal to the Commissioner, when such decision has been made
or order has been passed or assessment has been made by the Assistant Commissioner or Deputy
Commissioner or Joint Commissioner:Provided that no appeal against an assessment shall be
entertained unless the amount of tax, interest or penalty assessed that is not in dispute has been
paid:Provided further that only one appeal shall be made by the person against any assessment,
decision or order:Provided also that in the case where an assessment or order or decision has been
revised, the appeal may be made in respect of such revision or amendment from which a person is
aggrieved.(2)A person, who is aggrieved by the failure of the Commissioner to make a decision or
pass an order or make any assessment under this Regulation, within six months after a request in
writing was served by the person, may file an appeal against such failure.(3)An appeal shall be filed
in writing in the prescribed form and shall state fully and in detail the grounds upon which the
appeal is filed.(4)(a)Every appeal under sub-section (1) shall be filed within two months of the date
of service of the assessment, or order or decision, as the case may be; or(b)Every appeal under
sub-section (2) shall be filed after the expiry of six months but before eight months after the written
request was served by the person:Provided that where the Commissioner is satisfied that the person
was prevented for sufficient cause from filing the appeal within the time specified, he may allow an
appeal to be filed within a further period of two months.(5)The Commissioner may conduct its
proceedings under this section by an examination of the assessment, or order or decision, as the
case may be, consider the objections or grounds mentioned in the appeal filed, and any other
document or information as may be relevant:Provided that where the person aggrieved requests a
hearing in person, such person shall be given an opportunity of being heard in person.(6)Where a
person has requested a hearing under subsection (5) and the person fails to attend the hearing at the
time and place stipulated, the Commissioner may proceed and dispose of the appeal in the absence
of the person.(7)Within three months after the receipt of the appeal filed under sub-section (1), the
Commissioner shall, either -(a)allow the relief prayed in the appeal in whole or in part and take
appropriate action to give effect to the relief allowed (including the remission of any penalty
assessed either in whole or in part); or(b)refuse the relief prayed in the appeal in whole or part, and
in either case, serve on the appellant, a notice in writing of the decision and the reasons for it,Daman and Diu Value Added Tax Regulation, 2005

including a statement of the evidence on which it is based:Provided that the Commissioner may,
after communicating the reasons to the appellant, extend the said period of three months to six
months for the purposes of allowing or refusing the relief prayed in appeal:Provided further that the
person may, in writing, request the Commissioner to extend the said period by a further period of
not exceeding three months to produce proper and relevant documents for properly contesting the
appeal, in which case the period of the adjournment at the request of appellant shall be excluded for
the purposes of computing period of three months or six months as the case may be.(8)Where the
Commissioner does not dispose of the appeal within the time specified under sub-section (7), the
person may submit a written request requiring him to dispose of the appeal within fifteen days.(9)If
the appeal has not been disposed of within the said period of fifteen days after submission of written
request referred to in sub-section (8), then, at the end of that period, the Commissioner shall be
deemed to have allowed the relief prayed in the appeal.
75. Power of Commissioner and other authorities to take evidence on oath,
etc.
(1)The Commissioner or any person considering the appeal under section 74, for the purposes of
this Regulation, have the same powers as are vested in a court under the Code of Civil Procedure,
1908 (5 of 1908) when trying a suit, in respect of the following matters, namely: -(a)enforcing the
attendance of any person and examining him on oath or affirmation;(b)compelling the production
of accounts and documents; and(c)issuing commissions for the examination of witnesses,and any
proceeding under this Regulation before the Commissioner or person considering the appeal under
section 74 shall be deemed to be a judicial proceeding within the meaning of sections 193 and 228
and for the purposes of section 196 of the Indian Penal Code, 1860 (45 of 1860).(2)Subject to any
rules made in this behalf, the Commissioner or any person considering the appeal under section 74
may impound and retain in his custody, any books of account or other documents produced before
him in any proceedings under this Regulation until such proceedings are concluded:Provided that
the Commissioner or the person considering the appeal under section 74 shall not impound any
books of account or other documents without recording in writing his reasons for so doing.
76. Appeals to Appellate Tribunal.
(1)Any authority objecting any decision or order made under section 74 or any person aggrieved by a
decision or order made by the Commissioner under section 74, may appeal to the Appellate Tribunal
against such decision or order.(2)Subject to the provisions contained in section 77, no appeal shall
be entertained unless it is made within two months from the date of service of the decision or order
appealed against.(3)Every appeal made under this section shall be in the prescribed form, verified in
the prescribed manner and shall be accompanied by such fee as may be prescribed.(4)No appeal
against an assessment shall be entertained by the Appellate Tribunal unless the appeal is
accompanied by satisfactory proof of the payment of the amount in dispute and any other amount
assessed as due from the person:Provided that the Appellate Tribunal may, if it thinks fit, for
reasons to be recorded in writing, entertain an appeal against such order without payment of whole
or part of the amount in dispute, on the appellant furnishing in the prescribed manner security for
such amount as it may direct:Provided further that no appeal shall be entertained by the AppellateDaman and Diu Value Added Tax Regulation, 2005

Tribunal unless it is satisfied that such amount as the appellant admits to be due from him has been
paid.(5)In proceedings before the Appellate Tribunal the person aggrieved may be permitted to
adduce evidence not presented to the Commissioner for good and sufficient reasons.(6)The
Appellate Tribunal shall -(a)in the case of an appeal filed against an assessment, confirm, reduce, or
annul the assessment (including any penalty and interest imposed);(b)in the case of any other
decision or order of the Commissioner, affirm or reject the decision; or(c)pass such other order for
the determination of the issue or disposing of the appeal as it thinks fit:Provided that the Appellate
Tribunal shall give reasons in writing for its decision which shall include its findings on material
questions of fact and the evidence or other material on which those findings were based.(7)The
Appellate Tribunal shall not set aside an assessment and remit the matter to the Commissioner or
any other authority under this Regulation for a further assessment, unless it has
first-(a)communicated the aggrieved person of the proposed order;(b)offered the person an
opportunity to adduce such further evidence before it may assist the Appellate Tribunal to reach a
final determination of the issue and disposing the appeal.(8)Where the Appellate Tribunal sets aside
an assessment and remits the matter to the Commissioner or any other authority under this
Regulation for a further assessment, the Appellate Tribunal may at the same time order the
Commissioner to refund to the person whole or part of the amount in dispute(9)Where a person has
failed to attend the hearing at the time and place stipulated, the Appellate Tribunal may adjourn the
proceedings, reject the appeal or proceed to make an order determining the issue or disposing of the
appeal in the absence of the person.(10)Save as provided in section 81 and sub-section (11), an order
passed by the Appellate Tribunal on an appeal shall be final.(11)The Appellate Tribunal may rectify
any mistake or error apparent from the record of its proceedings.
77. Extension of period of limitation in certain cases.
(1)The Appellate Tribunal may admit an appeal under section 76 after the period of limitation laid
down in that section, if the appellant satisfies the Appellate Tribunal that he had sufficient cause for
not preferring the appeal within such period.(2)In computing the period laid down under sections
76 and 81, the provisions of sections 4 and 12 of the Limitation Act, 1963 (36 of 1963), shall, so far as
may be, apply.(3)In computing the period of limitation prescribed by or under any provision of this
Regulation, or the rules made thereunder, other than sections 76 or 81, any period during which any
proceeding is stayed by an order or injunction of any court shall be excluded.
78. Burden of proof.
- The burden of proving any matter in issue in proceedings under section 74, or before the Appellate
Tribunal which relates to the liability to pay tax or any other amount under this Regulation shall lie
on the person alleged to be liable to pay the amount:Provided that nothing contained in this section
shall apply to any proceedings for criminal offence or criminal prosecution.
79. Bar on appeal against certain orders.
(1)No appeal shall lie to any authority or the Appellate Tribunal under this Regulation against -(a)a
decision of the Commissioner to make an assessment of tax or penalty;(b)a notice requiring aDaman and Diu Value Added Tax Regulation, 2005

person to furnish a return;(c)a notice issued under section 58 or section 59;(d)a decision of the
Commissioner to notify any matter under this Regulation;(e)a notice asking a dealer to show cause
why he should not be prosecuted for an offence under this Regulation;(f)a decision relating to the
seizure or retention of books of account, registers and other documents;(g)a decision sanctioning a
prosecution under this Regulation;(h)a decision of the Commissioner on the administration of the
Value Added Tax authorities;(i)an assessment made by the Commissioner to give effect to an order
of the Appellate Tribunal or a court.(2)Save as provided in clause (i) of sub-section (1), nothing in
sub-section (1) shall prevent the person from filing an appeal under section 74 objecting to the
amount or the obligation to pay any amount assessed by the Commissioner.
80. Assessment or proceedings, etc., not to be invalid on certain grounds.
(1)No assessment, notice, summons or other proceedings made or issued or taken or purported to
have been made or issued or taken in pursuance of any of the provisions of this Regulation or under
the earlier law shall be invalid or shall be deemed to be invalid merely by reason of any mistake,
defect or omission in such assessment, notice, summons or other proceedings, if such assessment,
notice, summons or other proceedings are in substance and effect in conformity with or according to
the intent and purposes of this Regulation or any earlier law.(2)The service of any notice, order or
communication shall not be called in question if the said notice, order or communication, as the
case may be, has already been acted upon by the dealer or person to whom it is issued or which
service has not been called in question at or in the earliest proceedings commenced, continued or
finalized pursuant to such notice, order or communication.(3)No assessment made under this
Regulation shall be invalid merely on the ground that the action could also have been taken by any
other authority under any other provisions of this Regulation.
81. Statement of case to High Court.
(1)Within two months from the date of an order passed by the Appellate Tribunal under sub-section
(6) of section 76, a person aggrieved or the Commissioner may, by application in writing, and
accompanied by such fee as may be prescribed, require the Appellate Tribunal to refer to the High
Court any question of law arising out of such order, and, subject to the other provisions contained in
this section, the Appellate Tribunal shall, within four months of the receipt of such application draw
up a statement of the case and refer it to the High Court:Provided that the Appellate Tribunal may, if
it is satisfied that the person or the Commissioner was prevented by sufficient cause from presenting
the application within the period hereinbefore specified, allow it to be presented within a further
period not exceeding one month.(2)If the Appellate Tribunal refuses to state the case which it has
been required to do, on the ground that no question of law arises, the person or the Commissioner,
as the case may be, may, within one month of the communication of such refusal either withdraw his
application (and if he does so, any fee paid shall be refunded), or apply to the High Court against
such refusal.(3)If upon receipt of an application under sub-section (2), the High Court is not
satisfied as to the correctness of the refusal of the Appellate Tribunal, it may require the Appellate
Tribunal to state the case and refer it, and on receipt of such requisition, the Appellate Tribunal shall
state the case and refer it accordingly.(4)If the High Court is not satisfied that the statement in a
case referred to it is sufficient to enable it to determine the question so raised thereby, the court mayDaman and Diu Value Added Tax Regulation, 2005

refer the case back to the Appellate Tribunal for the purpose of making such additions thereto or
alterations therein as it may direct in that behalf.(5)The High Court, upon the hearing of any such
case, shall decide the question of law raised thereby, and shall deliver its judgment thereon
containing the grounds in which such decision is founded, and shall send to the Appellate Tribunal a
copy of such judgment under the seal of the court and the signature of the Registrar, and the
Appellate Tribunal shall dispose of the case accordingly.(6)Where a reference is made to the High
Court under this section, the cost, which shall not include the fee referred to in sub-section (1), shall
be in the discretion of the court.(7)The payment of the amount of tax, interest or penalty, if any, due
in accordance with the order of the Appellate Tribunal in respect of which an application has been
made under subsection (1) shall not be stayed pending the disposal of such application or any
reference made in consequence thereof but if such amount is reduced as a result of such reference,
the excess tax paid shall be refunded in accordance with the provisions of section 38.
82. Appearance before any authority in proceedings.
(1)Any person, who is entitled or required to attend before any authority in connection with any
proceedings under this Regulation, may attend-(a)by a person authorised by him in writing in this
behalf, being a relative or a person regularly employed by him; or(b)by a legal practitioner or
chartered accountant or a cost accountant or companies secretary who is not disqualified by or
under sub-section (2) of this section; or(c)by a Value Added Tax practitioner who possesses the
prescribed qualifications and is entered in the list, which the Commissioner shall maintain in that
behalf, and who is not disqualified by or under sub-section (2).Explanation. - For the purposes of
this section,-(a)"chartered accountant" means a chartered accountant as defined in clause (b) of
sub-section (1) of section 2 of the Chartered Accountants Act, 1949 (38 of 1949) and who has
obtained a certificate of practice under sub-section (1) of section 6 of that Act;(b)"company
secretary" means a company secretary as defined in clause (c) of sub-section (1) of section 2 of the
Company Secretaries Act, 1980 (56 of 1980) and who has obtained a certificate of practice under
sub-section (1) of section 6 of that Act;(c)"cost accountant" means a cost accountant as defined in
clause (b) of sub-section (1) of section 2 of the Cost and Works Accountants Act, 1959 (23 of 1959)
and who has obtained a certificate of practice under sub-section (1) of section 6 of that Act;(d)"legal
practitioner" means an advocate, vakil or an attorney of any High Court, and includes a pleader in
practice.(2)The Commissioner may, for reasons to be recorded in writing, disqualify for a period
from appearing before any such authority under this Regulation, any legal practitioner, chartered
accountant, cost accountant or company secretary or Value Added Tax practitioner-(a)who has been
dismissed from Government service; or(b)who, being a legal practitioner or chartered accountant,
cost accountant or company secretary is found guilty of misconduct in connection with any
proceedings under this Regulation by an authority empowered to take disciplinary action against the
members of the profession to which he belongs; or(c)who, being a Value Added Tax practitioner, is
found guilty of such misconduct by the Commissioner.(3)No order of disqualification shall be made
in respect of any particular person unless he has been given a reasonable opportunity of being
heard.(4)Any person who is disqualified under this section may, within one month of the date of
disqualification, appeal to the Government to have the disqualification cancelled.(5)The decision of
the Commissioner shall not take effect until one month of the making thereof or when an appeal is
preferred, until the appeal is decided.(6)The Commissioner may, at any time, suo motu or on anDaman and Diu Value Added Tax Regulation, 2005

application made to him in this behalf, revoke any decision made against any person under
sub-section (2) and thereupon such person shall cease to be disqualified.
83. Bar of suits in civil courts.
- No suit shall be brought in any civil court to set aside or modify any assessment made or any order
passed under this Regulation or the rules made thereunder.
84. Determination of specific questions.
(1)If any determinable question arises, otherwise than in proceedings before a court, a person may
apply in the prescribed manner to the Commissioner for the determination of that
question.(2)Subject to sub-section (3), an application for the determination of a determinable
question may be made in respect of a proposed transaction, a transaction that is being undertaken,
or a transaction has been concluded.(3)An application for the determination of a determinable
question may not be made after -(a)the Commissioner has commenced the audit of the person
pursuant to section 58; or(b)the Commissioner has made an assessment for the tax period in which
the transaction that is the subject of the determinable question occurred.Explanation. - For the
purposes of this sub-section, the Commissioner shall be deemed to have commenced the audit
under section 58 when the Commissioner serves a notice to this effect.(4)For the purposes of this
section, the following shall be determinable questions, namely :-(a)whether any person, society, club
or association or any firm or any branch or department of any firm is or would be a
dealer;(b)whether any dealer is or would be required to be registered under this Regulation;(c)the
amount of the taxable quantum of a dealer for a period;(d)whether a transaction is or would be a
sale, or requires an adjustment to be made under section 8 arising out of a sale;(e)whether a
transaction is or would be in the nature of works contract, or transfer of right to use any
goods;(f)whether a sale is not liable to tax under section 7;(g)whether a sale is exempt from tax
under section 6;(h)the sale price of a transaction;(i)the proportion of the turnover or turnover of
purchases of a dealer which arises in a tax period, and the time at which an adjustment to tax or tax
credit arises;(j)whether any transaction is or would be the import of goods;(k)the value of any goods
imported into Daman and Diu;(l)the rate of tax that is payable on a sale or import of goods and the
classification of the goods under the Schedules;(m)whether a transaction is the purchase of goods,
or requires an adjustment to be made under section 10 arising out of a purchase;(n)the amount of
any tax credit to which the dealer is entitled in respect of a purchase or import of goods;(o)the
amount of any tax credit in respect of any used goods purchased by a dealer;(p)the location of any
sale or purchase;(q)the application of a composition scheme in the circumstances of the dealer;
or(r)the tax period of a dealer.(5)The Commissioner shall make the determination within such
period as may be prescribed.(6)Where -(a)the Commissioner fails to make a determination under
this section within the time prescribed under subsection (5);(b)the person thereafter implements
the transaction which is the subject of the application and in the manner described in the
application; and(c)the person has, in the application for the determination of the determinable
question, indicated the answer to the determinable question which the person believes to be correct
(in this section called the "proposed determination"),the Commissioner shall be deemed for the
purposes of this Regulation to have made and issued to the person on the day after the expiry of theDaman and Diu Value Added Tax Regulation, 2005

prescribed period, a determination of the determinable question in the terms of the proposed
determination.(7)The Commissioner may -(a)direct that the determination shall not affect the
liability of any person under this Regulation with respect to any transaction effected prior to the
determination;(b)limit the period for which the determination will apply;(c)limit the transactions to
which the determination will apply; and(d)impose such other limitations or restrictions on the
determination as seem appropriate.(8)If any such question arises from any order already passed
under this Regulation or under the Daman and Diu Sales Tax Act, 1964 (4 of 1964) as then in force
in Daman and Diu, no such question shall be entertained for determination under this section but
such question may be raised in an appeal against such order.(9)Where -(a)the Commissioner has
issued to a person a determination in respect of a particular transaction; and(b)the person
implements the transaction based on the determination issued to him under this section and in the
manner described in the application,no assessment may be made by the Commissioner against that
person which is inconsistent with the determination and no penalty may be imposed on the person
if the determination is later held incorrect.(10)The Commissioner may, by notice served on the
person, withdraw or confirm or amend a determination issued under this section but such
withdrawal or confirmation or amendment shall not affect the entitlement of any person to rely on
the determination with respect to any transaction or action which he has commenced or which he
has completed prior to the withdrawal or qualification.(11)The determination by the Commissioner
under this section shall be binding only-(a)on the applicant who had sought it;(b)in respect of the
transaction in relation to which determination had been sought; and(c)on the Commissioner and
other Value Added Tax Authorities in respect of the applicant and the said transaction.(12)The
determination referred to in this section shall be binding as aforesaid unless there is a change in law
or facts on the basis of which the determination has been made.(13)Where the Commissioner finds,
that a determination made by him has been obtained by the applicant by fraud or misrepresentation
of fact, it may, by order declare such declaration to be void ab initio and thereupon all the provisions
of this Regulation shall apply (after excluding the period beginning with the date of such
determination and ending with the date of order under this sub-section) to the applicant as if such
determination had never been made.
85. Ruling on general questions.
(1)The Commissioner may, by notification, publish his ruling on the answer to any question
involving the interpretation of any issue under this Regulation or application of this Regulation to a
class of persons or class of transactions.(2)A ruling issued by the Commissioner under this section
may be issued subject to such restrictions and conditions as the Commissioner may deem fit.(3)The
ruling shall come into force on the date mentioned in the ruling or, if no date is stated in the ruling,
on the date of publication in the Official Gazette.(4)Where -(a)the Commissioner has published a
ruling in respect of a class of persons or transactions;(b)a person implements a transaction or
undertakes any action based on the ruling;(c)the ruling has, at the time of implementing the
transaction or undertaking the action, not been withdrawn by the Commissioner; and(d)according
to the terms of the ruling, the ruling purports to apply to the transaction or action undertaken by the
person,no assessment which is inconsistent with the ruling, shall be made by the Commissioner or
any other authority against that person and no penalty may be imposed on the person if the ruling is
later held incorrect.Explanation. - A person may rely on the ruling of the Commissioner or on theDaman and Diu Value Added Tax Regulation, 2005

determination made under section 84.(5)The Commissioner may, by notification, withdraw or
confirm or amend a ruling already issued under this section but such withdrawal or confirmation or
amendment shall not affect the entitlement of any person to rely on the ruling with respect to any
transaction or action commenced or completed by him prior to such withdrawal or confirmation or
amendment.
Chapter XIII
Penalties and Offences
86. Penalties.
(1)For the purposes of this section "tax deficiency" means the difference between the tax payable by
the person in accordance with the provisions of this Regulation and the amount of tax paid by the
person in respect of a tax period.(2)The penalty imposed under this section may be remitted by an
order made by an appellate authority in any proceeding under this Regulation where a person is able
to prove existence of a reasonable cause for the act or omission giving rise to penalty.(3)Where a
person, who is required to be registered under this Regulation, has failed to apply for grant of
certificate of registration within one month from the day on which his liability to register arose, the
person shall be liable to pay, by way of penalty, an amount equal to one thousand rupees for each
day during which such failure continues or one lakh rupees, whichever is less.(4)If, a registered
dealer fails to comply with the provisions of sub-section (1) of section 21, such dealer shall be liable
to pay, by way of penalty, a sum of one hundred rupees for each day during which such failure
continues or five thousand rupees, whichever is less.(5)If a registered dealer -(a)fails to comply with
the provisions of sub-section (2) of section 22; or(b)fails to surrender his certificate of registration
as provided in sub-section (7) of section 22,such dealer shall be liable to pay, by way of penalty, a
sum equal to one hundred rupees for each day during which such failure continues or five thousand
rupees, whichever is less.(6)If any person falsely represents that he is registered as a dealer under
this Regulation, he shall be liable to a penalty equal to the amount of tax wrongly collected as such
or one lakh rupees, whichever is higher.(7)Where a person has applied for grant of certificate of
registration under sub-section (5) of section 18 as a dealer under this Regulation and he -(a)fails to
undertake business which would entitle him to be a dealer, within the period specified in his
application; or(b)fails to comply with any of the restrictions or conditions subject to which
certificate of registration was granted,such dealer shall be liable to pay a penalty of ten thousand
rupees.(8)If a person required to furnish a return under the provisions of Chapter V -(a)fails to
furnish any return by the prescribed date; or(b)fails to furnish along-with the return any document
that is required to be furnished along-with the return; or(c)being required to revise a return already
furnished, fails to furnish the revised return by the prescribed date,such person shall be liable to
pay, by way of penalty, a sum of one hundred rupees for each day during which such failure
continues or ten thousand rupees, whichever is less.(9)Any person, who knowingly -(a)furnishes a
return under this Regulation which is false, misleading or deceptive in a material particular;
or(b)omits from a return furnished under this Regulation any material particular without which the
return is false, misleading or deceptive; or(c)claims tax credit in excess of the tax credit to which he
is entitled under section 9 or under other provisions of this Regulation,shall be liable to pay, by wayDaman and Diu Value Added Tax Regulation, 2005

of penalty, a sum of ten thousand rupees or the amount of the tax deficiency, whichever is the
higher.(10)Any dealer, who knowingly -(a)has claimed tax credit under section 14 to which he is not
entitled; or(b)has claimed an excess tax credit than to which he is entitled under section 14,shall be
liable to pay, by way of penalty, an amount equal to the amount of tax credit so claimed or ten
thousand rupees, whichever is higher.(11)Where a tax deficiency arises in relation to a dealer or any
other person, such person shall be liable to pay, by way of penalty, a sum of one per cent. of excess
tax deficiency per week for every week or fifty rupees per week for every week during which the tax
deficiency continues, whichever is higher.(12)Where a person is required under this Regulation to
-(a)prepare records or accounts in accordance with the provisions of Chapter X; or(b)prepare such
records or accounts in the prescribed manner; or(c)retain records or accounts in accordance with
provisions of sub-section (6) of section 48,and such person -(i)fails to prepare the required records
and accounts; or(ii)fails to prepare records and accounts in the prescribed manner; or(iii)fails to
retain the records and accounts as required by sub-section (6) of section 48,the person shall be
liable to pay, by way of penalty, a sum of fifty thousand rupees or twenty per cent. of the tax
deficiency, if any, whichever is higher.(13)Any person, who fails to comply with the provisions of
sub-section (2) or sub-section (3) of section 59, shall be liable to pay, by way of penalty, a sum of
fifty thousand rupees.(14)Where a person, who is required to prepare records and accounts under
this Regulation, knowingly prepares records and accounts in a false, misleading or deceptive
manner, such person shall be liable to pay, by way of penalty, a sum of one lakh rupees or the
amount of the tax deficiency, if any, whichever is higher.(15)Where a person -(a)issues a tax invoice
or retail invoice with incomplete or incorrect particulars; or(b)having issued a tax invoice or retail
invoice, has failed to account it correctly in his books of account,such person shall be liable to pay,
by way of penalty, an amount of five thousand rupees or twenty per cent. of the tax deficiency, if any,
whichever is higher.(16)Where a person, who is not authorised under this Regulation to issue a tax
invoice, issues a tax invoice, the person shall be liable to pay, by way of penalty, an amount of one
lakh rupees or the tax deficiency, if any, whichever is higher.(17)If any dealer fails to furnish a true
copy of report of audit referred to in section 49 within the prescribed time, the person shall be liable
to pay, by way of penalty, a sum of ten thousand rupees.(18)Where goods are being carried by a
transporter without the documents or without proper documents or with such documents being
false or without all documents referred to in sub-section (2) of section 61, the transporter shall be
liable to a penalty equal to the amount of tax payable on such goods.(19)Any person, who -(a)makes
a statement to the Commissioner or any authority under this Regulation which is false, misleading
or deceptive in a material particular; or(b)omits from a statement made to the Commissioner or any
authority under this Regulation any material particular without which the statement is false,
misleading or deceptive,such person shall be liable to pay, by way of penalty, a sum of fifty thousand
rupees, or the amount of the tax deficiency, whichever is higher.
87. Reduction or increase of penalty in certain cases.
(1)Where as a result of any proceedings the amount of tax has been wholly reduced, and a penalty
has been levied with reference to such tax, the penalty so levied shall be reduced to nil and if the
penalty has already been paid, it shall be refunded within two months of the reduction of such
tax.(2)If a person is liable to pay a penalty under sub-section (11) of section 86, and the person
voluntarily discloses in writing to the Commissioner the tax deficiency,-(a)the amount of the penaltyDaman and Diu Value Added Tax Regulation, 2005

leviable under this Regulation shall be reduced by eighty per cent. of such penalty if such disclosure
is made before the Commissioner issues the notice under section 58 for conducting of the audit of
the business affairs of such person;(b)the amount of the penalty leviable under this Regulation shall
be reduced by fifty per cent. of such penalty if such disclosure is made after the Commissioner has
issued the notice under section 58 for conducting of the audit of the business affairs of such
person.(3)If the tax deficiency has arisen in pursuance of determination by the Commissioner under
section 84 or ruling given under section 85 and in pursuance of such determination or ruling, a
person has become liable to pay a penalty under subsection (11) of section 86, the amount of the
penalty payable under this Regulation shall be reduced to nil and if the penalty has already been
paid, it shall be refunded within two months of the reduction of such tax.(4)Where penalty under
this Regulation has been imposed upon a person and such penalty has not been reduced by any
authority or Appellate Tribunal or court and has become final, and such person is subsequently
assessed to a further penalty in respect of the same or a substantially similar failure or default
occurring on another occasion (in this section called the "subsequent offence"), the penalty leviable
under this Regulation shall be increased by-(a)in the case of the first subsequent offence, fifty per
cent. of the penalty leviable under this Regulation; and(b)in the case of the second and any further
subsequent offence, one hundred per cent. of the penalty leviable under this Regulation.
88. Imposition of penalties notwithstanding of assessment.
(1)The penalties shall be leviable under this Regulation notwithstanding that no assessment of tax
under this Regulation has been made.(2)Any penalty imposed under this Regulation shall be
without prejudice to any prosecution for any offence under this Chapter or any other law for the
time being in force.
89. Offences and criminal penalties.
(1)Whoever -(a)not being a registered dealer, falsely represents that he is or was a registered dealer
at the time when he sells or buys goods; or(b)knowingly keeps false account or does not keep the
account of the value of the goods bought or sold by him in contravention of section 48; or(c)issues to
any person a false invoice, bill, cash memorandum, voucher or other document which he knows or
has reason to believe to be false, Offences and criminal penalties.shall, on conviction, be punished
with rigorous imprisonment for a term which may extend to six months and with fine.(2)Whoever
knowingly -(a)furnishes a false return; or(b)produces before the Commissioner, false bill, cash
memorandum, voucher, declaration, certificate, tax invoice or other document for claiming
deduction on tax credit; or(c)produces false accounts, registers or documents or knowingly
furnishes false information,he shall -(i)in case where the amount of tax, which could have been
evaded if the false return, bill, cash-memorandum, voucher, declaration, certificate, tax invoice or
other document for claiming deduction on tax credit, accounts, registers or documents or false
information, as the case may be, had been accepted as true exceeds, fifty thousand rupees, on
conviction, be punished with rigorous imprisonment for a term which may extend to six months ;
and(ii)in any other case, with rigorous imprisonment for a term which may extend to four months
and with fine.(3)Whoever, willfully attempts, in any manner whatsoever, to evade payment of tax,
penalty or interest or all of them under this Regulation, shall, on conviction, be punished -(a)in anyDaman and Diu Value Added Tax Regulation, 2005

case where the amount of such tax, penalty or interest involved exceeds fifty thousand rupees during
the period of a year, with rigorous imprisonment for a term which may extend to six months and
with fine; and(b)in any other case, with rigorous imprisonment for a term which may extend to
three months and with fine.(4)Whoever -(a)carries on business as a dealer without being registered
in willful contravention of sub-section (1) of section 18; or(b)fails without sufficient cause to furnish
any information required under section 21; or(c)fails to surrender his certificate of registration as
provided in sub-section (7) of section 22; or(d)fails without sufficient cause to furnish any returns as
required under section 26 or section 27 by the date or in the manner prescribed; or(e)without
reasonable cause, contravenes any of the provisions of section 40; or(f)fails without sufficient cause,
when directed so to do under section 48 to keep any accounts or record, in accordance with the
directions; or(g)without sufficient cause fails to issue invoice as required under section 50; or(h)fails
without sufficient cause, to comply with any requirements under section 59, or obstructs any officer
making inspection or search or seizure under sections 60 and 61; or(i)being owner in charge of a
goods vehicle fails, neglects or refuses to comply with any of the requirements contained in section
61; or(j)obstructs or prevents any officer performing any function under Chapter X; or(k)interferes
with or obstructs the Commissioner or any officer exercising any other power conferred under this
Regulation,he shall, on conviction, be punished with imprisonment for a term which may extend to
six months and with fine.(5)Whoever aids or abets any person in the commission of any act specified
in sub-sections (1) to (3) shall, on conviction, be punished with rigorous imprisonment which may
extend to six months, and with fine.(6)Whoever commits any of the acts specified in subsections (1)
to (5) and the offence is a continuing one under any of the provisions of these sub-sections, shall, on
conviction, be punished with fine of not less than one hundred rupees per day during the period of
the continuance of the offence, in addition to the punishments provided under this
section.(7)Notwithstanding anything contained in sub-sections (1) to (5), no person shall be
proceeded under these sub-sections if the total amount involved is less than two hundred rupees
during the period of a year.(8)Where a dealer is accused of an offence specified in sub-section (1), or
sub-section (2) or sub-section (3) of this section or in clause (a), or clause (b), or clause (c), or clause
(d), or clause (e), or clause (f), or clause (g), or clause (h) and clause (j) of sub-section (4), or
sub-section (6) of this section, the person deemed to be the manager of the business of such dealer
under section 95 shall also be deemed to be guilty of such offence, unless he proves that the offence
was committed without his knowledge or that he exercised all due diligence to prevent the
commission thereof.
90. Offences by companies and Hindu undivided family, etc.
(1)Where an offence under this Regulation or the rules has been committed by a company, every
person who, at the time the offence was committed, was in charge of, and was responsible to the
company for the conduct of the business of the company, as well as the company shall be deemed to
be guilty of the offence and shall be liable to be proceeded against and punished
accordingly:Provided that nothing contained in this sub-section shall render any such person liable
to any punishment provided in this Regulation if he proves that the offence was committed without
his knowledge or that he had exercised all due diligence to prevent the commission of such
offence.(2)Notwithstanding anything contained in sub-section (1), where an offence under this
Regulation has been committed by a company and it is proved that the offence has been committedDaman and Diu Value Added Tax Regulation, 2005

with the consent or connivance of, or is attributable to any neglect on the part of any director,
manager, secretary or other officer of the company, such director, manager, secretary or other
officer shall also be deemed to be guilty of that offence and shall be liable to be proceeded against
and punished accordingly.Explanation. - For the purposes of this section -(a)"company" means a
body corporate, and includes a firm or other association of individuals; and(b)"director" in relation
to a firm means a partner in the firm.(3)Where an offence under this Regulation has been
committed by a Hindu undivided family, the Karta thereof shall be deemed to be guilty of the
offence and shall be liable to be proceeded against and punished accordingly:Provided that nothing
contained in this sub-section shall render the Karta liable to any punishment if he proves that the
offence was committed without his knowledge or that he had exercised all due diligence to prevent
the commission of such offence:Provided further that where an offence under this Regulation has
been committed by a Hindu undivided family and it is proved that the offence has been committed
with the consent or connivance of or is attributable to any neglect on the part of any adult member
of the Hindu undivided family, such member shall also be deemed to be guilty of that offence and
shall be liable to be proceeded against and punished accordingly.
91. Cognizance of offences.
(1)No court shall take cognizance of any offence under this Regulation or rules made thereunder
except with the previous sanction of the Commissioner, and no court inferior to that of a
Metropolitan Magistrate shall try any such offence.(2)Notwithstanding anything contained in the
Code of Criminal Procedure, 1973 (2 of 1974), all offences punishable under this Regulation or the
rules made thereunder shall be cognizable and bailable.
92. Investigation of offences.
(1)Subject to such conditions as may be prescribed, the Commissioner may authorize either
generally or in respect of a particular case or class of cases any officer or person subordinate to him
to investigate all or any of the offences punishable under this Regulation.(2)Every officer or person
so authorised shall, in the conduct of such investigation, exercise the powers conferred by the Code
of Criminal Procedure, 1973 (2 of 1974) upon an officer in charge of a police station for the
investigation of a cognizable offence.
93. Compounding of offences.
(1)The Commissioner may, before the institution of proceedings for any offence punishable under
sub-section (4) of section 89 or under any rules made under this Regulation, accept from any person
charged with such offence by way of composition of offence, a sum not exceeding fifty thousand
rupees or a sum not exceeding three times the amount of tax which would thereby have been
avoided, whichever is higher.(2)On payment of such sum as may be determined by the
Commissioner under sub-section (1), no further proceedings shall be commenced against such
person in respect of the same offence.Daman and Diu Value Added Tax Regulation, 2005

94. Chapter XXXVI of Code of Criminal Procedure, 1973, not to apply to
certain offences.
- Nothing in Chapter XXXVI of the Code of Criminal Procedure, 1973 (2 of 1974) shall apply to
-(a)any offence punishable under this Regulation; or(b)any other offence which under the
provisions of that Code may be tried along with such offence, andevery offence referred to in clause
(a) or clause (b) may be taken cognizance of by the court having jurisdiction under this Regulation
as if the provisions of that Chapter were not enacted.
Chapter XIV
Miscellaneous
95. Dealer to declare the name of manager of business.
(1)Every dealer, being a Hindu undivided family or an association of persons or club or society or
firm or company or any person or body, who is engaged in business as the guardian or trustee or
otherwise on behalf of another person, and who is liable to pay tax under this Regulation, shall,
within the period prescribed, furnish a declaration in the manner prescribed, stating the name of the
person or persons who shall be deemed to be the manager or managers of such person's business for
the purposes of this Regulation.(2)The declaration furnished under sub-section (1) may be revised
from time to time as required.
96. Service of notice when family is disrupted or firm is dissolved.
(1)Where a Hindu undivided family has been partitioned, notices under this Regulation shall be
served on the person who was the last manager of the Hindu undivided family, or if such person
cannot be found, then, on all adults who were members of the Hindu undivided family, immediately
before the partition.(2)Where a firm or an association of persons is dissolved, notices under this
Regulation may be served on any person who was a partner (not being a minor) of the firm, or
member of the association, as the case may be, immediately before its dissolution.
97. Service of notice in case of discontinued business.
- Where an assessment is to be made in respect of business which has been discontinued, a notice
under this Regulation shall be served in the case of a firm or an association of persons or any person
who was a member of such firm or association at the time of its discontinuance or in the case of a
company, on the principal officer thereof.
98. Returns, etc., to be confidential.
(1)All particulars contained in any statement made, return furnished or accounts or documents
produced in accordance with this Regulation, or in any record of evidence given in the course of anyDaman and Diu Value Added Tax Regulation, 2005

proceedings under this Regulation, other than proceedings before a criminal court, shall, save as
provided in sub-section (3), be treated as confidential, and notwithstanding anything contained in
the Indian Evidence Act, 1872 (1 of 1872), no court shall, save as aforesaid, be entitled to require any
servant of the Government to produce before it any such statement, return, account, document or
record or any part thereof, or to give evidence before it in respect thereof.(2)If, save as provided in
sub-section (3), any servant of the Government discloses any of the particulars referred to in
subsection (1), he shall be punishable with imprisonment which may extend to six months, and shall
also be liable to a fine.(3)Nothing in this section shall apply to the disclosure -(a)of any of the
particulars referred to in sub-section (1) for the purposes of investigation or prosecution under this
Regulation or the Indian Penal Code 1860 (45 of 1860) or any other law for the time being in
force;(b)of such facts to an officer of the Central Government or any State Government as may be
necessary for verification of such facts or for the purposes of enabling that Government to levy or
realize any tax imposed by it;(c)of any such particulars where such disclosure is occasioned by the
lawful employment under this Regulation of any process for the service of any notice or the recovery
of any demand;(d)of any such particulars to a civil court in any suit or proceeding to which the
Government or any Value Added Tax Authority is a party and which relates to any matter arising out
of any proceeding under this Regulation or under any other law for the time being in force
authorizing any Value Added Tax Authority to exercise any powers thereunder;(e)of any such
particulars by any public servant where the disclosure is occasioned by the lawful exercise by him of
his powers under the Indian Stamp Act, 1899 (2 of 1899), to impound an insufficiently stamped
document;(f)of any such particulars to the Reserve Bank of India as are required by that Bank to
enable it to compile financial statistics of international investment and balance of payment;(g)of any
such particulars to any officer appointed by the Comptroller and Auditor-General of India for the
purpose of audit of tax receipts or refunds;(h)of any such particulars relevant to any inquiry into a
charge of misconduct in connection with income-tax proceedings against a legal practitioner or
chartered accountant or company secretary or cost accountant, to the authority empowered to take
disciplinary action against members of the profession to which he belongs;(i)of such particulars to
the officers of the Central Government or any State Government for such other purposes, as the
Government may, by general or special order, direct; or(j)of any information relating to a class of
dealers or class of transactions, if, in the opinion of the Commissioner it is desirable in the public
interest to publish such information.
99. Publication and disclosure of information in respect of dealers and other
persons in public interest.
(1)Notwithstanding anything contained in this Regulation, if the Government is of the opinion that
it is necessary or expedient in the public interest to publish or disclose the names of any dealers or
other persons and any other particulars relating to any proceedings under this Regulation in respect
of such dealers and persons, it may publish or disclose or cause to be published or disclosed such
names and particulars in such manner as it thinks fit.(2)No publication or disclosure under this
section shall be made in relation to any tax levied or penalty imposed or interest levied or any
conviction for any offence connected with any proceeding under this Regulation, until the time for
presenting an appeal to the appropriate Appellate Authority or Tribunal or court has expired
without an appeal having been presented or the appeal, if presented, has been disposed of.(3)In theDaman and Diu Value Added Tax Regulation, 2005

case of a firm, company or other association of persons, the names of the partners of the firm, the
directors, managing agents, secretaries, treasurers or managers of the company or the members of
the association, as the case may be, may also be published or disclosed, if, in the opinion of the
Government, the circumstances of the case justify it.
100. Power to collect statistics.
(1)If the Commissioner considers that for the purposes of the better administration of this
Regulation, it is necessary so to do, he may, by notification, direct that statistics be collected relating
to any matter dealt with, by or in connection with this Regulation.(2)Upon such direction being
made, the Commissioner or any person or persons authorised by him in this behalf may call upon all
dealers or any class of dealers or persons to furnish such information or statements as may be stated
therein relating to any matter in respect of which statistics are to be collected and the form in which
the persons to whom or, the authorities to which, such information or returns should be furnished,
the particulars which they should contain, and the intervals in which such information or returns
should be furnished, shall be such as may be prescribed:Provided that information may be called by
notification, or by notice in newspapers or in such other manner as, in the opinion of the
Commissioner or the said person, is necessary to bring to the knowledge of dealers and other
persons.(3)Without prejudice to the generality of the foregoing provisions, the Government may by
rules provide that every dealer or, as the case may be, any class of dealer shall furnish such
statements as may be prescribed, with the self assessment, and different provisions may be made for
different classes of dealers.
101. Setting up of check-posts and barriers.
- The Government may, by notification, set up check-posts or barriers, or both, at any place in the
Daman and Diu with a view to preventing evasion of tax and other dues payable under this
Regulation.
102. Power to make rules.
(1)The Government may, by notification, make rules to carry out the purposes of this
Regulation.(2)In particular, and without prejudice to the generality of the foregoing power, such
rules may provide for all or any of the following matters, namely:-(a)the documents, testimony or
other evidence constituting "sufficient proof" for the purpose of clause (zc) of section 2;(b)the "tax
period" for the purpose of clause (zg) of section 2 ;(c)the further period, for the purposes of
determining taxable turnover under sub-section (6) of section 3;(d)the conditions subject to which
the amount of price and other charges towards goods to be included in the turnover of a dealer
engaged in works contract under clause (a) of sub-section (2) of section 5;(e)the percentage of
amount to be reduced for the purpose of calculation of the amount of price and other charges
towards goods in case of a dealer engaged in works contract under clause (b) of sub-section (2) of
section 5;(f)the form in which, the authority to whom, and time within which a dealer shall file a
return and the manner of payment of tax under sub-section (3) of section 6;(g)the percentage of
reduction of the amount of tax credit by the dealer under sub-section (6) of section 9;(h)the periodDaman and Diu Value Added Tax Regulation, 2005

for which the turnover of a dealer, turnover of purchases made by a dealer and adjustment of
adjustment to tax or tax credit by a dealer shall be treated as arising for a class of transactions under
sub-section (4) of section 12;(i)the form of a statement, to be furnished by all registered dealers to
the Commissioner under sub-section (1) of section 14;(j)the manner and the conditions and
restrictions and the extent to determine the tax paid on the opening stock under sub-section (2) of
section 14;(k)the form of certificate to be signed by an accountant under sub-section (4) of section
14;(l)the time and manner of making an application to the Commissioner for withdrawing option
under first proviso to subsection (2) of section 16;(m)the time and manner to specify the intention of
a person to pay tax under sub-section (3) of section 16;(n)the form in which the proof of payment of
tax, statement of opening stock and finished goods shall be furnished to the Commissioner, under
sub-section (8) of section 16;(o)the form of application for grant of certificate of registration, time
within which such application is to be made, such other particulars and information relating to
registration and accompanied by fee, security and other documents under subsection (1) of section
19;(p)the amount of security and manner in which an applicant may furnish such security as
referred to in clause (a) of subsection (3) of section 19;(q)the form in which the statement of trading
stock and raw materials may be furnished by the dealer under clause (c) of subsection (1) of section
20;(r)the manner in which the information shall be given to the Commissioner by a registered
dealer under sub-section (1) of section 21;(s)the form of notice by the Commissioner for cancellation
of certificate of registration under sub-section (1) of section 22;(t)the manner and time within which
the registered dealer or the dealer's legal representative shall apply to the Commissioner for
cancellation of certificate of registration under sub-section (2) of section 22;(u)the manner in which
the excess tax shall be adjusted or refunded under sub-section (6) of section 22;(v)the particulars to
be published, by the Commissioner relating to registered dealers, whose certificate of registration
has been cancelled, under sub-section (8) of section 22;(w)the surety, amount, manner and the time
within which the Commissioner may require any person to furnish security under sub-section (1) of
section 25;(x)the amount of fresh surety to be furnished, where certificate of registration of the
person who has executed surety bond is either cancelled or such person has closed down his
business, under sub-section (4) of section 25;(y)the date within which, and the form in which
returns by every registered dealer shall be furnished under section 26;(z)the time within which and
the form in which the other returns specified by the Commissioner shall be furnished by a person
under section 27;(za)the branch of a bank in the Dadra and Nagar Haveli in which or other place
where and the manner in which the tax, interest, penalty or any other amount shall be paid by every
person under section 36;(zb)the manner and form of application in which the dealer may apply to
the Commissioner for grant of provisional refund under sub-section (9) of section 38;(zc)the
amount of bank guarantee or other security which the Commissioner may require the dealer to
furnish under subsection (10) of section 38;(zd)the restrictions and conditions subject to which the
Embassies, diplomatic officials and international or public organizations specified in the Fifth
Schedule shall claim a refund of tax under sub-section (1) of section 41;(ze)the manner and time
within which a person, entitled to a refund of tax, may apply to the Commissioner under sub-section
(2) of section 41;(zf)the manner and form in which the accounts and records shall be prepared and
maintained under sub-section (3) of section 48;(zg)the other amount of gross turnover, the form of
the audit report, the particulars to be set forth in such report and the time of furnishing true copy of
such report under section 49;(zh)the amount in value of goods sold in one transaction by a dealer,
for issuing a retail invoice to the purchaser under subsection (4) of section 50;(zi)the conditions andDaman and Diu Value Added Tax Regulation, 2005

restrictions subject to which a copy of tax invoice may be provided under sub-section (8) of section
50;(zj)the particulars to be contained in the debit or credit notes under section 51;(zk)the manner in
which a notice shall be served, by the Commissioner informing the person to conduct an audit of his
business affairs, under sub-section (1) of section 58;(zl)the conditions subject to which the
Commissioner may require any dealer or person and in the case of an organization any officer
thereof to produce records, books of account, registers and other documents, to submit clarifications
or to prepare and furnish additional information under sub-section (2) of section 59;(zm)the
records which an owner or person in charge of a goods vehicle shall carry with him in respect of the
goods carried in the goods vehicle under sub-section (2) of section 61;(zn)the form, manner and the
amount of security for which the owner or person in charge of the goods vehicle shall furnish to the
Commissioner under clause (b) of sub-section (5) of section 61;(zo)the manner for the sale of
property by which an auction of goods or a goods vehicle shall be carried out under sub-section (4)
of section 63;(zp)the restrictions and conditions subject to which the Commissioner may delegate
any of his powers, and the form of evidence of such delegation under section 68;(zq)the
qualifications and other conditions of service of the member or members constituting the Appellate
Tribunal and the period for which such member or members shall hold office under sub-section (3)
of section 73;(zr)the composition of the selection committee for the recommending for appointment
of members of the Appellate Tribunal under sub-section (4) of section 73;(zs)the form in which an
appeal may be filed under sub-section (3) of section 74;(zt)the form in which appeals may be filed,
the manner in which such appeals shall be verified and the fees payable in respect thereof under
sub-section (3) of section 76;(zu)the manner in which the appellant may furnish the security under
first proviso to sub-section (4) of section 76.(zv)the amount of fee for making an application to the
Appellate Tribunal under section 81;(zw)the qualifications of a Value Added Tax practitioner under
clause (c) of sub-section (1) of section 82;(zx)the manner in which an application may be made
under subsection (1) of section 84;(zy)the period within which the Commissioner shall make the
determination under sub-section (5) of section 84;(zz)the conditions subject to which, the
Commissioner may authorize any officer or person subordinate to him to conduct investigations
under section 92;(zza)the period within which and manner in which a declaration shall be published
under sub-section (1) of section 95;(zzb)the form in which, the persons or authorities to whom, the
particulars, and the intervals in which the information is to be furnished under sub-section (2) of
section 100;(zzc)the statements to be furnished by every dealer or any class of dealers as referred to
in sub-section (3) of section 100;(zzd)any other matter which is required to be, or may be,
prescribed;
103. Power to amend Schedules.
(1)If the Government is of opinion that it is expedient in the interest of general public so to do, it
may, by notification, add to, or omit from, or otherwise amend, the First, the Second, the Third, the
Fourth, the Fifth or the Sixth, Schedules, prospectively, and thereupon the said Schedules shall be
deemed to have been amended accordingly.(2)Every notification made under sub-section (2) shall
be laid, as soon as may be after it is made, before each House of Parliament, while it is in session, for
a total period of thirty days which may be comprised in one session or in two or more successive
sessions, and if, before the expiry of the session immediately following the session or the successive
sessions aforesaid, both Houses agree in making any modification in the notification or both HousesDaman and Diu Value Added Tax Regulation, 2005

agree that the notification should not be made, the notification shall thereafter have effect only in
such modified form or be of no effect, as the case may be; so, however, that any such modification or
annulment shall be without prejudice to the validity of anything previously done under that
notification.
104. Power to remove difficulties.
(1)If any difficulty arises in giving effect to the provisions of this Regulation, the Government may,
by general or special order published in the Official Gazette, make such provisions not inconsistent
with the provisions of this Regulation as appear to it to be necessary or expedient for the removal of
the difficulty:Provided that no such order shall be made after the expiration of two years from the
commencement of this Regulation.(2)Every order made under sub-section (1) shall be laid, as soon
as may be after it is made, before each House of Parliament, while it is in session, for a total period
of thirty days which may be comprised in one session or in two or more successive sessions, and if,
before the expiry of the session immediately following the session or the successive sessions
aforesaid, both Houses agree in making any modification in the order or both Houses agree that the
order should not be made, the order shall thereafter have effect only in such modified form or be of
no effect, as the case may be; so, however, that any such modification or annulment shall be without
prejudice to the validity of anything previously done under that order.
105. Transitory provisions.
(1)Where --(a)the tax has been collected under the Daman and Diu Sales Tax Act, 1964 (4 of 1964),
as repealed by section 106, but the same has not been deposited before the date of commencement
of this Regulation, the tax so collected by any person under the said Act shall be deposited in
accordance with the provisions of the aforesaid Act and rules made thereunder, as if this Regulation
has not come into force and the said Act had not been repealed;(b)a return is required to be filed
under the Daman and Diu Sales Tax Act, 1964 (4 of 1964), as repealed by section 106, but the same
had not been filed before the commencement of this Regulation, such every return shall be filed in
accordance with the provisions of the said Act and by the person liable to file such return to the
authorities as may, by notification, be specified;(c)a return has been filed, under the Daman and Diu
Sales Tax Act, 1964 (4 of 1964) as repealed by section 106, by any dealer for any assessment year and
no assessment in respect of that year has been made before the commencement of this Regulation,
the proceedings for the assessment of that dealer for that year shall be made or be continued as if
this Regulation had not come into force and the said Act had not been repealed and such assessment
shall be made by such Assessing Authority as may, by notification, be specified; for the purposes of
making the assessment in such cases;(d)a person has been aggrieved by any decision made or order
passed under the Daman and Diu Sales Tax Act, 1964 (4 of 1964) as repealed by section 106 and he
has not filed any appeal or an application for rectification of his mistake or for review or revision,
such person may file an appeal or make an application for rectification of mistake, revision or
review, as the case may be, in accordance with the provision of the said Act and the rules made
thereunder to such authority as may, by notification, be specified for the purpose of hearing and
disposing of such appeal or application;(e)any liability of any dealer to pay tax, under the Daman
and Diu Sales Tax Act, 1964 (4 of 1964) as repealed by section 106, had been affected, and suchDaman and Diu Value Added Tax Regulation, 2005

person was entitled to make a statement of case to the High Court under section 28 of the said Act,
before the date of commencement of this Regulation, such person may, draw up, within two months
of the date of commencement of this Regulation, a statement of case (if not already drawn such
statement) and refer it to the High Court in accordance with the provisions of said section 28, as if
the aforesaid Act had not been repealed.(2)Where on the date of commencement of this Regulation,
where an appeal under the Daman and Diu Sales Tax Act, 1964 (4 of 1964), as repealed by section
106, has been pending before any authority under the said Act, such appeal shall be disposed of
within a period of five years from the date of the commencement of this Regulation.(3)The
Commissioner may, having regard to the difficulties, if any, for issuing tax invoices containing
particulars specified in clauses (a) to (g) of sub-section (2) of section 50, by a general order, waive all
or any of the particulars required to be mentioned in the tax invoices under said clauses (a) to (g),
for a period not exceeding two weeks from the date of commencement of this Regulation.
106. Repeal and savings.
(1)The Daman and Diu Sales Tax Act, 1964 (4 of 1964), as in force in Daman and Diu (referred to in
this section as the "repealed Act"), is hereby repealed.(2)Notwithstanding anything contained in
sub-section (1), such repeal shall not affect the previous operation of the repealed Act or any right,
title, entitlement, obligation or liability already acquired, accrued or incurred thereunder.(3)For the
purposes of sub-section (2), anything done or any action taken including any appointment,
notification, notice, order, rule, form or certificate in the exercise of any powers conferred by or
under the repealed Act shall be deemed to have been done or taken in the exercise of the powers
conferred by or under this Regulation, as if this Regulation were in force on the date on which such
thing was done or action was taken, and all arrears of tax and other amounts due at the
commencement of this Regulation may be recovered as if they had accrued under this
Regulation.(4)Save as otherwise provided in sub-sections (2) and (3), the mention of particular
matters in sub-sections (2) and (3) shall not be held to prejudice or affect the general application of
section 6 of the General Clauses Act, 1897 (10 of 1897) with regard to the effect of repeal.The First
Schedule(See section 6)List of Exempted Goods
Serial
number.Goods
1. Agricultural implements manually operated oranimal driven.
2. Aids and implements used by handicapped persons.
3. Aquatic feed, poultry feed and cattle feedincluding grass, hay and straw.
4. Betel leaves.
5. Books, periodicals, newspapers and maps.
6. Charakha, Ambar Charakha, hand-looms andhand-loom fabrics and Gandhi Topi.
7. Charcoal.
8. Coarse grains other than paddy, rice and wheat.
9. Condoms and Contraceptives.
10. Cotton and silk yarn in hank..Daman and Diu Value Added Tax Regulation, 2005

11. Curd, Lussi, butter milk and separated milk.
12. Earthen pot.
13. Electricity energy.
14. Firewood.
15. Fishnet, fishnet ropes and fishnet fabrics.
16. Fresh milk and pasteurized milk.
17. Fresh plants, saplings and fresh flowers.
18. Fresh vegetables and fruits.
19. Garlic and ginger.
20. Glass bangles.
21. Human blood and blood plasma.
22. Indigenous handmade musical instruments.
23. Kumkum, bindi alta and sindur.
24.Meat, fish, prawn and other aquatic productswhen not cured or frozen, eggs and
livestock and animal hair.
25. National Flag.
26. Organic manure.
27.Non-judicial stamp paper sold by GovernmentTreasuries, postal items like envelope,
post card etc. sold byGovernment, rupee note, when sold to the Reserve Bank of
Indiaand cheques, whether loose or book form.
28. Raw wool.
29. Semen including frozen semen.
30. Silk worm laying, cocoon and raw silk.
31. Slate and slate pencils.
32. Tender green coconut.
33. Toddy, Neera and Arak.
34. Breads of all types except pizza bread.
35. Unprocessed and unbranded salt.
36.Water other than aerated, mineral, distilled,medicinal, ionic, battery, de-mineralized
water and water sold insealed container.
37. Food grains including paddy, rice, wheat andpulses.
38.Items which are subjected to levy of additionalexcise duty under the provisions of the
Additional Duties ofExcise (Goods of Special Importance) Act, 1957.
The Second Schedule(See clause (a) of sub-section (1) of section 4)List of Goods Taxed at one per
cent.
Serial
number.Goods
1. Bullion.Daman and Diu Value Added Tax Regulation, 2005

2.Articles of gold, silver and precious metalsincluding jewellery made from gold, silver
and precious metals.
3. Precious stones and semi-precious stones.
4. Platinum Jewellery.
5. Noble metals.
The Third Schedule(See clause (b) of sub-section (1) of section 4)List of Goods Taxed at four per
cent.
Serial
numberGoods
1. Agricultural implements not operated manually ornot driven by animal.
2.All equipments for communications such as,Private Branch Exchange (PBX) and
Electronic Private AutomaticBranch Exchange (EPABX).
3. All intangible goods like copyright, patent, replicense, goodwill.
4.All kinds of bricks including fly ash bricks,refractory bricks and asphaltic roofing,
earthen tiles.
5. All types of yarn other than cotton and silkyarn in hank and sewing thread.
6. Aluminum utensils and enameled utensils.
7. Arecanut powder and betel nut.
8. Bamboo.
9. Bearings.
10. Beedi leaves.
11. Belting's.
12. Bicycles, tricycles, cycle rickshaws and parts.
13. Bitumen.
14. Bone meal.
15. Pizza bread.
16. Bulk drugs.
17. Castings.
18. Centrifugal, mono-bloc and submersible pumps andparts thereof.
19. Coffee beans and seeds, cocoa pod, green tealeaf and chicory.
20.Chemical fertilizers, pesticides, weedicidesinsecticides, Plant growth promoters and
Plant nutrients.
21. Coir and coir products excluding coirmattresses.
22. Cotton and cotton waste.
23. Crucibles.
24.Declared goods as specified in section 14 of theCentral Sales Tax Act, 1956 other than
items subjected to levy ofadditional excise duty under the provisions of Additional
Dutiesof Excise (Goods of Special Importance) Act, 1957.
25. Edible oils, oil cake and de-oiled cake.Daman and Diu Value Added Tax Regulation, 2005

26. Electrodes.
27. Exercise book, graph book and laboratory notebook.
28. Ferrous and non-ferrous metals and alloys.
29. Fibres of all types and fibres waste.
30. Flour, atta, maida, suji, besan.
31. Fried grams.
32. Gur, jaggery, and edible variety of rub gur.
33. Hand pumps and spare parts.
34. Herb, bark, dry plant, dry root, commonly knownas jari booti and dry flower.
35. Hose pipes.
36. Hosiery goods.
37. Husk and bran of cereals.
38. Ice.
39. Incense sticks commonly known as, agarbatti,dhupkathi or dhupbati.
40. Industrial cables (High voltage cables, PVC orXLPE Cables, jelly filled cables).
41.IT products including computers, telephone andparts thereof, teleprinter and wireless
equipment and partsthereof.
42. Kerosene oil sold through PDS.
43. Leaf plates and cups.
44. Murmuralu, pelalu, atukulu, puffed rice, muri.
45. Newars.
46. Napa Slabs (Rough flooring stones).
47. Ores and minerals..
48. Tea.
49. Paper and newsprint.
50. Pipes of all varieties including GI pipes, CIpipes, ductile pipes and PVC pipes.
51. Plastic footwear.
52. Printed material including diary, calendar.
53. Printing ink whether concentrated or solidexcluding toner and cartridges.
54. Processed and branded salt.
55. Pulp of bamboo, wood and paper.
56. Rail coaches engines and wagons.
57. Ready-made garments.
58. Renewable energy devices and spare parts.
59. Safety matches.
60. Seeds.
61. Sewing machines.Daman and Diu Value Added Tax Regulation, 2005

62. Ship and other water vessels.
63. Silk fabrics.
64. Skimmed milk powder.
65. Solvent oils other than organic solvent oil.
66. Spices of all varieties and forms includingcumin seed, aniseed, turmeric and dry chillies.
67. Sports goods excluding apparels and footwear.
68. Starch.
69. Tamarind.
70. Tractors, threshers, harvesters and attachmentsand parts thereof.
71. Transmission towers.
72. Umbrella except garden umbrella.
73. Vanaspati (Hydrogenated vegetable oil).
74. Vegetable oil including gingili oil and branoil.
75. Writing instruments.
76. Animal including fish fats, oils, crude, refinedor purified.
77. Glycerol, crude, glycerol waters and glycerollyes.
78. Vegetable waxes, bees wax.
79. Animal or vegetable fats boiled or oxidized ordehydrated.
80. Liquid glucose (non-medicinal), Dextrose syrup.
81. Denatured ethyl alcohol of any strength.
82. Manganese ores and concentrates.
83. Copper ores and concentrates.
84. Nickel ores and concentrates.
85. Cobalt ores and concentrates.
86. Aluminum ores and concentrates.
87. Lead ores and concentrates.
88. Zinc ores and concentrates.
89. Tin ores and concentrates.
90. Chromium ores and concentrates.
91. Tungsten ores and concentrates.
92. Uranium or thorium ores and concentrates.
93. Molybdenum ores and concentrates.
94. Titanium ores and concentrates.
95. Niobium, tantalum, vanadium or zirconium oresand concentrates.
96. Precious metal ores and concentrates.
97. Other ores and concentrates.
98. Granulated slag (slag sand) from manufacturingof iron or steel.Daman and Diu Value Added Tax Regulation, 2005

99. Benzole.
100. Toluole.
101. Xylole.
102. Napthalene.
103. Phenols.
104. Creosole oils.
105. Normal Paraffin.
106. Butadine.
107. Bitumen.
108. Flurine, chlorine, bromine and iodine.
109. Sulphur, sublimed or precipitated, colloidalsulphur.
110. Carbon (carbon blacks and other forms ofcarbon).
111. Hydrogen, rare gases & other non-metals.
112. Alkali or alkaline earth metals.
113. Hydrogen chloride.
114. Sulphuric acid and anhydrides.
115. Nitric acid, sulphonitric acids.
116. Diphosphorous penataoxide, phosphoric acid.
117. Oxides of boron, boric acids.
118. Halides and halide oxides of non-metals.
119. Sulphides of non-metals.
120. Ammonia, anhydrous.
121. Sodium hydroxide (caustic soda), Potassiumhydroxide (caustic potash) and soda ash.
122. Hydroxide and peroxide of magnesium.
123. Aluminum hydroxide.
124. Chromium oxides and hydroxides.
125. Manganese oxides.
126. Iron oxides and hydroxides.
127. Cobalt oxides and hydroxides.
128. Titanium oxides.
129. Hydrazine and hydroxylamine and their inorganicsalts.
130. Flurides, fluorosilicates.
131. Chlorides, chloride oxides.
132. Chlorates and perchlorates, Bromates.
133. Sulphides, Polysulphides.
134. Dithionites and sulphoxylates.
135. Sulphites, thiosulphates.Daman and Diu Value Added Tax Regulation, 2005

136. Copper sulphate.
137. Nitrites, nitrates.
138. Phosphinates, phosphonates.
139. Carbonates, peroxocarbonates.
140. Cyanides, cyanide oxides.
141. Fulminates, cyanates and thiocyanates.
142. Borates, peroxoborates.
143. Sodium dischromate.
144. Potassium dischromate.
145. Radioactive chemical elements.
146. Isotopes and compounds.
147. Compounds, inorganic or organic of rare earthmetals.
148. Phosphides,whether or not chemically defined.
149. Calcium carbides.
150. Ethylene, Propylene.
151. Cyclic Hydrocarbons.
152. Halogenated derivatives of Hydrocarbons.
153. Sulphonated, nitrated or nitrosated derivativesof hydrocarbons.
154. Methanol.
155. DI-Ethylene Glycol, Mono-Ethylene Glycol.
156. Cyclic alcohols.
157. Halogenated, sulphonated derivatives ofproducts.
158. Ethers, ether-alcohols, ether-phenols.
159. Expoxides, epoxyalcohols, epoxyethers.
160. Ethylene Oxide.
161. Acetals and hemiacetals.
162. Aldehydes whether or not with other oxygenfunction.
163. Halogenated, sulphonated, nitrated derivativesof phenols alcohols.
164. Saturated acyclic monocarboxylic acids.
165. Unsaturated acyclic monocarboxylic acids.
166. Polycarboxylic acids.
167. Carboxylic acids.
168. Phosphoric ester and their salts.
169. Esters of other inorganic acids.
170. Amine-function compounds.
171. Oxygen - function amino-compounds.
172. Quaternary ammonium salts and hydroxides.Daman and Diu Value Added Tax Regulation, 2005

173. Carboxyamide-function compounds.
174. Carboxyamide-function compounds includingsaccharin and its salts.
175. Nitrile-function compounds.
176. Diazo-, Azo- or azoxy-compounds.
177. Organic derivatives of hydrazine or ofhydroxylamine.
178. Organo-sulphur compounds.
179. Ethylene Diamine Tetra Acetic Acid.
180. Heterocyclic compounds with oxygen heteroatom(s)only.
181. Heterocyclic compounds with nitrogenheteroatom(s) only.
182. Nucleic acids and their salts.
183. Sulphonamides.
184. Glycosides, natural or reproduced by synthesisand their salts.
185. Vegetable alkaloids,natural or reproduced bysynthesis and their salts.
186. Tanning extracts of vegetable origin.
187. Synthetic organic tanning substances.
188. Coloring matter of vegetable or animal origin.
189. Synthetic organic coloring matter.
190. Color lakes.
191. Glass frit and other glass.
192. Printed driers.
193. Casein, Caseinates.
194. Enzymes, Prepared enzymes.
195. Artificial graphite.
196. Activated carbon.
197. Residual lyes from manufacturing of wood pulp.
198. Rosin and resin acids and derivatives.
199. Wood tar, wood tar oils.
200. Finishing agents, fixing of dye-stuffs.
201. Prepared rubber accelerators.
202. Reducers and blanket wash or roller wash.
203. Reaction initiators, reaction accelerators.
204. Mixed alkylbenzenes.
205. Chemical elements doped.
206. Industrial mono-carboxylic fatty acids.
207. Retarders.
208. LLDPE or LDPE.
209. HDPE.Daman and Diu Value Added Tax Regulation, 2005

210. Polymers of propylene.
211. PVC.
212. Acrylic polymers.
213. Poly-acetals.
214. Polythene chips.
215. Poly-amides.
216. Amino-resins, poly-phenylene oxide.
217. Silicons.
218. Petroleum resins.
219. Cellulose and its chemical derivatives.
220. Natural polymers.
221. Ion-exchangers based on polymers.
222. Self-adhesive plates, sheets, film, strip ofplastics.
223. Flexible plain films.
224. Articles for conveyance or packing of goods ofplastics.
225. Natural rubber, balata, gutta percha.
226. Synthetic rubber and factice derived from oils,reclaimed rubber.
227. Raw rubber, latex, dry ribbed.
228. Compounded rubber, unvulcanised.
229. Mechanical wood pulp, chemical wood pulp,semi-chemical wood pulp.
300. Cartons, boxes.
301. Paper printed labels, paperboard printed labels.
302. Paper self-adhesive tape.
303. Partially oriented yarn, polyester texturisedyarn.
304. Polyester staple fibre and polyester staplefibre fill.
305. Polyester staple fibre waste.
306. Sacks and bags, of a kind used for packing ofgoods.
307. Carboys, bottles, jars, phials of glass.
308. Stoppers, caps and lids.
309. Word processing machines, electronictypewriters.
310. Microphones, multimedia speakers, headphones.
311. Telephone answering machines.
312. Prepared unrecorded media for sound recording.
313. IT software.
314. Transmission apparatus other than apparatus forradio or T.V. broadcasting.
315. Radio communication receivers, radio pagers.
316. Aerials, antennas and parts.Daman and Diu Value Added Tax Regulation, 2005

317. LCD Panels, LED panels and parts.
318. Electrical capacitors, fixed, variable andparts.
319. Electronic calculators.
320. Electrical resistors.
321. Printed circuits.
322. Switches, connectors, relays for up to 5 amps.
324. Data or graphic display tubes, other thanPicture tubes and parts.
325. Diodes, transistors and similar semi-conductordevices.
326. Electronic integrated circuits andmicro-assemblies.
327. Signal generators and parts.
328. Optical fibre and optical fibre bundles, cables.
329. Liquid crystal devices, flat panel displaydevices and parts.
330. Computer systems and peripherals, electronicdiaries.
331. Cathode ray oscilloscopes, Spectrum analyzers,Signal analyzers.
332. Parts and Accessories of HSN 84.69, 84.70 and84.71 .
333. D C Micro-motors, stepper motors of 37.5 watts.
334. Parts of HSN 85.01.
335. Uninterrupted power supply.
336. Permanent magnets and articles.
337. Electrical apparatus for line telephony or linetelegraphy.
337. Coal.
338. Hides and skin.
339. Oil-seeds.
340. Acids.
341. Aluminum conductor steel reinforced (ACSR).
342. Aluminum, aluminum alloys, their products exceptextrusions.
343. Polyster and staple fibre yarn.
344. Bagasse.
345. Basic chromium sulphate, sodium bi-chromate.
346. Biomass briquettes.
347. Castor oil.
348. Dyes, acid dyes, basic dyes.
349. Mixed PVC stabilizer.
350. Maize starch, glucose 'D', maize gluten, maizegerm and oil.
351. Paraffin wax .
352. Alloys and scraps of ferrous and non-ferrousmetals.
353. Gypsum of all forms and descriptions.Daman and Diu Value Added Tax Regulation, 2005

354. Hand-loom woven Gamcha, Khaddar and Khadi.
355. Hurricane lantern and kerosene lamp andaccessories and components thereof.
356. Lac and shellac.
357. Paper board - essentially as an input forpacking materials.
358. Transformer.
359. Waste paper.
360. Windmill for water pumping and for generation ofelectricity.
The Fourth Schedule(See clause (c) of sub-section (1) of section 4)List of Goods Taxed at twenty per
cent.
Serial
number.Goods
1.Petroleum Products (other than liquid petroleumgas, Compressed Natural Gas and
Kerosene) such as Naphtha,Aviation Turbine Fuel, Spirit, Gasoline, Diesel (High
SpeedDiesel, Super Light Diesel Oil, Light Diesel Oil), Furnace Oil,Organic Solvent, Coal
Tar, Mixture and combination of aboveproducts.
2. Liquor (Foreign and Indian made foreign liquor).
3. Country liquor.
4. Narcotics (bhaang).
5. Molasses.
6. Rectified spirit.
7. Lottery tickets.
8. Brake fluid.
The Fifth Schedule(See sub-section (1) of section 41)
Serial
number.List of organizations which can claim refund
1. Afghanistan.
 H.E. Ambassador of Republic of Afghanistan.
 The Embassy of Republic of Afghanistan. TheDiplomatic Officers (including their
spouses) of the Embassy ofAfghanistan.
2. Afro-Asian Rural Reconstruction Organization.
3. Algeria.
 The Embassy of Democratic and Popular Republicof Algeria.
4. Angola.
 The Embassy of Angola in on the purchase made bythe diplomats for Official and
personal use.
5. Apostolic Nunciature.
6. Argentina.
 Embassy of Argentine Republic on the purchasesmade by its diplomats for official as
well as personal use.Daman and Diu Value Added Tax Regulation, 2005

7. Armenia.
 Embassy of Armenia on the purchases made by themission for official use.
8. Asian African Legal Consultive Committee,
 for its official use.
9. Asian Development Bank.
10. Australia.
 The High Commission and its Diplomatic Officersin respect of purchases made from
bounded stores only for theirofficial and personal use.
11. Austria.
 The Embassy of Austria in India (for salesintended for their official use).
 The Diplomatic Officers of the Embassy ofAustria in India (for sales intended for their
personal use).
12. Bangladesh.
 The High Commission for the Peoples Republic ofBangladesh in India.
 The Diplomatic Officers (including theirspouses) of the High Commission for the
Peoples Republic ofBangladesh in India.
13. Belarus.
 The Embassy of Belarus in India. Purchases madefor its diplomatic and
administrative/technical personnel forofficial as well as personal use.
14. Belgium.
 H.E. the Ambassador of Belgium in India.
 The Embassy of Belgium in India.
 The Diplomatic Officers of the Belgium Embassyin India.
15. Bhutan.
 The Royal Bhutan Mission for sales intended forofficial use of Mission.
 The Representative of Bhutan for sales intendedfor personal use.
 The Diplomatic Officers of the Royal BhutanMission for sales intended for personal
use.
16. Brazil.
 The Embassy of the Federative Republic of Brazilin India.
 The Diplomatic Officers (including theirspouses) of the Embassy of Federative Republic
of Brazil inIndia.
17. Britain.
 The High Commission for Britain in India (allsales for official use).
 The Diplomatic Officers (including theirspouses) of the High Commission for Britain in
India (sales ofimported goods from bonded stocks only).
18. Brunei Darussalam.
 Embassy of Brunei Darussalam on the purchasesmade by its Diplomats for Official asDaman and Diu Value Added Tax Regulation, 2005

well as personal use.
19. Bulgaria.
 H.E. the Ambassador of the Peoples Republic ofBulgaria in India.
 The Embassy of the Peoples Republic of Bulgariain India.
 The Diplomatic Officers (including theirspouses) of the Embassy of the Peoples
Republic of Bulgaria inIndia.
20. Canada.
 H.E. the High Commissioner for Canadian inIndia.
 The Diplomatic Officers of the Canada HighCommission.
 The Canadian High Commission.
21. Central Africa.
 The Embassy of the Central African Empire .(forsales intended for official use).
 The Diplomatic Officers (including theirspouses) of the Embassy of the Central African
Empire (for salesintended for their personal use).
22. China.
 H.E. the Chinese Ambassador in India.
 The Embassy of the Peoples Republic of China.
 The Diplomatic officers of the Chinese Embassyin India
23. Columbia.
 The Embassy of Columbia in India.
24. Combodia.
 H.E. the ambassador of Combodia in India.
 The Embassy of Combodia in India.
 The Diplomatic Officers (including theirspouses) of the Embassy of Combodia in India.
25. Officials of the Commission of The EuropeanCommunities for setting up their office.
 (B) Personnel of the delegation holdingdiplomatic status (other than Indian nationals
and personspermanently resident in India Employed by the said Commission).
26. Common Educational Media Centre For Asia.
 Common Educational Media Centre on the purchasemade for official use and by its
President and Vice-President forpersonal use.
27. Congo.
 The Congolese Embassy and their DiplomaticOfficers.
28. Croatia.
 Embassy of Croatia on the purchases made by itsdiplomats for official as well as for
personal use of theirofficials.
29. Cuba.
 The Embassy of the Republic of Cuba in India.
 The Diplomatic Officers (including theirspouses) of the Republic of Cuba in India.Daman and Diu Value Added Tax Regulation, 2005

30. Cyprus.
 The Cyprus High Commission (for sales intendedfor official use).
 The Diplomatic Officers (including their spousesof the Cyprus High Commission (for
sales intended for theirpersonal use).
31. Czech Republic.
 Embassy of Czech Republic on the purchases madeby its diplomats for official as well as
for personal use oftheir officials.
32. Denmark.
 The Royal Danish Embassy in India.
 The Diplomatic Officers (including theirspouses) of the Royal Danish Embassy in India.
33. Dominica.
 The High Commission for the Commonwealth ofDominica (for its official purchases).
 The Diplomatic Officials of the High Commissionfor the Commonwealth of
Dominica(for their personal use).
34. Egypt.
 The Embassy of the Arab Republic of Egypt inIndia.
 The Diplomatic officers (including theirspouses) of the Embassy of the Arab Republic of
Egypt in India.
35. Ethopia.
 The Ethopian Embassy in India (for its officialpurchases).
 The Diplomatic Officers of the Ethopian Embassyin India (for their personal
purchases).
36. Finland.
 Embassy of Finland on the purchase of followingitems made by its diplomats for official
purpose.
 (1) Construction materials as well commoditiesto be used for the interior decoration
and furnishing ofbuilding.
 (2) Commodities used in representationalfunctions.
 (3) Motor vehicles as well as spare parts andequipment for Motor vehicles.
 (4) Work performances concerning the premises ofa mission or office and the
commodities referred to in items (1)to (3) or the rental of those commodities.
 (5) Telecommunication services, energycommodities and fuel purchased for the
building of a mission oroffice.
 (6) Fuels for motor vehicles.
37. France.
 The Embassy of France on the purchases made byits diplomats for Official purposes
and for the residence of theAmbassador.
38. Germany.
 The Embassy of Germany in India (for salesintended for official use only).Daman and Diu Value Added Tax Regulation, 2005

 The Diplomatic Officers of the German Embassy inIndia (for sales intended for
personal use).
39. Ghana.
 The High Commissioner for Ghana in India.
 The Diplomatic officers (including theirspouses) of the High Commissioner for Ghana
in India.
40. Greece.
 The Royal Greek Embassy in India.
 The Diplomatic Officers (including theirspouses) of the Royal Greek Embassy in India.
41. Guyana.
 The High Commission for Guyana, and itsDiplomatic Officers (including their spouses).
42. Hungary.
 H.E. The Ambassador of the Hungarian PeoplesRepublic in India.
 The Embassy of the Hungarian peoples Republic inIndia.
 The Diplomatic officers (including theirspouses) of the Embassy of the Hungarian
Peoples Republic inIndia.
43. Indonesia.
 The Embassy of Indonesia on all its officialpurchases and the purchases made by its
officials for theirpersonal use.
44.International Bank For Reconstruction andDevelopment In India and Employees, other
than those recruitedlocally of the International Bank for Reconstruction
andDevelopment in India.
45.International Centre For Genetic Engineering andBiotechnology, (for all its official
purchases).
46. (A) Office of the International Court of Justice(for sales intended for official use).
 (B) Dr. Nagendra Singh an elected judge of theInternational Court of Justice, (for sales
intended for hispersonal use).
47. International Labour Office.
48. Iran.
 The Embassy of Iran in India.
 The Diplomatic officers (including theirspouses) of the Embassy of Iran in India.
49. Iraq.
 H.E. the Ambassador of the Republic of Iraq inIndia.
 The Embassy of Republic of Iraq in India.
 The Diplomatic Officers (including theirspouses) of the Embassy of Iraq in India.
50. Ireland.
 The Embassy of Ireland in India.
 The Diplomatic Officers (including theirspouses) of the Embassy of Ireland in India.Daman and Diu Value Added Tax Regulation, 2005

51. Israel
 The Embassy of Israel on purchases made by itsdiplomats for official as well as for
personal use.
52. Italy.
 Embassy of Italy on the purchase made by itsdiplomats for official use as well as for
personal use of theirofficials.
53. Japan.
 The Embassy of Japan and its DiplomaticOfficers.
54. Jordan.
 The Embassy of Hashemite Kingdom of Jordon inIndia.
 The Diplomatic Officers (including theirspouses) of the Embassy of the Hashemite
Kingdom of Jordon inIndia).
55. Kazakhstan.
 The Embassy of Kazakhstan on the purchases madeby its diplomats for official as well
as for personal use.
56. Kenya.
 For official use as well as Diplomatic Officers(including their spouses) of the Kenya
High Commission in India.
57. Korea.
 H.E. the Ambassador of Korea.
 Embassy of the Republic of Korea.
 The Diplomatic Officers (including theirspouses) of the Embassy Republic of Korea.
58. Korea (D.P.R.).
 H.E. The Ambassador of the Democratic PeoplesRepublic of Korea.
 Embassy of the Democratic People Republic ofKorea.
 The Diplomatic Officers (including theirspouses) of the Embassy of the Democratic
Peoples Republic ofKorea.
59. Kuwait.
 H.E. the Ambassador of the State of Kuwait inIndia.
 The Embassy of the state of Kuwait in India.
 The Diplomatic officers of the Embassy of theState of Kuwait in India.
60. Kyrghystan.
 The Embassy of Kyrghystan on the purchases madeby its diplomats for official as well
as for personal use.
61. Laos.
 The Royal Embassy of Laos in India.
 The Diplomatic Officers (including theirspouses) of Royal Embassy of Laos in India.
62. League of Arab States Mission.Daman and Diu Value Added Tax Regulation, 2005

 League of Arab States Mission.
 Chief Representative, Deputy Chiefrepresentative, their spouses and minor children of
the league ofArab States Mission.
63. Lebanon.
 H.E. the Ambassador of Lebanon in India.
 The Embassy of Lebanon in India.
 The Diplomatic Officers (including theirspouses) of the Embassy of Lebanon.
64. Liberia.
 Embassy of Liberia on all its official purchasesas well as purchases made by its officials
for their personaluse.
65. Libya
 The Embassy of the Libyan Arab Republic in India(for sales intended for official use.)
 The Diplomatic Officers (including theirspouses) of the Embassy of the Libyan Arab
Republic in India (forsales intended for their personal use.
66. Luxembourg.
 Embassy of Grand Duchy of Luxembourg in respectof goods purchased by them for
official use only.
67. Malaysia.
 The High Commissioner for Malaysia in India.
 The Diplomatic Officer (including their spouses)of the High Commissioner for Malaysia
in India.
68. Mauritius
 The High Commission of Mauritius and itsDiplomatic Officers.
69. Mexico.
 The Embassy of Mexico in India.
 The Diplomatic Officers (including theirspouses) of the Embassy of Mexico in India.
70. Mongolia.
 H.E. the Ambassador of the Mongolian PeoplesRepublic in India.
 The Embassy of the Mongolian Peoples Republic inIndia.
 The Diplomatic Officers of the Embassy of theMongolian Peoples Republic in India.
71. Morocco
 Embassy of Morocco on the purchases made by itsdiplomats for official as well as
personal use.
72. Mozambique.
 High Commission of the Republic of Mozambique inrespect of goods purchased by
them for official use only.
73. Myanmar.
 The Embassy of the Republic of the Myanmar inIndia. (Restricted to sale of goods fromDaman and Diu Value Added Tax Regulation, 2005

bonded stocks)
 The Diplomatic Officers (including theirspouses) of the Embassy of the Union of
Myanmar in India.(sale ofpetrol only)
74. Namibia.
 Namibian High Commission on the purchase made byits diplomats for official as well
as for personal use.
75. Nepal.
 The Royal Nepalese Embassy in India, and
 The Diplomatic Officers (including theirspouses) of the Royal Nepalese Embassy in
India.
76. Netherlands.
 The Royal Netherlands Embassy in India.
 The Diplomatic Officers (including theirspouses) of the Royal Netherlands Embassy in
India.
77. Nicaragua.
 The Embassy of Nicaragua on all its officialpurchases as well as the purchases made by
its officials fortheir personal use.
78. NIGERIA..
 H.E. the High Commission of the Federal Republicof Nigeria in India.
 The High Commission for the Federal Republic ofNigeria.
 The Diplomatic Officers of the High Commissionfor the Federal Republic of Nigeria in
India.
79. Norway.
 H.E. the Norwegian Ambassador in India.
 The Royal Norwegian Embassy in India.
 The Diplomatic Officers (including theirspouses) of the Royal Norwegian Embassy in
India.
80. Oman.
 The Embassy of Sultanate of Oman and itsDiplomatic Officers.
81. Pakistan.
 The Embassy of Pakistan in India.
 The Diplomatic Officers (including theirspouses) of the Embassy of Pakistan in India.
82. Panama.
 The Embassy of Panama and its DiplomaticOfficers in respect of purchases made from
bonded stores only.
83. Philippines.
 H.E. the Ambassador of the Philippines in India.
 The Embassy of Philippines in India, andDaman and Diu Value Added Tax Regulation, 2005

 The Diplomatic Officers (including theirspouses) of the Embassy of the Philippines in
India.
84. PLO.
 The Embassy of the Palestine LiberationOrganization (for sales intended for official
use).
 The Diplomatic Officers (including theirspouses) of the Embassy of the Palestine
Liberation Organization(for sales intended for personal use).
85. Poland.
 The Embassy of the Polish Peoples Republic andtheir Diplomatic Officers.
86. Portugal.
 The Diplomatic Officers (including theirspouses) of the Embassy of Portugal in India
(for sales intendedfor their personal use).
87. Qatar.
 The Embassy of the State of Qatar.
 The Diplomatic Officers of the Embassy of theState of Qatar, and their spouses for sales
intended for theirpersonal use.
88. Romania.
 H.E. the Ambassador of the Socialist Republic ofRomania in India.
 The Embassy of the Socialist Republic of Romaniain India.
 The Diplomatic Officers (including theirspouses) of the Embassy of the Socialist
Republic of Romania.
89. Russia.
 The Embassy of the Russian Federation on thepurchases made by the Diplomats for
official and personal use.
90. Rwanda.
 Embassy of Republic of Rwanda on the purchasesmade by its diplomatic and
administrative/ technical personnelfor official as well as personal use.
91. Sahrawi Arab Democratic Republic.
 The Embassy of Sahrawi Arab Democratic Republic.
 The Diplomatic Officers of the Embassy ofSahrawi Arab Democratic Republic.
92. Saudi Arabia.
 H.E. the Ambassador of Saudi Arabia in India.
 The Embassy of Saudi Arabia in India.
 The Diplomatic Officers (including theirspouses) of the Embassy of Saudi Arabia in
India.
93. Senegal.
 The Embassy of Republic of the Senegal in India(for sales intended for the official use
of the Embassy).
 Daman and Diu Value Added Tax Regulation, 2005

The Diplomatic Officers (including theirspouses) the Embassy of the Republic of
Senegal in India (forsales intended for personal use).
94. Singapore.
 The High Commission for Singapore.
 Their Diplomatic Officers.
95. Slovak Republic.
 Embassy of Slovak Republic on the purchase madeby its diplomats for official as well as
for personal use oftheir officials.
96. Somalia.
 The Embassy of Somalai in India (for salesintended for official use).
 The Diplomatic Officers (including theirspouses) of the Embassy of the Somali in India
(for salesintended for their personal use).
97. South Africa.
 Embassy of South Africa on the purchase made byits diplomats for official as well as for
personal use.
98. South West African Peoples Organization (Swapo).
 Embassy of South West African PeoplesOrganization (SWAPO) - on all its official
purchases and thepurchases made by its officials for their personal use.
99. Spain.
 H.E. the Ambassador of Spain in India.
 The Embassy of Spain in India.
 The Diplomatic Officers of the Embassy of Spainin India.
100. Sri Lanka.
 The High Commission for the Democratic SocialistRepublic of Sri Lanka for purchase
made for its official use aswell by diplomats.
101. Sudan.
 The Embassy of Democratic Republic of Sudan inIndia.
 The Diplomatic Officers (including theirspouses) of the Embassy of the Democratic
Republic of Sudan inIndia.
 (Exemption extended to purchases from placesother than bonded stocks).
102. Suriname.
 The Embassy of Republic of Suriname on thepurchases made for official use as well as
personal use of thediplomats.
103. Sweden.
 The Royal Swedish Embassy in India (for itsofficial purchases).
 The Diplomatic Officers of the Royal SwedishEmbassy in India (for their personal use).
104. Switzerland.
 Embassy of Switzerland on the purchase made byits diplomats for official as well as for
personal use of theirofficials.Daman and Diu Value Added Tax Regulation, 2005

105. Syria.
 The Embassy of the Syrian Arab Republic &their Diplomatic Officers.
106. Thailand.
 The Royal Thai Embassy in India.
 The Diplomatic Officers (including theirspouses) of the Royal Thai Embassy in India.
107. Trinidad.
 The High Commission for Trinidad and Tobago inIndia.
 The members of the Diplomatic Staff of the saidHigh Commission.
 (Exemption restricted to (i) sale intended forthe official use of the Commission and (ii)
sale intended forpersonal use).
108. Tunisia.
 The Embassy of Tunisia on the purchases made byits Diplomats for official as well as
personal use.
109. Turkey.
 Embassy of Turkey on the purchase made by itsdiplomats for official as well as for
personal use.
110. Uae.
 The Embassy of the United Arab Emirates, for itsofficial use.
 The Diplomatic Officers of the Embassy of theUnited Arab Emirates, and their spouses
for sales intended fortheir personal use.
111. Uganda.
 The High Commission for the Republic of Ugandain India.
 The Diplomatic officers (including theirspouses) of the High Commission for the
Republic of Uganda inIndia.
112. Ukraine.
 Embassy of Ukraine in on the purchase made byits diplomats for official as well as for
personal use.
113. United Nations Development Programme
114.The Regional Office for India, Nepal Ceylon,Iran, Afghanistan and Pakistan of The
United Nations EconomicCommission For Asia and Far East (Division of Social
Affairs).
115. United Nations Education Scientific and CulturalOrganization
116.United Nations Educational Scientific andCultural Organization Research Centre On
Social and EconomicDevelopment In Southern Asia.
117. United Nations Food and AgriculturalOrganization.
118. United Nations High Commission For Refugees.
 (Exemption For Official Use Only).
119. United Nations Information Centre.
120. United Nations International Children'sEmergency Fund.Daman and Diu Value Added Tax Regulation, 2005

121. United Nations Military Observers Group In Indiaand Pakistan.
122. United Nations Office For Population Studies.
123.The Regional Office of The United Nations WorldHealth Organization for South East
Asia, (for sales intended forofficial use).
 (B) The Regional Director (including hisspouses) of the United Nations World Health
Organization forSouth East Asia, (for sales intended for personal use).
124. United States Agency For InternationalDevelopment Mission.
 United States Agency for InternationalDevelopment Mission and Employees other than
the locallyrecruited staff of the United States Agency for InternationalDevelopment
Mission.
125. Uruguay.
 H.E. the Ambassador of the Oriental Republic ofUruguay in India.
 The Embassy of the Oriental Republic of Uruguayin India.
 The Diplomatic Officers (including theirspouses) of the Oriental Republic of Uruguay in
India.
126. USA.
 The Embassy of the U.S.A. in India.
 H.E. the Ambassador of the U.S.A. in India.
 The Diplomatic Officers (including their spousesand dependents) of the Embassy of
U.S.A. in India.
127. Russian Federation.
 H.E. The Ambassador of the Russian Federation inIndia.
 The Embassy of the Russian Federation in India.
 The Diplomatic Officers of the Embassy ofRussian Federation in India.
128. Uzbekistan.
 The Embassy of Republic of Uzbekistan in on thepurchase made by its diplomats for
official as well as forpersonal use.
129. Vietnam (Democratic Republic).
 H.E. the Ambassador of the Democratic Republicof Vietnam in India.
 The Embassy of the Democratic Republic ofVietnam in India.
 The Diplomatic Officers (including theirspouses) of the Embassy of the Democratic
Republic of Vietnam inIndia.
130. Vietnam (Republic).
 The Counsel General of the Republic of Vietnamin India.
 The Consulate General of the Republic of Vietnamin India.
 The Consular Officer of the Consulate General ofthe Republic of Vietnam in India.
131. Venezuela.
 The Embassy of Venezuela in India.Daman and Diu Value Added Tax Regulation, 2005

 The Diplomatic Officers (including theirspouses) of the Embassy of Venezuela in India.
132. Yemen.
 The Embassy of the peoples Democratic Republicof Yemen in India.
 The Diplomatic Officers (including theirspouses) of the Embassy of Peoples Democratic
Republic of Yemenin India.
133. Yugoslavia
 The Embassy of the Socialist Federal Republic ofYugoslavia in India.
 The Diplomatic Officers (including theirspouses) of the Embassy of Federal Republic of
Yugoslavia inIndia.
134. Zaire.
 H.E. the Ambassador of the Republic of Zaire inIndia.
 The Embassy of the Republic of Zaire in India.
 The Diplomatic Officers (including theirspouses) of the Embassy of the Republic of
Zaire in India.(exemption restricted to goods from bonded stores only).
135. Zambia.
 The High Commission of Zambia in India (forsales intended for official use).
 The Diplomatic Officers (including theirspouses) of the Zambian High Commission in
India (for salesintended for personal use).
 (exemption is restricted to goods manufacturedor produced in India and not imported
from out of India).
136. Zimbabve.
 The Zimbabve High Commission for its officialpurchases only upon certification of the
Head of Mission ChargedAffairs.
The Sixth Schedule(See clause (b) of sub-section (2) of section 9)List of non-creditable goods
Serial
number.Description of non-creditable goods
1.Subject to clauses 2 and 3 of this Schedule, thefollowing goods shall be "non-creditable
goods" for thepurposes of this Regulation:
 (i) Motor vehicles designed for transportingfewer than eight passengers, motor cycles,
motor scooters andother motorized two-wheeled vehicles;
 (ii) Fuels in the form of petrol, diesel andkerosene, LPG, CNG, coal;
 (iii) Conventional clothing and footwear,clothing fabrics;
 (iv) Food for human consumption;
 (v) Beverages for human consumption;
 (vi) Goods designed, and used predominantly for,the provision of entertainment
including television receivers,video cassette players, radios, stereo systems, audio
cassetteplayer, CD players, DVD players, computer game consoles andcomputer games,
cameras of any kind;
 (vii) Air conditioners other than those used formanufacturing purposes; andDaman and Diu Value Added Tax Regulation, 2005

 (viii) Tobacco in any form and tobacco products.
2.Any item in clause other than Item (ii) shallnot be treated as non-creditable goods if the
item is purchasedby a registered dealer for the purpose of re-sale in anunmodified form
or use as raw material for processing ormanufacturing of goods for sale by him in Dadra
and Nagar Haveliin the ordinary course of his business.
3.Fuel Item (ii) of clause 1 shall not betreated as non-creditable goods if the purchaser is
licensed as adealer in fuel products and purchases the fuel in commercialquantities for
resale.Daman and Diu Value Added Tax Regulation, 2005

