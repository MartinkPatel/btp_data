Akhil Bharat Goseva Sangh vs State Of A.P.& Ors on 29 March,
2006
Author: Tarun Chatterjee
Bench: Chief Justice, Tarun Chatterjee
           CASE NO.:
Appeal (civil)  3968 of 1994
PETITIONER:
Akhil Bharat Goseva Sangh
RESPONDENT:
State of A.P.& Ors
DATE OF JUDGMENT: 29/03/2006
BENCH:
CJI & TARUN CHATTERJEE
JUDGMENT:
J U D G M E N T (With C.A.Nos.3964-3967 of 1994) With Cont .Pet. No...IN
C.A.No.3967/1994 And CIVIL APPEAL NOS. 4711-4713 OF 1998 Umesh & Others Appellants
Versus State of Karnataka & Ors. Respondents.
TARUN CHATTERJEE, J.
Al-Kabeer Exports Limited ( in short 'Company') is a public company formed for the purpose of
carrying on the business of processing meat, mainly for export purposes. The company with a view
to establish a slaughter house in Rudraram village, in the Medak District of the State of Andhra
Pradesh applied to the Gram Panchayat, Rudraram for the requisite permission to construct a
factory and other buildings connected therewith. On 24th March 1989, the Gram Panchayat
concerned, issued a 'No Objection Certificate' (in short 'NOC'). After obtaining opinion of the
District Medical and Health Officer, Director of Town Planning and Director of Factories, State of
Andhra Pradesh, permission was granted to the company to run a slaughter house on the selected
site on 29th June 1989. Prior to this permission, the Andhra Pradesh Pollution Control Board (for
short 'A.P.P.C.B.') also issued a 'NOC' on the application of the company filed on December 30,
1988, subject to certain conditions concerning the treatment of effluents and air pollution. In the
said NOC, it was inter-alia stipulated that the company shall obtain a second 'NOC' and a regular
consent under Sections 25 and 26 of the Water (Prevention and Control of Pollution) Act, 1974 from
A.P.P.C.B. before commencing regular production. The Director, Animal Husbandry Department,
Government of Andhra Pradesh also issued a NOC in favour of the company by a letter dated July
13, 1989, subject to compliance with the provisions of Sections 5 and 6 of the Andhra PradeshAkhil Bharat Goseva Sangh vs State Of A.P.& Ors on 29 March, 2006

Prohibition of Cow Slaughter and Animal Preservation Act, 1977 ( in short the 'A.P. Act') and the
instructions issued there under. Subsequently, on 18th July 1989 the Central Government (Ministry
of Industry) granted a Letter of Intent (in short 'L.O.I.') under the provisions of the Industries
(Development and Regulation) Act, 1951 (in short 'IDR Act') for establishment of a new industrial
undertaking to the company at the selected site mentioned herein earlier for manufacturing of
certain amount of Frozen Buffalo and Mutton Meat. The LOI was granted, subject to the following
conditions:-
"(a) Buffaloes to be slaughtered shall be subject to anti-mortem and post-mortem
examination by the concerned authorities.
(b) Only old and useless buffaloes shall be slaughtered and for this purpose, their
production and processing shall be subject to continuous inspection by the Municipal
Authorities, Animal Husbandry and Health Department of the State Government or
any other arrangement that the Central or the State Government may evolve for
ensuring this.
(c) Slaughter of cows of all ages and calves of cows and buffaloes male or female, shall
be prohibited.
(d) The company shall undertake measures for preserving and improving the breeds
of the buffaloes by adoption of suitable animal husbandry practices in consultation
with the State Government.
(e) At least 90% production of frozen buffalo meat would be exported for a period of
ten years which may be extended by another five years at the discretion of the
Government.
(f) Adequate steps shall be taken to the satisfaction of the Government to prevent air,
water and soil pollution. Such anti-
pollution measures to be installed should conform to the effluent and emission standards prescribed
by the State Government in which the factory of the industrial undertaking is located.
(g) The new industrial undertaking or the industrial activity for effecting substantial expansion or
for manufacture of new article shall not be located within:
(i) 50 kilometers from the boundary of the standard urban area limits of any city
having a population of more than 25 lakhs according to the 1981 census; or
(ii) 30 kilometers from the boundary of the standard urban area limits of any city
having a population of more than 15 lakhs but less than 25 lakhs according to the
1981 census;Akhil Bharat Goseva Sangh vs State Of A.P.& Ors on 29 March, 2006

(h) In case the location of the industrial undertaking is in no Industry District,
change of location from No Industry District to any other area including a notified
backward area either within the same State or outside the State will not normally be
allowed."
The recommendation was also made by the State of Andhra Pradesh to grant industrial licence to set
up abattoir slaughter house at the selected site.
If we are permitted to read the various conditions for grant of LOI issued by the Central Government
carefully, it would be evident that only old and useless buffaloes shall be available for slaughtering
and their production and processing shall be subject to continuous inspection by the Municipal
Authorities, Department of Animal Husbandry and Health Department of the State Government.
Clause (c) of the LOI speaks of total prohibition of slaughtering of cows of all ages and calves of cows
and buffaloes, male or female. Clause (d) invites the company to undertake measures of prohibiting
and improving the breeds of the buffaloes by adoption of suitable animal husbandry practices in
consultation with the State Government. Clause (e) of L.O.I. provides that 90% of the production of
frozen buffalo meat would be exported for a period of ten years which may be extended by five years
at the discretion of the Government. Clause (f) directs to take adequate steps to the satisfaction of
the Government to prevent air, water and soil pollution and for this purpose anti pollution measures
must be installed to enforce the effluent and emission standards prescribed by the State
Government. Clause (g) of the LOI says that a new industrial undertaking shall not be located either
for effecting substantial expansion or for manufacture of new article if the said location is situated
within 50 km from the boundary of the standard urban area of any city having a population of more
than 25 lakhs according to 1981 census or is located 30 km from the boundary of the standard urban
area limit of any city having a population of more than 15 lakhs but less than 25 lakhs according to
1981 census. On 28th August 1991 the Agriculture and Processed Food Products Export
Development Authority informed the company that the Government of India was keen to promote
the export of meat and meat products as part of its export drive.
It is an admitted position that for the purpose of running the slaughter house, the company, as
noted herein earlier, had applied for licences to various authorities of the State Government as well
as of the Central Government. Having been satisfied and after holding enquiry, permission and/or
licence was granted to the company first for the purpose of making construction at the site in
question and thereafter for running the slaughter house. Such being the position and in view of the
reasons given hereinafter we cannot apprehend that the company was permitted, by the authorities,
first to make construction of the factory at the selected site and thereafter to run the slaughter house
without being satisfied that the conditions for grant of permission and licence were observed by the
company.
It is not in dispute that on the basis of the LOI and permission granted by the State of Andhra
Pradesh and other authorities including the APPCB, the company started its construction work for
installation of buildings and machineries, for the purpose of running a slaughter house. When some
construction had progressed, the Executive Officer of the Gram Panchayat concerned issued a notice
in the exercise of his power under section 131 (3) of the Andhra Pradesh Gram Panchayat Act, 1964Akhil Bharat Goseva Sangh vs State Of A.P.& Ors on 29 March, 2006

suspending the permission granted for construction of the factory building and other buildings to
the company and thereby directed stoppage of constructions until further orders. Challenging this
order of the Executive Officer, the company filed a Writ Petition before the High Court of Andhra
Pradesh. Some organizations opposed the proposed establishment of the slaughter house and they
were impleaded as respondents to the said writ petition. The writ petition was, however,
subsequently withdrawn by the company and instead a revision petition was filed before the State
Government questioning the notice issued by the Executive Officer on the suspension of the
construction work which was permitted by the State Government. After hearing all the concerned
parties, by an order dated 15th September 1990 the revision case was allowed by the State
Government. A bare reading of this order would show that the order of the Executive Officer was not
only directed to be set aside but also the period of completing the construction work was extended
by one more year, from 29th of June 1989. Against the order passed in the revision case, two writ
petitions being W.P.No.13763 and W.P.No.13808 of 1990 were filed in the High Court  one by
those organizations who were impleaded in the earlier writ petition and the other by some
individuals. These two writ petitions were admitted by a learned Single Judge of the High Court and
by an interim order, the operation of the order passed in the revision case was suspended pending
decision of the two writ petitions. Against the aforesaid interim order, the State Government as well
as the company filed writ appeals which were admitted by a Division Bench of the High Court and
the interim order granted by the learned Single Judge was stayed by an interim order of the Division
Bench of the High Court. When the writ appeals came up for final hearing, the parties before the
Division Bench prayed that the writ petitions be disposed of on merits. Such stand having been
taken by the parties before the Division Bench, the writ petitions were heard and disposed of by an
order dated November 16, 1991 on merits with the following directions:-
"...However, we direct that the State Government shall prepare a detailed report
regarding the water, air and environment pollution, if any, as at present in Rudraram
and surrounding villages of Patancheru Mandal, Medak District having regard to the
provisions of the Water (Prevention and Control of Pollution) Act, 1974, the Air
(Prevention and Control of Pollution) Act, 1981 and the Environment (Protection)
Act, 1986 and the rules made thereunder, the likely effect of the setting up of the
mechanized slaughter house at Rudraram village on the prevailing environment, and
also its likely effect on the cattle wealth in the area, after considering the
representations which the petitioners in these writ petitions and other interested
parties may submit in writing in this regard. The petitioners herein and other
interested persons shall submit the representations and other supporting material in
writing to the State Government within four weeks from today. The State
Government shall prepare and submit a detailed report to the Central Government
within eight weeks from the date of receipt of the copy of this judgment. On receipt of
the report, the Central Government shall consider the same, having regard to the
provisions of the Water (Prevention and Control of Pollution) Act, 1974, the Air
(Prevention and Control of Pollution) Act, 1981, the Environment (Protection) Act,
1986 and the Industries (Development and Regulation) Act, 1951 and pass
appropriate orders in relation to the establishment of the mechanized slaughter
house (abattoir) at Rudraram village, Patancheru Mandal, Medak District, AndhraAkhil Bharat Goseva Sangh vs State Of A.P.& Ors on 29 March, 2006

Pradesh, within eight weeks from the date of receipt of the report."
(Emphasis supplied).
It may be kept in mind that this order of the Division Bench by which certain directions were made
by it to the State Government as well as to the Central Government was , however, not appealed
before this Court. Pursuant to the directions given by the Division Bench in the aforesaid order, as
noted hereinabove, the State Government constituted a Committee known as "Krishnan Committee"
for examining and reporting the matters referred to in the order of the High Court. The Krishnan
Committee constituted by the State Government submitted its report. It was noted in the report that
some fundamentalist organizations opposed the establishment of the slaughter house on account of
their religious and sentimental opposition to the slaughter of animals, whereas the Central
Government and the Government of Andhra Pradesh permitted the setting up of this plant subject
to the conditions imposed by them. So far as the pollution of air and water was concerned, the
committee was of the opinion that if due observance of the safeguards stipulated by the several
concerned departments, including Pollution Control Board was made by regular supervision, such
pollution of air and water could be kept within a reasonable limit. So far as the depletion of the
cattle wealth is concerned, the Committee upheld the objections of the Food and Agriculture
Department in the following words:
"There are valid reasons for believing that this argument is substantially valid. To
start with the capacity of the plant is so large that with the existing cattle wealth and
possible increases thereto, will not be able to provide adequate input to this factory
for more than a year or two unless drastic action is taken to increase the cattle wealth
in the surrounding areas. The Food and Agriculture Department have already
brought out the fact that the cattle wealth in the surrounding areas as also in the
other parts of the State is gradually going down and the cattle available for slaughter
is around 1.76 lakhs animals per year. As against this, the existing slaughter houses in
the State are already slaughtering animals to the extent of 2.01 lakhs, with the result
that with the level of existing cattle wealth, there is no additional input likely to be
available to cater to the huge capacity of the plant being established at Rudraram.
Food and Agriculture Department has also brought out the fact that it will be difficult
for the factory to adhere to the existing regulations of the provisions of the
Prevention of Cruelty to Animals Act and Prohibition of Cow Slaughter Act, 1977 and
every effort would be made to circumvent the provisions of this Act so that adequate
input supply is maintained (for the?) factory. It was reported in the newspapers
sometime ago that a similar factory established in Goa, after operation for one or two
years had to drastically stop their operations for want of adequate input material."
After expressing the opinion, the Krishnan Committee made the following recommendation as a
condition for allowing the establishment of the slaughter house:
"In the circumstances it is essential to insist on the Company to ensure that there is
an effective programme to raise feed cattle on their own initiative for not less thanAkhil Bharat Goseva Sangh vs State Of A.P.& Ors on 29 March, 2006

50% of the capacity so that the impact on the surrounding area is limited to this
extent atleast. Further increases in capacity can be considered only if the company
increases its own feed cattle. Eventually the Company will have to produce feed cattle
for their entire extent of operations so as to minimise the impact on the existing
cattle wealth.
If this alternative is not acceptable to the Company, the proposal mentioned by the
Food and Agriculture Department of starting a modem abattoir with an investment of
about Rs. 15 crores may be directed to take over this plant and eventually the
unhygenic private slaughter houses in and around the city and government slaughter
houses can be closed and the meat requirement for the city may be met from this
factory."
We have carefully examined the Report of the Krishnan Committee and its recommendation for
allowing the establishment of the slaughter house. From a plain reading of the report and its
recommendation, it cannot be doubted that the Krishnan Committee was in favour of the
establishment of the slaughter house subject to the condition that it should raise its own cattle
required by it - initially to the extent of half and ultimately to the full extent. The committee also
opined that if the company was not willing to or not in a position to raise its own cattle then the
company may not to be allowed to run or its capacity may be utilised to meet the existing
requirement by diverting the cattle from the existing slaughter houses. From this recommendation,
it may be said that the existing slaughter houses, big and small, government and private, were to be
closed down and the slaughter house of the company would be utilised to meet the present domestic
requirements. It also appears from the record that before forwarding this report to the Central
Government, the Chief Secretary to the Government of Andhra Pradesh appended a Reference note
which may not be required to be noted for our present purpose.
The report of the Krishnan committee was forwarded to the Central Government. The Central
Government in its turn forwarded the report to the A.P.P.C.B. for appropriate action. However, no
order was passed by the Central Government on the said report at all, although, the Central
Government was a party to the order of the High Court, as noted herein earlier. That apart, the High
Court also in its judgment as noted herein earlier, made certain directions to the Central
Government to pass an order after considering the report.
A Writ Petition being W.P.No. 6704 of 1991 was filed by two environmentalists for issuance of a
writ, restraining the Hyderabad Metropolitan Water Supply and Sewerage Board and others from
supplying/selling water to the slaughter house of the company. An interim order was passed by the
High Court on May 27, 1992 to the effect that the Hyderabad Metropolitan Water Supply and
Sewerage Board and others be restrained from considering the proposals for sale of water to the
company.
Dr. Kishan Rao appellant in Civil Appeal No. 3966 of 1994 along with Ahimsa Trust filed a Writ
Application being Writ Petition No. 8193 of 1992. In this writ petition an interim order was passed
to the effect that the NOC granted by the APPCB shall be subject to further orders in the writAkhil Bharat Goseva Sangh vs State Of A.P.& Ors on 29 March, 2006

application.
Akhil Bharat Goseva Sangh which is appellant in Civil Appeal No. 3968 of 1994 filed a Writ
Application No. 10454 of 1992 questioning the grant of permission for trial run of the slaughter
house of the company.
A Writ Application being Writ Petition No. 13062 of 1992 was filed by Dr. Kishan Rao along with
one Smt. Satyavani questioning the permissions granted for the establishment of the slaughter
house of the company. As noted hereinearlier, Writ Petition No. 8193/1992 was filed by Dr. Kishan
Rao praying for similar reliefs which were prayed by him in Writ Petition No. 13062/1992. The
Division Bench in the judgment under appeal had taken a serious objection to the filing of two Writ
Petitions by Dr. Kishan Rao for similar reliefs and observed that there was mis-statement on the
part of Dr. Kishan Rao saying that relief claimed in Writ Petition No. 13062/1992 and reliefs
claimed in Writ Petition No. 8193/1992 were different. All these writ petitions were heard together
and disposed of by the High Court by common judgment dated April 6, 1993. In the aforesaid
judgment, the High Court in substance observed as follows:
(1) As the LOI granted by the Central Government and the provisions of the Andhra
Pradesh Preservation of Cow Slaughter and Animal Preservation Act, 1977 permits
slaughtering of only useless cattle and in view of the fact that maintenance of such
useless cattle involves a wasteful drain on the nation's meager cattle feed resources,
the Government of Andhra Pradesh and the Central Government were fully justified
in granting permission for establishing and running the slaughter house.
(2) In view of the agitations by some organizations the matter was re-examined and
fresh discussions were made by different concerned departments of the State. On the
question of slaughter policy of the State and on re-examination of the issues involved,
the Director of Animal Husbandry observed on 21st December, 1990 that the
establishment of slaughter house would not really result in any depletion of cattle in
the State.
(3) On 28.9.1991 the issue was again considered by the Director of Animal
Husbandry, who reiterated his opinion expressed on 21.12.1990 which was also
approved by the Andhra Pradesh Cabinet.
In view of the aforesaid finding made by the Division Bench it was found by it that the establishment
of slaughter house of the company would have only "negligible effect" on rate cattle growth in the
State.
(4) So far as the environment aspects were concerned, Division Bench found that the safeguards
stipulated by APPCB and other authorities of the State were sufficient to ensure control of air and
water pollution.Akhil Bharat Goseva Sangh vs State Of A.P.& Ors on 29 March, 2006

Accordingly, the Division Bench was of the opinion that all the concerned authorities of the State
having granted requisite permissions after duly considering all the relevant facts and circumstances,
there was no ground for intervening with the establishment and operation of the slaughter house. In
the said judgment while dismissing the writ petitions, the Division Bench also directed prosecution
of Dr.Kishan Rao for his mis-statement that he had not filed any other writ petition seeking similar
reliefs.
We may restate that writ petition No.10454 of 1992 filed by Akhil Bharat Goseva Sangh was also
disposed of by the Division Bench on the same day. In Writ Petition No.10454 of 1992 the main
contention of the petitioner was that the State Government had not complied with the directions
made by the High Court in its judgment and order dated 16.11.1991 and in the said Writ Petition it
was prayed that until and unless the State Government sent its report, in accordance with the
direction of the Division Bench of the High Court, to the Central Government and the latter had
taken decision thereon, the company be restrained from functioning. On this issue, the Division
Bench held that this question was already dealt with in the judgment and therefore in this writ
application there was no need to deal with it all over again. C.A.No.3968 of 1994 was preferred
against this judgment in this Court.
C.A.Nos. 3966, 3967 and 3968 of 1994 have been preferred against the judgment of the Division
Bench of the A.P.High Court delivered on 6th April, 1993. The appellant in C.A.No.3966 of 1994 is
Dr.Kishan Rao, the appellant in C.A.No.3967 of 1994 is Smt.Satyavani whereas the appellant in
C.A.No.3968 of 1994 is Akhil Bharat Goseva Sangh.
Civil Appeal Nos. 3964-3965 of 1994 have been directed against the order of another Division Bench
allowing the writ appeal preferred by the company under Clause 15 of the Letters Patent and setting
aside the interlocutory order passed by a learned Single Judge in W.P.M.P. No.9367/1993 arising
out of W.P. No. 7483/1993. In this way the five appeals against the judgments of the High Court of
Andhra Pradesh were placed before us for final disposal which were heard in presence of the learned
counsel for the parties.
By an order dated 25th October 1994 passed in C.A. No.3968/1994 with C.A. Nos.3964-3967/1994
(Akhil Bharat Goseva Sangh vs. State of A.P. and Ors.) reported in [(1995) Suppl.(1) SCC 370], the
report of the Krishnan Committee was taken into consideration by a Division Bench of this Court
which made the following observations:
"We are of the opinion that the rejection of Krishnan Committee report in the above
manner really amounts to slurring over the main recommendation of the said report.
Moreover, the learned Judges have not dealt with the failure of the Central
Government to consider the said report and pass appropriate orders pursuant to the
directions of the High Court in its judgment dated November 16, 1991. The learned
Judges have observed in the said judgment that it is not possible for the Court to go
into conflicting reports of experts and that, therefore, they should leave the matter for
the judgment of the Government. This observation again does not take into account
the directions made by the said High Court in its judgment referred to above. TheyAkhil Bharat Goseva Sangh vs State Of A.P.& Ors on 29 March, 2006

have also observed that the Director of Animal Husbandry has given his opinion or
revised opinion, as the case may be, after taking into consideration the objections of
the Food and Agriculture department. Though no material has been brought to our
notice in support of the said statement, we shall assume that it is so. Even then the
fact remains that this reconsideration by Director, Animal Husbandry department is
said to have taken place sometime in 1990, whereas even in 1992, the Food and
Agriculture department was yet protesting with its views before the Krishnan
Committee. Above all, the said reconsideration by the Director, Animal Husbandry
department far prior to the judgment of the High Court dated November 16, 1991
does not relieve the Central Government of the obligation to consider the Krishnan
Committee report and pass appropriate orders in the matter as directed by the
judgment of the High Court dated November 16, 1991. It was for the Central
Government to consider the said report taking into consideration the several facts
and circumstances mentioned therein as also the contending views expressed by the
several authorities and departments referred to therein. This, the Central
Government has clearly failed to do.
There is another relevant consideration. The slaughter house has been in operation
for the past eighteen months or so. It would be possible to find out the effect, if any of
the operation of the slaughter house had on the cattle population of Medak and
adjacent and nearby districts. It would equally be relevant to ascertain, if possible,
what percentage of cattle slaughtered have been brought from other States and what
percentage from the surrounding areas. In this connection, it is relevant to mention
that the Animal Husbandry department has taken the total cattle population of the
Andhra Pradesh State which is indeed misleading. The slaughter house is situated on
the western border of Andhra Pradesh State, almost on the trijunction of Andhra
Pradesh, Maharashtra and Karnataka. In such a situation, the slaughter house would
rather draw its requirements of cattle from the surrounding and nearby districts
rather than go all the way to far away districts of Andhra Pradesh State like
Srikakulam, Visakhapatnam or for that matter, Nellore and Anantapur, which are
situated several hundreds of miles away. The transport of cattle over long distance
may induce the slaughter house to go in for cattle in the nearby areas, whether in
Andhra Pradesh, Maharashtra or Karnataka - unless, of course, the cattle are
available at far cheaper rates at distant places, which together with transport charges
would make it more economic for the slaughter house to bring cattle from far away
districts or from far away areas in the country. Therefore, taking the entire cattle
population of the Andhra Pradesh State is bound to convey an incorrect picture.
Perhaps, it would be more appropriate to take into consideration the cattle
population of, what the Krishnan Committee calls, the "hinterland" of the slaughter
house.
In view of the fact that the controversy relating to the establishment of the slaughter
house has been going on over the last several years, we think it appropriate that the
Central Government should look into all relevant aspects, as directed by the HighAkhil Bharat Goseva Sangh vs State Of A.P.& Ors on 29 March, 2006

Court of Andhra Pradesh in its judgment dated November 16, 1991, forthwith and
record its opinion before we take a final decision in the matter. The decision of the
Central Government shall be recorded in a reasoned proceeding, which, shall be
placed before this Court. The further orders to be passed would depend upon the
contents of the report and the material so placed before us.
We may make it clear that we should not be understood to have expressed any
opinion on the merits of the aspects which the Central Government has been directed
to consider by the Andhra Pradesh High Court. Whatever we have said in this
judgment is only to indicate the failure of the Central Government to abide by the
said directions and to record reasons in support of the direction made herein. We
have also not gone into the other questions raised by the learned counsel for the
appellants. They can be considered at a later stage after the receipt of the material
and the report from the Central Government." ( Emphasis supplied) From the above
noted observations of this Court in the appeals, we find that the propriety of the
Krishnan Committee report could be considered after the receipt of the material and
report from the Central Government. Therefore, it cannot be said that by the
aforesaid order of this Court at the intermediary stage this Court in fact rejected the
report of the Krishnan Committee. On the other hand, it was made clear that such a
report can be considered after submitting of the report of the Central Government in
compliance with the directions made by this Court, as noted herein earlier. In
compliance with the directions made by this Court in its order, a report was
submitted and a further order in continuance of the order dated 25th October 1994,
was also passed by this Court in the aforesaid appeals reported in Akhil Bharat
Goseva Sangh & Ors. Vs. State of A.P. & Ors. [1997 (3) SCC 707]. From this order, it
appears that the Central Government had constituted an inter-Ministerial committee
headed by the Joint Secretary, Ministry of Food Processing Industry and three other
Members. The committee in its report made the following conclusions and
suggestions:-
(i) With regard to the pollution of air and water the suggestions and
recommendations made by the Krishnan Committee as well as the expert opinion
contained in it were good and acceptable. The Government of India in the Ministry of
Environment and Forests have already accepted the same and the steps to implement
have already been taken. The Environment Audit Report along with the
Environmental Management Plan prepared by the Company were acceptable.
However, regular monitoring of pollution of air and water need to be continued by
the Company itself as well as periodic checking by the Andhra Pradesh State
Pollution Control Board. (Emphasis supplied)
(ii) The Krishnan Committee's assumption and apprehensions on depletion of cattle
due to establishment of M/s Al-Kabeer's slaughter house are not based on correct
scientific analysis and adequate reasoning, and therefore, are not acceptable. From
the facts and analysis it is obvious that amongst bovine animals, the project of M/s.Akhil Bharat Goseva Sangh vs State Of A.P.& Ors on 29 March, 2006

Al-Kabeer is to utilize only the unproductive buffaloes and not cow and its progeny.
In fact, adequate number of unproductive buffaloes were available for use in the slaughter house
and other slaughter houses in Andhra Pradesh.
(iii) The Krishnan Committee's suggestion of State Government taking over M/s Al-Kabeer
slaughter house for supply of meat for domestic requirement had gone contrary to the objective of
giving permission for setting up of abattoir by M/s. Al-Kabeer, as well as Government of India's
programme for increase of export of meat and meat products. There is, however, need for
modernizing the existing abattoirs in the State for which the State Government may take
appropriate steps separately.
(iv) The suggestion of Krishnan Committee of the Company undertaking effective programmes to
raise feed cattle for meeting 50% requirement of the abattoir was not practicable and therefore, not
acceptable. However, as per the terms of the licence, the Company should prepare a plan in
consultation with the State Government and take up its implementation in conjunction with the
State Government for promoting better animal husbandry practices.
Number of petitions were filed by the appellants in the appeals challenging the report and finally
this Court by its order dated 12th March 1997 (reported in 1997 (3) SCC 707 ) made the following
observations :
"There is good amount of substance in the submissions of the learned counsel for the
appellants. The statistics which constitute the basis of this Report submitted by the
Government of India are not really relevant to the issue before us. As rightly pointed
out by the learned counsel for the appellants, Al-Kabeer started functioning only in
April 1993 and the effects and impact of its functioning will be known only if one
studies the figures of availability and/or depletion of buffalo population over a period
of one or two years after Al- Kabeer has started functioning. Merely showing that
there has been a marginal increase in buffalo population between 1987 and 1993 is
neither here nor there. Even if it is assumed that the 1993 figures refer to the figures
up to September-October 1993, that will take only six months of working of Al-
Kabeer. The proper impact of working of Al-Kabeer on the depletion of cattle, if any,
would be known only if one takes into consideration the census figures of cattle in
Telangana region or in the areas contiguous to Medak District ( where the said unit is
located), as the case may be, after at least two years of working of Al-Kabeer. In short,
the position obtaining after April 1995 would alone give a correct picture. We cannot
also reject the contention of the learned counsel for the appellants that the
Government of India's Report is influenced to a considerable extent by the Report of
Shri Yogi Reddy, the then Director of Animal Husbandry, Government of Andhra
Pradesh, whose Report has been termed as "unauthorized" by the Special Secretary to
the Government of Andhra Pradesh and thus disowned by the Government. Even
according to the Government of India's Report, the requirement of Al-Kabeer is 1.5 to
2.0 lakh buffaloes every year, which is not an insubstantial figure. We must also takeAkhil Bharat Goseva Sangh vs State Of A.P.& Ors on 29 March, 2006

into consideration what the appellants' counsel call the inherent contradiction
between the standard and quality of beef required for export and the provisions of the
Andhra Pradesh Prohibition of Cow Slaughter and Animal Preservation Act, 1977 and
the effect of the decisions of this Court, which leave only old and infirm buffaloes for
slaughter. We, therefore, think it appropriate that the Government of India should be
called upon to send a fresh report after studying the impact and effect of the working
of Al-Kabeer upon the buffalo population of the Telangana region of Andhra Pradesh
and also of the areas adjacent to Al- Kabeer, two years after the commencement of
the operations by Al-Kabeer. It is not possible for us to pass any final orders on the
basis of the Report now submitted, which as stated above, is based upon the
statistics/census figures of cattle population including buffalo population for the
period 1987 to 1993.
Accordingly, we call upon the Central Government to submit a fresh report in the
light of the observations made herein within six months."
In the aforesaid order, an interim order was passed saying that with effect from 1st April 1997 the
company shall function at half of the installed capacity and not its full installed capacity and the
appeals were directed to be listed after 6 months.
Pursuant to the order of this Court in the year 1997, a report was filed by the Central Government.
In the direction made by this Court in 1997, this Court observed that the data starting from two
years after the functioning of the Al-Kabeer abattoir (company ) would give the correct picture of its
effect on live stock population in the surrounding areas and directed the Central Government to file
the same. In the report filed by the Central Government data has been analysed through a
comparison between a four year period immediately preceding the operation of the abattoir and four
year period immediately after the functioning of the abattoir i.e. data between 1989-90 to 1992-93
was compared with data between 1993-94 to 1996-97. The data was compared by averaging the
population of four year blocks before and after working of the abattoir.
After making the comparison, the following has been reported:
(1) It is young stock and females over 3 years that had contributed to the sustenance
of buffalo population. The increase in female and young stock clearly indicates that
the functioning of the Al-Kabeer Abattoir has not resulted in depletion of buffalo
population in Telangana region. There exists adequate potential of buffalo population
in these areas to sustain the demand from different sources for the buffaloes
including that of Al-Kabeer abattoir. (2) Increases in buffalo population, especially in
the latest year i.e. 1996-97, do not substantiate any consistent decline in buffalo
population as a result of functioning of the Al-Kabeer abattoir (company).
(3) Though there is a decrease in cattle population, that may not be related to the
functioning of the Al-Kabeer, as beef from cattle is banned from export.Akhil Bharat Goseva Sangh vs State Of A.P.& Ors on 29 March, 2006

Subsequently, in the year 1999 census data on cattle population of Andhra Pradesh namely 16th live
stock census was submitted before this Court. As per the live stock census conducted, the total live
stock population in the Andhra Pradesh State was calculated at 357.87 lakhs in 1999 with an
increase of 8.7% over that of 1993 census. This increase was stated to be mainly due to the
significant increase in bovine population to the extent of 22%.
On behalf of the appellants, the first question that was raised and not decided by this Court in its
earlier orders but kept to be decided at the final stage of the appeals, was whether Al-Kabeer Unit
(company) has been established in violation of location requirement, as mentioned in the LOI of the
Central Government for issuance of industrial licence to it. According to the appellants, since the
location of Al-Kabeer is in violation of location requirement, as mentioned in the LOI of the Central
Government and also the prohibition zone imposed by the State Government, and as Al-Kabeer
(Company) is located within 13 K.M. from the urban limit of Hyderabad city, it must be held that
Al-Kabeer (Company) must close down its abattoir. It was also urged that the Andhra Pradesh
Government, having issued a General Order banning location of industries in Medak District, where
the unit of the Company was located, had wrongly issued permission to the company to run its
abattoir and in that view of the matter the company must be directed to shut down its abattoir and
the licence issued to it must be cancelled. This submission was hotly contested by the learned
counsel appearing for Al-Kabeer (Company). We have carefully examined the submissions of the
learned counsel for the parties and also perused the records and the findings of the High Court
regarding location requirement, as indicated in the LOI of the Central Government and the General
Order of the State Government. In our view, this submission of the appellants, at this stage, cannot
be accepted. At the outset, we may say that this question was not seriously argued by the learned
counsel of the appellants before us, although in the written submissions filed by them, this question
was tentatively raised. Since a submission was made on this account, we feel it appropriate to deal
with this question. Before we deal with this question in detail, we may note that for the first time in
this Court the appellants have alleged the fact that the Al-Kabeer unit (company) is located within 13
km. from the standard urban limits of the city of Hyderabad which falls within the prohibited zone.
Even assuming, distance prohibition would be applicable to the case of Al-Kabeer (company), we are
still of the view that this distance prohibition may not stand in the way of Al-Kabeer from getting an
industrial licence for the purpose of setting up the abattoir at the site in question. It is an admitted
fact that in the application for grant of licence, Al-Kabeer (the Company), had stated the exact
location where they were going to set up the abattoir, that is to say in Rudraram Village in the
District of Medak of the State of Andhra Pradesh. When this application was processed by the
Central Government, a thorough enquiry must have been made by it and only thereafter industrial
licence was issued to the Company. It is true that before issuance of licence, LOI was issued by the
Central Government only wherein, this location requirement was stated in a printed form. It is an
admitted position that the Central Government did not make any query from the company about the
distance between Rudraram Village, where the site is located, and the urban limits of the city of
Hyderabad.
On a bare perusal of Section 11 of the IDR Act, it is evident that no person or authority shall, after
the commencement of the Act, establish any industrial undertaking except in accordance with theAkhil Bharat Goseva Sangh vs State Of A.P.& Ors on 29 March, 2006

licence issued in that behalf by the Central Government. That is to say, an embargo has been
imposed on any person or authority to establish any new industrial undertaking before obtaining a
licence from the Central Government. Subsection 2 of section 11 however says that a licence or a
permission under Sub-section 1 to establish a new industrial undertaking may contain such
conditions including condition as to the location of the undertaking as the Central Government may
deem fit to impose in accordance with the Rules. This subsection 2 of Section 11 empowers the
Central Government to impose conditions on the person or the authority as to the location of the
undertaking. In our view, subsection 2 of Section 11 of the Act by which conditions can be imposed
as to the location of the undertaking by the Central Government is only directory and it would be
open to the Central Government to issue licence without giving any conditions to the company as to
the location of the undertaking. It is significant to note that the legislature in sub-section 2 of
Section 11 has used the word 'may'.
By issuing the Industrial licence to the Company, even after knowing the proposed location of the
unit, it must be said that the Central Government waived the location requirements, as mentioned in
its LOI with regard to this unit.
Economic liberalization was made by the Central Govt. on 25th of July, 1991 and following the said
policy, the Government of Andhra Pradesh also issued a Notification on 3rd February 1992 which
was issued as a follow up action of the Notification of the Central Government dated 25th July 1991
under which permission/license was required for industries located within 25 km from the
periphery of standard urban area. The Notification dated 3rd February 1992 of the State
Government specified areas which would fall within or outside 25 km. from the periphery of the
standard urban area in order to enable the entrepreneurs to take appropriate action. According to
the appellants, the company is located within Rudraram village which is a prohibited zone from the
periphery of the city of Hyderabad and therefore the company, in terms of the Industrial policy of
the State Government, was not entitled to get an industrial licence to run the slaughter house.
Clause (2) of Paragraph 3 of the Notification specified the list of villages falling within the prohibited
zone for which, location approval from the Central Government would be necessary except for
non-polluting industries such as electronics, computer software and printing industries. In the
present case, the activity of the company does not fall in the category of non-polluting industries.
However, this notification contains two lists. One list is A and the other is B. List A specified all the
villages within the standard urban area of Hyderabad. Patancheru which falls within Medak District
and is within the computation of 25 km. from the periphery of the standard urban area of
Hyderabad falls under list B. Therefore, in terms of the distance there was requirement of obtaining
an industrial licence by virtue of the Notification dated 3rd February 1992 of the State Government.
In view of the admitted fact that industrial licence was granted by the Central Govt. on 11.11.1992
and permission to run the slaughter house was also granted by the State Government on the basis of
the Industrial policy of the State Govt. of 3rd February, 1992, we are unable to hold that distance
prohibition could be considered to be a ground either for cancellation of the industrial licence or for
closing down the unit.
Apart from that, we may keep it in mind that in pursuance of the LOI granted by the Central
Government and the various permissions granted by the State Government and other authorities,Akhil Bharat Goseva Sangh vs State Of A.P.& Ors on 29 March, 2006

the company commenced construction of its factory in 1989. It should also keep in mind that before
commencing its construction the following permissions/No Objection Certificates were taken by the
Company:
(a) No Objection Certificate for site clearance from APPCB.
(b) No Objection Certificate from the Director of Animal Husbandry, A.P.
(c) Letter of Intent from Ministry of Industry, Govt. of India.
(d) Two NOCs. from the Gram Panchayat to locate the factory as well as commence
construction.
(e) Permission from Medical and Health Department, A.P.
(f) Permission from the Director of Town and Country Planning.
(g) Permission from Director of Industries, A.P.
(h) NOCs. from National Airport Authority, Hyderabad and Madras.
(i) NOC from AIR Headquarters, New Delhi.
It also appears from the record that the Industrial licence was granted by the Central Government
on the strong recommendation of the State Government. The unit commenced production in April
1993 after dismissal of a batch of Writ Petitions challenging the permissions granted by various
authorities to commence production including that of the APPCB. The unit achieved its full
production in December 1993 and since then it is earning valuable and substantial foreign exchange
for our country. Above all, the question on location, as noted herein earlier, was neither raised
seriously before the High Court nor before us. It must also be noted that, in this regard various State
authorities had granted permissions for the abattoir to be constructed and function at the selected
site and production has been continuing for the last 10 to 15 years. That apart, the question on
location requirement is always a question of fact which cannot be permitted to be raised at this stage
before us. However, we keep it open to the Central Government and the State Government to
consider the distance prohibition as indicated in the LOI and the Notification and General Order of
the State Government for the purpose of shifting the site to some other alternative place which
would satisfy the location conditions. Subject to the above, this question is answered in favour of the
Al-Kabeer (company).
The next question that was urged by the learned counsel for the appellant before us which needs to
be decided is whether Al-Kabeer (company) operates in violation of Environmental Acts and Rules.
According to the appellants, no study has been made of the prevailing environment and the impact
of Al-Kabeer on it. Therefore, it was contended that the precautionary principle has been ignored by
the authority before granting permission to Al-Kabeer to run the slaughter house.Akhil Bharat Goseva Sangh vs State Of A.P.& Ors on 29 March, 2006

The learned counsel appearing on behalf of Satyavani in C.A. No. 3967 of 1994 contended that
APPCB by its consent order dated 21st December 1993 allowed limit for B.O.D. of 100 mg/Lit.
whereas the maximum permissible limit specified in the Environment Protection Rules, 1986 was
30 mg./Lit (Rule 3, Schedule 1, Entry 50B). According to the learned counsel appearing for
Satyavani the limit for suspended solids allowed by APPCB of 100 mg/Lit was in excess of limit of 50
mg/Lit. allowed in Rule 3, Schedule 1, Entry 50B of the Environment Protection Rules, 1986.
Therefore, it was contended that the consent of APPCB was in violation of the Act and Rules, and
accordingly it must be quashed. It was also contended on behalf of Satyavani that since the samples
collected on 6th August 1994 from Al- Kabeer show that its B.O.D. in fact reached 150 mg/Lit. which
was much beyond the permitted limit of 30 mg./Lit. and its suspended solid discharge was recorded
at 140 mg/Lit. which was much beyond the permitted 50 mg./Lit., the question of giving consent to
Al-Kabeer by the authorities could not arise at all as it had clearly violated the maximum permissible
limit specified in the Environment Protection Rules, 1986. Accordingly, permission granted should
be withdrawn. These submissions were strongly disputed by the learned counsel for Al-Kabeer
(company).
From a careful consideration of the rival submissions of the parties on the question of
environmental pollution, we find that this question was not seriously argued by the appellants
during the course of hearing that the company had violated the norms under Environment
Protection Rules, 1986. Thus we may not permit the appellant to raise this question before us.
However, as environmental pollution has now become a public nuisance, we thought it fit to go into
this question and decide the same.
We have carefully examined the rival submissions made before us by the learned counsel for the
parties on the aforesaid question. From the record it appears that the recommendations regarding
environment made by Krishnan Committee so far as the abattoir is concerned, were accepted by the
Central Government as would be evident from this Court's order dated 12th March, 1997. It also
appears from the record that Al-Kabeer Company had invested huge amount for installation of
elaborate anti-pollution equipment, and operates the same with consent obtained from APPCB. It is
true that the standards prescribed by APPCB for Al-Kabeer while issuing its consent for slaughtering
operation to begin, were indeed in violation of the Environment Protection Rules in so far as they
prescribe a lower standard than was mandated by the aforesaid Rules. Under Rule 3 of the Rules,
the State Boards are permitted to prescribe higher standards than those mentioned in the Rules but
are not permitted to lower the standard. Considering the fact that the permission to operate the
abattoir was granted by the APPCB, the State Government and also by various authorities of the
State 10 to 15 years back and considering the fact that Al-Kabeer had installed elaborate
anti-pollution equipment by investing huge amount, we are of the view that Al-Kabeer must be
directed to comply with the Environment Protection Rules by lowering down the pollution levels at
the abattoir to permissible limits, rather than to direct closure of the abattoir of the company. It also
appears that the samples which were collected by the Department of Water and Waste Water
Examination, Institute of Preventive Medicine, Narayanguda, Hyderabad from Al-Kabeer's abattoir
indicated violation of the standards prescribed under Environment Protection Rules. Though
Al-Kabeer has installed elaborate anti-pollution equipment, it would be of no consequence if such
equipment is in reality not bringing down the level of pollution below permissible limits. However, itAkhil Bharat Goseva Sangh vs State Of A.P.& Ors on 29 March, 2006

cannot be overlooked that Al-Kabeer is continuing its operation for more than 10 years without any
objection from the APPCB. Therefore, considering all the circumstances, we are of the view that
directly ordering closure of Al-Kabeer Abattoir is not called for; rather directions may be given to
APPCB to rectify its consent order in accordance with the Environment Protection Rules and also to
direct Al-Kabeer to strictly comply with that rectified consent order and Environment Protection
Rules. In the event abattoir fails to comply with such directions from the APPCB, it would be open to
the authorities to direct closure of the Al-Kabeer unit. We are taking this view keeping in mind that
the appellants had not seriously argued, during the course of hearing before this Court, that the
company had in fact violated the standards laid down in the Environment Protection Act and Rules.
It may also be noted that in the interim judgment dated 12.3.1997 reported in (1997) 3 SCC 707, this
Court has noted the conclusions of the Central Government Committee in paragraph 2 wherein, it
has recorded that the Committee had accepted the suggestions and recommendations made by the
Krishnan Committee with regard to pollution of air and water. It has also been noted therein that
the Environmental Audit Report and the Environmental Management Firm Report along with the
Environmental Management Plan prepared by the company are acceptable. As already noted
hereinearlier, the company has installed elaborate anti-pollution equipment, imported as well as
indigenous. The company has been operating only after obtaining consent from APPCB which is
regularly renewed. Insofar as standards for discharge of effluents from slaughterhouse and meat
processing are concerned, the same is prescribed under Rule 3 read with entry 50-B of Schedule I of
the Environment Protection Rules, 1986. In this connection Entry 50-B (b) of Schedule 1 of
Environment Protection Rules 1986 is relevant as it prescribes the B.O.D., suspended solids & oil
and grease limits. At this juncture it is also to be noted that Ministry of Environment, Government
of India, by its letter dated 29th May 1995 fixed the standards for Al-Kabeer Exports Pvt. Ltd. at 100
B.O.D. and 30 B.O.D. for slaughterhouse and meat processing respectively. As Al- Kabeer has been
operating on the basis of the norms specified by the Central Government and considering the fact
that Al-Kabeer unit has been operating for more than 10 years without any objection form APPCB
and keeping in mind the economic policy of the Central Government, we are of the view that
Al-Kabeer may not be, at this stage, directed to stop their operation and close the unit. In view of our
discussion made hereinbefore, and as APPCB reserves the right to take action against Al-Kabeer for
violation of the terms and conditions imposed in its permission, it would be open for APPCB to
direct Al- Kabeer to rectify the level of pollution below prescribed limits and in the event that it is
not done they may direct Al-Kabeer to close down its abattoir. As noted hereinbefore, it is of course
true that the prescribed limit of pollution by APPCB was in violation of the Environment Protection
Rules, therefore in our view, directions must be given to APPCB to rectify its consent order and
directions be given by them to the abattoir to comply with that rectified consent order in accordance
with Rule 3 of the Environment Protection Rules.
In this connection, two further questions had arisen in relation to compliance with environment
standards maintained by Al-Kabeer, which were raised by the appellant Shri Tukkoji, in C.A. Nos.
3964-65 of 1994.
The first question is whether the consent order of the APPCB was vitiated because the reports of the
analysts were not made available to Shri Tukkoji prior to the issuance of NOC. Learned counselAkhil Bharat Goseva Sangh vs State Of A.P.& Ors on 29 March, 2006

appearing for Shri Tukkoji contended that the consent order was in derogation of the right of Shri
Tukkoji to information in violation of Article 19(1)(a) of the Constitution. According to Shri Tukkoji,
he was not only entitled to receive the reports of the analysts relating to the effects of the functioning
of the abattoir but also to file objections prior to the issuance of N.O.C. This contention was accepted
by the learned Single Judge of the High Court but was rejected by the Division Bench. The Division
Bench in the impugned judgment observed as follows-
" On a prima facie view of the various provisions of the Water Act and the
corresponding provisions of the Air Act, in particular the provisions of sections 16, 17,
20 and 25 of the Water Act we are not inclined to hold at this stage that a third party
has any right to seek information or material from the State Board at or before
granting of consent by it under S. 25(3) of the Water Act. It is not as if aggrieved
party is left without a remedy. After consent is granted any third party who feels
aggrieved can make a complaint to the Court of a First Class Magistrate Apart from
that the State Board has ample powers to review its order granting consent by
modifying or revoking any existing condition"
( Emphasis supplied) We do not find any reason to disagree with this view of the Division Bench of
the High Court. In this connection, we examined Section 25 of the Water Act in depth and, in our
view, Section 25 of the Water Act does not confer any right on members of the public to demand
information from the APPCB prior to issuance of NOC. Therefore, it cannot be held, that the NOC
was vitiated by reason of non-disclosure of information to the appellant Tukkoji prior to its
issuance.
Thus, first question of Shri Tukkoji as argued by his learned counsel has no merit and it is hereby
rejected. The second question raised is whether the consent order was vitiated because the APPCB
was improperly constituted. It was contended on behalf of Shri Tukkoji that APPCB was not validly
constituted and that the Chairman and Member Secretary of APPCB did not possess the
qualifications required under the Water Act, and accordingly the Board as constituted was not
competent to issue consent order. In order to answer this question it would be beneficial if we
reproduce the relevant findings of the Division Bench which run as under :-
"We are not unaware of the contention of counsel for the petitioners that the
Pollution Control Board did not really consist of scientific experts, and that in that
sense, issue of No Objection Certificate by that body may not be considered as a
result of informed expert opinion. That brush can as well paint the opinion of Shri
H.K. Babu, Secretary, Food and Agriculture, as also that of Shri R.V. Krishnan,
Secretary, Energy, Forest, Environment, Science and Technology in the same hues.
We are informed that some, at least, of the members of the Pollution Control Board
was renowned scientists"
It is true that Section 4(2)(a) of the Water Act requires the Chairman of the APPCB to be 'a person
having special knowledge or practical experience in respect of matters relating to environmental
protection or a person having knowledge and experience in administering institutions dealing withAkhil Bharat Goseva Sangh vs State Of A.P.& Ors on 29 March, 2006

matters aforesaid, to be nominated by the State Government'.
Section 4(2)(f) of the Act requires the Member Secretary to possess "qualifications, knowledge and
experience of scientific, engineering or management aspects of pollution control."
From the record, it appears that at the relevant time the Chairman and the Member Secretary of the
APPCB did not possess these statutorily required qualifications. The observation of the High Court
in the judgment that some of the members of the APPCB were scientific experts, does not address
this specific breach of the statutory requirement. In this connection, we, however, need to look into
the provisions under Section 11 of the Water Act, which provides in terms that "No act or proceeding
of a Board or any committee thereof shall be called in question on the ground merely of the
existence of any vacancy in or any defect in the constitution of, the Board or such committee, as the
case may be." Therefore, applying Section 11 of the Act which clearly provides that no act or
proceeding of APPCB or any committee thereof shall be called in question, it can safely be concluded
that even if there was some defect in the composition of the APPCB, that would not invalidate the
consent order issued by it.
Let us now come back to the most important question that needs to be decided in these appeals,
which is about the issue of cattle depletion due to functioning of the Al-Kabeer abattoir. On this
question, the appellant in C.A. No.3966/1994 advanced the following submissions :-
(a) Since the Al-Kabeer project involves slaughtering of prohibited cattle, which can
be statistically shown to be inevitable, and is also evidenced on video the Govt. has a
constitutional duty under the second part of Art.48 of the Constitution to prevent
such slaughter as well as a duty to enforce the A.P. Preservation of Cow Slaughter and
Animal Preservation Act, 1977.
(b) The slaughter rate of Al-Kabeer exceeds the renewal rate as would be evident
from the reports submitted by the authorities before the High Court as well as before
this Court.
The appellant Satyavani in C.A. 3967/1994 made the following submissions:
a. The report of the Central Govt. submitted on 12.9.1997 was misleading, because it
had averaged, and then compared the figures for buffalo population in the four years
before and after Al-Kabeer was set up, which disguises the fact that a decline in
buffalo population had occurred subsequent to this setup. Further, the same persons
responsible for preparing the earlier Govt. report of 1994- which was held to be
misleading by this Court in its order dated 12.3.1997- were again involved in
preparation of this report. b. The abattoir stopped taking animals from its hinterland
subsequent to the Court's order of 12.3.1997, and instead began importing animals
from other States. Thus, the figures of 2003 Livestock Census are not relevant to the
issue at hand, and the effect of the abattoir on buffalo depletion can only be judged
on the basis of statistics of approximately two years after its commencement- asAkhil Bharat Goseva Sangh vs State Of A.P.& Ors on 29 March, 2006

observed by this Court in its order dated 25.10.1994. Further, the 2003 Census itself
shows a decrease in buffalo population in adjoining States of Karnataka and
Maharashtra, from 1999 to 2003- indicating the effect the abattoir has had, through
its importation of buffaloes from these States. Moreover, the figures in the 2003
Livestock Census show abnormal and unrealistic growth of cattle population in
districts of AP, which can not be accepted.
c. The subsequent report of the Central Govt. dated 23.12.2003 itself vindicates the
claim that cattle depletion has occurred due to Al-Kabeer's operations.
d. This depletion is not in relation to old and useless cattle, as Al-Kabeer necessarily
must slaughter useful animals, for export, as pointed out by the Krishnan Committee
Report. There are also no sufficient number of useless animals to meet its
requirement of 1.5 to 2 lakh buffaloes per year, as is evident from the figures of
successive census carried out by the Andhra Pradesh Directorate of Economics and
Statistics. Further, the monitoring of Al-Kabeer, for compliance with the Andhra
Pradesh Animal Preservation Act, is not effective, as reported by Dr. Jitendra Reddy,
Special Officer, Govt. of A.P. Such unrestricted slaughtering of useful animals will
worsen the already existing dung shortage in Andhra Pradesh.
The appellant Akhil Bharat Goseva Sangh in C.A. No. 3968/1994 made the following
submissions:
a) The Central Govt. report on buffalo population, as well as the 16th Quinquennial
census figures (1999) of the Bureau of Economics and Statistics contains gross
inconsistencies.
b) The census was not carried out comprehensively, nor does it provide figures as to
slaughter of buffaloes above 10 years, which are still useful.
c) The 17th Quinquennial census (2003) is only provisional in nature, and does not
categorize cattle based on age and use- hence it cannot be relied on by the Central
Government.
d) The census figures of 1999 and 2003 indicate growth rates which are inconsistent
with the extent of cattle slaughter.
e) Al-Kabeer cannot claim that it has a fundamental freedom to conduct a trade or
business which violates the Fundamental Duty in Article 51A(g) of the Constitution to
have compassion for living creatures, and is also destructive of the environment- this
follows from the rule of harmonious construction.
f) In any case, the freedom in Article 19(1)(g) of the Constitution cannot be permitted
to be exercised if it is not in the interests of the general public. The slaughter ofAkhil Bharat Goseva Sangh vs State Of A.P.& Ors on 29 March, 2006

livestock in response to export demand creates acute scarcity of animals which will
increase prices of milk, ghee, meat and other products.
Further, such export-oriented slaughter-houses induce owners of animals to sell them despite their
utility as milch or draught cattle. Depletion of cattle wealth also leads to loss of benefits from dung
output of cattle, which is its most useful contribution. The Al- Kabeer project also leads to a net loss
of employment, as more than one lakh persons are employed in activities in relation to cattle,
besides depriving the nation of the benefits of live cattle. These effects constitute violation of Art. 21
of the Constitution.
(g) The Al-Kabeer project is operating in violation of various State animal preservation laws, as it
has stated that it imports 70 percent of its buffalo requirement from other States, as well as the
Prevention of Cruelty to Animals Act, 1960.
h) Al-Kabeer cannot rely on the 1958 Quareshi's judgment, as that case concerned the rights of
individual butchers, not businesses setup to earn profits from export. Moreover, the crux of that
judgment, striking down the total ban on slaughter of old cattle, was scarcity of fodder resources-
which no longer exists. Finally, the concept of 'usefulness' of cattle was placed before the Court in
1958 in only a narrow sense (milk, breeding and draught services) and the utility of dung was not
considered.
All these submissions of the appellants, as noted hereinbefore, were contested by Al-Kabeer in
C.A.No.3967 of 1994 and made the following reply : -
a. The appellants had relied on a Central Govt. report dated 23.12.2003, which is
based on 1999 census figures, to prove cattle depletion. But in fact, this report
indicates increase in buffalo population in Andhra Pradesh, despite operation of the
Al- Kabeer project.
b. There are sufficient number of useless buffaloes to meet Al- Kabeer's capacity, if
figures over a year, and not simply a given day, are taken into account. In one year, 9.
4 lakh useless buffaloes are available in Andhra Pradesh, much more than the
requirement of Al-Kabeer.
c. The appellants had mistakenly inferred that useful buffaloes are being slaughtered
by Al-Kabeer but the report shows that, since milk production has increased along
with meat export, therefore young and productive animals are not being slaughtered.
Further Al-Kabeer in C.A. No. 3968/1994 made the following reply :-
a. The compliance by Al-Kabeer with the Andhra Pradesh Animal Preservation Act is
monitored by the officials deputed by the Director, Animal Husbandry.Akhil Bharat Goseva Sangh vs State Of A.P.& Ors on 29 March, 2006

b. The report of the Expert Committee of the Central Govt. filed on 15.9.1997,
pursuant to the order of this Court dated 12.3.1997, concluded that there would be no
depletion effect on livestock in Andhra Pradesh, as a result of continuance of
Al-Kabeer in full capacity. The method used in the report of relying on cattle
population figures in block periods of four years before and after commencement of
operations of Al-Kabeer was justified. The 16th and 17th Quinquennial Census figures
also indicate that there has been an increase in the buffalo population in Telangana
region, not a decline. Although reports have been challenged by the appellant, but it
has now become a settled law that the findings made in such reports are not open to
challenge unless it is shown that such findings are perverse, arbitrary and any
prudent person cannot reach to such findings.
The respondent APEDA (Agricultural and Processed Food Exports Development Authority) in C.A.
No. 3968/1994 supported the case of abattoir and in support thereof made the following
submissions :
a. The appellants had not even made the case that Al-Kabeer is violating any of the
conditions imposed on it for slaughter of buffalo.
b. The claim of the appellants that cattle population is declining on account of Al-
Kabeer's operation is based on a wrong approach, because the issue is not whether
the total population is decreasing or not, but whether the population of healthy
livestock is decreasing. The census figures confirm that there has been no such
depletion due to Al-Kabeer's operation.
As noted hereinearlier, we have not only carefully examined the Krishnan Committee
report but also the other reports submitted by the Central Government in pursuance
of the directions made by this Court in its earlier orders in 1994 and 1997. On cattle
depletion the Krishnan Committee noted that the operation of Al-Kabeer would
adversely affect the cattle population in and around the region unless 50% of the
demand of the abattoir was met through breeding of cattle by Al-Kabeer itself. Before
we go into this question we may note that the A.P. Act was enacted in the year 1977
(Act 11 of 1977). By this Act, the Legislature has regulated the slaughter of all bovine
animals including buffaloes. Under section 6(1) no animal is allowed to be
slaughtered unless a certificate in writing from the competent authority is obtained
certifying that the animal is fit for slaughter. Sub-section (2) of Section 6 of the Act
prohibits slaughtering of animals unless the competent authority grants a certificate
in respect of an animal that it is not likely to become economical for the purpose of
breeding, milching or draught. After carefully reading the conditions for obtaining a
permission from the competent authority to slaughter an animal, we find that
slaughtering an animal requires the following:
(a) Only old and useless buffaloes can be slaughtered.Akhil Bharat Goseva Sangh vs State Of A.P.& Ors on 29 March, 2006

(b) Buffaloes fit for milching, breeding or draught cannot be slaughtered.
(c) Cow and its progeny including calves of cows and calves of buffaloes cannot be
slaughtered.
In order to see whether those conditions are fulfilled by Al-Kabeer, the Director, Animal Husbandry
of State of Andhra Pradesh has deputed necessary officials of the rank of Veterinary Asstt. Surgeons
to the plant of the company to monitor and undertake anti-mortem and post-mortem examinations
and to implement the provisions of the Act. As noted hereinearlier, in the interim direction made by
this Court in these appeals on 12th March 1997 ( 1997 (3) SCC 707 ), this Court directed the Central
Govt. to give a report after studying the impact and effect of the working of Al-Kabeer upon the
buffalo population of the Telangana Region of Andhra Pradesh and also of the areas adjacent to
Al-Kabeer, two years after the commencement of the operations by Al- Kabeer. The Central
Government in pursuance of the said direction made on 12th March 1997 filed a fresh report on 15th
September 1997. From a reading of the said report, it appears to us that the expert committee of the
Central Govt. had examined all issues, as directed by this Court in its judgment dated 12th March
1997. This considered opinion in the said report is as under:
"on the examination of all observations mentioned in the judgment dated 12.3.1997
the committee is of the opinion that there would not be any depletion effect on live
stock population particularly buffaloe, sheep and goat in Medak and contiguous
districts, Telangana region or in the State of Andhra Pradesh as a result of
continuance of Al-Kabeer at the full capacity utilization."
(Emphasis supplied).
In support of this report the State Govt. also filed an affidavit on 15th November 1997 (See page 17 of
the counter affidavit of Al-Kabeer Exports to I.A. No.10-14/1997) wherein the State Government
noted that the report of the Central Govt. was based on the relevant data and the conclusions
reached by the expert committee in its report were not improper. In paragraph 20 of the said
affidavit, it has been stated that the State Govt. had deputed five veterinary Asstt. Surgeons to
supervise the slaughtering work at the site of Al-Kabeer and only thereafter the State Govt. issued
anti-mortem and post-mortem certificates. From the record, it is also evident that the Central Govt.
had filed yet another report prepared by an Expert committee along with an affidavit dated 6th July
1998 . This affidavit and report were filed pursuant to the order passed by this Court on 13th April
1998 directing the Central Govt. and the state of Andhra Pradesh to file affidavits not only
responding to the appellant's application for modification but also with regard to the cattle
population of Andhra Pradesh in general and Telangana zone in particular. The report states as
follows:
"The increase is much higher in Telangana region as compared to Andhra &
Rayalaseema during the four year period of Al-Kabeer working and this has clearly
indicated that Al-Kabeer working has no adverse impact on the buffalo population in
Telangana region on in Medal area where the abattoir is located."Akhil Bharat Goseva Sangh vs State Of A.P.& Ors on 29 March, 2006

The detailed report at yet another place states:
"A comparison of the estimated population of buffaloes in milk during the four year
period before working of Al-Kabeer abattoir and after working of Al-Kabeer abattoir
indicates that similar to milch buffaloes, population of buffaloes in milk also
increased during the four year period after working of Al-Kabeer abattoir. The
increase is 23.40 percent in Medak and contiguous districts, 24.33 percent in
Telangana and 17.17 percent in Andhra & Rayalaseema. An overall increase of 19.61
percent in the Andhra Pradesh State is observed. This clearly indicates that
productive buffaloes are not slaughtered in Al-Kabeer abattoir as stated by the
appellant and there would not be depletion of buffalo population as a result of
Al-Kabeer functioning."
In conclusion the report states:
From the above it could be inferred that Al- Kabeer working at full capacity does not
result in buffalo population either in any area of Andhra Pradesh or in the
country"
( Emphasis supplied ) On behalf of the appellant, it was argued that in the Central
Govt. report figures/statistics were misleading inasmuch as it had taken an average of
four years before the commencement of operations of Al- Kabeer and again of four
year figures after the commencement of operations by Al-Kabeer. According to the
appellants, the correct way was to see the figures immediately preceding the start of
operations by Al-Kabeer and thereafter to see the figures two years after
commencement of operation of Al-Kabeer. In our view, this submission is fallacious
and cannot be accepted. The committee of the Central Govt. has correctly taken the
figures of a block period of four years before commencement of operations and again
figures of a block period of four years after commencement of operations by
Al-Kabeer. This is in view of the fact that statistics/figures of one particular year
cannot represent or give a proper picture as the number of animals/buffaloes/cattle
can very well vary due to natural calamities large scale migration in view of
urbanization etc. We do not find any thing to say that the committee of the Central
Govt. had gone wrong by proceeding on that basis and it was justified to take a block
period of four years which would certainly indicate the trend or show whether there
was any steep or persistent decline after the commencement of operations of
Al-Kabeer. We must not forget that this Court has also seen that there is no sharp
decline or consistent reduction in the number of useful buffaloes year after year after
the commencement of operations of Al-Kabeer. The figures/statistics as given by the
Central Govt. in its report dated 15.9.1997 as well as the 16th Quinquennial and 17th
Quinquennial Census would clearly indicate that there is an increase in the number
of buffaloes and there is no reduction or decline much less a steep decline in the
number of buffaloes in the Telangana region, as argued by the appellant. The
district-wise comparison for Telangana between the census of 1999 and 2003 asAkhil Bharat Goseva Sangh vs State Of A.P.& Ors on 29 March, 2006

would be evident from the report is as follows :
        District                16th Census     1999            17th Census 2003        
        Mahaboobnagar           360749                  356269 (-)
        Rangareddy                      211044                  272342 (+)
        Hyderabad                       8870                            31400 (+)
        Medak                          313988                   367350 (+)
        Nizamabad                      267846                   333989 (+)
        Adilabad                               208823                   301014 (+)
        Karimnagar                    448896                    441361 (-)
        Warangal                              438324                    486779 (+)
        Khhammam                      498537                    565810 (+)
        Nalgonda                        622827                  592271 (-)
                                PERCENTAGE VARIATION
        Year                            A.P.State               Telangana Region
        1999  census  (over     + 5.3%          +4.6%
1993 census
        2003      census   (over        + 10.35%                + 10.91%
1999      census
The appellant sought to challenge the veracity and correctness of the figures given in
the report of the Central Govt. as well as in the Quinquennial census. In our view, this
submission is devoid of merit. It is now well-settled by various decisions of this Court
that the findings of expert bodies in technical and scientific matters would not
ordinarily be interfered with by courts in the exercise of their power under Art. 226 of
the Constitution or by this Court under Art.136 or 32 of the Constitution. For this
proposition, reliance can be placed on the decision of this Court in the case Systopic
Laboratories (Pvt.) Ltd. vs. Dr. Prem Gupta & Ors. (1994 Suppl.(1) SCC 160).Akhil Bharat Goseva Sangh vs State Of A.P.& Ors on 29 March, 2006

Paragraphs 19 and 20 of this decision clearly give the answer on the question whether
the findings of expert body in technical and scientific matters can be interfered with
by the Court either under Art.226 or by this Court under Art. 32 or 136 of the
Constitution.
Paragraph 19 is re-produced below:
" Having considered the submissions made by the learned counsel for the petitioners
and the learned Additional Solicitor General in this regard, we must express our
inability to make an assessment about the relative merits of the various studies and
reports which have been placed before us. Such an evaluation is required to be done
by the Central Government while exercising its powers under section 26-A of the Act
on the basis of expert advice and the Act makes provision for obtaining such advice
through the Board and the DCC.
(Emphasis supplied) Para 20 is as follows:-
"The learned counsel for the petitioners have urged that these studies and reports
had been submitted on behalf of the petitioners and other manufacturers before the
Sub-Committee of the DCC as well as the Experts Committee but there has been no
proper consideration of the same by the experts as well as the DCC and the Board. In
this context, it has been submitted that no medical expert in the field of clinical
medicine in the treatment of asthma was associated in the committees and such
experts alone could make a proper evaluation of the said studies. We find no
substance in this contention. We have pursued the minutes of the meetings of the
Board, the Sub- Committee of the DCC as well as the Experts Committee. The
minutes show that the material that was submitted on behalf of the manufacturers of
the drugs in question was examined by the members and it is not possible to hold
that there has been no proper consideration of the said material by the Experts
Committee or the Sub- Committee of the DCC. The complaint that experts in clinical
medicine were not associated with the Committee does not appear to be justified. The
minutes of the meetings of the experts to consider the views of the affected
manufacturers, who represented against the proposed withdrawal of certain
formulations moving in the market, which were held on September 8, 1987, October
16/17, 1987 and January 15/16, 1989 show that among the members were included
Dr. O.D. Gulati, Dean, CAM Medical College, Karansad and Dr.J.P. Wali, Assistant
Professor of Medicine, AIIMS, New Delhi, Dr. M.Durairaj Consultant, Cardiologist,
Director of Cardiology, Poona Hospital and Research Centre, Pune was also member
of the Sub-Committee and had attended the meeting held on January 15/16, 1988. It
cannot, therefore, be said that the medical experts in clinical medicine were not
associated in the Experts Committee for evaluation of the material that was furnished
by the manufacturers."( Emphasis supplied ) Similar is the view expressed by this
Court in K.Vasudevan Nair & Ors. Vs. U.O.I. & Ors. (1991 Supp. (2) SCC 134). We
have in detail noticed the report of the Krishnan Committee and itsAkhil Bharat Goseva Sangh vs State Of A.P.& Ors on 29 March, 2006

recommendations in the earlier part of this judgment. In our view, Krishnan
Committee has also not recommended closure of the unit because of cattle depletion
but on the other hand suggested some measures that may be taken to minimize cattle
depletion.
For the reasons aforesaid and in view of the discussions made hereinabove and after
considering the reports submitted by the committee of the Central Govt. and the 16th
and 17th Quinquennial census and report of the Krishnan Committee , we do not find
any reason to show our concern that the functioning of Al-Kabeer abattoir would
result in depletion of buffalo population in the Hinterland of the abattoir.
Before concluding this issue, let us deal with Submission No. (h) made by Akhil
Bharat Goseva Sangh in C.A.No.3968 of 1994. On behalf of Akhil Bharat Goseva
Sangh in Submission No.(h) it was urged that the decision in Mohd.Hanif Quareshi &
Ors. vs. The State of Bihar (1959 SCR 629), would not help Al-Kabeer in any way as
the position at present is completely different. In that decision, total ban on slaughter
of old cattle was struck down on the ground that there was scarcity of fodder
resources, which however, according to the Akhil Bharat Goseva Sangh, does not
exist any longer. In the case of State of Gujarat vs. Mirzapur Moti Kureshi Kassab
Jamat and Ors. reported in [2005 (8) SCC 534], it has also been held that in view of
the position that exists now i.e. adequate availability of cattle feed resources, the
question of striking down total ban on slaughter of old cattle for scarcity of fodder
resources would not arise at all. In our view, this position cannot be disputed.
However, in the present case, we are concerned with the A.P. Act, 1977 which does
not impose a total ban on slaughter of a particular type bovine animal, whereas in
Mirzapur's case (Supra) this Court dealt with the provisions of Bombay Animal
Preservation (Gujarat Amendment) Act, 1994 which imposes a total ban on slaughter
of cow and its progeny. So far as the A.P. Act, 1977 is concerned, there is no total ban
on slaughter of buffaloes. Therefore, in our view, this submission of the Akhil Bharat
Goseva Sangh cannot at all be accepted, as we are not concerned with the case of
striking down a particular provision which imposes an absolute prohibition of
slaughter of particular types of bovine animals. In Mirzapur case, it was, however, not
held that permitting slaughter of bovine cattle by itself is unconstitutional. This being
the position, we are not in agreement with the learned counsel for the appellant that
Submission No.(h) can come to their assistance for the purpose of banning of
slaughter of buffaloes by Al-Kabeer.
The last question which was agitated by Akhil Bharat Goseva Sangh ( C.A. No.
3968/1994 ) but not agitated by the other appellants in the other appeals was
whether the policy of the Central Govt. to promote export of meat violates
constitutional provisions. According to the appellant, the policy of the Govt. to
encourage slaughter for export is subject to judicial review as policies which violate
constitutional provisions are reviewable. This policy violates Art. 39(b) and (c) of the
Constitution as it serves to concentrate profits from cattle wealth in a few hands. ItAkhil Bharat Goseva Sangh vs State Of A.P.& Ors on 29 March, 2006

was further submitted by Akhil Bharat Goseva Sangh that not only this policy violates
Art. 47 of the Constitution as it leads to malnutrition but also Art. 48 which contains
a positive command to the State to preserve and improve breeds and prohibit
slaughter of milch and draught cattle regardless of their usefulness . The learned
counsel has also contended that this policy also violates Art. 21 by depriving the
society of the useful benefits of animals. It was further submitted that the A.P. Act,
1977 does not mention any specific age limit under which cattle slaughter is
prohibited and therefore the determination of healthy and useful cattle is subjective
and with a scope of maneuverability. Although no provision of the aforesaid Act
prescribes the age of any slaughterable buffalo but the A.P. animal husbandry manual
prescribes the age of slaughterable buffaloes as above 10 years. According to this
appellant, these buffaloes are useful even till 15-20 years. Lastly, it was submitted
that the agencies of the State Government also recommended ban on export of meat
and such being the position this Court may strike down the policy of the Central Govt.
so far as the meat export policy is concerned. This submission of the appellant was
contested by the learned counsel for the respondents, in particular, the learned
Advocate for APEDA in C.A. No. 3968/1994. In our view, as the policies taken by the
Central Govt. and APEDA, which is a creation of the Parliament for promotion of
export and product development of scheduled products, the question of striking
down of the policy cannot arise. However, it will be always open to the Court to direct
the Central Govt. or the State Government to renew or review its policy and to make a
fresh policy at any time if they find it to be expedient to do so. As noted herein earlier,
APEDA is a statutory authority created by an Act of Parliament for promotion of
export and product development of scheduled products. "Scheduled Product" has
been defined in section 2(i) of the Act which means any of the agricultural or
processed food products included in the Schedule. Item No.2 to the Schedule of the
Act of 1985 mandates that APEDA shall promote export and development of
scheduled products. It is the consistent policy of the Government of India to
encourage export of meat and meat products, as would be evident from the following:
Export of buffalo meat is on the OGL list.
(i) Government of India in its Directive has stressed export of meat and meat
products as thrust area.
(ii) Current "Foreign Trade Policy" encourage export of meat. It provides for export of
meat of buffalo provided it is accompanied by a certificate from the designated
veterinary authority to the effect that meat or offal are from buffalo not used for
breeding and milching purposes.
It appears that the certificates that are to be or already issued was in conformity with the decision of
the Constitution Bench's judgment in Mohd. Hanif Qureshi's case reported in [1959 SCR 629]. It is
the case of the Government as well as the abattoir that only those buffaloes which are unfit for
milching, breeding and draught were permitted to be slaughtered and are being slaughtered. WeAkhil Bharat Goseva Sangh vs State Of A.P.& Ors on 29 March, 2006

have already discussed the decline of cattle population because of the operation of Al-Kabeer in this
judgment hereinbefore. In Mohd. Hanif Qureshi's case reported in [1959 SCR 629] the issue was not
whether the population of live stock was increasing or not but whether the population of healthy live
stock was increasing. Although it was sought to be argued by the appellant that due to slaughter of
buffaloes by Al-Kabeer, the population of healthy buffaloes was declining even then in view of our
discussion made hereinearlier, it must be confirmed that there is no depletion of cattle/buffalo
wealth due to operation of Al-Kabeer. Apart from that, it appears from the record that Al-Kabeer
slaughterhouse was built in accordance with European Economic Community Standards and is one
of the most modern, scientific, integrated slaughterhouses in India with an installed capacity of
15000 MT. If in any way Al-Kabeer is directed to close down their factory the said action on the part
of the Central Government would be to discourage private entrepreneurs to invest in the meat
industry which will affect the reputation of India in the export market of meat. As we have already
noted, the interim direction given by this Court on 12th March 1997 by which the production of
Al-Kabeer was reduced to 50 %, the total export of meat from India, which is about 1,70,000 MT.,
did not reduce. For the reasons aforesaid, we are unable to direct at this stage to strike down the
policy regarding meat export from India to foreign countries. We are of the view that the policy of
the Central Government cannot be easily struck down only because there was slight decline of cattle
growth nor it can be struck down before looking into the entire aspect of the matter. It is also well
settled that policy decision of the Government cannot be interfered with or struck down merely on
certain factual disputes in the matter. It is not open to the Court to strike down such decision until
and unless a serious and grave error is found on the part of the Central Government or the State
Government. Such being the position, we are unable to strike down this meat export policy of the
Central Government, as in our view, it does not violate the constitutional provisions. That apart, the
question regarding constitutionality as mentioned above was not argued before the High Court
seriously. Accordingly, this submission of Akhil Bharat Goseva Sangh is hereby rejected.
Apart from that, from the discussion made hereinabove, we find that it is also the consistent policy
of the Government of India to encourage export of meat and meat products. The current foreign
trade policy also encourages export of meat provided that a designated veterinary authority certifies
that it is not obtained from buffalo used for breeding and milching purposes. It is true that in the
Constitution Bench decision of this Court in the case of State of Gujarat vs. Mirzapur reported in
[2005 (8) SCC 534] it has been held that the protection envisaged under Art.48 extended even to
cattle that had ceased to be milch or draught, provided they fall within the category of milch and
draught cattle. In State of Gujarat vs. Mirzapur (supra) it has also been held that cattle forms the
backbone of Indian agriculture and they remain useful throughout their lives. While dealing with
Art. 48 and 48-A of the Constitution read with the fundamental rights, the Constitution Bench
further held that both directive principles and fundamental duties must be kept in mind while
assessing the reasonableness of legal restrictions placed upon fundamental rights. However, striking
down a law or policy on the ground that it violates a directive principle or fundamental duty was not
an issue before the Constitution Bench of this Court in the case of State of Gujarat vs. Mirzapur
(supra). It is true that in the aforesaid Constitution Bench decision it has been held that total
prohibition of cow and cow progeny slaughter may be justified. However, it has not been held in that
decision that laws and policies which permit such slaughter are unconstitutional. Therefore, the
position of law remains that the directive principles and fundamental duties cannot in themselvesAkhil Bharat Goseva Sangh vs State Of A.P.& Ors on 29 March, 2006

serve to invalidate a legislation or a policy. Moreover, the export policy itself permits only export of
meat from buffaloes that are certified as not useful for milching, breeding or draught purposes.
Therefore, if properly implemented, it cannot be said that the policy will necessarily have adverse
consequences, especially in view of the foreign exchange obtained through it. Accordingly, we are
unable to accede to the argument of the learned counsel for the appellant that the meat export
policy, as made by the Central Government must to be struck down.
For the reasons aforesaid, we are of the view that meat export policy need not be struck down
subject to constant review by the Central Government in the light of its potentially harmful effects
on the economy of the country.
In view of our discussion made hereinabove and for the reasons stated hereinearlier we are of the
view that these appeals can be disposed off by giving the following directions:-
1. The APPCB is hereby directed to rectify its consent order given to Al-
Kabeer following Rule 3 read with Schedule 1, Entry 50-B of the Environmental Protection Rules,
1986. In the event abattoir fails to comply with such rectified consent order of the APPCB, it would
be open to the authorities to direct closure of the Al-Kabeer unit.
2. The APPCB is directed to file reports before the State Government as well as Central Government
relating to compliance with the pollution standards by Al-Kabeer specified under its consent order
in compliance with the Environmental Protection Rules, 1986, once in every three months.
3. The Company is directed to regularly monitor pollution of air and water by its abattoir. It is
further directed to file a report of its compliance with the Environmental laws, particularly, the
Environmental Protection Rules, 1986, before the APPCB every month.
4. Al-Kabeer is directed to file reports before the State Government on cattle population in its
surrounding areas once every year. The State Government shall examine the correctness of the said
report and thereafter take appropriate action.
5. The State Government is directed to monitor regularly and strictly in respect of Al Kabeer's
compliance with all applicable laws, particularly the provisions of the Andhra Pradesh Prohibition of
Cow Slaughter and Animal Preservation Act, 1977, once every three months and to obtain reports on
the same and thereafter to take necessary action for their proper implementation.
6. The Company is directed to prepare a plan in consultation with the State Government and take up
its implementation in conjunction with the State Government for promoting better animal
husbandry practices within the next three months. The State Government is directed to take all the
necessary steps for this purpose.
7. Modernizing the existing abattoirs in the state is advisable and in that regard the State
Government may take steps that it considers necessary.Akhil Bharat Goseva Sangh vs State Of A.P.& Ors on 29 March, 2006

8. Finally, the Central Govt. is directed to review the meat export policy, in the light of the Directive
Principles of State Policy under the Constitution of India, and also in the light of the policy's
potentially harmful effects on livestock population, and therefore on the economy of the country.
However, we keep it open to the Central Government and the State Government to consider the
distance prohibitions as indicated in the LOI, the Notifications and General Order of the State
Government and in the event, the Central Government or the State Government comes to the
conclusion that the abattoir cannot be permitted to run their business at the site in question, in that
case, the Central Government or the State Government, as the case may be, shall be entitled to
proceed in accordance with law.
Considering the facts and circumstances of the case, and in view of the fact that this Court by an
interim order granted stay of the operation of the direction of the High Court for initiating a
prosecution of Dr. Kishan Rao ( Appellant in C.A. No. 3966/1994 ) under section 195 of the Code of
Criminal Procedure read with Section 191 of the Indian Penal Code, we do not find any reason to
proceed with this prosecution against Dr. Kishan Rao any further.
In view of the disposal of appeals by this common judgment, all Interlocutory Applications and
Contempt Petition pending, if any, shall also stand disposed of.
There will be no order as to costs.
In Civil Appeal Nos. 4711-4713 of 1998 :
Although these three appeals being C.A. Nos. 4711-4713 of 1998 ( Umesh & Ors. vs.
Karnataka & Ors. ) were heard along with C.A. Nos. 3964-68 of 1994, it was thought
fit to deliver the judgment in C.A. Nos. 4711-4713 of 1998 separately, as the questions
involved in these appeals were not in issue in C.A. Nos. 3964-68 of 1994. Accordingly,
the judgment in these three appeals which involved common questions of law and
fact is being delivered in the following manner:-
Before the Karnataka High Court, two writ petitions being W.P.
Nos.32999-33000/1995 were filed by one N. Umesh and Hindu Jagarana Vedike.
Another Writ Petition being Writ Petition No. 31217/1992 was filed in the same High
Court by Smt. Sarojini Muthanna and H. Mangalamba Rao and others. In the Writ
Petitions bearing W.P. Nos. 32999 of 1995 and W.P. No. 33000 of 1995 filed by
Umesh and Hindu Jagaran Vedike, the following reliefs were sought :
(1) A writ in the nature of Mandamus commanding the respondents to strictly enforce
the provisions of sections 4,8,9,10,11 and 18 of the Mysore Prevention of Cow
Slaughter and Cattle Preservation Act, 1964 ( in short "the 1964 Act") in
Chamarajnagar Taluk of Mysore District and also to direct State Government to
establish institutions for taking care of cows and other animals in accordance with
the aforesaid provisions of the Act at the earliest.Akhil Bharat Goseva Sangh vs State Of A.P.& Ors on 29 March, 2006

(2) Declare section 5 of the 1964 Act as void and ultra-vires the spirit of the Directive
Principles of the Constitution  Act.37 and 48  and violative of Arts. 25 and 26 of the
Constitution. (3) Declare partial prohibition of slaughter of bovine cattle under 1964
Act as violative of Arts. 14,15,21,25 and 26 of the Constitution. (4) Issue a writ of total
prohibition of slaughter of bovine cattle in the whole of Karnataka.
Practically, the same reliefs were claimed by Sarojini Muthanna and Mangalamba Rao in W.P. No.
31217 of 1992. However, W.P. No. 31217 of 1992 relates to Kodagu and Coorg districts of Karnataka.
After exchange of affidavits and after hearing the learned counsel for the parties all the three Writ
Petitions were rejected by the High Court by a common judgment dated 16th March 1998. Against
this judgment the present appeals have been preferred by the appellants which were admitted by
this Court on grant of special leave and heard in presence of the learned counsel for the respective
parties. The relevant facts which are required to be taken into consideration in deciding these
appeals are enumerated below. The three Writ Petitions filed in the High Court were in the nature of
Public Interest Litigations and the petitioners were prosecuting the Writ Petitions before the Court
in representative capacity. The first appellant herein is an honourary Animal Welfare Officer of the
Animal Board of India. Second appellant herein i.e. Hindu Jagarana Vedike is an organization which
is working to uphold Hindu values and is interested in protecting sanctity of "cow". The third
appellant herein is a native of Kodagu district and belongs to Kodava community of Hindus. The
fourth appellant herein is a practicing Advocate and resident of Bangalore city.
In the erstwhile State of Coorg which now forms part of Karnataka State there had been a total
prohibition of slaughter of cows and its progeny since slaughtering or killing of cows and calves or
bullocks or oxen was considered an unpardonable sin and was considered as being opposed to
sentiments, customs and religious beliefs of the natives of Coorg called ' Kodavas'. Further all these
religious sentiments had for long received statutory protection and had been followed before the
reorganization of the State under the States Reorganization Act of 1956.
In the erstwhile State of Mysore, the Mysore Prevention of Cows Slaughter Act 1948 prohibited
slaughter of cows, bulls, bullocks, buffaloes and calves in order to conserve cattle wealth of the State.
In 1964, after the merger of the former State of Coorg with the State of Mysore, a new enactment,
namely, the Mysore Prevention of Cow Slaughter and Cattle Preservation Act 1964 ( in short "1964
Act"), which repealed the 1948 Act, modified the animal slaughter laws in the State to the following
effect :
(1) Slaughter of cows and calves of she buffaloes was totally prohibited (Section 4) (2)
Other bovine animals namely bulls, bullocks, buffaloes could be slaughtered after
obtaining a certificate in writing from the competent authority that the animal is fit
for slaughter i.e. it is above the age of 12 years or that the animal has become
permanently incapacitated for breeding, draught or milch purposes due to injuries,
deformities or any other cause. (Section 5) Under Sec. 18 of the 1964 Act the State
Government has the authority to establish or direct establishment of institutions to
take care of cows and other animals.Akhil Bharat Goseva Sangh vs State Of A.P.& Ors on 29 March, 2006

Before us, the following questions had cropped up for decision:
1. Whether the High Court erred in dismissing the petitions all-
together after holding that the State Government must strictly implement the provisions of the 1964
Act?
2. Whether the view taken by this Court in Mohd.Hanif Quareshi Vs. State of Bihar [1959 SCR 629]
regarding implementation of Art. 48 directive principle vis-`-vis fundamental right guaranteed
requires modification in the light of larger bench decision in Keshavananda Bharti Case (1973 (4)
SCC 225) and the subsequent decisions of this Court?
3. Whether the terms in Art. 48 are wide enough to include all categories of bovine cattle?
4. Whether section 5 of the 1964 Act is unconstitutional in so far as it does not impose a total
prohibition of slaughter of bovine cattle and whether a writ must be issued directing the State to
prohibit slaughter of all bovine cattle in the State of Karnataka?
Before we decide these questions, we may keep in mind the findings arrived at by the High Court of
Karnataka in the impugned judgment.
As noted herein earlier, we find from the reliefs claimed in all the three aforesaid Writ Petitions, a
prayer was made seeking a writ in the nature of Mandamus commanding the respondents to strictly
enforce the provisions of Sections 4, 8 to 11 and 18 of the 1964 Act in Chamarajnagar Taluk of
Mysore District, Coorg District, Kodagu District and also to direct the State Government to establish
institutions for taking care of cows and other animals in accordance with the aforesaid provisions of
the Act at the earliest.
In paragraph 8, the High Court concluded in the impugned order on this relief in favour of the
appellants and found that " it is needless to state that the Government and its officers are required
to strictly enforce and implement the provisions of the Act". (Emphasis supplied). That being the
conclusion made by the High Court in the body of the judgment, in respect of Question No.1, we feel
it proper at this stage to direct the State Government and its instrumentalities to strictly enforce and
implement the provisions of Sections 4, 8 to 11 and 18 of the 1964 Act without going into this
question in detail. It is needless to state that statutory provisions are required to be strictly complied
with and therefore it is the duty of the State authorities to comply with the aforesaid provisions of
the 1964 Act. In this view of the matter, Question No.1 as framed herein earlier is decided in favour
of the appellants by directing the State Government and other State authorities to strictly enforce
and implement the provisions of Sections 4, 8 to 11 and 18 of the 1964 Act.
Even though this conclusion was arrived at by the High Court in favour of the appellants, ultimate
decision, however, went against them i.e. Writ Petitions were dismissed in their entirety.Akhil Bharat Goseva Sangh vs State Of A.P.& Ors on 29 March, 2006

Let us now deal with the second issue raised by the appellants before us. According to the
appellants, the view taken in Mohd. Hanif Quareshi & Ors. vs. State of Bihar [1959 SCR 629]
decision vis-`-vis relationship between Directive Principles and Fundamental Rights requires
modification in the light of the decision in the case of Kesavananda Bharathi vs. State of Kerala (
1973 (4) SCC 225) and subsequent decisions. We need not deal with this aspect of the matter in
detail in view of the recent decision of this Court in the case of State of Gujarat Vs. Mirzapur [2005
(8) SCC 534]. The decision of this Court in the case of Mohd. Hanif Quareshi & Ors. Vs. State of
Bihar [1959 SCR 629] has now been over-ruled on this point by the Constitution Bench decision of
this Court in Mirzapur case. Therefore, this question is decided in favour of the appellants. In Mohd.
Hanif Quareshi & Ors. Vs. State of Bihar [1959 SCR 629] the contention that a law enacted to give
effect to Directive Principles cannot be held to be violative of fundamental rights was rejected on the
ground that :
" a harmonious interpretation has to be placed upon the Constitution and so
interpreted it means that the State should certainly implement the directive
principles but it must do so in such a way that its laws do not take away or abridge
the fundamental rights, for otherwise the protecting provisions of Chapter III will be
"a mere rope of sand".( Emphasis supplied).
This view was, however, not accepted in the aforesaid Constitution Bench decision in
the case of State of Gujarat vs. Mirzapur [(2005) 8 SCC 534]. The Constitution Bench
noted that after the decision in Kesavananda Bharathi vs. State of Kerala [1973 (4)
SCC 225] the position is :
"A restriction placed on any fundamental right aimed at securing Directive Principles
will be held as reasonable and hence intra vires subject to two limitations : first that it
does not run in clear conflict with the fundamental right, and secondly that it has
been enacted within the legislative competence of the enacting legislature under Part
XI Chapter I of the Constitution."( Emphasis supplied ) In Paragraph 22 of the
decision in the case of State of Gujarat Vs. Mirzapur it has been held as follows:
"The restrictions which can be placed on the rights listed in Article 19(1) are not
subject only to Articles 19(2) to 19(6); the provisions contained in the Chapter on
Directive Principles of State Policy can also be pressed into service and relied on for
the purpose of adjudging the reasonability of restrictions placed on the fundamental
rights."(Emphasis supplied).
Further, in the case of State of Gujarat vs. Mirzapur, so far as Arts.48, 48-A and also
Art. 51-A(g) are concerned the following was held:
"It is thus clear that faced with the question of testing the constitutional validity of
any statutory provision or an executive act, or for testing the reasonableness of any
restriction cast by law on the exercise of any fundamental right by way of regulation,
control or prohibition, the Directive Principles of State Policy and FundamentalAkhil Bharat Goseva Sangh vs State Of A.P.& Ors on 29 March, 2006

Duties as enshrined in Art. 51-A of the Constitution play a significant role. The
decision in Quareshi-1 in which the relevant provisions of the three impugned
legislations were struck down on the singular ground of lack of reasonability, would
have been decided otherwise if only Art. 48 was assigned its full and correct meaning
and due weightage was given thereto and Arts.48-A and 51-A(g) were available in the
body of the Constitution." (Emphasis supplied) In view of the aforesaid admitted
position in law, we therefore hold the question No.2, as framed, must be decided in
favour of the appellants. This question, even though decided in favour of the
appellants would not materially affect the decision of this appeal.
The third question which concerns interpretation of Art. 48 of the Constitution shall
now be dealt with.
In 1958 Quareshi's case it was held that:
"the protection recommended by this part of the directive is, in our opinion, confined
only to cows and calves and to those animals which are presently or potentially
capable of yielding milk or of doing work as draught cattle but does not, from the very
nature of the purpose for which it is obviously recommended, extend to cattle which
at one time were milch or draught cattle but which have ceased to be such."
(Emphasis supplied).
But in the case of State of Gujarat vs. Mirzapur this position was over-ruled and it has
been held that:
"In our opinion, the expression 'milch or draught cattle' as employed in Article 48 of
the Constitution is a description of a classification or species of cattle as distinct from
cattle which by their nature are not milch or draught and the said words do not
include milch or draught cattle, which on account of age or disability, cease to be
functional for those purposes either temporarily or permanently. The said words take
colour from the preceding words "cows or calves". A specie of cattle which is milch or
draught for a number of years during its span of life is to be included within the said
expression. On ceasing to be milch or draught it cannot be pulled out from the
category of 'other milch and draught cattle." (Emphasis supplied).
Such being the position and in view of the Constitution Bench decision as aforesaid, it
can no longer be held that the protection recommended by this part of the directive
under Art. 48 of the Constitution can be said to be confined only to cows and calves
and those animals which are presently capable of yielding milk or of doing work as
draught cattle. The aforesaid Constitution Bench decision has clarified that the
protection under Art. 48 of the Constitution also extends to cattle which at one time
were milch or draught but which have ceased to be such. A submission was made by
the learned counsel for the parties on the usefulness of cattle. In 1958 Quareshi's case
it was held that cattle becomes useless after a certain age which is for the LegislatureAkhil Bharat Goseva Sangh vs State Of A.P.& Ors on 29 March, 2006

to determine and thereafter their maintenance is a burden on the economy of the
country. This position has also been negatived by the decision of the Constitution
Bench in the aforesaid case, and it has been held by this Court as follows:
"We have found that bulls and bullocks do not become useless merely by crossing a
particular age.The increasing adoption of non-conventional energy sources like
Bio-gas plants justify the need for bulls and bullocks to live their full life inspite of
their having ceased to be useful for the purpose of breeding and draught."( Emphasis
supplied ) Following the aforesaid findings and on the basis of the findings that our
economy has adequate cattle feed resources and alternative sources of nutrition, in
the case of State of Gujarat vs. Mirzapur , it was held as under:
"The Legislature has correctly appreciated the needs of its own people and recorded
the same in the Preamble of the impugned enactment and the Statement of Objects
and Reasons appended to it. In the light of the material available in abundance before
us, there is no escape from the conclusion that the protection conferred by impugned
enactment on cow progeny is needed in the interest of Nation's economy. Merely
because it may cause 'inconvenience' or some 'dislocation' to the butchers, restriction
imposed by the impugned enactment does not cease to be in the interest of the
general public. The former must yield to the latter." ( Emphasis supplied) Therefore,
in our view, the interpretation of Art. 48 of the Constitution has now been widened
and "milch and draught cattle"
include cattle which have become permanently incapacitated to be used for milch and draught
purposes. Hence, this question is decided in favour of the appellants. Though, this question has been
decided in favour of the appellants, it does not make any material difference to the final decision of
this case. It is the decision on the next issue i.e. issue No.4 that will have impact on final directions
to be issued in this case.
Let us come to issue No.4, i.e. whether section 5 of the 1964 Act is unconstitutional in so far as it
does not impose a total prohibition on slaughter of bovine cattle and whether a writ of mandamus
must be issued to the State Government to impose a total ban on slaughter of bovine cattle in the
State of Karnataka?
In State of Gujarat vs. Mirzapur the impugned Act therein, provided for prohibition on slaughter of
certain types of cattle. The Constitution Bench of this Court in that case held such a legislation to be
constitutional in the light of the finding that the legislation was in furtherance of the directive in Art.
48 of the Constitution and any enactment which furthers the cause in the directive principles of
State Policy cannot be held to be unconstitutional. It was, however, not held that permitting
slaughter of bovine cattle by itself is unconstitutional. In the case at hand, section 5 of the 1964 Act
does not provide for a total prohibition on slaughter of bovine cattle. That being the case, declaring
section 5 of the 1964 Act as unconstitutional and directing the State Government to impose a total
ban on slaughter of bovine cattle, as requested by the appellants, would lead to judicial legislation
and would encroach upon the powers of the Legislature. Therefore, the prayer of the appellants inAkhil Bharat Goseva Sangh vs State Of A.P.& Ors on 29 March, 2006

issue No.4 to issue a writ to the State Government to totally prohibit slaughter of bovine cattle is
rejected.
In view of our discussions made hereinabove, even though the Mirzapur decision supports the
submission of the appellants on the questions Nos.2 and 3, the issuance of writ of Mandamus to
compel total prohibition of cattle slaughter would only amount to judicial legislation and would
encroach upon the powers of the Karnataka Legislature, as held by the High Court, which, in our
view, was the right approach made by it. That being the position, we are of the view that the
question of declaring total ban on slaughter of cattle cannot be permitted and section 5 of the Act
cannot be said to be ultra vires of the Constitution. For the reasons aforesaid, the appeals are
allowed in part, i.e. to the extent of directing the State Government to strictly enforce and
implement the provisions of Sections 4, 8-11 and 18 of the 1964 Act and take action on any violations
thereof. Further, it is directed that the State Government maintain proper institutions for providing
care and protection to cattle in the light of section 18 of the 1964 Act.
There will be no order as to costs.Akhil Bharat Goseva Sangh vs State Of A.P.& Ors on 29 March, 2006

