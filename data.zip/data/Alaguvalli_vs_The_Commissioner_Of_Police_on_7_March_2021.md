Alaguvalli vs The Commissioner Of Police on 7 March, 2021
Author: S.Vaidyanathan
Bench: S.Vaidyanathan, G.Jayachandran
                                                                            H.C.P.(MD)No.489 of 2021
                             BEFORE THE MADURAI BENCH OF MADRAS HIGH COURT
                                             Reserved on : 08.11.2021
                                             Delivered on : 18.11.2021
                                                    CORAM:
                                  THE HONOURABLE MR.JUSTICE S.VAIDYANATHAN
                                                     and
                                  THE HONOURABLE DR.JUSTICE G.JAYACHANDRAN
                                             H.C.P.(MD)No.489 of 2021
                 Alaguvalli                                                    ... Petitioner
                                                       -vs-
                 1.The Commissioner of Police,
                   Office of the Commissioner of Police,
                   Madurai City.
                 2.The Principal Secretary to Government,
                   Home, Prohibition & Excise Department,
                   Secretariat,
                   Chennai - 600 009.
                 3.The Superintendent of Police,
                   Central Prison,
                   Palayamkottai,
                   Tirunelveli District.                                        ... Respondents
                 PRAYER: Petition filed under Article 226 of the Constitution of India, for
                 issuance of a Writ of Habeas Corpus, to call for the entire records in detention
                 order No.23/BCDFGISSSV/2021, dated 07.03.2021, on the file of the first
                 1/10
https://www.mhc.tn.gov.in/judis
                                                                              H.C.P.(MD)No.489 of 2021
                 respondent herein, set aside the same as illegal and direct the respondents to
                 produce the body or person of the petitioner's son namely, Alex @ Chinna AlexAlaguvalli vs The Commissioner Of Police on 7 March, 2021

                 @ Alexpandian, Male, aged 29 years (now detained at Central Prison,
                 Palayamkottai), before this Court and set him at liberty.
                                  For Petitioner              :      Mr.G.Karuppasamy Pandian
                                                                     for Mr.Na.Manimaran
                                  For Respondents             :      Mr.S.Ravi
                                                                     Additional Public Prosecutor
                                                     ORDER
S.VAIDYANATHAN, J.
and G.JAYACHANDRAN, J.
Alex @ Chinna Alex @ Alexpandian, aged about 29 years, son of Thavasi, was detained by the first
respondent, terming him as a Goonda as defined under Section 2(f) of the Tamil Nadu Prevention of
Dangerous Activities of Bootleggers, Cyber Law Offenders, Drug Offenders, Forest Offenders,
Goondas, Immoral Traffic Offenders, Sand Offenders, Sexual Offenders, Slum Grabbers and Video
Pirates Act, 1982 [Tamil Nadu Act 14 of 1982], vide impugned order dated 07.03.2021. The mother
of the detenu has moved this Court under Article 226 of the Constitution of India, seeking issuance
of a Writ of Habeas Corpus to call for the entire records pertaining to the proceedings of the first
respondent https://www.mhc.tn.gov.in/judis made in No.23/BCDFGISSSV/2021, dated
07.03.2021, quash the same and set the detenu at liberty.
2.The grounds of detention indicates that on 15.11.2020 one Muruganandam, son of Panchavarnam
was found dead head severed from body near St. Mary's Church Compound, Madurai. In this
regard, an F.I.R. in Crime No.1166 of 2020 under Sections 307, 341 and 302 of I.P.C. was registered
based on the complaint given by the mother of the deceased Muruganandam. The investigation
unraveled that the murder of Muruganandam is a sequel of earlier crime occurred in the year 2019,
wherein one M.S.Pandi was done to death by Manikandan @ Chinna Vayithalai and his associates
due to previous enmity. The said Manikandan @ Chinna Vayithalai, who is the prime accused in
M.S.Pandi's murder case, was released on bail and stayed at the house of one Cent Muniyasamy. To
wreak vengeance for the murder of M.S.Pandi, his brother-in- law V.K.Gurusamy arranged for
surveillance of Manikandan @ Chinna Vayithalai, so that they can finish him off at the appropriate
time. In the said pursuit of crime, it appears that Muruganandam has helped V.K.Gurusamy and his
associates. Knowing about this, Manikandan @ Chinna Vayithalai group had
https://www.mhc.tn.gov.in/judis arranged Bavu @ Palanimurugan and Eli Dinesh @ Nondi Dinesh
and followed the movements of Manikandan @ Chinna Vayithalai. On 15.11.2020 when
Muruganandam and Eli Dinesh @ Nondi Dinesh came to St. Mary's Church in a two wheeler, Eli
Dinesh @ Nondi Dinesh left Muruganandam there and moved. Soon thereafter, Dineshkumar @
Thoothukudi Dinesh, Bavu @ Palanimurugan, Alaguraja @ Kottu Raja, Raja @ Undiyal Raja and the
detenu Alex @ Chinna Alex @ Alexpandian came in a Indica Car with deadly weapons and attacked
the said Muruganandam and severed the head Muruganandam and throw it at the gate of St. Mary's
Church. A case was registered against the detenu and others for the offences under Sections 307, 341Alaguvalli vs The Commissioner Of Police on 7 March, 2021

and 302 of I.P.C., which was altered into Sections 147, 148, 294(b), 307, 341 and 302 of I.P.C.
Subsequently also, the Section of law was altered into Sections 120-B, 147, 148, 294(b), 307, 341,
302 and 392 of I.P.C. read with Section 83(2) of the Juvenile Justice (Care and Protection of
Children) Act, 2015.
3.The detaining authority having gone through the papers, had found that the murder of
Muruganandam is the sequence of earlier murder of M.S.Pandi and the gang war between two
groups has led to disturbance of public peace and https://www.mhc.tn.gov.in/judis retaliatory
murders. All the accused persons, who were involved in Muruganandam's murder case, arrested and
remanded to judicial custody. The application for bail filed on behalf of the detenu in the above said
case was dismissed by the learned Judicial Magistrate No.IV, Madurai, in Cr.M.P.No.2998 of 2020
on 15.12.2020, whereas conditional bail was granted on 22.02.2021 to Nallamurugan, Muniyasami
@ Tumini and Maniperumal, who are the co-accused of the detenu in the above said ground case, by
the learned Principal Sessions Judge (i/c) Madurai, in Cr.M.P.Nos.683 and 780 of 2021. Therefore,
the detaining authority opined the likelihood of granting bail to the detenu Alex @ Chinna Alex @
Alexpandian is also imminent.
4.The Habeas Corpus Petition is filed on the ground that the principle laid down by the Hon'ble
Supreme Court in the case of D.K.Basu vs. State of West Bengal [AIR 1997 SC 610] was not followed.
The detenu has surrendered before the learned Judicial Magistrate No.II, Dindigul, on 18.11.2020 in
Crime No.1166 of 2020. The investigation in the said case has already been completed and final
report has also been filed. While so, the detention order dated 07.03.2021 was passed and the same
was received by the detenu on 08.03.2021. https://www.mhc.tn.gov.in/judis The detention order,
which was passed after nearly 109 days from the date of surrender of the detenu in the ground case,
is unexplained and therefore, the same has to be quashed. It is contended by the petitioner's counsel
that out of 12 accused involved in the case, the order of detention was slapped only against Accused
Nos.2 to 5 adopting the method of pick and choose and therefore, the detention order is bad in law.
5.Per contra, the first respondent has filed counter affidavit stating that the detention order was
passed after considering the material records and on subjective satisfaction that the detenu's
presence will be prejudicial to the maintenance of public order, the detention order was passed on
07.03.2021 immediately after receipt of recommendation from the sponsoring authority. The
gruesome murder of Muruganandam, they severed the head of the deceased thrown at the St. Mary's
Church Gate and the headless body found in a different place would clearly show the premeditated
murder by the accused persons to take revenge of the murder of M.S.Pandi, which took place in the
year 2019. The rivalry between two criminal gangs has gone to the extent of annihilation each other
gruesomely causing awe to the public. Hence, the detention of the detenu
https://www.mhc.tn.gov.in/judis under the Tamil Nadu Act 14 of 1982 is in accordance with the
procedure and law.
6.Heard the learned counsel appearing on either side and perused the materials available on record.
7.The City of Madurai is facing a peculiar law and order issue namely, a war between the gangs
leading to a chain of murders one after another as retaliation and revenge. The case underAlaguvalli vs The Commissioner Of Police on 7 March, 2021

consideration is one such incident where the detenu is involved in the murder of Muruganandam,
which is retaliatory attack in response to the murder of one M.S.Pandi. The sponsoring authority in
this case, being satisfied that to maintain law and order, preventive detention of the detenu is
necessary in view of the bail granted to some of the accused persons, had sponsored the detention of
the persons with all relevant records and the detaining authority soon after the receipt of the
recommendation, had applied his mind, scrutinized the documents and recorded the reasons for
detention in detail and served the detention order dated 07.03.2021 to the detenu.
8.One of the contentions raised by the petitioner's counsel is that the detaining authority has
applied pick and choose method to slap the detention https://www.mhc.tn.gov.in/judis order. This
Court is of the view that out of 12 accused, the detention order has been passed only against four
accused in this case, since their antecedents and association are prejudicial to the maintenance of
public order and peace. Therefore, out of 12 accused persons, only for the four accused persons,
preventive detention order has been passed. This clearly shows that the detaining authority has
applied his mind and only in the rarest of rare cases, where the very presence of the persons in the
Society will create disturbance, preventive detention order has been passed and not against every
one indiscriminately. The reason for detention speaks for itself. There is no undue delay in
considering the representation and also there is no error or omission in appreciating the documents.
This Court is of the view that the detention order has been passed after due consideration of the
records and on application of mind. There is no substantial reason to interfere in the well reasoned
order of detention. Hence, this Habeas Corpus Petition is dismissed.
[S.V.N., J.] [G.J., J.] Index : Yes / No 18.11.2021 https://www.mhc.tn.gov.in/judis Note :
In view of the present lock down owing to COVID-19 pandemic, a web copy of the order may be
utilized for official purposes, but, ensuring that the copy of the order that is presented is the correct
copy, shall be the responsibility of the advocate / litigant concerned.
To
1.The Commissioner of Police, Office of the Commissioner of Police, Madurai City.
2.The Principal Secretary to Government, Home, Prohibition & Excise Department, Secretariat,
Chennai - 600 009.
3.The Superintendent of Police, Central Prison, Palayamkottai, Tirunelveli District.
4.The Additional Public Prosecutor, Madurai Bench of Madras High Court, Madurai.
https://www.mhc.tn.gov.in/judis S.VAIDYANATHAN, J.
and G.JAYACHANDRAN, J.
smn2 Pre-delivery order in 18.11.2021 https://www.mhc.tn.gov.in/judisAlaguvalli vs The Commissioner Of Police on 7 March, 2021

