Emergent Genetics India Pvt. Ltd vs Shailendra Shivam And Ors
on 2 August, 2011
Author: S.Ravindra Bhat
Bench: S. Ravindra Bhat
                                                                                            1
               IN THE HIGH COURT OF DELHI AT NEW DELHI
                                                                      Reserved on : 07.04.2010
                                                                    Pronounced on: 02.08.2011
+              `       I.A. Nos. 388/2004 (U/S 39 R 1 & 2),
                       1267/2004 (U/O 39 R 4 Vacation of Stay) &
                       1268/2004 ( U/O 7 R 11 Rejection of Plaint) in
                                   CS(OS) 50/2004
       EMERGENT GENETICS INDIA PVT. LTD.                           ..... Plaintiff
               Through : Mr. P.V. Kapur, Sr. Advocate with Mr. Jagdish Sagar, Ms. Ikasha
                         Bhalla and Ms. Tanvi Misra, Advocates.
                                      versus
       SHAILENDRA SHIVAM AND ORS.                +                  ..... Defendants
               Through : Mr. C. Mohan Rao, Advocate.
       CORAM:
       MR. JUSTICE S. RAVINDRA BHAT
1.
     Whether the Reporters of local papers         YES
       may be allowed to see the judgment?
2.     To be referred to Reporter or not?            YES
3.     Whether the judgment should be                YES
       reported in the Digest?
MR. JUSTICE S.RAVINDRA BHAT
%
1. The Plaintiff, is a private limited company is a Joint Venture between Hindustan Lever Ltd and
Emergent Genetics LLC. It is engaged in research, development, processing and sale of seeds inEmergent Genetics India Pvt. Ltd vs Shailendra Shivam And Ors on 2 August, 2011

India. The second Defendant - Pradham Biotech Pvt. Ltd. is an incorporated Indian company; the
first, third and fourth Defendants are the Plaintiffs former employees. The fifth Defendant is the
Chief Executive of Seeds India, a partnership firm which processes and packages seeds, which also
used to process seeds for the Plaintiff between 13th Nov. 2001 and 17th Oct. 2003. The present order
will dispose of two applications - one by the Plaintiff, seeking temporary injunction, and the other,
by the Defendant, seeking rejection of the plaint.
IA Nos. 388/2004, 1267/2004 & 1268/2004 in CS(OS) No.50/2004 Page 1
2. The suit alleges that till March 2003, the first Defendant was the Plaintiffs National Sales
Co-ordinator; as on the date of filing the suit, he was director of the second Defendant and in-charge
of decision-making in key areas. Till January 2003, the third Defendant used to be in charge of the
Plaintiffs sales, production and processing; as on the date of filing the suit, he was principal share
holder and CEO, as well as Managing Director of the sixth Defendant. Similarly, till January 2003,
the fourth Defendant used to be in charge of the Plaintiffs research and production of vegetables;
as on the date of filing the suit, he was principal officer and shareholder of the second Defendant
and also part of its decision- making process. The fifth Defendant was a shareholder of the second
Defendant.
3. The Plaintiff contends that there are two types of seeds as per provisions of the Seeds Act, 1966 -
i.e. notified under Section 5 and "non-notified". Notified seeds can be sold by anyone upon
procuring a license to sell from the Appropriate Authority; these are termed "public varieties". The
other varieties are called "research varieties" for which separate licenses are required. An applicant
for this type of seed has to demonstrate proof of research history to obtain the license. The Plaintiff
contends that there are six distinct steps involved in development of research varieties, i.e. (1):
Collection of Germplasm. (2) Characterization and selection of desired traits in the plant; (3)
Creation of Hybrid Seed; (4) Evaluation of the new hybrid plant and multiplication of the parent
seed (hereafter called "foundation seed); (5) Production of hybrid seeds by contract farmers and (6)
Processing hybrid seeds for the market. It is submitted that the nomenclature "F-1" denotes the first
generation seed produced from the Foundation seed; the second generation seed produced from the
F-1 seed is called the F-2 seed, and so on.
4. It is contended and argued that the Plaintiff was initially a Seeds Division of Hindustan Lever
Ltd.(HLL). However, it was not successful and a policy of outsourcing was adopted. The third
Defendant had played a major role in implementing the new policy of outsourcing research,
production and processing, and thus had complete access to the foundation as well as F-1 seeds of
the Plaintiff. It is alleged that the Plaintiffs cotton hybrids, sold under the brands BRAHMA,
KRISHNA and LAKSHMI, were commercially successful and were developed by a local seed
Organizer called Bharati Seeds. BRAHMA was brought from Bharati Seeds for sale by HLL, and
Bharati Seeds developed cotton hybrids for HLL under an exclusive sourcing agreement dated 18th
April 1996. HLL subsequently acquired the IPRs for the BRAHMA, KRISHNA and LAKSHMI seeds
from Bharati Seeds through a Deed of Assignment dated 30th August 2001. It is stated that the
Plaintiff became the IPR IA Nos. 388/2004, 1267/2004 & 1268/2004 in CS(OS) No.50/2004 Page 2
owner of the BRAHMA, KRISHNA and LAKSHMI seeds by Deed of Transfer dated 30th Mar,2002;Emergent Genetics India Pvt. Ltd vs Shailendra Shivam And Ors on 2 August, 2011

HLL also assigned all trademarks to the Plaintiff by Deed of Assignment dated 4th Apr. 2002. It is
further argued that the Plaintiff later signed a royalty-based agreement with Bharati Seeds on 14th
May 2003 to outsource a new hybrid ATAL.
5. In this background, submits the Plaintiff, it entered into an Agreement dated 13-11- 2001 with
Seeds India through the fifth Defendant for processing and packaging of its seeds for 3 years. This
Processing Agreement was subsequently terminated w.e.f. 7-11-2003 by mutual consent. According
to the Processing Agreement, all seeds to be processed and packaged were to be supplied by the
Plaintiff, and Seeds India was to process and package the seeds, and would charge the Plaintiff an
amount per packet.
6. The suit alleges that the third Defendant became the Vice President (Business) with overall charge
of production, processing and sales in the company in 2002. That year, it was discovered that
records of sales were not recorded in the books of the Plaintiff, and illegal transactions were traced
to the department of the third Defendant. The latter (third Defendant) resigned in March 2003
since he was selected to go for training to the USA and he objected to this re-allocation. However,
the Plaintiff believes that since the Defendants portfolio was restricted only to sales after the
discovery of illegal transactions, he decided to resign. In March 2003, the first Defendant decided to
leave the services of the Plaintiff. The fourth Defendants services were terminated in June 2003
when the Plaintiff discovered that he was working with the second Defendant during the period of
absence from the Plaintiff company. It is alleged that in April 2003, the first and third Defendants
held meetings with the Plaintiffs distributors and dealers and announced that they had floated a
new company called Pradham Biotech Pvt. Ltd. The fourth Defendant, alleges the Plaintiff, had been
involved with its (the Plaintiffs) cottonseed hybrid production, and had been associated with it
since 1985. The second Defendant claimed that it sourced the VIDHATA, KRISHNA ASTRA and
AMOGH varieties from the sixth Defendant (denied by the Plaintiff, who alleges that its copyright
stands infringed). The Plaintiff also alleges that many of its employees were "poached" by the
Defendants.
7. The Plaintiff alleges having sent the products of the Defendants i.e. VIDHATA, KESHAV and
AMOGH for DNA Fingerprinting and comparison with its own products, i.e. BRAHMA, KRISHNA
and ATAL in an independent research organization called the Avestha Gengraine Technologies
(hereafter AGT). Describing the DNA Fingerprinting test, the Plaintiff submits the genetic makeup
of the two seeds was compared. The genotype holds IA Nos. 388/2004, 1267/2004 & 1268/2004 in
CS(OS) No.50/2004 Page 3 the essential information which is used to produce the outward,
physical manifestation or phenotype of the organism. If the DNA sequence or the genotype of the
variety is the same as another, they are considered to be genotypically similar to each other. One of
the most common methods of DNA Fingerprinting is Random Polymorphic DNA Test (hereafter
"RAPD" test).In the RAPD, the DNA is extracted from the samples, amplified by polymerase chain
reaction, which are loaded in agarose gel. The areas of DNA are classified depending upon the rate
of movement and are known as bands. If the position of the bands on the two samples is similar, the
two are considered to be genetically or genotypically identical. The Plaintiff relies on a chart,
summarizing the results of the RAPD test in its case, on a comparison of the two rival samples. The
results of the RAPD test have been shown as follows:Emergent Genetics India Pvt. Ltd vs Shailendra Shivam And Ors on 2 August, 2011

PLAINTIFF'S VARIETY DEFENDANT'S VARIETY FINDINGS OF THE DNA
FINGERPRINT REPORT BRAHMA VIDHATA Identical to each other KRISHNA
KESHAV Identical to each other ATAL AMOGH Identical to each other It is
contended that since the Defendants products and those of the Plaintiffs are
genotypically identical, the former have misappropriated the seeds of the Plaintiff
and are selling them as their own. Moreover, the Defendants have also reproduced
the unique sequencing formula of the hybrid seeds, thereby resulting in copyright
infringement of the literary work of the Plaintiff.
8. The Plaintiff alleges that the Defendants conduct amounts to copyright infringement, besides
appropriation of confidential information, and its commercial use, without its (the Plaintiffs)
permission. The Plaintiff also allege trademark infringement, and appropriation of goodwill and
reputation, in respect of the seed varieties over which it has proprietary interest. Consequently, the
Plaintiff seeks permanent injunction against the Defendants, their Directors, etc, from
manufacturing, selling and offering for sale, genotypically identical seeds to that of the Plaintiff as it
amounts to a copyright infringement of the unique sequencing information of the hybrid seeds.
Permanent injunction restraining the Defendants from manufacturing, selling and offering for sale
genotypically identical seeds to that of the Plaintiff as it amounts to a breach of legal rights of the
Plaintiff and also amounts to a breach of confidentiality as regards information belonging to the
Plaintiff, is sought. Permanent IA Nos. 388/2004, 1267/2004 & 1268/2004 in CS(OS) No.50/2004
Page 4 injunction to restrain the sale of seeds genotypically identical to those of the Plaintiff is also
claimed. Besides, the Plaintiff seek permanent injunction restraining the Defendants from selling
the tomato seeds under the trademark ANUPAMAas it amounts to passing off of the tomato seeds
sold by the Plaintiff and a permanent injunction restraining the Defendants from reverse passing off
spurious seeds as that of the Plaintiff. Consequential relief such as an order for rendition of accounts
of profits of the Defendants, is sought; as also the relief of delivery up, and a decree of damages is
claimed. The Plaintiffs application for ad-interim temporary injunction was heard, and such relief,
ex-parte, was granted by the Court.
9. In support of its allegations, the Plaintiff argues, through its senior counsel that a DNA sequence
has the ingredients of a „literary work because it is
(i) Capable of being expressed in writing or by analogous means.
(ii) Analogous to a computer programme as it is a set of instructions not intended for direct
application by the human mind.
(iii) It is urged that computer programmes have been held to be literary work by Courts in UK even
before amendment of the statute.
10. It is argued that sequences can be „original. They would not have existed previously but for the
toil and effort of their creators. In this case the sequence came into existence as a result of the
hybridization process by the Plaintiff. It is therefore, contended the sequences being the result of
skill and labour involved in decoding and recording it, creates an original copyrighted work. In thisEmergent Genetics India Pvt. Ltd vs Shailendra Shivam And Ors on 2 August, 2011

regard, the Plaintiffs senior counsel relies on the following extract of the textbook "Modern Law of
Copyrights and Designs" Laddie, Prescott and Vitoria, Chapter 21, 2nd Ed. Reliance is placed on the
following passages of the textbook:
" „literary work means any work, other than a dramatic or musical work, which is
written, spoken or sung, and accordingly includes -
(a) a table or compilation, and
(b) a computer program.... It is therefore hard to see why the expression does not
encompass a string of letters, eg written on paper, serving to denote a sequence of the
nucleotides in DNA or the amino acids in a protein. Such a thing is a work - it
certainly had to be created by the effort of a human mind - and it is written. That the
subsection mentions tables and compilations as instances of things which are
„accordingly included further supports the proposition. Further, in the above there
is nothing new in terms of traditional copyright law, as is shown by the telegraph
code cases in the nineteenth and twentieth centuries. In those it was held that there
was copyright in seemingly arbitrary sequences of letters which of themselves
imparted no human message and which, in fact, took their meaning from a highly
specialized, indeed unpublished, context IA Nos. 388/2004, 1267/2004 &
1268/2004 in CS(OS) No.50/2004 Page 5
1. Anderson & Col. Ltd. v. Lieber Code Co [1917] 2 KB 469, Ager v. Peninsular and
oriental Steam Navigation Co (1884) 26 Ch D 637, Ager v. Collingridge (1886) 2 TLR
291.
2. See also Express Newspapers plc v. Liverpool Daily Post and Echo plc [1985] FSR
306 (newspaper competition - arbitrary sequences of letters - holder of right
sequence entitled to prize). For a fuller discussion of s 3 (1) see ch 2 above.
21.20 However, without pretending to be able to define it with any precision, there must be a certain
minimum length of message, or the text will not answer to the description „literary work. Thus the
single word „Exxon was held not to be a literary work. „Similarly, it is not to be expected that a
short sequence of a few letters used to design a probe for gene library screening could, by itself,
qualify as a literary work. It would seem that the law requires a certain bare minimum of elaboration
of structure before it will be prepared to concede it is a „literary work.
1. Exxon Corpn. V. Exxon Insurance Consultants International Ltd [1982] Ch 119, C.A. Note that to
devise this word - it was required neither to form part of any known language nor to have been in
use as a trade name anywhere in the world - took a substantial amount of hard work. The objection
was directed to not being a „literary work, not to originality.
2. By way of illustration, in the Genentech case [1989] RPC 147 the patentees used the highly
unusual sequence W-E-Y-C-D to construct probes to locate the desired clone. For a description ofEmergent Genetics India Pvt. Ltd vs Shailendra Shivam And Ors on 2 August, 2011

the „probe concept see para 21.35 n 1 below.
„Original 21.21 While it is a question of fact, it will be obvious that the elucidation of a DNA or
protein sequence is a task frequently calling for very substantial independent skill, labour, and so
on. If so, the statutory requirement of originality is satisfied. It might be objected that the sequence
cannot be original because it is copied from nature, but this would be to ignore well-established law.
A work may be original and copyright although derived from antecedent material, provided further
independent skill, useful labour, knowledge or judgment have been bestowed on its creation. „That
the nature of the subject matter is such as to leave the author with no option but to arrive at a given
result (if he does his job correctly), or that no independent act of the human imagination was
required for its creation, have long been rejected as valid objections to the existence of copyright
protection, as is shown by the cases concerning shorthand writers copyright. Nature may have
been the author of biological sequence, but the human scientific team are the authors of the written
record thereof.
1. See paras 2.63 ff.
2. Walter v Lane [1990] AC 539, HL: described as „undeniably still good law in Express
Newspapers plc v. News (UK) Ltd [1990] 1 WLR 1320 at 1326 (where order 14 judgment was given).
„Second generation DNA and proteins 21.22 The above discussion relates to written records
faithfully representing sequences pre-existent in nature. But, of course, there is no logical reason
why those IA Nos. 388/2004, 1267/2004 & 1268/2004 in CS(OS) No.50/2004 Page 6 alone should
be capable of enjoying copyright protection; sequences modified by human intervention might do so
too
1. It is often the case that scientists, having elucidated such a sequence, go on to strive to improve on
nature. They seek to introduce modifications or variations which will lead to the production of
proteins which are even better than the originals. These are sometimes referred to as "second
generation" artefacts. For example, hormones are instances of proteins, but there is no a priori
reason for believing that nature has necessarily ensured that these are of optimal design. Their
formation in the human body may produce unpleasant side effects, eg morning sickness during
pregnancy, perhaps. Nature is indifferent to this, and cares only that the product is good enough to
ensure the present survival and reproduction of the individual. Scientists by routine trial and error
may create artificial hormones, equally effective for their primary purpose, but greatly superior in
other, secondary, respects.
Conclusion 21.23 It would therefore seem that copyright is capable of subsisting in a scientific
record consisting of a series of letters or other characters symbolizing the sequential structure of
DNA, proteins and similar constructs found in molecular biology, provided the recorded sequence is
of sufficient length. This view may seem somewhat surprising at first blush, but it is submitted that
it is rather difficult to see how any other can be sustained, consistent with the language of the Act
and well- established principles of copyright law. Any sense of surprise would appear to arise not
from the legal principles but from the dramatically novel set of scientific facts to which they areEmergent Genetics India Pvt. Ltd vs Shailendra Shivam And Ors on 2 August, 2011

applied. It will often be the case that such sequences will be held in the form of computer databases.
The protection to be enjoyed by these, if any, is discussed in chapter 20, above. "
11. It is urged next that unlike the United Kingdom, "fixation" (i.e. the existence of a
literary or copyrightable work in tangible form) is not a pre-condition for a copyright
to subsist in a work in India. Learned counsel relied on the definition of "work" and
"literary work" under the Copyright Act, and further submitted that according to
Article 2(2) of the Berne Convention it is a matter for municipal legislation in the
signatories to prescribe that works in general or any specified categories of works
shall not be protected unless they have been fixed in some material form.
12. It is argued that in the present matter, the hybrid seed is created expressing the
DNA sequence - such sequence is an original literary work enjoying copyright
protection. The same hybrid cannot be produced without reproducing this literary
work. Thus, Defendants, who have produced the same hybrid, have infringed the
Plaintiffs copyright. It is also argued that the actual DNA sequence will be a matter
of evidence, but evidence of fixation is not necessary to show the subsistence of
copyright. It is argued that even before the amendment IA Nos. 388/2004,
1267/2004 & 1268/2004 in CS(OS) No.50/2004 Page 7 of the laws, in the UK and in
the USA, computer databases and computer programmes were afforded copyright
protection; in support, the Plaintiff relies on Apple Computer, Inc. v. Franklin
Computer Corp., 714 F. 2d 1240, 1253 (3d Cir. 1983,) and Sega Enterprises Ltd. v
Richards & Anr 1983 FSR 73.
13. For contending that the Defendants have violated the Plaintiffs copyright in the
sequences of their hybrid seeds, learned senior counsel for the Plaintiff, Shri P.V.
Kapoor, relies on the report of AGT, and the affidavit of one Dr. Rajyashri K.R,
Scientist and group leader in AGT, dated 19-2-2004. Learned counsel relied on the
decision reported as Pioneer Hi-Bred International, Inc. v. Holden Foundation Seeds,
Inc. 35 F.3d 1226 (8th Cir. 1994) where Pioneer alleged that Holden misappropriated
proprietary inbred maize lines-either H3H or H43SZ7 ("H3H/H43SZ7"), or both-that
were Pioneer trade secrets. Pioneer did not have plant variety protection or patent
protection on H3H; However, it had maintained this parental line as a trade secret.
The United States District Court for the Southern District of Iowa found for Pioneer
and awarded it over $46.7 million in damages. Holden appealed this decision. Under
Iowa law, Pioneer had to show three elements to prevail in a trade secret action: (1)
existence of a trade secret, (2) acquisition of the secret as a result of a confidential
relationship, and (3) unauthorized use of a secret. In appeal, Holden argued that it
should not be liable for misappropriating H3H/H43SZ7 because Pioneer failed: (1) to
keep the genetic messages secret; (2) to prove that Holden actually possessed the
protected genetic messages; and (3) to prove that Holden obtained the material by
improper means. The Eighth (Appellate) Circuit Court, in its judgment "assume[d]
without deciding that genetic messages can qualify for trade secret status." The Court
affirmed the district Court's finding that Pioneer had taken every effort to keep H3HEmergent Genetics India Pvt. Ltd vs Shailendra Shivam And Ors on 2 August, 2011

and H43SZ7 secret by such means as grower confidentiality contracts, unlabeled
fields, secret codes on production seed bags, and the removal of male inbred lines to
be mixed with other corn before sending to elevators or putting in bags. Based on
scientific evidence, the District Court found, and the Eighth Circuit agreed, that the
Holden's lines, LH38, LH39, and LH40, were more likely than not fathered by
Pioneer's H3H/H43SZ7, rather than the Holden line, L120. The Appellate Court also
upheld the Trial Court's findings.
14. The Defendant submits, through its counsel, Mr. C. Mohan Rao, that the suit does
not disclose any cause of action. It is urged that the claim of the Plaintiffs hybrid
seeds being genotypically identical to those of the Defendant is incorrect. It is urged
that assuming there is a genotypical similarity between the two varieties (which is
natural as all cotton varieties IA Nos. 388/2004, 1267/2004 & 1268/2004 in CS(OS)
No.50/2004 Page 8 would show the same genotypic pattern) no right has been
infringed as has been made out by the Plaintiff. No intellectual property with respect
to seeds can be claimed by the Plaintiff. It is further argued that the Plaintiff does not
show that genotypical identity between the two seeds is the test applicable in respect
of seeds. The test to determine similarity between two plant varieties in most
countries where rights in respect of new plant varieties are recognised is the
phenotype test. The Defendant says that since there is no right to seeds in India and
the test relied upon by the Plaintiff is not the test on which similarity between two or
more plant varieties can be determined, the plaint is without cause of action and is
liable to be dismissed.
15. The Defendant argues that the Protection of Plant, Varieties and Farmers Rights
Act, 2001 is involved in this case. It is submitted that the enactment, though not
notified, does not recognize the kind of rights the Plaintiff seeks to enforce, in the
suit. It is argued that unlike the position in the US, where there is a separate patent
regime for plants (Plant Patent Act, 35 U.S.C. §§ 161-164 (1994)) no such enactment
exists in India. On the other hand, Section 3(j) of the Patents Act, 1970 specifically
excludes rights to patents with respect to seeds. Thus, the Indian Patents Act takes
away the rights of any inventor in respect of seeds, varieties and species; the Plaintiff
therefore, could not have acquired any rights under the Act.
16. The Defendant argues that the Copyright Act is inapplicable for seed hybrid
development processes. In this connection, it is urged that Section 2(o) of the
Copyright Act, 1957 defines literary work; it does not comprehend mere compilation
of sequences; it cannot be held to be concerned with development of hybrid seeds.
Even otherwise, the rights claimed by the Plaintiff cannot be granted. It is urged that
the Defendants have developed their own seeds, thus the Plaintiffs are not granted a
decree of permanent injunction.
17. Next, the Defendants deny the Plaintiffs allegations that they (the Defendants)
have violated the terms of their Service Agreement and have accessed andEmergent Genetics India Pvt. Ltd vs Shailendra Shivam And Ors on 2 August, 2011

misappropriated the confidential information of the Plaintiff. It is argued in this
connection that there is no confidential information, in the development of hybrid
seeds. It is argued that the basis for alleging breach of confidence is the genotypically
identical test, which is an incorrect test and cannot be used to establish malafides
necessary to prove breach of confidence. The Defendants contend that assuming
there is any confidentiality, the same would be subject matter of arbitration, i.e.
Clause 16 of the Service Agreement between the Plaintiff and the first, third and
fourth Defendants. The Defendants also contest that this Court has territorial
jurisdiction, and urge that the suit, based on Section 62(2) of the Copyright Act, is
misconceived. In this context, it is submitted that both contesting parties are carrying
on IA Nos. 388/2004, 1267/2004 & 1268/2004 in CS(OS) No.50/2004 Page 9
business in Andhra Pradesh, and the Plaintiffs attempt to aver jurisdiction, based
on a solitary trap transaction, cannot be accepted. It is also submitted that to the
extent the suit is based on accrual of a part of cause of action within territorial
jurisdiction, the plaint reveals that the goods or articles purportedly sold are not the
subject matter of the present suit.
18. The Defendants complain that the Plaintiffs reasons for invoking jurisdiction of
the Court are mala fide, since, the suit says that the Defendants sold seeds in the
markets of Andhra Pradesh, Maharashtra and Karnataka in May 2003. The suit was
filed later, in Delhi in January 2004 with the motive of obtaining interim ex parte
injunction from the Delhi High Court to prevent the Defendant from conducting
business just as the season starts and causing irreparable loss to the Defendants.
19. It is urged that farmers do not know the brand of the company or the brand
names of the seeds, but purchase seeds due to the face value and reputation of the
third Defendant. It is alleged that the Plaintiff filed the suit to stifle competition, and
since the Service Agreement did not prohibit the Defendants from starting its own
business, the Plaintiff is looking to ensure that the Defendants suffer an irreparable
loss and are put out of business. The second Defendant has an extensive collection of
research varieties, since after its incorporation in 2003, it entered into an agreement
with Shri Sai Lakshmi Agrotech (P) Ltd. which has been involved in research and
production of hybrid variety of seeds since 1985.
20. The Defendants urge that after the Plaintiff took over from HLL, the Plaintiff sold
spurious seeds mixed with quality seeds instead of destroying the sub-standard
seeds. The illegalities were brought to the notice of the senior officers of the Plaintiff,
but no action was taken. As a result, the first and third Defendants left the Plaintiff
Company. The Defendant also alleges theft - on part of the Plaintiffs senior officials,
from the processing plant of Seeds India, on 27-5-2003, which was subject of a
complaint, despite which the Plaintiff took no action.
21. It is urged that the Plaintiff has tried to mislead the Court by alleging the
development of research varieties takes 5 to 10 years. The Defendants also allege thatEmergent Genetics India Pvt. Ltd vs Shailendra Shivam And Ors on 2 August, 2011

the Plaintiff has not developed any research varieties itself, and gained commercial
success only upon outsourcing from Bharati seeds. It is urged that all the varieties of
the Defendant were developed by Shri Sai Lakshmi Agrotech Pvt. Ltd and were
transferred to Defendant 2 in the same manner that the Plaintiff had acquired its
seeds from Bharati Seeds. The Defendants contest the Plaintiffs averments about
two type of trade licenses i.e. the Public Variety license and the Research variety
license, and say that no such differentiation exists and only one license is issued with
IA Nos. 388/2004, 1267/2004 & 1268/2004 in CS(OS) No.50/2004 Page 10 respect
to trade in seeds. It is pleaded that in the state of Andhra Pradesh, the Government
recognises certain research varieties due to MoU entered into with breeders -
however, this MoU is not statutory and is not contemplated under the Seed Act or the
Rules.
22. Learned counsel for the Defendants submit that a claim for right in respect of a
hybrid variety is a right based on improvements purportedly made to the plant; thus,
entitlements claimed are based on the improvements made. It is submitted that the
accepted test for recognition of rights with respect to improvements must have
resulted in new plant variety that must be Distinct, Uniform and Stable. (hereafter
"DUS"). It is urged that the same test is the ground of trade secret and intellectual
property. The Defendants submit that this test is mandated by the Protection of Plant
Varieties and Farmers Rights Act, 2001. They also urge that to successfully premise a
claim on the ground of trade secret it has to be necessarily pleaded that the item is
not in public domain - plants fall in public domain and to prove that the variety is
DUS. Learned counsel submits that there cannot be two plants which are genetically
identical; no term like "genotypical identity" exists. In this context, it is submitted
that in some countries - after applying the DUS test - the genetic test can be used to
determine the distinctiveness of an item. Counsel highlights that the Seeds Act, and
the Rules do not confer any proprietary rights.
23. It is argued by the Defendants that in the present case, the Plaintiff skipped the
first step i.e. the DUS test; it has shown that the two varieties are identical: a factor
which is not the governing test, since it has to first show its plant varieties are distinct
from other available varieties and then show that the Defendants varieties are the
same as the Plaintiffs.
24. It is argued that hybridisation involves cross pollination and does not relate to
any deliberate interference with DNA sequencing. The process of DNA sequencing
does not involve any literary work as the DNA sequencing is not known. No copyright
exists with respect to DNA sequencing anywhere in the world. It is argued further
that there is no similarity between a computer programme and DNA sequencing. The
Defendants counsel submits that the U. S. Federal Courts of Appeal decision in
Pioneer Hi-bred International relied upon by the Plaintiff needs to be differentiated
because in that matter, the germplasm was held to be a trade secret. However, in the
present case, the Plaintiff has made no effort to prove that the germplasm of theEmergent Genetics India Pvt. Ltd vs Shailendra Shivam And Ors on 2 August, 2011

varieties is a trade secret. Counsel urges that while "fixation"
may not be required under Indian law, knowledge and expression of an idea are required.
Knowledge exists though it may be intangible. In the case of hybridization of cross pollination, the
knowledge as to DNA sequencing is not known. Furthermore, it was IA Nos. 388/2004, 1267/2004
& 1268/2004 in CS(OS) No.50/2004 Page 11 submitted that the lack of patent protection to
agricultural methods (hybridization being one such) would mean that the lawmakers did not want to
confer intellectual property monopoly in that sphere, as a matter of policy. The enactment of the
Plant Varieties Act, meant that protection could be claimed and granted in its terms; if however, an
extremely wide copyright protection to DNA sequence database were granted, that would defeat and
undermine Parliamentary intent. It was lastly urged that there was no originality in the mere
copying or compiling of gene or similar hybrid sequences, which could be taken down in tangible
form by any one. There was absence of minimum originality, an essential requirement for
copyrightability; thus the claim for copyright protection had to fail. The Defendants counsel lastly
argued that the Plaintiff cannot also claim that its trade secrets were stolen or used, or that it was
entitled to protect "confidential" information. Counsel submitted that the Plaintiff has prima facie
failed to establish or prove that the information which the Defendants possess are of a confidential
nature, and could not have been developed by them. It is not as if the process of hybridization or
agricultural techniques which result in such new seeds, are unique, or deserve protection, of the
kind claimed by the Plaintiff. These seeds can and are often commonly developed by farmers and
other breeders. In any case, there is no material to warrant the grant of an injunction.
25. This Court had granted an ex-parte injunction which has subsisted all the while. The Court now
proposes to discuss the rival contentions with respect to three aspects, i.e. whether copyright
protection is granted under Indian law, in respect of the work, for which the Plaintiff claims reliefs;
whether the Defendants used the Plaintiffs confidential information, unauthorizedly, and what
should be the appropriate interim relief, if any.
26. Section 2(o) of the Copyrights Act defines „literary work to include (among others) computer
programmes, tables and compilations including computer databases. Section 2(y) defines „work as
meaning any of the following works namely: (i) a literary, dramatic, musical or artistic work,(ii) a
cinematographic film, (iii) sound recording. Under Section 14, literary work is one of the items
wherein exclusive rights can be claimed so as to amount to copyright. Indian law has recognized that
compilation of databases is entitled to copyright protection. However, that would not end the
debate. The law mandates that the work claiming protection ought to be original. Copyright law does
not also grant the author of a literary work protection on ideas and facts. (Baker v. Seldon, 101 US
99 [1879], Nichols v. Universal Pictures Corp., 45 F.2d (2d Cir. 1930), RG Anand v. M/s Delux
Films, (1978) 4 SCC 118) It is the creative expression of an idea or fact which gets rewarded by law,
through copyright IA Nos. 388/2004, 1267/2004 & 1268/2004 in CS(OS) No.50/2004 Page 12
monopoly for a specified period. The law does not, however protect every expression, but grants
such recognition and protection to expressions that are "original". This standard is incorporated by
Section 13, in respect of every class of work. A literary work, in order to qualify as work in which
copyright can subsist, must therefore be original.Emergent Genetics India Pvt. Ltd vs Shailendra Shivam And Ors on 2 August, 2011

27. The standard for judging "originality" has undergone a radical change from the time a work was
deemed original if it was the product of the "sweat of the brow" as it was enunciated in University of
London Press. A higher criterion of "modicum of creativity" was deemed necessary after the decision
in Fiest Publication Inc. Vs. Rural Telephone Service, 199 US 340 (1991). The Supreme Court of
India has also recognized this shift and in Eastern Book Company v. DB Modak 2008 (1) SCC 1,
following the approach adopted by the Canadian Supreme Court in CCH Canadian Ltd., Vs. Law
Society of Upper Canada (2004) SCC 13. The Indian Supreme Court rejected the sweat of the brow
doctrine, (which conferred copyright on works merely because time, energy, skill and labour was
expended, that is, originality of skill and labour), and held that the work must be original "in the
sense that by virtue of selection, co-ordination or arrangement of pre-existing data contained in the
work, a work somewhat different in character is produced by the author". Pertinently our Supreme
Court noticed that the two positions i.e. the sweat of the brow on the one hand, and "modicum of
creativity" were extreme positions; it preferred a higher threshold than the doctrine of "sweat of the
brow" but not as high as "modicum of creativity". Thus, our law mandates that not every effort or
industry, or expending of skill, results in copyrightable work, but only those which create works that
are some what different in character, involve some intellectual effort, and involve a minimum degree
of creativity.
28. From the above discussion, it is apparent that mere labour (sweat of the brow) or investment of
manpower and resources, is not a substitute for originality. Sequences obtained from nature (e.g.,
the sequence for a gene) cannot per se, be original. The microbiologist or scientist involved in gene
sequencing "discovers" facts. There is no independent creation of a "work", essential for matching
the originality requirement. Such a scientist merely copies - from nature-genetic sequence that
contains codes for proteins. Therefore there is no minimum creativity. So long as a researcher
constructs a DNA sequence based on a sequence discovered in nature, there is no independent
creation, no minimum creativity and thus no originality. Now, this aspect has to be seen from the
background that the process by which those gene sequences are created, or isolated, or an improved
or unique variety is developed, does not receive any intellectual property protection, and is expressly
denied patent IA Nos. 388/2004, 1267/2004 & 1268/2004 in CS(OS) No.50/2004 Page 13
protection by reason of Section 3 (j) of the Patents Act, 1970 . If the process - despite its novelty and
industrial application, and other attributes of patentability - is denied patent protection, it is
inconceivable that the observation and compilation of the consequence of that process, which is a
natural consequence, can receive an extremely wide protection as a "literary" work. Another way of
looking at the question is that almost all DNA sequences used in research are based on sequences
discovered in nature. These sequences embodied in a work are not "original" expressions of ideas
but mere reproduction of something found in nature. Further, the mere putting together of letters,
denoting such sequences (AFAFFAA, etc) may amount to literary work, but would lack the
minimum creativity required by law, to be original. For example, the formula H2O is no different
from the formula AFAFFAA or some other combination, which may denote a genetic sequence.
Regardless of whether the molecule, exists in nature, or is isolated or developed, i.e. created rather
than discovered, and upon analysis discovered its formula confirmed as H2O, there can be no
sustainable copyright claim in the formula, since the formula is itself the molecule, not the
"expression" of it.Emergent Genetics India Pvt. Ltd vs Shailendra Shivam And Ors on 2 August, 2011

29. Another aspect is that there is no copyright protection for, any idea. This long- established
understanding, stems from the ruling in Baker v. Seldon, 101 U.S. 99 (1879), that there is no
copyright protection for ideas or procedures. In Baker, the Plaintiff claimed copyright in a book
detailing a particular method of bookkeeping and included blank forms for use with the method.
The Defendant made his own book that included the same forms for use in the Plaintiffs
bookkeeping method and the Plaintiff sued for copyright infringement. The Court found no
infringement and held that when the "art" taught by a work of authorship cannot be used without
copying some aspect of the work, then that aspect of the work will not be protected by copyright. The
Plaintiff was not allowed to assert copyright in his forms. The Court stated that if the Plaintiff could
prohibit others from using his forms and his forms were the only way to practice the bookkeeping
method, then the Plaintiff would have a de facto monopoly in that method. The Court reasoned that
to get a monopoly in the method/procedure should require satisfying the stringent requirements of
patent law. Thus, when the use of an idea or procedure requires copying of a Plaintiffs expression,
there is no copyright infringement. The judgment in Baker led to evolution of the "idea-expression
merger" doctrine. According to it (the idea-expression doctrine), when there is only one or there are
very few ways of expressing a particular idea, then it (the expression) merges with the idea. (Also,
ref. Morrissey v. Procter & Gamble Co., 379 F.2d 675 (1st Cir. 1976)). Since there can be no copyright
of ideas, the merged expression/idea is incapable of copyright.
IA Nos. 388/2004, 1267/2004 & 1268/2004 in CS(OS) No.50/2004 Page 14 Granting copyright
protection to the sole (method of expression) or limited way of expression of an idea, would mean
no one can practice the idea or procedure expressed without being guilty of copyright infringement.
In the case of combination of gene sequences, the selection of genetic components, however, mostly
has no minimal creativity because the creator is only considering what is scientifically known and
necessary. Arguendo, if such selection was original, it would still fall foul of the merger doctrine. The
idea of combining various gene components or constituents, is expressible in limited ways. Granting
copyright protection would mean that others are precluded from expressing such ideas. Therefore,
there is merger; with the resultant lack of copyright protection.
30. The Plaintiffs argument in favour of copyright protection of DNA sequence, is also based on the
analogy of computer programs. There are some similarities. e.g a gene and a computer program act
as instructions for something to be done. However, beyond this there is no similarity or identity.
DNA differs from computer programs fundamentally. The most important difference is that there is
only one way to express a "genetic program." This is by combinations of the four "nucleotide" bases.
DNA instructions for producing proteins can only exist in the form of nucleotide sequences. The
manner of stating the process or method of protein production is confined to one expression or
programme. Computer programs, however, are capable and flexible enough as to have one
instruction expressed in numerous ways through different program languages. In Apple Computer,
Inc. v. Franklin Computer Corp., 714 F. 2d 1240, 1253 (3d Cir. 1983,) cited by the Plaintiffs, the
Court held that computer programs are subject to the doctrine of merger. The Court reasoned that,
"If other programs can be written or created which perform the same function...then that program is
an expression of the idea and hence copyrightable." Here, on the other hand, a specific sequence
expressed in a manner, is the only way to express the underlining idea of the gene; therefore, there
is a merger of the idea with the expression, which precludes the copyrighting of DNA sequences thatEmergent Genetics India Pvt. Ltd vs Shailendra Shivam And Ors on 2 August, 2011

are codes for proteins.
31. It would next be relevant to discuss the impact of provisions of the Plant Protection Act.
Although the enactment was not in force when the present suit was filed, it has relevance, because it
is the legislative expression of the nature of intellectual property protection which can be secured in
respect of plant varieties. Some provisions of the Act are extracted below. The definition clause is
Section 2; some of the definitions are as follows:
"2. (h) "essential characteristics" means such heritable traits of a plant variety which
are determined by the expression of one or more genes of other IA Nos. 388/2004,
1267/2004 & 1268/2004 in CS(OS) No.50/2004 Page 15 heritable determinants that
contribute to the principal features, performance or value of the plant variety;
(i) "essentially derived variety", in respect of a variety (the initial variety), shall be
said to be essentially derived from such initial variety when it -
(i) is predominantly derived from such initial variety, or from a variety that itself is
predominantly derived from such initial variety, while retaining the expression of the
essential characteristics that results from the genotype or combination of genotypes
of such initial variety;
(ii) is clearly distinguishable from such initial variety; and
(iii) conforms (except for the differences which result from the act of derivation) to
such initial variety in the expression of the essential characteristics that result from
the genotype or combination of genotype of such initial variety;
(j) "extent variety" means a variety available in India which is -
(i) notified under section 5 of the Seeds Act, 1966; or
(ii) farmers; variety; or
(iii) a variety about which there is common knowledge;or
(iv) any other variety which is in public domain;
2. (za) "variety" means a plant grouping except micro organism within a single botanical taxon of the
lowest known rank, which can be -
(i) defined by the expression of the characteristics resulting from a given genotype of that plant
grouping;Emergent Genetics India Pvt. Ltd vs Shailendra Shivam And Ors on 2 August, 2011

(ii) distinguished from any other plant grouping by expression of at least one of the said
characteristics; and
(iii) considered as a unit with regard to its suitability for being propagated, which remains
unchanged after such propagation, and includes propagating material of such variety, extant variety,
transgenic variety, farmers variety and essentially derived variety."
Sections 14-16 are found in the chapter "Registration of plant varieties and essentially derived
variety". They are reproduced below; they spell out, importantly, the standard which has to be
fulfilled before registration and resultant protection is granted:
"14. Any person specified in section 16 may make an application to the Registrar for
registration of any variety -
IA Nos. 388/2004, 1267/2004 & 1268/2004 in CS(OS) No.50/2004 Page 16
(a) of such genera and species as specified under subsection (2) of section 29; or
(b) which is an extant variety; or
(c) which is a farmers variety.
15. (1) A new variety shall be registered under this Act if it conforms to the criteria of
novelty, distinctiveness, uniformity and stability.
(2) Notwithstanding anything contained in sub-section (1), an extant variety shall be
registered under this Act within a specified period if it conforms to such criteria of
distinctiveness, uniformity and stability as shall be specified under the regulations.
(3) For the purposes of sub-sections (1) and (2), as the case may be, a new variety
shall be deemed to be -
(a) novel, if, at the date of filing of the application for registration for protection, the
propagating or harvested material of such variety has not been sold or otherwise
disposed of by or with the consent of its breeder or his successor for the purposes of
exploitation of such variety -
(i) in India, earlier than one year; or
(ii) outside India, in the case of trees or vines earlier than six years, or in any other
case, earlier than four years.
Before the date of filing such application:Emergent Genetics India Pvt. Ltd vs Shailendra Shivam And Ors on 2 August, 2011

Provided that a trial of a new variety which has not been sold or otherwise disposed
of shall not affect the right to protection:
Provided further that the fact that on the date of filing the application for
registration, the propagating or harvested material of such variety has become a
matter of common knowledge other than through the aforesaid manner shall not
effect the criteria of novelty for such variety;
(b) distinct, if it is clearly distinguishable by at least one essential characteristic from
any other variety whose existence is a matter of common knowledge in any country at
the time of filing of the application.
Explanation - For the removal of doubts, it is hereby declared that the filing of an application for the
granting of a breeders rights to a new variety or for entering such variety in the official register of
varieties in any convention country shall be deemed to render that variety a matter of common
knowledge from the date of the application in case the application leads to the granting of the
breeders rights or to the entry of such variety in such official register, as the case may be;
IA Nos. 388/2004, 1267/2004 & 1268/2004 in CS(OS) No.50/2004 Page 17
(c) uniform, if subject to the variation that may be expected from the particular features of its
propagation it is sufficiently uniform in its essential characteristics;
(d) stable, if its essential characteristics remain unchanged after repeated propagation or, in the case
of a particular cycle of propagation, at the end of each such cycle.
(4) A new variety shall not be registered under this Act if the denomination given to such variety -
(i) is not capable of identifying such variety; or
(ii) consists solely of figures; or
(iii) is liable to mislead or to cause confusion concerning the characteristics, value identity to such
variety of the identity of breeder of such variety; or
(iv) is not different from every denomination which designates a variety of the same botanical
species or of a closely related species registered under this Act; or
(v) is likely to deceive the public or cause confusion in the public regarding the identity of such
variety; or
(vi) is likely to hurt the religious sentiments respectively of any class or section of the citizens of
India; orEmergent Genetics India Pvt. Ltd vs Shailendra Shivam And Ors on 2 August, 2011

(vii) is prohibited for use as a name or emblem for any of the purposes mentioned in section 3 of the
Emblems and Names (Prevention of Improper Use) Act, 1950; or
(viii) is comprised of solely or partly of geographical name :
Provided that the Registrar may register a variety, the denomination of which
comprises solely or partly of a geographical name, if he considers that the use of such
denomination in respect of such variety is an honest use under the circumstances of
the case.
16. (1) An application for registration under section 14 shall be made by -
(a) any person claiming to be the breeder of the variety; or
(b) any successor of the breeder of the variety; or
(c) any person being the assignee of the breeder of the variety in respect of the rights
to make such application; or
(d) any farmers or group of farmers or community of farmers claiming to be the
breeder of the variety; or
(e) any person authorized in the prescribed manner by a person specified under
clauses (a) to (d) to make application on his behalf; or
(f) any university or publicly funded agricultural institution claiming to be the
breeder of the variety.
(2) An application under sub-section (1) may be made by any of the persons referred
to therein individually or jointly with any other person."
IA Nos. 388/2004, 1267/2004 & 1268/2004 in CS(OS) No.50/2004 Page 18 Plant variety rights are
a species of intellectual property protection conferred upon breeders of new plant varieties. These
rights are a result of the Convention for the Protection of New Varieties of Plants of 1961 adopted in
Paris (and revised in 1972, 1978 and 1991), as well as Article 27, TRIPS. A "plant variety" is in
essence, a strain of a plant or a crop which is pure bred. To qualify for plant variety protection, a
crop or plant should produce the same type of plant/ crop each successive generation, should be
distinct in appearance and distinguishable from others "by at least one essential characteristic from
any other variety whose existence is a matter of common knowledge in any country at the time of
filing of the application." The criteria of "novelty, distinctiveness, uniformity and stability" to confer
protection, through registration has to be satisfied by each applicant seeking it.
32. It is no doubt correct that the Plant Varieties Act was not in force when the suit was filed.
However, it was brought into force, during its pendency, and what is more, Parliament had enactedEmergent Genetics India Pvt. Ltd vs Shailendra Shivam And Ors on 2 August, 2011

it, in 2001. Though the inter se rights of the parties, in the sense of enforcement of the rights
conferred under it, is not possible, in the case, equally, the Court cannot ignore legislative guidance,
which enacted the principles on which our society would afford protection; they are novelty,
distinctiveness, uniformity and stability of the plant variety or strain which seeks protection. The
expression "extent variety" clarifies that it is clearly meant to apply to notified varieties of species,
under the Seeds Act. In this case, apart from asserting the originality in the gene compilation, the
Plaintiff has not shown what exactly is novel or distinct about the seeds it markets, or to what extent
they are more efficient or what kind of improved efficacy they possess, such as the improvement in
terms of pest resistence, greater yield, or claims towards sturdier strain (or variety) etc. The only
averment in this regard is the following extract from the plaint:
"20. A major breakthrough for the Plaintiff was the commercial success of its cotton
hybrid varieties sold under BRAHMA, KRISHNA AND LAKSHMI. These varieties
were developed by a local seed organizer, one Mr. P. Brahmananda Reddy, who is
also a partner in Bharati Seeds, a registered partnership firm. These hybrid varieties
are better than the regular cotton varieties since the said hybrid varieties not only
produce more bolls and cotton, per plant but are also tolerant to sucking pests and
have free flowing lint, which allow for easy picking. They also provide excellent
quality of cotton fibre.
21. Under the new strategy adopted by the Plaintiff under the aegis of HLL, BRAHMA
was bought from Bharati Seeds for sale by HLL. As BRAHMA became highly
successful in the market, HLL started marketing the other products of Bharati Seeds,
such as KRISHNA and LAKSHMI, both of which are cotton hybrids. Consequently
the relationship between HLL and Bharati Seeds grew stronger and HLL's seeds IA
Nos. 388/2004, 1267/2004 & 1268/2004 in CS(OS) No.50/2004 Page 19 business
came to depend substantially upon the research and production of cotton from
Bharati Seeds. In turn, Bharati Seeds researched and produced cotton hybrids such
as Brahma and Krishna for HLL under an exclusive sourcing agreement dated April
18, 1996, as amended by a supplementary Agreement dated December 22, 2000 and
as replaced with Agreement dated May 14, 2003 (hereinafter together referred to as
"Sourcing Agreement"). A copy of the latest Sourcing Agreement is filed in the
proceedings."
The Plaintiff has relied on AVESTHAGEN's Report. Extracts of the same are reproduced below:
"Objective Fingerprinting of Cotton samples received from Emergent technologies.
Materials and Methods Primers All primers were custom synthesized by Microsynth,
Switzerland. Sequences of the RAPD primers used are given below: -
SEQUENCE PRIMER OPE-11 5'-GAGTCTCAGG-3' OPE-16 5'-GGTGACTGTG-3' OPK
2 5'-GTCTCCGCAA-3' OPN 8 5'-ACCTCAGCTC-3' OPQ 11 5'-TCTCCGCAAC-3' OPQ
14 5'-GGACGCTTCA-3' DNA Extraction and Quantitation 1.5g of cottonseeds wereEmergent Genetics India Pvt. Ltd vs Shailendra Shivam And Ors on 2 August, 2011

weighed for each sample and DNA was extracted using FAST ID kit (GID Inc, USA)
according to the manufacturer's instructions. Extracted DNA sample was quantified
using UV Tran illuminator (Bio-Rad).
Polymerase Chain Reaction 50 ng of DNA was amplified with the RAPD primers mentioned above,
in PTC 225 themocycler (MJ research).
IA Nos. 388/2004, 1267/2004 & 1268/2004 in CS(OS) No.50/2004                        Page 20
        Results
        Serial Primer No of        Comments
        No.           bands
                      Scored
        1      OPQ 18              16 bands identical in all samples. 1 unique to Brahma and Vidhata, 1
               11                  unique in Keshav, Krishna and Astra. Lakshmi has two unique bands.
                                   H-10 shows differences for two bands.
        2         OPN 8 15         All varieties have almost identical fingerprinting pattern. Atal and
Amogh show polymorphism for one band and are identical to each other. Lakshmi shows
polymorphism for two bands.
3 OPE- 17 Brahma and Vidhata differ from others by two polymorphic bands.
11 They are identical to each other. Astra, Atal and Amogh show identical fingerprints. Keshav and
Krishna are identical to each other and differ from other at one polymorphic locus. Lakshmi and
show polymorphism for six bands.
4 OPE- 13 13 bands common to all samples. 1 extra band unique to Brahma and 16 Vidhatha seen.
Lakshmi shows polymorphism for two bands.
5 OPK 2 12 All samples identical for 11 bands. 1 extra band unique to Krishna and Keshav. Lakshmi
polymorphic for one band.
6 OPQ 9 Brahma and Vidhata polymorphism for one band and are identical to 14 each other. All
other samples show identical fingerprints. Lakshmi and H-10 shows polymorphism over two loci.
Comments:
Brahma and Vidhata appear to be different from other varieties and are identical to
each other as seen by the presence of one polymorphic band with OPQ11, OPE16,Emergent Genetics India Pvt. Ltd vs Shailendra Shivam And Ors on 2 August, 2011

OPQ14 and two polymorphic bands with OPE11. 5 bands out of 299 show
polymorphism indicating that the two varieties are different from others, but
probably identical to each other.
Keshav and Krishna show a fingerprinting pattern identical to each other, but is very
slightly different from that of all other varieties as seen by a polymorphic bands with
OPQ11, OPK2 and OPE11.
Atal and Amogh show differences from other varieties and are identical to each other
as seen from the presence of polymorphic band with OPN8 and OPE11.
Lakshmi is distinctly different from the other varieties as seen by a number of
polymorphic bands with each of the primers. H-10 is also different as seen by a
number of polymorphic bands with the primers.
IA Nos. 388/2004, 1267/2004 & 1268/2004 in CS(OS) No.50/2004 Page 21 As
against the above, the Defendant has relied on the report of NBPGR, Pusa Campus,
New Delhi. Relevant extracts of the same are reproduced below:
"Report of RAPD Fingerprinting of cotton samples Six cotton samples were provided
by a representative of M/S Pradham Biotech Pvt. Ltd., #207, Orange Block, My
Home Rainbow Complex, Tolichowki, Hyderabad - 500 008. The purpose was to find
out similarity between the samples using RAPD fingerprinting technique. The pros
and cons of the technique were discussed in depth with the representative of the
aforementioned firm. The names of these samples as told by the representative were
as follows:
Sample 1: Mallika Sample 2: Bheeshma Sample 3: Indra Sample 4: Sujatha Sample 5:
Vidhata Sample6: Brahma Observations and conclusions The fingerprinting pattern
of the six samples, seen as vertical columns with horizontal light bands on a dark
background, have been depicted in 30 figures assembled in 8 plates (Plate 1 to 8). In
each figure column M represents 1 kb molecular weight standard, against which band
sizes in the six samples have been determined. Numbers 1 to 6 are Sample 1, Sample
2, Sample 3, Sample 4, Sample 5 and Sample 6 respectively. Table 1 below
summarizes the number of bands and their sizes observed for each primer. The
number of bands in these samples ranged from one (using primer OPA-04) to 12
(OPA-01). There were three primers which produced 10 or more bands. A total of 189
bands were observed using 30 RAPD primers on the basis of which the samples have
been compares. All the 189 bands were present in all the samples. None of the sample
had any unique band. Thus based on this study using 30 RAPD primers it is
concluded that all samples under test (Sample 1 to Sample 6) are similar to each
other.Emergent Genetics India Pvt. Ltd vs Shailendra Shivam And Ors on 2 August, 2011

Table 1: Number of bands observed and their sizes for 30 RAPD primers in six
samples IA Nos. 388/2004, 1267/2004 & 1268/2004 in CS(OS) No.50/2004 Page 22
_____________________________________________________________________
Sr. No. Primer Name Number of Bands Size range
_____________________________________________________________________
01 OPA-01 12 450-1600 02 OPA-02 06 500-1550 03 OPA-03 02 400-1200 04
OPA-04 01 500 05 OPA-05 08 300-1450 06 OPA-06 06 400-1200 07 OPA-07 10
300-2600 08 OPA-08 06 325-1200 09 OPA-10 08 400-2500 10 OPA-11 07 350-1500
11 OPA-12 08 300-1500 12 OPA-13 08 500-1300 13 OPA-14 06 350-1300 14 OPA-15
05 500-1400 15 OPA-16 07 400-2100 16 OPA-17 05 400-1500 17 OPA-18 02
450-1500 18 OPA-19 06 450-1500 19 OPB-01 06 650-2700 20 OPB-02 05 550-1250
21 OPB-03 06 500-1300 22 OPB-04 04 300-2500 IA Nos. 388/2004, 1267/2004 &
1268/2004 in CS(OS) No.50/2004 Page 23 23 OPB-05 04 600-2300 24 OPB-06 04
450-2000 25 OPB-07 04 250-1400 26 OPB-08 08 400-1600 27 OPB-09 08
550-1400 28 OPB-10 10 450-2000 29 OPB-11 08 300-2500 30 OPB-13 09 400-2600
__________________________ Total Bands = 189"
The suit does not rely on any supporting document to establish the claim that the seeds are pest
resistant or about the uniqueness which sets it apart from other seeds. Nor does the Plaintiff show,
by any comparison or study, how and to what extent, its assertions are substantiated. It is not even
shown whether the claim is distinct, in the sense that there is no other product containing similar
qualities or characteristics. The Court is left to surmise that the Plaintiff spent some money and
time, developing a new strain; however, significantly, the improvement effected through that strain,
and whether the technique used was unknown, or even the process of arriving at the new variety was
new, is not disclosed. The AVESTHAGEN report merely refers to two samples given by the Plaintiff.
There is no material or packaging, to show that the one of the two samples was that of the
Defendant. No receipt, or other documentary evidence, or any affidavit, in support of the claim that
the Defendants samples were sent for testing, has been produced. These materials are insufficient
to establish that the samples given for testing, are as claimed in the suit. The Defendant has
produced a report which discloses that a total of 189 bands were observed using 30 RAPD primers.
Therefore, the Court finds, prima facie, the suit claim as regards protection of the data base for
breeding the plant varieties, and producing the seeds in question, insubstantial.
33. The next issue to be discussed is whether, in the absence of copyright protection, the Plaintiff
can claim injunction on the ground that its trade secret, and confidential information IA Nos.
388/2004, 1267/2004 & 1268/2004 in CS(OS) No.50/2004 Page 24 has been unauthorizedly
misappropriated by the Defendants. The requisites for a cause of action for breach of confidence in
the common law world was enunciated clearly in the case of Coco v. A.N. Clark (Engineers) Ltd,
(1969) R.P.C. 41, i.e:
(1) the information itself must have the necessary quality of confidence about it; (2)
that information must have been imparted in circumstances imparting an obligation
of confidence;Emergent Genetics India Pvt. Ltd vs Shailendra Shivam And Ors on 2 August, 2011

(3) there must be an unauthorized use of that information to the detriment of the
party communicating it.
The "quality of confidence" highlights that trade secrets are a legal concept. With sufficient effort or
through illegal acts rivals may access trade secrets (confidential information). However, if the trade
secret or information owner proves that reasonable efforts were made to keep the information
confidential, it (the information) remains a trade secret and is legally protected. If, on the other
hand, trade secret owners cannot establish reasonable efforts to protect confidential information,
they risk losing the quality of confidentiality of the information even if its information is obtained by
rivals without permission.
34. Plant hybridization is done to develop a more desirable plant through the mixing of genetic
material from two plants. Such genetic manipulation of plants dates back to the experiments of
Gregor Mendal in the latter half of the eighteenth century. Mendel observed that the offspring of
certain plants had physical characteristics similar to the physical characteristics of the plant's
parents or ancestors. He examined pea plants to quantify their physical traits in an attempt to
predict the traits that would occur in later generations. This led to discovery of two known factors
for each genetic trait, one dominant and the other recessive. The interaction of factors with similar
factors from anther plant determines whether the dominant or recessive characteristic is expressed
in the offspring. Mendel's work (prominently his book Experiments on Plant Hybridization) led to
selective breeding. For a century the creation of a new and hybrid plant was accomplished by
mechanically grafting limbs of plants together, or obtaining pollen from a plant and using it to
fertilize another plant. Development of tissue culture changed the method and speed at which
hybridization is accomplished. Tissue culture is a method of biological research in which fragments
of tissue from an animal or plant are transferred to an artificial environment where they can
continue to function. The cultured tissue may consist of a single cell, a population of cells or a whole
part of a plant. Farmers and gardeners have been using hybridization techniques to achieve varieties
of plants and seeds better than existing ones. A famous example of integration of IA Nos. 388/2004,
1267/2004 & 1268/2004 in CS(OS) No.50/2004 Page 25 such techniques is the Green Revolution,
an initiative that involved the development of high- yielding varieties of cereal grains, particularly
wheat, which optimized its production and enabled farmers to achieve high yields.
35. In a preceding portion of the judgment, it was noticed by the Court that the suit and documents
are bereft in materials about the nature and quality of information which is confidential, and the
precise developments, which the Plaintiffs seeds offer to the public. This aspect is crucial, because
if the information and techniques are neither unique, nor novel, but are merely a documentation, or
compilation of existing material, or existing techniques, freely available, or widely practised, there is
no question of confidentiality. The Plaintiff does not claim exclusivity in respect of any particular
technique or process; it is the result, i.e., the documentation of elimination, and the attributes of the
different strains which are claimed to have been compiled. If such techniques were already available,
and were practised, they were capable of observation, and similar documentation. Another way of
looking at this aspect is that if the Plaintiffs claims were to be accepted, without any significant
substantiation, then, each hybridization development, so long as it is "documented" would qualify
for exclusivity, thus reducing the millennia old practise of farming, subject to a residual andEmergent Genetics India Pvt. Ltd vs Shailendra Shivam And Ors on 2 August, 2011

perpetual monopoly stemming from possession of so called "confidential information". This Court
has to pause to consider the wider ramifications of such an assertion. That in this case, the seeds in
question are in respect of a commercial crop would not in any manner detract from the
circumstance that the nature of protection sought, i.e confidentiality, affects all classes of seeds.
36. Since millenia, Indian farmers have been producing their seeds locally. A large majority (70%) of
the population depend on agriculture, in India, for their livelihood, and subsistence. Among these, it
is estimated that 75% of the seeds used are produced by the farmers and peasants themselves The
Plant Varieties Act has enacted certain safeguards for these farmers, who have the right to use, save,
use, exchange, share sell, sow, or re-sow, farm produce which includes inter alia, seeds protected
under the Act. Any propagating material sold by a breeder, which is registered under the Act, has to
disclose to the farmer, the predicted or expected performance, and on failure to provide such
performance the farmer can claim compensation. Section 39 of the Act protects innocent
infringement by a farmer. Also, Sections 41-42 provide for a community to have a right in benefit
sharing if the IA Nos. 388/2004, 1267/2004 & 1268/2004 in CS(OS) No.50/2004 Page 26
community has contributed to the evolution of the variety. There is also a provision for compulsory
licenses subject to certain conditions.
37. The danger of enclosing as a monopoly, (under the umbrella "trade secret" or confidential
information) what is clearly commonly shared information, and resources, in the absence of a
statutory regime (as is urged by the Plaintiff) is that the Courts of law would be at one fell stroke, not
only make policy choices which would impact livelihoods of millions, but would be ordaining,
unwittingly, legislation, which cannot be tested for its reasonableness. An inventor or innovator
undoubtedly should be provided a fair regime which protects his creative efforts, and rewards him.
But in the absence of thought out policies, which weigh the advantages as well as the drawbacks,
that may manifest in the unhindered enforcement of such impulses, there is a danger of imperilling
the right to occupation, guaranteed by Article 19 (1) (g) and the right to livelihood, so emphatically
held to be an intrinsic part of Article 21 of the Constitution of India, by our Courts.
38. Another, broader perspective cannot be lost sight of. The Courts, are enjoined to interpret the
law and the Constitution, keeping in view the Directive Principles of State Policy, embodied in Part
IV of the Constitution of India. By Article 39 (1) the State (an expression encompassing the Union,
the States and all their executive agencies and legislative organs) is enjoined to ensure:
"(b) that the ownership and control of the material resources of the community are so
distributed as best to subserve the common good;"
Parliamentary intention to ensure that the people of India are not subjected to one kind of
intellectual property monopoly, i.e. patents, is expressed, in case of Section 3 (j) of the Patents Act,
for "methods of agriculture". The interpretation adopted by this Court, not accepting the Plaintiffs
argument regarding copyright protection, would mean that another statutory intellectual property
right is also not available. However, if this Court were to accept, uncritically, and without any
statutory regime, the Plaintiffs blanket assumption that it is possessed of confidential information
in something, which plainly, is part of the material resource of the community, the Court wouldEmergent Genetics India Pvt. Ltd vs Shailendra Shivam And Ors on 2 August, 2011

overstep the mandate of the Constitution, in its anxiety to protect such a perceived right. Material
resources such as water and rivers (Ref In Re. Special Reference No.1 of 2001 Cauvery River Water
2004 (4) SCC 489) Petroleum and natural gas (Reliance Natural Gas Ltd. v Reliance Industries 2010
(7) SCC 1); forests (M.C. Mehta v Kamal Nath 1997 (1) SCC 388) essential commodities and
foodstuffs (Salar Jung IA Nos. 388/2004, 1267/2004 & 1268/2004 in CS(OS) No.50/2004 Page 27
Sugar Mills v State of Mysore 1972 (1) SCC 23) electricity generation and distribution (Tinsukhia
Electric Supply Ltd v State of Assam 1989 (3) SCC 709) have been held to be of public importance,
in respect of which the State, has to assure equitable access and availability, to the greatest numbers.
Food security lies at the heart of agriculture, and food sovereignty; it is an undoubted material
resource, as are agricultural practices such as seed breeding. It would be, in this context, useful to
recollect Article 11 of the International Covenant on Economic, Social and Cultural Rights, adopted
by the United Nations General Assembly, in 1976. It is as follows:
"Article 11
1. The States Parties to the present Covenant recognize the right of everyone to an
adequate standard of living for himself and his family, including adequate food,
clothing and housing, and to the continuous improvement of living conditions. The
States Parties will take appropriate steps to ensure the realization of this right,
recognizing to this effect the essential importance of international co-operation based
on free consent.
2. The States Parties to the present Covenant, recognizing the fundamental right of
everyone to be free from hunger, shall take, individually and through international
co-operation, the measures, including specific programmes, which are needed:
(a) To improve methods of production, conservation and distribution of food by
making full use of technical and scientific knowledge, by disseminating knowledge of
the principles of nutrition and by developing or reforming agrarian systems in such a
way as to achieve the most efficient development and utilization of natural resources;
(b) Taking into account the problems of both food-importing and food-exporting
countries, to ensure an equitable distribution of world food supplies in relation to
need."
Similarly, the UN Convention on the Rights of the Child enjoins the State parties (including India, a
signatory), by Article 25 (2) (3) to States Parties to take appropriate measures:
"To combat disease and malnutrition, including within the framework of primary
health care, through, inter alia, the application of readily available technology and
through the provision of adequate nutritious foods and clean drinking-water, taking
into consideration the dangers and risks of environmental pollution.."Emergent Genetics India Pvt. Ltd vs Shailendra Shivam And Ors on 2 August, 2011

The Constitution, by Article 47, enjoins the Indian State to reflect identical concerns, and guides
state policy in that direction:
IA Nos. 388/2004, 1267/2004 & 1268/2004 in CS(OS) No.50/2004 Page 28 "47.
DUTY OF THE STATE TO RAISE THE LEVEL OF NUTRITION AND THE
STANDARD OF LIVING AND TO IMPROVE PUBLIC HEALTH The State shall
regard the raising of the level of nutrition and the standard of living of its people and
the improvement of public health as among its primary duties and, in particular, the
State shall endeavour to bring about prohibition of the consumption except for
medicinal purposes of intoxicating drinks and of drugs which are injurious to health."
Obligations stemming from international covenants are consistent with Article 21 of the
Constitution of India. The Courts are therefore, in a position to read them into the Constitution,
while interpreting it (Ref. Jolly George Varghese v Bank of Cochin 1980 (2) SCC 360; Peoples Union
for Civil Liberties v Union of India 1997 (1) SCC 301; Nilabati Behara v State of Orissa 1993 (2) SCC
746 and Kuldip Nayar v Union of India 2006 (7) SCC
1). Absent a serious debate about enclosing widely practised agricultural methods, and a cogent
regulatory measure, in respect of the nature of protection afforded for such rights, as regards
information, there is a danger in the Courts accepting a ritualistic "enforcement of intellectual
property" approach, undermining the way farmers have been practising their occupation or
avocation. It can potentially implicate access to vital material resources such as food, and
agriculture, which is vastly detrimental to public and national interest.
39. In view of the above discussion, it is held that the Plaintiff has been unable to establish, prima
facie, its claim for copyright protection in the databases, claimed by it; similarly it has not shown
that the information, which it claims to be exclusive, is capable of protection, qualifying as
"confidential information". Consequently, the ex-parte injunction granted at an earlier stage of the
proceeding, has to be, and is, vacated. The application accordingly fails. IANo.1267/2004 filed by
the Defendant for vacation of ex parte interim injunction granted to the Plaintiff, is accordingly
allowed.
40. So far as the Defendants application for rejection of the suit is concerned, having regard to the
above reasons, the Court is of opinion that questions involving jurisdiction, data exclusivity and
copyright may yet be established after a fuller trial, and the Court would necessarily have to consider
the evidence, after a full trial. The said application too, therefore fails.
41. In view of the above reasons, IA Nos. 388/2004, and 1268/2004 are dismissed.
IA Nos. 388/2004, 1267/2004 & 1268/2004 in CS(OS) No.50/2004 Page 29 The suit shall be listed
before the Regular Bench, according to Roster allocation, on 23rd August, 2011, for directions.
2nd August, 2011                                                  (S.RAVINDRA BHAT)
                                                                         JUDGEEmergent Genetics India Pvt. Ltd vs Shailendra Shivam And Ors on 2 August, 2011

IA Nos. 388/2004, 1267/2004 & 1268/2004 in CS(OS) No.50/2004                       Page 30Emergent Genetics India Pvt. Ltd vs Shailendra Shivam And Ors on 2 August, 2011

