Assistant Commissioner Of Income Tax ... vs Ahmedabad Urban
Development Authority on 19 October, 2022
Author: S. Ravindra Bhat
Bench: Pamidighantam Sri Narasimha, S. Ravindra Bhat, Uday Umesh Lalit
                                                      1
                                                                                REPORTABLE
                              IN THE SUPREME COURT OF INDIA
                                CIVIL APPELLATE JURISDICTION
                                CIVIL APPEAL NO. 21762 OF 2017
          ASSISTANT COMMISSIONER OF
          INCOME TAX (EXEMPTIONS)                                              APPELLANT(S)
                                                  VERSUS
          AHMEDABAD URBAN DEVELOPMENT
          AUTHORITY                                                          RESPONDENT(S)
                                                   WITH
          C.A. No. 8193/2012; C.A. No. 5057/2012; C.A. No. 5058/2014; C.A. No. 9974/2018; C.A. No.
          5056/2012; C.A. No. 4196/2015; C.A. No. 4374/2015; C.A. No. 9380/2017; C.A. No.
          13071/2017; C.A. No. 12058/2017; C.A. No. 16375/2017; C.A. No. 12869/2017; C.A. No.
          17527/2017; C.A. No. 21845/2017; C.A. No. 5719/2018; C.A. No. 9886/2018; C.A. No.
          9200/2018; C.A. No. 9860/2018; C.A. No. 10114/2018; C.A. No. 1643/2019; C.A. No.
          3596/2018; C.A. No. 6762/2018; C.A. No. 3972/2018; C.A. No. 3343/2018; C.A. No. 3359/2018;
          C.A. No. 3971/2018; C.A. No. 3347/2018; C.A. No. 6489/2018; C.A. No. 10598/2018; C.A. No.
          7643/2018; C.A. No. 8321/2018; C.A. No. 8554/2018; C.A. No. 9172/2018; C.A. No.
          10406/2018; C.A. No. 11259/2018; C.A. No. 11884/2018; C.A. No. 226/2019; C.A. No.
          170/2019; C.A. No. 2047/2019; C.A. No. 2335/2019; C.A. No. 3971/2019; C.A. No. 4449/2019;
          C.A. No. 4957/2019; C.A. No. 213/2020; C.A. No. 783/2020; C.A. No. 4430/2021; C.A. No.
          2477/2021; C.A. No. 2478/2021; C.A. No. _____/2022 @ SLP(C) No. 23975/2012; C.A. No.
          _____/2022 @ SLP(C) No. 15547/2013; C.A. No. ______/2022 @ SLP(C) No. 15040/2019; C.A.
          No. _____/2022 @ SLP (C) No. _____/2022 @ Diary No(s). 39525/2017; C.A. No. _____/2022
          @ SLP(C) No. 14574/2019; C.A. No. _____/2022 @ SLP (C) No. _____/2022 @ Diary No(s).
          16597/2020; C.A. No. _____/2022 @ SLP(C) No. 10912/2018; C.A. No. _____/2022 @ SLP(C)
          No. 12304/2018; C.A. No. _____/2022 @ SLP (C) No. _____/2022 @ Diary No(s). 44856/2018;
Signature Not Verified
          C.A. No. _____/2022 @ SLP(C) No. 6553/2019; C.A. No. _____/2022 @ SLP (C) No.
Digitally signed by
NIRMALA NEGIAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

Date: 2022.10.19
          _____/2022 @ Diary No(s). 15525/2019; C.A. No. _____/2022 @ SLP(C) No. 30597/2018; C.A.
18:52:23 IST
Reason:
          No. _____/2022 @ SLP (C) No. _____/2022 @ Diary No(s). 5683/2019; C.A. No. _____/2022
                                           2
@ SLP (C) No. _____/2022 @ Diary No(s). 15488/2019; C.A. No. _____/2022 @ SLP (C) No.
_____/2022 @ Diary No(s). 15489/2019; C.A. No. _____/2022 @ SLP(C) No. 15055/2019; C.A.
No. _____/2022 @ SLP(C) No. 15079/2019; C.A. No. _____/2022 @ SLP(C) No. 14995/2019;
C.A. No. _____/2022 @ SLP (C) No. _____/2022 @ Diary No(s). 21237/2019; C.A. No.
_____/2022 @ SLP (C) No. _____/2022 @ Diary No(s). 17255/2020; C.A. No. _____/2022 @
SLP (C) No. _____/2022 @ Diary No(s). 17316/2020; C.A. No. _____/2022 @ SLP(C) No.
1404/2021; C.A. No. _____/2022 @ SLP (C) No. _____/2022 @ Diary No(s). 19394/2020; C.A.
No. _____/2022 @ SLP (C) No. _____/2022 @ Diary No(s). 19399/2020; C.A. No. _____/2022
@ SLP (C) No. _____/2022 @ Diary No(s). 19403/2020; C.A. No. _____/2022 @ SLP(C) No.
11486/2020; C.A. No. _____/2022 @ SLP(C) No. 11124/2020; C.A. No. _____/2022 @ SLP (C)
No. _____/2022 @ Diary No(s). 19449/2020; C.A. No. _____/2022 @ SLP(C) No. 12206/2020;
C.A. No. _____/2022 @ SLP (C) No. _____/2022 @ Diary No(s). 20986/2020; C.A. No.
_____/2022 @ SLP (C) No. _____/2022 @ Diary No(s). 23310/2020; C.A. No. _____/2022 @
SLP(C) No. 3759/2021; C.A. No. _____/2022 @ SLP(C) No. 4612/2021; C.A. No. _____/2022
@ SLP(C) No. 5167/2021; C.A. No. _____/2022 @ SLP(C) No. 6253/2021; C.A. No.
_____/2022 @ SLP(C) No. 5709/2021; C.A. No. _____/2022 @ SLP(C) No. 6005/2021; C.A.
No. _____/2022 @ SLP(C) No. 7166/2021; C.A. No. _____/2022 @ SLP(C) No. 7003/2021;
C.A. No. _____/2022 @ SLP(C) No. 7011/2021; C.A. No. _____/2022 @ SLP(C) No. 6917/2021;
C.A. No. _____/2022 @ SLP(C) No. 7510/2021; C.A. No. _____/2022 @ SLP(C) No.
19044/2021; C.A. No. _____/2022 @ SLP(C) No. 7779/2018; C.A. No. _____/2022 @ SLP(C)
No. 4678/2021; C.A. No. _____/2022 @ SLP (C) No. _____/2022 @ Diary No(s). 5806/2021;
C.A. No. _____/2022 @ SLP(C) No. 4636/2021; C.A. No. _____/2022 @ SLP(C) No.
4723/2021; C.A. No. _____/2022 @ SLP (C) No. _____/2022 @ Diary No(s). 6662/2021; C.A.
No. _____/2022 @ SLP(C) No. 10490/2021; C.A. No. _____/2022 @ SLP(C) No. 6686/2021;
C.A. No. _____/2022 @ SLP(C) No. 7302/2021; C.A. No. _____/2022 @ SLP(C) No.
6580/2021; C.A. No. _____/2022 @ SLP(C) No. 7290/2021; C.A. No. _____/2022 @ SLP(C)
No. 7606/2021; C.A. No. _____/2022 @ SLP(C) No. 8364/2021; C.A. No. _____/2022 @
SLP(C) No. 10908/2021; C.A. No. _____/2022 @ SLP(C) No. 7854/2021; C.A. No. _____/2022
@ SLP(C) No. 7789/2021; C.A. No. _____/2022 @ SLP(C) No. 11072/2021; C.A. No.
_____/2022 @ SLP(C) No. 11683/2021
                                   JUDGMENT
S. RAVINDRA BHAT, J.
Index I. Brief history of legislative changes and this court’s interpretation
..........................................................5 A. Provisions of the Income Tax Act, 1922
.....................................................................................................5 B. The new law: Income Tax Act,Assistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

1961 ...........................................................................................................8 C. The judgment in Surat
Art Silk ..................................................................................................................11 D. Relevant
changes brought about to the IT Act, 1961 (Finance Act, 1983 and 1991) ...............................17 E. The
judgment in Thanthi Trust..................................................................................................................18
F. Deletion of certain exemptions: Section 10 (20A) and Section 10 (23)
...................................................20 G. Amendments to Section 2 (15) by Finance Act, 2008 (w.e.f.
01.04.2009) ................................................21 II. Submissions of parties
.................................................................................................................................22 A. Arguments on
behalf of the revenue..........................................................................................................22 B.
Arguments of the assessee-organizations
.................................................................................................26 C. Revenue’s rebuttal
arguments...................................................................................................................54 III. Analysis
and reasoning ...............................................................................................................................55 A.
Aids to interpretation
................................................................................................................................62
(i) History of the legislation
..................................................................................................................62
(ii) Other extrinsic aids to construction of the statute
............................................................................63 B. Interpretation of Section 2(15), the definition
clause ...............................................................................70 Summation of interpretation of Section
2(15) ...............................................................................................85 C. Sections 10, 11, 12, 12A, 12AA
and 13 of the IT Act ................................................................................86 Distinction between
business held under Trust [Section 11(4)] and Trust carrying on business [Section 11(4A)] 87 D.
What kinds of income or receipts may not be characterized as derived from trade, commerce,
business or in relation to such activities, for a consideration
.........................................................................................98
(i) Statutory corporations, authorities or bodies
...................................................................................98
(ii) Statutory regulatory bodies/authorities
..........................................................................................109
(iii) Trade Promotion bodies, councils, associations or
organizations..................................................114
(iv) Non-statutory bodies - ERNET, NIXI and GS1 India
...................................................................116
(v) State Cricket Associations..............................................................................................................122Assistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

(vi) Private trusts
...................................................................................................................................135 IV. Summation
of conclusions ........................................................................................................................141 A.
General test under Section 2(15)
............................................................................................................141 B. Authorities, corporations,
or bodies established by statute....................................................................142 C. Statutory regulators
................................................................................................................................143 D. Trade
promotion bodies ..........................................................................................................................144 E.
Non-statutory bodies
...............................................................................................................................144 F. Sports
associations..................................................................................................................................145 G.
Private Trusts
..........................................................................................................................................145 H.
Application of
interpretation...................................................................................................................146
1. Leave granted in all matters where leave has not already been granted. C.A. No. 21762/2017
(Assistant Commission of Income Tax, Exemptions v. Ahmedabad Urban Development Authority) is
taken as the lead matter.
2. Religious and charitable trusts have existed in one form or the other, tracing their origins to the
instinct of benevolence, which is part of human nature. Indian philanthropy has enriched its
cultural heritage, particularly in catering to the educational, medical, socio-economic, and religious
needs of the people. Here its role has been supplementary to the efforts of the State, which has
recognized the public utility of this impulse, and granted tax exemptions. Indian income-tax laws
have favoured charities, even granted preferential treatment since 1886. The law, while granting
exemption to income from religious and charitable trusts has taken effective measures to minimise
misuse of trust funds. As a result, a charitable trust loses tax exemption if certain provisions are not
complied with, and if its activities do not fall under Section 10 of the Act. Such trusts also have to
apply their income to the charitable objects within a specified period, maintain proper audited
accounts, and invest or utilise funds in a manner so that no benefit is derived by the settlor, trustees,
their relatives, or other persons.1
3. The scope and amplitude of the definition “charitable purpose” under the Income Tax Act, 1961
(hereafter “Income Tax Act" or “the IT Act”) has engaged the courts’ (including that of this court)
attention on myriad occasions. The expression “not involving the carrying on of any activity for
profit” in the last limb of the definition [Section 2(15) prior to amendment by Finance Act, 1983]
was the subject of debate in no less than five judgments of this court (including that of a
five-member bench).
4. In these batch of appeals and special leave petitions, the primary question which falls for
consideration is the correct interpretation of the proviso to Section Sections 11, 12, 12-A and 13 of
the Income-tax Act, 1961.Assistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

2(15)2 of the IT Act introduced by amendment w.e.f. 01.04.2009. It is necessary, at this stage, to
notice that the IT Act visualized three kinds of charitable purposes: medical relief, education, and
relief for the poor – which are described hereafter as “per se purposes”. To this list, Parliament has,
by amendments, added other categories, such as preservation of environment (including
watersheds, forests, and wildlife) and preservation of monuments or places or objects of artistic or
historic interest, and yoga. The last – or the residual purpose included by the definition - is
“advancement of any other object of general public utility” (hereafter referred to as “GPU category”),
which is the subject of interpretation in the present case.
5. The Director General of Income Tax for exemptions, Commissioner of Income Tax (“CIT”) in
various states, and other officials of the Income tax department (hereafter compendiously referred
to as “the revenue”) have appealed the decisions of various High Courts, which have held that the
carrying on of any trade, commerce, or business, is not a per se bar or disqualification for a GPU
category charitable trust to claim to be such, precluding its tax-exempt status under the IT Act.
I. Brief history of legislative changes and this court’s interpretation A. Provisions of the Income Tax
Act, 1922
6. The provisions of the erstwhile Income Tax Act, 1922 (hereafter “the old Act”) enabled tax
exemption claims by trusts for their income from business activity, provided trusts were created
thereon. The Privy Council in The Trustees “charitable purpose” includes relief of the poor,
education, medical relief, preservation of environment (including watersheds, forests and wildlife)
and preservation of monuments or places or objects of artistic or historic interest, and the
advancement of any other object of general public utility:
Provided that the advancement of any other object of general public utility shall not
be a charitable purpose, if it involves the carrying on of any activity in the nature of
trade, commerce or business, or any activity of rendering any service in relation to
any trade, commerce or business, for a cess or fee or any other consideration,
irrespective of the nature of use or application, or retention, of the income from such
activity:..…” (emphasis supplied) of Tribune Press, Lahore v. CIT, Punjab3 (hereafter
“In Re: Trustees of the Tribune”) held that the income of the Tribune Press fell within
section 4(3)(i) of the old Act, and it was implied that income from the press was
derived from property held under trust to maintain a newspaper, to keep up its
liberal policy and to devote surplus funds to improve the newspaper. The word
“property” occurring under section 4(3)(i) of that Act was also held4 to include a
business too. The old Act was amended twice with the object of eliminating and
getting rid of tax exemptions for trusts, which were otherwise eligible for it. The first
amendment of 1939 inserted5 a new clause (ia) in the then existing provision. This
provided that income derived from business carried on by or on behalf of a charitable
trust or religious institution could be limited to only such business income as was
derived by the trust or institution from business carried on either in the course of the
carrying on of a trust’s primary purpose, or carried on mainly by the beneficiaries of
the trust or institution. The Lahore High Court in Charitable Gadodia SwadeshiAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

Stores v. CIT6, observed:
“Viewed in its proper perspective, therefore, clause (ia) can be taken to apply only
such business as is carried on behalf of religious or (1939) 7 ITR 415 (hereafter “In
Re: Trustees of the Tribune”).
In Commissioner of Income Tax v. P. Krishna Warriar, (1964) 8 SCR 36 : (1964) 53 ITR 176 this
court, citing and relying on In re, Trustees of the Tribune [(1939) ITR 415 PC] held that:
“This Court in J.K. Trust, Bombay v. Commissioner of Income Tax, Excess Profits
Tax, Bombay [(1957) 32 ITR 535] endorsed the said view and held that “property” is a
term of the widest import and that business would undoubtedly be property unless
there was something to the contrary in the enactment. If business was property, it
could be held under trust for religious and charitable purposes. As the business of
running the Arya Vaidya Sala vested under trust for religious and charitable
purposes, it would fall under clause (i), if the other conditions laid down therein were
satisfied.” Section 4(3) of the Indian Income-tax (Amendment) Act, 1939, reads as
follows:
“(3) Any income, profits or gains falling within the following classes shall not be
included in the total income of the person receiving them:]
(i) Subject to the provisions of clause (c) of sub-section (1) of section 16, any income
derived from property held under trust or other legal obligation wholly for religious
or charitable purposes, in so far as such income is applied or accumulated for
application to such religious or charitable purposes as relate to anything done within
the taxable territories, and in the case of property so held in part only for such
purposes, the income applied or finally set apart for application thereto:
(ia) Any income derived from business carried on on behalf of a religious or
charitable institution when the income is applied solely to the purposes of the
institution and-
(a) the business is carried on in the course of the carrying out of a primary purpose of
the institution, or
(b) the work in connection with the business is mainly carried on by beneficiaries of
the institution” (1944) 12 ITR 385 charitable institutions which were not held under
trust and not to such business as was itself held under trust or was conducted by or
on behalf of such charitable or religious institutions as were held under trust. If it was
intended to narrow down the scope of clause (1) so as to withdraw the exemption
enjoyed by a business held under trust or conducted by or on behalf of a religious or
charitable trust, the new clause should have been added as proviso to the old clause.”Assistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

7. The Act was again amended by the Finance Act, 19537 wherein clause (ia) was deleted from
section 4(3)(i) of the old Act and instead inserted as its proviso. Parliamentary intent, in
transforming old clause (ia) into a proviso to Section 4 (3)(i) was that whenever business was
carried on behalf of a religious or charitable institution, the conditions prescribed in clause (b) of
proviso to clause (i) had to be satisfied in addition to the general condition of exemption set out in
the substantive part of clause (i). Parliament’s attempt to exempt income from business activity
upon complying with other conditions - apart from those laid down in clause (i) - was interpreted by
this court in CIT v. P. Krishna Warriar8 (hereafter “Krishna Warriar”). The court observed that:
“The legal position may briefly be stated thus: Clause (i) of section 4(3) of the Act
takes in every property or a fractional part of it held in trust wholly for religious or
charitable purposes. It also takes in such property held only Section 4 of Finance Act,
1953 added proviso to Section 4(3)(i); it reads as follows:
“Provided that such income shall be included in the total income— [(a) if it is applied
to religious or charitable purposes without the taxable territories, but in the following
cases, namely:—
(i) where the property is held under trust or other legal obligation created before the
commencement of the-Indian Income-tax (Amendment) Act, 1953 (XXV of 1953),
and the income therefrom is applied to such purposes without the taxable territories;
and
(ii) where the property is held under trust or other legal obligation created after such
commencement, and the income therefrom is applied without the taxable territories
to charitable purposes which tend to promote international welfare in which India is
interested, the Central Board of Revenue may, by general or special order, direct that
it shall not be included in the total income;]
(b) in the case of income derived from business carried on on behalf of a religious or
charitable institution, unless the income is applied wholly for the purposes of the
institution and either—
(i) the business is carried on in the course of the actual carrying out of a primary
purpose of the institution, or
(ii) the work in connection with the business is mainly carried on by beneficiaries of
the institution;
(c) if it is applied to purposes other than religious or charitable purposes or ceases to
be accumulated or set apart for application thereto in which case it shall be deemed
to be the income of the year in which it is so applied or ceases to be so accumulated or
set apart.]” (1964) 8 SCR 36: (1964) 53 ITR 176 in part for such purposes. Business is
also property within the meaning of said clause. Clause (b) of the proviso to sectionAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

4(3)(i) applies only to business not held in trust but carried on on behalf of religious
or charitable institutions.”
8. The old Act defined ‘charitable purpose’ under Section 4(3) - i.e., the definition as it stood just
prior to the IT Act, 1961 coming into force (thereby replacing the old Act) - as follows:
“4 (3) Any income, profits or gains falling within the following classes shall not be
included in the total income of the person receiving them *** In this sub-section
“charitable purpose” includes relief of the poor, education, medical relief and the
advancement of any other object of general public utility, but nothing contained in
clause (i) or clause (ii) shall operate to exempt from the provisions of this Act that
part of the income from property held under a trust or other legal obligation for
private religious purposes which does not enure for the benefit of the public.” This
court had occasion to interpret the meaning of the expression “advancement of any
other object of general public utility” in CIT v. Andhra Chamber of Commerce9. The
court considered previous decisions in: In Re: Trustees of the Tribune (supra) and All
India Spinners Association of Mirzapur v. CIT10. Relying heavily on the decision of
the Privy Council in In Re: Trustees of the Tribune (supra), this court held, in Andhra
Chamber of Commerce that GPU objects included all objects promoting welfare of
general public, including taking steps to oppose or urge legislation affecting trade,
commerce, etc. B. The new law: Income Tax Act, 1961
9. Section 2 (15) of the IT Act (which came into force on 01.04.1962 and repealed the old IT Act)
defined “charitable purpose” as follows:
“(15) ― charitable purpose includes relief of the poor, education, medical relief, and
the advancement of any other object of general public utility not involving the
carrying on of any activity for profit.” (1965) 1 SCR 565 (hereafter “Andhra Chamber
of Commerce”) (1944) 12 ITR 482 (hereafter “All India Spinners Association of
Mirzapur”)
10. The then Finance Minister, Mr. Morarji Desai, explained the rationale for the new definition on
the floor of Lok Sabha:
“The definition of ‘charitable purpose’ in that clause is at present so widely worded
that it can be taken advantage of even by commercial concerns which, while
ostensibly serving a public purpose, get fully paid for the benefits provided by them,
namely, the newspaper industry which while running its concern on commercial line
can claim that by circulating newspapers it was improving the general knowledge of
the public. In order to prevent the misuse of this definition in such cases, the Select
Committee felt that the words ‘not involving the carrying on of any activity for profit’
should be added to the definition.”11Assistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

11. The first major decision to interpret the new definition was Sole Trustee, Lok Shikshana Trust v.
Commissioner of Income Tax12 (hereafter “Lok Shikshana Trust”). This court turned down a
contention that newspaper business, carried on with several other objects (which included setting
up of educational institutions, dissemination of knowledge to the Kannada speaking public through
newspaper, etc.) was charitable. The court noticed the changed definition:
“7.…The result thus of the change in the definition is that in order to bring a case
within the fourth category of charitable purpose, it would be necessary to show that
(1) the purpose of the trust is the advancement of any other object of general public
utility, and (2) the above purpose does not involve the carrying on of any activity for
profit. Both the above conditions must be fulfilled before the purpose of the trust can
be held to be charitable purpose.
***
9. It is true that there are some business activities like mutual insurance and
co-operative stores of which profit-making is not an essential ingredient, but that is
so because of a self-imposed and innate restriction on making profit in the carrying
on of that particular type of business. Ordinarily profit motive is a normal incidence
of business activity and if the activity of a trust consists of carrying on of a business
and there are no restrictions on its making profit, the court would be well justified in
assuming in the absence of some indication to the contrary that the object of the trust
involves the carrying on of an activity for profit…….. By the use of the expression
‘profit motive’ it is not intended that profit must in fact be earned. Nor does the
expression cover a mere desire to make some monetary gain out of a transaction or
even a series (LVI) Lok Sabha Debates., 32nd scs., p. 3073 (August 18, 1961).
(1976) 1 SCC 254 (hereafter “Lok Shikshana Trust”) of transactions. It predicates a motive which
pervades the whole series of transactions effected by the person in the course of his activity….” The
court also rejected the submission that the “profit” referred to meant private profit. It held that the
term had to be interpreted without qualification.
12. One of the judges - Beg, J, concurred with the majority, but after noticing that the trust deed did
not contain any condition on profit-making, expressed a slightly different view emphasizing that the
actual activity needs to be considered, rather than the absence or existence of any condition, in the
trust deed.
13. The next decision of importance is Indian Chamber of Commerce v. CIT13. The
appellant-chamber was a company registered under Section 25 of the Indian Companies Act, 1913.
Its memorandum and articles of association stipulated certain broad objects, which this court
agreed fell within the expression “the advancement of any … object of general public utility” in
Section 2(15) of the Act. The objects were “promotional and protective of Indian trade interests and
other allied service operations”. A residual clause authorised the chamber “to do all other things as
may be conducive to the development of trade, commerce and industries or incidental to attainmentAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

of the above objects or any of them”. As per clauses (4) and (8) of the memorandum of association,
the chamber’s member could not stand to gain personally since no portion of “income and property
of the association shall be paid … directly or indirectly, by way of dividend or bonus or otherwise
howsoever by “way of profit to the persons who at any time are ... members of the Association ....”
On dissolution of the association, the members could not claim any share in the assets. The
chamber, conceded before this court, that it “by and large, strives to advance the general trade
interests of India and Indian without seeking to make profits for its members.” This court denied the
exemption claimed, holding that:
“14… The attainment of that object shall not involve activities for profit. What then is
an activity for profit? An undertaking by a business organisation is ordinarily
assumed to be for profit unless expressly or by necessary (1976) 1 SCC 324 (hereafter
“Indian Chamber of Commerce”) implication or by eloquent surrounding
circumstances the making of profit stands loudly negatived. We will illustrate to
illumine. If there is a restrictive provision in the bye-laws of the charitable
organisation which insists that the charges levied for services of public utility
rendered are to be on a ‘no profit” basis, it clearly earns the benefit of Section 2(15).
For instance, a funeral home, an S.P.C.A. or a cooperative may render services to the
public but write a condition into its constitution that it shall not charge more than is
actually needed for the rendering of the services, — maybe it may not be an exact
equivalent, such mathematical precision being impossible in the case of variables, —
maybe a little surplus is left over at the end of the year — the broad inhibition against
making profit is a good guarantee that the carrying on of the activity is not for profit.
As an antithesis, take a funeral home or an animal welfare organisation or a super
bazaar run for general public utility by an institution which charges large sums and
makes huge profits.
Indubitably they render services of general public utility. Their objects are charitable but their
activities are for profit… **********
16. To sum up, Section 2(15) excludes from exemption the carrying on of activities for profit even if
they are linked with the objectives of general public utility, because the statute interdicts, for
purposes of tax relief, the advancement of such objects by involvement in the carrying on of
activities for profit. We appreciate the involved language we use, but when legislative draftsmanship
declines to be simple, interpretative complexity becomes a judicial necessity.
**********
21. The true test is to ask for answers to the following questions: (a) Is the object of the assessee one
of general public utility? (b) Does the advancement of the object involve activities bringing in
moneys? (c) If so, are such activities undertaken (i) for profit or (ii) without profit? Even if (a) and
(b) are answered affirmatively, if (c)(i) is answered affirmatively, the claim for exemption collapses.
The solution to the problem of an activity being one for or irrespective of profit is gathered on a
footing of facts. What is the real nature of the activity? One which is ordinarily carried on byAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

ordinary people for gain? Is there a built-in prescription in the constitution against making a profit?
Has there been in practice, profit from this venture? Although, this last is a weak test. The mere fact
that a service is rendered is no answer to chargeability because all income is often derived by
rendering some service or other.” C. The judgment in Surat Art Silk
14. The judgment by a larger, five-judge Bench, in Assistant Commissioner v. Surat Art Silk Cloth
Manufacturers’ Association14 (hereafter “Surat Art Silk”) was the most important decision rendered
on the issue. Here a Section 25 (of the Companies Act, 1956 corresponding to Section 8 of the
Companies Act, 2013) (1980) 2 SCC 31 (hereafter “Surat Art Silk”) non-profit company was
established. It claimed exemption as an institution with charitable purposes as its objectives. The
objects of the company included promoting commerce and trade in Art Silk yarn, raw silk, cotton
yarn, Art Silk cloth, silk cloth, and cotton cloth, among other objects15.Clause 5(1) of the company’s
memorandum provided that its income and property wheresoever derived was to be applied “solely
for the promotion of its objects as set forth in the Memorandum”; Clause 5(2) directed that no
portion of the income or property could be paid or transferred, directly or indirectly, by way of
dividend, bonus, or otherwise by way of profit, to persons, who at any time are or had been members
of the assessee. The Income Tax Appellate Tribunal (hereafter “ITAT”) after initial remand to the
Appellate Commissioner, held that “the primary purpose for which the assessee was established was
to promote commerce and trade in Art Silk and Silk Yarn and Cloth”. The ITAT made a direct
reference of the issue, to this court, since a conflict existed with regard to the correct interpretation
of the residual clause, i.e., institutions engaged in the advancement of objects of general public
utility, and whether the company was entitled to be assessed as one carrying on activities that
amounted to charitable purposes. This court first determined that the primary or dominant object of
the company was promotion and development of trade in silk, silk cloth, yarn and other such items
and that the other objects were subsidiary to this primary object. It then held that the requirement
of absence of profit motive, was satisfied:
“7...but this requirement was also satisfied in the case of the assessee, because the
object of private profit was eliminated by the recognition of the The list of objects
were as follows:
“(a) To promote commerce and trade in Art Silk Yarn, Raw Silk, Cotton Yarn, Art Silk
Cloth, Silk Cloth and Cotton Cloth.
(b) To carry on all and any of the business of Art Silk Yarn, Raw Silk, Cotton Yarn as
well as Art Silk Cloth, Silk Cloth and Cotton Cloth belonging to and on behalf of the
members.
(c) To obtain import licences for import of Art Silk Yarn, Raw Silk, Cotton Yarn and
other raw materials as well as accessories required by the members for the
manufacture of Art Silk, Silk and Cotton Fabrics.
(d) To obtain export licences and export cloth manufactured by the members.Assistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

(e) To buy and sell and deal in all kinds of cloth and other goods and fabrics
belonging to and on behalf of the members.
(n) To do all other lawful things as are incidental or conducive to the attainment of
the above objects.” assessee under section 25 of the Companies Act, 1956 and clauses
5 and 10 of its Memorandum. It must, therefore, be held that the income and
property of the assessee were held under a legal obligation for the purpose of
advancement of an object of general public utility within the meaning of section 2
clause (15).”
15. This court then held that the words of prohibition occurring at the end of Section 2(15) were
applicable to the last category of charitable institutions, i.e., those involved in the advancement of
objects of general public utility. It further clarified that the prohibition applied to the object and not
the advancement or attainment of the said object:
“10a. It is clear on a plain natural construction of the language used by the legislature
that the ten crucial words “not involving the carrying on of any activity for profit” go
with “object of general public utility” and not with “advancement”. It is the object of
general public utility which must not involve the carrying on of any activity for profit
and not its advancement or attainment. What is inhibited by these last ten words is
the linking of activity for profit with the object of general public utility and not its
linking with the accomplishment or carrying out of the object. It is not necessary that
the accomplishment of the object or the means to carry out the object should not
involve an activity for profit. That is not the mandate of the newly added words. What
these words require is that the object should not involve the carrying on of any
activity for profit. The emphasis is on the object of general public utility and not on
its accomplishment or attainment. The decisions of the Kerala and Andhra Pradesh
High Courts in CIT v. Cochin Chamber of Commerce and Industry [(1973) 87 ITR 83
: (Ker) 16 and A.P. State Road Transport Corporation v. CIT [(1975) 100 ITR 392
(AC)], in our opinion lay down the correct interpretation of the last ten words in
Section 2 clause(15). The true meaning of these last ten words is that when the
purpose of a trust or institution is the advancement of an object of general public
utility, it is that object of general public utility and not its accomplishment or carrying
out which must not involve the carrying on of any activity for profit.”
16. The court then went on to hold what is meant by “not involving the carrying on an activity for
profit”:
“15. …The question that is necessary to be asked for this purpose is as to when can the
purpose of a trust or institution be said to involve the carrying on of any activity for
profit. The word “involve” according to the Shorter Oxford Dictionary means “to
enwrap in anything, to enfold or envelop; to contain or imply”. The activity for profit
must, therefore, be intertwined or wrapped up with or implied in the purpose of the
trust or institution or in other words it must be an integral part of such purpose. ButAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

the question again is what do we understand by these verbal labels or formulae; what
is it This decision was reversed in Indian Chamber of Commerce v. Commissioner of
Income Tax (1976) 1 SCC 324 precisely that they mean? Now there are two possible
ways of looking at this problem of construction. One interpretation is that according
to the definition what is necessary is that the purpose must be of such a nature that it
involves the carrying on of any activity for profit in the sense that it cannot be
achieved without carrying on an activity for profit. On this view, if the purpose can be
achieved without the trust or institution engaging itself in an activity for profit, it
cannot be said that the purpose involves the carrying on of an activity for profit…
****************** **************
16. The other interpretation is to see whether the purpose of the trust or institution in
fact involves the carrying on of an activity for profit or in other words whether an
activity for profit is actually carried on as an integral part of the purpose or to use the
words of Chandrachud, J, as he then was in Dharmodayam case [(1977) 4 SCC 75] ,
“as a matter of advancement of the purpose”. There must be an activity for profit and
it must be involved in carrying out the purpose of the trust or institution or to put it
differently, it must be carried on in order to advance the purpose or in the course of
carrying out the purpose of the trust or institution. It is then that the inhibition of the
exclusionary clause would be attracted. This appears to us to be a more plausible
construction which gives meaning and effect to the last concluding words added by
the legislature and we prefer to accept it. Of course, there is one qualification which
must be mentioned here and it is that if the constitution of a trust or institution
expressly provides that the purpose shall be carried out by engaging in an activity
which has a predominant profit motive, as, for example, where the purpose is
specifically stated to be promotion of sports by holding cricket matches on
commercial lines with a view to making profit, there would be no scope for
controversy, because the purpose would, on the face of it, involve carrying on of an
activity for profit and it would be non-charitable even though no activity for profit is
actually carried on or, in the example given, no cricket matches are in fact organised.
17. The next question that arises is as to what is the meaning of the expression
“activity for profit”. Every trust or institution must have a purpose for which it is
established and every purpose must for its accomplishment involve the carrying on of
an activity. The activity must, however, be for profit in order to attract the
exclusionary clause and the question therefore is when can an activity be said to be
one for profit? The answer to the question obviously depends on the correct
connotation of the preposition “for”. This preposition has many shades of meaning
but when used with the active participle of a verb it means “for the purpose of” and
connotes the end with reference to which something is done. It is not therefore
enough that as a matter of fact an activity results in profit but it must be carried on
with the object of earning profit. Profit-making must be the end to which the activity
must be directed or in other words, the predominant object of the activity must be
making a profit. Where an activity is not pervaded by profit motive but is carried onAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

primarily for serving the charitable purpose, it would not be correct to describe it as
an activity for profit. But where, on the other hand, an activity is carried on with the
predominant object of earning profit, it would be an activity for profit, though it may
be carried on in advancement of the charitable purpose of the trust or institution.
Where an activity is carried on as a matter of advancement of the charitable purpose
or for the purpose of carrying out the charitable purpose, it would not be incorrect to
say as a matter of plain English grammar that the charitable purpose involves the
carrying on of such activity, but the predominant object of such activity must be to
subserve the charitable purpose and not to earn profit. The charitable purpose should
not be submerged by the profit making motive; the latter should not masquerade
under the guise of the former….”
17. The court took note of the judgment of Pathak, J. in Dharmadeepti v. CIT17 as well as the speech
of then then Finance Minister, and further observed:
“17. ….It is obvious that the exclusionary clause was added with a view to overcoming
the decision of the Privy Council in the Tribune case [AIR 1939 PC 208: In Re the
Trustees of the Tribune, (1939) 7 ITR 415] where it was held that the object of
supplying the community with an organ of educated public opinion by publication of
a newspaper was an object of general public utility and hence charitable in character,
even though the activity of publication of the newspaper was carried on commercial
lines with the object of earning profit. The publication of the newspaper was an
activity engaged in by the trust for the purpose of carrying out its charitable purpose
and on the facts it was clearly an activity which had profit making as its predominant
object, but even so it was held by the Judicial Committee that since the purpose
served was an object of general public utility, it was a charitable purpose. It is clear
from the speech of the Finance Minister that it was with a view to setting at naught
this decision that the exclusionary clause was added in the definition of “charitable
purpose”. The test which has, therefore, now to be applied is whether the
predominant object of the activity involved in carrying out the object of general
public utility is to subserve the charitable purpose or to earn profit. Where profit
making is the predominant object of the activity, the purpose, though an object of
general public utility, would cease to be a charitable purpose. But where the
predominant object of the activity is to carry out the charitable purpose and not to
earn profit, it would not lose its character of a charitable purpose merely because
some profit arises from the activity. The exclusionary clause does not require that the
activity must be carried on in such a manner that it does not result in any profit. It
would indeed be difficult for persons in charge of a trust or institution to so carry on
the activity that the expenditure balances the income and there is no resulting
profit…..
18. The court proceeded to quote from passages in its previous judgments, in Lok Shikshana Trust
and Indian Chamber of Commerce (supra) to the effect that if the activity of a trust consists of
carrying on a business and there are no restrictions on profit-making, the court could assume (in theAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

absence of something to the contrary) that the trust’s object involved carrying on of an (1978) 3 SCC
499 activity for profit. The Constitution Bench disagreed with the approach in both the previous
judgments, and observed:
“19. …Now we entirely agree with the learned Judges who decided these two cases
that activity involved in carrying out the charitable purpose must not be motivated by
a profit objective but it must be undertaken for the purpose of advancement or
carrying out of the charitable purpose. But we find it difficult to accept their thesis
that whenever an activity is carried on which yields profit, the inference must
necessarily be drawn, in the absence of some indication to the contrary, that the
activity is for profit and the charitable purpose involves the carrying on of an activity
for profit. We do not think the Court would be justified in drawing any such inference
merely because the activity results in profit. It is in our opinion not at all necessary
that there must be a provision in the constitution of the trust or institution that the
activity shall be carried on no profit no loss basis or that profit shall be proscribed.
Even if there is no such express provision, the nature of the charitable purpose, the
manner in which the activity for advancing the charitable purpose is being carried on
and the surrounding circumstances may clearly indicate that the activity is not
propelled by a dominant profit motive. What is necessary to be considered is whether
having regard to all the facts and circumstances of the case, the dominant object of
the activity is profit making or carrying out a charitable purpose. If it is the former,
the purpose would not be a charitable purpose, but, if it is the latter, the charitable
character of the purpose would not be lost.
20. If we apply this test in the present case, it is clear that the activity of obtaining
licences for import of foreign yarn and quotas for purchase of indigenous yarn, which
was carried on by the assessee, was not an activity for profit. The predominant object
of this activity was promotion of commerce and trade in Art Silk Yarn, Raw Silk,
Cotton Yarn, Art Silk Cloth, Silk Cloth and Cotton Cloth, which was clearly an object
of general public utility and profit was merely a bye-product which resulted
incidentally in the process of carrying out the charitable purpose. It is significant to
note that the assessee was a Company recognised by the Central Government under
Section 25 of the Companies Act, 1956 and under its Memorandum of Association,
the profit arising from any activity carried on by the assessee was liable to be applied
solely and exclusively for the promotion of trade and commerce in various
commodities which we have mentioned above and no part of such profit could be
distributed amongst the members in any form or under any guise. The profit of the
assessee could be utilised only for the purpose of feeding this charitable purpose and
the dominant and real object of the activity of the assessee being the advancement of
the charitable purpose, the mere fact that the activity yielded profit did not alter the
charitable character of the assessee. We are of the view that the Tribunal was right in
taking the view that the purpose for which the assessee was established was a
charitable purpose within the meaning of Section 2 clause (15) and the income of the
assessee was exempt from tax under Section 11. The question referred to us in each ofAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

these references must, therefore, be answered in favour of the assessee and against
the Revenue.”
19. There was, however, a discordant note in Surat Art Silk - A.P. Sen, J disagreed with the majority,
and delivered a dissenting opinion. Explaining how there were no restrictive words or conditions,
under the old IT Act, the learned judge held that the approach indicated in Lok Shikshana Trust and
Indian Chamber of Commerce were correct. He felt that the previous decisions of the court were not
relevant, and that if the activities of a trust involved any activity for profit or business, the
organization ceased to be charitable, and that such proceeds were utilized for charitable objects,
were not relevant. He also noted that “A reading of Section 2(15) and Section 11 together shows that
what is frowned upon is an activity for profit by a charity established for advancement of an object of
general public utility in the course of accomplishing its objects.” The same judgment also stated
that:
“if the object of the trust is advancement of an object of general public utility and it
carried on any activity for profit, it is excluded from the ambit of charitable purpose
defined in Section 2(15). The distinction is clearly brought out by the provision
contained in Section 13(1)(bb) inserted by Tax Laws (Amendment) Act, 1975.” D.
Relevant changes brought about to the IT Act, 1961 (Finance Act, 1983 and 1991)
20. It is pertinent to note that the judgment in Surat Art Silk was delivered on 19.11.1979. The
expression “not involving the carrying on of any activity for profit” in Section 2(15) of the IT Act, was
omitted by the Finance Act, 1983, w.e.f. 01.04.1984. Prior to this, w.e.f. 01.04.1977 the following
restrictive condition had been inserted18 as clause (bb), to Section 13(1)19:
“(bb) in the case of a charitable trust or institution for the relief of the poor, education
or medical relief, which carries on any business, any income Through the Taxation
Laws Amendment Act, 1975.
Section 13 - Section 11 not to apply in certain cases.
derived from such business, unless the business is carried on in the course of the
actual carrying out of a primary purpose of the trust or institution” This provision
had the effect of excluding or excepting the operation of Section 11 (which deemed
certain receipts of charitable institutions not to be part of their income). The
restrictive condition in clause (bb) was also omitted by the Finance Act, 1983, w.e.f.
01.04.1984.
21. Below Section 11(4)20 (as it originally stood in the IT Act, 1961), Section 11(4A)21
was inserted by the Finance Act, 1983, w.e.f. 01.04.1984. Subsequently, Section
11(4A) was amended and substituted by the following provision w.e.f. 01.04.1992
(and continues to be in force):Assistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

“(4A) Sub-section (1) or sub-section (2) or sub-section (3) or sub-section (3A) shall
not apply in relation to any income of a trust or an institution, being profits and gains
of business, unless the business is incidental to the attainment of the objectives of the
trust or, as the case may be, institution, and separate books of account are
maintained by such trust or institution in respect of such business.” E. The judgment
in Thanthi Trust
22. This court comprehensively interpreted these provisions as they existed, in
different time periods, in Assistant Commissioner of Income Tax v. Thanthi Trust22
where this court had to decide whether the assessee trust, created for establishing a
newspaper “as an organ of educated public opinion for the Tamil Section 11(4) as
originally enacted, reads as follows:
“For the purposes of this section ‘property held under trust’ includes a business
undertaking so held, and where a claim is made that the income of any such
undertaking shall not be included in the total income of the persons in receipt
thereof, the Income Tax Officer shall have power to determine the income of such
undertaking in accordance with the provisions of this Act relating to assessment; and
where any income so determined is in excess of the income as shown in the accounts
of the undertaking, such excess shall be deemed to be applied to purposes other than
charitable or religious purposes.” Earlier, sub-section (4A) was inserted by the
Finance Act, 1983, w.e.f. 01.04.1984, and read as follows:
“(4A) Sub-section (1) or sub-section (2) or sub-section (3) or sub-section (3A) shall
not apply in relation to any income of a trust or an institution, being profits and gains
of business, unless
(a) the business is carried on by a trust wholly for public religious purposes and the
business consists of printing and publication of books or is of a kind notified by the
Central Government in this behalf in the Official Gazette;
(b) the business is carried on by an institution wholly for charitable purposes and the
work in connection with the business is mainly carried on by the beneficiaries of the
institution;
and separate books of accounts are maintained by the trust or institution in respect of such
business” (2001) 2 SCC 707; (2001) 1 SCR 727.
reading public and to disseminate news and to ventilate opinion upon all matters of public interest
through it.” could avail of tax exemption. In 1957, the settlor executed a supplementary deed making
the trust irrevocable. On 28.07.1961 another supplementary deed was executed which directed that
the trust’s surplus income (after defraying all expenses), should be devoted to purposes such as
establishing and running a school or college for the teaching of journalism; establishing and/or
running or helping to run schools, colleges or other educational institutions for teaching arts andAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

science; establishing of scholarships for students of journalism, arts and science; establishing
and/or running or helping to run hostels for students; establishing and/or running or helping to run
orphanages; and other educational purposes. The High Court held that exemption could be claimed
by the trust. The revenue appealed. This court noticed that the appeals covered three distinct
periods- (i) 1979-80 to 1983-84, (ii) 1984-85 to 1991-92, and (ii) 1992-93 to 1996-97. This court held
that for the first period (1979-80 to 1983-84), the activity of running a newspaper, and the corpus
held for it, by the trust, did not directly result in carrying on the educational activities mentioned in
the supplementary deeds. The income was found to only feed such activity, which was not the same
as carrying on in the course of actual accomplishment of the trust’s objects of education and relief of
poor, and thus not entitled to exemption. For the next period (1984-85 to 1991-92), noting that
Section 11(4) continued to be in existence [despite Section 11(4A) being inserted (as originally
enacted w.e.f. 01.04.1984)], dealing with the expression “property held under trust”, and held that:
“23....Trusts and institutions are separately dealt with in the Act (Section 11 itself and
sections 12, 12A and 13, for example). The expressions refer to entities differently
constituted. It is thus clear that the newspaper business that is carried on by the
Trust does not fall within sub-section (4A). The Trust is not only for public religious
purposes so it does not fall within clause (a). It is a Trust not an institution, so it does
not fall within clause (b). It must, therefore, be held that for the assessment years in
question the Trust was not entitled to the exemption contained in section 11 in
respect of the income of its newspaper.”
23. For the third period (1992-93 to 1996-97), the court dealt with the meaning and
effect of Section 11(4A) (amended and substituted w.e.f. 01.04.1992) and held that
the assessee trust was entitled to be treated as a charity:
“25. The substituted sub-section (4A) states that the income derived from a business
held under Trust wholly for charitable or religious purposes shall not be included in
the total income of the previous year of the Trust or institution if "the business is
incidental to the attainment of the objective of the Trust or, as the case may be,
institution" and separate books of account are maintained in respect of such
business. Clearly, the scope of sub-section (4A) is more beneficial to a Trust or
institution than was the scope of sub-
section (4A) as originally enacted. In fact, it seems to us that the substituted sub-section (4A) gives
Trust or institution a greater benefit than was given by section 13(1)(bb). If the object of Parliament
was to give Trusts and institutions no more benefit than that given by section 13(1)(bb), the
language of section 13(1)(bb) would have been employed in the substituted sub-section (4A). As it
stands, all that it requires for the business income of a Trust or institution to be exempt is that the
business should be incidental to the attainment of the objectives of the Trust or institution. A
business whose income is utilized by the Trust or the institution for the purposes of achieving the
objectives of the Trust or the institution is, surely, a business which is incidental to the attainment of
the objectives of the Trust. In any event, if there be any ambiguity in the language employed, the
provision must be construed in a manner that benefits the assessee. The Trust, therefore, is entitledAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

to the benefit of section 11 for the assessment year 1992-93 and thereafter. It is, we should add, not
in dispute that the income of its newspaper business has been employed to achieve its objectives of
education and relief to the poor and that it has maintained separate books of account in respect
thereof.” (emphasis supplied) F. Deletion of certain exemptions: Section 10 (20A) and Section 10
(23)
24. Section 10(20A) had been inserted by the Finance Act, 1970, w.e.f. 01.04.1962; it exempted
certain classes of income earned by housing boards, etc., and before deletion read as follows:
“(20A) any income of an authority constituted in India by or under any law enacted
either for the purpose of dealing with and satisfying the need for housing
accommodation or for the purpose of planning, development or improvement of
cities, towns and villages, or for both;”
25. Similarly, Section 10(23)23 existed and provided exemption to income earned by
sport controlling boards, and associations, subject to specific conditions. Section
10(23) read as follows, before its deletion:
“(23) any income of an association or institution established in India which may be
notified by the Central Government in the Official Gazette having regard to the fact
that the association or institution has as its object the control, supervision, regulation
or encouragement in India of the games of cricket, hockey, football, tennis or such
other games or sports as the Central Government may, by notification in the Official
Gazette, specify in this behalf:”
26. Section 10(20A) and 10(23) were deleted/omitted by Finance Act, 2002, w.e.f.
01.04.2003. While both these provisions are not directly relevant for deciding the
primary question (i.e., as to what charitable purpose is, under Section
2 (15)), they still have an important bearing in the present case. This is because in view of the
circumstances that the provisions were deleted w.e.f. 01.04.2003, housing boards, and bodies, as
well as sports associations, that were earlier claiming exemption of their income under these
provisions, now sought to claim that they were charities.
G. Amendments to Section 2 (15) by Finance Act, 2008 (w.e.f. 01.04.2009)
27. Section 2(15) - which had been amended last, in 198324, was again amended, by Finance Act,
2008, w.e.f. 01.04.2009. Some other amendments too were made, with effect from the same date by
the Finance Act, 2009 and Finance Act, 2010. With the said amendments, as on 01.04.2009, the
provision read as follows:
(15) “charitable purpose” includes relief of the poor, education, medical relief,
[preservation of environment (including watersheds, forests and As amended by the
Direct Tax Laws (Amendment) Act, 1987, w.e.f. 01.04.1989; Direct Tax LawsAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

(Amendment) Act, 1989, w.e.f. 01.04.1989; substituted by the Direct Tax Laws
(Amendment) Act, 1989, w.e.f.
01.04.1990; and further amended by the Finance (No. 2) Act, 1991, w.r.e.f. 01.04.1990; Finance Act,
1992, w.r.e.f. 01.04.1990/w.e.f. 01.04.1992; and Finance Act, 2000, w.e.f. 1-4-2001.
Deletion of the expression “not involving the carrying on of any activity for profit” and the resulting
Section 2(15) read as follows:
““charitable purpose” includes relief of the poor, education, medical relief, and the
advancement of any other object of general public utility.” wildlife) and preservation
of monuments or places or objects of artistic or historic interest, and the
advancement of any other object of general public utility:
Provided that the advancement of any other object of general public utility shall not
be a charitable purpose, if it involves the carrying on of any activity in the nature of
trade, commerce or business, or any activity of rendering any service in relation to
any trade, commerce or business, for a cess or fee or any other consideration,
irrespective of the nature of use or application, or retention, of the income from such
activity:]” [Provided further that the first proviso shall not apply if the aggregate
value of the receipts from the activities referred to therein is [ten lakh rupees] or less
in the previous year;] In the second proviso, the reference to ten lakhs was
substituted, and the figure of rupees twenty-five lakhs, was inserted, by the Finance
Act, 2011 (w.e.f. 01.04.2012). By Finance Act, 2015 (w.e.f. 01.04.2016), the first two
provisos to Section 2(15) were deleted, and instead, the following proviso was
inserted:
“Provided that the advancement of any other object of general public utility shall not
be a charitable purpose, if it involves the carrying on of any activity in the nature of
trade, commerce or business, or any activity of rendering any service in relation to
any trade, commerce or business, for a cess or fee or any other consideration,
irrespective of the nature of use or application, or retention, of the income from such
activity, unless—
(i) such activity is undertaken in the course of actual carrying out of such
advancement of any other object of general public utility; and
(ii) the aggregate receipts from such activity or activities during the previous year, do
not exceed twenty per cent of the total receipts, of the trust or institution undertaking
such activity or activities, of that previous year;” Additionally, the same amendment
also inserted “yoga” (after “education”) as a listed category of charitable activity, in
the substantive provision.
II. Submissions of parties A. Arguments on behalf of the revenueAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

28. The learned Additional Solicitor General, Mr. N. Venkataraman (hereafter “ASG”) tracing the
genesis of Section 2(15) contended that the old IT Act contained no restrictive expressions
forbidding trade or business activities by charities. He argued that decisions in In Re: Trustees of
the Tribune, Andhra Chamber of Commerce and the decision in Krishna Warriar (supra) were in
light of Section 4(3) of the old Act; therefore, the contextual framework of this court’s decisions was
entirely different. Those decisions consequently did not rule out carrying on of activities akin to
business, by charitable institutions established to advance general public utility.
29. The ASG next submitted that Parliament’s intent, in changing the law, was to expressly forbid
the tax exemption benefit if the entity was “involved” in carrying on trade or business. The revenue
relied on the two decisions in Lok Shikshana Trust, and Indian Chamber of Commerce (supra),
highlighting that the significance of the change – brought about by Section 2(15) of the IT Act – was
noticed. Particular reliance was placed on the observations of Beg, J in Lok Shikshana Trust and the
passages in Indian Chamber of Commerce to urge that the involvement of an entity in the carrying
on of activities for profit, even if for advancement of charitable purpose or object, disentitled it to tax
exemption. The learned ASG urged that this court had recognized – from its earlier decisions – that
the prohibition from carrying on trade or commerce activities applied only to charities meant to
advance general public utility and not the other categories such as education, medical relief, or relief
to the poor (which are per se exempt).
30. The ASG submitted that the judgments in Indian Chamber of Commerce and Lok Shikshana
Trust (supra) were conscious of the generality of the GPU category which led Parliament to insert
the restrictive words "not involving the carrying on of any activity for profit”. It was argued that
Parliament amended the definition due to rampant abuse of the law by businesses claiming to be
driven by charitable purposes. Often, charities would be created merely to secure exemption from
tax, and would carry on large commercial activities, enjoying the profits. This led Parliament to
embed the exclusionary terms, depriving exemption if the institution otherwise fell under the GPU
category charity, but undertook activities for profit. The ASG relied on the Finance Minister's speech
in the House at the time of the introduction of the IT Act, and submitted that it outlines the
rationale for the restrictive condition noting that units run on commercial lines could claim that
some general public utility was promoted and claim exemption. The Select Committee of Parliament
(at that time), felt that to prevent misuse of the definition in such cases, the words “not involving the
carrying on of any activity for profit” should be added to the definition. ASG relied on Lok Shikshana
Trust (supra) which highlighted that this statement shed light on the new provision.
31. It was submitted that Indian Chamber of Commerce (supra) recognized this legislative history,
and also held that the interpretation of the provision had to be in tune with the advancement of the
object of the changed law. The court also was conscious that there were borderline cases which
posed difficulty in deciding ex facie whether the undertaking yielding profit is a “deceptive” device
or a bonafide venture resulting “in nominal surplus although substantially intended only to advance
the charitable object”. The court also held that the restrictive condition was a “term of art and
embraces objects of general public utility”. Yet, under the garb of charitable purposes, organisations
masking profit, sprang up. The mask was charitable, but the “heart was hunger for tax free profit”.
The revenue highlighted the following reasoning from this court’s judgment in Indian Chamber ofAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

Commerce (supra):
“by the new definition the benefit of exclusion from total income is taken away where
in accomplishing a charitable purpose the institution engages itself in activities for
profit. The Calcutta decisions are right in linking; activities for profit with
advancement of the object. If you want immunity from taxation, your means of
fulfilling charitable purposes must be unsullied by profit making ventures.”
32. It was then urged that before the decision in Surat Art Silk (supra) two legislative developments
took place, which reinforced the revenue’s view that charities cannot engage in commercial
activities. The first was the amendment, carried out in 1975 to the IT Act (w.e.f. 01.04.1976), which
introduced Section 10 (23C) and had the effect of excluding income received by inter alia, any fund
or institution, established for charitable purposes. The said provision, to the extent relevant, is
extracted as follows:
“10. In computing the total income of a previous year of any person, any income
falling within any of the following clauses shall not be included— ******* ********
“(23C) any income received by any person on behalf of-
(i) the Prime Minister' s National Relief Fund; or ******* ***** *****
(iv) any other fund or institution established for charitable purposes” The other
amendment was introduction of Section 13(1)(bb) (w.e.f. 01.04.1977) which imposed
conditions on the carrying on of business, by charitable institutions.
33. It was urged that the combined operation of Section 2(15), Section 10(23C) and Section 13(1)(bb)
meant that only charities which were set up for the purpose of “relief of the poor, education or
medical relief”, could claim exemption if they carried on business “in the course of actual carrying
out of a primary purpose of the trust or institution”. The studied omission of GPU category charities,
in Section 13(1)(bb) meant that if such trust or institutions carried on any business, even incidental
to their objects, they would not be entitled to exemption.
34. The ASG then contended that the decision in Surat Art Silk (supra) had the unintended
consequence of ignoring the significance of the addition of the expression “advancement of any
other object of general public utility not involving the carrying on of any activity for profit”. The
remedy intended by Parliament, in adding the said terms was to prevent charities (involved in the
carrying on of any activity for profit) from claiming exemption, and to ensure that purely charitable
activity-driven trusts or institutions, could claim exemption. It was submitted that the Constitution
Bench fell into error, in holding that as long as the ‘dominant’ objective of the charity was to
promote objects of general public utility, they were entitled to exemption.
35. The ASG further submitted that if the history of the provision, and the further amendments were
kept in mind, the question of permitting activities that had any business or trade, for consideration,
could not arise; however, by later amendments, GPU category charities have been permitted to carryAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

on activities in the nature of business, for consideration, or service in relation to business and
commerce, provided that is in the course of actually achieving the charitable object, and also that
income from such activities (i.e. business, etc.) does not exceed 20% of the total receipts.
36. It was submitted that statutory corporations, agencies, boards and authorities may trace their
origins to specific Central or State laws. However, if their activities are akin to or “in the nature of”
business, or trade, or they provide services to businesses or trade, for consideration, fee or even cess
(since they may be enabled to do so by law) they have to fulfil the mandate and restrictions under
Section 2(15), especially proviso (ii). The ASG cited the larger bench decision in New Delhi
Municipal Council v. State of Punjab25 (hereafter “NDMC”) to urge that state entities are not
exempt from Union taxation, if they engage in trade or business. It was furthermore submitted that
the effect of proviso (i) to Section 2(15) is that there can be no question of any incidental activity;
nor can the proceeds of trade claim to be exempt merely because they are ploughed back to feed the
charitable object.
B. Arguments of the assessee-organizations
37. Mr. S.N. Soparkar, learned Senior Advocate appeared for the Ahmedabad Urban Development
Authority (hereafter “AUDA”); the Gujarat Industrial Development Corporation (hereafter “GIDC”)
and Gujarat Housing Board (hereafter “GHB”). Counsel submitted that all three corporations were
established by or under statutes enacted by the Gujarat legislature; they were (1997) 7 SCC 339
(hereafter “NDMC”) treated as local authority under Section 10(20) of the IT Act, as it existed till
2003. Thereafter they were treated as charitable institutions engaged in activities involved in the
advancement of public utility till the amendment of 2008. Learned counsel highlighted that the
AUDA was created purely for the development and redevelopment - as well as for augmentation of
roads and allotment of lands after redevelopment, in the areas under its control. Relying upon the
provisions of the Act constituting AUDA26, he submitted that its mandate is to control development
activities, execution of works and dispersal of sewage, provisions of such other facilities and
generally engage in urban development in the areas it had jurisdiction over. He highlighted Section
40 of that Act and urged that the nature of activities, especially disposal of properties developed by
AUDA were entirely regulated. Whilst the lion’s shares of properties developed by AUDA were to be
allotted for housing and residence, and earmarked specifically for public amenities, roads etc., a
small percentage (15%) could be sold by public auction. It was submitted that the statutory model
adopted by AUDA was to enable it to function as a self-sustaining unit. The disposal of plots through
allotment and especially by public auction were the main modes through which it could generate
revenue. The entire revenue or income so generated was to be kept in a fund under Section 91; and
its accounts were mandatorily audited by the State’s Accountant General under Section 95.
38. It was argued that like AUDA, the GIDC too was also set up by virtue of a statute27, i.e. GIDA,
1962 for the purposes of securing and assisting rapid and orderly establishment and organisation of
industrial areas and estates in Gujarat, as well as establishing commercial centres for such industrial
areas and estates. Like AUDA, its accounts were audited by the Accountant General; the audited
report was to be laid before the State legislature (Section 26(4)) and the land developed by the GIDC
could be dealt with only in accordance with law, i.e., the Gujarat Town Planning and UrbanAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

Development Act, 1976 Gujarat Industrial Development Act, 1962 (referred to as “GIDA”)
regulations framed under the GIDA, its constituting enactment, further to Section 32(2). As far as
GHB is concerned, learned counsel submitted that like the other statutory corporations it was also
established by virtue of a special law 28. The functions of this Board were identical to that of AUDA
and its mandate is to regulate and develop building activities aimed for the purposes of providing
housing.
39. Learned counsel urged that none of the three boards carry on any business activity; their
functions are controlled by the parent enactments under which they were created. Furthermore, on
advancing of its affairs in such a manner that if any surpluses are generated, they were used for
furthering the objectives of law. Thus, for instance, if surplus is generated in the activities of AUDA,
GIDC, or GHB, those would not be handed to the State Government, which previously had control
over them but rather kept in a separate fund to be utilised for further development, expansion and
development activities by each of such corporations. These cannot be construed as carrying on any
trade, business or commerce.
40. It was submitted that the decisions in In Re: Trustees of the Tribune; Krishna Warriar and Lok
Shikshana Trust (supra) were all in the context of entities which carried on business. Moreover, in
the first two decisions, the law as it then stood did not contain any restriction prohibiting trade or
commerce activity. Learned counsel submitted that the judgment in Indian Chamber of Commerce
(supra) was specifically overruled in Surat Art Silk (supra). Therefore, it may be treated as having no
precedential value on subject. Learned counsel highlighted the observations in Surat Art Silk (supra)
and submitted that as long as the activities involved are mainly charitable and for advancement of
public utility, its purposes are deemed to be charitable even if it carries on some business or
trade-like activities for the purpose of generating income. What is important, it was argued, is
whether the main or dominant purpose of business or activity is Gujarat Housing Board Act, 1961.
motivated by profit. In such cases, the entity is debarred from claiming that it is a charity and cannot
claim the benefit of tax exemption. Therefore, what is to be understood from the ratio in Surat Art
Silk (supra) is that the main purpose or principal objective or motivation for the activity should not
be to carry on trade or business. It should be to advance the purpose of general public utility. If such
a purpose is fulfilled, the carrying on of some activity which might result in surplus, would not
disentitle the entity from the benefit of tax exemption.
41. Learned counsel then made a brief reference to the judgment in CIT, Bombay v. Bar Council of
Maharashtra29 arguing that Surat Art Silk (supra) was followed in this decision. He also cited
Thanthi Trust (supra). Counsel highlighted that the object of the assessee there, was charitable and
required that the business ought to be carried out for the purposes of achieving the charitable
purpose. Having regard to the nature of Section 13(1)(bb), which existed for the relevant period, the
court held that the income which the trust derived was through a business and it only fed the
charity. In this light, the court rejected the trust’s contention with respect to the entitlement to claim
tax benefit for the first part. Counsel pointedly referred to the observations in paragraph 24 of the
said decision and submitted that the court noticed the difference in language brought about by the
substitution of Section 11(4A) (w.e.f. 01.04.1992). The new provisions enabled the Trust to carry onAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

business for it was incidental to the attainment of its activities.
42. Elaborating on Thanthi Trust further, counsel highlighted that the scope of the provision, i.e.
Section 11(4A) had been ruled by this court as more beneficial to the trust or institution, than had
existed previously before its amendment. Therefore, as long as the Trust carried on its activities
mainly for charitable purposes - any income derived from incidental trading or business activities,
(1981) 3 SCC 308 (hereafter “Bar Council of Maharashtra”) would not result in it being characterised
as an entity carrying on business; in other words, it was one carrying on a charitable objective or
purpose.
43. Learned counsel also relied upon Circular 11/2008 dated 19.12.2008 which highlighted that
whether the activities carried on by any charitable institutions are in the nature of trade or whether
they are essentially charitable is a question of fact. It also spelt out that if an assessee is engaged in
any activity, in the nature of trade, commerce or business or rendering any services in relation to
such trade etc., it could not claim that its object was charitable. In such event, “the object of general
public utility will only be a means or defence to highlight the true purpose which is trade, service or
business………….”. It was emphasised therefore that the circular and the speech of the Finance
Minister during the budget clearly pointed out organisations, trust or entities which were
masquerading as charitable but in reality carrying on business. On the other hand, genuine
charitable organisations which generated income for their sustenance could not be denied the
benefit of tax exemption under the Income Tax Act.
44. Counsel relied on the decisions in Shri Ramtanu Cooperative Housing Society Ltd. v. State of
Maharashtra30, Gujarat Industrial Development Corporation v. CIT31 (hereafter "GIDC case"),
HSIDC v. Hari Om Enterprises32 and Commissioner of Central Excise v. Maharashtra Industrial
Development Corporation33 and urged that statutory organizations set up for housing and other
essential development, cannot be regarded as commercial or business entities.
45. Learned counsel relied upon the Constitution Bench decision of this Court in Navnit Lal C.
Jhaveri v. K.K. Sen34 (hereafter “Navnit Lal Jhaveri”), where the court had held while interpreting
the provisions of an enactment that the (1970) 3 SCC 323 1997 (Supp 3) SCR 466; (1997) 7 SCC 17
(hereafter "GIDC case").
(2009) 16 SCC 208 2017 SCCOnline Bom 10021 (para 10-12) (1965) 1 SCR 909 (hereafter “Navnit
Lal Jhaveri”) executive’s understanding – in the form of circulars in the context of taxing statutes –
were valuable guides to interpretation. The observations in Navnit Lal Jhaveri (supra) were relied
on to submit that the circulars in that case was used to in fact soften the rigor of a newly introduced
provision. Learned counsel also relied upon the judgment of this Court in UCO Bank Calcutta v.
Commissioner of Income Tax, West Bengal35 and in Lok Shikshana Trust (supra) where the Court
had specifically rejected the contention that a speech made in Parliament cannot be looked into to
discern the intent of the lawmaker. In that case, the Court had stressed that the real meaning of all
the words used could be understood specifically by referring to the past history of the legislation and
the speech of the mover of the amendment.Assistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

46. Learned counsel argued that the expressions “trade”, “business” or “commerce” always mean
and have been interpreted to mean activities driven by profit. In this context, reliance was placed on
this court’s decisions in State of Punjab v. Bajaj Electricals Ltd36.; Khoday Distilleries Ltd. v. State
of Karnataka37 and State of Gujarat v. M/s. Raipur Manufacturing38. It was submitted that in all
contexts, the primary meaning of the expression “trade” is “exchange of goods” for money and
connotates that such activity is necessarily or always carried on to earn profit. It was, therefore,
argued that Section 2(15) cannot be read in isolation, but should be construed in the light of the
minister’s speech while introducing the amendment, and the Circular (i.e. Circular 11/2018).
Therefore, if an organisation is created and carries on its activities with a view to earn profit as was
held in Bajaj Electricals, Khoday Distilleries, and Raipur Manufacturing (supra), it is precluded from
claiming to be a charitable organisation. On the other hand, if the entity is primarily set up for the
charitable purpose, i.e., to carry on activities for the advancement of general public utility, but it also
carries activities that 1999 (4) SCC 599 (hereafter “UCO Bank Calcutta”) 1968 SCR (2) 636 (1995) 1
SCC 574 (1967) 1 SCR 618 generate surplus or money, they cannot be per se excluded from
consideration for tax benefit.
47. Learned Senior Counsel Mr. Kavin Gulati argued for NOIDA and relied upon the Constitution
Bench judgment of this court in Commissioner of Central Excise, Bolpur v. Ratan Melting and Wire
Industries39 to urge that a circular cannot define an ambit of a provision. He highlighted the
decision rendered by the Delhi High Court in Greater Noida Industrial Development Authority v.
Union of India & Ors40, where the assessee’s activities were held to be not “commercial activity”
within the meaning of clause (b) to S.10(46).41 He also relied on other decisions – of this court, to
the same effect, in Kerala State Electricity Board v. Indian Aluminium Co. Ltd.42 and Trustees of
the Port of Madras v. Aminchand Pyarelal and Ors.43.
48. Mr. Gulati relied on the GIDC case (supra) to argue that the word “development” in S.10(20-A)
of the IT Act, 1961 has to be understood in its wide sense. It was urged that development authorities
like NOIDA fall under Section 2(15) of the IT Act, 1961 if they satisfy the test in Section 11(7) of the
IT Act, 1961. It was contended that Surat Art Silk (supra) was clear that engagement by a trust with a
commercial activity is not per se prohibited, as long as its object is the attainment of an object of
general public utility. Pointing to the Explanatory Notes (to the Provisions of the Finance Act, 2015)
- with respect to proviso to Section 2(15), counsel urged that the proviso operates at the stage of
registration of trust under Section 12AA(1A) of the IT Act, 1961, when the authorities satisfy
themselves with respect to the genuineness of the activity and scope of the trust.
(2008) 13 SCC 1 2018 SccOnline Delhi 7536 The High Court had relied upon the ratio in Shri
Ramtanu Co-operative Housing Society Limited v. State of Maharashtra (1970) 3 SCC 323 , which
ruled that the true character of the corporation in that case i.e., the Maharashtra Development
Corporation was to act as an architectural agent for the development and growth of industrial towns
and for their establishment.
(1976) 1 SCC 466 (1976) 3 SCC 167Assistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

49. It was lastly argued that the expression “trade” carries within it the idea of profitability: counsel
cited State of Gujarat v. Mahesh Dhiarjlal Thakkar44, Sodan Singh & Ors. v New Delhi Municipal
Committee & Ors 45 and T.M.A Pai Foundation and Ors. v. State of Karnataka & Ors46. Reliance
was placed upon the judgment in CIT, Madras v. M/s Madurai Mills Company Limited47 to urge
that interpretation of the definition of expression “charitable purpose” should not be coloured by
considerations stemming from legislative history, which override the plain words of a statute.
50. Mr. K. K. Chythanya, senior counsel appeared for M/s Karnataka Industrial Areas Development
Board (“KIADB”). He urged that KIADB was formed under Section 5 of the Karnataka Industrial
Areas Development Act, 1966 (“KIAD Act”) and it functions on “no profit-no loss” basis as is evident
from the preamble48, the aims and objectives49 of the board as well as Sections 3, 5, 6, 28, 29, 43
and 4650 of the KIAD Act. Reliance was placed on Karnataka Industrial Areas Development Board
v. Prakash Dal Mill51 which held that KIADB is “state” under Article 12 of the Constitution, and it
was urged that KIADB was an extension of the Karnataka Government. The board exercises power
of eminent domain and it performs governmental functions. Its activities, therefore, cannot (1980) 2
SCC 322 1989 (3) SCR 1038 (2002) 8 SCC 481 (1973) 4 SCC 194 “It is considered necessary to make
provision for the orderly establishment and development of Industries in suitable areas in the State.
To achieve this object, it is proposed to specify suitable areas for Industrial Development and
establish a Board to develop such areas and make available lands therein for establishment of
Industries.” Promote rapid and orderly development of industries in the state.; Assist in
implementation of policies of Government within the purview of KIAD Act; Facilitate in establishing
infrastructure projects: Function on “No Profit – No Loss” basis.
• Section 5 – Established and incorporated for securing the establishment of industrial areas in the
State of Karnataka and generally for promoting the rapid and orderly establishment and
development of industries and for providing industrial infrastructual facilities and amenity in
industrial areas in the State of Karnataka. • Section 6 – All the members of the Board are
government officials; • Section 46 - the members & other employees of the Respondent are deemed
to be public servants. • Section 3 & 28 - Government of Karnataka (GOK) that acquires the land
from the public. • Section 29 – GOK determines the price and pays the compensation. • Section 43 -
No duty under the Karnataka Stamp Act, 1957, or fees under the Indian Registration Act, 1908.
(2011) 6 SCC 714 be regarded as trade or business. Reliance was placed upon State of Karnataka v.
All India Manufacturer’s Organisation52.
51. It was submitted that in the absence of profit motive, the activity is not trade, commerce or
business - within the meaning of first proviso to Section 2(15) of the IT Act, 1961. Reliance was
placed upon Khoday Distilleries (supra), State of Tamil Nadu v. Board of Trustees of the Port of
Madras53 and several other decisions54. It was argued that wherever it is intended, profit element
is wholly excluded from activity - reliance was placed on provisions of the Karnataka VAT Act, The
Central Goods and Service Tax Act (“CGST Act”) and Section 2(31) of the IT Act. In the present
context, the activities of the Board do not amount to “trade”, “commerce” or “business” and the first
proviso to Section 2(15) is attracted only if the primary/dominant objects are (a) in the nature of
trade, commerce or business; or (b) rendering any service in relation to any trade, commerce orAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

business. To substantiate this argument, counsel relied on Surat Art Silk (supra), Commissioner of
Income Tax v. Gujarat Maritime Board55 (hereafter “Gujarat Maritime Board case”) and other
decisions56. Hence, if the main activity is not “business”, the connected, incidental or ancillary
activities of sales carried out in furtherance of and to accomplish their main objects would not
normally, amount to business, unless an independent intention to conduct ‘business’ in these
connected, incidental or ancillary activities is established by the revenue. The judgments in CST v.
Sai Publication Fund57 and the Board of Trustees of the Port of Madras (supra) was relied upon. It
was urged that the revenue’s contention that statutory authorities’ claim for exemption is confined
to the provision in Section (2006) 4 SCC 683 1999 (2) SCR 195 (hereafter, “Board of Trustees of the
Port of Madras”) State of Karnataka v. Shreyas Papers Pvt. Ltd. AIR 2006 SC 865; Ashoka
Smokeless Coal India (P) Ltd. v. Union Of India (2007) 2 SCC 640; New Delhi Municipal Committee
v. State of Punjab 1996 Supp 10 SCR 472; and Physical Research Laboratory v. K.G Sharma 1997 (3)
SCR 733.
2007 (12) SCR 962; (2007) 14 SCC 704 (hereafter “Gujarat Maritime Board case”).
Yogiraj Charity Trust v. CIT 1976 (3) SCR 947; Commissioner of Income Tax v. Andhra Pradesh
Road Transport Corporation 1986 (1) SCR 570; Queens’s Educational Society v. CIT 2015 (8) SCC
47.
2002 (2) SCR 743 10(46). He urged that in terms of Section 11(7)58 the Board has an option to claim
exemption either under Section 11 or under Section 10(46). There is no bar for claiming exemption
under either of those provisions.
52. Mr. Dhruv Agrawal, learned senior counsel appearing for the U.P Awas Evam Vikas Parishad
adopted the submissions of senior counsel Mr. Soparkar and K.K Chythyanya. He also urged that
the realization of the right to shelter and housing is an integral part of right to life, and contended
that the predominant activity of the assessee involves the fulfilment of those objectives, especially
for the weak and poorer sections of the society. He relied on this court’s decision in Chameli Singh v.
State of U.P & Ors.59 which had stated that right to social justice includes right to shelter, and that
these statutory corporations are the means to ensure that.
53. Mr. K. V. Viswanathan, senior counsel appearing on behalf of GS1 India submitted that the
assessee is involved in issuing bar codes which is a global language of standardised coding and the is
a universally accepted standard for identification of products. The GS1 barcode is a global standard
which is an intellectual property of GS1 (an international non-profit organisation headquartered at
Brussels) and it has affiliates in each country with the assistance of national governments. GS1 India
the assessee, is an affiliate; it was registered as a society in the year 1996, with the Joint
Secretary-Ministry of Commerce as its President and the administrative control vests with the
Ministry of Commerce, Government of India. It was registered as a charitable GPU category society
in Inserted by Finance (2) Act, 2014 and amended by Finance Act, 2020 (1996) 2 SCC 549. The
court had cited Article 25(1) of the Universal Declaration of Human Rights and Article 11(1) of the
International Covenant on Economic, Social and Cultural Rights, 1966 and relied on Sri. P.G. Gupta
v. State of Gujarat & Ors. 1995 (1) SCALE 653 - where a Bench of three Judges of this Court hadAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

considered the mandate of the human right to shelter and read it into Article 19(1)(e) and Article 21
of the Constitution of India to guarantee the right to residence and settlement.
1996. All the trade bodies60 as well Bureau of Indian Standards are members of its governing
council.
54. It was submitted that the revenue had granted exemptions to the assessee society under Section
12A and Section 10(23C)(iv) while issuing various certificates from time to time (from AY 1996-1997
to 2007-2008); therefore, it had accepted that the assessee’s object and purpose was charitable, i.e.,
advancement of general public utility. Also, to reflect that there is no business/trade/commerce
involved and profit motive is absent the learned counsel relied upon the decision of the assessee
society to issue substantial discounts to the extent of 50% to deserving sectors like cottage industries
to enable augmentation of market for such sectors, as well as the letter written by CEO- GS1 to the
President GS1 (i.e. Joint Secretary, Ministry of Commerce) to permit reduction of fee from 400 too
70 per farm/plot, for issuing Global Location Number (GLN) to farmers, which was approved.
55. Regarding the statutory provisions it was submitted that the words “trade, commerce or
business” in the proviso to Section 2(15) of the IT Act cannot be read in isolation and have to be seen
in context of “charitable purpose” and, even after a series of amendments - from the Finance Act,
2008 to Finance Act, 2015 there is essentially, no change in the basis of determination of what
amounts to a trade, commerce or business and therefore the tests as laid down in Surat Art Silk
(supra) still holds the field to interpret these words.
56. Counsel urged that Parliament is assumed to have used the word ‘involves’ found in proviso to
Section 2(15) as interpreted in Surat Art Silk (supra), in the sense that an activity is involved in the
advancement of an object when it is enwrapped or enveloped in the activity of advancement, so that
the resulting Federation of Chambers of Indian Commerce and Industry; Confederation of Indian
Industry; Associated Chambers of Commerce and Industry of India (ASSOCHAM); The Agricultural
and Processed Food Products Export Development Authority (APEDA).
activity has a dual nature or is twin faceted. The well-known principle of construction, that where
the legislature uses in an Act, a legal term which has received judicial interpretation, it must be
assumed that the term is used in the sense in which it has been judicially interpreted unless a
contrary intention appears, was relied upon, and the decision in P. Vajravelu Mudaliar v. Special
Deputy Collector, Madras & Ors.61 was cited in that context.
57. Countering the contentions of the revenue that if entities making profit but not involved in
commercial activity desire exemption, they ought to apply under Section 10(46) IT Act, it was
submitted that the expression “constituted by or under an Act” in Section 10(46) does not include all
entities like the assessee, which is a not a statutory corporation, but a “not for profit” society
registered under the Societies Act. It was argued that the distinction between “established by and
under an Act” is well settled and includes entities which are statutory corporations as contrasted
from non-statutory ones. The judgment in Dalco Engineering Pvt. Ltd. v. Satish Prabhakar Padhye &
Ors. 62 was referred to, in this context where this court ruled that “…when the words "by and underAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

an Act" are preceded by the words "established", it is clear that the reference is to a corporation
established, that it is brought into existence, by an Act or under an Act. In short, the term refers to a
statutory corporation as contrasted from a non-statutory corporation incorporated or registered
under the Companies Act.”
58. Learned senior counsel lastly submitted that an activity, to be “trade, commerce or business”,
must be profit driven. Profit motive is a quintessential element and an activity without profit motive
will not result in “trade, commerce or business” in terms of the decision in State of A.P v. H. Abdul
Bakhi & Bros63. If exemption is not granted to the assessee it will face a liability of around 300
1965 (1) SCR 614 (2010) 4 SCC 378 1964 (7) SCR 664 crore (from FY-2007-08 to 2020-21), which
given its financial condition will jeopardise its existence and functioning.
59. Ms. Radhika Suri, learned counsel argued on behalf of Bhatinda Improvement Trust and
adopted the submissions of Mr. Soparkar. She urged, in addition, that it is obligatory on part of the
assessee (a statutory corporation) to use the monies received for public utility purpose and the price
fixation of lands/plots sold by them is also regulated through statutory regulations. Therefore, such
activities qualify the test of general public utility. Ms. Suri also relied on the decision of the Delhi
High Court in Greater Noida Industrial Development Authority (supra) to the effect that there is
need to distinguish commercial activity which constitutes disqualification under clause (b) to
Section 10(46) of the Act, and charging and payment of fee, service charges, reimbursement of costs
or consideration for transfer of rights for performing and undertaking regulatory or administrative
duties for general public interest, when these are not guided and undertaken with profit motive or
intent. Further, reliance was placed on The Commissioner of Income Tax (Exemptions), Chandigarh
v. M/s Hoshiarpur Improvement Trust, Hoshiarpur64 to explain the characteristics of the assessee.
Learned counsel further laid emphasis on provisions of the regulations under the Punjab
Improvement Trust Rules and regulations to show the procedure adopted by the board in fixing
prices.
60. Mr. Gursharan S. Virk, argued that the Gujarat Maritime Board (GMB), is a statutory one,
constituted under Section 3(2) 65 of the Gujarat Maritime Board Act, 1981 (GMB Act); it performs
functions which, prior to the enactment of the Act, were being performed directly by the State
Government66. The Preamble to the Act notes that it is constituted for administration, control and
management of Section 3 (2):- “ The board shall be a body corporate by the name aforesaid having
perpetual succession and a common seal with power, subject to the provisions of this Act to acquire,
hold and dispose of property, both movable and immovable, and to contract, and may by the said
name sue and be sued.” Section 20 of the GMB Act minor ports in the State of Gujarat, and for all
matters connected therewith. The Board’s powers under the GMB Act apply to works carried out by
GMB as conservator of ports under the provisions of the Indian Ports Act67; it is charged with
essential functions such as development and upkeep of jetties, wharves, docks, piers, places of
anchorage, light-houses, light-ships, beacons, buoys, pilot boats, and other appliances necessary for
safe maritime navigation, etc. and for development of minor ports in general68. It is also entitled to
undertake essential maritime services such as stevedoring, landing, shipping or trans-shipping,
piloting, hauling, mooring and hooking vessels/goods, etc.69 Hence it was urged, that GMB’s
functions are, essential and sovereign in nature, and relate to the development, safety andAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

protection of the waterfront.
61. It was submitted that the GMB is not engaged in any business or trade, is not engaged in any
activity which generates profit and does not (also statutorily cannot) use money for anything except
for development of minor ports in the state of Gujarat and the features of the GMB Act. These
features in context of the controversy at hand, under the provisions of the IT Act, were considered
by this court in the Gujarat Maritime Board case (supra). The decision discussed Sections 73, 74 &
75 of the GMB Act, which provide for management of all monies received by the GMB; and Section
76 of the GMB Act, which permits the setting aside of surplus money only for “expanding existing
facilities or creating new facilities at the ports” or for meeting with contingencies caused on account
of “fire, cyclones, shipwrecks or other accidents or for any other emergency.” It was stressed that
that judgment clearly indicates GMB has no profit motive. It was therefore, urged that the
provisions of the GMB Act, indicate the overwhelming public purpose carried out by it without profit
motive and that Section 83 of the GMB Act Section 25(2) of the GMB Act Section 32 r/w Sections
37-30 of the GMB Act utilization of funds is only for the purpose of development, management and
safety of minor ports; all these entitles GMB to exemption.
62. Mr. Rohit Jain, learned counsel, appeared on behalf of the Education and Research Network
(ERNET) and National Internet Exchange of India (NIXI). On behalf of ERNET it was submitted
that it was started as a planned project of the Government of India under the Department of
Electronics (DoE) with the support of the United Nations Development Program (UNDP). The
program was focused on integrating information technology and internet tools with learning
environment, to enhance the quality of education. However, funding by the UNDP ended in 1992.
The DoE nevertheless continued to support the project till 1998 and thereafter the body was
registered as an autonomous society under administrative control of the Ministry of Communication
and Information Technology, Govt. of India on 27.01.1998. It was registered under Section 12A of
the IT Act, 1961 on 26.03.2004 and its activities fell within the meaning of “charitable purpose”
under Section 2(15). It duly complied with Sections 11 and 12 of the IT Act, 1961.
63. NIXI was created in 2003 by the Government of India under the Ministry of Information
Technology, for promotion and growth of internet services in India, regulating the internet traffic
and acting as internet exchange, to undertake “.in” domain name registration thereby saving
valuable foreign exchange, and take care of national concern. It was urged that this is a Section 25
company barred from undertaking any commercial or business activity for profit and is bound by
strict licensing conditions, including prohibition on alteration in the memorandum of association,
without prior consent of the government. The “charitable” nature of the same has also been upheld
under Section 12A of the IT Act, 1961.
64. Learned counsel submitted that ERNET is a “not for profit” society wherein considering its
objects, it receives only subscription fees mainly from schools, colleges, universities, scientific
research institutes, etc. This subscription fees is charged on “actual basis” and utilized towards
promotion of its objectives. The charitable character of the assessee is apparent and not in dispute
since it has been accepted by the revenue up to AY 2008-09. Also, the final factual findings recorded
by lower authorities conclusively demonstrate that the assessee is engaged in ‘advancement ofAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

general public utility’, and qualifies as a ‘charitable purpose’ as it does not carry any trade commerce
or business, and the income earned is not derived in the course of any commercial activity.
65. Learned counsel also submitted that the assessee carries on R&D work which enables
educational institutions with Information and Communication Technology infrastructure for
making education reach the public at large solely for charitable purpose and further reliance was
placed upon ICAI Accounting Research Foundation v. DGIT(E)70, Bureau of Indian Standards v.
DGIT(E)71 and GS1 India v. DGIT(E)72.
66. Mr. Ajay Vohra, learned senior counsel, appearing for the Apparel Export Promotion Council
(AEPC) urged that it is a non-profit organization set up with approval of the Central Government,
for promotion of exports of garments from India (i.e., promotion of trade). It was registered under
Section 12AA(1) of the IT Act, on 18.05.1979 and is engaged in the activity of promotion of the
export of all kind of ready-made garments, knitwear, and garments made of leather, jute and hemp.
It does not per se engage in any activity for profit, and its mandate is to ensure that Indian apparel
manufacturers, are given forums and platforms, to showcase their products. For that purpose, the
AEPC charges subscriptions, and provides services, which have general public utility. These
activities are by way of booking large spaces in fairs, and such like events, especially in overseas
locales, so that Indian manufacturers can interact with other overseas buyers, and 321 ITR 73 (Del)
358 ITR 78 (Del) 360 ITR 138 (Del) are enabled to promote trade. It was submitted that there is
ex-officio involvement on behalf of the Central Government, in the AEPC’s activities, including in its
policy formulation levels.
67. Mr. Vohra relied upon the Memo Explaining Provisions in the Finance Bill, 200873, the speech
of Finance Minister in Lok Sabha on Finance Bill, 200874, CBDT Circular No. 11 dated
19/12/200875 to submit that proviso to Section 2(15) only bars commercial/business activities
undertaken for profit motive. It was submitted that mere earning of income and/or charging any
fees is not barred by the proviso; rather, carrying of any activity in the nature of trade, commerce or
business or rendering service in relation thereto is barred. Reliance was placed upon judgments in
Dir. Of Supp. & Disp. v. Board of Revenue76 which follows H. Abdul Bakhi & Bros (supra), Barendra
Prasad Ray v. ITO77 and State of Gujarat v. Raipur Manufacturing Co. Ltd.78 to argue that in
“business” there must be some real and systematic, or organized course of activity or conduct with
the set purpose of making profit. Counsel referred to Sai Publication Fund (supra) where this court
observed that since primary and dominant activity of the trust was to spread message of Saibaba
and hence not business, then any incidental or ancillary activity of publishing and selling of books
and literature cannot be regarded as business. Reference was made to Customs & Excise
Commissioner v. Lord Fisher79 which held that there are six indicia to determining business namely
(a) serious undertaking earnestly pursued, (b) reasonable continuity, (c) substantial in amount, (d)
conducted regularly on business principles, (e) predominantly concerned with making taxable
supplies for consideration, (f) such as those commonly made by persons seeking to make profit.
Other judgments too 298 ITR (St.) Quoted in ITPO v. DGIT(E) : 371 ITR 333 (Del) (hereafter
“ITPO”) 308 ITR (St.) 1967 (3) SCR 778 1981 (3) SCR 387 1967 (1) SCR 618 (1981) 2 All ER 147 were
cited; and reference was made to definitions in the Concise Oxford Dictionary, Webster’s New
Twentieth Century Dictionary, Black’s Law Dictionary, and Sampath Iyengar’s Law of Income Tax.Assistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

68. Mr. Ajay Vohra, urged that AEPC has been claiming exemption under Section 11 from AY
1979-80 to 1990-91. During AY 1991-92, the Assessing Officer (“AO”) denied the exemption on the
ground that it was carrying on business. That order was eventually set aside by the ITAT which, held
that it was entitled to exemption under Section 11 of the Act. Subsequently, an amendment was
brought to Section 11(4A) and AEPC had to maintain separate books of accounts. In AY 1992-93, the
AO again denied exemption. On appeal, the issue was decided in favour of AEPC by the ITAT. The
Delhi High Court upheld the order of the ITAT in a judgment80. AEPC received entrance fee and
membership fee which, it claimed were exempt on the principle of mutuality. This issue too was
resolved in its favour from the AY 1992-93 to AY 1997-98 by the jurisdictional High Court. From the
assessment year 1998-99 to the assessment year 2008-09, the AO accepted the assessee’s claim that
income was exempt under Section 11 of the Act.
69. During AY 2009-10 and 2010-11, the AO denied exemption under Section 11 on the ground that
the newly inserted proviso to Section 2(15) was attracted; and thus the assessee was ineligible for
exemption under Section 11. The AO held that the assessee was rendering services in relation to
trade, commerce business for consideration and the receipt of which exceeds 10 lakhs. The CIT(A)
allowed the assessee’s appeal following the decision of the High Court in its case, and there being no
changes in the facts and circumstances of the case. The ITAT upheld the findings of the first
appellate authority as it observed that the assessee did not carry any activity with an object of profit,
and thus the question of attracting the proviso did not arise.
Reported at 244 ITR 736
70. Ms. Prabha Swami, learned counsel submitted that the A.P State Seed Certification Agency is a
statutory society set up under Section 881 of the Seeds Act, 1966 which is represented by the
representatives of Seedsmen Association, seed farmers, farming community and members
representing Central Seed Certification Board. While explaining the charitable characteristic of the
society the counsel pointed out that the society was duly registered and its Memorandum of
Association clearly inter-alia stated that the object for which it was established was to see that the
cultivators adopt all scientific methods for production of quality seeds in accordance with the Seeds
Act and to carry on educational programs designed to promote the use of certified seeds. Charges
are collected from the traders or the societies engaged in the trade of seeds. The society provides
quality seeds to the farmers and hence traders are prevented from selling inferior variety of seeds.
Highlighting the activities of the authority, it was urged that farmers are benefited by various
services it offers - inspection of fields at the time of seed production, supervision while processing
seeds and issuing a validation certificate at the time of packing, sampling, and seed testing. The
society (which is not involved in trade, commerce or business) is therefore rendering service to the
general public as they are encouraging farmers to purchase quality seeds and help prevent loss to
them, and loss of natural resources. Mr. Sanjay Jhawar, learned counsel for Rajasthan State Seed
Corporation also adopted the submissions of Ms. Prabha Swami.
71. Mr. Sanjay Visen, learned counsel argued on behalf of M/s Raebareli Development Authority,
Raebareli, urging that the assessee is a body constituted under the U.P Urban Planning and
Development Act, 1973. As their activities were aimed at public purpose, it applied for registrationAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

u/s 12AA of the IT Act, 1961. It was submitted that the assessee’s income was earlier exempted
under “Section 8. The State Government or the Central Government in consultation with the State
Government may, by notification in the Official Gazette, establish a certification agency for the State
to carry out the functions entrusted to the certification agency by or under this Act”.
Section 10(20A) of the IT Act, 1961 which was omitted by the Finance Act, 2002; however, this did
not restrict the assessee from getting registered under Section 12AA of IT Act, as the object of the
authority is to provide shelter to homeless people, which is charitable.
72. Mr. Harish Salve, learned senior counsel appearing on behalf of Saurashtra Cricket Association
drew attention of this court towards the ambit of Section 4(3) of Income Tax Act, 1922 (i.e., the old
Act), as compared to Section 2(15) of the IT Act, 1961 which defines ‘charitable purpose’. He also
presented the construction of Section 11 in light of Thanthi Trust (supra). It was emphasized that the
objects of a trust are decisive and every surplus cannot be construed as profit, as is discussed in
Krishna Warriar (supra). Profits from trade or business arising out of property held under trust for
charitable purpose, if ploughed back to the extent of 100% cannot be termed as a commercial
activity. This was the principal idea in omitting Section13(1)(bb) as it was considered as restrictive
for carrying out such activities. It was argued that, substitution of the definition of “charitable
purpose” in Section 2(15) by the Finance Act, 2008 has not changed the law. The words “in relation
to any trade, commerce or business” and “for a cess, fee or consideration” in the proviso to Section
2(15) implies that advancement of object of a trust may not involve activities of profit. It was urged
that the amendment appears to have undermined this court’s decision in Surat Art Silk (supra).
73. It was argued that the crucial part of the definition of “charitable purpose” is the word “cess”
employed in the proviso. As an explanatory measure, the activities of promotional councils were
taken into consideration - for example Surat Art Silk supported silk manufacturers. If such activity is
for a cess or a fee, the organization ceases to be charitable. Activities in the nature of trade,
commerce or business are not charitable if they are for a fee or other consideration. Fees collected
by the private organizations forms the content of Section 2(15). However, amounts based on tariff
regulations imposed by the controlling law, or statute-based fee is neither “fee” nor “cess” under that
provision. Further, the consideration involved is vis-à-vis the activity or service. The test is the
object for which the consideration is paid, and what it entails, wherein the words “any other
consideration” is for the activities in aid or service of business. In this regard it was submitted that,
in true sense the word “business” implies profit, however statutory organizations are excluded from
its ambit. Fee or consideration collected by such organizations should not be taken in the sense of
profiteering, as it is for the advancement of their objectives. In this sense the word “cess” can be
read down as non-statutory.
74. It was submitted that the phrase “cess, fee or any other consideration” in the proviso to Section
2(15) covers the second part of the proviso, i.e., it is relatable to “service in relation to” trade,
commerce or business. Mr. Salve submitted that any statutory cess, or fee, authorized or compelled
by law, which is within the domain of the state legislature, cannot be construed as taxable, having
regard to the principles indicated in the judgment of this court, in NDMC (supra). He relied on
Article 289 of the Constitution of India, and submitted that it is only if a state engages – by itself, orAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

through an agency, directly in trading activity, that the immunity from Union taxation is lifted. In
the present case, those agencies set up by the State, essentially through law, to carry out welfare
activities, such as regulation and housing, cannot per se be characterized as trading concerns.
75. Mr. Salve submitted that cricket associations are operating purely to advance their objective of
promoting the sport. They should not be considered as pursing activities in furtherance of trade,
commerce or business. The word “cess” has to be read down in reverse (reverse ejusdem generis)
and it should be read non-statutorily while adopting purposive interpretation of the same. Reliance
was placed on Nabha Power Limited v. Punjab SPCL 82 to state that a purposive interpretation of
“cess”, is to be adopted.
76. It was also argued that the sport of cricket is a form of education and if it is not considered as a
field of education, it is still an object of general public utility. The primary regulating body i.e., the
BCCI, promotes sport in the entire country and worldwide, and the assessees herein are its second
and third tier associations. The revenue generated by BCCI flows to state and regional cricket
associations in the form of grants to maintain stadia, conduct matches, organize training camps, and
other ancillary purposes. Counsel relied on the objects of Saurashtra Cricket Association which inter
alia include, the control, supervision, regulation, encouragement, promotion and development of
the game of cricket in the Association’s jurisdiction. Other objects include creation, fostering
friendly relationships through sports tournaments and the creation of a healthy sportsmanship
spirit, through the medium of sports in general and cricket in particular. All other objects were
similar, including “to arrange, and/or manage among other things league and/or any other
tournaments”; organize matches, lay out grounds for playing cricket, organization of matches in aid
of public charities, etc. If these associations sell tickets and generate revenue through other
activities, those do not necessarily mean that their objects are commercial or to promote trade.
Selling tickets for a sport performance or match is to promote cricket, and not trade. Mr. Salve also
urged that the expression “trade” has a particular meaning; he referred to State of Gujarat v.
Maheshkumar Dhirajal Thakkar83 where the court observed that “the word trade in its narrow
popular sense means ‘exchange of goods for goods or for money with the object of making profit’. In
its widest sense it includes any business carried on with a view to earn profit84. Further, the word
takes its meaning from the context.” (2018) 11 SCC 508 (1980) 2 SCC 322 Halsbury’s Laws of
England, Vol. 32 para 487
77. Likewise, with regard to “business” the counsel referred to H. Abdul Bakhi & Bros. (supra) which
had discussed the term and explained that any activity should be driven by profit motive.85 Lastly,
the judgment in Secretary, Ministry of Education & Broadcasting, Govt. of India & Ors. v. Cricket
Association of Bengal86 was cited to explain the dominant purpose of the BCCI. That judgment
highlighted what is relevant and applicable is the test of predominant character of the activity, and
not that an institution incidentally earns surplus or profit.
78. Mr. Arvind Datar, learned senior counsel appeared on behalf of the Institute of Chartered
Accountants of India (hereafter “ICAI”) as well as The Tribune Trust.Assistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

79. Counsel submitted that ICAI is a premier professional accountancy body of the country
established under the Chartered Accountants Act, 1949 (“CA Act”) to impart formal and quality
education in accounting and thereafter to regulate the profession of Chartered Accountancy in India.
It is under the control and supervision of the Ministry of Corporate Affairs, Government of India.
Section 1587 of the CA Act defines the functions of Council of Institute which include “the
expression ‘business’ though extensively used is a word of indefinite import, in taxing statutes it is
used in the sense of an occupation, or profession which occupies the time, attention and labour of a
person, normally with the object of making profit. To regard an activity as business there must be a
course of dealings, either actually continued or contemplated to be continued with a profit motive,
and not for sport or pleasure. But to be a dealer a person need not follow the activity of buying,
selling and supplying the same commodity. Mere buying for personal consumption i.e. without a
profit motive will not make a person a dealer within the meaning of the Act, but a person who
consumes a commodity bought by him in the course of his trade, or use in manufacturing another
commodity for sale, would be regarded as a dealer”.
(1995) 2 SCC 161
15. Functions of Council (1) The Institute shall function under the overall control, guidance and
supervision of the Council and the duty of carrying out the provisions of this Act shall be vested in
the Council. (2) In particular, and without prejudice to the generality of the foregoing powers, the
duties of the Council shall include –
(a) to approve academic courses and their contents;
(b) the examination of candidates for enrolment and the prescribing of fees therefor;
(c) the regulation of the engagement and training of articled and audit assistants;
(d) the prescribing of qualifications for entry in the Register;
(e) the recognition of foreign qualifications and training for the purposes of enrolment;
(f) the granting or refusal of certificates of practice under this Act;
(g) the maintenance and publication of a Register of persons qualified to practice as chartered
accountants;
(h) the levy and collection of fees from members, examinees and other persons;
(i) subject to the orders of the appropriate authorities under the Act, the removal of names from the
Register and the restoration to the Register of names which have been removed;
holding of examinations for chartered accountancy course candidates and regulation of engagement
and training of articled clerks and audit assistants.Assistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

80. It was submitted that holding of coaching and revision classes, and surplus generated due to the
fees collected from that activity is not a business or commercial activity. Counsel urged that it is
wholly incidental and ancillary to the objects of the institute - which is to provide education and
conduct examinations of the candidates enrolled for chartered accountancy courses, so as to bring
out true professionalism. Therefore, separate books of accounts are not required to be maintained in
terms of Section 11(4A) read with the fifth and seventh proviso to Section 10(23C) of IT Act, 1961. It
was urged that ICAI was not hit by the proviso to Section 2(15) of the IT Act (inserted w.e.f.
01.04.2009) since its activities fall within the purview of the clause “education” specified in the
definition of the expression “charitable purpose” in S. 2(15) of the said Act, and not the residuary
clause relating to the GPU category, wherein the proviso solely applies to the latter. In this regard
the counsel referred to the Gujarat High Court judgment in Saurashtra Education Foundation v.
CIT88 which took into account the observations made in another judgment by the same High Court
in Gujarat State Co-operative Union v. CIT89, to hold that the ICAI was existing solely for
educational purposes and its activities clearly fall within the category of ‘education’ in Section 2(15)
of the Act. In further support of this proposition, reliance was placed on American Hotel and
Lodging Association v. CBDT 90 to
(j) the regulation and maintenance of the status and standard of professional qualifications of
members of the Institute;
(k) the carrying out, by granting financial assistance to persons other than members of the Council
or in any other manner, of research in accountancy;
(l) the maintenance of a library and publication of books and periodicals relating to accountancy;
(m) to enable functioning of the Director (Discipline), the Board of Discipline, the Disciplinary
Committee and the Appellate Authority constituted under the provisions of this Act;
(n) to enable functioning of the Quality Review Board;
(o) consideration of the recommendations of the Quality Review Board made under clause (a) of
Section 28B and the details of action taken thereon in its annual report; and
(p) to ensure the functioning of the Institute in accordance with the provisions of this Act and in
performance of other statutory duties as may be entrusted to the Institute from time to time.
(2005) 273 ITR 139 (Guj.) (1992) 195 ITR 279 (Guj.) (2008) 10 SCC 509 argue that ICAI is entitled
to be notified under Section 10(23C)(iv) r/w Section 2(15) of the Act, 1961.
81. Counsel submitted that profit motive is an essential element, or the driving force, for any
business or commercial activity. The activities of ICAI are not of such nature. Counsel relied upon
the judgment in NDMC (supra) which ruled that profit motive is the core aspect of trade and
business, in the context of Article 289 of the Constitution of India, which talks about exemption of
property and income of a state from Union Taxation.Assistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

82. It was argued that there is a distinction between nature of commercial ventures and charitable
institutions such as ICAI. The word ‘profit’ should never be used with a body set up for public
purposes, to regulate activities, in public interest and the intent of the organization/establishment
must be taken into consideration. In support, Board of Trustees of the Port of Madras (supra) was
cited, where the Port trust’s activities included sale of unclaimed and unserviceable goods in
discharge of various statutory charges, items, etc. They were part of the Port Trust’s main activities
of service. The court said that they cannot be treated as ‘business’ and that the Port Trust had no
intention to carry on business in the sale of unserviceable/unclaimed goods. Reliance was placed on
Surat Art Silk (supra), Andhra Pradesh State Road Transport Corporation (supra), Victoria
Technical Institute v CIT91, Aditnar Educational Institution v. Addl. CIT92, Thiagarajar Charities v.
ACIT93, Director of Income Tax v. Bharat Diamond Bourse94 and Gujarat Maritime Board case
(supra). The observations in T.M.A Pai (supra) that there can be reasonable revenue surplus, by the
educational institution for the purpose of development of education and expansion of the
institution, was also referred to.
(1991) 188 ITR 57 (SC) (1997) 3 SCC 346 (1997) 4 SCC 724 (2003) 259 ITR 280 (SC)
83. Learned senior counsel further relied on the explanatory notes to the provisions of the Finance
Act, 2008, specifically towards amendment made to Section 2(15) of the IT Act, aimed at
streamlining the definition of “charitable purpose” as discussed in para 595 and the ratio
Visvesvarya Technological University v. Assistant Commissioner of Income Tax96 to submit that
there is no loss to the character of a GPU charity where surplus generated is ploughed back. Further,
a judgment of the Division Bench of the Delhi High Court in J.K Synthetics & Another v. Union of
India & Ors.97 was referred to contend that it is not open for the revenue authorities, without any
cogent reason and merely at its own caprices, to refuse to follow the conclusion reached on the
earlier occasion, and to take up a totally different stand in subsequent years - as was done in this
case while refusing to grant exemption under Section 10 (23C) of IT Act, 1961 to the ICAI.
84. Learned counsel further submitted that the present case involves two circulars issued by the
Board viz. Circular No. 1/2009 dated 27.03.2009 and Circular No. 11/2008 dated 19.12.2008 which
are clarificatory and not contrary to any provisions of the Act, 1961 and hence the ratio of the
decision in Ratan Melting and Wire Industries (supra) does not apply. Reliance was placed on
observations made in Navnit Lal Zaveri (supra) and Ellerman Lines v.
"5. Streamlining the definition of “charitable purpose” 5.1 Sub-section (15) of section
2 of the Act defines “charitable purpose” to include relief of the poor, education,
medical relief, and the advancement of any other object of general public utility. This
is based on the argument that they are engaged in the “advancement of an object of
general public utility” as is included in the fourth limb of the current 12 It has been
noticed that a number of entities operating on commercial lines are claiming
exemption on their income either under sub-section (23C) of section 10 or section 11
of the Act on the ground that they are charitable institutions. This is based on the
argument that they are engaged in the “advancement of an object of general public
utility” as is included in the fourth limb of the current definition of “charitableAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

purpose”. Such a claim, when made in respect of an activity carried out on
commercial lines, is contrary to the intention of the provision.
5.2 With a view to limiting the scope of the phrase “advancement of any other object of general
public utility”, sub-section (15) of section 2 has been amended to provide that the advancement of
any other object of general public utility shall not be a charitable purpose, if it involves the carrying
on of any activity in the nature of trade, commerce or business, or any activity of rendering any
service in relation to any trade, commerce or business, for a cess or fee or any other consideration,
irrespective of the nature of use or application, or retention, of the income from such activity.”
(2016) 12 SCC 258 1981 SCC OnLine Del 457 Commissioner of Income Tax98 to urge that these
circulars are classified as “beneficial”. They place a purposive interpretation on a statutory
provision. Such circulars enormously reduce litigation and hardship of assessees and they play a
vital role in the proper administration of taxes.
85. It was argued that the demand against ICAI is from 2004-05 and the fees collected from
students have already been spent on various infrastructure development and other capital
expenditure items. The surplus amounts remaining were invested in government securities/FDs of
nationalized banks, so the demands raised will seriously prejudice the assessees.
86. On behalf of the Tribune Trust, Mr. Datar argued that the charitable nature of the trust can be
traced back to the In Re: Trustees of the Tribune (supra) judgment rendered by the Privy Council,
which allowed the trust’s appeal against the judgment of Lahore High Court (that rejected
exemption for the trust’s income for AY 1932-33). The Privy Council considered the objects of the
trust and held it was not founded for private profit and prima facie the trust’s object was of general
public utility, since by supplying newspapers in the province the trust involved the dissemination of
educated public opinion. It was urged that the impugned judgment passed by the Punjab and
Haryana High Court 99 in Tribune’s case dismissing the Tribune’s appeal, erroneously relied on
para 17 of Surat Art Silk decision (supra) which wrongly quoted the Privy council judgment in the
Tribune’s case.
87. It was further argued that collecting advertisements for consideration cannot be treated as
business activity undertaken by profit because the sale price of the newspaper is 2 whereas the cost
of printing each newspaper is 12 and the deficits can be made up only through advertisements.
Placing reliance on the extracts from the will of the late Sardar Dyal Singh Majithia it was urged that
the (1972) 4 SCC 474 ITA Nos. 62 of 2015 and 147 of 2016 (O&M) trustees were under a duty to
devote the surplus income for the improvement of the newspaper and hence prayed for allowing the
appeal.
88. Upon this court’s query with respect to advancing submissions on the constitutional aspect in
the ITPO judgment (supra), the learned senior counsel advanced his submissions on the validity of
Section 2(15) in the context of Article 14 and Article 289. It was submitted that classification made
in the ITPO judgment i.e., institutions driven by profit motive vis-à-vis institutions driven by motive
to advance objective of GPU, was correct and is in tune with the decision of this court in NDMC
(supra). It was urged that Article 289(1) will not apply to ITPO as its income and property cannot beAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

regarded as income and property of a State. It was also submitted that proviso to Section 2(15)
applies only to the last limb i.e., “advancement of object of general public utility” and not to the
preceding limb “education” and in respect of charity there is no discernible difference between the
two. Since there is no intelligible differentia and rational nexus in this regard, this discrimination
offends Article 14.
89. It was argued that the term “for a cess or fee or any other consideration” used in Section 2(15) is
clearly violative of Article 14 as it fails to make a distinction between activities that are carried out by
the State or by the instrumentalities or agencies of the State, and those carried out by commercial
entities for which a consideration is charged. In addition, Article 289(1) exempts states’ property
and income from Union taxation. To permit levy of income tax on cess or fee collected by a state
would violate Article 289(1), hence the word “cess” or “fee” in the proviso is liable to be declared
unconstitutional and violative not only of Article 14 but of Article 289 as well, in the context of state
undertakings. For Central institutions, it was submitted that cess or fee can never fall within the
definition of “income” under Section 2(24) read with Entry 82 of List-I and cannot be subject to tax.
C. Revenue’s rebuttal arguments
90. In rebuttal to the submissions advanced by the assessees, the ASG relied upon Adityapur
Industrial Area Development Authority v. Union of India100 and submitted that there is no
constitutional immunity from taxation, for the state, because by Article 289(2) even state or its
instrumentalities/agencies are not immune from taxation if they carry on trade or business. In light
of Article 289(2), there is no constitutional bar for the States (or the Union) to engage or carry on
trade or business, and Article 289 allows the Parliament to impose taxes on such trade or business.
The ratio in NDMC (supra) has to be read in light of the provisions and the judgment rendered in
Shri Ramtanu Cooperative Housing Society (supra) should in turn be read in light of NDMC. The
decisive factor therefore is not the status of the entity, but the nature of activity carried by it. If the
nature of activity is trade or business with a profit motive, then the same can be taxed even if it is
carried by state or its instrumentalities. It was also contended that Article 289 does not grant
absolute any immunity from taxation.
91. The revenue further submitted that the validity of the amendment can be tested especially in the
case of exclusions or exemptions on limited grounds - invalidity, arbitrariness, unreasonableness,
discrimination; and the assessees have not made out a case under any such ground. Also, by
referring to In Re: Trustees of the Tribune and All India Spinners Association of Mirzapur (supra), it
was contended that “general public utility” is only a statutory creation so as to form part of
charitable purposes and it can always be given a statutory import by subjecting it to conditions and
limitations prescribed under Section 2(15), at different points of time. In other words, it can always
be regulated or modulated through statutory prescriptions, conditions, and limitations while
granting an exemption from taxation. The submission of the assessees, that one has to look only at
the objects to determine if it constitutes charitable purpose for Section (2006) 5 SCC 100 2(15) of
the Act, is to be rejected because exemptions or exclusions are not based on mere objects of trust but
on whether the purpose of the trust is “advancement of any other object of general public utility”.Assistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

III. Analysis and reasoning
92. The history of the statute and the evolving interpretation of “charitable purpose” reveals that in -
P. Krishna Warriar (supra), this court extensively considered the previous jurisprudence on the
subject (in light of the pre-existing Section 4(3) of the old law), as well as the amendment
introduced in 1953. At that time, income of a charitable organization, earned from business was
subject to limitations. The limitations were that (i) the business was to be carried on in the course of
the actual carrying out of a primary purpose of the trust or institution; or (ii) the work in connection
with the business was to be mainly carried on by beneficiaries of the institution. These expressions
were considered in Krishna Warriar (supra), where the court held that the term “property” (of a
trust) was of widest amplitude, which included business. The following decision, in Andhra
Chamber of Commerce (supra) where the chamber of commerce had among its objects, one
enabling it to advocate policies or legislation, or oppose them, in addition to the object of promoting
business, held that the incidental inclusion of such objects, involving espousing a political purpose,
did not undermine its essential or main purpose, of advancing objects of general public utility. The
new provision, i.e., Section 2(15) of the IT Act, defined “charitable purpose” restrictively: to deny tax
exemption to activities for profit which were carried on by a trust for the advancement of an object
of general public utility. The reason for this change (discussed previously) was that the advantage of
tax exemption was not intended to charitable trusts that were commercial concerns, which while
ostensibly serving a public purpose, were fully paid for the benefits provided by them.
93. The first two decisions of some note are Lok Shikshana Trust and Indian Chamber of Commerce
(supra). The former decision, by majority, held that to qualify as a charitable purpose, two
ingredients had to be satisfied. It was held that the change in the definition meant that to be the
fourth category of charitable purpose, it was necessary to show that “(1) the purpose of the trust is
the advancement of any other object of general public utility, and (2) the above purpose does not
involve the carrying on of any activity for profit. Both the above conditions must be fulfilled before
the purpose of the trust can be held to be charitable purpose.”
94. In Indian Chamber of Commerce this court categorically held that even if the activity for profit,
is to further an object of general public utility, the charity could not claim of exemption. The court
went on to indicate the following test:
“21. The true test is to ask for answers to the following questions: (a) Is the object of
the assessee one of general public utility? (b) Does the advancement of the object
involve activities bringing in moneys? (c) If so, are such activities undertaken (i) for
profit or (ii) without profit? Even if (a) and (b) are answered affirmatively, if (c)(i) is
answered affirmatively, the claim for exemption collapses. The solution to the
problem of an activity being one for or irrespective of profit is gathered on a footing
of facts. What is the real nature of the activity? One which is ordinarily carried on by
ordinary people for gain? Is there a built-in prescription in the constitution against
making a profit?....”Assistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

95. The decision in Surat Art Silk, needs careful scrutiny, not only because it is by a larger Bench,
but also because it has been the bulwark of the assessee’s contentions- and has been the premise
upon which almost all High Courts have interpreted Section 2 (15) after its amendment, in 2008. As
noticed earlier, the old Act (in Section 4(3)) did not contain any terms, restricting or prohibiting
charities from engaging in commercial activities or those which yielded profit. No doubt, the idea of
income from business carried on “behalf of a religious or charitable institution” being exempt,
provided “the business is carried on in the course of the actual carrying out of a primary purpose of
the institution” was introduced by amendment, in 1953. This was interpreted in Andhra Chamber of
Commerce and Krishna Warriar (supra). However, Parliament clearly intended a departure, when it
introduced the new Section 2 (15) under the IT Act. The earlier decisions in Indian Chamber of
Commerce, and Lok Shikshana Trust (supra) noticed this change. Surat Art (supra) was yet another
a departure. While it considered the previous decisions of the court, it consciously departed from
them, and even overruled the interpretation in Indian Chamber of Commerce (supra). The larger
Bench in Surat Art Silk agreed with the previous decisions to the effect that the motivation for the
activity in question (i.e., for it to be charitable) should not be deriving of profits. However, the larger
Bench enunciated the principle of ‘predominant object’ and held that what was of importance was
“whether the predominant object of the activity involved in carrying out the object of general public
utility is to subserve the charitable purpose or to earn profit” and that such an entity would not lose
its charitable character merely because some profit arose from the said activity.
96. Thus, was born the ‘predominant object’ test, of an organization, to determine whether it was
essentially charitable, or ‘for profit’. If the predominant object was not for profit, but advancement
of general public utility, that some profits were earned, would not debar it from claiming to be an
organization with a charitable purpose. However, if the predominant object was such that profit
making was “enwrapped” or “intertwined” with it, the organization or trust could not be called
charitable. Crucially, the court emphasized that the manner of carrying on of the activity in question,
was determinative:
“the nature of the charitable purpose, the manner in which the activity for advancing
the charitable purpose is being carried on and the surrounding circumstances may
clearly indicate that the activity is not propelled by a dominant profit motive.”
97. Interestingly, the test proposed by the majority judgment in Surat Art Silk is similar to the one
advocated in Indian Chamber of Commerce (which it overruled). The difference in approach is that
Surat Art Silk advocated the “predominant object” test to see whether the object is for advancement
of general public utility, bereft of profit motive, whereas in Indian Chamber of Commerce (supra),
the court did not deal with or visualize consideration of a “predominant object”. The second
difference between the two decisions, is that Surat Art Silk stated that there is no need for an express
provision in the constitution of a given trust, eschewing profit motive, whereas in Indian Chamber
of Commerce, the necessity of such a condition was highlighted.
98. The judgments of this court, after Surat Art Silk (supra), noticed the enunciation of, and the
need to apply the test of “dominant” object. In Commissioner of Income Tax v. Federation of Indian
Chambers of Commerce and Industries101 it was, thus held:Assistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

“In other words, the majority view in the Surat Art Silk's case (supra) was that the
condition that the purpose should not involve the carrying on of any activity for profit
would be satisfied if profit-making is not the real object. The theory of dominant or
primary object of the trust has, therefore, been treated to be the determining factor,
even in regard to the fourth head of charity, viz., the advancement of any other object
of general public utility, so as to make the carrying on of business activity merely
ancillary or incidental to the main object.”
99. In Bar Council of Maharashtra (supra) this court considered whether a bar council, constituted
under the Advocates Act, 1961, performed activities that were charitable in nature; it was held that
the statute obliged several activities whose dominant object was advancement of public utility,
without profit motive. This court held that the provisions of the Act “enjoined upon avowedly with
the objective of protecting the litigating public from unscrupulous professionals by taking them to
task for any misconduct on their part; it is also one of the obligatory functions of a State Bar Council
to promote and support measures for law reform as also to conduct law seminars and organise talks
on legal topics by eminent jurists, obviously with a view to educate the general public, the function
prescribed by Clause (eee) is obviously charitable in nature, the same being to organise legal aid to
the poor. Amongst these various obligatory functions one under Clause (d) is to safeguard the rights,
privileges and interests of the advocates on its roll and it is difficult to regard it as a primary or
dominant function or purpose for which the body is constituted. Even this function apart from
securing speedy discharge of obligations by the litigants to the lawyers ensures maintenance of high
professional standards and independence of the Bar which are 1981 (3) SCR 489 necessary in the
performance of their duties to the society. In other words, the dominant purpose of a State Bar
Council as reflected by the various obligatory functions is to ensure quality service of competent
lawyers to the litigating public, to spread legal literacy, promote law reforms and provide legal
assistance to the poor while the benefit accruing to the lawyer-members is incidental…”
100. The view that prevailed, after the decision in Surat Art Silk (supra), therefore, was that so long
as the “dominant” object of a trust was charitable, and it did not essentially involve in business or
commercial activity, the generation of profits, or surpluses by it, through activities, incidental to that
main or dominant activity, did not undermine its charitable purpose, as long as the surpluses or
profits, were used for the advancement of an object of general public utility.
101. An interesting detail, is that the old Act did not define “charitable purpose” restrictively, in the
manner that the IT Act did, when enacted, in 1961. This lent a fair degree of interpretive flexibility,
to the courts, to decide whether a commercial or business element, could be interwoven with a
charitable object. The amendment of 1953 ensured that income “applied or accumulated for
application to such .. charitable purposes as relate to anything done within the taxable territories,
and in the case of property so held in part only for such purposes, the income applied or finally set
apart for application…”102 could not be included as taxable income of any charitable organization.
This provision is a precursor for Section 11 under the IT Act. In other words, the structure of the old
Act did not prohibit the carrying on of business; it spelt out a condition that any income derived
from business “carried on in the course of the actual carrying out of a primary purpose of the
institution” if applied for charitable purposes, was exempt.Assistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

102. The second aspect is that Surat Art Silk (supra), was rendered in the context of Section 2(15) of
the IT Act, as it stood originally. However, by the Taxation Laws Amendment Act, 1975 (w.e.f.
01.04.1977), Section 13(1)(bb) was inserted.
Section 4(3)(i) of the old IT Act.
That provision excluded the operation of Sections 11 and 12 (under which income of charities were
entitled to be exempted) in the case of income derived from business by charities engaged in
medical relief, education and relief to the poor, unless the business fulfilled a condition:
“(bb) in the cases of a charitable trust or institution for the relief of the poor,
education or medical relief, which carries on any business, any income derived from
such business, unless the business is carried on in the course of the actual carrying
out of a primary purpose of the trust or institution;"
103. The interpretation in Surat Art Silk (supra), obviously could not have been affected, in the light
of a subsequent amendment; however, what is of significance is that with effect from 01.04.1977, the
condition of actual carrying on a primary purpose of the trust while conducting business was
visualised only in the case of trusts involved in relief of the poor, education or medical relief. The
majority judgment in Surat Art Silk (supra) recognized this:
“8. […] Where therefore, there is a charitable trust or institution falling within any of
the first three categories of charitable purpose set out in Section 2 Clause (15) and it
carries on business which is held by it under trust for its charitable purpose, income
from such business would not be exempt by reason of Section 13(1)(bb). Section 11
Sub-section (4) would, therefore, have no application in case of a charitable trust or
institution falling within any of the first three heads of 'charitable purpose'.” Yet, the
court enunciated and applied the ‘predominant object’ test.103 The conscious
omission of the last object, i.e., the GPU category, in the newly inserted 13(1)(bb),
therefore, meant that when those trusts, while carrying out the object of
advancement of general public utility, had to conduct of business, the income was to
be taxed (because the main provision, under Section 13(1) excluded the operation of
Sections 11 and 12).
104. The next significant change, which occurred was with the Finance Act, 1983 (w.e.f. 01.04.1984).
This amendment:
See para 19 of Surat Art Silk (extracted above at paragraph 18 of this judgment).
(a) omitted the restrictive words under Section 2(15) i.e. “not involving the carrying
on of any activity for profit”
(b) omitted Section 13(1)(bb)Assistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

(c) Section 11(4A) was inserted104, by which - in relation to charities set up with the
object of general public utilities, “business” could be “carried on by an institution
wholly for charitable purposes and the work in connection with the business is
mainly carried on by the beneficiaries of the institution, and separate books of
account are maintained by the trust or institution in respect of such business”.
105. It is therefore clear that after 1 April, 1984, the statute did not contain any restriction as to the
nature of activity that could be carried on by GPU category charity. Furthermore, the condition in
Section 13(1)(bb) - which applied to other kinds of trusts, i.e., that their incomes could be exempt
under Section 11 to the extent they arose out of business, if the business was “in the course of the
actual carrying out of a primary purpose of the trust”- was deleted. On the other hand, the wording
of Section 11(4A) did seem to indicate that business activity was permissible if the objects of the
trust were wholly charitable, and such business were to be carried on by its beneficiaries. This legal
position continued, till the amendments in question were carried out, in relation to Section 2(15) in
2008.
106. Section 2 begins with the expression “unless the context otherwise requires”- as a preface to
every expression which is sought to be defined, under the IT Act. The 1922 Act did not contain any
words of restriction, in the definition "(4A) Sub-section (1) or sub-section (2) or sub-section (3) or
sub-section (3A) shall not apply in relation to any income, being profits and gains of business,
unless –
(a) the business is carried on by a trust wholly for public religious purposes and the business
consists of printing and publication of books or publication of books or is of a kind notified by the
Central Government in this behalf in the Official Gazette; or
(b) the business is carried on by an institution wholly for charitable purposes and the work in
connection with the business is mainly carried on by the beneficiaries of the institution, and
separate books of account are maintained by the trust or institution in respect of such business. …"
clause. The IT Act, however, defined charitable purpose - at the outset, restrictively,
and then, substantively enacted provisions that give effect to Parliamentary intent.
Section 10 (23C)(iv) exempts any “income” of “any other fund or institution
established for charitable purposes which may be approved by the prescribed
authority, having regard to the objects of the fund or institution and its importance
throughout India or throughout any State or States” from taxation.
A. Aids to interpretation
(i) History of the legislation
107. The amendments (i.e. Finance Act 2008, Finance Act 2009, Finance Act 2012 and Finance Act
2015) do not throw light – by way of statement of objects and reasons or notes on clauses. The court,
therefore would have to resort to the surrounding circumstances that led to the amendment.Assistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

108. The words of a statute are to be construed in their terms, according to the circumstances in
which they occur. At the same time, there is some authority for the proposition that statutes –
particularly amending provisions, may be considered in the light of the previous history of the
legislation. Justice Cardozo in Duparquet Co. v. Evans105 said that in questions relating to
construction, "history is a teacher that is not to be ignored”. In a similar vein, Chief Judge Learned
Hand said that “statutes always have some purpose or object to accomplish, whose sympathetic and
imaginative discovery is the surest guide to their meaning”106.
109. Some decisions of this Court have highlighted this aspect. In Bhuwalka Steel Indus. Ltd. & Ors.
v. Bombay Iron and Steel Labour Bd. & Ors. 107 this court observed that 297 U.S. 216 (1936)  Cabell
v. Markham (1945) 148 F 2d 737 2009 (16) SCR 618 “The legislative intent of the enactment may be
gathered from several sources which are, from the statute itself, from the preamble to the statute,
from the Statement of Objects and Reasons, from the legislative debates, reports of committees and
commissions which preceded the legislation and finally from all legitimate and admissible sources
from where they may be allowed. Reference may be had to legislative history and latest legislation
also. But, the primary rule of construction would be to ascertain the plain language used in the
enactment which advances the purpose and object of the legislation...”
110. In Chief Justice of Andhra Pradesh & Ors. v. L.V.A. Dixitulu & Ors.108 again, the court held
that resort to the history of the legislation is legitimate, for interpreting a provision:
“..in order to ascertain the true meaning of the terms and phrases employed, it is
legitimate for the Court to go beyond the arid literal confines of the provision and to
call in aid other well-recognised rules of construction, such as its legislative history,
the basic scheme and framework of the statute as a whole, each portion throwing
light on the rest, the purpose of the legislation, the object sought to be achieved, and
the consequences that may flow from the adoption of one in preference to the other
possible interpretation.”
111. Other decisions109 have also commented on the use of history of the legislation as a tool for its
construction. It is, therefore, clear that courts can look at the previous history of the statute, and the
changes it underwent to discern what is intended by the lawmakers when an amendment is
introduced, or a new law enacted. In light of these factors, it would therefore, also be useful for the
court to consider the background which led to the amendment – firstly in 2008 and thereafter in
2012 and 2015, seeking to restrict the nature of activities that a GPU category charity can
legitimately undertake.
(ii) Other extrinsic aids to construction of the statute
(a) Speeches in Parliament
112. Speeches made in the legislature or Parliament, can be looked into for throwing light on the
rationale for an amendment. There is some authority for 1979 (1) SCR 26 Lohia Machines Ltd. and
Ors. v. Union of India & Ors 1985 (2) SCR 686; Commissioner of Customs (Import), Mumbai v.Assistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

Dilip Kumar & Company & Ors 2018 (9) SCC 1 that proposition.110 Some light can be discerned
from the statement of the finance minister on the floor of Parliament, who answered to the criticism
levelled against the change brought about by the amendment in 2008. The finance minister
commented on the criticism levelled against the amendment to Section 2(15) in the following words:
"I once again assure the House that genuine charitable organisations will not in any
way be affected. The CBDT will, following the usual practice, issue an explanatory
circular containing guidelines for determining whether an entity is carrying on any
activity in the nature of trade, commerce or business or any activity of rendering any
service in relation to any trade, commerce or business. Whether the purpose is a
charitable purpose will depend on the totality of the facts of the case. Ordinarily,
Chambers of Commerce and similar organisations rendering services to their
members would not be affected by the amendment and their activities would
continue to be regarded as "advancement of any other object of general public
utility".”
(b) Departmental circulars
113. Learned counsel for the assessees relied upon Circular No. 1/2009 dated 27.03.2009 and
Circular No. 11/2008 dated 19.12.2008 issued by the Central Board of Direct Taxes. The relevant
part of Circular No. 11/2008 reads as follows:
“3. The newly inserted proviso to section 2(15) will apply only to entities whose
purpose is ‘advancement of any other object of general public utility’ i.e. the fourth
limb of the definition of ‘charitable purpose’ contained in section 2(15). Hence, such
entities will not be eligible for exemption under section 11 or under section 10(23C) of
the Act if they carry on commercial State of West Bengal v. Union of India 1964 (1)
SCR 371:
“A statute, as passed by Parliament, is the expression of the collective intention of the
legislature as a whole, and any statement made by an individual, albeit a Minister, of
the intention and objects of the Act cannot be used to cut down the generality of the
words used in the statute.” At the same time, later decisions have relaxed the rigor of
this rule. In K.P. Varghese v. Income-tax Officer, 1982 (1) SCR 629, this court,
referring to the budget speech of the Minister stated:
“Now it is true that the speeches made by the Members of the Legislature on the floor
of the House when a Bill for enacting a statutory provision is being debated are
inadmissible for the purpose of interpreting the statutory provision but the speech
made by the Mover of the Bill explaining the reason for the introduction of the Bill
can certainly be referred to for the purpose of ascertaining the mischief sought to be
remedied by the legislation and the object and purpose for which the legislation is
enacted.” Other decisions following the same approach are Ramesh Yeshwant
Prabhoo v. Prabhakar Kashinath Kunte 1995 (Supp 6) SCR 371; Novartis AG v. UnionAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

of India (2013) 6 SCC 1; Surana Steels (P) Ltd. v. Commissioner of Income Tax 1999
(2) SCR 589 and Kalpana Mehta & Ors. v. Union of India (UOI) and Ors 2017 (7) SCC
295.
activities. Whether such an entity is carrying on an activity in the nature of trade,
commerce or business is a question of fact which will be decided based on the nature,
scope, extent and frequency of the activity. 3.1. There are industry and trade
associations who claim exemption from tax u/s 11 on the ground that their objects are
for charitable purpose as these are covered under ‘any other object of general public
utility’. Under the principle of mutuality, if trading takes place between persons who
are associated together and contribute to a common fund for the financing of some
venture or object and in this respect have no dealings or relations with any outside
body, then any surplus returned to the persons forming such association is not
chargeable to tax. In such cases, there must be complete identity between the
contributors and the participants.
Therefore, where industry or trade associations claim both to be charitable institutions as well as
mutual organizations and their activities are restricted to contributions from and participation of
only their members, these would not fall under the purview of the proviso to section 2(15) owing to
the principle of mutuality. However, if such organizations have dealings with non-members, their
claim to be charitable organizations would now be governed by the additional conditions stipulated
in the proviso to section 2 (15).”
114. Circular No. 1/2009 dated 27.03.2009 contains explanatory notes to provisions of the Finance
Act, 2008. It inter alia reads as follows:
“5. Streamlining the definition of "charitable purpose"
5.1 Sub-section (15) of section 2 of the Act defines "charitable purpose" to include
relief of the poor, education, medical relief, and the advancement of any other object
of general public utility. It has been noticed that a number of entities operating on
commercial lines are claiming exemption on their income either under sub-section
(23C) of section 10 or section 11 of the Act on the ground that they are charitable
institutions. This is based on the argument that they are engaged in the
"advancement of an object of general public utility" as is included in the fourth limb
of the current definition of "charitable purpose". Such a claim, when made in respect
of an activity carried out on commercial lines, is contrary to the intention of the
provision. 5.2 With a view to limiting the scope of the phrase “advancement of any
other object of general public utility", sub-section (15) of section 2 has been amended
to provide that the advancement of any other object of general public utility shall not
be a charitable purpose, if it involves the carrying on of any activity in the nature of
trade, commerce or business, or any activity of rendering any service in relation to
any trade, commerce or business, for a cess or fee or any other consideration,
irrespective of the nature of use or application, or retention, of the income from suchAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

activity. Scope of this amendment has further been explained by the CBDT vide its
circular no.11/2008 dated 19th Dec 2008.”
115. Senior counsel appearing for the assessees relied on Section 119 of the IT Act as well as
decisions of this court, reported as Navnit Lal Jhaveri (supra) and UCO Bank Calcutta (supra) and
argued that departmental circulars are binding upon tax administrators, and should be legitimately
considered as aids of construction. This was in support of their reliance on the circulars in the
present case (No.11/2008 and No. 1/2009).
116. This court in Navnit Lal Jhaveri (supra) considered Sections 2(6A)(e) and 12(1B) of the IT Act
which were introduced by the Finance Act, 15, 1955 (w.e.f. 01.04.1955). As a result of these
amendments, the combined effect of the two provisions was that three kinds of payments made to
shareholders companies to which those applied, were treated as taxable dividend to the extent of the
accumulated profits held by the company. The provision was challenged. It was noticed that while
introducing the amendment, the Finance Minister assured that outstanding loans and advances –
otherwise liable to taxation as dividends in AY 1955-56, would not be subjected to tax if it were
shown that they had been genuinely refunded to the respective companies before 30.06.1955. The
government felt that unless such a step was taken, the operation of Section 12(1B) would lead to
extreme hardship, as it would cover the aggregate of all outstanding loans of past years and could
have led to unreasonably high liability on shareholders to whom the loans might have been
advanced. A circular [No. 20(XXI-6) /55] was issued by the Central Board of Revenue on
10.05.1955. The court, in that context, observed that:
“It is clear that a circular of the kind which was issued by the Board would be binding
on all officers and persons employed in the execution of the Act under s. 5(8) of the
Act. This circular pointed out to all the officers that it was likely that some of the
companies might have advanced loans to their shareholders as a result of genuine
transactions of loans, and the idea was not to the effect such transactions and not to
bring them within the mischief of the new provision.
The officers were, therefore, asked to intimate to all the companies that if the loans
were repaid before the 30th June, 1955, in a genuine manner, they would not be
taken into account in determining the tax liability of the shareholders to whom they
may have been advanced. In other words, past transactions which would normally
have attracted the stringent provisions of s. 12(1B) as it was introduced in 1955, were
substantially granted exemption from the operation of the said provisions by making
it clear to all the companies and their shareholders that if the past loans were
genuinely refunded to the companies, they would not be taken into account under s.
12(1B). Section 12(1B) would, therefore, normally apply to loans granted by the
companies, to their respective shareholders with full notice of the provisions
prescribed by it.”
117. This court ultimately upheld the amendments. As is evident, the judgment
noticed that the circular sought to soften the rigors of the otherwise harshAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

consequence of immediate application of the amendment. There was nothing in the
circular to make it applicable for all times to come. It was more in the nature of the
government issuing a temporary suspension of operation of the substantive
provision, introduced by the amendment.
118. In UCO Bank, Calcutta (supra), this court had to deal with circulars issued under
Section 145 regarding the method of accounting to be followed, in the context of bank
loans to be written off, when an assessee was following the mercantile system (of
accounting). The court inter alia, held that under Section 119 (2) of the IT Act, the
Central Board of Direct Taxes is empowered, for proper and efficient management of
assessment and collection of revenue to issue general or special orders in respect of
any class of incomes or class of cases setting forth directions or instructions, not
being prejudicial to assessees, as the guidelines, principles or procedures to be
followed in the work relating to assessment. The court held that the “9. […] The
Board thus has power, inter alia, to tone down the rigour of the law and ensure a fair
enforcement of its provisions, by issuing circulars in exercise of its statutory powers
under Section 119 of the Income-tax Act which are binding on the authorities in the
administration of the Act. Under Section 119(2)(a), however, the circulars as
contemplated therein cannot be adverse to the assessee. Thus, the authority which
wields the power for its own advantage under the Act is given the right to forego the
advantage when required to wield it in a manner it considers just by relaxing the
rigour of the law or in other permissible manners as laid down in Section 119. The
power is given for the purpose of just, proper and efficient management of the work
of assessment and in public interest.”
119. The view expressed in Navnit Lal Jhaveri (supra), and later elaborated in UCO
Bank (supra) appears to have found resonance in other decisions111 of this court. A
recent instance where this court took aid of explanatory circulars is in CIT v. Vatika
Township112 when after holding that the amendment in question applied
prospectively, the court also supported that holding by citing the revenue’s
understanding about such prospective application, in a circular. What is of note in
that judgment, is that the question of whether circulars or explanatory notes issued
by the executive are binding aids of construction was not discussed;
more importantly, the court first interpreted the statute, in its own terms, and then cited the
circular.
120. That circulars are per se not binding upon courts, in regard to interpretation of a statutory
provision and, at best are guides or aid to interpretation for departmental authorities, who are
bound to take them into account, was pithily stated in Keshavji Ravji & Co. and Ors. v.
Commissioner of Income Tax113 where the court observed as follows:
“This contention and the proposition on which it rests, namely, that all circulars
issued by the Board have a binding legal quality incurs, quite obviously, the criticismAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

of being too broadly stated. The Board cannot preempt a judicial interpretation of the
scope and ambit of a provision of the 'Act' by issuing circulars on the subject. This is
too obvious a proposition to require any argument for it. A circular cannot even
impose on the tax payer a burden higher than what the Act itself on a true
interpretation envisages. The task of interpretation of the laws is the exclusive
domain of the courts. However, this is what Sri Ramachandran really has in mind -
circulars beneficial to the assessees and which tone down the rigour of the law issued
in exercise of the statutory power under Section 119 of the Act or under
corresponding provisions of the predecessor Act are binding on the authorities in the
administration of the Act. The Tribunal, much less the High Court, is an authority
under the Act. The circulars do not bind them. But the benefits of such circulars to
the assessees have been held to be permissible even though the circulars might have
departed from the strict tenor of the statutory provision and mitigated the rigour of
the law. But that is not the same thing as saying that such circulars would either have
a binding effect in the interpretation of the provision itself or that the Tribunal and
the High Court are supposed to interpret the law in the light of the circular. There is,
Ellerman Lines Ltd. v. Commissioner of Income tax 1972 (2) SCR 168; K.P. Verghese
v. Commissioner of Income Tax 1982 (1) SCR 629; Union of India v. Azadi Bachao
Andolan 2003 (Supp 4) SCR 222 (2015) 1 SCC 1 1992 (2) SCC 231 however, support
of certain judicial observations for the view that such circulars constitute external
aids to construction.”
121. This view was accepted in Commissioner of Customs v. Indian Oil Corporation114, which
articulated the position with some degree of clarity. Commenting on Navnit Lal Jhaveri (supra) and
other decisions, it was observed that:
“30. No proposition was laid down in that case that even if the circular was clearly
contrary to the provisions of the Act it should prevail, On the other hand, the learned
Judges were inclined to view the circular as granting the benefit of exemption from
the operation of the impugned provisions subject to fulfilment of certain conditions.
Navnit Lal's case was referred to and construed in two cases decided by Benches of
two learned Judges. The first one was the case of Ellerman Lines Ltd. v.
Commissioner of Income Tax, West Bengal [1971]82ITR913(SC) and the other is K.P.
Varghese v. I.T. Officer, Ernakulam [1981]131ITR597(SC) . In both these cases it was
assumed that Navnit Lal's case was an authority for the proposition that even if the
directions given in the circular clearly deviate from the provisions of the Act, yet, the
Revenue is bound by it. These three decisions were repeatedly referred to and relied
on in the subsequent decisions in which the issue arose as regards the binding nature
of the circulars either under the Income Tax Act or under the Central Excise Act. In
between, there was the three Judge Bench decision in Sirpur Paper Mills Ltd. v.
Commissioner of Wealth Tax [1970]77ITR6(SC) in which Section 13 of the Wealth
Tax Act corresponding to Section 5(8) of the Income Tax Act, 1922 fell for
consideration. This Court took the view that the instructions issued by the Board may
control the exercise of the power of the departmental officials in mattersAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

administrative but not quasi-judicial. There is yet another decision of a three Judge
Bench which seems to make a dent on the weight of the proposition that the circulars
of the Board, even if they are plainly contrary to the provisions of the Act, should be
given effect to and binding on the authorities concerned in the administration of the
Act. That is the case of Keshavji Ravji & Co. v. I.T. Commissioner [1990] 183 ITR
1(SC)”
122. In view of a conflict between decisions, on the binding nature of circulars issued by the Board
(in the context of decisions of authorities dealing with indirect taxation issues) this court, by a
five-judge decision, in Ratan Melting and Wire Industries (supra) held that “6. Circulars and
instructions issued by the Board are no doubt binding in law on the authorities under the respective
statutes, but when the Supreme Court or the High Court declares the law on the question arising for
consideration, it would not be appropriate for the Court to direct that the 2004 (2) SCR 511 circular
should be given effect to and not the view expressed in a decision of this Court or the High Court. So
far as the clarifications/circulars issued by the Central Government and of the State Government are
concerned they represent merely their understanding of the statutory provisions. They are not
binding upon the court. It is for the Court to declare what the particular provision of statute says
and it is not for the Executive. Looked at from another angle, a circular which is contrary to the
statutory provisions has really no existence in law.”
123. In the opinion of this court, the views expressed in Keshavji Ravji, Indian Oil Corporation and
Ratan Melting and Wire Industries (though the last decision does not cite Navnit Lal Jhaveri),
reflect the correct position, i.e., that circulars are binding upon departmental authorities, if they
advance a proposition within the framework of the statutory provision. However, if they are
contrary to the plain words of a statute, they are not binding. Furthermore, they cannot bind the
courts, which have to independently interpret the statute, in their own terms. At best, in such a task,
they may be considered as departmental understanding on the subject and have limited persuasive
value. At the highest, they are binding on tax administrators and authorities, if they accord with and
are not at odds with the statute; at the worst, if they cut down the plain meaning of a statute, or fly
on the face of their express terms, they are to be ignored.
B. Interpretation of Section 2(15), the definition clause
124. Section 2 of the Income Tax Act opens with the phrase “unless the context otherwise requires”.
It has been held in S.K. Gupta & Anr. v. K.P. Jain & Anr.115 that where the definition of a term is
preceded by this phrase, normally, the definition given in the section “should be applied and given
effect to but this normal rule can be deviated if there is something in the context to show that the
definition should not be applied”. This rule was also adopted in Indira Nehru Gandhi v. Shri Raj
Narain and Anr.116 by Khanna, J and in Kalya Singh v. Genda (1979) 3 SCC 54.
(1975) Supp. SCC 1 Lal and Ors117. Previously, in Vanguard Fire and Insurance Company Ltd. v.
M/s. Fraser and Ross and Anr.118, it was held that the term “unless the context otherwise requires”
implies that the word or term so defined should be applied – subject to the context. It was held that
in view of such a qualification, the Court has not only to look at the words but also to look at theAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

context, collocation, and the object of such words in respect of such matters and factor the meaning
to be conveyed by the use of the words under the circumstances. Almost the same reasoning has
been echoed in N.K. Jain and Ors. v. C.K. Shah and Ors 119.
125. The importance of terms expressly defined in a statute is that they are internal and binding aids
to interpretation. The prefacing – to any definition – of the phrase “unless the context otherwise
requires” merely signifies that in case there is anything expressly to the contrary, in any specific
provision(s) in the body of the Act, a different meaning can be attributed. However, to discern the
purport of a provision, the term, as defined has to prevail, whenever the expression is used in the
statute. This rule is subject to the exception that when a contrary intention is plain, in particular
instances, that meaning is to be given. Therefore, in the light of the previous discussion, this court
would interpret the true meaning of “charitable purpose” after its amendment in 2008, taking into
consideration the subsequent changes.
126. As observed at the beginning of this judgment, GPU charities have been recognized as distinct
from the ‘per se categories’ of charity (education, medical relief, relief to the poor; and later -
preservation of water sheds, monuments, environment, and yoga). The judgment of this court in
Dharmadeepti (supra) has clarified that the per se categories – are not subjected to the restrictive
condition of eschewing activities of profit. This enunciation of the principle has been endorsed in all
later decisions – starting with Surat Art Silk (supra). Therefore, (1975) 3 SCR 783 (1960) 3 SCR 837
(1991) 1 SCR 938 the restriction imposed by Parliament against charities – prohibiting them from
carrying on activities of profit do not apply to the first six categories. Although the occasion did not
so arise in Surat Art Silk (supra) (since this Court was dealing with AYs prior to 1975), the provision
in Section 13(1)(bb) which prevailed then with effect from 01.04.1977 made the position clearer in
that it permitted these per se category charities, in the course of their actual carrying on of their
activities, to earn profits. Of course, this provision was deleted from 01.04.1984. Alongside, the
restriction imposed on GPUs from engaging in activities for profit, was also deleted.
127. As noticed in Thanthi Trust (supra), Section 11(4A) was originally introduced with effect from
01.04.1984 and substituted w.e.f. 01.04.1991. At that stage, the statute as it stood, did not restrict
GPU category charities from carrying on activities of profit or from carrying on business. This court
nevertheless was bound by the decision in Surat Art Silk (supra) which had ruled that:
(i) A GPU category charity with a constitution granting discretion to the trustees to
engage in charitable and non-charitable activities, could not claim the exemption;
(ii) The main or dominant purpose of the GPU category charity had to be essentially
charitable. If it was so, and it incidentally entailed carrying on activities that led to
profit, it was entitled to exemption.
128. This court’s understanding of the law as expressed in Thanthi Trust was therefore, coloured by
the statute as it existed, and the formulation in Surat Art Silk (supra). As a result, Thanthi Trust,
interpreted Section 11(4A) in this background and held that the assessee in that case incidentally
was engaged in activities for profit. The court was also of the opinion that Section 11(4A) was widerAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

than the revenue urged it to be, in that activities by way of business could not be carried on
incidentally by a Trust, which otherwise was a GPU category trust.
129. As noticed earlier, between Surat Art Silk (supra) and the decisions rendered thereafter (i.e.,
Bar Council of Maharashtra, Federation of Indian Chamber of Commerce and Industries and
Thanthi Trust) there were two changes in law in 1983 w.e.f. 01.04.1984 – on the one hand deleting
the restrictive words prohibiting GPU categories from carrying on profit, and deleting Section
13(1)(bb), and introducing Section 11(4A), on the other. There was otherwise no meaningful
statutory change. The position therefore, continued as it was for about 25 years.
130. After its introduction, by amendment in 2008, Section 2(15) read as follows:
(15) “charitable purpose” includes relief of the poor, education, medical relief, and the
advancement of any other object of general public utility:
Provided that the advancement of any other object of general public utility shall not
be a charitable purpose, if it involves the carrying on of any activity in the nature of
trade, commerce or business, or any activity of rendering any service in relation to
any trade, commerce or business, for a cess or fee or any other consideration,
irrespective of the nature of use or application, or retention, of the income from such
activity;”
131. The term “in the nature of” occurring in Section 2(15) has frequently been interpreted by this
court. In G. Venkataswami Naidu v. Commissioner of Income Tax120 the isolated transaction of sale
of land was held not to be activity in the nature of trade or business. In State of Tamil Nadu v.
Burmah Shell Oil Storage Distribution Company of India Ltd.121 the test indicated was whether the
“frequency, volume, continuity and regularity of transactions carried on with a profit-motive”. In
State of Tamil Nadu v. Shakti Estates122, the assessee’s activities in leasing forest lands, clearing
them, and creation of wooden sleepers, which were sold, as well as charcoal, which was sold, in a
series of “sustained, systematic and organised activities” was held to be in the nature of business. In
1959 (Supp 1) SCR 646 1973 (2) SCR 636 1989 (1) SCR 408 Director of Civil Supplies v. Member
Board of Revenue123 this court outlined, what would be activity in the nature of business:
“To regard an activity as business there must be a course of dealings, either actually
continued or contemplated to be continued with a profit- motive; there must be some
real and systematic or organised course of activity or conduct with a set purpose of
making profit. To infer from a course of transactions that it is intended thereby to
carry on business ordinarily there must exist the characteristics of volume, frequency,
continuity and system indicating an intention to continue the activity of carrying on
the transactions for a profit. But no single test or group of tests is decisive of the
intention to carry on the business. “
132. The term “in relation to” was interpreted in Renusagar Power Co. Ltd. v. General Electric
Co.124 in an arbitration clause - as follows:Assistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

“25... (2) Expressions such as “arising out of or “in respect of or “in connection with”
or “in relation to” or “in consequence of or “concerning” or “relating to” the contract
are of the widest amplitude and content..” In Mansukhlal Dhanraj Jain v. Eknath
Vithal Ogale125 this court underlined the amplitude to the term “relating to”:
“16. It is, therefore obvious that the phrase “relating to recovery of possession” as
found in Section 41(1) of the Small Cause Courts Act is comprehensive in nature and
takes in its sweep all types of suits and proceedings which are concerned with the
recovery of possession of suit property from the licensee and, therefore, suits for
permanent injunction restraining the Defendant from effecting forcible recovery of
such possession from the licensee-Plaintiff would squarely be covered by the wide
sweep of the said phrase.” In Doypack System (P) Ltd. v. Union of India126, this
court ruled that the expression “in relation to” is broad and is akin to the “concerning
with” and “pertaining to”; and is also expansive. The court observed:
“50. The expression “in relation to” (so also “pertaining to”), is a very broad
expression which presupposes another subject matter. These are words of
comprehensiveness which might have both direct significance as well as indirect
significance depending on the context [internal citation omitted].
1967 (3) SCR 778 1985 (1) SCR 432 1995 (1) SCR 996 1988 (2) SCC 299 Assuming
that the investments in shares and in lands do not form part of the undertaking but
are different subject matters, even then these would be brought within the purview of
the vesting by reason of the above expressions. In this connection reference may be
made to 76 Corpus Juris Secundum at pages 620 and 621 where it is stated that the
term “relate” is also defined as meaning to bring into association or connection with.
It has been clearly mentioned that “relating to” has been held to be equivalent to or
synonymous with as to “concerning with” and “pertaining to”. The expression
“pertaining to” is an expression of expansion and not of contraction.”
133. The position, therefore, with respect to what kind activities GPU charities could legitimately
undertake, was in a state of flux till 2015. However, the amendments cumulatively point to
prohibitions that were constant:
(1) the prohibition applicable to such charities involved in carrying on activities “in
the nature of trade, commerce or business, or any activity of rendering any service in
relation to any trade, commerce or business, for a cess or fee or any other
consideration” (2) “irrespective of the nature of use or application, or retention, of
the income from such activity” (i.e. activity in the nature of trade, commerce or
business for a cess, fee or other consideration).
134. By retrospective amendment, in Section 2(15), after the proviso, a second proviso was inserted
with effect from 01.04.2009 .-Assistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

"Provided further that the first proviso shall not apply if the aggregate value of the
receipts from the activities referred to therein is ten lakh rupees or less in the
previous year;";
With the introduction of the second proviso, the resulting situation was that the first
proviso (of exclusion of income through an activity as referred to) was inapplicable if
the aggregate value of the receipts of such activity did not exceed 10,00,000, and
later by Finance Act, 2012 – this was enhanced to 25,00,000.
135. The next important change took place through the Finance Act, 2015, which, w.e.f. 01.04.2016
substituted the two provisos to Section 2(15) with the following proviso:
“Provided that the advancement of any other object of general public utility shall not
be a charitable purpose, if it involves the carrying on of any activity in the nature of
trade, commerce or business, or any activity of rendering any service in relation to
any trade, commerce or business, for a cess or fee or any other consideration,
irrespective of the nature of use or application, or retention, of the income from such
activity, unless—
(i) such activity is undertaken in the course of actual carrying out of such
advancement of any other object of general public utility; and
(ii) the aggregate receipts from such activity or activities during the previous year, do
not exceed twenty per cent of the total receipts, of the trust or institution undertaking
such activity or activities, of that previous year;”
136. The limited relief, given by the second proviso, to GPU charities (for the period 2009-2015) was
that in case such GPU category charities did carry on activities undertaken in the course of actual
carrying out of their GPU objects that were in the nature of trade, commerce or business, or
rendered any service in relation to trade, business, etc., and collected fee, cess, or other
consideration, such income could still be exempt, if it did not exceed 10,00,000 (and later,
25,00,000). By the amendment of 2015, the second proviso was deleted and two conditions were
introduced, with respect to permissibility of carrying on trade, commerce, etc:
(i) such activity is undertaken in the course of actual carrying out of such
advancement of any other object of general public utility; and
(ii) the aggregate receipts from such activity or activities during the previous year, do
not exceed twenty percent of the total receipts, of the trust or institution undertaking
such activity or activities, of that previous year.
137. Having thus far discussed a nature of the changes to the term “charitable purpose” and how
judicial thinking has shaped it, this court would now explore the all important question of the scope
of the term of “any other object generally public utility” not being charitable purpose “if it involvesAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

the carrying on of any activity in the nature of trade, commerce or business or any activity of
rendering any service in relation to any trade, commerce or business, for a cess or fee or any other
consideration, irrespective of the nature of use or application, or retention, of the income from such
activity.”
138. Parliamentary endeavour, was to alter the regime applicable to taxation of GPU category
charities, under the IT Act. The absolute bar imposed on GPU charities from carrying on activities in
the nature of trade, commerce or business, or of rendering any service in relation to any trade,
commerce or business, for a cess or fee or any other consideration, evidences this intent. The
original Section 2(15) did not allude to trade, commerce or business, or any service in relation to
such activities. It only enjoined the GPU charities from involving themselves from carrying on of any
activity for profit127 (which was interpreted in Surat Art Silk). This substantial change brought
about by the amendments of 2008 -2012 and 2015 is the prohibition from engaging in any kind of
activity in the nature of business, commerce, or trade or any rendering any service in relation
thereto, and earning income by the way of cess, fee or consideration. In the opinion of this court, the
express deletion of the reference to ‘activity for profit’ on the one hand, and the enactment of an
expanded list of what cannot be done by GPU charities if they are to retain their characteristic as
charities, is an emphatic manner in which Parliament wished to express itself.
139. Counsel on both sides went to great lengths and cited several judgments for the proposition
that “trade or business” are terms which imply profit-making. They relied on Khoday Distilleries
(supra); M/s. Raipur Manufacturing (supra); Board of Trustees of the Port of Madras (supra), and
Physical Research Laboratory v. K. G. Sharma 128. It was contended by the revenue, that the
reference to terms “business, trade or commerce” and “service in relation to” such activities are
meant to imply that profit motive should be completely absent.
“…the advancement of any other object of general public utility not involving the carrying on of any
activity for profit"
(1997) 4 SCC 257.
At the same time - on behalf of the assessees, it was contented that if the proscribed activities i.e.,
business, commerce or trade or service in relation to such activities - is not the main or dominant
object of the GPU charity, any incidental involvement in such activities is permissible. Counsel on
behalf of many assessees urged that some of them are statutory corporations charged with
developing housing industrial infrastructure sector, regulation of professions (such as chartered
accountants, etc.). It was underlined that such corporations are agencies of the state, recognized as
“State” under Article 12 of the Constitution, and carry out the essential purposes for which they were
set up, which otherwise state departments would have been expected to carry out. It was then
emphasized that the activities of such corporations cannot be characterized as motivated by profit-
rather their essential purposes are to achieve objects of general public utility.
140. In Town Investments v. Department of Environment 129, it was remarked that “business” is an
‘etymological chameleon’. In NDMC (supra) - while dealing with the question of immunity of statesAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

and state corporations, municipal corporations and local authorities from union taxation, this court
(in a nine-judge bench composition) interpreted Article 289 of the Constitution130 and discussed
the nature of the activities that could be carried on by state or state agencies:
“Section 155(1) which by its own force levied taxes upon the trading and business
operations carried on by the Provincial Governments did not either define the said
expressions or specify which trading or business operations are subject to taxation.
On this account, the proviso was not and could not be said to have been, ineffective or
unenforceable. It was effective till 26-1- 1977 1 ALLER 813
289. Exemption of property and income of a State from Union taxation.—(1) The
property and income of a State shall be exempt from Union taxation.
(2) Nothing in clause (1) shall prevent the Union from imposing, or authorising the imposition of,
any tax to such extent, if any, as Parliament may by law provide in respect of a trade or business of
any kind carried on by, or on behalf of, the Government of a State, or any operations connected
therewith, or any property used or occupied for the purposes of such trade or business, or any
income accruing or arising in connection therewith. (3) Nothing in clause (2) shall apply to any
trade or business, or to any class of trade or business, which Parliament may by law declare to be
incidental to the ordinary functions of government.
1950. Clause (2) of Article 289 also similarly does not define or specify — nor does it require that the
law made thereunder should so define or specify. It cannot be said that unless the law made under
and with reference to clause (2) specifies the particular trading or business operations to be taxed, it
would not be a law within the meaning of clause (2). Coming back to the language of clause (2), a
question is raised, why does the proviso speak of taxation in respect of trade or business when the
main limb of sub-section (1) speaks only of taxes in respect of lands or buildings and income? Is the
ambit of proviso wider than the main limb? Is it an independent provision of a substantive nature
notwithstanding the label given to it as a proviso? Or is it only an exception? It is asked. We are,
however, of the considered opinion that it is more important to give effect to the language of and the
intention underlying the proviso than to find a label for it. It is clarificatory in nature without a
doubt; it appears to be more indeed. It is concerned mainly with the “income” (of Provincial
Governments) referred to in the main limb of sub-section (1). It speaks of tax on the “lands or
buildings” in that context alone, as we shall explain in the next paragraph. The idea underlying the
proviso is to make it clear that the exemption of income of Provincial Government operates only
where the income is earned or received by it as a Government; it will not avail where the income is
earned or received by the Provincial Government on account of or from any trade or business
carried on by it — that is a trade or a business carried on with profit motive. In the light of the
language of the proviso to Section 155 and clause (2) of Article 289, it is not possible to say that
every activity carried on by the Government is governmental activity. A distinction has to be made
between governmental activity and trade and business carried on by the Government, at least for the
purposes of this clause. It is for this reason, we say, that unless an activity in the nature of trade and
business is carried on with a profit motive, it would not be a trade or business contemplated by
clause (2). For example, mere sale of government properties, immovable or moveable, or granting ofAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

leases and licences in respect of its properties does not amount to carrying on trade or business.
Only where a trade or business is carried on with a profit motive — or any property is used or
occupied for the purpose of carrying on such trade or business — that the proviso [or for that matter
clause (2) of Article 289] would be attracted. Where there is no profit motive involved in any activity
carried on by the State Government, it cannot be said to be carrying on a trade or business within
the meaning of the proviso/clause (2), merely because some profit results from the activity [ For
example, almost every State Government maintains one or more guest houses in Delhi for
accommodating their officials and others connected with the affairs of the State. But, when some
rooms/accommodation are not occupied by such persons and remain vacant, outsiders are
accommodated therein, though at higher rates. This activity cannot obviously be called carrying on
trade or business nor can it be said that the building is used or occupied for the purpose of any trade
or business carried on by the State Government.] . We may pause here a while and explain why we
are attaching such restricted meaning to the words “trade or business” in the proviso to Section 155
and in clause (2) of Article 289. Both the words import substantially the same idea though,
ordinarily speaking, the expression “business” appears to be wider in its content. The expression,
however, has no definite meaning; its meaning varies with the context and several other factors. …
Having regard to the context in which the words “trade or business” occur — whether in the proviso
to Section 155 of the Government of India Act, 1935 or in clause (2) of Article 289 of our
Constitution — they must be given, and we have given, a restricted meaning, the context being levy
of tax by one unit of Federation upon the income of the other unit, the manifold activities carried on
by Governments under our constitutional scheme, the necessity to maintain a balance between the
Centre and the States and so on.” (emphasis supplied)
141. From NDMC (supra), it is clear that not every state activity resembling commerce can be
considered per se exempt from union taxation, in the context of Article 289. The court also
emphasized that mere sale or lease of government property does not imply trade or business. The
crucial or determinative element in the venture, so to say, is whether performance of a function is
actuated by profit motive.
142. What then is the true meaning of the expressions “fee, cess or consideration”? The careful
analysis of the amended proviso to Section 2(15), reveal that the prohibition applies in a four-fold
manner-
(a) The bar to engaging in trade, commerce or business,
(b) The bar to providing any service in relation to trade, commerce or business,
(c) wherein “for a fee, cess or any other consideration” is the controlling phrase for both (a) and (b)
(which are collectively referred to as “prohibited activities” for brevity)
(d) irrespective of the application of the income derived from such ‘prohibited activities’.
143. The impermissibility of any trade, or commercial activity or service, and income, from them,
was intended to be conveyed through the prohibition, in the first part of the definition of GPUAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

charities. The necessary implication which arises is that income (received as fee, cess, or any other
consideration) derived from such ‘prohibited activities’ is necessarily motivated by profit. The
ordinary meaning of fee or consideration would be synonymous with something of value, usually in
monetary terms. However, the use of the expression “cess” facially lends a different colour to all the
three expressions.
144. “Fee, cess and any other consideration” has to receive a purposive interpretation, in the present
context. If fee or cess or such consideration is collected for the purpose of an activity, by a state
department or entity, which is set up by statute, its mandate to collect such amounts cannot be
treated as consideration towards trade or business. Therefore, regulatory activity, necessitating fee
or cess collection in terms of enacted law, or collection of amounts in furtherance of activities such
as education, regulation of profession, etc., are per se not business or commercial in nature.
Likewise, statutory boards and authorities, who are under mandate to develop housing, industrial
and other estates, including development of residential housing at reasonable or subsidized costs,
which might entail charging higher amounts from some section of the beneficiaries, to
cross-subsidize the main activity, cannot be characterized as engaging in business. The character of
being ‘state’, and such corporations or bodies set up under specific laws (whether by states or the
centre) would, therefore, not mean that the amounts are ‘fee’ or ‘cess’ to provide some commercial
or business service. In each case, at the same time, the mere nomenclature of the consideration
being a “fee” or “cess”, is not conclusive. If the fee or cess, or other consideration is to provide an
essential service, in larger public interest, such as water cess or sewage cess or fee, such
consideration, received by a statutory body, would not be considered “trade, commerce or business”
or service in relation to those. Non-statutory bodies, on the other hand, which may mimic regulatory
or development bodies - such as those which promote trade, for a section of business or industry, or
are aimed at providing facilities or amenities to improve efficiencies, or platforms to a segment of
business, for fee, whether charged by subscription, or specific fee, etc, may not be charitable; when
they claim exemption, their cases would require further scrutiny.
145. This Court has in some decisions considered the term "cess". In Shinde Brothers Etc. v. Deputy
Commissioner, Raichur and Ors.131, Justice M. Hidyatullah, (though his was a dissenting judgment,
yet no contrary opinion was expressed by majority in regard to “cess”) said that:
“... The word "cess" is used in Ireland and is still in use in India although the word
rate has replaced it in England. It means a tax and is generally used when the levy is
for some special administrative expense which the name (health cess, education cess,
road cess etc.) indicates. When levied as an increment to an existing tax, the name
matters not for the validity of the cess must be judged of in the same way as the
validity of the tax to which it is an increment. By Schedule A(1) read with Section 3 of
the Act, it is collected as an additional levy with a tax, which, as described in Schedule
A, is undoubtedly one within the powers of the State Legislature and has been so even
prior to the Constitution....”
146. The seven-judge bench judgment of this court in India Cement Ltd. & Ors. v. State of Tamil
Nadu and Ors.132, approved the definition propounded by Hidayatulla, J. In Vijayalashmi Rice MillAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

and Ors. v. Commercial Tax Officers, Palakol & Ors133 this court observed that “13. Hence
ordinarily a cess is also a tax, but is a special kind of tax. Generally tax raises revenue which can be
used generally for any purpose by the State. For instance, the income tax or excise tax or sales tax
are taxes which generate revenue which can be utilised by the Union or the State Governments for
any purpose e.g. for payment of salary to the members of the armed forces or civil servants, police,
etc. or for development programmes, etc. However, cess is a tax which generates revenue which is
utilised for a specific purpose. For instance, health cess raises revenue which is utilised for health
purposes e.g. building hospitals, giving medicines to the poor, etc. Similarly, education cess raises
revenue which is used for building schools or other educational purposes.”
147. The expression "cess", therefore, implies a tax or impost levied for some special purpose, which
may be levied as an increment to an existing tax. The term “fee”, to some extent, has a similar
meaning. In The Commissioner of Income Tax, Lucknow v. U.P. Forest Corporation134 this court,
after considering other 1967 (1) SCR 548 1989 (Supp 1) SCR 692 (2006) 6 SCC 763 1998 (2) SCR 22
previous decisions, held that exaction, through process of law, of amounts may be called “fee” but
broadly are taxes:
“compulsory exaction's of money imposed for public purpose and requiring no
consideration to sustain it, but in a broad generic sense as to also include fees levied
essentially for services rendered. It is now well recognised that there is no generic
difference between a tax and a fee; both are compulsory exaction of money by public
authority.”
148. At the same time, there is also authority135 for the proposition that charges (which may be
termed as “fee” in given statutes) collected by local or municipal authorities, for supply of water, for
sewerage, etc., are not “taxes”- they form consideration for the specific services, by the concerned
local authority.
149. The term “consideration” however is broader. The plain meaning is a monetary payment, for
something obtained, in the form of goods, or services. In Commissioner of Central Excise, Mumbai
v. Fiat India (P) Ltd. & Ors136 this court explained the meaning of that term:
“Consideration means something which is of value in the eyes of law, moving from
the Plaintiff, either of benefit to the Plaintiff or of detriment to the Defendant. In
other words, it may consist either in some right, interest, profit or benefit accruing to
the one party, or some forbearance, detriment, loss or responsibility, given, suffered
or undertaken by the other, as observed in the case of Currie v. Misa (1875) LR 10 Ex.
153.
54. Webster's Third New International Dictionary (unabridged) defines,
consideration thus:
‘Something that is legally regarded as the equivalent or return given or suffered by
one for the act or promise of another.’Assistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

55. In volume 17 of Corpus Juris Secundum (p.420-421 and 425) the import of
'consideration' has been described thus:
‘Various definitions of the meaning of consideration are to be found in the text-books
and judicial opinions. A sufficient one, as stated in Corpus Juris and which has been
quoted and cited with approval is "a benefit to the party promising or a loss or
detriment to the party to whom the promise is made.....
See Union of India & Ors. v. State of U.P. & Ors. 2007(12) SCR 792; Union of India v.
Purna Municipal Corporation 1991 (Supp 1) SCR 183; Municipal Corporation,
Amritsar v. Senior Superintendent of Post Offices, Amritsar Division & Anr. 2004 (1)
SCR 913.
2012(12) SCR 975 At common law every contract not under seal requires a
consideration to support it, that is, as shown in the definition above, some benefit to
the promisor, or some detriment to the promisee.’
56. In Salmond on Jurisprudence, the word 'consideration' has been explained in the
following words.
A consideration in its widest sense is the reason, motive or inducement, by which a man is moved to
bind himself by an agreement. It is for nothing that he consents to impose an obligation upon
himself, or to abandon or transfer a right. It is in consideration of such and such a fact that he agrees
to bear new burdens or to forego the benefits which the law already allows him.
57. The gist of the term 'consideration' and its legal significance has been clearly summed up in
Section 2(d) of the Indian Contract Act which defines 'consideration' thus:
‘When, at the desire of the promisor, the promisee or any other person has done or
abstained from doing, or does or abstains from doing, or promises to do or to abstain
from doing, something, such act or abstinence or promise is called a consideration to
the promise.’
58. From a conspectus of decisions and dictionary meaning, the inescapable conclusion that follows
is that 'consideration' means a reasonable equivalent or other valuable benefit passed on by the
promisor to the promisee or by the transferor to the transferee. Similarly, when the word
'consideration' is qualified by the word 'sole', it makes consideration stronger so as to make it
sufficient and valuable having regard to the facts, circumstances and necessities of the case.”
150. Therefore, what Parliament intended – through the amendments in question was to proscribe,
involvement or engagement of GPU charities, from any form (“in the nature of”) of activities that
were trade, business or commerce, or engage or involve in providing services in relation to trade,
business or commerce- for a fee, cess or other consideration. The inclusion of the term “in the
nature of” was by design, to clarify beyond doubt, that not only business, trade or commerce, but allAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

activities in the nature of, or resembling them, were proscribed. Likewise, service in relation to such
activities, i.e., services relating, or pertaining to, such proscribed activities, too were forbidden.
151. The reference to fee or cess, is in the opinion of the court, only to emphasize that even a
statutory consideration, for a service to business, trade or commerce, would take the activity outside
the definition of a GPU charity. The sense in which the expressions “cess, fee or other consideration”
are used, is that if any amount, is received for trading, or business or commercial activity, or any
services to such activity, then, notwithstanding their nomenclature (as fee or cess, i.e. that they are
fixed under a law) the GPU charity cannot claim tax exempt status. To bring home this even more
pointedly- and underline a break from the past, the application of such amounts (received in the
course of trade, commerce, or business, or towards services in relation thereto) would be irrelevant,
as evidenced by the term “irrespective”, in the fourth limb of reading Section 2(15).
Summation of interpretation of Section 2(15)
152. Section 2(15) - in the wake of its several amendments between 2008 and 2015 - can be
juxtaposed with the interpretation of the unamended Section 2(15) by this Court. In Surat Art Silk
(supra), the principle enunciated was that so long as the predominant object of GPU category
charity is charitable, its engagement in a non-charitable object resulting in profits that are
incidental, is permissible. The court also declared that profits and gains from such activities which
were non-charitable had to be deployed or “fed” back to achieve the dominant charitable object.
153. The paradigm change achieved by Section 2(15) after its amendment in 2008 and as it stands
today, is that firstly a GPU charity cannot engage in any activity in the nature of trade, commerce,
business or any service in relation to such activities for any consideration (including a statutory fee
etc.). This is emphasized in the negative language employed by the main part of Section 2(15).
Therefore, the idea of a predominant object among several other objects, is discarded. The
prohibition is relieved to a limited extent, by the proviso which carves out the condition by which
otherwise prohibited activities can be engaged in by GPU charities. The conditions are:
(a) That such activities in the nature of trade, commerce, business or service (in
relation to trade, commerce or business for consideration) should be in the course of
“actual carrying on” of the GPU object, and
(b) The quantum of receipts from such activities should be exceed 20% of the total
receipts.
(c) Both parts of the proviso: (i) and (ii) (to Section 2 (15)) have to be read
conjunctively-given the conscious use of “or” connecting the two of them. This means
that if a charitable trust carries on any activity in the nature of business, trade or
commerce, in the actual course of fulfilling its objectives, the income from such
business, should not exceed the limit defined in sub-clause (ii) to the proviso.
C. Sections 10, 11, 12, 12A, 12AA and 13 of the IT ActAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

154. The effect of Sections 11, 12, 12A 12AA and 13 have been the subject of certain decisions137 of
this court. These decisions have noticed that Section 11 deals with income from trusts for charitable
and religious purposes and sets out which shall be subject to tax. Section 11(1) relates to application
of income towards the objects of the trust and exempts income of trusts with objects wholly
charitable or religious, or parts of income which relate to such objects. Section 11(1-A) provides for
exemption of capital gains derived by trusts. Section 11(1- B), speaks of failure to apply income as
per option under Explanation (2) to Section 11(1). Section 11(2) relates to setting apart or
accumulation of income. Section 11(3) deals with consequences of misapplication of income or
improper investment, while Section 11(3-A) relates to modification of purposes specified in Form 10
under Section 11(2). Sections 11(4) and 11(4-A) relate to business income of charitable trusts. Lastly,
Section 11(5) provides for the prescribed Commissioner of Income Tax v. Dawoodi Bohara Jamat,
(2014) 16 SCC 222; S.RM.M.CT.M. Tiruppani Trust v. Commissioner of Income Tax, (1998) 2 SCC
584 modes of investment in regard to the said trusts. Section 12 enacts that income of trusts created
wholly for charitable or religious purpose from voluntary contributions would be deemed as income
from the property held under such trust for the purposes of Sections 11 and 13 of the Act. Section
12-A prescribes the conditions for applicability of Sections 11 and 12 of the Act. It enacts two
essential conditions which are to be satisfied by a charitable or religious trust for claiming
exemption under those sections: firstly, that the person in receipt of the income has made an
application for registration of the trust on or after 01.06.2007 in the prescribed form and manner to
the Commissioner and such a trust is registered under Section 12-AA and secondly, where the total
income of the trust exceeds the maximum amount which is not chargeable to income tax in any
previous year, the accounts of the trust must be audited by a chartered accountant and the person in
receipt of the income should furnish such audit report in the prescribed form along with the return
of income. The procedure for grant (or refusal) of registration is prescribed by Section 12AA. Section
13 enlists the circumstances under which tax exemption is unavailable to religious or charitable
trusts otherwise falling under Sections 11 or 12. Section 13 therefore, has to be read with the
provisions of Sections 11 and 12 for deciding eligibility of a trust’s claim for exemption.
Distinction between business held under Trust [Section 11(4)] and Trust carrying on business
[Section 11(4A)]
155. Section 11(4) applies to cases where the business undertaking itself is the property held by a
trust. Thus, where the property held in trust, or where property settled by the donor or trust creator
in favour of the trustees itself is a business undertaking, then the income from such an undertaking
is covered by Section 11(4). Section 11(4A) operates differently. It is applicable to cases where the
trust carries on a business. Section 11(4A) states that when a trust carries on a business, unless the
business is incidental or ancillary to the attainments of the objectives of the trust, it would be
disentitled to an exemption under Section 11(1). It imposes a further condition that separate books
of accounts need to be maintained in such cases.
156. Section 11(1) confers an exemption from tax only where the property itself is held under a trust
or other legal obligation. It does not apply to cases where a trust or legal obligation is not created on
any property, but only the income derived from any particular property or source is set apart and
charged for a charitable or religious purpose. Similarly, when a business itself has been set aside forAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

the objects of the trust, then such business is held under trust and will fall under sub-section (4).
However, where the profits of a business of a trust are applied for charitable purposes, then such
business and trust will be governed by sub-section (4A).
157. Section 11(1) of the Act exempts income derived from property held under trust wholly for
charitable or religious purposes, to the extent to which such income is applied to such purposes in
India. The Act does not comprehensively define "property held under trust". Section 11(4) however,
provides that for the purposes of Section 11, the words "property held under trust" "includes a
business undertaking so held". Section 11(4A) as amended by the Finance (No.
2) Act, 1991 w.e.f. 01.04.1992 reads as under:-
"(4A) Sub-section (1) or sub-section (2) or sub-section (3) or sub-section (3A) shall
not apply in relation to any income of a trust or an institution, being profits and gains
of business, unless the business is incidental to the attainment of the objectives of the
trust or, as the case may be, institution, and separate books of account are
maintained by such trust or institution in respect of such business."
158. The question whether Section 11(4A) applies where a business is held under trust was answered
in the negative in earlier High Court judgments. The general provision under Section 4(3)(i) of the
old Act exempted income derived from property held under trust from taxation. Section 4(3)(ia)
however, enacted that any income derived from a business carried on behalf of a religious or
charitable trust would be entitled to exemption only if the business was carried on in the course of
carrying out of a primary purpose of the trust or the work in connection with the business is mainly
carried on by the beneficiaries of the trust. The revenue contended there that since clause (ia) was a
special provision dealing with exemption in respect of a business carried on for and on behalf of a
trust, any claim for exemption as regards the profits of such business can be made only under that
provision, and if conditions laid down therein are not satisfied, the assessee cannot rely upon the
general provision contained in Section 4(3)(i) to claim exemption thereunder on the ground that
business is property. In Gadodia Swadeshi Stores v. Commissioner of Income Tax, Punjab138, the
Lahore High Court held that the fact that the business carried on behalf of the trust failed to satisfy
the two conditions in Section 4(3)(ia) was no reason for it be denied exemption if it fell within
Section 4(3)(i). The court held that that the two categories mentioned in the two clauses did not
exclude each other.
159. This judgment of the Lahore High Court was approved- by reference by this court in J.K. Trust
v. CIT139 which was followed in Krishna Warriar (supra). By then the content of Section 4(3)(ia)
had been enacted as a proviso to clause (i) of Section 4(3), by amending Act of 1953. After referring
to the judgment of the Lahore High Court (supra) and rejecting the argument of the revenue that a
proviso in a statute be always read as limitation upon the effect of the main enactment Subbarao, J.
in Krishna Warriar (supra) observed as under:
“........But it is not an inflexible rule of construction that a proviso in a statute should
always be read as a limitation upon the effect of the main enactment. Generally theAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

natural presumption is that but for the proviso the enacting part of the section would
have included the subject-matter of the proviso; but the clear language of the
substantive provision as well as the proviso may establish that the proviso is not a
qualifying clause of the main provision, but is in itself a substantive provision. In the
words of Maxwell, "the true principle is that the sound view of the enacting clause,
the saving clause and the proviso taken and construed together is to prevail". So
construed we find no difficulty, See Gadodia Swadeshi Stores v. Commissioner of
Income Tax, Punjab, (1944) 12 ITR 385 1958 (1) SCR 65 as we will indicate later in
our judgment, in holding that the said clause (b) of the proviso deals with a case of
business which is not vested in trust for religious or charitable purposes within the
meaning of the substantive clause of section 4(3)(i).”
160. Therefore, to summarise on the legal position on this - if a property is held under trust, and
such property is a business, the case would fall under Section 11(4) and not under Section 11(4A) of
the Act. Section 11(4A) of the Act, would apply only to a case where the business is not held under
trust. There is a difference between a property or business held under trust and a business carried
on by or on behalf of the trust. This distinction was recognized in Surat Art Silk (supra), which
observed that if a business undertaking is held under trust for a charitable purpose, the income from
it would be entitled to exemption under Section 11(1) of the Act.
161. The interface between Sections 11(1) and (4) is of some importance. Firstly, under Section 11(4),
it is only the business which is held under the trust that would enjoy exemption in respect of its
income under Section 11(1). Secondly, there is a distinction between the objects of a trust and the
powers given to the trustees to effectuate the purposes of the trust. In this regard, the observations
of this court, in J.K. Trust (supra) assume relevance. There, one of the questions which arose was
whether the office of managing agency, which was an office of profit, was in fact settled upon trust
and, therefore, could be considered to be business held under trust. The court held that for the
purposes of Section 4(3)(i) of the 1922 Act, the office of managing agency was property which could
be held under trust. The revenue pointed out that on the terms of the trust deed previously executed
by the settlors (on 15.06.1945), the properties which the trustees are to hold and stand possessed of,
were only the sum of 1,00,000/-, any donations and contribution received by the trustees and all
accretions thereto, and investment in securities made from time to time representing the accretions.
It was contended that on the terms of the trust deed, the managing agency which was acquired on
10.09.1945 for a period of 20 years, cannot be said to be property held under trust since no part of
the initial amount of 1,00,000/-, which was settled upon the trust, was utilised in the acquisition of
the managing agency, so as to impress it with the character of accretion. While repelling this
contention, this court held that:
“.......But it is to be observed that clause (3) of the trust deed expressly provides for
the acquisition of the business of managing agency on behalf of the trust and "with
the help of the trust fund" and that precisely is what has happened and indeed,
reading together Exhibits A and B, it is impossible to resist the conclusion that both
the documents formed part of an integral scheme, and that what the settlors had in
view in clause 3 of Exhibit A is the very managing agency, which was acquired underAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

Exhibit B. There is considerable authority in England that when trustees carry on
business with the aid of trust fund, the position in law is the same as if they actually
employed it in the business, though, in fact, it be not actually invested therein.”
162. It seems that the test applied in J.K. Trust (supra) that for a business, to be considered as
property held under trust, it should have been either acquired with the help of the fund originally
settled upon trust or the original fund settled upon trust must have a proximate connection with the
later acquisition or carrying on of the business by the trustees. This distinction between a business
held and carried on by a trust, or a trust business run by the trustees, was noticed, in Thiagesar
Dharma Vanikam v. CIT140 by the Madras High Court and in Raja P.C. Lall Choudhary v. CIT,
Bihar & Orissa141 by the Patna High Court which held similarly in relation to Section 4(3)(i) of the
Act of 1922 (which corresponds to Section 11(1) of the 1961 Act).
163. What has to be examined, therefore, is whether the business itself is held under trust or is
carried on by and on behalf of the trust. Importantly Section 11(1) of the Act starts with the
expression "subject to the provisions of Sections 60 to 63........". Those provisions are in Chapter V of
the Act. Section 60 provides for the consequences of a transfer of income where there is no transfer
of assets.
(1963) 50 ITR 798 Madras.
(1957) 31 ITR 226 Patna.
It says that where a person transfers merely the income from an asset without transferring the asset
itself, he would continue to be chargeable to income tax. Section 61 provides for the consequences of
a revocable transfer of assets and says that the same would be the position where a person is in
receipt of income by virtue of a revocable transfer of assets. Section 62 provides for the
consequences of a transfer of assets for a specified period, and serves as an exception to Section 61.
An assessee has to be divested of the asset before ceasing to be assessable in respect of the income
from it. A mere direction that the income from the business shall be applied to the charitable objects
of a trust, without there being a settlement of the business itself upon trust, does not result in any
trust or legal obligation.
164. It is now, necessary to consider Thanthi Trust (supra) and its context. This court, while
interpreting Section 11(4A) (as amended w.e.f. 01.04.1992) stated that the provision requires the
“business income of a trust or institution to be exempt is that the business should be incidental to
the attainment of objectives of the trust or institution”.
165. The above observations have to be understood in the light of the facts before the court. Thanthi
Trust carried on newspaper business which was held under trust. The charitable object of the trust
was the imparting of education - which falls under Section 2(15) of the Act. The newspaper business
was incidental to the attainment of the object of the trust, namely that of imparting education. This
aspect is important, because the aim of the trust was a per se charitable object, not a GPU object.
The observations were therefore made, having regard to the fact that the profits of the newspaperAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

business were utilized by the trust for achieving the object of education. In the light of such facts, the
carrying on of newspaper business, could be incidental to the object of education- a per se category.
The Thanthi Trust (supra) ratio therefore, cannot be extended to cases where the trust carries on
business which is not held under trust and whose income is utilized to feed the charitable objects of
the trust.
166. What then is the interpretation of the expression “incidental” profits, from “business” being
“incidental to the attainment of the objectives” of the GPU charity (which occurs in Section 11(4A))?
As stated earlier, the interpretation of that expression in Thanthi Trust (supra) was in the context of
a per se charity, i.e., where the trust’s object was education. However, the restrictive or negative
terms enjoining GPU charities from carrying on profitable activity had been deleted in 1983 (w.e.f.
01.04.1984). In Surat Art Silk (supra), the court had articulated the determinative test for defining
whether a Trust was a GPU charity if its predominant object was to carry out a charitable purpose
and that if that was the case, the fact that it earned profit would not per se deprive it of tax
exemption. This decision was interpreted in the context of Section 11(4A) by this court in Thanthi
Trust, to hold that business can be incidental to attainment of the trust’s objects.
167. Thus, the journey which began with Surat Art Silk was interpreted in Thanthi Trust to mean
that the carrying on of business by GPU charity was permissible as long as it inured to the benefit of
the trust. The change brought about by the amendments in questions, however, place the focus on
an entirely different perspective: that if at all any activity in the nature of trade, commerce or
business, or a service in the nature of the same, for any form of consideration is permissible, that
activity should be intrinsically linked to, or a part of the GPU category charity’s object. Thus, the test
of the charity being driven by a predominant object is no longer good law. Likewise, the ambiguity
with respect to the kind of activities generating profit which could feed the main object and
incidental profit-making also is not good law. What instead, the definition under Section 2(15)
through its proviso directs and thereby marks a departure from the previous law, is – firstly that if a
GPU charity is to engage in any activity in the nature of trade, commerce or business, for
consideration it should only be a part of this actual function to attain the GPU objective and,
secondly – and the equally important consideration is the imposition of a quantitative standard -
i.e., income (fees, cess or other consideration) derived from activity in the nature of trade, business
or commerce or service in relation to these three activities, should not exceed the quantitative limit
of 10,00,000 (w.e.f. 01.04.2009), 25,00,000 (w.e.f. 01.04.2012), and 20% (w.e.f. 01.04.2016) of
the total receipts. Lastly, the “ploughing” back of business income to “feed” charity is an irrelevant
factor – again emphasizing the prohibition from engaging in trade, commerce or business.
168. If one understands the definition in the light of the above enunciation, the sequitur is that the
reference to “income being profits and gains of business” with a further reference to its being
incidental to the objects of the Trust, cannot and does not mean proceeds of activities incidental to
the main object, incidental objects or income derived from incidental activities. The proper way of
reading reference to the term “incidental” in Section 11(4A) is to interpret it in the light of the
sub-clause (i) of proviso to Section 2(15), i.e., that the activity in the nature of business, trade,
commerce or service in relation to such activities should be conducted actually in the course of
achieving the GPU object, and the income, profit or surplus or gains can then, be logicallyAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

incidental. The amendment of 2016, inserting sub clause (i) to proviso to Section 2(15) was therefore
clarificatory. Thus interpreted, there is no conflict between the definition of charitable purpose and
the machinery part of Section 11(4A). Further, the obligation under Section 11(4A) to maintain
separate books of account in respect of such receipts is to ensure that the quantitative limit imposed
by sub-clause (ii) to Section 2(15) can be computed and ascertained in an objective manner.
169. The conclusion recorded above is also supported by the language of seventh proviso142 to
Section 10(23C). Whereas Section 2(15) is the definition clause, Section 10 lists out what is not
income. Section 10(23C) – by sub-clauses
(iv) and (v) exempt incomes of charitable organisations. Such organisations and institutions are not
limited to GPU category charities but rather extend to other types of charities (i.e. the per se kind as
well). The controlling part of Section 10(23C) along with the relevant clauses (iv) and (v) seek to
exclude income received by the concerned charities. However, the provisos hedge such exemption
with conditions. The seventh proviso - much like Section 11(4A) and the definition - carve out an
exception, to the exemptions such that income derived by charities from business, are not exempt.
The seventh proviso virtually echoes Section 11(4A) in that business income derived by a charity (in
the present case, the GPU charities) which arises from an activity incidental to the attainment of its
objective is not per se excluded.
170. Classically, the idea of charity was tied up with eleemosynary143. However, “charitable
purpose” – and charity as defined in the Act have a wider meaning where it is the object of the
institution which is in focus. Thus, the idea of providing services or goods at no consideration, cost
or nominal consideration is not confined to the provision of services or goods without charging
anything or charging a token or nominal amount. This is spelt out in Indian Chamber of Commerce
(supra) where this Court held that certain GPUs can render services to the public with the condition
that they would not charge “more than is actually needed for the rendering of the services, - may be
it may not be an exact equivalent, such mathematical precision being impossible in the case of
“Provided also that nothing contained in sub-clause (iv) or sub-clause (v) or sub-clause (vi) or
sub-clause (via) shall apply in relation to any income of the fund or trust or institution or any
university or other educational institution or any hospital or other medical institution, being profits
and gains of business, unless the business is incidental to the attainment of its objectives and
separate books of account are maintained by it in respect of such business:” Providing relief from
distress to humans based on Christian values - refer to Director of Income Tax v. Bharat Diamond
Bourse (2002) 10 SCC 392, and Bangalore Water Supply and Sewage Undertaking v. A Rajappa
(1978) 2 SCC 213.
variables, - may be a little surplus is left over at the end of the year – the broad inhibition against
making profit is a good guarantee that the carrying on of the activity is not for profit”.
171. Therefore, pure charity in the sense that the performance of an activity without any
consideration is not envisioned under the Act. If one keeps this in mind, what Section 2(15)
emphasizes is that so long as a GPU’s charity’s object involves activities which also generates profits
(incidental, or in other words, while actually carrying out the objectives of GPU, if some profit isAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

generated), it can be granted exemption provided the quantitative limit (of not exceeding 20%)
under second proviso to Section 2(15) for receipts from such profits, is adhered to.
172. Yet another manner of looking at the definition together with Sections 10(23) and 11 is that for
achieving a general public utility object, if the charity involves itself in activities, that entail charging
amounts only at cost or marginal mark up over cost, and also derive some profit, the prohibition
against carrying on business or service relating to business is not attracted - if the quantum of such
profits do not exceed 20% of its overall receipts.
173. It may be useful to conclude this section on interpretation with some illustrations. The example
of Gandhi Peace Foundation disseminating Mahatma Gandhi’s philosophy (in Surat Art Silk)
through museums and exhibitions and publishing his works, for nominal cost, ipso facto is not
business. Likewise, providing access to low-cost hostels to weaker segments of society, where the fee
or charges recovered cover the costs (including administrative expenditure) plus nominal mark up;
or renting marriage halls for low amounts, again with a fee meant to cover costs; or blood bank
services, again with fee to cover costs, are not activities in the nature of business. Yet, when the
entity concerned charges substantial amounts- over and above the cost it incurs for doing the same
work, or work which is part of its object (i.e., publishing an expensive coffee table book on Gandhi,
or in the case of the marriage hall, charging significant amounts from those who can afford to pay,
by providing extra services, far above the cost-plus nominal markup) such activities are in the
nature of trade, commerce, business or service in relation to them. In such case, the receipts from
such latter kind of activities where higher amounts are charged, should not exceed the limit
indicated by proviso (ii) to Section 2(15).
174. The insertion of Section 13(8)144, the seventeenth proviso to Section 10(23C) and third proviso
to Section 143(3) (all of which were inserted by Finance Act, 2012, but w.r.e.f. 01.04.2009), further
reinforces the interpretation of this Court, of “charitable purpose”. These provisions, form the
machinery to control the conditions under which income is exempt. The effect of the seventeenth
proviso to Section 10(23C) is to impose the same condition i.e., that that the trade, commerce or
business activity or service relating to trade, business or commerce, should be part of the GPU’s
activities, to achieve its object of advancing general public utility. The other condition– which is
drawn in as part of the exemption condition, is that if such trading or commercial activity takes
place the receipts should be confined to a prescribed percentage of the overall receipts. Section 13(8)
too reinforces the same condition.
175. In the opinion of this court, the change intended by Parliament through the amendment of
Section 2(15) was sought to be emphasised and clarified by the amendment of Section 10(23C) and
the insertion of Section 13(8). This was Parliaments’ emphatic way of saying that generally no
commercial or business or trading activity ought to be engaged by GPU charities but that in the
course of their functioning of carrying out activities of general public utility, they can in a limited
manner do so, provided the receipts are within the limit spelt out in Clause
(ii) of the proviso to Section 2(15).Assistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

“(8) Nothing contained in section 11 or section 12 shall operate so as to exclude any income from the
total income of the previous year of the person in receipt thereof if the provisions of the first proviso
to clause (15) of section 2 become applicable in the case of such person in the said previous year.” D.
What kinds of income or receipts may not be characterized as derived from trade, commerce,
business or in relation to such activities, for a consideration
(i) Statutory corporations, authorities or bodies
176. It would be essential now to deal with certain kinds of receipts which GPU charities, typically
statutory housing boards, regulatory authorities and corporations may be entitled to, if mandated to
collect or receive. During the course of hearing, learned counsels highlighted that statutory boards,
and corporations have to recover the cost of providing essential goods and services in public
interest, and also fund large scale development and maintain public property. These would entail
recovering charges or fees, interest and also receiving interest for holding deposits. It was further
pointed out that in some cases, income in the form of rents – having regard to the nature of the
schemes which the concerned board, trust or corporation may be mandated or permitted to carry
on, has to be received. For instance, in some situations, for certain kinds of properties, the boards
may be permitted only to lease out their assets and receive rents.
177. The answers to these, in the opinion of this court, are that the definition ipso facto does not
spell out whether certain kinds of income can be excluded. However, the reference to specific
provisions enabling or mandating collection of certain rates, tariffs or costs would have to be
examined. Generically, going by statutory models in enactments (under which corporations boards
or trust or authority by whatsoever name, are set up), the mere fact that these bodies have to charge
amounts towards supplying goods or articles, or rendering services i.e., for fees for providing typical
essential services like providing water, distribution of food grains, distribution of medicines,
maintenance of roads, parks etc., ought not to be characterized as “commercial receipts”. The
rationale for such exclusion would be that if such rates, fees, tariffs, etc., determined by statutes and
collected for essential services, are included in the overall income as receipts as part of trade,
commerce or business, the quantitative limit of 20% imposed by second proviso to Section 2(15)
would be attracted thereby negating the essential general public utility object and thus driving up
the costs to be borne by the ultimate user or consumer which is the general public. By way of
illustration, if a corporation supplies essential food grains at cost, or a marginal mark up, another
supplies essential medicines, and a third, water, the characterization of these, as activities in the
nature of business, would be self-defeating, because the overall receipts in some given cases may
exceed the quantitative limit resulting in taxation and the consequent higher consideration charged
from the user or consumer.
(a) Interpretation of Section 10(46) and Section 2(15)
178. Section (20A) was inserted by Finance Act, 1970 with effect from 01.04.1962. It had excluded
certain classes of income, of corporations145. This court had occasion to deal with the provision
while it was in force in the GIDC case (supra) . The court had then emphasized that the expression
“development” in Section 10(20A) should be understood widely; thus, all development programmesAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

“relating to any industry” fell within the purview of “development”. The court also highlighted that
nothing in the IT Act laid down how a corporation could be termed as a development corporation
nor was there anything mandating that fee chargeable by such corporations was confined to
non-industrial activities.
179. The decision in Gujarat Maritime Board case (supra) was rendered in the context of Section
10(20). That provision exempts income accruing to local authorities, from taxation. By Finance Act,
2002, an Explanation was added to Incomes not included in total income.
10. In computing the total income of a previous year of any person, any income falling within any of
the following clauses shall not be included-
xxxxxx xxxxxx xxxxxx (20A) any income of an authority constituted in India by or under any law
enacted either for the purpose of dealing with and satisfying the need for housing accommodation or
for the purpose of planning, development or improvement of cities, towns and villages, or for both.
Section 10(20) which defined “local authority” retrospectively. The Board ceased to enjoy exemption
which it had hitherto, in the absence of the retrospective definition. It, therefore sought exemption,
as a GPU category charity claiming that it was controlled by objects of general public utility having
regard to the provisions of its parent Act, i.e., the Gujarat Maritime Board Act. This court refuted the
argument of the revenue that if a corporation did not fall within the definition of “local authority” it
could not claim to be a GPU charity. It was held that Section 10(20) and Section 11 of the 1961 Act
operate in totally different spheres. Even if the Board is not considered as a local authority, it is not
precluded from claiming exemption under Section 11(1) of the 1961 Act. Therefore, the court read
Section 11(1) in light of the definition of the words “charitable purposes” as defined under Section
2(15). This court also relied upon the ruling in CIT v. APSRTC (supra) where the APSRTC –
constituted under the Road Transport Corporation Act, 1950 – having regard to the objectives of the
Act, was held to be a GPU charity, thus entitling it to exemption in terms of the IT Act.
180. In the light of these decisions, it is evident that the revenue’s narrow construction by which tax
exemption is denied on the ground that if an entity is not covered by Section 10(20A) – or the newly
applicable Section 10(46), it cannot claim benefit as a GPU charity under Section 11, is unsound.
These two provisions confer different though overlapping benefits. If an entity does not fulfil the
requirement of one provision because it does not answer the description of a body under that
provision, that ipso facto is not a bar for it to claim benefit of another provision.
181. Section 10(46) re-incarnated so to say Section 10(20A), which had been deleted w.e.f.
01.04.2003. This provision, i.e., Section 10(46) was inserted with effect from 01.04.2009
retrospectively by the Finance Act, 2011146. The Incomes not included in total income.
10. In computing the total income of a previous year of any person, any income falling within any of
the following clauses shall not be included-Assistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

conditions for applicability of Section 10(46), i.e., that specified income or a class of specified
income of ports, trusts or commissions, etc., established or constituted by or under Central or State
enactments with the object of regulating or administering any activity in the general public, is on
similar lines as in the case of GPU charities. Like in the case of GPU charities, there is a prohibition
by Section 10(46)(b) against such corporations, etc. engaging in commercial activity. This restriction
has been introduced for the first time [as that prohibition was absent in the now repealed Section 10
(20A)].
182. The term “commercial” is closely similar to, if not identical, with the phrase “in the nature of
trade, commerce or business.” The other condition in Section 10(46) is that the specified income to
be exempted, is to be notified by the Central Government in the Official Gazette. Facially the
allusion to commercial activity, appears to be in the nature of a complete bar to activities which are
akin to commerce or business, yielding profit. However, what needs to be kept in mind is that the
object of Section 10 is to remove from the taxable net, an entire class of receipts of income. Given
this object of Section 10, the interpretation of “commercial” activity has to be on the same lines as in
the case of income derived by GPU charities, in the course of their actual functioning, by involving in
activities in the nature of trade, commerce or business. Thus, if statutory corporations within
Section 10(46) derive their income by charging a nominal mark-up over the cost of service rendered
or goods supplied, meant to recover the costs of the activities they engage in primarily or to achieve
the object for which they were set up, such as development of housing, road infrastructure, xxxxxx
xxxxxx xxxxxx (46) any specified income arising to a body or authority or Board or Trust or
Commission (by whatever name called) or a class, thereof which-
(a) has been established or constituted by or under a Central, State or Provincial Act, or constituted
by the Central Government or a State Government, with the object of regulating or administering
any activity for the benefit of the general public;
(b) is not engaged in any commercial activity; and
(c) is notified by the Central Government in the Official Gazette for the purposes of this clause.
water supply, sewage treatment, supply of food grains, medicines, etc., with or without regulatory
powers, the mere fact that some surplus or gain is derived would not disentitle them from the
benefit of Section 10(46).
183. In this context, it would be useful to consider the judgment of the Delhi and Allahabad High
Courts in Greater Noida Industrial Development Authority v. Union of India147 (hereafter
“GNIDA”) and CIT v. Yamuna Expressway Industrial Development Authority148. In GNIDA
(supra), the High Court drew a distinction between bodies set up by the government with
commercial purpose and objects – which are motivated by profit, and other government bodies. The
court held, correctly so – that other government bodies are not entitled to exemption as they are
motivated by profit. Then, dealing with the term “commercial activity” under Section 10(46), it was
held that the decisive test is whether the activities for which consideration in the form of fee, service
charge etc., is collected, is “intrinsically associated, connected and had minimum nexus with theAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

object of regulating and administering the activity for the benefit of the public”.
184. It was also held that if the activity is not carried on commercial lines, i.e., with the profit motive
in mind, but the body is assigned an administrative role, having regard to the objects of the
controlling statute or law, exemption cannot be denied under Section 10(46). As juxtaposed,
activities for profit or activities which clearly were motivated by profit – carried on by government
or statutory bodies, cannot avail of exemption. The judgment in Yamuna Industrial Development
Authority (supra) is along the similar lines.
185. As far as boards and corporations which are tasked with development of industrial areas, by
statute, the judgments of this court, in Shri Ramtanu Cooperative Housing Society (supra) and
Gujarat Industrial Development (2018) 406 ITR 418 (hereafter “GNIDA”) (2017) 395 ITR 18
Corporation (supra) have declared that these bodies are involved in ‘development’ and are not
essentially engaged in trading. In Shri Ramtanu Cooperative Housing Society (supra) this court, by a
five judge bench, held that the Maharashtra Industrial Development Corporation is not a trading
concern, and observed as follows:
“These features of transfer of land, or borrowing of moneys or receipt of rents and
profits will by themselves neither be the indicia nor the decisive attributes of the
trading character of the Corporation. Ordinarily, a Corporation is established by
shareholders with their capital. The shareholders have their Directors for the
regulation and management of the Corporation Such a Corporation set up by the
shareholders carries on business and is intended for making profits. When profits are
earned by such a Corporation they are distributed to shareholders by way of
dividends or kept in reserve funds. In the present case, these attributes of a trading
Corporation are absent. The Corporation is established by the Act for carrying out the
purposes of the Act. The purposes of the Act are development of industries in the
State. The Corporation consists of nominees of the State Government, State
Electricity Board and the Housing Board. The functions and powers of the
Corporation indicate that the Corporation is acting as a wing of the State Government
in establishing industrial estates and developing industrial areas, acquiring property
for those purposes, constructing buildings, allotting buildings, factory sheds to
industrialists or industrial undertakings. It is obvious that the Corporation will
receive moneys for disposal of land, buildings and other properties and also that the
Corporation would receive rents and profits in appropriate cases. Receipts of these
moneys arise not out of any business or trade but out of sole purpose of
establishment, growth and development of industries.
17. The Corporation has to provide amenities and facilities in industrial estates and
industrial areas. Amenities of road, electricity, sewerage and other facilities in
industrial estates and industrial areas are within the programme of work of the
Corporation. The found of the Corporation consists of moneys received from the
State Government, all fees, costs and charges received by the Corporation, all moneys
received by the Corporation from the disposal of lands, buildings and otherAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

properties and all moneys received by the Corporation by way of rents and profits or
in any other manner. The Corporation shall have the authority to spend such sums
out of the general funds of the Corporation or from reserve and other funds. The
Corporation is to make provision for reserve and other specially denominated funds
as the State Government may direct. The Corporation accepts deposits from persons,
authorities or institutions to whom allotment or sale of land, buildings, or sheds is
made or is likely to be made in furtherance of the object of the Act. A budget is
prepared showing the estimated receipts and expenditure. The accounts of the
Corporation are audited by an auditor appointed by the State Government. These
provisions in regard to the finance of the Corporation indicate the real role of the
Corporation viz. the agency of the Government in carrying out the purpose and object
of the Act which is the development of industries. If in the ultimate analysis there is
excess of income over expenditure that will not establish the trading character of the
Corporation. There are various departments of the Government which may have
excess of income over expenditure.
************** ******** *********
20. The underlying concept of a trading Corporation is buying and selling.
There is no aspect of buying or selling by the Corporation in the present case. The Corporation
carries out the purposes of the Act, namely, development of industries in this State. The
construction of buildings, the establishment of industries by letting buildings on hire or sale, the
acquisition and transfer of land in relation to establishment of industrial estate or development of
industrial areas and of setting up of industries cannot be said to be dealing in land or buildings for
the obvious reason that the State is carrying out the objects of the Act with the Corporation as an
agent in setting up industries in the State. The Act aims at building an industrial town and the
Corporation carries out the objects of the Act. The hard core of a trading Corporation is its
commercial character. Commerce connotes transactions of purchase and sale of commodities,
dealing in goods. The forms of business transactions may be varied but the real character is buying
and selling. The true character of the Corporation in the present case is to act as an architectural
agent of the development and growth of industrial towns by establishing and developing industrial
estates and industrial areas. We are of opinion that the Corporation is not a trading one.”
186. In Shri Ramtanu Cooperative Housing Society (supra) no doubt, this court did not have to
decide whether the Maharashtra Industrial Development Corporation was entitled to tax exemption.
However, it examined the provisions of the Act, and the ratio, that such industrial development
corporations are not engaged in trading, is binding. Like in that case, here too, the concerned state
Acts (Gujarat Industrial Development Act, 1962 and the Karnataka Industrial Areas Development
Act, 1966) tasked the boards with planning and development of industrial areas. Their personnel are
appointed under the enactments and are deemed to be public servants. The state government is
empowered to acquire land, in exercise of eminent domain power, for their purposes; their audits
are by the Accountant General of the concerned state, or auditors appointed by the state. They are
authorized by law, to levy rates and charges, for the services they provide, on pre-determined basis.Assistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

In the light of these provisions, clearly, these boards and authorities perform objects of general
public utility; and they are not driven by profit motive.
187. There is a two-fold distinction between the now-deleted Section 10(20A) and the newly added
Section 10(46) (w.e.f. 01.06.2011). Firstly, that the erstwhile Section 10(20A) applied to a limited
class of undertaking i.e., the bodies, or corporations, constituted by or under any law-confined to the
planning and development of housing infrastructure. However, the newly added Section 10(46) is
wider in comparison and the activities of any body or authority or board constituted by or under any
central or State Act with “the object of regulating or administering any activity for the benefit of the
general public”, has broader import. In a sense, the newly added Section 10(46), resembles a GPU
category charity classified under Section 2(15). The second distinction is that Section 10(20A) did
not bar any board, or corporations, etc. from indulging in commercial activities. However,
sub-clause (b) of Section 10(46) imposes such a bar, and the concerned body cannot claim tax
exemption if it engages in commercial activity.
188. The manner in which GPU charities has been dealt with under the definition clause, i.e.,
Section 2(15), indicates that even though trading or commercial activity or service in relation to
trade, commerce or business appears to be barred – nevertheless the ban is lifted somewhat by the
proviso which enables such activities to be carried out if they are intrinsically part of the activity of
achieving the object of general public utility. Furthermore, in the case of GPU charities there is a
quantified limit of the overall receipts, which is permissible from such commercial activity. In the
case of local authorities and corporations covered by Section 10(46) no such activities are seemingly
permitted.
189. As was observed in the earlier part of this judgment – while considering whether for the period
01.0.2003 - 31.05.2011, statutory boards, corporations, etc. could have lawfully claimed to be GPU
charities, this court has observed that the nature of such corporations is not to generate profit but to
make available goods and other services for the benefit of public weal. If such corporations (falling
within the description of Section 10(46)) applied to the Central Government for exemption, the
treatment of their receipts, should be no different than how such receipts can and should have been
treated for the purposes of determining whether they are GPU charities, during the period when
Section 10(46) was not in existence. Furthermore, this court is of the opinion that having regard to
the observations in Gujarat Maritime Board case (supra), the denial of exemption under one
category cannot debar such corporations from claiming income exempt status under another
category.
(b) Summary in relation to statutory authorities/corporations
190. In light of the above discussion, this court is of the opinion that:
(i) The fact that bodies which carry on statutory functions whose income was eligible
to be considered for exemption under Section 10(20A) ceased to enjoy that benefit
after deletion of that provision w.e.f.Assistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

01.04.2003, does not ipso facto preclude their claim for consideration for benefit as GPU category
charities, under Section 11 read with Section 2(15) of the Act.
(ii) Statutory Corporations, Boards, Authorities, Commissions, etc. (by whatsoever names called) in
the housing development, town planning, industrial development sectors are involved in the
advancement of objects of general public utility, therefore are entitled to be considered as charities
in the GPU categories.
(iii) Such statutory corporations, boards, trusts authorities, etc. may be involved in promoting public
objects and also in the course of their pursuing their objects, involved or engaged in activities in the
nature of trade, commerce or business.
(iv) The determinative tests to consider when determining whether such statutory bodies, boards,
authorities, corporations, autonomous or self- governing government sponsored bodies, are GPU
category charities:
(a) Does the state or central law, or the memorandum of association, constitution,
etc. advance any GPU object, such as development of housing, town planning,
development of industrial areas, or regulation of any activity in the general public
interest, supply of essential goods or services - such as water supply, sewage service,
distributing medicines, of food grains (PDS entities), etc.;
(b) While carrying on of such activities to achieve such objects (which are to be
discerned from the objects and policy of the enactment; or in terms of the controlling
instrument, such as memorandum of association etc.), the purpose for which such
public GPU charity, is set-up - whether for furthering the development or a charitable
object or for carrying on trade, business or commerce or service in relation to such
trade, etc.;
(c) Rendition of service or providing any article or goods, by such boards, authority,
corporation, etc., on cost or nominal mark-up basis would ipso facto not be activities
in the nature of business, trade or commerce or service in relation to such business,
trade or commerce;
(d) where the controlling instrument, particularly a statute imposes certain
responsibilities or duties upon the concerned body, such as fixation of rates on
pre-determined statutory basis, or based on formulae regulated by law, or rules
having the force of law, setting apart amenities for the purposes of development,
charging fixed rates towards supply of water, providing sewage services, providing
food-grains, medicines, and/or retaining monies in deposits or government securities
and drawing interest therefrom or charging lease rent, ground rent, etc., per se,
recovery of such charges, fee, interest, etc. cannot be characterized as “fee, cess or
other consideration” for engaging in activities in the nature of trade, commerce, or
business, or for providing service in relation in relation thereto;Assistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

(e) Does the statute or controlling instrument set out the policy or scheme, for how
the goods and services are to be distributed; in what proportion the surpluses, or
profits, can be permissively garnered;
are there are limits within which plots, rates or costs are to be worked out; whether the function in
which the body is engaged in, is normally something a government or state is expected to engage in,
having regard to provisions of the Constitution and the enacted laws, and the observations of this
court in NDMC; whether in case surplus or gains accrue, the corporation, body or authority is
permitted to distribute it, and if so, only to the government or state; the extent to which the state or
its instrumentalities have control over the corporation or its bodies, and whether it is subject to
directions by the concerned government, etc.;
(f) As long as the concerned statutory body, corporation, authority, etc. while actually furthering a
GPU object, carries out activities that entail some trade, commerce or business, which generates
profit (i.e., amounts that are significantly higher than the cost), and the quantum of such receipts
are within the prescribed limit (20% as mandated by the second proviso to Section 2(15)) – the
concerned statutory or government organisations can be characterized as GPU charities. It goes
without saying that the other conditions imposed by the seventh proviso to Section 10(23C) and by
Section 11 have to necessarily be fulfilled.
(v) As a consequence, it is necessary in each case, having regard to the first proviso and seventeenth
proviso (the latter introduced in 2012, w.r.e.f 01.04.2009) to Section 10(23C), that the authority
considering granting exemption, takes into account the objects of the enactment or instrument
concerned, its underlying policy, and the nature of the functions, and activities, of the entity
claiming to be a GPU charity. If in the course of its functioning it collects fees, or any consideration
that merely cover its expenditure (including administrative and other costs plus a small proportion
for provision) - such amounts are not consideration towards trade, commerce or business, or service
in relation thereto. However, amounts which are significantly higher than recovery of costs, have to
be treated as receipts from trade, commerce or business. It is for those amounts, that the
quantitative limit in proviso
(ii) to Section 2(15) applies, and for which separate books of account will have to be maintained
under other provisions of the IT Act.
(ii) Statutory regulatory bodies/authorities
191. During the hearings, rival contentions were made in regard to the facial nature of the public
utility character of regulatory bodies. A sample special case was that of the Institute of Chartered
Accountants of India (ICAI). In respect of some years, the revenue has preferred appeals and in
respect of some others, the Institute has preferred appeals. Reliance was placed upon the provisions
of the ICAI Act and detailed submissions were made to emphasise that it plays a pivotal role in
regulating the entire universe of vocation of Chartered Accountants – i.e., selecting candidates that
can undergo the educational course, setting the syllabus for the Chartered Accountancy
examination; holding classes, training sessions and imparting education; conducting exams, etc. ItAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

was highlighted that the membership of the institute, i.e., those who are enrolled as Chartered
Accounts has grown significantly. Whereas in the end of financial year 2005, the membership was
1.23 lakhs, it had increased to 1,86,440 on 31.03.2012. Likewise, there was an exponential growth in
the students appearing in the examination - in 2005, it was 2,96,294, and on 31.03.2012, it had
increased to 10,70,839. Apparently, the Institute conducts distance education courses and also
conducts classroom instruction facilities. These are integrated with the course curriculum.
Additionally, it was urged that no commercial motive was involved; coaching and revisional classes
conducted are very nominally priced - ranging from 1500 to 2500 for one group, and from 4000
to 6000 for both groups, depending on cities where the classes are held.
192. During the submissions on behalf of the Institute, the financials for different years were
provided. It was revealed that the total outflow towards salaries for 2003-04 was 55.27 lakhs and
depreciation for the same was 51.64 lakhs. The total expenditure for that year was 1.0691 lakhs.
As against that, the Revenue earned from generation of fees for the corresponding year which was
1.78 crores and the corresponding expenditure was 96.93 lakhs. The corresponding figures for FY
2011-12 for salaries was 2.94 crores. The depreciation was Rs.4.05 crores. The total expenditure
thus was  6.9 crores. As against this, the amount received towards fees was 6.36 crores and
expenditure incurred towards coaching, including salaries, provisions of course material, etc. was
4.34 crores. The surplus (without including administrative expenditure) for that year was 2.01
crores. The Institute apparently cannot distribute the surplus or utilise it for any activity other than
what is set out under the controlling statute and its rules.
193. The Revenue highlighted that conducting courses leading to a professional qualification and
charging fees for it is in the nature of a ‘service’, and all services in relation to trade, commerce or
business squarely falls within the mischief of Section 2(15), which has to preclude the institute’s
claim for exemption as a GPU charity.
194. The Institute is a creature of the Institute of Chartered Accountants Act, 1949. By Section 4 of
this Act, every person who qualifies in the examination conducted by the Institute has to seek
registration as a Chartered Accountant. Only when members obtain certificates issued by the
Council of the Institute under Section 6 can they be known as a ‘Chartered Accountant’ and be
entitled to practice that profession (Sections 6 and 7). The Council of the Institute is constituted
under Section 9 which defines such constitution and the manner for holding elections, etc. The
functions of the Council by Section 15(2A) include approving the academic courses and their
contents, examining the candidates, regulation and articleship assistance, prescribing qualification
for entry of persons in the register, collection of fees from members; the regulation and maintenance
and status of the professional qualifications of the members of the Institute, etc. By Section 15A,
universities are enabled to impart education on subjects covered by the academic courses of the
Institute. However, by Section 15A(2) while awarding degrees or diplomas, their designation should
not resemble or be identical to what is awarded by the Institute. The finances are regulated by
Section 18. The Council is enjoined to maintain the register under Section 19 and has disciplinary
powers by virtue of Section 21A, 21B and 21C of the Act.Assistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

195. These provisions of the Act clarify beyond a doubt that the Institute performs statutory
functions in the larger public interest of regulating the standards of education, leading up to the
profession of Chartered Accountancy and also prescribing standards of professional etiquette,
behaviour, and discipline of its members. No other entity or body has the authority in law to
perform the functions that the Institute does. Although the Act regulating Chartered Accountancy
came into force prior to the Constitution of India, the subject (of regulating professions, etc.)
appears to be relatable to the exercise of legislative power under Entry 25 and 26 of the Concurrent
List149. Furthermore, they also In List III of the Seventh Schedule to the Constitution of India, “25.
Education, including technical education, medical education and universities, subject to the
provisions of entries 63, 64, 65 and 66 of List I; vocational and technical training of labour.
26. Legal, medical and other professions”.
appear to conform to Entry 65 of the Union List150 (which has been adverted to in Entry 25 of the
Concurrent List). As things stand, the Institute is the only body which prescribes the contents of
professional education and entirely regulates the profession of Chartered Accountancy. There is no
other body authorised to perform any other duties which it performs. It, therefore, clearly falls in the
description of a charity advancing general public utility. Having regard to the previous discussion on
the nature of charities and what constitutes activities in the ‘nature of trade, business or commerce’,
the functions of the Institute ipso facto does not fall within the description of such ‘prohibited
activities’. The fees charged by the Institute and the manner of its utilisation are entirely controlled
by law. Furthermore, the material on record shows that the amounts received by it are not towards
providing any commercial service or business but are essential for the providing of service to the
society and the general public.
196. Similarly, there are several other regulatory bodies that discharge functions which are
otherwise within the domain of the State. A singular characteristic of ICAI and other statutory
bodies which can be said to regulate specific functions and professions (including the profession of
Cost and Work Accountants, and Company Secretary, etc.) is the powers conferred upon them by
the statutes to prescribe standards and enforce them through disciplinary sanctions. Therefore, it is
held that bodies which regulate professions and are created by or under statutes which are enjoined
to prescribe compulsory courses to be undergone before the individuals concerned is entitled to
claim entry into the profession or vocation, and also continuously monitor the conduct of its
members do not ipso facto carry on activities in the nature of trade, commerce or business, or
services in relation thereto.
In List I of the Seventh Schedule to the Constitution of India, “65. Union agencies and institutions
for—
(a) professional, vocational or technical training, including the training of police officers; or
(b) the promotion of special studies or research; or
(c) scientific or technical assistance in the investigation or detection of crime.”Assistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

197. At the same time, this court would sound a note of caution. It is important, at times, while
considering the nature of activities (which may be part of a statutory mandate) that regulatory
bodies may perform, whether the kind of consideration charged is vastly or significantly higher than
the costs it incurs. For instance, there can be in given situations, regulatory fees which may have to
be paid annually, or the body may require candidates, or professionals to purchase and fill forms, for
entry into the profession, or towards examinations. If the level of such fees or collection towards
forms, brochures, or exams are significantly higher than the cost, such income would attract the
mischief of proviso to Section 2(15), and would have to be within the limits prescribed by sub-clause
(ii) of the proviso to Section 2(15).
198. The next set of ‘statutory regulatory authorities’ among the present batch are those related to
authorities set up under the Seeds Act, 1966 (i.e, the Andhra Pradesh State Seeds Certification
Authority and the Rajasthan State Seeds and Organic Production certification Agency). These two
entities are set up as societies under Section 8 of the Seeds Act, and comprise of farmers, farmers co-
operatives’ representatives, seed certification authorities, etc. The task of these agencies and
authorities is certification of seeds, to decide whether to certify supply of seeds of “any notified kind
or variety”, by applicants who may wish to offer them for trade. These agencies/authorities
scrutinize the samples to ensure they conform to the requisite standard notified under Section 6.
These decisions are subject to appeal under Section 11.
199. The functioning of the seed certification agency, is a crucial one, in those only seeds conforming
to prescribed standards, are permitted to be traded and used, by farmers. Such standards are - in the
context of the fact that agriculture is one of the mainstays of the economy, and furthermore, pivotal
for food security
- essential as they ensure efficacy of seeds and guarantee to the farmers that they can be relied upon.
The essential nature of the regulatory function performed by these certification agencies is obvious.
The nature of their activities is not by way of trade, commerce or business, nor service in relation to
trade commerce, business, for some form of consideration.
(iii) Trade Promotion bodies, councils, associations or organizations
200. Surat Art Silk (supra) and other decisions, had ruled that as long as the objects of trade
promotion bodies were for general public utility - wherein ‘trade promotion’ in itself, was held to be
a GPU - the fact that incidentally these bodies carried on some commercial activity, leading to profit,
did not preclude them from claiming to be driven by charitable purpose. As observed earlier, the
enunciation of those principles were in the context of the unamended Section 2(15).
201. The question that arises is whether the change in definition impacts the claims of trade
promotion bodies, federations of commerce, or such organizations, that they are GPU charities . The
judgment in Surat Art Silk (supra) proceeded on the assumption that trade promotion was the
pre-dominant object of the GPU charity before the court, and that other objects – including
procuring licences, trade etc. were incidental. The assessee in Surat Silk had clear trading objects:Assistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

“(b) To carry on all and any of the business of Art Silk Yarn, Raw Silk, Cotton Yarn as
well as Art Silk f loth, Silk Cloth and Cotton Cloth belonging to and on behalf of the
members.
********* **********
(e) To buy and sell and deal in all kinds of cloth and other goods and fabrics
belonging to and on behalf of the Members.” This court, nevertheless, held that since
the predominant object of the assessee was trade promotion, while furthering it, the
fact that some trading occurred, leading to income, did not preclude the assessee
from claiming tax exemption.
202. In the opinion of this court, the change in definition in Section 2(15) and the negative
phraseology - excluding from consideration, trusts or institutions which provide services in relation
to trade, commerce or business, for fee or other consideration - has made a difference. Organizing
meetings, disseminating information through publications, holding awareness camps and events,
would be broadly covered by trade promotion. However, when a trade promotion body provides
individualized or specialized services - such as conducting paid workshops, training courses, skill
development courses certified by it, and hires venues which are then let out to industrial, trading or
business organizations, to promote and advertise their respective businesses, the claim for GPU
status needs to be scrutinised more closely. Such activities are in the nature of services “in relation
to” trade, commerce or business. These activities, and the facility of consultation, or skill
development courses, are meant to improve business activities, and make them more efficient. The
receipts from such activities clearly are ‘fee or other consideration’ for providing service “in relation
to” trade, commerce or business.
203. The revenue has appealed to this court, in respect of two assessment years, in the case of
Apparel Export Promotion Council (AEPC). The objects of AEPC, which was set up in 1978 – include
promotion of ready-made garment export. To achieve that end, its objects include providing training
to instil skills in the workforce, to improve skills in the industry; guide in sourcing machinery; to
serve as a body advising, providing information on market or technical intelligence; assisting the
concerned industry in obtaining import licenses; showcase the best capabilities of Indian garment
exports through the prestigious “India International Garment Fair” organised twice a year by AEPC,
etc. These fairs host over 350 participants who exhibit their garment designs and patterns. Other
functions are to provide information, and to provide market research. AEPC also assists in
developing new design patterns and garments and to perform promotional activities in individual
foreign markets. Further, AEPC sends missions and trade delegations abroad, who participate in
international fairs; and conducts surveys to gather information on potential export of ready-made
garments.
204. As part of its functioning, it also books bulk space, which is then rented out to individual
Indian exporters, who showcase their products and services, and ultimately secure export orders.
Towards these services, i.e., booking and providing space, AEPC charges rentals. Now, these rents
are not towards fixed assets owned by it. They are in fact charges, or fees, towards services inAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

relation to business; likewise, the skill development and diploma courses conducted by it, for which
fees are charged, are to improve business functioning of garment exporters. Furthermore, market
surveys and market intelligence, especially country specific activities, aimed at catering to specified
exporters, or specified class of exporters, is also service in relation to trade, commerce or business.
205. In the circumstances, it cannot be said that AEPC’s functioning does not involve any element of
trade, commerce or business, or service in relation thereto. Though in some instances, the recipient
may be an individual business house or exporter, there is no doubt that these activities, performed
by a trade body continue to be trade promotion. Therefore, they are in the “actual course of carrying
on” the GPU activity. In such a case, for each year, the question would be whether the quantum from
these receipts, and other such receipts are within the limit prescribed by the sub-clause (ii) to
proviso to Section 2(15). If they are within the limits, AEPC would be – for that year, entitled to
claim benefit as a GPU charity.
(iv) Non-statutory bodies - ERNET, NIXI and GS1 India
206. ERNET is a not-for profit society, set up under the aegis of the Union Government. At one
time, government functionaries, including the late President, APJ Abdul Kalam, were members, on
account of their ex officio capacity. The objects of this assessee are to “ 3.1.1 To advance the cause of
computer communication in the country in all its aspects and dimensions with a view to provide
rapid nationwide development of the sector and technological and economic growth of the county.
3.1.2 To develop, design, setup and operate nationwide state of the art computer communication
infrastructure with international connectivity directed towards research and development,
advancement of high quality education, create and host content, express creative and academic
potential via intranet and intranet peer to peer connectivity among educational and research
institutions in the country and the world and make available the communication infrastructure to
users in academic, research and development institutions, Govt organizations in line with national
priorities.”
207. ERNET’s networks are a mix of terrestrial and satellite-based wide-area network. It provides
services through its 15 Points of Presence (PoPs) located across the country. All those are equipped
to provide access to Intranet, Internet and Digital Library through trial leased circuits and radio
links to the user institutions. The PoP at STPI Bengaluru provides Intranet and Internet access
through Satellite. ERNET provides, services, namely, Network Access Services, Network
Applications Services, Hosting Services, Operations Support Services und Domain Registration
Services under srnet.in, ac.in, edu.in & res.in domains. Funded through government grants, its
projects support educational networks and development of internet infrastructure in numerous
other segments of society.
208. Having regard to the nature of ERNET’s activities, it cannot be said that they are in the nature
of trade, commerce or business, or service, towards trade, commerce or business. It has to receive
fees, to reimburse its costs. The materials on record nowhere suggest that its receipts (in the nature
of membership fee, connectivity charges, data transfer differential charges, and registration charges)Assistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

are of such nature as to be called as fees or consideration towards business, trade or commerce, or
service in relation to it. The functions ERNET performs are vital to the development of online
educational and research platforms. For these reasons, it is held that the impugned judgment, which
upheld the ITAT’s order, does not call for interference.
209. The Revenue has appealed the decision of Delhi High Court in which the National Internet
Exchange of India (NIXI) was held to be a GPU category charity. The materials on record show that
NIXI was established in 2003 under the aegis of the Ministry of Information Technology of the
Union Government for the promotion and growth of internet services in India, to regulate the
internet traffic, act as an internet exchange, and undertake “.in” domain name registration.
Concededly, NIXI, is a not for profit, and is barred from undertaking any commercial or business
activity. Its object is to promote the interests of internet service providers and internet consumers in
India, improve quality of internet service, save foreign exchange, and carry on domain name
operations. It is bound by licensing conditions – which include the prohibition from altering its
memorandum, without the prior consent of the Union Government. According to the submissions
made on NIXI’s behalf, it charges annual membership fee of 1000/- and registration of second and
third level domain names at 500/- and 250/-. The finding of the ITAT and the High Court are
that NIXI’s objects and functioning are by way of general public utility and thus it is a GPU category
charity.
210. Having regard to the findings on record and the materials placed by the parties, it is evident
that NIXI carries on the essential – crucial purpose of promoting internet services and more
importantly, regulating domain name registration which is extremely essential for internet users in
India. A country’s need to have a domestic internet exchange, rather than depend on an
international one, cannot be overemphasized. The Union Government’s object of setting up of
internet exchange is part of its essential function as a government to regulate certain segment of the
communication networks. In the absence of a single entity authorized to register “.in” domain
names, there is bound to be chaos or confusion.
211. In view of the foregoing discussion, this Court is of the opinion that the revenue’s contention
that NIXI does not merely carry-on public purpose of regulatory activity but is involved in trade,
commerce, or business or in providing service in relation thereto, cannot be accepted.
212. The next assessee under consideration – is GS1 India. GS1 codes were developed and created by
GS1 International, Belgium (an international not-for- profit under Belgium tax law). This coding
system has been in use worldwide and is even mandatory for some services/goods, or adopted for
significant advantages being a singular identification system, recognized and accepted all over the
world. The code promotes universal standard in Electronic Data Inter-exchanged (EDI) and other
services. This system of coding has been accorded priority by the Government of India as it is a
compulsory requirement on products exported from India. Government of India had set up
non-profit organizations EAN India, now known as GS1 India (the assessee).
213. Counsel on behalf of GS1 India, submitted that GS1 is affiliated and conferred exclusive rights
relating to GS1 coding in India. The GS1 code on a product, provides a unique identification to itAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

with wide ranging benefits and advantages which facilitate tracking, tracing of the product, product
recalls, counterfeit detection, user safety due to accuracy, wastage control through accurate
monitoring and stock levels for commodities, security and safety of supply chains, detection of
illegal trade, etc. The unique identification or coding system developed and operated by GS1
International or GS1 India is recognized and accepted globally. Additionally, the unique
identification code can be enabled with RFID chip and other electronic technology. Being one of its
kinds globally, only a GS1 registered organization can set up and promote the said system/standard
within a country. These can be used for several fields including public distribution system,
agriculture, health products, etc. and has been successfully used for product package labels. The
utility and benefits of a universal coding system assessable by anyone across the globe, for the
consumers, government, manufacturers, traders, exporters, etc. are enormous and significant.
Initial registration fee of  20,000/- is charged by GS1, plus annual fee of 4,000/- (enhanced to 
5,000/- from financial year 2006-07 onwards) from third parties, who become subscribing
members, and are entitled to use the GS1 coding system.
214. It was submitted on behalf of GS1 that it was set up as society in 1996 and sponsored by the
Union Government. The Union Government representatives and the representatives of the trade
bodies are its members. The activities of GS1 are extremely important and have to be characterized
as involving general public utility. It was submitted that having regard to the fact that GS1 provides
services to all organizations regardless of whether they carry on business, trade or other commercial
activity, a narrow interpretation confining the expression “service in relation to” should not be
adopted. It was urged, that there is no dispute about the fact that GS1 was directed to be granted
registration under the IT Act, and that GS1 Belgium, the parent organization, so to say, which owns
the technology, has been granted the status of not for profit charity. GS1 urges that it is not dealing
or treating the prized rights as a right be exploited commercially to earn or generate profits. It is not
directly or indirectly subjecting their activity to market mechanism/dynamics (i.e., demand and
supply), rather it is motivated and prompted to serve the beneficiaries. Therefore, this is not a case
of commercial exploitation of intellectual property rights to earn profits (as contended by the
Revenue), but rather a case where a token fee has been fixed and payable by the user of the global
identification system. Clause 44 of GSI’s Memorandum of Association of the petitioner stipulates
that it is a "Not-for-Profit" society and the funds/receipts are to only be used for promotion of
objects of the society for which it is established, including sustenance and expansion.
215. The revenue contended that although GS1 India has a monopoly, the mere fact that it is stated
to be a Not for Profit Society with some governmental involvement in its management would not
detract from its essential nature; which is to sub-serve the interest of the business community. It
was elaborated in this context that GS1 by providing bar codes and the coding system secured by
license, not only exploits the intellectual property rights but is in fact engaged in services in relation
to trade, commerce or business. Counsel pointed to the fact that the revenues of GS1 has steadily
increased over the years. It was pointed out that according to the balance sheet the aggregate
registration fees receipt for the year ending 31.03.2007 was 1,80,80,760/- whereas for the year
ending 31.03.2008 which had increased to 4,85,47,170/-. Likewise, membership fees had
increased from 44,40,000/- as on 31.03.2007 to 93,42,500/-. Furthermore, renewal fees for the
year ending 2007 was 1,68,57,200/- whereas for the next year i.e., as on 31.03.2008 it wasAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

1,90,50,650/-. The Revenue submitted that even where income and interest were to be excluded,
the increase on a yearly basis was exponential. Likewise, it was pointed out that registration fees as
on 31.03.2011 was 4,24,69,850/- whereas as on 31.03.2012 it was 6,07,58,100/-; subscription fee
as on 31.03.2011 was 1,02,06,720/-; for the next year i.e., on 31.03.2012 it was 1,01,69,850/-.
Likewise, the subscription renewal fees as on 31.03.2011 was 4,18,62,804/- and the same head as
on 31.03.2012 was 4,46,71,134/-.
216. The Revenue emphasises the fact that GS1 is a monopolist organization, has exclusive licenses
in relation to bar coding technology which it admittedly uses for fee or other consideration. It is
highlighted that these services are provided mostly to business, trade purpose, manufacturing, etc.
On the other hand, GS1 urges that it performs the important public function which enables not
merely manufactures but others involved in supplies of various articles by packaging, etc., to
regulate and ensure their identity.
217. In the opinion of this Court, GS1’s functions no doubt is of general public utility. However,
equally the services it performs are to aid businesses manufactures, tradesmen and commercial
establishments. Bar coding packaged articles and goods assists their consigners to identify them;
helps manufactures, and marketing organizations (especially in the context of contemporary times,
online platforms which serve as market places). The objective of GS1 is therefore, to provide service
in relation to business, trade or commerce - for a fee or other consideration. It is also true, that the
coding system it possesses and the facilities it provides, is capable of and perhaps is being used, by
other sectors, in the welfare or public interest fields. However, in the absence of any figures,
showing the contribution of GS1’s revenues from those segments, and whether it charges lower
amounts, from such organizations, no inference can be drawn in that regard. The materials on
record show that the coding services are used for commercial or business purposes. Having regard
to these circumstances, the Court is of the opinion that the impugned judgment and order calls for
interference.
(v) State Cricket Associations
218. The revenue has preferred appeals against the decision of the Gujarat High Court in respect of
orders made in the cases of the Gujarat Cricket Association, the Saurashtra Cricket Association,
Baroda and Rajkot Cricket Associations and the decision of the Rajasthan High Court, in respect of
the Rajasthan Cricket Association. The main facts, relevant for deciding the questions involved are
set out in the order of the ITAT151 against which the Gujarat High Court rendered the impugned
judgment152. Since the legal issues are common in relation to all these ITA Nos: 1257/Ahd/13,
3303/Ahd/16, 3304/Ahd/16, 408/Ahd/17 Assessment years: 2009-10, 2010-11, 2011-12 and
2012-13.
SLP (D) No. 16597/2020 against a common judgment dated 27.9.2019, which relate to the Gujarat
Cricket Association, Saurashtra, Baroda and Rajkot Cricket Association Cricket Association.
matters, the facts relating to the Gujarat Cricket Association (GCA) may be considered for
convenience.Assistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

219. The objects of GCA (and other associations) are to control, supervise, regulate, promote or
encourage, and develop the game of cricket in the area under its jurisdiction. The association can
also undertake any other and all activities which may be beneficial to it. GCA’s objects include
activities aimed at creating, fostering and maintaining friendly and cordial relationship through
sports tournaments and competitions, to create a healthy spirit through the medium of sports in
general, and cricket in particular. The other objects include: to instil the spirit of sportsmanship in
school and college students, members of other institutions, and other citizens; instil the ideals of
cricket and educate them in the same; to select teams to represent the association in any competitive
forum; to arrange, supervise, hold, encourage and finance visits of teams; to arrange or manage
league and/or any other tournaments; to promote persons, meetings, competitions and matches in
relation to sports; and to offer, give/distribute or contribute towards prizes, medals and awards; to
lay out grounds for playing the game; and to provide pavilion, stadia, other conveniences and
amenities in connection therewith. The GCA also includes within its objects, providing coaching to
deserving persons in the various departments of the game of cricket; engaging professional
cricketers, coaches, umpires, groundsmen, and other employees, and to pay remuneration or
honorarium to them; and to start, sponsor and/or to subscribe to any fund for the benefit of such
persons or their families. The GCA can collect funds for the purpose of the Association and utilise it
in such manner as its Managing Committee considers desirable for the fulfilment of its objects.
220. The assessing authorities denied GCA’s claim and that of the other associations, that they were
charities. Before the ITAT, it was contended, on behalf of the revenue, inter alia, that looking at the
nature of the relationship of these state cricket associations with the Board of Cricket Control of
India (BCCI), the amounts received by these associations from BCCI were in the nature of
consideration or fees, for granting media rights, and collecting their share, among other things. This
amounted to a business or commercial activity. It would, in this context, be useful to quote the
observations set out in the ITAT’s order (which were part of the commissioner’s order). The
Commissioner had taken note of assessment proceedings in relation to BCCI, and set out its
submissions:
“9.7.2 The AO of BCCI, based on the communication of DIT(E), Mumbai, has not
granted benefit of section 11 & 12 of the Act to BCCI. The stand taken by BCCI during
its assessment proceedings is mentioned below. The BCCI vide its submission dated
03/12/2012 to the AO has explained its relationship with State Cricket Association as
follows:-
"1. BCCI is society registered under the Tamil Nadu Societies Registration Act. It was
formed in the year 1929 with the object of promotion and development of cricket in
India and is a member of the International Cricket Council (ICC) the regulatory body
for world cricket. As a member of ICC, BCCI represents India in bilateral tours
between member countries and in ICC tournaments such as the World Cup.
2. BCCI has 30 members out of whom 25 are state cricket associations, 2 are private
clubs and 3 are Central Government Institutions. BCCI does not own or manage the
infrastructure and facilities that are required for cricket. It encourages and overseesAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

the various state associations to promote the game, build the required infrastructure
organize tournaments, leagues, coaching camps etc. in their respective states.
Whenever a foreign team visits India, the international matches such as Test and ODI
are allotted by BCCI to the State Cricket Associations by a rotation policy. The
matches are conducted and managed by the respective state associations and over
time, arrangements have evolved about the respective responsibilities, rights, shares
of revenue etc. These have evolved in order to promote co-operation and unity among
the member associations and by applying the principles of equity and fairness, for
which the sport of cricket is renowned."
9.7.3 The BCCI in its submission dated 21/1/2013 earned subsidy paid to SCAs and TV Subvention
as stated as follows:-
"13.2 PAYMENTS TO STATE ASSOCIATIONS During the year, BCCI has paid
amounts to the state associations under the head "TV, Subventions to Associations".
This represents payment of 70% of the revenue from sale of media rights to the state
associations".
Whenever a foreign team visits India, the international matches such as Test and ODI are allotted by
BCCI to the state cricket associations by a rotation policy. The matches are conducted and managed
by the respective state associations. It is not possible for BCCI to conduct all these matches with its
own limited personnel. It is dependent on the state associations, their office bearers, their
employees and their network and resources at the local centre to conduct the matches.
The association manage the entire match right from provision of security to players, spectators in
coordination with respective state police personnel, taking other security measures like fire
prevention etc. The association incurs a good chunk of expenditure in conducting an International
Test/ODI/T20/IPL/CL T20 Matches.
In order to have fair and equitable sharing of the revenues, arrangements have evolved over time,
about the respective responsibilities, rights, shares of revenue etc. of BCCI and the state
associations. The state association is entitled to the ticket revenue and ground sponsorship
revenues. Expenses on account of security for players and spectators, temporary stands, operation
of floodlights, Score Boards, management of crowd. Insurance for the match, electricity charges,
catering etc are met by the state associations. On the other had expenditure on transportation of
players and other match officials, boarding and lodging, expenses on food for players and officials,
tour fee, match fee, etc are met by BCCI and revenues from sponsorship belong to BCCI. In respect
of revenues from sale of media rights, an arrangement has evolved over time. Until 1991-92 the
income from media rights was meager. With the growth in income from media rights, it became
necessary to optimize the arrangement for sale of media rights. For a Test series or ODI series
conducted in multiple centers and organised by BCCI and multiple state associations, it was found
that if each state association were to negotiate the sale of rights to events in its centre, its negotiating
strength would be low. It was, therefore, agreed that BCCI would negotiate the sale of media rights
for the entire country to optimize the income under this head. It was further decided that out of theAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

receipts from the sale of media rights 70% of the gross revenue less production cost would belong to
the state associations. Every year, BCCI has paid out exactly 70% of its receipts from media rights
(less- production cost) to the state associations. This amount has been utilized by the respective
associations to build infrastructure and promote cricket, making the game more popular, nurturing
and encouraging cricket talent, and leading to higher revenues from media rights.
************* **************** Even in the event that exemption under section 11 is denied, the
payments to state associations must be allowed as a deduction, as expenditure laid out or expended
wholly and exclusively for the purpose of earning such income, it must be appreciated that in order
to earn revenues, BCCI was and continues to be highly dependent on the state associations. BCCI
does not have the infrastructure and the resources to conduct the matches by itself and is dependent
on the state associations to conduct the matches. The income from media rights is dependent on the
efforts of the state associations in conducting the matches from which the media rights accrue. The
division of revenues and expenditure is a matter of arrangement between the parties. Certain
incomes such as sale of ticket revenues belong to the state associations, who meet the expenditure
on the matches such as security for players and spectators temporary stands, operation of
floodlights, Score Boards, management of crowd, insurance for the match, electricity charges,
catering etc. Whereas with regard to the income from sale of media rights, the arrangement between
BCCI and the State Associations has been that 70% of the revenue would belong to the State
Associations. As shown, this has been the arrangement between the parties for the twenty years. The
State Associations are entitled by virtue of established practice to 70% of the media right fee. It is in
expectation of this revenue that the various state associations take an active part and cooperate in
the conduct of the matches. This payment is therefore made only with a view to earn the income
from media rights.”
221. The ITAT accepted the assessee’s contentions, and held that the associations were GPU
charities:
“35. Let us take a pause here and examine as to what are the activities of the assessee
cricket associations so as to be brought within the ambit of trade, commerce or
business. We have seen objects of the association, which are reproduced earlier in our
order, and it is not even the case of the revenue that these objects have anything to do
with any trade, commerce or business; these objects are simply to promote cricket.
The trigger for invoking proviso to Section 2(15), as Shri Soparkar rightly contends,
has to an activity of the assessee which is in the nature of trade, commerce or
business. However, the case of the revenue authorities hinges on the allegation that
the way and manner in which cricket matches are being organized, particularly the
IPL matches, the activity of organizing cricket matches is nothing but brute
commerce. Undoubtedly, it would appear that right from the time Kerry Packer
started his World Series Cricket in 1977, there has been no looking back in
commercialization of cricket and the impact of this commercialization has not left
Indian cricket intact. The Indian Premier League and the rules of the game being
governed by the dictates of commercial considerations may seem to be one such
example of commercialization of Indian cricket. The difficulty for the case of theAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

revenue before us, however, is that these matches are not being organized by the local
cricket associations. We are told that the matches are being organized by the Board of
Cricket Control of India, but then, if we are to accept this claim and invoke the
proviso to Section 2(15) for this reason, it will amount to a situation in which proviso
to Section 2(15) is being invoked on account of activities of an entity other than the
assessees- something which law does not permit. We are not really concerned, at this
stage, whether the allegations about commercialization of cricket by the BCCI are
correct or not, because that aspect of the matter would be relevant only for the
purpose of proviso to Section 2(15) being invoked in the hands of the BCCI. We do
not wish to deal with that aspect of the matter or to make any observations which
would prejudge the case of the BCCI. Suffice to say that the very foundation of
revenue's case is devoid of legally sustainable basis for the short reason that the
commercialization of cricket by the BCCI, even if that be so, cannot be reason enough
to invoke the proviso to Section 2(15). We are alive o learned Commissioner (DR)'s
suggestion that the cricket associations cannot be seen on standalone basis as the
BCCI is nothing but an apex body of these cricket associations at a collective level and
whatever BCCI does is at the behest of or with the connivance of the local cricket
associations, and that it is not the case that anyone can become a Member of the
BCCI because only a recognized cricket association can become a Member of the
BCCI. We are also alive to learned Commissioner's argument that what is being
sought to be protected by the charitable status of these associations is the share of
these cricket associations from the commercial profits earned by the BCCI by
organizing the cricket matches. The problem, however, is that the activities of the
apex body, as we have explained earlier, cannot be reason enough to trigger proviso
to Section 2(15) in these cases. Whether these cricket associations collectively
constitute BCCI or not, in the event of BCCI being involved in commercial activities,
the taxability of such commercial profits will arise in the hands of the BCCI and not
the end beneficiaries. Even in such a case the point of taxability of these profits is the
BCCI and not the cricket associations, because, even going by learned
Commissioner's arguments, these receipts in the hands of the cricket associations is
nothing but appropriation of profits. What can be taxed is accrual of profits and not
appropriation of profits. In any event, distinction between the cricket associations
and the BCCI cannot be ignored for the purposes of tax treatment. There is no
dispute that the matches were organized by the BCCI, and the assessee cannot thus
be faulted for the commercial considerations said to be inherent in planning the
matches. As we make these observations, and as we do not have the benefit of hearing
the perspective of the BCCI, we make it clear that these observations will have no
bearing on any adjudication in the hands of the BCCI. Suffice to say that so far as the
cricket associations are concerned, the allegations of the revenue authorities have no
bearing on the denial of the status of 'charitable activities' in the hands of the cricket
associations before us- particularly as learned Commissioner has not been able to
point out a single object of the assessee cricket associations which is in the nature of
trade, commerce or business, and, as it is not even in dispute that the objects being
pursued by the assessee cricket associations are "objects of general public utility"Assistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

under section 2(15). All the objects of the assessee cricket associations, as reproduced
earlier in this order, unambiguously seek to promote the cricket, and this object, as
has been all along accepted by the CBDT itself, an object of general public utility.”
222. In granting relief, the ITAT was persuaded by the decision of the Madras High Court, in Tamil
Nadu Cricket Association v. Director of Income Tax (Exemptions) & Ors.153, and held “54. The
assessee is a member of the Board of Control for Cricket in India (BCCI), which in turn is a member
of ICC (International Cricket Council). BCCI allots test matches with visiting foreign team and one
day international matches to various member cricket associations which organise the matches in
their stadia. The franchisees conduct matches in the stadia belonging to the State cricket
association. The State association is entitled to all in-stadia sponsorship advertisement and beverage
revenue and it incurs expenses for the conduct of the matches. BCCI earns revenue by way of
sponsorship and [2014] 360 ITR 633 (Mad) media rights as well as franchisee revenue for IPL and it
distributes 70 per cent, of the revenue to the member cricket association. Thus, the assessee is also
the recipient of the revenue. Thus, for invoking section 12AA read with section 2(15) of the Act, the
Revenue has to show that the activities are not fitting with the objects of the association and that the
dominant activities are in the nature of trade, commerce and business. We do not think that by the
volume of receipt one can draw the inference that the activity is commercial. The Income-tax
Appellate Tribunal's view that it is an entertainment and, hence, offended section 2(15) of the Act
does not appear to be correct and the same is based on its own impression on free ticket, payment of
entertainment tax and presence of cheer group and given the irrelevant consideration. These
considerations are not germane in considering the question as to whether the activities are genuine
or carried on in accordance with the objects of the association. We can only say that the Income-tax
Appellate Tribunal rested its decision on consideration which are not relevant for considering the
test specified under section 12AA(3) to impose commercial character to the activity of the
association. In the circumstances, we agree with the assessee that the Revenue has not made out any
ground to cancel the registration under section 12AA(3) of the Act.
55. As regards the observation of the Income-tax Appellate Tribunal that IPL matches and Celebrity
cricket matches are also being held by the association and hence, it is an entertainment industry, we
need not go into these aspects for the order of the Director of Income-tax (Exemptions) casts no
doubt on the genuineness of the objects of the trust. Hence, it is for the Assessing Officer to take
note of all facts, while considering the same under section 11 of the Income-tax Act, 1961. We
disapprove the approach of the Tribunal in this regard. In the above said circumstances, we set aside
the order of the Income-tax Appellate Tribunal.”
223. The ITAT agreed with the assessees that TV subsidy amounts received by the associations were
“corpus donations” in furtherance of the BCCI’s resolution dated 05.09.2001. It accordingly held
that these amounts were in the capital field, irrespective of whether they were fully utilized by the
state association, or whether some part of it, was given to district associations. Thus, for AY 2009-
2010, the sum of 3,52,86,521 paid by BCCI to GCA was subsidy, falling in the capital field.
224. It was urged on behalf of the Revenue that the cricket associations are not carrying on any
charitable activity; reliance was placed on the facts to say that substantial amounts were received byAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

the state associations, towards their share of sale of media rights (as constituents or members of
BCCI), which are commercial receipts. Although the sale of those rights was by the BCCI, the lion’s
share of those amounts was that of the respective state associations. Furthermore, the state
associations owned the stadia, and actually conducted the matches, in respect of which stadium
advertisements and sponsorship amounts were received:
these, too, were in the nature of business or commercial activities. The assessees on
the other hand, submitted that they are distinct from the BCCI. It was sought to be
urged that the activity of sports and sport promotion is basically education, and
hence, per se exempt. Realizing the value of inculcating sportsmanship and fostering
the culture of sport, Parliament had introduced Section 10(23), to exempt income
received by sports bodies. However, that was deleted w.e.f. 01.04.2003. It was argued
that this does not preclude sports bodies, like cricket associations from claiming to be
charities. It was urged that even if the court were not to consider the cricket
associations to be education-related charities, they cannot be denied the status of
GPU charities, having regard to the sports promotional nature of their objects. It was
submitted that these bodies are primarily responsible for fostering the sport, talent
spotting, nurturing it, and providing opportunities to those who have the aptitude
and passion for the game of cricket. All these are objects of general public utility. It
was submitted that the amounts which BCCI collects may or may not be in the course
of commerce;
however, what is given to the associations is subsidy, which cannot be termed as consideration for
carrying on any commercial activity.
225. At the outset, the contention that sports promotion is ‘education’ and hence, per se exempt, has
to be dealt with. In Lok Shikshana Trust (supra) this court has comprehensively addressed the scope
of the term, and conclude that it would entail “scholastic” education:
“5. The sense in which the word “education” has been used in Section 2(15) is the
systematic instruction, schooling or training given to the young in preparation for the
work of life. It also connotes the whole course of scholastic instruction which a
person has received. The word “education” has not been used in that wide and
extended sense, according to which every acquisition of further knowledge
constitutes education. According to this wide and extended sense, travelling is
education, because as a result of travelling you acquire fresh knowledge. Likewise, if
you read newspapers and magazines, see pictures, visit art galleries, museums and
zoos, you thereby add to your knowledge. Again, when you grow up and have dealings
with other people, some of whom are not straight, you learn by experience and thus
add to your knowledge of the ways of the world. If you are not careful, your wallet is
liable to be stolen or you are liable to be cheated by some unscrupulous person. The
thief who removes your wallet and the swindler who cheats you teach you a lesson
and in the process make you wiser though poorer. If you visit a night club, you get
acquainted with and add to your knowledge about some of the not much revealedAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

realities and mysteries of life. All this in a way is education in the great school of life.
But that is not the sense in which the word “education” is used in clause (15) of
Section 2. What education connotes in that clause is the process of training and
developing the knowledge, skill, mind and character of students by formal schooling.”
Therefore, there is no doubt that the claim of the present sport associations will not
fall within ‘education’ and will have to be examined under the fourth limb of Section
2(15) – i.e., GPU category, if it is to make a case for tax exemption.
226. BCCI is the body which regulates cricket and represents the country. Within the country it
organizes and conducts the Ranji Trophy, the Irani Trophy, the Duleep Singh Trophy, the Deodar
Trophy and the NKP Salve Challenge Trophy. These are domestic events, yet only those who are
members of the Board and/or recognized by it can take part in these events. The members of the
Board (entitled to vote in its election) are the state cricket associations.154 The BCCI is the
country-level cricket regulator both off and on the fields, and its functions include selection of
players and umpires. The International Cricket Council (of which BCCI, as the representative body
of the country, is a member) possesses and exercises all the powers to regulate international
competitive cricket. It also exercises disciplinary power – in case of violation of the rules, a country
member or the player may be derecognized. The ICC exercises a monopoly over the sports at the
international level whereas BCCI does so at the country level. BCCI recognizes bodies which are
entitled to participate in the nominated tournaments. Players and umpires also are to be registered
with it.
Rule 3 (a) (ii) (B) of the latest BCCI Memorandum of Association and the Rules and Regulations
227. The game of competitive cricket, at the organizational level is structured in such a manner that
BCCI has umbilical ties with the state associations. Not only are the latter, the members who
constitute BCCI and elect its governing bodies, they also own vital infrastructure necessary to play
cricket: such as stadia, and all related facilities. BCCI does not own those facilities or infrastructure
and depends on them. Furthermore, the state associations are the channels through which players
are mostly selected, and get opportunities to participate in state, national and international level
cricket.
228. As things stand, therefore, the state associations and BCCI are linked closely. The management
of the game of cricket is structured in such a way that this link is apparent at every match or fixture
of significance. In the course of conducting matches (which are scheduled by the BCCI as the
national co- ordinating body), apart from amounts received towards sale of entry tickets, the state
associations also receive advertisement money, sponsorship fee, etc. from the BCCI. Aside from
these, media rights - i.e., broadcasting rights to each national or international event conducted at
various locales owned by the state associations, and digital rights (all of which are exclusive, in
nature) - are auctioned by BCCI. As noticed above, the BCCI, by its own admission, negotiates the
terms on which media rights are sold, on behalf of the state associations:
“For a Test series or ODI series conducted in multiple centers and organised by BCCI
and multiple state associations, it was found that if each state association were toAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

negotiate the sale of rights to events in its centre, its negotiating strength would be
low. It was, therefore, agreed that BCCI would negotiate the sale of media rights for
the entire country to optimize the income under this head. It was further decided that
out of the receipts from the sale of media rights 70% of the gross revenue less
production cost would belong to the state associations. Every year, BCCI has paid out
exactly 70% of its receipts from media rights (less- production cost) to the state
associations. This amount has been utilized by the respective associations to build
infrastructure and promote cricket, making the game more popular, nurturing and
encouraging cricket talent, and leading to higher revenues from media rights.”
229. These media, or broadcasting rights, are in the nature of intellectual property rights: under
Section 37 to 40 of the Copyrights Act, 1957. These rights- especially television and digital rights
enable the licensee or the successful bidder to exploit the telecast or broadcast commercially, by
carrying advertisements of various products and services, in the media. Given that (i) BCCI does not
own the stadia, and uses the entire physical infrastructure of the state associations (ii) expressly
negotiates on their behalf for the sale of such rights (which appear to be purely commercial
contracts), the associations’ assertions that they only received subsidy from BCCI, needed closer
examination.
230. The income and expenditure account for the year ending on 31.03.2009 shows that the total
income of the GCA was 4,03,98,736.81. Of these sponsorship money was 20,00,000/-; bank
interest was 2,21,88,527.05 and as against the head ‘India v. South Africa test match’, the sum of
1,51,97,741/- has been shown. Of the total of 2,21,02,441.45 shown as income, 32,24,591.25 is
shown as expenditure, only a fraction appears to have been expended towards promotion of cricket.
This is apparent from the following:
  S. No.                  Details of expenditure                      Amounts
  1.       Ground equipment of District Cricket Association                29,34,394/-
  2.       Prize money to all teams                                        27,86,796/-
  3.       Ground expenditure                                              20,06,228/-
  4.       Cricket academy expenses                                         9,51,067/-
  5.       Coach Fee                                                       10,06,040/-
  6.       Senior and Junior tournament subsidy to District                 7,00,000/-
           Cricket Association
           Total                                                         1,03,84,525/-
231. The details of the subsidy amounts received from BCCI for every match has been shown. This
aggregates to over 41 lakhs. Furthermore, the details received towards the India-South Africa test
fixture paid between 03.04.2008- 04.04.2008 has been shown. GCA received 1,57,00,000/-
towards sale of space; ticket sales yielded 27,57,700 and towards the head screen income, a sum of
3 lakhs was received. After deducting the expenditure, the excess income received for the year was
1,51,97,741/-.Assistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

232. In the case of Saurashtra Cricket Association, for the year ended on 31.03.2012, various heads
of income have been disclosed. These include entry fees which is 5200 onwards. Interest of income
received from Fixed Deposits was to the tune of 8,85,67,418/-; total amount of subsidy received
from BCCI is 17,56,72,490/-. Of these, the overwhelming share is towards the IPL money collected
by the BCCI – wherein Saurashtra Cricket Association’s share worked out to a total of
17,16,32,490/-.
233. Apart from this, the BCCI also reimbursed to Saurashtra Cricket Association the sum of
73,73,911/-. The income and expenditure account shows a head titled “subvention income from
BCCI” to the extent of 8,14,53,834/-. After deducting the heads of expenditure, excess of income
over expenditure for the AY was 69,96,537/-. The Cricket Association showed in the expenditure
column that the sum of 24,00,00,000/- was transferred to the Cricket infrastructure fund. For the
previous year, a sum of 21,21,00,000/- was transferred to the stadium fund.
234. It is quite evident that the activities of the cricket associations are run on business lines. The
associations own physical and other infrastructure, maintain them, have arrangements for
permanent manpower and have well-organised supply chains to cater to the several matches they
host. Many such matches are not at national level and are under-16 or under-18 matches at the
regional level. However, these activities are not to be seen in isolation but are to be regarded as part
of the overall scheme, and ecosystem in which the game of cricket is organized in India. Talent is
spotted, at local levels and dependent on the promise shown, given appropriate exposure.
235. On a close scrutiny of the expenses borne, having regard to the nature of receipts, the
expenditure incurred by Cricket Associations does not disclose that any significant proportion is
expended towards sustained or organized coaching camps or academies. Therefore, in the opinion of
this court, the ITAT fell into error in not considering the nature of receipts flowing from the BCCI
into the corpus of GCA and SCA – as well as other associations that are before this court- to
determine their true character. The ITAT appears to have been swayed by the submission that the
amount given by the BCCI were towards capital subsidy.
236. To determine whether a given receipt is to be characterized as falling in the revenue or capital
stream, the objective for which it is given as well as the manner in which it is utilized has to be
scrutinized. This aspect has been highlighted in Sahney Steel & Press Works Ltd v. Commissioner of
Income Tax155 in the following terms:
“It is not the source from which the amount is paid to the assessee which is
determinative of the question whether the subsidy payments are of revenue or capital
nature. The first proposition stated by Viscount Simon in Ostime case [28 TC 261 :
(1946) 1 All ER 668] is that if payments in the nature of subsidy from public funds
are made to the assessee to assist him in carrying on his trade or business, they are
trade receipts.” This has later been followed in Commissioner of Income Tax v. Ponni
Sugars156.Assistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

237. Recent trends have shown that media rights, especially broadcasting and digital media rights
have yielded colossal revenues to the BCCI. The model adopted in the last 10 years or so has been to
auction media rights in respect of events over a 3 or 5-year period. As discussed previously, these
media rights are not per se owned by BCCI, which is but an association of persons or agglomerate of
all the State Cricket Association. The stadia which form the venue for these cricket matches (in
relation to which media rights are transferred or licensed) are 1997 (Supp 4) SCR 189 2008 (9) SCC
337 owned by the State Cricket Associations. According to the BCCI itself, the State Associations can
well bargain and enter into arrangements for the sale of such media rights. However, to obtain
better terms, and gain bargaining leverage a centralized form of sale of such rights has been agreed
and adopted by which the BCCI auctions these rights on behalf of the State Associations. All State
Associations put together are entitled to 70% of the revenue – i.e., the proceeds of sale of the media
rights. This may or may not be in proportion to the events hosted by each or some of the cricket
associations. Yet, this forms part of the arrangement by which the consideration flowing from such
commercial rights has been agreed to be shared amongst all members of the BCCI. These rights are
apparently commercial.
238. In the light of these, the Court is of the opinion that the ITAT – as well as the High Court fell
into error in accepting at face value the submission that the amounts made over by BCCI to the
cricket associations were in the nature of infrastructure subsidy. In each case, and for every year, the
tax authorities are under an obligation to carefully examine and see the pattern of receipts and
expenditure. Whilst doing so, the nature of rights conveyed by the BCCI to the successful bidders, in
other words, the content of broadcast rights as well as the arrangement with respect to state
associations (either in the form of master documents, resolutions or individual agreements with
state associations) have to be examined. It goes without saying that there need not be an exact
correlation or a proportionate division between the receipt and the actual expenditure. This is in line
with the principle that what is an adequate consideration for something which is agreed upon by
parties is a matter best left to them. These observations are not however, to be treated as final; the
parties’ contentions in this regard are to be considered on their merit.
   (vi)      Private trusts
          (a) Tribune Trust
239. The Tribune Trust was constituted pursuant to a will executed by late Sardar Dial Singh
Majithia. In clause (xxi) of his Will – after nominating three trustees, the testator directed that they
ought to maintain a press and a newspaper; in clause (xx) the testator directed that his property in
the Tribune Press and newspaper would vest permanently in a Committee of Trustees who would
thereafter maintain them and “keep up the liberal policy of the newspaper and activity and the
excess income after current expenses in improving the said newspaper and place it on a footing of
permanency”.
240. Under the old Act, a question arose as to whether the activity of running a newspaper was one
of general public utility; the revenue disallowed the exemption for AY 1932-33. This was affirmed byAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

the Lahore High Court. The Privy Council by its decision in In Re: Trustees of Tribune (supra)
allowed the trust’s appeal and held that the trust was neither constituted for private profit either to
the testator nor to any other private person, and that the object of the paper could be described as
one “supplying the province with an organ of educated public opinion”. The Privy Council, therefore,
reasoned that the Trust was established as a GPU charity.
241. Apparently, the trust was continuously treated as a GPU category charity and exempted under
Section 10(23C)(iv) from 1984-85 onwards. For AY 2009- 10, after considering the revised return of
the trust, the Revenue was of the opinion that it was not entitled to claim exemption under Section
10(23C). The Punjab and Haryana High Court which dealt with the Trust’s present appeal was of the
opinion that in Surat Art Silk (supra), this court had considered the judgment of the Privy Council.
In that judgment, this Court had made some observations that even though the activity of the
publication of newspaper was carried on commercial lines with the object of earning profit, it was an
activity engaged by the Trust for the purposes of carrying out its charitable objects. The High Court
upheld the revenue’s contention and based upon its analysis of Section 2(15) concluded that the
Trust’s income derived from its activities were based on profit motive. In doing so, it was noticed
that 85% of the trust’s revenue was from advertisements and interest. The total revenue was 161
crores out of which 124.87 crores was received from advertisements and 11.38 crores from
interest on FDRs; 17.49 crores was from sale of newspapers and 3.74 crores from subscriptions of
the dailies.
242. It was argued on behalf of the trust that it was never intended and in fact, not run on profitable
basis. No part of its income was ever disbursed to any private individual through profit sharing or
otherwise, nor distributed for any purpose other than the activities of the Trust. It was submitted
that the High Court’s surmise that the accumulation of large profits and its assumption that the
Trust could utilize them for non-charitable purposes in future, was unfounded. In this regard, it was
submitted that till 2008-09 all assessments were completed, since the Revenue was satisfied that
more than 85% had been ploughed back to feed the main charitable activity.
243. It is noticed from the impugned judgment that the High Court concedes to the fact that the
trust’s activities were held by the Privy Council to constitute financing of objects of ‘general public
utility’; further that merely because thousands of newspapers were being published made no
difference. It still continues to be a GPU charity.
244. The question then is whether the nature of receipts and income garnered by the Trust, in the
course of actually carrying out its activity of publishing newspaper, can be characterized as “in the
nature of trade, commerce or business” or “service in relation to trade, commerce or business”, for
any consideration. During the course of submissions, it was urged that advertisement revenue
should not be treated as business or commercial receipts since that virtually is the lifeblood which
sustains the activity of publication of newspapers. It was highlighted that the object of maintaining
the activity of publishing and distribution of newspaper remains the advancement of general public
utility, as it has the effect of both notifying and educating the general public about the current affairs
and developments. The inclusion of advertisements also serves as information to the general public,
especially in areas of employment, availability of resources, etc. Therefore, publication ofAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

advertisement is intrinsically connected with the activity of printing and publishing of newspapers.
245. The publication of advertisements for consideration, in the opinion of the court, by the
newspaper, cannot but be termed as an activity in the nature of carrying on business, trade or
commerce for a fee or consideration. That the newspaper published by the trust (“the Tribune”) in
this case is funded mainly through advertisement is no basis for holding that publishing such
advertisements by the Trust does not constitute business. The object of the trust to involve or engage
in publication of newspapers. Publishing advertisements is obviously to garner receipts which are in
the nature of profit. Now, by virtue of the amended definition of Section 2(15), GPU charities can
engage themselves in business or commercial activity or profit, only if the receipts from such
activities do not exceed the quantitative limit of the overall receipts earned in a given year. While the
assessee’s contention that publication of advertisement is intrinsically linked with newspaper
activity (thereby fulfilling sub-clause (i) of the proviso to Section 2(15), i.e. an activity in the course
of actual carrying on of the activity towards advancement of the object) is acceptable, nevertheless,
the condition imposed by sub-clause (ii) of the proviso to Section 2(15) has to also be fulfilled. In the
present case, that percentage had been exceeded, as evident from the record.
246. In the light of the foregoing discussion, this court is of the opinion that the impugned judgment
and order of the Punjab and Haryana High Court cannot be sustained, to the extent it holds that the
Tribune trust is not a GPU charity. However, having regard to the factual analysis, the judgment
needs no interference.
(b) Shri Balaji Samaj Vikas Samiti
247. The revenue appeals a decision of the Allahabad High Court157 affirming the order of the ITAT
which had directed the CIT to grant registration under Section 12AA of the Income Tax Act.
248. The assessee is a registered society which was formed with the object of establishing and
running a health club, Arogya Kendra; its object included organization of emergency relief centres,
etc. Other objects, included promotion of moral values, eradication of child labour, dowry, etc. The
assessee had entered into arrangements with the state agencies to supply mid-day meals to students
of primary schools in different villages through contracts entered into with the Basic Shiksha
Adhikari, District Meerut. It is a matter of record that the materials for preparation of mid-day meal
was supplied by the government. The assessee society claimed that it only obtains nominal charges
for preparation of mid-day meals. The assessee’s claim for registration was rejected on the ground
that it was involved in commercial activity. Upon appeal, the ITAT agreed with the assessee that
supply of mid-day meals did not constitute business or commerce and that it promoted the objects
of general public utility.
249. The revenue in its appeal contends that the assessee’s only activity for the relevant year was
supply of mid-day meals to primary schools. This was not relatable to any object of the society. The
assessee’s contention is that the state ordinarily would have carried on the activity of supply of
mid-day meals. Yet, nevertheless it outsourced its activity to an outside agency like the assessee
which performed it for nominal charges.Assistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

250. This court is of the opinion that there is no clarity with respect to whether the activity of
supplying mid-day meals falls within the objects clause of the assessee society. The order of the
ITAT as well as the High Court disclosed that Dated 09.02.2018 in ITA 49/2014.
the assessee’s objects involved maintenance of health clubs, Arogya Kendra, promotion of moral
values and provision of emergency relief. These do not however include the activity which it actually
performed, i.e., entering into contracts for supply of mid-day meals and the activity of cooking and
supply of mid-day meals. In the absence of fuller material, it would not be possible for the court to
assess the activity with which the assessee was engaged, and determine whether it could be said to
legitimately fall within the description of GPU.
251. The first consideration would be whether the activity concerned was or is in any manner
covered by the objects clause. Secondly, the revenue authorities should also consider the express
terms of the contract or contracts entered into by the assessee with the State or its agencies. If on the
basis of such contracts, the accounts disclose that the amounts paid are nominal mark-up over and
above the cost incurred towards supplying the services, the activity may fall within the description of
one advancing the general public utility. If on the other hand, there is a significant mark-up over the
actual cost of service, the next step would be ascertain whether the quantitative limit in the proviso
to Section 2(15) is adhered to. It is only in the event of the trust actually carrying on an activity in the
course of achieving one of its objects, and earning income which should not exceed the quantitative
limit prescribed at the relevant time, that it can be said to be driven by charitable purpose.
252. This court, in the normal circumstances, having regard to the above discussion, would have
remitted the matter for consideration. However, it is apparent from the records that the tax effect is
less than Rs.10 lakhs. It is apparent that the receipt from the activities in the present case did not
exceed the quantitative limit of Rs.10 lakhs prescribed at the relevant time. In the circumstances, the
impugned order of the High Court does not call for interference.
IV. Summation of conclusions
253. In view of the foregoing discussion and analysis, the following conclusions are recorded
regarding the interpretation of the changed definition of “charitable purpose” (w.e.f. 01.04.2009), as
well as the later amendments, and other related provisions of the IT Act.
A. General test under Section 2(15) A.1. It is clarified that an assessee advancing general public
utility cannot engage itself in any trade, commerce or business, or provide service in relation thereto
for any consideration (“cess, or fee, or any other consideration”);
A.2. However, in the course of achieving the object of general public utility, the concerned trust,
society, or other such organization, can carry on trade, commerce or business or provide services in
relation thereto for consideration, provided that
(i) the activities of trade, commerce or business are connected (“actual carrying out…” inserted w.e.f.
01.04.2016) to the achievement of its objects of GPU; andAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

(ii) the receipt from such business or commercial activity or service in relation thereto, does not
exceed the quantified limit, as amended over the years (Rs. 10 lakhs w.e.f. 01.04.2009; then Rs. 25
lakhs w.e.f. 01.04.2012; and now 20% of total receipts of the previous year, w.e.f. 01.04.2016);
A.3. Generally, the charging of any amount towards consideration for such an activity (advancing
general public utility), which is on cost-basis or nominally above cost, cannot be considered to be
“trade, commerce, or business” or any services in relation thereto. It is only when the charges are
markedly or significantly above the cost incurred by the assessee in question, that they would fall
within the mischief of “cess, or fee, or any other consideration” towards “trade, commerce or
business”. In this regard, the Court has clarified through illustrations what kind of services or goods
provided on cost or nominal basis would normally be excluded from the mischief of trade,
commerce, or business, in the body of the judgment.
A.4. Section 11(4A) must be interpreted harmoniously with Section 2(15), with which there is no
conflict. Carrying out activity in the nature of trade, commerce or business, or service in relation to
such activities, should be conducted in the course of achieving the GPU object, and the income,
profit or surplus or gains must, therefore, be incidental. The requirement in Section 11(4A) of
maintaining separate books of account is also in line with the necessity of demonstrating that the
quantitative limit prescribed in the proviso to Section 2(15), has not been breached. Similarly, the
insertion of Section 13(8), seventeenth proviso to Section 10(23C) and third proviso to Section
143(3) (all w.r.e.f. 01.04.2009), reaffirm this interpretation and bring uniformity across the
statutory provisions.
B. Authorities, corporations, or bodies established by statute B.1. The amounts or any money
whatsoever charged by a statutory corporation, board or any other body set up by the state
government or central governments, for achieving what are essentially ‘public functions/services’
(such as housing, industrial development, supply of water, sewage management, supply of food
grain, development and town planning, etc.) may resemble trade, commercial, or business activities.
However, since their objects are essential for advancement of public purposes/functions (and are
accordingly restrained by way of statutory provisions), such receipts are prima facie to be excluded
from the mischief of business or commercial receipts. This is in line with the larger bench judgments
of this court in Ramtanu Cooperative Housing Society and NDMC (supra).
B.2. However, at the same time, in every case, the assessing authorities would have to apply their
minds and scrutinize the records, to determine if, and to what extent, the consideration or amounts
charged are significantly higher than the cost and a nominal mark-up. If such is the case, then the
receipts would indicate that the activities are in fact in the nature of “trade, commerce or business”
and as a result, would have to comply with the quantified limit (as amended from time to time) in
the proviso to Section 2(15) of the IT Act.
B.3. In clause (b) of Section 10(46) of the IT Act, “commercial” has the same meaning as “trade,
commerce, business” in Section 2(15) of the IT Act. Therefore, sums charged by such notified body,
authority, Board, Trust or Commission (by whatever name called) will require similar consideration
– i.e., whether it is at cost with a nominal mark-up or significantly higher, to determine if it fallsAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

within the mischief of “commercial activity”. However, in the case of such notified bodies, there is no
quantified limit in Section 10(46). Therefore, the Central Government would have to decide on a
case-by-case basis whether and to what extent, exemption can be awarded to bodies that are notified
under Section 10(46).
B.4. For the period 01.04.2003 to 01.04.2011, a statutory corporation could claim the benefit of
Section 2(15) having regard to the judgment of this Court in the Gujarat Maritime Board case
(supra). Likewise, the denial of benefit under Section 10(46) after 01.04.2011 does not preclude a
statutory corporation, board, or whatever such body may be called, from claiming that it is set up for
a charitable purpose and seeking exemption under Section 10(23C) or other provisions of the Act.
C. Statutory regulators C.1. The income and receipts of statutory regulatory bodies which are for
instance, tasked with exclusive duties of prescribing curriculum, disciplining professionals and
prescribing standards of professional conduct, are prima facie not business or commercial receipts.
However, this is subject to the caveat that if the assessing authorities discern that certain kinds of
activities carried out by such regulatory body involved charging of fees that are significantly higher
than the cost incurred (with a nominal mark-up) or providing other facilities or services such as
admission forms, coaching classes, registration processing fees, etc., at markedly higher prices,
those would constitute commercial or business receipts. In that event, the overall quantitative limit
prescribed in the proviso to Section 2(15) (as amended from time to time) has to be complied with, if
the regulatory body is to be considered as one with ‘charitable purpose’ eligible for exemption under
the IT Act.
C.2. Like statutory authorities which regulate professions, statutory bodies which certify products
(such as seeds) based on standards for qualification, etc. will also be treated similarly.
D. Trade promotion bodies Bodies involved in trade promotion (such as AEPC), or set up with the
objects of purely advocating for, coordinating and assisting trading organisations, can be said to be
involved in advancement of objects of general public utility. However, if such organisations provide
additional services such as courses meant to skill personnel, providing private rental spaces in fairs
or trade shows, consulting services, etc. then income or receipts from such activities, would be
business or commercial in nature. In that event, the claim for tax exemption would have to be again
subjected to the rigors of the proviso to Section 2(15) of the IT Act.
E. Non-statutory bodies E.1. In the present batch of cases, non-statutory bodies performing public
functions, such as ERNET and NIXI are engaged in important public purposes. The materials on
record show that fees or consideration charged by them for the purposes provided are nominal. In
the circumstances, it is held that the said two assessees are driven by charitable purposes. However,
the claims of such non- statutory organisations performing public functions, will have to be
ascertained on a yearly basis, and the tax authorities must discern from the records, whether the
fees charged are nominally above the cost, or have been increased to much higher levels.
E.2. It is held that though GS1 India is in fact, involved in advancement of general public utility, its
services are for the benefit of trade and business, from which they receive significantly high receipts.Assistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

In the circumstances, its claim for exemption cannot succeed having regard to amended Section
2(15). However, the Court does not rule out any future claim made and being independently
assessed, if GS1 is able to satisfy that what it provides to its customers is charged on cost-basis with
at the most, a nominal markup.
F. Sports associations So far as the state cricket associations are concerned (Saurashtra, Gujarat,
Rajasthan, Baroda, and Rajkot), this Court is of the opinion that the matter requires further
scrutiny, in light of the discussion in paragraphs 228-238 of the judgment. Accordingly, a direction
is issued that the AO shall adjudicate the matter afresh after issuing notice to the concerned
assessees and examining the relevant material indicated in the previous paragraphs of this
judgment. Furthermore, if any consequential order needs to be issued, the same shall be done and
resulting actions, including assessment orders shall be passed in accordance with the law under
relevant provisions of the IT Act.
G. Private Trusts So far as the appeal by assessee-Tribune Trust is concerned, it has been held that
despite advancing general public utility, the Trust cannot benefit from exemption offered to entities
covered by Section 2(15) as the records reveal that income received from advertisements,
constituted business or commercial receipts. Consequently, the limit prescribed in the proviso to
Section 2(15) has to be adhered to for the Trust’s claim of being as a charity eligible for exemption,
to succeed. Therefore, despite differing reasoning, this court has held that the impugned judgment
of the High Court does not call for interference.
H. Application of interpretation H. At the cost of repetition, it may be noted that the conclusions
arrived at by way of this judgment, neither precludes any of the assessees (whether statutory, or
non-statutory) advancing objects of general public utility, from claiming exemption, nor the taxing
authorities from denying exemption, in the future, if the receipts of the relevant year exceed the
quantitative limit. The assessing authorities must on a yearly basis, scrutinize the record to discern
whether the nature of the assessee’s activities amount to “trade, commerce or business” based on its
receipts and income (i.e., whether the amounts charged are on cost-basis, or significantly higher). If
it is found that they are in the nature of “trade, commerce or business”, then it must be examined
whether the quantified limit (as amended from time to time) in proviso to Section 2(15), has been
breached, thus disentitling them to exemption.
254. In accordance with the foregoing discussion, and summary of conclusions, the numerous
appeals are disposed of as follows:
(i) The revenue’s appeals against the Improvement Trust, Moga158, the Hoshiarpur
Improvement Trust159, Bathinda Improvement Trust160, Fazilka Improvement
Trust161, Sangrur Improvement Trust162; Patiala Improvement Trust163, Jalandhar
Improvement Trust164, Kapurthala Improvement Trust165, Pathankot Improvement
Trust166, Improvement Trust, Hansi167, and the Special Leave Petitions filed against
the Gujarat CA Nos. 9974/2018 and 10371/2017 CA Nos. 12058/2017 and 9886/2018
CA Nos. 16375/2017, 2047/2019 and Diary No. 5683/2019 CA Nos. 9860/2018,
8321/2018, 2335/2019, 4449/2019 and 4957/2019 CA Nos. 12869/2017 andAssistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

10406/2018 Maritime Board168 and Karnataka Water Supply and Drainage
Board169 are rejected.
(ii) The revenue’s appeals against Ahmedabad Urban Development Authority170, the
Gujarat Housing Board171, the Gandhinagar Urban Development Authority172,
Rajkot Urban Development Authority173, Surat Urban Development Authority174,
Jamnagar Area Development Authority175, and the Gujarat Industrial Development
Corporation176 are rejected. Likewise, the revenue’s appeals against Agra
Development Trust177; UP Awas Evam Vikas Parishad178; Raebareli Development
Authority179, Rajasthan Housing Board180; Mangalore Urban Development
Authority181; Mathura Vrindavan Development Authority182; Meerut Development
Authority183; Belgaum Development Authority184;
Moradabad Urban Development Authority185, Yamuna Expressway Industrial Development
Authority186; Greater Noida Industrial Development Authority187; New Okhla Industrial
Development SLP (C) Nos. 3759/2021, 4612/2021, 5167/2021, 4678/2021, 4636/2021, 4723/2021,
7854/2021 and 11683/2021 SLP (C) Nos. 8364/2021.
CA Nos. 21762/2017, 5719/2018, 6762/2018, 3343/2018, 3359/2018, 1643/2019, 3971/2019, SLP
(C) 6686/2021, and SLP (C) No. 6580/2021 SLP (C) No. 5709/2021, 6005/2021 and 10490/2021
SLP (C) No. 7003/2021; 7166/2021; 6917/2021; 7510/2021; 7290/2021 and 7606/2021 SLP (C) No.
10908/2021; 7789/2021 and 11072/2021 SLP (C) No. 7302/2021 and 7011/2021 D. Nos.
39525/2017, 15525/2019, 21237-2019; 15488/2019; 15489/2019 and 21237/2019; CA Nos. 3971-
3972/2018, 170/2019; SLP (C) No. 15055/2019 Authority188 and Karnataka Industrial Areas
Development Board189 are rejected.
(iii) The revenue’s appeals190 against ICAI are dismissed and for the same reasons, the appeals191
filed by the ICAI are hereby allowed.
(iv) The revenue’s appeal - C.A. No. 21845/2017, against Rajasthan State Seed and Organic
Production Certification Agency is rejected, whereas SLP (C) No. 15547/2013 filed by Andhra
Pradesh State Seed Certification Agency is allowed for the same reasons.
(v) The revenue’s appeal against APEC succeeds in part. The impugned judgment of the High Court
is set aside; the matter is remitted for the concerned years, to the Assessing Officer. SLP (C) No.
14995/2019 is allowed, in the above terms.
(vi) In relation to the non-statutory bodies - the revenue’s appeal against ERNET fails, and SLP (C)
No. 15040/2019 is hereby dismissed; and similarly the impugned judgment in relation to NIXI is
confirmed – SLP(C) No. 15079/2019 is therefore dismissed. However, the revenue’s appeals against
GS1 – C.A. No. 5058/2014 and C.A. No. 4374/2015, are hereby allowed and the impugned
judgments are set aside, for the reasons elaborated in the body of the judgment.Assistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

(vii) The revenue’s appeals against the cricket associations before this court succeed in part, and the
impugned judgments of the Gujarat High Court and Rajasthan High Court are hereby set aside. The
matter is remitted to the concerned authorities for determination of the question afresh in the light
of the above discussion and observations. D. No. 16597/2020, C.A No. 7643/2018, C.A No.
8554/2018, D. No. 17255-2020, SLP (C) No. CA Nos. 4430/2021, 2477/2021, 2478/2021 CA Nos.
8193/2012, 5057/2012 and 4196/2015 SLP (C) No. 23975/2012; and CA No. 5056/2012 1404/2021,
D. No. 19394-2020, D. No. 19399-2020, D. No. 19403-2020, SLP (C) No. 11486/2020, SLP (C) No.
11124/2020, D. No. 19449-2020, SLP (C) No. 12206/2020, D. No. 20986-2020, D. No.23310-2020,
SLP (C) No. 6253/2021, SLP(C) No. 19044/2021, D. No. 5806/2021, D. No. 6662/2021 are hereby
allowed.
(viii) In relation to the private trusts, the appeal filed by the assesseee, Tribune Trust - CA
9380/2017 is dismissed. The revenue’s appeal – SLP (C) No. 30597/2018, against Shri Balaji Samaj
Vikas Samiti is dismissed, on account of low tax effect.
255. This batch of matters is disposed of, in the above terms. Pending applications, if any, are
dismissed.
………..............................................................CJI. [UDAY UMESH LALIT]
.…...………..........................................................J. [S. RAVINDRA BHAT]
..............................................................................J. [PAMIDIGHANTAM SRI NARASIMHA] New
Delhi, October 19, 2022Assistant Commissioner Of Income Tax ... vs Ahmedabad Urban Development Authority on 19 October, 2022

