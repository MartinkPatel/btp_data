A.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December,
1981
Equivalent citations: AIR1982SC710, 1982CRILJ340, 1981(4)SCALE1904,
(1982)1SCC271, [1982]2SCR272
Bench: Y.V. Chandrachud, D.A. Desai, V.D. Tulzapurkar, A.C. Gupta
JUDGMENT
Chandrachud, C.J.
1. This is a group of Writ Petitions under Article 32 of the Constitution challenging the validity of the
National Security Ordinance, 2 of 1980, and certain provisions of the National Security Act, 65 of
1980, which replaced the Ordinance. Writ Petition No. 5724 of 1980 is by Shri A.K. Roy, a Marxist
member of the Parliament, who was detained under the Ordinance by an order passed by the
District Magistrate, Dhanbad, on the ground that he was indulging in activities which were
prejudicial to public order. Ten members of the Parliament, one an Independent and the others
belonging to various political parties in opposition applied for permission to intervene in the Writ
Petition on the ground that since the Ordinance-making power of the President is destructive of the
system of Parliamentary democracy, it is necessary to define the scope of that power. We allowed the
intervention. So did we allow the applications for intervention by the People's Union of Civil
Liberties, the Supreme Court Bar Association and the State of Jammu and Kashmir which is
interested in the upholding of the Jammu & Kashmir Public Safety Act, 1978. Shri R.K. Garg argued
the Writ Petition, respondents being represented by the Attorney General and the Solicitor General.
2. After the Ordinance became an Act, more writ petitions were filed to challenge the validity of the
Act as well. Those petitions were argued on behalf of the petitioners by Dr N.M. Ghatate, Shri Ram
Jethmalani, Shri Shiv Pujan Singh and Shri Kapil Sibal. Shri V.M. Tarkunde appeared in person for
the People's Union of Civil Liberties and Dr. L.M. Singhvi for the Supreme Court Bar Association.
3. Broadly, Shri Garg concentrated on the scope and limitations of the ordinance-making power,
Shri Ram Jethmalani on the vagueness and unreasonableness of the provisions of the Act and the
punitive conditions of detention and Dr. Ghatate on the effect of the 44th Constitution Amendment
Act and the validity of its Section 1(2). Shri Tarkunde dwelt mainly on the questions relating to the
fulfilment of pre-conditions of the exercise of the ordinance making power, the effect of
non-implementation by the Central Government of the provisions of the 44th Amendment
regarding the composition of the Advisory Boards and the broad, undefined powers of detention
conferred by the Act. Dr. L.M. Singhvi laid stress on the need for the grant of minimal facilities to
detenus, the nature of the right of detenus to make an effective representation against the order of
detention and the evils of the exercise of the power to issue ordinances.A.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

4. The National Security Ordinance, 1980, was passed in order "to provide for preventive detention
in certain cases end for matters connected therewith." It was made applicable to the whole of India
except the State of Jammu & Kashmir and it came into force on September 23, 1980. The
Parliament was not in session when it was promulgated and its preamble recites that it was being
issued because the "President is satisfied that circumstances exist which render it necessary for him
to take immediate action".
5. Shri R.K. Garg, appearing for the petitioners, challenges the power of the President to issue an
Ordinance depriving any person of his life or liberty. He contends:
(a) The power to issue an Ordinance is an executive power, not a legislative power;
(b) Ordinance is not 'law' because it is not made by an agency created by the
Constitution for making laws and no law can be made without the intervention of the
legislature;
(c) There is a marked shift towards distrust of power in order to preserve the people's
rights and therefore, liberty, democracy and the independence of Judiciary are
amongst the principal matters which are outside the ordinance-making power;
(d) By Article 21 of the Constitution, a person can be deprived of his life or liberty
according only to the procedure established by law. Ordinance is not 'law' within the
meaning of Article 21 and therefore no person can be deprived of his life or liberty by
an Ordinance;
(e) The underlying object of Article 21 is to wholly deny to the executive the power to
deprive a person of his life or liberty. Ordinance-making power, which is executive
power, cannot therefore be used for that purpose. The executive cannot resort to the
power to make ordinances so as or in order to remove the restraints imposed upon it
by Article 21;
(f) The procedure prescribed under an Ordinance is not procedure established by law
because, Ordinances have a limited duration in point of time. The procedure
prescribed by an Ordinance is neither firm nor certain by reason of which the
procedure cannot be said to be 'established'. From this it follows that no person can
be deprived of his life or liberty by procedure prescribed by an Ordinance;
(g) The power to issue an Ordinance is ordaining power of the executive which
cannot be used to liberate it from the discipline of laws made by a democratic
legislature. Therefore, the power to issue ordinances can be used, if at all, on a virgin
land only. No ordinance can operate on a subject which is covered by a law made by
the legislature;A.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

(h) Equating an Ordinance made by the executive with a law made by the legislature
will violate the principle of separation of powers between the executive and the
legislature, which is a part of the basic structure of the Constitution; and
(i) Articles 14, 19 and 21 of the Constitution will be reduced to a dead letter if the
executive is permitted to take away the life and liberty of the people by an Ordinance,
lacking the support of a law made by the legislature. The Ordinance-making power
must, therefore, be construed harmoniously with those and other provisions of the
Constitution.
6. This many-pronged attack on the Ordinance-making power has one central theme: 'Ordinance is
not law.' We must therefore consider the basic question as to whether the power to make an
ordinance is a legislative power as contended by the learned Attorney General or whether it is an
executive power masquerading as a legislative power, as contended on behalf of the petitioners.
7. In support of these submissions Shri Garg relies on many texts and decisions which we need not
discuss at length since, primarily, we have to consider the scheme of our Constitution and to
interpret its provisions in order to determine the nature and scope of the ordinance-making power.
Counsel drew our attention, with great emphasis, to the statements in Montesquieu's Esprit des lois
(1748) and Blackstone's Commentaries on the laws of England' (1756) which are reproduced in
'Modern Political Constitution's by C.F. Strong (8th edition) at page 291. According to Montesquieu,
"when the legislative and executive powers are united in the same person or body of persons there
can be no liberty, because of the danger that the same monarch or senate should enact tyrannical
laws and execute them in a tyrannical manner." Blackstone expresses the same thought by saying
that "wherever the right of making and enforcing the law is vested in the same man or one and the
same body of men, there can be no public liberty". Reliance was also placed on views and sentiments
expressed to the same effect in Walter Bagehot's 'The English Constitution' (1867). Wade's
Administrative Law' (3rd edition) pages 323-324, 'Constitutional Laws of the British Empire' by
Jennings and Young, 'Law and Orders' by C.K. Allen (1945) and Harold 'Laski's Liberty in the
Modern State' (1961). According to Laski (pages 42-43).
... if in any state there is a body of men who possess unlimited political power, those over whom they
rule can never be free. For the one assured result of historical investigation is the lesson that
uncontrolled power is invariably poisonous to those who possess it. They are always tempted to
impose their canon of good upon others, and, in the end, they assume that the good of the
community depends upon the continuance of their power. Liberty always demands a limitation of
political authority, and it is never attained unless the rulers of a state can, where necessary, be called
to account. That is why Pericles insisted that the secret of liberty is courage.
Finally, counsel drew on Jawaharlal Nehru's Presidential Address to the Lucknow Congress (April
19, 1936) in which he referred to the rule by ordinances as "the humiliation of ordinances" (Selected
Works of Jawaharlal Nehru, volume 7, page 183).A.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

8. We are not, as we cannot be, unmindful of the danger to people's liberties which comes in any
community from what is called the tryanny of the majority. Uncontrolled power in the executive is a
great enemy of freedom and therefore, eternal vigilance is necessary in the realm of liberty. But we
cannot transplant, in the Indian context and conditions, principles which took birth in other soils,
without a careful examination of their relevance to the interpretation of our Constitution. No two
Constitutions are alike, for it is not mere words that make a Constitution. It is the history of a people
which lends colour and meaning to its Constitution. We must therefore turn inevitably to the
historical origin of the ordinance-making power conferred by our Constitution and consider the
scope of that power in the light of the restraints by which that power is hedged. Neither in England
nor in the United States of America does the executive enjoy anything like the power to issue
ordinances. In India, that power has a historical origin and the executive, at all times, has resorted
to it freely as and when it considered it necessary to do so. One of the larger States in India has
manifested its addiction to that power by making an overgenerous use of it-so generous indeed, that
ordinances which lapsed by efflux of time were renewed successively by a chain of kindred creatures,
one after another. And, the Ordinances embrace everything under the sun, from Prince to pauper
and crimes to contracts. The Union Government too, so we are informed, passed about 200
Ordinances between 1960 and 1980, out of which 19 were passed in 1980.
9. Our Constituent Assembly was composed of famous men who had a variegated experience of life.
They were not elected by the people to frame the Constitution but that was their strength, not their
weakness. They were neither bound by a popular mandate nor bridled by a party whip. They
brought to bear on their task their vast experience of life-in fields social, economic and political.
Their deliberation;, which run into twelve volumes, are a testimony to the time and attention which
they gave with care and concern to evolving a generally acceptable instrument for the regulation of
the fundamental affairs of the country and the life and liberty of its people.
10. The Constituent Assembly had before it the Government of India Act, 1935 and many of its
members had experienced the traumas and travails resulting from the free exercise of the
ordinance-making power conferred by that Act. They were also aware that such a power was not
claimed by the Governments of two lading democracies of the world, the English and the American,
And yet, they took the Government of India Act of 1935 as their model, Section 42 of that Act ran
thus:
Power of 42(1) If at any time when the Federal Governor Legislature is not in section
the General to Governor-General is satisfied promulgate that circumstances exist
which ordinances render it necessary for him to take during recess immediate action,
he may promulgate of Legislature. such ordinances as the circumstances appear to
him to require:
Provided that the Governor-General-
(a) ...
(b) ...A.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

(2) An ordinance promulgated under this section shall have the same force and effect
as an Act of the Federal Legislature assented to by the Governor-General, but every
such ordinance-
(a) shall be laid before the Federal Legislature and shall cease to operate at the
expiration of six weeks from the reassembly of the Lagislature, or, if before the
expiration of that period resolutions disapproving it are passed by both Chambers,
upon the passing of the second of those resolutions;
(b) shall be subject to the provisions of this Act relating to the power of His Majesty
to disallow Acts as is it were an Act of the Federal Legislature assented to by the
Governor-General; and
(c) may be withdrawn at any time by the Governor-General.
(3) If and so far as an ordinance under this section makes any provision which the
Federal Legislature would not under this Act be competent to enact, it shall be void.
Section 43 conferred upon the Governor-General the power to issue ordinances for the purpose of
enabling him satisfactorily to discharge his functions in so far as he was by or under the Act required
to act in his discretion or to exercise his individual judgment.
11. Article 123, which confers the power to promulgate ordinances, occurs in Chapter III of Part V of
the Constitution, called "Legislative Power of the President". It reads thus:
Power of 123 (1) If at any time, except when both Houses President of Parliament are
in session, the President to promulgate is satisfied that circumstances exist which
Ordinances render it necessary for him to take immediate during action, he may
promulgate such recess of Ordinances as the circumstances appear Parliament. to
him to require.
(2) An Ordinance promulgated under this Article shall have the same force and effect
as an Act of Parliament, but every such Ordinance -
(a) shall be laid before both Houses of Parliament and shall cease to operate at the
expiration of six weeks from the reassembly of Parliament, or, if before the expiration
of that period resolutions disapproving it are passed by both Houses, upon the
passing of the second of those resolutions; and
(b) may be withdrawn at any time by the President.
Explanation-Where the Houses of Parliament are summoned to reassemble on different dates, the
period of six weeks shall be reckoned from the later of those dates for the purposes of this clause.A.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

(3) If and so far as an Ordinance under this article makes any provision which Parliament would not
under this Constitution be competent to enact, it shall be void.
Article 213, which occurs in Part VI, Chapter IV, called "Legislative Power of the Governor" confers
similar power on the Governors of States to issue ordinances.
12. As we have said earlier while setting out the petitioner's case, the thrust of his argument is that
the power to issue an ordinance is an executive power, not a legislative power, and consequently, is
not law. In view of the clear and specific provision of the Constitution bearing upon this question, it
is quite impossible to accept this argument. The heading of Chapter III of Part V is 'Legislative
Powers of the President". Clause (2) of Article 123 provides that an ordinance promulgated under
Article 123 "shall have the same force and effect as an Act of Parliament". The only obligation on the
Government is to lay the ordinance before both Houses of Parliament and the only distinction which
the Constitution makes between a law made by the Parliament and an ordinance issued by the
President is that whereas the life of a law made by the Parliament would depend upon the terms of
that law, an ordinance, by reason of Sub-clause (a) of Clause (2), ceases to operate at the expiration
of six weeks from the reassembly of Parliament, unless resolutions disapproving it are passed by
both Houses before the expiration of that period.
13. Article 13(2) provides that the State shall not make any law which takes away or abridges the
rights conferred by Part III and any law made in contravention of this provision shall, to the extent
of the contravention, be void. Clause,(3) of Article 13 provides that in Article 13, "law" includes, inter
alia, an ordinance, unless the context otherwise requires. In view of the fact that the context does
not otherwise so require, it must follow from the combined operation of Clauses (2) and (3) of
Article 13 that an ordinance issued by the President under Article 123, which is equated by Clause
(2) of that article with an Act of Parliament, is subject to the same constraints and limitations as the
latter. Therefore, whether the legislation is Parliamentary or Presidential, that is to say, whether it is
a law made by the Parliament or an ordinance issued by the President, the limitation on the power is
that the fundamental rights conferred by part III cannot be taken away or abridged in the exercise of
that power. An ordinance, like a law made by the Parliament, is void to the extent of contravention
of that limitation'
14. The exact equation, for all practical purposes, between a law made by the Parliament and an
ordinance issued by the President is emphasised by yet another provision of the Constitution. Article
367 which supplies a clue to the "Interpretation" of the Constitution provides by Clause (2) that-
Any reference in this Constitution to Acts or laws of, or made by, Parliament, or to Acts or laws of, or
made by, the Legislature of a State, shall be construed as including a reference to an Ordinance
made by the President or, to an Ordinance made by a Governor, as the case may be.
It is clear from this provision, if indeed there was any doubt about the true position, that the
Constitution makes no distinction in principle between a law made by the legislature and an
ordinance issued by the President. Both, equally, are products of the exercise of legislative power
and, therefore, both are equally subject to the limitations which the Constitution has placed uponA.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

that power.
15. It may sound strange at first blush that the executive should possess legislative powers, but a
careful look at our Constitution will show that the scheme adopted by it envisages the exercise of
legislative powers by the executive in stated circumstances. An ordinance can be issued by the
President provided that both Houses of the Parliament are not in session and the President is
satisfied that circumstances exist which render it necessary for him to take immediate action An
ordinance which satisfies these pre-conditions has the same force and effect as an Act of Parliament.
Article 356 empowers the President to issue a proclamation in case of failure of constitutional
machinery in the States. By Article 357(1)(a), if by a proclamation issued under Article 356(1) it has
been declared that the powers of the Legislature of the State shall be exercisable by or under the
authority of Parliament, it is competent for the Parliament to confer on the President the power of
the Legislature of the State to make laws. Indeed, by the aforesaid Clause (a), the Parliament can not
only confer on the President the power of the State Legislature to make laws but it can even
authorise the President to delegate the power so conferred to any authority to be specified by him in
that behalf. The marginal note to Article 357 speaks of the "Exercise of Legislative powers" under the
proclamation issued under Article 356. There cannot be the slightest doubt that not only the power
exercised by the President under Article 357(1)(a) but even the power exercised by his delegate
under that clause is legislative in character. It is therefore not true to say that, under our
Constitution, the exercise of legislative power by the legislature properly so called is the only source
of law. Ordinances issued by the President and the Governors and the laws made by the President or
his delegate under Article 357(1)(a) partake fully of legislative character and are made in the exercise
of legislative power, within the contemplation of the Constitution.
16. It is thus clear that the Constituent Assembly was of the view that the President's power to
legislate by issuing an ordinance is as necessary for the peace and good government of the country
as the Parliament's power to legislate by passing laws. The mechanics of the President's legislative
power was devised evidently in order to take care of urgent situations which cannot brook delay. The
Parliamentary process of legislation is comparatively tardy and can conceivably be time-consuming.
It is true that it is not easy to accept with equanimity the proposition that the executive can indulge
in legislative activity but the Constitution is what it says and not what one would like it to be. The
Constituent Assembly indubitably thought, despite the strong and adverse impact which the
Governor-General's ordinance-making power had produced on the Indian community in the
pre-independence era, that it was necessary to equip the President with legislative powers in urgent
situations. After all, the Constitution makers had to take into account life's realities. As observed by
Shri Seervai in 'Constitutional Law of India' (2nd Ed., p. 16), "Grave public inconvenience would be
caused if on an Act, like the Bombay Sales Tax Act, being declared void no machinery, existed
whereby a valid law could be promptly promulgated to take the place of the law declared void".
Speaking for the majority in R.C. Cooper v. Union of India , Shah J. said: "The President is under the
Constitution not the repository of the legislative power of the Union, but with a view to meet
extraordinary situations demanding immediate enactment of laws, provision is made in the
Constitution investing the President with power to legislate by promulagating Ordinances." The
Constituent Assembly therefore conferred upon the executive the power to legistate, not of course
intending that the said power should be used recklessly or by imagining a state of affairs to existA.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

when, in fact, it did not exist; nor, indeed, intending that it should be used mala fide in order to
prevent the people's elected representatives from passing or rejecting a Bill after a free and open
discussion, which is of the essence of democratic process. Having conferred upon the executive the
power to legislate by ordinances, if the circumstances were such as to make the exercise of that
power necessary, the Constituent Assembly subjected that power to the self-same restraints to which
a law passed by the legislature is subject. That is the compromise which they made between the
powers of Government and the liberties of the people. Therefore, in face of the provisions to which
we have already referred, it seems to us impossible to accept Shri Garg's contention that a ordinance
made by the President is an executive and not a legislative act. An ordinance issued by the President
or the Governor is as much law as an Act passed by the Parliament and is, fortunately and
unquestionably, subject to the same inhibitions. In those inhibitions, lies the safety of the people.
The debates of the Constituent Assembly (Vol. 8, Part V, Chapter III, pp 201 to 217) would show that
the power to issue ordinances was regarded as a necessary evil. That power was to be used to meet
extra-ordinary situations and not perverted to serve political ends. The Constituent Assembly held
forth, as it were, an assurance to the people that an extra-ordinary power shall not be used in order
to perpetuate a fraud on the Constitution which is conceived with so much faith and vision. That
assurance must in all events be made good and the balance struck by the founding fathers between
the powers of the Government and the liberties of the people not disturbed or destroyed.
17. The next contention of Shri Garg is that even assuming that the power to issue ordinances is
legislative and not executive in character, ordinance is not 'law' within the meaning of Article 21 of
the Constitution. That article provides that "No person shall be deprived of his life or personal
liberty except according to procedure established by law". It is contended by the learned Counsel
that the decision of this Court in A.K. Gopalan [1950] SCR 88 establishes that the supremacy of the
legislature is enshrined in Article 21 as a fundamental right in order to afford protection to the life
and liberty of the people against all executive powers and, therefore, the supremacy of the legislature
cannot be replaced by making the executive supreme by allowing it to promulgate ordinances which
have the effect of depriving the people of their life and liberty. The extent of protection afforded to
the right conferred by Article 21 consists, according to counsel, in the obligation imposed upon a
democratic legislature to devise a fair, just and reasonable procedure for attenuating the liberties of
the people. Since the very object of Article 21 is to impose restrains on the power of the executive in
the matter of deprivation of the life and liberty of the people, it is absurd, so the argument goes, to
concede to the executive the power to deprive the people of the right conferred by Article 21 by
issuing an ordinance. The argument, in other words is that the executive cannot under any
conditions or circumstances be permitted to liberate itself from the restraints of Article 21. Shri Garg
says that if ordinances are not excluded from the precious area of life and liberty covered by Article
21, it is the executive which will accquire the right to trample upon the freedoms of the people rather
than the people acquiring the fundamental right to life and liberty. It is also urged that by elevating
ordinances into the status of laws, the principle of separation of powers, which is a part of the basic
structure of the Constitution, shall have been violated. An additional limb of the argument is that an
ordinance can never be said to 'establish' a procedure, because it has a limited duration and it
transient in character.A.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

18. In one sense, these contentions of Shri Garg stand answered by what we have already said about
the true nature and character of the ordinance-making power. The contention that the word 'law' in
Article 21 must be construed to mean a law made by the legistature only and cannot include an
ordinance, contradicts directly the express provisions of Articles 123(2) and 367(2) of the
Constitution. Besides, if an ordinance is not law within the meaning of Article 21, it will stand
released from the wholesome and salutary restraint imposed upon the legislative power by Article
13(2) of the Constitution.
19. The contention that the procedure presribed by an ordinance cannot be equated with the
procedure established by law is equally unsound. The word 'established' is used in Article 21 in order
to denote and ensure that the procedure prescribed by the law must be defined with certainty in
order that those who are deprived of their fundamental right to life or liberty must know the precise
extent of such deprivation. The decision of this Court in State of Orissa v. Bhupendra Kumar Bose
[1962] Suppl. 2 SCR 380, 398-400, and Mohammadbhai Khudabux Chhipa and Anr. v. The State of
Gujarat and Anr. [1962] Supp. 3 SCR 875, illustrate that enduring rights and obligations can be
created by ordinances. The fact that any particular law has a temporary duration is immaterial for
the purposes of Article 21 so long as the procedure prescribed by it is definite and reasonably
ascertainable. In fact, the Preventive Detention laws were in their inception of a temporary character
since they had a limited duration. They were only extended from time to time.
20. The argument of the petitioner that the fundamental right conferred by Article 21 cannot by
taken away by an ordinance really seeks to add a proviso to Article 123(1) to the following effect:
"Provided that such ordinances shall not deprive any person of his right to life or personal liberty
conferred by Article 21 of the Consttution."; An amendment substantially to that effect was moved in
the Constituent Assembly by Shri B. Pocker Sahib, but was rejected by the Constituent Assembly,
(see Constituent Assembly Debates, Vol. 8, p. 203). Speaking on the amendment moved by Shri
Pocker Dr. Ambedkar said: "Clause (3) of Article 102 lays down that any law made by the President
under the provisions of Article 102 shall be subject to the same limitations as a law made by the
legislature by the ordinary process. Now, any law made in the ordinary process by the legislature is
made subject to the provisions contained in the Fundamental Rights articles of this Draft
Constitution. That being so, any law made under the provisions of Article 102 would also be
automatically subject to the provisions relating to fundamental rights of citizens, and any such law
therefore will not be able to over-ride those provisions and there is no need for any provision as was
suggested by my friend, Mr. Pocker in his amendment No. 1796" (page 214). It may be mentioned
that Draft Article 102 corresponds to the present Article 123 of the Constitution.
21. Another answer to Shri Garg's contention is that what Article 21 emphasise is that the
deprivation of the right to life or liberty must be brought about by a State-made law and not by the
rules of natural law (see A.K. Gopalan (supra) at pages 111, 169, 199, 229, 236 and 308, 309).
Reference may usefully be made in this behalf to a few representative decisions which illustrate that
Article 21 takes in laws other than those enacted by the legislature. In Re: Sant Ram , the Rules
made by the Supreme Court; in State of Nagaland v. Ratan Singh , the Rules made for the
governance of Nagaland Hills District; in Govind v. State of Madhya Pradesh and Anr. the
Regulations made under the Police Act; in Ratilal Bhanji Mithani v. Asstt. Collector of Customs,A.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

Bombay and Anr. , the Rules made by the High Court under Article 225 of the Constitution; and in
Pandit M.S.M. Sharma v. Shri Sri Krishna Sinha and Anr. [1959] Supp. 1 SCR 806, 860-861, the
Rules made by a House of Legislature under Article 208, were all regarded as lying down procedure
established by 'law' for the purposes of Article 21.
22. We must therefore reject the contention that Ordinance is not 'law' within the meaning of Article
21 of the Constitution.
23. There is no substance in the argument that the ordinance-making power, if extended to cover
matters mentioned in Article 21, will destroy the basic structure of the separation of powers as
envisaged by the Constitution. In the first place, Article 123(1) is a part of the Constitution as
originally enacted; and secondly, our Constitution does not follow the American pattern of a strict
separation of powers.
24. We may here take up for consideration some of the submissions made by Shri Tarkunde on the
validity of the National Security Ordinance. He contends that the power to issue an ordinance under
Article 123 is subject to the pre-conditions that circumstances must exist which render it necessary
for the president to take immediate action. The power to issue an ordinance is conferred upon the
President in order to enable him to act in unusual and exceptional circustances. Therefore,
according to Shri Tarkunde, unusual and exceptional circumstances must be show to exist, they
must be relevant on the question of the necessity to issue an ordinance and they must be such as to
satisfy a reasonable person that, by reason thereof, it was necessary to take immediate action and
issue an ordinance. The legislative power to issue an ordinance being conditional, the question as
regards the existence of circumstances which compelled the issuance of ordinance is justiciable and
it is open to this Court, says Shri Tarkunde, to determine whether the power was exercised on the
basis of relevant circumstances which establish the necessity to take immediate action or whether it
was exercised for a collateral purpose. In support of this contention, Shri Tarkunde relies on the
circumstance that the amendment introduced in Article 123 by the 38th Constitution Amendment
Act, 1975, was deleted by the 44th Constitution Amendment Act, 1978. Section 2 of the 38th
Amendment Act introduced Clause (4) in Article 123 to the following effect:
Notwithstanding anything in this Constitution, the satisfaction of the President
mentioned in Clause (1) shall be final and conclusive and shall not be questioned in
any Court on any ground.
This amendment was expressly deleted by Section 16 of the 44th Amendment Act.
Shri Tarkunde says that the deletion of the particular clause is a positive indication
that the Parliament did not consider it safe or proper to entrust untrammelled
powers to the executive to issue ordinances. It therefore decided that the President's
satisfaction should not be 'final and conclusive" and that it should be open to judicial
scrutiny. Shri Tarkunde added that the exercise of a conditional power is always
subject to the proof of conditions and no distinction can be made in this regard
between conditions imposed by a statute and conditions imposed by a constitutional
provision. Relying on Section 106 of the Evidence Act, Shri Tarkunde says thatA.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

circumstances which necessitated the passing of the ordinance being especially
within the knowledge of the executive, the burden lies upon it to prove the existence
of those circumstances.
25. It is strongly pressed upon us that we should not avoid the decision of these points on the plea
that they involve political questions. Shri Tarkunde distinguishes the decision in the Rajas than
Assembly Dissolution case on this aspect by saying that Article 356 which was under consideration
in that case uses language which is much wider than that of Article 123. He relies on Seervai's
observation in the Constitutional Law of India' (2nd Edition, Volume III pages 1795 and 1797) to the
effect that "there is no place in our Constitution for the doctrine of the political question", since that
doctrine is based on, and is a consequence of, a rigid separation of powers in the U.S. Constitution
and our Constitution is not based on a rigid separation of powers. Reliance is placed by Shri
Tarkunde on the decision in the Privy Purse case in which Shah, J. observed that "Constitutional
mechanism in a democratic polity does not contemplate existence of any function which may qua
the citizens be designated as political and orders made in exercise whereof are not liable to be tested
for their validity before the lawfully constituted courts". In the same case Hegde J., said that 'There
is nothing like a political power under our Constitution in the matter of relationship between the
executive and the citizens".
26. We see the force of the contention that the question whether the pre-conditions of the exercise of
the power conferred by Article 123 are satisfied cannot be regarded as a purely political question.
The doctrine of the political question was evolved in the United States of America on the basis of its
Constitution which has adopted the system of a rigid separation of powers, unlike ours. In fact, that
is one of the principal reasons why the U.S. Supreme Court had refused to give advisory opinions. In
Baker v. Carr, Brennan J. said that the doctrine of political question was "essentially a function of
the separation of powers". There is also a sharp difference in the position and powers of the
American President on one hand and the President of India on the other. The President of the
United States exercises executive power in his own right and is responsible not to the Congress but
to the people who elect him. In India, the executive power of the Union is vested in the President of
India, but he is obliged to exercise it on the aid and advice of his Council of Ministers. The
President's "satisfaction" is therefore nothing but the satisfaction of his Council of Ministers in
whom the real executive power resides. It must also be mentioned that in the United States itself,
the doctrine of the political question has come under a cloud and has been the subject matter of
adverse criticism. It is said that all that the doctrine really means is that in the exercise of the power
of judicial review, the courts must adopt a 'prudential' attitude, which requires that they should be
wary of deciding upon the merit of any issue in which claims of principle as to the issue and claims
of expediency as to the power and prestige of courts are in sharp conflict. The result, more or less, is
that in America the phrase "political question" has become "a little more than a play of words".
27. The Rajasthan case is often cited as an authority for the proposition that the courts ought not to
enter the "poltical thicket". It has to be borne in mind that at the time when that case was decided,
Article 356 contained Clause (5) which was inserted by the 38th Amendment, by which the
satisfaction of the President mentioned in Clause (1) was made final and conclusive and that
satisfaction was not open to be questioned in any court on any ground. Clause (5) has been deletedA.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

by the 44th Amendment and, therefore, any observations made in the Rajasthan case on the basis of
that clause cannot any longer hold good. It is arguable that the 44th Constitution Amendment Act
leaves no doubt that judicial review is not totally excluded in regard to the question relating to the
President's satisfaction.
28. There are, however, two reasons why we do not propose to discuss at greater length the question
as regards the justiciability of the President's satisfaction under Article 123(1) of the Constitution. In
the first place, the Ordinance has been replaced by an Act. It is true, as contended by Shri Tarkunde,
that if the question as regards the justiciability of the President's satisfaction is not to be considered
for the reason that the ordinance has become an Act the occasion will hardly ever arise for
considering that question, because, by the time the challenge made to an Ordinance comes up for
consideration before the Court, the ordinance almost invariably shall have been replaced by an Act.
All the same, the position is firmly established in the field of constitutional adjudication that the
Court will decide no more than needs to be decided in any particular case. Abstract questions
present interesting challenges, but it is for scholars and text-book writers to unravel their mystique.
It is not for the courts to decide questions which are but of academic importance.
29. The other reason why we are not inclined to go into the question as regards the justiciability of
the President's satisfaction under Article 123(1) is that on the material which is placed before us, it is
impossible for us to arrive at a conclusion one way or the other. We are not sure whether a question
like the one before us would be governed by the rule of burden of proof contained in Section 106 of
the Evidence Act, though we are prepared to proceed on the basis that the existence of
circumstances which led to, the passing of the Ordinance is especially within the knowledge of the
executive. But before casting the burden on the executive to establish those circumstances, at least a
prima facie case must be made out by the challenger to show that there could not have existed any
circumstances necessitating the issuance of the Ordinance. Every casual or passing challenge to the
existence of circumstances, which rendered it necessary for the President to take immediate action
by issuing an ordinance, will not be enough to shift the burden of proof to the executive to establish
those circumstances. Since the petitioners have not laid any acceptable foundation for us to hold
that no circumstances existed or could have existed which rendered it necessary for the President to
take immediate action by promulgating the impugned Ordinance, we are unable to entertain the
contention that the Ordinance is unconstitutional for the reason that the pre-conditions to the
exercise of the power conferred by Article 123 are not fulfilled. That is why we do not feel called
upon to examine the correctness of the submission made by the learned Attorney General that in the
very nature of things, the "satisfaction" of the President which is the basis on which he promulgates
an Ordinance is founded upon materials which may not be available to others and which may not be
disclosed without detriment to public interest and that, the circumstances justifying the issuance of
the Ordinance as well as the necessity to issue it lie solely within the President's judgment and are,
therefore, not justiciable.
30. The two surviving contentions of Shri Garg that the power to issue an ordinance can operate on
a virgin land only and that Articles 14, 19 and 21 will be reduced to a dead letter if the executive is
permitted to take away the life or liberty of the people by an ordinance, need not detain us long. The
Constitution does not impose by its terms any inhibition on the ordinance-making power that itA.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

shall not be used to deal with a subject matter which is already covered by a law made by the
Legislature. There is no justification for imposing any such restriction on the ordinance-making
power, especially when an ordinance, like any law made by the Legislature, has to comply with the
mandate of Artice 13(2) of the Constitution. Besides, legislative activity, properly so called, has
proliferated so enormously in recent times that it is difficult to discover a virgin land or a fresh field
on which the ordinance-making power can operate, as if on a clean slate. To-day, there is possibly no
subject under the sun which the Legislature has not touched.
31. As regards Articles 14, 19 and 21 being reduced to a dead letter, we are unable to appreciate how
an ordinance which is subject to the same constraints as a law made by the Legislature can, in its
practical operation, result in the obliteration of these articles. The answer to this contention is again
to be found in the provisions contained in Article 13(2).
32. That disposes of the contentions advanced by the various parties on the validity of the ordinance.
We must mention that in a recent judgment dated October 20, 1981 delivered by a Constitution
Bench of this Court in Writ Petition No. 355 of 1981 (the Bearer Bonds case [1982] 1 SCR 947, the
question as regards the nature and scope of the ordinance-making power has been discussed
elaborately. We adopt the reasoning of the majority judgment in that case.
33. The arguments advanced on behalf of the various petitioners can be broadly classified under six
heads: (1) The scope, limits and justiciability of the ordinance-making power; (2) The validity of
Preventive Detention in the light of the severe deprivation of personal liberty which it necessarily
entails; (3) The effect of the non-implementation of the 44th Amendment in so far as it bears upon
the Constitution of the Advisory Boards; (4) The vagueness of the provisions of the National Security
Act, authorizing the detention of persons for the reasons mentioned in Section 3 of the Act; (5) The
unfairness and unreasonableness of the procedure before the Advisory Boards; and (6) The
unreasonableness and harshness of the conditions of detention. We have dealt with the first
question fully though the impugned ordinance has been replaced by an Act, since the question was
argued over several days and arises frequently-as frequently as ordinances are issued. All that needs
have been said was said on that question by the various counsel and the relevant data was fully
placed before us. We will now turn to the second question relating to the validity of Preventive
Detention as a measure for regulating the liberties of the subject.
34. There can be no doubt that personal liberty is a precious right. So did the founding fathers
believe at any rate because, while their first object was to give unto the people a Constitution
whereby a Government was established, their second object, equally important, was to protect the
people against the Government. That is why, while conferring extensive powers on the Governments
like the power to declare an emergency, the power to suspend the enforcement of fundamental
rights and the power to issue Ordinances, they assured to the people a Bill of Rights by Part III of
the Constitution, protecting against executive and legislative despotism those human rights which
they regarded as fundamental. The imperative necessity to protect those rights is a lesson taught by
all history and all human exeperience. Our Constitution makers had lived through bitter years and
seen an alien government trample upon human rights which the country had fought hard to
preserve. They believed like Jefferson that "an elective despotism was not the government we foughtA.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

for." And therefore, while arming the government with large powers to prevent anarchy from within
and conquest from without, they took care to ensure that those powers were not abused to mutilate
the liberties of the people.
35. But, the liberty of the individual has to be subordinated, within reasonable bounds, to the good
of the people. Therefore, acting in public interest, the Constituent Assembly made provisions in
Entry 9 of List I and Entry 3 of List III, authorising the Parliament and the State legislatures by
Article 246 to pass laws of preventive detention. These entries read thus:
Entry 9, List I:
Preventive detention for reasons connected with Defence, Foreign Affairs, or the
security of India persons subjected to such detention.
Entry 3, List III:
Preventive detention for reasons connected with the security of a State, the
maintenance of public order, or the maintenance of supplies and services essential to
the community; persons subjected to such detention.
The practical need and reality of the laws of preventive detention find concrete
recognition in the provisions of Article 22 of the Constitution. Laws providing for
preventive detention are expressly dealt with by that article and their scope
appropriately defined. "The established Courts of Justice, when a question arises
whether the prescribed limits have been exceeded, must of necessity determine that
question; and the only way in which they can properly do so, is by looking to the
terms of the instrument by which, affirmatively, the legislative powers were created,
and by which, negatively, they are restricted. If what has been done is legislation
within the general scope of the affirmative words which give the power, and if it
violates no express condition or restriction by which that power is limited, ... it is not
for any Court of Justice to inquire further, or to enlarge constructively those
conditions and restrictions" (see The Queen v. Burah L.R. 5 I.A. 178, 193-194 per
Lord Selborne. The legislative power in respect of preventive detention is expressly
limited to the specific purpose mentioned in Entry 9, List I and Entry 3, List III. It is
evident that the power of preventive detention was conferred by the Constitution in
order to ensure that the security and safety of the country and the welfare of its
people are not put in peril. So long as a law of preventive detention operates within
the general scope of the affirmative words used in the respective entries of the union
and concurrent lists which give that power and so long as it does not violate any
condition or restriction placed upon that power by the Constitution, the Court cannot
invalidate that law on the specious ground that it is calculated to interfere with the
liberties of the people. Khanna J., in his judgment in the Habeas Corpus case [1976]
Supp. SCR 172, 291-292, 294-296 has dwelt upon the need for preventive detention
in public Interest.A.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

36. The fact that England and America do not resort to preventive detention in normal times was
known to our Constituent Assembly and yet it chose to provide for it, sanctioning its use for
specified purposes. The attitude of two other well-known democracies to preventive detention as a
means of regulating the lives and liberties of the people was undoubtedly relevant to the framing of
our Constitution. But the framers having decided to adopt and legitimise it, we cannot declare it
unconstitutional by importing our notions of what is right and wrong. The power to judge the
fairness and justness of procedure established by a law for the purposes of Article 21 is one thing:
that power can be spelt out from the language of that article. Procedural safeguards are the
handmaids of equal justice and since, the power of the government is colossal as compared with the
power of an individual, the freedom of the individual can be safe only if he has a guarantee that he
will be treated fairly. The power to decide upon the justness of the law itself is quite another thing:
that power springs from a 'due process' provision such as is to be found in the 5th and 14th
Amendments of the American Constitution by which no person can be deprived of life, liberty or
property "without due process of law".
37. In so far as our Constitution is concerned, an amendment was moved by Pandit Thakur Dass
Bhargava to draft Article 15, which corresponds to Article 21 of the Constitution, for substituting the
words "without due process of law" for the words "except according to procedure established by
law". Many members spoke on that amendment on December 6, 1948, amongst whom were Shri
K.M. Munshi, who was in favour of the amendment, and Sir Alladi Krishnaswamy Ayyar who, while
explaining the view of the Drafting Committee, said that he was "still open to conviction". The
discussion of the amendment was resumed by the Assembly on December 13, 1948 when, Dr.
Ambedkar, who too had an open mind on the vexed question of 'due process', said:
... I must confess that I am somewhat in a difficult position with regard to Article 15
and the amendment moved by my friend Pandit Bhargava for the deletion of the
words "procedure according to law" and the substitution of the words "due process.
...
The question of "due process" raises, in my judgment, the question of the relationship
between the legislature and the judiciary. In a federal constitution, it is always open
to the judiciary to deicide whether any particular law passed by the legislature is ultra
vires or intra vires in reference to the powers of legislation which are granted by the
Constitution to the particular legislature.... The 'due process' clause, in my judgment,
would give the judiciary the power to question the law made by, the legislature on
another ground. That ground would be whether that law is in keeping with certain
fundamental principles relating to the rights of the individual. In other words, the
judiciary would be endowed with the authority to question the law not merely on the
ground whether it was in excess of the authority of the legislature, but also on the
ground whether the law was good law, apart from the question of the powers of the
legislature making the law.... The question now raised by the introduction, of the
phrase 'due process' is whether the judiciary should be given the additional power to
question the laws made by the State on the ground that they violate certainA.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

fundamental principles.
... There are dangers on both sides. For myself I cannot altogether omit the possibility
of a Legislature packed by party men making laws which may abrogate or violate
what we regard as certain fundamental principles affecting the life and liberty of an
individual. At the same time, I do not see how five or six gentlemen sitting in the
Federal or Supreme Court examining laws made by the Legislature and by dint of
their own individual conscience or their bias or their prejudices be trusted to
determine which law is good and which law is bad. It is a rather a case where a man
has to sail between Charybdis and Seylla and I therefore would not say anything. I
would leave it to the House to decide in any way it likes." (See Constituent Assembly
Debates Vol. VII, pp. 999-1001)
38. The amendment was then put to vote and was negatived. In view of this background and in view
of the fact that the Constitution, as originally conceived and enacted, recognizes preventive
detention as a permissible means of abridging the liberties of the people, though subject to the
limitations imposed by Part III, we must reject the contention that preventive detention is basically
impermissible under the Indian Constitution.
39. The third contention centers around the 44th Constitution Amendment Act, 1978, with
particular reference to Section 1(2) and Section 3 thereof, Section 1 reads thus:
1. Short title and commencement.-
(1) This Act may be called the Constitution (Forty-fourth Amendment) Act, 1978.
(2) It shall come into force on such date as the Central Government may, by
notification in the Official Gazette, appoint and different dates may be appointed for
different provisions of this Act.
Section 3 reads thus:
3. Amendment of Article 22. In Article 22 of the Constitution.-
(a) for Clause (4), the following clause shall be substituted, namely:
(4) No law providing for preventive detention shall authorise the detention of a
person for a longer period than two months unless an Advisory Board constituted in
accordance with the recommendations of the Chief Justice of the appropriate High
Court has reported before the expiration of the said period of two months that there
is in its opinion sufficient cause for such detention:
Provided that an Advisory Board shall consist of a Chairman and not less than two
other members, and the Chairman shall be a serving Judge of the appropriate HighA.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

Court and the other members shall be serving or retired Judges of any High Court:
Provided further that nothing in this clause shall authorise the detention of any
person beyond the maximum period prescribed by any law made by Parliament
under Sub-Clause (a) of Clause (7).
40. Explanation.-In this clause, 'appropriate High Court' means,
(i) in the case of the detention of a person in pursuance of an order of detention made by the
Government of India or an officer or authority subordinate to that Government, the High Court for
the Union territory of Delhi;
(ii) in the case of the detention of a person in pursuance of an order of detention made by the
Government of any State (other than a Union territory), the High Court for that State; and
(iii) in the case of the detention of a person in pursuance of an order of detention made by the
administrator or a Union territory or an Officer or authority subordinate to such administrator, such
High Court as may be specified by or under any law made by Parliament in this behalf".
(b) in Clause (7).-
(i) Sub-clause (a) shall be omitted;
(ii) Sub-clause (b) shall be re-lettered as Sub-clause (a); and
(iii) Sub-clause (c) shall be re-lettered as Sub-clause (b) and in the sub-clause as so-relettered, for
the words, brackets, letter and figure "Sub-clause (a) of Clause (4)", the word, brackets and figure
"Clause (4)" shall be substitued.
41. Clause (4) of Article 22 of the Constitution to which the above amendment was made by the 44th
Amendments reads thus:
22. (4) No law providing for preventive detention shall authorise the detention of a
person for a longer period than three months unless-
(a) an Advisory Board consisting of persons who are, or have been, or are qualified to
be appointed as, Judges of a High Court has reported before the expiration of the said
period of three months that there is in its opinion sufficient pause for such detention:
Provided that nothing in this sub-clause shall authorise the detention of any person
beyond the maximum period prescribed by any law made by Parliament under
Sub-Clause (b) of Clause (7); orA.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

(b) such person is detained in accordance with the provisions of any law made by
Parliament under Sub-clauses (a) and (b) of Clause (7).
42. Clause (7) of Article 22 to which also amendment was made by the 44th Amendment reads thus-
22. (7) Parliament may by law prescribe-
(a) the circumstances under which, and the class or classes of cases in which, a person may be
detained for a period longer than three months under any law providing for preventive detention
without obtaining the opinion of an Advisory Board in accordance with the provisions of Sub-clause
(a) Clause (4);
(b) the maximum period for which any person may in any class or classes of case be detained under
any law providing for preventive detention; and
(c) the procedure to be followed by an Advisory Board in an inquiry under Sub-clause (a) of Clause
(4).
43. The 44th Amendment Act received the assent of the President under Article 368(2) on April 30,
1979. Most of the provisions of the 44th Amendment were brought into force with effect from June
20, 1979 by a notification issued by the Central Government on June 19, 1979. The rest of the
provisions of the Amendment were brought into force with effect from August 1, 1979 except Section
3 whereby Article 22 was amended, which has not yet been brought into force. The position, as it
stands today from the Government's point of view, is that advisory Boards can be constituted to
consist of persons who are, or have been, or are qualified to be appointed as, Judges of a High Court
in accordance with the provisions of Article 22(4)(a) in its original form, The amendment made to
that article by Section 3 of the 44th Amendment not having been brought into force by the Central
Government by issuing a notification Under Section 1(2), it is not necessary, according to the Union
Government, to constitute Advisory Boards in accordance with the recommendation of the Chief
Justice of the appropriate High Court and consisting of a Chairman and not less than two other
Members, the Chairman being a serving Judge of the appropriate High Court and the other
Members being serving or retired Judges of any High Court.
44. Before adverting to the arguments advanced before us on the question of the 44th Amendment,
it must be mentioned that the National Security Ordinance which came into force on September 22,
1980 provided by Clause (9) for the Constitution of Advisory Boards strictly in accordance with the
provisions of Section 3 of the 44th Amendment Act, in spite of the fact that the aforesaid section was
not brought into force. The National Security Act was passed on December 27, 1980 replacing the
Ordinance retrospectively. Section 9 of the Act makes a significant departure from Clause (9) of the
Ordinance by providing for the Constitution of Advisory Boards in accordance with Article 22(4) in
its original form and not in accordance with the amendment made to that article by Section 3 of the
44th Amendment Act.A.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

45. The arguments advanced before us by various counsel, bearing on the 44th Amendment have
different facets and shall have to be considered separately. The main thrust of Dr. Ghatate's
argument is that the Central Government was under an obligation to bring Section 3 of the 44th
Amendment into force within a reasonable time after the President gave his assent to the
Amendment and since it has failed so far to do so, this Court must, by a mandamus, ask the Central
Government to issue a notification Under Section 1(2) of the Amendment, bringing it into force
without any further delay. Alternatively, Dr. Ghatate contends that Clause (2) of Section 1 of the
44th Amendment is ultra vires the amending power conferred upon the Parliament by Article 368 of
the Constitution. He argues: The power to amend the Constitution is vested in the Parliament by
Article 368, which cannot be delegated to the executive. By such delegation, the Parliament has
created a parallel constituent body which is impermissible under the terms of Article 368.
Sub-section (2) of Section 1 of the 44th Amendment Act vests an uncontrolled power in the
executive to amend the Constitution at its sweet will, which is violative of the basic structure of the
Constitution. Section 1(2) is also bad because by conferring an unreasonable, arbitrary and
unguided power on the executive, it violates Articles 14 and 19 which are in integral part of the basic
structure of the Constitution.
46. Shri Tarkunde does not ask for a mandamus, compelling the Central Government to bring
Section 3 of the 44th Amendment Act into force. He challenges the Central Government's failure to
bring Section 3 into force as mala fide and argues: By refusing to bring Section 3 into force within a
reasonable time without any valid reason, the Central Government has flouted the constituent
decision of the Parliament arbitrarily, which is violative of Article 21. No law of preventive detention
can be valid unless it complies with Article 22 of the Constitution, particulary with Clause (4) of that
Article. Since the National Security Act does not provide for the Constitution of Advisory Boards in
accordance with Section 3 of the 44th Amendment Act, the whole Act is bad. There was an
obligation upon the Central Government to bring the whole of the 44th Amendment into force
within a reasonable time, since Section 1(2) cannot be construed as conferring a right of veto on the
executive to nullify or negate a constitutional amendment. The bringing into force of a constitutional
amendment when such power is left to the executive, may be conceivably deferred for reasons
arising out of the inherent nature of the provisions which are to be brought into force. But the
executive cannot defer or postpone giving effect to a constitutional amendments for policy reasons
of its own which are opposed to the policy of the constituent body as reflected in the constitutional
amendment. The fact that the National Security Ordinance provided by Clause (9) for the
Constitution of Advisory Boards in accordance with the provisions of the 44th Amendment shows
that no administrative difficulty was envisaged or felt in bringing the particular provision into force.
The National Security Act dissolves the Advisory Boards Constituted under the Ordinance in
accordance with the 44th Amendment and substitutes them by Advisory Boards whose composition
is contrary to the letter and spirit of that Amenement.
47. Shri Jethamalani, like Shri Tarkunde, relies upon the provisions of the 44th Amendment in
regard to the Constitution of Advisory Boards in support of the contention that the National Security
Act is bad for not compliance with Section 3 of the Amendment, despite the fact that the said section
has not been brought into force. No Act passed by a legislature, according to Shri Jethamalani, can
flout the constituent view or decision of the Parliament, whether or not the ConstitutionalA.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

Amendment has been brought into force." In any event, contends the learned Counsel, even if
Section 3 of the 44th Amendment Act has not been brought into force, the wisdom of that
Amendment, in so far as it bears on the composition of Advisory Boards, is available to the Court.
The view of the Constituent body on that question cannot but be regarded as reasonable, and to the
extent that the provisions of the impugned Act run counter to that view, that Act must be held to be
unreasonable and for that reason, struckdown.
48. Both Dr, Ghatate and Shri Garg contend that despite the provisions of Section 1(2) of the 44th
Amendment Act, Article 22 of the Constitution stood amended on April 30, 1979 when the 44th
Amendment Act received the assent of the President and that there was nothing more that remained
to be done by the executive. Section 1(2) which, according to them is misconceived and abortive
must be ignored and served from the rest of the Amendment Act and the rest of it deemed to have
come into force on April 30, 1979.
49. In so far as the arguments set out above bear on the reasonableness of the provisions of the
National Security Act, we will consider them later when we will take up for examination the
contention that the Act is violative of Articles 19 and 21 on account of the unreasonableness or
unfairness of its provisions and of the procedure prescribed by it. At this juncture we will limit
ourselves to a consideration of those arguments in so far as they bear upon the interpretation of
Section 1(2) of the 44th Amendment Act, the consequences of the failure of Central Government to
issue a notification under that provision for bringing into force the provisions of Section 3 within a
reasonable time and the question as to whether, despite the provisions contained in Section 1(2), the
44th Amendment Act must be deemed to have come into force on the date on which the President
gave his assent to it. The point last mentioned raises the question as to whether Section 1(2) of the
44th Amendment Act is severable from the rest of its provisions, if that section is bad for any reason.
50. The argument arising out of the provisions of Article 368(2) may be considered first. It provides
that when a Bill whereby the Constitution is amended is passed by the requisite majority, it shall be
presented to the President who shall give his assent to the Bill, "and thereupon the Constitution
shall stand amended in accordance with the terms of the Bill." This provision shows that a
constitutional amendment cannot have any effect unless the President gives his assent to it and
secondly, that nothing more than the President's assent to an amendment duly passed by the
Parliament is required, in order that the Constitution should stand amended in accordance with the
terms of the Bill. It must follow from this that the Constitution stood amended in accordance with
the terms of the 44th Amendment Act when the President gave his assent to that Act on April 30,
1979. We must then turn to that Act for seeing how and in what manner the Constitution stood thus
amended. The 44th Amendment Act itself prescribes by Section 1(2) a pre-condition which must be
satisfied before any of its provisions can come into force. That pre-condition is the issuance by the
Central Government of notification in the official gazette, appointing the date from which the Act or
any particular provision thereof will come into force, with power to appoint different dates for
different provisions. Thus, according to the very terms of the 44th Amendment, none of its
provisions can come into force unless and until the Central Government issues a notification as
contemplated by Section 1(2).A.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

51. There is no internal contradiction between the provisions of Article 368(2) and those of Section
1(2) of the 44th Amendment Act. Article 368(2) lays down a rule of general application as to the date
from which the Constitution would stand amended in accordance with the Bill assented to by the
President. Section 1(2) of the Amendment Act specifies the manner in which that Act or any of its
provisions may be brought into force. The distinction is between the Constitution standing amended
in accordance with the terms of the Bill assented to by the President and the date of the coming into
force of the Amendment thus introduced into the Constitution. For determining the date with effect
from which the Constitution stands amended in accordance with the terms of the Bill, one has to
turn to the date on which the President gave, or was obliged to give, his assent to the Amendment.
For determining the date with effect from which the Constitution, as amended, came or will come
into force, one has to turn to the notification, if any, issued by the Central Government Under
Section 1(2) of the Amendment Act.
52. The Amendment Act may provide that the amendment introduced by it shall come into force
immediately upon the President giving his assent to the Bill or it may provide that the amendment
shall come into force on a future date. Indeed, no objection can be taken to the Constituent body
itself appointing a specific future date with effect from which the Amendment Act will come into
force, and if that be so, different dates can be appointed by it for bringing into force different
provisions of the Amendment Act. The point of the matter is that the Constitution standing
amended in accordance with the terms of the Bill and the amendment thus introduced into the
Constitution coming into force are two distinct things. Just as a law duly passed by the legislature
can have no effect unless it comes or is brought into force, similarly, an amendment of the
Constitution can have no effect unless it comes or is brought into force. The fact that the Constituent
body may itself specify a future date or dates with effect from which the Amendment Act or any of its
provisions will come into force shows that there is no antithesis between Article 368(2) of the
Constitution and Section 1(2) of the 44th Amendment Act. The expression of legislative or
constituent will as regards the date of enforcement of the law or Constitution is an integral part
thereof. That is why it is difficult to accept the submission that, contrary to the expression of the
constituent will, the amendments introduced by the 44th Amendment Act came into force on April
30, 1979 when the President gave his assent to that Act. The true position is that the amendments
introduced by the 44th Amendment Act did not become a part of the Constitution on April 30, 1979.
They will acquire that status only when the Central Government brings them into force by issuing a
notification Under Section 1(2) of the Amendment Act.
53. The next question for consideration is whether Section 1(2) of the 44th Amendment Act is ultra
vires the power conferred of the Parliament by Article 368 to amend the Constitution. The argument
is that the constituent power must be exercised by the Constituent body itself and it cannot be
delegated by it to the executive or any other agency. For determining this question, it is necessary to
bear in mind that by 'constituent power' is meant that power to frame or amend the Constitution.
The power of amendment is conferred upon the Parliament by Article 368(1), which provides that
the Parliament may in exercise of its constituent power amend by way of addition, variation or
repeal any provision of the Constitution in accordance with the procedure laid down in that article.
The power thus conferred on the Parliament is plenary subject to the limitation that it cannot be
exercised so as to alter the basic structure "or framework of the Constitution. It is well-settled thatA.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

the power conferred upon the Parliament by Article 245 to make laws is plenary within the field of
legislation upon which that power can operate. That power, by the terms of Article 245, is subject
only to the provisions of the Constitution. The constituent power, subject to the limitation aforesaid,
cannot be any the less plenary than the legislative power, especially when the power to amend the
Constitution and the power to legislate are conferred on one and the same organ of the State,
namely, the Parliament. The Parliament may have to follow a different procedure while exercising
its constituent power under Article 368 than the procedure which it has to follow while exercising its
legislative power under Article 245. But the obligation to follow different procedures while
exercising the two different kinds of power cannot make any difference to the width of the power. In
either event, it is plenary, subject in one case to the constraints of the basic structure of the
Constitution and in the other, to the provisions of the Constitution.
54. The contention raised by the petitioners, that the power to appoint a date for bringing into force
a constitutional amendment is a constituent power and therefore it cannot be delegated to an
outside agency is without any force. It is true that the constituent power, that is to say, the power to
amend any provision of the Constitution by way of an addition, variation or repeal must be exercised
by the Parliament itself and cannot be delegated to an outside agency. That is clear from Article
368(1) which defines at once the scope of the constituent power of the Parliament and limits that
power to the Parliament. The power to issue a notification for bringing into force the provisions of a
Constitutional amendment is not a constituent power because, it does not carry with it the power to
amend the Constitution in any manner. It is, therefore, permissible to the Parliament to vest in an
outside agency the power to bring a Constitutional amendment into force. In the instant case, that
power is conferred by the Parliament on another organ of the State, namely, the executive, which is
responsible to the Parliament for all its actions. The Parliament does not irretrievably lose its power
to bring the Amendment into force by reason of the empowerment in favour of the Central
Government to bring it into force. If the Central Government fails to do what, according to the
Parliament, it ought to have done, it would be open to the Parliament to delete Section 1(2) of the
44th Amendment Act by following the due procedure and to bring into force that Act or any of its
provisions.
55. We need not enter into the much debated question relating to the delegation of legislative
powers. In The Queen v. Burah 5 I.A. 178 the Privy Council upheld the delegated power to bring a
law into force in a district and to apply to it, the whole or part of the present or future laws which
were in force in other districts. In Russell v. The Queen 7 A.C. 829 it upheld the provision that
certain parts of an Act should come into force only on the petition of a majority of electOrs. In
Hodge v. The Queen 9 A.C. 117, it upheld the power conferred upon a Board to create offences and
annex penalties. The American authorities on the question of the validity of delegated powers need
not detain us because, the theory that a legislature is a delegate of the people and therefore, it
cannot delegate its power to another does not hold true under our Constitution. The executive,
under our Constitution, is responsible to the legislature and is not independent of it as in the United
States. The three Privy Council decisions to which we have referred above were considered by this
Court in Re Delhi Laws Act [1951] SCR 747 case, which is considered as a leading authority on the
question of delegated legislation. The Reference made in that case by the President under Article
143(1) of the Constitution to the Supreme Court, in regard to the validity of certain laws, wasA.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

necessitated by the decision of the Federal Court in Jatindra Nath Gupta v. State of Bihar [1949]
FCR 595 in which it was held by the majority that the power to extend the operation of an Act for a
further period of one year with such modification as may be specified was a legislative power and
that the provisions of Section 1(3) of that Act which delegated that power to an outside agency was
bad. One of the questions which was referred to this Court in Delhi Laws Act case was whether
Section 7 of the Delhi Laws Act, 1912 was ultra vires the Legislature which passed that Act. That
section provided that the Provincial Government may by a notification extend with such restrictions
and modifications as it thinks fit to the Province of Delhi or any part thereof any enactment which is
in force in any part of British India at the date of such notification. The difficulty of discovering the
ratio of the seven judgments delivered in the Delhi Laws Act case is well-known. There is, however,
no difference amongst the learned Judges in their perception and understanding of what was
actually decided in the three Privy Council cases to which we have referred and which were
discussed by them. They read the Privy Council decisions as laying down that conditional legislation
is permissible whereby the legislature entrusts to an outside agency the discretionary power to select
the time or place to enforce the law. As stated by Shri H.M. Seervai in his "Constitutional Law of
India" (2nd ed. at p. 1203: "The making of laws is not an end in itself, but is a means to an end,
which the legislature desires to secure. That end may be secured directly by the law itself. But there
are many subjects of legislation in which the end is better secured by extensive delegation of
legislative power". There are practical difficulties in the enforcement of laws contemporaneously
with their enactment as also in their uniform extension to different areas. Those difficulties cannot
be foreseen at the time when the laws are made. It, therefore, becomes necessary to leave to the
judgment of an outside agency the question as to when the law should be brought into force and to
which areas it should be extended from time to time. What is permissible to the Legislature by way
of conditional legislation cannot be considered impermissible to the Parliament when, in the
exercise of its constituent power, it takes the view that the question as regards the time of
enforcement of a Constitutional amendment should be left to the judgment of the executive. We are,
therefore, of the opinion that Section 1(2) of the 44th Amendment Act is not ultra vires the power of
amendment conferred upon the Parliament by Article 368(1) of the Constitution.
56. We may now take up for consideration the question which was put in the forefront by Dr.
Ghatate, namely, that since the Central Government has failed to exercise its power within a
reasonable time, we should issue a mandamus calling upon it to discharge its duty without any
further delay. Our decision on this question should not be construed as putting a seal of approval on
the delay caused by the Central Government in bringing the provisions of Section 3 of the 44th
Amendment Act into force. That Amendment received the assent of the President on April 30, 1979
and more than two and half years have already gone by without the Central Government issuing a
notification for bringing Section 3 of the Act into force. But we find ourselves unable to intervene in
a matter of this nature by issuing a mandamus to the Central Government obligating it to bring the
provisions of Section 3 into force. The Parliament having left to the unfettered judgment of the
Central Government the question as regards the time for bringing the provisions of the 44th
Amendment into force, it is not for the Court to compel the Government to of that which, according
to the mandate of the Pariliament, lies in its disceretion to do when it considers it opportune to do it.
The executive is responsible to the Parliament and if the Parliament considers that the executive has
betrayed its trust by not bringing any provision of the Amendment into force, it can censure theA.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

executive. It would be quite anomalous that the inaction of the executive should have the approval of
the Parliament and yet we should show our disapproval of it by issuing a mandamus. The Court's
power of judicial review in such cases has to be capable of being exercised both positively and
negatively, if indeed it has that power; positively, by issuing a mandamus calling upon the
Government to act and negatively by inhibiting it from acting. If it were permissible to the Court to
compel the Government by a mandamus to bring a Constitutional amendment into force on the
ground that the Government has failed to do what it ought to have done, it would be equally
permissible to the Court to prevent the Government from acting, on some such ground as that, the
time was not yet ripe for issuing the notification for bringing the Amendment into force. We quite
see that it is difficult to appreciate what practical difficulty can possibly prevent the Government
from bringing into force the provisions of Section 3 of the 44th Amendment, after the passage of two
and half year. But the remedy, according to us, is not the writ of mandamus. If the Parliament had
laid down an objective standard or test governing the decision of the Central Government in the
matter of enforcement of the Amendment, it may have been possible to assess the situation
judicially by examining the causes of the inaction of the Government in order to see how far they
bear upon the standard or test prescribed by the Parliament. But, the Parliament has left the matter
to the judgment of the Central Government without prescribing any objective norms. That makes it
difficult for us to substitute our own judgment for that of the Government on the question whether
Section 3 of the Amendment Act should be brought into force. This is particularly so when, the
failure of the Central Government to bring that section into force so far, can be no impediment in
the way of the Parliament in enacting a provision in the National Security Act on the lines of that
section. In fact, the Ordinance rightly adopted that section as a model and it is the Act which has
wrongly discarded it. It is for these reasons that we are unable to accept the submission that by
issuing a mandamus, the Central Government must be compelled to bring the provisions of Section
3 of the 44th Amendment into force. The question as to the impact of that section which, though a
part of the 44th Amendment Act, is not yet a part of the Constitution, will be considered later when
we will take up for examination the argument as regards the reasonableness of the procedure
prescribed by the Act.
57. We have said at the very outset of the discussion of this point that our decision on the question
as to whether a mandamus; should be issued as prayed for by the petitioners, should not be
construed as any approval on our part of the long and unexplained failure on the part of the Central
Government to bring Section 3 of the 44th Amendment Act into force. We have no doubt that in
leaving it to the judgment of the Central Government to decide as to when the various provisions of
the 44th Amendment should be brought into force, the Parliament could not have intended that the
Central Government may exercise a kind of veto over its constituent will by not ever bringing the
Amendment or some of its provisions into force. The Parliament having seen the necessity of
introducing into the Constitution a provision like Section 3 of the 44th Amendment, it is not open to
the Central Government to sit in judgment over the wisdom of the policy of that section. If only the
Parliament were to lay down an objective standard to guide and control the discretion of the Central
Government in the matter of bringing the various provisions of the Act into force, it would have
been possible to compel the Central Government by an appropriate writ to discharge the function
assigned to it by the Parliament. In the past, many amendments have been made by the Parliament
to the Constitution, some of which were given retrospective effect, some were given immediateA.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

effect, while in regard to some others, the discretion was given to the Central Government to bring
the Amendments into force. For example, Sections 3(1)(a) and (4) of the Constitution (First
Amendment) Act, 1951 gave retrospective effect to the amendments introduced in Articles 19 and 31
by those sections. The 7th Amendment, 1956, fixed a specific date on which it was to come into
force. The 13th Amendment, 1962, provide 1 by Section 1(2) that it shall come into force on such
date as the Central Government may, by notification in the Official Gazette, appoint. That
amendment was brought into force by the Central Government on December 1, 1963. The 27th
Amendment, 1971 brought Section 3 thereof into force at once, while the remaining provisions were
to come into force on a date appointed by the Central Government, which was not to be earlier than
a certain date mentioned in Section 1(2) of the Amending Act. Those remaining provisions were
brought into force by the Central Government on February 15, 1972. The 32nd Amendment, 1973,
also provided by Section 1(2) that it shall come into force on a date appointed by the Central
Government. That amendment was brought into force on July 1, 1974. The 42nd Amendment, 1976.
by which the Constitution was recast extensively, gave power to the Central Government to bring it
into force. By a notification dated January 1, 1977 parts of that Amendment were brought into force
in three stages (see Basu's Commentary on the Indian Constitution, Ed. 1977, Volume C, Part III,
page 134). Certain sections of that Amendment, which were not brought into force, were repealed by
Section 45 of the 44th Amendment.
58. It is in this background that the Parliament conferred upon the Central Government the power
to bring the provisions of the 44th Amendment Act into force. The Parliament could not have
visualised that, without any acceptable reason, the Central Government may fail to implement its
constituent will. We hope that the Central Government will, without further delay, bring Section 3 of
the 44th Amendment Act into force. That section, be it remembered, affords to the detenu an
assurance that his case will be considered fairly and objectively by an impartial tribunal.
59. As regards the argument that Section 1(2) of the 44th Amendment Act is bad because it vests an
uncontrolled power in the executive, we may point out, briefly, how similar and even more extensive
delegation of powers to the executive has been upheld by this Court over the years. In Sardar Inder
Singh v. State of Rajasthan [1957] SCR 605, Section 3 of the Rajasthan (Protection of Tenants)
Ordinance provided that it shall remain in force for a period of two years unless that period is
further extended by the Rajpramukh. It was held by this Court that Section 3, in so far as it
authorised the Rajpramukh to extend the life of the ordinance, fell within the category of conditional
legislation and was intra vires. The Court dissented from the view expressed in Jetindra Nath Gupta
v. The State of Bihar (supra) that the power to extend the life of an enactment cannot validly be
conferred on an outside authority. In Sita Ram Bishambhar Dayal and Ors. v. State of U.P. and Ors. ,
Section 3D(1) of the U.P. Sales Tax Act, 1948, which was challenged on the ground of excessive
delegation, provided for levying taxes at such rates as may be prescribed by the State Government
not exceeding the maximum prescribed. While rejecting the challenge, Hegde, J. speaking for the
Court observed:
However much one might deplore the "New Despotism" of the executive, the very
complexity of the modern society and the demand it makes on its Government have
set in motion force which have made it absolutely necessary for the legislatures toA.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

entrust more and more powers to the executive. Text book doctrines evolved in the
19th Century have become out of date.
In Gwalior Rayon Silk Manufacturing (Wvg.) Co. Ltd. v. The Assistant Commissioner
of Sales Tax , the question which arose for determination was whether the provisions
of Section 8(2)(b) of the Central Sales Tax Act, 1956 suffered from the vice of
excessive delegation because the Parliament, in not fixing the rate itself and in
adopting the rate applicable to the sale or purchase of good inside the appropriate
State, had not laid down any legislative policy, abdicating thereby its legislative
function. Rejecting this contention Khanna, J., who spoke for himself and two other
learned Judges observed that the growth of the legislative power of the executive is a
significant development of the twentieth century and that provision was therefore
made for delegated legislation to obtain flexibility, elasticity, expedition and
opportunity for experimentation. Mathew, J. speaking on behalf of himself and Ray,
C.J. agreed with the conclusion that Section 8(2)(b) did not suffer from the vice of
excessive delegation of legislative power. The decisions bearing on the subject of
excessive delegation have been surveyed both by Khanna, J. and Mathew, J. in their
respective judgments. In M.K. Pasiah and Sons v. The Excise Commissioner , it was
contended for the appellants that the power to fix the rate of Excise Duty conferred
by Section 22 of the Mysore Excise Act of 1965 on the Government was bad for the
reason that it was an abdication by the State legislature of its essential legislative
function. The Court, speaking through Mathew, J. upheld the validity of Section 22.
We are unable to appreciate that the constituent body can be restrained from doing
what a legislature is free to do. We are therefore unable to accept the argument that
Section 1(2) confers an uncontrolled power on the executive and is, by its
unreasonableness, violative of Articles 14 and 19 of the Constition.
60. We are also unable to accept Shri Tarkunde's argument that the Central Government's failure to
bring Section 3 of the 44th Amendment into force is mala fide. The Parliament has chosen to leave
to the discretion of the Central Government the determination of the question as to the time when
the various provisions of the 44th Amendment should be brought into force. Delay in implementing
the will of the Parliament can justifiably raise many an eye-brow, but it is not possible to say on the
basis of such data, as has been laid before us, that the Central Government is actuated by any
ulterior motive in not bringing Section 3 into force. The other limb of Shri Tarkunde's argument that
there is an obligation upon the Central Government to bring the provisions of the 44th Amendment
into force within a reasonable time has already been dealt with by us while considering the
argument that, since the Government has not brought Section 3 into force within a reasonable time,
it should be compelled by a writ of mandamus to perform its obligation.
61. That disposes of all the contentions bearing on the 44th Amendment Act except one, which we
will consider later, as indicated already.
62. The next question arises out of the provisions of Section 3(1) and 3(2) of the National Security
Act which, according to the petitioners, are so vague in their content and wide in their extent that,A.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

by their application, it is easy for the Central Government or the State Government to deprive a
person of his liberty for any fanciful reason which may commend itself to them. Sub-section (1) and
(2) of Section 3 of the Act read thus:
3 (1) The Central Government or the State Government may:
(a) if satisfied with respect to any person that with a view to preventing him from
acting in any manner prejudicial to the defence of India, the relations of India with
foreign powers, or the security of India, or
(b) if satisfied with respect to any foreigner that with a view to regulating his
continued presence in India or with a view to making arrangements for his expulsion
from India, it is necessary so to do, make an order directing that such person be
detained.
(2) The Central Government or the State Government may, if satisfied with respect to
any person that with a view to preventing him from acting in any manner prejudicial
to the security of the State or from acting in any manner prejudicial to the
maintenance of public order or from acting in any manner prejudicial to the
maintenance of supplies and services essential to the community it is necessary so to
do, make an order directing that such person be detained.
Explanation: For the purposes of this sub-section, "acting in any manner prejudicial to the
maintenance of supplies and services essential to the community" does not include "acting in any
manner prejudicial to the maintenance of supplies of commodities essential to the community" as
defined in the Explanation to Sub-section (1) of Section 3 of the Prevention of Blackmarketing and
Maintenance of Supplies of Essential Commodities Act, 1980, and accordingly no order of detention
shall be made under this Act on any ground on which an order of detention may be made under that
Act.
63. It is contended by Shri Jethmalani that the expressions 'defence of India' 'relations of India with
foreign powers', 'security of India' and 'security of the State' which occur in Sub-sections (1)(a) and
(2) of Section 3 are so vague, general and elastic that even conduct which is otherwise lawful can
easily be comprehended within those expressions, depending upon the whim and caprice of the
detaining authority. The learned Counsel argues: These expressions are transposed from the
legislative entries into the aforesaid two sub-sections without any attempt at precision or definition.
In so for as 'defence of India' is concerned, the legislature could have easily indicated the broad
content of that expression by including within it acts like inciting armed forces to rebellion,
damaging or destroying defence installations or disclosing defence secrets. In the absence of such
definition, a statement that corrupt officials are responsible for the purchase of defence equipment
from a foreign power, may be considered as falling within the mischief of that expression. The
expression 'acting in any manner prejudicial to the relations of India with foreign powers', is
particularly open to grave objection because, it can take in any and every piece of conduct. In the
absence of a precise definition it is impossible for any person to know with reasonable certainty as toA.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

what in this behalf are the limits of lawful conduct which he must not transgress. Even if a person
were to say, in the exercise of the right of his free speech and expression, that a foreign power, which
is not friendly with India, is adopting ruthless measures to suppress human liberties, it would be
open to the detaining authority to detain a person for making that statement. The vice, therefore, of
Section 3 consists in the fact that the governing factor for the application of that section is the
passing and personal opinion of the detaining authority in regard to the security and defence of the
country and its external affairs. A cardinal requirement of the rule of law is that citizens must know
with certainty where lawful conduct ends and unlawful conduct begins; but more than that, the
bureaucrats must know the limits of their power. The vagueness of the expressions used in Section 3
confers uncontrolled discretion on the detaining, authority to expand the horizon of their power, to
the detriment of the liberty of the subject. Even the right to peaceful demonstration which has been
upheld by this Court, may be treated by the detaining authority as falling within the mischief of
Section 3. The circumstance that, if a habeas corpus petition is filed, the Court may release the
detenu is hardly any answer to the vice of the section because, the fundamental principle is that a
person cannot be deprived of his liberty on the basis of a vague and uncertain law. The provisions of
the Northern Ireland (Emergency Provisions) Act 1973 (Halsbury's Statutes of England, 3rd edition,
Volume 43, page 1235) is an instance of a statute which defines with precision the reasons for which
a person can be detained. That Act was passed inter alia for the detention of terrorists in Northern
Ireland. Section 10(1) provides that any constable may arrest without warrant any person whom he
suspects of being a terrorist. Section 20 of that Act defines the terms 'terrorist' and 'terrorism' with
great care and precision in order that the power of detention may not be abused.
64. In support of these propositions Shri Jethmalani relies on the decisions of the American
Supreme Court in United States of America v. L. Cohen Grocery Co. 65 Law Ed. 516, 520, Champlin
Refining Co. v. Corporation Commission of the State of Oklahoma 76 Law Ed. 1062, 1082, Ignatius
Lanzelta v. State of New Jersey 83 Law Ed. 888 and David H. Scull v. Common-wealth of Virginia
Ex Rel., Committee on Law Reform and Racial Activities 3 Law Ed. 2d. 865. The ratio of these cases
may be Summed up by reproducing the third head note of the case last mentioned:
Fundamental fairness requires that a person cannot be sent to jail for a crime he
could not with reasonable certainty know he was committing; reasonable certainty in
that respect is all the more essential when vagueness might induce individuals to
forgo their rights of speech, press, and association for fear of violating an unclear law.
Counsel has also drawn our attention to the decision of this Court in the State of
Madhya Pradesh and Anr. v. Baldeo Prasad where a law was struck down on the
ground, inter alia that the word 'goonda' is of uncertain import, which rendered
unconstitutional a law which permitted goondas to be externed.
65. In this behalf Dr. Singhvi, intervening on behalf of the Supreme Court Bar Association, has
drawn our attention to Section 8(3) of the Jammu & Kashmir Public Safety Act, 6 of 1968, which
defines the expressions "acting in any manner prejudicial to the security of State 'and' acting in any
manner prejudicial to the maintenance of public order.' Where there is a will there is a way, and
counsel contends that the way shown with admirable precision by the Jammu & KashmirA.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

Legislature is there for the Parliament to follow, provided its intention is, as it ought to be, that
before the people are deprived of their liberty, they must have the opportunity to regulate their
conduct in order to ensure that it may conform to the requirements of law.
66. In making these submissions counsel seem to us to hawever-stated their case by adopting an
unrealistic attitude. It is true that the vagueness and the consequent uncertainty of a law of
preventive detention bears upon the unreasonableness of that law as much as the uncertainty of a
punitive law like the Penal Code does. A person cannot be deprived of his liberty by a law which is
nebulous and uncertain in its definition and application. But in considering the question whether
the expressions 'aforesaid which are used in Section 3 of the Act are of that character, we must have
regard to the consideration whether concepts embodied in those expressions are at all capable of a
precise definition. The fact that some definition or the other can be formulated of an expression
does not mean that the definition can necessarily give certainty to that expression. The British
Parliament has defined the term "terrorism" in Section 28 of the Act of 1973 to mean "the use of
violence for political ends", which, by definition, includes 'any use of violence for the purpose of
putting the public or any section of the public in fear." The phrases "political ends" itself of an
uncertain character and comprehends within its scope a variety of nebulous situations. Similarly,
the definitions contained in Section 8(3) of the Jammu and Kashmir Act of 1978 themselves depend
upon the meaning of concepts like 'overawe the Government.' The formulation of definitions cannot
be a panacea to the evil of vagueness and uncertainty. We do not, of course suggest that the
legislature should not attempt to define or at least to indicate the contours of expressions, by the
use, of which people are sought to be deprived of their liberty. The impossibility of framing a
definition with mathematical precision cannot either justify the use of vague' expressions or the total
failure to frame any definition at ail which can furnish, by its inclusiveness at least, a safe guideline
for understanding the meaning of the expressions used by the legislature. But the point to note is
that there are expressions which inherently comprehend such an infinite variety of situations that
definitions, instead of lending them a definite meaning, can only succeed either in robbing them of
their intended amplitude or in making it necessary to frame further definitions of the terms defined.
Acts prejudicial to the 'defence of India', 'security of India', 'security of the State', and 'relations of
India with foreign powers' are concepts of that nature which are difficult to encase within the
strait-jacket of a definition. If it is permissible to the legislature to enact laws of preventive
detention, a certain amount of minimal latitude has to be conceded to it in order to make those laws
effective. That we consider to be a realistic approach to the situation. An administrator acting bona
fide, or a court faced with the question as to whether certain acts fall within the mischief of the
aforesaid expressions used in Section 3, will be able to find an acceptable answer either way. In
other words though an expression may appear in cold print to be vague and uncertain, it may not be
difficult to apply it to life's practical realities. This process undoubtedly involves the possiblity of
error but then,' there is hardly any area of adjudicative process which does not involve that
possiblity.
67. The requirement that crimes must be defined with appropriate definiteness is regarded as a
fundamental concept in criminal law and must now be regarded as a pervading theme of our
Constitution since the decision in Maneka Gandhi . The underlying principle is that every person is
entitled to be informed as to what the State commands or forbids and that the life and liberty of aA.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

person cannot be put in peril on an ambiguity. However, even in the domain of criminal law, the
processes of which can result in the taking away of life itself, no more than a reasonable degree of
certainty has to be accepted as a fact. Neither the criminal law nor the Constitution requires the
application of impossible standards and therefore, what is expected is that the language of the law
must contain an adequate warning of the conduct which may fall within the prescribed area, when
measured by common understanding. In criminal law, the legislature frequently uses vague
expressions like 'bring into hatred or contempt', 'maintenance of harmony between different
religious groups' or 'likely to cause disharmony or hatred or ill-will', or 'annoyance to the public',
(see Sections 124A, 153A(1)(b), 153B(1)(c), and 268 of the Penal Code). These expressions, though
they are difficult to define, do not elude a just application to practical situations. The use of language
carries with it the inconvenience of the imperfections of language.
68. We see that the concepts aforesaid, namely, 'defence of India", 'security of India', 'security of the
State' and 'relations of India with foreign powers', which are mentioned in Section 3 of the Act, are
not of any great certainty or definiteness. But in the very nature of things they are difficult to define.
We cannot therefore strike down these provisions of Section 3 of the Act on the ground of their
vagueness and uncertainty. We must, however, utter a word of caution that since the concepts are
not defined, undoubtedly because they are not capable of a precise definition, courts must strive to
give to those concept a narrower construction than what the literal words suggest. While construing
laws of preventive detention like the National Security Act, care must be taken to restrict their
application to as few situations as possible. Indeed, that can well be the unstated premise for
upholding the constitutionality of clauses like those in Section 3, which are fraught with grave
consequences to personal liberty, if construed liberally.
69. What we have said above in regard to the expressions 'defence of India', 'security of India',
'security of the State' and 'relations of India with foreign powers' cannot apply to the expression
"acting in any manner prejudicial to the maintenance of supplies and services essential to the
community which occurs in Section 3(2) of the Act. Which supplies and services are essential to the
community can easily be defined by the Legislature and indeed, legislations which regulate the
prices and possession of essential commodities either enumerate those commodities or confer upon
the appropriate Government the power to do so. In the absence of a definition of supplies and
services essential to the community', the detaining authority will be free to extend the application of
this clause of Sub-section (2) to any commodities or services the maintenance of supply of which,
according to him, is essential to the community.
70. But that is not all. The explanation to Sub-section (2) gives to the particular phrase in that
sub-section a meaning which is not only uncertain but which, at any given point of time, will be
difficult to ascertain or fasten upon. According to the Explanation, no order of detention can be
made under the National Security Act on any ground on which an order of detention may be made
under the Prevention of Black-marketing and Maintenance of Supplies of Essential Commodities
Act, 1980. The reason for this, which is stated in the Explanation itself, is that for the purposes of
Sub-section (2) "acting in any manner prejudicial to the maintenance of supplies essential to the
community" does not include "acting in any manner prejudicial to the maintenance of supplies of
commodities essential to the community" as defined in the Explanation to Sub-section (1) of SectionA.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

3 of the Act of 1980 Clauses (a) and (b) of the Explanation to Section 3 of the Act of 1980 exhaust
almost the entire range of essential commodities. Clause (a) relates to committing or instigating any
person to commit any offence punishable under the Essential Commodities Act, 10 of 1955, or under
any other law for the time being in force relating to the control of the production, supply or
distribution of, or trade and commerce in, any commodity essential to the community. Clause (b) of
the Explanation to Section 3 of the Act of 1980 relates to dealing in any commodity which is an
essential commodity as defined in the Essential Commodities Act, 1955, or with respect to which
provisions have been made in any such other law as is referred to in Clause (a). We find it quite
difficult to understand as to which are the remaining commodities outside the scope of the Act of
1980, in respect of which it can be said that the maintenance of their supplies is essential to the
community. The particular clause in Sub-section (2) of Section 3 of the National Security Act is,
therefore, capable of wanton abuse in that, the detaining authority can place under detention any
person for possession of any commodity on the basis that the authority is of the opinion that the
maintenance of supply of that commodity is essential to the community. We consider the particular
clause not only vague and uncertain but, in the context or the Explanation, capable of being
extended cavalierly to supplies, the maintenace of which is not essential to the community. To allow
the personal liberty of the people to be taken away by the application of that clause would be
flagrant violation of the fairness and justness of procedure which is implict in the provisions of
Article 21.
71. In so far as "services essential to the community" are concerned, they are not covered by the
Explanation to Section 3(2) of the Act. But in regards to them also, in the absence of a proper
definition or a fuller description of that or a prior enumeration of such services, it will be difficult for
any person to know with reasonable certitude as to which services are considered by the detaining
authority as essential to the community. The essentiality of services varies from time to time
depending upon the circumstances existing at any given time. There are, undoubtedly, some services
like water, electricity post and telegraph, hospitals, railways, ports, roads and air transport which
are essential to the community at all times but, people have to be forewarned if new categories are to
be added to the list of services which are commonly accepted as being essential to the community.
72. We do not, however, prose to strike down the power given to detain persons Under Section 3(2)
on the ground that they are acting in any manner prejudicial to the maintenance of supplies and
services essential to the community. The reason for this is that it is vitally necessary to ensure a
steady flow of supplies and services which are essential to the community, and if the State has the
power to detain persons on the grounds mentioned in Section 3(1) and the other grounds mentioned
in Section 3(2), it must also have the power to pass orders of detention on this particular ground.
What we propose to do is to hold that no person can be detained with a view to preventing him from
acting in any manner prejudicial to the maintenance of supplies and services essential to the
community unless, by a law, order or notification made or published fairly in advance, the supplies
and services, the maintenance of which is regarded as essential to the community and in respect of
which the order of detention is proposed to be passed, are made known appropriately, to the public.
73. That disposes of the question as to the vagueness of the provisions of the National Security Act.
We will now proceed to the consideration of a very important topic, namely, the reasonableness ofA.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

the procedure prescribed by the Act. The arguments advanced on this question fall under three
sub-heads: (1) the reasonableness of the procedure which is generally prescribed by the Act; (2) the
fairness and reasonableness of the substantive provisions in regard to the Constitution of Advisory
Boards; and (3) the justness and reasonableness of the procedure in the proceedings before the
Advisory Boards. The discussion of these questions will conclude this judgment.
74. Shri Jethmalani attacked the constitutionality of the very National Security Act itself on the
ground that it is a draconian piece of legislation which deprives people of their personal liberty
excessively and unreasonably, confers vast and arbitrary powers of detention upon the executive and
sanctions the use of those powers by following a procedure which is unfair and unjust. The Act,
according to the counsel, thereby violates Articles 14, 19 and 21 and and is therefore wholly
unconstitutional. This argument, it must be stated, is not to be confused with the fundamental
premise of the petitioners that, under our Constitution, no law of preventive detention can at all be
passed, whatever be the safeguards it provides for the protection of personal liberty. We have
already dealt with that argument.
75. The argument of Shri Jethmalani against the validity of the National Security Act can be
disposed of briefly. We need not enter into the controversy which is reflected in the dissenting
judgment of Kailasam, J. in Maneka Gandhi as to whether the major premise of Gopalan's case
really was that Article 22 is a complete code in itself and whether because of that premise, the
decision in that case that Article 21 excluded the personal freedom conferred by Article 19(1) is
incorrect. We have the authority of the decisions in the Bank Nationalisation case, Haradhan Saha ,
Khudiram , Sambhu Nath Sarkar and Maneka Gandhi for saying that the fundamental rights
conferred by the different Articles of Part III of the Constitution are not mutually exclusive and that
therefore a law of preventive detention which falls within Article 22 must also meet the
requirements of Articles 14, 19 and 21. Speaking for the Court in Khudiram, one of us, Bhagwati, J.
said:
This question, thus, stands concluded and a final seal is put on this controversy and
in view of these decisions, it is not open to any one now to contend that a law of
preventive detention, which falls within Article 22, does not have to meet the
requirement of Article 14 or Article 19. (page 847) But just as the question as to
whether the rights conferred by the different articles of Part III are mutually
exclusive is concluded by the aforesaid decisions, the question whether a law of
preventive detention is unconstitutional for the reason that it violates the freedoms
conferred by Articles 14, 19, 21 and 22 of the Constitution is also concluded by the
decision in Haradhan Saha. In that case the validity of the Maintenance of Internal
Security Act, 1971 was challenged on the ground that it violates these articles since its
provisions were discriminatory, they constituted an unreasonable infringement of the
rights conferred by Article 19, they infringed the guarantee of fair procedure and they
did not provide for an impartial machinery for the consideration of the
representation made by the detenu to the Government. The Constitution Bench
which heard the case considered these contentions and rejected them by holding that
the MISA did not suffer from any constitutional infirmity. The MISA was once againA.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

challenged in Khudiram, but the Court refused to entertain that challenge on the
ground that the question was concluded by the decision in Haradhan Saha and that it
was not open to the petitioner to challenge that Act on the ground that some
argument directed against the constitutional validity of the Act under Article 19 was
not advanced or considered in Haradhan Saha. The Court took the view that the
decision in Haradhan Saha must be regarded as having finally decided all questions
as to the constitutional validity of MISA on the ground of challenge under Article 19.
We would like to add that in Haradhan Saha the challenge to MISA on the ground of
violation of Articles 14, 21 and 22 was also considered and rejected. The question
therefore as to whether MISA violated the provisions of these four articles, namely,
Articles 14, 19, 21 and 22, must be considered as having been finally decided in
Haradhan Saha. Accordingly, we find it impossible to accept the argument that the
'National Security Act, which is in part materia with the Maintenance of Internal
Security Act, 1971, is unconstitutional on the ground that, by its very nature, it is
generally violative of Articles 14, 19, 21 and 22.
76. Though the Act, as a measure of preventive detention, cannot be challenged on the broad and
general ground that such Acts are calculated to interfere unduly with the liberty of the people, we
shall have to consider the challenge made by the petitioners' counsel, particularly by Shri
Jethmalani and Dr. Ghatate, to certain specific provisions of the Act on the ground that they cause
excessive and unreasonable interference with the liberty of the detenus and that the procedure
prescribed by those provisions is not fair, just and reasonable. Dr. Ghatate has, with particular
emphasis, challenged on these grounds the provisions of Sections 3(2), 3(3), 5, 8, 9, 10, 11, 13 and 16
of the Act. Shri Tarkunde challenged the provisions of Sections 8 and 11(4) of the Act.
77. We have already dealt with the argument arising out of the provisions of Section 3(2) read with
the Explanation, by which power is conferred to detain persons in order to prevent them from acting
in any manner prejudicial to the maintenance of supplies and services essential to the community.
In so far as Sub-section (3) of Section 3 is concerned, the argument is that it is wholly unreasonable
to confer upon the District Magistrate or the Commissioner of Police the power to issue orders of
detention for the reasons mentioned in Sub-section (2) of Section 3. The answer to this contention is
that the said power is conferred upon these officers only if the State Government is satisfied that
having regard to the circumstances prevailing or likely to prevail in any area within the local limits
of the jurisdiction of these officers, it is necessary to empower them to take action under Sub-section
(2). The District Magistrate or the Commissioner of Police can take action under Sub-section (2)
during the period specified in the order of the State Government only. Another safeguard provided
is, that the period so specified in the order made by the State Government during which these
officers can exercise the powers under Sub-section (2) cannot, in the first instance, exceed three
months and can be extended only from time to time not exceeding three months at any one time. By
Sub-section (4) of Section 3, the District Magistrate or the Commissioner of Police has to report
forthwith the fact of detention to the State Government and no such order of detention can remain
in force for more than 12 days after the making thereof unless, in the meantime, it has been
approved by the State Government. In view of these in built safeguards, it cannot be said that
excessive or unreasonable power is conferred upon the District Magistrate or the Commissioner ofA.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

Police to pass orders under Sub-section (2).
78. By Section 5, every person in respect of whom a detention order has been made is liable-
(a) to be detained in such place and under such conditions, including conditions as to maintenance,
discipline and punishment for breaches of discipline, as the appropriate Government may, by
general or special order, specify, and
(b) to be removed from one place of detention to another place of detention, whether in the same
State, or in another State, by order of the appropriate Government.
The objection of the petitioners to these provisions on the ground of their unreasonableness is not
wholly without substance. Laws of preventive detention cannot, by the back-door, introduce
procedural measures of a punitive kind. Detention without trial is an evil to be suffered, but to no
greater extent and in no greater measure than is minimally necessary in the interest of the country
and the community. It is neither fair nor just that a detenu should have to suffer detention in "such
place" as the Government may specify. The normal rule has to be that the detenu will be kept in
detention in a place which is within the environs of his or her ordinary place of residence. If a person
ordinarily resides in Delhi to keep him in detention in a far of place like Madras or Calcutta is a
punitive measure by itself which, in matters of preventive detention at any rate, is not to be
encouraged. Besides, keeping a person in detention in a place other than the one where he habitually
resides makes it impossible for his friends and relatives to meet him or for the detenu to claim the
advantage of facilities like having his own food. The requirements of administrative convenience,
safety and security may justify in a given case the transfer of a detenu to a place other than that
where he ordinarily resides, but that can only be by way of an exception and not as a matter of
general rule. Even when a detenu is required to be kept in or transferred to a place which is other
than his usual place of residence, he ought not to be sent to any far off place which, by the very
reason of its distance, is likely to deprive him of the facilities to which he is entitled. Whatever
smacks of punishment must be scruplously avoided in matters of preventive detention.
79. Since Section 5 of the Act provides for, as shown by its marginal note, the power to regulate the
place and conditions of detention there is one more observation which we would like to make and
which we consider as of great importance in matters of preventive detention. In order that the
procedure attendant upon detentions should conform to the mandate of Article 21 in the matter of
fairness, justness and reasonableness, we consider it imperative that immediately after a person is
taken in custody in pursuance of an order of detention, the members of his household, preferably
the parent, the child or the spouse, must be informed in writing of the passing of the order of
detention and of the fact that the detenu has been taken in custody. Intimation must also be given as
to the place of detention, including the place where the detenu is transferred from time to time. This
Court has stated time and again that the person who is taken in custody does not forfeit, by reason
of his arrest, all and every one of his fundamental rights. It is therefore, necessary to treat the detenu
consistently with human dignity and civilized norms of behaviour.A.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

80. The objection of the petitioners against the provision contained in Section 8(1) is that it
unreasonably allows the detaining authority to furnish the grounds of detention to the detenu as late
as five days and in exceptional cases 10 days after the date of detention. This argument overlooks
that the primary requirement of Section 8(1) is that the authority making the order of detention
shall communicate the grounds of detention to the detenu "as soon as may be". The normal rule
therefore is that the grounds of detention must be communicated to the detenu without avoidable
delay. It is only in order to meet the practical exigencies of administrative affairs that detaining
authority is permitted to communicate the grounds of detention not later than five days ordinarily,
and not later than 10 days if there are exceptional circumstances. If there are any such
circumstances, the detaining authority is required by Section 8(1) to record its reasons in writing.
We do, not think that this provision is open to any objection.
81. Sections 9, 10 and 11 deal respectively with the Constitution of Advisory Boards, reference to
Advisory Boards and procedure of Advisory Boards. We will deal with these three sections a little
later while considering the elaborate submissions made by Shri Jethmalani in regard thereto.
82. Dr. Ghatate's objection against Section 13 is that it provides for a uniform period of detention of
12 months in all cases, regardless of the nature and seriousness of the grounds on the basis of which
the order of detention is passed. There is no substance in this grievance because, any law of
preventive detention has to provide for the maximum period of detention, just as any punitive law
like the Penal Code has to provide for the maximum sentence which can be imposed for any offence.
We should have thought that it would have been wrong to fix a minimum period of detention,
regardless of the nature and seriousness of the grounds of detention. The fact that a person can be
detained for the maximum period of 12 months does not place upon the detaining authority the
obligation to direct that he shall be detained for the maximum period. The detaining authority can
always exercise its discretion regarding the length of the period of detention. It must also be
mentioned that, under the proviso to Section 13, the appropriate Government has the power to
revoke or modify the order of detention at any earlier point of time.
83. Section 16 is assailed on behalf of the petitioners on the ground that it confers a wholly
unwarranted protection upon officers who may have passed orders of detention mala fide. That
section provides that no suit or other legal proceeding shall lie against the Central Government or a
State Government and no suit, prosecution or other legal proceeding shall lie against a person, for
anything in good faith done or intended to be done in pursuance of the Act. The grievance of Dr.
Ghatate is that even if an officer has in fact passed an order of detention mala fide, but intended to
pass in good faith, he will receive the protection of this provision. We see a contradiction in this
argument because, if an officer intends to pass an order in good faith and if he intends to pass the
order mala fide he will pass it likewise Moreover, an act which is not done in good faith will not
receive the protection of Section 16 merely because it was intended to be done in good faith. It is also
necessary that the act complained of must have been in pursuance of the Act.
84. Shri Jethmalani also challenged the provisions of Section 16 on the ground of their
unreasonableness. He contends that the expression "good faith", which occurs in Section 16, has to
be construed in the sense in which it is defined in Section 3(22) of the General Clauses Act, 10 ofA.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

1897, according to which, a thing shall be deemed to be done in "good faith" where it is in fact done
honestly, whether it is done negligently or not. On the contrary, Section 52 of the Indian Penal Code
provides that 'nothing is said to be done or believed in "good faith" which is done or believed
without due care and attention. If the definition contained in Section 52 of the Penal Code were
made applicable, a suit or other proceeding could have lain against the detaining authority on the
ground that the order was passed carelessly or without a proper application of mind. Counsel
contends that since the General Clauses Act would apply, the detaining authority can defend the
order and defeat the suit or other proceeding brought against it by showing merely that the order
was passed honestly. We do not see any force in this grievance. If the policy of a law is to protect
honest acts, whether they are done with care or not, it cannot be said that the law is unreasonable.
In fact, honest acts deserve the highest protection. Then again, the line which divides a dishonest act
from a negligent act is often thin and, speaking generally, it is not easy for a defendant to justify his
conduct as honest, if it is accompanied by a degree of negligence. The fact, therefore, that the
definition contained in Section 3(22) of the General Clauses Act includes negligent acts in the
category of the acts done in good faith will not always make material difference to the proof of
matters arising in proceedings Under Section 16 of the Act.
85. That takes us to the last of the many points urged in this case, which relates to the Constitution
of Advisory Boards and the procedure before them. Three section of the National Security Act are
relevant in this context, namely, Section 9, 10 and 11. It may he recalled that Section 3 of the 44th
Constitution Amendment Act, 1978 made an important amendment to Article 22(4) of the
Constitution by providing that-
(i) No law of preventive detention shall authorise the detention of any person for more than two
months unless an Advisory Board has reported before the expiry of that period that there is in its
opinion sufficient cause for such detention;
(ii) the Advisory Board must be constituted in accordance with the recommendation of the Chief
Justice of the appropriate High Court; and
(iii) the Advisory Board must consist of a Chairman and not less than two other members, the
Chairman being a serving Judge of the appropriate High Court and the other members being serving
or retired judges of any High Court.
The main points of distinction between the amended provisions and the existing provisions of
Article 22(4) are that whereas, under the amended provisions, (i) the Constitution of the Advisory
Boards has to be in accordance with the recommendation of the Chief Justice of the appropriate
High Court, (ii) the Chairman of the Advisory Board has to be a serving Judge of the appropriate
High Court, and (iii) the other members of the Advisory Board have to be serving or retired Judges
of any High Court, under the existing procedure, (i) it is unnecessary to obtain the recommendation
of the Chief Justice of any High Court for constituting the Advisory Board and (ii) the members of
the Advisory Board need not be serving or retired Judges of a High Court: it is sufficient if they are
"qualified to be appointed as Judges of a High Court". By Article 217(2) of the Constitution, a citizen
of India is qualified for appointment as a Judge of a High Court if he has been advocate of a HighA.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

Court for ten years.
86. The distinction between the provisions of the amended and the unamended provisions of Article
22(4) in regard to the Constitution of Advisory Boards is of great practical importance from the
point of view of the detenu. The safeguards against unfounded accusation and the opportunity for
establishing innocence which constitute the hallmark of an ordinary criminal trial are not available
to the detenu. He is detained on the basis of ex parte reports in regard to his past conduct, with a
view to preventing him from persisting in that course of conduct in future. It is therefore of the
utmost importance from the detenu's point of view that the Advisory Board should consist of
persons who are independent, unbiased and competent and who possess a trained judicial mind.
But the question for our consideration is whether, as urged by Shri Jethmalani, Section 9 of the
National Security Act is bad for the reason that its provisions do not accord with the requirements of
Section 3 of the 44th Amendment Act. We find considerable difficulty in accepting this submission.
Earlier in this judgment, we have upheld the validity of Section 1(2) of the 44th Amendment Act, by
which the Parliament has given to the Central Government the power to bring into force all or any of
the provisions of that Act, with option to appoint different dates for the commencement of different
provisions of the Act. The Central Government has brought all the provisions of the 44th
Amendment Act into force except one, namely, Section 3, which contains the provision for the
Constitution of Advisory Boards. We have taken the view that we cannot compel the Central
Government by a writ of mandamus to bring the provisions of Section 3 into force. We have further
held that, on a true interpretation of Article 368(2) of the Constitution, it is in accordance with the
terms of the 44th Constitution Amendment Act that, upon the President giving his assent to that
Act, the Constitution stood amended. Since Section 3 has not been brought into force by the Central
Government in the exercise of its powers Under Section 1(2) of the 44th Amendment Act, that
section is still not a part of the Constitution. The question as to whether Section 9 of the National
Security Act is bad for the reason that it is inconsistent with the provisions of Section 3 of the 44th
Amendment Act, has therefore to be decided on the basis that Section 3, though a part of the 44th
Amendment Act, it is not a part of the Constitution. If Section 3 is not a part of the Constitution, it is
difficult to appreciate how the validity of Section 9 of the National Security Act can be tested by
applying the standard laid down in that section. It cannot possibly be that both the unamended and
the amended provisions of Article 22(4) of the Constitution are parts of the Constitution at one and
the same time. So long as Section 3 of the 44th Amendment Act has not been brought into force,
Article 22(4) in its unamended form will continue to be a part of the Constitution and so long as that
provision is part of the Constitution, the amendment introduced by Section 3 of the 44th
Amendment Act cannot become a part of the Constitution. Section 3 of 44th Amendment substitutes
a new Article 22(4) for the old Article 22(4). The validity of the Constitution of Advisory Boards has
therefore to be tested in the light of the provisions contained in Article 22(4) as it stands now and
not according to the amended Article 22(4). According to that Article as it stands now, an Advisory
Board may consist of persons, inter alia, who are qualified to be appointed as Judges of a High
Court. Section 9 of the National Security Act provides for the Constitution of the Advisory Boards in
conformity with that provision. We find it impossible to hold that the provision of a statute, which
conforms strictly with the existing provisions of the Constitution, can be declared bad either on the
ground that it does not accord with the provisions of a constitutional amendment which has not yet
come into force, or on the ground that the provision of the section is harsh or unjust. The standardA.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

which the Constitution, as originally enacted, has itself laid down for constituting Advisory Boards,
cannot be characterised as harsh or unjust. The argument, therefore, that Section 9 of the National
Security Act is bad for either of these reasons must fail.
87. We must hasten to add that the fact that Section 3 of the 44th Amendment has not yet been
brought into force does not mean that the Parliament cannot provide for the Constitution of
Advisory Boards in accordance with its requirements. The Parliament is free to amend Section 9 of
the National Security Act so as to bring it in line with Section 3 of the 44th Amendment. Similarly,
the fact that Section 9 provides for the Constitution of Advisory Boards consisting of persons "who
are, or have been, or are qualified to be appointed as Judges of a High Court" does not mean that the
Central Government or the State Governments cannot ['constitute Advisory Boards consisting of
serving or retired Judges of the High Court. The minimal standard laid down in Article 22(4)(a),
which is adopted by Section 9 of the Act, is binding on the Parliament while making a law of
preventive detention and on the executive while constituting an Advisory Board. That standard
cannot be derogated from. But, it can certainly be improved upon. We do hope that the Parliament
will take the earliest opportunity to amend Section 9 of the Act by bringing it in line with Section 3
of the 44th Amendment as the Ordinance did and that, the Central Government and the State
Governments will constitute Advisory Boards in their respective jurisdictions in accordance with
Section 3, whether or not Section 9 of the Act is so amended. We are informed that some
enlightened State Governments have already given that lead. We hope that the other Governments
will follow suit. After all, the executive must strive to reach the highest standards of justice and
fairness in all its actions, whether or not it is compellable by law to adopt those standards. Advisory
Boards consisting of serving or retired Judges of High Courts, preferably serving, and drawn from a
panel recommended by the Chief Justice of the concerned High Court will give credibility to their
proceedings. There will then be a reasonable assurance that Advisory Boards will express their
opinion on the sufficiency of the cause for detention, with objectivity, fairness and competence. That
way, the implicit promise of the Constitution shall have been fulfilled.
88. Now, as to the procedure of Advisory Boards. Shri Jethmalani laid great stress on this aspect of
the matter and, in our opinion, rightly. Consideration by the Advisory Board of the matters and
material used against the detenu is the only opportunity available to him for a fair and objective
appraisal of his case. Shri Jethmalani argues that the Advisory Boards must therefore adopt a
procedure which is akin to the procedure which is generally adopted by judicial and quasi-judicial
tribunals for resolving the issues which arise before them. He assails the procedure prescribed by
Sections 10 and 11 of the National Security Act on the ground that it is not in consonance with the
principles of natural justice, that it does not provide the detenu with an effective means of
establishing that what is alleged against him is not true and that it militates against the
requirements of Article 21. learned Counsel enumerated twelve requirements of natural justice
which, according to him, must be observed by the Advisory Boards. Those requirements may be
summed up, we hope without injustice to the argument, by saying that (i) the detenu must have the
right to be represented by a lawyer of his choice; (ii) he must have the right to cross-examine
persons on whose statements the order of detention is founded; and (iii) he must have the right to
present evidence in rebuttal of the allegations made against him. Counsel also submitted that the
Advisory Board must give reasons in support of its opinion which must be furnished to the detenu,A.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

that the entire material which is available to the Advisory Board must be disclosed to the detenu and
that the proceedings of the Advisory Board must be open to the public. According to Shri
Jethmalani, the Advisory Board must not only consider whether the order of detention was justified
but it must also consider whether it would have itself passed that order on the basis of the material
placed before it. Counsel says that the Advisory Board must further examine whether all the
procedural steps which are obligatory under the Constitution were taken until the time of its report,
the impact of loss of time and altered circumstances on the necessity to continue the detention and
last but not the least, whether there is factual justification for continuing the order of detention
beyond the period of three months. Counsel made an impassioned plea that 25 years of the Gopalan
jurisprudence have desensitised the community to the perils of preventive detention and that, it is
imperative to provide for the maximum safeguards to the detenu in order to preserve and protect his
liberty, which can be achieved by making at least the rudiments of due process available to him.
How much process is due must depend, according to Shri Jethmalani, on the extent of grievous loss
involved in the case. The loss in preventive detention is of the precious right of personal liberty and
therefore, it is urged, all such procedural facilities must be afforded to the detenu as will enable him
to meet the accusations made against him and to disprove them.
89. First and foremost, we must consider whether and to what extent the detenu is entitled to
exercise the trinity of rights before the Advisory Board: (i) the right of legal representation; (ii) the
right of cross examination and (iii) the right to present his evidence in rebuttal. These rights
undoubtedly constitute the core of just process because without them, it would be difficult for any
person to disprove the allegations made against him and to establish the truth. But there are two
considerations of primary importance which must be borne in mind in this regard. There is no
prescribed standard of reasonableness and therefore, what kind of processual rights should be made
available to a person in any proceeding depends upon the nature of the proceeding in relation to
which the rights are claimed. The kind of issues involved in the proceeding determine the kind of
rights available to the persons who are parties to that proceeding. Secondly, the question as to the
availability of rights has to be decided not generally but on the basis of the statutory provisions
which govern the proceeding, provided of course that those provisions are valid. In the instant case,
the question as to what kind of rights are available to the detenu in the proceeding before the
Advisory Board has to be decided in the light of the provisions of the Constitution, and on the basis
of the provisions of the National Security Act to the extent to which they do not offend against the
Constitution.
90. Turning first to the right of legal representation which is claimed by the petitioners, the relevant
article of the Constitution to consider is Article 22 which bears the marginal note "protection against
arrest and detention in certain cases." That article provides by Clause (1) that no person who is
arrested shall be detained in custody without being informed, as soon as may be, of the grounds for
such arrest nor shall he be denied the right to consult, and to be defended by, a legal practitioner of
his choice. Clause (2) requires that every person who is arrested and detained in custody shall be
produced before the nearest magistrate within a period of 24 hours of such arrest and that no
person shall be detained in custody beyond the said period without the authority of a magistrate.
Clause (3) provides that nothing in Clauses (1) and (2) shall apply (a) to any person who for the time
being is an enemy alien; or (b) to any person who is arrested or detained under any law providingA.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

for preventive detention. It may be recalled that Clause 4(a) of Article 22 provides that no law of
preventive detention shall authorise the detention of a person for a period longer than three months
unless the Advisory Board has reported before the expiry of the said period of three months that
there is in its opinion sufficient cause for such detention. By Clause 7(c) of Article 22, the Parliament
is given the power to prescribe by law the procedure to be followed by the Advisory Board in an
inquiry under Clause 4(a).
91. On a combined reading of Clauses (1) and (3) (b) of Article 22, it is clear that the right to consult
and to be defended by a legal practitioner of one's choice, which is conferred by Clause (1), is denied
by Clause 3(b) to a person who is detained under any law providing for preventive detention. Thus,
according to the express intendment of the Constitution itself, no person who is detained under any
law, which provides for preventive detention, can claim the right to consult a legal practitioner of his
choice or to be defended by him. In view of this, it seems to us difficult to hold, by the application of
abstract, general principles or on a priori considerations that the detenu has the right of being
represented by a legal practitioner in the proceedings before the Advisory Board, Since the
Constitution, as originally enacted, itself contemplates that such a right should not be made
available to a detenu, it cannot be said that the denial of the said right is unfair, unjust or
unreasonable. It is indeed true to say, after the decision in the Bank Nationalisation case, that
though the subject of preventive detention is specifically dealt with in Article 22, the requirements of
Article 21 have nevertheless to be satisfied. It is therefore necessary that the procedure prescribed by
law for the proceedings before the Advisory Boards must be fair, just and reasonable. But then, the
Constitution itself has provided a yardstick for the application of that standard, through the medium
of the provisions contained in Article 22(3)(b). Howsoever much we would have liked to hold
otherwise, we experience serious difficulty in taking the view that the procedure of the Advisory
Boards in which the detenu is denied the right of legal representation is unfair, unjust or
unreasonable. If Article 22 were silent on the question of the right of legal representation, it would
have been possible, indeed right and proper, to hold that the detenu cannot be denied the right of
legal representation in the proceedings before the Advisory Boards. It is unfortunate that courts
have been deprived of that choice by the express language of Article 22(3)(b) read with Article 22(1).
92. It is contended by Shri Jethmalani that the provision contained in Clause 3(b) of Article 22 is
limited to the right which is specifically conferred by Clause (1) of that article and therefore, if the
right to legal representation is available to the detenu apart from the provisions of Article 22(1), that
right cannot of denied to him by reason of the exclusionary provision contained in Article 22(3)(b).
Counsel says that the right of legal representation arises out of the provisions of Articles 19 and 21
and 22(5) and therefore, nothing said in Article 22(3)(b) can affect that right. In a sense we have
already answered this contention because, what that contention implies is that the denial of the
right of legal representation to the detenu in the proceedings before the Advisory Board is an
unreasonable restriction, within the meaning of Article 19(1), on the rights conferred by that article.
If the yardstick of reasonableness is provided by Article 22(3), which is as much a part of the
Constitution as originally enacted, as Articles 19, 21 and 22(5), it would be difficult to hold that the
denial of the particular right introduces an element of unfairness, unjustness or unreasonableness in
the procedure of the Advisory Boards. It would be stretching the language of Articles 19, 21 a little
too far to hold that what is regarded as reasonable by Article 22(3)(b) must be regarded asA.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

unreasonable within the meaning of those articles. For illustrating this point, we may take the
example of law which provides that an enemy alien need not be produced before a magistrate within
twenty-four hours of his arrest or detention in custody. If the right of production before the
magistrate within 24 hours of the arrest is expressly denied to the enemy alien by Article 22(3)(a), it
would be impossible to hold that the said right is nevertheless available to him by reason of the
provisions contained in Article 21. The reason is, that the answer to the question whether the
procedure established by law for depriving an enemy alien of his personal liberty is fair or just is
provided by the Constitution itself through the provisions of Article 22(3)(a). What that provision
considers fair, just and reasonable cannot, for the purposes of Article 21, be regarded as unfair
unjust or unreasonable.
93. To read the right of legal representation in Article 22(5) is straining the language of that article.
Clause (5) confers upon the detenu the right to be informed of the grounds of detention and the
right to be afforded the earliest opportunity of making a representation against the order of
detention. That right has undoubtedly to be effective, but it does not carry with it the right to be
represented by a legal practitioner before the Advisory Board merely because, by Section 10 of the
National Security Act, the representation made by the detenu is required to be forwarded to the
Advisory Board for its consideration. If anything, the effect of Section 11(4) of the Act, which
conforms to Article 22(3)(b), is that the detenu cannot appear before the Advisory Board through a
legal practitioner. The written representation of the detenu does not have to be expatiated upon by a
legal practitioner.
94. Great reliance was placed by Shri Jethmalani on the decision of the American Supreme Court in
Ozie Powell v. State of Alabama 77 L.ed. 158, in which it was held that the right of hearing includes
the right to the aid of counsel because, the right to be heard will in many cases be of little help if it
did not comprehend the right to be heard by a counsel. Delivering the opinion of the court,
Sutherland. J. said:
Even the intelligent and educated layman has small and sometimes no skill in the
science of law. If charged with crime, he is incapable, generally, of determining for
himself whether the indictment is good or bad. He is unfamiliar with the rules of
evidence. Left without the aid of counsel he may be put on trial without a proper
charge, and convicted upon incompetent evidence, or evidence irrelevant to the issue
or otherwise inadmissible. He lacks both the skill and knowledge adequately to
prepare his defence, even though he have a perfect one. He requires the guiding hand
of counsel at every step in the proceedings against him. Without it, though he be not
guilty, he faces the danger of conviction because he does not know how to establish
his innocence. If that be true of men of intelligence, how much more true is it of the
ignorant and illiterate, or those of feeble intellect. If in any case, civil or criminal, a
state or federal court were arbitrarily to refuse to hear a party by counsel, employed
by and appearing for him, it reasonably may not be doubted that such a refusal would
be a denial of a hearing, and, therefore, of due process in the constitutional sense.
(page 170) The aforesaid decision in Powell is unique in more than one way and has
to be distinguished. The petitioners therein were charged with the crime of rapeA.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

committed upon two white girls. At the trial, no counsel was employed on behalf of
petitioners but the trial Judge had stated that "he had appointed all the members of
the Bar for the purpose of arranging the defendants and then of course anticipated
that the members of the bar would continue to help the defendants if no counsel
appeared". The trial of the petitioners was completed within a single day, at the
conclusion of which the petitioners were sentenced to death. That verdict was
assailed on the ground, inter alia, that the petitioners were denied the right of
counsel. It must be stated that the Constitution of Alaboma provided that in all
criminal prosecutions, the accused shall enjoy the right to have the assistance of
counsel; and a state statute required that the court must appoint a counsel for the
accused in all capital cases where the accused was unable to employ one. It is in the
light of these provisions and as a requirement of the due process clause of the
American Constitution that it was held that the right to hearing, which is a basic
element of due process, includes the right to the aid of counsel. The patent distinction
between that case and the matter before us is that our Constitution, at its very
inception, regarded it reasonable to deny to the detenu the right to consult and be
defended by a legal practitioner of his choice. Secondly, a criminal trial involves
issues of a different kind from those which the Advisory Board has to consider. The
rights available to an accused can, therefore, be of a different character than those
available to the detenu, consistently with reason and fairplay.
95. Shri Jethmalani also relied upon another decision of the Supreme Court which is reported in
John J. Morrissey v. Lou B. Brewer 33 L.ed. 2nd 484. In that case, two convicts whose paroles were
revoked by the Iowa Board of Parole, alleged that they were denied due process because their
paroles were revoked without a hearing. Burger C.J., expressing the view of six members of the
court, expressly left upon the question whether a prolee is entitled, in a parole revocation
proceeding, to the assistance of counsel. The three other learned Judges held that due process
requires that the parolee be allowed the assistance of counsel in the parole revocation proceeding. Ft
must be appreciated that the American decisions on the right to counsel turn largely on the due
process clause in the American Constitution. We cannot invoke that clause for spelling out a right as
part of a reasonable procedure, in matters wherein our Constitution expressly denies that right.
96. In support of his submission that for detenu is entitled to appear through a legal practitioner
before the Advisory Board, Shri Jettimalani relies on the decisions of this Court in Madhav
Haywadanroo Hoskot v. State of Maharashtra . Hussainara Khatoon v. Home Secretary, State of
Bihar and Francis Coralie Mullin v. The Administrator, Union Territory of Delhi . Speaking for the
Court, Krishna Iyer, J. said in Hoskot:
The other ingredient of fair procedure to a prisoner, who has to seek his liberation
through the court process is lawyer's services. Judicial justice, with procedural
intricacies, legal submissions and critical examination of evidence, leans upon
professional expertise; and a failure of equal justice under the law is on the carde
where such supportive skill is absent for one side. Our judicature, moulded by
Anglo-American models and our judicial process, engineered by kindred legalA.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

technology, compel the collaboration of lawyer-power for steering the wheels of equal
justice under the law, Page (204)
97. In Hussainara Khatoon, one of us, Bhagwati, J. voiced the concern by saying:
It is an essenticial ingredient reasonable, fair and just procedure to a prisoner who is
to seek his liberation through the court's process that he should have legal services
avail to him. (Page 103).
These observations were made in the context of rights available to an accused in a
criminal trial and cannot be extended to the proceedings of Advisory Boards in order
to determine the rights of detenus in relation to those proceedings The question as
regards the kind and nature of rights available in those proceedings has to be decided
on the basis of the provisions contained in Article 22 of the Constitution and Sections
10 and 11 of the National Security Act.
98. In Francis Caralie Mullin, the petitioner, while in detention, wanted to have an interview with
her lawyer, which was rendered almost impossible by reason of the stringent provisions of Clause
3(b)(i) of the 'Conditions of Detention' formulated by the Delhi Administration. In a petition filed in
this Court to challenge the aforesaid clause, inter alia, it was held by this Court that the clause was
void, since it violated Articles 14 and 21 by its discriminatory nature and unreasonableness. The
Court directed that the detenu should be permitted to have an interview with her legal adviser at any
reasonable hour during the day after taking an appointment from the Superintendent of the jail and
that the interview need not necessarily take place in the presence of an officer of the Customs or
Central Excise Department. The Court also directed that the officer concerned may watch the
interview but not so as to be within the hearing distance of the detenu and the legal adviser. This
decision has no bearing on the point which arises before us, since the limited question which was
involved in that case was whether the procedure prescribed by Clause (3), governing the interviews
which a detenu may have with his legal adviser was reasonable. The Court was not called upon to
consider the question as regards the right of a detenu to be represented by a legal practitioner before
the Advisory Board.
99. We must therefore, held, regretfully though, that the detenu has no right to appear through a
legal practitioner in the proceedings before the Advisory Board. It is, however, necessary to add an
important caveat. The reason behind the provisions contained in Artice 22(4)(b) of the Constitution
clearly is that a legal practitioner should not be permitted to appear before the Advisory Board for
any party. The Constitution does not contemplate that the detaining authority or the Government
should have the facility of appearing before the Advisory Board with the aid of a legal practitioner
but that the said facility should be denied to the detenu. In any case, that is not what the
Constitution says and it would be wholly inappropriate to read any such meaning into the provisions
of Article 22. Permitting the detaining authority or the Government to appear before the Advisory
Board with the aid of a legal practitioner or a legal adviser would be in breach of Article 14, if a
similar facility is denied to the detenu. We must therefore make it clear that if the detaining
authority or the Government takes the aid of a legal practitioner or a legal adviser before theA.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

Advisory Board, the detenu must be allowed the facility of appearing before the Board through a
legal practitioner. We are informed that officers of the Government in the concerned departments
often appear before the Board and assist it with a view to justifying the detention orders. If that be
so, we must clarify that the Boards should not permit the authorities to do indirectly what they
cannot do directly; and no one should be enabled to take shelter behind the excuse that such officers
are not "legal practitioners" or legal advisers, Regard must be had to the substance and not the form
since, especially, in matters like the proceedings of Advisory Boards, whosoever assist or advises on
facts or law must be deemed to be in the position of a legal adviser. We do hope that Advisory
Boards will take care to ensure that the provisions of Article 14 are not violated in any manner in the
proceedings before them. Serving or retired Judges of the High Court will have no difficulty in under
standing this position. Those who are merely "qualified to be appointed" as High Court 6udges may
have to do a little homework in order to appreciate.
100. Another aspect of this matter which needs to be mentioned is that the embargo on the
appearance of legal practitioners should not be extended so as to prevent the detenu from being
aided or assisted by a friend who, in truth and substance, is not a legal practitioner. Every person
whose interests are adversely affected as a result of the proceedings which have a serious import, is
entitled to be heard in those proceedings and be assisted by a friend. A detenn, taken straight from
ois cell to the Board's room, may lack the ease and composure to present his point of view. He may
be "tonguetied, nervous, confused or wanting in intelligence", (see Pelt v. Greyhound Racing
Association Ltd.) [1969] 1 Q.B. 125, and if justice to be done, he must at least have the help of a
friend who can assist him to give coherence to his stray and wandering ideas. Incarceration makes a
man and his thoughts dishevelled. Just as a person who is domb is entitled, as he must, to be
represented by a person who has speech, even so, a person who finds himself unable to present his
own case is entitled to take the aid and advice of a person who is better situated to appreciate the
facts of the case and the language of the law. It may be that denial of legal representation is not
denial of natural justice per se, and therefore, if a statute excludes that facility expressly, it would
not be open to the tribunal to allow it. Fairness, as said by Lord Denning M.R., in Maynard v.
Osmond [1977] 1 Q.B. 240, 253 can be obtained without legal representation. But, it is not fair, and
the statute does not exclude that right, that the detenu should not even be allowed to take the aid of
a friend. Whenever demanded, the Advisory Boards must grant that facility.
101. Shri Jethmalani laid equally great stress on the need to give the detenu the right of
cross-examination and in support of his submission in that behalf, he relied on the decisions of the
American Supreme Court in Jack R. Goldberg v. John Kelly 25 L.ed. 2d. 287, 300, 301, Morrissey,
Norvai Goss v. Eileen Lopez 42 Led. 2d 725 and Powell. In Goldberg, Brennan, J., expressing the
view of five members of the court said that in almost every setting where important decisions turn
on questions of fact, due process requires opportunity to confront and cross-examine adverse
witnesses. The learned Judge reiterated the court's observations in Greeny v. Mc Elorey 3 L.ed. 2d
1377, 1390, 1391 to the following effect:
Certain principles have remained relatively immutable in our jurisprudence. One of
these is that where governmental action seriously injures an individual, and toe
reasonableness of the action depends on fact findings, the evidence used to prove theA.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

Government's case must be disclosed to the individual so that he has an opportunity
to show that it is untrue. While this is important in the case of documentary evidence,
it is even more important where the evidence consists of the testimony of individuals
whose memory might be faulty or who, in fact, might be prejurors or persons
motivated by malice, vinditiveness, intolerance, prejudice, or jealousy. We have
formalized these protections in the requirements of confrontation and
cross-examination. They have ancient roots. They find expression in the Sixth
Amendment.... This Court has been zealous to protect these right from erosion. It has
spoken out not only in criminal cases, ... but also in all types of cases where
administrative ... actions were under scrutiny.
Welfare recipients whose aid was terminated or was about to be terminated were held
entitled to be given an opportunity to confront and cross-examine the witnesses
relied on by the department. The right to confront and cross-examine adverse
witnesses was upheld in the other American cases also which counsel has cited.
102. For reasons which we have stated more than once during the course of this judgment, the
decisions of the U.S. Supreme Court which turn peculiarly on the due process clause in the
American Constitution cannot be applied wholesale for resolving questions which arise under our
Constitution, especially when, after a full discussion of that clause in the Constituent Assembly, the
proposal to incorporate it in Article 21 was rejected. In U.S.A. itself, Judges have expressed views on
the scope of the clause, which are not only divergent but diametrically opposite. For exmple, in
Goldberg on which Shri Jethmalani has placed considerable reliance, Black, J., said in his dissenting
opinion that the majority was using the judicial power for legislative purposes and that "they wander
out of their filed of vested powers and transgress into the area constitutionally assigned to the
Congress and the people". The dissenting opinion of Chief Justice Burger in that case is reported in
Mue Wheeler v. John Montgomery 25 L.ed. 2d 307, 311, in the some volume. Describing the
majority opinion as 'unwise and precipitous" the learned Chief Justice said:
The Court's action today seems another manifestation of the now familiar
constitionalizing syndrome: once some presumed flaw is observed, the Court then
eagerly accepts the inviation to find a constitutionally "rooted" remedy. If no
provision is explicit on the point it is then seen as implicit" or commanded by the
vague and nebulous concept of "fairness.
It is only proper that we must evolve our own solution to problems arising under our
Constitution without, of course, spurning the learning and wisdom of our
counterparts in comparable jurisdictions.
103. The principal question which arises is whether the right of cross-examination is an integral and
inseparable part of the principles of natural justice. Two fundamental principles of natural justice
are commonly recognised, namely, that an adjudicator should be disinterested and unbiased (nemo
judex in cause sua) and that, the parties must be given adequate notice and opportunity to be heard
(audi alterm partem). There is no fixed or certain standard of natural justice, substantive orA.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

procedural, and in two English cases the expression 'natural justice' was described as one 'sadly
lacking in precision' Local Govt. Board v. Arlidge [1915] A.C. 120, 138 and as 'vacuous' [1914] 1 KB.
@ 199. The principles of natural justice are, in fact, mostly evolved from case to case, according to
the broad requirements of justice in the given case.
104. We do not suggest that the principles of natural justice, vague and variable as they may be, are
not worthy of preservation. As observed by Lord Reid in Ridge v. Baldwin [1964] A.C. 40, 64-65, the
view that natural justice is so vague as to be practically meaningless" is tainted by "the perennial
fallacy that because something cannot be cut and dried or nicely weighed or measured therefore it
does not exist". But the importance of the realisation that the rules of natural justice are not rigid
norms of unchanging content, consists in the fact that the ambit of those rules must vary according
to the context, and they have to be tailored to suit the nature of the proceeding in relation to which
the particular right is claimed as a component of natural justice. Judged by this test, it seems to us
difficult to hold that a detenu can claim the right of cross-examination in the proceeding before the
Advisory Board. First and foremost, cross-examination of whom ? The principle that witnesses must
be confronted and offered for cross-examination applies generally to proceedings in which witnesses
are examined or documents are adduced in evidence in order to prove a point. Cross-examination
then becomes a powerful weapon for showing the untruthfulness of that evidence. In proceedings
before the Advisory Board, the question for consideration of the Board is not whether the detenu is
guilty of any charge but whether there is sufficient cause for the detention of the person concerned.
The detention, it must be remembered, is based not on fact proved either by applying the test of
preponderance of probabilities or of reasonable doubt. The detention is based on the subjective
satisfaction of the detaining authority that it is necessary to detain a particular person in order to
prevent him from acting in a manner prejudicial to certain stated objects. The proceeding of the
Advisory Board has therefore to be structured differently from the proceeding of judicial or
quasi-judicial tribunals, before which there is a Us to adjudicate upon,
105. Apart from this consideration, it is a matter of common experience that in cases of preventive
detention, witnesses are either unwilling to come forward or the sources of information of the
detaining authority cannot be disclosed without detriment to public interest. Indeed, the disclosure
of the identity of the informant may abort the very process of preventive detention because, no one
will be willing to come forward to give information of any prejudicial activity if his identity is going
to be disclosed, which may have to be done under the stress of cross-examination. It is therefore
difficult, in the very nature of things, to give to the detenu the full panoply of rights which an
accused is entitled to have in order to disprove the charges against him. That is the importance of
the statement that the concept of what is just and reasonable is flexible in its scope and calls for such
procedural protections as the particular situation demands. Just as there can be an effective hearing
without legal representation even so, there can be an effective hearing without the right of
cross-examination. The nature of the inquiry involved in the proceeding in relation to which these
rights are claimed determines whether these rights must be given as components of natural justice.
106. In this connection, we would like to draw attention to certain decisions of our Court. In New
Prakash Transport Co. Ltd. v. New Suwarna Transport Co. Ltd. [1957] S.C.R. 98, 106, it was
observed that "the question whether the rules of natural justice have been observed in a particularA.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

case must itself be judged in the light of the Constitution of the statutory body which has to function
in accordance with the rules laid down by the legislature and in that sense the rules themselves must
vary". In Nagendra Nath Bora v. Commissioner of Hills Division and Appeals, Assam [1958] S.C.R.
1240, 1261, the aforesaid statement was cited with approval by another Constitution Bench. In State
of Jammu Kashmir v. Bakshi Ghulam Mohammed [1966] supp. S.C.R. 401, 415, it was argued that
the right to hearing included the right to cross-examine witnesses. That argument was rejected by
the Court by observing that the right of cross-examination depends upon the circumstances of each
case and on the terms of the statute under which the matter is being enquired into. Citing with
approval the passage in Nagendra Nath Bora, the Court held that the question as to whether the
right to cross-examine was available had to be decided in the light of the fact that it was dealing with
a statute under which a Commission of Inquiry was set up for fact-finding purposes and that the
report of the Commission had no force proprio vigore.
107. In support of his submission that the right of cross-examination is a necessary part of natural
justice, Shri Jethmalani relies upon the decisions of this Court which are reported in Union of India
v. T.R. Varma [1958] S.C.R. 499, 507 and Khem Chand v. Chand Union of India [1958] S.C.R. 1080,
1096. It was observed in the first of these two cases that the rules of natural justice require that the
party concerned should have the opportunity of adducing the relevant evidence on which he relies,
that the evidence of the opponent should be taken in his presence, that "he should be given the
opportunity of cross-examining the witnessess examined by" the other side and that no materials
should be relied on against him without his being given an opportunity of explaining them. In Khem
Chand it was held that if the purpose of Article 311(2) was to give the Government servant an
opportunity to exonerate himself from the charge and if this opportunity is to be a reasonable one,
he should be allowed to show that the evidence against him is not worthy of credence or
consideration and, "that he can only do if he is given a chance to cross-examine the witnesses called
against him "and to examine himself or any other witnesses in support of his defence. These
observations must be understood in the context of the proceedings in which they are made and
cannot be taken as laying down a general rule that the right of cross-examination is available as a
part of natural justice in each and every proceeding. In both of these cases, the question which arose
for consideration of the Court was whether a Government servant, who was dismissed from service,
was given "a reasonable opportunity" of showing cause against the action proposed to be taken
against him, within the meaning of Article 311(2) of the Constitution, It shall have been noticed that
the emphasis in these cases is on the right to cross-examine the witnesses who are examined by the
opposite party. In T.R. Varma the right of cross-examination is described as the right in regard to
the witnesses examined by the other party while in Khem Chand, the right is described as an
opportunity to defend oneself by cross-examining the witnesses produced by the other side. No
witnesses are examined in the proceedings before the Advisory Board on behalf of the detaining
authority and therefore, the rule laid down in the two decisions on which Shri Jethmalani relies can
have no application to those proceedings.
108. If the debates of the Constituent Assembly are any indication, it would appear that Dr. B.R.
Ambedkar, at any rate, was of the opinion that the detenu should be given the right to cross-examine
witnesses before the Advisory Board. In his reply to the debate on the procedure of the Advisory
Board, he said on September 16, 1949 that a "pointed question has been asked whether the accusedA.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

person would be entitled to appear before the Board, cross-examine the witnesses, and make his
own statement". Dr. Ambedkar's answer was that the Parliament should be given the power to
prescribe the procedure to be followed by the Advisory Board. That is how Clause 7(c) came to be
incorporated in Article 22 of the Constitution, giving that power to the Parliament. Pandit Thakur
Dass Bhargava thereafter asked as to what was the position regarding the safeguard of
cross-examination. The reply of Dr. Ambedkar, significantly, was:
The right of cross-examination is already there in the Criminal Procedure Code and
in the Evidence Act. Unless a provincial Government goes absolutely stark mad and
takes away these provisions it is unnecessary to make any provision of that sort.
Defending includes cross examination.
x x x x x If you can give a single instance in India where the right of
cross-examination has been taken away, I can understand it. I have not seen any such
case." (see Constituent Assembly Debates, Vol. 9, pages 1561, 1562, 1563).
Dr. Ambedkar, unfortunately, was not prophetic and the authors of the various
Preventive Detention Acts did not evidently share his view. In fact, the right of
cross-examination under the Criminal Procedure Code and the Evidence Act, by
which Dr. Ambedkar laid great store, has nothing to do with the detenu's right of
cross-examination before the Advisory Board. With great respect, Dr. Ambedkar
seems to have nodded slightly in referring to the provision for cross examination
under those Acts. Whatever it is, Parliament has not made any provision in the
National Security Act, under which the detenu could claim the right of
cross-examination and the matter must rest there.
109. We are therefore of the opinion that, in the proceedings before the Advisory Board, the detenu
has no right to cross-examine either the persons on the basis of whose statement the order of
detention is made or the detaining authority.
110. The last of the three rights for which Shri Jethmalani contends is the right of the detenu to lead
evidence in rebuttal before the Advisory Board. We do not see any objection to this right being
granted to the detenu. Neither the Constitution nor the National Security Act contains any provision
denying to the detenu the right to present his own evidence in rebuttal of the allegations made
against him. The detenu may therefore offer oral and documentary evidence before the Advisory
Board in order to rebut the allegations which are made against him. We would only like to add that
if the detenu desires to examine any witnesses, he shall have to keep them present at the appointed
time and no obligation can be cast on the Advisory Board to summon them. The Advisory Board,
like any other tribunal, is free to regulate its own procedure within the constraints of the
Constitution and the statute. It would be open to it, in the exercise of that power, to limit the time
within which the detenu must complete his evidence. We consider it necessary to make this
observation particulary in view of the fact that the Advisory Board is under an obligation Under
Section 11(1) of the Act to submit its report to the appropriate Government within seven weeks from
the date of detention of the person concerned. The proceedings before the Advisory Board haveA.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

therefore to be completed with the utmost expedition.
111. It is urged by Shri Jethmalani that the Advisory Board must decide two questions which are of
primary importance to the detenu: One, whether there was sufficient cause for the detention of the
person concerned and two, whether it is necessary to keep the person in detention any longer after
the date of its report. We are unable to accept this contention. Section 11(2) of the Act provides
specifically that the report of the Advisory Board shall specify its opinion "as to whether or not there
is sufficient cause for the detention of the person concerned". This implies that the question to
which the Advisory Board has to apply its mind is whether on the date of its report there is sufficient
cause for the detention of the person. That inquiry necessarily involves the consideration of the
question as to whether there was sufficient cause for the detention of the person when the order of
detention was passed, but we see no justification for extending the jurisdiction of the Advisory
Board to the consideration of the question as to whether it is necessary to continue the detention of
the person beyond the date on which it submits its report or beyond the period of three months after
the date of detention. The question as to whether there are any circumstances on the basis of which
the detenu should be kept in detention after the Advisory Board submits its report, and how long, is
for the detaining authority to decide and not for the Board. The question as regards the power of the
Advisory Board in this behalf had come up for consideration before this Court in Puranlal Lakhanpal
v. Union of India [1958] SCR 460, 475. While rejecting the argument that the words "such
detention" which occur in Article 22(4)(a) of the Constitution mean detention for a period longer
than three months, the majority held that the Advisory Board is not called upon to consider whether
the detention should continue beyond the period of three months. In coming to that conclusion the
majority relied upon the decision in Dattatraya Moreshwar Pangarkar v. State of Bombay [1952]
SCR 612, 626 in which Mukherjea, J., while dealing with a similar question, observed:
The Advisory Board again has got to express its opinion only on the point as to
whether there is sufficient cause for detention of the person concerned. It is neither
called upon nor is it competent to say anything regarding the period for which such
person should be detained. Once the Advisory Board expresses its view that there is
sufficient cause for detention at the date when it makes its report, what action is to be
taken subsequently is left entirely to the appropriate Government and it can Under
Section 11(1) of the Act confirm the detention order and continue detention of the
person concerned for such period as it thinks fit.
The contention that the Board must determine the question as to whether the
detention should continue after the date of its report must therefore fail. The duty
and function of the Advisory Board is to determine whether there was sufficient cause
for detention of the person concerned on the date on which the order of detention
was passed and whether or not there is sufficient cause for the detention of that
person on the date of its report.
112. We are not inclined to accept the plea made by the learned Counsel that the proceedings of the
Advisory Board should be thrown open to the public. The right to a public trial is not one of the
guaranteed rights under our Constitution as it is under the 6th Amendment of the AmericanA.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

Constitution which secures to persons charged with crimes a public, as well as a speedy, trial. Even
under the American Constitution, the right guaranteed by the 6th Amendment is held to be personal
to the accussed, which the public in general cannot share. Considering the nature of the inquiry
which the Advisory Board has to undertake, we do not think that the interests of justice will be
served better by giving access to the public to the proceedings of the Advisory Board.
113. This leaves for consideration the argument advanced by Shri Jethmalani relating to the
post-detention conditions applicable to detenus in the matter of their detention. The learned
Counsel made a grievance that the letters of detenus are censored, that they are not provided with
reading or writing material according to their requirements and that the ordinary amenities of life
are denied to them. It is difficult for us to frame a code for the treatment of detenus while they are
held in detention. That will involve an exercise which calls for examination of minute details, which
we cannot undertake. We shall have to examine each case as it comes before us, in order to
determine whether the restraints imposed upon the detenu in any particular case are excessive and
unrelated to the object of detention. If so, they shall have to be struck down. We would, however,
like to say that the basic commitment of' our Constitution is to foster human dignity and the
well-being of our people. In recent times, we have had many an occasion to alert the authorities to
the need to treat even the convicts in a manner consistent with human dignity. The judgment of
Krishna Iyer, J. in Sunil Batra v. Delhi Administration is an instance in point. It highlights that
places of incarceration are "part of the Indian earth" and that, "the Indian Constitution cannot be
held at bay by jail officials 'dressed in a little, brief authority". We must impress upon the
Government that the detenus must be afforded all reasonable facilities for an existence consistent
with human dignity. We see no reason why they should not be permitted to wear their own clothes,
eat their own food, have interview with the members of their families at least once a week and, last
but not the least, have reading and writing material according to their reasonable requirement.
Books are the best friends of man whether inside or outside the jail.
114. There is one direction which we feel called upon to give specifically and that is that persons who
are detained under the National Security Act must be segregated from the convicts and kept in a
separate part of the place of detention. It is hardly fair that those who are suspected of being
engaged in prejudicial conduct should be lodged in the same ward or cell were the convicts whose
crimes are established are lodged. The evils of "custodial perversity" are well-known and have even
found a place in our law reports. As observed by Krishna Iyer, J. in Sunil Batra, the most important
right of the person who is imprisoned is to the integrity of his physical person and mental
personality. Even within the prison, no person can be deprived of his guaranteed rights save by
methods which are fair, just and reasonable. "In a democracy, a wrong to some one is a wrong to
every one" and care has to be taken to ensure that the detenue is not subjected to any indignity.
While closing this judgment, we would like to draw attention to what Shah, J. said for the Court in
Sampat Prakash v. State of Jammu & Kashmir .:
The petitioner who was present in the Court at the time of hearing of his petition
complained that he is subjected to solitary confinement while in detention. It must be
emphasised that a detenu is not a convict. Our Constitution, notwithstanding the
broad principles of the rule of law, equality and liberty of the individual enshrinedA.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

therein, tolerates, on account of peculiar conditions prevailing legislation which is a
negation of the rule of law, equality and liberty. But it is implicit in the Constitutional
scheme that the power to detain is not a power to punish for offences which an
executive authority in his subjective satisfaction believes a citizen to have committed.
Power to detain is primarily intended to be exercised in those rare cases when the
large interest of the State demand that restrictions shall be placed upon the liberty of
a citizen curbing his future activities. The restrictions so placed must consistently
with the effectiveness of detention, be minimal.
If any of the persons detained under the National Security Act are at present housed
in the same ward or cell where the convicts are housed, immediate steps must be
taken to segregate them appropriately. "The Indian human", whenever necessary, has
of course "a constant companion-the Court armed with the Constitution" and
informed by it.
115. In the result, the Writ Petitions shall stand disposed of in accordance with the view expressed
herein and the orders and directions given above.
Gupta, J.
116. I find myself unable to agree with the views expressed in the judgment of the learned Chief
Justice on two of the points that arise for decision in this batch of writ petitions, one of them relates
to the failure of the Central Government to bring into operation the provisions of Section 3 of the
Constitution (Forty-Fourth Amendment) Act, 1978 and the other concerns the question whether an
ordinance is 'law' within the meaning of Article 21 of the Constitution.
117. The Constitution (Forty-Fourth Amendment) Act, 1978 received assent of the President on April
30, 1979. Article 368(2) says, inter alia, that after a Bill for the amendment of the Constitution is
passed in each House of Parliament by the prescribed majority "it shall be presented to the
President who shall give his assent to the Bill and thereupon the Constitution shall stand amended
in accordance with the terms of the Bill". Section 1(2) of the Constitution (Forty-Fourth
Amendment) Act states that the Act "shall come into force on such date as the Central Government,
may, by notification in the Official Gazette, appoint," and that "different dates may be appointed for
different provisions of this Act". Section 3 of the Amendment Act substitutes a new clause for the
existing Clause (4) of Article 22 of the Constitution which provides inter alia for the Constitution of
Advisory Boards. The relevant part of Section 3 reads as follows;
Amendment of Article 22. In Article 22 of the Constitution,-
(a) for Clause (4), the following clause shall be substituted, namely:
(4) No law providing for preventive detention shall authorise the detention of a
person for a longer period than two months unless an Advisory Board constituted in
accordance with the recommendations of the Chief Justice of the appropriate HighA.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

Court has reported before the expiration of the said period of two months that there
is in its opinion sufficient cause for such detention:
Provided that an Advisory Board shall consist of a Chairman and not less than two
other members, and the Chairman shall be a serving Judge of the appropriate High
Court and the other members shall be a serving or retired Judges of any High Court.
The provision requiring the Advisory Board to be constituted in accordance with the
recommendations of the Chief Justice of the appropriate High Court and that the
Chairman of the Advisory Board shall be a serving Judge of the High Court and the
other members of the Board shall be serving or retired Judges of any High Court is
absent in the existing Clause (4) under which persons who are only qualified to be
appointed as Judges of a High Court are eligible to be members of the Advisory
Board. Many of the provisions of the Act were brought into force on different dates in
the year 1979 but the provisions of Section 3 were not given effect to for more than
one year and seven months when the hearing of these writ petitions commenced on
December 9, 1980. Now though more than two and a half years have passed the
provisions of Section 3 have not yet been brought into force. The question is whether
Under Section 1(2) the Central Government had the freedom to bring into force any
of the provisions of the Amendment Act at any time it liked. I do not think that
Section 1(2) can be construed to mean that Parliament left is to the unfettered
discretion or judgment of the Central Government when to bring into force any
provision of the Amendment Act. After the Amendment Act received the President's
assent, the Central Government was under an obligation to bring into operation the
provisions of the Act within a reasonable time; the power to appoint dates for
bringing into force the provisions of the Act was given to the Central Government
obviously because it was not considered feasible to give effect to all the provisions
immediately. After the Amendment Act had received the President's assent the
Central Government could not in it discretion keep it in a state of suspended
animation for any length of time it pleased. That Parliament wanted the provisions of
the Constitution (Forty-Fourth Amendment) Act, 1978 to be made effective as early
as possible would appear from its Objects and Reasons. The following extract from
the Objects and Reasons clearly discloses a sense of urgency:
Recent experience has shown that the fundamental rights, including those of life and
liberty, granted to citizens by the Constitution are capable of being taken away by a
transient majority. It is, therefore, necessary to provide adequate safeguards against
the recurrence of such a contingency in the future and to ensure to the people
themselves an effective voice in determining the form of government under which
they are to live. This is one of the primary objects of this Bill.
x x x x x As a further check against the misuse of the Emergency provisions and to put
the right to life and liberty on a secure footing, it would be provided that the power to
suspend the right to move the court for the enforcement of a fundamental rightA.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

cannot be exercised in respect of the fundamental right to life and liberty. The right to
liberty is further strengthened by the provision that a law for preventive detention
cannot authorise, in any case, detention for a longer period than two months, unless
an Advisory Board has reported that there is sufficient cause for such detention. An
additional safeguard would be provided by the requirement that the Chairman of an
Advisory Board shall be a serving Judge of the appropriate High Court and that the
Board shall be constituted in accordance with the recommendations of the Chief
Justice of that High Court.
118. I have already said that Parliament must have taken into consideration the practical difficulties
in the way of the executive in bringing into operation all the provisions of the Act immediately, and
by enacting Section 1(2) it relied on the Central Government to give effect to them. Now when more
than two and a half years have passed since the Constitution (Forty-Forth Amendment) Act, 1978
received the assent of the President, it seems impossible that any such difficulty should still persist
preventing the Government from giving effect to Section 3 of the Amendment Act. It is interesting to
note that Clause 9 of the National Security Ordinance, 1980 provided for the Constitution of
Advisory Boards in conformity with Article 22 of the Constitution as amended by Section 3 of the
Constitution (Forty-Fourth Amendment) Act, 1978. This makes it clear that non-implementation of
the provisions of Section 3 was not due to any practical or administrative difficulty. However, the
National Security Act, 1980 which replaced the Ordinance does not retain the provison of Clause 9
of the Ordinance and prescribes the Constitution of the Advisory Boards in Section 9 in accordance
with unamended Article 22(4). I do not think it can be seriously suggested that a provision like
Section 1(2) of the Constitution (Forty-Fourth Amendment) Act empowered the executive to scotch
an amendment of the Constitution passed by Parliament and assented to by the President. The
Parliament is competent to take appropriate steps if it considered that the executive had betrayed its
trust does not make the default lawful or relieve this Court of its duty. I would therefore issue a writ
of mandamus directing the Central Government to issue a notification Under Section 1(2) of the
Constitution (Forty-Fourth Amendment) Act, 1978 bringing into force the provisions of Section 3 of
the Act within two months from this date.
119. On the other point, I find it difficult to agree that an ordinance is 'law' within the meaning of
Article 21 of the Constitution. Article 21 reads:
No person shall be deprived of his life or personal liberty except according to
procedure established by law.
The National Security Ordinance, 1980 has been challenged on a number of grounds,
one of which is that the life and liberty of person cannot be taken away by an
ordinance because it is not 'law' within the meaning of Article 21. Normally it is the
legislature that has the power to make laws. Article 123 of the Constitution deals with
the President's power to promulgate ordinances and the nature and effect of an
ordinance promulgated under this article, Article 123 is as follows:A.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

(1) It at any time, except when both Houses of Parliament are in session, the
President is satisfied that circumstances exist which render it necessary for him to
take immediate actien, he may promulgate such Ordinances as the circumstances
appear to him to require.
(2) An Ordinance promulgated under this article shall have the same force and effect
as an Act of Parliament, but every such Ordinance-
(a) shall be laid before both Houses of Parliament and shall cease to operate at the
expiration of six weeks from the reassembly of Parliament, or, if before the expiration
of that period resolutions disapproving it are passed by both Houses, upon the
passing of the second of those resolutions; and
(b) may be withdrawn at any time by the President.
Explanation-Where the Houses of Parliament are summoned to reassemble on different dates, the
period of six weeks shall be reckoned from the later of those dates for the purpose of this clause.
(3) If and so far as an Ordinance under this article makes any provision which Parliament would not
under this Constitution be competent to enact, it shall be void.
120. To show that there is no difference between a law passed by Parliament and an Ordinance
promulgated by the President under Article 123 reliance was placed on behalf of the Union of India
on Clause (2) of the article which says that an Ordinance shall have the same force and effect as an
Act of Parliament. It was further pointed out that chapter III of part V of the Constitution which
includes Article 123 is headed "Legislative Powers of the President." Reference was made to Article
213 which concerns the power of the Governor to promulgate Ordinances: Article 213 is in chapter
IV of part VI of the Constitution which hears a similar decsription: Legislative Power of the
Governor." From these provisions it was contended that the President in promulgating an
Ordinance under Article 123 exercises his legislative power and therefore an ordinance must be
regarded as 'law' within the meaning of Article 21. But the nature of the power has to be gathered
from the provisions of Article 123 and not merely from the heading of the chapter. It is obvious that
when something is said to have the force and effect of an Act of Parliament, that is because it is not
really an Act of Parliament. Article 123(2) does say that an Act of Parliament to make the two even
fictionally identical. The significance of the distinction will be clear by a reference to Articles 356
and 357 which are in part XVIII of the Constitution that contains the emergency provisians. The
relevant part of Article 356 reads:
(1) If the President, on receipt of a report from the Governor of a State or otherwise,
is satisfied that a situation has arisen in which the government of the State cannot be
carried on in accordance with the provisions of this Constitution, the President may
by Proclamation-A.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

(a) assume to himself all or any of the functions of the Government of the State and
all or any of the powers vested in or exercisable by the Governor or any body or
authority in the State other than the Legislature of the State;
(b) declare that the powers of the Legislature of the State shall be exercisable by or
under the authority of Parliament;
Article 357 provides:
(1) Where by a Proclamation issued under Clause (1) of Article 356, it has been
declared that the powers of the Legislature of the State shall be exercisable by or
under the authority of Parliament, it shall be competent-
(a) for Parliament to confer on the President the power of the Legislature of the State
to make laws, and to authorise the President to delegate, subject to such conditions as
he may think fit to impose, the power so conferred to any other authority to be
specified by him in that behalf;
(b) for Parliament, or for the President or other authority in whom such power to
make laws is vested under Sub-clause (a), to make laws conferring powers and
imposing duties, or authorising the conferring of powers and the imposition of
duties, upon the Union or officers and authorities thereof;
(C) x x x x x (2) Any law made in exercise of the power of the Legislature of the State
by Parliament or the President or other authority referred to in Sub-clause (a) of
Clause (1) which Parliament or the President or such other authority would not, but
for the issue of a proclamation under Article 356, have been competent to make shall,
after the Proclamation has ceased to operate, continue in force until altered or
repealed or amended by a competent Legislature or other authority.
It will appear that whereas an ordinance issued under Article 123 has the same force and effect as an
Act of Parliament, under Article 357(1)(a) Parliament can confer on the President the power of the
legislature of the State to make laws. Thus, where the President is required to make laws, the
Constitution has provided for it. The difference in the nature of the power exercised by the President
under Article 123 and under Article 357 is clear and cannot be ignored. Under Article 21 no person
can be deprived of life and liberty except according to procedure established by law. Patanjali Sastri
J., in A.K. Gopalan v. State [1950] SCR 88 observed that the word "established" in Article 21
"implies some degree of firmness, permanence and general acceptance". An ordinance which has to
be laid before both Houses of Parliament and ceases to operate at the expiration of six weeks from
the reassembly of Parliament, or, if before the expiration of that period resolutions disapproving it
are passed by both Houses can hardly be said to have that 'firmness' and 'permanence' that the word
'established' implies. It is not the temporary duration of an ordinance that is relevant in the present
context, an Act of Parliament may also be temporary; what is relevant is its provisional and tentative
character which is apparent from Clause 2(a) of Article 123. On this aspect also the differenceA.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

between a law made by the President under Article 357 and an ordinance promulgated by him under
Article 123 should be noted. A law made under Article 357 continues in force until altered, repealed
or amended by a competent legislature or authority; an ordinance promulgated under Article 123
ceases to operate at the expiration of six weeks from the reassembly of Parliament at the latest. On
behalf of the Union of India learned Attorney General referred to Article 367(2) to argue that the
Constitution itself equates an ordinance with an Act of Parliament. Article 367(2) reads:
Any reference in this Constitution to Acts or laws of, or made by, Parliament, or to
Acts or laws of, or made by, the Legislature of a State, shall be construed as including
a reference to an Ordinance made by the President or, to an Ordinance made by a
Governor, as the case may be.
Any reference in the Constitution to Acts of Parliament has to be construed as
including a reference to an ordinance made by the President as Article 367(2)
provides because an ordinance has been given the force and effect of an Act, But
clearly an ordinance has this force and effect only over an area where it can validly
operate. An invalid ordinance can have no force or effect and if it is not 'law' in the
sense the word has been used in Article 21, Article 367(2) cannot make it so.
121. There is also another aspect of the matter. Article 21 not only speaks of a situation in normal
times which left no time for the to think of a situation in normal times which left no time for the
President to summon Parliament and required him to promulgate ordinances to take away the life
or liberty of persons, unless one considered life and liberty as matters of no great importance.
However, in view of the opinion of the majority upholding the validity of the Ordinance, it is
unnecessary to dilate on this aspect.
122. On all the other points I agree with conclusions reached by the learned Chief Justice.
Tulzapurkar, J.
123. On the question of bringing into force, Section 3 read with Section 1(2) of the Constitution
(Forty-Fourth Amendment) Act, 1978 I am in agreement with the view expressed by my learned
brother A.C. Gupta in his judgment. Barring this aspect, I am in agreement with the rest of the
judgment delivered by my Lord the Chief Justice.A.K. Roy Ors. vs Union Of India (Uoi) And Ors. on 28 December, 1981

