Chhattisgarh Minor Mineral Rules, 2015
CHHATTISGARH
India
Chhattisgarh Minor Mineral Rules, 2015
Rule CHHATTISGARH-MINOR-MINERAL-RULES-2015 of 2015
Published on 27 March 2015• 
Commenced on 27 March 2015• 
[This is the version of this document from 27 March 2015.]• 
[Note: The original publication document is not available and this content could not be
verified.]• 
Chhattisgarh Minor Mineral Rules, 2015Published vide Notification No. F 6-42/2012/12, dated 27th
March, 2015Last Updated 18th October, 2019Notification No. F 6-42/2012/12 dated the 27th
March, 2015. - In exercise of the powers conferred by Section 15 of the Mines and Minerals
(Development and Regulation) Act, 1957 (No. 67 of 1957), the State Government, hereby, makes the
following rules, namely :-
Chapter I
Preliminary
1. Short title, extent and commencement.
(1)These rules may be called the Chhattisgarh Minor Mineral Rules, 2015.(2)These rules shall apply
to the grant and regulation of Quarry Leases and other mineral concessions in respect of Minor
Minerals and for purposes connected therewith in the State of Chhattisgarh only.(3)These rules shall
come into force from the date of its publication in the Official Gazette.
2. Definitions.
(1)In these rules, unless the context otherwise requires,-(a)"Act" means the Mines and Minerals
(Development and Regulation) Act, 1957 (No. 67 of 1957);(b)"Additional Director", "Joint Director",
"Deputy Director" and "Assistant Geologist", means the respective officers of Directorate of Geology
and Mining, Government of Chhattisgarh;(c)"Agreement" means an agreement to quarry and carry
away one or more minor minerals specified therein;(d)"Air Pollution" shall have the meaning as
assigned to it under clause (b) of Section 2 of the Air (Prevention and Control of Pollution) Act, 1981
(No. 14 of 1981);(e)"Appellate Authority" means the Government or any other authority vested with
such powers under these rules;(f)"Assessee" means a person holding a Mining Lease, Quarry Lease
or Quarry Permit and includes any other person who holds a mine of minor minerals granted underChhattisgarh Minor Mineral Rules, 2015

these rules, save as exempted under rules;(g)"Assessing Authority" means Deputy Director (Mineral
Administration), Mining Officer, Assistant Mining Officer and Mining Inspectors posted in the
district;(h)"Assessment" means the assessment levied under these rules with reference to the extent
of minor minerals extracted;(i)"Assessment Year" means the yearly period beginning from the date
of commencement of the lease and ending on 31st December for the first year of the lease and
thereafter from 1st January to 31st December or part thereof;(j)"Association" means a body of
persons associated for objects and promotion of the economic interest of its members and is so
registered under the Chhattisgarh Co-operative Societies Act, 1960 (No. 17 of 1961);(k)"Below
Poverty Line" means the family declared as Below Poverty Line by the State Government, from tune
to time;(l)"Collector" shall have the same meaning as assigned to him under the Chhattisgarh Land
Revenue Code, 1959 (No. 20 of 1959);(m)"Commissioner" of a revenue division shall have the same
meaning as assigned to him in the Chhattisgarh Land Revenue Code, 1959 (No. 20 of
1959);(n)"Competent Authority" means a Competent Authority appointed by the State Government
to carry out the provisions of these rules;(o)"Co-operative Society" has the same meaning as
assigned to it under the Chhattisgarh Co-operative Societies Act, 1960 (No. 17 of
1961);(p)"Corporation" shall have the same meaning as assigned to it under the Chhattisgarh
Municipal Corporation Act, 1956 (No. 23 of 1956);(q)"Dead Rent" and "Royalty" shall have the same
meaning as respectively assigned to them under the Act;(r)"Director" means the
Director/Commissioner, Geology and Mining, Government of Chhattisgarh;(s)"Educated
Unemployed" means a person,-(i)who holds at least High School Certificate Examination i.e. 10th
pass in (10+2) system of the Chhattisgarh Board of Secondary Education;(ii)who is a resident of the
State of Chhattisgarh;(iii)who is above 18 years but below 35 years of age;(iv)who belongs to Below
Poverty Line family; and(v)who has not availed any facility under any other scheme for Educated
Unemployed at any time;(t)"Environment" shall have the same meaning as assigned to it under
clause (a) of Section 2 of the Environment (Protection) Act, 1986 (29 of 1986);(u)"Financial
Assurance" means the sureties furnished by the Mining Lease holder, Quarry Lease holder or Quarry
Permit holder to the Competent Authority, so as to indemnify the authorities against the
reclamation and rehabilitation cost;(v)"Form" means a form appended to these Rules;(w)"Gram
Panchayat", "Janpad Panchayat", "Zila Panchyat" and "Gram Sabha" shall have the same meaning
assigned to them respectively in the Chhattisgarh Panchayat Raj Adhiniyam, 1993 (No. 1 of
1994);(x)"Lessee" means a person who has been granted a Prospecting Licence, Mining Lease,
Quarry Lease or Quarry Permit under these rules and includes any contractor, sub-lessee and agent,
whether appointed or not, who is acting or purporting to act on behalf of the lessee and is taking
part in the management, supervision, extraction and dispatch of mineral;(y)"Mine" and "Owner"
shall have the same meaning assigned to them respectively in the Mines Act, 1952 (35 of
1952);(z)"Mineral Concession" includes Prospecting Licence, Mining Lease, Quarry Lease and
Quarry Permit;(aa)"Mining Officer", "Assistant Mining Officer" and "Mining Inspector" means the
respective officers of the Directorate of Geology and Mining, Government of
Chhattisgarh;(ab)"Mining Operation" and "Quarrying Operation" means any operation undertaken
for the purpose of winning any minor mineral and shall include erection of machinery, construction
of roads in connection with the mine;(ac)"Minor Minerals" means the minerals as specified in
Schedule-I and Schedule-II appended to these Rules and any other mineral which the Government
of India may, by notification in the Official Gazette, declare to be a minor mineral under clause (e) of
Section 3 of the Act;(ad)"Municipality" shall have the same meaning as assigned to it under clauseChhattisgarh Minor Mineral Rules, 2015

(18) of Section 3 of the Chhattisgarh Municipalities Act, 1961 (No. 37 of 1961);(ae)"Other Backward
Classes" means the Other Backward Classes of citizens as specified by the Government vide
Notification No. F-8-5-XXV-4-84, dated 26th December, 1984, as amended from time to
time;(af)"Prospecting Licence" means a licence granted for the purpose of undertaking Prospecting
Operation of minor minerals;(ag)"Prospecting Operation" means any operation undertaken for the
purpose of prospecting, locating or proving minor mineral deposits;(ah)"Public Place" means roads,
public buildings, reservoirs, irrigation canals, tanks, natural water courses, village paths, religious
places, burial ground, etc.;(ai)"Quarry Closure Plan" means a plan for the purpose of
decommissioning, reclamation and rehabilitation in the quarry or part thereof, after cessation of
mining and mineral processing operations that has been prepared in the manner specified in the
standard format and guidelines issued by the State Government;(aj)"Quarry Lease" means a lease
granted for mining and removal of minor minerals as mentioned in Section 15 of the
Act;(ak)"Quarry Permit" means the permission granted under these rules to extract and remove any
specific quantity of minor mineral within a specified period;(al)"Quarry Plan" means a plan
prepared under these rules for mining of minor mineral/minerals;(am)"Railway" and "Railway
Administration" shall have the same meaning as respectively assigned to them under the Indian
Railways Act, 1989 (No. 24 of 1989);(an)"Recognised Qualified Person" means a person having the
prescribed educational qualification or/and experience as notified by the State Government, under
these Rules, from time to time;(ao)"Schedule" means a schedule appended to these
Rules;(ap)"Scheduled Castes" means the Scheduled Castes as specified in relation to this State
under Article 341 of the Constitution of India;(aq)"Scheduled Tribes" means the Scheduled Tribes as
specified in relation to this State under Article 342 of the Constitution of India;(ar)"Special Area"
shall have the same meaning as assigned to it in the Chhattisgarh Nagar Tatha Gram Nivesh
Adhiniyam, 1973 (No. 23 of 1973);(as)"State Government" means the Government of
Chhattisgarh;(at)"Water Pollution" shall have the same meaning as assigned to it under the Water
(Prevention and Control of Pollution) Act, 1974 (No. 6 of 1974).(2)All other words and expressions
used in these rules but not defined in these rules but defined in the Mines and Minerals
(Development and Regulation) Act, 1957 (No. 67 of 1957) shall have the same meaning as
respectively assigned to them in the said Act.
3. Exemptions.
- Notwithstanding anything contained in these rules,-(i)Extraction of ordinary clay or ordinary sand
by hereditary Kumhars, being domicile of Chhattisgarh or their co-operative societies for preparing
pots, tiles and bricks by traditional means, but not by process of manufacture in chimney-kilns or by
any mechanical means, from the area of village of their common residence that may be decided and
earmarked by the Gram Panchayats within their respective panchayat area for extraction of ordinary
clay and ordinary sand :Provided that no extraction shall be made from any pubic place and within
50 meters in all directions from such public place;(ii)The removal of minor minerals from quarries
shall be exempted, whether situated in private or Government land, when such quarries have not
been appropriated to the use of a department of the State Government and the minor minerals are
not mined for sale but are required for the construction or repairs of wells, other agricultural works
or for the construction or improvement of the dwelling houses of agriculturists, village artisans and
labourers residing in revenue or forest villages;(iii)The minor minerals removed from GovernmentChhattisgarh Minor Mineral Rules, 2015

lands for public works by Gram Panchayats, Janpad Panchayats and Zila Panchayats for work
undertaken by respective Panchayats shall be exempted;(iv)The search for minor minerals at the
surface, not involving any substantial removal of the soil by digging up pits, trenches or otherwise,
shall be exempted;(v)The chipping of outcrops with a geological hammer, for the purposes of taking
samples, shall not be deemed to be a substantial removal of the soil:Provided that the aforesaid
exemptions do not afford immunity from any action which might be taken under any existing rules
or any act of the State or the Central Government, for unauthorized removal of minor minerals from
any land by private person without the permission of the State Government or any officer or
Authority authorized by it in this behalf;(vi)Excavation and regulation of the Minor Minerals
specified in Part B of Schedule-II shall be governed by the Chhattisgarh Minor Mineral Sand
Excavation and Trade Regulation Order, 2006.
Chapter II
General Restrictions on Undertaking Prospecting or Mining or
Quarrying Operations
4. Prohibition of prospecting or quarrying operation without a prospecting
license or quarry lease or quarry permit.
(1)No person shall undertake any Prospecting or Quarrying Operation in any area except under and
in accordance with the terms and conditions of Prospecting Licence or a Quarry Lease or Quarry
Permit granted under these rules :Provided that nothing in this sub-rule (1) shall affect any
Prospecting or Quarrying Operation undertaken in any area in accordance with the terms and
conditions of Prospecting Licence or Quarry Lease or Quarry Permit granted before the
commencement of these rules, in force at that time :Provided further that these rules shall be made
applicable to the existing Quarry Lease and Quarry Permit from the date of its renewal.(2)No
Prospecting Licence or Quarry Lease or Quarry Permit shall be granted other than in accordance
with the provisions of these rules.(3)Any Prospecting Licence or Quarry Lease or Quarry Permit
granted, renewed or permission for removal of ordinary sand and bajri, in contravention of the
provision of these rules or orders made thereunder, shall be void and be of no effect.
5. Restrictions on the grant of prospecting licence or quarry Lease or quarry
permit.
(1)No Prospecting Licence or Quarry Lease or Quarry Permit shall be granted to any person unless
such person is an Indian national or a company as defined under sub-section (20) of Section 2 of the
Companies Act, 2013 (No. 18 of 2013) and satisfies such conditions as prescribed in these
Rules.Explanation. - For the purposes of this sub-rule, in case of a firm or any other association of
individuals, it shall be deemed to be an Indian entity only if all the members of the firm or
association are citizens of India.(2)No Prospecting Licence or Quarry Lease or Quarry Permit shall
be granted in respect of an area :-(a)notified by the Government as reserved for the use of the
Government and Local Authorities or for any other public or for special purposes except with theChhattisgarh Minor Mineral Rules, 2015

previous approval of the State Government;(b)in forest land without the permission of appropriate
authority as prescribed in the Forest (Conservation) Act, 1980 (No. 69 of 1980);(c)within a distance
of 100 meters in all directions from any bridge, National or Stale Highways, Railway line and within
50 meters in all directions from the road constructed under Pradhan Mantri Gram Sadak Yojana,
Mukhya Mantri Gram Sadak Yojana, other District Roads of Public Works Department and within
10 meters in all directions from Grameen Kachcha Rasta or within fifty meters in all directions from
any public place except village path :Provided that the amended provisions shall be made applicable
from the date of renewal of the existing Quarry Leases and Quarry permits;(d)which is not compact
and contiguous.
6. No quarry lease shall be granted without the satisfaction of the competent
authority.
- No quarry lease for minor minerals shall be granted by the State Government or any other State
Authority, notified by the State Government, unless it is satisfied that,-(a)There is evidence to show
that the area for which the lease is applied for has been prospected earlier or the existence of
mineral contents therein has been established otherwise than by means of Prospecting Operation in
such area:Provided that no quarry lease for the minerals specified in Part A of Schedule-I shall be
granted by the Competent Authority unless the area for which the lease is applied for has been
prospected earlier:Provided further that no quarry lease exceeding an area of five hectares or depth
of six meters, for the minerals specified in Part B and Part C of Schedule-I and Part A of Schedule-II
shall be granted by the Competent Authority unless the area for which the lease is applied for has
been prospected earlier;(b)Prospecting is not compulsory for the quarry lease in which proposed
quarry operation shall be confined to the depth of six meters over an area not exceeding five
hectares, for the minerals specified in Part B and Part C of Schedule-I and Part A of Schedule-II,
however quarry lease shall be granted by the Competent Authority only after ascertaining the
availability of mineral applied for thorough spot inspection carried out by Deputy Director/Mining
Officer of the concerned District or Deputy Director or Assistant Geologist of concerned Regional
Office or any officer authorised by the Director :Provided that a non-refundable spot inspection fee
of rupees five thousand shall be deposited in Government Treasury under the revenue head as
prescribed in sub-rule (3) of rule 31;(c)There is a quarry plan duly approved by the Competent
Officer as notified by the Director in this behalf.Chapter-III Grant of Prospecting Licence
7. Application for grant of prospecting licence.
(1)The officer-in-charge of mining section of the concerned district shall receive the application for
the grant of Prospecting Licence in Form-1 and shall enter on it the date and time on which the
application was received by him :Provided that before the disposal of pending applications for
sanction of prospecting license of any mineral, if such mineral is declared as minor mineral by
notification of the Government of India under clause (e) of Section 3 of the Act, then for areas
relating to such applications pending before the date of issue of notification of the Government of
India, only on submission of amended application as per these rules within a period of sixty days of
such notification by the applicant Prospecting Licence shall be considered for sanction in
accordance with these rules.(2)Every such application shall be accompanied by,-(a)AChhattisgarh Minor Mineral Rules, 2015

non-refundable application fee of Rupees Five Thousand. Fee shall be deposited in the Government
Treasury under the following revenue receipt head-
0853. Non ferrous Mining and Metallurgical Industry
{102} Mineral concession fees, rent and royalties.(0278)Receipt from minor mineralsand the
original treasury receipt challan shall be attached to the application;(b)No dues certificate as
prescribed in Form-II of payment of mining dues, such as royalty or Dead Rent and surface rent
payable under the Act or the rules made thereunder, from the Government or any officer or
authority authorized by that Government in this behalf:Provided that in case the applicant is a
partnership firm or a private limited company, such certificates shall be furnished by all partners of
the partnership firm or, as the case may be, all members of the private limited company :Provided
further that where any injunction has been issued by court of law or any other Competent Authority
staying the recovery of any such mining dues or income tax, non-payment thereof shall not be
treated as a disqualification for the purpose of granting the said Prospecting Licence :Provided also
that where a person has furnished an affidavit, to the satisfaction of the Competent Authority for the
grant of Licence, stating that he does not hold or has held any Mineral Concession in the State, it
shall not be necessary for him to produce the said no dues certificate :Provided also that a duly
sworn affidavit stating that no dues are outstanding shall suffice subject to the condition that the
certificate required as above shall become invalid if the party fails to file the certificate within thirty
days from the date of application :Provided also that grant of above clearance certificate shall not
discharge the holder of such certificate, from the liability of paying dues which may subsequently be
found to be payable by him under the Act or the rules made there: under.(c)An affidavit stating that
the applicant has,-(i)filed up-to-date income tax returns;(ii)paid (he income lax assessed on him;
and(iii)paid the income tax on the basis of self-assessment as provided in the Income Tax Act,
1961.(d)An affidavit showing particulars of areas mineral-wise in the State, that the applicant or any
person jointly with him,-(i)already holds under Prospecting Licence;(ii)has applied for but not
granted; and(iii)being applied for, simultaneously.(e)A statement in writing that the applicant,
where the land is not owned by him, has obtained surface rights over the area or has obtained the
consent of the owner for starting Prospecting Operations :Provided that no such statement shall be
necessary where the land is owned by the Government:Provided further that the consent of the
owner for starting Prospecting Operations in the area or part thereof, may be furnished after
execution of the Prospecting Licence but before entry into the said area.
8. Receipt of application.
- Every application under sub-rule (1) of rule 7 shall be acknowledged in Form-III on the date of its
receipt.
9. Disposal of application for grant of prospecting licence.
(1)On receipt of an application, for the grant of a Prospecting Licence, its details shall be first
circulated for display on the notice board of the concerned Zila Panchayat, Janpad Panchayat and
Gram Panchayat of the district and Collectorate of the district concerned.(2)The SanctioningChhattisgarh Minor Mineral Rules, 2015

Authority, after making such enquiries as he may deems fit, may grant a Prospecting Licence or
refuse to grant it, within a period of one year from the date of receipt of the application, otherwise
the application shall be deemed to have been refused:Provided that no Prospecting Licence for new
area shall be granted without obtaining opinion of the respective Gram Panchayat. In case of
Scheduled Areas, opinion of the respective Gram Sabha shall be obtained.(3)Where it appears that
the application for Prospecting Licence is not complete in all material particulars or is not
accompanied by the required documents, the officer-in-charge of mining section of the concerned
district shall, by notice, require the applicant to supply the omission or, as the case may be, furnish
the documents without delay and in any case not later than thirty days from the date of receipt of
the said notice by the applicant, failing which the application shall be rejected by the Competent
Authority.(4)The Competent Authority may, after giving an opportunity of being heard and for
reasons to be recorded in writing and after communicating to the applicant, refuse to grant a
Prospecting Licence, over the whole or part of the area applied for.(5)Where an applicant for grant
of a Prospecting Licence dies before the sanction order is passed, it shall be deemed to have been
filed by his legal heir and if the applicant dies after the sanction order of grant but before execution
of Prospecting Licence deed, it shall be deemed to have been granted to the legal heir of the
applicant.
10. Preferential rights for grant of prospecting licence for minerals specified
in Schedule-1 and Part-A of Schedule-II.
(1)(a)Co-operative Society/Association of Scheduled Tribes/Scheduled Castes/Other Backward
Classes and Co-operative Society/Association of educated unemployed youths or individuals, where
more than fifty percent of the members belong to the concerned category, where the Chairman of
the Society is of the concerned category and also where the executive committee have representation
in the ratio of the members of the concerned category and belongs from Below Poverty Line families
listed in the District Rural Development Agency or Educated Unemployed youth belonging to
Scheduled Tribes/Schedule Castes/Other Backward Classes in that order;(b)An Educated
Unemployed youth belonging to Below Poverty Line families listed in the District Rural
Development Agency;(c)Any other person belonging to Below Poverty Line families listed in the
District Rural Development Agency;(d)Any other applicant:Provided that exclusive Co-operative
Society/Self Help Group of Women or an individual woman shall have the preferential right over
other applicants, in the same order, as provided in clause (a), (b), (c) and (d):Provided further that
the above priorities shall hold good only if the applications are received within 30 days from the date
of first application.(2)Whenever more than one application in any particular category is received for
minerals mentioned under Schedule-I and Part-A of Schedule-II, for an area, the Sanctioning
Authority, while sanctioning a Prospecting Licence shall take into consideration the following
matters in respect of the applicants, namely :-(a)any special knowledge of or experience in
Prospecting operations. Mining operations and Quarrying operations;(b)the nature and quality of
the technical staff employed by the applicant;(c)the financial resources of the applicant;(d)the
Licensee shall give priority in employment to the residents of the village in which the Prospecting
Licence is granted.(3)Where applications for the grant of Prospecting Licence and Quarry Lease in
respect of the same area are received on the same date or on different dates within a period of thirty
days, the applications for the grant of Quarry Lease shall, if the area was previously held and workedChhattisgarh Minor Mineral Rules, 2015

under a Quarry Lease or Prospecting Licence and deposit of mineral has been proved so as to
prepare Quarry Plan, be given priority over the application for the grant of Prospecting
Licence.(4)Where a Prospecting Licence has been granted in respect of any land, the Licensee shall
have a preferential right for obtaining a Quarry Lease in respect of that land over any other person if
he applies for a lease within ninety days after the expiry of the Prospecting Licence.
11. Period for which prospecting licence may be granted.
(1)For minerals dimensional Stone and Marble specified under Part-A of Schedule-I, the provisions
of the Granite Conservation and Development Rules, 1999 and the Marble Development and
Conservation Rules, 2002 respectively, shall apply.(2)For minerals specified under Part-B of
Schedule-I, Prospecting Licence shall be granted for a period of two years from the date of its
execution.(3)For minerals specified under Part-C of Schedule-1 and Part-A of Schedule-II,
Prospecting Licence shall be granted for a period of one year from the date of its execution.
12. Area restriction on grant of prospecting licence.
(1)For minerals specified under Part-A of Schedule-I, the provisions of the Granite Conservation and
Development Rules, 1999 and the Marble Development and Conservation Rules, 2002 respectively,
shall apply.(2)No person shall acquire one or more Prospecting licences, in respect of any mineral
specified under Part-B and Part-C of Schedule-1 and Part-A of Schedule-II, covering a total area,
more than fifty hectares :Provided that if the State Government is of opinion that in the interest of
the development of any mineral it is necessary so to do, it may, for reasons to be recorded by it, in
writing permit any person to acquire one or more prospecting Licence covering an area in excess of
the aforesaid total area.Explanation. - For the purposes of this clause a 'person' includes an
individual, a Hindu undivided family, a company, a firm, an association of persons or a body of
individuals, whether incorporated or not, a local authority, and every artificial juridical person.
13. Security Deposit.
- The Licensee shall, before the deed referred to in rule 14 is executed, deposit as security a sum of
rupees ten thousand for first five hectares, or part thereof and thereafter rupees two thousand for
every additional hectare, or part thereof, in the form of National Saving Certificate or a Fixed
Deposit Receipt of a Nationalised Bank/Scheduled Bank duly pledged in favour of the Collector of
the concerned District.
14. Prospecting licence to be executed within sixty days.
(1)Where on any application, an order has been made for the grant of Prospecting Licence, a licence
deed in accordance with Form-IV shall be executed within sixty days from the date of the order. If
no such deed is executed within the said period, due to any default on the part of the applicant, the
Competent Authority may revoke the order granting the licence and in that event fee paid shall be
forfeited in favour of the Government.(2)Where the Licencee is unable to execute the licence deedChhattisgarh Minor Mineral Rules, 2015

within sixty days from the date of the order, he may submit an application to the Director explaining
the reason for the same before the expiration of the said period. The application submitted after the
expiration of said period shall not be considered.(3)Every application under sub-rule (2) shall be
accompanied by non-refundable application fee of rupees five hundred.(4)The Director may, on
receipt of an application made under sub-rule (2) and on being satisfied about the adequacy and
genuineness of the reason for non-execution of deed, pass an order for extension of the period of
execution of deed.
15. Register of prospecting licence to be maintained.
(1)A register of application for grant of Prospecting Licence shall be maintained by the
officer-in-charge of mining section of the concerned district in the format under Form-V.(2)A
register for Prospecting Licence granted shall be maintained by the officer-in-charge of mining
section of the concerned district in Form-VI.
16. Conditions of prospecting licence.
- Every Prospecting Licence granted under these rules, in addition to other conditions that may be
specified therein, shall be subject to the following conditions, namely :-(i)Every holder of a
Prospecting Licence shall submit to the concerned Collector and Director or any officer authorised
by him, a scheme indicating the manner in which he proposes to carry out the Prospecting
Operations, within a period of thirty days from the date of execution of deed of Prospecting
Licence;(ii)Every holder of a Prospecting Licence shall submit to the concerned Collector and
Director or any officer authorised by him, an intimation in Form-VII of the commencement of
Prospecting Operation, so as to reach them within a period of fifteen days of such
commencement;(iii)Every Licensee shall maintain an account of all the expenses incurred by him on
Prospecting Operations and also the quantity and other particulars of all minerals obtained during
such operations and their despatch.(iv)The Licensee may, on payment of royalty and after obtaining
the transit pass for transportation of mineral, collect and carry away maximum up to five cubic
meter mineral for the purpose of testing during the period of licence.(v)The Licensee shall report to
the concerned Collector and Director or any officer authorised by him. the discovery of any mineral
not specified in the licence, within a period of thirty days from the date of such discovery and shall
make an application for inclusion of such mineral in his Prospecting Licence simultaneously. The
Licencee shall not despatch the newly discovered mineral from the Licence area till such is included
in his Prospecting Licence :Provided that in case of discovery of any mineral not specified as a Minor
Mineral, the Licencee shall not have any right of concession for that mineral under these
rules.(vi)The Licensee shall not pay less than the minimum wages proscribed by the Central or the
State Government under the Minimum Wages Act, 1948;(vii)The Licensee of granite or marble shall
observe provisions of the Granite Conservation and Development Rules, 1999 and the Marble
Development and Conservation Rules, 2002 respectively;(viii)(a)The Licensee shall submit a final
report under Form-VIII to the concerned Collector and Director or any officer authorised by him,
within a period of ninety days from the expiry of the Prospecting Licence; and(b)Any deposit made
under rule 13, if not forfeited under these rules, shall be refunded to the Licensee on submission of
application along with Prospecting Report as referred to in clause (a) above.(ix)The Licensee shallChhattisgarh Minor Mineral Rules, 2015

provide compensation for damage to land, to the extent of damage, in respect of which the licence
has been granted;(x)The Licensee shall indemnify to the Government against the claim of a third
party for any damage, injury or disturbance caused to him by the Licensee;(xi)Restrictions shall be
placed regarding felling of trees on unoccupied and unreserved Government land and other
environmental conditions, as may be notified by the State Government, from time to
time;(xii)Restriction on Prospecting Operations in any area prohibited by any Competent Authority
due to Environmental or any other reasons, as may be notified, from time to time;(xiii)Conditions
regarding entry on occupied land;(xiv)Facilities shall be provided by the Licensee for working other
minerals in the licensed area or in adjacent areas.
17. Duties of the Licensee.
- During subsistence of the licence, the Licensee shall,-(i)Take immediate measures for the
plantation and maintenance of not less than twice the number of trees fallen as a result of
Prospecting Operations in the sanctioned area or area nearby as approved by the Officer-in-charge
of mining section of the concerned district;(ii)Restore other flora destroyed by Prospecting
Operations to the maximum extent possible;(iii)Securely plug all bores and fill up or fence all
excavations in the land covered by the licence;(iv)Pay to the occupier of surface of the land, such
compensation as may be decided by the Collector;(v)Furnish to the concerned Collector and
Director or any officer authorised by him, such information and returns as may be prescribed in the
Rules;(vi)Allow any officer, authorised by the Central Government or Collector or Director or any
officer authorised by him, to inspect any Prospecting Operation carried out by him;(vii)Carry out
Prospecting Operations in such a manner so as to ensure the systematic development and
conservation of mineral deposits and protection of environment.
18. Cancellation of licence.
- In the case of non-compliance of these rules or breach of any condition imposed on any holder of a
Prospecting Licence, the Sanctioning Authority may, by order in writing, cancel the licence and/or
forfeit full or part of the security deposited by the Licensee under rule 13 :Provided that no such
order shall be made without giving the Licensee a fifteen day notice in writing and an opportunity of
being heard.
19. Availability of certain areas.
- No application for Prospecting Licence of minerals in Schedule-I and Part-A of Schedule-II shall lie
for areas previously held or which are being held under a Quarry Lease or the area reserved for
exploration/ prospecting by Directorate of Geology, and Mining or Geological Survey of India or any
other government organisation, unless the availability of the area for grant is notified in the Official
Gazette atleast thirty days in advance :Provided that the State Government by recording reasons in
writing may relax the provisions of this Rule for any special case.Chhattisgarh Minor Mineral Rules, 2015

Chapter IV
Power to grant Prospecting Licence, Quarry Leases, and Quarry
Permits
20. Grant of prospecting licence.
- Prospecting Licence in respect of minerals specified in Schedule-I and Part-A of Schedule-II, shall
be granted by the authority mentioned in column (2) for the minerals specified in column (3),
subject to the extent as specified in the corresponding entry in column (4) thereof, of the table
below,-Table
S.
No.Authority Minerals Extent of Power
(1) (2) (3) (4)
1.The State
GovernmentMinerals specified in Part-A and Part-B
ofSchedule-I.Full powers.
2. DirectorMinerals specified in Part-C of
Schedule-I andPart-A of Schedule-II.Where the area applied for is
more than tenhectares.
3. CollectorMinerals specified in Part-C of
Schedule-1 andPart-A of Schedule-II.Where the area applied for is up
to tenhectares.
21. Grant of quarry lease.
- Quarry Lease in respect of minerals specified in Schedule-I and Part-A of Schedule-II, shall be
granted and renewed by the authority mentioned in column (2) for the minerals specified in column
(3), subject to the extent as specified in the corresponding entry in column (4) thereof, of the table
below,-Table
S.
No.Authority Minerals Extent of Power
(1) (2) (3) (4)
1.The State
GovernmentMinerals specified in Part-A and Part-B
ofSchedule-I.Full powers.
2. DirectorMinerals specified in Part-C of
Schedule-I andPart-A of Schedule-II.Where the area applied for is
more than tenhectares.
3. CollectorMinerals specified in Part-C of
Schedule-I andPart-A of Schedule-II.Where the area applied for is up
to tenhectares.
22. Pending applications in relation to new minor minerals declared by the
Government of India.Chhattisgarh Minor Mineral Rules, 2015

- In relation to any mineral from minor minerals declared by notification dated 10th February, 2015
of Government of India, only on submission of amended application within sixty days from the date
of enforcement of these rules shall be considered in accordance with these rules, in matters of
pending applications of Mining Lease or Prospecting License submitted under sub-section (2) of
Section 10A of the Act.
Chapter V
Grant of quarry lease in respect of minerals specified in
Schedule-I and Part-A of Schedule-II
23. Application for Quarry Lease.
- An application for the grant or renewal of a Quarry Lease shall be made in Form-IX in triplicate,
for the minerals specified in Schedule-I and in Part-A of Schedule-II. The application shall be affixed
with a court fee stamp of the value of rupees five and shall contain the following particulars together
with documents in support of the statement made therein, namely :-(i)If the applicant is an
individual, his name, nationality, profession, caste, educational qualification, age, residence, present
address and financial status;(ii)If the applicant is a company, its name, nature and place of business,
place of registration or incorporation, list of directors, their nationality, financial status and
registration/incorporation certificate;(iii)If the applicant is a firm, its name, nature and place of
business, place of residence of partners, their nationality, partnership deed, registration certificate
and financial status;(iv)If the applicant is a society/association, its name, nature, place of working,
list of members, their caste, educational qualification, nationality, registration certificate, bye-laws
and financial status of individual members;(v)A description illustrated by a map or plan showing, as
accurately as possible, the situation and boundaries of the land in respect of which the Quarry Lease
is required. Where the area is unsurveyed, the location of the area should be shown by some
permanent physical feature, roads, tank, etc.;(vi)Copy of latest khasra panchsala;(vii)The minerals
or mineral which the applicant intends to mine;(viii)The period for which the Quarry Lease is
required;(ix)The purpose for which the extracted mineral is to be used;(x)Every application for the
grant or renewal of a Quarry Lease shall be accompanied by an affidavit showing particulars of the
areas mineral-wise in each district of the State, which the applicant or persons jointly with
him-(a)already hold under Quarry Lease;(b)has already applied for, but not granted; and(c)being
applied for simultaneously;(xi)An affidavit to the effect that the applicant has, where the land is not
owned by him, obtained surface rights over the area or has obtained the consent of the
owner/owners for conducting mining operations :Provided that no such affidavit shall be necessary
where the land rights are vested in the State Government;(xii)Every application for the grant or
renewal of a Quarry Lease shall be accompanied by No Dues Certificate in Form-II, in respect of
payment of mining dues payable under the Act or rules made thereunder from all the districts where
the applicant holds or held Mineral Concessions, granted by the Mining Officer or Assistant Mining
Officer or Officer-In-Charge of the mining section of the district:Provided that it shall not be
necessary for the applicant to produce the No Dues Certificate, if he has furnished an affidavit and
such other evidence as may be required to the satisfaction of the concerned authority that he does
not hold and has never held any Mineral Concession in any district of the State :Provided furtherChhattisgarh Minor Mineral Rules, 2015

that the grant of No Dues Certificate shall not discharge a holder of such certificate from the liability
to pay the mining dues which may be subsequently found to be payable by him under the Act or
Rules made thereunder.(xiii)Every application for the grant of Quarry Lease shall be accompanied
by a Prospecting report or the report indicating existence of mineral contents as per rule
6.(xiv)Every application for the grant or renewal of quarry lease confined to the depth of 6 meters
over an area not exceeding five hectares, for the minerals specified in Part-B and Part-C of
Schedule-I and Part A of Schedule-II, shall be accompanied by a Challan of rupees five thousand for
spot inspection fee; and(xv)Before the disposal of pending applications for sanction of mining lease
of any mineral, if such mineral is declared as minor mineral by notification of the Central
Government under clause (e) of Section 3 of the Act, then for areas relating to such applications
pending before the date of issue of notification of the Government of India, only on submission of
amended application as per these rules within a period of sixty days such notification by the
applicant mining lease shall be considered for sanction in accordance with these rules :Provided that
renewal of mining lease, sanctioned before enforcement of these rules, shall be done under these
rules.
24. Quarrying operation for minor minerals to be in accordance with quarry
plan.
(1)Quarrying operation shall be undertaken in accordance with the duly approved Quarry
Plan.(2)The Quarry Plan once approved, shall be valid for the entire duration of the
lease.(3)Modification of the approved Quarry Plan during the operation of a Quarry Lease also
requires prior approval.(4)Where quarrying operations have been undertaken before the
commencement of these rules without an approved quarrying plan, the holder of such Quarry Lease
shall submit a quarry plan, within a period of one year from the date of commencement of these
rules to the authorised officer in this behalf by the State Government for approval.(5)The Quarry
Plan shall incorporate,-(i)Name of the Applicant(ii)Address :-CityDistrictPin CodePhone
NumberE-mail(iii)Status of Applicant(iv)Name of the Recognised Qualified Person preparing the
Quarry PlanAddress:-CityDistrictPin CodePhone NumberE-mail(v)Registration No. of Recognised
Qualified Person or authorization of the State Government,Date of Grant and RenewalValid up
to(vi)Name and details of the Prospecting Agency(vii)Address :-CityDistrictPin CodePhone
NumberE-mail(viii)Whether area is prospected by the Directorate of Geology and Mining, if yes
then enclose a certified copy of prospecting report.(ix)Location and AccessibilityDetail of the Area
(with location map)District, Tehsil, Patwari Halka Number, Village Khasra Number/Compartment
No.Lease Area (Hectares)Ownershipexistence of public road/railway line, if am nearby and
approximate distanceTopo-sheet No. with latitude and longitude in case where the area is five
hectares or more.For area under reserve forest/protected forest, the area should be marked on
forest map.(x)The area showing the nature and extent of the mineral body.(xi)Spot or spots where
the Quarrying operations are proposed and proposed maximum depth of quarrying operation.(xii)A
tentative scheme of quarrying, annual program and plan for excavation from year to year for five
years.(xiii)The extent of manual quarrying or quarrying by the use of machinery and mechanical
devices(xiv)Measures of protection of environment, especially against air and water pollution due to
Quarrying operation(xv)Measures to be taken for reclamation of land(xvi)Quarrying Closure Plan
(Not applicable in case of temporary permit).Chhattisgarh Minor Mineral Rules, 2015

25. Quarry Plan to be prepared by recognized qualified persons (RQP).
(1)No Quarry Plan shall be approved unless it is prepared by a recognized qualified person or
authorized person as notified by the Director.(2)Recognized Qualified person/Authorized person
shall possess the following qualification and experience, namely :-(i)a degree in Mining Engineering
or post-graduate degree in Geology from a University established or incorporated by or under a
Central Act, or a State Act, including any institution recognised by the University Grants
Commission established under Section 4 of the University Grants Commission Act, 1956 (3 of 1956)
or any equivalent qualification granted by any University or Institution outside India;
and(ii)professional experience of three years in the field of mineral exploration/administration or
mining after obtaining the degree or have been in the employment of the Directorate of Geology and
Mining.(3)A Recognised Qualified Person/Authorised person may also carry out modifications of an
existing Quarry Plan.
26. Approval of Quarry Plan.
(1)Every Quarry Plan submitted for approval, shall be accompanied with a non-refundable fee of
rupees one thousand for every hectare or part thereof, of quarrying area covered under the Quarry
Lease.(2)Any person aggrieved by any order made or direction issued in respect of Quarry Plan by
the officer authorised by the Director may, within thirty days of the communication of such order or
direction may apply to the Director, alongwith original treasury challan of rupees one hundred for
revision of the order or direction :Provided that any such application may be entertained after the
said period of thirty days if the Director is satisfied that he had sufficient cause for not making the
application within time.(3)On receipt of any application for revision under sub-rule (2), the
Director, after giving a reasonable opportunity of being heard to the aggrieved person, may confirm,
modify or set aside the order made or direction issued by any officer who approved the Quarry
Plan.(4)The procedure enumerated above, shall mutatis mutandis, be followed for the disposal of
such application.
27. Power to approve Quarry Plan.
- The Quarry Plan shall be approved by any officer authorized by the Director for this purpose
through a notification.
28. Grant of recognition by Director.
(1)Any person possessing the qualifications and experience, referred to in rule 25, may apply for
being recognised as a Recognised Qualified Person to the Director or any officer duly authorised by
the Director.(2)After making such enquiry as it deems fit, the Director or officers authorised by the
Director, may grant or refuse to grant recognition and where recognition is refused, shall record
reasons in writing and communicate the same to the applicant.(3)Recognition shall be granted for
an initial period of 5 years and may be renewed for a period of 5 years at a time :Provided that the
Director or officers authorised by the Director, may refuse to renew recognition for reasons to beChhattisgarh Minor Mineral Rules, 2015

recorded in writing after giving an opportunity of being heard to the person concerned.(4)An appeal
shall lie to the State Government against the order of the Director refusing to grant or renew an
application for recognition and in cases where the order has been passed by the officers authorised
by the Director the appeal shall lie to the Director whose decision shall be final.(5)If Recognised
Qualified Person uses false or fabricated data/information for preparation of Quarry Plan, the
officer competent to grant recognition shall cancel the recognition of that Recognised Qualified
Person or black list for preparation of Quarry Plan for a period of five years or both :Provided that
before cancellation of recognition or black listing, the Recognised Qualified Person should be given
reasonable opportunity of being heard :Provided further that an appeal shall lie to the State
Government against the order of the Director regarding cancellation of the recognition of that
Recognised Qualified Person and black listing for preparation of Quarry Plan and in cases where the
order has been passed by the officers authorised by the Director the appeal shall lie to the Director
whose decision shall be final.(6)If Recognised Qualified Person uses false or fabricated
data/information for preparation of Quarry Plan, he shall be punishable with imprisonment for a
term which may extend to one year and with fine which may extend to twenty five thousand
rupees.(7)Any Quarry Plan prepared by using false or fabricated data/information shall be void and
be of no effect.
29. Financial assurance.
(1)Financial assurance has to be furnished by every Quarry Leaseholder. The amount of financial
assurance shall be rupees twenty five thousand per hectare or part thereof of the lease area.(2)The
financial assurance shall be submitted in one of the following forms to the Collector or the Director,
as the case may be,-(i)Letter of Credit from any Scheduled Bank; or(ii)Surety Bond in
Form-X;(3)The lessee shall submit the financial assurance to the Collector or the Director, as the
case may be, before execution of the lease deed.(4)Where quarrying operations have been
undertaken before the commencement of these rules the holder of such Quarry Lease shall submit
financial assurance within a period of one year from the date of commencement of these
rules.(5)Release of financial assurance shall be effective upon the notice given by the Lessee for the
satisfactory compliance of the provisions contained in the Quarry Closure Plan and certified by the
Collector.(6)If Collector has reasonable grounds for believing that the protective, reclamation and
rehabilitation measures as envisaged in the approved Quarry Closure Plan in respect of which
financial assurance was given has not been or will not be carried out in accordance with the Quarry
Closure Plan, either fully or partially, the Collector shall give the Lessee a written notice of his
intention to issue the orders for forfeiting the sum assured at least thirty days prior to the date of the
order to be issued.(7)Within thirty days of the receipt of notice referred to in sub-rule (6), if no
satisfactory reply has been received in writing from the Lessee, the Collector shall pass an order for
forfeiting the surety amount and a copy of such order shall be endorsed to the Director.(8)Upon
issuance of such order by the Collector, the Director may realise any Letter of Credit or Surety Bond;
Guarantee provided or obtained as financial assurance for the purpose of performance of protective,
reclamation, rehabilitation measures and shall carry out those measures or appoint an agent to do
so.Chhattisgarh Minor Mineral Rules, 2015

30. Area restriction on grant of Quarry Lease.
(1)For minerals Granite and Marble specified under Part-A of Schedule-I, the provisions of Granite
Conservation and Development Rules, 1999 and Marble Development and Conservation Rules,
2002 respectively, shall apply.(2)No person shall acquire one or more- Quarry Lease, in respect of
any mineral specified under Part-B and Part-C of Schedule-1 and Part-A of Schedule-II, covering a
total area, more than fifty hectares :Provided that if the State Government is of opinion that in the
interest of the development of any mineral, it is necessary so to do, it may, for reason to be recorded
by it, in writing, permit any person to acquire one or more Quarry Lease covering an area in excess
of the aforesaid total area:Provided further that for cluster mining of minor mineral/minerals the
maximum area shall not exceed five hundred hectares.Explanation. - For the purposes of this clause
a 'person' includes an individual, a Hindu undivided family, a company, a firm, an association of
persons or a body of individuals, whether incorporated or not, a local authority, and every artificial
juridical person.(3)For minerals specified under Part-B of Schedule-I and except Serial No. 2
(Flagstone) of Part-C the minimum area shall not be less than one hectares. In case of Flagstone,
and minerals specified in Part-A of Schedule-II, the minimum area shall not be less than 0.40
hectare :Provided minimum area specified in this sub-rule shall not apply for renewal of quarry
leases granted before commencement of these rules.
31. Application Fee.
(1)There shall be paid a non-refundable application fee in respect of every application for grant or
renewal of a Quarry Lease with respect to minerals specified in Schedule-I and minerals specified in
Part-A of Schedule-II.(2)A non-refundable application fee shall be deposited in the following
manners :
S. No. Area Applied Fee
(1) (2) (3)
(i) up to Five hectare Rupees Five Thousand
(ii) more than Five hectare Rupees Ten Thousand
(3)The application fee shall be deposited in the Government Treasury under the revenue receipt
head-
0853. Non ferrous Mining and Metallurgical Industry
{102} Mineral concession fees, rent and royalties(0278)Receipt from minor mineralsand the
original treasury receipt Challan shall be attached with the application.
32. Officer authorised to receive applications.
- The Deputy Director or Mining Officer or Assistant Mining Officer or in their absence any officer
authorised by the Collector of the district shall receive the applications for grant or renewal of
Quarry Lease for Minor Minerals and shall enter on it the date and time on which the applicationChhattisgarh Minor Mineral Rules, 2015

was received by him.
33. Availability of certain areas.
- No application for Quarry Lease of minerals, mentioned in Schedule-I and Part-A of Schedule-II,
shall lie for areas previously held or which are being held under a Mining/Quarry Lease or in respect
of which the order had been made for the grant thereof, but due to any reason lease deed is not
executed and in respect of which the order granting lease has been revoked or in respect of which an
application for Quarry Lease has been rejected on the ground that the area should be reserved for
any purpose, unless the date from which the area shall be available for grant is notified in the
Official Gazette at least thirty days in advance :Provided that the State Government may for reasons
to be recorded in writing relax the provisions of this rule in a special case.
34. Reservation of areas for exploitation in the public sector, etc.
- The State Government may, by notification in the Official Gazette, reserve any area for
conservation, protection of environment, assessment of reserve by the State Government or for
exploitation by the Government Corporation established by the Central or the State Government or
a Government Company within the meaning of sub-section (45) of Section 2 of the Companies Act,
2013 (No. 18 of 2013).
35. Acknowledgement of application.
(1)Where an application for the grant or renewal of a Quarry Lease is delivered personally, its
receipt shall be acknowledged forthwith and where such application is received by registered post;
and in other cases, the receipt shall be acknowledged within three days of the receipt.(2)The receipt
of every of such application shall be acknowledged under Form-Ill.
36. Register of application for Quarry Lease.
- A register of applications for Quarry Lease shall be maintained by the Mining Officer or Assistant
Mining Officer of the district in Form-XI.
37. Premature applications.
(1)Application for the grant of a Prospecting Licence, or Quarry Lease in respect of areas whose
availability for grant is required to be notified under rule 33, shall, if,-(i)no notification has been
issued, under that Rule; or(ii)where any such notification has been issued and the period specified
in the notification has not expired, then application shall be deemed to be premature and shall not
be entertained.(2)On request of applicant, the fee paid along with application as per sub-rule (1)
shall be refunded.Chhattisgarh Minor Mineral Rules, 2015

38. Renewal of Quarry Lease.
(1)Every application for the renewal of a Quarry Lease shall be made at least one year before the
date on which the lease is due to expire; and shall be disposed off before the expiry of lease and if the
application is not disposed off within the said period, the lease shall be deemed to have been
extended by a further period till final orders are passed on the renewal of application by the
sanctioning authority.(2)Where the application for renewal has been received after the period
prescribed in sub-rule (1), it shall only be entertained on payment of late fees along with the
application at the rate of rupees one thousand per month or part thereof and the reasons for such
delay:Provided that the delay only up to a period of six months in filing the application shall be
considered by the Sanctioning Authority :Provided further that the Sanctioning Authority may on
being satisfied about the adequacy and genuineness of the reasons for delay in filing the application,
pass an order with the reasons recorded in writing for such condonation of delay.(3)During the
extended period as mentioned under sub-rule (1), no quarrying operation including the dispatch of
minerals from the lease area, shall be carried out or allowed to be carried out, by the Lessee till the
lease is renewed.
39. Disposal of applications for the grant or renewal of Quarry Lease.
(1)On receipt of an application for the grant or renewal of a Quarry Lease, its details shall be first
circulated for display on the notice board of the Zila Panchayat, Janpad Panchayat and Gram
Panchayat concerned of the district and Collectorate of the district concerned.(2)On receipt of the
application for the grant of a Quarry Lease for the minerals specified in Schedule-I and Part-A of
Schedule-II, the Sanctioning Authority shall take decision to grant precise area for the said purpose
and communicate such decision to the applicant.(3)On receipt of communication from the
Sanctioning Authority of the concerned area, the applicant shall submit the following documents
within a period of six months or such other period as may be allowed by the Sanctioning Authority,
namely :-(a)Quarry Plan, prepared and approved, as per rule 24; and(b)Necessary consent, if
applicable, from Competent Authority, required under the Water (Prevention and Control of
Pollution) Act, 1974 (No. 6 of 1974), the Air (Prevention and Control of Pollution) Act, 1981 (No. 14
of 1981), and the Environmental (Protection) Act, 1986 (No. 29 of 1986) and rules made
thereunder.(4)An application, for the renewal of a Quarry Lease made within the time, referred to in
rule 38, and complete in all material particulars shall be disposed off by the Sanctioning Authority
before the date of expiry of the lease.(5)All pending applications for the grant of Quarry Lease,
inclusive of such applications on which agreements have not been executed on the date of
commencement of these rules shall be deemed to have been refused by the Sanctioning Authority.
Fresh applications in this behalf may be made according to the procedure laid down under these
Rules.(6)Where an applicant for grant or renewal of a Quarry Lease, expires before the sanction
order is passed, it shall be deemed to have been filed by his legal heirs and if the applicant expires
after the sanction order of grant or renewal but before execution of lease deed, it shall be deemed to
have been granted or renewed to the legal heir of the applicant.Chhattisgarh Minor Mineral Rules, 2015

40. Reasons for refusal to be recorded.
(1)The Sanctioning Authority may, after giving an opportunity of being heard and for reasons to be
recorded in writing and communicated to the applicant, refuse to grant or renew a Quarry Lease
over the whole or part of the area applied for.(2)An application for the grant or renewal of a Quarry
Lease made under rule 23, shall not be refused by the Sanctioning Authority only on the ground,
that Form-IX, is not complete in all material particulars by the documents referred to in sub-clause
(xi) and (xii) of rule 23.(3)Where it appears that the application is not complete in all material
particular or is not accompanied by the required documents, the Sanctioning Authority, shall by a
notice require the applicant to supply the omission or, as the case may be, furnish the documents,
without delay and in any case not later than thirty days from the date of receipt of the said notice by
the applicant.
41. Register of Quarry Leases.
(1)A Register of Quarry Leases shall be maintained by the Mining Officer/Assistant Mining Officer
in Form-XII.(2)The Register of Application for Quarry Leases and the Register of Quarry Leases
shall be available for inspection by any person on payment of the following fee, namely:-(a)rupees
fifty for first hour or part thereof; and(b)rupees fifty for subsequent hour or part thereof.(3)The fee
under sub-rule (2) shall be deposited in the same manner as prescribed in sub-rule (3) of rule 31.
42. Preferential Rights.
(1)Where a Prospecting Licence has been granted in respect of any land, the Licensee shall have a
preferential right for obtaining a Quarry Lease, in respect of that land over any other person
:Provided that the sanctioning authority is satisfied that the Licensee,-(a)has undertaken
Prospecting Operations to establish mineral reserve in such land;(b)has followed the terms and
conditions of the Prospecting Licence;(c)has not become ineligible under the provisions of this rule;
and(d)has not failed to apply for grant of Quarry Lease, within ninety days after the expiry of
Prospecting Licence.(2)In all other cases where direct applications for Quarry Leases have been
invited through notification or otherwise, as the case may be, the preferential rights for grant of
Quarry Leases shall be as follows,-(a)Co-operative Society/Association of Scheduled
Tribes/Scheduled Castes/Other Backward Classes and co-operative society/ association of educated
unemployed youths or individuals where more than fifty per cent., of the members belong to the
concerned category and also where the Chairman of the Society is of the concerned category and
also where the executive committee have the representation in the ratio of the members of the
concerned category and belonging from Below Poverty Line families listed in the District Rural
Development Agency or Educated Unemployed youth belonging to Scheduled Tribes/Scheduled
Castes/Other Backward Classes in that order;(b)An Educated Unemployed youth belonging to
Below Poverty Line families listed in the District Rural Development Agency;(c)Any other person
belonging to Below Poverty Line families listed in the district Rural Development Agency;(d)Any
other applicant:Provided that exclusive Co-operative Society/Association of Women or an individual
woman shall have the preferential right over other applicants in the same order as provided in
clause (a), (b), (c) and (d):Provided further that the above priorities shall hold good only if theChhattisgarh Minor Mineral Rules, 2015

applications are received within thirty days from the date of first application.(3)Whenever more
than one application in any particular category is received by the Sanctioning Authority, while
sanctioning a Quarry Lease, it shall take into consideration the following matters in respect of the
applicants, namely :-(a)any special knowledge of or experience in mining;(b)technical and
management experience of establishing, running and maintaining mineral based industry;(c)the
nature and quality of the technical staff employed by the applicant;(d)the financial resources of the
applicant; and(e)the proposed phased programme of establishing the industry.(4)Notwithstanding
anything contained in sub-rule (1) or (2) the Sanctioning Authority shall record the reasons to grant
a lease, in variance with the order of priority specified in sub-rule (1) and (2), in writing, with the
prior approval of the State Government:Provided that in cases falling under category (a) to (d) in
sub-rule (2), the grant of lease shall be subject to the condition that lessee shall work the mine
directly and shall not hand it over to any other party for working :Provided further that the
Sanctioning Authority may refuse to accord preference to the application of a Co-operative
Society/Association, if he finds that the particular society does not work properly in the interest of
the workers concerned.
43. Period of Quarry Lease.
(1)The period for which a Mining Lease/ Quarry Lease may be granted or renewed shall be as shown
in the table below,-
S.
No.Name of the Minerals Period
(1) (2) (3)
1.Minerals specified in Part-A of
Schedule-IAs prescribed in the Granite Conservation
andDevelopment Rules, 1999 and Marble Development
and ConservationRules, 2002, respectively.
2.Minerals specified in Part-B and
Part-C ofSchedule-I and in Part-A
of Schedule- II.Ten years with a renewal clause, or lesserperiod subject to
the availability of mineral resource. However,the
minimum period shall not be less than 5 years.
44. Aggregate holding area of limestone (minor mineral), marble and flag
stone.
- No lessee shall ordinarily hold in aggregate more than fifty hectares area of Limestone (Minor
Mineral), Marble and Flag stone in the State.Explanation. - The above limit shall ordinarily be
applicable in renewal cases also.
45. Boundaries below the Surface.
- The boundaries of the area covered by a Quarry Lease shall be vertically downward below the
surface towards the centre of the Earth.Chhattisgarh Minor Mineral Rules, 2015

46. Security deposit and surety.
(1)An applicant for Quarry Lease shall, before the deed referred to in rule 47 is executed, deposit as
security, a sum of Rupees Twenty Five Thousand in respect of Quarry Leases of minerals specified in
Schedule-I and Part-A of Schedule-II, in the Government Treasury under the following revenue
receipt head and the original Treasury receipt Challan shall be attached with the lease deed :-
8443. - Civil Deposit
101. - Revenue Receipt (Refundable)
(2)The applicant shall also submit the surety bond duly executed in Form-X or a bank guarantee for
an amount equal to two years of Dead Rent:Provided that in case of a Co-operative
Society/Association the provision of sub-rule (2) may be waived by the Competent
Authority.(3)Deposit made under sub-rule (1), if not forfeited under these rules and no other dues
are outstanding against the Lessee, shall be refunded by the Collector on the expiry of the lease or its
determination whichever is earlier.
47. Lease to be executed within ninety days.
(1)Where a Quarry Lease is granted or renewed, the lease deed in Form-XIII shall be executed and
registered under the Indian Registration Act, 1908 (No. 16 of 1908) within a period of ninety days of
the order of sanction of the lease and if no such lease is executed within the aforesaid period, the
order sanctioning the lease shall be deemed to have been revoked and in that event the application
fee paid shall be forfeited to the State Government.(2)Where the lessee is unable to execute the lease
deed within a period of ninety days from the date of the order, he may submit an application to the
Director explaining the reason for the same before the expiry of the said period.(3)Every application
under sub-rule (2) shall be accompanied by non-refundable fee of Rupees Five Hundred.(4)The
Director may, on receipt of an application made under sub-rule (2) on being satisfied on the
adequacy and genuineness for the non-execution of the deed, pass an order for extension of the
period of execution of deed.(5)The Collector shall send copy of every lease deed along with the plan
to the respective Janpad Panchayat and shall intimate the full details of area to the respective gram
panchayat.
48. Survey of the area leased.
(1)When a Quarry Lease is granted over any area, arrangement shall be made by the Deputy
Director or Mining Officer or Assistant Mining Officer at the expense of the lessee for the
preparation of map on tracing doth showing co-ordinates of the area granted and the demarcation of
the area granted under the lease, after collecting a fee calculated according to the rates specified in
the table below :-Table
Area Rates of feesChhattisgarh Minor Mineral Rules, 2015

S.
No.
(1) (2) (3)
(a)Area not exceeding 20
hectaresRupees five hundred per hectare or part thereofsubject to a
minimum of rupees one thousand.
(b)Area exceeding 20
hectaresRupees one thousand per hectare or part thereof.
(2)The lessee shall erect and maintain at his own expense, boundary pillars of substantial material,
standing not less than one meter above the surface of the ground at each comer or angle in the line
of the boundary, delineated in the plan attached to the lease deed, co-ordinates should be marked on
all the comer pillars.(3)The maximum distance between any two successive boundary pillars should
not be more than 100 meter.(4)The fee under sub-rule (1) shall be deposited in the revenue receipt
head as mentioned in sub-rule (2) of Rule 7.
49. Rent and Royalty.
(1)When a Quarry Lease is granted or renewed,-(a)Dead Rent shall be charged at the rates specified
in Schedule-I V;(b)royalty except for limestone shall be charged at the rates specified in
Schedule-Ill;(c)rate of royalty on limestone shall be the same as fixed by the Government of India,
from time to time, for other limestone in Schedule-II of the Act;(d)surface rent shall be charged at
the rates specified by the Collector of the district, from time to time, for the area occupied or used by
the lessee.(2)On and from the date of commencement of these rules, the provisions of sub-rule (1)
shall also apply to the leases granted or renewed prior to the date of such commencement and
subsisting on such date.(3)If the lease permits the working of more than one mineral in the same
area separate Dead Rent in respect of each mineral may be charged :Provided that the lessee shall be
liable to pay the Dead Rent or royalty in respect of each mineral, whichever is higher in
amount.(4)Notwithstanding anything contained in any instrument of the lease, the lessee shall pay
Royalty/Dead Rent in respect of any mineral removed and/or consumed at the rate specified from
time to time in Schedule in and IV.(5)The State Government, by notification in the Official Gazette,
may amend Schedules III and IV, so as to enhance or reduce the rate at which Royalty/Dead Rent
shall be payable in respect of any mineral with effect from the date of publication of the notification
in the Official Gazette :Provided that the State Government shall not enhance the rate of
Royalty/Dead Rent, in respect of any mineral more than once during any period of three
years.(6)On declaration of any mineral as minor minerals under clause (e) of Section 3 of the Act by
the Government of India, rates of dead rent/royalty notified by the Central Government for said
minerals shall be effective till rates are notified for the said minerals in Schedule-III and IV by the
State Government. This provision shall also be applicable on minerals declared minor minerals by
notification dated 10th February, 2015 of Government of India.
50. District Mineral Foundation.
(1)For any district affected by operations relating to mining, the State Government shall by
notification establish non-profit earning "District Mineral Foundation" under Section 9-B of theChhattisgarh Minor Mineral Rules, 2015

Act.(2)The object of District Mineral Foundation shall be to work for benefit and profit of area and
person affected from operations relating to mining in such manner as may be prescribed by the
State Government.(3)Formation and work of District Mineral Foundation shall be such as may be
prescribed by the State Government.(4)The amount prescribed by the State Government shall be
paid in addition to royalty to be paid by the lessee of minor mineral, to such District Mineral
Foundation in which district mining operations are being operated by him.(5)Amount to be paid as
per sub-rule (4) to the District Mineral Foundation shall be payable from the date of enforcement of
this rule.
Chapter VI
Quarry Lease-General Conditions
51. Conditions of Quarry Lease.
(1)Every Quarry Lease shall be subject to the following conditions, namely :-(a)The lessee shall pay,
for every year except for the first year of the lease, yearly Dead Rent at the rates specified in the
Schedule IV, in advance for the whole year, on or before the 20th day of the first month or the
year;(b)The lessee shall pay the Dead Rent or Royalty in respect of each mineral whichever is higher
in amount but not both. Such royalty shall be paid in respect of quantities of mineral intended to be
consumed or transported from the leased area no sooner the amount of Dead Rent already paid
equals the royalty on mineral consumed or transported by him. The Dead Rent or royalty shall be
deposited in the Government Treasury under the following revenue receipt head, namely :-
0853. Non ferrous Mining and Metallurgical Industry
{102} Mineral concession fees, rent and royalties.(0278)Receipt from minor minerals(c)The lessee
shall also pay for the surface area occupied or used by him for the purposes of mining operations
and surface rent in advance for the whole year on or before the 20th day of the first month every
year;(d)Notwithstanding any other action that may be taken in case of default in payment of dues as
specified in clause (a), (b), (c) within time under these rules or under any other condition of the
lease, the lessee shall pay interest at the rate of 24% per annum or equivalent to the rate of interest
prescribed under rule 64A of the Mineral Concession Rules, 1960, whichever is higher for all
defaulted payments of Dead Rent, royalty and surface rent.(2)If any mineral, not specified in the
lease is discovered in the leased area, the lessee shall report such discovery without delay to the
Collector and shall not win or dispose off such mineral without obtaining a lease therefore. If he fails
to apply for such a lease within a period of ninety days of the discovery of the mineral, the
Competent Authority may sanction lease of such mineral, to any other person, who applied for
it.(3)The lessee shall not pay wages, less than the minimum wages prescribed by the State or the
Central Government under the Minimum Wages Act, 1948 (No. 11 of 1948), from time to
time.(4)The lessee shall take all measures for planting not less than twice the number of trees
destroyed by reasons of mining operation in addition to restoring and leveling the land in mined out
area or any other area selected by the Collector.(5)The lessee shall commence mining operation
within one year from the date of execution of the lease deed and shall thereafter conduct suchChhattisgarh Minor Mineral Rules, 2015

operations in a proper, skillful and workman-like manner.(6)Subject to the provision under these
rules, where mining operations have not commenced within a period of one year from the date of
execution of the lease deed or discontinued for a cumulative period of six months during any
calendar year after commencement of such operation, the Sanctioning Authority may, by an order,
declare the Quarry Lease as lapsed and communicate the declaration to the lessee.(7)Where the
lessee is unable to commence mining operation for a period exceeding one year or unable to
continue mining after commencement for a cumulative period of six months during any calendar
year, for reasons beyond his control, he may submit an application to Sanctioning Authority
explaining the reasons at least ninety days before the expiry of such period.(8)There shall be paid, in
respect of every application under sub-rule (7), a non-refundable fee of rupees five hundred,
deposited in the Government treasury under the receipt head prescribed in sub-rule (3) of Rule
31.(9)The Sanctioning Authority of the lease shall, on receipt of an application made under sub-rule
(7) and on being satisfied about the adequacy and genuineness of the reason for the
non-commencement of mining operations or discontinuance thereof, pass an order before the date
on which the lease would have otherwise lapsed, extended or refusing to extend the period of the
lease :Provided that where the Sanctioning Authority on receipt of application under sub-rule (7),
does not pass any order before the expiry of the date on which the lease would have otherwise
lapsed, the lease shall be deemed to have been extended until the order is passed by the concerned
authority or for a period of one year, whichever is earlier.(10)Where non-commencement of the
mining operation is on account of delay in,-(i)acquisition of surface rights, or(ii)getting the
possession of the leased area, or(iii)supply or installation of machinery, or(iv)getting Financial
Assistance from banks or any financial institution,and the lessee is able to furnish documentary
evidence supported by a duly sworn-in affidavit stating sufficient reasons for non-commencement of
mining operations, the sanctioning authority may revoke the declaration/order through which the
lease has lapsed.(11)The lessee shall, at his own expense, erect, maintain and keep in good repairs
boundary marks and boundary pillars necessary to indicate the demarcation shown in the plan, at
all times.(12)The lessee shall not carry on or allowed to be carried on, any mining operations in an
area (areas) restricted as per sub-rule (2) of rule 5.(13)The lessee shall keep correct accounts
showing the quantity and other particulars of all minerals obtained from the mine, date wise and
quantities of dispatches/consumptions from the lease hold, the price obtained for such minerals, the
name of the purchaser, the receipts for money received, the number or persons employed therein
and shall allow all officers of the Directorate of Geology and Mining and any officer authorised by
the Zila Panchayat/Janpad Panchayat/Gram Panchayat, in this behalf, to examine at any time any
accounts and record maintained by him and shall furnish to the Collector and respective Zila
Panchayat/Janpad Panchayat/Gram Panchayat such information and returns as may be
required.(14)The lessee shall issue a transit pass, in Form-1 of the Chhattisgarh Minerals (Mining,
Transportation and Storage) Rules, 2009, to accompany every carrier for every trip carrying mineral
or product or products from leased area. The transit pass shall be prepared in duplicate in a book
form. Duplicate copy shall be given to the driver of the carrier, after making the necessary entries.
The Mining Officer shall issue the transit pass book, duly stamped and signed by him, on an
application made by the lessee in Form-XIV. The lessee shall surrender all previous duplicate copies
of used transit pass books together with unused transit pass books issued to him before the royalty is
paid by him under clause (b) of sub-rule (1) and fresh transit passes are issued. The Mining Officer
shall keep proper accounts of issued and used duplicate transit passes. The Mining Officer will keepChhattisgarh Minor Mineral Rules, 2015

proper accounts of issued and used duplicate transit pass books and unused transit pass books
deposited back by the lessee.(15)Whosoever transports minerals or their products like bricks, tiles
lime, dressed stone, blocks, slabs, tiles, chips stone dust and ballast etc. without a valid pass under
Form-1 of the Chhattisgarh Minerals (Mining, Transportation and Storage) Rules, 2009, or where
the transit pass is found to be incomplete, distorted or tampered with, the Collector, Additional
Collector, Chief Executive Officer of the Zila Panchayat/Janpad Panchayat and Gram Panchayat,
Deputy Director, Mining Officer, Assistant Mining Officer or Mining Inspector may seize the
mineral or its products together with all tools and equipment and the vehicle used for
transport:Provided that the provisions of this sub-rule shall not apply for the purposes of clause (i)
of rule 3.(16)The Collector, Additional Collector, Chief Executive Officer of Zila/Janpad Panchayat
and Gram Panchayat, Joint Director, Deputy Director or Mining Officer, by an order in writing, may
impose a penalty up to a maximum of rupees ten thousand but not less than rupees five
thousand.(17)The seized mineral, its products, tools, equipment and vehicle may be released when
the penalty so imposed is deposited.(18)If the penalty so imposed is not paid within 15 days from the
date of the order of imposing the penalty, all the minerals, its product, tools, equipment and
vehicles, etc. so seized shall stand forfeited and shall become the property of the State
Government.(19)The lessee shall submit the records, books and accounts, for the purpose of
assessment of royalty, to the concerned Assessing Authority, within thirty days from 30th June/31st
December or whenever demanded by the Assessing Authority through a notice in writing. On
failure, a penalty of one thousand rupees may be imposed for every month till the production of the
said record.(20)The lessee shall,-(a)submit by the 10th day of every month, to the Collector and
Gram Panchayat, a return in Form XV giving the total quantity of mineral/minerals raised,
removed/consumed in previous month;(b)submit on or before 15th day of July and January, to the
Collector, half yearly returns upto June and December in Form-XVI;(c)submit by the 31st January
of every year, to the Collector a statement giving information under Form-XVII regarding quantity
and value of mineral/minerals raised/removed/consumed during last calendar year, average
number of labourers employed (men and women separately) and the number of days worked;(d)in
case the lessee fails to submit the information in period/date as prescribed in clause (a), (b) and (c),
a penalty of five hundred rupees per month or part thereof, shall be imposed till the said
information in prescribed form is produced.(21)The lessee shall strengthen and support to the
satisfaction of Railway Administration or the sanctioning authority, as the case may be, any part of
mine which in its opinion requires such strengthening or support for the safety of any railway,
bridge, national highway, reservoir, tank, canal, or any other public works or buildings.(22)If the
lessee or his transferee or assignee does not allow entry or inspection under sub-rule (23), the
sanctioning authority shall cancel the lease and forfeit, in whole or in part, the security deposit paid
by the lessee under rule 46.(23)(i)The lessee shall allow officers authorised by the State or the
Central Government and any officer authorised by the Zila Panchayat/Janpad Panchayat/Gram
Panchayat to enter upon any building, excavation or land comprised in the lease for the purpose of
inspecting the same.(ii)Every owner, agent or manager of a mine shall provide all necessary facilities
to the persons deputed by the State Government for the purpose of undertaking research or training
in matters relating to mining operations.(24)The lessee shall immediately provide to the Director
General, Mines Safely of Government of India at Dhanbad, the Controller General of Indian Bureau
of Mines of Government of India at Nagpur and the District Magistrate of the district in which the
mine is situated, a notice under Form-XVIII appended to these rules, and shall comply withChhattisgarh Minor Mineral Rules, 2015

provisions mentioned in Mines Act, 1952 and rules and regulations made thereunder at the time
when,-(a)the working in the mine extends below superjacent ground; or(b)the depth of any open
cast excavation measured from its highest to the lowest point exceeds 6 meters; or(c)the number of
persons employed on any day exceed 50; or(d)any explosive are used.(25)The State Government
shall, at all times, have the right of pre-emption of the minerals won from the land, in respect of
which the lease has been granted :Provided that a fair market price prevailing at the time of
pre-emption shall be paid to the lessee, for all such minerals.(26)In case of breach by the lessee or
his transferee or assignee, of any of the conditions specified in sub-rule (1), (3), (4), (11), (12), or (13)
of this rule, the Collector/Additional Collector shall give notice in writing to the lessee or his
transferee or his assignee to show cause as to why such breach should not be penalized and directing
him to remedy the breach within a period of thirty days from the date of the notice. On failure to
show proper cause or if the branch is not remedied within such period, the sanctioning authority,
without prejudice to any other action, shall determine the lease and forfeit, in the whole or in part,
the security deposit or may alternatively receive from the lessee such penalty for the breach not
exceeding four times the amount of the yearly Dead Rent as mentioned in column 5 of Schedule-IV
but in any case shall not be less than rupees ten thousand, as the lessor may fix.(27)In case of breach
of any conditions of the lease, by the lessee or his transferee or assignee, the sanctioning authority
shall require the lessee to pay a penalty not exceeding an amount equivalent to twice the amount of
annual Dead Rent as mentioned in column 5 of Schedule-IV but in any case shall not be less than
rupees five thousand.(28)A Quarry Lease may contain such other conditions as the sanctioning
authority may deem necessary in regard to the following, namely,-(a)the lime limit, mode and place
of payment of rents and royalties;(b)the compensation for damage to the land covered by
lease;(c)the felling of trees;(d)the restriction of surface operation in any area prohibited by any
authority;(e)the notice by lessee for surface occupation;(f)the facilities to be given by the lessee for
working other minerals in the leased area or adjacent areas;(g)the entering and working in an
reserved or protected forest;(h)the security of pits and shafts;(i)the reporting of accidents;(j)the
indemnity to State Government against claims of third parties;(k)the maintenance of sanitary
conditions in the mining area;(l)the delivery of possession over lands and mines on the surrender,
expiration or determination of the lease;(m)the forfeiture of property left after determination of the
lessee;(n)the power to take possession of plant, machinery, premises, and mines in the event of war
or emergency;(o)the manner in which rights of third parties may be protected (whether by way of
payment of compensation or otherwise) in cases where any such party is prejudicially affected by
reason of any mining operation;(p)the manner in which rehabilitation of flora and other vegetation
such as trees, shrubs etc., destroyed by reason of any Mining Operation, shall be made in the same
area or in any other areas selected by the State Government, by way of reimbursement of the cost of
rehabilitation or otherwise, by the person holding the Quarry Lease;(q)the construction,
maintenance and use of roads, power transmission lines, tramways, railways, aerial rope ways,
pipelines and making of passage for water for mining purposes on any land comprised in a mine or
other mineral concessions.
52. Special conditions.
- A Quarry Lease may contain any other special conditions as may be specified by the State
Government.Chhattisgarh Minor Mineral Rules, 2015

53. Establishment of cutting and polishing units.
(1)Notwithstanding anything contained in sub-rule (5) of rule 51, in respect of Quarry Leases of
minerals specified in Schedule-I, granted for the establishment of a cutting and polishing unit, if the
unit is not established within a period of one year, from the date of execution of lease/leases in the
State, the said lease/leases shall be deemed to be terminated.(2)Where the lessee is unable to
establish cutting and polishing unit within one year from the date of execution of lease/leases, he
ma$submit an application to the Director explaining the reason for the same before the expiry of the
said period.(3)Every application under sub-rule (2) shall be accompanied by non-refundable fee of
five thousand rupees.(4)The Director may, on receipt of an application made under sub-rule (2) on
being satisfied on the adequacy and genuineness for the non-establishment of cutting and polishing
unit, pass an order for extension of the period up to one year to establish cutting and polishing
unit.(5)The lessee can transport inter-state or export the set quantity of rough blocks within the first
year of the Quarry Lease or the period extended under sub-rule (4), as may be permitted by the State
Government.
54. Rights of lessee.
- Subject to the conditions specified in rule 51, the lessee, for the purposes of mining operations with
respect to the land leased to him, shall have the right(i)to work the mines;(ii)to sink pits and
construct building and roads;(iii)to erect plant and machinery;(iv)to mine and obtain building and
road materials and make bricks, but not for the purposes of sale;(v)to use water;(vi)to use land for
stacking purpose; and(vii)to do any other thing specified in the lease.
55. Right to determine lease.
- The lessee may determine the lease at any time by giving not less than six months notice in writing
to the sanctioning authority after paying all outstanding dues to the Government and complying
conditions of reclamation of quarry closure plan if applicable.
56. Transfer of Quarry Lease.
(1)No lessee shall transfer or sub-let his lease to any other person, nor make any arrangement with
anybody, thereby creating any right, direct or indirect, over the area leased ;Provided that the
permission for transfer may be granted to the lessee by the sanctioning authority on payment of
twenty five thousand rupees per hectare or part thereof, deposited in the same manner as prescribed
in sub-rule (3) of rule 31 :Provided further that in case of transfer of quarry lease, granted in
government land, such transfer fee will be rupees fifty thousand per hectare or part thereof.(2)The
sanctioning authority, may by an order in writing, determine the lease at any time if in the opinion
of the sanctioning authority the lessee has committed a breach of sub-rule (1).(3)On receiving an
application Lease under sub-rule (1), for transfer of Quarry Lease, the sanctioning authority has
given consent for transfer of such lease, a transfer lease deed under Form-XIX shall be executed
within three months from the date of permission or within such further period as the sanctioningChhattisgarh Minor Mineral Rules, 2015

authority may allow in this behalf.
57. Amalgamation of leases.
(1)The Director may, in the interest of mineral conservation and development, record in writing and
permit amalgamation of two or more adjoining leases held by a lessee/lessees,(2)Lessee/lessees
shall submit an application for amalgamation alongwith a common Quarry Plan for leases proposed
for amalgamation.(3)There shall be paid, in respect of every application for amalgamation of leases,
a non-refundable application fee of rupees ten thousand.(4)Period of amalgamated leases shall be
co-terminus with the lease whose period expires first.(5)The leases situated within the distance of 50
meters, from each other in all directions, may be treated as adjoining leases :Provided that
amalgamation of leases shall not be allowed where any all-weather road or nala or river or canal or
high-tension power line or railway line or any other restricted structure is falling within the above
mentioned area of 50 meters.(6)The area between the lease as mentioned in sub-rule (5) shall be the
part of the amalgamated lease.
Chapter VII
Grant of Quarry Permit in respect of minerals specified in Part-C
of Schedule-I and Part-A of Schedule-II
58. Procedure for grant of Quarry Permit.
(1)(i)The Collector shall grant Quarry Permit for extraction, removal and transportation of any
Minor Mineral specified in Part-C of Schedule-I and Part-A of Schedule-II from any specified land
which may be required for the works of any department or undertaking of the Central Government
or State Government.(ii)Such permission shall only be granted to either the concerned departmental
authority or its authorised contractor on furnishing proof of award of contract.(iii)An application for
Quarry Permits shall be made to the Collector of the concerned district in Form-XX along with an
application fee of rupees one hundred. Every such application shall be acknowledge in Form III on
the date of its receipt.(iv)A register of applications of Quarry Permit shall be maintained in
Form-XXI.(v)The Collector shall grant such Quarry Permit in Form-XXII after satisfaction of the
need and availability of mineral, on such conditions as he deems fit.(2)Area of Quarry Permit shall
not exceed the one hectare and duration of one year and the quantity of mineral shall not exceed the
quantity required for carrying out the particular work/works for which the permit has been
granted.(3)The transit pass for transportation of mineral in Form-1 of the Chhattisgarh Minerals
(Mining, Transportation and Storage) Rules, 2009 shall be issued on payment of advance royalty
only.(4)The Quarry permit shall be governed by the following conditions, namely:-(a)The holder of
Quarry permit shall maintain complete and correct account of the mineral removed and transported
from the area;(b)The holder of Quarry permit shall allow Deputy Director/Mining Officer/Assistant
Mining Officer/Mining Inspector or any officer authorised by the Collector or Zila
Panchayat/Janpad Panchayat/ Gram Panchayat to inspect quarrying operations and verify the
accounts;(c)No sooner the permitted quantity is transported within the time period of 30 days orChhattisgarh Minor Mineral Rules, 2015

earlier, original of all transit pass, such unused transit passes together with a complete statement of
the quantities duly certified by the Officer of the concerned department shall be furnished to the
Sanctioning Authority;(d)The holder of Quarry permit shall obtain all permissions/consents from
the competent authority under any Act and Rules applicable for excavation or removal of the
minerals from the area;(e)The holder of Quarry permit shall submit by the 10th of every month, to
the Collector and Gram Panchayat, a return in Form-XV;(f)Any other condition, the sanctioning
authority may deem fit.
59. Permission for disposal of minor minerals obtained during excavation
work.
(1)The Collector shall grant permission for removal and use of any such Minor Minerals obtained
during deepening or widening Panchayat ponds/ tanks, well, water reservoir or any other digging
work.(2)The said permission shall be granted on payment of an amount equivalent to royalty of such
mineral in advance, for the specified quantity and period.
60. Permission for disposal of Minor Minerals obtained during excavation
work within Mining Lease area granted under the Mines and Mineral
(Development and Regulation) Act, 1957.
- The Collector shall grant permission for transportation or use of any Minor Minerals obtained
during mining operations within the mining lease area for the purpose of construction activities of
the Government including local government bodies:Provided that in case of use of Minor Mineral,
collected within the Mining Lease area, by other than works department of the State Government,
Collector shall sell it through auction. Royalty shall be paid in advance for the said sold Minor
Mineral at prescribed rates.
Chapter VIII
Quarrying Operations
61. Opencast working.
(1)In opencast working, the benches formed shall be so arranged that the benches in mineral and
overburden are separated so as to avoid mixing or wastage of mineral.(2)(i)In alluvial soil, murrum,
gravel, clay or other similar ground, the sides shall be slopped at an angle of safety, not exceeding 45
degrees from horizontal or such other angle as the Competent Authority may permit by an order in
writing;(ii)the sides shall be kept benched, and the height of any bench shall not exceed 1.5 meter
and the breadth there of shall not be less them the height;(iii)the benches in overburden shall be
kept sufficiently in advance so that their working does not interfere with the working of
mineral;(iv)the overburden and waste material obtained during quarrying operations shall not be
allowed to be mixed with non-saleable or sub-grade minerals. They shall be dumped and stacked
separately;(v)the quarrying operations shall be carried out in workmen-like-manner and inChhattisgarh Minor Mineral Rules, 2015

accordance with the provisions of the State and Central Acts and rules and regulations made
thereunder, wherever applicable;(vi)if in the opinion of the Collector of the concerned district or any
officer authorised by the State Government, the compliance with the provisions thereof is not
reasonably practicable, he may, by an order in writing and subject to such conditions as he may
specify therein, exempt from the operation of these rules for any workings in those cases in which
special difficulties exist.
62. Exemptions.
- Subject to the exemptions granted under the Mines Act, 1952 (No. 35 of 1952) and rules made
thereunder, the lessees shall comply with all provisions of the said Act and rules.
Chapter IX
Protection of Environment
63. Protection of environment.
(1)Every holder of Quarry Lease shall take all possible precautions for the protection of environment
and control of pollution while conducting quarrying operation in the following manner,
namely--(a)Wherever top soil exists and is to be excavated for quarrying operation, it shall be
removed separately;(b)The top soil so removed shall be stored for future use;(c)The dumps shall be
properly secured to prevent escape of material therefrom and cause land degradation or damage to
agricultural fields, pollution of surface water bodies or cause floods;(d)The site of dumps shall be
selected, as far as possible, on impervious and barren ground within the leased area; and(e)The top
soil dumps shall be suitably terraced and established through vegetation or otherwise.(2)The top
soil so removed shall be utilised for restoration or rehabilitation of the land which is no longer
required for quarrying operations.(3)Removal, storage and utilisation of overburden etc.-(a)Every
holder of an Quarry Lease/Quarry Permit shall take steps so that the over burden, waste rock,
rejects and fines generated during quarrying or during sizing shall be stored in separate
dumps;(b)The dumps shall be properly secured and shall be suitably terraced and stabilised through
vegetation or otherwise;(c)Wherever possible, the waste rock, over burden etc. shall be back-filled
into the mined out area excavations with a view to restoring the land to its original use as far as
possible.
64. Reclamation and rehabilitation of lands.
- Every holder of Quarry Lease shall,-(i)Undertake the phased restoration, reclamation and
rehabilitation of lands affected by quarrying operations and shall complete this work before the
conclusion of such operations and the abandonment of quarry;(ii)Carry out quarrying operations in
such a manner so as to cause least damage to die flora of the area held under Quarry Lease and the
nearby area;(iii)Every holder of a Quarry Lease/Quarry Permit shall,-(a)take immediate measures
for planting in the same area or any other area selected by the Collector not less than twice the
number of trees destroyed by reason of any quarrying operations;(b)look after them during theChhattisgarh Minor Mineral Rules, 2015

subsistence of the lease after which the trees shall be handed over to the Gram Panchayat of the area
in which the quarries situated; and(c)restore to the extent possible other flora destroyed by
quarrying operations.(iv)Upon failure to observe these rules by the holder of a Quarry Lease/Quarry
Permit, the Sanctioning Authority shall recover the cost of rehabilitation and reclamation from
financial assurance deposited by the holder of lease/permit under Rule 29.
65. Precautions against damage to public places, etc.
- Every holder of a Quarry Lease or institution responsible for removal of Minor Minerals, ordinary
sand and bajri, specified in Part-B of Schedule-II, shall take adequate precautions against damage to
public buildings, monuments, roads, religious places either within the lease/specified area or in
proximity to the lease/permit/specified area.
66. Measures against air, water and environment pollution, etc.
- Every holder of a Quarry Lease or institution responsible for removal of Minor Minerals ordinary
sand and bajri, specified in Part-B of Schedule-II, shall take all necessary measures for avoiding air
and water pollution and protection of Environment, and shall obtain necessary consent, if
applicable, from competent authority, required under the Water (Prevention and Control of
Pollution) Act, 1974 (No. 6 of 1974), the Air (Prevention and Control of Pollution) Act, 1981 (No. 14
of 1981) and the Environmental (Protection) Act, 1986 (No. 29 of 1986) and rules made thereunder
and shall take all necessary steps/actions as mentioned in the consent during the course of
quarrying/removal operation, as the case may be.
67. Provisions for cluster mining.
(1)"Cluster" shall mean the geographical boundary declared by the State Government, comprising of
Quarry Lease/ Quarry Permits for Minor Minerals which already exists or will be granted in future.
The area of a cluster, as far as possible, share not exceed 500 hectares and mineral concessions area,
at the time of formation of cluster, shall not be less than 50 hectares. For cluster having area less
than 500 hectares, the minimum area under concession should be proportionate.(2)No Quarry
Lease/Quarry Permits shall be granted without a proper Quarry Plan including the Regional
Environment Management Plan (EMP) in a cluster. For clusters of leases/permit, a Regional
Environment Management Plan shall be prepared by association of lessees/permit holders of the
cluster through qualified person/agency and submitted to the Competent Authority under the
Environment (Protection) Act, 1986 for Environment Clearance/Consent.(3)Small leases/permit
holders falling in a cluster shall form an association for the implementation of Regional
Environment Management Plan approved by the Competent Authority. Any lessee/permit holder
within the boundary of cluster shall be deemed to be a member of the association. Such associations
shall be registered under the provisions of the relevant laws.(4)The objectives of Regional
Environment Management Plan shall be to manage the Regional Environment risk and the Regional
Environment Management Plan shall primarily comprise of the following issues, namely
:-(i)removal and utilisation of top soil;(ii)storage of overburden waste rock, etc.;(iii)reclamation and
rehabilitation of lands;(iv)precaution against air pollution;(v)discharge of effluents;(vi)precautionChhattisgarh Minor Mineral Rules, 2015

against noise;(vii)restoration of flora and fauna;(viii)water management;(ix)risk management;
and(x)integrated environmental management.
68. Quarry lease or permit undertaken before the commencement of these
rules.
- Where quarrying operation, under any Quarry Lease or Permit, have been undertaken before the
commencement of these rules, without an approved Environment Management Plan/Scheme, as the
case may be. from the Competent Authority, the holder of all such Quarry Leases/Permits shall
submit approved Environment Management Plan/scheme, at the time of renewal or within six
months from the commencement of these rules, whichever is earlier of such quarry.
69. Penalty.
- Contravention of any of the provisions of Rule 63 to 65 shall be punishable with imprisonment for
a term which may extend up to three months or with fine which may extend to five thousand rupees
or with both. In case of continuing contravention, an additional fine of twenty five hundred rupees
for every day during which such contravention continue after conviction for the first such
contravention, shall be imposed.
Chapter X
Assessment of Royalty
70. Assessment and determination of royalty.
(1)Assessment and determination of royalty due from an assessee during an assessment year or as
required, shall be made by the Assessing Authority after the returns in respect of that year have been
filed by the assessee as required under the terms and conditions of the lease deed or the statement
of production, dispatches or consumption has been submitted by the lease/permit holder :Provided
that the Assessing Authority may make a provisional assessment for a particular period during the
assessment year after the receipt of returns in respect of that period.(2)For the purpose of
assessment of royalty as mentioned in sub-rule (1), the assessee shall submit monthly returns under
Form-XV by the 10th of the following month and annual return under Form-XVII within one month
from the expiry of the assessment year.(3)If the assessee fails to submit returns as required under
sub-rule (2) or the returns filed appear to be incorrect, the Assessing Authority may hold such
inquiry as it may deem fit and assess royalty of the assessment year :Provided that the Assessing
Authority shall give reasonable opportunity of being heard to an assessee before taking any action
under this sub-rule.(4)For the purpose of sub-rule (3), the Assessing Authority shall serve a 15 days
notice upon the assessee requiring him to be present on such date and place specified in the notice,
to produce any evidence on which the assessee relies upon in support of the correctness of the
returns, statement and records furnished by him and to produce or cause to be produced such
accounts pertaining to the assessment year as the Assessing Authority may require.(5)On the dayChhattisgarh Minor Mineral Rules, 2015

specified in the notice, given in sub-rule (4), or on any other day thereafter which the Assessing
Authority may fix, the Assessing Authority after hearing and considering the evidence as may be
produced by the assessee in this behalf, shall make an order in writing or assessment of royalty
payable by the assessee.(6)Notwithstanding anything contained in these rules or in the agreement of
Quarry Lease, if the assessee contravenes any of the provisions of sub-rule (2), (4) and (5) or has not
adopted any method of regular accounting on the basis of which assessment can be made properly,
then the Assessing Authority shall assess the royalty to the best of its judgment and may impose for
each of the contravention, a penalty of 50% of annual Dead Rent as mentioned in column (5) of
Schedule IV.(7)If an assessee fails to submit monthly returns, under Form-XIV under sub-rule (2),
for any month within the prescribed time limit and if the Assessing Authority has reasons to believe
that the assessee has evaded or avoided payment of royalty, the Assessing Authority shall, after
giving to assessee a reasonable opportunity of being heard and after making such inquiry as it may
consider necessary, assess the royalty for the period to the best of its judgment which shall be
payable forthwith by the assessee.
Chapter XI
Penalty for Unauthorised Extraction and Transportation
71. Penalty for unauthorized extraction and transportation.
(1)Whenever any person is found extracting or transporting minerals or on whose behalf such
extraction or transportation is being made, otherwise than in accordance with these rules, shall be
presumed to be a party to the illegal extraction of minerals and every such person shall be
punishable with simple imprisonment for a term which may extend to one year or with fine which
may extend to twenty five thousand rupees or with both.(2)Whenever any person is found extracting
or transporting mineral in contravention of the provisions of these rules, the Collector/Joint
Director/ Deputy Director/Mining Officer/Assistant Mining Officer/Mining Inspector or any Officer
authorised by him or Zila Panchayat/Janpad Panchayat/Gram Panchayat, may seize the minerals
and its products together with all tools, equipments and vehicles used in committing such
offence.(3)The officer seizing such illegally extracted or transported mineral or its product, tools,
equipments and vehicles shall give a receipt of the same to the person from whose possession such
things were so seized and shall make report to the Magistrate having jurisdiction to try such
offence.(4)The property so seized under sub-rule (2) shall be released by the officer who seized such
property on execution of a bond to the satisfaction of the officer by the persons from whose
possession such property was seized. It shall be produced at such time and place when production is
asked for by such officer :Provided that where a report has been made to a Magistrate under
sub-rule (3) then the seized property shall be released only under the orders of such
Magistrate.(5)The Collector/Joint Director/Deputy Director/Mining Officer or any officer
authorised by Zila Panchayat/Janpad Panchayat/Gram Panchayats may, either before or after the
institution of the prosecution, compound the offence so committed under sub-rule (1) on payment of
market value of mineral so extracted or transported and such fine which may extend to double the
market value of mineral so extracted or transported, but in no case it shall be less than five thousand
rupees or ten times of royalty of minerals so extracted whichever is higher ;Provided that in case ofChhattisgarh Minor Mineral Rules, 2015

continuing contravention, the Collector/Deputy Director/Mining Officer may, in addition to the fine
imposed also recover an amount of one thousand rupees for each day till such contravention
continues.(6)Where an offence is compounded under sub-rule (5), no proceeding or further
proceeding, as the case may be, shall be taken against the offender in respect of the offence so
compounded, and the offender, if in custody, shall be released forthwith.(7)Any person who
trespasses on any land in contravention of these rules shall be served with an order of eviction by
the Collector.(8)All property seized under sub-rule (2) shall be liable to be confiscated, by an order
of the Magistrate trying the offence, if the amount of the fine and other sums imposed are not paid
within a period of one month from the date of the order :Provided that on payment of such sum
within one month of the order all property so seized shall be released except that the mineral or its
products, so seized mineral or its products under sub-rule (2) shall be confiscated and shall be the
property of the State Government.(9)The Authorities empowered to take action under this rule, if
deem necessary, request to the Police Authority in writing for the help of Police and the Police
Authorities shall render such assistance as may be necessary to enable the officer to exercise the
powers conferred on them by this rule to stop illegal extraction and transportation of
minerals.(10)(i)Subject to such conditions as may be specified, the Collector may authorise, either
generally or in respect of particular case or class of cases, any officer not below the rank of assistant
mining officer to investigate all or any offence punishable under this rule;(ii)Every officer so
authorised to conduct such investigation, shall exercise the powers conferred upon the
officer-in-charge of a police station by the Code of Criminal Procedure, 1973 (No. 2 of 1974) for the
investigation of a cognizable offence;(iii)The investigation officer for the purposes of this rule shall
exercise the powers of the Code of Civil Procedure, 1908 (No. 5 of 1908) in respect of the following
matters, namely-(a)Enforcing the attendance of any person and examining him on oath or
affirmation;(b)Completing production of documents.
72. Provision for maintaining records of consumption of minor minerals in
construction activities.
(1)Every person, company, firm, society/association engaged in construction of residential building
or buildings for sale and commercial building or buildings for sale/rental purpose shall maintain a
true account of all the Minor Minerals procured and used in construction under Form-XXIII and
shall submit to the officer-in-charge of the mining section of the concerned district, a quarterly
report of Minor Minerals procured and consumed under Form-XXIV so as to reach them within
thirty days after the expiry of every quarter.(2)Every person, company, firm, society/association
engaged in construction of residential building or buildings for sale and commercial building or
buildings for sale/rental purposes shall allow District Collector/ District Mining Officer or any other
officer authorised by the Collector of the concerned District, to enter upon any premises/area of
construction or storage of construction material for the purpose of inspection of the minerals, stored
or used in the construction.
73. Suspension of quarrying operations.
- The Director/District Collector or any other officer authorised by the Director, in this behalf, shall
prohibit Prospecting/Quarrying Operation and seize minerals, equipment, tools and vehicles in caseChhattisgarh Minor Mineral Rules, 2015

the Prospecting/Mining Operations are being carried out in contravention of the terms and
conditions of the Prospecting Licence, Quarry Lease or Quarry Permit granted under these rules or
without any lease or permit irrespective of minerals, tools, equipment and vehicles lying at site or in
transit:Provided that an opportunity of hearing shall be given before prohibiting the
Prospecting/Quarrying Operation.
Chapter XII
Minor Mineral Offences Prevention Award
74. Awards.
(1)Any officer of Directorate, Geology and Mining, Chhattisgarh furnishing information leading to or
otherwise contributing to the prosecution of offence in respect of illegal mining and transport, or of
offences otherwise committed against the Act and the rules, may be granted awards.(2)Awards may
be granted only in cases when the information furnished is useful to impose penalty under the
rules.(3)Conditions and extent of award. - The awards may be granted under these rules shall be in
cash, subject to the following conditions-(i)Where minerals are seized.-The maximum amount of an
award shall be 5% of the sale value of the seized mineral after realisation or ten thousand rupees,
whichever is less;(ii)Where no mineral is seized.-A maximum amount of an award shall be 5% of the
penalty amount realized.(4)Awards under these rules cannot be claimed as a matter of right. No
appeal lies to any authority on any award made by the Competent Authority under these rules.
75. Authority and mode of awards.
(1)The power to grant awards shall vest with the Director.(2)The case or proposal to make an award
shall be examined and decided by a committee consisting of the Director with two other officers of
bis Directorate nominated by him.(3)The award shall be drawn on Form-XXXIV of the Chhattisgarh
Treasury Code, Volume-II by the drawing and disbursing officer who disburses the pay and
allowances of the Government servant concerned.
Chapter XIII
Disbursement of Revenue amongst Janpad Panchayats and
Gram Panchayats
76. Deposition of revenue.
(1)The revenue alongwith interest from Minor Minerals, under the provisions of these rules, within
the control of Municipal Corporation, Municipality, Nagar Panchayat or Panchayats shall be first
deposited in the Consolidated Fund of the State as per sub-rule (3) of rule 31. The State Government
at the beginning of the financial year shall, if the Legislative Assembly has provided for an
appropriation, draw from the Consolidated Fund, all such amounts which are to be distributed fromChhattisgarh Minor Mineral Rules, 2015

the revenue of the minor minerals received in the preceding financial year.(2)The amount drawn
under sub-rule (1) shall be distributed for development of the areas affected by mining and related
operation of minor minerals as per the directions and procedure prescribed by the State
Government.(3)Sub-rule (1) shall not apply to the revenue received from Minor Mineral "Ordinary
sand and bajri", which is directly deposited to the Municipal Corporation/ Municipality/Nagar
Panchayat or Panchayats.
Chapter XIV
Appeal, Revision and Review
77. Appeal, appellate authorities.
(1)Where any power is exercisable by Gram Panchayat, Janpad Panchayat or Zila Panchayat, under
these rules in relation to any matter, an appeal shall lie from every such order to the authority
mentioned in the Chhattisgarh Panchayat (Appeal and Revision) Rules, 1995 and in the same
manner as prescribed therein.(2)Where any power is exercisable by the Collector under these rules,
in relation to any matter, an appeal shall lie from every such order to the Director, Geology and
Mining, Chhattisgarh.(3)Where any power is exercisable by the Director under these rules, in
relation to any matter, an appeal shall lie from order passed under these rules to the State
Government.
78. Revision.
- The State Government and Director may at any time, suo-moto for the purpose of satisfying itself
as to the legality or propriety of any order passed by or as to the regularity of the proceedings of any
officer subordinate to it, call for and examine the record of any case pending before or disposed of by
such officer and may pass such order in reference thereto as it thinks fit:Provided that any order in
revision under this rule shall not be varied or reversed unless reasonable opportunity of being heard
is given to the interested parties.
79. Review.
- The State Government may, suo-moto or on application of interested parties, review its original
order within ninety days from the date of issue of original order and may pass such order as it deems
fit:Provided that any order in review under this rule shall not be varied or reversed unless
reasonable opportunity of being heard is given to the interested parties.
80. Limitation of appeal.
- No appeal shall be entertained unless presented within sixty days from the date of the order and in
computing the period aforesaid, time requisite for obtaining a copy of the said order shall be
excluded :Provided that any such appeal may be entertained by an Appellate Authority after the saidChhattisgarh Minor Mineral Rules, 2015

period, if the appellant satisfies authority that he has sufficient cause for not making the application
for appeal within time.
81. Application for appeal.
(1)An application for appeal shall be made in triplicate under Form-XXV appended to these rules.
The application for appeal shall be accompanied by a non-refundable application fee of rupees one
thousand shall be deposited, in the Government Treasury under the revenue receipt head as
mentioned in sub-rule (3) of Rule 31 and the original treasury receipted challan shall be attached to
the application.(2)The application for appeal shall be affixed with a court fee stamp of the value of
ten rupees.(3)Every application for appeal under sub-rule (1) against the order refusing to grant a
Quarry Lease, any person to whom a Quarry Lease was granted in respect of the same area or part
thereof, shall be impleaded as party.(4)Alongwith the application for appeal under sub-rule (1), the
applicant shall submit as many copies thereof as there are parties impleaded under sub-rule (3).
82. Copies of application of appeal to be sent to impleaded parties.
- On receipt of the application for appeal and the copies thereof, the Appellate Authority shall send a
copy of the application for appeal to each of the parties impleaded under sub-rule (3) of rule 81
specifying the date on or before which he may make his representation, if any, against the appeal
application.
83. Order on appeal application.
- Where an application for appeal is made under these rules, the authority may confirm, modify or
set aside the order or pass such other order in relation thereto as it may deem just and proper.
84. Grant of stay.
- The Appellate authority may at any time direct that the execution of the order against which an
appeal is pending be stayed for such time as it may deem fit:Provided that no stay for the recovery of
mining dues shall be granted unless the party seeking stay has paid the undisputed amounts of
rents, royalties and interest due thereon and has furnished bank guarantee for the disputed amounts
of such rent, royalty and interest.
Chapter XV
Miscellaneous
85. Power to rectify apparent mistakes.
- The Competent Authority may. at any time within six months from the date of the order passed by
it under these rules on its own motion, rectify any mistake or error apparent on the face of theChhattisgarh Minor Mineral Rules, 2015

record and shall, within the like period, rectify any such mistake or error which has been brought to
its notice by an applicant for the grant of quarry :Provided that no such rectification having or
purported to have a prejudicial effect on another application for the grant of the Prospecting
Licence/Quarry Lease shall be made unless the Competent Authority has given to such applicant
notice of its intention to do so and has allowed him reasonable opportunity of being heard.
86. Relaxation of rules in special cases.
- In any case or class of cases in which the State Government is of the opinion that the public
interest so requires, it may grant a Prospecting Licence/Quarry Lease on the terms and conditions
other than those prescribed in these rules.
87. Handing over possession of quarry.
(1)Where Quarry Lease is cancelled or determined or right of pre-emption is exercised or the period
for which the lease is granted has expired, the lessee shall hand over possession of quarry to the
Collector or any officer authorised by him or to Zila Panchayat/Janpad Panchayat/Gram Panchayat
within a period of fifteen days of the cancellation of the lease or determination of the lease or
exercise of the right of pre-emption or the day immediately following the date of expiry of the lease,
as the case may be.(2)Where a lessee fails to hand over possession of the quarry in accordance with
sub-rule (1), the Collector or the Officer authorized by him or Zila Panchayat/Janpad
Panchayat/Gram Panchayat shall serve or cause to be served a notice on the lessee, either by post or
by tendering or delivering a copy of it personally to the lessee or one of his family members or
servants or by affixing it to a conspicuous part of the place of his residence or publishing it in atleast
one newspaper having circulation in the locality where the lessee resides.(3)Notice under sub-rule
(2) shall contain a statement that the lessee shall hand over possession of the quarry within a period
of fifteen days from the date of service of the notice to an officer authorised by him under sub-rule
(1) of this rule. Where a lessee fails to hand over possession of a quarry within the period specified in
the notice under sub-rule (2), to the officer authorised under sub-rule (1) of this rule, he may take
possession of the quarry from the lessee and for that purposes may use such force as prescribed by
the provisions under these rules.
88. Payment of compensation to owner of surface rights, etc.
- The holder of a Prospecting Licence or Quarry Lease or Quarry Permit shall be liable to pay to the
occupier of the: surface of the land, over which he holds the Prospecting Licence or Quarry Lease or
Quarry Permit, as the case may be, such annual compensation as may be determined by the
Collector of the concerned district.
89. Delegation of powers and functions.
- The State Government, may by notification in the Official Gazette, direct that any power or
function which may be exercised or performed by it under these rules, may in relation to suchChhattisgarh Minor Mineral Rules, 2015

matters subject to such conditions, if any, as it may specify in the notification, be exercised or
performed also by such officer or authority subordinate to the State Government as may be specified
in the notification.
90. Repeal.
- All rules or executive instructions corresponding to these rules in force immediately before the
commencement of these rules are hereby repealed :Provided that anything done or any action taken
under the rules or instructions so repealed shall, so far as they are not inconsistent with the
provisions of these rules, be deemed to have been done or taken under the corresponding provisions
of these rules.
I
Specified MineralsPart-A
1. Dimensional stone-granite, dolerite, and other igneous, sedimentary and
metamorphic rocks which are used for cutting and polishing purpose for
making blocks, slabs, tiles of specific dimension.
2. Marble which is used for cutting and polishing purpose for making blocks,
slabs, tiles of specific dimension.
Part-B 1. Agate;
2. Ball Clay;
3. Barytes;
4. Calcareous Sand;
5. Calcite;
6. Chalk;
7. China Clay;
8. Clay (Others);Chhattisgarh Minor Mineral Rules, 2015

9. Corundum;
10. Diaspore;
11. Dolomite;
12. Dunite or pyroxenite;
13. Felsite;
14. Felspar;
15. Fireclay;
16. Fuschite Quartzite;
17. Gypsum;
18. Jasper;
19. Kaolin;
20. Laterite;
21. Limekankar;
22. Mica;
23. Ochre;
24. Pyrophyllite;
25. Quartz;
26. Quartzite;
27. Sand (Others);Chhattisgarh Minor Mineral Rules, 2015

28. Shale;
29. Silica Sand;
30. Slate; and
31. Steatite or Talc or Soapstone.
Part-C 1. Low grade limestone when used in kilns for manufacture of lime and/or as building
material for building, road and other construction work.
2. Flag stone-natural sedimentary rock which is used for flooring, roof top,
etc. and used in cutting and polishing industry.
3. Stone for making gitti by mechanical crushing (i.e. use of crusher).
4. Bentonite/Fuller's earth.
5. Ordinary clay for making bricks or tiles by fixed chimney kiln.
II
Other MineralsPart-A 1. Ordinary clay for making bricks, pots, tiles etc. (Except by fixed chimney).
2. Stone, Boulder, Road Metal, Gitti, Dhaka Khanda, Dressed Stones, used as
Rubble, Chips.
3. Murrum.
4. Gravel.
5. Reh Mitti.
6. Slate, when used for building material.
7. Shale, when used for building material.
8. Quartzite and quartzite sand, when used for purposes of building or for
making road, metal or house-hold utensils.Chhattisgarh Minor Mineral Rules, 2015

9. Salt petre.
Part-B 1. Ordinary Sand and Bajri.
III
[See rule 49]Rates of Royalty
S. No. Mineral Rates
(1) (2) (3)
1.DimensionalStone-Granite, dolerite, and other igneous, sedimentary
andmetamorphic rocks which are used for cutting and polishingpurpose
for making blocks, slabs, tiles of specific dimension(a) Black colour(b)
Other colourRs. 1500/- per
cubic metre Rs.
500/- per
cubicmetre
2.Marble, used for cutting and polishing purposefor making blocks slabs,
tiles of specific dimension.Rs. 750/- per
cubic metre
3. Marble stone used for other purposesRs. 350/- per
cubic metre
4.Flagstone-natural sedimentary rock which is usedfor flooring, roof top,
etc.Rs. 103/- per
cubic metre
5. Ordinary Sand, bajriRs. 20/- per
cubic metre
6. MurrumRs. 20/- per
cubic metre
7. Stone(a) Boulder(b) Gitti, road metal(c) Dressed Stone, Khanda, DhokaRs. 103/- per
cubic metre
8. Soil-for making bricks and tilesRs. 20/- per
cubic metre
9. Other minor mineralsRs. 30/- per
cubic metre
IV
[See rule 49]Rates of Dead Rent (in Rupees Per Hectare Per Annum)
S.
No.Category of MineralFirst year
of the
Quarry
LeaseSecond year to
third year of
the Quarry
LeaseFourth year of
the Quarry
Lease and
onward
(1) (2) (3) (4) (5)
1. Dimensional stone-Granite, dolerite, and
otherigneous, sedimentary and metamorphicNil 10,000 15,000Chhattisgarh Minor Mineral Rules, 2015

rocks which are used forcutting and polishing
purpose for making blocks, slabs, tiles ofspecific
dimension
2.Marble used for cutting and polishing purposefor
making blocks, slabs, tiles of specific dimension
and marblestone for other purpose.Nil 5,000 7,500
3.Low grade limestone when used in kilns
formanufacture of lime and/or as building
material for building,road and other construction
works.Nil 5,000 7,500
4.Flagstone-Natural sedimentary rock which is
usedfor flooring, roof top, etc.Nil 5,000 7,500
5. Stone for crusher Nil 5,000 7,500
6. Ordinary sand, bajri Nil 5,000 7,500
7. Murrum Nil 2,000 3,000
8.Stone for building purposes and other
minormineralsNil 2,000 3,000
Form I[See rule 7 (1)]"To be submitted in Triplicate"Application for the Grant of Prospecting
Licence for Minor MineralsReceived at............(Place) on the...............day of.......20.....
  
Date.................20.....To,The Collector.........................................District.......................Chhattisgarh
1. I/We request that a Prospecting Licence under the Chhattisgarh Minor
Mineral Rules. 2015, be granted to me/us.
2. A sum of Rupees.....................as application fee payable under the rules
has been deposited vide challan No.....................Dated.........place.......
3. The required particulars are given below:-
(i) Name of applicant ….................................................................................
(ii)Nationality of the applicant
(Partners,Directors, Members)….................................................................................
(iii)Place of registration or incorporation
(Firm,Company or Society/ Association)….................................................................................
(iv)Profession of individual, nature of
business ofFirm or Company or
Society/Association and place of
business.….................................................................................
(v) Complete postal address, of the
individual,firm, company or society/….................................................................................Chhattisgarh Minor Mineral Rules, 2015

association
 Pin Code ….................................................................................
 Phone/Mobile number ….................................................................................
 E-mail ….................................................................................
(vi)Self attested copy of PAN card/voter
ID/drivingLicence/Aadhar card of
individual, Partners, Directors, Members….................................................................................
(vii)Caste (individual or members
ofSociety/Association)….................................................................................
(viii)Educational qualification (individual or
membersof Society/ Association)….................................................................................
(ix)Age (individual or members
ofSociety/Association)….................................................................................
(x)Residence address (individual or
members ofSociety/Association)….................................................................................
(xi) List of Directors/Partners/ Members ….................................................................................
(xii) Registration/incorporation certificate ….................................................................................
(xiii) Financial Status ….................................................................................
(xiv)Articles of memorandum/
partnershipdeed/bye-laws….................................................................................
(xv)Mineral/Minerals which the applicant
intends toprospect….................................................................................
(xvi)Period for which the prospecting licence
isrequired.….................................................................................
4. A statement supported by an affidavit showing all the areas of prospecting
licence, mineral wise in each district of the State,-
(i)already held by me/us in my/our name/names (and jointly with others) under the prospecting
licence for minor minerals,(ii)already applied for but not yet granted, and(iii)being applied for
simultaneously.
5. An affidavit of obtaining surface rights.
6. No dues certificate in Form II.
7. (a) A plan (six copies) showing the situation and boundaries of the
area/areas applied for and concession, if any, adjoining is/are enclosed. (If
this plan/these plans be considered insufficient, I/We request that the
necessary plan/plans of the area/areas may be prepared in duplicate in your
office at my/our cost.)Chhattisgarh Minor Mineral Rules, 2015

(b)Khasrapanchsala
8. The plan should indicate important features, viz.-
(i)if a railway, its full details i.e. whether South East Central Railway or East Coast Railway, whether
a branch line or a main line or colliery tramway,(ii)if a road, whether village or public works
department or cart track,(iii)wells,(iv)temples or mosques.(v)burning ghat or burial ground, etc.
9. Preferential right sought for (mention sub-rule/rules)
10. Any other particulars which the applicant wishes to furnish.
Schedule 5
Description of the area applied for :-(i)Name of village(ii)Gram Panchayat(iii)Khasra number and
area of each field or part thereof
Khasra number Area in Hectares
  
(iv)Full description of the area applied for with regard to natural
feature-(v)Block,(vi)Vidhansabha(vii)Tehsil(viii)Patwari circle number(ix)District
11. List of enclosures :-
(i)(ii)(iii)(iv)(v)(vi)(vii)(viii)(ix)(x){||-| Place.....................| Your faithfully,|}Dated...................Name
and DesignationN.B. -• If the application is signed by an authorized representative of the applicant,
power of attorney should be attached.• If all the Khasra number cannot be entered on this form they
should be continued on a separate sheet attached to it and signed.• Where a portion of a khasra
number only is required the approximate area of such portion will suffice.Form II[See rules 7 (2)
(b); 23 (xii)]No Dues CertificateOffice of issue.............
No.................District..................... Date..................
This is to certify that the following mineral concessions are held by Shri/M/s...................in
district...................(Prospecting Licence/Mining Lease/Quarry Lease/Quarry Permit, etc.)
Village Tehsil Mineral Area in hectares
(1) (2) (3) (4)
    
Total Dues Assessed (in Rupees) Period
Surface Rent Dead Rent Royalty Others  
(5) (6) (7) (8) (9)
     Chhattisgarh Minor Mineral Rules, 2015

Amount paid during the period from.......to.......in rupees
Surface Rent Dead Rent Royalty Others Total
(1) (2) (3) (4) (5)
Balance Dues :-     
1.     
2.     
3.     
1. In case there has been no assessment in any year, it must be stated clearly
with reasons thereof.
2. It must be stated whether any attachment or R.R.C. are pending in respect
of this lease.
3. This is valid only for six months from the date of issue.
Signature and Designation of authorized officer with seal of office.Form III[See rules 8; 35 (2); 58
(1) (iii)]Receipt of Application for Prospecting Licence/Quarry Lease/ Quarry Permit or Renewal for
Minor Minerals
S. No.................Date.............. Time...........................
Received application with the following enclosures for grant/renewal of...................... from
Shri/Sarvashri...................on..........20....for about........................hectares of land located in
Village....... Panchayat.......... Tehsil............ District......., Chhattisgarh
for................Mineral.Enclosures:-(1)..............................................(2)..............................................(3)..............................................(4)..............................................(5)..............................................(6)..............................................(7)..............................................(8)..............................................(9)..............................................(10)..............................................Place
:..................
Date:............................. Signature..........................
Name...........................(Seal of the receiving officer)Form IVProspecting Licence Deed for Minor
Minerals[See rule 14]This indenture made on this..............day of.......20.....between the Governor of
the State of Chhattisgarh (hereinafter referred to as the Government which expression shall, where
the context so admits be deemed to include his successors and assigns) of the one partandWhen the
Licensee is an individual......................(Name of person with address and occupation) (hereinafter
referred to as the 'Licensee' which expression shall where the context so admits be deemed to
include his heirs, executors, administrators, representatives, and permitted assigns)When the
Licensees are more than one individual......................(Name of person with address and occupation)
and.............................. (Name of person with addresses and occupation) and ...........................(Name
of person with addresses and occupation) (hereinafter referred to as the "Licensee" which
expression shall, where the context so admits be deemed to include their respective heirs, executors,
administrators, representatives and permitted assignee).When the Licensee is a registered
Firm..................(Name and address of partner) and...............................(Name and address of
partner) and........................(Name and address of partner) All carrying on business in partnership
under the firm name and style of (Name of the Firm)......................registered under the Indian
Partnership Act, 1932 (9 of 1932) and having their registered office at......................in the town ofChhattisgarh Minor Mineral Rules, 2015

......................... (hereinafter referred to as the "the Licensee" which expression shall, when the
context so admits be deemed to include all the partners of the said firm, their respective heirs,
executors, legal representatives and permitted assignee).When the Licensee is a registered
Company..........................(Name of the Company) a Company registered under ...................... (Act
under which incorporated) and having its registered office at ..................(Address) (hereinafter
referred to as the "the Licensee" which expression shall, where the context so admits be deemed to
include its successors and permitted assignee) of the other part.Whereas the Licensee/Licensees
has/have applied to the State Government in accordance with the Chhattisgarh Minor Mineral
Rules, 2015 (hereinafter referred to as the said rules) for a licence to prospect for..................(minor
mineral) in the land specified in Schedule-'A' hereunder written and delineated in the plan herewith
annexed (hereinafter referred to as the said lands) and has/have deposited with the State
Government the sum of Rupees ....................as prescribed security in respect of such licence.Now
these presents witness as follows :Part-IIn consideration of the fees, royalties, covenants and
agreements hereinafter reserved and contained and on the part of the Licensee/Licensees to be paid,
observed and performed, the State Government, hereby, grants and demise into the
Licensee/Licensees, the sole rights and the licence.To enter upon the lands and to search for, win,
carry away and dispose of mineral won :-(1)To enter upon the said lands and to search for by
mining, boring and digging or otherwise all or any...............(Name of minerals) lying or being within
under or throughout the said lands;(2)This licence shall not confer upon the Licensee a right to win
or carry away the minerals for commercial purposes :Provided that the Licensees may collect and
carry away upto five cubic meter of ...............(Name of mineral) for the purposes of testing as
specified in rule 16 (4) after obtaining transit pass for transportation of mineral on payment of
royalty.To clear undergrowth, brushwood etc.:-(3)Subject to the provisions of clauses (4) and (5) of
Part-II of these presents, for the purpose aforesaid, to clear undergrowth and brushwood and trees
with the sanction of the Collector, previously obtained in writing, to make and use any drains or
water courses on the said lands for purposes as may be necessary for effectually carrying on the
prospecting operations and for the workmen employed thereon and with the like sanction to use any
water. Provided that such use shall not diminish or interfere with the supply of water to which any
cultivated land, village, building or watering place for livestock has heretofore been accustomed and
that no streams, springs or well shall be fouled or polluted by any such use or the prospecting
operations hereby Licensed.To bring upon and erect machinery etc., on the said lands :-(4)To erect
and bring upon the said lands all such temporary huts, sheds and structures, steam sand, other
engine machinery and conveniences, chattels and effects as shall be proper and necessary for
effectually carrying on the prospecting operations hereby Licensed or for the workmen employment
thereon.Reserved nevertheless to the State Government, full power and liberty at all times to enter
into and upon and to grant or demise to any person or persons whomsoever liberty to enter into and
upon the said lands for all or any purposes other than those for which sole rights; andLicence are
hereby expressly conferred upon the Licensee/Licencees and particularly (and without hereby in any
way qualifying such general power and liberty) to make on, over or through the said lands such
roads, tramways and ropeways as shall be considered necessary or expedient for any purposes and
to obtain from and out of the said lands such stone, earth or other materials as may be necessary or
requisites for making, repairing or maintaining such roads, tramways, railways and ropeways to
pass and re-pass at all times over and along such roads, tramways, railways and ropeways for all
purposes and as occasion shall require;To hold the said right and licence unto theChhattisgarh Minor Mineral Rules, 2015

Licensee/Licensees from the date of these presents for the term of one year.Part-II Covenants by
Licensee / LicenseesThe Licensee/Licensees hereby covenants/covenant with the State Government
as follows :-Payment and rates of royalty :-(1)To pay royalty to the State Government at such rates
as specified in Schedule-III of the said rules and in advance for experimental purposes.To carry on
work in workman like manner :-(2)To work and carry on the operations, hereby, Licensed in a fair
orderly skilful and workman like manner and with as little damage as may be to the surface of the
lands and to trees, crops, buildings, structures and other property thereon;To undertake prospecting
in Khatedari or any private land with the consent of Khatedar or occupier or owner of such land;Not
to enter upon any land in the occupation of any person without the consent of the occupier nor to
cut or in any way injure any trees, standing crops, buildings, huts, structures or property of any kind
of the occupier of any land or any other person without the written consent of such owner, occupier
or person.Maintenance of correct accounts :-(3)every Licensee shall maintain a correct and faithful
account of all the expenses incurred by him on prospecting operations and also the quantity and
other particulars of all minerals obtained during such operations and their despatch;No prospecting
operations within restricted distance from bridge, road etc.:-(4)The Licensee/Licensees shall not
work or carry on or allow to be worked or carried on any prospecting operations at or to any points
within a distance of 100 meters from any bridge, national or state highways, railway line, 50 meters
from the road constructed under Pradhan Mantri Gram Sadak Yojana, other District Roads of Public
Works Department; and 10 meters from grameen kachcha rasta; or 50 meters from any public place
except village path;Not to enter and cut or injure trees in forest land, etc. without previous
permission :-(5)(i)Not to enter and cut or injure any timber or tree on any forest land except in
accordance with the provisions of the Forest (Conservation) Act, 1980 and guidelines issued by the
Central Government, from time to time.(ii)Not to enter upon or commence prospecting in any forest
land without obtaining the prior written sanction of the authorized Forest Officer and in accordance
with such conditions as may be prescribed in such sanction as per provisions of the Forest
(Conservation) Act, 1980 and guidelines issued by the Central Government, from time to time, in
this regard.Indemnify Government against all claims :-(6)(a)To make reasonable satisfaction and
pay such compensation as may be assessed by lawful authority in accordance with the law in force
on the subject for all damage, injury, or disturbance which may be done by him in exercise of the
powers granted by this licence and to indemnify and keep indemnified fully and completely the State
Government against all claims which may be made by any person or persons in respect of any such
damage, injury or disturbance and expenses in connection therewith.(b)To pay a wage not less than
the minimum wage prescribed by the Central or State Government, from time to time.(c)To comply
with the provisions of the Mines Act, 1952.(d)To comply with the provisions of the Chhattisgarh
Minor Mineral Concessions Rules, 2015.(e)To take measures, at his own expense, for the protection
of environment like planting of trees, reclamation of mines land, use of pollution control devices and
such other measures as may be prescribed by the Central or State Government, from time to
time.(f)To pay compensation to the occupier of the surface of the land on the date and in the manner
laid down in these rules.Forfeiture of security deposit, etc.:-(7)Whenever the security deposit of
Rs..............or any part thereof or any further sum hereafter deposited with the State Government in
replenishment thereof shall be forfeited or applied by the State Government. Pursuant to the power
hereinafter declared in that behalf, the Licensee/Licensees shall forthwith deposit with the State
Government such further sum as may be sufficient with the un-appropriated part thereof to bring
the amount in deposit with the State Government up to the sum of Rupees.......Licensee not to beChhattisgarh Minor Mineral Rules, 2015

controlled by trust, syndicate, etc. :-(8)The Licensee/Licensees shall not be controlled or permit
himself/ themselves to be controlled by any trust, syndicate, corporation, firm or person except with
the written consent of the State Government.Report of accident:-(9)The Licensee/Licensees shall
within twenty-four hours send to the Director, Geology and Mining, Collector of concerned district a
report of any accident causing death or serious bodily injury to property or seriously affecting or
endangering life or property which may occur in the course of the prospecting operation under this
licence.(10)The Licensee, in case f prospecting of granite and marble, shall abide all the provisions
of the Granite Conservation and Development Rules, 1999 and the Marble Development and
Conservation Rules, 2002 and the rules as amended from time to time, as the case may be, and shall
not carry on estimation or other operations under the said Licence in any way other than as
prescribed under these rules.Plugging of bore holes, fencing etc., and restoring the surface land after
determination or abandonment:-(11)Save in the case of land over which the Licensee/Licensees
shall have been granted, a Quarry Lease, on or before the expiration or sooner determination of the
licence, he shall within three months next after the expiration or sooner, determination of the
licence or date of abandonment of the undertaking, whichever shall first occur, securely plug any
bore or hole and fill up or fence any holes or excavations that may have been made in the lands to
such an extent, as may be required by the Collector concerned and shall to a like extent restore the
surface of the land and all buildings there on which may have been damaged or destroyed in the
course of prospecting. Provided that Licensee/Licensees shall not be required to restore the surface
of the land, or any building in respect of which full and proper compensation has already been
paid.Removal of machinery etc., after expiration, determination or abandonment :-(12)Upon
expiration or sooner determination of this licence, the Licensee/Licensees shall remove
expeditiously not later than thirty days at his/ their own cost all buildings, structure, plant, engines,
machinery implements, utensils and other property and effects therefore erected or brought by the
Licensee/Licensees and then standing or being upon the said lands by the Licensee/ Licensees
under the authority of these presents and then being upon the said lands :Provided that this
covenant shall not apply to any part of the said lands which may be comprised in any Quarry Lease
granted to the Licensee/Licensees. If the machinery etc. is not removed within-specified period then
it shall be deemed to have become Government property.Report of work done before the refund of
security deposit.:-(13)At any time before the said security deposit as refunded to him/them or
transferred to any other account or within one month after the expiration or sooner determination
of the license or abandonment of the operations, whichever is earlier, the Licensee/Licensees shall
submit to the Director and concerned Collector a full report of the work done by him/them and
disclose all information acquired by him/them in the course of the operations carried on under this
licence regarding the geology and mineral resources of the area covered by the licence.Report of
information obtained by Licensee :-(14)The Licensee shall submit to the State Government within
ninety days of the expiry of the licence, or abandonment of operations or termination of the licence,
whichever is earlier, a final report of the work done by him and all information relevant to mineral
resources acquired by him in the course of prospecting operations in the area covered by the licence.
Final report shall indicate the quality and quantity of proved and probable reserves of
mineral.Part-III Powers of the GovernmentIt is hereby agreed as follows :-Cancellation of the
licence and forfeiture of the security deposit in case of breach of conditions :-(1)In the case of any
breach of any condition of the licence by the Licensee/Licensees or his assignees, the competent
authority shall give a reasonable opportunity to the Licensee/Licensees of stating him/their case andChhattisgarh Minor Mineral Rules, 2015

where it is satisfied that the breach is such as cannot be remedied, on giving thirty days notice to the
Licensee/Licensees or his assignees, determine the license and/or forfeit the whole or any part of
the said security deposit of rupees..............deposited under the covenant in that behalf as the
Competent Authority may deem fit. In case the Competent Authority considers the breach to be of a
remediable nature, it shall give notice to the Licensee /Licensees or his assignees, as the case may
be, requiring him/them to remedy the breach within fifteen days from the date of receipt of the
notice informing him of the penalty proposed to be inflicted if such remedy is not made within such
period. If the breach is not remedied within prescribed period the licence shall be cancelled with
forfeiture of the security deposit.Part-IV Right of Licensee/LicenseesIt is hereby further agreed as
follows :-Preferential right of the Licensee/Licensees for obtaining Quarry Lease :-(1)Where a
Prospecting Licence has been granted in respect of any land, the Licensee shall have a preferential
right for obtaining a Quarry Lease in respect of that land over any other persons, provided that the
sanctioning authority is satisfied that the licensee/licensees, has/have undertaken prospecting
operations to establish reserves in such land; has not committed any breach of the terms and
conditions of the prospecting licence; and is otherwise a fit person for being granted the Quarry
Lease.Refund of deposit:-(2)Security deposit made under rule 13, if not forfeited under these rules,
shall be refunded to the applicant as soon as the report referred under rule 16(8) (a) is
submitted.Part-V General ProvisionsIt is lastly agreed as follows :-Delay in fulfilment of the terms of
licence due to force majeure :-Discovery of new mineral:-(1)The Licensee shall report to the
Collector and Director or any officer authorized by him, the discovery of any mineral not specified in
the licence within a period of thirty days from the date of such discovery and shall not undertake any
prospecting operations in respect of such mineral unless such mineral is included in the
licence.Provided that in case of discovery of any mineral not specified as minor mineral, the
Licensee shall have no right for including that mineral in the licence under these rules.Service of
notices :-(2)Every notice required to be given to the Licensee/Licensees shall be given in writing to
such person as the Licensee/ Licensees may appoint for the purpose of receiving such notices or if
no such appointment is made then the notice shall be sent to the Licensee/Licensees by registered
post addressed to him/them at the address shown in his/their application for the licence or at such
other address in India as he/they designate from time to time and every such service shall be
deemed to be proper and valid service upon the Licensee/Licensees and shall not be questioned or
challenged by him.Immunity of Competent Authority from liability to pay compensation :-(3)If in
any event the orders of the Competent Authority are revised or cancelled by the Director and State
Government in pursuance of proceedings under Chapter XIV of the Chhattisgarh Minor Mineral
Rules, 2015, the Licensee/Licensees shall not be entitled to compensation for any loss sustained by
the Licensee/Licensees in exercise of the powers and privileges conferred upon him/them by these
presents.In witness whereof these presents have been executed in the manner hereunder appearing
the day and year first above written.
A
The land covered by the Licence(Here insert the description of lands with area, boundaries names of
District, Sub-Division, Thana, etc. and cadastral survey numbers, if any. In case a map is attached,
refer the map in the description to be inserted.)Description of the land covered by the licence
:-(i)District(ii)Sub-division(iii)Tehsil(iv)Thana(v)Patwari circle number(vi)Name of villageChhattisgarh Minor Mineral Rules, 2015

S. No. Cadastral survey numbers Area in Hectare
1.   
2.   
3.   
Total  
................................... .............................................................Signature
Signature by LicenseeBy order and on behalf of the Governor
ofChhattisgarh
Licensees Signature  
 (Designation)
Witnesses :-(1)Signature..........................Name .............................S/o or ID/o or
W/o................Address...........................(2)Signature........................Name .....................................S/o
or D/o or W/o.......................Address..................................Form V[See rule 15(1)]Register of
application for Prospecting LicenceDistrict............................
1. Serial No.
2. Date on which application was received by receiving officer.
3. Name of applicant with complete address, phone no., email.
4. Situation and boundaries of the land applied for :
(i)Name of the village(ii)Name of Gram Panchayat(iii)Block(iv)Vidhansabha(v)Tehsil(vi)Patwari
circle number(vii)Khasra Number
5. Area in Hectares (Khasrawise)
6. Particulars of minerals which the applicant desires for prospecting.
7. Application fee paid.
8. Remarks (preferential right sought for).
9. Final disposal of applications together with number and date of the order.
10. Signature of the officer.
Form VI[See rule 15 (2)]Register of Prospecting LicenceDistrict....................Chhattisgarh Minor Mineral Rules, 2015

1.Serial No.  
2.Name of the licensee with complete address,phone no.,
email. 
3.Date of application and serial number inapplication
register. 
4.Situation and boundaries of the land.  
5.Mineral for which licence has been granted.  
6.Number and date of grant order of licence withauthority.  
7.Situation and boundaries of the licence granted. ….......................................................
8.Name of the village. ….......................................................
9.Name of Gram Panchayat. ….......................................................
10.Block. ….......................................................
11.Vidhan Sabha. ….......................................................
12.Tehsil. ….......................................................
13.Patwari circle number ….......................................................
14.Khasra Numbers. ….......................................................
15.Area in hectares for which licence has beengranted. ….......................................................
16.Date of execution of licence. ….......................................................
17.Period for which granted. ….......................................................
18.Details of licence fee paid. ….......................................................
19.Amount of security deposit. ….......................................................
20.Date of submission of prospecting report anddetails of
reserve and grade proved.….......................................................
21.Particulars of disposal or of refund of securitydeposit.  
22.Date of application for Quarry Lease (if any).  
23.Remarks.  
24.Signature of the Officer.  
Form VII[See rule 16 (ii))Notice of commencement of Prospecting operationsImportant : This Form,
duly filled in must reach the concerned authorities within fifteen days of the commencement of
Prospecting operations.To,
1. Director
Geology and Mining Chhattisgarh..............................Raipur, Chhattisgarh
2. The Collector
District...................ChhattisgarhChhattisgarh Minor Mineral Rules, 2015

1.Name of the mineral or minerals for
whichProspecting Licence has been
granted.…...............................................................  
2. Name of the licensee …...............................................................  
 complete address, …...............................................................  
 phone no., …...............................................................  
 email. …...............................................................  
3. Particulars of Prospecting Licence :   
 (i) Date of execution …...............................................................  
 (ii)
Period:...........years,from..............to........  
 (iii)Area under licence..............hectares.   
4.Location of the Prospecting Licence Area
:  
 (i) Survey of India, Topo Sheet Number …...............................................................  
 (ii) District and Tahsil …...............................................................  
 (iii) Block …...............................................................  
 (iv) Name of Gram Panchayat …...............................................................  
 (v) Patwari circle number …...............................................................  
 (vi) Name of the village …...............................................................  
 (vii) Khasra Number …...............................................................  
 (viii) Area in hectare …...............................................................  
5.Particulars of Geologist or Mining
Engineeremployed for the Prospecting
Licensed area :  
 (i) Name and address …...............................................................  
 phone no. …...............................................................  
 email. …...............................................................  
 (ii) Qualifications …...............................................................  
 (iii) Date of appointment …...............................................................  
 (iv) Nature of appointment : Whole
time/ Parttime.…...............................................................  
6.Date of commencement of Prospecting
Operations: 
 .......th day month....................year  
Place:  Signature:
Date :  Name in full:
   Designation:
Owner/Agent/Chhattisgarh Minor Mineral Rules, 2015

   Mining
Engineer/Manager
Form VIII[See rule 16(viii) (a)|Final Report of Prospecting Operations carried out for Minor
MineralImportant: This Form, duly filled in must reach the concerned authorities within ninety
days after expiration of one year from the date of execution of prospecting licence or the expiry of
prospecting licence or abandonment of prospecting operations, whichever is earlier.To,
1. Director
Geology and Mining Chhattisgarh...............................................Raipur, Chhattisgarh
2. The Collector
District..................Chhattisgarh
1.Name of the mineral or
minerals for
whichProspecting
licence has been
granted(a) ..................................................
(b)...................................................
2.Name and address of
the Licensee,..........................................................
 Phone number, ..........................................................
 E-mail PIN.................................
3.Particulars of
Prospecting Licence   
 (i) Date of execution ..........................................................
 (ii) Period …...........................................years,from.............to.................
 (iii) Area under licence hectares
4.Location of
Prospecting Licence
Area :   
 (i) Khasra Number ..........................................................
 (ii)
Village/Tahsil/District..........................................................
5.Particulars of the
Geologist/Mining
Engineer-   
 In-Charge of
Prospecting operations   Chhattisgarh Minor Mineral Rules, 2015

:
 (i) Name and address: ..........................................................
 Phone number, ..........................................................
 E-mail PIN.................................
 (ii) Qualifications ..........................................................
 (iii) Date of
appointment..........................................................
 (iv) Nature of
appointment..........................................................
 [Please tick (V) mark
one of the boxes
whicheveris
applicable]Whole time ( )Part
Time ( )
6.(i) Status of
Prospecting operation :Completed [ ]
 [Please tick (V) mark
one of the boxes
whicheveris
applicable]Abandoned [ ]
 (ii) Date of completion
or abandonment
ofProspecting
operation..........................................................
7.Total area, in hectare,
covered
underProspecting
operations within the
Licenced area...........................................................
8.Details of Prospecting
operation carried out:..........................................................
 (a) Detailed Geological
Mapping   
 (i) Area in hectare ..........................................................
 (ii) Scale. ..........................................................
 (b) Topographical
Survey   
 (i) Area in hectare ..........................................................
 (ii) Scale. ..........................................................
 (iii) Contour interval. ..........................................................
 (c) Pitting    Chhattisgarh Minor Mineral Rules, 2015

 (i) Number of pits ..........................................................
 (ii) Depth (metres) ..........................................................
 Average ..........................................................
 Maximum ..........................................................
 Minimum ..........................................................
 (d) Trenching    
 (i) Number of trenches ..........................................................
 (ii) Depth/length of
trenches (metres)..........................................................
 Average ..........................................................
 Maximum ..........................................................
 Minimum ..........................................................
 (e) Drilling    
 (i) Number of
boreholes completed..........................................................
 (ii) Grid interval of
boreholes..........................................................
 (iii) Total drilling
(metres)..........................................................
 (f) Particulars of
drilling machines:Type Make Capacity
 Number of drills ….......... ….......... …..........
 (g) Total number of
samples analysed..........................................................
 Surface samples:- ..........................................................
 Pit's/trench's
samples:-..........................................................
 Core samples :- ..........................................................
 (i) Main constituent
(please specify radicals
/elements)..........................................................
 (ii) Complete analysis ..........................................................
 (iii) Address of
Chemical Laboratory..........................................................
9.Brief description of
geology of area and..........................................................
 Nature of deposit. ..........................................................
10. Assessed Reserve in
the area along with..........................................................Chhattisgarh Minor Mineral Rules, 2015

Grade
11. Any other information ..........................................................
Note. - Please enclose a geological report describing the prospecting operations undertaken
alongwith the detailed geological plans and sections showing locations of (a) boreholes, (b) pits, (c)
trenches, (d) outcrops and other geological features, etc. Copy of chemical analysis reports certified
by the Chemical Laboratory, where samples were analysed.
Place: Signature:
Date: Name in full:
Designation : Owner/Agent/Mining Engineer/ManagerForm IX[See rule 23]Application For
Grant/Renewal of Quarry Lease for Minor MineralReceived at.................(Place) on the
...................day of ................20.....
  
Date.................20.....To,The Collector......................District...................Chhattisgarh
1. I/We beg to apply for grand of Quarry Lease/renewal of Quarry Lease for a
tenn of.............years over hectares of land in the area specified in the
schedule.
2. A sum of Rupees.................as application fee payable under rules has been
deposited vide challan No.............Dated at place..........
3. The required particulars are given below :-
(i) Name of applicant …..........................................................
(ii)Nationality of the applicant (partners,Directors,
Members)…..........................................................
(iii)Place of registration or incorporation (Firm,Company
or Society/Association)…..........................................................
(iv)Profession of individual, nature of business offirm or
company or Society/ Association and place of
business.…..........................................................
(v)Complete postal address, of the individual
firm,company or society/ association…..........................................................
 Pin Code …..........................................................
 Phone/Mobile number …..........................................................
 E-mail …..........................................................
(vi)Self attested copy of PAN card/voter
ID/drivingLicence/Aadhar card of individual,
partners, Directors, Members…..........................................................
(vii) Caste (individual or members ofSociety/Association) …..........................................................Chhattisgarh Minor Mineral Rules, 2015

(viii)Educational qualification (individual or membersof
Society/Association)…..........................................................
(ix) Age (individual or members ofSociety/Association) …..........................................................
(x)Residential Address (individual or members
ofSociety/Association)…..........................................................
(xi) List of Directors/Partners/Members …..........................................................
(xii) Registration/in-corporation certificate …..........................................................
(xiii) Financial Status …..........................................................
(xvi) Articles of memorandum/ partnershipdeed/bye-laws …..........................................................
(xv)Whether the application is for a fresh lease orfor a
renewal of a lease previously granted. Give details
ofprevious lease held.…..........................................................
(xvi) Mineral/Minerals which the applicant intends tomine. …..........................................................
(xvii)Period for which the Quarry Lease/renewal ofQuarry
Lease is required.…..........................................................
(xviii)(a) No. and date of grant order of ProspectingLicence
and the date when it is due to expire…..........................................................
 (b) A report giving the details of Prospectingcarried
out in the said area to be attached…..........................................................
 (c) Reserve and grade of mineral deposit as
perprospecting report…..........................................................
(xix) Manner in which the mineral raised is to beutilized …..........................................................
 (a) for manufacture …..........................................................
 (b) for sale …..........................................................
 (c) any other purpose …..........................................................
 In case of manufacture the industries inconnection
with which it is required, should be specified.Details of
plant(s) owned, proposed to be set up be given. 
4. A statement supported by a affidavit showing all the areas mineral wise in
each district of the State :-
(i)already held by me/us in my/our name/names (and jointly with others) under quarry lease
specifying the names of minor minerals,(ii)already applied for but not yet granted, and (iii) being
applied for simultaneously.
5. An affidavit of obtaining surface rights....................Chhattisgarh Minor Mineral Rules, 2015

6. No dues certificate in Form II..................
7. (a) A plan (six copies) showing the situation and boundaries of the
area/areas applied for and concession if any, adjoining is/are enclosed. (If
this plan/these plans be considered insufficient, I/we request that the
necessary plan/plans of the area/areas may be prepared in duplicate in your
office at my/our cost.)
(b)Khasrapanchsala.............................................
8. The plan should indicate important features, viz.-
(i)if a railway, its full details i.e. whether South East Central Railway or East Coast Railway, whether
a branch line or a main line or colliery tramway.(ii)if a road, whether village or public works
department or cart track.(iii)wells,(iv)temples or mosques.(v)bumingghat or burial ground, etc.
9. In case the renewal applied for is only for part of the lease hold,
(a)The area applied for renewal.............................(b)description of the area applied for
renewal(c)particulars of the lease hold with area applied for renewal clearly marked on it (attached.)
10. Means by which mineral is to be raised i.e. by hand labourers, mechanical
or electric power...........................................
11. Preferential right sought for (mention sub-rule/rules)......................
12. Any other particulars which the applicant wishes to furnish.
Schedule 7
Description of the area applied for :-(i)Name of village(ii)Gram Panchayat and Police
Station(iii)Khasra number and area of each field or part thereof
Khasra Number Area in Hectares
  
  
(iv)Full description of the area applied for with regard to natural
feature-(v)Block,..................................................................................................................................................(vi)Vidhansabha......................................(vii)Tehsil..................................................................................................................................................(viii)Patwari
circle number......................................(ix)District......................................Chhattisgarh Minor Mineral Rules, 2015

13. List of enclosures :-
(i) (ii) (iii) (iv) (v) (vi) (vii) (viii) (ix) (x)Place.........Dated......Yours FaithfullyName and
DesignationN.B. -• If the application is signed by an authorized agent of the applicant, power of
attorney should be attached.• If all the number cannot be entered on this form they should be
continued on a separate sheet attached to it and signed.• Where a portion of a khasra number only is
required the approximate area of such portion will suffice.Form X[See rule 29(2),46(2)]Surety
BondStamp Duty as Specifiedagainst Item 57 of Sch. I -A of Indian Stamp Act, 1899Know all Men by
These Present, that I, ....................S/o Shri..................Resident of ........................in the Tehsil
District....................(hereinafter called the surety) am held and firmly bound to the Governor of
Chhattisgarh (hereinafter called the Governor) for the sum of Rs................only, to be paid to the
Governor, his successors, or assignees or their attorney or the officer authorized by the Governor in
this behalf, for which payment will and truly to be made, I hereby bind myself, my heirs, executors,
administrators and representatives, firmly by these witnesses;As witness I have set out my hand on
this day of...................two thousand and.................And whereas Shri.....................Son of
Shri...............resident of......................... in the tehsil.................district.........(hereinafter called the
lessee) has at his own request been granted prospecting Licence/ Quarry Lease
for................................... (minor mineral) over an area of..............hectares......................in
village............Tehsil........... District............for a period of..........vide order no ..........................
dated.............................And whereas the lessee has agreed to execute the prescribed agreement with
the Government.And whereas by virtue of the agreement to be executed between the Governor
(lessor) and lessee, the said is required to pay regularly and timely the dead rent, royalty, surface
rent and any other dues arising out of the licence/lease, as the case may be.And whereas the
Governor has asked Shri...........................son of .......................................... to furnish surety of
Rs.................... (Rupees only), I, .......................... stand as surety for him to the above amount and
execute this bond, and I declare that I own the following immovable property of which I am the
absolute owner and that the property is not mortgaged or gifted and it is free from all
encumbrances.Details of the property...............................Value............................And the conditions
of the Bond is such that if the lessee shall die or become insolvent or at any time ceases to pay the
dead rent, royalty, surface rent or any other dues arising out of the said licence/lease, as the case
may be, by such due on this account under this licence/lease, as the case may be, shall immediately
become due and payable to the Governor and the same will be recovered from my property detailed
above as an arrear of land revenue in instalment by virtue of this Bond.And I further declare that I
will not sell, mortgage, gift or transfer in any other manner and will not act in to dispose off the
above property till this bond is in force.In witness whereof the said.....................has signed hereinto
on...........................................day of...............Two thousand and .........
Dated : {|
Photo of surety
| Signature of thesurety|-|| Verified and foundcorrect has signed|-|| This bond today in
mypresence|-|| Magistrate, Executive|}Witnesses
:-(1)Signature....................Name........................S/o or D/o or W/o.
Address......................(2)Signature.....................Name................................S/o or D/o or
W/o......................Address...........................Form XI[See rule 36]Register of applications for QuarryChhattisgarh Minor Mineral Rules, 2015

Leases of Minor MineralDistrict..............
1. Serial No.
2. Date on which application was received by receiving officer.
3. Name of applicant with complete address, phone no., email.
4. Situation and boundaries of the land applied for;
(i)Name of the village(ii)Name of Gram Panchayat(iii)Block(iv)Vidhansabha(v)Tehsil(vi)Patwari
circle number(vii)Khasra Number
5. Area in Hectares (Khasra wise).
6. Particulars of minerals which the applicant desires for Quarry Lease.
7. Particulars of the prospecting licence if the area applied for is covered by
it.
8. Period for which applied.
9. Application fee paid.
10. Remarks (preferential right sought for).
11. Final disposal of applications together with number and date of the order.
12. Signature of the officer.
Form XII[See rule 41(1)]Register of Quarry Leases for Minor Mineral
1. Serial Number
2. Name of the lessee with complete address, phone no., email
3. Date of application and Serial number in application registerChhattisgarh Minor Mineral Rules, 2015

4. Mineral for which lease has been granted
5. (a) Number and date of grant order of lease with authority
(b)Date of execution of Quarry Lease
6. Period for which granted/renewed
7. Situation and boundaries of the lease granted
8. Name of the village
9. Name of Gram Panchayat
10. Block
11. Vidhansabha
12. Tehsil Patwari circle number
13. Khasra Numbers
14. Granted lease area in hectare.
15. Number and date of approval of Quarry Plan and period.
16. Number and date of El A clearance (if applicable) and period.
17. Amount of compensation paid for Area-in col. No. 14 with date of
payment and whether through Government or by private negotiations
together with No. and date of order of land acquisition or transfer of lease.
18. Amount of surface rent fixed and date of fixation.
19. Amount and details of financial assurance
20. Amount and details of security depositsChhattisgarh Minor Mineral Rules, 2015

21. Particulars of disposal or refund of financial assurance.
22. Particulars of disposal or refund of security deposit.
23. Date of expiry or relinquishment or cancellation of the lease.
24. Remarks with particulars as to date of renewal, actual expiry or
relinquishment
25. Date of assignment or transfer of lease, if any, and the name and address
of the assignee or transferee.
26. Date of change together with the details of change that take place, in
name, nationality or other particulars of the holder of Quarry Lease.
27. Date from which the area is available for grant (Date and number of
Notification and date of availability)
28. Remarks
29. Signature of the Officer.
Form XIII[See rule 47 (1)]Quarry Lease Deed for Minor MineralThis Indenture made on
this.................day of......................20.....between theGovernor of Chhattisgarh acting through
the......................................(hereinafter referred to as the "lessor" which expression shall where the
context so admits so deemed to include the successors in office) of the one
partAndShri...................S/o........................(Name of person with address and occupation)
(hereinafter referred as the "lessee" which expression shall, where the context so admits be deemed
to include his heirs, executors, administrators, representatives and permitted assignees) of the other
part.Or.......................(Name of society/Association with address and occupation)
and..........................(Name of person with designation) (hereinafter referred to as "the lessee" which
expression shall where the context so admits be deemed to include their respective heirs, executors,
administrators, representatives and their permitted assignees) of the other
part.Or.......................(Name and addresses of partners), son of..........................
and.......................................................son of...................all carrying on business in partnerships
under the firm name and style of.....................(Name of the firm) registered under the Indian
Partnership Act, 1932 (9 of 1932) and having their registered office at...................................in the
town of...................(hereinafter referred to as "the lessee" which expression where the context so
admits be deemed to include all the said partners their respective heirs, executors, legal
representatives and permitted assignees) of the other part.Or.......................(Name of company) a
company registered under the Companies Act, 2013 (No. 18 of 2013) and having its registered office
at.................................(address) (hereinafter referred to as "the lessee" which expression shall whereChhattisgarh Minor Mineral Rules, 2015

the context so admits be deemed to include its successors and permitted assignees) of the other
part.Whereas the lessee/lessees has /have applied to the Competent Authority in accordance with
the Chhattisgarh Minor Minerals Rules, 2015 (hereinafter referred to as the said Rules) for a Quarry
Lease for....................in respect of the lands described in Part I of the Schedule hereunder written
and has/have deposited with the State Government the sum of Rupees.....................as security
deposit.Witnessth that in consideration of the rents and royalties, covenants and agreements by and
in these presents and the Schedule hereunder written, reserved and contained and on the part of the
lessee/lessees to be paid, observed and performed. The Competent Authority, hereby, grants and
demise unto lessees.All those mines bed...................(herein state the mineral or minerals) lease,
(hereinafter and in the Schedule referred to as the said minerals) situated lying and being in or
under the lands which are referred to in Part I of the said schedule, together with the liberties,
powers and privileges to be exercised or enjoyed in connection herewith, which are mentioned in
Part II of the said schedule subject to the restrictions and conditions as to the exercise and
enjoyment of such liberties, powers and privileges which are mentioned in Part III of the said
Schedule. Except and reserving out of this demise unto the State Government the liberties, powers
and privileges mentioned in Part IV of the said Schedule.To hold the premises hereby granted and
demised unto the lessee/lessees from the day..........................20........................for "the term of years
hence next ensuing Yielding And Paying therefore unto the State Government the several rents and
royalties mentioned in Part V of the said Schedule, at the respective times in specified, subject to the
provisions contained in Part VI of the said Schedule and the lessee/lessees hereby
covenant/covenants with the State Government as expressed in Part VII of the said Schedule and
the State Government, hereby, covenants with lessee/lessees as expressed in Part VIII of the said
Schedule and it is, hereby, mutually agreed between the parties hereto as expressed in Part IX of the
said Schedule is.In witness whereof these presents have been executed in manner hereunder
appearing the day and year first above written.The Schedule above referred toPart-I The Area of this
LeaseLocation and area of the lease. - All that tract of lands situated at village.............(Description of
area or areas) in Tehsil............in..............Gram Panchayat,.............bearing Khasra survey
Nos..............containing an area of.................or thereabout, in district,.............. delineated on the
plan hereto annexed and thereon coloured.................and bounded as follows :-On the North
by..............................................On the South by..............................................On the East
by...............................................AndOn the West by...............................................hereinafter referred
to as "the said lands"
Part II – Liberties, powers and privileges to be exercised and
enjoyed by the lessee/ lessees subject to the restrictions and
conditions in Part III.
1. To enter upon land win, work, etc. - Liberty and power at all times during
the term, hereby, demised to enter upon the said lands and to win, work,
dress, process, convert, carry away and dispose of the said mineral/minerals.Chhattisgarh Minor Mineral Rules, 2015

2. To bring and use machinery equipment, etc. - Liberty and power for or in
connection with any of the purposes mentioned in this part to erect,
construct, maintain and use on or under the said lands any engines,
machinery, plant, dressing floors, brickkilns, workshops, store house,
godown, sheds and other buildings and other works and conveniences of the
like nature on or under the said lands.
3. To make roads and ways, etc. and use existing road and ways. - Liberty
and power for or in connection with any of the purposes mentioned in this
part to make any tramways, roads, and other ways in or over the said lands
and to use, maintain and go, and repass with or without horses cattle,
wagons, or other vehicles over the same (or any existing tramways, roads
and other ways in or over the said land) on such conditions as may be
agreed to.
4. To get building and road materials, etc. - Liberty and power for or in
connection with any of the purposes mentioned in this part to mine and get
stone, gravel and other building and road materials and ordinary clay and to
use and employ the same and manufacture such clay into bricks or tiles and
to use such bricks or tiles but not to sell any such material bricks or tiles.
5. To use water from streams, etc. - Liberty and power for or in connection
with any of the purposes mentioned in this part but subject to the right of any
existing or future lessees and with the written permission of Collector to
appropriate and use water from any streams, water-courses, springs or other
sources in or upon the said lands and to divert, set up or dam any such
stream or water course and collect or impound any such water and to make,
construct and maintain any water-course culverts, dams or reservoirs but not
as so to deprive any cultivated lands, villages, building or watering places for
livestock or a reasonable supply of water as before accustomed nor in any
way to foul or pollute any stream or springs. Provided that the lessee/lessees
shall not interfere with the navigation in any navigable stream or shall divert
such stream without the previous written permission of the State
Government.Chhattisgarh Minor Mineral Rules, 2015

6. To use land for stacking, heaping, depositing purposes. - Liberty and
power to enter upon and use a sufficient part of the surface of the said lands
for the purpose of stacking, heaping, storing or depositing therein any
produce of the mines or works carried on and any tools, equipment, earth
and materials and substances, dug or raised under the liberties and powers
mentioned in this part.
7. Beneficiation/processing and conveying of production. - Liberty and power
to enter upon and use a sufficient part of the surface of the said lands to
beneficiate/process any minor mineral produced from the said land and to
carry away such beneficiated minor mineral.
8. To clear brushwood and to fell and utilize trees, etc. - Liberty and power for
or in connection with any of the purpose mentioned. In this part and subject
to the existing rights of others and save as provided in clause 3 of Part III of
this Schedule to clear undergrowth and brushwood and to fell and utilize any
trees or timber standing or found on the said lands provided that the State
Government may ask the lessee/lessees to pay for any trees or timber felled
and utilised, by him/them at the rates specified by the Collector or the State
Government.
Part III – Restrictions and conditions as to the exercise of the
liberties, power and privileges in Part II
1. No building etc. upon certain places. - No building or thing shall be erected
set up or placed and no surface operations shall be carried on in or upon any
public pleasure ground, burning or burial ground or place held sacred by any
class of person or any house or village site, public road or other place which
the State Government may determine as public ground nor in such a manner
as to injure or prejudicially effect any building, works, property or rights of
other persons and land shall be used for surface operations which is already
occupied by persons other than the State Government for works or purposes
not included in this lease. The lessee/lessees shall not also interfere with any
right of way, well or tank.Chhattisgarh Minor Mineral Rules, 2015

2. Permission for surface operation in a land not already in use. - Before
using for surface operations any land which has not already been used for
such operations, the lessee/lessees shall give to the Collector of the District
two calendar months previous notice in writing specifying the name or other
description of the situation and the extent of the land proposed to be so used
and the purpose for which the same is required and the said land shall not be
so used if objection is issued by the Collector within two months after the
receipt by him of such notice unless the objection so stated shall on
reference to the State Government be annulled or waived.
3. To cut trees in unreserved lands. - The lessee/lessees shall not without the
express sanction of the Collector cut down or injure any timber or trees on
the said lands but may without such sanction clearway any brushwood or
under growth which interferes with any operations authorized by these
presents. The Collector or the State Government may require the
lessee/lessees to pay for any trees or timber felled and utilized by him/them
at the rates specified by the Collector of the District.
4. No Mining operations within prohibited distances. - The lessee/lessees
shall not work or carry on or allow to be worked or carried on any mining
operations at or to any point within the prohibited distances specified in
rules 5 (2) and 51 (12).
5. Facilities for adjoining Government Licence and Leases. - The Lessee/
Lessees shall allow existing and future holders of Government Licensee or
leases over any land which is comprised in or adjoins or is reached by the
land held by the lessee/lessees reasonable facilities or access there to :
Provided that no substantial hindrance or interference shall be caused by such holders of Licences
or leases to the operation lessee/lessees under these present and fair compensation as may be
mutually agreed upon or in the event of disagreement as may be decided by the State Government
shall be made to the lessee/lessees for loss or damage sustained by the lessee/lessees by reason of
the exercise of this liberty.
Part IV – Liberties, Powers and Privileges reserved to the State
GovernmentChhattisgarh Minor Mineral Rules, 2015

1. To work other minerals. - Liberty and power for the State Government or to
any lessee or persons authorized by it in that behalf to enter into and upon
the said land and to search for, win, work, dig, get, raise, dress, process,
convert and carry away mineral other than the said minerals and any other
substances and for those purposes to sink, drive, make, erect, construct,
maintain and use such pits, shafts, inclines, drifts, levels and other lines,
waterways, airways, water courses, drains, reservoirs, engines, machinery,
plant, building, canals, tramways, railway, roadways and other works and
conveniences as may be deemed necessary or convenient:
Provided that in the exercise of such liberty and power no substantial hindrance or interference shall
be caused to or with the liberties, power and privileges of the lessee/lessees under these presents
and that fair compensation as may be mutually agreed upon or in the event of disagreement as may
be decided by the State Government shall be made to the lessee/lessees for all loss or damage
sustained by the lessee/lessees by reasons for all loss or damages sustained by the lessee/lessees by
reasons or in consequence of the exercise of such liberty and power.
2. To make railway and roads. - Liberty and power for the State Government
or any lessee or person authorized by it in that behalf to enter into and upon
the said lands and to make upon over or through the same any railways,
tramways, roadways or pipelines for any purpose other than those
mentioned in Part II of these presents and to get from the said lands stones,
gravel, earth and other materials for making, maintaining and repairing such
railway, tramways and road or any existing railways and road and to re-pass
at all times with or without horse, cattle or other animal carts, wagons,
carriages, locomotives or other vehicles over or along any such railway,
tramways, road lines and other ways for all purposes and as occasion may
require, provided that in the exercise of such liberty and power by such other
lessee or person no substantial hindrance or interference shall be caused to
or with the liberties, powers and privileges of the lessee/lessees under these
presents and that fair compensations as may be mutually agreed upon or in
the event of disagreement as may be decided by the State Government be
made to the lessee/lessees for all loss or damage sustained by the
lessee/lessees by reason or in consequence of the exercises of such liberty
and power.Chhattisgarh Minor Mineral Rules, 2015

Part V – Rents and royalties reserved by this lease
1. To pay dead rent or royalty whichever is higher. - The lessee shall pay for
every year except the first year of the lease, dead rent as specified in clause
2 of this part:
Provided that, where the holder of such Quarry Lease becomes liable under Rule 51 of the rules to
pay royalty for any mineral removed or consumed by him or by his agent, manager, employee,
contractor or sub-lessee from the leased area he shall be liable to pay either such royalty or the dead
rent in respect of that area, whichever is higher.
2. Rate and mode of payment of dead rent. - Subject to the provisions of
clause 1 of this Part during the subsistence of the lease, the lessee/lessees
shall pay to the State Government annual dead rent for the lands demised
and described in Part I of this Schedule at the rate for time being specified in
the Schedule IV of the Rules in such manner as specified in Rule 51 (1) (a).
3. Rate and mode of payment of royalty. - Subject to the provision of clause 1
of this part, the lessee/lessees shall during the subsistence of this lease pay
to the State Government as specified in Rule 51 (1) (b) royalty in respect of
any mineral/minerals removed by him/them from the leased area at the rate
for the time being specified in the Schedule-Ill to the Rules.
4. Payment of surface rent. - The lessee/lessees shall pay rent to State
Government in respect of all parts of the surface of the said lands which
shall from time to time be occupied or used by the lessee/lessees under the
authority of these presents at the rate of Rupees...............respectively per
annum per hectare or part thereof for area so occupied during the period
from commencement of such occupation or use until the area shall cease to
be so occupied for used and shall as far as possible restore the surface land
so used to its original condition. Surface rent shall be paid as detailed in
Rule 51 (1) (c).
Part VI – Provisions relating to the rents and royalties
1. Rent and royalties to be free from deduction, etc. - The rent and royalties
mentioned in Part V of this Schedule shall be paid free from any deductions
to the State Government as specified in Rule 51 (1).Chhattisgarh Minor Mineral Rules, 2015

2. Mode of computation of royalty. - For the purposes of computing the said
royalties the lessee/lessees shall keep a correct account of the mineral/
minerals produced, consumed and dispatched. The accounts as well as the
volume of mineral/minerals in stock or in the process of export may be
checked by an officer authorized under the Rules.
3. Course of action if rents and royalties are not paid in time. - Should any
rent, royalty or order sums due to the State Government under the terms and
conditions of these presents be not paid by the lessee/lessees wit hin
prescribed time, the same, together with simple interest due thereon at: the
rate of twenty four percent per annum or equivalent to the rate of interest
prescribed under rule 64A of Mineral Concession Rules, 1960, whichever is
higher, may be recovered on a certificate of Mining Officer/Assistant Mining
Officer in the same manner as an arrear of land revenue.
Part VII – The Covenants of the lessee/lessees
1. Lessee to pay rents and royalties, taxes etc. - The lessee/lessees shall pay
the rent and royalties reserved by this lease at such times and in the manner
provided in Part-V and VI of these presents and shall also pay and discharge
all taxes, rents, assessments and impositions whatsoever being in the nature
of public demands which shall from time to time be charged, assessed or
imposed by the authority of the State Government upon or in respect of the
premises and works of the lessee/lessees in common with other premises
and works of a like nature except demands for land revenues.
2. To maintain and keep boundary marks in good order. - The lessee/lessees
shall at his/their own expense erect and at all tunes maintain and keep in
repair boundary marks and pillars according to the demarcation to be shown
in the plan annexed to this lease. Such marks and pillars shall be sufficiently
clear of the shrubs and other obstruction as to allow easy identification,
co-ordinates shall be marked on all the comer pillars. The maximum distance
between any two successive boundary pillars should not be more than 100
meters.Chhattisgarh Minor Mineral Rules, 2015

3. To Commence operations within a year and work in a workman like
manner. - Mining operation shall be undertaken in accordance with the
approved Quarry Plan as per Rule 24. The lessee/lessees shall commence
operation within one year from the date of execution of the lease and shall
thereafter at all times during the continuance of this lease win, work and
develop, the said minerals without voluntary intermission in a skillful and
workman like manner and as prescribed under clause 12 hereinafter without
doing or permitting to be done any unnecessary or avoidable damage to the
surface of the said lands or the crops, building, structures or other property
thereon. For the purposes of this clause operations shall include the erection
of machinery, laying of a tramway or construction of a road in connection
with the mine.
4. To indemnify Government against all claims. - The lessee/lessees shall
make and pay such reasonable satisfaction and compensation as may be
assessed by lawful authority in accordance with the law in force on the
subject for all damage, injury or disturbance which may be done by him/them
in exercise of the powers granted by this lease and shall indemnify and keep
indemnified fully and completely the State Government against all claims
which may be made by any person or persons in respect of any such
damage, injury or disturbance and all costs and expenses in connections
therewith.
5. To secure and keep in good condition pits, shafts, etc. - The lessee/
lessees shall during the subsistence of this lease well and sufficiently secure
and keep open with timber or other durable means all pits and workings that
may be made or used in the said lands and make and maintain sufficient
fences to the satisfaction of the Collector around every such pit or working
whether the same is abandoned or not and shall during the same period keep
all workings in the said lands except such as may be abandoned accessible
free from water and foul air as far as possible.
6. To strengthen and support the mine to necessary extent. - The lessee/
lessees shall strengthen and support to the satisfaction of the Railway
Administration concerned or the State Government, as the case may be any
part of the mine which in its opinion requires such strengthening or support
for the safety of any railway, reservoir, canal, road and any other publicChhattisgarh Minor Mineral Rules, 2015

works or structures.
7. To allow inspection of workings. - The lessee/lessees shall allow any
officer authorized under these Rules to enter upon the premises including
any building excavation or land comprised in the lease for the purpose of
inspecting, examining, surveying, prospecting and making plans thereof
sampling and collecting any data and the lessee/lessees shall with proper
person employed by the lessee/lessees and acquainted with the mines and
works effectually assist such officer, agents, servants and workman in
conducting every such inspection and shall afford them all facilities,
information connected with the working of the mines which they may
reasonably require and also shall and will conform to and observe all orders
and regulations which the Central and State Government as the result of
such inspection or otherwise may from time to time see fit to impose.
8. To report accident. - The lessee/lessees shall without delay send to the
Collector a report of any accident causing death or serious bodily injury or
serious injury to the property or seriously affecting or endangering life or
property which may occur in the course of the operations under this lease.
9. To report discovery of other minerals. - The lessee/lessees shall report to
the Collector the discovery in the leased area of any mineral not specified in
the lease without delay along with full particulars of the nature and position
of each such find. If any mineral not specified in the lease is discovered in
the leased area, the lessee/lessees shall not win and dispose of such mineral
unless such mineral is included in the lease or a separate lease is obtained
thereof.
10. To keep records and accounts regarding production and employees etc. -
The lessee/lessees shall at all time during the said term keep or cause to be
kept at an office to be situated upon or near the said lands correct and
intelligible books of accounts which shall contain accurate entries showing
from time to time :-
(1)Quantity and quality of the said mineral/minerals realized from the said lands.(2)Quantities of
the various qualities of the said mineral/minerals sold/dispatched from said land and consumed
within said land separately.(3)Quantities of the various qualities of the said mineral/minerals
otherwise disposed of and the manner and purpose of such disposal.(4)The prices and all otherChhattisgarh Minor Mineral Rules, 2015

particulars of all sales of said mineral/ minerals.(5)The number of persons employed in the mines or
work or upon the said lands specifying nationality qualification and pay of the technical
personnel.(6)Such other facts, particulars and circumstances as the Central or the State Government
may from time to time require and shall also furnish free of charge to such officers and at such times
as the Central and State Government may appoint true and correct abstract of all or any such books
of accounts and such information and returns to all or any of the matters aforesaid as the State
Government may prescribe and shall at all reasonable times allow such officers as the Central
Government or State Government shall in that behalf appoint to enter into and have free access to
the said offices for the purpose of examining and inspecting the said books of accounts, plans and
records and to make copies thereof and make extracts therefrom.
11. To maintain plans, etc. - The lessee/lessees shall at the all times during
the said term maintain at the mine office correct intelligible up-to-date and
complete plans of the mines in the said lands. They shall show all the
operations, and working and all the trenches, pits made by him/them in the
course of operations carried on by him/them under the lease and geological
data and all such plans shall be amended and filled up by and from actual
surveys to be made for that purpose at the end of twelve months or any
period specified from time to time and the lessee/lessees shall furnish free of
charge to the State Government true and correct copies of such plans
wherever required. Accurate records of all trenches, pits shall show-
(a)The subsoil and strata through which they pass.(b)Any mineral encountered.(c)Any other matter
of interest and all data required by the State Government from time to time.The lessee/lessees shall
allow officer of the State Government authorized in this behalf to inspect the same at all reasonable
time. He/they shall also supply when asked for by the State Government a composite plan of the
area showing thickness, dip, inclination, etc. as also the quantity of reserves quality wise.
12. To pay compensation for injury of third parties. - The lessee/lessees shall
make and pay reasonable and satisfactory compensation for all damage,
injury or disturbance to person or property which may be done by or on the
part of lessee / lessees in exercise of the liberties and power granted by
these presents and shall at all times save harmless and keep indemnified the
State Government from and against all suits, claims and demands which may
be brought or made by any person or persons in respect of any such
damage, injury or disturbance. In case of Government land the
lessee/lessees shall pay, an amount equal to five percent of prevalent price
fixed by Revenue Department for paddath land of concerned district in every
financial year as a compensation to government.Chhattisgarh Minor Mineral Rules, 2015

13. Not to obstruct working of other minerals. - The lessee/lessees will
exercise the liberties and power hereby granted in such a manner as to offer
no unnecessary or reasonably avoidable obstruction or corruption to the
development and working within the said lands of any minerals not included
in this lease and shall at all times afford to the Central and State Government
and to the holders of prospecting licence, Quarry Leases or quarry permit in
respect of any such minerals or any minerals within any land adjacent to the
said lands as the case may be reasonable means of access and safe and
convenient passage upon and across the said land to such minerals for the
purpose of getting working, developing and carrying away the same provided
that the lessee/ lessees shall receive reasonable compensation for any
damage or injury which he/they may sustain by reason or in consequence of
the use of such passage by such lessees or holders of prospecting Licences.
14. Transfer/Amalgamation of lease. - (1) The lessee/lessees shall not,
without the previous consent in writing of the Sanctioning Authority-
(a)Assign, sublet, mortgage, or in any other manner transfer the Quarry Lease, or any right, title or
interest therein, or(b)Enter into or make any arrangement, contract or understanding whereby the
lessee/lessees will or may be directly or indirectly financed to a substantial extent by, or under
which the lessee's operation's or undertakings will or may be substantially controlled by, any person
or body of persons other than the lessee /lessees.(c)The Sanctioning Authority may by an order in
writing determine the lease at any time if the lessee/lessees has/have in his opinion committed a
breach of any of the above provisions of has/have transferred lease or any right, title or interest
therein otherwise than in accordance with rule 56, provided that no such order shall be made
without giving the lessee/lessees a reasonable opportunity of stating his/their case.(2)For
amalgamation of leases, lessee/lessees shall submit an application for amalgamation, along with at
common Quarry Plan for the leases proposed for amalgamation, in accordance with rule 57. The
Director may permit amalgamation of leases and period of amalgamated lease shall be co-terminus
with the lease whose period expires first.
15. Lessees shall deposit any additional amount necessary. - Whenever the
security deposit of rupees.................... or any part thereof or any further sum
hereinafter deposited with the State Government in replenishment thereof
shall be forfeited or applied by the State Government pursuant to the power
in hereinafter declared in that behalf the lessee/lessees shall deposit with the
State Government such further sum as may be sufficient with the
inappropriate part thereof to bring the amount in deposit with the State
Government up to the sum of rupees..............Chhattisgarh Minor Mineral Rules, 2015

16. Delivery of working in good order to State Government after
determination of lease. - The lessee/lessees shall at the expiration or sooner
determination of the said term or any renewal thereof deliver up to the State
Government all mines, pits, water ways, and other works now existing or
hereinafter to be sunk or made on or under the said lands except such as
have been abandoned with the sanction of the State Government and in any
ordinary and fair course of working all engines, machinery, plant, building,
structure, other works and conveniences which at the commencement of the
said term were upon or under the said lands and all such machinery set up
by the lessee/ lessees which cannot be removed without causing injury to
the mines, works under the said lands (except such of the same as may with
the sanction of the State Government have become dis-used) and all
buildings and structures of bricks or stone erected by the lessee/lessees
above ground level in good repair order and condition and fit in all respects
for further working of the said mines and the said minerals.
17. Right of pre-emption. - (A) The State Government shall from time to time
and all times during the said term have the right (to be exercised by notice in
writing to the lessee/lessees) of pre-emption of the said minerals (and all
products thereof) lying in or upon the said lands hereby demised or
elsewhere under the control of the lease/leases and the lease/leases shall
with all possible expedition deliver all minerals or products or minerals
purchased by the State Government under the power conferred by this
provision in the quantities at the times in manner and at the place specified
in the notice exercising the said rights.
(B)The price to be paid for all minerals or products of minerals taken in preemption by the State
Government in exercise of the right hereby conferred shall be the fair market price prevailing at the
time of preemption :Provided that in order to assist in arriving at the said fair market price the
lessee/lessees shall if so required furnish to the State Government for the confidential information
of the Government, particulars of the quantities, description and prices of the said minerals or
products thereof sold to other customers and of charters entered into for freight, for carriage of the
same and shall produce to such officer or officers as may be directed by the State Government
original or authenticated copies of contracts and charter parties entered into for the sale or
freightage of such minerals or products.(C)In the event of the existence of a state of war or
emergency (of which existence and President of India shall be the sole judge and a notification to
this effect in the gazette of India shall be conclusive proof), the State Government with the consent
of the Central Government shall from time to time and all times during the said term have the right
(to be exercised by a notice in writing to the lessee/lessees) forthwith take possession and control ofChhattisgarh Minor Mineral Rules, 2015

the works, plant, machinery and premised of the lessee/lessees on or in connection with the said
lands or operations under this lease and during such possession or control the lessee/lessees shall
conform to and obey all directions given by or on behalf of the Central Government or State
Government regarding the use or employment of such works, plants, premises and minerals
:Provided that fair compensation which shall be determined in default of agreement by the
Government shall be paid to the lessee/ lessees for all loss or damage sustained by him/them by
reason or in consequence of the exercise of the powers conferred by this clause :Provided also that
the exercise of such powers shall not determine the said term hereby granted or affect the terms and
provisions of these presents further than may be necessary to give effect to the provisions of this
clause.
18. Recovery of expenses incurred by the State Government. - If any of the
works or matters which in accordance with the covenants in that behalf
hereinbefore contained are to be carried or performed by the lessee/lessees
be not so carried out or performed within the time specified in that behalf, the
State Government may cause the same to be carried out or performed and
the lessee/ lessees pay the State Government on demand all expenses which
shall be incurred in such carrying out or performance of the same and the
decision of the State Government as to such expenses shall be final.
19. Other obligations,-
(a)The lessee/lessees shall pay a wage not less than the minimum wage prescribed by the Central
Government or State Government from time to time under Minimum Wages Act, 1948;(b)The
lessee/lessees shall comply with provisions of the Mines Act, 1952 and the rules made
thereunder;(c)The lessee/lessees shall comply with provisions of the Water (Prevention and Control
of Pollution) Act, 1974 and the rules made thereunder;(d)The lessee/lessees shall comply with
provisions of the Air (Prevention and Control of Pollution) Act, 1981 and the rules made
thereunder;(e)The lessee/lessees shall comply with provisions of the Environment (Protection) Act,
1986 and the rules made there- under;(f)The lessee/lessees shall take measures for the protection of
environment like planting of trees, reclamation of land, use of pollution control devices and such
other measures as may be prescribed by the Collector or any other officer authorized for it, from
time to time at his own expense;(g)The lessee/lessees shall pay compensation to the occupier of the
land on the date and in the manner laid down in the rules;(h)The lessee/lessees shall in the matter
of employment give preference to the tribal's and to the local persons;(i)The lessee/lessees shall not
transport any mineral or its product from the leased area without a valid transit pass as provided in
the rules.
Part VIII – The Covenants of the State GovernmentChhattisgarh Minor Mineral Rules, 2015

1. Lessee/Lessees may hold and enjoy rights quietly. - The lessee/lessees
paying the rents and royalties hereby reserved and observing and
performing all the covenants and agreements herein contained and on the
part of the lessee/ lessees to be observed and performed shall and may
quietly hold and enjoy the rights and premises hereby demised for and
during the term hereby granted without any in lawful interruption from or by
the State Government or any person rightfully claiming under it.
2. Acquisition of land of third parties and compensation thereof. - If in
accordance with the provision of clause 4 of Part VII of this Schedule the
lessee/ lessees shall offer to pay to an occupier of the surface of any part of
the said lands compensation for any damage or injury which may arise from
the proposed operations of the lessee/lessees and the said occupier shall
refuse his consent to the exercise of the rights and powers reserved to the
State Government and demised to the lessee /lessees by these presents and
the lessee/ lessees shall report the matter to the State Government and shall
deposit with it the amount offered as compensation and if the State
Government are satisfied that the amount of compensation offered is fair and
reasonable or if it is not so satisfied and the lessee/lessees shall have
deposited with it such further amount as the State Government shall
consider fair and reasonable the State Government shall order the occupier
to allow the lessee/lessees to enter the land and to carry out such operations
as may be necessary for the purpose of this lease. In assessing the amount
of such compensation the State Government shall be guided by the
principles of the Right to Fair Compensation and Transparency in Land
Acquisition, Rehabilitation and Resettlement Act, 2013 (No. 30 of 2013).
3. To renew. - The Quarry Lease is renewable in terms of the provisions of
the rules.
4. Liberty to determine the lease. - (1) The lessee/lessees may at any time
determine this lease by giving not less than six calendar months notice in
writing to the Sanctioning Authority and upon the expiration of such notice
provided that the lessee/lessees shall upon such expiration render and pay
all rents, royalties, compensation for damages and other moneys which may
then be due and payable under these presents to the lessor or any other
person or persons and shall deliver these presents to the State GovernmentChhattisgarh Minor Mineral Rules, 2015

then this lease and the said term and the liberties, powers and privileges
hereby granted shall absolutely cease and determine but without prejudice to
any right or remedy of the lessor in respect of any breach of any of the
covenants or agreements contained in these presents.
(2)The Sanctioning Authority may on an application made by the lessee permit him to surrender
one or more minerals from his lease which is for a group of minerals on the ground that deposits of
that mineral have since exhausted or depleted to such an extent that it is no longer possible to work
the mineral economically, subject to the condition that the lessee;(a)Makes an application for such
surrender of mineral at least six months before the intended date of surrender, and(b)Gives an
undertaking that he will not cause any hindrance in the working of the mineral so surrendered by
any other person who is subsequently granted a Quarry Lease for that mineral.
5. Refund of security deposits. - On such date as the Collector may elect after
the determination of this lease or of any renewal thereof, the amount of the
security deposit paid in respect of this lease and then remaining in deposit
with the State Government and not required to be applied to any of the
purposes mentioned in this lease shall be refunded to the lessee/lessees. No
interest shall run on the security deposit.
Part IX – General Provisions
1. Obstructions to inspection. - In case the lessee/lessees or his/their
transferee/assignee does/do not allow entry or inspection by the officers
authorized by the Central or State Government under the said rules, the
Collector shall give notice in writing to the lessee/lessees requiring him/them
to show cause within such time as may be specified in the notice why the
lease should not be determined and his/their security deposit forfeited; and if
the lessee/lessees fails/fail to show cause within the aforesaid time to the
satisfaction of the Sanctioning Authority may determine the lease and forfeit
the whole or part of the security deposit.
2. Penalty in case of default in payment of royalty and breach of covenants. -
If the lessee/lessees or his/their transferee or assignee makes/make any
default in payment of rent or royalty as required by the rules, Act or commits
a breach of any of the conditions and covenants; other than those referred to
in covenant I above, the Collector shall give notice to the lessee/ lessees
requiring him/them to pay the rent and royalty with interest as per rule 51 (1)
(d) or remedy the breach, as the case may be within sixty days from the dateChhattisgarh Minor Mineral Rules, 2015

of receipt of the notice and if the rent and royalty with interest are not paid or
the breach is not remedied within such period, the Sanctioning Authority
without prejudice to any proceedings that may be taken against him/them,
determine the lease and forfeit the whole or part of the security deposit or
may impose penalty as provided in the rules.
3. Lessee/Lessees to remove his/their properties on the expiry of lease. - The
lessee/lessees having first paid discharged rent, and royalties payable by
virtue of these presents may at the expiration or sooner determination of the
said term or within three calendar months thereafter (unless the lease shall
be determined under clauses 1 and 2 of this part and in that case at any time
not less than 15 days nor more than three calendar months after such
determination) take down and remove for his/their own benefit all or any
engines, machinery, plant, building, structures, tramways and other works,
erections and conveniences which may have been erected, set up or placed
by the lessee/lessees in or upon the said lands and which the lessee/lessees
is/are not bound to deliver to the State Government under these rules.
4. Forfeiture of property left more than three months after determination of
lease. - If at the end of three calendar months after the expiration or sooner
determination of the said term under the provision contained in clause 4 of
part VIII of this schedule become, effective there shall remain in or upon the
said land any engines, machinery, plant, building structures, tramways and
other work, erections and conveniences or other lands held by him/them
under Quarry Lease the same shall if not removed by the lessee/lessees
within one calendar months after notice in writing requiring their removal has
been given to lessee/ lessees by the Collector be deemed to become the
property of the State Government and may be sold or disposed of in such
manner as the State Government shall deem fit without liability to pay any
compensation to the account to then lessee/lessees in respect thereof.
5. The lease is executed at.............and subject to the provision of Article 226
of the Constitution of India, it is hereby agreed upon by the lessee and the
lessor that in the event of any dispute in relation to the area under lease,
condition of lease, the dues realizable under the lease and in respect of all
matters touching the relationship of the lessee and the lessor, the suits (or
appeals) shall be filed in the Civil Court at..............(name of the city) and it isChhattisgarh Minor Mineral Rules, 2015

hereby expressly agreed that neither party shall be competent to file a suit or
bring any action or file any petition at any place other than the courts named
above.
6. For the purpose of stamp duty the anticipated royalty from the demised
land is rupees..............per year.
In witness whereof these present have been executed in the manner hereunder appearing the day
and year first above written.Signed byFor and on behalf of
theGovernor(Lessor)dated(Lessee)(Signature andDesignation of Lesseewith date)WITNESSES
:-(1)Signature....................Name.......................S/o or D/o or
W/o..........Address....................(2)Signature....................Name.......................S/o or D/o or
W/o..........Address....................Form XIV[See Rule 51 (14)]Application for issue of transit
pass/transit pass book for dispatch of minor minerals
1. Name of lessee/licensee/permit holder
2. Address
3. Grant Order Number and date of lease/ licence/permit.
4. Source of the Mineral:-
(i)Mine/permit at village(ii)Tehsil(iii)Panchayat(iv)Police Station(v)District
5. Name of Mineral.
6. Quantity of Mineral in stock and the quantity proposed to be
dispatched/transported and mode of transport
7. Purpose of dispatch (own consumption/sale in case of sale, the name and
address of the purchaser should be furnished).
8. In case of Rail Transport:-
(i)Station of loading(ii)Destination of the consignment with the name and the address of the
consignee.Chhattisgarh Minor Mineral Rules, 2015

9. Sale value of the mineral
10. Period within which the applicant desires to dispatch/transport the
quantity
11. Other particulars which the applicant wishes to state.
I/we hereby certify that the particulars given above are correct to the best of my/our knowledge and
belief.
Place : Signature of Applicant
Date: Name...........................
Form XV[See Rules 51 (20)(a), 58(4)(e), 70(2)]Monthly Return for Quarry Lease/Permit for Minor
Mineral (To be submitted by 10th ensuing month)For the month of...............To,
1. The Collector
District...................
2. Gram Panchayat
.......................................(a)Name of the lessee /permit holder: .............................................(b)Postal
address/phone number/e-mail: ............................................(c)Location of Quarry Lease/permit:
District.............................. Tahsil........... Block............ Gram Panchayat.............. Patwari circle
number............Village............................(d)Detail of Quarry Lease/permit :
Mineral/minerals......................Area in hectare.............Period of lease/permit from.to............Khasra
Number..................Note. - All figures be given in cubic meters.
1. Opening stock : …....................................................................
2. Production of mineral : …....................................................................
3. Total (1+2) : …....................................................................
4. Consumption of mineral : …....................................................................
5. Dispatch of Mineral : …....................................................................
6.Total consumption and
dispatch (4+5): …....................................................................
7. Closing Stock (3-6) : …....................................................................
8.Transit passes used book
Nos. and Serial Nos.: …....................................................................
9.Products from mineral
consumed: …....................................................................
 (a) Opening stock : …....................................................................Chhattisgarh Minor Mineral Rules, 2015

 (b) Production : …....................................................................
 (c) Total (a+b) : …....................................................................
 (d) Dispatch : …....................................................................
 (e) Closing stock (c-d) : …....................................................................
10. Balance payable royalty : …....................................................................
11. Royalty for this month : …....................................................................
12. Total Royalty (10+11) :  
13.Royalty paid vide
challanNo........................ Date........................Place................
14. Balance due (12-13)  …....................................................................
15. Remarks  …....................................................................
Date...................  Name and
Signature............................
Place..................  of the lessees/permit
holder or his
authorisedperson
Form XVI[See Rule 51 (20) (b)]Half Yearly Return for Quarry Lease of Minor Mineral
1.
-1-20.....to 30-6-20.....
1.
-7-20.....to 31-12-20....(To be submitted by 15th July/15th January)To,
1. The Collector
District..............
2. Gram Panchayat
......................................(a)Name of the quarry lessee holder :
............................................................(b)Postal address/phone number/e-mail:
...........................................................(c)Location of Quarry Lease :
District.................................................... Tahsil.......Block , Gram Panchayat....................... Patwari
circle number....... Village........(d)Detail of Quarry Lease : Mineral/minerals................Area in
hectare...................... Period of lease year, from to Khasra
Number.................................................Note. - All figures be given in cubic meters.
1. Total production in half year :…................................................................Chhattisgarh Minor Mineral Rules, 2015

2. Consumption :…................................................................
3. Dispatches :…................................................................
4. Total (2+3) :…................................................................
5. Royalty :…................................................................
6. Dead Rent paid :…................................................................
7. Royalty payable (5-6) :…................................................................
8. Royalty paid challan No. :…................................................................
9. Please give details for-   
 (1) Pits mouth value :…................................................................
 (2) Sale price :…................................................................
 (3) Average number of persons employed per day :…................................................................
 (4) Depth of mine :…................................................................
 (5) Use of explosives if any :…................................................................
10. Remark...........................................................................................   
Date............ Name and Signature.......
Place........ of the lessees/permit holder or his authorizedperson
Form XVII[See Rules 51 (20) (c), 70 (2)]Annual Return for Quarry Lease of Minor Minerals (To be
submitted by 31st January every year)
1. The Collector
District..............
2. Gram Panchayat
......................................Part-I General(1)Name of the lessee :
..........................................................................................................(2)Postal address/phone
number/e-mail................................................(3)Location of Quarry Lease : District..........................
Tahsil............. Block........................................ Gram Panchayat................ Patwari circle
number................Village......................(4)Detail of Quarry Lease :
Mineral/minerals.........................................Area in hectare..................Khasra
Number..................................Date of execution :.................... Date of possession : .................Period
of Quarry Lease :........................year, from.............to.......(5)Transferor of previous quarry lessee, if
any date of transfer :...................(6)Ownership (please mark)-(i)Schedule Tribe Society(ii)Scheduled
Caste Society(iii)Education unemployed Society(iv)Individual(v)(Indicate S.C./S. T./O.B.C.
etc.)(vi)Any otherPart - II Utilization of area(7)Lease area utilization as at the end of year -(a)Area
already exploited and abandoned .............................................................(b)Area covered under
current operations ..............................................................(c)Area used for waste disposal
..............................................................................(d)Area used for any other purpose (Give details)
.................................................Part-III Rents and Royalties(8)Royalty paid during the year
-(a)Royalty during the year :(b)Amount of past arrears if any paid during the year(9)Amount of deadChhattisgarh Minor Mineral Rules, 2015

rent paid during the year(10)Surface Rent Area for which surface rent is payable(i)Amount paid for
the year(ii)Amount paid for past arrears if anyPart -IV Production and dispatches(11)Production
and dispatch(i)Opening stock(ii)Production(iii)Dispatches(iv)Closing stockPart-V Cost of
Production(12)(i)Cost per tone(ii)Over-head cost(iii)Interest(iv)Depreciation(v)Taxes, Royalty
etc.(13)Explosives and machinery used (Give specific details)Part-VI General Geology and
Mining(14)(a)General geology of the area :(i)Geology(ii)Name of rock/mineral excavated and
disposed as waste.(iii)Name of rock/mineral excavated but not sold i.e. mineral reject.(iv)Reserves
and Resources estimated at the and of year.(b)Exploration:
Item Number Meterage Grid/ Dimension Remark
Drilling     
Trenching     
Pitting     
(c)Mining:(i)Number of benches : In mineral.............In over burden(ii)Height of benches : Average
..................Maximum........... Minimum(iii)Depth of the deepest working from adjacent ground
:............(iv)Number of trees planted during the year :..................(v)Total trees planted up to
previous year : .................No. of survived trees:............(vi)Mineral production proposed for next
year :................(vii)Please indicate the salient features which affected quarrying operations during
the year :.....................
Date.................................. Name and Signature.............
Place....................... of the lessees/permit holder or his authorizedperson
Form XVIII[See Rule 51(24)]Notice
1. (a) Name of Mine
(b)Name of mineral worked(c)Situation of mine (Village, Thana, Sub-Division, District,
State)(d)Date when work was first started.
2. (a) Name, postal address, phone and e-mail of present owner (s)
(b)Name, postal address, phone and e-mail of agent, if any
3. (a) Name, postal address, phone and e-mail of the Manager
(b)His age(c)His qualifications(d)His experience in mining.
4. Whether working are likely to be extended below ground.
5. (a) Maximum depth of open cast excavation measured from its highest to
its lowest point, (b) Date when depth first exceeded 6 meters.Chhattisgarh Minor Mineral Rules, 2015

6. (a) Nature, amount and kind of explosives used, if any.
(b)Date when explosive were first used.........................................Name and Signature
ofOwner/Agent /ManagerDate.................................To be sent to :-
1. The Director General, Mines Safety, Govt, of India, Dhanbad.
2. The Controller General, Indian Bureau of Mines, Govt, of India, Nagpur.
3. The District Magistrate of the District where the mine situated.
4. The Mining Officer/Assistant Mining Officer.
Form XIX[See Rule 56 (3)]Model Form for Transfer of Quarry Lease of Minor MineralWhen the
transferor is an individual .......................The indenture made this..............day
of............20.......between...................(Name of the person with address and occupation) hereinafter
referred to as the "transferor" (which expression shall where the context so admits be deemed to
include his heirs executors, administrators, representatives and permitted assignees);OrWhen the
transferor is a Society/Association..................(Name of the society/Association with address and
occupation) and...................(Name of person with address and occupation) hereinafter referred to as
the "transferor" (which expression shall where the context so admits be deemed to include their
respective heirs, executors administrator, representatives and their permitted assignees);OrWhen
the transferor is a registered firm...............(Name of the person with address of all the partners) all
carrying on business in partnership under the firm name and style of.................(Name of the firm)
registered under the Indian Partnership Act, 1932 (9 of 1932) and having their registered office
at..................hereinafter referred to as the "transferor"' (which expression shall where the context so
admits be deemed to include their respective heirs, executors administrators, representatives and
their permitted assignees).OrWhen the transferor is a registered company ............................. (Name
of the company) a company registered under .................................... (Act, under which incorporated)
and having their registered office at.....................(address) hereinafter referred to as the "transferor"
(which expression shall where the context so admits be deemed to include their respective heirs,
executors administrators, representatives and their permitted assignees) of the first part.AndWhen
the transferee is an individual ............................(Name of the person with address and occupation)
hereinafter referred to as the "transferee" (which expression shall where the context so admits be
deemed to include their respective heirs, executors administrators, representatives and their
permitted assignees);OrWhen the transferee is a Society/Association.............................(Name of the
Society/Association with address and occupation) and...........................(Name of person with
address and occupation) hereinafter referred to as the "transferee" (which expression shall where
the context so admits be deemed to include their respective heirs, executors administrators,
representatives and their permitted assignees);OrWhen the transferee is a registered
firm......................(Name of the person with address of all the partners) all carrying on business in
partnership under the firm name and style of.....................(Name of the firm) registered under the
Indian Partnership Act, 1932 (9 of 1932) and having their registered office at........................Chhattisgarh Minor Mineral Rules, 2015

hereinafter referred to as the "transferee" (which expression shall where the context so admits be
deemed to include their respective .heirs, executors administrators, representatives and their
permitted assignees);OrWhen the transferee is a registered company.................................. (Name of
the company) a company registered under ........................................(Act, under which incorporated)
and having their registered office at.......................(address) hereinafter referred to as the
"transferee" (which expression shall where the context so admits be deemed to include their
respective heirs, executors administrators, representatives and their permitted assignees) of the
second part.AndThe Governor of Chhattisgarh hereinafter referred to as the "State Government"
(which expression shall where the context so admits be deemed to be include their respective heirs,
executors administrators, representatives and their permitted assignees) of the third part.Whereas
by virtue of an indenture of lease dated the..............and registered as
No...............On..................(date) in the office of the Sub-Registrar of...............(place) hereinafter
referred to as lease the original whereof is attached hereto and marked "A" entered into between the
State Government (herein-called the lessor) and transferor (therein called the lessee), the transferor
is entitled to search for, win and work the mines and minerals in respect of......................(name of
mineral/s) in the lands described in schedule thereto and also in schedule annexed hereto for the
term and subject to the payment of the rents and royalties and observance and performance of the
lessee's covenant and condition is said deed of lease reserved and contained including a covenant
not to assign the lease or any interest thereunder without the previous sanction of the competent
authority.And Whereas the transferor is now desirous of transferring and assigning the lease to the
transferee and the Competent Authority has at the request of the transferor, granted permission to
the transferor vide order No........................Dated.............to such a transfer and assignment of the
lease upon the condition of the transferee entering into an agreement in and containing the terms
and conditions hereinafter setforth.Now this deed witnesses as follows :
1. The transferee hereby covenants with the State Government that from and
after the transfer and assignment of the lease the transferee shall be bound
by, and be liable to perform, observe and conform and be subject to all the
provisions of all the covenants, stipulations and conditions contained in said
herein before recited lease in the same manner in all respect as if the lease
had been granted to the transferee as the lessee thereunder and he had
originally executed it as such.
2. It is further hereby agreed and declared by the transferor of the one part
and the transferee of the other part that-
(i)The transferor and the transferee declare that they have ensured that the mineral rights over the
area for which the Quarry Lease is being transferred vest in the State Government.(ii)The Transferor
hereby declares that he/she has not assigned, subject; mortgaged or in any other manner
transferred the Quarry Lease now being transferred and that no other person or persons has any
right; title or interest whereunder in the present Quarry Lease being transferred.(iii)The transferor
further declares that he/she has not entered into or made any agreements, contract orChhattisgarh Minor Mineral Rules, 2015

understanding whereby he had been or is being directly or indirectly financed to a substantial extent
by or under which the transferor's operation or understandings were or are being substantially
controlled by any person or body of persons other than transferor.(iv)The transferee hereby declares
that he/she has accepted all the conditions and liabilities which the transferor was having in respect
of such "Quarry Lease".(v)The transferee further declares that he/she is financially capable of and
will directly undertake mining operations.(vi)The transferor has supplied to the transferee the
original or certified copies of all plans of abandoned working in the area and in a belt 65 metre wide
surrounding it.(vii)The transferee hereby further declares that as a consequence of this transfer, the
total area which is held by him under Quarry Leases are not in contravention of the Chhattisgarh
Minor Minerals Rules, 2015.(viii)The transferor has paid all the rent, royalties and other dues
towards Government till the date, in respect of this lease.In witness whereof the parties hereto have
signed on the date and year first above written.
Schedule 8
Location and Area of the LeaseAll the tract of lands situated at village.............(Description of area or
areas) Tehsil ..........District.........Bearing Khasra Nos.............containing an area of.................or
thereabout delineated on the plan hereto annexed and thereon coloured.............and bounded as
follows :-On the North by.....................On the South by......................On the East by......................
AndOn the West by........................Signed byFor and on behalf of the State GovernmentIn the
presence of-
1.
2.
Signature of transferor in the presence of witnesses
1.
2.
Signature of transferee in the presence of witnesses
1.
2.
Form XX{See rule 58 (1)(iii)]Application for Grant of Quarry PermitReceived at............(Place) on
the...............day of.......20.....
  
Date.................20.....To,The Collector.........................................District.......................ChhattisgarhChhattisgarh Minor Mineral Rules, 2015

1. I/we beg to apply for grant of quarry permit for a term of..................years
over....................hectares of land in the area specified in the schedule.
2. A sum of rupees.........................as application fee payable under rules has
been deposited vide challan No................Dated.............at place.
3. The required particulars are given below :-
(i)Name and designation of applicant(ii)Department(iii)Office(iv)Complete postal address, of the
OfficePin CodePhone/Mobile numberE-mail(v)Minor mineral/minerals applied(vi)Production
(Quantity in cubic metres)(vii)Period for which quarry permit required
4. No dues certificate in Form II..............................................
5. (a) A plan (six copies) showing the situation and boundaries of the
area/areas applied for and concession if any, adjoining is/are enclosed. (If
this plan/these plans be considered insufficient, I/we request that the
necessary plan/plans of the area/areas may be prepared in duplicate in your
office at my/our cost.)
(b)Khasrapanchsala............................
6. Means by which mineral is to be raised i.e. by Manual Mining or
Mechanical Mining.................................
7. If crusher is installed, then mention capacity of crusher.................
8. Any other particulars or details which the applicant wishes to furnish.
Schedule 9
Description of the area applied for :-(i)Name of village(ii)Grant Panchayat(iii)Khasra number and
area of each field or part thereof
Khasra Number Area in Hectare
  
  
(iv)Full description of the area applied for with regard to natural
feature-(v)Block(vi)Vidhansabha(vii)Tehsil(viii)Patwari circle number(ix)DistrictChhattisgarh Minor Mineral Rules, 2015

9. List of enclosures :-
(i)(ii)(iii)(iv)(v){||-| Place.....................................| Yours Faithfully|-| Dated.....................................|
Name and Designation|}N.B. - If the application is signed by an authorized agent of the applicant,
power of attorney should be attached.If all the number cannot be entered on this form they should
be continued on a separate sheet attached to it and signed. Where a portion of a khasra number only
is required the approximate area of such portion will suffice.Form XXI[See rule 58 (1) (iv)]Register
of Application for Quarry Permit for Minor MineralsDistrict......................
1.Serial No. ….......................................................................................
2.Date on which application was received
byreceiving officer.….......................................................................................
3.Name of applicant with complete
address, phoneno., email.….......................................................................................
4.Situation and boundaries of the land
appliedfor; 
 (i) Name of the village  
 (ii) Name of Gram Panchayat  
 (iii) Block  
 (iv) Vidhansabha  
 (v) Tehsil  
 (vi) Patwari circle number  
 (vii) Khasra Number  
5.Area in Hectares (Khasra-wise)  
6.Particulars of minerals applied for.  
7.Quantity of mineral required in cubic
meters. 
8.Period for quarry permit.  
9.Application fee paid.  
10.Remarks (Details of project for which
mineral isrequired). 
11.Final disposal of applications together
withnumber and date of the order. 
12.Signature of the officer.  
Form XXII[See rule 58 (1)(v)]Form of Grant of Quarry PermitQuarry permit
no..............Place...........Date.............Whereas, Shri (Name and designation) applied for grant of
quarry permit for..............cubic metres of................(Name of Minor Minerals) from Khasra
No..............of Village............... Panchayat.............Tehsil.............District............under
Rule.................of the Chhattisgarh Minor Mineral Rules,2015 and has paid an application fee of
Rs.........Chhattisgarh Minor Mineral Rules, 2015

2. Permission is hereby granted to quarry, collect, remove and
transport....................(mineral) from the area indicated on the plan annexed
hereto for the project.............(Name of project).................department/Public
Sector Undertaking of the State/Central Government located
at........................(village).................(Patwari Halka
No.)..............(Panchayat)..............(Tehsil)..............(District).
3. The Quarry permit shall be valid for....................(period) from................
to............
4. The Quarry permit shall be governed by the following conditions namely-
(a)The holder of Quarry permit shall maintain complete and correct account of the mineral removed
and transported from the area;(b)The holder of Quarry permit shall allow Deputy Director/Mining
Officer/Assistant Mining Officer/Mining Inspector or any officer authorized by the Collector or Zila
Panchayat/Janpad Panchayat/ Gram Panchayat to inspect quarrying operations and verify the
accounts;(c)No sooner the permitted quantity is transported within the time period of 30 days or
earlier, original of all transit pass, such unused transit passes together with a complete statement of
the quantities duly certified by the Officer of the concerned department shall be furnished to the
Sanctioning Authority;(d)The holder of Quarry permit shall obtain all permissions/consents from
the competent authority under any Act and Rules applicable for excavation or removal of the
minerals from the area;(e)The holder of Quarry permit shall submit by the 10th of every month, to
the collector and Gram Panchayat, a return in Form XV;(f)Any other condition, the sanctioning
authority may deem fit.Enclosure. - Plan showing area granted under quarry permit.Signature of the
Competent AuthorityWith seal of officeTo,Shri..................................................Copy to:-
1. Mining Officer/Assistant Mining Officer of the District.
2. Janpad Panchayat
3. Gram Panchayat
Signature of the Competent AuthorityWith seal of officeForm XXIII[See rule 72(1)]Format for
maintaining records of consumption of minor minerals in construction of residential building or
buildings for sale and commercial building or buildings for sale/rental purpose
1.Name, address, phone and e-mail of the
person/s,company, firm, society/ association :-.....................................................................
2.Details of construction work: -  
 (i) Location  
 (ii) Type of construction (road/building, etc.)  Chhattisgarh Minor Mineral Rules, 2015

 (iii) Proposed area of civil construction  
 (iv) Mineral wise estimated quantity requiredfor the
proposed civi work: 
3. Quantity of the minor minerals required and Source, (month
.......................year) :-
S. No. Date Mineral Vehicle No. Name of the Quarry Transit Pass No. Quantity (in cubic metres)
1 2 3 4 5 6 7
       
       
       
       
       
4. Total quantity of minerals procured during the month.............. 20.....
  (Quantity in cubic meters)
Name of mineralNo. of
trucksTotal Quantity
procured in the
monthQuantity used in the
month for civil
constructionBalance stock
at the siteRemark
1 2 3 4 5 6
(a) Metal/gitti      
(b) Sand      
(c) Murrum      
(d) Bricks
(Quantity in
numbers)     
(e) Flagstone/
natural tiles     
(f) Others      
5. Proposed period of construction
6. Any other information :
Place:............... Signature
Date:................ Name in full and Designation
Form XXIV[See rule 72(1)]Quarterly Report of consumption of minor minerals in construction of
residential building or buildings for sale and commercial building or buildings for sale/rental
purpose[The form duly filled in shall be sent so as to reach the concerned authority within 30 days
after the expiry of every quarter]To,The Officer-In-Charge,Mining Section,Office of theChhattisgarh Minor Mineral Rules, 2015

Collector,District............................Subject : Quarterly Report of consumption of minor minerals for
the period from ......................to..........
1.Name, address, phone and e-mail of the
person/s,company, firm, society/ association :-.....................................................................
2.Details of construction work: -  
 (i) Location  
 (ii) Type of construction (road/building, etc.)  
 (iii) Proposed area of civil construction  
 (iv) Mineral wise estimated quantity requiredfor the
proposed civil work: 
3. Total quantity of minerals produced/consumed/utilised/balanced during
the quarter from............. to ...............
  (Quantity in cubic meters)
Name of mineralNo. of
trucksTotal Quantity
procured in the
monthQuantity used in the
month for civil
constructionBalance stock
at the siteRemark
1 2 3 4 5 6
(a) Metal/gitti      
(b) Sand      
(c) Murrum      
(d) Bricks
(Quantity in
numbers)     
(e) Flagstone/
natural tiles     
(f) Others      
5. Proposed period of construction
6. Any other information :
Place :.......... Signature
Date :.......... Name in full and Designation
Form XXV[See Rule 81 (1)]Model Form of Application for Appeal(To be submitted in triplicate)
1.Name and address of individual(s), society, firmor
company, applying. 
2.Phone no. and email.  
3.Profession.  
4.Name of authority, Order number and date  Chhattisgarh Minor Mineral Rules, 2015

againstwhich the appeal is filed (copy of order
attached)
5.Minor mineral or minerals for which the appealis
filed. 
6.Details of the area in respect of which theapplication
is filed. 
{|
 District Tehsil Village PanchayatKhasra No. and
Total area
      
|-| 7.| Whether application fee has been deposited inthe manner prescribed. (Original receipt to be
attached.)||-| 8.| Whether the appeal/review/revision applicationhas been filed within time
specified if not, the reasons for notpresenting it within the prescribed limits as provided for
inrules.||-| 9.| Name and complete address of the party/partiesimpleaded.||-| 10.| No. of copies
attached.||-| 11.| Synopsis of the case (Maximum two pages).||-| 12.| List of dates and events.||-|
13.| Brief facts of the case.||-| 14.| Grounds of appeal.||-| 15.| Prayer.||-| 16.| If the appeal
application has been filed by theholder of power of Attorney, the Power of Attorney, to
beattached.||}Place :...................Date :....................Signature of the ApplicantChhattisgarh Minor Mineral Rules, 2015

