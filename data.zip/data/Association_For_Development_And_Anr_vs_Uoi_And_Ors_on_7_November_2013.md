Association For Development And Anr. vs Uoi And Ors. on 7
November, 2013
Author: S.Ravindra Bhat
Bench: S. Ravindra Bhat, Najmi Waziri
* IN THE HIGH COURT OF DELHI AT NEW DELHI
                                         Reserved on: 30.10.2013
                                        Decided on: 07.11.2013
+      W.P.(C) 1055/2011, C.M. APPL. 2239/2011, 5093/2013 &
       13341/2013
       ASSOCIATION FOR DEVELOPMENT AND ANR.
                                                           ..... Petitioners
                           Through: Sh. Colin Gonsalves, Sr. Advocate
                           with Sh. Tariq Adeeb, Advocates.
                                        versus
       UOI AND ORS.                                      ..... Respondents
Through : Mr. Sidharth Luthra, ASG with Mr. Sachin Datta, Sh. Gurmohan Singh Bedi and Sh.
Vineet Tayal, Advocates for Resp.
No.1.
Ms. Geeta Luthra, Sr. Advocate with Mr. Manoj K. Mishra, Advocate for Resp. No.2.
Ms. Shobha, Sh. R.N. Mahlawat, Advocates, for Resp No.3.
CORAM:
HON'BLE MR. JUSTICE S. RAVINDRA BHAT HON'BLE MR. JUSTICE NAJMI
WAZIRI MR. JUSTICE S. RAVINDRA BHAT %
1. The petitioners, in these writ proceedings, under Article 226 of the Constitution of
India, challenge the appointment of the second and third W.P. (C) 1055/2011 Page 1
respondent (hereafter "the private respondents" when referred to collectively, and
referred to individually by their names as Dr. Dube and Mr. Tikoo, respectively) as
members of the National Commission for Protection of Child Rights (hereafter
"NCPCR" or "the Commission") under the Commissions for Protection of ChildAssociation For Development And Anr. vs Uoi And Ors. on 7 November, 2013

Rights Act, 2005 (hereafter "the Act") and to that end, quash the notification issued
on 22-11-2010.
2. The first petitioner, Association for Development is represented through its
President, Raj Mangal Prasad; the second petitioner HAQ Foundation, (hereafter
"HAQ") is represented through its Co-Director, Ms. Bharti Ali. The petitioners allege
that they wish, by these proceedings, to highlight the arbitrary nature of procedure
adopted by the first respondent (the Union Government, hereafter called "UOI") in
calling for applications of eligible candidates, and ultimately selecting the private
respondents, as members of the Commission. The Petition claims that the Director of
the first respondent, Raj Mangal Prasad, in addition to associating himself in public
interest in these proceedings, is also seeking to agitate his private right claiming that
as candidate who held himself out to the position of member of the NCPCR, his claim
and application was wrongly overlooked.
Both petitioners however state that:
"More importantly, however, is the public interest part in as much as the Petitioners
are very aggrieved, by the non consideration of several meritorious persons for
appointment to the post. The Petitioners would hardly have any grievance if such
meritorious persons were selected and they were not. The main concern of the
Petitioners is that the practice of appointing persons for collateral reasons must cease
and the best in the country should run statutory institutions such as the
Commission."
W.P. (C) 1055/2011 Page 2 It is further averred that the first petitioner was set up in
1993 with the objective of uplifting the weaker and voiceless sections of society, and
that it has, through its endeavours over the years, sought to intervene in different
ways to improve the quality of governance in the country. The petition avers that
HAQ was registered as a society in 1999 and is an NGO that works towards the
recognition, promotion and protection of rights of all children by mainstreaming
their concerns into all developmental planning and action, establishing child rights as
a core developmental indicator, monitoring state performance and holding state
accountable. It is stated that HAQ believes that the State is the primary duty bearer in
the realization of the rights of all children. Children's rights must therefore become
an integral component of good governance.
3. The petitioners contend that they are deeply concerned that membership of the
NCPCR be filled only on the basis of merit, since the Commission is the watch dog of
body for implementing children's rights. They further underline the necessity of the
UOI adopting a fair and transparent procedure in selection and appointment of
members of the Commission, which ought to stand up for fairness, transparency and
accountability. The petitioners refer to Section 3 of the Act, and highlight that in its
terms, the UOI has to appoint six members, including two women, from among sixAssociation For Development And Anr. vs Uoi And Ors. on 7 November, 2013

specified categories or disciplines (education, child health, care, welfare or child
development; juvenile justice or care of neglected or marginalized children or
children with disabilities; elimination of child labour or children in distress; child
psychology or sociology and laws relating to children). It is stated that the members
of the NCPCR were first appointed in 2007 for three years their term ended on
10-4-2010. On 18-05-2010 Dr. Sinha was re-appointed as Chairperson of the NCPCR.
The petitioners contend that the Act and Rules framed under it are silent about W.P.
(C) 1055/2011 Page 3 the selection process in respect of members of NCPCR, which
has led to concerns about lack of transparency. This was the reason for an earlier
proceeding (WP 10296/2009) before this Court under Article 226 of the Constitution
of India. In those proceedings, the Court gave necessary orders. The UOI, Ministry of
Women and Child Development had to implement those directions to follow a
transparent process of selection. As part of this, particulars of members of the
Selection Committee as well as selected candidates together with their particulars
had to be put up on the Ministry's website.
4. It is stated further that a selection committee comprising the Minister in charge,
the Secretary to the Department of Women and Child Welfare and an independent
expert of eminence in the field of child rights was constituted in April 2010; the
expert was Ms. Padma Seth. The same month, she resigned, alleging that the Ministry
was pressurizing her to select certain candidates against whom cases were pending in
the High Court. The Petitioners quote a news report which stated that Ms. Seth, in a
letter asked the minister to add special invitees as she felt the committee was too
small. They further rely on a letter written by Ms. Seth to the Prime Minister which
stated that if the UOI's action was challenged, the Government would be
embarrassed. Ms. Seth was replaced by Dr. Shyama Chona; the date of her induction
into the committee is unknown to the petitioners. The petition relies on the response
of the CPIO of the Ministry to a query posed by Ms. Sonam Gulati of an NGO,
Pratinidhi, to the effect that no advertisement was issued by the Ministry to fill up
posts of Members. The three member committee, states the petition, short listed five
candidates out of a list of 165 names who had responded, according to the facts
disclosed in the UOI's website; they were Ms. Sukhanya Bharatram, Dr. Yogesh Dube,
Ms. Dipa Dixit, Dr. Dinesh Laroia and Shri Vinod Kumar Tikoo.
W.P. (C) 1055/2011 Page 4 The UOI, in compliance with the order in the previous
writ petition, put up these names in the website on 01-10-2010 for information. The
UOI put up the selected candidates' CVs but no other documents to disclose the
public about suitability of the selected candidates.
5. It is alleged that the Committee never interacted with, or interviewed the
candidates; nor is there anything to show that it had found evidence to enable
assessment of validity of allegations made in the press about Dr. Dube. Reference is
made to another proceeding, WP 7200/2010, filed by the petitioners regarding
unsuitability of the candidates and the UOI's failure to comply with orders of theAssociation For Development And Anr. vs Uoi And Ors. on 7 November, 2013

Court of 03-02-2010 to implement a transparent process for selection of members.
The court had directed the petition to be treated as a representation and an
appropriate order to be made by the UOI, reserving liberty to the petitioners to
proceed in accordance with law in respect of any order to be made on the
representation. The petitioners refer to media-expressed concerns about the
functioning of the NCPCR and its inability to settle any of the 227 cases pending since
its inception as on 5-4-2010, as well as adverse criticism about Dr. Dube and Mr.
Tikoo that they withheld vital information in the bio data submitted to the Selection
Committee. It is submitted that the UOI sought to only technically comply with the
previous directions of this court in respect of the selection procedure, violating it
completely in the spirit. The Selection Committee, according to the petitioners, took
no steps to verify credentials of the private respondents. They also submit that these
concerns - articulated to the UOI, in the representations− were brushed aside in the
letter of 09-12-2010.
6. The details of the meetings of the committee are mentioned by the petitioners.
Reference is made to the meeting of 29-04-2010, when names of 9 candidates were
short listed to fill 6 positions, without disclosing any W.P. (C) 1055/2011 Page 5
reasons. In the next meeting of 09-07-2010, various candidates' names were
dropped, including that of Mr. Gerry Pinto. Others had been included in the short
list, which was surprising, because some of the candidates' applications had been
received at the time of the initial meeting, such as Mr. Shashank Shekhar. Nothing
was disclosed as to why their names were suddenly considered when they had not
made it in the short list the first time. The meeting of 29-07-2010 had suddenly
decided that representation of SC/ST category was essential; Dr. Paul Divakar (SC)
was suddenly included, though his application had been received in before the first
short list (which did not contain his name). However, after this meeting his name was
not mentioned, or inexplicably, not considered. It is alleged that though between 3 to
5 individuals' names were short listed in the categories of education, health, juvenile
justice or care, child labour and child laws, only one person was short listed for the
person relating to child psychology or social welfare, i.e. Shri Tikoo, who was totally
unqualified. The meetings of 29-04-2010, 09-07-2010 and 27-10-2010 considered 3
individuals for positions relating to Juvenile Justice, i.e. Raghavenddhiraa, J. P.
Tiwari and Pradeep Rahunandan. Without any explanation, the committee ignored
the short list and selected Ms. Amita Dhanda on 21-09-2010; her name was however
excluded by the Ministry on 01-10-2010 when it excluded her name, announcing that
her CV was not on its website. The petitioners also highlight the discrepancy about
number of the committee's meetings; the response to an RTI query stated that five
meetings were held, whereas the website of the Ministry mentioned that four
meetings were held. The claim of UOI that detailed discussions were held between
members of the Selection Committee, is sought to be disputed by stating that there is
no material to support the assertion. The petitioners state that a large number of
W.P. (C) 1055/2011 Page 6 individuals who were not even short listed were eminently
suited for the post, due to their qualifications, expertise and experience.Association For Development And Anr. vs Uoi And Ors. on 7 November, 2013

7. The petitioners allege that Mr. Dube concealed crucial information about his
affiliation to the ruling party. They state that he is a close associate of Sanjay
Nirupam, the Congress MP from Mumbai North. The petition also highlights a
discrepancy between the said candidates' assertions regarding his qualifications, in
the instant selection process and what was declared by him when he stood for
elections. He had also claimed to be the President of the Akhil Bharatiya Hindu
Muslim Ekta Mahasangh without elaborating whether that body is registered. The
petitioners state that several outfits which Mr. Dube claims to have been associated
with are found to not be registered. The petitioners further rely on a news report that
Mr. Dube ran a beer bar. The credentials of Mr. Tikoo to hold the position too are
disputed; the petitioners state that his CV clearly establishes that he was working in a
public sector enterprise for 23 years and that he was an intern at the time of pursuing
his masters' degree in social work. The petitioners allege that this respondent had
worked his entire career in a bank, where the husband of Ms. Krishna Tirath, the
Minster of Woman and Child Development was working under him. This, allege the
petitioners amount to nepotism and fraud. Mr. Tikoo's claim in the CV that he had
done work in the field of child rights is disputed.
8. On the strength of all these allegations, the petitioners state that the selection
procedure was not transparent or fair but was arbitrary. Those with qualifications
and experience better than the private respondents were kept out of consideration;
the UOI never adopted any fair method of inviting applications. The minute keeping
in respect of meetings was not proper and no explanation is forthcoming as to why
eminently suited and better qualified candidates were never considered. Nor is there
any explanation as W.P. (C) 1055/2011 Page 7 to why names in the short list of
candidates was sought to be altered time and again.
9. It is argued by Mr. Colin Gonzalves learned senior counsel, that the selection
procedure adopted for appointing the two members, i.e. M/s Dube and Tikoo was
tainted and arbitrary. It is argued that the committee did not call for any names from
the general public by adopting a fair method, such as publication of vacancies to
enable suitable candidates to apply. Furthermore, the entire procedure adopted by
the Committee reeked of arbitrariness and favoritism. Why only 9 candidates were
short listed; what qualities were possessed by them, to render them suited for the
post; what made the committee reject the candidatures of 160 other candidates; why
names were included and dropped in successive committee meetings, have not
emerged from the record.
10. It is submitted that a look at the various minutes of meeting of the committee
would reveal that neither the merits of the candidates not the suitability of such
candidates to occupy the post having regard to the relative qualifications and
experience was ever discussed. Counsel stressed upon the fact that the NCPCR is a
specialized body, conceived to address children related issues. Emphasizing that the
Act was brought into existence to fulfill India's obligations under the Convention onAssociation For Development And Anr. vs Uoi And Ors. on 7 November, 2013

the Rights of the Child, in 1992, it was argued that Parliament intended the body
(NCPCR) to be a meaningful authority, which would study and deal with not only
issues, but also best practices and suggest policies to the appropriate authorities, with
a view to achieving the obligations of the country under the Convention, and ensure
that children are assured their rightful place in the nation.
11. Characterizing the selection process culminating in the appointment of the second
and third respondents as one reeking in arbitrariness, it is W.P. (C) 1055/2011 Page 8
contended that their appointments can be justified only on the ground of nepotism
and political patronage. It was submitted that the impugned appointments have
made a mockery of the NCPCR and undermined its prestige and dignity. Responding
to the plea of lack of locus standi, (adopted by the UOI and the private respondents)
Counsel relied on the decision reported as State Of Punjab vs Salil Sabhlok & Ors
(Civil Appeal Nos. 1365-1367/ 2013 decided by Supreme Court).
12. The UOI's position is that the members appointed by it, to the NCPCR were on the
basis of recommendations of the Committee set up in accordance with the
suggestions of the Court in WP 10296/2009. It is contended that the present petition
is bereft of merit and that the petitioners have not disclosed how they possess locus
standi to maintain these proceedings. The learned Additional Solicitor General (ASG)
contends that the appointment of the two private respondents has neither violated
the terms of any statute, nor statutory rules, or any guidelines. The said two members
were selected and recommended for appointment on the basis of extensive
deliberations of the Committee and the Court should refrain from conducting an
enquiry into the merits of the decision. It was stressed that even in the previous writ
petition, the Court consciously refrained from spelling out any guidelines, having
regard to the terms of the statute, which vested discretion with the UOI. All that
could be properly enquired into in these proceedings, according to the UOI is
whether the process was objective, did it eschew irrelevant considerations and if it
was bona fide. If there is no material to suggest otherwise - as in the present case -
the allegations of public interest petitioners, or even those who unsuccessfully
applied for the same position, as in the case of Shri Prasad, are unfounded
apprehensions which should not impel the court into upsetting what are clearly legal
appointments. Reliance was placed on the decision reported as W.P. (C) 1055/2011
Page 9 High Court of Gujarat v Gujarat Kisan Mazdoor Panchayat 2003 (4) SCC 71
for the proposition that quo warranto proceedings cannot be a weapon to control the
executive from making public appointments. He also relied on Rajesh Awasthi v
Nand Lal Jaiswal 2013 (1) SCC 501 to say that the court is concerned only with
eligibility and legality of appointments to public offices, not suitability of individual
candidates, in proceedings under Article 226 of the Constitution of India.
13. It was argued - on the basis of the counter affidavit filed in these proceedings that
the Selection Committee first met on 06-04-2010 under the chairmanship of the
Minister for Woman and Child Development. It included the Secretary of theAssociation For Development And Anr. vs Uoi And Ors. on 7 November, 2013

Ministry and Dr. Padma Seth as an expert. The UOI denies allegations that any
pressure was applied on anyone for the selection of any candidate and submits that
Dr. Seth expressed her inability to attend the meeting because her sister was ill and in
ICU. She further stated, in her letter dated 21-04-2010 that selecting candidates was
a challenging task which could not be undertaken by her; as a result she requested
that she be relieved from the duties as a member and someone else be appointed
instead. Therefore, Dr. Shyama Chona was appointed as member of the Committee.
The UOI denies the accuracy of the news report dated 19-05-2010; it also denies
having received any letter from Dr. Seth asking special invitees to be asked to join the
deliberations of the Selection Committee. It was argued that every effort was made by
the UOI to ensure that the provisions of the Act were not violated; the Selection
Committee tasked to make recommendations for the position of members functioned
effectively and without interference. In the circumstances, submits the learned ASG,
the Court should not substitute its opinion for that of the UOI, which took into
consideration all relevant materials objectively, fairly and W.P. (C) 1055/2011 Page
10 in a bona fide manner, while selecting the private respondents as members of
NCPCR and notifying their appointments on 22-11-2010.
14. Ms. Shobha, learned counsel, argued on behalf of Mr. Tikoo and contended that
the present litigation is not maintainable. She relied on the rulings of the Supreme
Court, reported as State of Uttranchal Vs. Balwant Singh Chaufal & Ors, (2010) 3 SCC
402, to say that the so-called private interest of Mr. Prasad is the real motive behind
this litigation. It was stressed that the petitioners cannot be said to have any bona
fide interest in the appointment of members of the NCPCR because at best they could
have
- if at all sought a writ of quo warranto. However, the pleadings in the writ petition go
beyond such relief, and invite the court to make an in-depth inquiry into the merits of
the appointments, which is clearly beyond the permissible limits of jurisdiction under
Article 226 of the Constitution of India.
15. Learned counsel placed reliance on the judgment of the Supreme Court, reported
as Centre for Public Interest Litigation and Anr v. Union of India & Anr [(2011) 4 SCC
1. It was argued that in the absence of clear violation of statutory provisions and
regulations laying down the procedure for appointment, the High Court has no
jurisdiction even to issue a writ of quo warranto. Learned counsel submitted that
even this Court, in the previous writ petition (WP 10296/2009) consciously avoided
framing guidelines in respect of how the selection committee ought to function, what
kind of experts should man it and the nature of qualifications that members of
NCPCR should possess and the extent of powers that the UOI has. It was argued that
in fact, the Court stated that since the Act was silent on many aspects - apart from
mentioning the disciplines which the members were to be drawn from - in these
circumstances, it would be perilous for the court to conduct an indepth merit analysis
of the merits of W.P. (C) 1055/2011 Page 11 the candidates and conclude that theAssociation For Development And Anr. vs Uoi And Ors. on 7 November, 2013

private respondents were somehow less deserving than others. It was also contended
that in fact, the dispute sought to be raised is a service matter which cannot be
entertained in public interest litigation. In this context, she relied on decisions
reported as R.K. Jain v. Union of India & Ors. [(1993) 4 SCC 119], Dr. Duryodhan
Sahu & Ors. v. Jitendra Kumar Mishra & Ors. [(1998) 7 SCC 273] Dattaraj Nathuji
Thaware v. State of Maharashtra & Ors. [(2005) 1 SCC 590], and Ashok Kumar
Pandey v. State of West Bengal [(2004) 3 SCC 349].
16. It was submitted that the allegations levelled against Mr. Tikoo's being an officer
superior to Ms. Tirath's husband, in the State Bank, constituting the primary reason
for his appointment as NCPCR is false. It was highlighted that factually, the
Minister's husband worked in the same branch as Shri Tikoo only for a year. Mr.
Tikoo had voluntarily retired from the service of the bank over a decade ago. Counsel
emphasized that he held a Master's degree in social work, and had several years' field
experience to his credit. It was submitted that before his selection and appointment,
the UOI had conducted verification of all candidates' credentials and claims. Counsel
also submitted that the President of the first petitioner, Shri Prasad, and Mr. Tikoo
studied from the same institution, i.e. the Delhi University and that Mr. Tikoo had
secured better marks and position in that course. He also had wide experience in the
field of child development, having conducted several programmes successfully for
various organizations. His credentials to hold the post could not therefore be
questioned.
17. Dr. Dube's objections to the maintainability of the petition, and limited
jurisdiction of the Court, were on the same lines as those alleged on behalf of Shri
Tikoo. It was argued in addition on his behalf, by Ms. Geeta Luthra, learned senior
counsel that the allegations about his owning a beer bar are baseless. She argued that
mere political affiliation with the ruling W.P. (C) 1055/2011 Page 12 party could not
be a ground for disqualifying a candidate from consideration. It was argued that Dr.
Dube's credentials and eligibility for appointment as member should not be gone
into. The UOI had verified the claims made in his curriculum vitae and his
application was considered to be valid, and recommended not by one member, or
officer, but a three member committee, set up in accordance with this Court's
directions in the previous writ petition. Under these circumstances, the Court should
be circumspect in conducting a "merit" review which would result in the court
substituting its opinion for the wisdom of the statutory designated authority, i.e. the
Central Government. She argued that as a consequence, the court should dismiss the
petition. It was argued that no fault can be found with the selection procedure, since
the statute is silent and the mechanism adopted was fair and reasonable.
Analysis and Findings
18. The NCPCR was established in March 2007 under the Act. Its object is to ensure
that laws, policies, and mechanisms are in tune with the child rights perspective asAssociation For Development And Anr. vs Uoi And Ors. on 7 November, 2013

envisioned in the Constitution of India as well as the UN Convention on the Rights of
the Child. The Commission outlines its vision (in its website http://ncpcr.gov.in/) as
follows:
"The Commission visualises a rights-based perspective flowing into National Policies
and Programmes, along with nuanced responses at the State, District and Block
levels, taking care of specificities and strengths of each region. In order to touch every
child, it seeks a deeper penetration to communities and households and expects that
the ground experiences inform the support the field receives from all the authorities
at the higher level.
Thus the Commission sees an indispensable role W.P. (C) 1055/2011 Page 13 for the
State, sound institution-building processes, respect for decentralization at the level of
the local bodies at the community level and larger societal concern for children and
their well-being."
Section 3 of the Act outlines the composition of the Commission; to the extent it is relevant, that
provision is extracted below:
3. (I) The Central Government shall, by notification, constituted a body to be known
as the National Commission for Protection of Child Rights to exercise the powers
conferred on, and to perform the functions assigned to it, under this Act.
(2) The Commission shall consist of the following Members, namely; -
(a) a Chairperson who is a person of eminence and has done outstanding work for promoting the
welfare of children; and
(b) six Members, out of which at least two shall be women, from the following fields, to be appointed
by the Central Government from amongst persons of eminence, ability, integrity, standing and
experience in,-
(i) education;
(ii) child health, care, welfare or child development;
(iii) juvenile justice or care of neglected or marginalized children or children with disabilities;
(iv) elimination of child labour or children in distress;
(v) child psychology or sociology; and
(vi) laws relating to children."Association For Development And Anr. vs Uoi And Ors. on 7 November, 2013

Section 4, which is somewhat relevant, provides as follows:
W.P. (C) 1055/2011 Page 14 "4. The Central Government shall, by notification, appoint the
Chairperson and other Members:
Provided that the Chairperson shall be appointed on the recommendation of a three
member Selection Committee constituted by the Central Government under the
Chairmanship of the Minister in-charge of the Ministry of Human Resource
Development."
19. In the previous writ petition, disposed of by this Court (Association For
Development vs Union of India WP 10296/2009 decided on 03-02-
2010, this court recorded the assurance on behalf of the UOI about the process of appointment of
Members of NCPCR:
"The Learned Solicitor General without prejudice to his legal contentions, after
obtaining instructions states that the Govt. of India desires the composition of the
Selection Committee for selection of Chairperson and members to be left to be
decided by and with the Minister in-charge of the Ministry of Human Resource
Development as Chairperson of the Selection Committee. It is however assured that
the suggestions aforesaid of this Court will be kept in view while deciding the
composition of the Selection Committee and at least one member of the Selection
Committee shall be an independent expert of eminence in the field of child rights or
welfare. The Learned Solicitor General has further assured that immediately after
completing the selection process and at least 30 days before the notification of
appointment, the particulars of the members of the Selection Committee as well as of
the selected candidate/s together with their qualification, experience and expertise
shall be put up on the website of the Ministry of Human Resource Development. The
Learned Solicitor General has contended that the aforesaid will allay the
apprehensions expressed and should be allowed to be tested in the first instance."
The Court had then noticed that the statute (i.e. the Act) was silent about the manner or procedure
of appointments. The process indicated in a sense aligned the statutorily prescribed mandate
(contained in proviso to Section 4 W.P. (C) 1055/2011 Page 15 in respect of appointment of the
Chairperson of the Commission) with the procedure to be followed for appointment of members, i.e.
by selection through a three member Committee. The Court observed that it would not re-cast the
words of the statute, or read into it requirements which are not spelt out. After quoting from Global
Energy Ltd. Vs. Central Electricity Regulatory Commission AIR 2009 SC 3194 that the endeavour of
the law is to reflect a framework of neutrality and objectivity and "to put sphere of general
decision-making outside the discretionary power of those wielding governmental power" this Court
observed that the Minister "would have regard to the aforesaid principles in choosing the other
members of Selection Committee and also consider framing guidelines for constitution of Selection
Committee to eliminate allegations of arbitrariness from future appointments and bring moreAssociation For Development And Anr. vs Uoi And Ors. on 7 November, 2013

transparency and objectivity therein."
20. This Court is to be guided by the above decision, and confine its enquiry as to whether the
appointments challenged are (1) contrary to the statute insofar as the private respondents do not
possess any qualification or do not fulfil any eligibility condition; (2) procedurally illegal or
irregular; (3) not in bona fide exercise of power.
21. So far as the first ground, i.e. with respect to the maintainability of the present proceeding goes,
the private respondents attack the locus standi of the first petitioner association, on the ground that
its president, Shri Prasad, was himself a candidate. It is submitted that the petition at his behest is
barred, because he has a private interest, and the pleadings clearly mention that the proceedings are
more to highlight that other allegedly more meritorious candidates were not selected. Significantly,
there is no challenge to the second petitioner's locus standi. There is yet another W.P. (C) 1055/2011
Page 16 significant aspect- the first petitioner association had approached this court as a petitioner
in WP 10296/2009 which was disposed off on 03-02-2010 recording the statements on behalf of the
UOI. The reliance by the private respondents on Dr. Duryodhan Sahu; Dattaraj Nathuji Thaware
(supra) no doubt indicate that a "service matter" cannot be the subject matter of a public interest
litigation. Yet, N. Kannadasan v Ajay Khose (2009 [7] SCC
1) is an authority for the proposition that such litigation is maintainable if the statutory
prescriptions are not met with, in respect of the public office, or if the relevant materials are
overlooked or not made available to the executive government or the selecting body.
22. Traditionally, a writ of quo warranto could be applied for by anyone complaining that the holder
of a public office was not entitled to appointment by reason of his not fulfilling the requirements
spelt out by statute to such office. The courts consistently held that anyone could complain of such
inadequacy, and the courts would investigate that aspect; though not a writ of right, yet, if the
complaint was well grounded, the courts would not hold back the relief, since its denial would result
in a pretender, or one unsuited by law to hold it, continuing to hold public office (Ref Statesman v
H.R. Deb AIR 1968 SC 1495; and Mir Ghulam Hussan & Ors. vs The Union Of India AIR 1973 SC
1138, both judgments by Constitution Benches). There are other judgments in the same vein: Shri
Kumar Prasad v. Union of India and Others [(1992) 2 SCC 428] and Dr. Kashinath G. Jalmi and
Another v The Speaker and Others, (1993) 2 SCC
703. The Supreme Court held that "while examining if a person holds a public office under valid
authority or not, the court is not concerned with technical grounds of delay or motive behind the
challenge, since it is necessary to prevent continuance of usurpation of office or perpetuation of
W.P. (C) 1055/2011 Page 17 an illegality." (Kashinath G. Jalmi, supra). In Centre for Public Interest
Litigation (supra) itself, the Supreme Court held that "Before a citizen can claim a writ of quo
warranto he must satisfy the court inter-alia that the office in question is a public office and it is held
by a person without legal authority and that leads to the inquiry as to whether the appointment of
the said person has been in accordance with law or not. A writ of quo warranto is issued to prevent a
continued exercise of unlawful authority."Association For Development And Anr. vs Uoi And Ors. on 7 November, 2013

23. Having regard to the undisputed facts of this case, i.e., that the previous litigation was initiated
at the behest of the first petitioner association and there being no dispute that the second petitioner
is an association, concerned and involved with child rights issues, with field experience for 13 years,
the Court is of opinion that the present petition is maintainable as a public interest litigation. The
mere circumstance that the President of the first petitioner was a candidate who had applied for
appointment would not bar scrutiny by the Court, especially in view of the fact that the second
petitioner is a party to the present proceeding.
24. The next aspect is to the breadth of judicial review. In this respect, the Court is cognizant of the
limitations placed upon it by the very nature of public law proceedings, where procedural regularity,
compliance with statute, fairness and bona fides (or lack of it) are the only grounds of judicial
scrutiny. The Court would desist from donning the mantle of what has been termed as a "primary
decision maker" ( Union of India & Another vs. G. Ganayutham AIR 1997 SC 3387) and test the
wisdom of the appointment. In other words, as held in Centre for Public Interest Litigation (supra)
the court does not sit in appeal over the opinion of the authority or committee required to
recommend names for appointments (the HPC in that W.P. (C) 1055/2011 Page 18 case, under the
concerned Act of 2003). The role of the court was delineated as follows:
"What we have to see is whether relevant material and vital aspects having nexus to
the object of the 2003 Act were taken into account when the decision to recommend
took place on 3rd September, 2010. Appointment to the post of the Central Vigilance
Commissioner must satisfy not only the eligibility criteria of the candidate but also
the decision making process of the recommendation [see para 88 of N. Kannadasan
(supra)]. The decision to recommend has got to be an informed decision keeping in
mind the fact that CVC as an institution has to perform an important function of
vigilance administration. If a statutory body like HPC, for any reason whatsoever,
fails to look into the relevant material having nexus to the object and purpose of the
2003 Act or takes into account irrelevant circumstances then its decision would stand
vitiated on the ground of official arbitrariness."
Elaborating further, it was held that:
"While making recommendations, the HPC performs a statutory duty. Its duty is to
recommend. While making recommendations, the criteria of the candidate being a
public servant or a civil servant in the past is not the sole consideration. The HPC has
to look at the record and take into consideration whether the candidate would or
would not be able to function as a Central Vigilance Commissioner. Whether the
institutional competency would be adversely affected by pending proceedings and if
by that touchstone the candidate stands disqualified then it shall be the duty of the
HPC not to recommend such a candidate..."
As to the scope and nature of review, the Court held that the merits of the decision cannot be gone
into in judicial review:Association For Development And Anr. vs Uoi And Ors. on 7 November, 2013

"We reiterate that Government is not accountable to the courts for the choice made
but Government is accountable to the courts in respect of the lawfulness/legality of
its decisions W.P. (C) 1055/2011 Page 19 when impugned under the judicial review
jurisdiction. We do not wish to multiply the authorities on this point..."
25. A pertinent decision on the subject is Rajesh Awasthi v Nandlal Jaiswal 2013 (1) SCC 501 that
had examined the appointment to the Electricity Regulatory Commission under the Electricity Act,
2003; the relevant provision (Section 84 (1)) stated that the Chairperson and members "shall be
persons of ability, integrity and standing who have adequate knowledge of, and have shown capacity
in, dealing with problems relating to engineering, finance, commerce, economics, law or
management." The High Court had after considering the minutes of the Selection Committee as well
as the bio data, concluded that the statutory requirements had not been fulfilled. Repelling the
appellant's contention of judicial review overreach, the Supreme Court held that quo warranto is
always available to highlight breach of statutory provisions, which might expose the public office
holder to the charge of being a pretender to it. Deepak Misra, J, who delivered a concurring
judgment, emphasized the necessity of adhering to the statute, and most crucially, the necessity of
intellectual objectivity which is to be brought to bear while considering the candidature of
individuals:
"25. It is manifest in the selection of the appellant that there is absence of
"intellectual objectivity" in the decision making process. It is to be kept in mind a
constructive intellect brings in good rationale and reflects conscious exercise of
conferred power. A selection process of this nature has to reflect a combined effect of
intellect and industry. It is because when there is a combination of the two, the
recommendations as used in the provision not only serves the purpose of a "lamp in
the study" but also as a "light house" which is shining, clear and transparent. "
26. Keeping within the above precincts of permissible scrutiny in judicial review, the Court would
now consider the material facts and W.P. (C) 1055/2011 Page 20 circumstances of this case. During
the hearing, the UOI made available the relevant files and documents in relation to the selection and
appointment of the private respondents. This court proposes to discuss those materials.
27. The UOI did not - and this is a conceded position of all parties- publicly make known the vacancy
position, in the Commission. The file reveals that about 165 applications were received.
Interestingly, in a response given under the RTI Act sometime in June, 2010, to the first petitioner's
President, the concerned Joint Secretary of the Ministry of Woman and Child Development,
furnished a tabular chart in respect of 130 applications received and the relative recommendations.
That response is part of the record of the writ petition; it has not been denied. Of the 130
applications in respect of which information was given, 35 recommendations of candidates have
been disclosed from Union Ministers; 18 are from political party functionaries (17 of which are from
Congress leaders); 33 recommendations have been made by Members of Parliament and Members
of Legislative Assemblies; 7 have been made by Chief Ministers and State Cabinet Ministers and 10
have been forwarded from the NCPCR (some of which have been endorsed by the Chairperson). 3
applications were forwarded from the Prime Minister's Office. Mr. Dube's application wasAssociation For Development And Anr. vs Uoi And Ors. on 7 November, 2013

recommended by a Member of Parliament, Shri Karan Singh; likewise the application of two other
candidates was endorsed by the Chairperson of NCPCR.
28. It appears that the file containing the Bio Data/ curriculum vitae of applicants runs into over
900 pages; those documents were not made available to the Court. The Petition annexes the
curriculum vitae of the private respondents, and also that of 4 others. It is not the task of this court
W.P. (C) 1055/2011 Page 21 to make a subjective assessment of those materials; doing so would
exceed the mandate permitted by the Constitution and be entering into the arena of a "merit review"
impermissible in law. That said, however, the Court would still have the obligation of satisfying itself
that the Committee - and later, the UOI did not commit any procedural irregularity or deviate from
the statute in making the impugned appointments.
29. Dr. Dube's curriculum vitae shows that he was born in 1974. Against the column "Qualification"
he stated "B.Ed & Ph.D (Mumbai University) Diploma in Computer Science". He also stated that he
was recipient of National Youth Award in 1996 and had been awarded the Rashtriyayuvak Samman
in 2001, and later, in 2004 of the "Shresth Baalak Paalak Puruskar". He also claimed to have
authored several books, journals and research articles and was "President Bharatiya Vikas
Sansthan" and that he ran "Child Relief Centre (AFFLT)". He was also President of the Akhil
Bharatiya Hindu Muslim Ekta Mahasangh, Uttar Bharatiya Mahasangh, Chairman of Mahrastra
Sanskritik Vikas Parishad, and several organizations. He was member of Hindi Advisory Committee,
Union Ministry of Home Affairs, as well as of the Censor Board and of the Central Railway
Committee, Ministry of Railways. In the next section he claimed that he was a "Dedicated
Personality to child development and Rights" and elaborated that:
"Dr. Yogesh Dubey is working from a long time for child rights, like organizing
workshops, rallies for awareness of child rights, arranging seminars on child rights
through his various forums and organizations. Works on grass root level for child
rights. Dr. Yogesh work on child rights and welfare for education organizing
scholarship for poor childs, awareness programme for below poverty line childs and
parents for improving attendance in scools, distribution of W.P. (C) 1055/2011 Page
22 school uniforms, books, pen, pencil as well as arranging sports material in low
price.."
In the column "Child Psychology" Dr. Dube stated that he was working on Child Psychology
"through his organizations, and organizing seminar and workshops, mainly focusing on the child
(sic: children's) parents to develop them for observing and scrutinizing the child (sic: children's)
behavior avoid imposing least required discipline, understand the normal behavior of childrens,
providing memory, development programmes for mentally retarded (sic: retarded) handicap
children. Personality development program for Childs (sic: children) to improve their memory,
development programmes for mentally handicap (sic: handicapped) children. Help them for their
various activities like education, medical treatments, awareness programs for community mental
disorder childs, organizing picnics, educational tours for poor childs and mental disorder childs,
(sic: children's) training camp for the parents on child psychology."Association For Development And Anr. vs Uoi And Ors. on 7 November, 2013

The CV also mentioned achievements of Dr. Dube in the field of child labour:
"CHILD LABOUR Child Labor is a serious problem of Indian Community. Dr. Yogesh
Dube works on this subject through his various organizations arranging various
seminars/workshops for preventive remedies and campaign against child labour. He
conducted massive child drivers (sic: drives) against child labour. He liberated
numbers of childrens from various hotels, small industrial units in Mumbai apart
from that he liberated child labour from works of carpet in Bhadohi Dist. of Uttar
Pradesh during salvation on relief work he exposed violence and atrocities carried out
on them. He organized mass campaigning for the legal side of child labour like taking
work from below age of 14 years is crime and penalty of Rs.20000/- with
imprisonment of one year. Arranged various meetings and group discussions with
Labor Minister, Commissioner and Officers, Government authorities to W.P. (C)
1055/2011 Page 23 implement rules and regulations effectively in this regards (sic:
regard)."
30. In the counter affidavit, Dr. Dube deposes that he completed his BA in 1995 and then:
"obtained B.Ed Degree in year 2006 from V.B.S. Purvanchal University (UP). He has
done his Ph.D from Mumbai University, it is also respectfully submitted that the
answering respondent is president of Akhil Bhariya Hindu Muslim Ekta Mahasangh,
which is not a political party but is working for communal harmony in the society for
welfare of the communities.....It is further submitted that Ghyanshyam Dube College
of Arts, Commerce and Science is situated at Suriyava District Sant Ravi Das Nagar
Dhadohi (UP) affiliated to Purvanchal University as approved by University Grant
Commission (UGC) New Delhi.."
The documents on the official (UOI) record contain a letter written by Dr. Dube, on 28-10-2010
refuting the allegations pertaining to his irregular appointment. They enclose copies of certain
documents, including the marks sheet in respect of the B.Ed. qualification he possesses from the
VBS Purvanchal University (obtained in 2006) and a copy of the mark sheet evidencing that he was
an external candidate of the Osmania University in 1995 in respect of BA subjects. Interestingly, the
copy of the Mumbai University doctorate (Ph.D) conferred upon Dr. Dube in respect of a thesis in
Hindi, submitted by him in 2006 has been placed on record. It would appear that Dr Dube secured
his B.Ed qualification from the Purvanchal University in the examination held in 2006 (page 151,
UOI file No. 1- 10/2010/CW-I). The same year (in March 2006) he appears to have submitted his
doctoral thesis ("Thesis in Hindi presented in May, 2006" as per the copy of the Ph.D certificate
which mentions the convocation date as 14th January, 2007). This was a clear discrepancy, which
certainly required W.P. (C) 1055/2011 Page 24 investigation. The CV only mentioned that Dr. Dube
was a B.Ed and Ph.D (Mumbai University). Yet, the material on record reveal that the B.Ed
qualification was not from Mumbai University; the documents evidencing that qualification show
that it was conferred by the Purvanchal University in 2006. This fact undermined the CV submitted
by Dr. Dube. Furthermore, these material left some questions unanswered, i.e. as to when did Dr.
Dube acquire post graduate qualifications for eligibility to submit a doctoral thesis, and whether heAssociation For Development And Anr. vs Uoi And Ors. on 7 November, 2013

cleared the B.Ed exams and also submitted the doctoral thesis in Hindi at the same time, in 2006.
These aspects clearly give a lie to the UOI's affidavit, especially its assertion in response to Paras
31-32 that the selected persons' CVs were "carefully seen and considered by the Selection
Committee" and that the said selected candidates "are all persons having a standing and experience
in the respective areas of work." If one also keeps in mind the fact that in 2006 - even May, 2006,
Dr. Dube was just 31 years, the possibility of his having "standing" and "experience" in the relevant
field of child rights or child development was remote. The file noting of Ms. Anju Bhalla, (dated
03-11-2010) -which deals with objections as to discrepancy of the claims of Dr. Dube, that he
concealed information and that "none of the outfits which Dr. Yogesh Dube claims to be associated
with can be located on the Internet" rejected the objections stating the Committee had "carefully
seen and considered" claims of all applications and that the said selected candidates "are all persons
having a standing and experience in the respective areas of work."(Refer Para 7 of the file noting,
which was ultimately accepted by all superior officers).
31. As far as Mr. Tikoo is concerned, the petitioners objections are that his principal experience is as
a banker and that he had worked in a public sector bank for 23 years till he obtained voluntary
retirement in 2001 and W.P. (C) 1055/2011 Page 25 that he was close to the husband of the Minister
in charge, Ms. Krishna Tirath, since he was his superior officer in the bank where he had previously
worked. The UOI refutes this contending that both individuals were in the same branch for one year.
As far as eligibility or suitability goes, it is contended that Mr. Tikoo is a holder of post graduate
degree in Master of Social Work. His curriculum vitae reads as follows:
"Academic Qualifications:
B. Sc. : University of Kashmir With major Subjects as English, Mathematics, Physics
& Chemistry M.A. (S.W.) : Delhi School of Social Work, Delhi University With
Specialization in Child & Community Development M. Phil : 1978 - Delhi School of
Social Work, Delhi University With Specialization in Personnel Management &
Industrial Relations Block Field work in Childrens Home Kingsway Camp and
Community Development in Kingsway Camp & Qutram Lines with Special Emphasis
on the women welfare & Child Development under the Community Welfare
Programme specially in the Slum Areas of Delhi Associated with Gram Mahila
Kendra later renamed as Centre for Community Action and Development (CCAD).It
is currently in operation in Burari Semi -Urban Area in Delhi. It envisions the
creation of empowered community for improving the quality of life of the people,
based on the principles of Social Justice and human rights. It has successfully
organized three womens self help groups in the community and is concentrating the
activities in shankarapura & Bhararigarhi clusters.
Associated with the Child Guidance Centre (CGC) established in 1971 as a field
demonstration project and now renamed as centre for child and adolescent Wellbeing
(CCAW). At the centre diagnostic W.P. (C) 1055/2011 Page 26 treatment and referral
services to the Children with behavioural and emotional problems and other specific
childhood disorders of children aged above 3 years are provided, usingAssociation For Development And Anr. vs Uoi And Ors. on 7 November, 2013

inter-disciplinary approach with an aim to understand childrens problems through
planned interventions carried at the level of child, his/her Parents, Family, School,
and Community, Services of visiting Psychiatriests, Child Psychologists, Doctors and
Homeopaths are utilized.
With over twenty Three years of experience as a Senior Manager cum Administrator
in a Premier Public Sector Enterprises having worked across various Indian Cities in
a variety of Role Functions in Field Operations as well as Administrative set up
looking forward to work in a corporate environment which provides a platform to eke
out the best in me and benefit the society at large through the interactive and
innovative methods with my exposures, experience and capabilities. Also worked in
the Sociology Division TCPO on the project "Social Cohesiveness and physical form"
The relevant extracts of Shri Tikoo's counter affidavit are as follows:
"The contents of the para no.28 & 29 of the Writ Petition are false, wrong, misleading
and hence specifically denied. It is respectfully that the answering Respondent being
a professionally qualified Social Worker from a Premier National University Institute,
namely, Delhi School of Social Work, University of Delhi has every qualification for
the post of member in the NCPCR also as per the provisions of the CPCR Act 2005. It
is further submitted that based on the professional qualifications of the Respondent
No.3 some of the path breaking works in protecting the child rights in the country
including the infamous Bharat Vikas Sangh NGO run „Apna Ghar Rohtak, was
exposed wherein 103 inmates were subjected to gross physical, sexual and
psychological abuse or the sexual abuse of girls leading to their contracting HIV in
"Drone Foundation", Gurgaon, or the sexual abuse of children in „Superna Ka
Angan, Gurgaon, Haryana or the malnutrition deaths in Raichur, Karnataka was
inquired into, which was rendered as a National Shame by our Prime Minister. The
infanticide and female foeticide cases in Rajasthan, the infant and Neo - natal
mortality in Malda Medical College & Hospital, the deprivation of the right to W.P.
(C) 1055/2011 Page 27 education and healthcare of more than thousand children of
Gangetic Chars in West Bengal ignored by the State for more than 40 years was
addressed. The identification of children in Tihar Jails lodged as adults was also
spearheaded by the answering respondent no.3. The news that Doctors are turning
Scores of Girls into Boys, which was carried by a national daily and caught the
attention of not just the country but even the globe was also one of the path breaking
inquiries handled by the answering respondent no.3. The respondent No.3 being a
Member of the NCPCR, also took steps against three Governments in the High Court
for not complying with the provisions of CPCR Act 2005 and was successful in getting
reliefs on four important counts viz setting up of State Commissions for protection of
Child Rights, for mapping up and registration of Child Care Institutions under
Section 34 (3) of the Juvenile Justice (Care & Protection of Children ) Act 2000,
constitution of the selection Committee and setting up of a robust inspection
mechanism by constitution of Inspection Committee for the child care Institutions.Association For Development And Anr. vs Uoi And Ors. on 7 November, 2013

The petitioners alleged that they have made due enquiry of its own initiative and attained numerous
CVs, it seems that the Petitioners wish to assume the constitutional authority of the concerned
administrative Ministry. It is further submitted that these allegations are false and frivolous as the
other candidates have not challenge the appointments/ selection process conducted by the
concerned ministry under the Respondent No1. It is further submitted that they have also not been
arrayed in the petition nor any list of all the candidates applied for the post has been filed by the
petitioners. Thus in the absence of the list of candidates the annexed CVs are not believable and
cannot be relied upon in any manner whatsoever. Hence it is re-iterated that the petition be
dismissed outright."
32. The Court is not inclined, nor equipped to inquire into the relative merits of the applications
furnished by various candidates. Nevertheless, it cannot help wondering whether in the case of the
candidature of the private respondents, their "experience in the field" and "expertise" vouchsafed for
W.P. (C) 1055/2011 Page 28 by the UOI in its affidavit reflects "ability" "standing" "experience" and
"eminence". The use of these terms, to this Court's mind, highlights Parliamentary intention that
those of proven merit and track record, and singularly distinguished only should be chosen to man
the NCPCR. The Commission, like the National Commission for Human Rights, National
Commission for Women, National Minorities Commission, etc, have been created with the purpose
of bringing to bear expertise in various - though inter-related - disciplines, with the aim of
improving policies, and evolving best practises. In the case of NCPCR, the various areas indicated
(education, child psychology, child health, care, welfare or child development; juvenile justice or
care of neglected or marginalized children or children with disabilities; elimination of child labour
or children in distress; child psychology or sociology; and laws relating to children are relevant
disciplines or fields). Apart from leveling allegation of bias, the petitioner has not impleaded the
Minister in charge. The allegation, by themselves are insufficient to measure up to the "reasonable
apprehension"
or "real danger" of bias standard applicable in the case, given that the said
respondent left employment in 2001 and applied for the post in question in 2010.
This Court refrains from rendering any adverse finding with respect to Mr. Tikoo's
candidature for the reason that though the materials regarding his ability, standing
and eminence are scanty, there is something to indicate his eligibility vis-à-vis
qualifications. The Court is also cognizant of the fact that Mr. Tikoo is now 59 years,
and as the per the noting (rejecting other candidates' application) ineligible for
further appointment, as apparent from the file noting (dated 03.11.2010) that those
"over aged or close to 58-59 years" could not be considered for appointment. He
would therefore be ineligible for re-appointment.
W.P. (C) 1055/2011 Page 29
33. In this case, the Selection Committee apparently met and deliberated on four
occasions. The earliest view in regard to the appointments was taken on 11-2-2010
when the officers drew attention to the order of the court dated 03-02-2010, and
stated that a selection Committee ought to be appointed. On 06-04-2010, the UOIAssociation For Development And Anr. vs Uoi And Ors. on 7 November, 2013

issued an order constituting the Selection Committee in respect of members; it
included the minister in charge, the Secretary to UOI, Ministry of Women and Child
Development and Ms. Padma Seth. Ms. Seth's inability or disinclination led to Dr.
Shyama Chona replacing her. The Committee met four times, to consider various
names for appointment as members. The relative names approved in the minutes of
each committee meeting are discussed below.
34. The first meeting, i.e. 29-04-2010 considered "the nominations received under
the different categories and shortlisted the following persons" for appointment. For
the heading "Education", Dr. Daphne Pillai (age not confirmed) and Dr. Renu Singh
were shortlisted; for "Health" Dr. Dinesh Laroia was shortlisted; for Juvenile Justice
or Care "Shri Ravendranddiraa was shortlisted with comment that his age was to be
confirmed; For "Child Labour" Dr. Yogesh Dube, Ms. Alpa Vohra (with comment "age
to be confirmed" and Mr. Gerry Pinto (again "age to be confirmed") were shortlisted.
For the heading "Child Laws" Ms. Dipa Dixit was shortlisted and for the head "Child
psychology" Shri Vinod Kumar Tikoo was shortlisted. In the next meeting (second
meeting), i.e. 09-07- 2010, under "Education" the two names mentioned earlier were
retained; however, Ms. Sukhanya Bharatram's name was added; for health, apart
from Dr. Laroia, the names of Mr. Shashank Shekhar and Dr. Father Anthony
Sebastian were added; for the head Juvenile Justice and Care, apart from Shri
Ravendranddiraa (against whose name no comment about W.P. (C) 1055/2011 Page
30 age appears) two other names were added, i.e. M/s J.P. Tewari and Sheri Pradeep
Raghunandan (age to be confirmed). In the head Child Labour, while retaining the
name of Dr. Dube and Ms. Alpa Vora, two other names (M/s Madan Mohan Vidyarthi
and Ashok Singh) were added. Two names were added under the head Child laws, to
that of Ms. Dipa Dixit, i.e. Dr. Charu Walikhanna and Sheri Sabu Thomas. Under the
head Child Psychology, the lone name of Mr. Tikoo was retained. In the meeting of
27- 07-2010, the names mentioned earlier were retained, (except in respect of
Education) that the Committee felt that there had to be representation of SC/ST
communities, and therefore added the name of Dr. N. Paul Divakar in the list
pertaining to Child Health, Care, Welfare or Child Development. Under the head
Education, the names which had been shortlisted first and reiterated in the second
meeting, i.e. Dr. Daphne Pillai and Dr. Renu Singh were deleted. Though nothing
turns on this aspect, since the appointment under the head "Education" is not under
challenge, the manner of inclusion and deletion of names this reflects a fair degree of
opaqueness in the deliberations of the Committee. The fourth meeting (01-09-2010)
saw the committee finalizing only three names for selection, i.e. Ms. Sukanya
Bharatram (Education); Ms. Dipa Dixit (Laws relating to Children) and Mr. Vinod
Kumar Tikoo (Child Psychology or Sociology). In the final meeting, apart from
reiterating these three names, the Committee selected three others, i.e. Dr. Dinesh
Larioa (Child Care, Welfare and Development), Ms. Amita Dhanda (Juvenile Justice
or Care or Marginalised Children or Children with Disabilities) and Dr. Dube
(Elimination of Child Labour or Children in Distress).Association For Development And Anr. vs Uoi And Ors. on 7 November, 2013

35. This Court is acutely conscious of its limitation and the need to desist from
undertaking a "merit review". Therefore, it is confining its W.P. (C) 1055/2011 Page
31 scrutiny to the settled parameters, i.e. whether the procedure adopted was fair,
reasonable and transparent, and whether the private respondents could be set to
have fulfilled the statutorily prescribed eligibility criteria. The selection process
nowhere discusses - even in the barest minimum manner, the strengths and
weaknesses of the short listed candidates, particularly where more than one applicant
is listed under the same head. What ultimately persuaded the Committee to drop
certain names, and accepts names of those finally appointed, does not appear from
the record made available to the Court. Nor is there any light shed in the affidavit
filed by the UOI to indicate if the relative qualifications and experience of at least the
short listed candidates was considered, and whether some kind of ranking, marking
or evaluating system was adopted. Granted that the statute is silent; yet the
obligation of the executive authority is to take an informed decision. It is one thing to
say that the process undertaken was fair, or apparently fair, but entirely another to
say that the reasons for the decision are buried in the maker's mind. This Court is
emphasizing that there is no duty to record reasons why one or the other candidate is
short listed - after all, when a large number of applications is received, some sifting
has to take place. The Court is not reviewing that level of scrutiny; yet, having
shortlisted many candidates, some of whom were retained (especially in respect of
the head "Elimination of Child Labour or Children in Distress"
and reiterated them at least twice) there are complete lack of reasons for dropping the names of
Alpa Vora, M/s Madan Mohan Vidyarthi and Ashok Singh. In the case of Alpa Vora, her CV
indicates that she had about 23-24 years relevant experience in the field, and had worked for the
UNICEF, as well as in areas of Juvenile Justice and Child Care. Her CV, is on the record; it discloses
a wide ranging experience, including conducting specific programmes (the particulars of which are
mentioned) and the W.P. (C) 1055/2011 Page 32 several publications of this applicant. This court
underlines that the insistence for reasons is not to probe the merits of the decision to drop this
candidate's name, but as to what really struck the Committee at that stage and persuaded them to
drop her candidature.
36. In this context, the Court is cognizant of the statutory requirement that the person chosen
should possess "ability", "standing", "integrity" and be "eminent". The use of these terms, in the
opinion of the Court was to focus the mind of the appointing authority to select and appoint persons
who have outstanding and sterling qualities; in short, visionaries - and may be pioneers in the
discipline. There is nothing on the record to disclose which of these attributes was seen or noticed in
respect of Dr. Dube. The Court is in this context wary of commenting on the choice of the Committee
in selecting Mr. Tikoo- at least he possesses educational qualifications, relevant to the field
(Sociology and Social Work) and has placed on record some certificate in this regard. But in the case
of Dr. Dube, the conspicuous inconsistencies in respect of his claim regarding educational
qualifications were glossed over; his CV does not pin point specifically any relevant experience in the
relevant discipline or field. His doctoral thesis is in Hindi. His final selection and appointment can
be justified due to "absence of "intellectual objectivity" (Rajesh Awasthis case, supra). As far as theAssociation For Development And Anr. vs Uoi And Ors. on 7 November, 2013

challenge to Shri Tikoo's appointment goes, this Court is not prepared to agree with the petitioners'
contentions in that regard.
37. In view of the above discussion, this Court holds that the selection and appointment of Dr. Dube
is contrary to the mandate of Section 3 (2) (b). The materials on record do not show that he
possessed of qualifications relating to the field or discipline he was chosen for in the NCPCR; they
also W.P. (C) 1055/2011 Page 33 show that the Committee could not have by applying any standard,
reasonably concluded that he had qualifications, standing, ability or eminence in the field. This
court emphasizes that an individual may not be necessarily debarred from consideration merely
because he does not have adequate qualification- though some minimum qualifications would be
necessary; yet he or she should possess some modicum of experience, ability or distinction in the
field as to inspire confidence that the issues concerning the NCPCR, particularly in the category or
discipline for which he or she is selected, can be ably and efficiently handled. The conclusion that
this Court has drawn is not based on a merit review of Dr. Dube's credentials, but on the basis of the
available materials which nowhere reveal how he can be called as one having standing, ability or
eminence in the chosen field.
38. Before parting, this Court expresses concern that the selection for a national level commission
such as the NCPCR is not based on any objective guidelines. This omission is significant, because
such guidelines are - in this court's opinion- necessary since the same language is repeated in
respect of essential requirements for members of State Commissions. Also, prescribing some
guidelines as to the nature of qualifications, as well as the quality of experience which is considered
essential, would go a long way in making the task of future selection committees easier. A further
aspect which may be duly considered would be to introduce some objective evaluation method,
which incorporates different weightage or marks for qualification, experience in the field, evaluation
of publication and participation in seminars, workshops, etc. Such criteria can be in addition to the
commitment of the UOI to constitute selection committee to screen and recommend names for
members and Chairperson of NCPCR; the procedure W.P. (C) 1055/2011 Page 34 of tentatively
posting the recommended names on the UOI's web site may also be continued. More publicity
should be given when the vacancies are to be filled up so that a wider range of prospective
candidates from all over the country could apply and be considered for the Commission.
39. For the above reasons, the selection and appointment of Dr. Yogesh Dube, the second
respondent, as member of NCPCR is hereby quashed. The writ petition is allowed to the above
extent; there shall be no order as to costs.
(S. RAVINDRA BHAT) JUDGE (NAJMI WAZIRI) JUDGE NOVEMBER 07, 2013 W.P. (C)
1055/2011 Page 35Association For Development And Anr. vs Uoi And Ors. on 7 November, 2013

