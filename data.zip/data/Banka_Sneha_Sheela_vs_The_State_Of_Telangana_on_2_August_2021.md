Banka Sneha Sheela vs The State Of Telangana on 2 August,
2021
Equivalent citations: AIR 2021 SUPREME COURT 3656, AIRONLINE 2021 SC
406
Author: R.F. Nariman
Bench: Rohinton Fali Nariman, B.R. Gavai
                                                                         REPORTABLE
                                IN THE SUPREME COURT OF INDIA
                               CRIMINAL APPELLATE JURISDICTION
                                CRIMINAL APPEAL NO. 733 OF 2021
                         [ARISING OUT OF SLP (CRIMINAL) NO.4729 OF 2021]
         BANKA SNEHA SHEELA                                            ..APPELLANT
                                               VERSUS
         THE STATE OF TELANGANA & ORS.                                 ..RESPONDENTS
                                             JUDGMENT
R.F. Nariman, J
1. Leave granted.
2. The present appeal arises out of a judgment dated 31.03.2021, passed by the High Court for the
State of Telangana at Hyderabad, by which a Writ Petition filed by the Petitioner challenging a
Preventive Detention Order [hereinafter referred to as “Detention Order”] passed against the
Petitioner’s husband [hereinafter referred to as “the Detenu”] under Section 3(2) of the Telangana
Prevention of Dangerous Activities of Boot-leggers, Dacoits, Drug-Offenders, Goondas, Immoral
Traffic Offenders Land-Grabbers, Spurious Seed Offenders, Insecticide Offenders, Fertiliser
Offenders, Food Adulteration Offenders, Fake Document Offenders, Scheduled 16:45:07 IST
Reason:
Commodities Offenders, Forest Offenders, Gaming Offenders, Sexual Offenders,
Explosive Substances Offenders, Arms Offenders, Cyber Crime Offenders and White
Collar or Financial Offenders Act, 1986 [hereinafter referred to as “Telangana
Prevention of Dangerous Activities Act”] , was dismissed.
3. The Detention Order under the provisions of the Telangana Prevention of Dangerous Activities
Act is dated 28.09.2020. It refers to five FIRs that have been filed against the Detenu, all the said
FIRs being under Sections 420, 406 and 506 of the IPC. The facts contained in the FIRs range fromBanka Sneha Sheela vs The State Of Telangana on 2 August, 2021

October, 2017 to December, 2019 and are similar. We may set out the facts contained in FIR No.705
of 2019 as a sample of similar FIRs filed against the Detenu as follows [This narration of the FIR is
to be found in the Detention Order itself]:
“On 12.12.2019 at 1200 hours a complaint was received from Sri Kommu Naveen
Kumar S/o Veeraswamy, aged about 24 years, Occ: Car Mechanic, R/o H.No. 2-32,
Yadaran Village, Shamirpet Mandal stating that he has been running a Garage near
main road at Muraharipally village for the past one year. One Banka Ravikanth, aged
about 35 years used to come to his garage for two to three times in a month for his car
servicing. In the month of March, 2019 the said Ravikanth introduced himself as a
High Court advocate and he would invest money in newly upcoming companies and
insisted the complainant to invest money for 100% return. He also informed that they
are three advocates, of them one is CA (Chartered Accountant) and another is CS
(Company Secretary) by name Chandramouli, aged about 65 years. On believing his
words, he transferred Rs.50,000/-
through Phone-pay to his Indian Bank, Shamirpet branch vide A/c No. 6714073306. Again on
28.05.2019 he transferred Rs. 1,00,000/- through Phone-pay as second investment and on
20.06.2019 he deposited Rs. 1,00,000/- from his Indian Bank, Gachibowli Branch account to his
account besides giving net cash of Rs. 2,00,000/- by hand. While sending Rs. 1 lakh through phone
pay in presence of one Prasad, Banka Ravikanth assured the complainant that in the 2nd investment
he would give him Rs. 41,000/- per month throughout the year and he will take Rs. 3,000/- towards
his commission. On 12.12.2019 when the complainant asked him to return his money, he threatened
with dire consequences. The complainant stated that the said Ravikanth has cheated him by saying
that he would get more return. On the strength of the complainant, police registered a case and
investigation into.” Following upon the narration of the 5 FIRs comes this important paragraph:
“Due to above incidents, the complainants, victims and other young aspirants, who
want to invest money in stock/share market and derive benefits became scared and
feeling insecure. These incidents have also caused loss of faith and trust among
investors in stock trading fearing similar cheating towards them by the people like
you. They are hesitated to consult any consultancies or persons fearing similar
cheating by the unknown persons in the guise of providing good profits. These
prejudicial activities have also caused disturbance in the public.”
4. The Detention Order then refers to the ‘Modus Operandi’ of the Detenu as follows:
“You are a native of Karimnagar district. You completed graduation (B.Com) in 2011
and LLB in 2019 and have been doing trading in stock market. You have introduced
yourselves to the victims as a High Court Advocate and you have a team consisting of
one CA (Chartered Accountant) and CS (Company Secretary) and three advocates.
Your CS has an expertise and links in Central and State governments. You have
knowledgeable persons in share marketing and used to invest money in upcoming
companies which ensure return of 100%. You would lure the innocent public in theBanka Sneha Sheela vs The State Of Telangana on 2 August, 2021

guise of providing good profit by investing their money in share marketing. You used
to contact your known persons and lure them to invest their money in share market
to get good profits assuring the profit 100% within a short period. Further you used
to give blank cheques and ask commission from the victims to gain their confidence.
As per plan, you collected amount from the victims through Phone-pe which is linked
to your bank account and net-banking and in-person. When you received money to
your bank account, immediately you had transfer the received amount to your wife's
bank account. When the victims contact you over phone, you first start avoiding them
and then diverting their calls and finally cheating them. Later, you changed your
residential address in order to conceal your where-abouts from the victims. You have
cheated so many people to the tune of more than Rs. 50.00 lakhs in the guise of
providing good profit through investment in share market.
You are involved in Cr.No.34/2020 u/s 406, 420 IPC of Malkajgiri Police Station in
the limits of Rachakonda Police Commissionerate which referred by way of your
antecedent criminal background the same is not relied upon for your detention.”
5. Thereafter, the Detention Order narrates that anticipatory bail/bail has been granted to the
Detenu in all the aforesaid FIRs, the last such relief granted being on 10.08.2020. The Detention
Order then narrates:
“Having regard to your involvement in series of criminal activities such as cheating in
the guise of providing good profit by investing their money in stock market and
collected huge amounts to the tune of more than Rs. 50 lakhs from them in an
organized way and in view of the bail petitions moved by you and granted in the
aforesaid cases and later releasing on conditional bail, I am satisfied that free
movement of such an offender like you is not safe in the interest of the society as
there is an imminent possibility of you indulging in similar prejudicial activities with
another set of innocent youth and cheat them on the pretext of providing good profit
by investing their money in stock market, which are detrimental to public order,
unless you were prevented from doing so by an appropriate order of detention. xxx
xxx xxx Thus you have indulged in the acts of White Collar offences by committing
offences such as cheating so many people by collecting more than Rs. 50 lakhs from
them through Phone Pay and online banking and sometimes in person in the guise of
providing more profit in the limits of Cyberabad Police Commissionerate. Further
your acts have been adversely affecting the maintenance of public order and creating
feeling of insecurity among young people, thus disturbing peace and tranquillity in
the area. It is imperative to prevent you from acting in any manner prejudicial to the
maintenance of public order. I feel that recourse to normal law may not be effective
deterrent-in preventing you from indulging in such further activities prejudicial to
the maintenance of public order in the area, unless you were detained by invoking the
provisions under the "Telangana Prevention of Dangerous Activities of Bootleggers,
Dacoits, Drug-Offenders, Goondas, Immoral Traffic Offenders, Land-Grabbers,
Spurious Seed Offenders, Insecticide Offenders, Fertiliser Offenders, FoodBanka Sneha Sheela vs The State Of Telangana on 2 August, 2021

Adulteration Offenders, Fake Document Offenders, Scheduled Commodities
Offenders, Forest Offenders, Gaming Offenders, Sexual Offenders, Explosive
Substances Offenders, Arms Offenders, Cyber Crime Offenders and White Collar or
Financial Offenders Act, 1986, (Act No. 01 of 1986)".”
6. As a result thereof, the Detenu was preventively detained from the date of the Detention Order
itself. A representation dated 31.10.2020 was made by the Petitioner herein to the Commissioner of
Police, Cyberabad Commissionerate [Respondent No. 2] which was considered by the Advisory
Board, who by its Order 11.11.2020 found that there was sufficient cause to continue the Detention
Order. Vide the Order of the State of Telangana dated 17.12.2020, the Detention Order was
confirmed and the period of detention was directed to be for a period of one year from 05.10.2020.
7. The impugned judgment, after narrating the facts and the arguments made by counsel on behalf
of the Petitioner as well as counsel on behalf of the State, then held:
“9.In the instant case, a perusal of the material placed on record reveals that the
detenu was granted bail by the Courts concerned in all the five cases relied upon by
the detaining authority for preventively detaining him. Under these circumstances,
the contention of the respondents that the illegal activities of the detenu would
disturb the even tempo of life of the community which makes it prejudicial to the
maintenance of the public order and there is imminent possibility of the detenu again
indulging in similar prejudicial activities, cannot be brushed aside.” The judgment
then referred to the decisions of this Court in Madhu Limaye v. Sub-Divisional
Magistrate (1970) 3 SCC 746, Commissioner of Police v. C. Sunita (2004) 7 SCC 467
and R.Kalavathi v. State of Tamil Nadu (2006) 6 SCC 14, and then concluded:
“The modus operandi of the detenu in the alleged offences which were committed in
quick succession would certainly disturb the public peace and tranquillity. So it is
imperative upon the officers concerned to pass the order of detention, since the acts
of the detenu are prejudicial to the maintenance of public order. The illegal activities
of the detenu were of such a reach and extent, that they would certainly affect the
even tempo of life and were prejudicial to the public order. The detaining authority
had sufficient material to record subjective satisfaction that the detention of the
detenu was necessary to maintain public order and even tempo of life of the
community. The order of detention does not suffer from any illegality. The grounds of
detention, as indicated in the impugned order, are found to be relevant and in tune
with the provisions of the P.D.Act. Since the detenu got bail in all the five cases relied
upon by the detaining authority, there is nothing wrong on the part of the detaining
authority in raising an apprehension that there is every possibility of the detenu
committing similar offences, which would again certainly affect the public order. The
quick succession of commission of alleged offences by the detenu makes it amply
clear that there is every possibility of detenu committing similar offences in future,
which are prejudicial to the maintenance of public order.”Banka Sneha Sheela vs The State Of Telangana on 2 August, 2021

8. Shri Gaurav Agarwal, learned counsel appearing on behalf of the Petitioner has raised three
points before us. First and foremost, he said there is no proximate or live connection between the
acts complained of and the date of the Detention Order, as the last act that was complained of,
which is discernible from the first 3 FIRs [FIRs dated 12.12.2019, 12.12.2019 and 14.12.2019], was in
December 2019 whereas the Detention Order was passed 9 months later on 28.09.2020. He then
argued, without conceding, that at best only a ‘law and order’ problem if at all would arise on the
facts of these cases and not a ‘public order’ problem, and referred to certain judgments of this court
to buttress the same. He also argued that the Detention Order was totally perverse in that it was
passed only because anticipatory bail/bail applications were granted. The correct course of action
would have been for the State to move to cancel the bail that has been granted if any further
untoward incident were to take place.
9. Shri Ranjit Kumar, learned senior counsel appearing on behalf of the State of Telangana,
reiterated the grounds contained in the Detention Order and argued that the Detenu was a habitual
fraudster who had therefore created fear amongst the gullible public, and since he was likely to
commit similar offences in future, it was important to preventively detain him, as the ordinary law
had no deterrent effect on him. Further, there is no doubt that he had infringed ‘public order’ as
defined by the Telangana Prevention of Dangerous Activities Act and had disturbed the even tempo
of life of persons who were cheated by him and were likely to be cheated by him.
10. Having heard learned counsel for both parties, it is first important to set out the important
provisions of the Act as follows:
“2. Definitions In this Act, unless the context otherwise requires,
(a) “acting in any manner prejudicial to the maintenance of public order” means
when a bootlegger, a dacoit, a drug-
offender, a goonda, an immoral traffic offender, Land- Grabber, a Spurious Seed Offender, an
Insecticide Offender, a Fertiliser Offender, a Food Adulteration Offender, a Fake Document
Offender, a Scheduled Commodities Offender, a Forest Offender, a Gaming Offender, a Sexual
Offender, an Explosive Substances Offender, an Arms Offender, a Cyber Crime Offender and a
White Collar or Financial Offender is engaged or is making preparations for engaging, in any of his
activities as such, which affect adversely, or are likely to affect adversely, the maintenance of public
order:
Explanation:- For the purpose of this clause public order shall be deemed to have
been affected adversely or shall be deemed likely to be affected adversely inter alia, if
any of the activities of any of the persons referred to in this clause directly, or
indirectly, is causing or calculated to cause any harm, danger or alarm or a feeling of
insecurity among the general public or any section thereof or a grave wide-spread
danger to life or public health;
xxx xxx xxxxBanka Sneha Sheela vs The State Of Telangana on 2 August, 2021

(x) “White collar offender” or “Financial Offender” means a person who commits or
abets the commission of offences punishable under the Telangana Protection of
Depositors of Financial Establishment Act, 1999 (Act 17 of 1999) or under sections
406 to 409 or 417 to 420 or under Chapter XVIII of the Indian Penal Code, 1860.”
“Section 3. Power to make orders detaining certain persons (1) The Government may,
if satisfied with respect to any bootlegger, dacoit, drug-offender, goonda, immoral
traffic offender, Land-Grabber, Spurious Seed Offender, Insecticide Offender,
Fertilizer Offender, Food Adulteration Offender, Fake Document Offender,
Scheduled Commodities Offender, Forest Offender, Gaming Offender, Sexual
Offender, Explosive Substances Offender, Arms Offender, Cyber Crime Offender and
White Collar or Financial Offender that with a view to preventing him from acting in
any manner prejudicial to the maintenance of public order, it is necessary so to do,
make an order directing that such person be detained.” “Section 13. Maximum period
of detention The maximum period for which any person may be detained, in
pursuance of any detention order made under this Act which has been confirmed
under section 12, shall be twelve months from the date of detention.”
11. While it cannot seriously be disputed that the Detenu may be a “white collar offender” as defined
under Section 2(x) of the Telangana Prevention of Dangerous Activities Act, yet a Preventive
Detention Order can only be passed if his activities adversely affect or are likely to adversely affect
the maintenance of public order. Public order is defined in the Explanation to Section 2(a) of the
Telangana Prevention of Dangerous Activities Act to be a harm, danger or alarm or a feeling of
insecurity among the general public or any section thereof or a grave widespread danger to life or
public health.
12. As is well-known, the expressions ‘law and order’, ‘public order’, and ‘security of state’ are
different from one another. In Ram Manohar Lohia v. State of Bihar (1966) 1 SCR 709 the question
before this Court arose under a Preventive Detention Order made under Rule 30 of the Defence of
India Rules, which permits apprehension and detention of a person likely to act in a manner
prejudicial to the maintenance of public order. This Court set out the distinction between a mere law
and order disturbance and a public order disturbance as follows:
“The Defence of India Act and the Rules speak of the conditions under which
preventive detention under the Act can be ordered. In its long title and the preamble
the Defence of India Act speaks of the necessity to provide for special measures to
ensure public safety and interest, the defence of India and civil defence. The
expression public safety and interest between them indicate the range of action for
maintaining security peace and tranquillity of India whereas the expressions defence
of India and civil defence connote defence of India and its people against aggression
from outside and action of persons within the country. These generic terms were used
because the Act seeks to provide for a congeries of action of which preventive
detention is just a small part. In conferring power to make rules, Section 3 of the
Defence of India Act enlarges upon the terms of the preamble by specification of
details. It speaks of defence of India and civil defence and public safety withoutBanka Sneha Sheela vs The State Of Telangana on 2 August, 2021

change but it expands the idea of public interest into maintenance of public order, the
efficient conduct of military operations and maintaining of supplies and services
essential to the life of the community. Then it mentions by way of illustration in
clause (15) of the same section the power of apprehension and detention in custody of
any person whom the authority empowered by the rules to apprehend or detain (the
authority empowered to detain not being lower in rank than that of a District
Magistrate), suspects, on grounds appearing to that authority to be reasonable—
(a) of being of hostile origin; or
(b) of having acted, acting or being about to act or being likely to act in a manner
prejudicial to—
(i) the defence of India and civil defence;
(ii) the security of the State;
(iii) the public safety or interest:
(iv) the maintenance of public order;
(v) India's relations with foreign states:
(vi) the maintenance of peaceful conditions in any part or area of India: or
(vii) the efficient conduct of military operations.
It will thus appear that security of the state, public safety or interest, maintenance of public order
and the maintenance of peaceful conditions in any part or area of India may be viewed separately
even though strictly one clause may have an effect or bearing on another. Then follows Rule 30,
which repeats the above conditions and permits detention of any person with a view to preventing
him from acting in any of the above ways. The argument of Dr Lohia that the conditions are to be
cumulatively applied is clearly untenable. It is not necessary to analyse Rule 30 which we quoted
earlier and which follows the scheme of Section 3(15). The question is whether by taking power to
prevent Dr Lohia from acting to the prejudice of “law and order” as against “public order” the
District Magistrate went outside his powers.
[page 738-739] xxx xxx xxx We have here a case of detention under Rule 30 of the Defence of India
Rules which permits apprehension and detention of a person likely to act in a manner prejudicial to
the maintenance of public order. It follows that if such a person is not detained public disorder is the
apprehended result. Disorder is no doubt prevented by the maintenance of law and order also but
disorder is a broad spectrum which includes at one end small disturbances and at the other the most
serious and cataclysmic happenings. Does the expression “public order” take in every kind of
disorders or only some of them? The answer to this serves to distinguish “public order” from “lawBanka Sneha Sheela vs The State Of Telangana on 2 August, 2021

and order” because the latter undoubtedly takes in all of them. Public order if disturbed, must lead
to public disorder. Every breach of the peace does not lead to public disorder. When two drunkards
quarrel and fight there is disorder but not public disorder. They can be dealt with under the powers
to maintain law and order but cannot be detained on the ground that they were disturbing public
order. Suppose that the two fighters were of rival communities and one of them tried to raise
communal passions. The problem is still one of law and order but it raises the apprehension of
public disorder. Other examples can be imagined. The contravention of law always affects order but
before if can be said to affect public order, it must affect the community or the public at large. A
mere disturbance of law and order leading to disorder is thus not necessarily sufficient for action
under the Defence of India Act but disturbances which subvert the public order are. A District
Magistrate is entitled to take action under Rule 30(1)
(b) to prevent subversion of public order but not in aid of maintenance of law and order under
ordinary circumstances.
It will thus appear that just as “public order” in the rulings of this Court (earlier cited) was said to
comprehend disorders of less gravity than those affecting “security of State”, “law and order” also
comprehends disorders of less gravity than those affecting “public order”. One has to imagine three
concentric circles. Law and order represents the largest circle within which is the next circle
representing public order and the smallest circle represents security of State. It is then easy to see
that an act may affect law and order but not public order just as an act may affect public order but
not security of the State. By using the expression “maintenance of law and order” the District
Magistrate was widening his own field of action and was adding a clause to the Defence of India
Rules.” [page 745-746]
13. There can be no doubt that for ‘public order’ to be disturbed, there must in turn be public
disorder. Mere contravention of law such as indulging in cheating or criminal breach of trust
certainly affects ‘law and order’ but before it can be said to affect ‘public order’, it must affect the
community or the public at large.
14. There can be no doubt that what is alleged in the five FIRs pertain to the realm of ‘law and order’
in that various acts of cheating are ascribed to the Detenu which are punishable under the three
sections of the Indian Penal Code set out in the five FIRs. A close reading of the Detention Order
would make it clear that the reason for the said Order is not any apprehension of widespread public
harm, danger or alarm but is only because the Detenu was successful in obtaining anticipatory
bail/bail from the Courts in each of the five FIRs. If a person is granted anticipatory bail/bail
wrongly, there are well-known remedies in the ordinary law to take care of the situation. The State
can always appeal against the bail order granted and/or apply for cancellation of bail. The mere
successful obtaining of anticipatory bail/bail orders being the real ground for detaining the Detenu,
there can be no doubt that the harm, danger or alarm or feeling of security among the general public
spoken of in Section 2(a) of the Telangana Prevention of Dangerous Activities Act is make believe
and totally absent in the facts of the present case.Banka Sneha Sheela vs The State Of Telangana on 2 August, 2021

15. At this stage, it is important to advert to the counter affidavit dated 17.07.2021 filed by the State
of Telangana. Paragraph 18 of the counter affidavit refers to the granting of bail by Courts in all the
five FIRs, which is the real reason for the passing of the Detention Order, as follows:
“18. It is submitted that in the instant case, the decision to detain the detenu herein is
based on the perusal of the material on records which revealed that the detenu was
granted bail by the Courts concerned in all the five cases relied upon by the detaining
authority for preventively detaining him. The Respondent No. 2 herein recorded his
satisfaction that the activities of the detenu are prejudicial to the maintenance of
public order, and that ordinary law may not be an effective deterrent to prevent the
detenu from indulging in further prejudicial activities. Furthermore, the materials
relied upon and circumstances show that subjective satisfaction of the detaining
authority is not tainted or illegal on any account. Therefore the passing of the
detention order is justified considering that the illegal activities of the detenu would
disturb the even tempo of life of the community, which makes it prejudicial to the
maintenance of the public order and there is imminent possibility of the detenu again
indulging in similar prejudicial activities.” Paragraph 21 of the counter affidavit then
states as follows:
“21. It is submitted that in the acts which disturb public tranquillity or are breaches of
the peace should not be given a narrow meaning, but should be given a liberal
interpretation and the expression ‘in the interest of public order’ is very wide
amplitude as held by this Hon’ble Court in Madhu Limaye Versus Sub Division
Magistrate reported in AIR 1971 SC 2486. Therefore the Respondent No. 2, before
passing the said detention order considered the crucial issues as to whether the
activities of the detenu were prejudicial to public and as to whether public order
could be affected by only such contravention which affects the community or the
public at large.”
16. The reference to Madhu Limaye v. Sub-Divisional Magistrate (supra) is wholly
inapposite. This judgment dealt with the scope of the expression “in the interests of
public order” which occurs in Article 19(2) to 19(4) of the Constitution of India. The
observations made by this judgment were in the context of a challenge to Section 144
of the Code of Criminal Procedure. Importantly, this Court referred to the judgment
in Ram Manohar Lohia (supra) and then opined:
“19. Adopting this test we may say that the State is at the centre and society
surrounds it. Disturbances of society go in a broad spectrum from more disturbance
of the serenity of life to jeopardy of the State. The acts become graver as we journey
from the periphery of the largest circle towards the centre. In this journey we travel
first though public tranquillity, then through public order and lastly to the security of
the State.Banka Sneha Sheela vs The State Of Telangana on 2 August, 2021

20. In dealing with the phrase “maintenance of public order” in the context of
preventive detention, we confined the expression in the relevant Act to what was
included in the second circle and left out that which was in the largest circle.
But that consideration need not always apply because small local disturbances of the even tempo of
life, may in a sense be said to effect “public order” in a different sense, namely, in the sense of a state
of law abidingness vis-a-vis the safety of others. In our judgment the expression “in the interest of
public order” in the Constitution is capable of taking within itself not only those acts which disturb
the security of the State or act within ordre publique as described but also certain acts which disturb
public tranquillity or are breaches of the peace. It is not necessary to give the expression a narrow
meaning because, as has been observed, the expression “in the interest of public order” is very wide.
Whatever may be said of “maintenance of public order” in the context of special laws entailing
detention of persons without a trial on the pure subjective determination of the Executive cannot be
said in other circumstances. In the former case this Court confined the meaning to graver episodes
not involving cases of law and order which are not disturbances of public tranquillity but of ordre
publique.”
17. To tear these observations out of context would be fraught with great danger when it comes to
the liberty of a citizen under Article 21 of the Constitution of India. The reason for not adopting a
narrow meaning of ‘public order’ in that case was because of the expression “in the interests of”
which occurs to Article 19(2) to 19(4) and which is pressed into service only when a law is challenged
as being unconstitutional for being violative of Article 19 of the Constitution. When a person is
preventively detained, it is Article 21 and 22 that are attracted and not Article 19. Further,
preventive detention must fall within the four corners of Article 21 read with Article 22 and the
statute in question. To therefore argue that a liberal meaning must be given to the expression ‘public
order’ in the context of a preventive detention statute is wholly inapposite and incorrect. On the
contrary, considering that preventive detention is a necessary evil only to prevent public disorder,
the Court must ensure that the facts brought before it directly and inevitably lead to a harm, danger
or alarm or feeling of insecurity among the general public or any section thereof at large.
18. Several judgments of this Court have reminded us about the role of the High Courts and this
Court in cases of preventive detention. Thus, in Frances Coralie Mullin v. W.C. Khambra (1980) 2
SCR 1095, a Division Bench of this Court held:
“We have no doubt in our minds about the role of the court in cases of preventive
detention: it has to be one of eternal vigilance. No freedom is higher than personal
freedom and no duty higher than to maintain it unimpaired. The Court's writ is the
ultimate insurance against illegal detention. The Constitution enjoins conformance
with the provisions of Article 22 and the Court exacts compliance. Article 22(5) vests
in the detenu the right to be provided with an opportunity to make a representation.
Here the Law Reports tell a story and teach a lesson. It is that the principal enemy of
the detenu and his right to make a representation is neither high-handedness nor
mean-mindedness but the casual indifference, the mindless insensibility, the routine
and the red tape of the bureaucratic machine.” Likewise, in Vijay Narain Singh v.Banka Sneha Sheela vs The State Of Telangana on 2 August, 2021

State of Bihar (1984) 3 SCC 14, a 3-Judge Bench of this Court (in which A.P. Sen,J.
dissented), Venkataramiah,J., speaking for the majority, reminds us:
“32. …It is well settled that the law of preventive detention is a hard law and therefore
it should be strictly construed. Care should be taken that the liberty of a person is not
jeopardised unless his case falls squarely within the four corners of the relevant law.
The law of preventive detention should not be used merely to clip the wings of an
accused who is involved in a criminal prosecution. It is not intended for the purpose
of keeping a man under detention when under ordinary criminal law it may not be
possible to resist the issue of orders of bail, unless the material available is such as
would satisfy the requirements of the legal provisions authorising such detention.
When a person is enlarged on bail by a competent criminal court, great caution
should be exercised in scrutinising the validity of an order of preventive detention
which is based on the very same charge which is to be tried by the criminal court.”
[emphasis supplied] O. Chinappa Reddy,J., in a short concurring judgment also sets
out the constitutional fundamentals qua preventive detention as follows:
“I entirely agree with my brother Venkataramiah, J. both on the question of
interpretation of the provisions of the Bihar Control of Crimes Act, 1981 and on the
question of the effect of the order of grant of bail in the criminal proceeding arising
out of the incident constituting one of the grounds of detention. It is really
unnecessary for me to add anything to what has been said by Venkataramiah, J., .but
my brother Sen, J. has taken a different view and out of respect to him, I propose to
add a few lines. I am unable to agree with my brother Sen, J. on several of the views
expressed by him in his dissent. In particular, I do not agree with the view that “those
who are responsible for the national security or for the maintenance of public order
must be the sole judges of what the national security or public order requires” It is
too perilous a proposition. Our Constitution does not give a carte blanche to any
organ of the State to be the sole arbiter in such matters. Preventive detention is
considered so treacherous and such an anathema to civilised thought and democratic
polity that safeguards against undue exercise of the power to detain without trial,
have been built into the Constitution itself and incorporated as Fundamental Rights.
There are two sentinels, one at either end. The Legislature is required to make the
law circumscribing the limits within which persons may be preventively detained and
providing for the safeguards prescribed by the Constitution and the courts are
required to examine, when demanded, whether there has been any excessive
detention, that is whether the limits set by the Constitution and the Legislature have
been transgressed. Preventive detention is not beyond judicial scrutiny. While
adequacy or sufficiency may not be a ground of challenge, relevancy and proximity
are certainly grounds of challenge. Nor is it for the court to put itself in the position of
the detaining authority and to satisfy itself that the untested facts reveal a path of
crime. I agree with my brother Sen,, J. when he says, “It has always been the view of
this Court that the detention of individuals without trials for any length of time,
however short, is wholly inconsistent with the basic ideas of our Government and theBanka Sneha Sheela vs The State Of Telangana on 2 August, 2021

gravity of the evil to the community resulting from anti-social activities can never
furnish an adequate reason for invading the personal liberty of the citizen except in
accordance with the procedure established by law.”
19. In Union of India v. Yumnam Anand (2007) 10 SCC 190, this Court reiterated some of these
principles as follows:
“8. In case of preventive detention no offence is proved, nor any charge is formulated
and the justification of such detention is suspicion or reasonability and there is no
criminal conviction which can only be warranted by legal evidence. Preventive justice
requires an action to be taken to prevent apprehended objectionable activities. (See
R. v. Halliday [1917 AC 260 : (1916-17) All ER Rep Ext 1284 : 86 LJ KB 116 : 116 LT
417 (HL)] and Kubic Darusz v. Union of India [(1990) 1 SCC 568 : 1990 SCC (Cri) 227
: AIR 1990 SC 605] .) But at the same time, a person's greatest of human freedoms
i.e. personal liberty is deprived, and, therefore, the laws of preventive detention are
strictly construed, and a meticulous compliance with the procedural safeguard,
however technical, is mandatory. The compulsions of the primordial need to
maintain order in society, without which enjoyment of all rights, including the right
of personal liberty would lose all their meanings, are the true justifications for the
laws of preventive detention.
This jurisdiction has been described as a “jurisdiction of suspicion”, and the compulsions to
preserve the values of freedom of a democratic society and social order sometimes merit the
curtailment of the individual liberty. (See Ayya v. State of U.P. [(1989) 1 SCC 374 : 1989 SCC (Cri)
153 : AIR 1989 SC 364] ) To lose our country by a scrupulous adherence to the written law, said
Thomas Jefferson, would be to lose the law, absurdly sacrificing the end to the means. No law is an
end itself and the curtailment of liberty for reasons of State's security and national economic
discipline as a necessary evil has to be administered under strict constitutional restrictions. No carte
blanche is given to any organ of the State to be the sole arbiter in such matters.”
20. In Rekha v. State of Tamil Nadu, (2011) 5 SCC 244, a 3-Judge Bench of this Court spoke of the
interplay between Articles 21 and 22 as follows:
“13. In our opinion, Article 22(3)(b) of the Constitution of India which permits
preventive detention is only an exception to Article 21 of the Constitution. An
exception is an exception, and cannot ordinarily nullify the full force of the main rule,
which is the right to liberty in Article 21 of the Constitution. Fundamental rights are
meant for protecting the civil liberties of the people, and not to put them in jail for a
long period without recourse to a lawyer and without a trial. As observed in R. v.
Secy. of State for the Home Deptt., ex p Stafford [(1998) 1 WLR 503 (CA)] : (WLR p.
518 F-G) “ … The imposition of what is in effect a substantial term of imprisonment
by the exercise of executive discretion, without trial, lies uneasily with ordinary
concepts of the rule of law.” Article 22, hence, cannot be read in isolation but must be
read as an exception to Article 21. An exception can apply only in rare andBanka Sneha Sheela vs The State Of Telangana on 2 August, 2021

exceptional cases, and it cannot override the main rule.
14. Article 21 is the most important of the fundamental rights guaranteed by the
Constitution of India. Liberty of a citizen is a most important right won by our
forefathers after long, historical and arduous struggles. Our Founding Fathers
realised its value because they had seen during the freedom struggle civil liberties of
our countrymen being trampled upon by foreigners, and that is why they were
determined that the right to individual liberty would be placed on the highest
pedestal along with the right to life as the basic right of the people of India.
xxx xxx xxx
17. Article 22(1) of the Constitution makes it a fundamental right of a person detained
to consult and be defended by a lawyer of his choice. But Article 22(3) specifically
excludes the applicability of clause (1) of Article 22 to cases of preventive detention.
Therefore, we must confine the power of preventive detention to very narrow limits,
otherwise the great right to liberty won by our Founding Fathers, who were also
freedom fighters, after long, arduous and historical struggles, will become nugatory.”
This Court went on to discuss, in some detail, the conceptual nature of preventive
detention law as follows:
“29. Preventive detention is, by nature, repugnant to democratic ideas and an
anathema to the rule of law. No such law exists in the USA and in England (except
during war time). Since, however, Article 22(3)(b) of the Constitution of India
permits preventive detention, we cannot hold it illegal but we must confine the power
of preventive detention within very narrow limits, otherwise we will be taking away
the great right to liberty guaranteed by Article
21 of the Constitution of India which was won after long, arduous and historic struggles. It follows,
therefore, that if the ordinary law of the land (the Penal Code and other penal statutes) can deal with
a situation, recourse to a preventive detention law will be illegal.
30. Whenever an order under a preventive detention law is challenged one of the questions the court
must ask in deciding its legality is: was the ordinary law of the land sufficient to deal with the
situation? If the answer is in the affirmative, the detention order will be illegal. In the present case,
the charge against the detenu was of selling expired drugs after changing their labels. Surely the
relevant provisions in the Penal Code and the Drugs and Cosmetics Act were sufficient to deal with
this situation. Hence, in our opinion, for this reason also the detention order in question was
illegal.” [emphasis supplied] In an important passage, this Court then dealt with certain general
observations made by the Constitution Bench in Haradhan Saha v. The State of West Bengal (1975)
3 SCC 198 as follows:
“33. No doubt it has been held in the Constitution Bench decision in Haradhan Saha
case [(1975) 3 SCC 198 : 1974 SCC (Cri) 816] that even if a person is liable to be triedBanka Sneha Sheela vs The State Of Telangana on 2 August, 2021

in a criminal court for commission of a criminal offence, or is actually being so tried,
that does not debar the authorities from passing a detention order under a preventive
detention law. This observation, to be understood correctly, must, however, be
construed in the background of the constitutional scheme in Articles 21 and 22 of the
Constitution (which we have already explained). Article 22(3)(b) is only an exception
to Article 21 and it is not itself a fundamental right. It is Article 21 which is central to
the whole chapter on fundamental rights in our Constitution. The right to liberty
means that before sending a person to prison a trial must ordinarily be held giving
him an opportunity of placing his defence through his lawyer. It follows that if a
person is liable to be tried, or is actually being tried, for a criminal offence, but the
ordinary criminal law (the Penal Code or other penal statutes) will not be able to deal
with the situation, then, and only then, can the preventive detention law be taken
recourse to.
34. Hence, the observation in SCC para 34 in Haradhan Saha case [(1975) 3 SCC 198 :
1974 SCC (Cri) 816] cannot be regarded as an unqualified statement that in every
case where a person is liable to be tried, or is actually being tried, for a crime in a
criminal court a detention order can also be passed under a preventive detention law.
35. It must be remembered that in cases of preventive detention no offence is proved
and the justification of such detention is suspicion or reasonable probability, and
there is no conviction which can only be warranted by legal evidence. Preventive
detention is often described as a “jurisdiction of suspicion” (vide State of
Maharashtra v. Bhaurao Punjabrao Gawande [(2008) 3 SCC 613 : (2008) 2 SCC (Cri)
128] , SCC para 63). The detaining authority passes the order of detention on
subjective satisfaction. Since clause (3) of Article 22 specifically excludes the
applicability of clauses (1) and (2), the detenu is not entitled to a lawyer or the right
to be produced before a Magistrate within 24 hours of arrest. To prevent misuse of
this potentially dangerous power the law of preventive detention has to be strictly
construed and meticulous compliance with the procedural safeguards, however
technical, is, in our opinion, mandatory and vital.
36. It has been held that the history of liberty is the history of procedural safeguards.
(See Kamleshkumar Ishwardas Patel v. Union of India [(1995) 4 SCC 51 : 1995 SCC
(Cri) 643] vide para 49.) These procedural safeguards are required to be zealously
watched and enforced by the court and their rigour cannot be allowed to be diluted
on the basis of the nature of the alleged activities of the detenu. As observed in Rattan
Singh v. State of Punjab [(1981) 4 SCC 481 : 1981 SCC (Cri) 853] : (SCC p. 483, para
4) “4. … May be that the detenu is a smuggler whose tribe (and how their numbers
increase!) deserves no sympathy since its activities have paralysed the Indian
economy. But the laws of preventive detention afford only a modicum of safeguards
to persons detained under them, and if freedom and liberty are to have any meaning
in our democratic set up, it is essential that at least those safeguards are not denied to
the detenus.” xxx xxx xxxBanka Sneha Sheela vs The State Of Telangana on 2 August, 2021

39. Personal liberty protected under Article 21 is so sacrosanct and so high in the
scale of constitutional values that it is the obligation of the detaining authority to
show that the impugned detention meticulously accords with the procedure
established by law. The stringency and concern of judicial vigilance that is needed
was aptly described in the following words in Thomas Pelham Dale case [(1881) 6
QBD 376 (CA)] : (QBD p. 461) “Then comes the question upon the habeas corpus. It
is a general rule, which has always been acted upon by the courts of England, that if
any person procures the imprisonment of another he must take care to do so by steps,
all of which are entirely regular, and that if he fails to follow every step in the process
with extreme regularity the court will not allow the imprisonment to continue.””
[emphasis supplied]
21. Shri Ranjit Kumar, learned senior counsel appearing on behalf of the State of
Telangana relied strongly upon Subramanian v. State of Tamil Nadu (2012) 4 SCC
699, and in particular upon paragraphs 14 and 15 which read as follows:
“14. It is well settled that the court does not interfere with the subjective satisfaction
reached by the detaining authority except in exceptional and extremely limited
grounds. The court cannot substitute its own opinion for that of the detaining
authority when the grounds of detention are precise, pertinent, proximate and
relevant, that sufficiency of grounds is not for the court but for the detaining
authority for the formation of subjective satisfaction that the detention of a person
with a view to preventing him from acting in any manner prejudicial to public order
is required and that such satisfaction is subjective and not objective. The object of the
law of preventive detention is not punitive but only preventive and further that the
action of the executive in detaining a person being only precautionary, normally, the
matter has necessarily to be left to the discretion of the executive authority. It is not
practicable to lay down objective rules of conduct in an exhaustive manner. The
satisfaction of the detaining authority, therefore, is considered to be of primary
importance with certain latitude in the exercise of its discretion.
15. The next contention on behalf of the detenu, assailing the detention order on the
plea that there is a difference between “law and order” and “public order” cannot also
be sustained since this Court in a series of decisions recognised that public order is
the even tempo of life of the community taking the country as a whole or even a
specified locality. [Vide Pushpadevi M. Jatia v. M.L. Wadhawan [(1987) 3 SCC 367 :
1987 SCC (Cri) 526] , SCC paras 11 & 14; Ram Manohar Lohia v. State of Bihar [AIR
1966 SC 740 : 1966 Cri LJ 608 : (1966) 1 SCR 709] ; Union of India v. Arvind Shergill
[(2000) 7 SCC 601 : 2000 SCC (Cri) 1422] , SCC paras 4 & 6; Sunil Fulchand Shah v.
Union of India [(2000) 3 SCC 409 : 2000 SCC (Cri) 659] , SCC para 28 (Constitution
Bench); Commr. of Police v. C. Anita [(2004) 7 SCC 467 : 2004 SCC (Cri) 1944] , SCC
paras 5, 7 & 13.]” The statement made by this Court in paragraphs 14 and 15 were on
facts which were completely different from the facts of the present case as reflected in
paragraphs 16 and 17 thereof which read as follows:Banka Sneha Sheela vs The State Of Telangana on 2 August, 2021

“16. We have already extracted the discussion, analysis and the ultimate decision of
the detaining authority with reference to the ground case dated 18-7-2011. It is clear
that the detenu, armed with “aruval”, along with his associates, armed with “katta”
came to the place of the complainant. The detenu abused the complainant in filthy
language and threatened to murder him. His associates also threatened him. The
detenu not only threatened the complainant with weapon like “aruval” but also
damaged the properties available in the shop. When the complainant questioned the
detenu and his associates, the detenu slapped him on his face. When the complainant
raised an alarm for rescue, on the arrival of general public in and around, they were
also threatened by the detenu and his associates that they will kill them.
17. It is also seen from the grounds of detention that because of the threat by the
detenu and his associates by showing weapons, the nearby shopkeepers closed their
shops out of fear and auto drivers took their autos from their stand and left the place.
According to the detaining authority, the above scene created a panic among the
public. In such circumstances, the scene created by the detenu and his associates
cannot be termed as only law and order problem but it is public order as assessed by
the detaining authority who is supposed to safeguard and protect the interest of
public. Accordingly, we reject the contention raised by the learned Senior Counsel for
the appellant.” This was obviously a case in which ‘public order’ was directly affected
and not a case in which ‘law and order’ alone was affected and is thus distinguishable,
on facts, from the present case.
22. In Yumman Ongbi Lembi Leima v. State of Manipur (2012) 2 SCC 176, this Court
specifically adverted to when a preventive detention order would be bad, as recourse
to the ordinary law would be sufficient in the facts of a given case, with particular
regard being had to bail having been granted. This Court held:
“23. Having carefully considered the submissions made on behalf of the respective
parties, we are inclined to hold that the (sic exercise of) extraordinary powers of
detaining an individual in contravention of the provisions of Article 22(2) of the
Constitution was not warranted in the instant case, where the grounds of detention
do not disclose any material which was before the detaining authority, other than the
fact that there was every likelihood of Yumman Somendro being released on bail in
connection with the cases in respect of which he had been arrested, to support the
order of detention.
24. Article 21 of the Constitution enjoins that:
“21. Protection of life and personal liberty.—No person shall be deprived of his life or
personal liberty except according to procedure established by law.” In the instant
case, although the power is vested with the authorities concerned, unless the same
are invoked and implemented in a justifiable manner, such action of the detaining
authority cannot be sustained, inasmuch as, such a detention order is an exception toBanka Sneha Sheela vs The State Of Telangana on 2 August, 2021

the provisions of Articles 21 and 22(2) of the Constitution.
25. When the courts thought it fit to release the appellant's husband on bail in
connection with the cases in respect of which he had been arrested, the mere
apprehension that he was likely to be released on bail as a ground of his detention, is
not justified.
xxx xxx xxx
27. As has been observed in various cases of similar nature by this Court, the personal liberty of an
individual is the most precious and prized right guaranteed under the Constitution in Part III
thereof. The State has been granted the power to curb such rights under criminal laws as also under
the laws of preventive detention, which, therefore, are required to be exercised with due caution as
well as upon a proper appreciation of the facts as to whether such acts are in any way prejudicial to
the interest and the security of the State and its citizens, or seek to disturb public law and order,
warranting the issuance of such an order. An individual incident of an offence under the Penal Code,
however heinous, is insufficient to make out a case for issuance of an order of preventive detention.”
This judgment was followed in Mungala Yadamma v. State of A.P. (2012) 2 SCC 386, as follows:
“7. Having considered the submissions made on behalf of the respective parties, we
are unable to accept the submissions made on behalf of the State in view of the fact
that the decision in Rekha case [(2011) 5 SCC 244 : (2011) 2 SCC (Cri) 596] , in our
view, clearly covers the facts of this case as well. The offences complained of against
the appellant are of a nature which can be dealt with under the ordinary law of the
land. Taking recourse to the provisions of preventive detention is contrary to the
constitutional guarantees enshrined in Articles 19 and 21 of the Constitution and
sufficient grounds have to be made out by the detaining authorities to invoke such
provisions.
8. In fact, recently, in Yumman Ongbi Lembi Leima v. State of Manipur [(2012) 2
SCC 176] we had occasion to consider the same issue and the three-Judge Bench had
held that the personal liberty of an individual is the most precious and prized right
guaranteed under the Constitution in Part III thereof. The State has been granted the
power to curb such rights under criminal laws, as also under the laws of preventive
detention, which, therefore, are required to be exercised with due caution as well as
upon a proper appreciation of the facts as to whether such acts are in any way
prejudicial to the interest and the security of the State and its citizens, or seek to
disturb public law and order, warranting the issuance of such an order.
9. No doubt, the offences alleged to have been committed by the appellant are such as
to attract punishment under the Andhra Pradesh Prohibition Act, but that in our view
has to be done under the said laws and taking recourse to preventive detention laws
would not be warranted.Banka Sneha Sheela vs The State Of Telangana on 2 August, 2021

Preventive detention involves detaining of a person without trial in order to prevent him/her from
committing certain types of offences. But such detention cannot be made a substitute for the
ordinary law and absolve the investigating authorities of their normal functions of investigating
crimes which the detenu may have committed. After all, preventive detention in most cases is for a
year only and cannot be used as an instrument to keep a person in perpetual custody without trial.
Accordingly, while following the three-Judge Bench decision in Rekha case [(2011) 5 SCC 244 :
(2011) 2 SCC (Cri) 596] we allow the appeal and set aside the order passed by the High Court dated
20-7-2011 [ The High Court dismissed the same vide Munagala Yadamma v. State of A.P., WP (Cri)
No. 13313 of 2011, order dated 20-7-2011 (AP)] and also quash the detention order dated 15-2-2011,
issued by the Collector and District Magistrate, Ranga Reddy District, Andhra Pradesh.”
23. Shri Gaurav Agrawal and Shri Ranjit Kumar also cited the judgments of this Court in Sama
Aruna v. State of Telangana (2018) 12 SCC 150 and Collector & District Magistrate v. Sangala
Kondamma (2005) 3 SCC 666 respectively. Since we are not going into other grounds raised by the
Petitioner, it is unnecessary to discuss the law laid down in these judgments.
24. On the facts of this case, as has been pointed out by us, it is clear that at the highest, a possible
apprehension of breach of law and order can be said to be made out if it is apprehended that the
Detenu, if set free, will continue to cheat gullible persons. This may be a good ground to appeal
against the bail orders granted and/or to cancel bail but certainly cannot provide the springboard to
move under a preventive detention statute. We, therefore, quash the detention order on this ground.
Consequently, it is unnecessary to go into any of the other grounds argued by the learned counsel on
behalf of the Petitioner. The impugned judgment is set aside and the Detenu is ordered to be freed
forthwith. Accordingly, the appeal is allowed.
…………………..………………J. (R. F. Nariman) ……………..…………………… J. (Hrishikesh Roy) New
Delhi, August 02, 2021.Banka Sneha Sheela vs The State Of Telangana on 2 August, 2021

