Aasan vs State Of Tamil Nadu on 18 December, 2023
Author: M.Sundar
Bench: M.Sundar
    2023/MHC/5510
                                                                      H.C.P(MD)No.1267 of 2023
                      BEFORE THE MADURAI BENCH OF MADRAS HIGH COURT
                                            DATED: 18.12.2023
                                                  Coram
                                    THE HON'BLE MR.JUSTICE M.SUNDAR
                                                   and
                                  THE HON'BLE MR. JUSTICE R.SAKTHIVEL
                                         H.C.P(MD)No.1267 of 2023
                  Aasan                                         .. Petitioner/
                                                                   brother of the detenu
                                                    vs
                  1.State of Tamil Nadu,
                    Represented by its Principal Secretary to Government,
                    Government of Tamil Nadu,
                    Home, Prohibition & Excise Department,
                    Chennai – 9.
                  2.The Commissioner of Police,
                    Madurai City, Madurai.
                  3.The Superintendent,
                    Central Prison, Madurai.                    .. Respondents
                  Prayer:- Petition filed under Article 226 of the Constitution of India
                  praying for issuance of a writ of Habeas Corpus to call for the records
                  pertaining to the proceedings of the second respondent made in his
                  proceedings in Detention Order No.79/BCDFGISSSV/2023 dated
                  16.09.2023 and quash the same and set the petitioner's brother by name
https://www.mhc.tn.gov.in/judis
                  1/10
                                                                           H.C.P(MD)No.1267 of 2023Aasan vs State Of Tamil Nadu on 18 December, 2023

                  'Imrankhan @ Usain, Son of Abuthahir, aged about 25 years at liberty
                  from Superintendent of Police, Central Prison, Madurai.
                            For Petitioner          :    Mr.C.Karthikeya
                            For Respondents         :    Mr.A.Thiruvadi Kumar
                                                         Additional Public Prosecutor
                                                        ORDER
[Order of the Court was made by R.SAKTHIVEL, J.] This 'Habeas Corpus Petition' [henceforth
referred to as 'HCP'] has been filed in the Court on 12.10.2023 by the brother of the detenu assailing
a 'preventive detention order dated 16.09.2023 bearing reference No.79/BCDFGISSSV/2023'
[henceforth referred to as 'impugned preventive detention order']. To be noted, the second
respondent is the Detaining Authority as the impugned preventive detention order has been made
by him. The Inspector of Police, C2 Subramaniyapuram Police Station is the Sponsoring Authority
[henceforth referred to as 'Sponsoring Authority'].
2. Impugned preventive detention order has been made under 'The Tamil Nadu Prevention of
Dangerous Activities of https://www.mhc.tn.gov.in/judis Bootleggers, Cyber law offenders,
Drug-offenders, Forest-offenders, Goondas, Immoral traffic offenders, Sand-offenders,
Sexual-offenders, Slum-grabbers and Video Pirates Act, 1982 (Tamil Nadu Act No.14 of 1982)'
[henceforth referred to as 'Act 14 of 1982'] on the premise that the detenu is a 'Goonda' within the
meaning of Section 2(f) of Act 14 of 1982.
3.At the time of admission, learned counsel for petitioner has raised a point that in the grounds
booklet, several documents are in English language but Tamil translated version was not served on
the detenu which prevented the detenu from making an effective representation.
4.The admission board order dated 31.10.2023 reads as follows:
M.SUNDAR, J.
and R.SAKTHIVEL, J.
ORDER ************ [Order of the Court was made by M.SUNDAR, J.,]
https://www.mhc.tn.gov.in/judis Captioned Habeas Corpus Petition has been filed in
this Court on 12.10.2023 inter alia assailing a 'detention order dated 16.09.2023,
bearing reference No. 79/BCDFGISSSV/2023 [hereinafter 'impugned preventive
detention order' for the sake of convenience, clarity and brevity] made by 'second
respondent' [hereinafter 'Detaining Authority' for the sake of convenience].
2.To be noted, the brother of the detenu is the petitioner.Aasan vs State Of Tamil Nadu on 18 December, 2023

3.Mr.C.Prithviraj, learned counsel on record for petitioner is before us. Learned
counsel for petitioner submits that ground case qua the detenu is for alleged offences
under Sections 294(b), 324, 506(ii) of 'the Indian Penal Code, 1860 (Act 45 of 1860)'
[hereinafter 'IPC' for the sake of brevity] and subsequently altered into Sections 147,
148, 294(b), 324, 307 and 506(ii) IPC in Crime No.318 of 2023 on the file of C2,
Subramaniyapuram Police Station.
4.The aforementioned impugned preventive detention order has been made on the
premise that the detenu is a 'Goonda' under Section 2(f) of 'The Tamil Nadu
Prevention of Dangerous Activities of Bootleggers, Cyber law offenders,
Drug-offenders, Forest-offenders, Goondas, Immoral traffic offenders,
Sand-offenders, Sexual-offenders, Slum-grabbers and Video Pirates Act, 1982 (Tamil
Nadu Act No.14 of 1982)' [hereinafter 'Act 14 of 1982' for the sake of convenience and
clarity].
5.The impugned preventive detention order has been assailed inter alia on the
ground that in the grounds booklet, several documents are in English language but
Tamil translated version was not served on detenu which prevented the detenu from
making an effective representation.
6.Prima facie case made out for admission. Admit.
Issue Rule nisi returnable by four [4] weeks. https://www.mhc.tn.gov.in/judis
7.Mr.A.Thiruvadi Kumar, learned State Additional Public Prosecutor accepts notice for all
respondents. List the captioned Habeas Corpus Petition accordingly.'
5.Today, in the final hearing board, learned counsel for petitioner raised a point that subjective
satisfaction recorded by the detaining authority with regard to the third adverse case namely, Crime
No:317/2023 on the file of C2 Subramaniyapuram Police Station is flawed. Elaborating the said
point, learned counsel submitted that the detaining authority while recording subjective satisfaction
has relied on a similar case bail order namely, co-accused R.Vignesh bail order. The said order is not
similar to the third adverse case. Learned counsel drew our attention to a portion of paragraph 5 of
grounds of the impugned preventive detention order which reads as follows:
'I am also aware that conditional bail was granted by the Principal Sessions Judge,
Madurai in Crl.M.P.No.5187/2023 on 13.09.2023 to Vignesh, co-accused of
Imrankhan @ Usain in the above said third adverse case in C2 Subramaniyapuram
Police Station Crime No.317/2023.
https://www.mhc.tn.gov.in/judis Hence, I am satisfied that there is a real possibility
of his (Imrankhan @ Usain, s/o.Abuthahir) coming out on bail through the pending
bail applications before the Court concerned in the ground case and third adverse
case, since in a case similar to that of the ground case, bail has been granted by theAasan vs State Of Tamil Nadu on 18 December, 2023

court concerned and the co-accused of Imrankhan @ Usain was granted conditional
bail in the third adverse case in the court concerned.'
6.Learned counsel further submitted that copy of the similar case bail order namely, co-accused
R.Vignesh case bail order which was passed by the learned Principal District and Sessions Judge,
Madurai in Crl.M.P.No.5187 of 2022 dated 13.09.2023 has been furnished to the detenu at page
no.272 as part of the grounds booklet. Further, learned counsel submitted that at the time of
considering the bail plea to the co- accused R.Vignesh, he has no previous case and was a college
student. In that effect, he had produced Student Identity Card. Considering the facts and
circumstances of that case, learned Sessions Judge granted bail to R.Vignesh, petitioner therein.
But, in the case on hand, detenu has three adverse cases and one ground case. Hence, the subjective
satisfaction arrived at by the detaining authority that imminent https://www.mhc.tn.gov.in/judis
possibility of the detenu being enlarged on bail is flawed exercise and erroneous decision.
Accordingly, he prayed to set aside the impugned preventive detention order.
7. Per contra, learned Additional Public Prosecutor for the respondents submitted that the offences
under the similar case and the offences under the third adverse case are broadly comparable.
Accordingly, he prayed to sustain the impugned preventive detention order.
8. We have considered both sides' submissions. The detenu has three adverse cases and one ground
case. The bail was granted to the detenu in the first and second adverse cases. The third adverse case
is in Crime No:317/2023 under Section 294(b), 364A, 323, 325 and 392 of IPC, on the file of C2
Subramaniyapuram Police Station. The earlier bail application filed by the detenu was dismissed in
Crl.M.P.No.3705 of 2023 by the Judicial Magistrate Court No.IV, Madurai. The detenu filed another
bail application before the Principal Sessions Court, Madurai in Crl.M.P.No.4843 of 2023 which was
also dismissed on 31.08.2023. In these circumstances, the detaining authority recorded
https://www.mhc.tn.gov.in/judis subjective satisfaction by relying on the co-accused R.Vignesh bail
order.
9. Similar case bail petitioner namely, R.Vignesh was a college student and he had no previous case.
The said aspects weighed the mind of the bail Court for granting bail to the petitioner therein
namely, R.Vignesh. In the case on hand, the detenu has three adverse cases and one ground case.
The detaining authority himself has stated the details of the adverse cases of the detenu in the
grounds of detention. Hence, the subjective satisfaction arrived at by the detaining authority
regarding the imminent possibility of the detenu being enlarged on bail would show his
non-application of mind before passing the impugned preventive detention order. Hence, we are
inclined to interfere with the impugned preventive detention order.
10.In the result, the captioned HCP is allowed. Impugned preventive detention order dated
16.09.2023 bearing reference No.79/BCDFGISSSV/2023 made by the second respondent is set
aside and the detenu Thiru.Imrankhan @ Usain, male aged 25 years, son of Thiru.Abuthahir, is
directed to be set at liberty forthwith, if not required https://www.mhc.tn.gov.in/judis in connection
with any other case / cases. There shall be no order as to costs.Aasan vs State Of Tamil Nadu on 18 December, 2023

(M.S.,J.) (R.S.V.,J.) 18.12.2023 Index : Yes Neutral Citation : Yes ps / jen Post Script:
(i) Registry to forthwith communicate this order to Jail authorities in Central Prison,
Madurai.
(ii) All concerned to act on this order being uploaded in official website of this Court
without insisting on certified copies. To be noted, this order when uploaded in official
website of this Court will be watermarked and will also have a QR code.
To
1.The Principal Secretary to Government, Government of Tamil Nadu, Home, Prohibition & Excise
Department, Chennai – 9.
2.The Commissioner of Police, Madurai City, Madurai.
3.The Superintendent, Central Prison, Madurai.
4.The Joint Secretary to Government, Public (Law and Order) Department, Secretariat, Chennai.
5.The Additional Public Prosecutor, Madurai Bench of Madras High Court, Madurai.
M.SUNDAR, J., https://www.mhc.tn.gov.in/judis and R.SAKTHIVEL, J., ps / jen 18.12.2023
https://www.mhc.tn.gov.in/judisAasan vs State Of Tamil Nadu on 18 December, 2023

