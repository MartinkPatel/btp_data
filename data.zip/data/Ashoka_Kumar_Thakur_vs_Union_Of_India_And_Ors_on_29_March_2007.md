Ashoka Kumar Thakur vs Union Of India And Ors on 29 March,
2007
Equivalent citations: (2007) 2 SCT 655, AIRONLINE 2007 SC 114, (2007) 2 ESC
274, (2007) 5 SCALE 179, (2007) 7 SERV LR 4, 2007 (4) SCC 361, (2007) 2 MAD
LJ 1211, (2007) 3 SUPREME 268, (2018) 188 ALLINDCAS 230, (2018) 6 SCALE
168, (2019) 132 ALL LR 58
Author: Arijit Pasayat
Bench: Arijit Pasayat, Lokeshwar Singh Panta
           CASE NO.:
Writ Petition (civil)  265 of 2006
PETITIONER:
Ashoka Kumar Thakur
RESPONDENT:
Union of India and Ors
DATE OF JUDGMENT: 29/03/2007
BENCH:
Dr. ARIJIT PASAYAT & LOKESHWAR SINGH PANTA
JUDGMENT:
J U D G M E N T I.A. No.13 IN WRIT PETITION (CIVIL) NO. 265 OF 2006 (With WP (Civil) Nos.
269/2006, 598/2006, 35/2007 and 29/2007) Dr. ARIJIT PASAYAT, J.
In this I.A. prayer has been made to grant interim protection pending final disposal of the writ
petitions.
In the writ petitions the policy of 27% reservation for the Other Backward Classes (in short the
'OBCs') contained in the Central Educational Institutions (Reservation in Admission) Act, 2006 (in
short the 'Act') is the subject matter of challenge. The primary ground of challenge is that the Union
of India has failed in performing the constitutional and legal duties toward the citizenry and its
resultant effect. Consequentially the Act shall have the effect and wide ramifications and ultimately
it shall have the result in dividing the country on caste basis. It would lead to chaos, confusion, and
anarchy which would have destructive impact on the peaceful atmosphere in the educational and
other institutions and would seriously affect social and communal harmony. The constitutional
guarantee of equality and equal opportunity shall be seriously prejudiced. It has been contended
that a time has come to replace the "vote bank" scenario with "talent bank". The statute in question,
it is contended, has lost sight of the social catastrophe it is likely to unleash. Not only the productsAshoka Kumar Thakur vs Union Of India And Ors on 29 March, 2007

would be intellectual pigmies as compared to normal intellectual sound students presently passing
out. It has been highlighted that on the basis of unfounded and unsupportable data about the
number of OBCs in the country the Act has been enacted. It has been pointed out that this Court in
Indra Sawhney v. Union of India and Ors. (1992 Supp. (3) SCC 217) had recognised the concept of
"creamy layer" amongst the advanced OBCs to be kept out of preferential treatment. The population
data of 52% projected by the Mandal Commission was not actually given the seal of acceptance. In
any event, this Court in its judgment dated 16.11.1992 directed the Government to constitute a
permanent body by 15th March, 1993 for examining and recommending for inclusion or exclusion in
the lists of backward classes of citizens. The National Commission for Backward Classes Act, 1993
(in short the 'Backward Classes Act') defines 'backward classes" to mean such backward classes of
citizens other than the Scheduled Castes and Scheduled Tribes as may be specified by the Central
Government in the lists. In terms of Section 2(c) of the Act "lists" mean lists prepared by the
Government of India from time to time for the purpose of making provision for the reservation of
appointments or posts in favour of backward classes of citizens which in the opinion of the
Government are not adequately represented in the services under the Government of India and any
legal or other authority within the territory of India or under the control of the Government of India.
Though there is a specific provision in Section 11 of the Backward Classes Act for a periodic revision
of the lists, same has not been done, and on the contrary additions are being made. The rational of
27% having been arrived at on the mythical figure that the OBCs are 52% in the country and even
the ratio of 27% reservation for the students belonging to other backward classes in the educational
institutions is to be funded and controlled by the Central Government. The same is to be enforced
from May 2007. It is highlighted that after 1931 census there has never been any caste-wise
enumeration or tabulation which in essence corrodes the credibility of the claim of 52% population
of other backward classes.
It is pointed out that in terms of Section 2(g), 3(iii), Sections 5(1)(2) and 6 of the Act, 27% seats are
being reserved for other backward classes out of only permitted strength. The expression "Other
Backward Classes" means the class or classes of citizens who are socially or educationally backward
and are so determined by the Central Government. There has never been any determination on any
acceptable basis. The parameters provided in the Backward Classes Act have not been kept in view.
Without supportable data the introduction of a Statute which would have the effect of disturbing the
harmony in the society was avoidable. Though it has been provided that increase in the number of
seats can be done in a staggered manner, that is really of no consequence. The stand that number of
seats available for the general categories remains unaffected is really not a solution as in essence
unequals are treated as equals. The very concept of equality enshrined in Article 14 of the
Constitution of India, 1950 (in short the 'Constitution') is directly affected.
Reference is made to the figures provided by the National Samples Survey of India and the National
Health and Family Survey (Government of India's own Departments) which clearly establish the
hollowness of the claim about OBCs being 52% of the population. The source for the enactment of
the Act was the 93rd amendment to the Constitution which has come into force w.e.f. 20.1.2006 by
insertion of Clause (5) in Article 15 of the Constitution.
Prayer has been made to declare certain provisions in the Act to be unconstitutional.Ashoka Kumar Thakur vs Union Of India And Ors on 29 March, 2007

The effect of the judgments in M. Nagaraj and Ors. v. Union of India and Ors. (2006 (8) SCC 212)
and Nair Service Society v. State of Kerala (Writ Petition (Civil) No. 598 of 2000 etc. decided on
23.02.2007) has not been considered. It has been emphasized that what may have been relevant
eight decades back cannot hold good in the present scenario. There has to be indepth analysis to
find out the number of socially and educationally backward class of citizens. The concept of
Backward class citizens is dealt with in para 786 of Indra Sawhney's case (supra). It is pointed out
that in the immediately succeeding paragraph i.e. Paragraph 787 the position has been clarified. In
that paragraph reference has also been made at page 720 that certain classes which may not qualify
for Article 15(4) may qualify for Article 16(4). Reference is made to Janki Prasad Parimoo v. State of
J & K (1973 (1) SCC 420) to contend that it is social and educational backwardness of a class which
is material for the purposes of Articles 16(4). It does not have determinative relevance for the
purposes of Articles 15(4) and 15(5). Further reference is also made to the concluding para 859 in
Indra Sawhney's case (supra) where it has been said in category (3)(c) that it is not correct to say
that backward class of citizens contemplated in Article 16(4) is the same as the socially and
educationally backward classes referred to in Article 15(4). It is much wider. Therefore, it is
submitted that the concept of socially and educationally backward classes in Article 15(4) stand on a
different footing from Article 16(4) and consequentially Article 15(5) is different from Article 16(4).
It has been highlighted that in any event the concept of creamy layer which has been completely
kept out of consideration in the Statute has great relevance and effect. The criteria of Article 16(4)
and the lists under the Backward Classes Act can at the most provide a rough and ready rule for the
purpose of Articles 15(4) and 15(5) but that does not in any way take care of the requirements of
Section 11 of the Backward Classes Act. There is no report subsequent to 3.2.2005 by the National
Commission for the Backward Classes. Therefore, it is highlighted that the whole exercise has been
done in great hurry without any justifiable reason. Since there is no data base after 1931 census,
what the Government could have done is to find out a definite data base and then take such action
as is permissible in law. Even otherwise, the Office Memorandum bearing
No.36012/31/90-Est.(SCT) dated 13.8.1990 on which great emphasis has been laid by learned
Additional Solicitor General for the respondent- Union of India, does not take note of another
O.M.No.36012/22/93-Estt.(SCT) dated 8.9.1993 which expressly states as follows:
"(d) The OBCs for the purpose of the aforesaid reservation would comprise, in the
first phase, the castes and communities which are common to both the lists in the
report of the Mandal Commission and the State Governments' Lists. A list of such
castes and communities is being issued separately by the Ministry of Welfare."
It has been pointed out that the Act itself specifically requires a determination of socially and
educationally backward classes to be made by the Central Government, as is clear from a bare
reading of Section 2(g). That has not been done for the purposes of the Act and by referring to the
lists meant for cases covered by Article 16(4) the requirements have not been met, there cannot be
any basis for contending that the "creamy layer concept" attached to Article 16(4) has no relevance
for Articles 15(4) and 15(5). It is pointed out that the intention of the Parliament does not appear to
be that any existing list under Article 16(4) should be treated as the foundation for Section 2(g) of
the Act. The determination should be made "in futuro" and not by adopting any past determinationAshoka Kumar Thakur vs Union Of India And Ors on 29 March, 2007

by the National Commission for the purposes of Article 15(5). The "special provision of law" under
Article 15(5) is the Act which provides that OBCs must be so determined for the purposes of the Act
by the Central Government (underlined for emphasis). There has been no separate determination.
In essence, it is submitted that the baseless figure of 27% cannot be pressed into service for
introducing a Statute which has such wide ramifications. No methodology has been laid down for
determining the socially and educationally backward classes because castes alone should not be
made the basis for identification even though there appears to be some casual observations in Indra
Sawhney's case (supra) as contended by learned Additional Solicitor General that castes can be
synonyms with class. That is not the correct approach. It was only stated that castes may be the
starting point for identifying the backward class, but it can not definitely be the sole basis.
The figure of 27% it is emphasized is an imaginary figure with no rational. The non exclusion of
"creamy layer"
has also affected the validity of the Statute.
In addition to these aspects highlighted by Mr. F.S. Nariman, Senior Advocate, Mr.
P.P. Rao, Senior Advocate, Mr. M.L. Lahoti, Advocate, Mr. Sushil Kr. Jain, Advocate,
Mr. V. Tankha, Senior Advocate, Mr. Ashoka Kr. Thakur and Dr. Mittal, who appear
in person, have more or less highlighted to similar effect.
Mr. P.P. Rao, Senior Advocate, with reference to certain observations in Indra
Sawhney's case (supra) has submitted that inclusion of castes in the lists of backward
classes cannot be mechanic and cannot be done without adequate relevant data.
The following reports have also been referred to highlight as to how figures arrived at
by the Union are erroneous.
"(a) The National Sample Survey Organisation survey of 1999-2000 which shows that
the present educational level is directly proportionate to his/her economic condition.
(pp. 14-15 para 7.21, 7.22 and 7.23)
(b) Section 11 of the National Commission for Backward Classes Act, 1993 which says
"The Central Government may at any time, and shall, at the expiration of ten years
from the coming into force of this Act and every succeeding period of ten years
thereafter, undertake revision of the lists with a view to excluding from such lists
those classes who have ceased to be backward classes or for including in such lists
new backward classes.
(c) Standing Committee on Social Justice and Empowerment Chaired by Sumitra
Mahajan 2005-2006 (pp 18-22 - Copy of the Report is Annexure P-lI in Vol.II at
pp.142-217).Ashoka Kumar Thakur vs Union Of India And Ors on 29 March, 2007

(d) 186th Report of the Parliamentary Standing Committee of Human Resources
Development submitted to the Parliament on 1-12-2006 (pp. 22-23 paras 8.8 to
8.13).
The Report is Annexure P-Ill in Vol.II at pp.218-227).
(e) Annual Report of National Commission for Backward Classes dt. 3-2-2005. (Para 8.14 at pp
25-26). The Report is Annexure P-IV in Vol.II at pp. 228-317.
(f) Report of the Oversight Committee constituted under the Orders of the Prime Minister on
27-5-2006 (pp. 29-30 para 8.19 to 8.21). The Report is Annexure P-V in Vol.II at pp 318-353."
It is pointed out that Office Memoranda of 1990 and 1991 referred to in Indra Sawhney's case
(supra) cannot hold the field forever. It is pointed out that if that continues to be so, Section 11 of the
Backward Classes Act would be rendered nugatory. The revision of the lists was called for after
expiration of the period of 10 years. The non-revision renders the acceptability of the figures
doubtful and basisless.
In Mandal Commission's Report it was inter-alia observed as follows:
"On the basis of the Commission's Report - popularly known as Mandal
Commission's Report -(for short 'the Report'), two Office Memoranda - one dated
August 13, 1990 and the other amended one dated September 25, 1991 were issued by
the Government of India. We are reproducing those Memoranda hereunder for
proper understanding and appreciation of the significance of these two OMs and the
distinctions appearing between them:
"No. 36012/31/90-Estt. (SCT) Government of India Ministry of Personnel, Public
Grievances & Pensions (Deptt. of Personnel & Training) OFFICE MEMORANDUM
New Delhi, the 13th August, 1990 Subject: Recommendation of the Second Backward
Classes Commission (Mandal Report) - Reservation for Socially and Educationally
Backward Classes in Services under the Government of India.
In a multiple undulating society like ours, early achievement of the objective of social
justice as enshrined in the Constitution is a must. The second Backward Classes
Commission called the Mandal Commission was established by the then Government
with this purpose in view, which submitted its report to the Government of India on
31.12. 1980.
2. Government have carefully considered the report and the recommendations of the
Commission in the present context responding the benefits to be extended to the
socially and educationally backward classes as opined by the Commission and are of
the clear view that at the outset certain weightage has to be provided to such classes
in the services of the Union and their Public Undertakings. Accordingly orders areAshoka Kumar Thakur vs Union Of India And Ors on 29 March, 2007

issued as follows:
(i) 27 per cent of the vacancies in civil posts and services under the Government of
India shall be reserved for SEBC.
(ii) The aforesaid reservation shall apply to vacancies to be filled by direct
recruitment. Detailed instructions relating to the procedure to be followed for
enforcing reservation will be issued separately.
(iii) Candidates belonging to SEBC recruited on the basis of merit in an open
competition on the same standards prescribed for the general candidates shall not be
adjusted against the reservation quota of 27 per cent.
(iv) The SEBC would comprise in the first phase the castes and communities which
are common to both, the list in the report of the Mandal Commission and the State
Governments' lists. A list of such castes/communities is being issued separately.
(v) The aforesaid reservation shall take effect from 7.8.1990. However, this will not
apply to vacancies where the recruitment process has already been initiated prior to
the issue of these orders.
Similar instructions in respect of public sector undertakings and financial institutions including
public sector banks will be issued by the Department of Public Enterprises and Ministry of Finance
respectively. Sd/.
(Smt Krishna Singh) Joint Secretary to the Govt. of India"
AMENDED MEMORANDUM:
"No. 36012/31/90-Estt. (SCT) Government of India Ministry of Personnel, Public
Grievances & Pensions (Deptt.of Personnel & Training) OFFICE MEMORANDUM
New Delhi, the 25th September 1991 Subject: Recommendation of the Second
Backward Classes Commission (Mandal Report) - Reservation for Socially and
Educationally Backward Classes in Services under the Government of India.
The undersigned is directed to invite the attention to O.M. of ever number dated the
13th August 1990, on the above sections of the SEBCs to receive the benefits of
reservation on a preferential basis and to provide reservation for other economically
backward sections of the people not covered by any of the existing schemes of
reservation, Government have decided to amend the said Memorandum with
immediate effect as follows:
2. (i) Within the 27 per cent of the vacancies in civil posts and services under the
Government of India reserved for SEBCs, preference shall be given to candidatesAshoka Kumar Thakur vs Union Of India And Ors on 29 March, 2007

belonging to the poorer sections of the SEBCs. In case sufficient number of such
candidates are not available, unfilled vacancies shall be filled by the other SEBC
candidates.
(ii) 10 per cent of the vacancies in civil posts and services under the Government of
India shall be reserved for other economically backward sections of the people who
are not covered by any of the existing schemes of reservation.
(iii) The criteria for determining the poorer sections of the SEBCs or the other
economically backward sections of the people who are not covered by any of the
existing schemes of reservations are being issued separately.
3. The O.M. of even number dated the 13th August 1990, shall be deemed to have
been amended to the extent specified above.
Sd/ (A.K. Harit) Dy. Secretary to the Govt. of India"
The expression deployed in both the OMs, "Socially and Educationally Backward
Classes" is on the strength of the Report of the Commission, though no such
expression is used in Article 16(4) whereunder the reservation or appointments or
posts in favour of any backward class of citizens is to be made. This expression is
used as an explanatory one to the words 'backward class' occurring in Article 16(4).
Articles 16(4) and 340(1) were embodied in the Constitution even at the initial stage;
but Article 15(4) containing the same expression as in Article 340(1) was
subsequently added by the Constitution (First Amendment) Act of 1951 to override
the decision of this Court in State of Madras v. Smt Champakam Dorairajan (1951
SCR 525)"
According to Mr. M.L. Lahoti, the Act specifically overlooks the mandate of Article 340 of the
Constitution. According to him also the specific directions given by this Court in Indra Sawhney's
case (supra) have been dis- regarded. Specific reference in this context is made to Section 11 of the
Backward Classes Act. It is submitted that Article 340 provides that the condition of socially and
educationally backward classes is to be investigated imperatively. Reference is also made to K.C.
Vasanth Kumar and Anr. v. State of Karnataka (1985 Supp SCC
714) to submit that the policy of reservation for employment and education should be necessarily
reviewed. It was noted in that case that a time has come to review the criterion for identifying
socially and educationally backward classes ignoring the caste label. Identification is an imperative
requirement and cannot be by-passed on any ipsi-dixi referring to out-dated data based on 1931
census. The object of advancement of socially and educationally backward classes undisputedly
brings in the concept of creamy layer. Certain institutions are basically super specialty institutions
e.g. All India Institute of Medical Science (AIIMS). If the character of an institution of super
specialty of national importance is permitted to be affected in the manner sought to be done it
would be counted productive. That would affect quality of education.Ashoka Kumar Thakur vs Union Of India And Ors on 29 March, 2007

About the Mandal Commission's report, it has been pointed out by Dr. Mittal who appears in person
that survey conducted selected 0.15 of the total villages population and 7% of the district blocks.
There is nothing to suggest as to on what basis the particular village or particular district was
selected. The Commission itself distributed two groups (a) intermediate OBC and (b) depressed
OBC, which were equi-distributed. It has been emphasized that the Mandal Commission while
arriving at the figure of 52% population of OBC had added 8.6% population of other non Hindu
communities. Thus, non Hindu communities formed 17% of the total OBC population. The
management of social backwardness, it is submitted, has to be dynamic which means that the
various measures to be adopted as a remedy have to be time bound and reviewable.
In response, Mr. Gopal Subramanium, learned ASG appearing for the Union has submitted that all
the issues that are being raised have been appropriately dealt with in Indra Sawhney's case (supra)
and long earlier in Minor P. Rajendra v. State of Madras and Ors. [1968 (2) SCR 786]. It is
submitted that reservation whether in employment or in education is not violative of the basic
structure or equality code. Various provisions in the Constitution acknowledge that reservation is an
integral part of the principle of equality where inequality exists. There is nothing wrong or
unconstitutional in specifying in terms of units of castes, those who have been identified as "Socially
and Educationally Backward Classes" on the basis of criteria of social and educational
backwardness. Reservation is not anti merit. In the absence of caste data after 1931, there was no
alternative but to project the population proportion of social and educational backward classes and
other backward classes from the next best source i.e. latest available census of 1931. The
identification and listing of such classes by Mandal Commission has nothing to do with the census of
1931 but was based on multiple approach in the contemporary context only and not in the context of
1931.
Determination or classification as to which class belongs to social and educational backward class or
other backward class as made by the Government of India is valid and the Backward Classes
Commission has a statutory function of examining as to which class included in the list is not really
backward. Reservation policy is not dis-integrative and is not against the unity and integrity of the
nation. On the contrary, according to him, reservation policy is a means of integrating the society
disintegrated over the centuries by the age old caste system. It is submitted that the lists of OBCs
identified on the basis of social and educational backwardness have been determined. The Ministry
of Welfare (now named as Ministry of Social Justice & Empowerment) is in charge of the subject.
There are State-wise lists. Once issued, these lists continue to be in force and are binding for any or
all purposes, subject to modifications, deletions, additions from time to time in accordance with the
Backward Classes Act and in the light of decision in Indra Sawhney's case (supra).
The lists of Scheduled Castes and Scheduled Tribes categories covered by Clause (h) and (i) of
Section 2 have already been notified in the past, and are subject to changes in accordance with
Articles 341 and 342 of the Constitution.
The fact that there has been centuries long historical oppression in relation to Scheduled Castes and
Scheduled Tribes and Socially and Educationally Backward Classes and Other Backward Classes,
has been recognized by this Court in Indra Sawhney's case (supra).Ashoka Kumar Thakur vs Union Of India And Ors on 29 March, 2007

Reference is also made to the decision of this Court in State of A.P. v. U.S.V. Balram (1972 (1) SCC
660) which was referred to in Indra Sawhney's case (supra). The contentions, as noted above, have
not only focused on legal issues but also on factors of great social relevance. The issues need deeper
consideration in the background of their legal and social importance. The only question is whether it
would be desirable to stay process of implementation of the Act and, if so, to what extent.
There is no dispute and in fact it was fairly accepted by learned Additional Solicitor General that
there is need for periodical identification of the backward citizens and for this purpose the need for
survey of entire population on the basis of an acceptable mechanism. What may have been relevant
in 1931 census may have some relevance but cannot be the determinative factor. As was observed by
this Court in Nagaraj's case (supra) backwardness has to be based on objective factors whereas
inadequacy has to factually exist.
Even in Indra Sawhney (II) [2000 (1) SCC 168] at Para 9 it was held as follows:
"9. Inclusion of castes in the list of backward classes cannot be mechanical and
cannot be done without adequate relevant data. Nor can it be done for extraneous
reasons. Care should be taken that the forward castes do not get included in the
backward castes' list. In Indra Sawhney' Pandian, J. observed (SCC p. 408, para 174)
that before a conclusion is drawn that a caste is backward or is inadequately
represented in the services, "the existence of circumstances relevant to the formation
of opinions is a sine qua non. If the opinion suffers from the vice of non-application
of mind or formulation of collateral grounds or beyond the scope of statute, or
irrelevant and extraneous material, then that opinion is challengeable".
Sawant, J. (see para 539 of SCC) too pointed out the need for proper application of mind to the facts
and circumstances, the field, the post and the extent of existing representation and the need to
balance representation. On behalf of himself and three others, Jeevan Reddy, J. pointed out (para
798 SCC) that opinion in regard to backwardness and inadequate representation must be based on
relevant material. The scope of judicial scrutiny even with regard to matters relating to subjective
satisfaction are governed by the principles stated in Barium Chemicals Ltd. v. Company Law Board
(AIR 1967 SC 295). Likewise, periodic examination of a backward class could lead to its exclusion if
it ceases to be socially backward or if it is adequately represented in the services. Once backward,
always backward is not acceptable. In any case, the "creamy layer" has no place in the reservation
system."
The concept of creamy layer cannot prima facie be considered to be irrelevant. It has also to be
noted that nowhere else in the world do castes, classes or communities queue up for the sake of
gaining backward status. Nowhere else in the world is there competition to assert backwardness and
then to claim we are more backward than you. This truth was recognized as unhappy and disturbing
situation and such situation was noted by this Court as a stark reality in Indra Sawhney's case
(supra).Ashoka Kumar Thakur vs Union Of India And Ors on 29 March, 2007

According to some jurists, equality as a fundamental substantive norm is a characteristic feature of
many democratic Constitutions. In societies that are diverse or in societies where certain groups of
people were subjected to discrimination in the past subscription to the norm of equality necessitates
an element of affirmative action. That may be the underlying object of Article 15. In India the
"Varna" system of the early Vedic period was distorted and became a rigid and hierarchical caste
system which resulted in lower castes being socially oppressed and economically exploited.
Whatever be the truth in this plea, in the late 19th and early 20th century social reform movements
started. An eminent jurist has noted that the equality provisions in the Indian Constitution were
intended to be a pro-active means of social engineering and it is against this backdrop that the
jurisprudence of reservations has developed in the Indian context. By contrast, the scenario in
United States and South Africa can be looked at. The Constitution of US is older in point of time
than that of Indian or South African Constitution. When it was initially adopted there was no
mention of equality. The institution of slavery was legally sanctioned. It was only after the Civil War
that the Thirteenth and fourteenth amendments to the Constitution were enacted. The institution of
slavery was abolished and "equal protection clause" came to be enacted.
The "separate but equal doctrine" was sanctified by the decision of US Supreme Court in Plessy v.
Ferguson (163 US 537). But the formal equality was established in US after the decision in Brown v.
Board of Education (347 US 483) and the Civil Rights Act, 1964. It is to be noted that in both the
United States and South Africa, the past discrimination was along racial lines.
This Court has in several instances focused on the question as to whether Articles 15(4) and 16(4)
are a facet of equality or a derogation from it.
Equality of opportunity is not simply a matter of legal equality. Its existence depends not merely on
the absence of disabilities but on the presence of abilities. Where, therefore, there is inequality in
fact, legal equality always tends to accentuate it. (See Dr. Pradeep Jain and Ors. v. Union of India
and Ors. (1984 (3) SCC 654).
In Indra Sawhney's case (supra) it appears that underlying principles which have been identified are
the identification of class, which was held to be affirmative by using castes as a proxy. The State was
Constitutionally empowered to enact affirmative action measures for backward classes.
Differentiation or classifications for special preference must not be unduly unfair for the persons left
out of the favoured groups.
There is another question which has been emphasized by learned counsel for the petitioners is that
the policy of reservation cannot be and should not be intended to be permanent or perpetuate
backwardness.
In a very significant judgment in Grutter v. Bollinger (539 US 306) the US Supreme Court upheld
the law school admission programme because it found "compelling state interest in diversity" in
higher education. Referring to an earlier judgment in Regents of University of California v. Allan
Bakke (438 US265) the US Supreme Court by majority held that the school's interest in obtaining aAshoka Kumar Thakur vs Union Of India And Ors on 29 March, 2007

"critical mass" of minority students was indeed a "tailored use". Majority opinion was to the effect
that race conscious admissions policies must be limited in time and that with the efflux of time the
use of racial preferences would no longer be necessary.
According to South African Constitution the right in the Bill of Rights may be limited so long as the
limitation is "justifiable in an open and democratic society based on human dignity, equality and
freedom". The justifiability of the limitation must be assessed by evaluating the nature of the right,
the nature and extent of the limitation, the importance of the purpose of the limitation, the relation
between the limitation and the purpose and less restrictive means to achieve the purpose.
It remains to be examined as to whether a different form of preferential treatment other than quotas
could be employed as at some stage an affirmative action concept can be focused in this direction
also. Though it is submitted that the number of seats available for the general category is not
affected, but that is really no answer to the broader issue.
If there is possibility of increase in seats in the absence of reservation it could have gone to the
general category. If the stand of learned Additional Solicitor General is accepted that the exercise
was not intended to be undertaken immediately and the increase would be staggered over a period
of 3 years it could not be explained as to why a firm data base could not be evolved first, so that the
exercise could be undertaken thereafter. By increasing the number of seats for the purpose of
reservation unequals are treated as equals. The stand of learned Additional Solicitor General is that
imperfection may be there in the data but so far as the existing modalities are concerned there is no
difficulty in adopting the same.
Another important factor which needs to be noted is the concept of 'Creamy layer".
In M. Nagaraj's case (supra) it was inter-alia held as follows:
"123. However, in this case, as stated above, the main issue concerns the "extent of
reservation". In this regard the State concerned will have to show in each case the
existence of the compelling reasons, namely, backwardness, inadequacy of
representation and overall administrative efficiency before making provisions for
reservation. As stated above, the impugned provision is an enabling provision. The
State is not bound to make reservation for SCs/STs in matters of promotions.
However, if they wish to exercise their discretion and make such provision, the State
has to collect quantifiable data showing backwardness of the class and inadequacy of
representation of that class in public employment in addition to compliance with
Article 335. It is made clear that even if the State has compelling reasons, as stated
above, the State will have to see that its reservation provision does not lead to
excessiveness so as to breach the ceiling limit of 50% or obliterate the creamy layer or
extend the reservation indefinitely."
In Nair Service Society's case (supra) it was noted as follows:Ashoka Kumar Thakur vs Union Of India And Ors on 29 March, 2007

"36. Recently, a Constitution Bench of this Court in M. Nagaraj and Ors. v. Union of
India and Ors. has reaffirmed the importance of the creamy layer principle in the
scheme of equality under the Constitution. This Court held that the creamy layer
principle was on of the important limits on State power under the Equality Clause
enshrined under Articles 14 and 16 and any violation of dilution of the same would
render the State action invalid. More precisely this Court held:
"As stated above, the boundaries of the width of the power, namely, the ceiling-limit
of 5O% (the numerical benchmark), the principle of creamy layer, the compelling
reasons, namely, backwardness, inadequacy of representation and the overall
administrative efficiency are not obliterated by the impugned amendments. At the
appropriate time, we have to consider the law as enacted by various States providing
for reservation if challenged. At that time we have to see whether limitations on the
exercise of power are violated. The State is free to exercise its discretion of providing
for reservation subject to limitation, namely, that there must exist compelling
reasons of backwardness, inadequacy of representation in a class of post(s) keeping
in mind the overall administrative efficiency. It is made clear that even if the State
has reasons to make reservation, as stated above, if the impugned law violates any of
the above substantive limits on the width of the power the same would be liable to be
set aside".
37. This Court reiterated the limit on State power imposed by the creamy layer rule and the
invalidity of any State action in violation of the same by concluding as follows:
"We reiterate that the ceiling-limit of 50%, the concept of creamy layer and the
compelling reasons, namely, backwardness, inadequacy of representation and overall
administrative efficiency are all constitutional requirements without which the
structure of equality of opportunity in Article 16 would collapse. However, in this
case, as stated, the main issue concerns the "extent of reservation". In this regard the
concerned State will have to show in each case the existence of the compelling
reasons, namely, backwardness, inadequacy of representation and overall
administrative efficiency before making provision for reservation. As stated above,
the impugned provision is an enabling provision. The State is not bound to make
reservation for SC/ST in matter of promotions. However if they wish to exercise their
discretion and make such provision, the State has to collect quantifiable data showing
backwardness of the class and inadequacy of representation of that class in public
employment in addition to compliance of Article 335. It is made clear that even if the
State has compelling reasons, as stated above, the State will have to see that its
reservation provision does not lead to excessiveness so as to breach the ceiling-limit
of 50% or obliterate the creamy layer or extend the reservation indefinitely".
38. This Court rationalized the creamy layer rule as a necessary bargain between the competing ends
of caste based reservations and the principle of secularism. The Court opined:Ashoka Kumar Thakur vs Union Of India And Ors on 29 March, 2007

"In Indra Sawhney this Court has, therefore, accepted caste as determinant of
backwardness and yet it has struck a balance with the principle of secularism which is
the basic feature of the Constitution by bringing in the concept of creamy layer".
This Court, thus, has categorically laid down the law that determination of creamy layer is a part of
the constitutional scheme."
It, therefore, needs no reiteration that the creamy layer rule is a necessary bargain between the
competing ends of caste based reservations and the principle of secularism. It is a part of
constitutional scheme. Therefore these cases have to be examined in detail as to whether the stand
of Union of India that creamy layer rule is applicable to only Article 16(4) and not Article 15(5) is
based on any sound foundation. That is more so because the lists relatable to Article 16(4) form the
foundational base for Article 15(5).
In the background of what has been explained above, it would be desirable to keep in hold the
operation of the Act so far as it relates to Section 6 thereof for the OBCs category only. We make it
clear that we are not staying operation of the Statute, particularly, Section 6 so far as the Scheduled
Castes and Scheduled Tribes candidates are concerned. It would be permissible for the respondent-
Union of India to initiate or continue process, if any, for determining on a broad based foundation
"Other Backward Classes" notwithstanding pendency of the cases before this Court and without
prejudice to the issues involved.
The writ petitions be listed in the 3rd week of August, 2007 for final hearing. I.A. is accordingly
disposed of.Ashoka Kumar Thakur vs Union Of India And Ors on 29 March, 2007

