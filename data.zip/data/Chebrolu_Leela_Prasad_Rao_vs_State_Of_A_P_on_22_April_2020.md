Chebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020
Equivalent citations: AIRONLINE 2020 SC 488
Author: Arun Mishra
Bench: Aniruddha Bose, M.R. Shah, Vineet Saran, Indira Banerjee, Arun
Mishra
                                                        1
                                                                                REPORTABLE
                                    IN THE SUPREME COURT OF INDIA
                                     CIVIL APPELLATE JURISDICTION
                                      CIVIL APPEAL NO.3609 OF 2002
         CHEBROLU LEELA PRASAD RAO & ORS.                                 … APPELLANTS
                                                    VERSUS
         STATE OF A.P. & ORS.                                             … RESPONDENTS
                                                      WITH
                                      CIVIL APPEAL NO.7040 OF 2002
                                               JUDGMENT
ARUN MISHRA, J.
1. In the reference, the validity of the Government Office Ms. No.3 dated 10.1.2000 issued by the
erstwhile State of Andhra Pradesh providing 100% reservation to the Scheduled Tribe candidates
out of whom 33.1/3% shall be women for the post of teachers in the schools in the scheduled areas
in the State of Andhra Pradesh, is under challenge.
2. Several questions have been referred for consideration in the order dated 11.1.2016. We have
renumbered question nos.1(a)(b)(c) and (d) based on interconnection. The questions are as follows:
“(1) What is the scope of paragraph 5(1), Schedule V to the Constitution of India?
(a) Does the provision empower the Governor to make a new law?
(b) Does the power extend to subordinate legislation?Chebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

(c) Can the exercise of the power conferred therein override fundamental rights
guaranteed under Part III?
(d) Does the exercise of such power override any parallel exercise of power by the
President under Article 371D?
(2) Whether 100% reservation is permissible under the Constitution?
(3) Whether the notification merely contemplates a classification under Article 16(1)
and not reservation under Article 16(4)?
(4) Whether the conditions of eligibility (i.e., origin and cut-off date) to avail the
benefit of reservation in the notification are reasonable?"
3. The facts in the backdrop project that by G.O.Ms. No.275 dated 5.11.1986, issued by the Governor
in exercise of power under para 5(1) of Schedule V to the Constitution of India, directing the posts of
teachers in educational institutions in the scheduled tribe areas shall be reserved for Scheduled
Tribes only notwithstanding anything contained in any other order or rule or law in force. The
Andhra Pradesh Administrative Tribunal (for short “the tribunal”) quashed the notification by order
dated 25.8.1989. The order was questioned in this Court in C.A. Nos.2305−06/1991, which was
dismissed as withdrawn on 20.3.1998.
4. Another G.O.Ms. No.73 dated 25.4.1987 was issued to amend GOMs. No.275 dated 5.11.1986 to
allow the appointment of non− tribals to hold the posts of teachers in the scheduled areas till such
time the qualified local tribals were not made available. After that, non−tribals who were appointed
as teachers in the scheduled areas filed Writ Petition No.5276/1993 in the High Court of Andhra
Pradesh at Hyderabad against termination of their services. The same was allowed vide judgment
and order dated 5.6.1996 and GOMs. No.73 dated 25.4.1987, and the advertisements were held to be
violative of Article 14 of the Constitution of India. In writ appeal, the order of the Single Bench was
set aside by the Division Bench vide judgment and order dated 20.8.1997. The decision in W.P.
No.16198/1988 thus prevailed. The non−tribal appointees preferred Civil Appeal 6437/1998 before
this Court, which was allowed on 18.12.1998.
5. After this Court rendered the decision on 18.12.1998, the Government issued a fresh notification
vide GOMs. No. 3 dated 10.1.2000 effectively providing for 100% reservation in respect of
appointment to the posts of teachers in the scheduled areas. The tribunal set aside the GOMs.
Aggrieved thereby, writ petitions were filed in the High Court, a 3−Judge Bench by majority upheld
the validity of G.O. Aggrieved by the same, the appeals have been preferred.
6. The majority view opined that historically scheduled areas were treated specially, and affirmative
action taken was in the constitutional spirit. The notification was a step for increasing literacy in the
scheduled areas and also aimed at providing the availability of teachers in every school in the
scheduled areas. 100% reservation can be sustained on the ground that it was based on intelligible
differentia, and the classification has nexus with the object sought to be achieved. The G.O. becameChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

necessary considering the phenomenal absenteeism of the teachers in the schools situated in the
scheduled areas and was a step in aid to promote educational developments of tribals. In
extraordinary situations, reservation can exceed 50%. The Governor possessed the power to issue
the impugned notification under Schedule V, para 5(1) of the Constitution. The same overrides all
other provisions of the Constitution, including Part III of the Constitution of India.
7. The High Court in the minority view opined that providing 100% reservation for Scheduled Tribes
in scheduled areas offends the spirit of Articles 14 and 16 of the Constitution of India. The Governor
is not conferred power to make any law in derogation to Part III or other provisions of the
Constitution of India in the exercise of his power under Clause I, Para 5 of Schedule V. It was also
held that G.O.Ms. No.3 is discriminatory as the same adversely affects not only the open category
candidates but also other Scheduled Castes, Scheduled Tribes, and backward classes. It also opined
that the reservation under Article 16(4) should not exceed 50%. However, little relaxation was
permissible. The rules made under Article 309 of the Constitution could not be treated as an Act of
Parliament or State Legislature.
8. G.O.Ms. No.3 dated 10.1.2000, validity of which is questioned, reserved all posts in the
educational institutions within the scheduled areas in favour of the local Scheduled Tribes. The
order is extracted hereunder:
"Whereas, under sub-paragraph (1) of paragraph 5 of the Fifth Schedule to the
Constitution of India, the Governor of Andhra Pradesh may by public notification
direct that any particular Act of Parliament or of Legislature of the State shall not
apply to the Scheduled Areas or any part thereof in the State or shall apply to a
scheduled area or any part thereof subject to specified exceptions and modifications;
2. AND WHEREAS, in G.O.Ms.No.275, Social Welfare Department dated 5.11.1986, a
notification has been issued exercising the powers conferred under sub-paragraph (1)
of paragraph 5 of the Fifth Schedule to the Constitution of India directing that the
posts of teachers in the Educational Institutions in the Scheduled Areas of State shall
be filled in only by the local members of the Scheduled Tribes;
3. AND WHEREAS, the Andhra Pradesh Administrative Tribunal in its order dated
25.8.1989 in R.P.Nos.6377 and 6379 of 1988 quashed the orders issued in
G.O.Ms.No.275, Social Welfare Department dated 5.11.1986 on the ground that the
notification issued under sub-paragraph (1) of paragraph 5 of the Fifth Scheduled to
the Constitution of India does not reflect the existence of either a State or a Central
Legislation referable for issuing such notification;
4. AND WHEREAS, the Division Bench of the High Court of Andhra Pradesh in its
judgement dated 20-8-1997 in Writ Appeal No.874 of 1997 filed by the Project
Officer, I.T.D.A., Rampachodayaram, East Godavari District, directed to continue the
petitioners respondents in their respective posts of teachers without any break as
temporary employees until replaced by the qualified local tribals as and when suchChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

tribals are available to fill up those posts;
5. AND WHEREAS, the Andhra Pradesh Administrative Tribunal subsequently while
disposing of O.A.No.4598/97 in its order dt.22.9.1997 directed the respondents to
follow the statutory rules while making recruitment to the posts of Secondary Grade
Teachers and also Telugu Pandits, Grade. I in Agency Areas without taking into
consideration of the orders issued in G.O.Ms.No.275, Social Welfare Department,
dated 5.11.1986.
6. AND WHEREAS, the Supreme Court of India while allowing Civil Appeal
No.6437/98 in its order dated 18th December 1998, set aside the orders of the
Andhra Pradesh Administrative Tribunal on the ground that the State withdraw the
appeals arising out of the S.L.P. Nos.14562-63 of 1989:
7. AND WHEREAS, the Government considers that rule 4 (b) of the Andhra Pradesh
School Educational Subordinate Service Rules, 1992 and rule 22A of the Andhra
Pradesh State and Subordinate Service Rules, 1996 shall be modified to the extent
that only Scheduled Tribe Women shall be appointed in Scheduled Areas against 33
1/3% reservation in respect of direct recruitment;
8. AND WHEREAS, the consultation of the Tribes Advisory Council has been made
as required under sub-paragraph (5) of paragraph 5 of the Fifth Schedule to the
constitution of India.
9. AND WHEREAS, the Government of Andhra Pradesh in order to strengthen the
educational infrastructure in the Scheduled Areas, to promote educational
development of Tribals, to solve the phenomenal absenteeism of Teachers in the
Schools situated in Scheduled Areas and with a view to protect the interests of local
tribals have decided to reserve the posts of teachers in favour of local Scheduled
Tribes candidates;
10. AND WHEREAS, the Government considered to re-issue the said orders
retrospectively from 5.11.1986 keeping in view the provisions of sub-paragraph (1) of
paragraph 5 of Fifth Schedule to the Constitution;
11. The following notification will be published in part-IV-B Extraordinary issue of
the Andhra Pradesh Gazette, dated 10.1.2000.
NOTIFICATION In exercise of the power conferred by subparagraph (1) of paragraph 5 of the Fifth
Schedule to the Constitution of India and in Supersession of the notification issued in
G.O.Ms.No.275, Social Welfare Department, dated the 5th November 1986, as subsequently
amended in G.O. Ms. No.73, Social Welfare Department, dated the 25th April 1988, the Governor of
Andhra Pradesh hereby directs that sections 78 and 79 of the Andhra Pradesh Education Act, 1982
(Act 1 of 1982) and sections 169, 195 and 268 of the Andhra Pradesh Panchayat Raj Act, 1994 (Act 13Chebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

of 1994) and rule 4 (a) of the Andhra Pradesh School Educational Subordinate Service Rules issued
in G.O.Ms.No.538 Education (Ser. II) Department, dated the 20th November 1998 and rule 22 and
22A of the Andhra Pradesh State and Subordinate Service Rules, 1996 and any other rules made in
this regard shall apply to the appointment of posts of teachers in schools situated, in the Scheduled
areas in the State subject to the modification that all the posts of teachers in the Schools situated in
Scheduled Areas in the State of Andhra Pradesh shall be filled in by the local Scheduled Tribe
candidates only out of whom 33 1/3% shall women.
EXPLANATION:- For the purpose of this notification, the 'Local Scheduled Tribe Candidate' means,
the candidate belonging to the Scheduled Tribes notified as such under article 342 of the
Constitution of India and the candidates themselves or their parents have been continuously
residing in the scheduled areas of the Districts in which they are residents till to date since the 26th
January 1950."
(emphasis supplied)
9. In the notification various provisions have been mentioned. Section 78 of the A.P. Education Act,
1982 provides for the constitution of educational service. It confers power upon the Governor to
make rules to regulate the classification, methods of recruitment, conditions of service, pay and
allowances and discipline and conduct of the members of the educational service. Section 79 inter
alia deals with dismissal, removal, reduction in rank and suspension of the employees of private
institutions. Section 169 of the A.P. Panchayat Raj Act, 1994 deals with creation of the posts of
officers and employees of the Mandal Parishad, the method of recruitment and conditions of service.
Section 195 of the A.P. Panchayat Raj Act, 1994, provides for creation of posts of officers and
employees of Zilla Parishad, the method of recruitment, conditions of service, etc. Section 268 of the
said Act empowers the Government to make rules.
10. The Andhra Pradesh State and Subordinate Service Rules, 1996 referred to in the notification
were made by the State in exercise of the power conferred under proviso to Article 309 of the
Constitution of India. Rule 22 of the Andhra Pradesh State and Subordinate Service Rules, 1996
provides for reservation. Rule 22 is extracted hereunder:
“Special Representation (Reservation): (1) Reservation may be made for
appointments to a service, class or category in favour of Scheduled Castes, Scheduled
Tribes, Backward Classes, Women, Physically handicapped, Meritorious Sportsman,
Ex- Servicemen and such other categories, as may be prescribed by the Government
from time to time, to the extent and in the manner specified hereinafter in these rules
or as the case may be, in the special rules. The principle of reservation as hereinafter
provided shall apply all appointments to a service, class, or category.
(i) by direct recruitment, except where the Government by a General or Special Order
made in this behalf, exempt such service, class or category;Chebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

(ii) otherwise than by direct recruitment where the special rules lay down specifically
that the principle reservation in so far as it relates to Scheduled Castes and Scheduled
Tribes only shall apply to such services, class, or category to the extent specified
therein.
(2)(a) The unit of appointments for the purpose of this rule shall be one hundred
vacancies, of which, fifteen shall be reserved for scheduled for Scheduled Castes, six
shall be reserved for Scheduled Tribes, twenty-five shall be reserved for the Backward
Classes and the remaining fifty-four appointments shall be made on the basis of open
competition and subject to Rule 22-A of these rules.
(e) Appointments under this rule shall be made in the order of rotation specified
below in a unit of hundred vacancies.
Rule 22-A: Women reservation in appointments: Notwithstanding anything
contained in these rules or special rules or Ad hoc Rules:
(1) In the matter of direct recruitment to posts for which women are better suited
than men, preference shall be given to women:
Provided that such absolute preference to women shall not result in total exclusion of
men in any category of posts.
(2) In the matter of direct recruitment to posts for which women and men are
equality suited, there shall be reservation to women to an extent of 33 1/3 % of the
posts in each category of Open Competition, Backward Classes (Group-A), Backward
Classes (Group-B), Backward Classes (Group-C), Backward Classes (Group-D),
Scheduled Castes, Scheduled Tribes and Physically Handicapped and Ex-Servicemen
quota.
(3) In the matter of direct recruitment to posts which are reserved exclusively for
being filled by women, they shall be filled by women only.” Six per cent reservation
has been provided in the State for Scheduled Tribes.
11. The A.P. Regulation of Reservation and Appointment to Public Services Act, 1997, was enacted to
ensure that the reservation mandated under Rule 22 is followed scrupulously. The Act intended to
punish the officers for violation of the rules of reservation. The Act did not provide any percentage
of the reservation to the Scheduled Castes, Scheduled Tribes, and the backward classes. The
reservations were provided under Rules 22 and 22A of the Rules framed under Article
309. ARGUMENTS
12. It was submitted by Mr. C.S.N. Mohan Rao, Mr. G. Ramakrishna Prasad and Mr. G.V.R.
Choudhary, learned counsel and other learned counsel for the appellants that the limited legislativeChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

power is conferred on the Governor to modify the existing legislation made by the Parliament or the
State legislature under Para 5(1) of the Fifth Schedule to the Constitution. The power to make
regulation was conferred under Para 5(2) of Schedule V. Under Para 5(1), there is no such legislative
power. The earlier G.O.Ms. of 1986 was quashed. After that, the appeal preferred in this Court was
withdrawn, and fresh G.O. was issued, again perpetuating the illegality by providing a 100%
reservation.
13. Learned counsel for the appellants argued that Article 371−D of the Constitution contains special
provisions concerning the State of Andhra Pradesh, which has now been amended for Andhra
Pradesh as well as Telangana. After re−organisation of the States, the Article has been amended in
its application to Andhra Pradesh as well as Telangana. Article 371D was promulgated given the
geographical disparities in the arena of public employment in the State of Andhra Pradesh as
candidates from certain districts were capturing a disproportionately large number of posts, as such
by way of the Presidential Order issued under the said provisions, local cadres were created for
different parts of the State. The Presidential Order provided for reservation on district/zonal basis
for different posts. A district/zone as the case may constitute a local area. A district is a unit for
teachers, and all the posts have been ordered to be filled by scheduled tribe candidates in the
scheduled areas in several districts.
14. Learned counsel for the appellants argued that as per the Presidential Order issued under Article
371D, aspiring candidates could not apply outside the district or zone, as the case may be. Thus, the
incumbents cannot apply outside their districts where they are residing. Their chances of obtaining
public employment as against the posts of teachers have been taken away. Thus, the G.O.
transgresses the Presidential Order issued under Article 371−D of the Constitution as such the same
is unconstitutional and could not prevail.
15. Learned counsel for the appellants further argued that providing 100% reservation is not
permissible because of the catena of decisions rendered by this Court, to be referred later. Learned
counsel vehemently argued that it is an unfortunate reality that the law− makers are resorting to
reservations on political basis catering to vote− bank, thereby ignoring the constitutional mandate to
which they owe allegiance. The reservation so provided is against the wishes of the founding fathers
of the Constitution. The reason employed of chronic absenteeism in the schools, could not have been
made the fulcrum justifying 100% reservation. Merit has been ignored and whittled down. The noble
profession of teaching cannot be demeaned. There cannot be a compromise with the standard of
education in the garb of cent percent reservation, and merit is a casualty. It tantamounts to reverse
discrimination. It cannot be said to be a case of classification, but it is a case of reservation. It is
highly unfair and unreasonable action. The Constitution of India does not permit 100% reservation
in respect of any particular class or category to the total exclusion of others. Reservation set out
under Article 16 should not exceed the limit of 50%.
16. The G.O. would be counter−productive to the aim of the Constitution in providing protective
legislation, and the main thrust of the reservation is to bring in the disadvantaged classes into the
mainstream of the society at large. The idea of the tribal students to be taught by tribal teachers in
the scheduled areas is akin to compromising with the merit and quality of education and further putChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

the tribal children at a disadvantage and segregate them from the mainstream. Regarding the
language barrier, learned counsel argued that qualifications for teachers could be provided that they
should know the local language, a resident of a district invariably knows the local language. In the
impugned notification, no such aspect was mentioned.
17. Learned counsel on behalf of the appellants further argued that Rules 22 and 22A of the Andhra
Pradesh State and Subordinate Service Rules, 1996 provides for reservation framed under proviso to
Article 309 of the Constitution. The legislature did not frame them. Thus, it could not have been
amended or modified by the Governor in exercise of the power under Para 5(1) of Schedule V to the
Constitution being subordinate legislation. That apart, it was argued that no new law could have
been created within the realm of Para 5(1) of Schedule V. The Acts mentioned in G.O.Ms.
No.3/2000 did not deal with reservation. The Act of 1997, provided for the reservation, was not
amended. Even by amending the same, 100% reservation could not have been provided.
18. The classification created within the scheduled tribes to benefit only the candidates or their
parents continuously residing in the scheduled areas since 26.1.1950 is arbitrary, illegal, and
discriminatory vis−à−vis the scheduled tribes also, besides other categories. The executive order
could not have provided the reservation. The legislation was imperative to provide for a 100%
reservation. Testing the case on the anvil of the doctrine of basic structure is not germane as it is not
a case set up that provisions under Para 5 of Schedule V are against the basic structure of the
Constitution. The provisions of Para 5 of Schedule V are not questioned, but only the legality of the
action taken thereunder. The right of judicial review is available in case of any action taken, which is
per se illegal, arbitrary or violative of fundamental rights and sans any basis.
19. Concerning the non−obstante clause, it was argued that the order under Para 5 of Schedule V
could not have been issued in contravention of Article 371D. It contravened the Presidential order.
20. Dr. Rajeev Dhawan, learned senior counsel appearing for the respondents, argued that the
Constitution has a solicitude for scheduled castes and scheduled tribes under various provisions
contained in Articles 15 and 16 and the Directive Principles contained in Articles 37, 38, 47 and
51(A). There are special provisions carved out providing reservation to SCs/ STs; there is National
Commission for Scheduled Tribes, Article 330 provides reservation of seats for SC/ ST in House of
People, Article 332 provides reservation in State Assemblies, Article 335 provides to consider the
claim of SCs/STs to services, Article 338 provides for the constitution of National Commission for
Scheduled Castes and Article 338A provides for the constitution of National Commission for
Scheduled Tribes. Articles 339, 341, 342 and 334, are other provisions relating to SCs/ STs. Articles
343D and 343(T)(h) provide reservation for SC/ST in Panchayats.
21. Learned senior counsel further argued that India's Constitution is symmetrical and spatial for
SCs/STs. In that view, the scheduled areas are constituted under the provisions of Article 244 and
Schedules V and VI. The Constitution creates special classification. Equality is a concept of anti−
arbitrariness. The normal rule of 50% reservation can be relaxed in appropriate cases that have
precisely been done by the Governor. Reservation can be made by executive order. Reservations
cannot be termed to be anti−meritarian. He urged that the reservations were provided due toChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

discrimination, disadvantage, and to share the State power. Elaborately referred to the decision in
Indra Sawhney & Ors. v. Union of India & Ors., (1992) Supp. 3 SCC 217, it was argued that
reservations could be rectified/revised. It is not permissible to sub−divide the SCs and STs. Article
16(4) aims at group backwardness. Strictly speaking, the constitution of a Commission to enquire is
not necessary for providing further reservations, particularly for scheduled tribes in the scheduled
areas. The scope of judicial review is limited in such matters. He referred to various dictums to be
adverted to later.
22. Dr. Rajeev Dhawan, learned senior counsel, lastly argued that G.O.Ms. No.3/2000 is
constitutionally valid, and the Court may, if so advised, issue directions to the States to maintain
oversight. The purposes of Article 371D and Para 5 of Schedule V are entirely different. He further
argued that to trickle down the necessary benefits, the remedy lies in following what is inelegantly
called the "bottoms up" approach. The malady can be addressed by empowering Gram Sabhas,
ensuring the right to information, and strengthening its implementation. Learned senior counsel
alternatively argued that in case this Court concludes that the G.O. is to be quashed, the
appointments made should not be disturbed.
23. Shri R. Venkataramani, learned senior counsel appearing for the State of Andhra Pradesh,
argued that the scheme of Schedule V, as a whole, deserves to be dealt with on a special
constitutional footing, that is an exclusive constitutional enclave, free in its ambit to ensure the
promotion of the interests, concerns and the development of scheduled areas. Paras 2 and 5 of the
Fifth Schedule constitute its essence. Para 2 enacts limitations on the executive power of the State
concerning the scheduled areas. Para 5 is a composite and particular species of the enabling power,
conferring on the Governor, legislative, and administrative powers. The legislative and
administrative powers run seamlessly. For instance, the power under clause (1) of Para 5 to extend a
Central or State legislation to the scheduled area, "subject to exceptions and modifications," confer a
power to amend the legislation. The power under clauses (1) and (2) operates in distinct fields to
achieve distinct purposes, each of them wide in their way. The object to be achieved under clause (1)
is to evaluate and assess the relevance, fitness, or inappropriateness of any law in their application
to scheduled areas, the domain of policy with considerable latitude to bring into force with
modifications and exceptions any law.
24. Shri R. Venkataramani, learned senior counsel further argued that the scheduled areas and the
tribes constitute a special class. This special homogenous class can always be dealt with on a special
basis. The G.O. was not issued to favour the local scheduled tribes or to discriminate against others
intentionally. It was passed to advance the educational interests of the scheduled areas, even if it
otherwise impinges upon the claims under Article 14 or 16(1), cannot be faulted. Even if the G.O.
advances a class interest, it cannot be subjected to scrutiny under Articles 14 and 16(1).
25. Shri R. Venkataramani further argued that there is no conflict between Article 371D and
Schedule V. The two operate in distinct fields and achieve different purposes. The socio−economic
experiments drafted by the legislatures, and in this case by the Governor, cannot be subjected to
judicial scrutiny. It is wrong to suggest that the non− obstante clause in Article 371−D can annul the
non−obstante clause in Para 5 of the Fifth Schedule. Firstly, the two constitutional provisionsChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

operate in distinct domains. Article 371−D was not enacted to be a superimposition on Schedule V.
Secondly, it is well settled that if the object and purpose of legislation or provisions with respective
non−obstante clauses are distinct, the Court would not see any conflict.
26. Shri R. Venkataramani, learned senior counsel, also argued that Schedule V is a complete Code
by itself. It is not a case of reservation at all. It is a classification made to ensure that the schools in
the scheduled areas function and promote the educational interest of the tribal populace. The
Governor took cognizance of the general non− availability of teachers. The notification by
prescribing that the Scheduled Tribe teachers of the local areas should be the exclusive component
of the teaching element was looking at the local scheduled tribe teacher as the best possible tool for
ensuring the educational interest of the scheduled areas. Learned senior counsel has referred to
various decisions, to be adverted later.
27. Learned senior counsel further pointed out that the scheduled area is extended over 31,485 sq.
km. which is about 11% of the total area of the State with more than 5938 villages distributed in
Srikakulam, Vizianagaram, Visakhapatnam, East Godavari, West Godavari, Khammam, Warangal,
Adilabad and Mahaboobnagar Districts. Scheduled Tribe students are at a disadvantageous position.
The non−attendance of teachers was more in the scheduled areas, so to provide the facility of
teaching, classification has been made. It cannot be said to be a case of providing reservations. The
Government of Andhra Pradesh, Department of Tribal Welfare, has established various categories of
educational institutions to cater to the needs of Scheduled Tribes children in the State.
28. Learned senior counsel further submitted that the Government of Andhra Pradesh, Department
of Tribal Welfare, established various categories of educational institutions to cater to the needs of
Scheduled Tribes children in the State, such as Gurukula Pathasalas, Ashram schools, and
residential, educational institutions, and the method of appointment of the local tribe has yielded
good results.
29. Shri B. Adinarayana Rao, learned senior counsel appearing for the State of Telangana, pointed
out the history of scheduled areas Ganjam and Vizagapatnam. The Act of 1839 declared agency areas
of Madras Presidency, providing for separate administration of tribals/agency areas. In 1874, the
Scheduled Districts Act, XIV was passed, which had a schedule in which the territories were
mentioned, inhabited by tribals as such. Rules were issued for administering the areas by the
Governor General−in−Council to the exclusion of ordinary laws. The Government of India Act, 1919,
had made "wholly excluded and partially excluded areas for reform" and kept them under the
administration of Governor General−in−Council, with a separate application of laws. The
Government of India Act, 1935, had extended the same. Thus, historically, the scheduled areas were
governed by special laws. They cannot be compared with areas generally administered by the Act of
legislatures. Special provisions have been made in Schedule V. The order issued by the Governor has
to be treated as legislation. The application of laws is one of the recognised forms of legislation. The
order of Governor can only be tested on the parameters of competence and violation of the
Constitution. It cannot be tested on the touchstone of ideal norms. It achieves the purpose of Article
46 of the Constitution.Chebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

30. Shri B. Adinarayana Rao, learned senior counsel, has further argued that forests or hills separate
scheduled areas from other areas. Notified tribes inhabit them. There are some non−tribals in the
scheduled areas. In spite of their stay/residence, the non−tribals cannot acquire by sale, purchase,
lease, or otherwise, the lands in the scheduled areas and legislations imposing such restrictions have
been held to be constitutional by this Court in various decisions. The tribal customs, culture,
traditions, and personal laws need to be protected and preserved. They speak their dialect in their
habitations. Due to inaccessibility and lack of facilities, the teachers appointed in scheduled areas
are not attending the schools, leading to chronic absenteeism. The experiment has resulted in
fulfilling the desired objectives. There has been a significant increase in literacy among tribals.
There is no repugnancy with the Presidential Order issued under Article 371D. Article 371D(10)
provides for the non−obstante clause to make the provisions immune from challenge under Articles
14 and 16 of the Constitution of India. The provisions made in Para 5 of Schedule V have to be
viewed on a similar anvil.
31. Shri Shivam Singh, learned counsel appearing on behalf of some of the respondents, argued that
the basic structure doctrine is inapplicable, the original constitutional text must not be employed to
test the impugned action. Schedule V under Article 244(1) of the Constitution is part of the original
text. Hence, it must not be tested on the touchstone of the basic structure violation. He argued by
referring to the decisions of this Court that the constitutional amendments post−1973 can be struck
down if they violate the basic structure doctrine and not the original text of the Constitution. The
non−obstante clause in Para 5(1) Schedule V continues to hold and occupy the field. The rigours of
the basic structure doctrine may hit Article 371−D but cannot affect Schedule V. Article 14 cannot be
used to defeat intendment of the non−obstante clause of Schedule V.
32. Shri Shivam Singh, learned counsel, further argued that in case of conflict between non−
obstante clauses, as far as possible, they must be harmoniously construed. The provision enacted
later prevails over the one enacted earlier. If the latter provision is found to be generic as against the
earlier provision, then the earlier provision has to prevail.
33. Learned counsel has further canvassed that as the Governor has the power to frame the
regulations, the power extends to subordinate legislation also. Subordinate legislation has to be
treated as part of the legislation itself. Regulations must be treated as part of the statute itself. In the
power to modify and create exceptions in exceptional circumstances to provide a 100% reservation
is permissible. There is minimal scope for judicial review. The notification contemplated a
classification under Article 16(1) not a reservation under Article 16(4) issued to provide impetus to
scheduled areas in the field of education; to strengthen educational infrastructure, to promote the
educational development of tribals; to prevent phenomenal absenteeism of teachers in the schools
in the scheduled areas from teaching tribals. The conditions of eligibility and cut−off date to avail
the benefit of reservation are reasonable to further strengthen the educational infrastructure
development and other problems faced in the area. In Re: Question No.1: What is the scope of Para
5(1) of Schedule V of the Constitution of India?; and Question No.1(a): Does the provision empower
the Governor to make a new law?Chebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

34. The Fifth Schedule finds reference in Article 244 of the Constitution of India. Article 244 deals
with the administration of scheduled areas and tribal areas. It is provided that the provisions of
Schedule V shall apply to the administration of scheduled areas. Article 244 is extracted hereunder:
“Article 244. Administration of Scheduled Areas and Tribal Areas.— (1) The
provisions of the Fifth Schedule shall apply to the administration and control of the
Scheduled Areas and Scheduled Tribes in any State other than the States of Assam
Meghalaya, Tripura, and Mizoram.
(2) The provisions of the Sixth Schedule shall apply to the administration of the tribal
areas in the State of Assam, Meghalaya, Tripura and Mizoram."
35. Article 244 excludes Assam, Meghalaya, Tripura, and Mizoram from Schedule V, and they are
included as per Article 244(2) in Schedule VI. Schedule V in extenso is extracted hereunder:
“FIFTH SCHEDULE [Article 244(1)] PROVISIONS AS TO THE ADMINISTRATION
AND CONTROL OF SCHEDULED AREAS AND SCHEDULED TRIBES PART A
GENERAL “1. Interpretation.—In this Schedule, unless the context otherwise
requires, the expression ‘State’ does not include the States of Assam, Meghalaya,
Tripura, and Mizoram.
2. Executive power of a State in Scheduled Areas.— Subject to the provisions of this
Schedule, the executive power of a State extends to the Scheduled Areas therein.
3. Report by the Governor to the President regarding the administration of Scheduled
Areas.—The Governor of each State having Scheduled Areas therein shall annually, or
whenever so required by the President, make a report to the President regarding the
administration of the Scheduled Areas in that State and the executive power of the
Union shall extend to the giving of directions to the State as to the administration of
the said areas.
PART B ADMINISTRATION AND CONTROL OF SCHEDULED AREAS AND SCHEDULED
TRIBES
4. Tribes Advisory Council.—(1) There shall be established in each State having Scheduled Areas
therein and, if the President so directs, also in any State having Scheduled Tribes but not Scheduled
Areas therein, a Tribes Advisory Council consisting of not more than twenty members of whom, as
nearly as may be, three-fourths shall be the representatives of the Scheduled Tribes in the
Legislative Assembly of the State:
Provided that if the number of representatives of the Scheduled Tribes in the
Legislative Assembly of the State is less than the number of seats in the Tribes
Advisory Council to be filled by such representatives, the remaining seats shall be
filled by other members of those tribes.Chebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

(2) It shall be the duty of the Tribes Advisory Council to advise on such matters
pertaining to the welfare and advancement of the Scheduled Tribes in the State as
may be referred to them by the Governor.
(3) The Governor may make rules prescribing or regulating, as the case may be,
(a) the number of members of the Council, the mode of their appointment and the
appointment of the Chairman of the Council and of the officers and servants thereof;
(b) the conduct of its meetings and its procedure in general; and
(c) all other incidental matters.
5. Law applicable to Scheduled Areas.—(1) Notwithstanding anything in this Constitution, the
Governor may by public notification direct that any particular Act of Parliament or of the Legislature
of the State shall not apply to a Scheduled Area or any part thereof in the State or shall apply to a
Scheduled Area or any part thereof in the State subject to such exceptions and modifications as he
may specify in the notification and any direction given under this sub-paragraph may be given so as
to have retrospective effect.
(2) The Governor may make regulations for the peace and good government of any area in a State
which is for the time being a Scheduled Area.
In particular and without prejudice to the generality of the foregoing power, such regulations may—
(a) prohibit or restrict the transfer of land by or among members of the Scheduled Tribes in such
area;
(b) regulate the allotment of land to members of the Scheduled Tribes in such area;
(c) regulate the carrying on of business as money-lender by persons who lend money to members of
the Scheduled Tribes in such area.
(3) In making any such regulation as is referred to in sub- paragraph (2) of this paragraph, the
Governor may repeal or amend any Act of Parliament or of the Legislature of the State or any
existing law which is for the time being applicable to the area in question.
(4) All regulations made under this paragraph shall be submitted forthwith to the President and,
until assented to by him, shall have no effect.
(5) No regulation shall be made under this paragraph unless the Governor making the regulation
has, in the case where there is a Tribes Advisory Council for the State, consulted such Council.
PART C SCHEDULED AREASChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

6. Scheduled Areas.—(1) In this Constitution, the expression ‘Scheduled Areas’ means such areas as
the President may by order declare to be Scheduled Areas.
(2) The President may at any time by order—
(a) direct that the whole or any specified part of a Scheduled Area shall cease to be a Scheduled Area
or a part of such an area;
(aa) increase the area of any Scheduled Area in a State after consultation with the Governor of that
State;]
(b) alter, but only by way of rectification of boundaries, any Scheduled Area;
(c) on any alteration of the boundaries of a State or on the admission into the Union or the
establishment of a new State, declare any territory not previously included in any State to be, or to
form part of, a Scheduled Area;
(d) rescind, in relation to any State or States, any order or orders made under this paragraph, and in
consultation with the Governor of the State concerned, make fresh orders redefining the areas which
are to be Scheduled Areas, and any such order may contain such incidental and consequential
provisions as appear to the President to be necessary and proper, but save as aforesaid, the order
made under sub-paragraph (1) of this paragraph shall not be varied by any subsequent order.
PART D AMENDMENT OF THE SCHEDULE
7. Amendment of the Schedule.—(1) Parliament may from time to time by law amend by way of
addition, variation or repeal any of the provisions of this Schedule and, when the Schedule is so
amended, any reference to this Schedule in this Constitution shall be construed as a reference to
such Schedule as so amended.
(2) No such law as is mentioned in sub-paragraph (1) of this paragraph shall be deemed to be an
amendment of this Constitution for the purposes of article 368.”
36. The State can exercise executive power in scheduled areas. However, the same is subject to the
provisions of the Schedule. Para 3 of Schedule V provides for the continuous interplay between the
Governor and the President. The Governor has to send an Annual Report or at any time whenever so
required by the President. The Governor is bound to report to the President regarding the
administration of the scheduled areas, and in the exercise of executive power, the Union
Government can issue directions to State as to the administration of the scheduled areas.
37. The object of para 5 of Schedule V is to establish an egalitarian society and to ensure socio−
economic empowerment to the Scheduled Tribes as held in Samatha v. State of A.P. & Ors., (1997) 8
SCC 191 thus:Chebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

“71. Thus, the Fifth and Sixth Schedules, an integral scheme of the Constitution with
direction, philosophy and anxiety is to protect the tribals from exploitation and to
preserve valuable endowment of their land for their economic empowerment to
elongate social and economic democracy with liberty, equality, fraternity and dignity
of their person in our political Bharat.”
38. Para 4 of Schedule V to the Constitution of India provides for the formation of Tribes Advisory
Council for administration and control of the scheduled areas and scheduled tribes. Para 4(2)
enables the Advisory Council to advise on such matters pertaining to the welfare and advancement
of the scheduled tribes in the State as may be referred to them by the Governor. The Governor has
the power to make rules, regulations as to the number of members of the Tribes Advisory Council,
the mode of their appointment, conduct of meetings, and other incidental matters.
39. Para 5 of Schedule V deals with the law applicable to the scheduled areas. It contains a non−
obstante clause and authorises the Governor to issue a notification to the effect that any particular
Act of the Parliament or of the State Legislature shall not apply to a scheduled area or any part
thereof. It also empowers the Governor to create exceptions and modifications as he may specify in
the notification concerning the applicability of such Act of Parliament or legislature of the State. The
Governor is empowered to issue notification giving it retrospective effect. It is apparent that the law
contained in the Act can be modified by the Governor or can be excluded in its application from the
scheduled area or any part of it. Thereupon such Act, hence, of the Parliament or the State
Legislature can be applied with exceptions and modifications to the scheduled area. Para 5(1)
confers power upon the Governor not concerning the only exclusion of Act of Parliament or the
State but to modify or create exceptions.
(a) Para 5(1) of Schedule V does not confer upon Governor power to enact a law but to direct that a
particular Act of Parliament or the State Legislature shall not apply to a scheduled area or any part
thereof or shall apply with exceptions and modifications, as may be specified in the notification. The
Governor is not authorised to enact a new Act under the provisions contained in para 5(1) of
Schedule V of the Constitution. Area reserved for the Governor under the provisions of para 5(1) is
prescribed. He cannot act beyond its purview and has to exercise power within the four corners of
the provisions.
(b) Para 5(2) of Schedule V deals with the power of the Governor to make regulations for the peace
and good government in a scheduled area of a State. The Governor has to obtain the advice of the
Tribes Advisory Council in the matters pertaining to Para 5(2), if it has been constituted. The
Governor is expressly authorised to prohibit or restrict the transfer of land by any member of
scheduled tribes and also regulate the allotment of land to the members of the Scheduled Tribes in
the Scheduled Areas. Para 5(3) provides that while making any such regulations as mentioned in
Para 5(2), the Governor has the power to repeal or amend any Act of Parliament or the legislature of
the State or any existing law which is for the time being applicable to the area in question, but that is
for peace and good governance of the scheduled area. The regulation made by the Governor to be
effective is required to be assented by the President. Prior assent of the President is mandatory for
regulation to be put into effect. There is a further rider on the regulatory power of the GovernorChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

provided by Para 5(5). In case Tribes Advisory Council has been constituted before making any
regulation, the Governor is duty−bound to consult such Council. No regulation can be made without
consultation with the Council in case it has been formed.
40. The Act of Parliament or the appropriate legislature applies to the scheduled areas. The
Governor has the power to exclude their operation by a notification. In the absence thereof, the Acts
of the legislature shall extend to such areas. In Jatindra v. Province of Bihar, (1949) FLJ 225, it was
held that the power of the Governor under para 5 is a legislative power and Governor is empowered
to change or modify the provisions of the Act or the section as he deems fit by way of issuing a
notification. The power under para 5(1) is limited to the application of the Governor's decision to
apply an Act or making modification or creating exceptions. Though the power is legislative to some
extent, that is confined to applicability, modification, or creating exceptions concerning the Act of
the Parliament or the State. While para 5(2) confers the power of independent legislation, the
Governor has plenary power of framing regulations for the peace and good governance of a
scheduled area. He is the repository of faith to decide as to the necessity. The Governor is
empowered by para 5(3) to repeal or amend any Act of Parliament or State Legislature, following the
procedure prescribed therein, in exercise of making regulations as provided under para 5(2) of
Schedule V. The aspect of power was considered in Ram Kirpal Bhagat and Ors. v. The State of
Bihar, (1969) 3 SCC 471 thus:
“21. The second question which falls for consideration is whether the Bihar
Regulation I of 1951 is in excess of the Governor’s powers. The contentions were:
first, that the Regulation I of 1951 could not at all have been made; secondly, that
Regulations deal with the subject-matter and did not mean power to apply law and
thirdly, the power to extend a law passed by another legislature was said to be not a
legislative function, but was a conditional legislature. The legislation, in the present
case, is in relation to what is described as Scheduled Areas. The Scheduled Areas are
dealt with by Article 244 of the Constitution and the Fifth Schedule to the
Constitution. Prior to the Constitution, the excluded areas were dealt with by
Sections 91 and 92 of the Government of India Act, 1935. The excluded and the
partially excluded areas were areas so declared by order in Council under Section 91
and under Section 92. No act of the Federal Legislature or of the Provincial
Legislature was to apply to an excluded or a partially excluded area unless the
Governor by public notification so directed. Sub-section (2) of Section 92 of the
Government of India Act, 1935 conferred power on the Governor to make regulations
for the peace and good government of any area in a Province which was an excluded
or a partially excluded area and any regulations so made might repeal or amend any
Act of the Federal Legislature or the Provincial Legislature or any existing Indian law
which was for the time being applicable to the area in question. The extent of the
legislative power of the Governor under Section 92 of the Government of India Act,
1935 in making regulations for the peace and good government of any area conferred
on the Governor in the words of Lord Halsbury "an utmost discretion of enactment
for the attainment of the objects pointed to." (See Riel v. Queen, LR 10 AC 657 at
658)). In that case the words which fell for consideration by the Judicial CommitteeChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

were “the power of the Parliament of Canada to make provisions for the
administration, peace, order and good government of any territory not for the time
being included in any province”. It was contended that if any legislation differed from
the provisions which in England had been made for the administration, peace, order
and good government then the same could not be sustained as valid. That contention
was not accepted. These words were held to embrace the widest power to legislate for
the peace and good government for the area in question.
22. The Fifth Schedule to the Constitution consists of 7 paras and consists of Parts A,
B, C and D. Para 6 in Part C deals with Scheduled Areas as the President may by
order declare and there is no dispute in the present case that the Santhal Parganas
falls within the Scheduled Areas. Para 5 in the Fifth Schedule deals with laws
applicable to Scheduled Areas. Sub-para 2 of para 5 enacts that the Governor may
make regulations for the peace and good government of any area in a State which is
for the time being a Scheduled Area. Under sub-para 3 of para 5, the Governor may
repeal or amend any Act of Parliament or of the legislature of the State or any
existing law which is for the time being applicable to the area in question. It may be
stated that a contention was advanced by counsel for the appellants that Section 92 of
the Government of India Act, 1935 was still in operation and the Governor could only
act under that section.
This contention is utterly devoid of any substance because Section 92 of the Government of India
Act, 1935 ceased to exist after repeal of the Government of India Act, 1935 by Article 395 of the
Constitution. It was contended that the power to make regulations did not confer power on the
Governor to apply any law. It was said that under Section 92 of the Government of India Act, 1935
the Governor could do so but under the Fifth Schedule of the Constitution the Governor is not
competent to apply laws. This argument is without any merit for the simple reason that the power to
make regulations embraces the utmost power to make laws and to apply laws. Applying law to an
area is making regulations which are laws. Further the power to apply laws is inherent when there is
a power to repeal or amend any Act, or any existing law applicable to the area in question. The
power to apply laws is really to bring into legal effect sections of an Act as if the same Act had been
enacted in its entirety. Application of laws is one of the recognised forms of legislation. Law can be
made by referring to a statute or by citing a statute or by incorporating a statute or provisions or
parts thereof in a piece of legislation as the law which shall apply.
23. It was said by Counsel for the appellants that the power to apply laws under the Fifth Schedule
was synonymous with conditional legislation. In the present case, it cannot be said that the Bihar
Regulation I of 1951 is either a piece of delegated legislation or a conditional legislation. The
Governor had full power to make regulations which are laws and just as Parliament can enact that a
piece of legislation will apply to a particular State, similarly, the Governor under para 5 of the Fifth
Schedule can apply specified laws to a Scheduled area. The Bihar Regulation I of 1951 is an instance
of a valid piece of legislation emanating from the legislative authority in its plenitude of power and
there is no aspect of delegated or conditional legislation.” (emphasis supplied)Chebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

41. In Hota Venkata Surya Sivarama Sastry and Anr. v. State of Andhra Pradesh, (1962) 2 SCR 535:
AIR 1967 SC 71, the question came up for consideration as to the power to apply the laws under para
5(2). This Court opined that the power to repeal or amend is legislative, and the regulations made in
exercise of this power, cannot be said to be delegated or conditional legislation. This Court held:
“(11) It was next contended that Regulation IV of 1951 was invalid as having
outstepped the limits of the legislation permitted by Paras 5(1) and (2) of the Fifth
Schedule to the Constitution. It was said that if the Governor desired to enact a law
with retrospective effect it must be a law fashioned by himself, but that if he applied
to the Scheduled areas a law already in force in the State, he could not do so with
retrospective effect. Reduced to simple terms, the contention merely amounts to this
that the Governor should have repeated in this Regulation the terms of the Abolition
Act but that if he referred merely to the title of the Act he could not give retrospective
effect to its provisions over the area to which it was being applied. It is obvious that
this contention was correctly negatived by the High Court.”
42. Reliance has been placed on the decision in Edwingson Bareh v. State of Assam and Ors., (1966)
2 SCR 770 in which the validity of the notification issued on 23.11.1964 was in question. By the
notification, the Governor of Assam was pleased to create a new Autonomous District to be called
the Jowai District by excluding the Jowai Sub−Division of the United Khasi−Jaintia Hills District
with effect from 1.12.1964 and altered the boundaries. The notification was issued by the Governor
in the exercise of powers conferred on him by paragraph 1(3) of the Sixth Schedule. This Court
observed:
“It cannot, however, be disputed that as a result of the modification made by the
impugned notification, paragraph 20(2) has to be changed. Paragraph 20(2), as it
originally stood, describes in detail the territories comprised in the United Khasi-
Jaintia Hills District, and as a result of the impugned notification, the said
description will have to be modified, because the said District has now been split up
into two Autonomous District. That, however, is a change consequent upon the
change made by the Governor by issuing the impugned notification in exercise of the
powers conferred on him by para 1(3). In our opinion, where the Governor makes
changes by virtue of the powers conferred on him by para. 1(3) (c), (d), (e), (f) and
(g), what follows is a change in the internal composition of the different items in Part
A of the table. The exercise of the said powers does not change, and in the present
case it has not changed, the total area comprised in Part A. What it purports to do is
to change one item into two items of Autonomous Districts. Since the power to bring
about this change is expressly conferred on the Governor by paragraph 1(3)(c), (d),
(e), (f) and (g), it is not unreasonable to hold that the exercise of the said power
should, as in the present case, lead to a consequential change in para 20(2). Such a
change in para 20(2) is a logical corollary of the exercise of the power conferred on
the Governor by para 1(3)(c), (d), (e), (f) and (g).”Chebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

43. In Samatha v. State of A.P. & Ors., (1997) 8 SCC 191, this Court held that the executive power
under Article 298 and legislative power under Article 245 to dispose of Government property are
subject to Para 5 of Schedule V. The relevant portion is extracted hereunder:
“85. It is true, as contended by Shri Choudhary, that the Constitution has demarcated
legislative, executive and judicial powers and entrusted them to the three wings of the
State; in particular the President/Governor of the State is to exercise the executive
power in their individual discretion. It is not subject to legislative limitations to be
done in accordance with rules of business. In particular, the President/Governor is
entrusted with the executive power coextensive with the legislative power
enumerated in the Seventh Schedule read with Article 245 of the Constitution. The
executive power especially conferred by the Constitution like the pleasure tenure or
the power of pardoning a convict are in our view, not apposite to the issue. The power
of the executive Government in that behalf has wisely been devised in the
Constitution and is not subject to any restriction except in accordance with the
Constitution and the law made under Article 245 read with the relevant entry in the
Seventh Schedule to the Constitution subject to the Fifth Schedule when it is applied
to Scheduled Area. The power of the Government to acquire, hold and dispose of the
property and the making of contracts for any purpose conferred by Article 298 of the
Constitution equally is coextensive with the legislative power of the Union/State.
However, Article 244(1) itself specifies that provisions of the Fifth Schedule shall apply to the
administration and control of the Scheduled Areas and Scheduled Tribes in any State except the
excluded areas specified therein. The legislative power in clause (1) of Article 245 equally is “subject
to the provisions of the Constitution” i.e. Fifth Schedule. Clause (1) of para 5 of Part B of the Fifth
Schedule applicable to Scheduled Areas, adumbrates with a non obstante clause that:
“Notwithstanding anything in the Constitution, in other words, despite the power, under Article
298, the Governor may, by public notification direct that any particular Act of Parliament or of the
legislature of a State shall not apply to a Scheduled Area or any part thereof in the State or shall
apply to a Scheduled Area or any part thereof in the State, subject to such exceptions and
modifications as he may specify in the notification and any direction given under clause (1) of para
5, may be given so as to have retrospective effect.” The executive power of the State is, therefore,
subject to the legislative power under clause 5(1) of the Fifth Schedule. Similarly, sub-para (2)
thereof empowers the Governor to make Regulations for the peace and good government of any area
in a State which is for the time being a Scheduled Area. In particular and without prejudice to the
generality of the foregoing power, such Regulations may regulate the allotment of land to members
of the Scheduled Tribes in such area or may prohibit or restrict the transfer of land under clause (a)
by or among the members of the Scheduled Tribes in such areas. In other words sub-para 5(2)
combines both legislative as well as executive power, clause 5(2)
(a) and (c) legislative power and clause (b) combines both legislative as well as executive power. The
word “regulation” in para 5(2)(b) is thus of wide import.” (emphasis supplied) In Samatha (supra),
it was held that mining leases could not have been granted to non−tribals in the Scheduled Areas
even concerning land belonging to the Government. This Court in the aforesaid decision dealt withChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

the prohibition on the transfer of immovable property situated in Agency tracts by a person,
whether or not such person is a member of Scheduled Tribes or a society composed solely of the
members of the Scheduled Tribes or by a person including inter alia State Government or State
Corporations. Transfer of Government land in Agency tracts by granting mining lease in favour of
non−tribal persons was null and void. In the said case, the tribals were granted patta in their favour
for cultivation purposes, the said aspect made the entire difference, and the prohibition on lease
came in the way of non−tribal, which was upheld by this Court. The decision is to operate in a
different area. This Court upheld a similar restriction in Rajasthan Housing Board v. New Pink City
Nirman Sahkari Samiti Ltd. and Anr., (2015) 7 SCC 601.
44. There is no dispute with the abovesaid proposition concerning the protection of the transfer of
land. Such provisions have been carved out, and they have been held to be constitutionally valid.
More or less, similar provisions exist virtually in all the States. In various States, transactions that
took place relating to land of Scheduled Tribes were statutorily annulled including decree or order of
the court, and such transactions have been declared to be void with retrospective effect and validity
of the same was upheld by this Court. But the question here is not of the protection of the land. The
idea behind protection of land is to protect tribals, as they are isolated, and in disadvantageous
position socially as compared to non−tribals. Thus, protection has been conferred.
45. In re Art. 143 of the Constitution of India and Delhi Laws Act (1912) etc., AIR 1951 SC 332, the
Court considered the word ‘modify’ to mean alteration without radical transformation in the context
in which modification was used, it did not involve any material alteration or substantial alteration.
However, in the context of Article 370(1) of the Constitution of India in Puranlal Lakhanpal v.
President of India & Ors., AIR 1961 SC 1519, the power is given to the President to efface effect of
any provision of law altogether in its application to the State of Jammu & Kashmir. The Court
observed that power to modify should be considered in its widest possible amplitude. This Court
further considered the word ‘modify’ in the Oxford English Dictionary, Vol. VI, to mean inter alia "to
make partial changes in"; to change (as object) in respect of some of its qualities; to alter or vary
without radical transformation”. Similar is the word 'modification,' which means the action of
making changes in an object without altering essential nature. The Court also observed that modify
just means to alter or vary, extend, or enlarge thus:
“(4) But even assuming that the introduction of indirect election by this modification
is a radical alteration of the provisions of Art. 81(1), the question still remains
whether such a modification is justified by the word “modification” as used in Art.
370(1). We are here dealing with the provision of a Constitution which cannot be
interpreted in any narrow or pedantic sense. The question that came for
consideration in In re Delhi Laws Act case, 1951 SCR 747: (AIR 1951 SC 332), was
with respect to the power of delegation to a subordinate authority in making
subordinate legislation. It was in that context that the observations were made that
the intention of the law there under consideration when it used the word
“modification” was that the Central Government would extend certain laws to Part C
States without any radical alteration in them. But in the present case we have to find
out the meaning of the word “modification” used in Art. 370(1) in the context of theChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

Constitution. As we have said already the object behind enacting Art. 370(1) was to
recognise the special position of the State of Jammu and Kashmir and to provide for
that special position by giving power to the President to apply the provisions of the
Constitution to that State with such exceptions and modifications as the President
might by order specify. We have already pointed out that the power to make
exceptions implies that the President can provide that a particular provision of the
Constitution would not apply to that State. If therefore the power is given to the
President to efface in effect any provision of the Constitution altogether in its
application to the State of Jammu and Kashmir, it seems that when he is also given
the power to make modifications that power should be considered in its widest
possible amplitude. If he could efface a particular provision of the Constitution
altogether in its application to the State of Jammu and Kashmir, we see no reason to
think that the Constitution did not intend that he should have the power to amend a
particular provision in its application to the State of Jammu and Kashmir. It seems to
us that when the Constitution used the word “modification” in Art. 370(1) the
intention was that the President would have the power to amend the provisions of the
Constitution if he so thought fit in their application to the State of Jammu and
Kashmir. In the Oxford English Dictionary (Vol. VI) the word “modify” means inter
alia “to make partial changes in; to change (as object) in respect of some of its
qualities; to alter or vary without radical transformation”. Similarly the word
“modification” means “the action of making changes in an object without altering its
essential nature or character; the state of being thus changed; partial alteration”.
Stress is being placed on the meaning “to alter or vary without radical
transformation” on behalf of the petitioner; but that is not the only meaning of the
words “modify” or “modification”. The word “modify” also means “to make partial
changes in” and “modification” means “partial alteration”. If therefore the President
changed the method of direct election to indirect election he was in essence making a
partial change or partial alteration in Art. 81 and therefore the modification made in
the present case would be even within the dictionary meaning of that word. But, in
law, the word “modify” has even a wider meaning. In “Words and Phrases” by Roland
Burrows, the primary meaning of the word “modify” is given as “to limit” or “restrict”
but it also means “to vary” and may even mean to “extend” or “enlarge”. Thus in law
the word “modify” may just mean “vary” i.e. amend; and when Art. 370(1) says that
the President may apply the provisions of the Constitution to the State of Jammu and
Kashmir with such modifications as he may by order specify it means that he may
vary (i.e. amend) the provisions of the Constitution in its application to the State of
Jammu and Kashmir. We are therefore of opinion that in the context of the
Constitution we must give the widest effect to the meaning of the word “modification”
used in Art. 370(1) and in that sense it includes an amendment. There is no reason to
limit the word “modifications” as used in Art. 370(1) only to such modifications as do
not make any “radical transformation”. We are therefore of opinion that the
President had the power to make the modification which he did in Art. 81 of the
Constitution. The petition therefore fails and is hereby dismissed with costs.” The
Governor is conferred the power to modify or create exceptions, is not in dispute. TheChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

power is wide but is confined to the Acts of the Parliament or the State legislature.
The power of the Governor is not only extensive but also sui generis, and as the court
has to defer to legislative wisdom in areas of social and economic experimentation, it
also defers to the wisdom of the Governor in the exercise of his power under Para 5 of
the Fifth Schedule.
46. In Bombay Dyeing & Mfg. Co. Ltd. (3) v. Bombay Environmental Action Group & Ors., (2006) 3
SCC 434, the Court referred to the decision in Puranlal Lakhanpal (supra) and observed:
“243. Yet again in Puranlal Lakhanpal v. President of India, (1962) 1 SCR 688, it was
stated: (SCR p. 693) “[T]he word ‘modification’ means ‘the action of making changes
in an object without altering its essential nature or character …’.”
47. In Puranlal (supra), the Court observed that modification in Article 370(1) must be given the
widest effect in the context of the Constitution, and in that sense, it cannot include such limitations
as do not make any radical transformation. In S.K. Gupta & Anr. v. K.P. Jain & Anr., (1979) 3 SCC
54, the term “modification” came up for consideration. The Court held that it would include the
making of additions and omissions. In the context of Section 392, “modification” would mean
addition to the scheme of compromise and/or arrangement or omission therefrom solely to make it
workable. The court observed thus:
“26. According to the definition, "modify" and "modification" would include the
making of additions and omissions. In the context of Section 392, "modification"
would mean addition to the scheme of compromise and/ or arrangement or omission
therefrom solely for the purpose of making it workable. Reading Section 392 by
substituting the definition of the word "modification" in its place, if something can be
omitted or something can be added to a scheme of compromise by the Court on its
own motion or on the application of a person interested in the affairs of the company
for the proper working of the compromise and/or arrangement, we see no
justification for cutting down its meaning by a process of interpretation and thereby
whittle down the power of the Court to deal with the scheme of a compromise and/or
arrangement for the purpose of making it workable in course of its continued
supervision as ordained by Section 392(1)."
48. Para 5(1) of Schedule V to the Constitution confers power upon the Governor to exclude law,
which is applicable in a scheduled area. It also empowers the Governor to apply the same with
exceptions and modifications as he deems fit. However, the power to exclude an area from
applicability, modification, and to create exceptions in the law, which was applicable in the area,
cannot be said to be at par to the regulation−making power conferred under para 5(2) of the said
Rules. Meaning of the expressions ‘exception’ and ‘modification’ is as follows :
“exception  n. a person or thing that is excepted or that does not follow a rule.  the
action or state of excepting or being excepted.” “modification  n. the action of
modifying.  a change made.” (Source: Concise Oxford English Dictionary, 10th Edn.Chebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

Revised)
49. The exceptions and modifications are created by the law, which is already applicable in the area.
It is not the formulation of a new law which is contemplated under Para 5(1) of Schedule V. No new
law can be formulated while exercising power under Para 5(1) of Schedule V. The power of
modification cannot extend to re−writing the entire statute. The power cannot be used to supplant
the law, which is applicable. The law has to be applied only with exceptions or modifications. It
cannot totally supersede the existing law, which is wholly opposed to the idea of applicable law as in
that case it would tantamount to the new law and not the modification or exception or creation of
exceptions or modifications to the applicable law. The object and substance of law applicable cannot
be changed within the purview of Para 5(1), though the applicability of applicable law can be
excluded. In case the Governor decides the law to remain applicable, he has the power only to create
exceptions and to modify the same, not to create a new one juxtaposed to the same applicable law.
50. The A.P. Regulation of Reservation and Appointment to Public Services Act, 1997, deals with
reservation in the State in the field of public services. G.O. Ms. No.3 of 2000 did not amend the said
Act. The provisions of the other Acts mentioned in the notification did not deal with the extent of
reservation. Sections 78 and 79 of the A.P. Education Act, 1982 and Sections 169, 195, and 268 of
the A.P. Panchayati Raj Act, 1994, are not related to reservation. The rules were framed under the
proviso to Article 309. They were not framed under the main provision by the legislature. The
Governor in the exercise of power under Para 5(1) of Schedule V could have amended the Public
Services Act, 1997, or direct it not to apply to Scheduled Areas. The creation of 100 per cent
reservation had the effect of making a new law under Para 5(1) without reference to the Act of State
or Central legislation. Independently of that power could not be exercised within the purview of Para
5(1) of Schedule V to the Constitution of India. Even otherwise, even if the Act of 1997 would have
been modified by the Governor, 100% reservation could not have been provided.
51. We are of the opinion that the Governor's power to make new law is not available in view of the
clear language of Para 5(1), Fifth Schedule does not recognise or confer such power, but only power
is not to apply the law or to apply it with exceptions or modifications. Thus, notification is ultra vires
to Para 5(1) of Schedule V of the Constitution.
In Re: Question No.1(b): Does the power extend to subordinate legislation?
52. G.O. Ms. No.3/2000 refers to various provisions and Sections 78 and 79 of the A.P. Education
Act, 1982. There is also reference to sections 169, 195, and 268 of the A.P. Panchayat Raj Act, 1994.
None of the aforesaid provisions deals with reservation of posts. The third reference is about the
A.P. State and Subordinate Service Rules, 1996, which were framed in exercise of the powers
conferred by the proviso of Article 309 of the Constitution of India. Rule 22 of A.P. State and
Subordinate Services Rules, 1996, deals with reservation. The rules have been framed under proviso
to Article 309 of the Constitution.
53. The Andhra Pradesh Regulation of Reservation and Appointment to Public Services Act, 1997,
was enacted to provide reservations. It mandates to ensure that reservation provided under Rule 22Chebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

is followed scrupulously, and the provisions made in the rules are not violated. In the A.P.
Regulation of Reservation and Appointment Act, the percentage of reservation has not been
provided to respective Scheduled Castes, Scheduled Tribes and Backward classes.
54. Rules 22 and 22A, which provide for reservation for Scheduled Castes, Scheduled Tribes,
backward classes and women have been framed under the proviso to Article 309 of the Constitution
of India. They are not to partake with an Act of Parliament or State legislature.
In substance, Rules 22 and 22A framed under Article 309 have been amended, which could not have
been done as that is not the Act of the Parliament or the legislature of the State. Thus, the Governor
could not have exercised power concerning rule framed under the proviso to Article 309 of the
Constitution.
55. In B.S. Yadav & Ors. v. State of Haryana & Ors., AIR 1981 SC 561, this Court held that the rule
made by the Governor under the proviso is also the law but, at the same time, it cannot be said in
view of the aforesaid decision that the Parliament or the State legislature made the rules under the
proviso to Article 309 of the Constitution.
56. Learned counsel on behalf of the State argued that Para 5(1) of Schedule V empowers the
Governor to make laws, and it is a legislative function, and any order of the Governor shall be
treated as legislation. The impugned order shall have to be treated as legislation and can only be
tested on the parameters of competence and violation of the Constitution. It cannot be tested on the
touchstone of ideal norms. Reliance has been placed on Natural Resources Allocation, In re, Special
Reference No.1 of 2012, (2012) 10 SCC 1 in which the Court opined:
“112. Equality, therefore, cannot be limited to mean only auction, without testing it in
every scenario. In State of W.B. v. Anwar Ali Sarkar, AIR 1952 SC 75, this Court,
quoting from Kotch v. River Port Pilot Commissioners, 91 L Ed 1093: 330 US 552
(1947) had held that: (Anwar Ali Sarkar case, AIR 1952 SC 75, AIR p. 80, para 10)
“10. … ‘The constitutional command for a State to afford equal protection of the laws
sets a goal not attainable by the invention and application of a precise formula. This
Court has never attempted that impossible task.’” One cannot test the validity of a law
with reference to the essential elements of ideal democracy, actually incorporated in
the Constitution. (See Indira Nehru Gandhi v. Raj Narain, 1975 Supp SCC 1) The
courts are not at liberty to declare a statute void, because in their opinion, it is
opposed to the spirit of the Constitution. The courts cannot declare a limitation or
constitutional requirement under the notion of having discovered some ideal norm.
Further, a constitutional principle must not be limited to a precise formula but ought
to be an abstract principle applied to precise situations. The repercussion of holding
auction as a constitutional mandate would be the voiding of every action that deviates
from it, including social endeavours, welfare schemes and promotional policies, even
though CPIL itself has argued against the same, and asked for making auction
mandatory only in the alienation of scarce natural resources meant for private and
commercial business ventures. It would be odd to derive auction as a constitutionalChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

principle only for a limited set of situations from the wide and generic declaration of
Article 14. The strength of constitutional adjudication lies in case to case adjudication
and therefore auction cannot be elevated to a constitutional mandate."
The submission that the order of the Governor shall be treated as legislation and has to be tested like
legislation cannot be disputed. However, when it comes to modification or exception, concerning the
Act of Parliament or the State legislature, we cannot add subordinate legislation in the ken of Para
5(1). The Governor can make a decision not to apply Parliamentary law or State law to scheduled
areas and modify such law.
57. The rules framed under the proviso to Article 309 of the Constitution cannot be said to be the
Act of Parliament or State legislature. Though the rules have the statutory force, they cannot be said
to have been framed under any Act of Parliament or State legislature. The rules remain in force till
such time the legislature exercises power. The power of the Governor under Para 5(1) of Schedule V
of the Constitution is restricted to modifying or not to apply, Acts of the Parliament or legislature of
the State. Thus, the rules could not have been amended in the exercise of the powers conferred
under Para 5(1) of Schedule V. The rules made under proviso to Article 309 of the Constitution
cannot be said to be an enactment by the State legislature. Thus, in our opinion, it was not open to
the Governor to issue the impugned G.O. No.3/2000. In re: Question No.1(c): Can the exercise of
the power conferred in Para 5 of the Fifth Schedule override fundamental rights guaranteed under
Part III?
58. Manifold arguments are made in this regard. Firstly, it was argued on behalf of the respondents
that the basic structure doctrine is inapplicable upon the Constitution's original text. It must not be
employed to test the validity of the impugned action. The fifth Schedule under Article 244(1) of the
Constitution is part of the original text, and hence, it must not be tested under the Basic Structure
Doctrine. Reliance has been placed on Kesavananda Bharti v. State of Kerala, (1973) 4 SCC 225 in
which this Court laid down that Constitutional amendments post−1973 can be struck down if they
violate the Basic Structure Doctrine.
59. Reliance has also been placed on Waman Rao and Ors. v. Union of India and Ors., (1981) 2 SCC
362, in which this Court opined thus:
“49. We propose to draw a line, treating the decision in Kesvananda Bharati, (1973) 4
SCC 225, as the landmark. Several Acts were put in the Ninth Schedule prior to that
decision on the supposition that the power of Parliament to amend the Constitution
was wide and untrammelled. The theory that the Parliament cannot exercise its
amending power to damage or destroy the basic structure of the Constitution was
propounded and accepted for the first time in Kesavananda Bharati, (1973) 4 SCC
225, is one reason for upholding the laws incorporated into the Ninth Schedule
before April 24, 1973, on which date the judgment in Kesavananda Bharati, (1973) 4
SCC 225, was rendered. A large number of properties must have changed hands, and
several new titles must have come into existence on the faith and belief that the laws
included in the Ninth Schedule were not open to challenge on the ground that theyChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

were violative of Articles 14, 19 and 31. We would not be justified in upsetting settled
claims and titles and in introducing chaos and confusion into the lawful affairs of a
fairly orderly society.
50. The second reason for drawing a line at a convenient and relevant point of time is
that the first 66 items in the Ninth Schedule, which were inserted prior to the
decision in Kesavananda Bharati, (1973) 4 SCC 225, mostly pertain to laws of
agrarian reforms. There are a few exceptions amongst those 66 items, like Items 17,
18, 19, which relate to Insurance, Railways and Industries. But almost all other items
would fall within the purview of Article 31-A(1)(a). In fact, Items 65 and 66, which
were inserted by the 29th Amendment, are the Kerala Land Reforms (Amendment)
Acts of 1969 and 1971 respectively, which were specifically challenged in
Kesavananda Bharati, (1973) 4 SCC 225. That challenge was repelled.
51. Thus, insofar as the validity of Article 31-B read with the Ninth Schedule is
concerned, we hold that all Acts and Regulations included in the Ninth Schedule
prior to April 24, 1973 will receive the full protection of Article 31-B. Those laws and
regulations will not be open to challenge on the ground that they are inconsistent
with or take away or abridge any of the rights conferred by any of the provisions of
Part III of the Constitution. Acts and Regulations, which are or will be included in the
Ninth Schedule on or after April 24, 1973 will not receive the protection of Article
31-B for the plain reason that in the face of the judgment in Kesavananda Bharati,
(1973) 4 SCC 225, there was no justification for making additions to the Ninth
Schedule with a view to conferring a blanket protection on the laws included therein.
The various constitutional amendments, by which additions were made to the Ninth
Schedule on or after April 24, 1973, will be valid only if they do not damage or destroy
the basic structure of the Constitution.” (emphasis supplied)
60. Reliance has also been placed on the decision of this Court in I.R. Coelho (Dead) by LRs. v. State
of T.N., (2007) 2 SCC 1, decided by a nine−Judge Bench of this Court thus:
“151. The effect of the application of the limitation of the basic structure to a
scheduled Act is that Article 31-B read with the Ninth Schedule is no longer not
subject to judicial review. Judicial review is, therefore, very much present.” Thus, it
was urged that since the original text of the Constitution is contained in the Fifth
Schedule, it would not be permissible to test the same in terms of the basic structure.
Article 14 is the part of the basic structure; therefore, it cannot be used to dilute the
non−obstante clause of Para 5(1) of Fifth Schedule, and action taken thereunder
cannot be tested on the anvil of violation of fundamental rights.
61. In our opinion, the submission based on Basic Structure Doctrine is not at all germane to the
instant case to decide the validity of the provisions contained in Para 5 of Fifth Schedule of the
Constitution or validity of any other Constitutional amendment. We are deciding the validity of the
action of the Governor issuing impugned notification, providing 100 per cent reservation toChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

Scheduled Tribes in the Scheduled Areas. Every action of the legislature, whether it is Parliament or
State, has to conform with the rights guaranteed in Part III of the Constitution. The original scheme
of the Constitution itself so provides; thus, the argument based upon Basic Structure Doctrine does
not hold the validity of the notification as that action is taken under the provisions, and the
provisions in Para 5 Schedule V do not override the rights guaranteed in Part III of the Constitution.
The limitations on the legislature in the field of legislation are applicable to Governor also.
62. It was next argued that there is absolute discretion with the Governor to make modification and
exception as to the applicability of laws; however, absolute discretion cannot be said to be
exercisable arbitrarily. The Constitution has not conferred any arbitrary power on any constitutional
functionary. Arbitrariness is an antithesis to the concept of equality, which is enshrined in Article 14
of the Constitution, and the same is its spirit and soul.
63. The provisions of the Constitution are required to be interpreted keeping in view the will of the
makers thereof as held in S.R. Chaudhuri v. State of Punjab & Ors., (2001) 7 SCC 126 thus:
“33. Constitutional provisions are required to be understood and interpreted with an
object-oriented approach. A Constitution must not be construed in a narrow and
pedantic sense. The words used may be general in terms but, their full import and
true meaning have to be appreciated considering the true context in which the same
are used and the purpose which they seek to achieve. Debates in the Constituent
Assembly referred to in an earlier part of this judgment clearly indicate that a
non-member's inclusion in the Cabinet was considered to be a “privilege” that
extends only for six months, during which period the member must get elected,
otherwise he would cease to be a Minister. It is a settled position that debates in the
Constituent Assembly may be relied upon as an aid to interpret a constitutional
provision because it is the function of the court to find out the intention of the
framers of the Constitution. We must remember that a Constitution is not just a
document in solemn form, but a living framework for the Government of the people
exhibiting a sufficient degree of cohesion and its successful working depends upon
the democratic spirit underlying it being respected in letter and in spirit. The debates
clearly indicate the “privilege” to extend “only” for six months.”
64. The very concept of equality, which is sought to be achieved by protective discrimination, is not
just a matter of classification but also aims against arbitrariness. Equality is the antithesis of
arbitrariness. In Col. A.S. Iyer and Ors. v. V. Balasubramanyam, (1980) 1 SCC 634, the Court as to
the doctrine of classification observed:
“57. x x x This tendency, in an elitist society with a diehard caste mentality, is a
disservice to our founding faith, even if judicially sanctified. Subba Rao, J., hit the
nail on the head when he cautioned in Lachhman Das v. State of Punjab, (1963) 2
SCR 353, 395: AIR 1963 SC 222:Chebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

“The doctrine of classification is only a subsidiary rule evolved by courts to give a
practical content to the said doctrine. Over-emphasis on the doctrine of classification
or an anxious and sustained attempt to discover some basis for classification may
gradually and imperceptibly deprive the article of its glorious content. That process
would inevitably end in substituting the doctrine of classification for the doctrine of
equality; the fundamental right to equality before the law and the equal protection of
the laws may be replaced by the doctrine of classification.”
65. In Ajay Hasia and Ors. v. Khalid Mujib Sehravardi and Ors., (1981) 1 SCC 722, the Court
considered the doctrine of classification. The classification is not only to be reasonable; it must
satisfy the requisite conditions. Whenever there is arbitrariness in State action, whether it be of the
legislature or the executive or authority under Article 12, the provisions of Article 14 immediately
springs into action to strike down such an action. The Court held:
"16. If the Society is an ‘authority’ and therefore ‘State’ within the meaning of Article
12, it must follow that it is subject to the constitutional obligation under Article 14.
The true scope and ambit of Article 14 have been the subject-matter of numerous
decisions, and it is not necessary to make any detailed reference to them. It is
sufficient to state that the content and reach of Article 14 must not be confused with
the doctrine of classification. Unfortunately, in the early stages of the evolution of our
constitutional law, Article 14 came to be identified with the doctrine of classification
because the view was taken was that that article forbids discrimination and there
would be no discrimination where the classification making the differentia fulfils two
conditions, namely, (i) that the classification is founded on an intelligible differentia
which distinguishes persons or things that are grouped together from others left out
of the group; and (ii) that that differentia has a rational relation to the object sought
to be achieved by the impugned legislative or executive action. It was for the first time
in E.P. Royappa v. State of Tamil Nadu, (1974) 2 SCR 348: (1974) 4 SCC 3, that this
Court laid bare a new dimension of Article 14 and pointed out that that article has
highly activist magnitude and it embodies a guarantee against arbitrariness. This
Court speaking through one of us (Bhagwati, J.) said: SCC p. 38: SCC (L&S) p. 200,
para 85] “The basic principle which, therefore, informs both Articles 14 and 16 is
equality and inhibition against discrimination. Now, what is the content and reach of
this great equalising principle? It is a founding faith, to use the words of Bose, J., ‘a
way of life’, and it must not be subjected to a narrow pedantic or lexicographic
approach. We cannot countenance any attempt to truncate its all-embracing scope
and meaning, for to do so would be to violate its activist magnitude. Equality is a
dynamic concept with many aspects and dimensions and it cannot be “cribbed,
cabined and confined” within traditional and doctrinaire limits. From a positivistic
point of view, equality is antithetic to arbitrariness. In fact, equality and arbitrariness
are sworn enemies; one belongs to the rule of law in a republic while the other, to the
whim and caprice of an absolute monarch. Where an act is arbitrary it is implicit in it
that it is unequal both according to political logic and constitutional law and is
therefore violative of Article 14, and if it affects any matter relating to publicChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

employment, it is also violative of Article 16. Articles 14 and 16 strike at arbitrariness
in State action and ensure fairness and equality of treatment.” This vital and dynamic
aspect which was till then lying latent and submerged in the few simple but pregnant
words of Article 14 was explored and brought to light in Royappa case, (1974) 2 SCR
348: (1974) 4 SCC 3, and it was reaffirmed and elaborated by this Court in Maneka
Gandhi v. Union of India, (1978) 1 SCC 248, where this Court again speaking through
one of us (Bhagwati, J.) observed: (SCC pp. 283-84, para 7) “Now the question
immediately arises as to what is the requirement of Article 14: What is the content
and reach of the great equalising principle enunciated in this Article? There can be no
doubt that it is a founding faith of the Constitution. It is indeed the pillar on which
rests securely the foundation of our democratic republic. And, therefore, it must not
be subjected to a narrow, pedantic or lexicographic approach. No attempt should be
made to truncate its all-embracing scope and meaning, for to do so would be to
violate its activist magnitude. Equality is a dynamic concept with many aspects and
dimensions and it cannot be imprisoned within traditional and doctrinaire limits....
Article 14 strikes at arbitrariness in State action and ensures fairness and equality of
treatment. The principle of reasonableness, which legally as well as philosophically, is
an essential element of equality or non- arbitrariness pervades Article 14 like a
brooding omnipresence.” This was again reiterated by this Court in International
Airport Authority case, (1979) 3 SCC 489, at p. 1042 (SCC p. 511) of the Report. It
must therefore now be taken to be well settled that what Article 14 strikes at is
arbitrariness because an action that is arbitrary must necessarily involve negation of
equality. The doctrine of classification which is evolved by the courts is not
paraphrase of Article 14 nor is it the objective and end of that article. It is merely a
judicial formula for determining whether the legislative or executive action in
question is arbitrary and therefore constituting denial of equality. If the classification
is not reasonable and does not satisfy the two conditions referred to above, the
impugned legislative or executive action would plainly be arbitrary and the guarantee
of equality under Article 14 would be breached. Wherever therefore there is
arbitrariness in State action whether it be of the legislature or of the executive or of
an “authority” under Article 12, Article 14 immediately springs into action and strikes
down such State action. In fact, the concept of reasonableness and non-arbitrariness
pervades the entire constitutional scheme and is a golden thread which runs through
the whole of the fabric of the Constitution.”
66. In E.P. Royappa v. State of Tamil Nadu & Anr., (1974) 4 SCC 3, concerning the concept of
equality and arbitrariness in action, in the context of Articles 14 and 16, the Court held:
“85. The last two grounds of challenge may be taken up together for consideration.
Though we have formulated the third ground of challenge as a distinct and separate
ground, it is really in substance and effect merely an aspect of the second ground
based on violation of Articles 14 and 16. Article 16 embodies the fundamental
guarantee that there shall be equality of opportunity for all citizens in matters
relating to employment or appointment to any office under the State. Though enactedChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

as a distinct and independent fundamental right because of its great importance as a
principle ensuring equality of opportunity in public employment which is so vital to
the building up of the new classless egalitarian society envisaged in the Constitution,
Article 16 is only an instance of the application of the concept of equality enshrined in
Article 14. In other words, Article 14 is the genus while Article 16 is a species. Article
16 gives effect to the doctrine of equality in all matters relating to public employment.
The basic principle which, therefore, informs both Articles 14 and 16 is equality and inhibition
against discrimination. Now, what is the content and reach of this great equalising principle? It is a
founding faith, to use the words of Bose. J., “a way of life”, and it must not be subjected to a narrow
pedantic or lexicographic approach. We cannot countenance any attempt to truncate its
all-embracing scope and meaning, for to do so would be to violate its activist magnitude. Equality is
a dynamic concept with many aspects and dimensions and it cannot be “cribbed, cabined and
confined” within traditional and doctrinaire limits. From a positivistic point of view, equality is
antithetic to arbitrariness. In fact equality and arbitrariness are sworn enemies; one belongs to the
rule of law in a republic while the other, to the whim and caprice of an absolute monarch. Where an
act is arbitrary, it is implicit in it that it is unequal both according to political logic and constitutional
law and is therefore violative of Article 14, and if it effects any matter relating to public employment,
it is also violative of Article 16. Articles 14 and 16 strike at arbitrariness in State action and ensure
fairness and equality of treatment. They require that State action must be based on valid relevant
principles applicable alike to all similarly situate and it must not be guided by any extraneous or
irrelevant considerations because that would be denial of equality. Where the operative reason for
State action, as distinguished from motive inducing from the antechamber of the mind, is not
legitimate and relevant but is extraneous and outside the area of permissible considerations, it
would amount to mala fide exercise of power and that is hit by Articles 14 and 16. Mala fide exercise
of power and arbitrariness are different lethal radiations emanating from the same vice: in fact the
latter comprehends the former. Both are inhibited by Articles 14 and
16.”
67. In Maneka Gandhi v. Union of India & Anr., (1978) 1 SCC 248, this Court held that fundamental
rights are not distinct and mutually exclusive rights. Each freedom has its dimensions. The law is
not freed from the necessity to meet the challenge of another guaranteed freedom. Thus, the law
effecting personal liberty under Article 21 will also have to satisfy the test under Articles 14 and 19.
In majority opinion, Beg, J. observed:
“202. Articles dealing with different fundamental rights contained in Part III of the
Constitution do not represent entirely separate streams of rights which do not mingle
at many points. They are all parts of an integrated scheme in the Constitution. Their
waters must mix to constitute that grand flow of unimpeded and impartial Justice
(social, economic and political), Freedom (not only of thought, expression, belief,
faith and worship, but also of association, movement, vocation or occupation as well
as of acquisition and possession of reasonable property), of Equality (of status and of
opportunity, which imply absence of unreasonable or unfair discrimination betweenChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

individuals, groups, and classes) and of Fraternity (assuring dignity of the individual
and the unity of the nation), which our Constitution visualises. Isolation of various
aspects of human freedom, for purposes of their protection, is neither realistic nor
beneficial but would defeat the very objects of such protection.” Justices Bhagwati,
Untwalia and Fazal Ali observed:
“The nature and requirement of the procedure under Article 21
7. Now, the question immediately arises as to what is the requirement of Article 14 :
what is the content and reach of the great equalising principle enunciated in this
article? There can be no doubt that it is a founding faith of the Constitution. It is
indeed the pillar on which rests securely the foundation of our democratic republic.
And, therefore, it must not be subjected to a narrow, pedantic or lexicographic
approach. No attempt should be made to truncate its all-embracing scope and
meaning, for to do so would be to violate its activist magnitude. Equality is a dynamic
concept with many aspects and dimensions and it cannot be imprisoned within
traditional and doctrinaire limits.
We must reiterate here what was pointed out by the majority in E.P. Royappa v. State of Tamil
Nadu, (1974) 2 SCR 348, namely, that “from a positivistic point of view, equality is antithetic to
arbitrariness. In fact equality and arbitrariness are sworn enemies; one belongs to the rule of law in
a republic, while the other, to the whim and caprice of an absolute monarch. Where an act is
arbitrary, it is implicit in it that it is unequal both according to political logic and constitutional law
and is therefore violative of Article 14”. Article 14 strikes at arbitrariness in State action and ensures
fairness and equality of treatment...The principle of reasonableness, which legally as well as
philosophically, is an essential element of equality or non-arbitrariness pervades Article 14 like a
brooding omnipresence and the procedure contemplated by Article 21 must answer the test of
reasonableness in order to be in conformity with Article 14. It must be “right and just and fair” and
not arbitrary, fanciful or oppressive; otherwise, it would be no procedure at all and the requirement
of Article 21 would not be satisfied.” Krishna Iyer, J. observed:
“96. A thorny problem debated recurrently at the bar, turning on Article 19, demands
some juristic response although avoidance of overlap persuades me to drop all other
questions canvassed before us. The Gopalan verdict, with the cocooning of Article 22
into a self-contained code, has suffered suppression at the hands of R.C. Cooper,
(1970) 3 SCR 530. By way of aside, the fluctuating fortunes of fundamental rights,
when the proletarist and the proprietarist have asserted them in Court, partially
provoke sociological research and hesitantly project the Cardozo thesis of
sub-conscious forces in judicial noesis when the cycloramic review starts from
Gopalan, moves on to In re Kerala Education Bill, 1959 SCR 995 and then on to
All-India Bank Employees’ Association, (1962) 3 SCR 269, next to Sakal Papers,
(1962) 3 SCR 842, crowning in Cooper and followed by Bennett Coleman, (1973) 2
SCR 757 and Shambhu Nath Sarkar, (1973) 1 SCC 856. Be that as it may, the law is
now settled, as I apprehend it, that no article in Part III is an island but part of aChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

continent and the conspectus of the whole part gives the direction and correction
needed for interpretation of these basic provisions. Man is not dissectible into
separate limbs and, likewise, cardinal rights in an organic constitution, which make
man human have a synthesis. The proposition is indubitable that Article 21 does not,
in a given situation, exclude Article 19 if both rights are breached."
68. In Neelima Misra v. Harinder Kaur Paintal & Ors., (1990) 2 SCC 746, this Court held that an
administrative action, whether legislative, administrative or quasi−judicial must not be illegal,
irrational or arbitrary. The non−obstante clause as to what it excludes is to be considered only in
light of extent of power conferred on the Governor to issue a notification, to order that Act of the
legislature shall not apply and may make exceptions and modifications. However, at the same time
power is to be exercised within bounds of legislative power conferred on the legislature. The special
control is conferred upon the Governor to direct that any Act shall not apply, which could not
otherwise apply or be applicable in the area without such exceptions or modifications as ordered by
the Governor.
Effect of the non−obstante clause:
69. Para 5(1) of the Fifth Schedule of the Constitution starts with a non−obstante clause. What is the
effect of the non−obstante clause vis− à−vis the applicability to other provisions of the Constitution?
Whether the provisions of Para 5(1) prevail over all other provisions of the Constitution? Whether
the fundamental rights in Part III of the Constitution are inapplicable and need not be satisfied?
70. The provision of the Fifth Schedule beginning with the words “notwithstanding anything in this
Constitution” cannot be construed as taking away the provision outside the limitations on the
amending power and has to be harmoniously construed consistent with the foundational principles
and the basic features of the Constitution.
71. In R.C. Poudyal v. Union of India & Ors., 1994 Supp. (1) SCC 324, this Court considered the
question whether the non−obstante clause (f) to Article 371F inserted by the Constitution (36 th
Amendment) Act, 1975 containing a special provision for the State of Sikkim. The Governor of
Sikkim has exclusive responsibility for peace and equitable arrangement, for social and economic
advancement and various other provisions have been made that the non−obstante clause is
contained in Article 371−F, cannot be construed as taking clause (f) of Article 371F outside the
limitation on the amendment power itself. This Court opined that:
"102. It is, however, urged that Article 371-F starts with a non- obstante clause, and
therefore the other provisions of the Constitution do not limit the power to impose
conditions. But Article 371-F cannot transgress the basic features of the Constitution.
The non-obstante clause cannot be construed as taking clause (f) of Article 371-F
outside the limitations on the amendment power itself. The provisions of clause (f) of
Article 371-F and Article 2 have to be construed harmoniously consistent with the
foundational principles and basic features of the Constitution. Whether clause (f) has
the effect of destroying a basic feature of the Constitution depends, in turn, on theChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

question whether reservation of seats in the legislature based on ethnic group is itself
destructive of democratic principle. Whatever the merits of the contentions be, it
cannot be said that the issues raised are non-justiciable.
103. In Mangal Singh v. Union of India, (1967) 2 SCR 109, 112 this Court said:
“Power with which the Parliament is invested by Articles 2 and 3, is power to admit,
establish, or from new States which conform to the democratic pattern envisaged by
the Constitution; and the power which the Parliament may exercise by law is
supplemental, incidental or consequential to the admission, establishment or
formation of a State as contemplated by the Constitution, and is not power to
override the constitutional scheme.”
104. Even if clause (f) of Article 371-F is valid, if the terms and conditions stipulated
in a law made under Article 2 read with clause (f) of Article 371-F go beyond the
constitutionally permissible latitudes, that law can be questioned as to its validity.
The contention that the vires of the provisions and effects of such a law are non-justiciable cannot be
accepted.”
72. In State of Sikkim v. Surendra Prasad Sharma & Ors., (1994) 5 SCC 282, this Court held that the
laws, which were in force before the commencement of the Constitution of India, must be consistent
with Part III of the Constitution to continue to be in force. This Court opined:
“11. From the above constitutional scheme what emerges is that the laws which were
in force in the territory of India immediately before the commencement of the
Constitution shall continue in force therein until altered, repealed or amended by a
competent legislature or authority except to the extent inconsistent with Part III of
the Constitution. However, notwithstanding anything in the Constitution, Parliament
was empowered to make laws inter alia with respect to any matter referred to in
Article 16(3). Thus, Parliament could prescribe by law the requirement as to
residence within a State or Union Territory and if such a law is made nothing in
Article 16 will stand in the way of such prescription. Since Article 16(3) is in Part III
of the Constitution, the law, if made, would clearly be intra vires the Constitution. By
virtue of Article 35(b) any law in force immediately before the commencement of the
Constitution in relation to any matter in Article 16(3) shall continue in force,
notwithstanding anything in the Constitution. The expression ‘law in force’ has the
meaning assigned to it in Article 372, Explanation I. This is the conjoint effect of
Articles 13, 16(3), 35(b) and 372 of the Constitution. Since Sikkim was never a part of
the territory of India immediately before the commencement of the Constitution, the
High Court has ruled out the applicability of the said provisions in this case. Article 2
provides that Parliament may by law admit into the Union, or establish, new States
on such terms and conditions as it thinks fit. The law so made must conform to the
requirements of Article 13. That is the view expressed in Poudyal case, 1944 Supp (1)Chebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

SCC 324. But the historical events preceding its inclusion in the territory of India
must be borne in mind. Sikkim during the British period was ruled by a monarch
called the Chogyal. After India became free there was a popular demand from the
people of Sikkim for its merger with India. Pursuant to the sentiments expressed by
the People of Sikkim, a treaty was entered into between India and the Chogyal short
of merger which was followed up by consequential changes. However, the public
demand became violent forcing the Chogyal to request the Union Government to
assume the responsibility for good Government. Ultimately, on 8-5-1973, a formal
agreement was signed between the Chogyal and the political leaders of Sikkim on the
one side and the Government of India on the other in pursuance whereto the people
of Sikkim were to enjoy certain democratic rights. This development would show that
Sikkim which was a British protectorate under the British paramountcy until 1947
came within the protectorate of India under the treaty of 3-12-1950 and later became
an associate State by the insertion of Article 2-A in the Constitution by the 35th
Amendment on the terms and conditions set out in the Tenth Schedule and soon
thereafter by the 36th Amendment Article 2-A was deleted and full statehood under
the Union of India was conferred on the terms and conditions incorporated in the
newly added Article 371-F. These constitutional changes had to be introduced in 1975
in reciprocation of the understanding on which Sikkim agreed to its merger with
India and to fulfil the aspirations of the Sikkimese people. The terms and conditions
for merger of Sikkim found in Article 371-F have, therefore, to be viewed in this
background.”
73. However, under the special agreement special provisions contained in Article 371−F(k), all laws
in force in the State of Sikkim were protected until amended or repealed to ensure a smooth
transition from Chogyal’s rule to democratic rules under the Constitution. Article 371−F(l) enshrines
that many of such existing laws may be inconsistent with the Constitution, as such immunity was
granted in the transitional period, this Court in State of Sikkim v. Surendra Prasad Sharma (supra)
considered non−obstante clause in Article 371−F and observed that the laws in force would have had
to meet the test of Article 13 of the Constitution. It was held:
"22. Article 371-F, is as stated earlier, a special constitutional provision concerning
the State of Sikkim. The reason why it begins with a non obstante clause is that the
matters referred to in the various clauses immediately following required a protective
cover so that such matters are not struck down as unconstitutional because they do
not satisfy the constitutional requirement. Unless such immunity was granted, 'the
laws in force' would have had to meet the test of Article 13 of the Constitution. Same
being the objective, existing laws or laws in force came to be protected by clause (k)
added to Article 371-F. The said laws in force in the State of Sikkim were, therefore,
protected, until amended or repealed, to ensure a smooth transition from the
Chogyal’s rule to the democratic rule under the Constitution. Inherent in clause (l) is
the assumption that many of such existing laws may be inconsistent with the
Constitution and, therefore, the President came to be conferred with a special power
to make adaptations and modifications with a view to making the said rule consistentChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

with the Constitution. Of course, this power had to be exercised within two years
from the appointed day. If any adaptation or modification is made in the law in force
prevailing prior to the appointed day, the law would apply subject to such adaptation
and modification. It is thus obvious that the adaptation and modification made by the
President in exercise of this special power does not have the effect of the law ceasing
to be a law in force within the meaning of clause (k) of Article 371-F. Therefore, on
the plain language of the said provision it is difficult to hold that the effect of
adaptation or modification is to take the law out of the purview of ‘laws in force’.”
74. The non−obstante clause contained in Para 5(1) of the Fifth Schedule of the Constitution means
the Governor can exercise power in spite of the provisions contained in Article 245 of the
Constitution, conferring the power upon Parliament to make laws and the legislature of the State.
The Parliament has the power to enact the law. It cannot be questioned on the ground that it would
have extra− territorial operation.
75. The non−obstante clause has also been considered in Smt. Parayankandiyal Eravath Kanapravan
Kalliani Amma & Ors. v. K. Devi & Ors., AIR 1996 SC 1963. The scope has to be considered in the
context and purpose for which it has been carved out.
76. In Peerless General Finance and Investment Co. Ld. And Anr. v. Reserve Bank of India, (1992) 2
SCC 343, the Court held that the court has to make every endeavour to ensure that the efficacy of
fundamental rights is maintained and the legislature is not invested with unlimited power. The
Court is to guard against the gradual encroachment and strike down a restriction as soon as it
reaches that magnitude of total infringement of the right. The Court observed:
“48. x x x The State can regulate the exercise of the fundamental right to save the
public from a substantive evil. The existence of the evil as well as the means adopted
to check it are the matters for the legislative judgment. But the Court is entitled to
consider whether the degree and mode of the regulation is in excess of the
requirement or is imposed in an arbitrary manner. The Court has to see whether the
measure adopted is relevant or appropriate to the power exercised by the authority or
whether it overstepped the limits of social legislation. Smaller inroads may lead to
larger inroads and ultimately result in total prohibition by indirect method. If it
directly transgresses or substantially and inevitably affects the fundamental right, it
becomes unconstitutional, but not where the impact is only remotely possible or
incidental. The Court must lift the veil of the form and appearance to discover the
true character and the nature of the legislation, and every endeavour should be made
to have the efficacy of fundamental right maintained and the legislature is not
invested with unbounded power. The Court has, therefore, always to guard against
the gradual encroachments and strike down a restriction as soon as it reaches that
magnitude of total annihilation of the right.”
77. In case the argument raised on behalf of the respondent is accepted that the Governor has
unfettered power, notwithstanding the provisions contained in Part III of the Constitution, ArticleChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

13 of the Constitution becomes redundant. The power of judicial review of court and legislature
would loom into insignificance. There is no power to the legislature or to the Governor to act
contrary to the constitutional provisions, and they cannot enact a law in derogation to the provisions
contained in Part III of the Constitution. In Chandavarkar S. R. Rao v. Ashalata S. Guram, (1986) 4
SCC 447, it has been held that the effect of the non−obstante clause is that in spite of the provisions
of the Act or any other Act mentioned in the non−obstante clause or any contract or document
mentioned, the enactment following it will have its full operation or that the provision vested in the
non−obstante clause would not be an impediment for the operation of the enactment. In case
Governor decides not to apply the Act of the Parliament or legislature of the State or apply them
with exceptions and modifications, he is empowered to do so. But it would be subject to the
restriction on the very legislative power with which the Parliament or legislature of State suffers
from the above−avowed objective devised by the framers of the Constitution.
78. The power is conferred on the Governor to deal with the scheduled areas. It is not meant to
prevail over the Constitution. The power of the Governor is pari passu with the legislative power of
Parliament and the State. The legislative power can be exercised by the Parliament or the State
subject to the provisions of Part III of the Constitution. In our considered opinion, the power of the
Governor does not supersede the fundamental rights under Part III of the Constitution. It has to be
exercised subject to Part III and other provisions of the Constitution. When Para 5 of the Fifth
Schedule confers power on the Governor, it is not meant to be conferral of arbitrary power. The
Constitution can never aim to confer any arbitrary power on the constitutional authorities. They are
to be exercised in a rational manner keeping in view the objectives of the Constitution. The powers
are not in derogation but the furtherance of the constitutional aims and objectives.
In Re: Question No.1(d): Whether the exercise of power under the Fifth Schedule of the Constitution
overrides any parallel exercise of power by the President under Article 371D?
79. It was argued on behalf of the appellants that Article 371D was promulgated in view of
geographical disparity in public employment within the State of Andhra Pradesh. The candidates
from certain districts/areas of the State capturing a disproportionately large number of public posts.
Article 371D requires the State Government to reorganise class or classes of posts in the State into
different local cadres for different parts of the State. The Presidential Order of 1975 was issued
providing district/zone as a unit for the local cadre. Whereas, G.O. provided that all the posts of
teachers in the schools situated in Scheduled Areas in the State of Andhra Pradesh shall be filled in
with the local Scheduled Tribes candidates only. A district or zone is the unit for the local cadre.
Whereas on the other hand, the impugned G.O.Ms. No.3 of 2000 provided that all the posts of
teachers in the Scheduled Area, forming part of a district, to be filled up by local Scheduled Tribe
candidates only. The impugned G.O. reserved all the posts in the Scheduled Area; thus, aspiring
candidates in a district/zone in the Scheduled Areas cannot apply for the post of teachers in the
district or zone as all the posts have been reserved for local Scheduled Tribe candidates and "they
cannot apply outside the district or zone" because of the restrictions under Article 371D of the
Constitution.Chebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

80. Learned counsel for the appellant further argued that the candidates other than Scheduled Tribe
candidates in a district residing in Scheduled Areas cannot apply at all, and they have been deprived
of the opportunity of getting public employment. The impugned G.O. takes away the entire
opportunity of non−Scheduled Tribe candidates even from applying for the post of teachers. Thus,
the impugned G.O. transgresses Article 371D of the Constitution and is unconstitutional. The
Governor could not have issued the notification in such a manner in exercise of powers under Para 5
of Fifth Schedule, which is repugnant to the Presidential Order issued under Article 371D. The
Governor cannot exercise the powers under Para 5(1) of Fifth Schedule and cannot modify or
override the provisions of Article 371D of the Constitution.
81. It was argued on behalf of respondents that there is no repugnancy in the Presidential Order and
the impugned notification issued by the Governor. Article 371D also starts with non−obstante clause
and conflict between the non−obstante clause as far as possible must be resolved by way of
harmonious construction of two conflicting non−obstante clauses as laid down in Jay Engineering
Works Limited v. Industry Facilitation Council and Anr., (2006) 8 SCC 677:
“28. Both the Acts contain non obstante clauses. Ordinary rule of construction is that
where there are two non obstante clauses, the latter shall prevail. But it is equally well
settled that ultimate conclusion thereupon would depend upon the limited context of
the statute. (See Allahabad Bank, (2000) 4 SCC 406, para 34.)
29. In Maruti Udyog Ltd. v. Ram Lal, (2005) 2 SCC 638, it was observed: (SCC p.
653, para 39) “39. The interpretation of Section 25-J of the 1947 Act as propounded
by Mr Das also cannot also be accepted inasmuch as in terms thereof only the
provisions of the said chapter shall have effect notwithstanding anything inconsistent
therewith contained in any other law including the Standing Orders made under the
Industrial Employment (Standing Orders) Act, but it will have no application in a
case where something different is envisaged in terms of the statutory scheme. A
beneficial statute, as is well known, may receive liberal construction but the same
cannot be extended beyond the statutory scheme.”
30. In Sarwan Singh v. Kasturi Lal, (1977) 1 SCC 750, this Court opined: (SCC p. 760,
para 20) “When two or more laws operate in the same field and each contains a non
obstante clause stating that its provisions will override those of any other law,
stimulating and incisive problems of interpretation arise. Since statutory
interpretation has no conventional protocol, cases of such conflict have to be decided
in reference to the object and purpose of the laws under consideration.”
31. The endeavour of the court would, however, always be to adopt a rule of
harmonious construction.” It was laid down that endeavour of the court would always
be to adopt a rule of harmonious construction, and the non−obstante clause must be
given effect as to the Parliament intent and not beyond that.Chebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

It was also urged that if the latter provision is found to be generic as against the earlier provision,
which is a special provision, then the earlier provision shall prevail. Reliance has also been placed on
Maharashtra Tubes Ltd. v. State Industrial & Investment Corporation of Maharashtra Ltd. and Anr.,
(1993) 2 SCC 144. The policy underlying the provisions has to be considered, as observed in Jay
Engineering Works (supra). The notification issued, according to the Presidential Order, creates
district/zonal cadre for teachers. The Governor Order reserved the posts of teachers in the
Scheduled Area for Scheduled Tribes. There is no strict conflict between the aforesaid notification,
and harmonious construction is possible.
82. It was further urged on behalf of respondents that the State of Andhra Pradesh was reorganised
in the year 1956, and part of the areas falling in the State of Hyderabad, Telugu speaking areas
known as Telangana merged with Andhra Pradesh. In the Telangana region, Mulki Rules prevail,
which provide for residence as a requirement for public employment. After the reorganisation, the
Central Government enacted the A.P. Public Employment (Requirement as to Residence) Act, 1957,
to continue the same. On challenge being made as to the provisions being violative of Article 16(2),
this Court in Narasimha Rao v. State of A.P., (1969) 1 SCC 839, opined that the residence
requirement as unconstitutional, resulting in agitation demanding division of State. The Parliament
amended the Constitution by inserting Article 371D, empowering the President to issue an order
providing equal opportunities to people belonging to different parts of the State in education and
public employment. Under para 3 of the Presidential Order, the civil posts in the State were to be
organised on local cadres, such as Lower Division Clerks and equivalent Non− Gazetted category
and existed Gazetted and Non−Gazetted category in each department. Paras 4 and 5 of the
Presidential Order provided that employees to be allotted to local cadres/areas, which shall be a unit
for all purpose. Under para 6 of the Presidential Order, local areas have to be the basis for various
posts making district/zone, multi zone and State−wide as local areas for all civil posts. Para 8
provided for reservation by way of direct recruitment for local candidates. Article 371D(10) provided
for non−obstante clause to make provisions immune from challenge from Articles 14 and 16 of the
Constitution. The operation of Article 371D is confined to providing for reservation in direct
recruitment for local candidates and also for various percentages of reservation for locals. Under
para 6(1) each district shall be regarded as local area. The action is not violative of Article 371D. It
was further argued on behalf of respondents that the President has issued notification under Article
371D towards the promotion of equality of opportunity. The notification did not deal with Scheduled
Areas or employment opportunities in Scheduled Areas. No notification issued by the President
under Article 371D collides or is in conflict with the impugned notification. The preferences given to
the local areas within the meaning of Presidential notification or exclusion of non−local areas cadre
will not offend Article 14 of the Constitution, for which reliance has been placed on Sandeep and
Ors. v. Union of India and Ors., (2016) 2 SCC 328, Dr. Fazal Ghafoor v. Principal, Osmania Medical
College, Hyderabad and Ors., (1988) 4 SCC 532, Dr. Fazal Ghafoor v. Union of India and Ors.,
(1988) Supp. SCC 794, N.T.R. University of Health Science, Vijayawada v. G. Babu Rajendra Prasad
and Anr., (2003) 5 SCC 350. Similar logic, which is applicable to Articles 14 and 371D, is also to be
relevant in the context of what the Governor does under the Fifth Schedule. Consequently, what the
Governor has done to greater equality for Scheduled Areas will not be faulted.Chebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

83. The non−obstante clause in Article 371D will not annul the non− obstante clause in Para 5 of the
Fifth Schedule. Two constitutional provisions operate in distinct domain. Article 371D was not
enacted to be a super imposition on Fifth Schedule. The object and purpose of legislations or
provisions with respect to non−obstante clause are distinct. Thus, the court will not see any conflict.
Reference has been made to R.S. Raghunath v. State of Karnataka and Ors., (1991) Supp. 1 SCR 387,
Sarwan Singh and Ors. v. Kasturi Lal, (1977) 2 SCR 421, Sanwarmal Kejriwal v. Vishwa Co−operative
Housing Society Ltd. and Ors., (1990) 1 SCR 862, The South India Corporation (P) Ltd. v. The
Secretary, Board of Revenue Trivandrum and Ors., (1964) 4 SCR 280, and Dr. Fazal Ghafoor v.
Principal, Osmania Medical College, Hyderabad and Ors., (1988) 4 SCC 532.
84. Article 371−D has been inserted in the Constitution of India. Sub−clauses 1, 2 and 10 of Article
371−D are extracted hereunder:
“371D. Special provisions with respect to the State of Andhra Pradesh or the State of
Telangana.— (1) The president may by order made with respect to the state of Andhra
Pradesh or the State of Telangana provide, having regard to the requirement of each
State, for equitable opportunities and facilities for the people belonging to different
parts of such State, in the matter of public employment and in the matter of
education, and different provisions may be made for various parts of the States.
(2) An order made under clause (1) may, in particular,—
(a) require the State Government to organise any class or classes of posts in a civil
service of, or any class or classes of civil posts under, the State into different local
cadres for different parts of the State and allot in accordance with such principles and
procedure as may be specified in the order the persons holding such posts to the local
cadres so organised;
(b) specify any part or parts of the State which shall be regarded as the local area—
(i) for direct recruitment to posts in any local cadre (whether organised in pursuance
of an order under this article or constituted otherwise) under the State Government;
(ii) for direct recruitment to posts in any cadre under any local authority within the
State; and
(iii) for the purposes of admission to any University within the State or to any other
educational institution which is subject to the control of the State Government;
(c) specify the extent to which, the manner in which and the conditions subject to
which, preference or reservation shall be given or made—
(i) in the matter of direct recruitment to posts in any such cadre referred to in
sub-clause (b) as may be specified in this behalf in the order;Chebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

(ii) in the matter of admission to any such University or other educational institution
referred to in sub-
clause (b) as may be specified in this behalf in the order, to or in favour of candidates who have
resided or studied for any period specified in the order in the local area in respect of such cadre,
University or other educational institution, as the case may be.
(3) x x x
10) The provisions of this article and of any order made by the President thereunder shall have effect
notwithstanding anything in any other provision of this Constitution or in any other law for the time
being in force.” The provisions contained in Article 371D were inserted by the Constitution (Thirty−
second Amendment) Act, 1973, w.e.f. 1.7.1974 and has further been amended by the Andhra Pradesh
Reorganisation Act, 2014, applicable to the State of Andhra Pradesh or the State of Telangana.
85. The President in exercise of powers under Article 371−D(1) and (2) promulgated order, namely,
Andhra Pradesh Public Employment (Organisation of Local Cadres and Regulation of Direct
Recruitment) Order, 1975. Para 3 provided for organisation of local cadres. Recruitment to various
categories has to be made to local cadres taking district as a unit or 3 or 4 districts comprising as a
zone. The local area has been defined in Para 6(1) thus:
“Local areas: (1) Each district shall be regarded as a local area –
(i) For direct recruitment to posts in any local cadre under the State Government
comprising all or any of the posts in any department in that district belonging to the
category of Junior Assistants or to any other category equivalent to or lower than that
of a Junior Assistant.
(ii) For direct recruitment to posts in any cadre under any local authority within that
district, carrying a sale of pay the minimum of which does not exceed the minimum
of the scale of pay of a Junior Assistant or a fixed pay not exceeding that amount.”
For recruitment to the posts of teachers, a district is a unit.
Para 7 defines local candidates. Para 8 provides that 80 per cent of the posts to be filled by direct
recruitment. The matter of recruitment to various local cadres is required to be in terms of the
provisions of the Presidential Order issued under Article 371D. The recruitment of teachers is to be
made for which district is a unit.
86. In Dr. C. Surekha v. Union of India, AIR 1989 SC 44, this Court held that Article 371D does not
militate against the basic structure of the Constitution. Similar is the view taken in Dr. Fazal
Ghafoor v. Union of India, AIR 1989 SC 48.
87. This Court in V. Jagannadha Rao and Ors. v. State of A.P. and Ors., (2001) 10 SCC 401 held that
Article 371D(1) of the Constitution unequivocally indicates that the said article and any order madeChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

by the President thereunder shall have effect notwithstanding anything in any other provision of the
Constitution or any other law for the time being in force. The Court observed:
“21. In Sadanandam case, 1989 Supp. (1) SCC 574, while considering the legality of
amended provisions of the Rules framed by the State Government and in sustaining
the same, this Court was of the opinion that as the aforesaid Rules had been framed
under Section (3) of the Andhra Pradesh Ordinance 5 of 1983 read with para 5(2)(a)
of the Presidential Order, the conclusion of the Tribunal in striking down the rule is
erroneous. The Court was of the opinion that mode of recruitment and category from
which the recruitment to a service should be made are policy matters exclusively
within the purview and domain of the executive and it would not be appropriate for
judicial bodies to sit in judgment over the wisdom of the executive in choosing the
mode of recruitment or the categories from which the recruitment should be made.
In our considered opinion, both the aforesaid reasons do not constitute a true
interpretation of the provisions of the Presidential Order. At the outset, it may be
noticed that Article 371-D(10) of the Constitution unequivocally indicates that the
said article and any order made by the President thereunder shall have effect
notwithstanding anything in any other provision of the Constitution or in any other
law for the time being in force. Necessarily, therefore, if it is construed and held that
the Presidential Order prohibits consideration of the employees from the feeder
category from other units then such a rule made by the Governor under the proviso to
Article 309 of the Constitution will have to be struck down. Then again in exercise of
powers under para 5(2) of the Presidential Order if the State Government makes any
provision, which is outside the purview of the authority of the Government under
para 5(2) of the Order itself, then the said provision also has to be struck down.
Having construed the Rules framed by the Governor under proviso to Article 309 of
the Constitution from the aforesaid standpoint, the conclusion is irresistible that the
said Rule to the extent indicated by the Tribunal is constitutionally invalid and its
conclusion is unassailable. In the case in hand, the impugned provisions do not
appear to have been framed in exercise of powers under para 5(2) of the Presidential
Order and as such the same being a Rule made under proviso to Article 309 of the
Constitution, the Presidential Order would prevail, as provided under Article
371-D(10) of the Constitution. Even if it is construed to be an order made under para
5(2) of the Presidential Order, then also the same would be invalid being beyond the
permissible limits provided under the said paragraph.
In this view of the matter, the Tribunal rightly held the provision to the extent it provides for
consideration of employees of the Factories and Boilers Units to be invalid, for the purpose of
promotion to the higher post in the Labour Unit and as such we see no justification for our
interference with the said conclusion of the Tribunal and the earlier judgment of this Court in
Sadanandam case, 1989 Supp. (1) SCC 574, must be held to have not been correctly decided. As a
consequence, so would be the case with Satyanarayana Rao case, (2000) 4 SCC 262.” (emphasis
supplied by us)Chebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

88. In S. Prakasha Rao and Anr. v. Commissioner of Commercial Taxes and Ors., (1990) 2 SCC 259,
this Court opined that once the President makes an order under Article 371D(1) and (2), the State
Government loses its inherent power to deal with matters relating to services, it may exercise its
powers on matters dealt with the Presidential Order only in the manner specified in the order. This
Court observed:
“19. It is seen that the order was made pursuant to the power given to the President
under Article 371-D, which is a special provision made under the Constitution
(Thirty-second Amendment) Act, 1973 peculiar to the State of Andhra Pradesh due to
historical background. Therefore, the State Government have no inherent power in
creating a zone or organising local cadre within the zones except in accordance with
the provisions made in the Andhra Pradesh Public Employment (Organisation of
Local Cadres and Regulation for Direct Recruitment) Order. It is true that the clause
‘or constituted otherwise’ defined in paragraph 2(e) is of wide import, but is only
relatable to the power given by the President to the State Government to organise
local cadre. Paragraph 3(1) is the source of that power, but the exercise thereof is
hedged with a limitation of twelve months from the date of commencement of the
Order. Therefore, the power to organise class or classes of post of civil services of, and
class or classes of civil posts, under the State into different local cadres should be
exercised by the State Government in accordance with paragraph 3(1) before the
expiry of the twelve months from October 20, 1975. If the exercise of the power is not
circumscribed within limitation, certainly under General Clauses Act the power could
be exercised from time to time in organising local cadres to meet the administrative
exigencies. The prescription of limitation is a fetter put on the exercise of power by
the State Government. Obviously, realising this reality and the need to organise local
cadres, subsequent thereto the amendment was made and was published in GOMs
No. 34 G.A. dated January 24, 1981 introducing proviso to paragraph 3(1).
Thereunder, notwithstanding the expiry of the said period, the President alone has
been given power to organise local cadres in respect of class or classes of posts in civil
services and class or classes of civil posts, under the State. That too subject to the
conditions precedent laid therein. Thus, it is the President and the President alone
who has been given power under proviso by an order to require the State
Government to organise the local cadres in relation to any class or classes of posts in
the civil services of and class or classes of civil posts under the State into different
local cadres. It could be considered in yet another perspective. Paragraph 2(e)
indicates that President himself may create a local cadre instead of requiring the
State Government to organise local cadre. For instance, paragraph 3(6) empowered
the President to create local cadre for the city of Hyderabad. Similarly, under proviso
to paragraph 3(1) the President may require the State Government to create a local
cadre within a zone. So the phrase ‘or constituted otherwise’ cannot be understood de
hors the scheme of the Presidential Order. No doubt in common parlance, the word
‘otherwise’ is of ‘wide’ amplitude. This Court in K.K. Kochuni v. States of Madras and
Kerala, AIR 1960 SC 1080, Subba Rao, J., as he then was, speaking per majority inChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

paragraph 50 while construing the word ‘otherwise’ held that it must be confined to
things analogous to right or contract such as lost grant, immemorial user etc. The
word ‘otherwise’ in the context only means whatever may be the origin of the receipt
of maintenance. The ratio thereunder cannot be extended in the contextual
circumstances obtainable on the facts in this case. Similarly, in Lilavati Bai v. State of
Bombay, AIR 1957 SC 521, Sinha J., as he then was, speaking for the Constitution
Bench interpreting Explanation (a) to Section 6 of Bombay Land Requisition Act,
1948, as amended in 1950 and repelling the application of ejusdem generis doctrine
laid the law thus:
“The legislature has been cautious and thoroughgoing enough to bar all avenues of
escape by using the words ‘or otherwise’. Those words are not words of limitation but
of extension so as to cover all possible ways in which a vacancy may occur. Generally
speaking a tenant’s occupation of his premises ceases when his tenancy is terminated
by acts of parties or by operation of law or by eviction by the landlord or by
assignment or transfer of the tenant’s interest. But the legislature, when it used the
words ‘or otherwise’, apparently intended to cover other cases which may not come
within the meaning of the preceding clauses, for example, a case where the tenant’s
occupation has ceased as a result of trespass by a third party. The legislature, in our
opinion, intended to cover all possible cases of vacancy occurring due to any reasons
whatsoever.” Thus, contextual interpretation to the words ‘or otherwise’ was given by
this Court. Therefore, the phrase ‘constituted otherwise’ is to be understood in that
context and purpose which Article 371-D and the Presidential Order seek to achieve.
If the interpretation given by the appellants is given acceptance it amounts to giving
blanket power to the State Government to create local cadres at its will tending to
defeat the object of Article 371-D and the Presidential Order. Accordingly, we have no
hesitation to reject the interpretation of wider connotation. The ratio in these
decisions does not render any assistance to the appellants.
20. Similarly, the power given to the State Government in sub-
paragraph (7) of paragraph 3 of the Order is only to organise a separate cadre in respect of any
category of posts in any department when more than one cadre in respect of such category exists in
each department; so the State Government may organise one cadre when more than one cadre in
respect of different categories of posts exist in a zone under paragraph 3(1) of the Order. It is clear
when we see the language in paragraph 3(7) which says that: “nothing in this order shall be deemed
to prevent the State from organising”. Take for instance while creating local cadre co-terminus with
the administrative control of the Deputy Commissioner, Commercial Taxes, local cadre for Senior
Assistants may be created. It is also made manifest by instructions 7 and 9(e) of the instructions
contained in GOMs No. 728 GAD dated November 1, 1975. But, as stated earlier, it is only for the
purpose of administrative convenience, not for the purpose of recruitment, seniority or promotion
etc., as the case may be. Thus, we have no hesitation to hold that the creation of a division and
maintaining separate seniority of Junior Assistants and Senior Assistants for Adilabad and
Warangal Divisions are illegal, contrary to order issued in GOMs No. 581 and the Andhra PradeshChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

Employment (Organisation of Local Cadre and Regulation of Direct Recruitment) Order, 1975. The
single member of the Tribunal in R.P. No. 101 of 1982 dated April 1, 1982 did not consider the effect
of the order in proper perspective and is illegal.” (emphasis supplied by us) No doubt about it that
the provision to have overriding effect shall have any nexus as to the subject matter of other
provisions.
89. The main question to be considered is whether there is any conflict between the Presidential
Order and the G.O. Ms. No. 3 of 2000 issued under the order of the Governor under Para 5(1) of the
Fifth Schedule of the Constitution. Considering the geographical disparity in public employment,
Article 371D was inserted in the Constitution, providing candidates from certain districts/zones to
form the local cadre for different posts for different parts of the States. The Presidential Order was
issued providing district/zone for local cadre, on the other hand, the order issued by the Governor
has reserved all the posts of teachers in the Scheduled Areas for Schedule Tribe candidates. The
aspiring candidates of the district/zone in the Scheduled Area cannot apply for the post of teachers
in the district as 100 per cent reservation was made vide G.O.Ms. No. 3 of 2000 by the Governor. It
is also not disputed that aspiring candidates cannot apply outside the district/zone because of the
restrictions under Article 371D of the Constitution. As there is 100 per cent reservation provided for
the Scheduled Tribes in the Scheduled Areas, other candidates of Scheduled Castes, General and
Other Backward Classes category cannot apply at all in other districts. They are being denied the
opportunity of getting the employment as against the posts in question. Thus, the order issued by
the Governor is clearly in conflict with the Presidential Order issued under Article 371D. The
candidates of local areas or other candidates except for Scheduled Tribes have been deprived of the
opportunity of seeking public employment because of the order issued by the Governor, and they
cannot apply outside the local area in view of the Presidential notification. The Presidential
notification intends that they have to apply within the district, and the Governor's notification takes
away that right. Thus, there is a clear repugnancy between the notification issued by the President
and that subsequent order issued by the Governor in the exercise of powers under Para 5, Fifth
Schedule of the Constitution. It is not possible to harmonise both the notifications. Apart from that,
there is total deprivation. It is not factually correct that Presidential Order did not deal with
Scheduled Areas. The Presidential Order applied to the entire State and carved out a special
provision that applies with a non−obstante clause.
90. The Governor is competent to issue an order which is not in conflict with the Presidential Order.
The Governor issued the order when the Presidential Order was already in force in the entire State.
The Governor could not have issued the order in derogation to the Presidential Order. In our
opinion, 100 per cent reservation could not have been provided as that violates the Presidential
Order. In Re: Question No.2: whether 100% reservation is permissible under the Constitution?
91. The Constitution has provided for justice – social, economic and political; liberty of thought,
expression, belief, faith and worship; equality of status and opportunity; and to promote among
them all fraternity assuring the dignity of the individual and the unity and integrity of the Nation.
The framers of the Constitution have taken great care and deliberation so that it reflects the high
purpose and noble objectives. It aims at the formation of an egalitarian order, free from
exploitation, the fundamental equality of humans and to provide support to the weaker sections ofChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

the society and wherefrom there is a disparity to make them equal by providing protective
discrimination. The Constitution in the historic perspective leans in favour of providing equality and
those aims sought to be achieved by the Constitution by giving special protection to the socially and
economically backward classes by providing a protective umbrella for their social emancipation and
providing them equal justice, ensuring the right of equality by providing helping hand to them by
way of reservation measures. Article 14 guarantees equality before the law or the equal protection of
the laws. Be it a matter of distribution of State largesse; the Government is obligated to follow the
constitutionalism. State action cannot be arbitrary and discriminatory and cannot be guided by
extraneous considerations, which is opposed to equality. The concept of equality is the antithesis of
arbitrariness in action. There cannot be any legislation in violation of equality, which violates the
basic concept of equality as enshrined in Part III of the Constitution. An administrative order has to
be tested on the anvil of non−arbitrariness. Any action of the legislature, administrative or quasi−
judicial, is open to challenge if it is in conflict with the Constitution or the Act and applicable general
principles of law. The protective discrimination of persons residing in backward areas is
permissible, as held in M.P. Oil Extraction & Anr. v. State of M.P. & Ors., (1997) 7 SCC 592. The
industrial units were set up in backward areas at the instance of the Government. Special treatment
was given to them for the supply of sal seeds at a concessional rate of royalty. It was held in the
aforesaid decision that the distinction was reasonable.
92. The concept of equality cannot be pressed to commit another wrong. The concept of equality
enshrined in Article 14 of the Constitution is a positive concept. It is not a concept of negative
equality. It cannot be used to perpetuate an illegality. Equity cannot be applied when it arises out of
illegality. The doctrine of equity would not be attracted when the benefits were conferred on the
basis of illegality, as held in Usha Mehta v. Government of Andhra Pradesh, (2012) 12 SCC 419;
John Vallamattom v. Union of India, (2003) 6 SCC 611; General Manager, Uttranchal Jal Sansthan
v. Laxmi Devi, (2009) 7 SCC 205, State of West Bengal v. Debashish Mukherjee, AIR 2011 SC 3667.
93. Article 14 is to be understood in the light of the Directive Principles, as observed in Indra
Sawhney (supra). The classification made cannot be unreasonable. It can be based on a reasonable
basis. It cannot be arbitrary but must be rational. It should be based on intelligible differentia and
must have rational nexus to the object sought to be achieved. There are various fields in which
Article 14 has extended its reach and ambit. The provision is very deep and pervasive. It kills the evil
of discrimination to bring equality.
94. Article 15 of the Constitution prohibits discrimination based on religion, race, caste, sex, or place
of birth. Article 15(4) provides that the State can make any special provision for the advancement of
socially and economically backward classes or scheduled castes and scheduled tribes. Similarly,
Article 15(5) enables the State to make special provisions for educationally backward classes,
Scheduled Castes, and Scheduled Tribes for admission to educational institutions, including private
educational institutions, whether aided or unaided by the State. Article 15(6) enables the State
Government to make any special provision for the advancement of economically weaker sections of
citizens other than the classes mentioned in Article 15(4) and 15(5). The State can also make a
provision under Article 15(6)(b) for the advancement of economically weaker sections of the citizens
relating to their admission to educational institutions, including private educational institutions,Chebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

whether aided or unaided except for the minority educational institutions. The State has the power
to notify economically weaker sections from time to time based on family income and other
indicators of economic disadvantage.
95. Article 16 deals with equality of opportunity in matters of public employment, which ensures
equality of opportunity for all citizens in matters relating to employment or appointment to any
office under the State. Article 16(2) provides that no citizen shall be discriminated on the grounds of
religion, race, caste, sex, descent, place of birth, residences or any of them and be ineligible for, or
discriminated against in respect of any employment or office under the State. Article 16(3) enables
the Parliament to make law regarding a class or classes of employment or appointment to an office
providing for any requirement as to residence within that State or Union Territory before such
employment or appointment. Under Article 16(4), State can provide reservation in appointments or
posts in favour of any backward class of citizens which, in its opinion, is not adequately represented
in services under State. Directive Principles of State Policy enjoin a duty upon the State to secure a
social order for the promotion and welfare of the people, to promote justice – social, economic, and
political; and all institutions of the national life have to endeavour furtherance of the above−avowed
purposes. The State has to strive to minimise inequalities of income, eliminate the status of
opportunities not only amongst individuals but also groups of people engaged in different areas, and
engaged in different professions. Article 39(b) and
(c) aim at the distribution of State largesse and control of the material resources of the community
as best to sub−serve the common good, and that the operation of the economic system does not
result in the concentration of wealth and means of production to the collective detriment. Article 47
of the Constitution deals with the duty of the State to raise the level of nutrition and the standard of
living and to improve public health. Article 51A (a) to (k) contains the fundamental duties, and every
citizen of India must promote harmony and the spirit of common brotherhood amongst all the
people of India transcending religious, linguistic and regional or sectional diversities; to renounce
practices derogatory to the dignity of women. Article 51A(j) confers a duty to strive towards in all
spheres of individual and collective activity so that the nation steadily rises to higher levels of
endeavours and achievement. Article 51A has been used as an interpretative tool where the
constitutionality of an Act is challenged. The Court considered the duties in Mohan Kumar
Singhania & Ors. v. Union of India & Ors., 1992 Supp. (1) SCC 594 thus:
“41. In this regard, it will be worthwhile to refer to Article 51-A in Part IV-A under the
caption 'Fundamental Duties' added by the Constitution (Forty-second Amendment)
Act, 1976, in accordance with the recommendations of the Swaran Singh Committee.
The said article contains a mandate of the Constitution that it shall be the duty of
every citizen of India to do the various things specified in clauses (a) to (j) of which
clause (j) commands that it is the duty of every citizen of India to strive towards
excellence in all spheres of individual and collective activity so that the nation
constantly rises to higher levels of endeavour and achievement.
42. In our view, the effort taken by the government in giving utmost importance to
the training programme of the selectees so that this higher civil service being theChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

topmost service of the country is not wasted and does not become fruitless during the
training period is in consonance with the provisions of Article 51-A(j).”
96. The Constitution of India contains special provisions for scheduled castes and scheduled tribes
in Part XVI. Article 330 provides for reservation of seats for scheduled castes and scheduled tribes
in the House of the People. Article 332 provides for “reservation of seats” for scheduled castes and
scheduled tribes in the legislative assemblies of the States. Article 334 provides for “reservation of
seats” and special representation to “cease after a certain period." The provision was made initially
for a lesser period. After that, it was extended for 20 years, 30 years, 40 years, 50 years, 60 years,
and now enhanced to 70 years by amendment made in 2019. Article 335 provides that claims of the
members of the scheduled castes and the scheduled tribes, for maintenance of efficiency of
administration, in the making of appointments to services and posts in connection with the affairs of
the Union or a State; and State can relax criteria in qualifying marks in any examination or lower
standards of evaluation, for reservation in matters of promotion to any class or classes of services or
posts in connection with the affairs of the Union or a State.
97. Article 338 provides for constitution of National Commission for Scheduled Castes to investigate
and monitor all matters relating to the safeguards provided for the scheduled castes and to evaluate
the working of such safeguards; to inquire into specific complaints concerning the deprivation of
rights and safeguards of the scheduled castes; to participate and advise on the planning process of
socio− economic development of the scheduled castes and to evaluate the progress of their
development under the Union and any State; to present to the President, annually and at such other
times as the Commission may deem fit, reports upon the working of those safeguards are provided
in Article 338(5)(d). Article 338(6) requires that the President shall cause all such reports to be laid
before each House of Parliament and a memorandum explaining action taken or proposed to be
taken on recommendations relating to the Union and the reasons for non−acceptance, if any, of any
of such recommendations. A copy of the report has to be forwarded to the Governor to be dealt with
in terms of Article 338(7). The Commission has the power of inquiring into any complaint as
specified in Article 338(8), and Article 338A provides for the constitution of a National Commission
for Scheduled Tribes. Similar provisions are contained for National Commission for Scheduled
Tribes in Article 338A. Article 339 envisages control of the Union over the administration of
scheduled areas and the welfare of the scheduled tribes. Article 340 deals with the appointment of a
Commission to investigate the conditions of backward classes.
98. Under Article 341 the President concerning any State or Union territory, may specify the castes,
races or tribes or parts of or groups within castes, races or tribes which shall for the Constitution, be
deemed to be scheduled castes in relation to that State or Union territory, as the case may be. Article
341(2) confers power on the Parliament to include in or exclude from the list of scheduled castes
specified in a notification issued under Article 342(1) any caste, race or tribe or part of or group
within any caste, race or tribe, and any subsequent notification shall not vary the same. Power can
be exercised only once. Article 342 contains a provision in respect of scheduled tribes. The President
may, by notification specify the tribe or tribal communities or parts of or groups within tribes or
tribal communities which shall for the Constitution, be deemed to be scheduled tribes in relation to
that State or the Union territory, as the case may be. The Parliament may include in or exclude fromChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

the list of scheduled tribes, any tribe or tribal community or part of or group within any tribe or
tribal community, but save as aforesaid, any subsequent notification shall not vary a notification
issued under the said clause. Thus, the power to vary can be exercised only once. A similar provision
has been added in Article 342A concerning socially and educationally backward classes.
99. Article 243T deals with reservation of seats for scheduled castes and scheduled tribes in every
municipality in proportion to the population of the scheduled castes or scheduled tribes in the
municipal area to the total population of that area and provides for rotation of seats. Article 243D
provides for reservation of seats for scheduled castes and scheduled tribes in every Panchayat, and
Panchayat is constituted in every State, Panchayat at the village, intermediate and district levels as
provided in Article 243B. It is mandatory to constitute such Panchayat at the district level in a State
having a population exceeding 20 lakhs.
100. Article 244, with which we are concerned in the present matter, provides for the administration
of scheduled areas and tribal areas. The Constitution is spatially it provides Scheduled Areas under
Article 244, Schedule V, Schedule VI, and special provisions have been made concerning various
States under Articles 370, 371A to 371J. For better administration, the Constitution has divided
India into States and Union Territories as per Articles 3 and 4.
101. Concerning classification in a constitutional dispensation for scheduled castes and scheduled
tribes, Dr. Ambedkar’s speech in the Constituent Assembly Debates, page 979, 11th at pages 979−80
is referred to by Dr. Dhawan. Same is extracted hereunder:
"We must begin by acknowledging the fact that there is a complete absence of two
things in Indian Society. One of these is equality. On the social plane, we have in
India a society based on the principle of graded inequality, which means elevation for
some and degradation for others. On the economic plane, we have a society in which
there are some who have immense wealth as against many who live in abject poverty.
On the 26 th of January, we are going to enter into a life of contradictions. In politics,
we will have equality and in social and economic life we will have inequality. In
politics we will be recognizing the principle of one man one vote one value. In our
social and economic life we shall, by reason of our social and economic structure,
continue to defy the principle of one man one vote one value. How long shall we
continue to live this life of contradictions? How long shall we continue to deny
equality in our social and economic life? If we continue to deny it for long, we shall do
so by putting out political democracy in peril. We must remove this contradiction at
the earliest possible moment or else those suffer from inequality will blow up the
structure of political democracy which this Assembly has so laboriously built up.
The second thing we are wanting in is recognition of the principle of fraternity. What
does fraternity mean? Fraternity means a sense of common brotherhood of all
Indians - if Indians think of themselves as being one people. It is the principle which
gives unity and solidarity to social life… The sooner we realize that we are not as yet a
nation and seriously think of ways and means of realizing this goal, the better forChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

us….. For fraternity can be a fact, only where there is a nation. Without fraternity,
equality and liberty will be no deeper than a coat of paint."
102. The scheduled castes and scheduled tribes have been provided with special measures to make
them equal to the others. Efforts have been made to protect their land and property by enacting
various laws. Special provisions have also been carved out to preserve their human dignity with
respect, in the shape of trusts in Scheduled Castes and Scheduled Tribes (Prevention of Atrocities)
Act, 1989. The scheduled castes and scheduled tribes were making a struggle for freedom and
various rights in the country. They suffered discrimination; fruits of development have not
percolated down to them. They remained an unequal and vulnerable section of the society and
treated for centuries as outcasts socially. That is the basis for providing them reservation and special
treatment to provide them upliftment and to eradicate their sufferings. We have not been able to
eradicate untouchability in the real sense so far and to provide safety and security to downtrodden
class and to ensure that their rights are preserved and protected, and they equally enjoy frugal
comforts of life.
103. Concerning tribals, we see that there are several schemes for their upliftment, but we still see
that at certain places, they are still kept in isolation and are not even able to get basic amenities,
education, and frugal comforts of life. These classes have an equal right to life available to all human
beings. Considering the social backwardness, which includes economic aspects also, these are the
classes that have suffered historic disabilities arising from discrimination, poverty, educational
backwardness to provide them empowerment and to make them part of the mainstream. Special
provisions have been carved out in the Constitution. Article 16(4) is not an exception to Article 16(1)
being part of equality. The reservation can be rectified. Section 16(4) aims at group backwardness.
Reservations are provided due to discrimination and disadvantages suffered by the backward
classes, scheduled castes and scheduled tribes for sharing the State power.
104. The concept of sharing State power was considered in Indra Sawhney (supra). Sawant, J., in his
opinion, dealt with the idea of sharing of State power thus:
“483. That only economic backwardness was not in the contemplation of the
Constitution is made further clear by the fact that at the time of the First Amendment
to the Constitution which added clause (4) to Article 15 of the Constitution, one of the
Members, Prof. K.T. Shah wanted the elimination of the word “classes” in and the
addition of the word “economically” to the qualifiers of the term “backward classes”.
This Amendment was not accepted. Prime Minister Nehru himself stated that the
addition of the word “economically” would put the language of the article at variance
with that of Article 340. He added that “socially” is a much wider term including
many things and certainly including “economically”. This shows that economic
consideration alone as the basis of backwardness was not only not intended but
positively discarded.” (emphasis supplied) Justice Jeevan Reddy dealt with the same,
thus:Chebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

“694. The above material makes it amply clear that the objective behind clause (4) of
Article 16 was the sharing of State power.
The State power which was almost exclusively monopolised by the upper castes i.e., a
few communities, was now sought to be made broad-based. The backward
communities who were till then kept out of apparatus of power, were sought to be
inducted thereinto and since that was not practicable in the normal course, a special
provision was made to effectuate the said objective. In short, the objective behind
Article 16(4) is empowerment of the deprived backward communities — to give them
a share in the administrative apparatus and in the governance of the community.
750. Dr Rajeev Dhavan, learned counsel appearing for Srinarayana Dharma
Paripalana Yogam (an association of Ezhavas in Kerala) submitted that Articles 16(4)
and 15(4) occupy different fields and serve different purposes. Whereas Article 15(4)
contemplates positive action programmes, Article 16(4) enables the State to
undertake schemes of positive discrimination. For this reason, the class of intended
beneficiaries under both the clauses is different. The social and educational
backwardness which is the basis of identifying backwardness under Article 15(4) is
only partly true in the case of ‘backward class of citizens’ in Article 16(4). The
expression “any backward class of citizens” occurring in Article 16(4) must be
understood in the light of the purpose of the said clause namely, empowerment of
those groups and classes which have been kept out of the administration — classes
which have suffered historic disabilities arising from discrimination or disadvantage
or both and who must now be provided entry into the administrative apparatus. In
the light of the fact that the Scheduled Castes and Scheduled Tribes were also
intended to be beneficiaries of Article 16(4) there is no reason why caste cannot be an
exclusive criterion for determining beneficiaries under Article 16(4). Counsel
emphasised the fact that Article 16(4) speaks of group protection and not individual
protection.
788. Further, if one keeps in mind the context in which Article 16(4) was enacted it
would be clear that the accent was upon social backwardness. It goes without saying
that in the Indian context, social backwardness leads to educational backwardness
and both of them together lead to poverty — which in turn breeds and perpetuates
the social and educational backwardness.
They feed upon each other constituting a vicious circle. It is a well-known fact that till independence
the administrative apparatus was manned almost exclusively by members of the ‘upper’ castes. The
Shudras, the Scheduled Castes and the Scheduled Tribes and other similar backward social groups
among Muslims and Christians had practically no entry into the administrative apparatus. It was
this imbalance which was sought to be redressed by providing for reservations in favour of such
backward classes. In this sense Dr Rajeev Dhavan may be right when he says that the object of
Article 16(4) was “empowerment” of the backward classes. The idea was to enable them to share the
state power. We are, accordingly, of the opinion that the backwardness contemplated by ArticleChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

16(4) is mainly social backwardness. It would not be correct to say that the backwardness under
Article 16(4) should be both social and educational. The Scheduled Tribes and the Scheduled Castes
are without a doubt backward for the purposes of the clause; no one has suggested that they should
satisfy the test of social and educational backwardness. It is necessary to state at this stage that the
Mandal Commission appointed under Article 340 was concerned only with the socially and
educationally backward classes contemplated by the said article. Even so, it is evident that social
backwardness has been given precedence over others by the Mandal Commission — 12 out of 22
total points. Social backwardness — it may be reiterated — leads to educational and economic
backwardness. No objection can be, nor is taken, to the validity and relevancy of the criteria adopted
by the Mandal Commission. For a proper appreciation of the criteria adopted by the Mandal
Commission and the difficulties in the way of evolving the criteria of backwardness, one must read
closely Chapters III and XI of Volume I along with Appendixes XII and XXI in Volume II. Appendix
XII is the Report of the Research Planning Team of the Sociologists while Appendix XXI is the ‘Final
List of Tables’ adopted in the course of socio-educational survey. In particular, one may read paras
11.18 to 11.22 in Chapter XI, which are quoted hereunder for ready reference:
“11.18. Technical Committee constituted a Sub- Committee of Experts (Appendix-20,
Volume II) to help the Commission prepare ‘Indicators of Backwardness’ for
analysing data contained in computerised tables. After a series of meetings and a lot
of testing of proposed indicators against the tabulated data, the number of tables
actually required for the Commission’s work was reduced to 31 (Appendix-21,
Volume II). The formulation and refinement of indicators involved testing and
validation checks at every stage.
11.19. In this connection, it may be useful to point out that in social sciences no
mathematical formulae or precise bench-marks are available for determining various
social traits. A survey of the above type has to tread warily on unfamiliar ground and
evolve its own norms and bench-
marks. This exercise was full of hidden pitfalls and two simple examples are given below to illustrate
this point. 11.20. In Balaji case the Supreme Court held that if a particular community is to be
treated as educationally backward, the divergence between its educational level and that of the State
average should not be marginal but substantial. The Court considered 50% divergence to be
satisfactory. Now, 80% of the population of Bihar (1971 Census) is illiterate. To beat this percentage
figure by a margin of 50% will mean that 120% members of a caste/class should be illiterates. In fact
it will be seen that in this case even 25% divergence will stretch us to the maximum saturation point
of 100%.
11.21. In the Indian situation where vast majority of the people are illiterate, poor or backward, one
has to be very careful in setting deviations from the norms as, in our conditions, norms themselves
are very low. For example, Per Capita Consumer Expenditure for 1977-78 at current prices was Rs
991 per annum. For the same period, the poverty line for urban areas was at Rs 900 per annum and
for rural areas at Rs 780. It will be seen that this poverty line is quite close to the Per Capita
Consumer Expenditure of an average Indian. Now following the dictum of Balaji case, if 50%Chebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

deviation from this average Per Capita Consumer Expenditure was to be accepted to identify
‘economically backward’ classes, their income level will have to be 50% below the Per Capita
Consumer Expenditure i.e. less than Rs 495.5 per year. This figure is so much below the poverty line
both in urban and rural areas that most of the people may die of starvation before they qualify for
such a distinction.
11.22. In view of the above, ‘Indicators for Backwardness’ were tested against various cut-off points.
For doing so, about a dozen castes well-known for their social and educational backwardness were
selected from amongst the castes covered by our survey in a particular State. These were treated as
‘Control’ and validation checks were carried out by testing them against ‘Indicators’ at various
cut-off points. For instance, one of the ‘Indicators’ for social backwardness is the rate of student
drop-outs in the age group 5-15 years as compared to the State average. As a result of the above
tests, it was seen that in educationally backward castes this rate is at least 25% above the State
average. Further, it was also noticed that this deviation of 25% from the State average in the case of
most of the ‘Indicators’ gave satisfactory results. In view of this, wherever an ‘Indicator’ was based
on deviation from the State average, it was fixed at 25%, because a deviation of 50% was seen to give
wholly unsatisfactory results and, at times, to create anomalous situations.” (emphasis supplied by
us)
(a). In Indra Sawhney (supra), the Court held that reservation is not a proportionate representation
but adequate, thus:
807. We must, however, point out that clause (4) speaks of adequate representation
and not proportionate representation.
Adequate representation cannot be read as proportionate representation. Principle of proportionate
representation is accepted only in Articles 330 and 332 of the Constitution and that too for a limited
period. These articles speak of reservation of seats in Lok Sabha and the State legislatures in favour
of Scheduled Tribes and Scheduled Castes proportionate to their population, but they are only
temporary and special provisions. It is therefore not possible to accept the theory of proportionate
representation though the proportion of population of backward classes to the total population
would certainly be relevant. Just as every power must be exercised reasonably and fairly, the power
conferred by clause (4) of Article 16 should also be exercised in a fair manner and within reasonable
limits — and what is more reasonable than to say that reservation under clause (4) shall not exceed
50% of the appointments or posts, barring certain extraordinary situations as explained hereinafter.
From this point of view, the 27% reservation provided by the impugned Memorandums in favour of
backward classes is well within the reasonable limits. Together with reservation in favour of
Scheduled Castes and Scheduled Tribes, it comes to a total of 49.5%. In this connection, reference
may be had to the Full Bench decision of the Andhra Pradesh High Court in V. Narayana Rao v.
State of A.P., striking down the enhancement of reservation from 25% to 44% for OBCs. The said
enhancement had the effect of taking the total reservation under Article 16(4) to 65%.
(b). The expression ‘socially backward’ holds the key to define backward as held in Indra Sawhney
(supra):Chebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

“774. In our opinion too, the words “class of citizens — not adequately represented in
the services under the State” would have been a vague and uncertain description. By
adding the word “backward” and by the speeches of Dr Ambedkar and Shri K.M.
Munshi, it was made clear that the “class of citizens … not adequately represented in
the services under the State” meant only those classes of citizens who were not so
represented on account of their social backwardness.”
(c). In Indra Sawhney (supra), the Court further laid down that reservation are not
anti−meritarian. Following is the relevant discussion:
“832. In Balaji and other cases, it was assumed that reservations are necessarily
anti-meritarian. For example, in Janki Prasad Parimoo, it was observed, "it is implicit
in the idea of reservation that a less meritorious person be preferred to another who
is more meritorious." To the same effect is the opinion of Khanna, J in Thomas,
though it is a minority opinion. Even Subba Rao, J, who did not agree with this view,
did recognize some force in it. In his dissenting opinion in Devadasan while holding
that there is no conflict between Article 16(4) and Article 335, he did say, "it is
inevitable in the nature of reservation that there will be a lowering of standards to
some extent," but, he said, on that account, the provision cannot be said to be bad,
inasmuch as in that case, the State had, as a matter of fact, prescribed minimum
qualifications, and only those possessing such minimum qualifications were
appointed. This view was, however, not accepted by Krishna Iyer, J in Thomas. He
said: (SCC p. 366, para 132) “[E]fficiency means, in terms of good government, not
marks in examinations only, but responsible and responsive service to the people. A
chaotic genius is a grave danger in public administration. The inputs of efficiency
include a sense of belonging and of accountability which springs in the bosom of the
bureaucracy (not pejoratively used) if its composition takes in also the weaker
segments of ‘We, the people of India’. No other understanding can reconcile the claim
of the radical present and the hangover of the unjust past.”
833. A similar view was expressed in Vasanth Kumar by Chinnappa Reddy, J. The
learned Judge said (SCC p. 739, para
36) “[T]he mere securing of high marks at an examination may not necessarily mark
out a good administrator. An efficient administrator, one takes it, must be one who
possesses among other qualities the capacity to understand with sympathy and,
therefore, to tackle bravely the problems of a large segment of population
constituting the weaker sections of the people. And, who better than the ones
belonging to those very sections? Why not ask ourselves why 35 years after
Independence, the position of the Scheduled Castes, etc. has not greatly improved? Is
it not a legitimate question to ask whether things might have been different, had the
District Administrators and the State and Central Bureaucrats been drawn in larger
numbers from these classes? Courts are not equipped to answer these questions, but
the courts may not interfere with the honest endeavours of the Government to findChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

answers and solutions. We do not mean to say that efficiency in the civil service is
unnecessary or that it is a myth. All that we mean to say is that one need not make a
fastidious fetish of it.”
834. It is submitted by the learned counsel for petitioners that reservation necessarily
means appointment of less meritorious persons, which in turn leads to lowering of
efficiency of administration. The submission, therefore, is that reservation should be
confined to a small minority of appointments/posts, — in any event, to not more than
30%, the figure referred to in the speech of Dr Ambedkar in the Constituent
Assembly. The mandate of Article 335, it is argued, implies that reservations should
be so operated as not to affect the efficiency of administration. Even Article 16 and
the directive of Article 46, it is said, should be read subject to the aforesaid mandate
of Article
335.
835. The respondents, on the other hand, contend that the marks obtained at the
examination/test/interview at the stage of entry into service is not an indicium of the inherent merit
of a candidate. They rely upon the opinion of Douglas, J in DeFunis where the learned Judge
illustrates the said aspect by giving the example of a candidate coming from disadvantaged sections
of society and yet obtaining reasonably good scores — thus manifesting his “promise and potential”
— vis-a-vis a candidate from a higher strata obtaining higher scores. (His opinion is referred to in
para 716.) On account of the disadvantages suffered by them and the lack of opportunities, — the
respondents say — members of backward classes of citizens may not score equally with the members
of socially advanced classes at the inception but in course of time, they would. It would be fallacious
to presume that nature has endowed intelligence only to the members of the forward classes. It is to
be found everywhere. It only requires an opportunity to prove itself. The directive in Article 46 must
be understood and implemented keeping in view these aspects, say the respondents.
836. We do not think it necessary to express ourselves at any length on the correctness or otherwise
of the opposing points of view referred to above. (It is, however, necessary to point out that the
mandate — if it can be called that — of Article 335 is to take the claims of members of SC/ST into
consideration, consistent with the maintenance of efficiency of administration. It would be a
misreading of the article to say that the mandate is maintenance of efficiency of administration.)
Maybe, efficiency, competence and merit are not synonymous concepts; maybe, it is wrong to treat
merit as synonymous with efficiency in administration and that merit is but a component of the
efficiency of an administrator. Even so, the relevance and significance of merit at the stage of initial
recruitment cannot be ignored. It cannot also be ignored that the very idea of reservation implies
selection of a less meritorious person. At the same time, we recognise that this much cost has to be
paid, if the constitutional promise of social justice is to be redeemed. We also firmly believe that
given an opportunity, members of these classes are bound to overcome their initial disadvantages
and would compete with — and may, in some cases, excel — members of open competition. It is
undeniable that nature has endowed merit upon members of backward classes as much as it has
endowed upon members of other classes and that what is required is an opportunity to prove it. ItChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

may not, therefore, be said that reservations are anti-meritarian. Merit there is even among the
reserved candidates and the small difference, that may be allowed at the stage of initial recruitment
is bound to disappear in course of time. These members too will compete with and improve their
efficiency along with others.
837. Having said this, we must append a note of clarification. In some cases arising under Article 15,
this Court has upheld the removal of minimum qualifying marks, in the case of Scheduled
Caste/Scheduled Tribe candidates, in the matter of admission to medical courses. For example, in
State of M.P. v. Nivedita Jain admission to medical course was regulated by an entrance test (called
Pre-Medical Test). For general candidates, the minimum qualifying marks were 50% in the
aggregate and 33% in each subject. For Scheduled Caste/Scheduled Tribe candidates, however, it
was 40% and 30% respectively. On finding that Scheduled Caste/Scheduled Tribe candidates equal
to the number of the seats reserved for them did not qualify on the above standard, the Government
did away with the said minimum standard altogether. The Government’s action was challenged in
this Court but was upheld. Since it was a case under Article 15, Article 335 had no relevance and was
not applied. But in the case of Article 16, Article 335 would be relevant and any order on the lines of
the order of the Government of Madhya Pradesh (in Nivedita Jain) would not be permissible, being
inconsistent with the efficiency of administration. To wit, in the matter of appointment of Medical
Officers, the Government or the Public Service Commission cannot say that there shall be no
minimum qualifying marks for Scheduled Caste/Scheduled Tribe candidates, while prescribing a
minimum for others. It may be permissible for the Government to prescribe a reasonably lower
standard for Scheduled Castes/Scheduled Tribes/Backward Classes — consistent with the
requirements of efficiency of administration — it would not be permissible not to prescribe any such
minimum standard at all. While prescribing the lower minimum standard for reserved category, the
nature of duties attached to the post and the interest of the general public should also be kept in
mind.
838. While on Article 335, we are of the opinion that there are certain services and positions where
either on account of the nature of duties attached to them or the level (in the hierarchy) at which
they obtain, merit as explained hereinabove, alone counts. In such situations, it may not be
advisable to provide for reservations. For example, technical posts in research and development
organisations/departments/institutions, in specialities and super-specialities in medicine,
engineering and other such courses in physical sciences and mathematics, in defence services and in
the establishments connected therewith. Similarly, in the case of posts at the higher echelons e.g.,
Professors (in Education), Pilots in Indian Airlines and Air India, Scientists and Technicians in
nuclear and space application, provision for reservation would not be advisable.” (emphasis
supplied by us) This Court observed that some relaxation has to be granted consistent with the
requirement of administration, to do social justice, it would not be permissible not to prescribe any
minimum standard at all. This Court also observed that as to specialty in technical posts and
research development, medical engineering, defence services, physics, and mathematics, provision
for reservation would not be advisable.
(d). In Indra Sawhney (supra), the Court held that reservation could be provided by executive order,
thus:Chebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

“735. Shri K.K. Venugopal learned counsel for the petitioner in writ petition No. 930
of 1990 submits that the "provision" contemplated by clause (4) of Article 16 can be
made only by and should necessarily be made by the legislative wing of the State and
not by the executive or any other authority. He disputes the correctness of the
holding in Balaji negativing an identical contention. He submits that since the
provision made under Article 16(4) affects the fundamental rights of other citizens,
such a provision can be made only by the Parliament/Legislature. He submits that if
the power of making the “provision” is given to the executive, it will give room for any
amount of abuse. According to the learned counsel, the political executive, owing to
the degeneration of the electoral process, normally acts out of political and electoral
compulsions, for which reason it may not act fairly and independently. If, on the
other hand, the provision is to be made by the legislative wing of the State, it will not
only provide an opportunity for debate and discussion in the legislature where
several shades of opinion are represented but a balanced and unbiased decision free
from the allurements of electoral gains is more likely to emerge from such a
deliberating body. Shri Venugopal cites the example of Tamil Nadu where, according
to him, before every general election a few communities are added to the list of
backward classes, only with a view to winning them over to the ruling party. We are
not concerned with the aspect of what is ideal or desirable but with what is the proper
meaning to be ascribed to the expression ‘provision’ in Article 16(4) having regard to
the context. The use of the expression ‘provision’ in clause (4) of Article 16 appears to
us to be not without design. According to the definition of ‘State’ in Article 12, it
includes not merely the Government and Parliament of India and Government and
Legislature of each of the States but all local authorities and other authorities within
the territory of India or under the control of the Government of India which means
that such a measure of reservation can be provided not only in the matter of services
under the Central and State Governments but also in the services of local and other
authorities referred to in Article 12. The expression ‘Local Authority’ is defined in
Section 3(31) of the General Clauses Act. It takes in all municipalities, Panchayats
and other similar bodies. The expression ‘other authorities’ has received extensive
attention from the court. It includes all statutory authorities and other agencies and
instrumentalities of the State Government/Central Government. Now, would it be
reasonable, possible or practicable to say that the Parliament or the Legislature of the
State should provide for reservation of posts/appointments in the services of all such
bodies besides providing for in respect of services under the Central/State
Government? This aspect would become clearer if we notice the definition of “Law” in
Article 13(3)(a). It reads:
“13(3) In this article, unless the context otherwise requires,—
(a) “law” includes any Ordinance, order, bye-law, rule, regulation, notification,
custom or usage having in the territory of India the force of law; …”Chebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

736. The words “order”, “bye-law”, “rule” and “regulation” in this definition are
significant. Reading the definition of “State” in Article 12 and of “law” in Article
13(3)(a), it becomes clear that a measure of the nature contemplated by Article 16(4)
can be provided not only by the Parliament/Legislature but also by the executive in
respect of Central/State services and by the local bodies and “other authorities”
contemplated by Article 12, in respect of their respective services. Some of the local
bodies and some of the statutory corporations like universities may have their own
legislative wings. In such a situation, it would be unreasonable and inappropriate to
insist that reservation in all these services should be provided by
Parliament/Legislature. The situation and circumstances of each of these bodies may
vary.
The rule regarding reservation has to be framed to suit the particular situations. All this cannot
reasonably be done by Parliament/Legislature.
737. Even textually speaking, the contention cannot be accepted. The very use of the word
“provision” in Article 16(4) is significant. Whereas clauses (3) and (5) of Article 16 — and clauses (2)
to (6) of Article 19 — use the word “law”, Article 16(4) uses the world “provision”. Regulation of
service conditions by orders and rules made by the executive was a well- known feature at the time
of the framing of the Constitution. Probably for this reason, a deliberate departure has been made in
the case of clause (4). Accordingly, we hold, agreeing with Balaji, that the “provision” contemplated
by Article 16(4) can also be made by the executive wing of the Union or of the State, as the case may
be, as has been done in the present case. Balaji has been followed recently in Comptroller and
Auditor-General of India v. Mohan Lal Mehrotra. With respect to the argument of abuse of power by
the political executive, we may say that there is adequate safeguard against misuse by the political
executive of the power under Article 16(4) in the provision itself. Any determination of
backwardness is not a subjective exercise nor a matter of subjective satisfaction. As held herein — as
also by earlier judgments — the exercise is an objective one. Certain objective social and other
criteria have to be satisfied before any group or class of citizens could be treated as backward. If the
executive includes, for collateral reasons, groups or classes not satisfying the relevant criteria, it
would be a clear case of fraud on power.
Question 1(b):
Whether an executive order making a ‘provision’ under Article 16(4) is enforceable
forthwith?
738. A question is raised whether an executive order made in terms of Article 16(4) is effective and
enforceable by itself or whether it is necessary that the said “provision” is enacted into a law made
by the appropriate legislature under Article 309 or is incorporated into and issued as a Rule by the
President/Governor under the proviso to Article 309 for it to become enforceable? Mr Ram
Jethmalani submits that Article 16(4) is merely declaratory in nature, that it is an enabling provision
and that it is not a source of power by itself. He submits that unless made into a law by the
appropriate legislature or issued as a rule in terms of the proviso to Article 309, the “provision” soChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

made by the executive does not become enforceable. At the same time, he submits that the
impugned Memorandums must be deemed to be and must be treated as Rules made and issued
under the proviso to Article 309 of the Constitution. We find it difficult to agree with Shri
Jethmalani. Once we hold that a provision under Article 16(4) can be made by the executive, it must
necessarily follow that such a provision is effective the moment it is made. A Constitution Bench of
this Court in B.S. Yadav, (Y.V. Chandrachud, CJ, speaking for the Bench) has observed:
“Article 235 does not confer upon the High Court the power to make rules relating to
conditions of service of judicial officers attached to district courts and the courts
subordinate thereto. Whenever it was intended to confer on any authority the power
to make any special provisions or rules, including rules relating to conditions of
service, the Constitution has stated so in express terms. See for example Articles
15(4), 16(4), 77(3), 87(2), 118, 145(1), 146(1) and (2), 148(5), 166(3), 176(2), 187(3),
208, 225, 227(2) and (3), 229(1) and (2), 234, 237 and 283(1) and (2).”
740. It would, therefore, follow that until a law is made or rules are issued under
Article 309 with respect to reservation in favour of backward classes, it would always
be open to the Executive Government to provide for reservation of
appointments/posts in favour of Backward Classes by an executive order. We cannot
also agree with Shri Jethmalani that the impugned Memorandums should be treated
as Rules made under the proviso to Article 309. There is nothing in them suggesting
even distantly that they were issued under the proviso to Article 309. They were
never intended to be so, nor is that the stand of the Union Government before us.
They are executive orders issued under Article 73 of the Constitution read with clause
(4) of Article 16. The mere omission of a recital “in the name and by order of the
President of India” does not affect the validity or enforceability of the orders, as held
by this Court repeatedly.” (emphasis supplied by us)
(e). What is sought to be achieved by Articles 14 and 16 is equality and equality of
opportunity. In Indra Sawhney (supra), this Court emphasised that founding fathers
never envisaged reservation of all seats, and 50% shall be the rule. Some relaxation
may become imperative, but extreme caution is to be exercised, and a special case is
to be made for exceeding reservation more than 50%. This Court held:
“808. It needs no emphasis to say that the principal aim of Articles 14 and 16 is
equality and equality of opportunity and that clause (4) of Article 16 is but a means of
achieving the very same objective. Clause (4) is a special provision — though not an
exception to clause (1). Both the provisions have to be harmonised, keeping in mind
the fact that both are but the re- statements of the principle of equality enshrined in
Article 14. The provision under Article 16(4) — conceived in the interest of certain
sections of society — should be balanced against the guarantee of equality enshrined
in clause (1) of Article 16 which is a guarantee held out to every citizen and to the
entire society. It is relevant to point out that Dr Ambedkar himself contemplated
reservation being "confined to a minority of seats" (See his speech in ConstituentChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

Assembly, set out in para 693). No other member of the Constituent Assembly
suggested otherwise. It is, thus, clear that reservation of a majority of seats was never
envisaged by the Founding Fathers. Nor are we satisfied that the present context
requires us to depart from that concept.
809. From the above discussion, the irresistible conclusion that follows is that the
reservations contemplated in clause (4) of Article 16 should not exceed 50%.
810. While 50% shall be the rule, it is necessary not to put out of consideration
certain extraordinary situations inherent in the great diversity of this country and the
people. It might happen that in far-flung and remote areas the population inhabiting
those areas might, on account of their being out of the mainstream of national life
and in view of conditions peculiar to and characteristically to them, need to be
treated in a different way, some relaxation in this strict rule may become imperative.
In doing so, extreme caution is to be exercised and a special case made out.
811. In this connection it is well to remember that the reservations under Article
16(4) do not operate like a communal reservation. It may well happen that some
members belonging to, say, Scheduled Castes get selected in the open competition
field on the basis of their own merit; they will not be counted against the quota
reserved for Scheduled Castes; they will be treated as open competition candidates.”
(emphasis supplied by us)
105. It is apparent that despite more than 72 years of attaining independence, we are
not able to provide benefits to the bottom line, i.e., down−trodden and oppressed
classes. Benefits meant to such classes are not reaching them. The question is writ
large how to trickle down the benefits. Panchayat, Gram Sabha has been empowered,
but still, benefits are not reaching as envisaged. The right to information system has
to be strengthened at the village level. They must know how the money meant for
development has been utilised.
Transparency of administration is vital for the removal of corruption. They are required to be
motivated. They must know what is allocated to them and how it is spent. There is a need to improve
the system, ensuring the implementation of beneficial measures.
106. It was envisaged that social disparities, economic and backwardness should be wiped out
within a period of 10 years, but gradually, amendments have been made, and there is no review of
the lists nor the provisions of the reservation have come to an end. Instead, there is a demand to
increase them and to provide reservations within the reservation. It is very hard for any elected
government to have the political will to meet with the challenges arising out of the aforesaid
scenario. By grant of privileges and amenities, it was felt that the aspirations of socially and
economically backward classes would be met, and inequalities would diminish.Chebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

107. Reservation provided to scheduled tribes and constitution of scheduled areas is for the reason
as systems concerning way of life are different. They were in isolation, differed in various aspects
from common civilisation such as the delivery of justice, as regards legal system, the culture, way of
life differs from the ordinary people, their language and their primitive way of life makes them unfit
to put up with the mainstream and to be governed by the ordinary laws. It was intended by the
protective terms granted in the constitutional provisions that they will one day be the part of the
mainstream and would not remain isolated for all time to come. The Scheduled Tribes Order, 1950
was promulgated to include groups and communities which were not part of social society, based on
characteristic and culture, which developed by that time. The formal education, by and large, failed
to reach them, and they remained a disadvantaged class, as such required a helping hand to uplift
them and to make them contribute to the national development and not to remain part of the
primitive culture. The purpose of the constitutional provisions is not to keep them in isolation but to
make them part of the mainstream. They are not supposed to be seen as a human zoo and source of
enjoyment of primitive culture and for dance performances. The benefits of developments have not
reached them, and they remain isolated in various parts of the country. The social and economic
upliftment and education are necessary for tribals to make them equal.
108. Question emanating in the case is how to balance the rights of scheduled castes and scheduled
tribes. Whether providing 100% reservation in favour of any particular class is permissible?”
109. The High Court referred to the Constituent Assembly Debates. What was stated by Dr.
Ambedkar in an answer concerning backward community;
“A backward community is a community which is backward in the opinion of the Government. My
honourable friend Mr.T.T. Krishnamachari asked me whether this rule will be justiciable. It is rather
difficult to give a dogmatic answer. Personally, I think it would be a justiciable matter. If the local
Government included in this category of reservations such a large number of seats; I think one could
very well go to the Federal Court and the Supreme Court and say that the reservation is of such a
magnitude that the rule regarding equality of opportunity has been destroyed and the Court will
then come to the conclusion whether the local Government or the State Government has acted in a
reasonable and prudent manner.” (emphasis supplied)
110. In M.R. Balaji & Ors. v. State of Mysore & Ors., (1963) Supp 1 SCR 439, this Court held that
total reservations in favour of disadvantaged sections of the society could not exceed 50% thus:
“16. It now remains to consider the report made by the Nagan Gowda Committee
appointed by the State. This report proceeds on the basis that higher social status has
generally been accorded on the basis of caste for centuries; and so, it takes the view
that the low social position of any community is, therefore, mainly due to the caste
system. According to the Report, there are ample reasons to conclude that social
backwardness is based mainly on racial, tribal, caste and denominational differences,
even though economic backwardness might have contributed to social backwardness.
It would thus be clear that the Committee approached its problem of enumerating
and classifying the socially and educationally backward communities on the basisChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

that the social backwardness depends substantially on the caste to which the
community belongs, though it recognised that economic condition may be a
contributory factor. The classification made by the Committee and the enumeration
of the backward communities which it adopted shows that the Committee virtually
equated the classes with the castes. According to the Committee, the entire Lingayat
community was socially forward, and that all sections of Vokkaligas, excluding
Bhunts, were socially backward. With regard to the Muslims, the majority of the
Committee agreed that the Muslim community as a whole should be classified as
socially backward. The Committee further decided that amongst the backward
communities two divisions should be made (i) the backward and
(ii) the More Backward. In making this distinction, the Committee applied one test. It
enquired: “Was the standard of education in the community in question less than
50% of the State average? If it was, the community should be regarded as more
backward; if it was not, the community should be regarded as backward.” As to the
extent of reservation in educational institutions, the Committee’s recommendation
was that 28% should be reserved for backward and 22% for more backward. In other
words, 50% should be reserved for the whole group of backward communities besides
15% and 3% which had already been reserved for the Scheduled Castes and
Scheduled Tribes respectively. That is how according to the Committee, 68% was
carved out by reservation for the betterment of the Backward Classes and the
Scheduled Castes and Tribes. It is on the basis of these recommendations that the
Government proceeded to make its impugned order.”
111. In State of Kerala v. N.M. Thomas, (1976) 2 SCC 310, the Court observed that the rule evolved in
Balaji (supra) that reservations cannot exceed 50% is merely a rule of caution.
112. In M. Nagaraj and Ors. v. Union of India and Ors., (2006) 8 SCC 212, it was held that the ceiling
limit of the reservation is 50% without which structure of equality of opportunity in Article 16 would
collapse. This Court held:
“122. We reiterate that the ceiling limit of 50%, the concept of creamy layer and the
compelling reasons, namely, backwardness, the inadequacy of representation and
overall administrative efficiency are all constitutional requirements without which
the structure of equality of opportunity in Article 16 would collapse.” (emphasis
supplied by us)
113. Reliance has also been placed on Union of India & Ors. v. Rakesh Kumar & Ors., (2010) 4 SCC
50 on behalf of the respondents, which related to a reservation in Panchayats. Considering the
provisions of Articles 243, 243D, 15(4), 16(4) and the Fifth Schedule of the Constitution and under
Part IX to extend Panchayati Raj system to scheduled areas, it was held that post of Chairperson of
Panchayat, Scheduled Tribes in the scheduled areas cannot be put into a disadvantaged position.
Because of the peculiar conditions in those areas, it is permissible that chairpersons of scheduled
areas should be exclusively from scheduled tribes only. It was also held that Article 243D envisagesChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

proportionate representation and is distinct and an independent constitutional basis of reservation
in Panchayati Raj institutions. The reservation under Article 243D cannot be compared with
affirmative action measures under Articles 15(4) and 16(4), where a balance is to be maintained
between affirmative action measures and merits. This Court pointed out though Articles 14, 15, and
16 provide for affirmative action measures; however, there is a need for periodical review keeping in
view the changing social and economic conditions.
(a). The difference between Article 243D and Article 16(4) was pointed out in Rakesh Kumar (supra)
thus:
“42. Especially on the unviability of the analogy between Article 16(4) and Article
243-D, we are in agreement with a decision of the Bombay High Court, reported as
Vinayakrao Gangaramji Deshmukh v. P.C. Agrawal, AIR 1999 Bom 142. That case
involved a fact situation where the Chairperson position in a panchayat was reserved
in favour of a Scheduled Caste woman. In the course of upholding this reservation, it
was held: (AIR p. 143, para 4) “4. … Now, after the seventy-third and seventy-fourth
constitutional amendments, the constitution of local bodies has been granted a
constitutional protection and Article 243-D mandates that a seat be reserved for the
Scheduled Castes and Scheduled Tribes in every Panchayat and sub- article (4) of the
said Article 243-D also directs that the offices of the Chairpersons in the panchayats
at the village or any other level shall be reserved for the Scheduled Castes, the
Scheduled Tribes and women in such manner as the legislature of a State may, by
law, provide. Therefore, the reservation in the local bodies like the Village Panchayat
is not governed by Article 16(4), which speaks about the reservation in the public
employment, but a separate constitutional power directs the reservation in such local
bodies.”
43. For the sake of argument, even if an analogy between Article 243-D and Article
16(4) was viable, a close reading of Indra Sawhney, 1992 Supp (3) SCC 217, decision
will reveal that even though an upper limit of 50% was prescribed for reservations in
public employment, the said decision did recognise the need for exceptional
treatment in some circumstances. This is evident from the following words (at paras
809-10): (SCC p. 735) “809. From the above discussion, the irresistible conclusion
that follows is that the reservations contemplated in clause (4) of Article 16 should
not exceed 50%.
810. While 50% shall be the rule, it is necessary not to put out of consideration
certain extraordinary situations inherent in the great diversity of this country and the
people. It might happen that in far-flung and remote areas the population inhabiting
those areas might, on account of their being out of the mainstream of national life
and in view of conditions peculiar to and characteristical to them, need to be treated
in a different way, some relaxation in this strict rule may become imperative. In
doing so, extreme caution is to be exercised and a special case made out.”Chebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

(b). The departure from adequate and proportionate representation has been
considered in Rakesh Kumar (supra) thus:
“48. There is of course a rational basis for departing from the norms of “adequate
representation” as well as “proportionate representation” in the present case. This
was necessary because it was found that even in the areas where Scheduled Tribes are
in a relative majority, they are under-represented in the governmental machinery and
hence vulnerable to exploitation. Even in areas where persons belonging to
Scheduled Tribes held public positions, it is a distinct possibility that the non-tribal
population will come to dominate the affairs. The relatively weaker position of the
Scheduled Tribes is also manifested through problems such as land grabbing by
non-tribals, displacement on account of private as well as governmental
developmental activities, and the destruction of environmental resources. In order to
tackle such social realities, the legislature thought it fit to depart from the norm of
"proportional representation." In this sense, it is not our job to second guess such
policy choices.
56. In the context of reservations in panchayats, it can be reasoned that the limitation
placed on the choices available to voters is an incidental consequence of the
reservation policy. In this case, the compelling State interest in safeguarding the
interests of weaker sections by ensuring their representation in local self-government
clearly outweighs the competing interest in not curtailing the choices available to
voters. It must also be reiterated here that the 50% reservations in favour of STs as
contemplated by the first proviso to Section 4(g) of the PESA Act were not struck
down in the impugned judgment. Even though it was argued before this Court that
this provision makes a departure from the norm of “proportionate representation”
contemplated by Article 243-D(1), we have already explained how Article
243-M(4)(b) permits “exceptions” and “modifications” in the application of Part IX to
Scheduled Areas.
Sections 17(B)(1), 36(B)(1) and 51(B)(1) of JPRA merely give effect to the exceptional treatment that
is mandated by the PESA Act.”
(c). This Court in Rakesh Kumar (supra) held that State of Jharkhand was also under an obligation
to account for the interests of the other backward classes as contemplated in the Panchayati Raj Act,
thus :
“57. However, in addition to the 50% reservations in favour of Scheduled Tribes, the
State of Jharkhand is also under an obligation to account for the interests of
Scheduled Castes and Other Backward Classes. The same has been contemplated in
Sections 17(B)(2), 36(B)(2) and 51(B)(2) of JPRA which incorporate the standard of
“proportionate representation” for Scheduled Castes and Backward Classes in such a
manner that the total reservations do not exceed 80%. This does not mean that
reservations will reach the 80% ceiling in all the Scheduled Areas. Since theChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

allocation of seats in favour of Scheduled Castes and Backward Classes has to follow
the principle of proportionality, the extent of total reservations is likely to vary across
the different territorial constituencies identified for the purpose of elections to the
panchayats. Depending on the demographic profile of a particular constituency, it is
possible that the total reservations could well fall short of the 80% upper ceiling.
However, in Scheduled Areas where the extent of the population belonging to the
Scheduled Castes and Backward Classes exceeds 30% of the total population, the
upper ceiling of 80% will become operative.
58. Irrespective of such permutations, the legislative intent behind the impugned
provisions of JPRA is primarily that of safeguarding the interests of persons
belonging to the Scheduled Tribes category. In the light of the preceding discussion,
it is our considered view that total reservations exceeding 50% of the seats in
panchayats located in Scheduled Areas are permissible on account of the exceptional
treatment mandated under Article 243-M(4)(b). Therefore, we agree with the
appellants and overturn the ruling of the High Court of Jharkhand on this limited
point.” (emphasis supplied by us)
(d). The decision has been rendered in the context of reservation in Panchayat for
which special provisions have been made in Article 243− M(4)(b), and this Court held
that the provisions of Article 243D are distinguishable from the provisions contained
in Article 16(4). It has also been emphasised that the State cannot ignore the other
backward and scheduled caste classes.
114. In K. Krishna Murthy (Dr.) & Ors. v. Union of India & Anr., (2010) 7 SCC 202, this Court
observed thus:
“53. In this respect, we are in partial agreement with one of the submissions made by
Shri M. Rama Jois that the nature of disadvantages that restrict access to education
and employment cannot be readily equated with disadvantages in the realm of
political representation. To be sure, backwardness in the social and economic sense
does not necessarily imply political backwardness. However, the petitioner's
emphasis on the distinction between "selection" (in case of education and
employment) and "election" (in case of political representation) does not adequately
reflect the complexities involved. It is, of course, undeniable that in determining who
can get access to education and employment, due regard must be given to
considerations of merit and efficiency which can be measured in an objective
manner. Hence, admissions to educational institutions and the recruitment to
government jobs is ordinarily done through methods such as examinations,
interviews or assessment of past performance. Since it is felt that the applicants
belonging to the SC/ST/OBC categories among others are at a disadvantage when
they compete through these methods, a level playing field is sought to be created by
way of conferring reservation benefits.Chebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

54. In the domain of political participation, there can be no objective parameters to
determine who is more likely to get elected to representative institutions at any level.
The choices of voters are not guided by an objective assessment of a candidate’s merit
and efficiency. Instead, they are shaped by subjective factors such as the candidate’s
ability to canvass support, past service record, professed ideology and affiliations to
organised groups among others. In this context, it is quite possible that candidates
belonging to the SC/ST/OBC categories could demonstrate these subjective qualities
and win elections against candidates from the relatively better-off groups. However,
such a scenario cannot be presumed in all circumstances. It is quite conceivable that
in some localised settings, backwardness in the social and economic sense can also
act as a barrier to effective political participation and representation. When it comes
to creating a level playing field for the purpose of elections to local bodies,
backwardness in the social and economic sense can indeed be one of the criteria for
conferring reservation benefits.
63. As noted earlier, social and economic backwardness does not necessarily coincide
with political backwardness. In this respect, the State Governments are well advised
to reconfigure their reservation policies, wherein the beneficiaries under Articles
243-D(6) and 243-T(6) need not necessarily be coterminous with the Socially and
Educationally Backward Classes (SEBCs) [for the purpose of Article 15(4)] or even
the backward classes that are underrepresented in government jobs [for the purpose
of Article 16(4)]. It would be safe to say that not all of the groups which have been
given reservation benefits in the domain of education and employment need
reservations in the sphere of local self-government. This is because the barriers to
political participation are not of the same character as barriers that limit access to
education and employment. This calls for some fresh thinking and policy-making
with regard to reservations in local self-government.
64. In the absence of explicit constitutional guidance as to the quantum of
reservation in favour of backward classes in local self-government, the rule of thumb
is that of proportionate reservation. However, we must lay stress on the fact that the
upper ceiling of 50% (quantitative limitation) with respect to vertical reservations in
favour of SCs/STs/OBCs should not be breached. On the question of breaching this
upper ceiling, the arguments made by the petitioners were a little misconceived since
they had accounted for vertical reservations in favour of SCs/STs/OBCs as well as
horizontal reservations in favour of women to assert that the 50% ceiling had been
breached in some of the States. This was clearly a misunderstanding of the position
since the horizontal reservations in favour of women are meant to intersect with the
vertical reservations in favour of SCs/STs/OBCs, since one-third of the seats reserved
for the latter categories are to be reserved for women belonging to the same.
This means that seats earmarked for women belonging to the general category are not accounted for
if one has to gauge whether the upper ceiling of 50% has been breached.Chebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

65. Shri Rajeev Dhavan has contended that since the context of local self-government is different
from education and employment, the 50% ceiling for vertical reservations which was prescribed in
Indra Sawhney, 1992 Supp (3) SCC 217, cannot be blindly imported since that case dealt with
reservations in government jobs. It was further contended that the same decision had recognised the
need for exceptional treatment in some circumstances, which is evident from the following words:
(SCC p. 735, paras 809-10) “809. From the above discussion, the irresistible
conclusion that follows is that the reservations contemplated in clause (4) of Article
16 should not exceed 50%.
810. While 50% shall be the rule, it is necessary not to put out of consideration
certain extraordinary situations inherent in the great diversity of this country and the
people. It might happen that in far-flung and remote areas the population inhabiting
those areas might, on account of their being out of the mainstream of national life
and in view of conditions peculiar to and characteristical to them, need to be treated
in a different way, some relaxation in this strict rule may become imperative. In
doing so, extreme caution is to be exercised and a special case made out.”
66. Admittedly, reservations in excess of 50% do exist in some exceptional cases, when it comes to
the domain of political representation. For instance, the Legislative Assemblies of the States of
Arunachal Pradesh, Nagaland, Meghalaya, Mizoram and Sikkim have reservations that are far in
excess of the 50% limit. However, such a position is the outcome of exceptional considerations in
relation to these areas. Similarly, vertical reservations in excess of 50% are permissible in the
composition of local self-government institutions located in the Fifth Schedule Areas.
67. In the recent decision reported as Union of India v. Rakesh Kumar, (2010) 4 SCC 50, this Court
has explained why it may be necessary to provide reservations in favour of the Scheduled Tribes that
exceed 50% of the seats in panchayats located in the Scheduled Areas. However, such exceptional
considerations cannot be invoked when we are examining the quantum of reservations in favour of
backward classes for the purpose of local bodies located in general areas. In such circumstances, the
vertical reservations in favour of SCs/STs/OBCs cannot exceed the upper limit of 50% when taken
together. It is obvious that in order to adhere to this upper ceiling, some of the States may have to
modify their legislations so as to reduce the quantum of the existing quotas in favour of OBCs.”
115. The decision of Bombay High Court in Vinayakrao Gangaramji Deshmukh v. P C Agrawal, AIR
1999 Bom. 142 regarding the distinction between Articles 243D and 16(4) was affirmed. This Court
observed that some decisions in past examined validity of reservations in local self−Government
applying principles evolved about employment and education. It was also observed that for
scheduled castes, scheduled tribes and other backward classes categories, the level playing field is
sought to be created by conferring reservation benefits. In K. Krishna Murthy (supra), this Court
also emphasised that socio−economic backwardness does not necessarily coincide with political
backwardness, which need not necessarily be envisaged under Articles 15(4) and 16(4). Barriers to
political participation are not of the same character as barriers that limit access to education and
employment. Concerning vertical reservations, it was said that they have to be made in the upperChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

ceiling of 50%.
The 100% reservation would amount to unreasonable and unfair and cannot be termed except as
unfair and unreasonable. Thus, we are of the considered opinion that providing 100% reservation to
the scheduled castes and scheduled tribes were not permissible. The Governor in the exercise of the
power conferred by para 5(1) of the Fifth Schedule of the Constitution, cannot provide a 100%
reservation.
116. In R. Chitralekha v. State of Mysore, AIR 1964 SC 1823, it was laid down that reservation should
not exceed 50 percent; however, a little relaxation is permissible with great care. Reservation is an
exception to the general rule. The quantum of reservation should not be excessive and societally
injurious.
117. In AIIMS Students Union v. A.I.I.M.S., JT 2001 (7) SC 12, the Court observed:
"Reservation, as an exception, maybe justified subject to discharging the burden of
proving justification in favour of the class which must be educationally handicapped
– the reservation geared up to getting over the handicap. The rationale of reservation
in the case of medical students must be removal of regional or class inadequacy or
like disadvantage. Even there, the quantum of reservation should not be excessive of
societally injurious. The higher the level of the specially the lesser the role of
reservation."
118. Reliance has been placed on Lingappa Pochanna Appelwar & Ors. v. State of Maharashtra &
Ors. (1985) 1 SCC 479 in which the Court held that it is a Constitutional duty on the State to take
positive and stem measures to ensure dignity and right to life of Scheduled Tribes. There is no
quarrel with the proposition mentioned above; however, Constitutional duty has to be discharged
from a Constitutional perspective and not in violation thereof.
119. It was argued on behalf of the respondents that the scope of judicial review is very limited in
such cases. The court may observe due deference to the opinion of State if the material exists to
support the opinion that is formed. The decision in Indra Sawhney (supra) has been relied upon, in
which this Court considered the question and held:
“798. Not only should a class be a backward class for meriting reservations, it should
also be inadequately represented in the services under the State. The language of
clause (4) makes it clear that the question of whether a backward class of citizens is
not adequately represented in the services under the State is a matter within the
subjective satisfaction of the State. This is evident from the fact that the said
requirement is preceded by the words "in the opinion of the State". This opinion can
be formed by the State on its own, i.e., on the basis of the material it has in its
possession already, or it may gather such material through a
Commission/Committee, person or authority. All that is required is, there must be
some material upon which the opinion is formed. Indeed, in this matter the courtChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

should show due deference to the opinion of the State, which in the present context
means the executive. The executive is supposed to know the existing conditions in the
society, drawn as it is from among the representatives of the people in
Parliament/Legislature. It does not, however, mean that the opinion formed is
beyond judicial scrutiny altogether. The scope and reach of judicial scrutiny in
matters within subjective satisfaction of the executive are well and extensively stated
in Barium Chemicals v. Company Law Board37 which need not be repeated here.
Suffice it to mention that the said principles apply equally in the case of a
constitutional provision like Article 16(4), which expressly places the particular fact
(inadequate representation) within the subjective judgment of the State/executive.”
(emphasis supplied by us)
120. In Indra Sawhney (supra), it was observed that each situation could not be visualised and must
be left to appropriate authorities. There can be various tests for identifying backward classes. The
Court can lay down only general guidelines. If the approach adopted by the State is fair and
adequate, then the Court has no say in the matter. The Court held:
“780. Now, we may turn to the identification of a "backward class of citizens." How
do you go about it? Where do you begin? Is the method to vary from State to State,
region to region, and from rural to urban? What do you do in the case of religions
where caste-system is not prevailing? What about other classes, groups, and
communities which do not wear the label of caste? Are the people living adjacent to
cease-fire line (in Jammu and Kashmir) or hilly or inaccessible regions to be surveyed
and identified as backward classes for the purpose of Article 16(4)? And so on and so
forth are the many questions asked of us. We shall answer them. But our answers will
necessarily deal with generalities of the situation and not with problems or issues of a
peripheral nature which are peculiar to a particular State, district or region. Each and
every situation cannot be visualised and answered. That must be left to the
appropriate authorities appointed to identify. We can lay down only general
guidelines.
783. We do not mean to suggest — we may reiterate — that the procedure indicated
hereinabove is the only procedure or method/approach to be adopted. Indeed, there
is no such thing as a standard or model procedure/approach. It is for the authority
(appointed to identify) to adopt such approach and procedure as it thinks
appropriate, and so long as the approach adopted by it is fair and adequate, the court
has no say in the matter. The only object of the discussion in the preceding para is to
emphasise that if a Commission/Authority begins its process of identification with
castes (among Hindus) and occupational groupings among others, it cannot by that
reason alone be said to be constitutionally or legally bad. We must also say that there
is no rule of law that a test to be applied for identifying backward classes should be
only one and/or uniform. In a vast country like India, it is simply not practicable. If
the real object is to discover and locate backwardness, and if such backwardness is
found in a caste, it can be treated as backward; if it is found in any other group,Chebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

section or class, they too can be treated as backward.
*** *** ***
854. (b) Strictly speaking, appointment of a Commission under Article 340 is not
necessary to identify the other backward classes. Article 340 does not say so.
According to it, the Commission is to be constituted ‘to investigate the conditions of
socially and educationally backward classes … and the difficulties under which they
labour and to make recommendations as to the steps that should be taken by the
Union or any State to remove such difficulties ….” The Government could have, even
without appointing a Commission, specified the OBCs, on the basis of such material
as it may have had before it (e.g., the lists prepared by various State Governments)
and then appointed the Commission to investigate their conditions and to make
appropriate recommendations. It is true that Mandal Commission was constituted
“to determine the criteria for defining the socially and educationally backward
classes” and the Commission did determine the same. Even so, it is necessary to keep
the above constitutional position in mind, — more particularly in view of the veto
given to State lists over the Mandal lists as explained in the preceding sub-para. The
criteria evolved by Mandal Commission for defining/identifying the Other Backward
Classes cannot be said to be irrelevant. Maybe there are certain errors in actual
exercise of identification, in the nature of over-inclusion or under-inclusion, as the
case may be.
But in an exercise of such magnitude and complexity, such errors are not uncommon. These errors
cannot be made a basis for rejecting either the relevance of the criteria evolved by the Commission
or the entire exercise of identification. It is one thing to say that these errors must be rectified by the
Government of India by evolving an appropriate mechanism and an altogether different thing to say
that on that account, the entire exercise becomes futile. There can never be a perfect report. In
human affairs, such as this, perfection is only an ideal — not an attainable goal. More than forty
years have passed by. So far, no reservations could be made in favour of OBCs for one or the other
reason in Central services though in many States, such reservations are in force. Reservations in
favour of OBCs are in force in the States of Kerala, Tamil Nadu, Karnataka, Andhra Pradesh,
Maharashtra, Orissa, Bihar, Gujarat, Goa, Uttar Pradesh, Punjab, Haryana and Himachal Pradesh
among others. In Madhya Pradesh, a list of OBCs was prepared on the basis of the Mahajan
Commission Report but it appears to have been stayed by the High Court.” (emphasis supplied by
us) It was also observed that strictly speaking, the appointment of a Commission is not necessary to
identify the other backward classes.
121. Reliance has also been placed on Barium Chemicals v. Company Law Board AIR 1967 SC 295 to
argue that the scope of judicial review is limited. It is not for the court to find sufficiency. It is not
open to the court to adjudge the accuracy of the material to conclude.
122. Dr. Rajeev Dhawan, learned Senior Counsel has relied upon Treatise on Constitutional Law
(Fifth Edition) by Ronald D. Rotunda, in which it has been observed that law should be tested onChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

traditional rational standards and Court need not review seriously suspect classification. Following
observations have been made:
“The Court, in an opinion by Justice White, found that the retirement classification
should be tested by general equal protection principles, but that it did not violate the
equal protection guarantee. Although the parties agreed that the law should be tested
under the traditional rational basis standard, Justice White’s opinion stressed that
the federal judiciary is not to review seriously those classifications that do not involve
fundamental rights or suspect classifications:
The Constitution presumes that, absent some reason to infer antipathy, even
improvident decisions will eventually be rectified by the democratic process and that
judicial intervention is generally unwarranted no matter how unwisely we may think
a political branch has acted. Thus, we will not overturn such a statute unless the
varying treatment of different groups or persons is so unrelated to the achievement of
any combination of legitimate purposes that we can only conclude that the
legislature’s actions were irrational.” Applying the traditional rational standard, the
position is worsened to support the impugned G.O.
123. Reliance has also been placed on Jarnail Singh & Ors. v. Lachhmi Narain Gupta & Ors., 2018
(10) SCC 396, in which it was observed:
“23. This brings us to whether the judgment in M. Nagaraj v. Union of India, (2006)
8 SCC 212 needs to be revisited on the other grounds that have been argued before
us. Insofar as the State having to show quantifiable data as far as backwardness of the
class is concerned, we are afraid that we must reject Shri Shanti Bhushan’s argument.
The reference to “class” is to the Scheduled Castes and the Scheduled Tribes, and
their inadequacy of representation in public employment. It is clear, therefore, that
Nagaraj, (2006) 8 SCC 212, has, in unmistakable terms, stated that the State has to
collect quantifiable data showing backwardness of the Scheduled Castes and the
Scheduled Tribes. We are afraid that this portion of the judgment is directly contrary
to the nine-Judge Bench in Indra Sawhney (1), 1922 Supp (3) SCC 217. Jeevan Reddy,
J., speaking for himself and three other learned Judges, had clearly held:
“[t]he test or requirement of social and educational backwardness cannot be applied
to the Scheduled Castes and the Scheduled Tribes, who indubitably fall within the
expression “backward class of citizens”.” (See SCC p. 727, paras 796 to 797.) Equally,
Dr Justice Thommen, in his conclusion at para 323(4), had held as follows: (SCC pp.
461-62) “323. Summary * * * (4) Only such classes of citizens who are socially and
educationally backward are qualified to be identified as Backward Classes. To be
accepted as Backward Classes for the purpose of reservation under Article 15 or
Article 16, their backwardness must have been either recognised by means of a
notification by the President under Article 341 or Article 342 declaring them to be
Scheduled Castes or Scheduled Tribes, or, on an objective consideration, identified byChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

the State to be socially and educationally so backward by reason of identified prior
discrimination and its continuing ill effects as to be comparable to the Scheduled
Castes or the Scheduled Tribes. In the case of the Scheduled Castes or the Scheduled
Tribes, these conditions are, in view of the notifications, presumed to be satisfied.”
124. In Jarnail Singh (supra), this Court considered the decision of M. Nagaraj (supra), which dealt
with the promotional aspect. In that context, the aforesaid observations were made by this Court. In
the instant case, the question involved is different. This case does not pertain to quantifying data for
promotional avenues. The question to quantify data showing the backwardness of scheduled castes
or scheduled tribes is not germane. The decision has no application. The question involved in the
instant case is whether reservation for scheduled tribes is permissible, but to what extent. The
decision in Jarnail Singh (supra) concerning quantifying data for reservation and promotion does
not apply to provisions of Para 5 of Schedule V of the Constitution of India.
125. Dr. Rajeev Dhawan, learned Senior Counsel, has made available the Annual Report of the
Governor on the Administration of Scheduled Areas in Andhra Pradesh for the year 1999−2000, in
which question of the amendment and bringing a fresh notification in place of G.O. 275, Social
Welfare (E) Dept. dated 5.11.1986 for reservation of all teacher vacancies in the educational
institutions within the Scheduled Areas in favour of local Scheduled Tribes, was considered. It was
resolved that as against the vacant posts reserved for the local tribals in the Scheduled Areas, if the
local tribals are not available, it may be filled by non−local tribals. The relevant agenda item no.3
and resolution thereupon, which form part of the report sent to the President, is reproduced
hereunder:
“Agenda Item: 3 The amendment and bringing a fresh notification in place of
G.O.275, Social Welfare (E) Dept. dt. 5.11.1986 for reservation of all teacher vacancies
in the Educational Institutions within the Scheduled Areas in favour of Local
Scheduled Tribes. The Commissioner of Tribal Welfare explain the above item in
detail:
Resolution:
It is decided that the vacant posts reserved for local tribals in scheduled areas. If the
local tribals are not available, the posts may be filled by non-local tribals."
Thus, it is apparent that the Andhra Pradesh Tribes Advisory Council took the
decision described above. It is pertinent to mention that the G.O.275 dated 5.11.1986
was struck down by the High Court/Tribunal. The civil appeal filed in this Court was
withdrawn. It is also apparent that there were vacant posts reserved for the local
tribals in the Scheduled Areas, as they could not be filled; thus, it was decided to fill
the posts by local−non tribals.
The reservation of 100 per cent posts was irrational and arbitrary and violative of
Article 14 of the Constitution of India. On the one hand, local tribals were notChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

available, and the posts were vacant, thereby a decision was taken to fill those posts
by non−local tribals, and on the other hand, a decision was taken to fill these posts by
incumbents who were residing in the area since 26.1.1950. The minutes of the
Andhra Pradesh Tribes Advisory Council formed part of the report of the Governor,
which was sent to the President under Para Three of the Fifth Schedule.
126. The Governor, as per Para 3 of Schedule V of Constitution, has to submit a report to the
President regarding the administration of scheduled areas annually or whenever so required by the
President. The report is required to keep track of the progress in the areas. The report is essential for
deciding to make reservations and for its review. However, 100 percent reservation could not have
been provided even by amending Act of 1997, at the cost of the scheduled castes, backward classes,
open category and the scheduled tribes who might have settled in the areas after 26 th January
1950, as reservation had been provided only to the tribal families residing in the district on or before
26th January 1950. Thus, the action is discriminatory vis−à−vis not only concerning open category
but also to the disadvantageous sections of the society, totally vanishing the hopes of the incumbents
of other classes. The decision to issue G.O. Ms No.3/2000 was taken not on verifiable data, but it
was taken on the basis that there was chronic absenteeism of non−tribal teachers in the schools in
scheduled areas.
127. By providing 100 percent reservation to the scheduled tribes has deprived the scheduled castes
and other backward classes also of their due representation. The concept of reservation is not
proportionate but adequate, as held in Indra Sawhney (supra). The action is thus unreasonable and
arbitrary and violative of provisions of Articles 14, 15 and 16 of the Constitution of India. It also
impinges upon the right of open category and scheduled tribes who have settled in the area after
26th January 1950. The total percentage of reservation provided for Scheduled Tribes in the State is
6%. By providing 100 percent reservation in the scheduled areas, the rights of the tribals, who are
not residents of the scheduled areas, shall also be adversely affected. As per Presidential order under
Article 371−D, they cannot stake their claim in other areas. The posts in other areas are to be
reduced by making a 100% reservation in a particular area.
128. The population in the scheduled areas not only includes scheduled tribes but also open
category, scheduled castes, and other scheduled tribes settled after 26.1.1950, and they are not
covered in the notification. In Khammam district, as noted by the High Court, out of 31 mandals
notified as scheduled areas, the population of the scheduled tribes is less than 50 percent, except in
9 mandals. In those 9 mandals, where there is more than 50%, the population of the scheduled
tribes' ranges between 53 percent to 77 percent. The percentage of the scheduled tribes' students is
around 25 percent, and the remaining students belong to other classes. Similarly, in West Godavari
district, the population of scheduled tribes as per the 1991 census was 39.31 percent, whereas the
population of non−tribals was 60.69 percent.
129. Concerning Kothagudem, the High Court noted that many collieries and industries are
belonging to public and private sector undertakings and a large number of the influx of the people
from scheduled castes, scheduled tribes and backward classes had taken place to obtain
employment.Chebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

130. No law mandates that only tribal teachers can teach in the scheduled areas; thus, the action
defies the logic. Another reason given is the phenomenal absenteeism of teachers in schools. That
could not have been a ground for providing 100 percent reservation to the tribal teachers in the
areas. It is not the case that incumbents of other categories are not available in the areas. When a
district is a unit for the employment, the ground applied for providing reservation for phenomenal
absenteeism is irrelevant and could not have formed the basis for providing 100 percent reservation.
The problem of absenteeism could have been taken care of by providing better facilities and other
incentives.
131. The reason assigned that reservation was to cover impetus in the scheduled areas in the field of
education and to strengthen educational infrastructure is also equally bereft of substance. By
depriving opportunity to the others, it cannot be said that any impetus could have been given to the
cause of students and effective education, and now that could have been strengthened. The
provisions of 100 percent reservation are ignoring the merit. Thus, it would weaken the educational
infrastructure and the merit and the standard of education imparted in the schools. Educational
development of students cannot be made only by a particular class of teachers appointed by
providing reservation, ignoring merit in toto. The ideal approach would be that teachers are selected
based on merit.
132. Depriving the opportunity of employment to other categories cannot be said to be a method of
achieving social equilibrium. Apart from that, roster points are maintained for appointment by
providing 100 percent reservation, there would be a violation of the said provision also, and it would
become unworkable and the action has an effect of taking away the rights available to the tribals
settled in the other non−scheduled areas. By providing 100 per cent reservation in the scheduled
areas, their right to enjoy reservation to the extent it is available to them had also been taken away
by uncalled for distribution of reservation.
133. There were no such extraordinary circumstances to provide a 100 percent reservation in
Scheduled Areas. It is an obnoxious idea that tribals only should teach the tribals. When there are
other local residents, why they cannot teach is not understandable. The action defies logic and is
arbitrary. Merit cannot be denied in toto by providing reservations.
134. A reservation that is permissible by protective mode, by making it 100 percent would become
discriminatory and impermissible. The opportunity of public employment cannot be denied unjustly
to the incumbents, and it is not the prerogative of few. The citizens have equal rights, and the total
exclusion of others by creating an opportunity for one class is not contemplated by the founding
fathers of the Constitution of India. Equality of opportunity and pursuit of choice under Article 51−A
cannot be deprived of unjustly and arbitrarily. As per the Presidential Order, the citizens of the
locality and outsiders were entitled to 15 percent of employment in the district cadre in terms of
clause 10 of Article 370(1) (d) of the Constitution. Thus, the G.O. does not classify but deals with
reservations. It was contrary to the report sent to the President by the Governor, which indicated
even the posts which were reserved for scheduled tribes teachers, they were not available as such
Tribes Advisory Council decided to fill them from other non−local tribals.Chebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

135. We find that G.O. Ms. No.3/2000 is wholly impermissible and cannot be said to be legally
permissible and constitutionally valid. It can be said that action is not only irrational, but it violates
the rights guaranteed under Part III of the Constitution and is not sustainable. In Re: Question
No.3: Whether the notification merely contemplates a classification under Article 16(1) and not
reservation under Article 16(4)?
136. Question No.3 is whether notification No.3/2000 contains classification under Article 16(1) and
does not provide reservation under Article 16(4) of the Constitution.
137. Article 16(1) permit classification being a facet of Article 14. Clause 4 of Article 16 is an instance
of classification arising out of Clause 1 of Article 16 of the Constitution. Articles 14, 16 (1) and 16(4)
are all facets of equality. In Indra Sawhney (supra), it was held that Article 16(4) is not an exception
to Article 16(1) but a part of equality. This Court observed that in certain situations to treat unequal
persons equally, provide them equality:
“741. In M.R. Balaji v. State of Mysore, 1963 Supp 1 SCR 439, it was held — “there is
no doubt that Article 15(4) has to be read as a proviso or an exception to Articles 15(1)
and 29(2)”. It was observed that Article 15(4) was inserted by the First Amendment
in the light of the decision in State of Madras v. Smt Champakam Dorairajan, 1951
SCR 525, with a view to remove the defect pointed out by this court namely, the
absence of a provision in Article 15 corresponding to clause (4) of Article 16.
Following Balaji it was held by another Constitution Bench (by majority) in T.
Devadasan v. Union of India, (1964) 4 SCR 680 — “further this Court has already
held that clause (4) of Article 16 is by way of a proviso or an exception to clause (1)”.
Subba Rao, J, however, opined in his dissenting opinion that Article 16(4) is not an
exception to Article 16(1) but that it is only an emphatic way of stating the principle
inherent in the main provision itself. Be that as it may, since the decision in
Devadasan, it was assumed by this Court that Article 16(4) is an exception to Article
16(1). This view, however, received a severe setback from the majority decision in
State of Kerala v. N.M. Thomas (1976) 2 SCC 310. Though the minority (H.R. Khanna
and A.C. Gupta, JJ) stuck to the view that Article 16(4) is an exception, the majority
(Ray, CJ, Mathew, Krishna Iyer and Fazal Ali, JJ) held that Article 16(4) is not an
exception to Article 16(1) but that it was merely an emphatic way of stating a
principle implicit in Article 16(1). (Beg, J took a slightly different view which it is not
necessary to mention here.) The said four learned Judges — whose views have been
referred to in para 713 — held that Article 16(1) being a facet of the doctrine of
equality enshrined in Article 14 permits reasonable classification just as Article 14
does. In our respectful opinion, the view taken by the majority in Thomas is the
correct one. We too believe that Article 16(1) does permit reasonable classification for
ensuring attainment of the equality of opportunity assured by it. For assuring
equality of opportunity, it may well be necessary in certain situations to treat
unequally situated persons unequally. Not doing so, would perpetuate and accentuate
inequality. Article 16(4) is an instance of such classification, put in to place the matter
beyond controversy. The “backward class of citizens” are classified as a separateChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

category deserving a special treatment in the nature of reservation of
appointments/posts in the services of the State.
Accordingly, we hold that clause (4) of Article 16 is not exception to clause (1) of Article 16. It is an
instance of classification implicit in and permitted by clause (1). The speech of Dr Ambedkar during
the debate on draft Article 10(3) [corresponding to Article 16(4)] in the Constituent Assembly —
referred to in para 693 — shows that a substantial number of members of the Constituent Assembly
insisted upon a “provision (being) made for the entry of certain communities which have so far been
outside the administration”, and that draft clause (3) was put in in recognition and acceptance of the
said demand. It is a provision which must be read along with and in harmony with clause (1).
Indeed, even without clause (4), it would have been permissible for the State to have evolved such a
classification and made a provision for reservation of appointments/posts in their favour. Clause (4)
merely puts the matter beyond any doubt in specific terms.
742. Regarding the view expressed in Balaji (supra) and Devadasan (supra), it must be remembered
that at that time it was not yet recognised by this Court that Article 16(1) being a facet of Article 14
does implicitly permit classification. Once this feature was recognised the theory of clause (4) being
an exception to clause (1) became untenable. It had to be accepted that clause (4) is an instance of
classification inherent in clause (1). Now, just as Article 16(1) is a facet or an elaboration of the
principle underlying Article 14, clause (2) of Article 16 is also an elaboration of a facet of clause (1). If
clause (4) is an exception to clause (1) then it is equally an exception to clause (2). Question then
arises, in what respect if clause (4) an exception to clause (2), if ‘class’ does not means ‘caste’.
Neither clause (1) nor clause (2) speak of class. Does the contention mean that clause (1) does not
permit classification and therefore clause (4) is an exception to it. Thus, from any point of view, the
contention of the petitioners has no merit.” (emphasis supplied by us)
138. In Indra Sawhney (supra), the Court held that Article 16(4) aims at group backwardness, thus:
“792. In our opinion, it is not a question of permissibility or desirability of such test
but one of proper and more appropriate identification of a class — a backward class.
The very concept of a class denotes a number of persons having certain common
traits which distinguish them from the others. In a backward class under clause (4) of
Article 16, if the connecting link is the social backwardness, it should broadly be the
same in a given class. If some of the members are far too advanced socially (which in
the context, necessarily means economically and, may also mean educationally) the
connecting thread between them and the remaining class snaps. They would be
misfits in the class. After excluding them alone, would the class be a compact class. In
fact, such exclusion benefits the truly backward.
Difficulty, however, really lies in drawing the line — how and where to draw the line?
For, while drawing the line, it should be ensured that it does not result in taking away
with one hand what is given by the other. The basis of exclusion should not merely be
economic, unless, of course, the economic advancement is so high that it necessarily
means social advancement. Let us illustrate the point. A member of backward class,Chebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

say a member of carpenter caste, goes to Middle East and works there as a carpenter.
If you take his annual income in rupees, it would be fairly high from the Indian
standard. Is he to be excluded from the Backward Class? Are his children in India to
be deprived of the benefit of Article 16(4)? Situation may, however, be different, if he
rises so high economically as to become — say a factory owner himself. In such a
situation, his social status also rises. He himself would be in a position to provide
employment to others. In such a case, his income is merely a measure of his social
status. Even otherwise there are several practical difficulties too in imposing an
income ceiling. For example, annual income of Rs 36,000 may not count for much in
a city like Bombay, Delhi or Calcutta whereas it may be a handsome income in rural
India anywhere. The line to be drawn must be a realistic one. Another question would
be, should such a line be uniform for the entire country or a given State or should it
differ from rural to urban areas and so on. Further, income from agriculture may be
difficult to assess and, therefore, in the case of agriculturists, the line may have to be
drawn with reference to the extent of holding. While the income of a person can be
taken as a measure of his social advancement, the limit to be prescribed should not
be such as to result in taking away with one hand what is given with the other. The
income limit must be such as to mean and signify social advancement. At the same
time, it must be recognised that there are certain positions, the occupants of which
can be treated as socially advanced without any further enquiry. For example, if a
member of a designated backward class becomes a member of IAS or IPS or any
other All India Service, his status is society (social status) rises; he is no longer
socially disadvantaged. His children get full opportunity to realise their potential.
They are in no way handicapped in the race of life. His salary is also such that he is
above want. It is but logical that in such a situation, his children are not given the
benefit of reservation. For by giving them the benefit of reservation, other
disadvantaged members of that backward class may be deprived of that benefit. It is
then argued for the respondents that ‘one swallow doesn’t make the summer’, and
that merely because a few members of a caste or class become socially advanced, the
class/caste as such does not cease to be backward. It is pointed out that clause (4) of
Article 16 aims at group backwardness and not individual backwardness. While we
agree that clause (4) aims at group backwardness, we feel that exclusion of such
socially advanced members will make the ‘class’ a truly backward class and would
more appropriately serve the purpose and object of clause (4).
(This discussion is confined to Other Backward Classes only and has no relevance in the case of
Scheduled Tribes and Scheduled Castes).” (emphasis supplied by us)
(a). Concerning the interpretation of provisions in Articles 15(4) and 16(4), in Indra Sawhney
(supra), this Court held that:
“787. It is true that no decision earlier to it specifically said so, yet such an impression
gained currency and it is that impression which finds expression in the above
observation. In our respectful opinion, however, the said assumption has no basis.Chebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

Clause (4) of Article 16 does not contain the qualifying words “socially and
educationally” as does clause (4) of Article 15. It may be remembered that Article 340
(which has remained unamended) does employ the expression ‘socially and
educationally backward classes’ and yet that expression does not find place in Article
16(4). The reason is obvious: “backward class of citizens” in Article 16(4) takes in
Scheduled Tribes, Scheduled Castes and all other backward classes of citizens
including the socially and educationally backward classes. Thus, certain classes which
may not qualify for Article 15(4) may qualify for Article 16(4). They may not qualify
for Article 15(4) but they may qualify as backward class of citizens for the purposes of
Article 16(4). It is equally relevant to notice that Article 340 does not expressly refer
to services or to reservations in services under the State, though it may be that the
Commission appointed thereunder may recommend reservation in
appointments/posts in the services of the State as one of the steps for removing the
difficulties under which SEBCs are labouring and for improving their conditions.
Thus, SEBCs referred to in Article 340 is only of the categories for whom Article 16(4)
was enacted: Article 16(4) applies to a much larger class than the one contemplated
by Article 340. It would, thus, be not correct to say that ‘backward class of citizens’ in
Article 16(4) are the same as the socially and educationally backward classes in
Article 15(4). Saying so would mean and imply reading a limitation into a beneficial
provision like Article 16(4). Moreover, when speaking of reservation in
appointments/posts in the State services — which may mean, at any level whatsoever
— insisting upon educational backwardness may not be quite appropriate.”
(emphasis supplied by us)
(b). Article 16(4) applies to much larger classes than is contemplated by Article 340.
Thus, it would not be correct to say that the backward class of citizens under Article
16(4) is the same as provided as socially and backward classes in Article 15(4). What
is backward community, has been considered in Indra Sawhney (supra) thus:
“693. Ultimately Dr. B.R. Ambedkar, the Chairman of the Drafting Committee, got up
to clarify the matter. His speech, which put an end to all discussion and led to
adopting of draft Article 10(3), is worth quoting in extenso, since it throws light on
several questions relevant herein:
“ … [T]here are three points of view which it is necessary for us to reconcile if we are
to produce a workable proposition which will be accepted by all. Of the three points
of view, the first is that there shall be equality of opportunity for all citizens. It is the
desire of many Members of this House that every individual who is qualified for a
particular post should be free to apply for that post, to sit for examinations and to
have his qualifications tested so as to determine whether he is fit for the post or not
and that there ought to be no limitations, there ought to be no hindrance in the
operation of this principle of equality of opportunity. Another view mostly shared by
a section of the House is that, if this principle is to be operative — and it ought to be
operative in their judgment to its fullest extent — there ought to be no reservations ofChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

any sort for any class or community at all, that all citizens, if they are qualified,
should be placed on the same footing of equality so far as the public services are
concerned. That is the second point of view we have. Then we have quite a massive
opinion which insists that, although theoretically it is good to have the principle that
there shall be equality of opportunity, there must at the same time be a provision
made for the entry of certain communities which have so far been outside the
administration. As I said, the Drafting Committee had to produce a formula which
would reconcile these three points of view, firstly, that there shall be equality of
opportunity, secondly that there shall be reservations in favour of certain
communities which have not so far had a ‘proper look-in’ so to say into the
administration. If Honourable Members will bear these facts in mind — the three
principles we had to reconcile, — they will see that no better formula could be
produced than the one that is embodied in sub-clause (3) of Article 10 of the
Constitution; …. It is a generic principle. At the same time, as I said, we had to
reconcile this formula with the demand made by certain communities that the
administration which has now — for historical reasons — been controlled by one
community or a few communities, that situation should disappear and that the others
also must have an opportunity of getting into the public services. Supposing, for
instance, we were to concede in full the demand of those communities who have not
been so far employed in the public service to the fullest extent, what would really
happen is, we shall be completely destroying the first proposition upon which we are
all agreed, namely, that there shall be an equality of opportunity. Let me give an
illustration. Supposing, for instance, reservations were made for a community or a
collection of communities, the total of which came to something like 70% of the total
posts under the State and only 30% are retained as the unreserved. Could anybody
say that the reservation of 30% as open to general competition would be satisfactory
from the point of view of giving effect to the first principle, namely, that there shall be
equality of opportunity? It cannot be in my judgment. Therefore the seats to be
reserved, if the reservation is to be consistent with sub-clause (1) of Article 10, must
be confined to a minority of seats. It is then only that the first principle could find its
place in the Constitution and be effective in operation. If Honourable Members
understand this position that we have to safeguard two things, namely, the principle
of equality of opportunity and at the same time satisfy the demand of communities
which have not had so far representation in the State, then, I am sure they will agree
that unless you use some such qualifying phrase as ‘backward’ the exception made in
favour of reservation will ultimately eat up the rule altogether. Nothing of the rule
will remain. That I think if I may say so, is the justification why the Drafting
Committee undertook on its own shoulders the responsibility of introducing the word
‘backward’ which, I admit, did not originally find a place in the fundamental right in
the way in which it was passed by this Assembly ….
Somebody asked me: ‘What is a backward community’? Well, I think anyone who
reads the language of the draft itself will find that we have left it to be determined by
each local Government. A backward community is a community which is backward inChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

the opinion of the Government.” (C.A.D., Vol. 7, p. 701)” (emphasis supplied by us)
(c). In Indra Sawhney (supra), the Court held that once the reservation has been
provided to other backward classes, scheduled castes and scheduled tribes within the
purview of Article 16(4), any further exemption, concession or preference to such
class of persons can be extended only under clause (4) of Article 16. Article 16(4) is
exhaustive of the special provisions that can be made in favour of a backward class of
citizens, that is, other backward classes, scheduled castes, and scheduled tribes.
Under Article 16(1), if the State wants to make any reservation on whatever point, to
address a specific situation, Article 16(4) acts as a damper as there would be whittling
down of the vacancies for free competition, and that is not a reasonable thing to do.
In Indra Sawhney (supra), the Court held:
“743. x x x In our opinion, therefore, where the State finds it necessary — for the
purpose of giving full effect to the provision of reservation to provide certain
exemptions, concessions or preferences to members of backward classes, it can
extend the same under clause (4) itself. In other words, all supplemental and
ancillary provisions to ensure full availment of provisions for reservation can be
provided as part of concept of reservation itself. Similarly, in a given situation, the
State may think that in the case of a particular backward class it is not necessary to
provide reservation of appointments/posts and that it would be sufficient if a certain
preference or a concession is provided in their favour. This can be done under clause
(4) itself. In this sense, clause (4) of Article 16 is exhaustive of the special provisions
that can be made in favour of “the backward class of citizens”. Backward Classes
having been classified by the Constitution itself as a class deserving special treatment
and the Constitution having itself specified the nature of special treatment, it should
be presumed that no further classification or special treatment is permissible in their
favour apart from or outside of clause (4) of Article 16.” (emphasis supplied by us)
744. The aspect next to be considered is whether clause (4) is exhaustive of the very
concept of reservations? In other words, the question is whether any reservations can
be provided outside clause (4) i.e., under clause (1) of Article 16. There are two views
on this aspect. On a fuller consideration of the matter, we are of the opinion that
clause (4) is not, and cannot be held to be, exhaustive of the concept of reservations;
it is exhaustive of reservations in favour of backward classes alone. Merely because,
one form of classification is stated as a specific clause, it does not follow that the very
concept and power of classification implicit in clause (1) is exhausted thereby. To say
so would not be correct in principle. But, at the same time, one thing is clear. It is in
very exceptional situations, — and not for all and sundry reasons — that any further
reservations, of whatever kind, should be provided under clause (1). In such cases,
the State has to satisfy, if called upon, that making such a provision was necessary (in
public interest) to redress a specific situation. The very presence of clause (4) should
act as a damper upon the propensity to create further classes deserving special
treatment. The reason for saying so is very simple. If reservations are made bothChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

under clause (4) as well as under
clause (1), the vacancies available for free competition as well as reserved categories
would be a correspondingly whittled down and that is not a reasonable thing to do.
xxx
859. We may summarise our answers to the various questions dealt with and
answered hereinabove:
(1) x x x (2) (a) Clause (4) of Article 16 is not an exception to clause (1).
It is an instance and an illustration of the classification inherent in clause (1). (Paras 741-742)
(b) Article 16(4) is exhaustive of the subject of reservation in favour of backward class of citizens, as
explained in this judgment. (Para 743)
(c) Reservations can also be provided under clause (1) of Article
16. It is not confined to extending of preferences, concessions or exemptions alone. These
reservations, if any, made under clause (1) have to be so adjusted and implemented as not to exceed
the level of representation prescribed for ‘backward class of citizens’ — as explained in this
Judgment. (Para 745)
860. For the sake of ready reference, we also record our answers to questions as framed by the
counsel for the parties and set out in para 681. Our answers question-wise are:
(1) Article 16(4) is not an exception to Article 16(1). It is an instance of classification
inherent in Article 16(1). Article 16(4) is exhaustive of the subject of reservation in
favour of backward classes, though it may not be exhaustive of the very concept of
reservation. Reservations for other classes can be provided under clause (1) of Article
16.
(2) The expression ‘backward class’ in Article 16(4) takes in ‘Other Backward Classes’,
SCs, STs and may be some other backward classes as well. The accent in Article 16(4)
is upon social backwardness. Social backwardness leads to educational backwardness
and economic backwardness. They are mutually contributory to each other and are
intertwined with low occupations in the Indian society. A caste can be and quite often
is a social class in India. Economic criterion cannot be the sole basis for determining
the backward class of citizens contemplated by Article 16(4). The weaker sections
referred to in Article 46 do include SEBCs referred to in Article 340 and covered by
Article 16(4).Chebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

xxx (7) No special standard of judicial scrutiny can be predicated in matters arising under Article
16(4). It is not possible or necessary to say more than this under this question.”
139. In the instant case, it is not in dispute that the district is a local area and a unit for the
appointment of teachers and reservation is provided at the district level and as per the Presidential
Order under Article 371D of the Constitution, incumbent of one district cannot stake claim outside
the district for an appointment. The reservations for scheduled tribes are covered within the ken of
Article 16(4). Thus, no further preference or classification could have been made under Article 16(1)
of the Constitution of India in favour of scheduled tribes as Article 16(4) is exhaustive of the special
provisions that can be made in favour of scheduled castes, scheduled tribes, and other backward
classes. Reservation for the other classes can be provided under Article 16(1) and not to scheduled
tribes to whom the reservation has been provided under Article 16(4). Thus, as argued on behalf of
respondents, it cannot be said to be a case of classification made under Article 16(1) of the
Constitution of India. It is a case of tinkering with the percentage of reservation permissible as per
the dictum of Indra Sawhney (supra). Other incumbents who are in the reserved classes such as
scheduled castes and other backward classes and even Scheduled Tribes who have settled after
26.1.1950 beside incumbents of open category, were deprived of the right to stake claim to obtain
public employment as against the posts in question. In the background of the discussion made in the
earlier part of the judgment, it is crystal clear that the order passed providing 100% reservation is
arbitrary, illegal, impermissible, and unconstitutional.
140. The 100 percent reservation has been provided. It cannot be said to be a case of classification
that has been made under Article 16(1). Assuming, for the sake of argument, it is to be a case of
classification under Article 16(1), it would have been discriminatory and grossly arbitrary without
rationale and violative of constitutional mandate.
141. The incumbents of various categories have the right to stake a claim for the employment of
which they have been deprived. Thus, it is not a matter of classification. The reservation under
Article 16(4) was made. By way of 100% reservation, the employment to others was illegally
deprived and they have no chance of employment as against the post of teachers elsewhere because
of the order under Article 371D in which district/zone is a unit. It is a clear case of tinkering with
reservation.
In Re: Question No.4: Whether the conditions of eligibility that is the origin and cut−off date to avail
the benefit of reservation in the notification is reasonable:
142. It has been provided in the notification that the local scheduled tribe's candidates have been
defined to be scheduled tribes notified as under Article 342 of the Constitution of India, if the
candidates of scheduled tribes themselves or their parents have been continuously residing in the
scheduled areas of the district in which they are residing from the date i.e., 26th January 1950.
143. The condition of continuously residing in the district is ex facie arbitrary. Article 15(1) of the
Constitution provides that State shall not discriminate inter alia on the ground of place of birth,
however, under Article 15(4), it is provided that reservation can be made in favour of citizens ofChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

backward classes i.e. Scheduled Castes and Scheduled Tribes and special provision can be carved out
for their advancement. It is also open to prescribe for conditions of eligibility on the ground of
residence in a particular area as well as on the educational requirements but that cannot be fixed
arbitrarily and irrationally.
144. In the Presidential Order called the Andhra Pradesh Public Employment (Organisation of Local
Cadres and Regulation of Direct Recruitment) Order, 1975, (for short, “1975 Order”) “Local
Candidate” has been defined in para 7 thus:
“7. Local Candidate:- (1) A candidate for direct recruitment to any post shall be
regarded as a local candidate in relation to a local area.
(a) in cases where a minimum educational qualification has been prescribed for
recruitment to the post.
(i) if he has studied in an educational institution or educational institutions in such
local area for a period of not less than four consecutive academic years ending with
the academic year in which he appeared or, as the case may be, first appeared for the
relevant qualifying examination; or
(ii) where during the whole or any part of the four consecutive academic years ending
with the academic year in which he appeared or as the case may be, first appeared for
the relevant qualifying examination he has not studied in any educational institution,
if he has resided in that local area for a period of not less than four years immediately
preceding the date of commencement of the qualifying examination in which he
appeared or as the case may be, first appeared.
(b) In cases where no minimum educational qualification has been prescribed for
recruitment to the post, if he has resided in that local area for a period of not less
than four years immediately preceding the date on which the post is notified for
recruitment.
         ***    ***    ***
         ***    ***    ***
(2)     A candidate for direct recruitment to any post who is not
regarded as a local candidate under sub paragraph (1) in relation to any local area
shall.
(a) in cases where a minimum educational qualification has been prescribed for
recruitment to the post.
(i) if he has studied in educational institutions in the State for a period of not less
than seven consecutive academic years ending with academic year in which he
appeared or as the case may be, first appeared for the relevant qualifyingChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

examination, be regarded as a local candidate in relation to (1) Such local area where
he has studied for the maximum period out of the said period of seven years; or (2)
where the periods of his study in two or more local areas are equal, such local areas
where he has studied last in such equal periods;
(ii) if during the whole or any part of the seven consecutive academic years ending
with the academic years in which he appeared or as the case may be first appeared for
the relevant qualifying examination, he has not studied in the educational
institutions in any local area, but has resided in the State during the whole of the said
period of seven years, be regarded as a local candidate in relation to (1) such local
area where he has resided for a maximum period out of the said period of seven
years: or (2) where the periods of his residence in two or more local areas are equal,
such local areas where he has resided last in such equal periods;
(b) In cases where no minimum educational qualification has been prescribed for
recruitment to the post, if he has resided in the State for a period of not less than
seven years immediately preceding the date on which the post is notified for
recruitment, be regarded as a local candidate in relation to
(i) such local area where he has resided for the maximum period out of the said
period of seven years;
                  or
                  (ii)     where the periods of his residence in two or
more local areas are equal such local area where he has resided last in such equal
periods.”
145. Para 7(1) of the 1975 Order provided that a candidate shall be regarded as a local candidate in
relation to local area in cases where a minimum qualification is prescribed for recruitment to the
post i.e. a person who has studied in such local area for a period of not less than four consecutive
academic years or if he has resided in that local area for a period of not less than four years
immediately preceding the date of commencement of qualifying examination in which he appeared.
146. Para 7(2) of the 1975 Order provides that candidate for direct recruitment to any post, who is
not regarded as a local candidate in relation to any local area, shall study for 7 consecutive academic
years where a minimum educational qualification has been prescribed for recruitment to the post.
Condition of Study for less than 7 consecutive academic years is also provided for a resident for a
period of seven years with certain stipulation in para 7(2)(A)(2)(ii).
147. The G.O. in question requires candidate or the parents to reside in the area continuously w.e.f.
26.1.1950 to date. There is no rhyme or reason to require continuous residence for last 50 years or
more. It overlooks the rights of various other persons who might have settled decades together in
the area in question. It is discriminatory vis−à−vis to the scheduled tribes also settled in the area
and it has no purpose to be achieved and imposes restriction which was not even provided in theChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

Presidential Order issued under Article 371D of the Constitution of India with respect to residential
or educational requirements. Thus, it does not lay down valid conditions. The same is fixed in highly
unreasonable and arbitrary manner and limits zone of consideration to miniscule where an
opportunity for public employment has to be afforded to all concerned with reasonable rights.
148. Public employment envisages opportunity to all, who have been provided reservation is by way
of exception to do the compensatory jobs. The condition above deprives the scheduled tribes who
are permanent residents of the areas and have settled after the said cut− off date. Thus, the
classification created is illegal, unreasonable, and arbitrary. Making such a provision that a person
should be a resident on or before 26th January 1950 to date is discriminatory and has the effect of
exceeding the purpose of providing the reservation. It defeats the rights of other similar tribes who
might have settled after 26 th January 1950 in the area taken care of in the Presidential Order under
Article 371−D. It is violative of Articles 14, 15(1) and 16 of the Constitution and has no rationale with
the purpose sought to be achieved. It creates a class within a class, and the classification made failed
to qualify the parameters of Articles 14, 15 and 16 of the Constitution of India.
REVISION OF LISTS
149. Article 341(1) provides for the inclusion of castes, races, or tribes to be Scheduled Castes in
relation to any State. Article 341(2) empowers the Parliament to include or exclude from the list of
Scheduled Castes any caste, race or tribe. Article 341(2) is extracted hereunder:
“341.— (1)** (2) Parliament may by law include in or exclude from the list of
Scheduled Castes specified in a notification issued under clause (1) any caste, race or
tribe or part of or group within any caste, race or tribe, but save as aforesaid a
notification issued under the said clause shall not be varied by any subsequent
notification.”
150. Identical provisions in relation to the inclusion of Scheduled Tribes are provided in Article
342(1), and the Parliament's power to amend is provided in Article 342(2). Similar provisions are
contained with respect to socially and educationally backward classes in Article 342A. Scheduled
Area is defined in Para 6 of Schedule V, and the power to amend is provided in Para 7 of Schedule V.
It is also provided in Para 3 of the Schedule V that the Governor has to send a report to the President
regarding the administration of Scheduled Areas. The objective is to keep track of the progress in the
areas. The report is essential for deciding to make reservations and for its review. Oversight is
required to be kept by the Constitutional authorities, and the Parliament has been given the right to
amend the list and the Schedule.
151. In Indra Sawhney (supra), it was held that the State Lists adopted to provide reservations by the
Government are not meant to be sacrosanct and unalterable. There may be cases where
Commissions appointed by the State may have, in their reports, recommended modification of such
lists by deletion or addition of certain castes, communities, and classes. Where such reports are
available, the State Government is bound to act on that basis with reasonable promptitude. If the
State Government effects any modification or alteration by way of deletions or additions, the sameChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

shall be intimated to the Government of India forthwith. This Court opined concerning the
modifications and rectification of such list thus:
“853. At the same time, we think it necessary to make the following clarification: It is
true that the Government of India has adopted the State lists obtaining as on August
13, 1990 for its own purposes but that does not mean that those lists are meant to be
sacrosanct and unalterable. There may be cases where commissions appointed by the
State Government may have, in their reports, recommended modification of such
lists by deletion or addition of certain castes, communities and classes. Wherever
such commission reports are available, the State Government is bound to look into
them and take action on that basis with reasonable promptitude. If the State
Government effects any modification or alteration by way of deletions or additions,
the same shall be intimated to the Government of India forthwith which shall take
appropriate action on that basis and make necessary changes in its own list relating
to that State. Further, it shall be equally open to, indeed the duty of, the Government
of India — since it has adopted the existing States lists — to look into the reports of
such commission, if any, and pass its own orders, independent of any action by the
State Government, thereon with reasonable promptitude by way of modification or
alternation. It shall be open to the Government of India to make such
modification/alteration in the lists adopted by way of additions or deletions, as it
thinks appropriate on the basis of the Reports of the Commission(s). This direction,
in our opinion, safeguards against perpetuation of any errors in the State lists and
ensures rectification of those lists with reasonable promptitude on the basis of the
Reports of the Commissions already submitted, if any. This course may be adopted de
hors the reference to or advice of the permanent mechanism (by way of Commission)
which we have directed to be created at both Central and State level and with respect
to which we have made appropriate directions elsewhere.”
152. The Court in Rakesh Kumar (supra) emphasised need of periodical review and held:
“37. It is a well-accepted premise in our legal system that ideas such as “substantive
equality” and “distributive justice” are at the heart of our understanding of the
guarantee of “equal protection before the law”. The State can treat unequals
differently with the objective of creating a level-playing field in the social, economic
and political spheres. The question is whether “reasonable classification” has been
made on the basis of intelligible differentia and whether the same criteria bears a
direct nexus with a legitimate governmental objective. When examining the validity
of affirmative action measures, the enquiry should be governed by the standard of
proportionality rather than the standard of “strict scrutiny”. Of course, these
affirmative action measures should be periodically reviewed and various measures
modified or adapted from time to time in keeping with the changing social and
economic conditions. Reservation of seats in panchayats is one such affirmative
action measure enabled by Part IX of the Constitution.” (emphasis supplied by us)Chebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

153. Now there is a cry within the reserved classes. By now, there are affluents and socially and
economically advanced classes within Scheduled Castes and Scheduled Tribes. There is voice by
deprived persons of social upliftment of some of the Scheduled Castes/Tribes, but they still do not
permit benefits to trickle down to the needy. Thus, there is a struggle within, as to worthiness for
entitlement within reserved classes of scheduled castes and scheduled tribes and other backward
classes.
In our opinion, it was rightly urged by Dr. Rajeev Dhawan that the Government is required to revise
the lists. It can be done presently without disturbing the percentage of reservation so that benefits
trickle down to the needy and are not usurped by those classes who have come up after obtaining the
benefits for the last 70 years or after their inclusion in the list. The Government is duty− bound to
undertake such an exercise as observed in Indra Sawhney (supra) and as constitutionally envisaged.
The Government to take appropriate steps in this regard.
154. We answer the questions referred to us thus:
Question No.1: The Governor in the exercise of powers under Para 5(1), Fifth
Schedule of the Constitution, can exercise the powers concerning any particular Act
of the Parliament or the legislature of the State. The Governor can direct that such
law shall not apply to the Scheduled Areas or any part thereof. The Governor is
empowered to apply such law to the Scheduled Area or any part thereof in the State
subject to such exceptions and modifications as he may specify in the notification and
can also issue a notification with retrospective effect.
Question No.1(a): The Governor is empowered under Para 5(1), Fifth Schedule of the
Constitution, to direct that any particular Act of Parliament or the Legislature of the
State, shall not apply to a Scheduled Area or apply the same with exceptions and
modifications.
The Governor can make a provision within the parameters of amendment/
modification of the Act of Parliament or State legislature.
The power to make new laws/regulations, is provided in Para 5(2), Fifth Schedule of
the Constitution for the purpose mentioned therein, not under Para 5(1) of the Fifth
Schedule to the Constitution of India.
Question No.1(b): The power of the Governor under Para 5(1), Fifth Schedule to the
Constitution does not extend to subordinate legislation, it is with respect to an Act
enacted in the sovereign function by the Parliament or legislature of the State which
can be dealt with.
Question No.1(c): The Governor’s power under Para 5(1) of the Fifth Schedule to the
Constitution is subject to some restrictions, which have to be observed by the
Parliament or the legislature of the State while making law and cannot override theChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

fundamental rights guaranteed under Part III of the Constitution.
Question No.1(d): In exercise of power under Para 5(1) of the Fifth Schedule to the
Constitution of India, the Governor cannot override the notification issued by the
President in the exercise of powers under Article 371D. The power has to be exercised
harmoniously with such an order issued under Article 371D, not in conflict thereof.
Question No.2: G.O.Ms. No.3/2000 providing for 100 per cent reservation is not
permissible under the Constitution, the outer limit is 50 per cent as specified in Indra
Sawhney (supra).
Question No.3: The notification in question cannot be treated as classification made
under Article 16(1). Once the reservation has been provided to Scheduled Tribes
under Article 16(4), no such power can be exercised under Article 16(1). The
notification is violative of Articles 14 and 16(4) of the Constitution of India.
Question No.4: The conditions of eligibility in the notification with a cut−off date, i.e., 26.1.1950, to
avail the benefits of reservation, is unreasonable and arbitrary one.
RELIEF:
As a sequel to the quashing of G.O. Ms. No.3 of 2000, the appointments made in
excess of the permissible reservation cannot survive and should be set aside.
However, on behalf of State and other respondents, it was urged that appointments
may not be set aside. In the peculiar circumstances, the incumbents, who have been
appointed, cannot be said to be at fault and they belong to Scheduled Tribes.
We cannot ignore the fact that a similar G.O. was issued by the erstwhile State
Government of Andhra Pradesh in the year 1986, which was quashed by the State
Administrative Tribunal, against which an appeal was preferred in this Court, which
was dismissed as withdrawn in the year 1998. After withdrawal of the appeal from
this Court, it was expected of the erstwhile State of Andhra Pradesh not to resort to
such illegality of providing 100% reservation once again. But instead, it issued G.O.
Ms. No.3 of 2000, which was equally impermissible, even if the A.P. Regulation of
Reservation and Appointment to Public Services Act, 1997 would have been
amended, in that event also providing reservation beyond 50% was not permissible.
It is rightly apprehended by appellants that the State may again by way of mis−
adventure, resort to similar illegal exercise as was done earlier. It was least expected
from the functionary like Government to act in aforesaid manner as they were bound
by the dictum laid down by this Court in Indra Sawhney (supra) and other decisions
holding that the limit of reservation not to exceed 50%.
There was no rhyme or reason with the State Government to resort to 100%
reservation. It is unfortunate that illegal exercise done in 1986 was sought to beChebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

protected by yet another unconstitutional attempt by issuing G.O.Ms. No.3 of 2000
with retrospective effect of 1986, and now after that 20 years have passed. In the
peculiar circumstance, we save the appointments conditionally that the reorganised
States i.e. the States of Andhra Pradesh and Telangana not to attempt a similar
exercise in the future. If they do so and exceed the limit of reservation, there shall not
be any saving of the appointments made, w.e.f. 1986 till date. We direct the
respondents−States not to exceed the limits of reservation in future. Ordered
accordingly.
Resultantly, we allow the appeals, and save the appointments made so far
conditionally with the aforesaid riders. The cost of appeal is quantified at Rupees Five
Lakhs and to be shared equally by the States of Andhra Pradesh and Telangana.
..……………………….J. (Arun Mishra) ..……………………….J. (Indira Banerjee)
..……………………….J. (Vineet Saran) …..…………………….J. (M.R. Shah) New Delhi
…………………………J. April 22, 2020 (Aniruddha Bose)Chebrolu Leela Prasad Rao vs State Of A.P. . on 22 April, 2020

