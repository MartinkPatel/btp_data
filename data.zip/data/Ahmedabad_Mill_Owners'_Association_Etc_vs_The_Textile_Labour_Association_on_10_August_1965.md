Ahmedabad Mill Owners' Association Etc vs The Textile Labour
Association on 10 August, 1965
Equivalent citations: 1966 AIR 497, 1966 SCR (1) 382, AIR 1966 SUPREME
COURT 497, 1965-66 FJR 15, 1965 (11) FACLR 337, 1966 (1) SCR 382, 1966 (1)
LABLJ 1, 1967 (1) SCJ 360
Author: P.B. Gajendragadkar
Bench: P.B. Gajendragadkar, K.N. Wanchoo, M. Hidayatullah, V. Ramaswami
           PETITIONER:
AHMEDABAD MILL OWNERS' ASSOCIATION ETC.
        Vs.
RESPONDENT:
THE TEXTILE LABOUR ASSOCIATION
DATE OF JUDGMENT:
10/08/1965
BENCH:
GAJENDRAGADKAR, P.B. (CJ)
BENCH:
GAJENDRAGADKAR, P.B. (CJ)
WANCHOO, K.N.
HIDAYATULLAH, M.
RAMASWAMI, V.
CITATION:
 1966 AIR  497            1966 SCR  (1) 382
 CITATOR INFO :
 RF         1969 SC 360  (21)
 RF         1972 SC1234  (18)
 RF         1972 SC2273  (15)
 R          1972 SC2332  (64,72)
 R          1978 SC 828  (20)
 R          1978 SC1113  (18,26)
 R          1980 SC  31  (15,22)
 R          1986 SC 125  (8,19)
 R          1992 SC 504  (27)
ACT:
The Bombay Industrial Relations Act (11 of 1947), ss. 42 and
73-Payment  of  dearness allowance based on cost  of  living
index-Principles.Ahmedabad Mill Owners' Association Etc vs The Textile Labour Association on 10 August, 1965

HEADNOTE:
After  the 2nd World War broke out the industrial  employees
at  Ahmedabad, who had organised themselves as  the  Textile
Labour  Association (Respondent herein) raisd a  demand  for
payment  of  dearness allowance to meet the cost  of  living
which  had  shot up as a result of the War, and  the  demand
became  the subject-matter of arbitration and an  ,award  by
the  Industrial Court at Bombay.  As a result  of  petitions
filed  by  the  Parties  and  references  made  to  it,  the
Industrial  Court had been giving directions, from  time  to
time,  regarding the payment of dearness allowance  awarded,
on the basis of cost of living index number, with 1926-27 as
the  base year.  In the Second Five Year Plan, the  Planning
Commission  recommended  that the series of cost  of  living
indices  should  be  revised, and  accordingly,  the  labour
Bureau  and  the  Central Statistical  Organisation  of  the
Government of India undertook family living surveys in 1958-
59.  One of the centers chosen was Ahmedabad and the Govern-
ment  of India began to publish consumer price index  number
for  the city -of Ahmedabad from 1960 with 1960 as the  base
year.   The  Government  of India  also  advised  the  State
Government  to remove various anomalies in the State  series
of  the price index number and publish a new series  linking
the State series with that of Government of India, with 2.98
as the linking factor.  The Government of Gujarat set up  an
expert  Committee  to  advise it on the  question  and  that
Committee made recommendations for the removal of anomalies
and  also  suggested  3.17 instead of 2.98  as  the  linking
factor.   In November 1963, the Government accepted the re-
commendations for   removing  the a normalies  and  adjusted
the consumer price index number, and the appellants paid the
dearness allowance according to the adjusted consumer  price
index   number  under  protest.   In  February   1964,   the
Government  of Gujarat announced its decision to  adopt  the
linking  factor at 3.17. The appellants were not willing  to
pay  dearness  allowance according to  the  converted  price
index number in spite of a representation by the  employees,
and  so,  the dispute was referred to the  Industrial  Court
under  s. 73 of Bombay Industrial Relations Act, 1946.   The
industrial  Court  decided that the  appellants  should  pay
dearness allowance to their employees for the month of March
1964  and for subsequent months on the consumer price  index
numbers  for  Ahmedabad published by  the  State  Government
since February 1964 by using the index numbers in the series
for  Ahmedabad compiled by the Labour Bureau at  Simla,  and
the  linking factor of 3.17 adopted for linking that  series
to  the State series with the old base. and gave  directions
as to the manner of paying the dearness allowance.
In their appeal to this Court, the appellants contended that
(i)  the  reference was invalid because, before  making  the
reference  to  requirements of s. 42, which  prescribes  theAhmedabad Mill Owners' Association Etc vs The Textile Labour Association on 10 August, 1965

procedure  which has to be followed by the employer  or  the
employee if either of them wants a change
383
to  be effected in the terms of the existing award, had  not
been  complied  with;  (ii) the Industrial  Court  erred  in
overruling  their contention that the new  survey  sufferred
from  two  major infirmities, (a) inadequacy of  the  sample
size, and (b) impropriety of the method of interview adopted
by  the investigators; (iii) the linking factor of 3.17  was
improper;  and  (iv) the Industrial Court was not  right  in
coming  to. the conclusion that the additional burden  which
its  award would impose upon the  appellants. would  not  be
beyond their financial capacity.
    HELD:  (i) The dispute must be treated as an  industrial
dispute,  notwithstanding the fact that s. 42 had  not  been
complied  with, and Industrial Court was right in coming  to
the  conclusion that the objection raised by  the  appellant
against  the competence of the reference was  mis-conceived.
[398 F; 399 E]
The  Act   is a comprehensive piece  of  legislation  and
makes  elaborate' provision for the regulation of  relations
between  employers and employees and for the  settlement  of
disputes between them.  Section 73 deals  with the powers of
the  State  Government to make a reference and as  such,  it
could  not  have been intended that those powers are  to  be
controlled   by  s.  42.  Section 42 provides  that,  if  an
employer or employee intends to effect any change in respect
of  certain industrial matters, he will have to give  notice
of such intention to the representative of the employees  or
tie   employer  respectively.  The  section  can   have   no
application to cases where the State Government itself wants
to make a reference.  The meaning of the non-obstante clause
with which s. 73 opens also unambiguously indicates that the
power  of  the  State  Government to  make  a  reference  is
controlled   by  any  other  provision  in  the  Act.    The
definition  of  "industrial dispute" in s. 3(17) is so  wide
and  comprehensive,  that, even If an, award  is  subsisting
between  the parties, if a difference arises  between  them,
the  said difference would amount to an  industrial  dispute
for the purpose of s. 73 and a notice of change need not  be
given,  either by the employer or by the employee.   It   is
true  that  the power conferred on the State  Government  to
make a reference is. not absolute or unqualified, but  could
be  exercised  only if one or the other  of  the  conditions
specified in sub-ss. (1), (2) or (3) of s. 73 is  satisfied.
But  once  the State Government is satisfied, its  power  to
make  a  reference is not limited to cases where  notice  of
change  has  been  given  by the parties  under  s.  42,  On
principle  also,  the  conferment of  power  on  the  State,
Government is fully justified, because, if as a result of  a
dispute  between the employer and his employees,  a  serious
outbreak of disorder, or a breach of public peace is  likely
to  occur,  or a serious or prolonged hardship  to  a  largeAhmedabad Mill Owners' Association Etc vs The Textile Labour Association on 10 August, 1965

section  of  the community is likely to be caused,   or  the
industry  concerned is likely to be affected  adversely,  it
would  be  idle  to require that even in the  face  of  such
serious  danger, the procedure prescribed by s. 42  must  be
followed before reference can be made under s. 73. [396  DF;
397 E-H; 398 C-E, G; 399 C-B]
    (ii)   (a):  The  appellants  were  not   justified   in
contending that the inadequacy of the size of the sample  in
relation  to  the  universe of the  working  class  families
vitiated the enquiry. [414 H]
    From the Report of Family Living Survey among Industrial
workers  at Ahmedabad, 1958-59, it appears that  the  survey
and field work was the result of the cooperation of  several
expert  institutions, official as well as non-official.  and
was based on accepted principles and method is.  The size of
the  sample was determined in the light of  the  permissible
margin  of  error  and was selected by  the  application  of
scientific   sampling  techniques  and   according  to   the
principle  that  it is the quality of survey  that  is  more
important,  not  so  much the size of the  sample.   If  the
quality  of  investigation has improved, and the  method  of
working out the sample'
384
survey  has made very great progress, then, it would not  be
correct  to say that because the size of the sample  in  the
survey  was  smaller as compared to the size of  the  sample
taken  in  1926-27,  the  inadequacy  of  the  size  on  the
subsequent   occasion   introduces  an  infirmity   in   the
investigation itself.  [409 H; 410 G; 412 D, E, G; 413 D-E]
    (b)  'the  Industrial Court was right in  rejecting  the
appellants'  contention  that the impugned survey  ,rut  the
index  constructed  as  a  result  it,   suffered  from  the
infirmity that the investigation was conducted in the survey
by 1he interview method,  [416 D]
    Having  regard  to the fact that a majority  of  working
class  population  in  India is  illiterate  the  method  of
interview is the only method which can be adopted.   Besides
according  to  expert  opinion, the  interview  methods,  if
properly  adopted gives better results than the  alternative
method     of   supplying   account   books   and    written
questionnaire.  [416 A-C]
   (iii)  As  the  appellants  had  not  placed  before  the
Industrial  Court any material to justify  their  contention
that  for determining the linking factor. the  behaviour  of
prices  for two or three years should have been studied,  it
could  not  be said that the Industrial Court  committed  an
error in upholding the decision of the Government of Gujarat
that the linking factor should be 317.  [419 F-G; 420]
    The Industrial Court had to choose between two  courses.
One  was to  work out an entirely new scale of  basic  wages
rounded not on the pre'war level of 1939 but on the cost  of
living  of  1960  as the base year and  .to  award  dearness
allowance thereafter.  The Industrial Court thought that  toAhmedabad Mill Owners' Association Etc vs The Textile Labour Association on 10 August, 1965

adopt that course might conceivably create a large number of
new  problems,  disturbing  industrial peace  and  would  be
outside its terms of reference.  Therefore, it approved  the
other course of linking the State series with the new series
to maintain continuity, which was the method adopted by  the
Government of Maharashtra also.  [418 E, G; 419
    (iv)  The  appellants  had failed  to  substantiate  the
contention that the -additional burden would be beyond their
capacity to pay.  [429 E]
    The claim of the employees for a fair and higher wage is
undoubtedly, based on the concept of social justice, and  if
employees  are paid better wages which would enable them  to
live  in  comfort  and discharge their  obligations  to  the
members  of their families in a reasonable way,  their  work
would  show an appreciable increase in efficiency.   On  the
ether  hand. industrial adjudication must take into  account
the  problem  of  the  additional  burden  which  such  wage
structure  would  impose  upon  the  employer  and  consider
whether  the employer can reasonably be called upon to  bear
such burden.  The task of constructing a wage structure must
be tackled on the basis that such wage structure should  not
be  changed from time to time.  It is a long-range plan  and
in  dealing  with  the  problem,  which  is   difficult  and
delicate  the  financial position of the  employer  and  the
future  prospects of the industry and the additional  burden
which  may  be  imposed on the consumer  must  be  carefully
examined.   A  broad  and  overall  view  of  the  financial
position  of  the employer must be taken  into  account  and
attempt  should always be made to reconcile the natural  and
just claims of the employees for a fair and higher wage with
the  capacity of the employer to pay it, and in  determining
such.  capacity,  allowance must be made  for  a  legitimate
desire of the employer to make a reasonable profit.. Unusual
profit  or loss should not be allowed to play a major  role.
It  is  true that normally, once a wage structure  is  fixed
employees  are reluctant to face a reduction in the  content
of  the wage packet; but like all other problems  associated
with  industrial adjudication, the decision of  the  problem
must  also  be  based on the major  consideration  that  the
conflicting
                            385
claims  of  labour  and  capital must  be  harmonised  on  a
reasonable  basis; and so, if it appears that  the  employer
cannot  really bear the burden of the increasing wage  bill,
industrial  adjudication cannot refuse to examine  his  case
and  should  not  hesitate  to give  him  relief  if  it  is
satisfied that if such relief is not Even, the employer  may
have to close down his business. The last principle, however
does  not  apply  to  cases where  the  wages  paid  to  the
employees  are  no better than the basic minimum  wage.   If
what  the employer pays to his employees is just  the  basic
subsistence wage and if he cannot afford to pay it, he would
not  be  justified in carrying on his industry.   Since  theAhmedabad Mill Owners' Association Etc vs The Textile Labour Association on 10 August, 1965

wages paid to the textile employees at ,Ahmedabad cannot  be
regarded as subsistence wages or bare minimum , it would not
be  open  to the respondent to contend that  the  appellants
must  pay the wages whether the employers can afford to  pay
them or not.  If it is shown that the appellants cannot bear
the  burden and that the implementation of the  award  would
inevitably  have  extremely  prejudicial  effect  upon   the
continued  existence of the industry itself, there would  be
justification for revising the scale of dearness  allowance.
In  considering the financial position of the appellants  it
would not be appropriate to rely unduly on the profitability
ratio  which has been adopted by the Bulletin issued by  the
Reserve  Bank  of  India dealing  with  the  cotton  textile
industry, or other single-purpose statements produced by the
parties.   Industrial  adjudication  should  not  lean   too
heavily  on  such statements whilst attempting the  task  of
deciding  the  financial  capacity of the  employer  in  the
context  of  the wage problem.  Taking a  broad  view  which
emerged  from  a consideration of all  the  relevant  facts,
there is little doubt that the productivity of the  industry
is increasing and that the demand for textile products  will
never  decrease  in  future.  It is true  that  the  textile
industry  at  Ahmedabad  has been leaning  very  heavily  on
borrowing%  but  that is a peculiar feature of  the  textile
industry  at  Ahmedabad.  It helps the  development  of  the
industry and so the extent of borrowings, cannot be  pressed
into  service for the purpose of showing that the  financial
position   of  the  industry  is  unsatisfactory.   On   the
contrary,  the harmonious relations which have  consistently
subsisted  between  the employer and the.  employees,  would
help  the  textile industry in Ahmedabad  in  its  prospects
towards     speedy economic growth. [420 C-E, F-G; 421  A-C.
E-G, H-; 422 C, G-H; 426 B, F; 427 G-H; 428 A, D; 429 D]
JUDGMENT:
CIVIL APPELLATE JURISDICTION : Civil Appeals Nos. 167 to, 173, 537 and 538 of 1965.
Appeals by special leave from the award dated October 26, 1964 of the Industrial Court Gujarat in
Reference (I.C.) No. 67 of 1964.
M. C. Setalvad, R. J. Kolah, 1. M. Nanavati, J. B. Dada- chanji, O. C. Mathur and Ravinder Narain,
for the appellant (in CA. No. 167 of 1965).
R. J. Kolah, I. M. Nanavati, J. B. Dadachanji, O. C. Mathur and Ravinder Narain, for the appellants
(in C. As. Nos. 168 and' 170 of 1965).
N. A. Palkhivala, 1. M. Nanavati, J. B. Dadachanji, O. C. Mathur and Ravinder Narain, for theAhmedabad Mill Owners' Association Etc vs The Textile Labour Association on 10 August, 1965

appellants (in C. As. Nos.. 169 and 173 of 1965).
I. M. Nanavati, J. B. Dadachanji, O. C. Mathur and Ravinder Narain, for the appellants (in C. As.
Nos. 171 and 172 of 1965).
J. B. Dadachanji, O. C. Mathur and Ravinder Narain, for the appellants (in C. As. Nos. 537 and 538
of 1965). S. R. Vasavada, N. M. Barot, N. H. Shaikh, R. M. Shukla, A. N. Buch and D. T. Trivedi, for
the respondents. C. K. Daphtary, Attorney-General, K. L. Hathi and B. R. G. K. Achar, for intervener
NO. 1.
G. .B. Pai, J. B. Dadachanji, O. C. Mathur and Ravinder Narain, for intervener No. 2.
G. Ramanujam, for intervener No. 4.
B. Narayanaswami, J. B. Dadachanji, O. C. Mathur and Ravinder Narain, for intervener No. 5.
I. M. Nanavati, J. B. Dadachanji, O. C. Mathur and Ravinder Narain, for intervener No. 6.
H. K. Sowani and K. R. Chaudhuri, for intervener No. 7. The Judgment of the Court was delivered by
Gajendragadkar, C.J. This is a group of seven appeals which arise from an industrial dispute
between the appellants, the Ahmedabad Millowners' Association, Ahmedabad, and 67 em- ployers
on the one hand, and the respondent, the Textile Labour Association, Ahmedabad, on the other.
This dispute was referred by the Government of Gujarat to the Industrial Court, Gujarat, under
section 73 of the Bombay Industrial Relations Act, 1946 (No. XI of 1947) (hereinafter called 'the
Act'). In making the order of reference, the Government stated that it was satisfied that the
industrial dispute in question was not likely to be settled by other means. The dispute itself
consisted of three questions. These questions have been thus stated in the reference :"(1) Whether
under the award of the Industrial Court, Bombay, dated the 2nd March, 1950, in Reference (1C) No.
189 of 1949 (as subsequently modified) read with award of the Industrial Court dated the 27th April,
1948, in Revision Petition No. Misc. 1 of 1947, the Ahmedabad Millowners' Association and the
emploers mentioned in the Annexure are bound to payness allowance to their employees on the
Consumer Price Index Numbers for working class for Ahmedabad published by the State
Government since February, 1964, by using the index numbers in the series for Ahmedabad
compiled by the Labour Bureau, Simla, and the linking factor of 3.17 adopted for linking that series
to the State series with the old base;
(2) If not, whether the said Ahmedabad Mill-
owners' Association and the employers mentioned in the Anexure should pay dearness allowance to
their employees for March, 1964 and subsequent months in terms of the aforesaid awards, by
treating the index numbers for working class for Ahmedabad published by the State Government
since February, 1964, as the index numbers in the State series compiled on the basis of the family
budget survey made in 1926-27;Ahmedabad Mill Owners' Association Etc vs The Textile Labour Association on 10 August, 1965

(3) If not, how the dearness allowance to the aforesaid employees for March 1964 and onwards
should be paid on the index numbers for Ahmedabad published by the State Government since
February, 1964".
The Industrial Court has answered the first question in favour of the appellants, whereas the two
remaining questions have been answered in favour of the respondent. In the result, the appellants
have been directed to pay dearness allowance to their employees for the month of March, 1964 and
for subsequent months on the consumer price index numbers for working class for Ahmedabad
published by the State Government since February, 1964, (by using the index numbers in the series
for Ahmedabad compiled by the Labour Bureau, Simla, and the linking factor of 3.17 adopted for
linking that series to the State series with the old base) at the rate of 2.84 pies per day for rise of
each point in the cost of living index number over the pre-war figure 73. The Industrial Court has
further directed that as per the award in Miscellaneous Application (1C-G) No. 1 of 1960, 75% of the
average dearness allowance of the first six months of 1959, i.e., Rs. 63-15-9 per month of 26 working
days, shall be consolidated with the basic wage and the difference between the dearness allowance
as worked out as indicated and the said sum of Rs. 63-15-9 shall be continued to be paid as dearness
allowance. The other terms and conditions in regard to payment of wages, including the dearness
allowance, shall continue as under the existing award. The Industrial Court has made it clear that
these directions should be given effect to from 1st of January, 1965 and the difference between what
is paid and what has become payable under the present award shall be paid on or before April 30,
1965. It appears that before the Industrial Court an agreement had been reached between the Fine
Knitting Co. Ltd. of Ahmedabad and the Textile Labour Association, and the award has, therefore,
provided that the directions issued by it shall apply only to the spinning department of the Fine
Knitting Co. and not to the hosiery department. It is against this award that the appellants have
come to this Court by special leave. On January 5, 1965, while granting special leave to the
appellants, this Court directed that the statements of the case should be dispensed with and the
appeals be listed for hearing in the week commencing March 8, 1965. That is how these appeals have
now come for final disposal before us. Before dealing with the points raised by the appellants in
these appeals, it is necessary to set out somewhat elaborately the previous history of the present
dispute. The story about the payment of dearness allowance to textile industrial employees at
Ahmedabad takes us back to the time when the Second World War broke out in September, 1939. As
is well-known, as a result of the said War, the cost of living shot up; and in consequence, the
industrial employees at Ahmedabad who had organised themselves as the Textile Labour
Association, Ahmedabad, raised a demand for payment of dearness allowance. This demand became
the subject- matter of arbitration by the Industrial Court at Bombay (Case No. 1 of 1940). The
Industrial Court had to consider, inter alia, two major questions; the first was as to what was the
extent of the rise in the cost of living consequent upon the Second World War; and the second was
as to the extent and manner in which the said rise in the cost of living should be neutralised by the
payment of dearness allowance. The Industrial Court examined the matter at great length and came
to the conclusion that for the purpose of determining the quantum of dearness allowance to be paid
to the employees, it would be reasonable to rely on the working class budget inquiry which had been
conducted by the Government of Bombay between August, 1926 and July, 1927. Another similar
inquiry had been conducted by the same Government in 1933-35, but the Industrial Court preferred
to base its conclusions on the first inquiry. On the basis of the cost of living index taken as 100 forAhmedabad Mill Owners' Association Etc vs The Textile Labour Association on 10 August, 1965

the base year 1926-27, the index for August 1939 which stood at 73 was accepted as datum index, so
that the rise in cost of living over the datum index of 73 had to be neutralised by payment of
dearness allowance to the employees.
Having reached this conclusion on the first question, the Industrial Court examined the problem as
to the extent and method by which the rise in the cost of living should be neutralised. On this
question, its conclusion was that for 11 points rise (which is equivalent to a rise of 15%) in the cost of
living for the month of December, a cash relief to the extent of 10 per cent of the average wage, i.e.
Rs. 3-8-0 per employees, should be awarded for the month of December and a similar relief
proportionately determined should be awarded for other months. It was urged before the Industrial
Court that relief could be granted to the employees in kind rather than in cash; but this contention
was negatived by the Court, though it expressed a hope that the employers should start cost price
grain shops at convenient centres for the benefit of the employees. That, in substance, is the result of
the proceedings in Case No. 1 of 1940. It is with the decision of this dispute that the story about the
payment of dearness allowance under an award began in Ahmedabad in respect of textile labour. It
appears that as a result of this award, 66-2/3 per cent neutralisation was allowed. This award
continued to be in operation till September, 1941. On August 12, 1941, an agreement was entered
into between the. appellants and the respondent by which it was resolved that the dearness
allowance to be paid to the employees in the member Mills of the appellant Association be raised by
45 per cent from the month of July, 1941, and in accordance with this agreement, an award was
made by the Industrial Court on September 15, 1941. As a result of this award, neutralisation came
to be effected to the extent of 96% on the average wage over the pre-war cost of living index of 73 in
August, 1939, and to that extent the respondent gained. We have already noticed that the
neutralisation which was effected by the earlier award was 66-2/3 per cent.
Two years thereafter, the appellant Association filed a petition (No. 1 of 1943) for a substantial
reduction in the quantum of dearness allowance. It urged that in the year 1943, the textile industry
at Ahmedabad had suffered considerable loss in its profits, and so, it was necessary that the
dearness allowance fixed by the consent award should be reduced. When the matter was considered
by the Industrial Court, it was discovered that the claim made by the appellant Association was not
substantiated by sufficient or satisfactory data in the form of published balance-sheets for the year
1943. The Industrial Court, therefore, refused to interfere with the award, but permitted the
appellant Association to raise the same dispute in April, 1944 if it thought necessary to do so. No
such application was, however, made by the appellant Association in 1944, with the result that the
consent award passed on September 15, 1941, continued to be in operation. The said consent award
had provided that the member mills were to pay the dearness allowance prescribed by it till the
termi-
nation of the Second World War; and so, as soon as the war came to an end, the member mills
stopped the payment of dearness allowance with effect from May 8, 1945. The respondent then filed
Petition No. 1 of 1945 before the Industrial Court asking for a direction against the appellant
Association for payment of' the dearness allowance on the same scale as was then prevailing for
three months after May 8, 1945. This prayer was .granted by the Industrial Court. That is how
matters stood as a result of the order passed on Petition No. 1 of 1945.Ahmedabad Mill Owners' Association Etc vs The Textile Labour Association on 10 August, 1965

Meanwhile, the respondent gave a notice of change on May 20, 1945 and demanded continuance of
the payment of dearness allowance until the working class cost of living index for Ahmedabad stood
above 73. It suggested that the quantum of dearness allowance should be related to the cost of living
index as awarded by the Industrial Court Award dated the 26th April, 1940, and revised by the
subsequent Award dated the 15th, September, 1941. While making this demand, the respondent
made it clear that this demand was made without prejudice to the claim of the employees for a
revision in the entire wage structure. It appears that during the course of these proceedings, it was
urged before the Indus- trial Court that the rise in the cost of living should be computed not with
reference to the index figure of 73 in August, 1939, but with reference to the figure of 100 in
1926-27. This contention was, however, rejected by the Industrial Court. By its award, the Industrial
Court directed that neutralisation should be effected to the extent of 76 per cent. As a result of this
decision, the Court awarded Rs. 4 for 11 points rise in the cost of living index.
In 1946, the respondent moved for the revision of the said award (Revision Petition No. 1 of 1946).
By this revision petition, the respondent claimed that the rise in the cost of living should be
neutralised fully instead of 76%, and this claim was based on the allegation that the profits of the
textile industry had maintained a high level and the reduction in the extent of neutralisation from
96% to 76% in the award of the previous year had adversely affected the employees and they had in
fact begun to leave the industry. It may be pointed out that on all these occasions, the appellant
Association urged before the Industrial Court that the average monthly income and expenditure of
the textile employees in Ahmedabad left surplus with them and the need for neutralising the rise in
the cost of living was not as much as was sought to be made out by the respondent. This contention
has, however, been consistently rejected by the Industrial Court. Even so, the claim made by the
respondent for increasing the extent of neutralisation was rejected by the Industrial Court, liberty
being reserved to both the parties to approach the Court with a request for continuance or revision
of the allowance at the end of seven months.
As soon as seven months expired, the respondent tiled a Revision Petition (No. 1 of 1947) before the
Industrial Court on March 8, 1947. By this petition, the respondent renewed its claim for an increase
in the dearness allowance. Meanwhile, the minimum wage for textile employees in Bombay had
been fixed at Rs. 30 and dearness allowance was awarded to them with the object of neutralising the
rise in the cost of living to the extent of 90% on the minimum wage of Rs.
30. Taking advantage of the fact that the minimum wage for textile employees in Bombay had been
fixed at Rs. 30, the appellant association urged that there was no occasion to increase the rate of
dearness allowance because the wages of the employees had already been increased under the
standardization scheme which had been adopted in Ahmedabad. Alternatively, the appellant
Association contended that if the Court was inclined to revise the dearness allowance, it should
follow the same formula as in Bombay and provide for neutralisation at the most at 90% on the
minimum wage of Rs. 28 in Ahmedabad. This contention was, however, rejected by the Industrial
Court. By its award, the Court directed that the rise in the cost of living over pre-war level of 73 in
the case of the lowest paid employee should be neutralised to the extent of 100% and all employees
earning Rs. 150 or less a month should be paid at a flat rate. On arithmetical calculation, it was
found that this rate came to 2.84 pies per day for rise of each point in the cost of living indexAhmedabad Mill Owners' Association Etc vs The Textile Labour Association on 10 August, 1965

number over the pre-war figure.
The appellant Association issued a notice on October 31, 1949, purporting to terminate this award
with effect from 1st January, 1950. The -round for terminating, the award set out by the appellant
Association in its notice was that the textile industry in Ahmedabad was passing through a crisis and
that certain mills were completely closed down while others were partially closing down. It appears
that about that time, the Central Government acting in pursuance of the recommendations made by
the Tariff Board, directed a 4% cut in ex-mill cloth prices; and that, according to the appellant
Association, led to a crisis in the financial affairs of the textile industry at Ahmedabad. It was also
alleged in the notice that though the prices fixed were uniform, the dearness allowance paid was not
uniform and that the member mills of the appellant Association were paying Rs. 15-4-0 more per
month per employee in dearness allowance at Ahmedabad as compared to that paid to the textile
employees in Bombay. Arithmetical calculations showed that as a result of this extra payment, the
Ahmedabad mills had to bear an additional burden of Rs. 238 lakhs in 1949 as compared to the
burden bore by the Bombay textile mills.
Before the notice thus issued by the appellant Association came into force, the respondent gave a
notice of change to the mills to continue to pay the dearness allowance according to the existing
award; and since no settlement could be reached between the parties, a reference was made to the
Industrial Court. As a result of these proceedings, however, neither party scored a victory, and the
award directed that payment of the dearness allowance should be made in accordance with the
orders passed in Revision Petition No. 1 of 1947. Since the date when this order was made, the terms
of the award in Revision Petition No. 1 of 1947 have been in operation between the parties.
Meanwhile, the Central Wage Board for the Cotton Textile Industry was constituted. One of the
points which the Wage Board had to consider was the demand made by the employees for
consolidating a part of the dearness allowance in the basic wage. The Wage Board recommended
that 75% of the dearness allowance should be consolidated in the basic wage, and the remaining 25%
should bear a flexible character. The Board also made other recommendations which are not
relevant for our purpose. In consequence of the recommendation made by the Board as to the
consolidation of the dearness allowance, an agreement was reached between the appellant
Association and the respondent, as a result of which a joint application (No. 1 of 1960) was made by
both the parties under s. 11 6A of the Act; and on this joint application an award by consent was
passed directing that 75% of the average dearness allowance of the first 6 months of 1959 which is
Rs. 63-15-9 p.m. of 26 working days should be con- solidated with the basic wage, and the balance of
the dearness allowance should be paid as worked out on the existing basis. That is how matters then
stood between the parties.
It appears that about this time, there was a growing feeling amongst both the employers and the
employees that the different series of consumer price index compiled and published in India were
not very satisfactory and some of them had become obsolete. In the Second Five Year Plan, it was,
therefore, recommended that it was desirable that steps should be taken simultaneously with the
undertaking of wage census to institute enquiries for the revision of the present series of cost of
living indices at different centres. According to the recommendation made by the Planning
Commission Report, the Labour Bureau, Simla, and the Central Statistical Organisation of theAhmedabad Mill Owners' Association Etc vs The Textile Labour Association on 10 August, 1965

Government of India took steps to conduct fresh family living surveys among working class and
middle class population respectively with a view to construct the new series of consumer price index
numbers. The working class surveys were conducted at 50 selected centres and the middle class
surveys at 45 centres, 18 centres being common to both. The work of these surveys was commenced
in the second half of 1958 and was concluded by September, 1959. One of the centres selected for
this survey was Ahmedabad. The Government of India began to publish consumer price index
number for the city of Ahmedabad, having index number 100 for the base year 1960. The
publication of these series naturally raised the problem of arriving at a linking factor between the
present series published by the State Government and the new series published by the Government
of India. The Government of India considered this problem and indicated that 2.98 would be a
proper linking factor. This figure was arrived at as a result of taking the annual average of the
monthly index numbers of the State series for 1960 which then stood at
298. For the base year of 1960, the figure of the new series was 100 and the linking factor was,
therefore, taken at 2.98.
It then appeared clear that there were several anomalies in regard to the collection of prices in the
State series. Some of the items which were specified in such series had ceased to exist, whereas
quotation for one major item, viz., house rent allowance had been frozen for many years. After the
Government of India began to publish its new series, it advised' the Government of Gujarat to stop
publishing its old series and publish the converted index in its place. The Government of India
thought that it would be unjust to the employees if the conversion were allowed to take place
without removing anomalies of the State series. Faced with this problem, the Government of Gujarat
set up an expert Committee under the Chairmanship of Dr. M. B. Desai. The terms of reference of
this Committee were thus formulated "(1) to examine the validity of the submissions and
representations made to Government and to make recommendations as to whether any
readjustment is necessary in the existing series for Ahmedabad published by the State Government,
and if so, what readjustment should be made;
(2) to consider how the new series of Consumer Price Index Numbers for Ahmedabad should be
linked with the existing series, so readjusted if found necessary; and in so considering, to take into
consideration the factor that the period of family budget enquiry on which the new series for
Ahmedabad is based is different from the base period for the said new series".
The said Committee made a fairly exhaustive investigation, and made two main recommendations.
The first recommendation involved an addition of 19 points in the overall price index in the State
series and the same was fixed at 317 instead of 298 as it stood when the new series and its base
period were decided upon. The other recommendation which it made was that the conversion or the
linking factor should be 3.17 as against 2.98 per point in the new series.
The Government of Gujarat accepted the first recommendation and revised the index number for
the month of November, 1963, by adding 19 points to the figure originally released by it and stated
that its existing series would be adjusted month to month by the addition of 19 points for adjusting
the index for clothing and house rent groups as recommended by the Expert Committee. In regardAhmedabad Mill Owners' Association Etc vs The Textile Labour Association on 10 August, 1965

to the second recommendation, the Government took the view that it was necessary to continue
publication of the current series to permit industry and labour time to have necessary modifications
in the existing agreements, settlements and awards made to link up the dearness allowance with the
new series published by the Labour Bureau, Simla. This decision was announced by the Government
by a Press Note on January 31, 1964.
When this decision of the Government of' Gujarat was announced, the appellant Association found
that it entailed considerable additional burden on the textile industry even so, it advised its member
mills to pay the dearness allowance according to the adjusted consumer price index number by
adding 19 points for the month of January, 1964, under protest. This protest was expressed by the
President of the Appellant Association by issuing a press communique criticizing the Government
for its unilateral and hasty decision in the matters.
On February 29, 1964, the Government of Gujrat issued another Press Note by which it accepted the
second recommendation made by the Expert Committed to take the linking factor at 317 instead of
298. The Press Note shows that this decision was reached by the Government of Gujarat in
accordance with the advice received from the Government of India. In consequence of this decision,
the Government of Gujarat discontinued publication of the cost of living index number of its
1926-27 numbers from January, 1964. This decision of the Government raised a storm of protest
from the appellant Association. A general meeting of the members of the appellant Association was
held on March 30, 1964, and it passed a resolution to the effect that the discontinuance of the
publication of the cost of living index by the Government of Gujarat made it impossible for the
appellant Association to comply with the terms of the existing award in respect of the payment of
dearness allowance in the manner prescribed by the award and so, the appellant Association advised
its members to pay to their employees dearness allowance for the month of March, 1964, calculated
on the basis of the last published index number for the month of December, 1963 in the State's
1926-27 series and to continue to pay dearness allowance for succeeding months on the basis of the
same index number till such time as the Government of Gujarat resumed publication of index
numbers in the said series. According to the appellant Association, as a result of the decision of the
Government of Gujarat, an unbearable burden would be imposed on the members of the appellant
Association in the matter of dearness allowance; and so, it was not prepared to accept that decision.
When the appellant Association adopted this attitude, the .Secretary of the respondent Association
expressed his profound sorrow at the decision of the appellant Association, and by his letter
addressed to the appellant Association on April 3, 1964, he requested the members of the appellant
Association to pay dearness allowance to their employees according to the converted number
published by the Government of Gujarat. This letter was accompanied by a resolution passed by the
respondent Association in which it set forth its version of the financial position of the members of
the appellant Association and the justice of the claim made by the employees for the payment' of
dearness allowance in accordance with the decision of the Government of Gujarat. 'no appeal thus
made by the Secretary of the respondent Association did not, however, receive any sympathetic
response from the appellant Association; and that made it necessary for the Government of Gujarat
to refer the present dispute to the Industrial Court at Gujarat under s. 73 of the Act. That, broadly
stated, is the background and the previous history of the present dispute. At the hearing of the
present reference before the Industrial Court the appellants had urged a preliminary objectionAhmedabad Mill Owners' Association Etc vs The Textile Labour Association on 10 August, 1965

against 3 9 6 the competence of the present reference. They contended that the reference under s. 73
of the Act was invalid, because, before making the reference, the requirements of s. 42 of the Act had
not been complied with. The argument was that, in substance, the reference relates to a change in
the terms of the award binding between the parties, and for effecting such a change, the procedure
prescribed by S. 42 and the other sections in Chapter VIII of the Act has to be complied with. It is
common ground that the -said procedure has not been followed and the Government of Gujarat has
made the present reference in exercise of the power ,conferred on it by s. 73. The Industrial Court
has rejected the appellants' contention and has held that the reference is valid. Mr. Setalvad for the
appellants has urged before us that the view taken by the Industrial Court is not justified by the
terms of S. 73 read along with s. 42 of the Act. The Act was passed by the Bombay Legislature in
1947. It purports to regulate the relations of employers and employees, to make provision for
settlement of industrial disputes, and to provide for certain other purposes. It is a comprehensive
piece of legislation and it makes elaborate provisions for the regulation of relations between
employers and employees and for the settlement of disputes between them. Section 42 of the Act
provides for a notice of change. It is unnecessary to cite the provisions of the said section, because
for the purpose of dealing with the point raised by Mr. Setalvad, it would be enough if we state the
sum and substance of S. 42 (1) & (2). Section 42 (1) provides that if an employer intends to effect any
change in respect of an industrial matter specified in Schedule II, he will have to give notice of such
intention in the prescribed form to the representative of employees. Similarly,s. 42(2)provides that
if an employee desires a change in respect of an industrial matter not specified in Schedule I or III,
he shall give notice in the prescribed form to the employer through the representative of employees.
Mr. Setalvad relies on the fact that Entry 9 in Sch. II relates to wages including the period and mode
of payment, and be points out that the definition of "wages" prescribed by S. 3(39) includes dearness
allowance. His case is that the present dispute falls under Sch. 11, Entry 9, and if the employees had
intended to make a change in the existing award in relation to the payment of dearness allowance, it
would have been necessary for them to take action as prescribed by s. 42(2). Since it is common
ground that no notice of change has been given by the respondent, it is urged that the reference
made by the Government of Gujarat under S. 73 -of the Act is invalid. It would be noticed that this
argument assumes that the provisions of S. 42 would govern the provisions of S. 73. The question is:
is this assumption well-founded ?
Let us then read S. 73; it reads thus :-
"Notwithstanding anything contained in this Act, the State Government may, at any
time, refer an industrial dispute to the arbitration of the Industrial Court, if on a
report made by the Labour Officer or otherwise it is satisfied that-
(1) by reason of the continuance of the dispute (a) a serious outbreak of disorder or a
breach of the public peace is likely to occur;
(b) serious or prolonged hardship to a large section of the community is likely to be
caused; orAhmedabad Mill Owners' Association Etc vs The Textile Labour Association on 10 August, 1965

(c) the industry concerned is likely to be seriously affected or the prospects and
scope, for employment therein curtailed; or (2) the dispute is not likely to be settled
by other means; or (3) it is necessary in the public interest to do so".
On a fair reading of s. 73, it is plain that it deals with the powers of the State Government to make a
reference and as such, it is difficult to assume that the said powers of the State Government are
intended to be controlled by the provisions of S. 42. Section 42 prescribes the procedure which has
to be followed by the employer and the employee respectively if either of them wants a change to be
effected as contemplated by it. The scheme of S. 42 read along with the other provisions in Ch. VIII
clearly shows that the said Chapter can have no application to cases where the State Government
itself wants to make a reference. That is the first consideration which militates against the
construction which Mr. Setalvad suggests. The opening clause in s. 73 also unambiguously indicates
that the power of the State Government to make a reference will not be controlled by any other
provision contained in the Act. This clause plainly repels the argument that the provisions of S. 42
should be read as controlling the provisions of s. 73. The meaning of the non-obstante clause is clear
and it would be idle to urge that the requirements of S. 42 must be satisfied before the power under
s. 73 can be invoked by the State Government.
Sup.Cl/65-11 It is, however, urged that the power conferred on the State Government by s. 73 is the
power to refer an industrial dispute to the arbitration of the Industrial Court, and there can be no
industrial dispute unless a notice of change has been given either by the employer or the employee.
In other words, the argument is that unless a notice of change is given as required by s. 42, no
industrial dispute can be said to arise between the employer and his employee, and that is how s. 42
governs s. 73. If it was the true legal position that there can be no industrial dispute between an
employer and his employee unless a notice of change is given by either of them, there would have
been some force in this contention but the definition of the words "industrial dispute" does not
justify the assumption that it is only a notice of change that brings into existence an industrial
dispute. Section 3(17) of the Act defines an "industrial dispute" as meaning any dispute or difference
between an employer and employee or between employers and employees or between employees
and employees and which is connected with any industrial matter. This definition is so wide and
comprehensive that it would be impossible to accept the argument that it introduces the limitation
suggested by Mr. Setalvad. Even if an award is subsisting between the parties but a difference arises
between them, as in the present case, it is not easy to hold that the said difference does not amount
to an industrial dispute for the purpose of s. 73 merely because notice of change has not been given
either by the employer or the employee. Therefore, we are satisfied that the dispute which has been
referred by the Government of Gujarat in the present case must be treated as an industrial dispute,
notwithstanding the fact that s. 42 has not been complied with either by the appellants or by the
respondent.
It is true that the power conferred on the State Government to make a reference is not absolute or
unqualified. It can be exercised only if one or the other of the conditions specified by sub-sections
(1), (2) or (3) of s. 73 is satisfied. But once the State Government comes to the conclusion that one or
the other of the said conditions is satisfied, its power to make a reference is not limited to cases
where notice of change has been given by the parties as required by s. 42. It is an over-riding powerAhmedabad Mill Owners' Association Etc vs The Textile Labour Association on 10 August, 1965

which is intended to be exercised to avoid anomalies or other serious consequences which would
flow in case the Government does not make an immediate reference. The requirements prescribed
by sub-sections (1), (2) and (3) of S. 73 indicate the types of cases which are intended to be referred
without requiring the parties to take recourse to s. 42. In the present case, the Government of
Gujarat was satisfied that the dispute was not likely to be settled by other means, and so, it made the
present reference. Therefore, we do not think there is any substance in the argument that the
reference is bad, because s. 42 has not been complied with. The terms of s. 73 are plain and
unambiguous and them leave no doubt that the power of the State Government to make the
reference is not at all controlled by the requirements of s. 42.
On principle, the conferment of this power seems to be fully justified. If as a result of a dispute
between the employer and his employees, a serious outbreak of disorder or a breach of the public
peace is likely to occur, or a serious or prolonged hardship to a large section of the community is
likely to be caused, or the industry concerned is likely to be affected adversely, it would be idle to
require that even in the face of such a serious danger, the procedure prescribed by s. 42 must be
followed before reference can be made under s. 73. The very nature of the conditions prescribed by
sub-sections (1), (2) and (3) of s. 73 emphasises the fact that the said conditions refer to categories
of cases or types of occasions on which reference has to be made promptly and immediately, and
that explains the conferment of the wide powers on the State Government as prescribed by s. 73. We
are, therefore,, satisfied that the Industrial Court was right in coming to the conclusion that the
preliminary objection raised by the appellant-, against the competence of the present reference was
misconceived. It appears that a similar view has been expressed by the Bombay High Court in
Suryaprakash Weaving Factory v. The Industrial Court(1).
That takes us to the merits of the controversy between the parties in the present appeals. Let us
begin by briefly indicating the broad contentions raised by the appellants before the Industrial Court
and its findings on them which are relevant for the purpose of the present appeals. The first
contention which was urged before the Industrial Court was that the family living survey which was
conducted by the Labour Bureau, Simla, in 1958-59, was unreliable, because the sample survey on
which it was based was inadequate, and the interview method which was adopted in conducting it
was unsatisfactory. It was also contended that the linking factor at 3.17 which had been adopted by
the Government of Gujarat was unscientific and irrational; and that the scientific and rational way
to deal with the problem presented by the new (1) 53 B.L.R. 902 consumer price index recently
adopted by the Government of Gujarat would be to devise a scheme of dearness allowance afresh,
taking the present basic salary as a base, and relating it to the changing price pattern from month to
month with the base year 1960 = 100. The appellants' case in respect of this aspect of the matter was
that for the purpose of fixing the dearness allowance, the basic salary should be taken to be the total
amount which is paid to the lowest-paid employee after consolidating 75% of the dearness allowance
in the basic wage. That amount, it is said, represents the true basic wage today. In the alternative, it
was suggested that if it is intended to correlate the present prevailing wage structure, including the
scheme of payment of dearness allowance, by making suitable adjustments required by the change
in the level of prices in the light of the new consumer price index with the same base year, it would
be more rational and scientific to watch the behaviour of prices for two or three years and then
devise a linking factor on the average rise in prices during the said period. The appellants alsoAhmedabad Mill Owners' Association Etc vs The Textile Labour Association on 10 August, 1965

emphasised the fact that before the Industrial Court accepts the new arrangement on the basis of the
linking factor of 3.17, it is essential to examine their paying capacity, and in this connection, they
strongly urged that the burden which would be imposed on them by the new scheme would be
plainly beyond their capacity.
The validity of these contentions was strenuously disputed by the It urged that the, sample survey
was conducted on rational and scientific lines and it did not suffer from any infirmity at all. It
further argued that the attempt to construct a new wage structure by taking the basic salary with
75% of the consolidated dearness allowance as the basis with 1960 := 100 as the base year, would be
beyond the terms of reference, and it would, besides, create many problems and complications.
According to the respondent, the basic salary still continues to be what it was before, though for
practical purposes 75% of the dearness allowance has been consolidated with it. The respondent
seriously challenged the appellants' case that the operation of the linking factor was either
unscientific, unreasonable or unjust; and the appellants' theory that the average rise in prices should
be determined after watching the behaviour of prices for two or three years, was characterised by the
respondent as unreasonable, inexpedient and unscientific. The respondent emphatically contended
before the Industrial Court that the appellants' financial position was perfectly sound and the
argument that the burden would be beyond their capacity is wholly untenable.
During the course of hearing before the Industrial Court, the appellants examined two Experts, Mr.
Gokhale and Mr. Chokshi. They also led voluminous documentary evidence. The respondent filed
detailed statements disputing the correctness of the pleas taken by the appellants, and in support of
them, they filed several charts which were prepared from the balance-sheets of the appellants
themselves. Both parties referred to the opinions expressed by several writers on the subject of the
preparation of consumer price index and on other matters which became relevant for the decision of
the present dispute. Broadly stated, the Industrial Court has rejected all the contentions raised by
the appellants. It has found that the recent survey was conducted under the advice and guidance of a
technical advisory committee of a high order and that the work of carrying on the survey had
scrupulously followed the relevant recommendations made by the International Labour Office and
the United Nations. The Industrial Court did not accept the contention of the appellants that the
sample size was inadequate or had vitiated the quality of the survey. It held that the method of
inquiry adopted by the Investigators who conducted the survey was by no means unsatisfactory or
unscientific, and in its opinion, having regard to the local conditions, it was indeed the most feasible
and satisfactory way to adopt. The adoption of the interview method did not, in the opinion of the
Industrial Court, introduce any infirmity in the survey. The Industrial Court was thus not satisfied
that the compilation of the consumer price index number by the Labour Bureau, Simla, for the city
of Ahmedabad was not proper or was unscientific or suffered from any more infirmity. In regard to
the question of the linking factor on which both parties addressed the Industrial Court elaborately,
the Court consider the matter in the light of expert opinion cited before it and held that the
Government of India was justified in recommending a sample arithmetical method of linking; it
found that the said method had been accepted by the Expert Committee appointed by the
Government of Gujarat and had been recommended by the Expert Committee appointed by the
Government of Maharashtra as well. It, therefore, reached the conclusion that the said method
based on the application of the linking factor at 3.17 was the most suitable to adopt. In thisAhmedabad Mill Owners' Association Etc vs The Textile Labour Association on 10 August, 1965

connection, it rejected the appellants suggestion that the dearness allowance, should be paid at a flat
rate and held that flexible dearness allowance alone would meet the ends of justice and would lead
to industrial peace. It noticed the fact that now there was only one cost of living index existing in
Ahmedabad and that is based on the new series The old series had rightly gone out of existence since
it had become antiquated. In this situation, there were two possibilities; one was to work out an
entirely new scheme of basic wages based not on the prewar level of 1939 but based on the cost of
living of 1960 as the base year and to award dearness allowance thereafter. The Industrial Court
thought that if such a course was to be adopted, it would create a large number of problems in the
industry and would seriously disturb industrial peace. It observed that this aspect of the matter
would also be beyond the terms of its reference. Nevertheless, it was inclined to take the view that
"the results in terms of rupees, annas and pies may also not be very different", if this alternative,
method was adopted. It suggested that such a method may be adopted by the Central Cotton Textile
Wage Board which had been recently appointed with a view to bring out a fair amount of uniform
wage level all over India; but speaking for itself, it held that it would not be Necessary, advisable or
practicable for it to attempt that task. That left only one alternative and that is the adoption of the
arithmetical method of linking. The argument that even if the arithmetical method of linking is
intended to be adopted, it should be worked on the basis of the average result derived from watching
the behaviour of prices during two or three years, does not appear to have been seriously pressed
before the Industrial Court and has not been examined by it.
The Industrial Court then considered the question about the paying capacity of the appellants. As a
matter of law, it rejected the respondent's argument that a wage structure once constructed by
industrial adjudication can never be revised to the detriment of workmen, and it held that if it was
shown that the financial position of the employer had substantially deteriorated and such
deterioration was likely to persist for some time, it would be open to industrial adjudication to make
a suitable revision of the wage structure, provided, of course, the wage structure does not represent
the wages at their basic minimum level. Considering the problem presented by the appellants plea of
incapacity to bear the burden in the light of this legal position, the Industrial Court has found that,
in its opinion, the textile industry of Ahmedabad is in a sound financial position. It has also added
that "in any event, there has been no substantial deterioration in its condition so as to justify any
wage cut or abandonment of the basic principles in respect of its employees which have been laid
down in the past". It is on these findings that the Industrial Court has held against the appellants on
issuer, 2 & 3. As we have already mentioned, the Industrial Court has found against the respondent
on issue No. 1; but since the respondent has not challenged the correctness of the said finding, it is
only the conclusions of the, Industrial Court on issues 2 and 3 that fall to be considered in the
present appeals. The first point which we must now consider is whether the appellants are justified
in contending that the Industrial Court erred in over-ruling their contention that the new survey
suffered from two major infirmities-inadequacy of the sample size, and impropriety of the method
of interview adopted by the Investigators. In support of this plea, the appellants examined Mr.
Gokhale as an expert witness. Mr. Gokhale who served in the Labour Office at Bombay from 1926 to
1937, was directly associated with the family budget inquiries, compilation of cost of living index
numbers, and with the first General Wage Census conducted by the Labour Office in Bombay. He
also worked as Assistant Secretary of the Bombay Textile Labour Enquiry Committee. Later, he
joined the Millowners' Association, Bombay, as their Labour Officer on 1-1-1938 and served in thatAhmedabad Mill Owners' Association Etc vs The Textile Labour Association on 10 August, 1965

capacity until he retired on 1-11-1962. He was deputed on a study tour to Lancashire in 1951 and
attended the International Labour Conference at' Geneva. He has also been a member of the I.L.O.
Committee on Women's Employment. According to Mr. Gokhale, the 'new survey was not as
scientific as it might have been. He was inclined to take the view that the sample selected in the
Ahmedabad inquiries was very inadequate. He commented on the fact that the choice of the size of
sample was determined, inter alia, on the ground of the workload manageable by the investigator,
and he said that it was difficult for him to understand as to why in deciding the sample size.
"workload manageable by the investigator" had to be considered as a relevant factor. He then
produced a chart showing the ratio of the size of the universe with the size of sample, and said that
nowhere had he found such a low size of the sample as in the impugned inquiry. The size of the
sample, according to him, in the impugned inquiry was less than even half a per cent of the
population group which was intended to be covered.
Mr. Gokhale was cross-examined by the respondent. It was put to him that his experience in the
matter of sample survey was somewhat limited and that the said experience had now become
antiquated in view of the great strides of progress which had been made in the science of sample
survey after 1926. He agreed that sampling technique involves knowledge of statistics and statistics
involves mathematics, and he did not make any claim to be an expert either in statistics or in
mathematics. In his examination-in-chief, Mr. Gokhale appeared to criticise the extent of
imputation which was evident in the preparation of the new series; but in his cross-examination, he
fairly conceded that amputations have always got to be done in compiling consumer price index. It
had been done in the past, he said, as also in the case of the present series. When he was asked
whether he knew what the percentage of imputation was in the compilation of the consumer price
index of 1926-27, he admitted that he did not know. He was, however, reluctant to agree with the
Labour Bureau in so far as the application of their reasons to individual items was concerned, and in
support of his theory he relied upon the illustrations given by him in the affidavit which he had filed
before he gave evidence.
The statements made by Mr. Gokhale in his affidavit were disputed by the respondent and the
accuracy and the validity of the views expressed by him were seriously challenged by Mr. Vasavada
who filed a reply on behalf of the respondent (Item 19). In his reply, Mr. Vasavada referred to Clause
14 of the Resolution as reported at p. 403 of the International Labour Code-1951 Vol. III; and
emphasised the fact that the main distinguishing feature of the new survey was that it was carried
out under the technical guidance of professional statisticians not only with adequate knowledge of
sampling theory but also with actual experience in sampling practice, and with the help of a properly
trained field and computing staff. This was the requirement laid down by the publications issued by
the I.L.O. and the United Nations as a very important test, and the impugned survey fully satisfies
the said test. Mr. Vasavada also referred to the opinion expressed by Dr. Basu who is at present the
I.L.O. Expert on the subject, that the size of the sample should be determined in the light of the
permissible margin of error in the resulting series of consumer price index numbers. In our country,
the permissible margin of error in the index has been broadly set at 2 per cent; and so, the case set
out by Mr. Vasavada on behalf of the respondent was that when the permissible margin of error in
the index is 2%, the number of families, viz. 722 taken at Ahmedabad, is highly satisfactory.Ahmedabad Mill Owners' Association Etc vs The Textile Labour Association on 10 August, 1965

Mr. Vasavada then questioned the accuracy of Mr. Gokhale's statement that such a small percentage
of the universe had never been adopted before in any other inquiry. He urged that the present
techniques have advanced so far that a small sample size can achieve the best results; and he cited
the example of a survey carried out in the United Kingdom where the proportion of 13,000
households surveyed to the total households which constituted the universe came to 0.1%. The
Industrial Court has considered the evidence given by Mr. Gokhale and has taken into account the
arguments urged on behalf of the respondent, and it has held that the size of the sample selected for
the impugned survey cannot be said to introduce any infirmity in the survey. The question which we
have to decide is whether the Industrial Court was right in coming to this conclusion.
In dealing with this question, it is necessary to refer briefly to the genesis and growth of the science
of Social Survey. "In, its broadest sense", says the Encyclopedia of the Social Sciences, " social
Survey is a first hand investigation, analysis and coordination of economic, sociological, and other
related aspects of a selected community or group. Such a survey may be undertaken primarily in
order to provide material scientifically gathered, upon which social theorists may base their
conclusions; or its chief purpose may be to formulate a programme of amelioration of the conditions
of life and work of a particular group or community"(1). Wells defines a social survey as a
"fact-finding study dealing chiefly with working-class poverty and with the nature and problems of
the COmmunity"(2). As Moser has, however, pointed out, "this definition might have covered the
classical community and poverty studies but would hardly be adequate, the first part at any rate, to
the modern forms of survey"(3). The history of social survey in England can be said to have begun
with the publication of May hew's book "London Life and the London Poor" published in 1851; and
Booth made a very significant contribution to the scientific development of social survey by
publishing his book "Labour and Life of the People of London" (1889-1902). Rowntree followed with
his book "Poverty: A Study of Town Life". Thereafter, a number of studies have been made by social
scientists, and the subject of the theory and practice of social surveys has been the subject-matter of
valuable and extensive literature all over the civilised world. During the First World War and
thereafter, social scientists devoted their attention to the problem of family living studies mainly
from the point of view of the impact of price changes on consumers' economic situation. The
development of reliable consumer Price indices naturally involved the use of weights that (1)
Encyclopaedia of the Social Scinces, Vol. XIV edited by Edwin R. A. Seligman, p. 162 (2) Wells. A. F.
(1935). The Local Social Survey in Great Britain, Allen and Unwin, London.
(3) "Survey Methods in Social Investigation" by C. A. Moser, P. 1.
would properly reflect the consumption expenditure of the population. This led to further extension
of family living studies in different countries and for different periods, mainly to secure information
on patterns of consumption expenditure(1).
The Second World War and the conditions that flowed from it made it necessary to carry on
investigations on a wide range of inquiry relating to all aspects of conditions, c.g., nutrition, health,
education and employment. The whole question of family living survey came up for consideration in
the Seventh International Conference of Labour Statisticians in 1949. This Conference adopted a
resolution defining the objectives of family living studies and setting new international standards asAhmedabad Mill Owners' Association Etc vs The Textile Labour Association on 10 August, 1965

regards the Organisation of enquiries and the analysis and presentation of the results that flowed
from it(1).
In India, a standardised statistical type of family living study was -first initiated in Bombay in 1921.
Such enquiries were also conducted in Sholapur in 1925, in Ahmedabad in 1926 and in some centers
in Bihar in 1923. While reviewing the position of social surveys in India, the Royal Commission on
Labour pointed out the great paucity of statistical material in this country for judging the standard
of living of the workers and recommended conduct of socioeconomic enquiries of the type of family
living surveys. This report naturally gave an impetus to the conduct of family budget enquiries. In all
the surveys that followed, sampling and interviewing techniques were adopted, though, of course,
not of a much advanced nature. A statistical analysis of the data collected was also attempted(2) The
Second World War saw the appointment of the Rau Court of Enquiry constituted under the Trade
Disputes Act, 1929. One of the recommendations made by the said Court was that the Central
Government should take up responsibility for maintaining up-to-date cost of living index numbers
for important areas and centres. The Government of India accepted this recommendation and set up
a special Organisation called 'the Directorate of Cost of Living Index Numbers' and family budget
enquiries among industrial workers were conducted at 28 centres during 1944-45 in the course of
which 2,700 budgets were collected. A remarkable feature of these enquiries was that for the first
time in this country, an attempt was made to conduct such enquiries simultaneously at a large
number of centres under more or less uniform techniques. During the same period, the Labour
Bureau of the Government of (1) Labour Survey Techniques issued by the Labour Bureau, Ministry
of labour & Employment, pp. 171-72. (2) Labour Survey Techniques. pp. 171-72.
India and some of the Organisations of State Governments continued to conduct family budget
enquiries from time to time at specific areas or centres, either for deriving weighting diagrams for
consumer price index numbers or for collection of data required for fixation of minimum wages(1).
It was in the background of these events that the Second Five Year Plan made a significant
recommendation. The Plan said that :-
"The existing wage structure in the country comprises, in the main, a basic wage and
a dearness allowance. The latter component in a majority of cases has relation to cost
of living indices at different industrial centres. These indices have not been built up
on a uniform basis; some of them are worked out on primary data collected about 20
to 25 years ago and are, therefore, not a true reflection on the present spending
habits of workers. Since one of the questions which the wage commission will have to
take into account is the demand made by the workers' organisations for merging a
part of dearness allowance with the basic wage, evolving recommendations for such a
merger will not be sufficiently scientific if cost of living indices at different centres do
not have a uniform basis. Steps will therefore have to be taken simultaneously with
the undertaking of a wage census, to institute enquiries for the revision of the present
series of cost of living indices at different centres".
It is in pursuance of this recommendation that the impugned survey was made.Ahmedabad Mill Owners' Association Etc vs The Textile Labour Association on 10 August, 1965

Let us now see on what principles and methods the impugned survey was made. It is necessary to
be-in the discussion of this question with the observation "that the consumer price index number
measures nothing but changes in prices, as they affect a particular population group; and so, it is
really a price index number as distinct from a cost of living index number. In fact, these indices used
to be termed as cost of living index numbers in the past, but in order to make their meaning clear, it
was decided by Government to change the name to consumer price index numbers in accordance
with international recommendations and growing practice in other countries. Most of the State
Governments compiling such index numbers have also adopted this (1) Labour Survey Techniques,
pp. 171-72.
usage"(1). This index number is intended to show over a period of time the average percentage
change in the prices paid by the consumers belonging to the population group proposed to be
covered by the index for a fixed list of goods and services consumed by them. The average
percentage change, measured by the index, is calculated month after month with reference to a fixed
period. This fixed period is known as the "base-period" of the index; and since the object of the
index is to measure the effect of price- changes only, the price-changes have to be determined with
reference to a fixed list of goods and services of con- sumption which is known as a fixed "basket" of
goods and services.
The index does not purport to measure the absolute level of prices but only the average percentage
change in the prices of a fixed basket of goods and services at different periods of time. There are
certain preliminary considerations which are relevant in the construction of consumer price index
numbers. The first consideration is the purpose which the index is intended to serve; and that
necessarily involves the definition of the group of consumers to which the index is intended to
relate. Then it is necessary to determine the consumption level and pattern of the population group
at a period of time which generally becomes the base period of the index numbers. For that purpose,
a list of commodities and services has to be made. Usually, this list would con- tain items of food,
fuel and light, clothing, and others; items of services, such as barber charges, bus fare, doctor's fee,
etc., have also to be selected. It is the combined total of the items of commodities and services that
constitutes the basket. Then follows a description of the quality of each commodity and service
through which price changes have to be measured. Generally, one quality which is popularly
consumed by the population group is selected for each commodity and service. The importance or
weight which has to be attached to each commodity or service is also a material factor. For instance,
if rice is considered to be twice as important -is wheat in the consumption pattern, the weight of rice
will be 2 in relation to I of wheat.
Having determined the consumption level and the pattern of the population group, the next task to
attempt is to arrange for the regular collection of price data for the various qualities of commodities
and services which enter the basket. With this material, the consumer price index has to be
compiled from month to month subsequent to the base period. That, shortly stated, is (1) A Guide,
to Consumer Price index Numbers is such by the Labour Bureau, M.O. Labour & Employment, 5.
the nature of the preliminary considerations which have to be borne in mind while constructing the
consumer price index numbers.Ahmedabad Mill Owners' Association Etc vs The Textile Labour Association on 10 August, 1965

We have just noticed the theory of weights on which weighting diagrams are prepared. Weights are
intended to indicate the importance attached to the percentage changes in the prices paid by
consumers for different items (commodities and services) of consumption. Accordingly, each item in
the index is given, what is called in technical language, a "weight" to represent the relative
importance of the price changes recorded for that item. This weight means nothing more than the
percentage of expenditure on each item of goods and services in relation to the total expenditure. It
will thus be seen that the main basis for determining the weights of respective commodities and
services is the investigation of the family budget; and that emphasises the importance and
significance of a proper investigation. During the course of investigation, data are collected on all
items on which money has been defrayed by families; but only such items as involve consumption
expenditure are included in the average budget. Even so, it is only selected items which find a place
in the index calculations, because it is obviously neither practicable nor necessary to include all
items featuring in the average budget. Since only a sample of items from each group is included in
the index, it becomes necessary to enquire as to what happens to other items featuring in the
average budget but not included in the index. Their weights are added or distributed to the items
included in the index, so that the total expenditure of the average budget is fully taken into account
in the weights adopted for the index. This process is known as "imputation" of weights. Besides the
weights the other set of primary data which enter into the compilation of a series of consumer price
index numbers are the prices; and that emphasises the importance of collecting material data in
respect of prices. The Investigator, therefore, has to bear in mind ,)II the relevant factors that
ultimately go to ,,he construction of the index. and has to carry on his investigation in a proper and
scientific way. Having thus briefly reviewed the theoretical aspects of the factors that govern the
construction of consumer price index numbers, let us now proceed to see how the impugned inquiry
was in fact held. The material evidence which will assist us in this part of our inquiry is furnished by
the Report on Family Living Survey among Industrial Workers at Ahmedabad, 1958-59. From this
report it appears that the Organisation of the survey was based on the co-operation of several
institutions. The survey was sponsored by the Labour Bureau, Ministry of Labour & Employment,
Government of India; and its technical details were worked out under the guidance of a Technical
Advisory Committee on Cost of Living Index Numbers consisting of the representatives of the
Ministries of Labour and Employment, Food and Agriculture, Finance, Planning Commission, the
National Sample Survey Directorate, the Department of Statistics (C.S.O.), the Indian Statistical
institute and the Reserve Bank of India. The field work was entrusted to the Directorate of National
Sample Survey, and processing and tabulation of data collected in Schedule 'A' (Family Budget) to
the Indian Statistical Institute, Calcutta. The tabulation of data collected in Schedule 'B' which deal
with Level of Living was done in the Labour Bureau. It was a multipurpose survey; and so, the
investigation conducted under it covered both the Family Budget, and the Level of Living. Ultimate
analysis of the data, publication of reports on the results of the surveys and construction and
maintenance of new series of consumer price index numbers were the responsibilities of the Labour
Bureau.
The first thing that the Organisation did was to define a working class family", because this
definition determined the size of the universe. A working class family which was the basic unit of the
survey, was defined in terms of sociological and economic considerations as consisting of persons :Ahmedabad Mill Owners' Association Etc vs The Textile Labour Association on 10 August, 1965

(i) generally related by blood and marriage or adoption;
(ii) usually living together and/or served from the same kitchen; and
(iii) pooling a major part of their income and/or depending on a common pool of
income for major part of their expenditure.
Then followed the delimitation of area. The geographical area to be covered during the survey was
decided in consultation with local Organisation both official and non- official. At the Ahmedabad
centre, 46 localities were selected for the purpose of the survey; they consisted of 16 Chawls, 21
Labour Colonies (Housing Societies) and 9 Villages. Before setting the ultimate units of the family
living survey, viz., the families, two types of sampling methods were adopted; they were the
tenement sampling and the pay-roll sampling. The sample size for a centre was determined on the
basis of the number of industrial workers, the type of sampling followed, the work-load manageable
by an Investigator and the required precision of weights to be derived from Schedule 'A' for
consumer price index numbers. The sample size for Ahmedabad was 720 families to be canvassed
for Schedule 'A'. The number of schedules finally collected and tabulated was 722 for Schedule 'A'.
The two samples drawn for Schedules 'A' & 'B' were however, mutually exclusive, because
canvassing for both the schedules from the same sampled families would have caused fatigue both to
the Investigators and the informants. The whole sample was staggered over a period of 12 months
evenly so as to eliminate the seasonal effects on the consumption pattern. The selection of sample
was done in two stages. In the first stage the chawls within each of the wards were grouped to form
blocks of about 150 households each and these blocks along with the labour colonies (housing
societies) were grouped to form clusters of about 450 households each, so that each cluster had
blocks from different wards. From the list of these clusters and villages, 4 independent simple
systematic samples of 12 clusters or villages each were selected for survey. Each of the 12 clusters
sampled for an Investigator was assigned to a particular month for enquiry by a random process.
That is how the first stage was arranged.
The second stage unit for selection was a working class family. Each month, the Investigator listed
all the families in the cluster allotted to that month by house-to- house visit and classified them as
working class families and others. While listing, information was also collected on the family size,
the expenditure class to which it belonged and the State of origin of the head of the family. This
information was utilised to arrange the working class families in the cluster, first by family size and
within these classes by expenditure class and within these by the State of origin. A simple systematic
sample of 20 working class families was drawn from this arranged list. Every fourth family in this
sample was contacted for filling Schedule 'B' (on Level of Living} and the remaining three were for
Schedule 'A' (on Family Budget). That is the nature of the procedure adopted in selecting the
families for sample survey and determining the size of the sample. The same survey was designed to
cover a period of 12 months at each centre. At Ahmedabad centre, the work was carried on between
August, 1958 and July, 1959. The method of survey was the "interview method". The questionnaire
which each Investigator adopted covered a wide range of subjects, accurate replies to some of which
could not be had without explaining the significance of the questions to the persons concerned.Ahmedabad Mill Owners' Association Etc vs The Textile Labour Association on 10 August, 1965

The population of Ahmedabad is about 11.5 lakhs. The working class population in Ahmedabad was
reported to be concentrated in 13 localities. The markets predominantly patronised by the working
class population in Ahmedabad were 6 and it is the markets that were selected for the collection of
retail prices for the new series of consumer price index number for Ahmedabad centre.
This summary of the Report gives us a broad idea as to the manner in which and the method by
which the investigation was made which ultimately led to the construction of the consumer price
index number.
Reverting then to the objections raised by the appellants that the size of the sample was inadequate
and the method of investigation was inappropriate, can it be said that the Industrial Court was in
error in holding that these objections were not valid ? In dealing with this question, it is necessary to
bear in mind that the size of the sample has to be determined in the light of the permissible margin
of error in the resulting series of consumer price index numbers. As Dr. Basu has observed : "In our
country, this permissible margin of error in the index has been broadly set at 2 per cent";(1) and that
is not contradicted by the opinion of any other Expert. The sample of consuming units has to be
selected by the application of scientific sampling techniques; and there is no doubt whatever that
during the last 40 years, this branch of human knowledge has made remarkable progress. The
optimum sample design is now worked out by competent statisticians in the light of the available
material and requirements in each case, and as Dr. Basu has observed, "the desired data are secured
at minimum cost and at an evaluation of sampling errors in tile estimated data obtained from the
survey". It is the quality of the survey that is more important, not so much the size of the sample or
the number of families with whom investigation was made.
On the question about the adequacy of the sample size selected for investigation on the present
occasion it would be material to refer to the opinion expressed by Moser on this subject. Says
Moser:-
"Most people who are unfamiliar with sampling probably over-rate the importance of
sample size as A Basu, "Consumer Price index, pp.54-
55. such, taking the view that "as long as the sample is big enough, or a large enough
proportion of the population is included, all will be well". The fallacy in this is clear as
soon as one looks at any standard error formula, say (5.1) on p. 61 above. If the
population is large, the finite population correction N-n/N-1 practically vanishes and
the precision of the sample result is seen to depend on n, the size of the sample, not
on n/N, the proportion of the population included in the sample. Only if the sample
represents a relatively high proportion of the population (say, 10 per cent or more)
need the population size enter into the estimate of the standard error". (1) Mr. Kolah
for the, appellants has not cited before us the opinion of any Expert to the contrary.
Considering the question from a commonsense point of view, it seems to us
reasonable to hold that if the quality of investigation has improved, and the method
of working out the sample survey has made very great progress, then it would not be
correct to say that because the size of the sample in the present case was smaller asAhmedabad Mill Owners' Association Etc vs The Textile Labour Association on 10 August, 1965

compared to the size of the sample taken in 1926-27, the inadequacy of the size on the
subsequent occasion introduces an infirmity in the investigation itself. That is the
view which the Industrial Court has taken, and we see no reason to differ from it.
At this stage, it would be interesting to consider the comparative contents of the
basket as it was devised in the two respective enquires, one held in 1926-27, and the
other in 1958-59. The former enquiry reflects the consumption pattern of the working
class as it existed in 1926. The index number then devised was composed of five
groups, viz., (1) Food, (2) Fuel and Lighting, (3) Clothing, (4) House rent, and (5)
Miscellaneous. The food group in its turn consisted of 16 items; the fuel and lighting
group of 4 items; the clothing group of 7 items; the house rent group of the item of
house rent; and the miscellaneous group of two items, viz. bidis and soap. Thus, in
all( 30 items were included. These items represent 82-32% of the average monthly
expenditure, and they were respectively assigned 58, 7, 10, 12 and 4 weights which
together aggregate 91. At the time of this enquiry, the items included in the
investigation totalled 49; out of them, 30 were priced and 19 were unpriced; and in
respect of the (1) C. A. Moser, Survey Methods in Social investigation, p.
115, para 3.
L6sup65-12 latter, the method of imputation was adopted. This series was prepared after collecting
the budgets of 985 families when the estimated population of the city of Ahmedabad was 2,90,000.
The new series is based on the enquiry into 722 working class families conducted in 1958-59 when
the total population of the city was about 11 lakhs. The total working class families at this time were
estimated to be 51.5 thousand; and so, the percentage of the sample size in relation to the universe
of the working class families would come to about 1.4 and not less than 5 as appears to have been
assumed by Mr. Gokhale. The weighting diagram for the new series is based on 110 articles divided
into the main groups of food, fuel and lighting, housing, clothing, and miscellaneous. The important
groups in this enquiry carried respectively the weights of 64-41, 6.22, 5.05, 9.08, and 15.24 which
aggregate to 100. The total number of items included in the basket was 239. Of these, 89 were priced
items and 150 unpriced, and in respect of the latter, the method of imputation was adopted. It is
true that in the new series, the unpriced items are considerably more than in the earlier one; but it
must be remembered that it is not so much the number of items that makes the difference, but the
percentage of expenditure on unpriced items to priced items. The total expenditure of all items in
the 1926-27 enquiry was Rs. 36.01 of which Rs. 32.35 was the expenditure on priced items and Rs.
3.66 was the expenditure on non-priced items. In terms of percentage, the expenditure on priced
items to total expenditure was 89.8% and expenditure on non- priced items to total expenditure was
10.2%. In the latter enquiry of 1958-59, the total expenditure on all items was Rs. 139.06. Of this,
Rs. 124-91 was the expenditure on priced items and Rs. 14.15 was the expenditure on non-priced
items. In terms of percentage, the first expenditure was 89.8% and the second is 10.2%. Thus, it is
clear that the expenditure on unpriced items in the present enquiry is not larger than in the former
enquiry at all. The fact that the components of the basket have considerably increased, cannot be a
matter of surprise, because with the growth of Indian economy and the change in the standard ofAhmedabad Mill Owners' Association Etc vs The Textile Labour Association on 10 August, 1965

living of all citizens, the requirements of the working class have also increased and the components
of the basket which was devised in 1926-27 have now become completely obsolete. It is in the light
of this position that we have to consider whether the appellants are justified in contending that the
inadequacy of the size of the sample vitiates the enquiry. In our opinion, the answer to this question
must be against the appellants.
The next question to consider is whether the Interview method is unscientific and its adoption
makes the enquiry itself defective and unreliable. In dealing with this question again, it is necessary
to remember that the interview method itself has made very great progress since 1926. The task of
investigation is in no sense merely mechanical; it is a constructive task, the efficient discharge of
which requires a well-trained Investigator. As Moser observes, the investigators are expected to ask
all the applicable questions; to ask them in the order given and with no more elucidation and
probing than is explicitly allowed; and to make no unauthorised variations in the working (p. 188).
Interviewers, according to Moser, are not machines. Their voices, manner, pronunciations and
inflections differ as much as their looks, and no amount of instruction will bring about complete
uniformity in technique; and so, interviewers have to be properly educated in the task of putting
questions to the families interviewed. What is true about asking questions, is also true about
recording the answers. "The recording of answers", says Moser, 'would seem a simple enough task
and one which interviewers might be expected to perform with accuracy". But he adds that "the task
of interviewers is a fairly tiring one. With random sampling, the interviewer may have travelled and
walked a good way before getting to the respondent. He has to go through what is often a lengthy,
and always a somewhat repetitive, operation" (p.
190); and that makes the task of recording answers also important. The Interviewers are, therefore,
appointed after selection, and it is now realized that their work is not at all mechanical and cannot
be compared to the work-of Investigators who collect data at the time of population census. The
Investigator must take interest in the task that he has undertaken, must be accurate in asking
questions and recording answers, must show an equitable temper in meeting the persons
interviewed and must, above all, be a man of education who understands the significance of
sampling survey and the purpose which it is intended to serve.
It is true that in England, the method of supplying account- books to the families is adopted. Under
this method, the families are expected to fill in every detail in the account-book, and the cost of
living is compiled from exact and correct information given by the persons who keep regular
accounts according to the directions issued. But on the other hand, in countries like Canada and the
United States, the method of interview is preferred to that of the account-books. It seems that
according to Moser, the method of mail questionnaire, which corresponds in a sense with the
method of account-books, suffers from several infinities; and so, he seems to prefer the method of
interview, provided, of course, this method is scientifically and efficiently adopted.
In our country where a majority of working class population still suffers from illiteracy, the method
of interview is obviously indicated. It would be impracticable to suggest that a written questionnaire
should be supplied to the members of the working class or account-books should be given to them in
the expectation that they would furnish answers in return. Having regard to this special feature ofAhmedabad Mill Owners' Association Etc vs The Textile Labour Association on 10 August, 1965

the life of the working class as it obtains in our country today, the method of interview is the only
method which can be adopted. Besides, as we have just indicated, even on the merits, expert opinion
seems to suggest that if the interview method is properly adopted, it gives better results than the
alternative method of account-books. Therefore, we are satisfied that the Industrial Court was right
in rejecting the appellants' contention that the impugned survey and the index constructed as a
result of it, suffer from the infirmity that investigation was conducted in this survey by the interview
method.
That takes us to the question about the propriety of the linking factor which has been upheld by the
Industrial Court. We have already noticed that the Government of Gujarat has adopted the linking
factor at 3.17, and the Industrial Court has taken the view that no case has been made out by the
appellants to interfere with the said decision of the Government of Gujarat. Mr. Kolah contended
that if a linking factor has to be adopted it would be more rational and scientific to watch the
behaviour of prices for two or three years and then devise a factor on the average rise in prices
during the period in question. Mr. Vasavada, on the other hand, seriously disputed the correctness
of Mr. Kolah's contention. As this case was being argued on the 24th March, 1965, the parties
suggested that the question about the proper procedure to be followed in 'determining the linking
factor in such cases was a very important question and that it would be better if we hear the views of
associations or bodies which would be interested in a proper solution of this problem. That is why
on the said date we adjourned the hearing of the appeals to enable such interested parties to appear
before us. The parties furnished a list of sixteen institutions or bodies which, according to them,
would be interested in assisting us with arguments on this issue. On April 12, 1965, a letter of
request was accordingly sent to these bodies indicating to them the nature -of the question on which
we wanted their assistance. In response to the said letter, only four bodies have appeared; they are :
The All-India Organisation of Industrial Employers; the All-India Manufacturers' Organisation; the
Millowners' Association, Bombay; and the Indian National Trade Union Congress. The first three
bodies appear broadly to support the appellants' case, whereas the fourth body has resisted the
appellants' contention that the Government of Gujarat was in error in adopting the linking factor at
3.17. The appeals were then set down for hearing before us on the 2nd August, 1965, and we
indicated to the parties that having regard to the unsatisfactory response which our letter of request
had received, we did not think it would be appropriate that we should proceed to decide the larger
issue raised by Mr. Kolah as to what would be a rational and satisfactory method of evolving a
linking factor. The Indian National Trade Union Congress in its affidavit has urged that the method
of linking of the new series with the old by the simple arithmetical ratio,at the base period is
universals accepted. It appears that the employers' and the employee,s are not able to take a
consistent stand on this issue and their approach apparently differs from region to region and
industry to industry, because considerations of expediency and self interest do not seem to dictate a
uniform common approach to be adopted in the present case. Besides, the issue is of a very technical
character and any decision of this Court on such an issue of principle is likely to affect several
industries in this country. We have, therefore, decided not to embark upon a general enquiry on this
point. Our decision will be confined to the material placed before the Industrial Court in the present
proceedings, and we will merely examine Mr. Kolah's contention that the view taken by the
Industrial Court is not correct. That is why we wish to make it clear that our present decision should
not be taken to be of any general significance and should be confined to the facts of this case. If it isAhmedabad Mill Owners' Association Etc vs The Textile Labour Association on 10 August, 1965

thought necessary or desirable by the employers and the employees that this question should be
scientifically examined and determined in a general way, it would be appropriate for them to more
the Government to appoint a special body of experts to deal with it. Reverting then to the narrow
question as to whether the appellants are justified in attacking the finding of the Industrial Court on
this issue, lot us mention a few relevant facts and considerations. We have already noticed that at
the request of the Government of India, the Government of Gujarat discontinued the publication of
the State series of the consumer price index;
and so it became necessary for the said Government to secure the advice of an Expert Committee as
to how the new series of consumer price index for Ahmedabad should be linked with State series
after making such adjustments therein as may be found necessary. The Expert Committee dealt with
this problem of arriving at the linking factor, so that when the new series is adopted and the State
series is discontinued, the dearness allowance on the present scale can be computed even on the
basis of the new series. The Government of India had, in this connection. indicated that 2.98 would
be an appropriate linking factor. This figure had been reached by taking the annual average of the
monthly index number of the State series for the year 1960 which then stood at 298. The figure of
the base year 1960 was obviously 100. The linking factor of 2.98 was deduced by dividing 298 by
100. In doing so, however, the question about making necessary adjustments in the index numbers
of the State and of the new series had not been considered. This question was consider- ed by the
Desai Expert Committee, and it held that the linking factor should be 3.17 as against 2.98 per point
in the new series as was worked out without correcting the old series In other words, the Desai
Committee suggested as a linking factor a mere arithmetical ratio of 3.17. A similar question was
referred by the Government of Maharashtra to the Lakdawala Expert Committee, and the said
Committee was inclined to take the same view. It no doubt observed that "in spite of the fact a
linking on the basis of a simple ratio corrects a series only in respect of one of its dimensions, we
recommend this course because we are of opinion that such a correction is adequate for the
requirements of our terms of reference and in any case, the only correction that we can meaningfully
,carry out." It would thus be seen that in accepting the linking factor at 3.17, the Government of
Gujarat has adopted the conclusion of the Desai Expert Committee.
The question which arises is whether in upholding this view, the Industrial Court has committed any
error. As the Industrial Court has observed, two possibilities presented themselves in attacking this
problem. One was to work out an entirely new scale of basic wages founded not on the pre- war level
of 1939, but on the cost of living of 1960 as the base year of the new series and to award dearness
allowance thereafter. The Industrial Court thought that to adopt this course may conceivably create
a large number of problems which do not exist at present and in fact, it may tend to destroy
industrial peace. The Industrial Court thought that such a course might even be outside its terms of
reference. Even so, in its opinion, the result which would be achieved by adopting this course may
not in the end be very different. The other course is to link the State series with the new series to
maintain continuity. It is this latter alternative which has been adopted by the Government of
Gujarat, and the Industrial Court has approved of the said course. We are not satisfied that the
conclusion thus recorded by the Industrial Court is shown to be erroneous.Ahmedabad Mill Owners' Association Etc vs The Textile Labour Association on 10 August, 1965

As we have just indicated, the problem is a technical problem and it can be decided only in the light
of the opinion which experts may form on examining all the aspects pertaining to the problem and
after taking into account all the pros and cons which may be put before them by the respective
interested parties. The stand which the parties may take in regard to this controversy would differ
according as the change in the cost of living index in the respective States may help their interest
one way or the other. That explains why there is no unanimity in the approach adopted by the
different parties. This is made clear by the contentions raised by the respective parties before the
Lakdawala Expert Committee.
There is no doubt that on the material as it stands, it would be unreasonable, inexpedient and in fact
impossible for this Court to attempt to resolve this controversy on the basis of the larger issue of law
raised by Mr. Kolah before us. The decision of that question must, therefore, be left to a Committee
of experts if and when it is appointed. Meanwhile, the question will have to be dealt with on an ad
hoc basis in each industry, taking into account the particular facts and circumstances of each case.
Looking at the question from this narrow point of view, we do not think the appellants have placed
before the Industrial Court any material to justify their contention that for determining a linking
factor, the behaviour of prices for two or three years during the relevant period should and can be
studied. In fact, Mr. Vasavada's contention is that a study of the behaviour of prices for such a
period and deducing the average therefrom would be inconsistent with the notion of evolving a
linking factor. He contends that we have to take one year by reference to which this problem must be
resolved. We express no opinion on this part of the controversy between the parties. In fact, the
Award under appeal shows that the argument which Mr. Kolah has urged before as was not placed
in this form, and in any case does not appear to have been pressed, before the Industrial Court. Even
assum-
ing that it would have been open to the Industrial Court to consider this larger issue under the terms
of its reference, we do not see how the Industrial Court could have attempted to solve the problem
satisfactorily on the material placed before it. Therefore, we cannot accept Mr. Kolha's argument
that the Industrial Court was not justified in upholding the decision of the Government of Gujarat
that the linking factor should be taken at 3.17.
The last question to consider is whether the Industrial Court was right in coming to the conclusion
that the additional burden which its award would impose upon the appellants would not be beyond
their financial capacity. In dealing with this question, there are two general considerations which
cannot be ignored. The first consideration is that the task of constructing a wage structure of
industrial employees is a very responsible task and if,- -present.,:, several difficult and delicate
problems. The claim of the employees for a fair and higher wage is undoubtedly based on the
concept of social justice, and it inevitably plays a major part in the construction of a wage structure.
There can be little doubt that if the employees are paid a better wage which would enable them to
live in fair comfort and discharge their obligations to the members of their families in a reasonable
way, they would be encouraged to work whole-heartedly and their work would show appreciable
increase in efficiency.Ahmedabad Mill Owners' Association Etc vs The Textile Labour Association on 10 August, 1965

On the other hand, in trying to recognise and give effect to the demand for a fair wage, including the
payment of dearness allowance to provide for adequate neutralisation against the everincreasing
rise in the cost of living, industrial adjudication must always take into account the problem of the
additional burden which such wage structure would impose upon the employer and ask itself
whether the employer can reasonably be called upon to bear such burden. The problem of
constructing a wage structure must be tackled on the basis that such wage structure should not be
changed from time to time. It is a long-range plan; and so, in dealing with this problem, the financial
position of the employer must be carefully examined. What has been the progress of the industry in
question; what are the prospects of the industry in future; has the industry been making profits; and
if yes, what is the extent of profits; what is the nature of demand which the industry expects to
secure; what would be the extent of the burden and its gradual increase which the employer may
have to face ? These and similar other considerations have to be carefully weighed before a proper
wage structure can be reasonably constructed by industrial adjudication, vide Express Newspapers
(Private) Ltd., and Another v. Union of India & Others(1). Unusual profit made by the industry for a
single year as a result of adventitious circumstances, or unusual. loss incurred by it for Similar
reasons, should not be allowed to play a major role in the calculations which industrial adjudication
would maker in regard to the construction of a wage structure. A broad and overall view of 'the
financial position of the employer must be taken into account and attempt should always be made to
reconcile the natural and just claims of the employees for a fair and higher wage with the capacity of
the employer to pay it; and in determining such capacity, allowance must be made for a legitimate
desire of the employer to make a reasonable profit. In this connection, it may also be permissible to
take into account the extent of the rise in price structure which may result from the fixation of a
wage structure, and the reasonableness of the additional burden which may thereby be imposed
upon the, consumer. That is one aspect of the matter which is relevant.
The other aspect of the matter which cannot be, ignored is that if a fair wage structure is constructed
by industrial adjudication, and in course of time, experience shows that the employer cannot bear
the burden of such wage structure, industrial as judication can, and in a proper case should, revise
the wage structure. though such revision may result in the reduction of the wages paid to the
employee. It is true that normally, once a wage structure is fixed, employees are reluctant 'to face a
reduction in the content of their wage Packet; but like all major problem, associated with industrial
adjudication, the decision of this problem must also be based on the major consideration that the,
conflicting claims of labour and capital must be hormonised on, a reasonable basis; and so if it
appears that the employer cannot really 'hear the burden of the increasing wage bill, industrial
adjudication, on principle. cannot refuse to examine the employer's care and should not hesitate to
give him relief if it is satisfied that if such relief is not given, the employer may have to close down
his business. It is unlikely that such situation would frequently arise but principle if situations arise,
a claim by the employer for the reduction of the wage structure cannot be rejected summarily.
This principle, however, does not apply to cases where the wages paid to the employees are no better
than the basic minimum wage. If, what the employer pays to his employees is just the basic
subsistence wage, then it would not be open to the employer to contend that even such a wage is
beyond his paying capacity.Ahmedabad Mill Owners' Association Etc vs The Textile Labour Association on 10 August, 1965

(1) [1961] 1 L. L. J. 339.
Industrial adjudication has consistently recognised and enforced the principle that social justice
requires that an industrial employer must be able to pay his employees a wage structure which can
be reasonably regarded as basic minimum wage. No employer can be allowed to pay his employees
wages which are below the basic minimum or the subsistence wage. It is well-known that in certain
industries, minimum wages are fixed by the statute. Even where minimum wages are not fixed by
statute, industrial adjudication can easily determine whether in a given case, the wage paid is basic
minimum or not. In either case, where the wage answers the description of the basic minimum or
subsistence wage, it has to be paid by the employer; and if he cannot afford to nay it, he would not
be justified in carrying on his industry vide Crown Aluminium Works v. Their Workmen(1). That is
the second consideration which has to be borne in mind in dealing with the point raised by the
appellants about their incapacity to bear the burden.
We have thought it necessary to refer to these two theoretical considerations at this stage, because if
they are borne in mind, we get a proper perspective of the problem raised by the appellants'
contention as to their financial capacity. In the present proceedings, the Industrial Court is not
constructing any wage structure for the first time, nor is it dealing with the question of determining
the quantum or the sliding scale of the dearneses allowance to be paid to the textile employees at
Ahmedabad. These matters have been considered in the past on several occasions and they are
governed by consent awards passed between the parties. It is because of the new survey made in
1958-59 and the consequent change in the construction of the consumer price index made by the
series published by the Government of Gujarat that the present dispute has arisen; and so, while
dealing with the appellants' contention, it would be pertinent to enquire whether the appellants
show that a case has been made out for reduction of the wages paid to the employees. It is, of course,
true that the wages paid to the textile employees at Ahmedabad cannot be regarded as subsistence
wages or bare minimum wages: and so, it would not be open to the respondent to contend that the
appellants Must pay the said wages whether they can afford to may them or not. If it is shown that
the appellants cannot bear the burden and that the implementation of the award would inevitably
have extremely prejudicial effect upon the continued existence of the textile industry itself, we would
be justified in revising the scale of dearness allowance. But. as we have just indicated, such a plea (1)
[1958] 1 L. L. J. 1.
can succeed only if it is shown satisfactorily that the burden cannot truly and really be borne by the
textile industry at Ahmedabad. That is the proper approach to adopt in dealing with this problem;
and the award under appeal shows that the Industrial Court did approach the problem in a proper
way.
In support of their contention that the textile industry at Ahmedabad cannot bear the burden which
would be imposed by the award, the appellants examined Mr. Chokshi. Mr. Chokshi is a Chartered
Accountant and a senior partner in the firm of Messrs. C. C. Chokshi & Co. He has been practising as
a Chartered Accountant for about 24 years. He was a member of the Council of the Institute of
Chartered Accountants for 8 years and its President for one year. It appears that the appellant
Association sent to him five statements and asked for his opinion on the financial position of theAhmedabad Mill Owners' Association Etc vs The Textile Labour Association on 10 August, 1965

textile industry at Ahmedabad. Mr. Chokshi first filed an affidavit in which he set out his opinions
and then gave oral evidence. In his affidavit, Mr. Chokshi referred to the respective statements on
which his opinion was based and he stated that the financial position of the textile industry at
Ahmedabad was, on the whole, not very satisfactory. In appreciating the evidence given by Mr.
Chokshi, it would, therefore, be material to indicate the nature of the statements on which his
opinion was based. The first statement shows the depreciation, development rebate, and increase in
gross block per year of the Ahmedabad Cotton Textile Mill Industry for the years 1945 to 1963. The
statement indicates that all these items have increased from year to year; depreciation was Rs. 0.83
crore in 1945 and it rose to Rs. 6.68 crores in 1963; development rebate was Rs. 0.05 crore in 1954
and it became Rs. 1.26 crores in 1963; gross block rose from Rs. 20.25 crores in 1945 to Rs. 101.98
crores in 1963; and increase in gross block Per year for the same years was Rs. 1.31 and Rs. 9.77
crores.
The second statement shows the net worth and borrowings of the said industry during the same
period. The emphasis in this statement was on the ever-increasing borrowings. In 1945, the
borrowings, consisting of secured and unsecured loans and other deposits, were of-the order of Rs.
9.58 crores, whereas in 1.963, they rose to Rs. 47.76 crores. The third statement shows the working
capital and borrowings for the period in question. The fourth statement shows profits after tax as
percentage of net worth of the said industry for the same period. This statement refers to profits
before tax, loss, tax provision, profits after tax, net worth, and the last column gives profits after tax
and indicates percent-
age of net worth. It is the last column on which Mr. Chokshi relied when he gave his opinion that the
financial position of the Ahmedabad textile industry was not very satisfactory. Whereas in 1945, the
percentage of profits to net worth was 13.4%, in 1963 it was 3.3%. The last statement shows
dividends as percentage of net worth in different industries. It covers the period between 1951 and
1962. This statement shows that the dividends paid by the industry in question are comparatively on
the low side. Dividends paid by 12 industries are shown in this statement, and it would be right to
say that the textile industry has not been paying dividends which can be said to be very high in
comparison to the dividends paid by other industries. On the other hand, the respondent has filed
several statements showing that the financial position of the appellants has been conSistently good,
and the fear that the appellants would not be able to bear the burden is entirely unjustified.
Annexure 11 filed by the respondent along with its statement shows the percentage of wages to total
income in Ahmedabad Cotton Textile Industry from 1939 to 1962. This percentage was 26 in 1939
and is 24 both in 1961 and 1962; for the intervening period, it has risen to 28 in 1949 and fallen to
20 in 1943. Annexure III gives the statement showing the growth of paid up capital by cash in the
said industry for the same period. In 1939, the paid up capital by cash was 407 lakha. where as in
1962 it was 770 lakhs. Annexure IV shows the growth of total paid up capital including bonus shares
for the same Period. This statement shows a remarkable growth of total paid up Capital in this
manner. In 1939, the total paid up capital was 442 lakhs whereas in 1962 it has reached the
magnitude of 2,129 lakhs. From 1950 onwards, this category of capital has been consistently rising.
Annexure V shows the value of gross block for the same period. In 1939, it was 1,915 lakhs whereas
in 1962 it rose to 9,341 lakhs. Annexure VI shows the amount of Depreciation Fund including
Development Rebate; in 1939 it was 745 lakhs, whereas in 1962 it was 5,643 lakhs. Annexure VIIAhmedabad Mill Owners' Association Etc vs The Textile Labour Association on 10 August, 1965

shows the amount of Reserves excluding Depreciation Fund and Liability Funds; in 1939 they were
360 lakhs, while in 1962 they were 2,518 lakhs. From Annexure VII we gather that the amount of
Gross Profit including the Managing Agents' Commission and Depreciation was Rs. 159 lakhs in
1939, and it was Rs. 1,860 lakhs in 1961 and Rs. 1,296 lakhs in 1962. Incidentally, it is the figure of
gross profit which is more important, because it is not disputed that wages payable to the employees
are a first charge, and all other liabilities take their place after the wages. There are three other
Annexures filed by the respondent, but it is unnecessary to refer to them.
The main comment which falls to be made on the opinion expressed by Mr. Chokshi is that he has
looked at the problem merely from the investor's point of view. In fact, he fairly stated that he had
made his analysis from the point of view of an investor. That explains why Mr. Chokshi took the
view that absolute figures of more gross profit or net profit from year to year would be misleading.
He did not agree that most of the textile mills in Ahmedabad are at present under capitalised. He
conceded that in dealing with the problem of expanding business and increasing the wage bill, one
of two methods can be adopted by the industry; the industry can increase the capital or borrow
money. Very often, said Mr. Chokshi, borrowing is preferred to the increase of capital in certain
market conditions. He was not certain whether borrowings had been resorted to by the textile
industry for the purpose of expansion. In dealing with the problem of the financial capacity of the
appellants to bear the burden, it would be inappropriate to rely solely upon the approach which an
investor would adopt in such a case; and so, we are not prepared to hold that the Industrial Court
was in error in not accepting Mr. Chokshi's estimate about the financial position of the Textile
industry at Ahmedabad.
Mr. Kolha for the appellants has strongly relied upon certain statements made in the Reserve Bank
of India Bulletin issued in July, 1964, in support of his argument that the financial position of the
appellants was not satisfactory. Dealing with the position of the Cotton Textile Industry during the
period under review, tile Bulletin says that cotton textiles recorded a steep fail of Rs. 17.0 crores in
net profits as against a rise of Rs. 2.1 crores in the previous year. Applying the profitability ratio, the
Bulletin goes on to say that cotton textiles, amongst others. showed declines in profitability. This
test is evolved by the ratio of gross profits to sales, and the return on capital, as measured by the
ratio of gross profits to total capital employed. According to the Bulletin, the IF decline in the return
on shareholders equity (ratio of profits after tax to net worth) was substantial in the case of cotton
textiles along with other named industries. Table 4 in the Bulletin gives a comparative statement of
the profitability ratios, industry-wise, in 1960-61, 1961-62 and 1962-63. It is arranged in five
columns which deal respectively with gross profits as percentage of sales gross profits as percentage
of total capital employed, profits after tax as percentage of net worth, dividends as percentage of net
worth, and dividends as percentage of paid up capital. The figures shown against the cotton textiles
in these five columns support the main comment made in the Bulletin that the position of the textile
industry, considered as a whole in this country, was not quite satisfactory.
We do not think in considering the financial position of the appellants in the context of the dispute
before us, it would be appropriate to rely unduly on the profitability ratio which has been adopted by
the said Bulletin. Indeed, in appreciating the effect of the several statements produced before the
Industrial Court by the parties in the present proceedings, it would be relevant to remember thatAhmedabad Mill Owners' Association Etc vs The Textile Labour Association on 10 August, 1965

some of these single-purpose statements are likely to create confusion and should not ordinarily be
regarded as decisive. As Paton has observed : "Different groups for whom financial statements are
prepared are interested in varying degree in particular types of information; and so, it has been held
in some quarters that no one form of statement will satis- factorily serve all these purposes, that
separate single- purpose statements should be prepared for each need or that the statements usually
prepared for general distribution should be expanded so as to include all the detail desired".(1)
Paton cites the comment of Wilcox against these single-purpose statements. Said Wilcox : "The
danger in undertaking to furnish single-purpose financial statements lies in increasing confusion
and misunderstanding, and in the possible misuse of such statements for unintended purposes".
Paton has then referred to certain methods for determining the financial position of a commercial
and industrial concern. In this connection, he refers to the proprietary ratio rate of earnings on total
capital employed, rate of dividends on common stockholders' equity and others. Our purpose in
referring to these comments made by Paton is to emphasise the fact that industrial adjudication
cannot lean too heavily on such single-purpose statements or adopt any one of the tests evolved
from such statements, whilst it is attempting the task of deciding the financial capacity of the
employer in the context of the wage problem. While we must no doubt examine the position in
detail, ultimately we must base our decision on a broad view which emerges from a consideration of
all the relevant factors.
What then is the broad picture which emerges from the evi- dence on the record in respect of the
financial position of the textile industry at Ahmedabad ? The cotton textile industry at Ahmedabad
can legitimately claim to be the oldest organised industry in the country. It recently celebrated its
centenary in (1) 'Accountants' Handbook Edited by Paton, p. 13 1961. The story about the growth of
this industry during this century is very heartening. In its early stages, it no doubt made. a small and
modest beginning; but at the time when the centenary celebrations were held, it had an installed
capacity of about two million spindles and 42,000 looms and it employed 1,30,000: workmen.
Statistics show that textile mills at Ahmedabad account roughly for one- third of the total mill
production in the country, and it would be no exaggeration to say that some of the best varieties of
cloth produced in the country are manufactured at Ahmedabad.
The paid up capital by cash of the industry in 1939 was 4.07 crores and it became 7.70 crores in
1962. The total paid up capital including bonus shares was 4.42 crores in 1939 and in 1962 it rose to
21.29 crores. It would thus be seen that out of the total paid up capital of 21.29 crores in 1962, the
capital collected by cash is 7.70 crores, whereas the balance of 13.59 crores is by way of bonus
shares. In other words, the cash capital is increased by 175% because of capitalisation of the
reserves. Similarly, the gross block in 1939 was 19.15 crores and in 1962 it rose to, 93.41 crores.
Almost the same rate of progress is evidenced by the Reserves. The Reserves excluding Depreciation
Fund and other liability funds at the end of 1939 was 3.60 crores and they have gone to 25.18 crores
in 1962. The gross profits have registered a similar rise. In 1939, the gross profit including Managing
Agents' Commission and depreciation was 1.59 crores, whereas in 1962 it has reached the magnitude
of 12.96 crores. In this connection, it would be unreasonable to ignore the fact that the industry has
been able to save and capitalise from 1939 onwards 13.85 crores and has been able to pay a fair
amount of dividend on equity shares throughout the period, in spite of a very large capitalisation of
reserves.Ahmedabad Mill Owners' Association Etc vs The Textile Labour Association on 10 August, 1965

It is true that the textile industry at Ahmedabad has been learning very heavily on borrowings; but
that may partly be due to the fact that the said industry has for several decades been
under-capitalised. Besides, the tendency to rely upon borrowings for expanding the business is
noticeable throughout this period of the life of textile industry at Ahmedabad and has been the
subject-matter of comment by several persons. In fact, sometimes it is treated as a peculiar feature
of the development of the textile industry at Ahmedabad; and so, the extent of borrowings cannot be
pressed into service for the purpose of showing that the financial position of the industry is
unsatisfactory.
One remarkable feature of the textile industry at Ahmedabad is the harmonious relations which
have consistently subsisted between the employers and the employees. The employers, on the whole,
are enlightened and progressive in their outlook, and the Trade Union leadership of the employees
is also enlightened and progressive. Both the employers and the employees realize that the progress
of the industry depends primarily on the cooperation between capital and labour; and the large
number of consent awards and agreements to which they have been parties over a period of several
years, is a standing tribute to the spirit of co- operation which inspires the textile industrial life in
Ahmedabad. As one looks back over the last hundred years of the life of the textile industry at
Ahmedabad, one is struck by the fact that industrial life in that area has rarely been disturbed by
bitterness, feuds or, general strikes. This spirit of co-operation, based on the willingness to give and
take, alone can ensure the economic and industrial growth of our country, for, after all, it is the
speedy economic growth of industry of the country which must be the ultimate object of both capital
and labour. In considering the prospects of the textile industry in Ahmedabad, this feature must be
given a place of pride.
It is significant that as a result of the spirit of co- operation between capital and labour, the textile
industry at Ahmedabad has been able to enter into several agreements for rationalising the industry
itself. It is well-known that an attempt to rationalise textile industry inevitably involves
retrenchment of a large number of employees; but the appellants and the respondents have entered
into agreements of rationalisation after both of them agreed to three basic principles in that behalf.
These principles are:-
(a) Rationalisation to be effected without creating unemployment of the existing
workers;
(b) Gains of Rationalisation should be adequately shared between the Management
and the workers; and
(c) The workload should not be increased in a manner which may jeopardise the
health of the workers.
The fact that a large number of agreements have been made between the parties by consent
concerning the vexed subject of rationalisation also shows that the future of the textile industry at
Ahmedabad is bound to be as bright as it has been in the past. In this connection, we may refer to
the tribute paid by the Central Wage Board to the Cotton Textile Industry at Ahmedabad. Says theAhmedabad Mill Owners' Association Etc vs The Textile Labour Association on 10 August, 1965

Board "The industry, however, is conscious of the need for rationalisation and modernisation as the
sine quo non of survival, the pace of which had been checked in the past by the fear of
unemployment; that fear has been allayed, and labour now recognises that its own welfare depends
on rationalisation and modernisation, and it has agreed upon the broad lines for their introduction.
Some mills even today have very modem and up-to-date machinery, and all mills which can manage
to do so will have to rationalise and modernise; for the nation is on the march, and this industry
must clothe the nation".
Let us then consider the question about the prospects of the demand for textile products in future
and the increasing productivity of the industry. On this point again, it is difficult to share the
pessimism disclosed by the attitude adopted by the appellants. There is little doubt that the
productivity of the industry is increasing and that the demand for textile products will never be on
the decrease in future. Therefore, we do not see how we can differ from the conclusion of the
Industrial Court that the appellants have failed to substantiate their contention that the additional
burden would be beyond their capacity to pay. In this connection, we ought to recall the fact that
what the appellants are required to prove is that the prospects of their financial position in future
justify a reduction in the wage which is being paid to the industrial employees during all these years;
for that on the ultimate analysis would be the result if their contention is accepted. The Industrial
Court has made a definite finding that it does not think that the financial condition of the industry
has deteriorated so as to justify a departure _from the principles in regard to dearness allowance
hitherto laid down in respect of this industry at this centre. In our opinion, this conclusion is
well-founded. It was conceded before us that our decision in Civil Appeals Nos. 167-173 of 1965
would govern the decision of Civil Appeals Nos. 537-538 of 1965. So, the result is that all the said
appeals fail and are dismissed with costs. One set of hearing fee.
Appeals dismissed.
3up.CI,/65-13Ahmedabad Mill Owners' Association Etc vs The Textile Labour Association on 10 August, 1965

