Ganesh Bank, Kurundwad Ltd. And Ors vs The Union Of India
And Ors on 28 August, 2006
Equivalent citations: AIRONLINE 2006 SC 231
Author: Arijit Pasayat
Bench: Arijit Pasayat, C.K. Thakker
           CASE NO.:
Appeal (civil)  3698 of 2006
PETITIONER:
Ganesh Bank, Kurundwad Ltd. and Ors.
RESPONDENT:
The Union of India and Ors.
DATE OF JUDGMENT: 28/08/2006
BENCH:
ARIJIT PASAYAT & C.K. THAKKER
JUDGMENT:
J U D G M E N T (Arising out of SLP (C) No. 7188 of 2006) ARIJIT PASAYAT, J.
Leave granted.
The present appeal is directed against the judgment and order dated 5.4.2006 passed by a Division
Bench of the Bombay High Court in Writ Petition No.337/2006 questioning Notification dated 7th
January, 2006 issued by the Government of India, Ministry of Finance imposing a moratorium in
respect of the appellant-Ganesh Bank of Kurundwad Ltd. (hereinafter referred to as "Bank") for a
period of three months from the date of order upto and inclusive of 6th April, 2006. Amongst
others, the said Bank was directed not to grant any loan or advances or incur liability without the
permission in writing of the Reserve Bank of India (in short the 'RBI''). Further, withdrawal of sums
not exceeding 5,000/- by a Savings Bank or Current Account holder was permitted with a further
relaxation of amount not exceeding Rs.10,000/- or the actual balance whichever is less in the event
of certain difficulties such as medical treatment, higher education and obligatory expenses like
marriage etc. Challenge was also made to the appointment of two Directors on the Board of
Directors of the Bank.
Further Challenge was made to the Notification dated 9.1.2006 proposing a scheme of
amalgamation of the Bank with Federal Bank, another private sector commercial bank and to the
order dated 24.1.2006 sanctioning amalgamation of Bank with Federal Bank.Ganesh Bank, Kurundwad Ltd. And Ors vs The Union Of India And Ors on 28 August, 2006

It is to be noted that along with the said writ petition filed by the Bank, another writ petition (WP(C)
No. 160/2006) was filed by one Mr. Sunil Mahadev Chavan.
The background facts in which the writ petitions were filed are essentially as follows:
Appellant Bank was founded sometimes in the year 1920 and is having a banking
license given by the RBI. It has some 32 branches situated principally in districts of
Kolhapur and Sangli of Maharashtra and the adjoining Belgaum District of
Karnataka. It has around 1,75,000 depositors in the rural areas of these three
districts.
It was carrying on its activities smoothly, and it incurred losses only once and that was in the
financial year 2004-05. That was also for the reasons which were beyond its control, viz (i) the value
of the government securities, wherein it had made deposits, went down, and (ii) the provisioning
norms set up by the RBI were made more stringent by it. It was on this background that it was
shocked to receive the order of moratorium in the morning of 8th January, 2006. It led to
unnecessary long queue at its Dadar branch, Mumbai, though there was no run on the bank any
time in the past or even on that day as such. Thereafter, the issuance of the moratorium and the
decision of the RBI to take further steps was duly advertised. The RBI appointed two directors of its
own on the Board of Directors of the appellant-Bank on 7th January, 2006. The RBI then notified
the proposed scheme of amalgamating the appellant-Bank with the Federal Bank on 9th January,
2006. The appellant-Bank objected to it by filing its objections on 23rd January, 2006, yet a
decision was taken by the RBI and the Central Government on 24th January, 2006 sanctioning
amalgamation of the appellant-Bank with the Federal Bank.
An interim order was passed by the High Court in W.P.337/2006 by which operation of the order
dated 24.6.2006 was stayed and status quo was directed to be maintained. The order was challenged
by the RBI and Federal Bank before this Court.
By Order dated 30.1.2006 this Court directed that the petitions were to be heard and decided early
by the High Court. However, the interim order was left undisturbed.
Before the High Court the principal submissions of the writ petitioners were two-fold, namely that
the order dated 7th January, 2006 imposing moratorium and then the order dated 7th January,
2006 appointing two Directors are both mala fide to suit the convenience of Federal Bank, ultra
vires the power of the RBI and the Central Government and, therefore, bad in law, illegal and void.
Similarly, the other submission of the writ petitioners was that the subsequent framing of scheme of
amalgamation on 9th January, 2006 and the decision to sanction the amalgamation taken on 24th
January, 2006 are motivated and pre-planned decisions for the benefit of the Federal Bank, mala
fide and ultra vires the powers of the Central Government and the RBI. It was further submitted that
both these decisions are not justified on facts and have been arrived at without taking into
consideration the relevant materials. As far as the first decision imposing the moratorium is
concerned, it was submitted that there were no good reasons to impose the same and, as far as the
decision to amalgamate is concerned, it was submitted that the said decision was arrived at withoutGanesh Bank, Kurundwad Ltd. And Ors vs The Union Of India And Ors on 28 August, 2006

considering the proposals of four other banks which were better placed and had made better offers.
As against these submissions of the writ petitioners, the stand of the RBI and the Central
Government was that the Bank was in serious financial difficulties and therefore, the moratorium
had to be imposed. The moratorium was fully justified on the facts of the case. The decision to
amalgamate the appellant Bank with the Federal Bank was arrived at in full compliance with the
statutory requirements and after considering relevant materials on record as well as the suggestions
and objections from the appellant-Bank and all concerned, and after examining the proposals from
the four other banks. It was, therefore, submitted that there is no reason to interfere with the
decisions arrived at by the RBI and the Central Government which essentially were for benefit of the
depositors. It was submitted that the interest of the employees was taken care of and the interest of
the shareholders obviously came last.
According to the High Court the following two questions were to be adjudicated:
"(A) Whether the decision dated 7th January, 2006 of the Central Government
imposing moratorium and to appoint two directors was mala fide, ultra vires the
powers of the Central Government and the RBI, bad in law and void and unjustified
on facts?
(B) Whether the notification dated 9th January, 2006 containing the proposed
scheme of amalgamation and the decision to sanction the amalgamation dated 24th
January, 2006 were mala fide, ultra vires the powers of the Central Government and
the RBI and unjustified on facts?"
Taking note of the factual background the High Court held that the inference drawn by RBI was a
positive inference and cannot be termed to be perverse. The High Court felt that it is the discretion
of the decision maker where two views are possible and if the regulatory body arrived at a
conclusion on the basis of facts and figures before it and points out that it has been warning the
Bank for last over three years it will not be proper for the High Court to substitute its judgment for
that of the RBI. Therefore, it was held that the decision of the RBI to impose the moratorium was
neither unjustified nor against the provisions of Section 45(1) of the Banking Regulation Act, 1949
(in short the 'Act'). It was noted that the RBI is an expert body to regulate the banking activities and
its judgment based on the factual scenario cannot be substituted by the High Court, may be because
another view of the matter was possible. The High Court held that the allegation of mala fides was
not substantiated. It was also of the view that while dealing with the question of mala fides, the
following questions were also to be dealt with:
"(i) The first one is non-consideration of any scheme for reconstruction before going
for amalgamation.
(ii) The second is with respect to proposing amalgamation with Federal Bank on 9th
January, 2006 itself.Ganesh Bank, Kurundwad Ltd. And Ors vs The Union Of India And Ors on 28 August, 2006

(iii) The third facet is not considering the proposal of other banks.
(iv) The fourth is in respect to an adequate opportunity under Section 45(6) and (7)
of the Act."
After considering the rival submissions, the High Court held that the allegations were mala fides and
were not established. Accordingly, the writ petitions were dismissed.
The stands taken before the High Court were re-iterated by learned counsel appearing for the
appellant and the respondents.
Learned counsel for the appellants submitted that the undue and unseemly haste with which the
order of moratorium dated 7.1.2006 was passed is a clear indication of mala fides. Moreover, full
and correct facts were not placed by the RBI before the Central Government, in particular, facts
regarding bank balances with the RBI and other banks and cash at hand amounting to Rs.36.62
crores were not placed before the Central Government. Actual figure of those liquid assets were
Rs.119 crores as against total deposits of Rs.217.43 crores which is 55% against required 25% as per
RBI norms. This was indicative of the bank's strong liquidity position. Total assets of the bank as on
31.3.2005 were Rs.235.44 crores as against total liabilities of Rs.220.45 crores. Therefore, the assets
were exceeding the liabilities by Rs.14.99 crores. Even as on 31.12.2005, the assets were exceeding
the liabilities by Rs.17.70 crores. The net loss in the year 2004-05 on which great stress was laid by
the RBI and the Central Government was on account of notional/book entry loss with respect to
additional provision for Non Performing Assets (in short the 'NPAs') and depreciation in the value
of Government securities. In respect of Urban Cooperative Banks, the RBI has relaxed provisional
norms up to 5 years in respect of depreciation in the value of Government securities. However, the
same was denied to the Bank. Majority advances of the banks were given to the priority sector
namely Agricultural advances to which Securitisation Act is not applicable. Therefore, relaxation
was necessary to be given. The RBI had granted permission to the Bank to open three new Branches
after being satisfied that the Bank was in a sound financial position. Several awards were given to
the Bank for exercising banking services. There was no complaint from any depositor, customer or
shareholder and the Bank has not defaulted in payment of taxes or other government dues.
When objections were called for by the RBI regarding amalgamation within a span of 15 days in
January, 2006, out of the total objections received by RBI, 97.49% of the customers/depositors
objected to moratorium and/or amalgamation of the Bank and have opted for independent entity of
the Bank.
The factual scenario indicates that the proposal for amalgamation with the Federal Bank was
circulated and in a pre-determined manner the proposal was ultimately approved on 24.1.2006. The
draft scheme of amalgamation was sent to the Central Government to be operative w.e.f. 27.1.2006.
When the appellant-Bank approached the High Court on 24.1.2006 and the copy of the writ petition
was served on the RBI and the Central Government, the Notification of amalgamation w.e.f.
25.1.2006 was issued on 24.1.2006 itself so that it could be argued before the High Court that the
appellant Bank was no longer in existence on 25.1.2006. The exercise of power under Section 45 ofGanesh Bank, Kurundwad Ltd. And Ors vs The Union Of India And Ors on 28 August, 2006

the Act was done solely for the purpose of favoring the Federal Bank. Though Section 36(AB) of the
Act empowers the RBI to appoint Additional Directors there is no provision which empowers RBI to
direct that no decision of the Board of Directors would be valid unless it is approved by the Directors
appointed by the RBI.
The entire exercise was pre-conceived under the garb of exercise of statutory authority. There was a
systematic plan to amalgamate the appellant-Bank with the Federal Bank. The entire proceedings
are thus vitiated by malice in law. The rejection of the proposal of Saraswat Bank is vitiated on
account of misunderstanding of Section 56(zb) of the Act and on account of a failure to consider the
interest of shareholders whose interest would continue to be of paramount importance. On account
of heavy floods there was temporary disruption of banking activities and this aspect has not been
considered.
The fact that Federal Banks' Board Meeting was preponed from 11.1.2006 to 8.1.2006 is a pointer to
the fact that they were very much in know of things to gain under advantage.
The data given by the RBI relating to some other amalgamation i.e. in cases of Global Trust Bank
and Nedgundi Bank have no relevance as in those cases there were large scale complaints of fraud.
In response, learned counsel for the respondent No.4 i.e. Federal Bank submitted as follows:
The procedure, process and yardsticks envisaged under Section 45 of the Act for the
amalgamation of a financially unviable bank with a stronger bank, cannot be the
same as are applicable to a tender process. It is submitted that when acting under
Section 45 of the Act, the primary consideration must be of public interest. Under the
said provision, the RBI has the statutory duty and responsibility to act swiftly and
decisively to protect interests of depositors and public confidence in the banking
system. In contrast, when awarding a tender, it is primarily commercial
considerations that must be the selection process. It is, therefore, submitted that it is
in public interest not to interfere on commercial consideration with a decision made
under Section 45 so long as it safeguards depositors' interests and public confidence
in the banking system in an emergent situation.
The respondent No.4-Federal Bank is a financially strong bank with high net worth,
large capital funds and huge amount of deposits with more than adequate capital to
Risk Weighted Assets Ratio (in short the 'CRAR'). Its net worth is about Rs.897
crores and its capital is about Rs.85 crores It has deposits to the tune of Rs.16,448
crores and its CRAR at 11.34%, exceeds the Reserve Bank of India requirement of 9%.
It has a very low percentage of NPA with its Gross NPAs being 5.17% and Net NPA
being 1.41%. As of 31st December, 2005 Federal Bank has recorded a profit of
Rs.174.48 crores. The contrast on each of these parameters with the appellant-Bank
is striking. On each parameter, the performance of the appellant-Bank is abysmal in
comparison to Federal Bank.Ganesh Bank, Kurundwad Ltd. And Ors vs The Union Of India And Ors on 28 August, 2006

It is also pertinent to note that Section 45 of the Act does not contemplate or require the consent of
either the transferor or the transferee bank, although both are given an opportunity to lodge their
objections/suggestions to the draft scheme, before a final decision is taken.
It was submitted that Federal Bank was not privy to any information from RBI regarding the status
of the appellant- Bank or any proposal to impose a moratorium at any time prior to 7.1.2006 when
for the first time the order of moratorium and the RBI's press release was placed on RBI's website.
It was also submitted that allegations of complicity based on the advancement of the date of Federal
Bank's Board Meeting from 11.1.2006 to 8.1.2006 are completely unfounded. It was submitted that
Federal Bank had indeed vide its Notice dated 29.12.2005 originally scheduled the said Board
Meeting for 11.1.2006 at Kochi, but this date was found to be inconvenient to several directors.
Instead, 8.1.2006 was found to be a more convenient date for the meeting, since firstly many of the
directors were congregating at Kochi for the wedding of the son of one of Directors on that date, and
secondly, one other director, an NRI was scheduled to attend a meeting at the PMO on 7.1.2006.
The said director would also have found it convenient to attend the Board Meeting, if it were to be
held on 8.1.2006. In view thereof, for bona fide reasons and in good faith, the said Board meeting
was rescheduled for 8.1.2006 vide notice dated 4.1.2006.
Certain aspects which have been noted by the High Court to dismiss the appellant's writ petition
need to be noted to test how for the conclusions are correct.
The first is whether there were "good reasons" for the RBI to apply to the Central Government for
the moratorium which led to the impugned order dated 24th January, 2006, the concept of "good
reasons" contemplated under Section and as to how the RBI justifies its decision on the basis of the
yardstick applied by it. As far as the appellant bank is concerned, its case is that it is a small
commercial bank and the only year in which it had made losses was for the financial year 2004-05.
That was because of the value of the Government securities going down and the provisioning norms
being made more stringent by the RBI. According to the RBI's application to the Central
Government, the net worth of the petitioner bank had become negative and so also CRAR had
become negative and was at 5.83.
As against this stand of the RBI, it was pointed out on behalf of the appellant-Bank that Annexure-I
to RBI's application under Section 45(1) dated 4th January, 2006 contained the key financial
positions of the Bank. Clause 8 thereof dealt with the NPAs. It was pointed that the net NPAs had
gone down from 10.59% to 8.32%. It was also pointed out that the Bank had done good resource
mobilization in the meantime and its paid up capital had gone up from Rs.1.52 crore to Rs.1.82
crore.
In para 5 of the letter, the RBI wrote to the Additional Secretary, Ministry of Finance that infusing
fresh capital did not appear to be feasible. There was reluctance on the part of the shareholders and
directors to merge with the stronger Bank. It was therefore imperative to make immediate
arrangement to protect the interest of the depositors to merge with another bank. It is for this
purpose that the moratorium was proposed under Section 45(1) In the counter affidavit filed beforeGanesh Bank, Kurundwad Ltd. And Ors vs The Union Of India And Ors on 28 August, 2006

the High Court, it was stated on behalf of RBI that in June 1998, the Chairman of the appellant Bank
was advised that old private sector banks having present net worth of Rs.5 lakhs should attain the
level of Rs.50 crores within a period of 3 years On 12th January, 1999, the appellant -Bank sent the
plan to augment resources up to Rs.20.08 crores over the period of 5 years. At on 31st March, 2002
its net worth stood at only Rs.6.62 crores and its paid up capital as on 31st March, 2005 was Rs.1.82
crore. It was further stated that as per the Bank's Balance Sheet as on 31st March, 2005, it had
reported the net loss of Rs.5.97 crores. In view of the deteriorating financial position, further
meetings were held on 12th August, 2005, 26th August, 2005 and 12th September, 2005 to point
out the major concerns of RBI vis. low paid up capital of Rs.182 crore, high level of gross NPAs
(18.04%) and net loss of Rs.5.97 crores. On 14th October, 2005 the bank was asked to submit a
detailed plan for capital augmentation. It is on the background that the moratorium was imposed on
7th January, 2006.
Appellants' stand was that since deposits with the Bank were Rs.92 crores, it was irrational to insist
that it should have capital funds of Rs.50 crores. It was however pointed out that the Bank was
consistently increased its capital and it stood at Rs.2.95 crores by 5th January, 2006 which included
Rs.1.13 crore in the form of share application money. It was nothing but a part of share capital.
Again, as far as NPAs are concerned, they had gone down from 14.10% to 9% and, as far as loss of
Rs.5.97 crores is concerned, it is because of the change in the provisioning norms.
High Court noted that the Bank had paid up capital of Rs.1.82 crores only, high gross NPAs at
18.04% and net loss of Rs.3.97 crores. It was in these circumstances that the RBI had to decide as to
whether the depositors of the Bank required any protection. RBI had been monitoring the financial
position of the Bank since June 1998 and since December 2003 the Bank had been placed under
monthly monitoring as provided under Section 27 of the Act. According to High Court, expression
"good reasons" under Section 45(1), primarily relates to interest of the depositors and the interest of
the Bank. This is because the primary objective of the Act is protection of the interest of depositors
as against the primary objective of the Company Law which is to safeguard the interest of
shareholders. This is what is specifically stated in the Objects and Reasons of the Act. On these facts,
the RBI was of the view that an appropriate action was necessary. It could not be said that the
decision was lacking in the absence of good reasons. It is difficult to say that it was taken for the
benefit of the Federal Bank since these reasons go back to December 2003 when Federal Bank was
not in picture.
It has been submitted that a small bank like the appellant cannot be expected to have the Capital
Adequacy of Rs.50 crores as advised in June 1998 and which was later on revised to Rs.300 crores
by circular dated 20th February 2004. Reference is made to Section 11(3)(i) of the Act which
provides that if a banking company has places of its business in more than one State, it is required to
have the aggregate value of its paid-up capital and reserves at not less than Rs.5 lakhs. If that is the
expectation, the RBI cannot insist on the requirement of Rs.50 crores and then go on increasing it
further. Reliance is placed on the decision of this Court in Assam Co. Ltd. v. State of Assam (2001
(4) SCC 202), which lays down that a delegate cannot over-ride the Act either by exceeding the
authority or by making provision which is inconsistent with the Act. On the other hand, stand of RBI
is that the language of Section 11(3)(i) is that in the case of such a banking company, the aggregateGanesh Bank, Kurundwad Ltd. And Ors vs The Union Of India And Ors on 28 August, 2006

value of paid-up capital and reserves shall not be less than Rs.5 lakhs. Therefore, insistence of Rs.50
crores or a higher amount cannot be said to be erroneous. With globalisation, finance and banking
in rural areas also have to improve and it is from that point of view that the RBI had expected the
above referred enhancement. That was expected from all similarly situated banks and not merely
from the appellant-Bank alone. Reference is made to the expectations under the Basle Committee on
Banking Supervision, 1988 and the first Narasimham Committee Report on Financial System, 1991
which recommended on the basis of the Basle Committee that India also must conform to the
international standards of capital adequacy in a phased manner. Second Narsimham Committee
Report on Banking Sector Reforms of 1998 led RBI to issue guidelines to revise the minimum
paid-up capital for the private sector banks.
The actual scenario shows that when the paid-up capital of the Bank is so low, namely Rs.1.82 crore,
its gross NPAs are at higher level (8.04%), its net worth had turned negative and the net loss is
Rs.5.97 crores. There was nothing wrong on the part of the RBI to expect an appropriate plan of
capital augmentation. The Bank has not been able to do that and it was quite likely that it would
land into difficulties. The phrase "good reasons" in sub-section (1) of Section 45 is a term of wide
amplitude and it will not be correct to restrict it only to the actions mentioned under sub-section (2)
of Section 45 of the Act as is contended by the appellant. The provision is concerned with preparing
a scheme of reconstruction or amalgamation which would become necessary where the RBI is
satisfied about the existence of any of the four grounds mentioned in Section 45(4). Apart from
public interest and the interest of the banking system, which are provided in sub-clause (a) and (d)
thereof, Section 45(4) provides for the necessary action in the interest of the depositors or with a
view to secure proper management of the bank which are grounds (b) and (c) in that sub-section.
Precursor to the framing of the scheme is the imposition of the moratorium which is provided in
sub-sections (1) and (2) of Section 45. Existence of court proceedings, mentioned in section 45(2),
would certainly be one of the good reasons to impose moratorium, but that certainly cannot be the
only one. Considering that object of the Act is protection of the interest of the depositors, such an
interpretation of the concept of "good reasons" will have to be adopted, and not a narrow one. It has
been contended that there was a negative impact when moratorium was imposed, and there were
long queues at four branches of the appellant Bank on 8th January 2006. The RBI arranged to send
an amount of Rs.2 crores to the Bank from its Current Account to meet the depositors' demands.
The manager of the Appellant Bank's branch at Dadar has made an affidavit to state that he had not
asked for an amount of Rs.2 crores and yet it was sent by RBI. The branch manager has further
stated that depositors were unhappy with the decision of RBI. These are all disputed questions as
rightly noted by the High Court. As far as the views of the depositors are concerned, they are bound
to vary from person to person and no definite conclusion can be drawn merely on the bank
manager's affidavit that people were angry against RBI. Besides, no depositor has questioned
legality of the action. It can be said that the action of the RBI is a pre-emptive action which it took
considering the then financial position of the appellant Bank and to prevent further difficulties
which were likely. It is not that when there is a run on the bank then only RBI must intervene or that
it must intervene only when there are good number of court proceedings against the concerned
bank. The RBI has to take into account the totality of the circumstances and has to form its opinion
accordingly.Ganesh Bank, Kurundwad Ltd. And Ors vs The Union Of India And Ors on 28 August, 2006

The ultimate question is whether the inference drawn by the RBI is a possible inference or is
something which can be said to be a perverse one. Even if two views are possible since the regulating
body has arrived at a conclusion on the basis of the facts and figures before it, and it has pointed out
that it has been warning the appellant Bank for last over 3 years, it will not be proper for the Courts
to substitute their judgment for that of RBI. In the circumstances, it cannot hold that the decision of
RBI to impose the moratorium was unjustified or against the provisions of section 45(1) or such that
one can call it a perverse one and interfere with it. The RBI is an expert body to regulate the banking
activities. The moratorium has been challenged on the ground of malafides also. This challenge
along with the challenge to amalgamation also on the basis of malafides needs to be considered. As
far as the challenge to the appointment of two directors on the Board of Directors of the appellant
Bank is concerned, the RBI has the necessary power under Section 36AB of the Act. In the
circumstances, it cannot be faulted for appointing the two directors.
That brings into focus the question as to whether the decision of RBI to recommend a scheme for
amalgamation on 9th January 2006 and the decision of the Government to sanction the
amalgamation on 24th January 2006 could be said to be mala fide or bad in law. As far as this
question is concerned, it contains many sub-questions which are as follows:-
(i) The first one is non-consideration of any scheme for reconstruction before going
for amalgamation.
(ii) The second is with respect to proposing amalgamation with Federal Bank on 9th
January 2006 itself.
(iii) The third facet is not considering the proposal of four other banks.
(iv) The fourth is with respect to an adequate opportunity under Section 45(6) and
(7) of the Act.
Now, as far as the first two questions of non-
consideration of reconstruction and proposing merger with Federal Bank, the RBI has noted that
the Bank was in difficulties from 1990 and particularly from December 2003 when it was placed
under monthly monitoring. RBI in its application for moratorium to the Central Government dated
4th January 2006 had clearly stated that during the discussion with the appellant-Bank, major
shareholders and directors had shown total reluctance to merge into the stronger bank. In view
thereof, it was imperative that immediate arrangement to protect the interest of the depositors was
to be made through its merger with a bank under Section 45 of the Act. RBI had, therefore, made an
effort and called upon the appellant-Bank, that if possible, to explore the possibility of merger with
another stronger bank. It had also made an effort to impress that there should be infusion of fresh
capital. That was not coming. There could be a reconstruction by bringing in more money or by
narrowing the size of the appellant-Bank which did not appear to be feasible. The only option left
was that of amalgamation. When a moratorium is imposed, RBI was duty bound to prepare a
scheme either of reconstruction or of amalgamation under Section 45(4) with any other bankingGanesh Bank, Kurundwad Ltd. And Ors vs The Union Of India And Ors on 28 August, 2006

institution. Thus, RBI had to give a scheme. Federal Bank had responded immediately and
unconditionally. The fact that the appellant- Bank was put under moratorium was advertised on web
site on 7th January 2006 itself. It is at that stage that Federal Bank promptly gave its proposal on
8th January 2006. The Federal Bank gave three reasons in its letter to RBI which were as follows:-
(i) Ganesh Bank of Kurundwad Ltd. has 32 branches situated in Western
Maharashtra and Belgaum area of Karanataka. Our presence in this area is very
minimal and adding up of the branches of Ganesh Bank of Kurundwad Ltd. will
enable us to have significant presence in the area.
(ii) Ganesh Bank of Kurundwad Ltd. has mot of the branches in the agricultural
heartland which would enable us to augment our credit disbursal to agricultural
sector.
(iii). Small size of Ganesh Bank of Kurundwad Ltd. ensures that there will not be any
difficulty in the merger process between our bank and them.
Thereafter it stated as follows:-
We also inform our unconditional acceptance to make full payment to depositors and
that we will not demand any regulatory forbearance."
Thus, the Federal Bank was ready to honour full liabilities of the depositors and did
not ask for any concessions. Therefore, on the basis of a standard scheme, the
opinion of the appellant-Bank was sought on 9th January 2006 with respect to
merger in Federal Bank. The scheme was described as a "cut and paste scheme" and
of RBI's action as a regulator in the interest of the depositors was highlighted.
It appears that the action of the RBI was based on the finding about the negative net
worth and CRAR of the Appellant-Bank, its inability to infuse fresh capital and the
continued existence of a high level of NPAs. It has been rightly pointed out that once
it was decided to amalgamate by reason of Section 45 of the Act, the RBI had to move
with utmost expedition. This is of paramount importance to prevent erosion of the
confidence of the depositors. Once such confidence is lost it becomes difficult to
revive the confidence and the credibility.
This Court had occasion to deal with need for expedition in Joseph Kuruvilla
Vellukunnel v. Reserve Bank of India and Ors. (1962 (Supp.) 3 SCR 632) and Reserve
Bank of India and Ors. v. Timex Finance and Investment Co. Ltd. and Ors. (1992 (2)
SCC 344). It is not in dispute that there were long queues and on 8.1.2006 the one
branch of the appellant-Bank actually faced cash shortage and had to draw its funds
with the RBI protecting the interest of the depositors because during such period
there are severe restrictions on the ability of the depositors to operate their bank
accounts. Therefore, with a view to protect the interest of the depositors, the RBI hasGanesh Bank, Kurundwad Ltd. And Ors vs The Union Of India And Ors on 28 August, 2006

to act expeditiously to identify another bank prepared to take over the
appellant-Bank and keeping in view the background principles governing merger and
amalgamation RBI had to act with expedition. The factual scenario does not show
that there was any undue haste or mala fides involved.
Under Section 45 of the Act, the primary consideration is public interest. There is an underlying
object of acting swiftly and decisively to protest interests of depositors and ensure public confidence
in the banking system. The emergent situation which warrants action with expedition cannot be lost
sight of while deciding the legality of the action.
It is brought on record that Federal Banks' strength lay on the fact that it is a strong bank with huge
net worth, large capital funds and huge amount of deposits with more than adequate CRAR. Its net
worth is about Rs.897 crores, capital is around Rs.85 crores, and deposits to the tune of Rs.16,448
crores. Its CRAR (11.34%) exceeds the RBI requirement (9%) and percentage of NPAs (Gross and
Net) is (5.17% and 1.41% respectively). For the accounting period ending 31st December, 2005 its
profit is Rs.174 Crores.
As observed by this Court in Bari Doab Bank Ltd. v. Union of India and Ors. (1997 (6) SCC 417) the
provisions of Section 45 of the Act provide adequate opportunity of a representation and no
additional opportunity is required to be given. The objection filed by the appellant-Bank was duly
considered. In fact, certain objections were raised and comments of the RBI on them were
forwarded to the Central Government along with the final recommendations. The RBI was of the
view that the proposal received from the Federal Bank was best under the circumstances and,
therefore, the same appears to have been accepted.
At this juncture it is to be noted that offer of Federal Bank was an unconditional offer, whereby it
proposed to take over the responsibility of any regulatory forbearance. Three reasons given by the
Federal Bank to take over the appellant's Bank were considered cogent reasons and, therefore, RBI's
decision cannot be faulted. As rightly contended the offers received from the City Bank, Standard
Chartered Bank were neither comprehensive nor unconditional. In fact, they were not concluded
offers, since they were both dependent upon a request for due diligence and in certain instances
regulatory forbearances. Ratnakar Bank's offer was not accepted as it was itself an ailing bank.
Learned counsel for the appellants has highlighted that Sarastwat Bank's offer was an equally good
offer if not better and should have been accepted. It has been pointed out by learned counsel for the
respondents that Saraswat Bank is a Multi State Co-operative Bank and its functioning is governed
by Multi State Cooperative Societies Act, 2002 (in short '2002 Act'). The legal opinion available to
the RBI was that it was not feasible or permissible to amalgamate a commercial bank with a
cooperative Bank by reason of the provisions of the Act as well as 2002 Act. The RBI was of the view
that such amalgamation is not possible under Sections 17 and 18 of the 2002 Act as also Section 56
(zb) of the Act. It was pointed out that Saraswat Bank cannot be considered to be a banking
company for the purpose of Section 45(4) to 45(15) of the Act. In order to be a banking company
within the meaning of the Act, the entity in question must be a company. Section 56(zb) of the Act
excludes the applicability of Section 45(4) to 45(15) so far as cooperative banks are concerned. ItGanesh Bank, Kurundwad Ltd. And Ors vs The Union Of India And Ors on 28 August, 2006

was pointed out that even if it is conceded for the sake of argument that legally amalgamation is
permissible it could have taken a very long time to get requisite clearance from several other
agencies under the 2002 Act and could not have gone through expeditiously. It is also pointed out
that an amalgamation of Multi State Cooperative Bank is subject to far less regulatory control of the
RBI especially in relation to non banking matters. There is no dispute that the application made by
Saraswat Bank was duly considered by the RBI.
The scope of Judicial review in administrative matters has been the subject matter of consideration
before this Court in several cases.
There should be judicial restraint while making judicial review in administrative matters. Where
irrelevant aspects have been eschewed from consideration and no relevant aspect has been ignored
and the administrative decisions have nexus with the facts on record, there is no scope for
interference. The duty of the court is (a) to confine itself to the question of legality; (b) to decide
whether the decision making authority exceeded its powers (c) committed an error of law (d)
committed breach of the rules of natural justice and (e) reached a decision which no reasonable
Tribunal would have reached or (f) abused its powers. Administrative action is subject to control by
judicial review in the following manner:
(i) Illegality: This means the decision-
maker must understand correctly the law that regulates his decision-making power and must give
effect to it.
(ii) Irrationality, namely, Wednesbury unreasonableness.
(iii) Procedural impropriety.
One of the points that falls for determination is the scope for judicial interference in matters of
administrative decisions. Administrative action is stated to be referable to broad area of
Governmental activities in which the repositories of power may exercise every class of statutory
function of executive, quasi- legislative and quasi-judicial nature. It is trite law that exercise of
power, whether legislative or administrative, will be set aside if there is manifest error in the
exercise of such power or the exercise of the power is manifestly arbitrary (See State of U.P. and Ors.
v. Renusagar Power Co. and Ors. (AIR 1988 SC 1737). At one time, the traditional view in England
was that the executive was not answerable where its action was attributable to the exercise of
prerogative power. Professor De Smith in his classical work "Judicial Review of Administrative
Action" 4th Edition at pages 285-287 states the legal position in his own terse language that the
relevant principles formulated by the Courts may be broadly summarized as follows. The authority
in which discretion is vested can be compelled to exercise that discretion, but not to exercise it in
any particular manner. In general, discretion must be exercised only by the authority to which it is
committed. That authority must genuinely address itself to the matter before it; it must not act
under the dictates of another body or disable itself from exercising discretion in each individual
case. In the purported exercise of its discretion, it must not do what it has been forbidden to do, norGanesh Bank, Kurundwad Ltd. And Ors vs The Union Of India And Ors on 28 August, 2006

must it do what it has not been authorized to do. It must act in good faith, must have regard to all
relevant considerations and must not be influenced by irrelevant considerations, must not seek to
promote purposes alien to the letter or to the spirit of the legislation that gives it power to act, and
must not act arbitrarily or capriciously. These several principles can conveniently be grouped in two
main categories: (i) failure to exercise a discretion, and (ii) excess or abuse of discretionary power.
The two classes are not, however, mutually exclusive. Thus, discretion may be improperly fettered
because irrelevant considerations have been taken into account, and where an authority hands over
its discretion to another body it acts ultra vires.
The present trend of judicial opinion is to restrict the doctrine of immunity from judicial review to
those classes of cases which relate to deployment of troupes, entering into international treaties, etc.
The distinctive features of some of these recent cases signify the willingness of the Courts to assert
their power to scrutinize the factual basis upon which discretionary powers have been exercised.
One can conveniently classify under three heads the grounds on which administrative action is
subject to control by judicial review. The first ground is 'illegality' the second 'irrationality', and the
third 'procedural impropriety'. These principles were highlighted by Lord Diplock in Council of Civil
Service Unions v. Minister for the Civil Service (1984 (3) All.ER.935), (commonly known as CCSU
Case). If the power has been exercised on a non-consideration or non-application of mind to
relevant factors, the exercise of power will be regarded as manifestly erroneous. If a power (whether
legislative or administrative) is exercised on the basis of facts which do not exist and which are
patently erroneous, such exercise of power will stand vitiated. (See commissioner of Income-tax v.
Mahindra and Mahindra Ltd. (AIR 1984 SC 1182) . The effect of several decisions on the question of
jurisdiction has been summed up by Grahame Aldous and John Alder in their book "Applications for
Judicial Review, Law and Practice" thus:
"There is a general presumption against ousting the jurisdiction of the courts, so that
statutory provisions which purport to exclude judicial review are construed
restrictively. There are, however, certain areas of governmental activity, national
security being the paradig, which the courts regard themselves as incompetent to
investigate, beyond an initial decision as to whether the government's claim is bona
fide. In this kind of non-justiciable area judicial review is not entirely excluded, but
very limited. It has also been said that powers conferred by the Royal Prerogative are
inherently unreviewable but since the speeches of the House of Lords in council of
civil Service Unions v. Minister for the civil Service this is doubtful. Lords Diplock,
Scaman and. Roskili appeared to agree that there is no general distinction between
powers, based upon whether their source is statutory or prerogative but that judicial
review can be limited by the subject matter of a particular power, in that case
national security. May prerogative powers are in fact concerned with sensitive, non-
justiciable areas, for example, foreign affairs, but some are reviewable in principle,
including the prerogatives relating to the civil service where national security is not
involved. Another nonjusticiable power is the Attorney General's prerogative to
decide whether to institute legal proceedings on behalf of the public interest."
(Also see Padfield v. Minister of Agriculture, Fisheries and Food (LR (1968) AC 997).Ganesh Bank, Kurundwad Ltd. And Ors vs The Union Of India And Ors on 28 August, 2006

The court will be slow to interfere in such matters relating to administrative functions unless
decision is tainted by any vulnerability enumerated above; like illegality, irrationality and
procedural impropriety. Whether action falls within any of the categories has to be established.
Mere assertion in that regard would not be sufficient.
The famous case commonly known as "The Wednesbury's case" is treated as the landmark so far as
laying down various basic principles relating to judicial review of administrative or statutory
direction.
Before summarizing the substance of the principles laid down therein we shall refer to the passage
from the judgment of Lord Greene in Associated Provincial Picture Houses Ltd. v. Wednesbury
Corpn. (KB at p. 229: All ER p. 682). It reads as follows:
"It is true that discretion must be exercised reasonably. Now what does that mean?
Lawyers familiar with the phraseology used in relation to exercise of statutory
discretions often use the word 'unreasonable' in a rather comprehensive sense. It has
frequently been used and is frequently used as a general description of the things that
must not be done. For instance, a person entrusted with a discretion must, so to
speak, direct himself properly in law. He must call his own attention to the matters
which he is bound to consider. He must exclude from his consideration matters
which are irrelevant to what he has to consider. If he does not obey those rules, he
may truly be said, and often is said, to be acting 'unreasonably' . Similarly, there may
be something so absurd that no sensible person could even dream that it lay within
the powers the authority. . . . In another, it is taking into consideration extraneous
matters. It is unreasonable that it might almost be described as being done in bad
faith; and in fact, all these things run into one another."
Lord Greene also observed (KB p.230: All ER p.683) "..it must be proved to be unreasonable in the
sense that the court considers it to be a decision that no reasonable body can come to. It is not what
the court considers unreasonable The effect of the legislation is not to set up the court as an arbiter
of the correctness of one view over another."
(emphasis supplied) Therefore, to arrive at a decision on "reasonableness" the Court has to find out
if the administrator has left out relevant factors or taken into account irrelevant factors. The
decision of the administrator must have been within the four corners of the law, and not one which
no sensible person could have reasonably arrived at, having regard to the above principles, and must
have been a bona fide one. The decision could be one of many choices open to the authority but it
was for that authority to decide upon the choice and not for the Court to substitute its view.
The principles of judicial review of administrative action were further summarized in 1985 by Lord
Diplock in CCSU case as illegality, procedural impropriety and irrationality. He said more grounds
could in future become available, including the doctrine of proportionality which was a principle
followed by certain other members of the European Economic Community. Lord Diplock observed
in that case as follows:Ganesh Bank, Kurundwad Ltd. And Ors vs The Union Of India And Ors on 28 August, 2006

".Judicial review has I think, developed to a stage today when, without reiterating
any analysis of the steps by which the development has come about, one can
conveniently classify under three heads the grounds on which administrative action
is subject to control by judicial review. The first ground I would call 'illegality', the
second 'irrationality' and the third 'procedural impropriety'. That is not to say that
further development on a casebycase basis may not in course of time add further
grounds. I have in mind particularly the possible adoption in the future of the
principle of 'proportionality' which is recognized in the administrative law of several
of our fellow members of the European Economic Community."
Lord Diplock explained "irrationality" as follows:
"By 'irrationality' I mean what can by now be succinctly referred to as Wednesbury
unreasonableness'. It applies to a decision which is to outrageous in its defiance of
logic or of accepted moral standards that no sensible person who had applied his
mind to the question to be decided could have arrived at it."
In other words, to characterize a decision of the administrator as "irrational" the Court has to hold,
on material, that it is a decision "so outrageous" as to be in total defiance of logic or moral
standards. Adoption of "proportionality" into administrative law was left for the future.
These principles have been noted in aforesaid terms in Union of India and Anr. v. C. Ganayutham
(1997 [7] SCC 463). In essence, the test is to see whether there is any infirmity in the decision
making process and not in the decision itself. (See Indian Railways Construction Co. Ltd. v. Ajay
Kumar (2003 (4) SCC 579).
Looked at from the aforesaid angle, the judgment of the High Court does not suffer from any
infirmity to warrant interference. The appeal is dismissed.Ganesh Bank, Kurundwad Ltd. And Ors vs The Union Of India And Ors on 28 August, 2006

