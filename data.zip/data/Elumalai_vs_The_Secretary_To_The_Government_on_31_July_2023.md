Elumalai vs The Secretary To The Government on 31 July, 2023
Author: M.Sundar
Bench: M.Sundar
                                                                               H.C.P.No.950 of 2023
                                  IN THE HIGH COURT OF JUDICATURE AT MADRAS
                                               DATED: 31.07.2023
                                                       Coram
                                   THE HONOURABLE MR.JUSTICE M.SUNDAR
                                                  and
                                  THE HONOURABLE MR.JUSTICE R.SAKTHIVEL
                                               H.C.P.No.950 of 2023
                     Elumalai                                     .. Petitioner/Detenu
                                                         vs
                     1.The Secretary to the Government
                       Home, Prohibition and Excise Department,
                      Secretariat, Chennai – 600 009.
                     2.The District Collector and District Magistrate of
                      Tiruvannamalai District, Tiruvannamalai
                     3.The Superintendent of Police,
                       Tiruvannamalai District, Tiruvannamalai
                     4.The Superintendent of Prison
                       Central Prison, Vellore-2
                     5.The Inspector of Police,
                       Jamunamarathur Police Station,
                       Tiruvannamalai District.                                .. Respondents
                           Petition filed under Article 226 of the Constitution of India praying
                     for issuance of a writ of habeas corpus to call for the records in
                     connection with the order of detention passed by the second respondent
                     dated 23.01.2023 in D.O.No.13/2023-C2 against petitioner/detenu
                     Elumalai, male, aged 22 years, son of Govindan, who is confined at
                     Central Prison, Vellore and set aside the same and direct the respondents
                     to produce the detenu before this Court and set him at liberty.
https://www.mhc.tn.gov.in/judis
                     1/9
                                                                                    H.C.P.No.950 of 2023Elumalai vs The Secretary To The Government on 31 July, 2023

                                  For Petitioner           :      Mr.D.Balaji
                                  For Respondents          :      Mr.E.Raj Thilak,
                                                                  Additional Public Prosecutor
                                                            ORDER
[Order of the Court was made by M.SUNDAR, J.] When the captioned 'Habeas Corpus Petition'
[hereinafter 'HCP' for the sake of convenience and clarity] was listed in the Admission Board on
06.06.2023, this Court made the following order:
' Captioned Habeas Corpus Petition has been filed in this Court on 15.05.2023 inter
alia assailing a detention order dated 23.01.2023 bearing reference D.O.No.13/2023-
C2 made by 'second respondent' [hereinafter 'Detaining Authority' for the sake of
convenience and clarity]. To be noted, fifth respondent is the Sponsoring Authority.
2. To be noted, detenu is the petitioner.
3. Mr.D.Balaji, learned counsel on record for habeas corpus petitioner is before us.
Learned counsel for petitioner submits that ground case qua the detenu is for alleged
offences under Sections 294(b) and 307 of 'Indian Penal Code, 1860 (Act 45 of 1860)'
['IPC' for brevity] and Sections 25(1B)(a) and 27(1) of Arms Act, 1959 and
subsequently, altered into Sections 294(b), 302 of IPC and Section 25(1B)(a) and
27(1) of Arms Act, 1959 in Crime No.171 of https://www.mhc.tn.gov.in/judis 2022 on
the file of Jamunamarathur Police Station.
4. The aforementioned detention order has been made on the premise that the
detenu is a 'Goonda' under Section 2(f) of 'The Tamil Nadu Prevention of Dangerous
Activities of Bootleggers, Cyber law offenders, Drug-offenders, Forest-
offenders, Goondas, Immoral traffic offenders, Sand- offenders, Sexual-offenders, Slum-grabbers
and Video Pirates Act, 1982 (Tamil Nadu Act No.14 of 1982)' [hereinafter 'Act 14 of 1982' for the
sake of convenience and clarity].
5. The detention order has been assailed inter alia on the ground that live and proximate link
between the grounds of detention and purpose of detention has snapped as the date of surrender in
the ground case is 12.12.2023 but the impugned detention order has been made only on 23.01.2023.
6. Prima facie case made out for admission. Admit. Issue Rule nisi returnable by four weeks.
7. Mr.R.Muniyapparaj, learned Additional Public Prosecutor, State of Tamil Nadu accepts notice for
all respondents. List the captioned Habeas Corpus Petition accordingly.'Elumalai vs The Secretary To The Government on 31 July, 2023

2. The aforementioned order made in the 06.06.2023 Admission listing shall be read as an integral
part and parcel of this order which https://www.mhc.tn.gov.in/judis means that the short forms,
short references and abbreviations used in the order in the Admission listing shall be used in the
instant order also.
3. There is no adverse case. The solitary case which is the sole substratum of the impugned
preventive detention order is Crime No.171 of 2022 on the file of Jamunamarathur Police Station for
alleged offences under Sections 294(b) and 307 of 'Indian Penal Code, 1860 (Act 45 of 1860)' ['IPC'
for brevity] and Sections 25(1B)(a) and 27(1) of Arms Act, 1959 and subsequently, altered into
Sections 294(b), 302 of IPC and Section 25(1B)(a) and 27(1) of Arms Act, 1959. Owing to the nature
of the challenge to the impugned preventive detention order, it is not necessary to delve into the
factual matrix or be detained further by facts.
4. Mr.D.Balaji, learned counsel on record for petitioner and Mr.E.Raj Thilak, learned State
Additional Public Prosecutor for all respondents are before us.
5. As would be evident from the Admission Board order dated 06.06.2023 (more particularly
paragraph 5 thereat), at the time of admission, learned counsel for HCP petitioner projected the
point that 'live and proximate link' between the grounds of detention and purpose of detention has
snapped as there is delay in passing the detention order. Elaborating on the aforementioned point,
learned counsel for petitioner https://www.mhc.tn.gov.in/judis submitted that 'live and proximate
link' between the grounds of detention and purpose of detention has snapped as date of arrest in the
ground case is 12.12.2022 but the impugned preventive detention order has been made only on
23.01.2023.
6. Mr.E.Raj Thilak, learned State Additional Public Prosecutor, submits to the contrary by saying
that materials had to be collected and time was consumed for the same. Considering the facts and
circumstances of the case and nature of ground case, we find that this explanation of learned State
Additional Public Prosecutor is unacceptable.
7. We remind ourselves of Sushanta Kumar Banik's case [Sushanta Kumar Banik Vs. State of
Tripura & others reported in 2022 LiveLaw (SC) 813 : 2022 SCC OnLine SC 1333]. To be noted,
Banik case law arose under 'Prevention of Illicit Traffic in Narcotic Drugs and Psychotropic
Substances Act, 1950' [hereinafter 'PIT NDPS Act' for the sake of brevity] in Tirupura, wherein after
considering the proposal by the Sponsoring Authority and after noticing the trajectory the matter
took, Hon'ble Supreme Court held that the 'live and proximate link between grounds of detention
and purpose of detention snapping' point should be https://www.mhc.tn.gov.in/judis examined on
a case to case basis. Hon'ble Supreme Court has held in Banik case law that this point has two facets.
One facet is 'unreasonable delay' and other facet is 'unexplained delay'. We find that the captioned
matter falls under latter facet i.e., unexplained delay.
8. To be noted, Banik case has been respectfully followed by this Court in Gomathi Vs.The Principal
Secretary to Government and others reported vide Neutral Citation of Madras High Court being
2023/MHC/334, Sadik Basha Yusuf Vs. The State of Tamil Nadu and others reported vide NeutralElumalai vs The Secretary To The Government on 31 July, 2023

Citation of Madras High Court being 2023/MHC/733, Sangeetha Vs. The Secretary to the
Government and others reported vide Neutral Citation of Madras High Court being
2023:MHC:1110, N.Anitha Vs. The Secretary to Government and others reported vide Neutral
Citation of Madras High Court being 2023:MHC:1159 and a series of other orders in HCP cases.
9. To be noted, the sole substratum of the impugned preventive detention order is a solitary case
viz., Crime No.171 of 2022 on the file of Jamunamarathur Police Station for alleged offences under
Sections https://www.mhc.tn.gov.in/judis 294(b) and 307 of IPC and Sections 25(1B)(a) and 27(1)
of Arms Act, 1959 and subsequently, altered into Sections 294(b), 302 of IPC and Section 25(1B)(a)
and 27(1) of Arms Act, 1959.
10. Before concluding, we also remind ourselves that preventive detention is not a punishment and
HCP is a high prerogative writ.
11. Ergo, the sequitur is, captioned HCP is allowed. Impugned detention order dated 23.01.2023
bearing reference D.O.No.13/2023-C2 made by the second respondent is set aside and the detenu
Thiru.Elumalai, aged 22 years, son of Thiru.Govindan, is directed to be set at liberty forthwith, if not
required in connection with any other case / cases. There shall be no order as to costs.
(M.S.,J.) (R.S.V.,J.) 31.07.2023 Index : Yes Neutral Citation : Yes gpa P.S: Registry to forthwith
communicate this order to Jail authorities in Central Prison, Vellore.
https://www.mhc.tn.gov.in/judis To
1.The Secretary to the Government Home, Prohibition and Excise Department, Secretariat, Chennai
– 600 009.
2.The District Collector and District Magistrate of Tiruvannamalai District, Tiruvannamalai
3.The Superintendent of Police, Tiruvannamalai District, Tiruvannamalai
4.The Superintendent of Prison Central Prison, Vellore-2
5.The Inspector of Police, Jamunamarathur Police Station, Tiruvannamalai District.
6.The Public Prosecutor, High Court, Madras.
https://www.mhc.tn.gov.in/judis M.SUNDAR, J., and R.SAKTHIVEL , J., gpa 31.07.2023
https://www.mhc.tn.gov.in/judisElumalai vs The Secretary To The Government on 31 July, 2023

