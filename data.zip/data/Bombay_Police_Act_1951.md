Bombay Police Act, 1951
BOMBAY PRESIDENCY
India
Bombay Police Act, 1951
Act 22 of 1951
Published on 11 June 1951• 
Not commenced• 
[This is the version of this document from 11 June 1951.]• 
[Note: The original publication document is not available and this content could not be
verified.]• 
For Statement of Objects and Reasons see Bombay Government Gazette, 1950, Part V, Page 324; for
Report of the Select Committee, see Bombay Government Gazette, 1951, Part V, pages
34-88.[Received assent of the President on the 1st June, 1951; assent first published in the Bombay
Government Gazette, Part IV, on the 11th June, 1951.]An Act to consolidate and amend the law for
the regulation of the Police Force in the State of BombayWhereas, it is expedient to amalgamate the
District and Greater Bombay Police Forces [and the Police Forces of the Saurashtra, Kutch and
Hyderabad areas, and of the Vidarbha region of the State of Bombay] into one common Police Force
and to introduce uniform methods regarding the working control of the said Force throughout the
State; And whereas it is necessary to consolidate and amend the law relating to the regulation of the
said Force and the exercise of powers and performances of functions by the State Government and
by the members of the said Force for the maintenance of public order; And whereas it is necessary to
provide for certain other purposes hereinafter appearing; It is hereby enacted as follows:-
Chapter I
Preliminary
1. Short title, extent and Commencement. - (1) This Act may be called [the
Maharashtra Police Act].
[(2) It extends to the whole of the State of [Maharashtra] ].[(3) It shall come into force [in the
pre-Reorganisation State of Bombay] on such date as the State Government may, by notification in
the Official Gazette [specify in this behalf], and in that part of the State to which it is extended by the
Bombay Police (Extension and Amendment) Act, 1959, it shall come into force on such other date as
that Government may by like notification specify].Bombay Police Act, 1951

2. Definitions. - In this Act, unless there is anything repugnant in the subject
or context,-
(1)"cattle" includes elephants, camels, horses, asses, mules, sheep, goats and swine;(2)"Corporation"
means a Corporation constituted under the Bombay Municipal Corporation Act or the Bombay
Provincial Municipal Corporations Act, 1949 [of the City of Nagpur Corporation Act, 1948];(3)The
expression "competent authority" when used with reference to the exercise of performance of any
power, duty or function under the provisions of this Act, means-(a)in relation to Greater Bombay
and other areas for which a Commissioner of Police is appointed under section 7, the
Commissioner;(b)in relation to the areas other than those referred to in clause (a), the District
Magistrate or the [Superintendent] or the Additional Superintendent when specially empowered in
that behalf by the State Government;[(c) in relation to a revenue division, the Revenue
Commissioner;](4)"constable" means a police officer of the lowest grade;[(4A) "dancing school"
means any place (by whatever name called) where dancing of any kind is taught to, or practised by,
persons on admission thereto either on payment of fees or with or without any other consideration;
but does not include any institution where dancing is taught or practised as one of the subject of its
curriculum and the institution is for the purposes of this Act duly recognised by the Government or
any officer duly authorised by Government in that behalf].(5)"district" means a territorial division
constituting a district for the purposes of the [Code of Criminal Procedure, 1898], but does not
include [any area for which a Commissioner of Police has been appointed under section 7];[(5A)
"eating house" means any place to which the public are admitted, and where any kind of food or
drink is supplied for consumption in the premises by any person owning or having an interest in or
managing such place, and includes a refreshment room, boarding-house, coffee-house or a shop
where any kind of food or drink is supplied to the public for consumption in or near such shop; but
does not include "place of public entertainment"];[(6) "Director General and Inspector General",
"Additional Director General and Inspector General", "Special Inspector General", "Commissioner",
"Joint Commissioner", "Additional Commissioner", "Deputy Inspector General", "Deputy
Commissioner", "Assistant Commissioner", "Superintendent", "Additional Superintendent"
"Assistant Superintendent" and "Deputy Superintendent" means respectively, the Director General
and Inspector General of Police, Additional Director General and Inspector General of Police,
Special Inspector General of Police, Commissioner of Police, Joint Commissioner of Police,
Additional Commissioner of Police, Deputy Inspector General of Police (including the Director of
Police Wireless and Deputy Inspector General of Police, Police Motor Transport appointed under
section 8A), Deputy Commissioner of Police, Assistant Commissioner of Police, Superintendent of
Police (including a Superintendent appointed under section 8A or 22A), Additional Superintendent
of Police, Assistant Superintendent of Police and Deputy Superintendent of Police, appointed or
deemed to be appointed under this Act.][(7) "municipality" means a municipality or municipal
borough established under any law for the time being in force in any part of the State, but does not
include a Municipal Corporation];[(7A) "Municipal Commissioner", in relation to the Municipal
Corporation of the City of Nagpur, means the Chief Executive Officer by whatever name
called;](8)"place" includes a building, a tent, a booth or other erection, whether permanent or
temporary, or any area whether enclosed or open.(9)"place of public amusement" means any place
where music, singing, dancing, or any diversion or game, or the means of carrying on the same, is
provided and to which the public are admitted either on payment of money or with the intentionBombay Police Act, 1951

that money may be collected from those admitted and includes a race course, circus, theatre, music
hall, billiard room, bagatelle room, gymnasium, fencing school, swimming pool or dancing hall;[(10)
"Place of public entertainment" means a lodging-house, boarding and lodging house or residential
hotel, and includes any eating house in which any kind of liquor or intoxicating drug is supplied
(such as a tavern, a wine shop, a beer shop or a spirit, arrack, toddy, ganja, bhang or opium shop) to
the public for consumption in or near such place;](11)"Police Officer" means any member of the
Police Force appointed or deemed to be appointed under this Act and includes a special or an
additional Police Officer appointed under section 21 or section 22;(12)"prescribed" means
prescribed by rules;(13)"public places" includes the foreshore, the precincts of every public building
or monument, and all places accessible to the public for drawing water, washing or bathing or for
the purpose of recreation;[(13A) "Revenue Commissioner" means the Commissioner of a Division
appointed under section 6A of the [Bombay Land Revenue Code, 1879;]](14)"rules" means rules
made under this Act;(15)"street" includes any highway, bridge, way over a causeway, viaduct, arch,
quay, or wharf or any road, lane, footway, square, court, alley or passage accessible to the public,
whether a thoroughfare or not;(16)"subordinate ranks" means members of the Police Force below
the rank of the Inspector;(17)"vehicle" means any carriage, cart, van dray, truck, hand cart or other
conveyance of any description and includes a bicycle, a tricycle, a rickshaw, an automatic car, a
vessel or an aeroplane.
Chapter II
Superintendence, Control and Organisation of the Police Force
3. One Police Force for the [whole of the [State of Maharashtra]]. - There shall
be one Police Force for the [whole of the [State of Maharashtra]] [and such
Police Force shall include every Police officer referred to in clause (6) of
section 2]:
Provided that, the members of the Police Forces constituted under any of the Acts mentioned in
Schedule I, immediately before the coming into force of this Act [in the relevant part of the State]
shall be deemed to be the members of the said Police Force.
4. Superintendence of Police Force to vest in the State Government. - The
superintendence of the Police Force throughout [the [State of Maharashtra]]
vests in and exercisable by the State Government and [subject to such
superintendence, the Secretary to the State Government in the Home
Department, whether designated as Secretary, Home Secretary, Special
Secretary, Additional Chief Secretary or otherwise, in charge of the Law and
Order Division of the Home Department shall exercise control, direction and
supervision over the Police Force].Bombay Police Act, 1951

5. Constitution of Police Force. - Subject to the provisions of this Act-
(a)the Police Force shall consist of such number in the several ranks and have such organization and
such powers, functions and duties as the State Government may by general or special order
determine;(b)the recruitment, pay, allowances and all other conditions of service of the Police Force
shall be such as may from time to time be determined by the State Government by general or special
order:Provided that-[(i) the rules and orders governing the recruitment, pay, allowances and other
conditions of service of the members of the Police Force constituted under any of the Acts
mentioned in Part I or II of Schedule I and deemed to be the members of the Police Force under
section 3, shall continue in force until altered or cancelled under clause (b); but in the case of
members of the Police Force constituted under any of the Acts mentioned in Part II of that Schedule
such alteration or cancellation shall be subject to the proviso to sub-section (7) of section 115 of the
States Reorganisation Act, 1956;](ii)nothing in this clause shall apply to the recruitment, pay,
allowances and other conditions of service of the members of the Indian Police and Indian Police
Service.
6. Inspector-General, Additional and Deputy Inspector-General. - (1) [Subject
to the provisions of section 4 for the direction and supervision] of the Police
Force, the State Government shall appoint a [Director-General and
Inspector-General of Police] who shall exercise such powers and perform
such functions and duties and shall have such responsibilities and such
authority as may be provided by or under this Act, or orders made by the
State Government.
[(2) (a) The State Government may appoint one or more Additional Director General and Inspector
General, one or more Special Inspector General and one or more Deputy Inspector General.(b)The
State Government may direct that any of the powers, functions, duties and responsibilities and the
authority of the Director-General and Inspector General may be exercised, performed or discharged,
as the case may be, by a Special Inspector General or an Additional Inspector General or a Deputy
Inspector General.(c)The State Government may also by a general or special order direct that an
Additional Director General and Inspector General or a Special Inspector General or a Deputy
Inspector General shall assist and aid the Director General and Inspector General in the
performance, exercise and discharge of his powers, functions, duties, responsibilities and authority
in such manner and to such extent as may be specified in the order.]
7. Commissioner. - (a) The State Government may appoint a Police Officer to
be the Commissioner of Police for Greater Bombay or any other area
specified in a notification issued by the State Government in this behalf and
published in the Official Gazette.
(b)The State Government [may also appoint one or more Additional Commissioners of Police [and
one or more Joint Commissioners] for any of the areas] specified in clause (a).(c)The CommissionerBombay Police Act, 1951

shall exercise such powers, perform such functions and duties and shall have such responsibilities
and authority as are provided by or under this Act or as may otherwise be directed by the State
Government by a general or special order:Provided that the State Government may direct that any
of the powers, functions, duties, responsibilities or authority exercisable or to be performed or
discharged by the Commissioner shall be exercised, performed or discharged subject to the control
of the [Director General and Inspector General]:Provided further that the area for which a
Commissioner has been appointed under this section shall not, unless otherwise provided by or
under this Act, be under the charge of the District Magistrate or the [Superintendent] for any of the
purpose of this Act, notwithstanding the fact that such area forms part of a district within the
territorial jurisdiction for which a District Magistrate or, a [Superintendent] may have been
appointed.
8. Appointment of [Superintendent and] Additional, Assistant and Deputy
Superintendents. - (1) The State Government may appoint for each District or
for a part of a District or for one more district [a Superintendent of Police]
and one or more Additional, Assistant and Deputy Superintendents of Police,
as it may think expedient.
(2)The State Government may, by a general or special order, empower an Additional
Superintendent to exercise and perform in the district for which he is appointed or in any part
thereof, all or any of the powers, functions or duties to be exercised or performed by a
[Superintendent] under this Act or under any law for the time being in force.(3)The
[Superintendent] may, with the previous permission of the State Government delegate any of the
powers and functions conferred on him by or under this Act to an Assistant or Deputy
Superintendent:[Provided that, the powers to be exercised by the Superintendent of making,
altering or rescinding any rules under section 33 shall not be delegated to an Assistant or Deputy
Superintendent].[8A. [Appointment of Director of Police Wireless and of Superintendent], Assistant
and Deputy Superintendents for Wireless System, Motor Transport System or any specific duty. - (1)
The State Government may appoint for the whole of the State or for any part thereof-[(i) one or
more Directors of Police Wireless and [a Special Inspector General] of Police for the Police Wireless
System (hereinafter referred to as "the Director of Police Wireless") as it thinks fit, and(ii)one or
more Superintendents of Police, and Assistant and Deputy Superintendents of Police as it thinks
fit-],(a)for the Police Wireless System;(b)for the Police Motor Transport System; or(c)for the
performance of such specific duties as the State Government may from time to time determine in
this behalf.(2)[Any Director of Police Wireless and Superintendent] so appointed shall exercise such
power and perform such functions as the State Government may from time to time [assign to each of
them]. [The Director may, with the previous permission of the State Government, delegate any of
the powers and functions conferred on him by or under this Act to a Superintendent, or to an
Assistant or Deputy Superintendent, and the Superintendent may, subject to the like previous
permission, delegate such powers and functions to an Assistant or Deputy
Superintendent]:Provided that, the powers and functions aforesaid shall be exercised or performed
by [the Director, Superintendent] or Assistant or Deputy Superintendent, subject to the control of
the [Director General and Inspector General].][9. Appointment of Principals of Police TrainingBombay Police Act, 1951

Institutions. - (1) The State Government may appoint any Police Officer not below the rank of
Superintendent to be the Principal of the Police Training College, Nashik, or any other Police
Training College established by it. The State Government may assign to each of the Principals
aforesaid such powers, functions and duties as it may think fit.(2)The State Government may
appoint any Police Officer not below the rank of an Assistant or Deputy Superintendent to be the
Principal of any Police Training School established by it. An officer (not below the rank of a Deputy
[Inspector-General]) authorised by the State Government in that behalf may, subject to the control
of the State Government, assign to each Principal so appointed such powers, functions and duties as
he may think fit].
10. Deputies [* *] to Commissioner. - (1) The State Government may appoint
one or more Deputy Commissioners [* * * *] of Police in Greater Bombay or in
any area in which a Commissioner has been appointed under clause (a) of
section 7.
(2)Every such Deputy [* *] Commissioner shall, under the orders of the Commissioner, exercise and
perform any of the powers, functions and duties of the Commissioner to be exercised or performed
by him under the provisions of this Act or any other law for the time being in force [* * *] :Provided
that the powers to be exercised by the Commissioner [of making, altering or rescinding rules under
section 33] shall not be exercisable by a Deputy [* * *] Commissioner.
11. [ [Assistant Commissioners] within jurisdiction of Commissioners]. - (1)
The State Government may appoint [for any area for which a Commissioner
of Police has been appointed under section 7] such number of [Assistant
Commissioners of Police] as it may think expedient.
(2)[An Assistant Commissioner] appointed under sub-section (1) shall exercise such powers and
perform such duties and functions as can be exercised or performed under the provisions of this Act
or any other law for the time being in force or as are assigned to him by the Commissioner under the
general or special orders of the State Government:Provided that the powers to be exercised by the
Commissioner [of making, altering or rescinding rules under section 33] shall not be exercisable by
[the Assistant Commissioner].
12. Constitution of Divisions and Sections. - (1) Subject to the control of the
State Government the Commissioner [for any area] shall, if he thinks fit-
(a)constitute [within the area under his charge], Police divisions.(b)sub-divide the same into
sections, and(c)define the limits and extent of such divisions and sections.(2)Officers in charge of
Divisions and sections, each such division shall be in charge of [an Assistant Commissioner] and
each section shall be in charge of an Inspector of Police.[12A. Inspectors. - Subject to the general or
special orders of the State Government the Commissioner for the area for which he is appointed and
the [Director-General and Inspector-General] for other areas shall appoint Inspectors.]Bombay Police Act, 1951

13. [Inspector-General and Commissioner to exercise the powers of First
Class Magistrate and Presidency Magistrate]. - Deleted by Bombay XXI of
1954, Second Schedule
14. Certificate of appointment. - (1) Every Police Officer [ [of the grade of
Inspector or below] ], shall on appointment receive a certificate in form
provided in Schedule II. The certificate shall be issued under the seal of such
officer as the State Government may by general or special order direct.
(2)A certificate of appointment shall become null and void whenever the person named therein
ceases to belong to the Police Force or shall remain inoperative during the period within which such
person is suspended from such force.
15. Effect of suspension of Police Officer. - The powers, functions and
privileges vested in a police shall remain suspended whilst such Police
Officer is under suspension from office:
Provided that notwithstanding such suspension such person shall not cease to be a Police officer and
shall continue to be subject to the control of the same authorities to which he would have been if he
was not under suspension.
16. General powers of Commissioner and [Superintendent]. - The
Commissioner subject to the orders, of the [Director-General and
Inspector-General], and the [Superintendent], subject to the orders of the
[Director-General and Inspector-General] and the District Magistrate, shall,
within their respective spheres of authority direct and regulate all matters of
arms, drill, exercise, observation of persons and events, mutual relations,
distribution of duties, study of laws, orders and modes of proceedings and
all matters of executive detail or the fulfilment of their duties by the Police
Force under him.
17. Control of District Magistrate over Police Force in district. - (1) The
[Superintendent] and the Police Force of a district shall be under the control
of the District Magistrate.
(2)In exercising such control the District Magistrate shall be governed by such rules and orders as
the State Government may make in this behalf [and shall be subject to the lawful orders of the
Revenue Commissioner].Bombay Police Act, 1951

18. Power of District Magistrate to require reports from [Superintendent]. -
The District Magistrate may require from the [Superintendent] reports, either
particular or general, on any matter connected with the crimes, habitual
offenders, the prevention of disorder, the regulation of assemblies and
amusements, the distribution of the Police Force, the conduct and character
of any Police Officer subordinate to the [Superintendent], the utilization of
auxiliary means and all other matters in furtherance of his control of the
Police Force and the maintenance of order.
19. Power of supervision by District Magistrates. - If the District Magistrate
observes any marked incompetence or unfitness for the locality or for his
particular duties, in any Police officer subordinate to the [Superintendent] he
may require the [Superintendent] to substitute another officer for any officer
whom he has power to transfer and the [Superintendent] shall be bound to
comply with the requisition:
Provided that if the Police Officer concerned is an officer [of a grade higher than that of an
Inspector] the District Magistrate may report his conduct to the [Director-General and
Inspector-General]. The [Director-General and Inspector-General] may, thereafter, determine the
action to be taken and pass such orders as he thinks fit, and shall communicate such action or
orders to the District Magistrate.
20. Power of [Director-General and Inspector-General] and Commissioner to
investigate and regulate matters of Police accounts. - The [Director-General
and Inspector-General] throughout the [State] and the Commissioner in the
area for which he is appointed, shall, subject to the orders of the State
Government, have authority to investigate and regulate all matters of account
connected with the Police in the [State] or in the area, as the case may be,
and all persons concerned shall be bound to give him reasonable aid and
facilities in conducting such investigations and to conform to his orders
consequent thereto.
21. Special Police Officers. - (1) The Commissioner, the [Superintendent], or
any Magistrate, [* * * *] specially empowered in this behalf by the State
Government, may, at any time by a written order signed by himself and
sealed, with his own seal appoint any able-bodied male person between the
ages of 18 and 50, whom he considers fit to be a Special Police Officer to
assist the Police Force on any occasion, when he has reason to apprehendBombay Police Act, 1951

the occurrence of any riot or grave disturbance of the peace within the limits
of his charge and he is of opinion that the ordinary Police Force is not
sufficient for the protection of the inhabitants and for the security of
property.
(2)Every special Police Officer so appointed shall on appointment-(a)receive a certificate in a form
approved by the State Government in this behalf,(b)have the same powers, privileges and
immunities and be liable to the same duties and responsibilities and be subject to the same
authorities as an ordinary Police Officer.
22. Appointment of Additional Police Officers. - (1) Additional Police Officers
of such rank or grade for such time and on such pay as the authority
specified by or under the provisions of this Act in that behalf may determine,
may be employed or deputed for the purpose stated in such provisions.
(2)Every additional Police Officer appointed, shall on appointment-(a)receive a certificate in a form
approved by the State Government in this behalf, "(b)be vested with all or such of the powers,
privileges and duties of a Police Officer as are specially mentioned in the certificate, and(c)be subject
to the orders of the Commissioner or the [Superintendent] as the case may be.(3)The employment
or deputation of such Additional Police Officer may be made at the request of any person requiring
such Police and the cost of such employment shall be recovered in such manner as is provided by or
under this Act or under any other law for the time being in force.[22A. Appointment of Railway
Police. - (1) The State Government may by notification in the Official Gazette create one or more
special police districts embracing such railway areas in the State as it may specify, and appoint a
Superintendent of Police [one or more Assistants and Deputy Superintendents] and such other
Police Officers for each such special district as it may think fit.(2)Subject to the control of the
[Director-General and Inspector-General], such Police Officers shall discharge police functions
connected with the administration of railways situate within their respective charges, and such other
functions as the State Government may, from time to time, assign to them.(3)Any member of the
said Police Force whom the State Government shall generally or specially empower to act under this
sub-section may, subject to any orders which that Government may make in this behalf, exercise
within the special district or any part thereof any of the powers of an officer incharge of a police
station in that district, and when so exercising such powers shall, subject to any such order as
aforesaid, be deemed to be an officer incharge of the police station discharging the functions of such
officer within the limits of his station.(4)Subject to any general or special orders which the State
Government may make in this behalf, such police officers shall, in the discharge of their functions,
be vested within every part of the State with the powers and privileges and be subject to the
liabilities of police officers under this Act or any other law for the time being in force.][(5) The
Superintendent of Police may, with the previous permission of the State Government, delegate any
of the powers and functions conferred on him by or under this Act to an Assistant or Deputy
Superintendent.].Bombay Police Act, 1951

Chapter III
Regulation, Control and Discipline of the Police Force
23. Framing of rules for administration of the Police. - Subject to the orders
of the State Government, the Commissioner in the case of the Police Force
allocated to Greater Bombay and other areas for which he has been
appointed and the [Director-General and Inspector-General] in the case of the
Police Force allocated to other areas may make rules or orders not
inconsistent with this Act or with any other enactment for the time being in
force-
(a)regulating the inspection of the Police Force by his subordinates;(b)determining the description
and quantity of arms, accoutrement's, clothing and other necessaries to be furnished to the
Police;(c)prescribing the places of residence of members of the Police Force;(d)for institution,
management and regulation of any Police Fund for any purpose connected with police
administration;(e)regulating, subject to the provisions of section 17, the distribution, movements
and location of the Police;(f)assigning duties to Police Officers of all ranks and grades, and
prescribing -(i)the manner in which, and(ii)the conditions subject to which, they shall exercise and
perform their respective powers and duties;(g)regulating the collection and communication by the
Police of intelligence and information;(h)generally, for the purpose of rendering the Police efficient
and preventing abuse or neglect of their duties.
24. [Director-General and Inspector-General] or Commissioner may call for
returns. - (1) The [Director-General and Inspector-General] may, subject to
the rules and orders of the State Government, call for such returns, reports
and statements on subjects connected with the suppression of crime, the
maintenance of order and the performance of their duties as his
subordinates may be able to furnish to him. The [Director-General and
Inspector-General] shall communicate to the District Magistrate [and the
Revenue Commissioner] any general orders issued by him for the purposes
aforesaid or in consequence of the information furnished to him, and also
any orders which the State Government may direct.
(2)The Commissioner may subject as aforesaid with reference to the area under his charge call for
such reports, returns and statements as are provided for in sub-section (1).Bombay Police Act, 1951

25. Punishment of the members of the subordinate ranks of the Police Force
departmentally for neglect of duty, etc. - [(1) The State Government or any
officer authorised under sub-section (2), in that behalf, may impose upon an
Inspector or any member of the subordinate ranks of the Police Force, who in
the opinion of the State Government or such authorised officer, is cruel,
perverse, remiss or negligent in, or unfit for, the discharge of his duties, any
one or more of the following penalties, namely
(a)recovery from pay of the whole or part of any pecuniary loss caused to Government on account of
the negligence or breach of orders on the part of such Inspector or any member of the subordinate
rank of the Police Force;(b)suspension;(c)reduction in rank, grade or pay, or removal from any
office of distinction or withdrawal of any special emoluments;(d)compulsory retirement;(e)removal
from service which does not disqualify for future employment in any department other than the
Police Department;(f)dismissal which disqualifies for future employment in Government
service:Provided that, suspension of a police officer pending an inquiry into his conduct or
investigation of a complaint against him of any criminal offence shall not be deemed to be a
punishment under clause (b).(1A)The State Government or any officer authorised under sub-section
(2) in that behalf, may impose upon an Inspector or any member of the subordinate ranks of the
Police Force, who is guilty of any breach of discipline or misconduct or of any act rendering him
unfit for the discharge of his duty which, in the opinion of the State Government or of such
authorised officer, is not of such nature as to call for imposition of any of the punishments referred
to in sub-section (1), any one or more of the following punishments, namely(a)warning;(b)a
reprimand (to be entered in his service book);(c)extra drill;(d)fine not exceeding one month's
pay;(e)stoppage of increments :Provided that, the punishment specified, -(i)in clause (c), shall not
be imposed upon any personnel above the rank of Constable;(ii)in clause (d), shall not be imposed
upon an Inspector.]Punitive powers of [Director-General and Inspector-General], Commissioner,
Deputy Inspector-General [(including Director of Police Wireless)] and [Superintendent] [and
Principal of Training Institution][(2) (a) The Director General and Inspector General including
Additional Director General, Special Inspector General, Commissioner including Joint
Commissioner, Additional Commissioner and Deputy Inspector-General shall have authority to
punish an Inspector or any member of the subordinate rank under sub-section (1) or (1A). A
Superintendent shall have the like authority in respect of any police officer subordinate to him
below the grade of Inspector and shall have powers to suspend an Inspector who is subordinate to
him pending enquiry into a complaint against such Inspector and until an order of the
Director-General and Inspector-General or Additional Director-General and Inspector-General and
including the Director of Police Wireless and Deputy Inspector-General of Police can be
obtained.](b)The Principal of [a Police Training College] shall also have the like authority in respect
of any member of the subordinate ranks of the Police Force below the grade of Inspector
[undergoing training at [such [College] or] serving under him], and in respect of head constables
and constables belonging to the Police Force of [the District in which such [College] is situated] or of
any other district attached to [such [College] for duty under him]. [He may also suspend an
Inspector who is [undergoing training at [such [College] or] subordinate to him pending inquiry
inters complaint against such Inspector] and until an order of the [Director-General andBombay Police Act, 1951

Inspector-General] or Deputy [Director-General and Inspector-General] can be obtained.][(ba) The
Principal of a Police Training School shall have the like authority in respect of any member of the
subordinate ranks of the Police Force below the grade of an Inspector, undergoing training at such
school or serving under him, or attached to such school for duty under him.][(bb) ******](c)The
exercise of any power conferred by this sub-section shall be subject always to such rules and orders
as may be made by the State Government in that behalf.(3)Nothing in [sub-sections (1), (1A)] and
(2)-(a)shall affect any Police Officer's liability to a criminal prosecution for any offence with which
he may be charged; or(b)shall entitle any authority subordinate to that by which the Police Officer
was appointed, to dismiss or remove him.[26. Procedure to be observed in awarding punishment. -
Except in cases referred to in the second proviso to clause (2) of article 311 of the Constitution of
India, no order of punishment under sub-section (1) of section 25 shall be passed unless the
prescribed procedure is followed.]
27. Appeals from orders of punishment. - An appeal against any order
passed against a Police Officer under section 25 or the rules or orders
thereunder shall lie to the State Government itself or to such officer as the
State Government may by general or special order specify:
[Provided that, a punishment shall not be enhanced or more severe punishment shall not be
awarded in appeal, unless notice to show cause against such enhancement or, as the case may be,
more severe punishment, has been given, and any cause shown thereon has been considered.][27A.
Power of State Government or Director-General and Inspector-General to call for record of any
inquiry or proceeding. - The State Government or the Director-General and the Inspector-General
may, suo motu or on an application made to it or him, as the case may be, within the period
prescribed in this behalf, call for and examine the record of any inquiry or proceedings held against
any Police Officer under this Chapter by any authority for the purpose of satisfying itself or himself
as to the legality or propriety of any decision taken or order passed in any such inquiry and as to the
regularity of the proceedings held, against such officer, and may, at any time -(a)confirm, modify or
reverse any such order;(b)impose any punishment or set aside, reduce, confirm or enhance the
punishment imposed by such order;(c)direct that further inquiry be held; or(d)make such other
order as, in the circumstances of the case it or he, as the case may be, may deem fit:Provided that, an
order in revision imposing or enhancing the punishment, shall not be passed unless the Police
Officer affected thereby has been given a reasonable opportunity of making a representation which
he may wish to make against such punishment:Provided further that, no order in revision shall be
passed,-(i)in a case where, an appeal against the decision or order passed in such inquiry or
proceeding has been filed and such appeal is pending;(ii)in a case where, an appeal against such
decision or order has not been filed, before the expiry of the period provided for filing of such
appeal; and(iii)in any other case, after the expiry of a period of three years from the date of the
decision or order sought to be revised.Bombay Police Act, 1951

27B. Power of State Government or Director General and Inspector General
to review order passed under Sections 25, 27 or 27A. - The State Government
or the Director-General and Inspector-General of Police may, at any time,
either suo motu or otherwise, review any order passed by it or him, as the
case may be under sections 25, 27 or 27A, when any new material or
evidence which could not be produced or was not available at the time of
passing the order under review and which has the effect of changing the
nature of the case, has come or has been brought, to its or his notice:
Provided that, no order imposing or enhancing any penalty shall be made by the State Government
or Director-General and Inspector-General unless the Police Officer concerned has been given a
reasonable opportunity of making a representation against the penalty proposed, or where it is
proposed to impose any of the major penalties specified in sub-section (1) of section 25 or to
enhance the minor penalty imposed by the order sought to be reviewed, to any of the major
penalties :Provided also that, if any inquiry under the prescribed rules has not already been held in
the case, no such penalty shall be imposed except after holding an inquiry in the manner prescribed
by rules.
27C. Power to make rules. - Without prejudice to the power to issue an order
contained in clause (b) of section 5, the State Government may frame rules
consistent with this Act for carrying out the purposes of sections 27, 27A and
27B.]
28. Police Officers to be deemed to be always on duty and to be liable to
employment in any part of the State. - (1) Every Police Officer not on leave or
under suspension shall for all purposes of this Act be deemed to be always
on duty, and any Police Officer or any number or body of Police Officers
allocated for duty in one part of the State may, if the State Government or the
[Director-General and Inspector-General] so directs, at any time, be
employed on Police duty in any other part of the State for so long as the
services of the same may be required there.
Intimation of proposed transfers to be given by the [Director-General and Inspector-General] to the
Commissioner and District Magistrate.(2)Timely intimation shall, except in cases of extreme
urgency, be given to the [Revenue Commissioner] and the District Magistrate, by the
[Director-General and Inspector-General] of any proposed transfer under this section, and except
where secrecy sis necessary, the reasons for the transfer shall be explained; whereupon the officers
aforesaid and their subordinates shall give all reasonable furtherance to such transfer.Bombay Police Act, 1951

29. Under what conditions Police Officer may resign. - [(1) No Police Officer
[of the grade of Inspector or] of the subordinate ranks shall resign his office
or withdraw himself from the duties thereof except, with the written
permission of the Commissioner or the Deputy [Director-General and
Inspector-General] Criminal Investigation Department or of the Principal of [a
Police [Training College] ], or of the [Superintendent] or of some other Police
Officer empowered by the [Director-General and Inspector-General] or the
Commissioner to grant such permission:
Provided that subject to the provisions of sub-section (2), no such permission shall be granted to
any such Police Officer until he has fully discharged any debt due by him as such Police Officer to
Government or to any Police fund.](2)If any such Police Officer produces a certificate signed by the
Police Surgeon or the Civil Surgeon declaring him to be unfit by reason of diseases or mental or
physical incapacity for further service in the Police, the necessary written permission to resign shall
forthwith be granted to him on his discharging or giving satisfactory security for the payment of any
debt due by him as such Police Officer to Government or to any Police fund.Arrears of pay of a
Police Officer contravening this section may be forfeited(3)If any such Police Officer as aforesaid
resigns or withdraws himself from the duties of his office in contravention of this section, he shall be
liable on the order of the Commissioner, or the Deputy [Director-General and Inspector-General]
Criminal Investigation Department, or of the Principal of [the Police [Training College], or of the
[Superintendent], as the case may be, to forfeit all arrears of pay then due to him. This forfeiture
shall be in addition to the penalty to which the said Officer is liable under section 145 of this Act or
any other law in force.
30. Certificate, arms, etc. to be delivered up by person ceasing to be a Police
Officer and if not delivered up may be seized under a search warrant. - (1)
Every person who for any reason ceases to be a Police Officer shall forthwith
deliver up to some officer empowered by the Commissioner or the Deputy
[Director-General and Inspector-General], Criminal Investigation Department,
or the Principal of [the Police [Training College or School] ] or the
[Superintendent] to whom such Police Officer is subordinate to receive the
same, his certificate of appointment or of office and the arms,
accoutrements, clothing and other necessaries which have been furnished to
him for the performance of duties and functions connected with his office.
(2)Any Magistrate and, for special reasons which shall be recorded in writing at the time, the
Commissioner or the Deputy [Director-General and Inspector-General], Criminal Investigation
Department, or the Principal of [the Police [Training College or School] ] or any [Superintendent],
Assistant Superintendent, or Deputy Superintendent may issue a warrant to search for and seize,
wherever they be found, any certificate, arms, accoutrements, clothing or other necessaries not so
delivered up. Every warrant so issued shall be executed in accordance with the provisions of theBombay Police Act, 1951

[Code of Criminal Procedure, 1898] by a Police Officer or, if the Magistrate, the Commissioner, the
Deputy [Director-General and Inspector-General] Criminal Investigation Department, the Principal
of [the Police [Training College or School] ], the [Superintendent], the Assistant Superintendent" or
the Deputy Superintendent issuing the warrant so directs, by any other person.Saving of certain
articles(3)Nothing in this section shall be deemed to apply to any article which, under the Orders of
the [Director-General and Inspector-General] or the Commissioner, as the case may be, has
"become the property of the person to whom the same was furnished.
31. Occupation of and liability to vacate premises provided for Police
Officers. - (1) Any Police Officer occupying any premises provided by the
State Government for his residence-
(a)shall occupy the same subject to such conditions and terms as may generally or in special cases,
be specified by the State Government; and(b)shall, notwithstanding anything contained in any law
for the time being in force, vacate the same on his ceasing to be a Police Officer or whenever the
State Government or any officer authorised by the State Government in this behalf think it
necessary and expedient to require him to do so.(2)If any person who is bound or required under
sub-section (1) to vacate any premises fails to do so, the State Government or the officer authorised
in this behalf by the State Government may order such person to vacate the premises and may direct
any Police Officer with such assistance as may be necessary to enter upon the premises and remove
therefrom any person found therein and to take possession of the premises and deliver the same to
any person specified in the direction.[32. State Government may make order under section 144 of
Act V of 1898. - The State Government, whenever it shall seem necessary, may by notification in the
Official Gazette make in order to such effect as any order if made by a Magistrate under section 144
of the [Code of Criminal Procedure, 1898] could be continued in force by the State Government
under the said Code].
Chapter IV
Police Regulations[ [33. Power to make rules for regulations of traffic and for preservation of order
in public place, etc.] ] - (1) [The Commissioner with respect to any of the matters specified in this
sub-section, the District Magistrate] with respect to any of the said matters (except those falling
under [clauses (a), (b), (d), (db), (e) (g), (r), (t) and (u) thereof), and the Superintendent of Police
with respect to the matters falling under the clauses aforementioned read with clause (y) of this
sub-section,] in areas under their respective charges or any part thereof, may make, alter or rescind
rules or orders not inconsistent with this Act for-(a)licensing and controlling persons offering
themselves for employment at quays, wharves and landing places, and outside Railway stations, for
the carriage of passengers' baggages, and fixing and providing for the enforcement of a scale of
charges for the labour of such persons so employed;(b)regulating traffic of all kinds in streets and
public places, and the use of streets and public places by persons riding, driving, cycling, walking or
leading or accompanying cattle, so as to prevent danger, obstruction or inconvenience to the
public;(c)regulating the conditions under which vehicles may remain standing in streets and public
places, and the use of streets as halting places for vehicles or cattle;(d)prescribing the number andBombay Police Act, 1951

position of lights to be used on vehicles in streets and the hours between which such lights shall be
used;[(da) licensing, controlling or prohibiting the display of any pictures, advertisements, news
boards or public notices upon a vessel or boat in territorial waters or on inland waterways other
than national waterways;][(db) licensing, controlling or prohibiting the erection, exhibition, fixation
or retention of any sign, device or representation for the purpose of advertisement, which is visible
against the sky from some point in any street and is hoisted or held a loft over any land, building or
structure at such heights as (regard being had to the traffic in the vicinity, and the likelihood of such
sign, device or representation at that height being a distraction or causing obstruction to such
traffic) may be specified in the rule or order;](e)prescribing certain hours of the day during which
cattle shall not be driven along the streets, or along certain specified streets except subject to such
regulations as may be prescribe in that behalf;(f)regulating the leading, driving, conducting or
conveying of any elephant or wild or dangerous animal through or in any street;(g)regulating and
controlling the manner and mode of conveying timber, scaffold poles, ladders, iron girders, beams
or bars, boilers or other unwieldy articles through the streets, and the route and hours for such
conveyance;(h)licensing, controlling or, in order to prevent the obstruction, inconvenience,
annoyance, risk danger, or damage of the residents or passengers in the vicinity, prohibiting the
carrying in streets and public places of gunpowder or any other explosive substance;(i)prohibiting,
except along certain specified streets and during specified hours and subject to such regulations as
he may prescribe in that behalf, the exposure or movement in any street of persons if animals
suffering from contagious or infectious diseases and the carcasses of animals or part thereof and the
corpses of persons deceased;(j)prescribing certain hours of the day during which ordure or offensive
matter or objects shall not be taken from or into house or buildings in certain streets or conveyed
through such streets except subject to such rules as he may make in that behalf;(k)setting apart
places for the slaughtering of animals, the cleaning of carcasses or hides, the deposit of noxious or
offensive matter and for obeying calls of nature;(l)in cases of existing or apprehended epidemic or
infectious disease of men or animals, the cleanliness and disinfection of premises by the occupier
thereof and residents therein and the segregation and management of the persons or animals
diseased or supposed to be diseased, as may have been directed or approved by the State
Government with a view to prevent the disease or to check the spreading thereof;(m)directing the
closing or disuse, wholly or for certain purposes, or limiting to certain purposes only the use of any
source, supply or receptacle of water and providing against pollution of the; same or of the water
therein;(n)licensing, controlling or, in order to prevent the obstruction, inconvenience, annoyance,
risk, clanger or damage of the residents or passengers in the vicinity, prohibiting the playing of
music, the beating of drums, tom-toms or other instruments and the blowing or sounding of horns
or other noisy instruments in or near streets or public place;(o)regulating the conduct of and
behaviour or action of persons constituting assemblies and processions on or along the street and
prescribing in the case of processions the routes by which the order in which and times at which the
same may pass;(p)prohibiting the hanging or placing of any cord or pole across a street or part
thereof, or the making of a projection or structure so as to obstruct traffic or the free access of light
and air;(q)prohibiting, except under such reasonable rules as he may make, the placing of building
materials or other articles or the fastening or detention of any horse or other animals in any street or
public place;(r)licensing, controlling, or, in order to prevent obstruction, inconvenience, annoyance,
risk, danger or damage of the residents or passengers in the vicinity prohibiting-(i)the illumination
of streets and public places and the exteriors of building abutting thereon by persons other thanBombay Police Act, 1951

servants of Government or Municipal Officers duly authorized in that behalf;(ii)the blasting of rock
or making excavations in or near streets or public places;(iii)the using of a loudspeaker in [or near
any public place or in any] place of public entertainment;(s)closing certain streets or places
temporarily, in cases of danger from ruinous buildings or other cause, with such exceptions as shall
appear reasonable;(t)guarding against injury to person and property in the construction, repair and
demolition of buildings, platforms and other structures from which danger may arise to passengers,
neighbours or the public;(u)prohibiting the setting fire to or burning any straw or other matter, or
lighting a bonfire or wantonly discharging a fire-arm or air-gun, or letting off or throwing a firework
or, sending up a fire balloon or rocket in or upon or within fifty feet of a street or building or the
putting up of any post or other thing on the side of or across a street for the purpose of affixing
thereto lamps or other contrivances for illumination, except subject to such reasonable rules, as he
may make in that behalf;(v)regulating the hours during which and the manner in which any place
for the disposal of dead, any dharmashala, village-gate or other place of public resort may be used,
so as to secure the equal and appropriate application of its advantages and accommodation and to
maintain orderly conduct amongst those who resort thereto;(w)(i)licensing or controlling places of
public amusement or entertainment;(ii)prohibiting the keeping of places of public amusement or
entertainment or assembly, in order to prevent obstruction, inconvenience, annoyance, risk, danger
or damage to the residents or passengers in the vicinity;(iii)regulating the means of entrance and
exist at places of public amusement or entertainment or assembly, and providing for the
maintenance of public safety and the prevention of disturbance thereat;[(wa) (i) licensing or
controlling [in the interest of public order, decency or morality or in the interest of the general
public], with such exceptions as may be specified, the musical, dancing, mimetic or the article or
other performances for the public amusement, including melas and tamashas.(ii)regulating in the
interest of public order, decency or morality or in the interest of the general public, the employment
of artistes and the conduct of the artistes and the audience at such performances;(iii)prior scrutiny
of such performances [and of the scripts in respect thereof if any, and granting of suitability
certificate therefor subject to conditions if any] [by a Board appointed by the State Government for
the purpose, either for the whole State or for the area concerned,] [the members of the Board being
persons who in the opinion of the State Government possess knowledge of, or experience in,
literature, the theatre and other matters relevant to such scrutiny] or by an Advisory Committee
appointed by the Commissioner, or the District Magistrate in this behalf; [provision for appeal
against the order or decision of the Board to the prescribed authority, its appointment or
constitution, its procedure and other matter ancillary thereto, and the fees (whether in the form of
court-fee stamp or otherwise) to be charged for the scrutiny of such performances or scripts for
applications for obtaining such certificates and for issuing duplicates thereof and in respect of such
appeals;](iv)regulating the hours during which and the places at which such performances may be
given;][(wb) licensing or controlling (with such exceptions as may be specified) in the interest of
public order, decency or morality or in the interest of the general public places used as dancing
schools;](x)regulating or prohibiting the sale of any ticket or pass for admission, by whatever name
called, to a place of public amusement;[(xa) registration of eating houses, including granting a
certificate of registration in each case which shall be deemed to be a written permission required
and obtained under this Act for keeping the eating house, and annual renewal of such registration
within a prescribed period;](y)prescribing the procedure in accordance with which any licence or
permission sought to be obtained or required under this Act should be applied for and fixing the feesBombay Police Act, 1951

to be charged for any such licence or permission:Provided that nothing in this section and no licence
[or certificate of registration] granted under any rule, made thereunder shall authorise any person to
import export, transport, manufacture, sell or possess any liquor, or intoxicating drug, in respect of
which a licence, permit, pass or authorisation is required under the Bombay Prohibition Act,
1949.[or [* * * * * *] the Abkari Act, the Hyderabad Intoxicating Drugs Act, the Central Province and
Berar Excise Act, 1915, or the Central Provinces and Berer Prohibition Act, 1938] or under any other
law for the time being in force [relating to the Abkari, revenue or to the Prohibition of the
manufacture, sale and consumption of liquor] or shall affect the liability of any person under any
such law or shall in any way affect the provisions of the [Arms Act, 1878], or of the Explosives Act,
1884, or of rules made under either of those enactments or the liability of any person
thereunder:Provided further that any action taken under the rules or orders made under this
sub-section or the grant of a licence [or certificate or registration] made under such rules or orders
shall be subject to the control and supervision of the State Government.[Provided also that, against
any order granting or refusing to grant or renew or revoking any licence for [the using of a
loudspeaker in or near any public place or in any place of public entertainment or for any places of
public amusement or entertainment] [or used as a dancing school] [or refusing to grant or renew or
revoking any certificate of registration for any eating house,] an appeal shall lie to the State
Government itself, or to such officer as the State Government may by general or special order
specify, within thirty days from the date of receipt of such order by the aggrieved person].[(1A) The
power to make rules or orders under clauses (w), (wa) and (x) [of sub-section (1)] shall in the first
instance have effect only in relation to [the Bombay area of the State of Maharashtra]; but the State
Government may by notification in the Official Gazette provide that such power under any or all of
those clauses, shall also have effect from such date as may be specified in the notification, in any
other area of the State.][(1B) The power to make rules, orders or appointments under clauses (w)
and (wa) [(x) and (xa)] and in so far as it relates to a licence or permission under any of those
clauses, under clause (y) of sub-section (1), may, subject to the provision of sub-section (M), also be
exercised by a Revenue Commissioner in the revenue division under his charge.](2)(i)The power of
making, altering or rescinding rules under [clauses (a) and (c)] of sub-section (1) shall be subject to
the control of the State Government.(ii)The power of making, altering or rescinding rules under the
remaining clauses of sub-section (1) shall be subject to the previous sanction of that
Government.(3)Every rule made under clause (v) of sub-section (1) with respect to the use of a place
for the disposal of the dead shall be framed with due regard to ordinary and established usages and
to the necessities of prompt disposal of the dead individual cases.(4)Every rule promulgated under
the authority of clause (1) of sub-section (1) shall if made in relation to [any area which is not under
the charge of a Commissioner], be forthwith [reported to the Revenue Commissioner and the State
Government].(5)If any rule or order made or promulgated under this section relates to any matter
with respect to which there is a provision in any law, rule or bye law of any municipal or local
authority in relation to the public health, convenience or safety of the locality such rule or order
shall be subject to such law, rule or bye law of the municipal or local authority, as the case may
be.(6)The power of making, altering or rescinding rules under this section shall be subject to the
condition of the rules being made, altered or rescinded after previous publication and every rule
made or alteration or rescission of a rule made under this section shall be published in the Official
Gazette, and in the locality affected thereby affixing copies thereof in conspicuous places near to the
building, structure work or place, as the case may be, to which the same specially relates or byBombay Police Act, 1951

proclaiming the same by the beating of drum or by advertising the same in such local newspapers in
English or in the local language, as the authority making, altering or rescinding the rule may deem
fit or by any two or more of these means or by any other means it may think suitable:Provided that
any such rules may be made, altered or rescinded without previous publication of [the Revenue
Commissioner, the Commissioner], [the District Magistrate or the Superintendent,] as the case may
be, is satisfied that circumstances exist which render it necessary that such rules or alterations
therein or rescission thereof should be brought into force at once.(7)Notwithstanding anything
hereinbefore contained in this section or which may be contained in any rule made thereunder, it
shall always be lawful for the competent authority to refuse a licence for, or to prohibit the keeping
of any place of public amusement or entertainment [or any place used for conducting a dancing
school] [or to refuse a certificate of registration for, or to prohibit the keeping of any eating house, as
the case may be,] by a person of notoriously bad character.(8)It shall be the duty of all persons
concerned to conform to any order duly made as aforesaid so long as the same shall be in
operation.[33A. Prohibition of performance of dance in eating house, permit room or beer bar and
other consequential provisions. - (1) Notwithstanding anything contained in this Act or the rules
made by the Commissioner of Police or the District Magistrate under sub-section (1) of section 33
for the area under their respective charges, on and from the date of commencement of the Bombay
Police (Amendment) Act, 2005,-(a)holding of a performance of dance, of any kind or type, in an
eating house, permit room or beer bar is prohibited;(b)all performance licences, issued under the
aforesaid rules by the Commissioner of Police or the District Magistrate or any other officer, as the
case may be, being the Licensing Authority, to hold a dance performance, of any kind or type, in an
eating house, permit room or beer bar shall stand cancelled.(2)Notwithstanding anything contained
in section 131, any person who holds or causes or permits to be held a dance performance of any
kind or type, in an eating house, permit room or beer bar in contravention of sub-section (1), shall
on conviction, be punished with imprisonment for a term which may extend to three years or with
fine which may extend to rupees two lakhs or with both:Provided that, in the absence of special and
adequate reasons to the contrary to be mentioned in the judgment of the Court, such imprisonment
shall not be less than three months and fine shall not be less than rupees fifty thousand.(3)If it is
noticed by the Licensing Authority that any person, whose performance licence has been cancelled
under sub-section (1), holds or causes to be held or permits to hold a dance performance of any kind
or type in his eating house, permit room or beer bar, the Licensing Authority shall, notwithstanding
anything contained in the rules framed under section 33, suspend the Certificate of Registration as
an eating house and the licence to keep a Place of Public Entertainment (PPEL) issued to a permit
room or a beer bar and within a period of 30 days from the date of suspension of the Certificate of
Registration and licence, after giving the licensee a reasonable opportunity of being heard, either
withdraw the order of suspending the Certificate of Registration and the licence or cancel the
Certificate of Registration and the licence.(4)A person aggrieved by an order of the Licensing
Authority cancelling the Certificate of Registration and the licence under sub-section (3), may,
within a period of 30 days from the date of receipt of the order, appeal to the State Government. The
decision of the State Government thereon shall be final.(5)Any person whose performance licence
stands cancelled under sub-section (1), may apply to the Licensing Authority, who has granted such
licence, for refund of the proportionate licence fee. The Licensing Authority, after making due
inquiry, shall refund the licence fee on pro-rata basis, within a period of 30 days from the date of the
receipt of such application.(6)The offence punishable under this section shall be cognizable andBombay Police Act, 1951

non-bailable.
33B. Non-application of the provisions of section 33A in certain cases. -
Subject to the other provisions of this Act, or any other law for the time being
in force, nothing in section 33A shall apply to the holding of a dance
performance in a drama theatre, cinema theatre and auditorium; or sports
club or gymkhana, where entry is restricted to its members only, or a three
starred or above hotel or in any other establishment or class of
establishments, which, having regard to (a) the tourism policy of the Central
or State Government for promoting the tourism activities in the State; or (b)
cultural activities, the State Government may, by special or general order,
specify in this behalf.
Explanation. - For the purposes of this section, "sports club" or "gymkhana" means an
establishment registered as such under the provisions of the Bombay Public Trusts Act, 1950, or the
Societies Registration Act, 1860 or the Companies Act, 1956, or any other law for the time being in
force.]
34. Competent authority may authorise erection of barriers on streets. - The
Commissioner and the [Superintendent] in areas under their respective
charges may, whenever in his opinion such action is necessary, authorise
such Police Officer as he thinks fit to erect barriers on any street for the
purpose of stopping temporarily vehicles driven on such street and satisfy
himself that the provisions of law for the time being in force have not been
contravened in respect of any such vehicle or by the driver of or the person
in charge of such vehicle. The said authority may also make such orders as it
deems fit for regulating the use of such barriers.
35. Power to make rules prohibiting disposal of the dead except at places set
apart. - (1) A competent authority may, from time to time, make rules
prohibiting the disposal of the dead, whether by cremation, burial or
otherwise at places other than those set apart for such purpose:
Provided that no such rules shall be made in respect of any such town or place in which places have
not been so set apart:Provided further that, the competent authority or any officer authorised by it
in this behalf may, in its or his discretion on an application made to it or him by any person, grant to
such person permission to dispose of the corpse of any deceased person at any place other than a
place so set apart, if in its or his opinion such disposal is not likely to cause obstruction to traffic or
disturbance of the public peace or is not objectionable for any other reason.(2)Any rules made under
sub-section (1) shall specify the places set apart for the disposal of the dead of different communitiesBombay Police Act, 1951

or sections of communities.(3)All such rules shall be subject to the condition of previous publication
and the date to be specified under clause (c) of section 24 of the Bombay General Clauses Act, 1904,
shall not be earlier than two months from the date on which the draft of the proposed rules is
published.Explanation. - For the purposes of this section, a place, set apart for the disposal of the
dead means a place set apart for such purpose under any custom, usage or law for the time being in
force.
36. Power of Commissioner or the [Superintendent] and of other officers to
give direction to the public. - In areas under their respective charges the
Commissioner, and subject to his orders every Police Officer not inferior in
rank to an Inspector, and the [Superintendent] and subject to his orders any
Police Officer of not lower than such rank as may be specified by the State
Government in that behalf, may from time to time as occasion may arise, but
not so as to contravene any rule or order under section 33 give all such
orders either orally or in writing as may be necessary to-
(a)direct the conduct of, and behaviour or action of persons constituting processions or assemblies
on or along the streets;(b)prescribe the routes by which and the time at which any such processions
may or may not pass;(c)prevent obstructions on the occasion of all processions and assemblies and
in the neighbourhood of all places of worship during the time of worship and in all cases when any
street or public place or place of public resort may be thronged or liable to be obstructed;(d)keep
order on and in all streets, quays, wharves, and at and within public bathing, washing and landing
places, fairs, temples and all other places of public resort;(e)regulate and control the playing of
music or singing, or the beating of drums, tom-toms and other instruments and the blowing or
sounding of horns or other noisy instruments in or near any street or public place;[(ea) regulate and
control the use of loudspeakers in or near any public place or in any place of public
entertainment;](f)make reasonable orders subordinate to and in furtherance of any order made by a
competent authority under sections 33, 35, 37 to 40, 42, 43 and 45 of this Act.
37. Power to prohibit certain acts for prevention of disorder. - (1) The
Commissioner and the District Magistrate in areas under their respective
charges may, whenever and for such time as he shall consider necessary for
the preservation of public peace or public safety by a notification publicly
promulgated or addressed to individuals, prohibit at any town, village or
place or in the vicinity of any such town, village or place-
(a)the carrying of arms, cudgels, swords, spears, bludgeons, guns, knives, sticks or lathis, or any
other article, which is capable of being used for causing physical violence,(b)the carrying of any
corrosive substance or explosives;(c)the carrying, collection and preparation of stones or other
missiles or instruments or means of casting or impelling missiles;(d)the exhibition of persons or
corpses or figures or effigies thereof;(e)the public utterance of cries, singing of songs, playing ofBombay Police Act, 1951

music;(f)delivery of harangues, the use of gestures or mimetic representation, and the preparation,
exhibition or dissemination of pictures, symbols, placards or any other object or thing which may in
the opinion of such authority offend against decency or morality or undermine the security of or
tend to overthrow the State.(2)If any person goes armed with any such article or carries any
corrosive substance or explosive or missile in contravention of such prohibition, he shall be liable to
be disarmed or the corrosive substance or explosive or missile shall be liable to be seized from him
by any Police Officer, and the article, corrosive substance, explosive or missile so seized shall be
forfeited to the State Government.(3)The authority empowered under sub-section (1) may also by
order in writing prohibit any assembly or procession whenever and for so long as it considers such
prohibition to be necessary for the preservation of the public order:Provided that no such
prohibition shall remain in force for more than fifteen days without the sanction of the State
Government.(4)The authority empowered under sub-section (1) may also by public notice
temporarily reserve for public purpose any street or public place and prohibit person from entering
the area so reserved, except under such conditions as may be prescribed by such authority.
38. Power to prohibit, etc. continuance of music, sound or noise. - (1) If the
Commissioner or [Superintendent] is satisfied from the report of an officer in
charge of a Police Station or other information received by him that it is
necessary to do so in order to prevent annoyance, disturbance, discomfort
or injury or risk of annoyance, disturbance, discomfort or injury to the public
or to any persons who dwell or occupy property on the vicinity, he may, by a
written order issue such directions as he may consider necessary to any
persons for preventing prohibiting, controlling or regulating-
(a)the incidence or continuance in or upon any premises of -(i)any vocal or instrumental
music,(ii)sounds caused by the playing, beating, clashing, blowing or use in any manner whatsoever
of any instrument, appliance or apparatus or contrivance which is capable of [producing or
reproducing sound], or(b)the carrying on, in or upon, any premises of any trade, avocation or
operation resulting in or attended with noise.(2)the authority empowered under sub-section (1)
may, either on its own motion, or on the application of any person aggrieved by an order made
under sub-section (1) either rescind, modify or alter any such order:Provided that before any such
application is disposed of, the said authority shall afford to the applicant an opportunity of
appearing before it either in person or by pleader and showing cause against the order and shall, if it
rejects any such application either wholly or in part, record its reasons for such rejection.
39. Issue of orders for prevention of riot, etc. - (1) In order to prevent or
suppress any riot or grave disturbance of peace, the Commissioner and the
[Superintendent], in areas under their respective charges, may temporarily
close or take possession of any building or place, and may exclude all or any
persons therefrom, or may allow access thereto to such persons only and on
such terms as he shall deem expedient. All persons concerned shall beBombay Police Act, 1951

bound to conduct themselves in accordance with such orders as the
authority making orders may make and notify in exercise of the authority
hereby vested in it.
Compensation to lawful occupier of building or place closed or taken possession of(2)If the lawful
occupier of such building or place suffers substantial loss or injury by reason of the action taken
under sub-section (1) he shall be entitled, on application made to the authority concerned within
one month from the date of such action, to receive reasonable compensation for such loss or injury,
unless such action was in the opinion of such authority rendered necessary either by the use to
which such building or place was put or intended to be put or by the misconduct of persons having
access thereto.Disputes as to compensation to be settled(3)In the event of any dispute in any case
under sub-section (2) the decision of the Chief Presidency Magistrate or the District Magistrate, as
the case may be, shall be conclusive as to the amount (if any) to be paid, and as to the persons to
whom it is to be paid.
40. Issue of orders for maintenance of order at religious ceremonials, etc. -
(1) In any case of an actual or intended religious or ceremonial, or corporate
display or exhibition or organised assemblage in any street or public place,
as to which or the conduct of or participation in which it shall appear to a
competent authority that a dispute or contention exists which is likely to lead
to grave disturbance of the peace, such authority may give such orders as to
the conduct to the persons concerned towards each other and towards the
public as it shall deem necessary and reasonable under the circumstances,
regard being had to the apparent legal rights and to any established practice
of the parties of the persons interested. Every such order shall be published
in the town or place wherein it is to operate, and all persons concerned shall
be bound to conform to the same.
(2)Any order under sub-section (1) shall be subject to a decree, injunction or order made by a Court
having jurisdiction, and shall be recalled or altered on its being made to appear to the authority
making the order that such order is inconsistent with a judgment, decree, injunction or order of
such Court on the complaint, suit or an application of any person interested, as to the rights and
duties of any person affected by the order aforesaid.
41. Police to provide against disorder, etc., at places of amusement and
public meeting. - (1) For the purpose of preventing serious disorder or
breach of the law or, manifest an imminent danger to the persons assembled
at any public place or amusement or at an assembly or meeting to which the
public are invited or which is open to the public, the senior Police Officer of
higher rank superior to that of constable, present at such place ofBombay Police Act, 1951

amusement or such assembly or meeting may subject to such rules and
orders as may have been lawfully made give such reasonable directions as
to the mode of admission of the public to, and for securing the peaceful and
lawful conduct of the proceedings and the maintenance of the public safety
at such place of amusement or such assembly or meeting as he thinks
necessary and all persons shall be bound to conform to every such
reasonable direction.
Police to have free access thereto(2)The Police shall have free access to every such place of
amusement, assembly or meeting of the purpose of giving effect to the provisions of sub-section (1)
and to any direction made thereunder.
42. (Discontinuance of brothels) - Deleted by Maharashtra 28 of 1964, Section
8.
43. District Magistrate may take special measures to prevent outbreak of
epidemic disease at fair, etc. - (1) Whenever it shall appear to the
Commissioner or District Magistrate that any place in the areas under their
respective charges, at which, on account of a pilgrimage, fair or other such
occasions large bodies of persons have assembled or are likely to assemble
is visited or will probably be visited with an outbreak of any epidemic
disease, he may take such special measures and may by public notice
prescribe such regulations to be observed by the residents of the said place
and by persons present thereat or returning thereto or returning therefrom as
he shall deem necessary to prevent the outbreak of such disease or the
spread thereof.
(2)It shall be lawful for the District Magistrate or for the Collector or the Chief Presidency
Magistrate on the requisition of the Commissioner or the District Magistrate to assess and levy such
reasonable fees on persons falling under the provisions of sub-section (1) as will provide for the
expenses of the arrangements for sanitation and the preservation of order at and about the place of
assemblage.(3)When the place of assemblage is within the limits of a municipality or corporation
such sums as shall be necessary for the purposes aforesaid may be recovered from the municipality
or corporation.
44. Destruction of stray dogs. - (1) The Commissioner and the
[Superintendent] in areas under their respective charges, may from time to
time by public notice, proclaim that any stray dogs found, during such period
as may be specified in the said notice, wandering in the streets or in anyBombay Police Act, 1951

public place may be destroyed, and any dog so found within such period
may be destroyed accordingly.
(2)The authority empowered under sub-section (1) may by public notice require that every dog,
while in any street or public place and not led by some person, shall be muzzled in such a manner as
effectually to prevent it from biting, while not obstructing its breathing or drinking, and the Police
may, so long as such notice remains in force, destroy, or take possession of and detain, any dog,
found loose without muzzle in any street or place beyond the premises of the owner
thereof:Provided that any dog so found, wearing a collar on which an apparently genuine name and
address of an owner is inscribed, shall not unless it is rabid, be forthwith destroyed, but information
of the detention thereof shall forthwith be sent by post or otherwise to such owner.(3)Any dog which
has been detained under sub-section (2) for a period of three clear days without the owners
providing a muzzle and paying all expenses connected with such detention, may be destroyed or sold
with the sanction and under the orders of the competent authority.(4)The proceeds of the sale of any
dog under sub-section (3) shall be applied, as far as may be, in discharge of the expenses incurred in
connection with its detention, and the balance, if any, shall form part of the consolidated fund of the
State.(5)Any expenses incurred in connection with the destruction or detention of any dog under
this section shall, subject to the provisions of sub-section (4), be recoverable from the owner thereof
upon a warrant issued by the competent authority as if it were a warrant under section 386 of the
[Code of Criminal Procedure, 1898.]
45. Destructions of suffering or unfit animals. - (1) Any Police officer who in
any street or public place other than a place of worship finds any animal
other than a bull or a cow so diseased, or so severely injured, and in such a
physical condition, that in his opinion it cannot without cruelty be removed
shall, if the owner is absent or refuses to consent to the destruction of the
animal, at once summon the Veterinary Practitioner in charge of the area in
which the animal is found and, if the Veterinary Practitioner certifies that the
animal is mortally injured, or so severely injured, or so diseased, or in such a
physical condition, that it is cruel to keep it alive, the Police Officer may
without the consent of the owner, destroy the animal or cause it to be
destroyed:
Provided that if in the opinion of the Veterinary Practitioner the animal can be removed from the
place where it is found without causing it great suffering, and, if the owner or person in-charge of
the animal or in their absence any other person, on the spot is willing and offers to remove the
animal to a Veterinary Hospital or Panjrapole within such time as the Veterinary Practitioner
considers reasonable the Veterinary Practitioner shall allow the animal to be removed by such
owner, person in-charge of the animal or other person, if the owner or person in-charge of the
animal or such other person is unwilling or fails so to remove the animal, the Veterinary Practitioner
may direct the Police Officer to remove the animal before it is destroyed from the place where it is
found to such other place as he may think fit:Provided further that when the animal is destroyed inBombay Police Act, 1951

any street or public place it shall as far as possible, be screened from the public gaze while it is being
destroyed.(2)The State Government may appoint such persons as it thinks fit to be Veterinary
Practitioners and may declare the areas of which they shall be in-charge for the purposes of this Act.
46. Powers under this Chapter to be exercised by [Superintendent] subject to
the control of District Magistrate and Commissioner and by District
Magistrate subject to the control of State Government. - Every power
conferred by this Chapter on a [Superintendent] not specially empowered by
the State Government to exercise that power or on any officer subordinate to
him shall be exercised by him subject to the orders of the District Magistrate
and all rules, regulations, and orders made under this Chapter shall, if made
by [the Revenue Commissioner or the Commissioner] be governed by such
rules and orders as the State Government may from time to time make in this
behalf and, if made by the District Magistrate or the [Superintendent]
specially empowered in that behalf, shall be subject to the provisions of
section 17.
Chapter V
Special Measures for Maintenance of Public Order and Safety of StateI. Employment of Additional
Police, recovery of cost thereof and of riots compensation - its assessment and recovery
47. Employment of additional Police on application of a person. - (1) The
Commissioner or [Superintendent] may, on the application of any person,
depute any additional number of Police to keep the peace, to preserve order
or to enforce any of the provisions of this or any other Act in respect of any
particular class or classes of offences or to perform any other Police duties
at any place in the area under his charge.
(2)Such additional Police shall be employed at the cost of the person making the application, but
shall be subject to the orders of the Police authorities and shall be employed for such period as the
appointing authority thinks fit.(3)If the person upon whose application such additional Police are
employed shall at any time make a written requisition to the appointing authority to which the
application for the employment of additional Police was made, for the withdrawal of the said Police,
he shall be relieved from the cost thereof at the expiration of such period not exceeding one month
from the date of the delivery of such requisition as the State Government or the appointment
authority, as the case may be, shall determine.Bombay Police Act, 1951

48. Employment of additional police at large works and when apprehension
regarding behaviour of employees exists. - (1) Whenever it appears to the
State Government or a competent authority that, -
(a)any large work which is being carried on or any public amusement which is being conducted is
likely to impede the traffic or to attract a large number of people; or(b)that the behaviour or a
reasonable apprehension of the behaviour, of the persons employed on any railway, canal or other
public work, or in or upon any manufactory or other commercial concern under construction or in
operation at any place necessitates the; employment of additional Police at such place, the State
Government or the competent authority may depute such additional Police to the said place as it
shall think fit and keep the said Police, employed at such place for so long as such necessity shall
appear to it to continue.(2)Such additional Police shall be employed at the cost of the person by
whom the work, amusement, manufactory or concern is being constructed, conducted or carried on
and the said person shall pay the costs therefor at such rates as the State Government or the
competent authority, as the case may be, shall from time to time require.
49. Recovery of cost of additional Police employed under sections 47 and 48.
- In case of any dispute under section 47 and 48 the decision of the Chief
Presidency Magistrate, in Greater Bombay, and the District Magistrate, in the
district shall be conclusive as to the amount to be paid and as to the person
by whom it is to be paid and the sum so ascertained may, on the requisition
of the Chief Presidency Magistrate or the District Magistrate be recovered by
the Collector as if it were an arrear of land revenue due by the person found
to be answerable therefor.
50. Employment of additional Police in cases of special danger to public
peace. - (1) If in the opinion of the State Government any area is in a
disturbed or dangerous condition or in which the conduct of the inhabitants
or of any particular ejection of the inhabitants renders it expedient
temporarily to employ additional Police, it may by notification in the Official
Gazette specify-
(a)the area (hereinafter called "the disturbance area") in which the additional Police is to be
employed;(b)the period for which the additional Police is to be employed:Provided that the period
fixed under clause (b) may be extended by the State Government from time to time, if in its opinion
it is necessary to do so in the general interest of the public. The cost of the additional Police shall be
a tax imposed under this section and shall be recovered in the manner prescribed in the succeeding
sub-sections.(2)The decision of the State Government under clauses (a) and (b) of sub-section (1)
shall be final.(3)On the issue of such notification, the State Government may require,-(a)in any
disturbance area which is within the limits of a Corporation, the Municipal Commissioner, the
Collector or any other authority,(b)in any disturbance area which is within the limits ofBombay Police Act, 1951

municipality, the municipality, the Collector or any other authority.(c)in any disturbance area which
is outside the areas specified in clauses (a) and (b) the Collector or any other authorityto recover,
whether in whole or in part, the cost of such additional Police generally from all persons who are
inhabitants of the disturbance area or specially from any particular section or sections, or class or
classes of such persons, and in such proportion as the State Government may direct:Provided that
where the Municipal Commissioner or the Municipality is directed to recover such cost, an
additional sum not exceeding 3 per cent of the amount of such cost shall also be
recoverable.(4)(i)The State Government may require the Municipal Commissioner or the
Municipality to recover such cost and the additional sum by an addition to the general or property
tax which shall be imposed and levied in all or such of the municipal wards, sub-wards or sections
thereof, as the State Government may direct. Every addition to the general or property tax imposed
under this sub-section shall be recovered by the Municipal Commissioner or the Municipality from
each person liable therefor in the same manner as the general or property tax due from him. The
provisions of the relevant Municipal Act shall apply to any such addition as if it were part of the
general or property tax levied under the said Act. Such addition shall be a charge along with the
general or property tax, on the properties, in such municipal wards or sub-wards or sections.(ii)The
State Government may also require the Municipal Commissioner or the Municipality to recover
such cost and the additional sum from each person liable therefor under sub-section (3) in such
manner as the State Government may direct.(iii)Where the Municipal Commissioner or a
Municipality makes default in imposing and levying any such tax or in making such recovery, the
State Government may direct the Collector to impose and levy such tax or to make such
recovery.(5)Every amount recoverable by the Collector or other authority under this section shall be
recoverable as if it were an arrear of land revenue due by the person liable therefor.(6)It shall be
lawful for the State Government by order to exempt any person from liability to bear any portion of
the cost of such additional Police.(7)Out of the total amount recovered by the Municipal
Commissioner or by a Municipality under sub-section (4) or (5) whether before or after the coming
into operation of this Act the amount of the cost shall be paid to the State Government and the
balance, if any, shall be credited to the municipal fund constituted under the relevant Municipal Act.
Such amount of cost shall be paid to the State Government every three months.Explanation. - In this
section the expression "inhabitants" when used with reference to any area includes persons who
themselves or by their agents or servants occupy or hold land or other immovable property within
such area and landlords who themselves or by their agents or servants collect rent from holders or
occupiers of lands in such area notwithstanding that they do not actually reside therein.
51. Compensation for injury caused by unlawful assembly, how recoverable,
date to be fixed for liability. - [(1) When any loss or damage is caused to any
property or when death results or grievous hurt is caused to any person or
persons by anything done in the prosecution of the common object of an
unlawful assembly, the District Magistrate may by order, specify,-
(a)the area (hereinafter called "the disturbance area") in which in his opinion such unlawful
assembly was held;(b)the date on which or the period during which such unlawful assembly was
held.](2)The decision of the [District Magistrate] under clauses (a) and (b) of sub-section (1) shall beBombay Police Act, 1951

final.(3)On the [issue of an order under sub-section (1), the District Magistrate], may, after such
inquiry as he deems necessary, determine the amount of the compensation which, in his opinion
should be paid to any person or persons in respect of the loss or damage or death or grievous hurt
aforesaid. The amount of compensation shall be a tax imposed under this section and shall be
recovered in the manner prescribed in the succeeding sub-sections.(4)The [District Magistrate], as
the case may be, may require,-(a)in any disturbance area which is within the limits of a Corporation,
the Municipal Commissioner, [or any other authority authorized by the Collector];(b)in any
disturbance area which is within the limits of Municipality, the municipality, the [or any other
authority authorized by the Collector]; and(c)in any disturbance area which is outside the area
specified in clauses (a) and (b) [any authority authorized by the Collector],to recover the amount
(hereinafter called "the compensation amount") as determined under sub-section (3) either in whole
or in part and where the Municipal Commissioner or the Municipality is required to recover such
amount, an additional sum not exceeding three per cent of the compensation amount (hereinafter
referred to as "the Municipal recovery costs"), generally from all persons who were inhabitants to
the disturbance area [or the members of the unlawful assembly as specified in sub-section (1) or
specially from any particular section or sections or class or classes of such persons and in such
proportion as] the District Magistrate may direct.[(4A) If the District Magistrate observes that the
amount of compensation as determined under sub-section (3), either in whole or in part is to be
recovered from persons or section or sections or class or classes of such persons are inhabitants of
the area, which is beyond the area of his jurisdiction, the District Magistrate, shall send the
information along with his report, to the District Magistrate of the district in whose jurisdiction such
persons or section or sections or class or classes of such persons are residing to recover the amount
from them. On receiving such information the District Magistrate of such area shall recover the
amount of compensation in the manner as provided under this section.](5)(i)The [District
Magistrate], may require the Municipal Commissioner or the Municipality concerned to recover the
compensation amount and the municipal recovery cost by an addition to the general or property tax
which shall be imposed and levied in the disturbance area. Every addition to the general or property
tax imposed under this sub-section shall be recovered by the Municipal Commissioner or the
Municipality concerned from each person liable therefor in the same manner as the general or
property tax due from him. The provisions of the relevant Municipal Act shall apply to any such
addition as if it were part of the general or property tax levied under the relevant Municipal Act.
Such addition shall be a charge along with the general or property tax on the properties in the area
aforesaid.(ii)The [District Magistrate], may also require the Municipal Commissioner or the
Municipality concerned to recover the compensation amount and the municipal recovery cost from
each person,liable therefor under sub-section (4) in such manner as he may direct.(6)Where a
Municipal Commissioner or a Municipality makes a default in imposing and levying any such tax or
in making any such recovery, the State Government may direct the Collector to impose and levy
such tax or to make such recovery.(7)Every amount recoverable by the Collector or other authority
under this section shall be recoverable as if it were an arrear of land revenue due by the person liable
therefor.(8)Out of the total amount recovered by the Municipal Commissioner or by a Municipality
under sub-section (5) or (7) whether before or after the coming into operation of this Act, the
proportionate amount of the municipal recovery cost shall be deducted therefrom and the amount
not exceeding the compensation amount determined by the [District Magistrate], under sub-section
(3) shall be paid to him for the payment of compensation to the persons entitled thereto and theBombay Police Act, 1951

balance, if any, shall be credited to the municipal fund constituted under the relevant Municipal Act,
such amount shall be paid to the [District Magistrate], every three months.(9)It shall be lawful for
the [District Magistrate] by order to exempt any persons from liability to pay any portion of the
compensation amount.(10)The State Government may, (a) on its own motion, or (b) on an
application made by a person within a period of thirty days from date of the order of the [District
Magistrate], granting or refusing to grant an exemption thereunder, set aside or modify such
order.[(11) The provisions of this section shall be in addition to and not in derogation of the
provisions of any other law for the time being in force.]Explanation. - In this section the expression
"inhabitants" when used with reference to any disturbance area includes persons who themselves or
by their agents or servants occupy or hold land or other immovable property within such area and
landlords who themselves or by their agents or servants collect rent from holders or occupiers of
land in such area, notwithstanding that they do not actually reside therein.
52. [District Magistrate] to award or apportion compensation. - (1) It shall be
lawful for the [District Magistrate] to award or apportion all or any moneys
recovered as compensation amount under sub-sections (3) to (8) of section
51 to any person or among all or any persons whom he considers entitled to
compensation in respect of the loss or damage or death or grievous hurt
aforesaid.
(2)No compensation shall be awarded under this section except upon a claim made within 45 days
from the date of [the order issued by the District Magistrate] under sub-section (2) of section 51 and
unless the [District Magistrate], is satisfied that the person claiming compensation or where such
claim is made in respect of the death of any person, that person also has himself been free from
blame in connection with the occurrences which led to the loss, damage, death or grievous hurt as
aforesaid.(3)The compensation payable to any person under section 51 in respect of death or
grievous hurt shall not in any way be capable of being assigned or charged or be liable to attachment
or to pass to any person other than the person entitled to it by operation of law, nor shall any claim
be set off against the same.(4)Every direction and order made by the [District Magistrate], under
this or the preceding section shall be subject to revision by the State Government but save as
aforesaid, shall be final.(5)No civil suit shall be maintainable in respect of any loss or injury for
which compensation has been granted under this section.
53. [District Magistrate] to discharge functions under orders of State
Government. - The [District Magistrate], shall discharge his functions under
sections 51 and 52 subject to any general or special orders of the State
Government in this behalf.
54. Proportionate recovery of the cost of additional Police and compensation
for loss caused by unlawful assembly. - (1) Notwithstanding anything
contained in the Bombay Rents, Hotel and Lodging House Rates Control Act,Bombay Police Act, 1951

1947, [or any] law corresponding thereto in force in any area of the [State of
Maharashtra,] where under the provisions of section 50 or 51, the Municipal
Commissioner, the Municipality or the Collector, as the case may be, is
required to recover the cost of the additional police including the additional
sum referred to in sub-section (3) of section 50 (hereinafter called "the
additional cost") or the compensation amount and the municipal recovery
cost (hereinafter called "the riot tax") by an addition to the general or
property tax the landlord from whom any portion of the additional cost or the
riot tax is recovered in respect of any premises shall be entitled to recover 75
per cent, of such portion from the tenant in the occupation of the premises
during the period fixed under sub-section (2) of section 50 or on the date or
during the greater part of the period specified under clause (b) of sub-section
(2) of section 51, as the case may be, in the manner specified in sub-section
(2).
(2)The amount referred to in sub-section (2) and to be recovered from a tenant referred to therein,
shall bear the same proportion as the rent payable by him in respect of the premises in his
occupation bears to the total amount of rent recoverable for the whole premises if let, and the same
shall be recoverable from the tenant in not less than four equal instalments.(3)The provisions of
sub-section (2) in so far as they relate to the recovery of the riot tax from the tenant shall not apply
to Greater Bombay during the period during which section 10-B of the Bombay Rents, Hotel and
Lodging House Rates Control Act, 1947, is in force in the said area.II. Dispersal of Gangs and
Removal of Persons Convicted by certain offences [and of certain beggars].
55. Dispersal of gangs and bodies of persons. - Whenever it shall appear in
Greater Bombay and in other areas in which a Commissioner is appointed
under section 7 to the Commissioner and in a district to the District
Magistrate, the Sub-Divisional Magistrate or the [Superintendent] [* * *]
empowered by the State Government in that behalf, that the movement or
encampment of any gang or body of persons in the area in his charge is
causing or is calculated to cause danger or alarm or reasonable suspicion
that unlawful designs are entertained by such gang or body or by members
thereof, such officer may, by notification addressed to the persons appearing
to be the leaders or chief men of such gang or body and published by beat of
drum or otherwise as such officer thinks fit, direct the members of such gang
or body so to conduct themselves as shall seem necessary in order to
prevent violence and alarm or disperse and each of them to remove himself
outside the area within the local limits of his jurisdiction [or such area andBombay Police Act, 1951

any district or districts, or any part thereof, contiguous thereto] within such
time as such officer shall prescribe, and not to enter to area [for the areas
and such contiguous districts, or part thereof, as the case may be,] or return
to the place from which each of them was directed to remove himself.
56. Removal of persons about to commit offence. - [(1)] Whenever it shall
appear in Greater Bombay and other areas for which a Commissioner has
been appointed under section 7 to the Commissioner and in other area or
areas to which the State Government may, by notification in the Official
Gazette, extend the provisions of this section, to the District Magistrate, or
the Sub-Divisional Magistrate [* * *] empowered by the State Government in
that behalf (a) that the movements or acts of any person are causing or
calculated to cause alarm, danger or harm to person or property or (b) that
there are reasonable grounds for believing that such person is engaged or is
about to be engaged in the commission of an offence involving force or
violence or an offence punishable under Chapters XII, XVI or XVII of the
Indian Penal Code, or in the abetment of any such offence and when in the
opinion of such officer witnesses are not willing to come forward to give
evidence in public against such person by reason of apprehension on their
part as regards the safety of their person or property, or [(bb) that there are
reasonable grounds for believing that such person is acting or is about to
act] (1) in any manner prejudicial to the maintenance of public order as
defined in the Maharashtra Prevention of Communal, Antisocial and Other
Dangerous Activities Act, 1980, or (2) in any manner prejudicial to the
maintenance of supplies of commodities essential to the community as
defined in the Explanation to sub-section (1) of section 3 of the Prevention of
Black marketing and Maintenance of Supplies of Essential Commodities Act,
1980, or (c) that an outbreak of epidemic disease is likely to result from the
continued residence of an immigrant, the said officer may, by an order in
writing duly served on him or by beat of drum or otherwise as he thinks fit
direct such person or immigrant so to conduct himself as shall seem
necessary in order to prevent violence and alarm [or such prejudicial act,] or
the outbreak or spread of such disease or [notwithstanding anything
contained in this Act or any other law for the time being in force, to remove
himself outside such area or areas in the State of Maharashtra (whether
within the local limits of the jurisdiction of the officer or not and whether
contiguous or not), by such route, and within such time, as the officer mayBombay Police Act, 1951

specify and not to enter or return to the area or areas specified (hereinafter
referred to as "the specified area or areas") from which he was directed to
remove himself].
[(2) An officer directing any person under sub-section (1) to remove himself from any specified area
or areas in the State may further direct such person that during the period the order made against
him is in force, as and when he resides in any other areas in the State, he shall report his place of
residence to the officer in-charge of the nearest police station once in every month, even if there be
no change in his address. The said officer may also direct that, during the said period, as and when
he goes away from the State, he shall, within ten days from the date of his departure from the State
send a report in writing to the said officer, either by post or otherwise, of the date of his departure,
and as and when he comes back to the State he shall, within ten days, from the date of his arrival in
the State, report the date of his arrival to the officer in-charge of the police station nearest to the
place where he may be staying.][57. Removal of persons convicted of certain offences. - [(1)] If a
person has been convicted-(a)(i)of an offence under Chapters XII, XVI or XVII of the Indian Penal
Code; or(ii)of any offence under sections 65, 66A or 68 of the Bombay Prohibition Act, 1949;
or(iii)of an offence under sections 3, 4, 5, 6, or 9 of the Suppression of Immoral Traffic in Women
and Girls Act, 1956; or(iv)of an offence under section 135 of the Customs Act, 1962; or(v)of an
offence under section 4, or for accepting bet in any public street or thoroughfare or in any place to
which the public have or are permitted to have access, or in any race course under clause (a) of
section 12 or under section 12A of the Bombay Prevention of Gambling Act, 1887; or(b)twice or
more of an offence under the Bombay Prohibition Act, 1949 not being an offence under sections 65,
66A and 68; or[(b-a)] twice or more of an offence under section 3 or 4 of the Railway Property
(Unlawful Possession) Act, 1966; or](c)thrice or more of an offence under section 122 or 124 of this
Act, the Commissioner, the District Magistrate, or the Sub-Divisional, Magistrate [* * *] empowered
by the State Government in this behalf, if he has reason to believe that such person is likely again to
engage himself in the commission of an offence similar to that for which he was convicted, may
direct such person [notwithstanding anything contained in this Act or any other law for the time
being in force, to remove himself outside such area or areas in the State of Maharashtra (whether
within the local limits of the jurisdiction of the officer or not and whether contiguous or not), by
such route, and within such time, as the officer may specify and not to enter or return to the area or
areas so specified (hereinafter referred to as "the specified area or areas") from which he was
directed to remove himself.][(2) An officer directing any person under sub-section (1) to remove
himself from any specified area or areas in the State may further direct such person that, during the
period the order made against him is in force, as and when he resides in any other areas in the State,
he shall report his place of residence to the officer-in-charge of the nearest police station once in
every month, even if there be no change in his address. The said officer may also direct that, during
the said period, as and when he goes away from the State, he shall, within ten days from the date of
his departure from the State, send a report in writing to the said officer either by post or otherwise,
of the date of his departure, and as and when he comes back to the State, he shall, within ten days
from the date of his arrival in the State report the date of his arrival to the officer-in-charge of the
police station nearest to the place where he may be staying.]Explanation. - For the purpose of this
section "an offence similar to that for which a person was convicted" shall mean-(i)in the case of a
person convicted of an offence mentioned in clause (a) (i) an offence falling under any of theBombay Police Act, 1951

chapters of the Indian Penal Code, and (ii) in the case of a person convicted of an offence mentioned
in clauses (a) (excluding sub-clause (i) thereof), (b) and (c), an offence falling under the provisions
of the Acts mentioned respectively in the said clauses.][57A. Removal of certain persons declared to
be beggars. - In any area in which the Bombay Prevention of Begging Act, 1959, is in force, the
Commissioner or the District Magistrate having jurisdiction in that area, on receipt of a copy of the
order of the Court made under clause (b) of sub-section (5) of section 5 of that Act, shall examine the
person who has been directed to appear before him, and if the Commissioner or the District
Magistrate is satisfied that such person is not likely to engage himself in the said area in any lawful
profession, trade, calling or employment, such officer may by order in writing duly served on such
person direct such person to remove himself outside the area or areas where the said Act is in force
within such time as may be specified in the order and not to enter or return to the area or areas, as
the case may be, from which he was directed to remove himself:Provided that, before serving such
order on any person, the Commissioner or as the case may be, the District Magistrate shall, in
consultation with the State Government or in accordance with any general or special order issued by
the State Government for this purpose, offer to such person the option of accepting an employment
in any undertaking, public works, or otherwise on such terms and conditions as may be specified by
him in this behalf. Where such option is accepted, the fact of such acceptance shall be recorded in
the externment order;Provided further that, where the Commissioner or the District Magistrate is
satisfied that such person is unfit for any work he shall refer the case of such person to the Court,
with a request that the Court may order such person to be detained in a Certified Institution, as
provided in clause (c) of sub-section (5) of section 5 of the Bombay Prevention of Begging Act, 1959.]
58. Period of operation of orders under sections 55, [56, 57 and 57A]. - A
direction made under section 55, [56, 57 and 57A] not to enter any particular
area [or such area and any district or districts, or any part thereof,
contiguous thereto, [or any specified area or areas] as the case may be,]
shall be for such period as may be specified therein and shall in no case
exceed a period of two years [from the date on which the person removes
himself or is removed from the area district or districts or part aforesaid] [or
from the specified area or areas, as the case may be].
59. Hearing to be given before order under sections 55, [56, 57 or 57A] is
passed. - (1) Before an order under section 55, [56, 57 or 57A] is passed
against any person the officer acting under any of the said sections or any
officer above the rank of an Inspector authorised by that officer shall inform
the person in writing of the general nature of the material allegations against
him and give him a reasonable opportunity of tendering an explanation
regarding them. If such person makes an application for the examination of
any witness produced by him, the authority or officer concerned shall grant
such application; and examine such witness, unless for reasons to be
recorded in writing, the authority or officer is of opinion that such applicationBombay Police Act, 1951

is made for the purpose of vexation or delay. Any written-statement put in by
such person shall be filed with the record of the case. Such person shall be
entitled to appear before the officer proceeding under this section by an
advocate or attorney for the purpose of tendering his explanation and
examining the witness produced by him.
(2)The authority or officer proceeding under sub-section (1) may, for the purpose of securing the
attendance of any person against whom any order is proposed to be made under sections 55, [56, 57
or 57A] require such person to appear before him and to pass a security bond with or without
sureties for such attendance during the inquiry. If the person fails to pass the security bond as
required or fails to appear before the officer or authority during the inquiry, it shall be lawful to the
officer or authority to proceed with the inquiry and thereupon such order as was proposed to be
passed against him may be passed.
60. Appeal. - [(1)] Any person aggrieved by an order made under sections 55,
[56, 57 or 57A] may appeal to the State Government [or to such Officer as the
State Government may by order specify (hereinafter referred to as "the
specified Officer")] within thirty days from the date of such order.
[(2) An appeal under this section shall be preferred in duplicate in the form of a memorandum,
setting forth concisely the grounds of objection to the order appealed against, and shall be
accompanied by that order of a certified copy thereof.(3)On receipt of such appeal the State
Government [or the specified Officer] may, after giving a reasonable opportunity to the appellant to
be heard either personally, or by a pleader, advocate or attorney and after such further inquiry, if
any, as it may deem necessary, confirm, vary or cancel, or set aside the order appealed against, [or
remand the case for disposal with such directions as it or he thinks fit, and make its or his order]
accordingly:Provided that the order appealed against shall remain in force pending the disposal of
the appeal, unless the State Government [or the specified Officer] otherwise directs.(4)In calculating
the period of thirty days provided for an appeal under this section, the time taken for granting a
certified copy of the order appealed against shall be excluded.][Explanation. - For the purposes of
this sub-section the power to vary the order appealed against shall include, and shall be deemed
always to have included, the power to hold such order in abeyance and to make conditional order
permitting the person to enter or return to the area or such areas and any contiguous districts or
part thereof, or to the specified area or areas, as the case may be, from which he was directed to
remove himself.]
61. Finality of order passed by State Government in certain cases. - Any
order passed under section 55, [56, 57 or 57A] or by the State Government
under section 60 shall not be called in question in any Court except on the
ground that the authority making the order or any officer authorised by it had
not followed the procedure laid down in sub-section (1) of section 59 or thatBombay Police Act, 1951

there was no material before the authority concerned upon which it could
have based its order or on the ground that the said authority was not of
opinion that witnesses were unwilling to come forward to give evidence in
public against the person in respect of whom an order was made under
section 56.
62. Procedure on failure of person to leave the area and his entry therein
after removal. - [(1) If a person to whom a direction has been issued under
sections 55, [56, 57 or 57A] to remove himself from [any area, district or part
thereof or from any specified area-]
(i)fails to remove himself as directed, or(ii)having so removed himself except with the permission in
writing of the authority making the order [as provided in sub-section (2)], [enters the areas, district
or part thereof or the specified area] within the period specified in the orders, the authority
concerned may cause him to be arrested and removed in police custody to such place [outside the
area, district or part thereof or outside the specified area, and as the case may be], as the said
authority may in each case prescribe.][(2) The authority making an order under sections 55, [56, 57
or 57A] may in writing permit any person in respect of whom such order has been made to enter or
return to the area, including any contiguous districts or part thereof [or to the specified area or
areas,] from which he was directed to remove himself for such temporary period and subject to such
conditions as may be specified in such permission and may require him to enter into a bond with or
without surety for the due observance of the conditions imposed. The authority aforesaid may at any
time revoke any such permission. Any person who with such permission enters or returns [to such
area, district or part thereof or to such specified area] shall observe the conditions imposed, and at
the expiry of the temporary period for which he was permitted to enter or return, or on the earlier
revocation of such permission shall remove himself outside such area, or the area and any
contiguous districts or part thereof, [or outside such specified area or areas,] and shall not enter
therein or return thereto within the unexpired residue of the period specified in the original order
made under sections 55, [56, 57 or 57A] without a fresh permission. If such person fails to observe
any of the conditions imposed, or to remove himself accordingly, or having so removed himself
enters or returns to the area, or the area and any contiguous districts or parts thereof [or to the
specified area or areas], without fresh permission, the authority concerned may cause him to be
arrested and removed in police custody to such place [outside the areas and district or part thereof
or outside the specified area or areas, as the case may be,] as that authority may in each case
prescribe.]
63. Temporary permission to enter or return to the area from which a person
was directed to remove himself. - (1) The State Government [or any officer
specially empowered by the State Government in that behalf] may, by order,
permit any person in respect of whom an order has been made under
sections 55, [56, 57 or 57A], to enter or return for a temporary period to [theBombay Police Act, 1951

area, or such areas] and any contiguous districts or part thereof, [or to the
specified area or areas,] as the case may be, from which he was directed to
remove himself, subject to such conditions as it [or he] may by general or
special order specify and which such person accepts is and may, at any time,
revoke any such permission.
(2)In permitting a person such sub-section (1) to enter or return to [the area, or such areas] and any
contiguous districts or part thereof, [or to the specified area or areas,], as the case may be from
which he was directed to remove himself, the State Government [or such officer] may require him to
enter into bond with or without surety for the observance of the conditions imposed.(3)Any person
permitted under sub-section (i) to enter or return to [the area or such areas] and any contiguous
district or part thereof, [or to the specified area or areas,] as the case may be, from which he was
directed to remove himself shall surrender himself at the time and place and to the authority
specified in the order or in the order revoking the said order, as the case may be.[63AA. Powers of
externment of State Government and officers specially empowered. - (1) The State Government or
any officer specially empowered by the State Government in that behalf, may, in like circumstances
and in like manner exercise the powers exercisable, [in any area for which a Commissioner is
appointed] by the Commissioner, and in a district by the District Magistrate, Sub-Divisional
Magistrate or [Superintendent] [* * *] empowered by the State Government in that behalf, as the
case may be, under sections 55, [56, 57 or 57A], with this modification that [under sections 55 and
57A] it shall, be lawful for the State Government or the officer specially empowered to direct the
members of [the gang or body, or persons] [or persons declared to be beggars], as the case may be,
to remove themselves from, and not to enter or return to, any local area, or any such area and any
districts or part thereof, whether contiguous thereto or not.(2)The provisions of sections 58, 59, 60,
61, 62 and 63 shall mutatis mutandis apply to the exercise of any powers under this section as they
apply to exercise of any powers under sections 55, [56, 57 or 57A]].[III. Control of camps, etc., and
Uniforms
63A. Control of camps, parades, etc., and banning use of uniform, etc. - (1) If
the State Government is satisfied that it is necessary in the interest of the
maintenance of public order so to do, it may by general or special order,
prohibit or restrict throughout the [State of Maharashtra] or any part thereof
all meetings and assemblies of persons for the purpose of training or drilling
themselves or being trained or drilled to the use of arms, or for the purpose
of practising military exercise, movements or evolution or for the purpose
aforesaid of attending or holding or taking any part in any camp, parade or
procession.
(2)If the State Government is satisfied that the wearing in public by any member of the body or
association or organisation to be specified in the order to be issued hereunder of any dress or article
of apparel resembling any uniform or part of uniform required to be worn by a member of theBombay Police Act, 1951

Armed Forces of the Union or by a member of the Police Force or of any force constituted under any
law for the time-being in force, would be likely to prejudice the security of the State or the
maintenance of public order, the State Government may, by general or special order, prohibit or
restrict the wearing, or display in public, of any such dress or article of apparel by any member of
such body or association or organisation.(3)Every general or special order under sub-sections (1)
and (2) shall be published in the manner prescribed for the publication of a public notice under
section 163.Explanation. - For the purposes of sub-section (2), a dress or an article of apparel shall
be deemed to be worn or displayed in public, if it is worn or displayed in any place to which the
public have access.][IV. Village Defence Parties
63B. Constitution of Village defence parties. - (1) For the protection of
persons, the security of property and the public safety in villages, the
[Superintendent] may constitute voluntary bodies, hereinafter in this section
called "Village defence parties", for any villages within his jurisdiction, as he
deems fit.
(2)Subject to any general or special orders which the State Government may make in this behalf,
every person between the ages of 20 and 50 and residing in a village and who in the opinion of the
[Superintendent] is a fit and proper person having regard to the nature of duties and functions to be
performed under the provisions of this section shall be eligible for appointment as a member of the
village defence party constituted for this village.(3)The [Superintendent] may by a written order
signed by himself, and sealed with his own seal, appoint any person eligible under sub-section (2) to
be a member of a village defence party.(4)For each village party the [Superintendent] shall appoint a
person eligible under sub-section (2) to be an honorary commandant called the Kotwal.(5)For the
direction and supervision of village defence parties in a taluka, the [Superintendent] may appoint a
police officer, not below the rank of Head Constable, to be a Taluka Village Defence Officer, and any
person who is willing to serve and in the opinion of the [Superintendent] is fit to be a Joint Taluka
Village Defence Officer.(6)For the direction and supervision of village defence parties in a district,
the [Superintendent] may appoint a police officer, not below the rank of Sub-Inspector to be a
District Village Defence Officer, and any person who is willing to serve and in the opinion of the
[Superintendent] is fit, to be a Joint District Village Defence Officer.(7)Members of village defence
parties and officers, appointed under this section shall be under the direction and control of the
[Superintendent] and shall receive such training, and discharge such duties, as may be determined
by the [Superintendent],(8)Members of village defence parties and officers (other than police
officers) appointed under this section, shall be subject to such terms and conditions of service as
may be determined with the previous approval of the State Government, by the
[Superintendent].(9)The [Superintendent] or any officers appointed under this section may at any
time call out officers subordinate to them, or any members of a village defence party for training or
to discharge the duties assigned to them.(10)Every member of a village defence party and every
officer appointed under this section shall,-(a)on appointment receive a certificate in a form
approved by the State Government in this behalf;(b)when called out for duty, have the same powers,
privileges and protection as a Police Officer appointed under this Act.(11)Notwithstanding anything
contained in any law for the time being in force, a member of a village defence party or any officerBombay Police Act, 1951

(other than a Police Officer) appointed under this section, shall not be disqualified from being
chosen as, or for being a member of-(a)the [Maharashtra] Legislative Assembly or the
[Maharashtra] Legislative Council, or(b)any local authority,by reason only of the fact that he is a
member of a village defence party or such officer.[(12) In such districts as the State Government
may by notification in the Official Gazette specify, the powers, duties and functions of the
[Superintendent], District Village Defence Officer and Taluka Village Defence Officer under this
section shall be exercised, performed and discharged by such officers of the Home Guards as the
Commandant General appointed under the Bombay Home Guards Act, 1947 may direct, and
thereupon all the foregoing provisions of this section shall apply but, references therein to the
[Superintendent], District Village Defence Officer and Taluka Village Defence Officer shall be
deemed to be references to the relevant officers of the Home Guards].
Chapter VI
Executive Powers and Duties of the Police
64. Duties of a Police Officer. - It shall be the duty of every Police Officer-
(a)promptly to serve every summons and obey and execute every warrant or other order lawfully
issued to him by competent authority, and to endeavour by all lawful means to give effect to the
lawful commends of his superior;(b)to the best of his ability to obtain intelligence concerning the
commission of cognizable offences or designs to commit such offences, and to lay such information
and to take such other steps, consistent with law and with the orders of his superior as shall be best
calculated to bring offenders to justice or to prevent the commission of cognizable and within his
view of non-cognizable offences;(c)to prevent to the best of his ability the commission of public
nuisances;(d)to apprehend without unreasonable delay all persons whom he is legally authorised to
apprehend and for whose apprehension there is sufficient reason;(e)to aid another Police Officer
when called on by him or in case of need in the discharge of his duty, in such ways as would be
lawful and reasonable on the part of the officer aided;(f)to discharge such duties as are imposed
upon him by any law for the time being in force.
65. Power to enter places of public resort. - (1) Every Police Officer, may,
subject to the rules and orders made by the State Government or by a person
lawfully authorised, enter for any of the purposes referred to in section 64
without a warrant, and inspect any place of public resort which he has
reason to believe is used as drinking shop, or a shop for the sale of
intoxicating drugs or a place of resort of loose and disorderly characters.
Power to search suspected persons in a street(2)When in a street or a place of public resort a person
has possession or apparent possession of any article which a Police Officer in good faith suspects to
be stolen property, such Police Officer may search for and examine the same and may require an
account thereof, and should the account given by the possessor by manifestly false or suspicious,Bombay Police Act, 1951

may detain such article and report the facts to a Magistrate, who shall thereon proceed according to
sections 523 and 525 of the Code of Criminal Procedure, 1898, or other law in force.
66. Duties of Police Officers towards the Public. - It shall be the duty of every
Police Officer,-
(a)to afford every assistance within his power to disabled or helpless persons in the streets, and to
take charges of intoxicated persons and of lunatics at large who appear dangerous or incapable of
taking care of themselves;(b)to take prompt measures to procure necessary help for any person
under arrest or in custody, who is wounded or sick and whilst guarding or conducting any such
person, to have due regard to his condition;(c)to arrange for the proper sustenance and shelter of
every person who is under arrest or in custody;(d)in conducting searches, to refrain from needless
rudeness and the causing of unnecessary annoyance;(e)in dealing with women and children to act
with strict regard to decency and with reasonable gentleness;(f)to use his best endeavours to prevent
any loss or damage by fire;(g)to use his best endeavours to avert any accident or danger to the
public.
67. Police to regulate traffic, etc. in streets. - It shall be the duty of a Police
Officer -
(a)to regulate and control the traffic in the streets, to prevent obstructions therein and to the best of
his ability, to prevent the infraction of any rule or order made under this Act or any other law in
force for observance by the public in or near the streets;(b)to keep order in the streets and at and
within public bathing, washing and landing places, fairs, temples and all other places of public
resort and in the neighbourhood of places of public worship during the time of public worship;(c)to
regulate resort to public bathing, washing and landing places, to prevent overcrowding thereat and
in public ferry-boats and, to the best of his ability, to prevent the infraction of any rule or order
lawfully made for observance by the public at any such place or on any such boat.
68. Persons bound to conform to reasonable orders of Police. - All persons
shall be bound to conform to the reasonable directions of a Police Officer
given in fulfilment of any of his duties under this Act.
69. Power of Police Officer to restrain, remove, etc. - A Police Officer may
restrain or remove any person resisting or refusing or omitting to conform to
any direction referred to in section 68 and may either take such person
before a Magistrate or, in trivial cases, may release him when the occasion is
past.Bombay Police Act, 1951

70. Enforcement of orders issued under sections 37, 38 or 39. - Whenever a
notification has been duly issued under section 37 or an order has been
made under section 38 or 39 it shall be lawful for any Magistrate in a District
or Police Officer to require any person acting or about to act contrary thereto
to desist or to abstain from so doing, and in case of refusal, or disobedience,
to arrest the person offending. Such Magistrate or Police Officer may also
seize any object or thing used or about to be used in contravention of such
notification, or order as aforesaid, and the thing seized shall be disposed of
according to the order of any District Magistrate having jurisdiction at the
place.
71. Duty of Police to see orders issued under sections 43, 55, 56, [57, 57A or
63AA] are carried out. - It shall be the duty of the Police to see that every
regulation and direction made by any authority under sections 43, 55, 56, [57,
57A or 63AA] is duly obeyed to warn persons who from ignorance fail to
obey the same and to arrest any person who wilfully disobeys the same.
72. When Police Officer may arrest without warrant. - Any Police Officer may,
without any order from a Magistrate and without a warrant, arrest-
(1)any person who has been concerned in an offence punishable under section 121 or against whom
reasonable complaint has been made or credible information has been received or a reasonable
suspicion exists, of his having been concerned in such offence;(2)any person who contravenes a rule
or order under clause (x) of sub-section (1) of section 33 or an order or notification under sections
36, 37, 56, [57, 57A or 63AA].[(2A) any person who contravenes any order made under sub-section
(1) of section 63A;](3)any person who commits an offence punishable under section 122 or section
136.
73. When Police may arrest without a warrant. - Any Police Officer may,
without an order from a Magistrate and without a warrant, arrest any person
committing in his presence any offence punishable under [clauses (a), (b),
(c), (d), (e), (f), (g), (h), (i), (j), (k) or (m) of sub-section (1) of section 11 of the
Prevention of Cruelty to Animals Act, 1960].
73A. [Extension of section 6B of Act XI of 1890 as in force in
pre-Reorganisation State to rest of the State for the purposes of sections 74
to 77]. Deleted by Maharashtra 24 of 1964, Section 3.Bombay Police Act, 1951

74. Powers with regard to offences under [Act LIX of 1960]. - When in respect
of an animal an offence under [sub-section (1) of section 11 or section 12 of
the Prevention of Cruelty to Animals Act, 1960 (hereinafter in this section and
in sections 75 and 77 referred to as 'the said Act')] has been committed, or,
when there is reasonable ground for suspecting that such offence has been
committed, a Police Officer may-
(a)take the animal to a Magistrate, or(b)if the accused person so requires take the animal to a
veterinary officer, if any, empowered by the State Government in this behalf, or(c)take the animal to
an infirmary appointed under [section 35] of the said Act for treatment and detention therein,
pending direction of a Magistrate under [* * * * *] the said section, or(d)when the animal is in such a
physical condition that it cannot be taken to a veterinary officer or a Magistrate, draw up a report of
the condition of the animal in the presence of two or more respectable persons describing such
wounds, sores, fractures, bruises or other marks of injury as may be found on the body of the
animal:Provided that in cases falling under clause (b) or (d) the Police Officer may direct that the
animal shall be sent for detention in a dispensary or any suitable place approved by the State
Government by general or special order and be there detained until its production before a
Magistrate:Provided further that an animal so detained shall be produced before a Magistrate with
the least possible delay and within a period not exceeding three days from the date on which it was
sent for detention and shall be handed over to its owner unless the Magistrate passes an order for its
further detention in an infirmary.
75. Power of Magistrate to return animal to person from whose possession it
was taken. - When an animal is brought before a Magistrate under section 74,
the Magistrate may direct the animal to be returned to the person from whose
possession it was taken, on such person giving security to the satisfaction of
the Magistrate binding from himself to produce the animal when required, or
may direct that the animal shall be sent for treatment and care to an infirmary
and be there detained as provided in [section 35] of the said Act or may make
such order as he thinks fit regarding the disposal or custody and production
of the animal.
76. Veterinary Officer to examine the animal. - The veterinary officer before
whom an animal is brought under section 74 shall with all convenient speed
examine the same and draw up a report of such examination. A copy of the
report shall be delivered free of charge to the accused person, if he applies
for it.Bombay Police Act, 1951

77. Animal to be dealt with under [Act LIX of 1960]. - When under section 74 a
Police Officer directs that an animal shall be sent for detention in a
dispensary or any suitable place before its production before a Magistrate or
under section 74 a Magistrate directs that an animal shall be sent for
treatment and care to an infirmary and be detained therein the provisions of
[section 35] of the said Act, shall, so far as may be, apply.
78. Power of Police Officer to unsaddle the animal or unload. - When a Police
Officer in good faith suspects that any animal being employed in any work or
labour is, by reason of any sore, unfit to be so employed, he may require the
person in charge of such animal to unsaddle or unload it for the purpose of
ascertaining whether any sore exists and, if any person refuses to do so,
may himself unsaddle or unload the animal or may cause the same to be
unsaddled or unloaded.
[79. Power of Police to arrest without warrant when certain offences committed in his presence. -
Any Police Officer may, without an order from a Magistrate and without a warrant, arrest any
person committing in his presence any offence punishable under section 117 or section 125 or
section 130 or sub-clauses (i), (iv) or (v) of section 131 or clause (i) of section 135 in respect of
contravention of any order made under section 39 or 40].
80. Other powers of arrest. - (1) Any Police Officer specially employed in this
behalf by a competent authority may arrest without warrant for an offence
specified in section 110.
(2)Any Police Officer may, on the information of any person in possession, or charge of any dwelling
house, private premises or land ground attached thereto, arrest without warrant any person alleged
to have committed therein or thereon an offence punishable under section 120.
81. Refusal to obey warning or to accompany Police. - A Police Officer may
arrest without warrant any person committing in his presence in any street or
public place any non-cognizable offence punishable under this Act, or under
any rule thereunder and for which no express provision has been made
elsewhere or under any other law for the time being in force, if such person -
(i)after being warned by a Police Officer persists in committing such offence, or(ii)refuses to
accompany the Police Officer to a Police Station on being required so to do.Bombay Police Act, 1951

82. Police to take charge of unclaimed property. - (1) The Police shall take
temporary charge-
(a)of all unclaimed property found by, or made over to them, and also(b)of all property found lying
in any public street, if the owner or person in charge of such property on being directed to remove
the same, refuses or omits to do so.(2)[In any area for which a Commissioner has been appointed]
the property of which the Police have taken charge under sub-section (1) shall be handed over to the
Commissioner.
83. Intestate property over four hundred rupees in value. - (1) [In any area
under the charge of a Commissioner] if any property of the nature referred to
in section 82 appears to have been left by a person who has died intestate,
and not to be under four hundred rupees in value, the Commissioner shall
communicate with the Administrator-General with a view to its being dealt
with under the provisions of the Administrator-General's Act, 1913, or other
law for the time being in force.
(2)[In areas outside the charge of a Commissioner] the property shall be delivered to the
police-patel, if any, of the town or village in which the same was found, and a receipt therefor taken
from the police-patel, who shall forward such property to the Magistrate to whom such police-patel
is subordinate. If in any such case there be no police-patel of such town or village, the Police shall
forthwith report to such Magistrate the Magistrate of the district shall, from time to time, appoint in
this behalf, and act thereafter as the said first mentioned Magistrate shall direct.
84. Intestate property over four hundred rupees in value. - If the property
regarding which a report is made to a Magistrate under section 83 or under
section 19 of the Bombay Village Police Act, 1867, [or of that Act as in force
in the Kutch area of the State of Bombay, or under section 21 of the
Saurashtra Village Police Ordinance, 1949,] appears to such Magistrate to
have been left by a person who has died intestate and without known heirs
and to be likely, if sold in public auction, to realise more than four hundred
rupees net proceeds, he shall communicate with the District Judge with a
view to its being dealt with under the provision of section 10 of Bombay
Regulation VIII of 1827 (Regulation to provide for the formal recognition of
heirs, etc.) or other law in force.
85. Procedure in other cases. - (1) In any case not covered by section 83 or
84, the Commissioner [, the Superintendent] or the Magistrate concerned, as
the case may be, shall issue a proclamation specifying the articles of whichBombay Police Act, 1951

such property consists, and requiring any person who may have a claim
thereto to appear before himself of some other officer whom he appoints in
this behalf and establishes his claim within [two months] from the date of
such proclamation.
Power to sale perishable property at once(2)If the property, or any part thereof, is subject to speedy
and natural decay, or consists of live-stock, or if the property appears to be of less value than [two
thousand and five hundred rupees], it may be forthwith sold by auction under the orders of the
Commissioner [, the Superintendent] or the Magistrate concerned, as the case may be, and the net
proceeds of such sale shall be dealt with in the same manner as is hereinafter provided for the
disposal of the said property.
86. Delivery of property to person entitled. - (1) The Commissioner [or, the
Superintendent] or the Magistrate concerned, as the case may be, shall, on
being satisfied of the title of any claimant to the possession or administration
of the property specified in the proclamation issued under sub-section (1) of
section 85, order the same to be delivered to him, after deduction or payment
of the expenses properly incurred by the Police in the seizure and detention
thereof.
Power to take security(2)The Commissioner [or, the Superintendent] or the Magistrate concerned,
as the case may be, may, at his discretion, before making any order under sub-section (1), take such
security as he may think proper from the person to whom the said property is to be delivered, and
nothing hereinbefore contained shall affect the right of any person to recover the whole or any part
of the same from the person to whom it may have been delivered pursuant to such order.
87. In default of claim, Property to be at disposal of State Government. - If no
person establishes his claim to such property within the period specified in
the proclamation it shall be at the disposal of the State Government, and the
property, or such part thereof as has not already been sold under
sub-section (2) of section 85, may be sold by auction under the orders of the
Commissioner [or, the Superintendent], or the Magistrate concerned, as the
case may be.
88. Procedure not affected by Indian Succession Act or
Administrator-General's Act or Regulation VIII of 1827 [or corresponding
law]. - Nothing in the Indian Succession Act, 1925, or in the
Administrator-General's Act, 1913, shall apply to intestate property which is
dealt with by the Commissioner under sub-section (1) of section 85, nor shallBombay Police Act, 1951

the provisions of section 10 of Regulation VIII of 1827 [or of any
corresponding law in force] likewise be deemed to apply to intestate property
which is dealt with by a Magistrate under sub-section (1) of section 85.
89. Police Officer may take charge of stray cattle. - [In any areas outside the
charge of a Commissioner] a Police Officer may take charge of any animal
falling under the provisions of the Cattle Trespass Act, 1871, [ [* * * * * or,] as
the case may be, under the Hyderabad Cattle Trespass Act,] which may be
found straying in a street, and may take or send the same to the nearest
pound, and the owner and other persons concerned shall thereon become
subject to the provisions of the [relevant Act.]
90. Power to establish cattle-pounds and appoint pound-keepers. - (1) [In any
area [(other than Greater Bombay)] under the charge of a Commissioner], the
Commissioner [* * * *] shall, from time to time, appoint such places as he
thinks fit to be public pounds, and may appoint to be keepers of such
pounds Police officers of such rank as may be approved by the State
Government.
(2)Every pound-keeper so appointed shall, in the performance of his duties' be subject to the
direction and control of the Commissioner, [* *].[90A. Penalty for allowing cattle to stray into street
or trespass upon private or public property. - (1) Whoever in [any area [(other than Greater
Bombay)] under the charge of a Commissioner] allows any cattle which are his property or in his
charge to stray in any street or to trespass upon any private or public property shall, on conviction,
be punished-(i)for the first offence, with imprisonment for a term which may extend to one month
or with fine which may extend to [three thousand rupees] or with both;(ii)for the second or
subsequent offence, with imprisonment for a term which may extend to six months or with fine
which may extend to [five thousand rupees] or with both.(2)The Magistrate trying the offence under
sub-section (1) may order,-(a)that the accused shall pay such compensation, not exceeding [two
thousand rupees] as the Magistrate considers reasonable, to any person for any damage proved to
have been caused to his property or to produce of land by the cattle under the control of the accused
trespassing on his land; and also(b)that the cattle in respect of which an offence has been committed
shall be forfeited to the State Government.(3)Any compensation awarded under sub-section (2) may
be recovered as if it were a fine imposed under this section.(4)An offence under this section shall be
cognizable].
91. Impounding of cattle. - It shall be the duty of every Police Officer, and it
shall be lawful for any other person, to seize, and take to any such public
pound for confinement therein, any cattle found straying in any street or
trespassing upon any private or public property in [any area [(other thanBombay Police Act, 1951

Greater Bombay)] under the charge of a Commissioner.].
[* * * * *]
92. Delivery of cattle claimed. - If the owner of the cattle impounded under
section 91 or his agent appears and claims the cattle, the pound-keeper shall
deliver them to him on payment of the pound-fees and expenses chargeable
in respect of such cattle under section 94.
93. Sale of cattle not claimed. - (1) If within ten days after an animal has been
impounded no person appearing to be the owner of such animal offers to pay
the pound-fee and expenses chargeable under section 94, such animal shall
be forthwith sold by auction, and the surplus remaining after deducting the
fee and expenses aforesaid from the proceeds of the sale shall be paid to any
person who, within fifteen days after the sale, proves to the satisfaction of
such officer as the Commissioner authorises in this behalf [*] that he was the
owner of such animal, and shall in any other case, form part of the
consolidated fund of the State.
(2)No Police Officer or pound-keeper shall, directly or indirectly, purchase any cattle at a sale under
sub-section (1).
94. Rate to be fixed by notification. - (1) The pound-fee chargeable shall be
such as the State Government may, from time to time, by notification in the
Official Gazette, specify for each kin of animal [* * *]
(2)The expenses chargeable shall be at such rates for each day during any part of which an animal is
impounded, as shall from time to time be fixed by the Commissioner [* * *] in respect of such
animal.
95. Powers as to inspection, search and seizure of false weights and
measures. - (1) Notwithstanding anything contained in section 153 of the
Code of Criminal Procedure, 1898, any Police Officer generally or specially
deputed, in [any area under the charge of a Commissioner], by the
Commissioner and elsewhere, by the [Superintendent] or any other officer
specially empowered in that behalf by the State Government, may without
warrant enter any shop or premises for the purpose of inspecting or
searching for any weights or measures or instruments for weighing or
measuring used or kept therein.Bombay Police Act, 1951

(2)If he finds in such shop or premises weights, measures or instruments, for weighing or measuring
which he has reason to believe are false, he may seize the same and shall forthwith give information
of such seizure to the Magistrate having jurisdiction, and if such weights, measures or instruments
shall be found by the Magistrate to be false, they shall be destroyed.(3)Weights and measures
purporting to be of the same denomination as weights and measures, the standards whereof are
kept under any law from time to time in force shall, if they do not correspond with the said
standards, be deemed to be false within the meaning of this section.
96. Procedure to be followed by officers and Magistrates in certain cases. -
(1) Notwithstanding anything contained in sections 129, 130, sub-section (2)
of section 167, and section 173 of the Code of Criminal Procedure, 1898-
(i)the powers and duties of a Magistrate under sections 129 and 130 of that Code may, in [any area
under the charge of a Commissioner] be exercised and performed by the Commissioner,(ii)the
Presidency Magistrate in Greater Bombay to whom an accused person is forwarded under
sub-section (2) of section 167 of the Code, may, whether he has or has not jurisdiction to try the
case, from time to time, authorise the detention of the accused in such custody as such Magistrate
thinks fit for a term not exceeding fifteen days at a time,(iii)the officer in charge of the Police Station
shall forward his report under section 173 of the Code to the Commissioner or such other officer as
the Commissioner may direct in that behalf.(2)Nothing contained in section 62 of the Code of
Criminal Procedure, 1898, shall operate to require any officer in charge of a Police Station [any area
under the discharge of a Commissioner] to submit any report provided for by that section to any
Magistrate.(3)Sections 127 and 128 of the Code of Criminal Procedure, 1898, in their application to
Greater Bombay [and any other area for which a Commissioner has been appointed] shall be
amended as follows:-(a)in section 127, for the words "police Station" the words "section or any
Police Officer not below the rank of a sub-inspector authorised by the State Government in this
behalf" shall be substituted;(b)in section 128, for the words "police station whether within or
without the presidency-towns "the words and figures" section or any Police Officer authorised under
section 127" shall be substituted.
97. A superior Police Officer may himself perform duties imposed on his
inferior; etc. - A. Police Officer of rank superior to that of constable may
perform any duty assigned by Law or by a lawful order to any officer
subordinate to him and in case of any duty imposed on such subordinate, a
superior where it shall appear to him necessary, may aid, supplement,
supersede or prevent any action of such subordinate by his own action or
that of any person lawfully acting under his command or authority, whenever
the same shall appear necessary or expedient for giving more complete or
convenient effect to the law or for avoiding as infringement thereof.Bombay Police Act, 1951

98. Emergency duties of Police. - (1) The State Government may, by
notification in the Official Gazette, declare any specified service to be an
essential service to the community:
Provided that such notification shall remain in force for one month in the first instance, but may be
extended, from time to time, by a like notification.(2)Upon a declaration being made under
sub-section (1) and so long as it remains in force, it shall be the duty of every Police Officer to obey
any order given by any superior officer in relation to employment upon or in connection with the
service specified in the declaration; and every such order shall be deemed to be a lawful order within
the meaning and for the purposes of this Act.
Chapter VII
Offences and Punishments
99. Disregarding the rule of the road. - No person shall-
(a)when driving a vehicle along a street and except in cases of actual necessity or of some sufficient
reason, for deviation, fail to keep on the left side of such street and when passing and other
proceeding in the same direction fail to keep on the right side of such vehicle; orLeaving cattle, etc.
insufficiently tended(b)leave in any street or public place insufficiently tended or secured any
animal or vehicle.
100. Causing obstruction or mischief by animal. - No person shall cause
obstruction, damage, injury, danger, alarm or mischief in any street or public
place,-
(i)by any misbehaviour, negligence or ill-usage in the driving, management, treatment or care of any
animal or vehicle; or(ii)by driving any vehicle or animal laden with timber, poles, or other unwidely
articles through a street or public place contrary to any regulation made in that behalf and published
by a competent authority.
101. Exposing animals for hire or sale, etc. - No person shall in any street or
public place expose for hire or sale any animal or vehicle, clean any furniture
or vehicle, or clean or groom any horse or other animal, except at such times
and places as a competent authority permits, or shall train or break in any
horse or other animal or make any vehicle or any part of a vehicle, or except
when in the case of an accident repairing on the spot is unavoidable, repair
any vehicle or part of a vehicle or carry on therein any manufacture or
operation so as to be a serious impediment to traffic or a serious annoyance
to residents or to the public.Bombay Police Act, 1951

102. Causing any obstruction in a street. - No person shall cause obstruction
in any street or public place by allowing any animal or vehicle which has to
be loaded or unloaded, or to take up or set down passengers, to remain or
stand therein longer than may be necessary of such purpose or by leaving
any vehicle standing or fastening any cattle therein, or using any part of a
street or public place as a halting place for vehicles or cattle, or by leaving
any box bale, package or other thing whatsoever in or upon a street for an
unreasonable length of time or contrary to any regulation made and
published by a competent authority by exposing anything for sale or setting
out anything for sale in or upon any stall, booth, board, cask, basket or in
any other way whatsoever.
103. Obstructing a footway. - No person shall drive, ride, lead, propel or leave
on any footway any animal or vehicle other than a perambulator or fasten any
animal so that the same can stand across or upon such footway.
104. Exhibiting mimetic, musical or other performances, etc. - No person
shall exhibit, contrary to any regulation made and notified by [the Revenue
Commissioner or the Commissioner] or a District Magistrate, as the case
may be, any mimetic, musical or other performances of a nature to attract
crowds, or carry or place bulky advertisements, pictures, figures or emblems
in any street or public place whereby an obstruction to passengers or
annoyance to the inhabitants may be occasioned.
105. Doing offensive acts on or near street or public place. - No person shall
slaughter any animal, clean a carcass or hide, or bathe or wash his person in
or near to and within sight of a street or public place (except at a place set
apart for the purpose by order of a competent authority) so as to cause
annoyance to the neighbouring residents or to passerby.
106. Letting loose horse, etc. and suffering ferocious dogs to be at large. - No
person shall in any street or public place (A) negligently let loose any horse
or other animal, so as to cause danger, injury, alarm or annoyance, or suffer
a ferocious dog to be at large without a muzzle or (8) set on or urge a dog or
other animal to attack, worry or put in fear any person or horse or other
animal.Bombay Police Act, 1951

107. Bathing or washing in places not set apart for those purposes. - No
person shall bathe or wash in or by the side of a public well, tank or reservoir
not set apart for such purposes by order of a competent authority, or in or by
the side of any pond, pool, aqueduct, part of a river, stream, nala or other
source or means of water-supply in which such bathing or washing is
forbidden by order of the competent authority.
108. Defiling Water in public wells, etc. - No person shall defile or cause to be
defiled, the water in any public well, tank, reservoir, pond, pool, aqueduct or
part of a river, stream, nala or other source or means of water-supply, so as
to render the same less fit for any purpose for which it is set apart by the
order of the competent authority.
109. Obstructing bathers. - No person shall obstruct or incommode a person
bathing at a place set apart for the purpose by the order of the competent
authority under section 107 by wilful intrusion or by using such place for any
purpose for which it is not so set apart.
110. Behaving indecently in public. - No person shall wilfully and indecently
expose his person in any street or public place or within sight of and in such
manner as to be seen from, any street or public place, whether from within
any house or building or not, or use indecent language or behave indecently
or riotously, or in a disorderly manner in a street or place of public resort or
in any office, station or station house.
111. Obstructing or annoying passengers in the street. - No person shall
wilfully push, press, hustle or obstruct any passenger in a street or public
place or by violent movements, menacing gestures, wanton personal
annoyance, screaming, shouting, wilfully frightening horses or cattle or
otherwise disturbs the public peace or other.
112. Misbehaviour with intent to provoke a breach of the peace. - No person
shall use in any street or public place any threatening, abusive or insulting
words or behaviour with intent to provoke a breach of the peace or whereby
a breach of the peace may be occasioned.Bombay Police Act, 1951

113. Prohibition against flying kite. - No person shall fly a kite so as to cause
danger, injury or alarm to persons [horses] or property.
114. [Begging and exposing offensive ailments] - Repealed by Bombay X of
1960, Section 1(4) Schedule.
115. Committing nuisance in or near street, etc. - No person shall in or near
to any street, public place or place of public resort-
(a)commit a nuisance by easing himself, or(b)having the case or custody of any child under seven
years of age suffer such child to commit a nuisance as aforesaid [or(c)spit or throw any dust, ashes,
refuse or rubbish so as to cause annoyance to any passerby.]
116. Disregard of notice in public building. - No person shall, in any Court,
Police Station, Police Office, building occupied by Government or building
occupied by any public body, smoke or spit in contravention of a notice by a
competent authority in charge of such place and fixed to such Court, Station,
office or building.
117. Penalties for offenders under Sections 99 to 116. - Any person who
contravenes any of the provisions of sections 99 to 116 (both inclusive) shall,
on conviction, be punished with fine which may extend to [twelve hundred
rupees].
118. Penalty for failure to keep in confinement cattle, etc. - (1) In any local
area in which the State Government by notification in the Official Gazette
brings this section into force, whoever through neglect or otherwise fails to
keep in confinement or under restraint between one hour after sunset and
sunrise any cattle which are his property or in his charge shall, on
conviction, [be punished,-
(i)for the offence, with imprisonment for a term which may extend to one month or with fine which
may extend to [four thousand rupees] or with both;(ii)for the second or subsequent offence, with
imprisonment for a term which may extend to six months or with fine which may extend to [five
thousand rupees] or with both.]Explanation. - Cattle shall not be deemed to be kept in confinement
within the meaning of this sub-section unless they are effectively confined within a fence, wall or
other enclosure and shall not be deemed to be kept under restraint within the meaning of this
sub-section unless they are restrained by means of a rope or other attachment.[(1A) The Magistrate
trying the offence under sub-section (1) may order,-(a)that the accused shall pay such compensation
not exceeding two hundred and fifty rupees, as the Magistrate considers reasonable to any personBombay Police Act, 1951

for any damage proved to have been caused to his property or to produce of land by the cattle under
the control of the accused trespassing on his land; and also(b)that the cattle in respect of which the
offence has been committed shall be forfeited to the State Government.(1B)Any compensation
awarded under sub-section (1A) may be recovered as if it were a fine imposed under this
section.(1C)The offence under this section shall be cognizable].(2)Any person may seize any cattle
not being kept in confinement or under restraint as required by this section and may take or send
the same to the nearest cattle-pound, and the owner and other persons concerned shall thereon
become subject to the provisions of the Cattle Trespass Act, 1891 [ [* * * *] or of the Hyderabad
Cattle Trespass Act, as the case may be]. All officers of Police and all police-patels and all members
of the village police shall when required, aid in preventing resistance to such seizures and rescues
from persons making such seizures.(3)Any fine imposed under this section, may without prejudice
to any other means of recovery provided by law, be recovered by sale of all or any of the cattle in
respect of which the offence was committed, whether they are the property of the person convicted
of the offence or were only in his charge when the offence was committed.
119. Punishment for cruelty to animals. - Whoever in any place [in any area
for which a Commissioner has not been appointed] cruelty beats, goads,
overworks, ill-treats or tortures, or causes procures to be cruelty beaten,
goaded, over-worked, ill-treated or tortured any animal, shall, on conviction,
be punished with imprisonment which may extend to one month or with fine
which may extend to [two thousand five hundred rupees], or with both.
120. Wilful trespass. - Whoever without satisfactory excuse wilfully enters or
remains in or upon any dwelling house or premises or any land or ground
attached thereto, or on any grounds, building, monument or structure
belonging to Government or appropriated to public purposes, or on any boat
or vessel, shall, on conviction, whether he causes any actual damage or not,
be punished with fine which may extend to [five thousand rupees].
121. False alarm of fire or damage to fire-alarm. - Whoever knowingly gives or
causes to be given a false alarm of fire to the fire brigade of a municipality or
corporation or to any officer or fireman thereof whether by means of a street
fire-alarm, statement, message or otherwise, or with intent to give such false
alarm, wilfully breaks the glass of, or otherwise damages a street fire-alarm,
shall, on conviction, be punished with imprisonment for a term which may
extend to three months or with fine which may extend to [three thousand
rupees] or with both.Bombay Police Act, 1951

122. Being found under suspicious circumstances between sunset and
sunrise. - Whoever is found between sunset and sunrise-
(a)armed with any dangerous instrument with intent to commit an offence; or(b)having his face
covered, or otherwise disguised, with intent to commit an offence; or(c)in any dwelling-house or
other building or on board any vessel or boat without being able satisfactorily to account for his
presence there, or(d)laying or loitering in any street, yard or other place, being a reputed thief and
without being able to give a satisfactory account of himself; or(e)having in his possession without
lawful excuse (the burden of proving which excuse shall be on such person) [any implement of
house-breaking,-shall, on conviction, be punished with imprisonment which may extend to one
year, but shall not, except for reasons to be recorded in writing, be less than one month] and shall
also be liable to fine which may extend to [one thousand rupees.]
123. Carrying weapon without authority. - Whoever not being a member of
the armed forces of the Union and acting as such or a Police Officer, goes
armed with any sword, spear, bludgeon, gun or other offensive weapon or
with any explosive or corrosive substance in any street or public place
unless so authorised by lawful authority, shall be liable to be disarmed by
any Police Officer, and the weapon or substance so seized shall be forfeited
to the State Government, unless redeemed within two months by payment of
such fine not exceeding [twelve thousand five hundred rupees] as the
Commissioner or the District Magistrate in areas under their respective
charges imposes.
124. Possession of property of which no satisfactory account can be given. -
Whoever has in his possession or conveys in any manner, or offers for sale
or pawn, anything which there is reason to believe is stolen property or
property fraudulently obtained, shall, if he failed to account for such
possession or to act to the satisfaction of the Magistrate, on conviction, be
punished with imprisonment for a term [which may extend to one year but
shall not, except for reasons to be recorded in writing, be less than one
month and shall also be liable to fine which may extend to [five thousand
rupees].]
125. Taking spirits into public hospitals or into barracks or on boards of
vessels of war. - Whoever-
(a)takes or introduces, or attempts to take or introduce, any spirits or spirituous or fermented
liquors or intoxicating drugs or preparations into any public hospitals without the permission of a
medical officer of such hospital, or(b)not being amendable to the Articles of War takes orBombay Police Act, 1951

introduces, or attempts to take or introduced, any such spirits, liquors, drugs or preparations not
belonging to any person above the rank of non-commissioned officer,(i)into the barracks or
buildings occupied by the troops composing the Garrison of Bombay or into any military barracks,
guard-rooms or encampments, or(ii)on board or alongside of any vessel of war belonging to
Government, shall, on conviction, be punished with imprisonment for a term which may extend to
two months, or with fine which may extend to [three thousand rupees], or with both and such spirit
is, liquor, drugs or preparation and the vessels containing the same, shall be forfeited to the State
Government.
126. Omission by pawn-brokers, etc. to report to Police possession or tender
of property suspected to be stolen. - Whoever, being a pawn-broker, dealer in
second-hand property, or worker in metals, or reasonably believed by the
Commissioner, or [Superintendent], in the areas under respective charges to
be such a person, and having received from a Police Officer written or
printed information that the possession of any property suspected to have
been transferred by any offence mentioned in section 410 of the Indian Penal
Code, or by any offence punishable under sections 417, 418, 419 or 420 of
the said Code, is found in possession or thereafter comes into the
possession or has an offer either by way of sale, pawn, exchange or for
custody, alteration or otherwise howsoever, made to him of Property
answering the description contained in such information, shall, unless-
(i)he forthwith gives information to the Commissioner, or the [Superintendent], as the case may be,
or at a Police Station of such possession or offer and takes all reasonable means to ascertain and to
give information as aforesaid of the name and address of the person from whom the possession or
offer was received; or(ii)the property being, as an article of common wearing apparel otherwise,
incapable of identification from the written or printed information given, has been in no way
concealed after the receipt of such information, on conviction, be punished with fine which may
extend to [two thousand rupees] in respect of each such article of property so in his possession or
offered to him.
127. Melting, etc., of such property. - Whoever, having received such
information as is referred to in section 126, alters, melts, defaces or puts
away or causes or suffers to be altered, melted, defaced or put away without
the previous permission of the Police any such property, shall, on proof that
the same was stolen property within the meaning of section 410 of the Indian
Penal Code, or property in respect of which any offence punishable under
sections 417, 418, 419 or 420 of the said Code has been committed, be
punished with imprisonment for a term which may extend to three years, or
with fine, or with both.Bombay Police Act, 1951

128. Taking pledge from child. - Whoever takes from any child not appearing
to be above the age of fourteen years any article whatsoever as a pawn,
pledge or security for any sum of money lent, advanced or delivered to such
child, or without the knowledge and consent of the owner of the article buys
from such child any article whatsoever shall, on conviction, be punished with
fine which may extend to [two thousand rupees].
129. Permission of disorderly conduct at places of public amusement, etc. -
Whoever, being the keeper of any place of public amusement or
entertainment, knowingly permits drunkenness or other disorderly behaviour
or any gaming whatsoever, in such place, shall, on conviction, be punished
with a fine which may extend to [two thousand five hundred rupees].
130. Cheating at games. - Whoever, by any fraud or unlawful device or
malpractice in playing at or with cards, dice or other game, or in taking a part
in the stakes or wagers, or in betting on the sides or hands of the players, or
in wagering on the event of any game, sport, pastime, or exercise, wins from
any other person, for himself or any other or others, any sum of money or
valuable thing, shall be deemed guilty of cheating within the meaning of
section 415 of the Indian Penal Code, and shall be liable to punishment
accordingly.
[130A. Gambling in street. - Whoever assembles with others or joins any assembly in a street
assembled for the purpose of gaming or wagering shall, on conviction, be punished with fine which
may extend to [two thousand five hundred rupees] or may be released after a due admonition].
131. Penalty for contravening rules, etc., under section 33. - [ [Save as
provided in section 131A, whoever]-
(a)contravenes any rule or order made under section 33 or any of the conditions of a licence issued
under such rule or order; or(b)abets the commission of any offence under clause (a) shall, on
conviction, be punished] -(i)if the rule or order under which the said licence was issued was made
under clauses (b), (g), (b), (i), sub-clauses (i) and (ii) of clause (r) or clause (u) of sub-section (1) of
section 33, with imprisonment for a term which may extend to eight days or with fine which may
extend to [one thousand two hundred fifty rupees] or with both;[(ia) if the rule or order which the
said licence was issued was made under sub-clause (iii) of clause (r), of sub-section (1) of section 33,
with imprisonment for a term which may extend to three months or with fine which may extend to
two thousand rupees or with both.](ii)if the rule or order contravened was made under clause [(wb)
or (x)] of sub-section (1) of section 33, with imprisonment for a term which may extend to three
months or with fine which may extend to [twelve thousand five hundred rupees] or with, both;(iii)ifBombay Police Act, 1951

the rule or order contravened or the rule or order under which the said licence was issued was made
under clauses (n) and (o) of sub-section (1) of section 33 with fine which may extend to [five
thousand rupees];(iv)if the rule or order contravened was made under clause (b) of sub-section (1)
of section 33 and prohibits the sale or exposure for sale of any goods on any street or portion thereof
so as to cause obstruction to traffic or inconvenience to the public-(a)for the first offence, with
imprisonment for a term which may extend to one month or with fine which may extend to [two
thousand five hundred rupees] or with both, and(b)for a subsequent offence, with imprisonment for
a term which may extend to six months and with fine which may extend to [five thousand rupees];
and(v)if the rule or order contravened or the rule or order under which the said licence was issued
[was made under any clause of sub-section (1) section 33 and for the contravention of which no
penalty is provided for under this section], with fine which may extend to [five hundred
rupees].[131AA. Liability of licensee of place of public entertainment for acts of servants. - The
holder of a licence, granted under this Act, in respect of a place of public entertainment [or a place in
which a dancing school is conducted] shall be responsible, as well as the actual offender, for any
offence under section 131 committed by his servant or other agent acting with his express or implied
permission on his behalf, as if he himself had committed the same unless he establishes that, all due
and reasonable precautions were taken by him to prevent the commission of such offence].[131A.
[Penalty for not obtaining licence in respect of place of public entertainment or certificate or
registration in respect of eating house or for not renewing such licence or certificate within
prescribed period]. - (1) Whoever fails to obtain a licence under this Act in respect of place of public
entertainment [or a place in which a dancing school is conducted] [or a certificate of registration
thereunder in respect of any eating house, or to renew the licence or the certificate, as the case may
be,] within the prescribed period shall, on conviction, be punished with a fine which may extend to
[two thousand rupees.](2)Any Court trying any such offence shall in addition direct that the person
keeping the place of public entertainment, [or the eating house,] [or conducting a dancing school],
in respect of which the offence has been committed shall [close such place, dancing school, or as the
case may be, [or eating house] until he obtains a licence or fresh licence, [or certificate of
registration, fresh registration certificate, as the case may be, in respect thereof and thereupon such
person shall forthwith comply with such direction].(3)If the person fails to comply with any such
direction he shall, on conviction, be punished with imprisonment for a term which may extend to
one month or with fine which may extend to [five thousand rupees] or with both.(4)Without
prejudice to any action taken under sub-section (3), on the failure of such person to comply with the
direction of the Court any Police Officer authorised by the Commissioner or the District Magistrate,
as the case may be, by an order in writing, may take or cause to be taken such steps and use or cause
to be used such force as may, in the opinion of such officer, be reasonably, necessary for securing
compliance with the Court's direction.]
132. Penalty for disobedience to order under section 31. - Whoever
contravenes, disobeys, opposes, or fails to conform to an order under
section 31 requiring him to vacate any premises, shall, on convictions be
punished with imprisonment which may extend to three months, or with fine
which may extends [five thousand rupees] or with both.Bombay Police Act, 1951

133. Penalty for contravening rules, etc., under section 35. - Whoever
contravenes any rule made under section 35 shall, on conviction, be
punished with imprisonment for a term which may extend to three months or
with fine which may extend to [five thousand rupees] or with both.
134. Penalty for contravention of rule etc., under section 36. - Whoever
contravenes, disobeys, opposes or fails to conform to any order given by a
Police Officer under section 36 shall, on conviction, be punished with fine
which may extend to [five thousand rupees].
135. Penalty for contravention of rules or directions under sections 37, 39 or
40. - Whoever disobeys an order lawfully made under sections, 37, 39 or 40
or abets the disobedience thereof shall, on conviction, be punished-
(i)if the order disobeyed or of which the disobedience was abetted was made under sub-section (1) of
section 37 or under section 39, or section 40, with imprisonment for a term which may extend to
one year but shall not except for reasons to be recorded in writing, be less than four months and
shall also be liable to fine, and(ii)if the said order was made under sub-section (2) of section 37, with
imprisonment for a term which may extend to one month or with fine which may extend to [two
thousand five hundred rupees]; and(iii)if the said order was made under sub-section (3) of section
37, with fine which may extend to [two thousand five hundred rupees].
136. Penalty for contravening rules, etc., made under Section 38. - Whoever
disobeys any direction lawfully made under section 38 or abets the
disobedience thereof shall, on conviction, be punished with imprisonment
for a term which may extend to three months or with fine which may extend
to [five thousand rupees] or with both.
137. Penalty for contravening rules, etc. made under Section 41. - Whoever
opposes or fails to conform to any direction given by the Police under
section 41 shall, on conviction, be punished with fine which may extend to
[five hundred rupees].
138. [Penalty for failure to comply with order under section 42] - Deleted by
Maharashtra 28 of 1964, Section 9.
139. Penalty for contravention of a regulation made under section 43. -
Whoever contravenes or abets the contravention of any regulation made
under section 43 shall, on conviction, be punished with imprisonment whichBombay Police Act, 1951

may extend to three months or with fine which may extend to [two thousand
five hundred rupees], or with both.
140. Penalty for contravening directions under section 68. - Whoever
opposes or fails to conform to any direction given by the Police under
section 68 or abets the opposition or failure to do so shall, on conviction, be
punished with fine which may extend to [five hundred rupees].
141. Penalty for contravention of directions under sections 55, 56, [57, 57A or
63AA]. - Whoever opposes or disobeys or fails to conform to any direction
issued under sections 55, 56, [57, 57A or 63AA] or abets opposition to or
disobedience of any such direction shall, on conviction, be punished with
imprisonment which may extend to one year but shall not, except for reasons
to be recorded in writing, be less than four months, and shall also be liable to
fine.
[142. Penalty for entering without permission area from which a person is directed to remove
himself or overstaying when permitted to return temporarily, [or for failure to report place or
residence or departure or arrival]. - Without prejudice to the power to arrest and remove a person in
the circumstances and in the manner provided in section 62, any person who-(a)in contravention of
a direction issued to him under sections 55, 56, [57, 57A or 63AA] enters or returns without
permission to the area, or any district or districts or part thereof [or to any specified area or areas,]
from which he was directed to remove himself;(b)enters or returns to any such area or district
aforesaid or part thereof [or to any such specified area or areas,] with permission granted under
sub-section (2), of section 62 but fails, contrary to the provisions thereof, to remove himself [outside
such area, district or part thereof or outside such specified area or areas, as the case may be,] at the
expiry of the temporary period for which he was permitted to enter or return or on the earlier
revocation of such permission, or having removed himself at the expiry of such temporary period or
on revocation of the permission, enters or returns thereafter without fresh permission;[(c) fails,
without sufficient cause, to make a report about his place of residence or about his date of departure
or arrival as required by sub-section (2) of section 56 or of section 57,]shall on conviction, be
punished with imprisonment for a term which may extend to two years, but shall not, except for
reasons to be recorded in writing, be less than six months, and shall also be liable to fine];
143. Penalty for failure to surrender in accordance with sub-section (3) of
section 63. - Whoever fails without sufficient cause to surrender in
accordance with sub-section (3) of section 63 shall, on conviction, be
punished with imprisonment which may extend to two years and shall also
be liable to fine.Bombay Police Act, 1951

[143A. Penalty for contravention of order under section 63A. - (1) Whoever contravenes any order
made under sub-section (1) of section 63A shall, on conviction, be punished with imprisonment for
a term which may extend to one year or with fine or with both.(2)Whoever contravenes any order
made under sub-section (2) of section 63A shall, on conviction, be punished with imprisonment for
a term which may extend to three years or with fine or with both.][143B. Dangerous performances. -
(1) No person shall without the previous permission of the Commissioner or the District Magistrate,
as the case may be, and except in accordance with any conditions subject to which such permission
is granted hold or give in any place which is likely to cause an assembly of persons, any performance
in which or during which he buries himself underground, or seals himself in receptacle or other
thing, in such manner as to prevent all access of air to him and for such time as would ordinarily
result in death by suffocation.(2)If any person contravenes or attempts to contravene the provisions
of this section, he shall, on conviction, be punished with imprisonment for a term which may extend
to one year or with fine, or with both.(3)Notwithstanding anything contained in the [Code of
Criminal Procedure, 1898,] the offence punishable under this section shall be cognizable.]
144. Neglect or refusal to serve as Special Police Officer. - Any person who
having been appointed a Special Police Officer under section 21 shall,
without sufficient cause, neglect or refuse to serve as such or to obey any
lawful order or direction that may be given to him for the performance of his
duties shall, on conviction, be punished with fine which may extend to [two
thousand rupees].
145. Penalty for making false statement, etc., and for misconduct of Police
Officers. - (1) Any person who makes a false statement or uses a false
document for the purpose of obtaining employment or release from
employment as a Police Officer, or
(2)Any Police Officer who (a) is guilty of cowardice, or (b) resigns his office or withdraws himself
from duties thereof in contravention of section 29, or (c) is guilty of any wilful-breach or neglect of
any provision of law or of any rule or order which as such Police Officer, it is his duty to observe or
obey, or (d) is guilty of any violation of duty for which no punishment is expressly provided by any
other law in force, shall, on conviction, be punished with imprisonment for a term which may
extend to three months, or with fine which may extend to one hundred rupees, or with
both.Consequence of failure to return to duty after leave(3)A Police Officer who being absent on
leave fails, without reasonable cause, to report himself for duty on the expiration of such leave shall,
for the purpose of clause (b) of sub-section (2), be deemed to withdraw himself from the duties of
his office within the meaning of section 29.
146. Penalty for failure to deliver up certificate of appointment or of office or
other article. - Any Police Officer, who wilfully neglects or refuses to deliver
up his certificate of appointment or of office or any other article, inBombay Police Act, 1951

accordance with the provisions of sub-section (i) of section 30, shall, on
conviction, be punished with imprisonment for a term which may extend to
one month, or with fine which may extend to two hundred rupees, or with
both.
147. Vexatious entry search, arrest, etc., by Police Officer. - Any Police
Officer who-
(a)without lawful authority or reasonable cause enters or searches, or causes to be entered or
searched, any building, vessel, tent or place;(b)vexatiously and unnecessarily seizes the property of
any person;(c)vexatiously and unnecessarily detains, searches or arrests any person;(d)offers any
unnecessary personal violence to any person in his custody, or(e)holds out any threat or promise not
warranted by law,shall for every such offence, on conviction, be punished with imprisonment for a
term which may extend to six months or with fine which may extend to five hundred rupees, or with
both.
148. Penalty for vexatious delay in forwarding a person arrested. - Any Police
Officer who vexatiously and unnecessarily delays forwarding any person
arrested to a Magistrate or to any other authority to whom he is legally bound
to forward such person, shall, on conviction, be punished with imprisonment
for a term which may extend to six months or with fine which may extend to
five hundred rupees, or with both.
149. Penalty for opposing or not complying with direction given under
section 70. - Whoever opposes or fails forthwith to comply with any
reasonable direction given by a Magistrate or a Police Officer under section
70 or abets opposition thereto or failure to comply therewith, shall, on
conviction, be punished with imprisonment for a term which may extend to
one year but shall not except for reasons to be recorded in writing by less
than four months and shall also be liable to fine.
[149A. Penalty for an unauthorised use of Police uniform. - If any person not being a member of the
Police Force, wears, without the permission of an officer authorised by the State Government in this
behalf by a general or special order for any area [in the [State of Maharashtra] ] the uniform of the
Police Force or any dress having the appearance or bearing any of the distinctive marks of that
uniform, he shall, on conviction, be punished with fine which may extend to [two thousand rupees].]Bombay Police Act, 1951

150. Jurisdiction when offender is a Police Officer above the rank of
constable. - Offences against this Act, when the accused person or any one
of the accused persons is a Police Officer above the rank of a constable,
shall not be cognizable except by a Presidency Magistrate or a Magistrate not
lower than a Second Class Magistrate.
151. Prosecution for certain offences against the Act to be in the discretion
of the Police. - It will not, except in obedience to a rule or order made by the
State Government or by the competent authority, be incumbent on the Police
to prosecute for an offence punishable under sections 117, 119, 131, 134,
137, 139, 140 or 144 when such offence has not occasioned serious mischief
and has been promptly desisted from on warning given.
[151A. Summary disposal of certain cases. - (1) [A Court taking cognizance of an offence punishable
under section 117, or under [sub-clauses] (iii), (iv) or (v) of section 131], may state upon the
summons to be served on the accused person that he may, by a specified date prior to the hearing of
the charge plead guilty to the charge by registered letter and remit to the Court such sum, not
exceeding [two thousand rupees], as the Court may specify.(2)Where an accused person pleads
guilty and remits the sum specified, no further proceedings in respect of the offence shall be taken
against him.]
152. Prosecution for offences under other enactments not affected. - Nothing
in this Act shall be construed to prevent any person from being prosecuted
and punished under any other enactment for any offence made punishable
by this Act or from being prosecuted and punished under this Act for an
offence punishable under any other enactment:
Provided that all such cases shall be subject to the provisions of section 103 of the [Code of Criminal
Procedure, 1898].
Chapter VIII
Miscellaneous
153. Disposal of fees, rewards, etc. - All fees paid for licences or written
permissions issued under this Act, and all sums paid for the service of
processes by Police Officers, and all rewards, forfeitures and penalties or
shares thereof which are by law payable to Police Officers as informers,
shall, save in so far as any such fees or sums belong under the provisions ofBombay Police Act, 1951

any enactment in force to any local authority, be credited to the State
Government:
Provided that with the sanction of the State Government, or under any rule made by the State
Government in that behalf, the whole or any portion of any such reward, forfeiture or penalty may,
for special services, be paid to a Police Officer, or be divided amongst two or more Police Officers.
154. No municipal or other rates to be payable by State Government on
Police buildings. - No municipal or other local rates shall be payable by the
State Government on account of the occupation or use of any house or place
[by members of the Police Force for the convenient performance of their
duties, in any area of the [Bombay area of the State of Maharashtra
excluding] Greater Bombay, and also in such of the remaining areas of the
[State of Maharashtra] as may be notified by the State Government in the
Official Gazette].
155. Method of providing orders and notifications. - Any order or notification
published or issued by the State Government or by a Magistrate or officer
under any provisions of this Act, and the due publication or issue thereof,
may be proved by the production of a copy thereof in the Official Gazette, or
of a copy thereof signed by such Magistrate, or officer, and by him certified
to be a true copy of an original published or issued according to the
provisions of the section of this Act applicable thereto.
156. Rules and order not invalidated by defect of form or irregularity in
procedure. - No rule, order, direction, adjudication, inquiry or notification
made or published, and no act done under any provision of this Act or of any
rule made under this Act, or in substantial conformity to the same, shall be
deemed illegal, void, invalid or insufficient by reason of any defect of form or
any irregularity of procedure.
157. Presumption in prosecutions for contravention of directions issued
under sections 55, 56, [57, 57A or 63AA]. - Notwithstanding anything
contained in any law for the time being in force, in a prosecution or an
offence for the contravention of a direction issued under sections 55, 56,
[57A or 63AA] on the production of an authentic copy of the order, it shall,
until the contrary is proved and the burden of proving which shall lie on the
accused, be presumed-Bombay Police Act, 1951

(a)that the order was made by the authority competent under this Act to make it;(b)that the
authority making the order was satisfied that the grounds on or the purpose for which it was made
existed, and that it was necessary to make the same; and(c)that the order was otherwise valid and in
conformity with the provisions of this Act.[157A. Officers holding charge of, or succeeding to
vacancies competent to exercise power. - Whenever in consequence of the office of a Commissioner,
Magistrate or Police Officer becoming vacant, any officer holds charge of the post of such
Commissioner, Magistrate or Police Officer or succeeds, either temporarily or permanently, to his
office, such officer shall be competent to exercise all the powers and perform all the duties
respectively conferred and imposed by this Act of such Commissioner, Magistrate or Police Officer,
as the case may be.]
158. Forfeiture of bond entered into by person permitted to enter or return to
the area from which he was directed to remove himself. - If any person
permitted under sub-section (1) of section 63 fails to observe any condition
imposed under the said sub-section or in the bond entered into by him under
sub-section (2) of the said section his bond shall be forfeited and any person
bound thereby shall pay the penalty thereof or show cause to the satisfaction
of the Court why such penalty should not be paid.
159. No Magistrate or Police Officer to be liable to penalty or damage for act
done in good faith in pursuance of duty. - [No Revenue Commissioner,
Magistrate] or Police Officer shall be liable to any penalty or to payment of
damages on account of an act done in good faith, in pursuance or intended
pursuance of any duty imposed or any authority conferred on him by any
provision of this Act or any other law for the time being in force or any rule,
order or direction made or given therein.
160. No public servant liable as aforesaid for giving effect in good faith to any
rule, order or direction issued with apparent authority. - No public servant or
person duly appointed or authorised shall be liable to any penalty or to
payment of any damages for giving effect in good faith to any such order or
direction issued with apparent authority by the State Government or by a
person empowered in that behalf under this Act or any rule, order or
direction made or given thereunder.
161. Suits or prosecutions in respect of acts done under colour of duty as
aforesaid not to be entertained, or to be dismissed if not instituted [within the
prescribed period]. - (1) In any case of alleged offence by [the Revenue
Commissioner, the Commissioner], a Magistrate, Police Officer or otherBombay Police Act, 1951

person, or of a wrong alleged to have been done by [such Revenue
Commissioner, Commissioner], Magistrate, Police
Officer or other person, by any act done under colour or in excess of any such, duty or authority as
aforesaid, or wherein it shall appear to the Court that the offence or wrong if committed or done was
of the character aforesaid, the prosecution or suit shall not be entertained, or shall be dismissed, if
instituted, more than six months after the date of the act complained of:[Provided that, any such
prosecution against a Police Officer may be entertained by the Court, if instituted with the previous
sanction of the State Government within two years from the date of the offence.]In suits as aforesaid
one month's notice of suit to be given with sufficient description of wrong complained of(2)In the
case of an intended suit on account of such a wrong as aforesaid, the person intending to sue shall be
bound to give to the alleged wrong-doer one month's notice at least of the intended suit with
sufficient description of the wrong complained of, failing which such suit shall be dismissed.Plaint
to set forth service of notice and tender of amends(3)The plaint shall set forth that a notice as
aforesaid has been served on the defendant and the date of such service, and shall state whether any,
and if any, what tender of amends has been made by the defendant. A copy of the said notice shall be
annexed to the plaint endorsed or accompanied with a declaration by the plaintiff of the time and
manner of service thereof.
162. Licences and written permissions to specify conditions, etc., and to be
signed. - (1) Any licence or written permission granted under the provisions
of this Act shall specify the period and locality for which, and the conditions
and restrictions subject to which, the same is granted, and shall be given
under the signature of the competent authority and such fee shall be charged
therefor as is prescribed by any rule under this Act in that behalf.
Revocation of licences, etc(2)Any licence or written permission granted under this Act may at any
time be suspended or revoked by the competent authority, if any of its conditions or restrictions is
infringed or evaded by the person to whom it has been granted, of or if such person is convicted of
any offence in any matter to which such licence or permission relates.When licence revoked, etc.,
grantee to be deemed without licence(3)When any such licence or written permission is suspended
or 'evoked, or when the period for which the same was granted has expired, the person 'o whom the
same was granted shall, for all purposes of this Act, deemed to be without a licence or written
permission, until the order for suspending or revoking the same is cancelled, or until the same is
renewed, as the case may be.Guarantee to produce licence, etc., when required(4)Every person to
whom any such licence or written permission has been granted, shall, while the same remains in
force, at all reasonable time, produce the same if so required by a Police Officer.Explanation. - For
the purpose of this section any such infringement or evasion by, or conviction of, a servant or other
agent acting on behalf of the person to whom the licence or written permission has been granted
shall be deemed to be infringement or evasion by, or as the case may be, conviction of, the person to
whom such licence or written permission has been granted.Bombay Police Act, 1951

163. Public notices how to be given. - Any public notice required to be given
under any of the provisions of this Act shall be in writing under the signature
of a competent authority and shall be published in the locality to be affected
thereby, by affixing copies thereof in conspicuous public places, or by
proclaiming the same with beat of drums, or by advertising the same in such
local newspaper, - English or regional language or Hindi, - as the said
authority may deem fit, or by any two or more of these means and by any
other means it may think suitable.
164. Consent, etc., of a competent authority may be proved by writing under
his signature. - Whenever under this Act, the doing or the omitting to do
anything or the validity of anything depends upon the consent, approval,
declaration, opinion or satisfaction of a competent authority, a written
document signed by a competent authority purporting to convey or set forth
such consent, approval, declaration, opinion or satisfaction shall be
sufficient evidence thereof.
165. Signature on notice, etc., may be stamped. - Every licence, written
permission, notice or other document, not being a summons or warrant or
search warrant, required by this Act, or by any rule thereunder, to bear the
signature of the Commissioner, shall be deemed to be properly signed if it
bears a facsimile of his signature stamped thereon.
166. Persons interested may apply to State Government to annul, reverse or
alter any rule or order. - (1) In the case of any rule or order made by the State
Government under an authority conferred by this Act and requiring the
public or a particular class of persons to perform some duty or act, or to
conduct or order themselves or those under their control in a manner therein
described, it shall be competent to any person interested to apply to the
State Government by a memorial given to a Secretary to the State
Government to annul, reverse or alter the rule or order aforesaid on the
ground of its being unlawful, oppressive or unreasonable.
When a suit shall lie to the District Court to declare a rule or order unlawful(2)After such an
application as aforesaid and the rejection thereof wholly or in part or after the lapse of four months
without an answer to such application or a decision thereon published by the State Government, it
shall be competent to the person interested and deeming the rule or order contrary to law to
institute a suit against the State for a declaration that the rule or order is unlawful either wholly orBombay Police Act, 1951

in part. The decision in such suit shall be subject to appeal; and a rule or order finally adjudged to be
unlawful shall by the State Government be annulled or reversed or so altered as to make it
conformable to law.
167. Repeal and saving. - (1) The enactments [specified in Part I of Schedule
I] are hereby repealed :
Provided that -(i)All rules prescribed, appointments made, powers conferred, orders made or
passed, directions and certificates issued, consent, permit, permission or licences given, summons
or warrants issued or served, persons arrested or detained or discharged on bail or bond, search
warrants issued, bond forfeited, penalty incurred under any such enactment shall, so far as they are
consistent with this Act, be deemed to have been respectively prescribed, made, conferred, given,
passed, served, arrested, detained, discharged, forfeited and incurred thereunder.(ii)All references
made in any Bombay Act to any of the Acts hereby repealed shall be read as if made to the
corresponding provisions of this Act.(2)Nothing in sub-section (1) shall be deemed to affect -(a)the
validity, invalidity, effect or consequence of anything done or suffered to be done in an area before
the date on which the provisions of this Act come into force in such area;(b)any right, privilege,
obligation or liability already acquired, accrued or incurred before such date;(c)any penalty,
forfeiture or punishment incurred or inflicted in respect of any act before such date;(d)any
investigation, legal proceeding or remedy in respect of such right, privilege, obligation, liability,
penalty, forfeiture or punishment;(e)any legal proceeding pending in any Court or before any officer
on the aforesaid date or anything done or suffered to be done in the course of such proceedings; and
any such proceeding or any appeal or revisional proceedings arising out of such proceeding shall be
instituted, continued or disposed of, as the case may be, as if this Act had not come into force.[(2A)
On the commencement of this Act in that part of the State to which it is extended by the Bombay
Police (Extension and Amendment) Act, 1959, the laws specified in Part II of Schedule I and in
Schedule IV, as in force in that part of the State, shall stand repealed :Provided that such repeal shall
not affect-(a)the previous operation of any law so repealed, or anything duly done or suffered
thereunder; or(b)the right, privilege, obligation or liability acquired, accrued or incurred under any
law so repealed; or(c)any penalty incurred in respect of anything done against any law so
repealed;and any investigation, legal proceeding or remedy in respect of any such right, privilege,
obligation, liability or penalty as aforesaid may be instituted, continued, or enforced, and any such
penalty may be imposed, as if this Act had not come into force in the relevant part of the
State:Provided further that, subject to the preceding proviso, anything done or any action taken
(including any rule prescribed, appointment made, power conferred, order made or passed,
direction or certificate issued, consent, permit, permission or licence given, summons or warrant
issued or served, person arrested or detained or discharged on bail or bond, search warrant issued
or bond forfeited), under any such repealed law shall, in so far as it is not inconsistent with this Act,
be deemed to have been done or taken under the corresponding provision of this Act, as if the said
provisions were in force in the relevant part of the State when such thing was done or such action
was taken, and shall continue in force accordingly, unless and until superseded by anything done or
any action taken under this Act:Provided also that any reference to any such repealed law, or to any
provision thereof, in any law for the time being in force, shall be construed as a reference to this Act
or to the corresponding provision thereof.][(3) The enactment specified in Schedule III in itsBombay Police Act, 1951

application to the [pre-Reorganisation State of Bombay, excluding the transferred territories,] is
hereby amended to the extent and in the manner mentioned in the fourth column thereof.]
168. [Saving of laws relating to Village Police and Reserve Police]. - Nothing
in this Act shall affect the provisions of the Bombay Village Police Act, 1867
[that Act as in force in the Kutch area of the State of Bombay or of the
Saurashtra Village Police Ordinance, 1949, or any law corresponding thereto
in force in any part of the State] or any enactment which may be made, and in
regard to the Reserve Police.
Schedule I
Year No. Short title
1 2 3
  [[Part I]()[]()
1890 ....IV ....The Bombay District Police Act, 1890.
1902 ....IV ....The City of Bombay Police Act, 1902.
1949 ....XVI ....The Police Forces (Control and Direction) Act, 1949].
  [[Part II]()[]()
1861 ....V ....The Police Act, 1861, as in force in the Vidarbha region ofthe State of Bombay.
1890 ....IV ....The Bombay District Police Act, 1890, as in force in theKutch area of the State
of Bombay.
1329F ....X ....The Hyderabad District Police Act.
1954 ....XVIII ....The Saurashtra Police Act, 1954].
II
(See section 14)CertificateofAppointment in the Police Force.No.............................._ _ _ _ _[State of
Maharashtra]
Certificate of Appointment issued under the Police Act
of1951...........................................(Photograph to be affixed in the case of
[Inspectors and]()Sub-Inspectors)
Act of 1861.......................................................  
Mr.......................................................................  
has been appointed as....................................
and is invested with the powers, functions and privileges of aPolice Officer under the Bombay
Police Act of 1951. 
Act V of 1861.[Greater Bombay/Area under the charge of the Commissioner
for......................................]_______________________In the Bombay District Police.Railway
Police.On the................................... day of.................................................19Signature
.................................Designation .............................Bombay Police Act, 1951

III
[See sub-section (3) of section 167]
Year  No.  Short title Amendment
1  2  3 4
1898 ..V ..Code of Criminal
Procedure.In clause (a) of sub-section (2) of section 1 of the Act-
     (i)for the words "towns of Calcutta, Madras and Bombay"the
words "towns of Calcutta and Madras" shall besubstituted.
     (ii)for the words "towns of Calcutta and Bombay" thewords
"town of Calcutta" shall be substituted.
[Schedule IV][See sub-section (2A) of section 167]
Year    No.   Short title
1    2   3
1946 ......X ....The Central Provinces and Berar Goondas Act, 1946.
1947 ......XVII ....The Central Provinces and Berar Special Police EstablishmentAct, 1947.
1951 ......XXIX ....The Hyderabad Public Security Measures Act, 1951.
1953 ......XII ....The Punjab Security of the State Act, 1953, as extended tothe Kutch area of
the State of Bombay.
1955 ......XXV ....The Saurashtra Gram Rakshah Dal Act, 1955.
1957 ......XXXVII ....The Hyderabad Public Security Measures (Amendment) andSupplemental
Provisions Act, 1957
NotificationsG.N., H.D., No. 8484/5-IV, dated 25th June, 1953 (B.G., Part I, page 8735) - In exercise
of the powers conferred by sub-section (2) of section 1 of the Bombay Police (Amendment) Act, 1953
(Bombay XX of 1953), the Government of Bombay is pleased to appoint the 1st July 1953 as the date
on which the said Act shall come into force.G.N., H.D., No. BPA. 3057/ 100301-V(e), dated 21st
September, 1959 (B.G., Part IV-B, page 1214) - In exercise of the powers conferred by sub-section (2)
of section 1 of the Bombay Police (Amendment) Act, 1959 (Bombay XXXVII of 1959), the
Government of Bombay hereby specifies the 2nd October, 1959 to be the date on which the said Act
shall come into force.G.O., H.D., No. BPA. 3064-V, dated 23rd October, 1964 (M.G., Part IV-B, page
1552) - In exercise of the powers conferred by sub-section (2) of section 1 of the Bombay Police (Sea
Amendment) Act, 1964 (Maharashtra XXVIII of 1964) the Government of Maharashtra hereby
appoints 1st day of November, 1964 as the date on which the said Act shall come into force.G.N.,
H.D., (Spl.), No. MIS. 0480/3455-Spl.-5, dated 10th July, 1981 (M.G., Part IV-B, page 1560) - In
exercise of the powers conferred by sub-section (2) of section 1 of the Bombay Police (Amendment)
Act, 1981 (Maharashtra XXXIII of 1981), the Government of Maharashtra hereby appoints the 15th
day of July 1981 to be the date on which the said Act shall come into force.G.N., H.D., No. BPA,
3057/100301-V(a), dated 21st September, 1959 (M.G., Part IV-B, page 1214) - In exercise of the
powers conferred by sub-section (3) of section 1 of the Bombay Police Act, 1951 (Bombay XXII of
1951), the Government of Bombay hereby specifies 1st day of October, 1959 to be the date on whichBombay Police Act, 1951

the said Act shall come into force in that part of the State of Bombay to which it is extended by the
Bombay Police (Extension and Amendment) Act, 1959 (Bombay XXXIV of 1959).G.N., H.D., No.
ACB. 3059-V, dated 23rd October, 1961 (M.G., Part IV-B, page 1012) - In exercise of the powers
conferred by section 5 of the Bombay Police Act, 1951 (Bombay XXII of 1951), the Government of
Maharashtra hereby directs that whenever any officer of and above the rank of a Police
Sub-Inspector of Anti-Corruption and Prohibition Intelligence Bureau of the Maharashtra State
investigates, at any place in the State, any offence, he shall be deemed to be an officer incharge of
the Police station within the limits of which such place is situate.Amended by G.O., H.D., No.
DLP.0178/C-3071-POL-3, dated 24th November, 1980 (M.G., Part IV-B, page 1087).G.O., H.D., No.
CID. 1264/73815-V, dated 11th April, 1967 (M.G., Part IV-B, page 1369) - In exercise of the powers
conferred by section 5 of the Bombay Police Act, 1951 (Bombay XXII of 1951), the Government of
Maharashtra hereby directs that whenever any officer of the Maharashtra State falling within any of
the following categories investigates at any place in the State any offence he shall be deemed to an
officer in charge of the police station within the limits of which such place is situated,
namely:-(a)Officer of and above the rank of a Sub-Inspector of the Crime Branch, Special Branch I
and Special Branch II, Criminal Investigation Department, Greater Bombay.(b)Officer of an above
the rank of a Sub-Inspector of the Crime Branch and Special Branch of Nagpur Police
Force.(c)Officer of and above the rank of a Sub-Inspector of the Crime Branch and Special Branch of
the Poona Police Force.(d)Officer of and above the rank of a Head Constable of Intelligence Branch,
Criminal Investigation Department, Maharashtra State.(e)Officer of and above the rank of a Head
Constable of Crime and Railways Branch, Criminal Investigation Department, Maharashtra
State.(f)Officer of and above the rank of a Head Constable of Local Intelligence Branches in the
districts and the two Railways Special Police Districts (viz., Central, Southern and Western Railways
and Central, South-Eastern and Western Railways).(g)Officer of and above the rank of a Head
Constable of Local Crime Branches in the districts and Detective Branches of the Central, Southern
and Western Railways and Central, South-Eastern and Western Railways Special Police
Districts.[(h) Officer deputed, from time to time, by the Deputy Inspector General of police, C.I.D.
(Crime), Maharashtra State, to investigate into any case or class of cases.]G.O., H.D., No. MSC.
1275/113-III-P, dated 18th September, 1975 (M.G., Part IV-A, page 706) - In exercise of the powers
conferred by section 5 of the Bombay Police Act, 1951 (Bombay XXII of 1951), the Government of
Maharashtra hereby directs that every Police Officer of, and above, the rank of a
Sub-Inspector,-(a)in the State Traffic Branch or in the Traffic Control Branch in Greater Bombay;
or(b)in the Traffic Branch in the City of Pune; or(c)in the Traffic Branch in the City of Nagpur;
or(b)in the Traffic Branch of other Police units in the State;shall be deemed to be an officer in
charge of a Police Station for the purposes of section 436 read with section 445 of the Code of
Criminal Procedure, 1973, within the limits of his jurisdiction.G.O., H.D., No. PSA. 0280/24-POL-5,
dated 30th September, 1980 (M.G., Part IV-B, page 963) - In pursuance of the provisions of section
5 of the Bombay Police Act, 1951 (Bombay XXII of 1951), and of all other powers enabling it in this
behalf, the Government of Maharashtra hereby makes the following Order for regulating the
conduct of the candidates and other persons connected with the election of an office-bearer of any
recognised Association of the Members or any Class of Members of the Police Force in the State of
Maharashtra, namely:-Bombay Police Act, 1951

1. In this Order, unless the context otherwise requires,-
(a)"election" means an election of any Member of the Police Force in the State as an office-bearer of
any recognised Association;(b)"recognised Association" means an Association of the Members or
any Class of Members of the Police Force in the State, which recognised by the Inspector General of
Police, Maharashtra State.
2. No person standing as a candidate for any election, and no office-bearer or
Member of any recognised Association, shall be entitled to claim or get any
leave for the purposes of such election.
3. A candidate for any election shall not ask or permit any person other than
a Member of the recognised Association, to take part in canvassing or
propaganda, for him, and shall not hold or organise or cause to be held or
organised any procession or meeting for canvassing for votes.
4. Except as permitted hereunder, canvassing for any election by the
candidate himself, or by any other person on his behalf, is hereby
prohibited:-
(a)A candidate may write signed letters to the voting Members, which shall not contain any
persuading or promising material, except his bio-data, special qualifications or services and appeal
to vote in his favour.(b)A candidate may display placards or posters announcing his candidature at
such places as the Inspector General of Police or any Police Officer designed by him may specify.(c)A
candidate or any Member of the recognised Association on his behalf may have personal contact for
canvassing with the voting Members of the recognised Association.
5. Any candidate or other person who contravenes any of the provisions of
this Order shall be guilty of breach of discipline and shall be liable to be
punished therefor.
G.O., H.D., No. BPA. 0178/822-POL-3, dated 23rd October, 1978 (M.G., Part IV-B, page 1075) - In
exercise of the powers conferred by clause (a) of section 5 of the Bombay Police Act, 1951) (Bombay
XXII of 1951), the Government of Maharashtra hereby empowers every Police Officer of, and above
the rank of a Sub-Inspector, working in the Special Cell created by Government Resolution, Home
Department, No. UOM. 3177/2048-III-P, dated the 5th November, 1977, to investigate at any place
in the State of Maharashtra, any offence under the Protection of Civil Rights Act, 1955 (22 of 1955)
and under the Indian Penal Code, 1860 (45 of 1860) and further directs that such an officer shall be
deemed to be an officer in charge of a Police Station within the limits of which such offence is
committed.G.O., H.D., No. APO. 2463/C-2896(III)(C)-V, dated 9th March, 1968 (M.G., Part IV-B,
page 388) - In exercise of the powers conferred by clause (b) of section 5, read with clause (c) ofBombay Police Act, 1951

section 7, of the Bombay Police Act, 1951 (Bombay XXII of 1951), the Government of Maharashtra
hereby directs that the Commissioner of Police, Poona and Nagpur, shall exercise the power of
appointing Police Officers of and below the rank of Police Sub-Inspectors, in their respective
jurisdiction.G.O., H.D., No. PSB. 1082/POL-5-A, dated 31st August, 1982 (M.G., Part IV-B, page
850) - In pursuance of the provisions of clause (b) of section 5 of the Bombay Police Act, 1951
(Bombay XXII of 1951), and of all other powers enabling it in this behalf, and in supersession of all
orders or rules made in this behalf and in force in the State of Maharashtra or any part thereof, in so
far as they are not consistent with this Order, the Government of Maharashtra hereby makes the
rules determining the method of selection of candidates by nomination for admission to the Police
Sub-Inspectors' Training Course at the Police Training College, Nashik, for even that appointment
to the posts of Sub-Inspector of Police in the Police Force of the State of Maharashtra as follows,
namely:-
1. Method of selection of candidates. - Save as otherwise provided by any
other general or special orders issued by the State Government for
recruitment to the posts of Sub-Inspector of Police in the Police Force of the
State of Maharashtra by promotion of Departmental candidates, selection of
candidates for admission to the Police Sub-Inspectors' Training Course at
the Police Training College, Nashik, for eventual appointment to the posts of
Sub-Inspector of Police in the Police Force of the State of Maharashtra shall
be made by nomination through the Maharashtra Public Service Commission
(hereinafter referred to as "the Commission"), on the basis of the competitive
examination held by the Commission in accordance with the provision of
rules 2 and 3.
2. Eligibility of candidates for examination. - To qualify for examination for
admission to the Police Sub-Inspectors' Training Course at the Police
Training College, Nashik, by nomination, a candidate:-
(1)shall be-(a)a citizen of India, or(b)a subject of Nepal, or(c)a subject of Bhutan, or(d)a Tibetan
refugee, who came over to India before the 1st January, 1962 with the intention of permanently
settling down in India, or(e)a person of Indian origin who was migrated from Pakistan, Burma, Sri
Lanka or East African countries of Kenya, Uganda and United Republic of Tanzania (formerly
Tanganyka and Zanzibar), with the intention of permanently settling down in India:Provided that, a
candidate belonging to categories (b), (c), (d) or (e) shall be a person in whose favour a certificate of
eligibility has been given by the Government of Maharashtra; and(2)shall be a person-(a)who is not
less than 19 years of age and is not more than 28 years of age; or(b)who belongs to backward classes
and is not less than 19 years of age and is not more than 33 years of age; or(c)who being already in
service of the Government of Maharashtra has applied for admission through proper channel;
and(i)possesses a bachelor's degree of any statutory university and was not more than 28 years of
age at the time of joining Government service and is not more than 30 years of age; or(ii)is a HeadBombay Police Act, 1951

Constable or Constable of Police, who has passed Secondary School Certificate Examination or any
examination recognised by Government as equivalent thereto and has put in service of not less than
three years, and is not more than 30 years of age; or(d)who, being otherwise eligible, is an
ex-serviceman, having served continuously in the Armed Forces of the Union for a period of not less
than six months, and is, after excluding the period of service so rendered in the Armed Forces of the
Union plus three years from his age, of not more than 28 years of age so calculated; and(3)shall be a
person, who possess a bachelor's degree of any statutory university;Provided that, the provision of
this sub-clause shall not apply as provided in sub-clause (2)(c)(ii) to a person who is a Head
Constable or Constable of Police, who has passed Secondary School Certificate Examination or an
Examination recognised by Government as equivalent thereto and has put in service of not less than
three years; and(4)shall be a person who possesses the following minimum physical standards
namely:-(i)height .. .. 165 cms.(ii)chest .. .. 85 cms. when fully inflated with minimum expansion of 5
cm.All other conditions being equal, preference may be given to a candidate who possesses
knowledge of-(i)Japanese, Chinese or any other languages spoken or written in Asia or
Europe.;(ii)motor driving.
3. Examination and selection of candidates by the Commission. - (1) The
competitive examination shall consist of-
(a)a written examination with four papers, each paper being of 100 marks and of one hour's
duration and the subjects therefor shall be as mentioned in the Appendix;(b)Physical test in the
following subjects carrying 200 marks, namely:-(i)putting the short (weight 7.250 kgs.);(ii)pull-ups
(eight);(iii)long jump; and(iv)running (800 metres).(c)Viva-vice carrying 100 marks.(2)The
Commission shall fix the qualifying marks in all the subjects of the examination and in the total,
either generally for all candidates, or separately for candidates from the Backward Classes in respect
of vacancies reserved for such candidates, and for other candidates, and a candidate shall not be
deemed to have qualified in the examination if he fails to obtain the qualifying marks fixed by the
Commission in the written-examination or in the Physical Test or in the viva-vice and Personality
Test.(3)Candidate who is declared successful in the written examination shall only be called upon to
appear for the Physical Test and on his passing the Physical Test he shall have to appear for the
viva-vice and other test.(4)The Commission shall then select such number of candidates from
amongst those finally declared successful in the competitive examination in order of their inter se
merit, as is equal to the vacancies notified:Provided that, the Commission may keep on waiting list
such number of selected candidate as is considered reasonably necessary so to do by the
Commission.
4. Necessity of passing Hindi and Marathi examinations. - A candidate
appointed to the post of Sub-Inspector of Police shall be required to pass
examination in Hindi and Marathi according to the prescribed rules, unless
he has already passed or has been exempted from passing, such
examination.
AppendixBombay Police Act, 1951

//SerialNo.// Subject  Marks
1. Written paper of English and Marathi ......100
2. Intelligence test ......100
3. General Knowledge ......100
4. Psychological and Aptitude test ......100
G.O., H.D., No. FST. 0188/3808(C)/POL-5A, dated 16th November, 1988 (M.G., Part IV-B, page
1232) - In exercise of the powers conferred by clause (b) of section 5 of the Bombay Police Act, 1951
(Bombay XXII of 1951), the Government of Maharashtra hereby makes the following Order,
namely:-Persons dismissed from service for acts of misconduct committed by them during or prior
to the police agitation made in August, 1982, shall be given fresh employment in the posts held by
them at the time of their dismissal from service by relaxing the upper age limit prescribed for
recruitment to the Constabulary, provided they are willing and available for such
employment.Amended by G.O., H.D. No. DLP. 1870C-.22-V-dated 11th May 1970 (M.G., Part I-C.S.,
page 484)G.O., H.D., No. DLP. 1870/C-1222-V, dated 15th April, 1970 (M.G., Part I-C.S., page 388)
- In exercise of the powers conferred by clause (b) of sub-section (2) of section 6 of the Bombay
Police Act, 1951 (Bombay XXII of 1951), the Government of Maharashtra hereby directs that all the
powers and the authority of the Inspector-General of Police under the said Act [except those under
section 23 and section 25(2)(a) and all powers, functions, duties and responsibilities incidental to
the provisions of section [25(2)(a)] and the rules made thereunder may be exercised, performed or
discharge as the case may be, by the Additional Inspector-General.G.N, H.D., No.
DLP-1370/1058-VA, dated 17th December, 1974 (M.G., 1972, Part I-C.S., page 78) - In exercise of
the powers conferred by clause (b) of sub-section (2) of section 6 of the Bombay Police Act, 1951,
(Bombay XXII of 1951), the Government of Maharashtra hereby directs that all the powers,
functions, duties and responsibilities and the authority of the Inspector-General of Police under the
said Act (except the power to make rules under section 23 and the power and authority to punish an
Inspector and Sub-Inspector under clause (a) of sub-section (2) of section (25) and the rules made
thereunder, may also be exercised, performed, or as the case may be, discharged by the Special
Inspector-General of Police.G.O., H.D., No. APO-2643-C-2896-Special Unit, dated 19th October,
1965 (M.G., Part I-C.S., page 645) - In exercise of the powers conferred by clause (c) of section 7,
read with sub-section (1) of section 6, of the Bombay Police Act, 1951 (Bombay XXII of 1951), and of
all other powers enabling it in that behalf, the Government of Maharashtra hereby directs that the
Commissioners of Police, Poona and Nagpur, shall, within their respective jurisdiction, exercise the
powers and perform the functions and duties in respect of the matters specified in the schedule
hereto, appended in connection with the administration of the Police Force, subject to the control
(only as respects matters of policy) of the Inspector-General of Police.
Schedule 3
(1) Changes in the standards of recruitment to the Police Force.
(2)Changes in the strength of the Police Force and changes in the strength of the different branches
or grades thereof.(3)Changes in the armament, uniform and other equipment of the Police
Force.(4)Changes in the methods of training of officers and men of Police Force and the syllabusBombay Police Act, 1951

and arrangements for such training.(5)Recommendations for the award of the Police Medal and for
award of the President's Police and Fire Service Medal.(6)Promotions of Sub-Inspectors to the grade
of Inspectors and the preparation of select lists of Sub-Inspectors fit for such
promotions.(7)Promotion of Inspectors of Police to the grade of Assistant Commissioners of Police
and the preparation of select lists of Inspector fit for such promotion.(8)Reports on Assistant
Commissioners of Police fit to become Deputy Commissioners of Police.(9)Amenities for the Police
Force and its welfare.(10)Creation or change in the organisation of any special branch of the Police
Force.(11)Creation or reorganisation of any police station.(12)Police Wireless
Grid.(13)Mechanisation of the Police Force.(14)Measures intended to be taken in connection with
the prevention and detection of crime on the border between the areas of their jurisdiction and
continuous districts.(15)Measures intended to be taken in connection with communal, political
industrial or economic activities in their jurisdiction which are likely to affect public order in the
contiguous districts, and vice-versa.(16)Preparation or modification of any security scheme.G.O.,
H.D., No. BPA. 2263/C-4354-V, dated 31st October, 1967 (M.G., Part IV-B, page 2344) - In exercise
of the powers conferred by clause (c) of section 7, read with sub-section (1) of section 6, of the
Bombay Police Act, 1951 (Bombay XXII of 1951), and of all other powers enabling it in that behalf,
and in supersession of the Government Order, Home Department, No. 8484/5-II, (a), dated the 9th
November, 1951, the Government of Maharashtra hereby directs that the Commissioner of Police
Greater Bombay, shall exercise the powers and perform the functions and duties in respect of the
matters specified in the Schedule hereto appended in connection with administration of the Greater
Bombay Police Force subject to the control (only as respects matters of policy) of the
Inspector-General of Police.
Schedule 4
(1) Changes in the standards of recruitment to the Police Force.
(2)Changes in the strength of the Police Force and in the different branches or grades thereof except
where they arise out of creation or reorganization of any Police Station.(3)Changes in the armament,
uniform and other equipment of the Police Force.(4)Changes in the methods of training of officers
and men of the Police Force and in the syllabus and arrangements for such
training.(5)Recommendations for the award of the Police Medal and for the award of the President's
Police and Fire Services Medal.(6)Promotions of Sub-Inspectors to the grade of Inspectors and the
preparation of select lists of Sub-Inspectors fit for such promotions.(7)Promotion of Inspectors of
Police to the grade of Assistant Commissioners of Police and the preparation of select lists of
Inspectors fit for such promotion.(8)Reports on Assistant Commissioners of Police fit to become
Deputy Commissioners of Police.(9)Creation of any special branch of the Police Force.(10)Police
Wireless Grid.(11)Mechanisation of the Police Force.(12)Measures intended to be taken in
connection with the prevention and detection of crime on the border between Greater Bombay and
contiguous districts.(13)Measures intended to be taken in connection with communal, political,
industrial or economic activities in Greater Bombay which are likely to affect public order in the
contiguous districts, and vice-versa.(14)Preparation or modification of any security scheme.G.O.,
H.D., No. MTS. 2263/29634-XI, dated 3rd January, 1964 (M.G., Part I-B.D.S., page 123) - In
exercise of the powers conferred by section 8A of the Bombay Police Act, 1951 (Bombay XXII ofBombay Police Act, 1951

1951), the Government of Maharashtra hereby directs that the Superintendent of Police, Traffic
Branch, Maharashtra State, Bombay, appointed by it shall exercise all the powers and perform all
the functions, which may be exercised or performed by a Superintendent appointed under
sub-section (1) of section 8 of the said Act, under the said Act or under any law for the time being in
force; and without prejudice to the foregoing provision shall attend to all matters relating to traffic
in the State outside Greater Bombay, and in particular the following namely:-(i)to check traffic of all
kinds and especially the vehicular traffic on the highways, with a view to preventing accidents;(ii)to
inquire into and give technical advice in cases of motor accidents;(iii)to inculcate traffic sense
amongst the public by means of propaganda sections and by organising traffic branches in the
districts;(iv)to exercise supervision over and to train the officers and men of the State Traffic
Branch;(v)to attend to all work relating to such matters in the office of the Inspector-General of
Police, in addition to any other duties which may be assigned to him by the Inspector-General of
Police.G.N., H.D., No. APO. 4360/C-6022-V, dated 23rd October, 1961 (M.G., Part IV-B, page 1012)
- In exercise of the powers conferred by sub-section (2) of section 8 of the Bombay Police Act, 1951
(Bombay XXII of 1951), the Government of Maharashtra hereby empowers the Additional
Superintendent of Police, Thane, to exercise and perform in the Thane District, all the powers,
functions and duties to be exercised and performed by a District Superintendent of Police under the
said Act.G.N., H.D., No. DLP. 1761/21361-V, dated 6th November, 1961 (M.G., Part IV-B, page 1039)
- In exercise of the powers conferred by sub-section (2) of section 8 of the Bombay Police Act, 1951
(Bombay XXII of 1951), the Government of Maharashtra hereby empowers the Additional
Superintendent of Police, Nagpur, to exercise and perform in the Nagpur District, all the powers,
functions and duties to be exercised and performed by a District Superintendent of Police under the
said Act.G.O., H.D., No. APO. 1968/21361-V, dated 5th July, 1969 (M.G., Part IV-B, page 948) - In
exercise of the powers conferred by sub-section (2) of section 8 of the Bombay Police Act, 1951
(Bombay XXII of 1951), the Government of Maharashtra hereby empowers the Additional
Superintendent of Police Nashik, to exercise and perform in the Nashik District, all the powers,
function and duties to be exercised and performed by a District Superintendent of Police under the
said Act.G.O., H.D., No. APO. 2870/64664-V-A, dated 24th November, 1971 (M.G., Part IV-B, page
1951) - In exercise of the powers conferred by sub-section (2) of section 8 of the Bombay Police Act,
1951 (Bombay XXII of 1951), the Government of Maharashtra hereby empowers the Additional
Superintendent of Police, Solapur, to exercise and perform in the Solapur District, all the powers,
functions and duties to be exercised and performed by a District Superintendent of Police under the
said Act.G.O., H.D., No. APO. 1372/7-V-A, dated 18th July, 1973 (M.G., Part IV-B, page 1462) - In
exercise of the powers conferred by sub-section (2) of section 8 of the Bombay Police Act, 1951
(Bombay XXII of 1951), the Government of Maharashtra hereby empowers the Additional
Superintendent of Police, Aurangabad, to exercise and perform in the Aurangabad District, all the
powers, functions and duties to be exercised and performed by a Superintendent of Police under the
said Act.G.N., H.D., No. 7747/5, dated 31st July, 1954 (B.G., Part IV-B, page 1056) - In exercise of
the powers conferred by sub-section (1) of section 11 of the Bombay Police Act, 1951 (Bombay XXII
of 1951), the Government of Bombay is pleased to appoint all the Deputy Superintendents of Police
of the Special Police Establishment stationed in Greater Bombay as Superintendents of Police for
Greater Bombay.G.N., H.D., No. APO. 2690/658/CR-123/POL-3, dated 27th December, 1990
(M.G., Part IV-B, page 201) - In exercise of the powers conferred by sub-section (1) of section 11,
read with section 12 of the Bombay Police Act, 1951 (Bombay XXII of 1951), the Government ofBombay Police Act, 1951

Maharashtra hereby appoints Shri T.W. Rebeiro, Port Inspector, Bombay Port Trust, as an Assistant
Commissioner of Police Greater Bombay, with effect from the date he took over charge of the Port
Trust Harbour Police Patrol till he relinquishes it, and directs that the Assistant Commissioner of
Police Shri Rebeiro shall exercise the powers and perform the functions and enjoy privileges of a
Police Officer under the said Act, for the purposes of carrying out the functions enumerated below
under the provisions of law within the limit of the Port of Bombay:-
1. to ensure compliance with Port Rules-
(a)Keeping Dock channel limits clear and prosecuting offenders.(b)Keeping to P. and O. and B.L Dry
Docks and Break-up ground clear and prosecuting offenders.(c)Keeping fishermen within their
limits and prosecuting offenders.(d)Preventing drift not fishing and prosecuting
offenders.(e)Preventing too many Cargo boats coming alongside or obstructing vessels mooring and
prosecuting offenders.(f)Enforcement of the use of navigation lights and prosecuting
offenders.(g)Attendance in case of collision with native craft and prosecuting offenders, if
required.(h)Preventing ashes of oil from being discharged into harbour and prosecuting
offenders.(i)Generally assisting the conservator in the Administration of the Indian Ports Act, 1908
(15 of 1908) and prosecuting offenders if required.
2. to ensure compliance with Explosive Rules, 1940 and its Supplementary
rules regulating the handling of explosives in the Port of Bombay.
3. to ensure compliance with the Petroleum Act, 1934 (30 of 1934) and the
rules made thereunder, specially when dangerous petrol is on board.
4. to ensure compliance with the Coasting Vessels Act, 1938 (19 of 1938) and
the rules made thereunder and to prosecute offenders.
5. to control passenger boats and launches under the passenger Boat Rules
afloats, and to keep landing places clear and see that all boats are licensed
and prosecute offenders.
G.O., H.D., No. APO-2463-C-2896 (III) (E)-V, dated 10th March, 1967 (M.G., Part IV-B, page 304) -
In exercise of the powers by sub-section (2) of section 11 of the Bombay Police Act, 1981 (Bombay
XXII of 1951), the Government of Maharashtra, hereby directs that the Commissioners of Police,
Greater Bombay, Pune and Nagpur may assign to the Assistant Commissioners of Police working
under them any of their powers, duties and functions as are exercised or performed by them under
the provisions of the Bombay Police Act, 1951, or any other law for the time being in force except the
powers vested in the Commissioners of Police under sections 37(3), 39 and 40 of the said Act.G.O.,
H.D., No. 8484/5-11, dated 14th April, 1955 (B.G., Part I, part 1603) - In exercise of the powers
conferred by sub-section (1) of section 14 of the Bombay Police Act, 1951 (Bombay XXII of 1951), the
Government of Bombay hereby directs that the certificates of appointment of the Inspectors ofBombay Police Act, 1951

Police in Greater Bombay shall be issued by the Commissioner of Police, Greater Bombay and
elsewhere by the Inspector-General of Police, Bombay State.G.N., H.D., No. TTC.
1166/15041-XXII-I, dated 14th April, 1975 (M.G., Part I-C.S., page 744) - In exercise of the powers
conferred by section 22-A of the Bombay Police Act, 1951 (Bombay XXII of 1951), and in
supersession of Government Notification, Home Department, No. POS. 5660/8592-V, dated the
25th October, 1960, the Government of Maharashtra hereby creates the Special Police Districts
mentioned in column 1 of the schedule annexed hereto embracing the railway areas specified against
each such district in column 2 thereof-
Schedule 5
Special Police District  Railway Areas
1  2
1.The Central, South-Central and
Western Railways SpecialPolice
District.All that piece of land within the Railway fencing and
Railwaypremises, through which the Central,
South-Central and WesternRailways pass –
Kilometres
  Central Railway
 (1)Bombay Victoria Terminus to Outer
Signal Kasbesukane(including) ..213.00
 (2)Bombay Victoria Terminus to Poona
(including) ..141.03
(3) Palasdhari to Khopoli (including)  ..12.00
(4) Neral to Matheran (including)  ..21.00
(5) Dhond to Padegaon (including)  ..146.00
(6) Diva to Apta (including)  ..42.00
(7) Panvel to Uran (including)  ..27.00
 South-Central Railways    
(1) Poona to Shedbal (including)  ..275.00
(2) Miraj to Kolhapur (including)  ..47.12
(3) Miraj to Sangli (including)  ..9.05
(4)Sholapur to Tadval (Half portion of
Bhima-Bridge) ..311.00
(5) Hadapsar to Dudhani (including)  ..43.61
(6) Dhond to Baramati (including)  ..327.00
(7) Miraj to Latur  ..327.00
Western Railway
(1)Churchgate to Umbergaon upto Outer
Signal ..136.71
2.The Central, South-Central, All that piece of land within the Railway premisesBombay Police Act, 1951

South-Eastern and WesternRailways
Special Police District.throughwhich the Central, South-Central, South Eastern
and WesternRailway Pass –
Kilometres
 Central Railway
 (1) Nagpur to Kasbe Sukane (including) ....624
(2) Chalisgaon to Dhulia ....57
(3) Pachora to Jamner ....56
(4) Bhusawal to Waghoda ....45
(5) Nagpur to Narkhed ....86
(6) Wardha to Makudi ....174
(7) Majri to Rajur ....21
(8) Tadali to Ghugus ....15
(9) Pulgaon to Arvi ....35
(10) Badnera to Amraoti ....10
(11) Ellichpur-Murtizapur-Yeotmal ....190
(12) Dhulghat to Purna ....373
(13) Jalamb to Khamgaon ....13
Kilometres
 (14) Beapur to Manmad ....86
 South-Central Railway
 (15) Manmad to Basar ....431
(16) Mudkhed to Ambari ....125
(17) Parli-Vajinath to Belehkarga ....107
(18) Parbhani to Parli-Vaijnath ....64
 South-Western Railway
 (19) Nagpur to Salekasa ....168
(20) Tumsar to Tirodi ....47
(21) Gondia to Birsola ....17
(22) Gondia to Chanda ....243
(23) Nagpur to Ramtek ....42
(24) Nagpur to Nagbhir ....101
 (25) Nagpur to Kilod ....45
(26) Saoner to Khapa ....6
 Western Railway
 (27) Navapur to Jalgaon ....208
Amended by G.N., H.D., No. PDE. 6661/C-3518-XI-P, dated 6th September, 1976 (M.G., Part IV-B,
1067)G.O., H.D., No. PDE. 6661-C-3518-IX, dated 1st July, 1963 (M.G., Part IV-B, page 854) - In
exercise of the powers conferred by clause (i) of sub-rule (1-A) of rule 3 of the Bombay PoliceBombay Police Act, 1951

(Punishments and Appeals) Rules, 1956, as amended by Government Notification in the Home
Department, No. PDE. 4858/74705-V, dated the 28th April, 1960, and in supersession of the
Government Order in the Home Department, No. PDE. 6661-C-3518-IX, dated the 13th August 1962
the Government of Maharashtra hereby empowers each of the authorities specified in column 1 of
the schedule hereto annexed also, to place under suspension for the purposes of that sub-rule any of
the police officers respectively mentioned against such authority in column 2 thereof, whose
appointing authority is higher in rank than such authority.
Schedule 6
Authorities  Officers who can be
placed under
suspension
 1  2
1.Deputy Inspector-General of
Police..Police Officers of and
below the rank of the
Sub-Inspector inthe
Range.
2.District Superintendent of
Police..Police Officers of and
below the rank of the
Sub-Inspector inthe
District.
3.Deputy Commissioner of Police,
Greater Bombay..Police Officers of and
below the rank of the
Sub-Inspector inGreater
Bombay.
[[3A.]()[]()Deputy Commissioner of Police,
City of Pune...Police Officers of and
below the rank of the
Sub-Inspector inthe City
of Pune.
3B.Deputy Commissioner of Police,
City of Nagpur...Police Officers of and
below the rank of the
Sub-Inspector inthe City
of Nagpur.]
4.Principal, Police Training
School..Police Officers of and
below the rank of the
Sub-Inspectorundergoing
training at, or serving on
the staff of, the School.
5.Superintendent of Police for the
Police Wireless System...Police Officers of and
below the rank of the
Sub-Inspector inthe
Police Wireless Section.Bombay Police Act, 1951

6.Superintendent of Police for the
Police-Motor TransportSystem..Police Officers of and
below the rank of the
Sub-Inspector inthe
Police Motor Transport
Section.
7.Superintendent of Railway
Police..Police Officers of and
below the rank of the
Sub-Inspector inthe
Railway District.
G.O., H.D., No. FST. 0188/3808/(b)/POL-5A/ dated 16th November, 1988 (M.G., Part IV-B, page
1231) - In pursuance of rule 3A of the Bombay Police (Punishments and Appeals) Rules 1956, the
Government of Maharashtra hereby removes the disqualification incurred under clause (iii) of
sub-rule (1) of rule 3 of the said rules by the Police Officers, who were dismissed from service for
acts of misconduct committed by them during or prior to the police agitation made in August
1982.G.N., H.D., No. PDE. 7164/90285-IV-C, dated 23rd May, 1969 (M.G., Part IV-B, page 709) - In
exercise of the powers conferred by clause (b) of sub-section (1) and sub-section (2) of section 31 of
the Bombay Police Act, 1951 (Bombay XXII of 1951), the Government of Maharashtra hereby
authorises all Deputy Commissioners of Police in Poona and Nagpur, to exercise the powers under
the said clause (b) and the said sub-section (2) with respect to police officers under their respective
jurisdiction.G.O., H.D., No. RSA. 1554, dated 3rd December, 1954 (B.G., Part IV-B, page 1586) - In
exercise of the powers conferred by sub-section (2) of section 31 of the Bombay Police Act, 1951
(Bombay XXII of 1951), the Government of Bombay hereby authorises a District Superintendent of
Police, an Additional District Superintendent of Police and the Deputy Commissioner of Police,
Headquarters, Greater Bombay, to exercise the powers under the said sub-section (2) with respect to
persons who are or were police officers under their respective jurisdiction.G.N., H.D., No. BPR.
1258/6129-V, dated 10th March, 1958 (B.G., Part IV-B, page 258) - In exercise of the powers
conferred by sub-section (2) of section 31 of the Bombay Police Act, 1951 (Bombay XXII of 1951), the
Government of Bombay hereby authorises all District Superintendents of Police to exercise the
powers under the said sub-section (2), with respect to police officers under their respective
jurisdiction.G.N., H.D., No. BPA. 3057/100301-V(c), dated 1st October, 1959 (B.G., Part I-C-S., page
894) - In exercise of the powers conferred by sub-section (1-A) of section 33 of the Bombay Police
Act, 1951 (Bombay XXII of 1951), the Government of Bombay hereby provides that the power to
make rules or orders under clauses (w), (w-a) and (x) of sub-section (1) of the said section 33 shall
also have effect from 1st day of October, 1959 in the Nagpur, Amravati, Akola, Bhandara, Yeotmal,
Buldana, Chanda, Wardha, Aurangabad, Parbhani, Nanded, Bhir, Osmanabad, Rajkot, Junagadh,
Bhavnagar, Jamnagar, Surendranagar and Kutch Districts.G.O., H.D., No. BPA. 3057/100301-V,
dated 13th October, 1959 (B.G., Part I-C.S., page 980) - In exercise of the powers conferred by
section 36 of the Bombay Police Act, 1951 (Bombay XXII of 1951), read with section 2 of the Bombay
Police (Extension and Amendment) Act, 1959 (Bombay XXXIV of 1959), the Government of Bombay
hereby specifies that in that part of the State of Bombay to which the Bombay Police Act, 1951, has
been extended the rank of the police officer who shall exercise powers under the said section 36,
subject to the orders of the District Superintendent of Police, shall not be lower than that of an
officer in charge of a police station.G.N., H.D., No. PPA. 1255/3032(b), dated 17th June, 1955 (B.G.,
Part IV-B, page 1314) - In exercise of the powers conferred by section 42 of the Bombay Police Act,Bombay Police Act, 1951

1951 (Bombay XXII of 1951), the Government of Bombay hereby extends the provisions of the said
section 42 of the Chopda Municipal District in the East Khandesh District.G.N., H.D., No. PPA.
1255/20841, dated 15th December, 1955 (B.G., Part IV-B, page 2032) - In exercise of the powers
conferred by section 42 of the Bombay Police Act, 1951 (Bombay XXII of 1951), the Government of
Bombay hereby extends the provisions of the said section 42 to the Municipal area of the Shirpur
town in the West Khandesh District.G.N., H.D., No. CAA. 1660/34011-(a)-X, dated 2nd November,
1961 (M.G., Part IV-B, page 1029) - In exercise of the powers conferred by sub-section (2) of section
45 of the Bombay Police Act, 1951 (Bombay XXII of 1951), and in supersession of all notifications
issued in this behalf, the Government of Maharashtra hereby-(1)appoints all Government Veterinary
Officers to be Veterinary Practitioners and(2)declares the areas within their respective jurisdiction
to be the areas of which they shall be in charge for the purposes of the said Act.G.N., H.D.,
(Political), No. SB-II/EXT. 3959/18948 (2), dated 1st October, 1959 (B.G., Part IV-B, page 1293) - In
exercise of the powers conferred by sections 55, 56 and 57 of the Bombay Police Act, 1951 (Bombay
XXII of 1951), the Government of Bombay hereby specially empowers the Sub-Divisional
Magistrates in charge of the Sub-Divisions specified in column 1 of the Schedule appended hereto in
the Districts specified against them in column 2 for the purposes of those sections.
Schedule 7
Sub-division   District  
1   2  
1* *  *  
1. Wardha
]-..
Wardha. 2. Hinganghat ..
3. Arvi ..
1. Amravati
]-..
Amravati2. Chandur ..
3. Morshi ..
4. Daryapur ..
5. Achalpur ..
1. Chanda
]-..
Chanda2. Warora ..
3. Brahmapuri ..
4. Gadchiroli ..
5.Sironcha at
Aheri..
6. Rajura ..
1. Yeotmal
]-..
Yeotmal2. Pusad ..
3. Darwha ..
4. Wani ..Bombay Police Act, 1951

5.Pandhar
Kaoda..
1. Akola.
]-..
Akola2. Akot. ..
3. Balapur ..
4. Washim ..
5. Murtizapur ..
6. Mangrulpir. ..
1. Bhandara
]-..
Bhandara 2. Gondia ..
3. Sakoli. ..
1. Buldana
]-..
Buldana2. Mehkar ..
3. Malkapur ..
4. Khamgaon ..
5. Jalgaon ..
1. Nagpur
]-..
Nagpur2. Ramtek ..
3. Umrer ..
4. Katol ..
5. Saoner ..
1. Aurangabad
]-..
Aurangabad 2. Jalna ..
3. Vaijapur ..
1. Bhir 1
]-..
Bhir
2.Mominabad
J..
1. Hingoli]-..Parbhani
2. Sailu ..
1. Nanded]-..Nanded
2. Deglur ..
1. Latur
]-..
Osmanabad 2. Udgir ..
3. Osmanabad ..
G.N., H.D., (Special), No. EXT. 3292/185/SPL-5, dated 16th November, 1992 (M.G., Part IV-B, page
1862) - In exercise of the powers conferred by sections 55, 56 and 57 of the Bombay Police Act, 1951
(Bombay XXII of 1951), the Government of Maharashtra is hereby pleased to empower the
Sub-Divisional Magistrate in charge of the Sub-Divisions specified it in column 1 of the ScheduleBombay Police Act, 1951

appended hereto in the Districts specified against them in column 2 for the purpose of the said
sections 55, 56 and 57.
Schedule 8
Sub-division    District
1    2
1. Jalna ......]Jalna
2. Partur ......
1. Gadchiroli ......]Gadchiroli
2. Desaigani ......
G.N., H.D., (Political), No. SB-II-EXT. 3959/18948(1), dated 1st October, 1959 (B.G., Part IV-B,
page 1292) - In exercise of the powers conferred by section 56 of the Bombay Police Act, 1951
(Bombay XXII of 1951), the Government of Bombay hereby extends the provisions of the said
section 56 to the areas specified in the Schedule appended hereto.
Schedule 9
Areas[***]
7. The Chanda District.
8. The Bhandara District.
9. The Nagpur District
10. The Akola District.
11. The Buldana District
12. The Yeotmal District
13. The Amravati District.
14. The Wardha District.
15. The Rajura District.
G.N., H.D., (Political), No. S.B-II EXT. 3959/18948(3), dated 3rd October, 1959 (B.G., Part IV-B,
page 1295) - In exercise of the powers conferred by section 63 of the Bombay Police Act, 1951
(Bombay XXII of 1951), the Government of Bombay hereby specially empowers, within their
respective jurisdiction the following officers for the purposes of the said section 63, namely:-(1)TheBombay Police Act, 1951

Commissioner, Bombay Division, Bombay.(2)The Commissioner, Poona Division, Poona.(3)The
Commissioner, Nagpur Division, Nagpur.(4)The Commissioner, Ahmedabad Division,
Ahmedabad.(5)The Commissioner, Rajkot Division, Rajkot.(6)The Commissioner, Aurangabad
Division, Aurangabad.G.N., H.D., No. VDP. 1260/2181-VII, dated 2nd March, 1965 (M.G., Part
IV-B, page 694) - Government is pleased to cancel the orders contained in Government Notification,
Home Department, No. 4047/5/15299-XVI, dated the 7th August, 1961, issued in exercise of the
powers conferred by section 63-B(12) of the Bombay Police Act, 1951 (Bombay XXII of 1951),
declaring that in respect of the four district of Thana, Ahmednagar, Kolaba and Satara, the powers,
duties and functions of the District Superintendent of Police, District Village Defence Officer and
Taluka Village Defence Officer as set out under section 63-B of the said Act should be exercised,
performed and discharged by such officers of the Home Guards as the Commandant-General, Home
Guards, may direct, and is further pleased to direct that in respect of the above mentioned four
districts the powers, duties and functions should now be exercised, performed and discharged by the
respective Superintendents of Police under section 63-B(1) of the said Act.G.N., H.D., No. CAA.
1660/34011-(b)-X, dated 2nd November, 1961 (M.G., Part IV-B, page 1029) - In exercise of the
powers conferred by clause (b) of section 74 of the Bombay Police Act, 1951 (Bombay XXII of 1951),
and in supersession of all notifications issued in this behalf, the Government of Maharashtra hereby
empowers all Government Veterinary Officers, within their respective jurisdiction, for the purpose
of the said section 74.G.N., H.D., No. CTP. 1261/72687-V, dated 18th November, 1963 (M.G., Part
IV-B, page 1635) - In exercise of the powers conferred by sub-section (1) of section 94 of the Bombay
Police Act, 1951 (Bombay XXII of 1951), and of all other powers enabling it in this behalf, and in
supersession of the Government Notification, Home Department, No. 8484/5-IV, dated the 12th
September 1951, the Government of Maharashtra hereby specifies the fees mentioned in column (2)
of the schedule appended hereto as the pound-fees chargeable in Greater Bombay in respect of the
kinds of animals mentioned against them in column (1) of the said Schedule.
Schedule 10
Kinds of animal   Fees  
 (1)   (2)  
1.Rams,
ewes,
sheep,
lambs,
goats
and
kids..Rs. 5 per
head.
2. Any
other
cattle.. Rs. 15 per
head plus
an
additional
fee for
bringing
thecattleBombay Police Act, 1951

from the
place of
seizure to
the pound,
at the rate
ofRe. 1 per
kilometre
or part
thereof per
head
G.N., H.D., No. BPA. 1358/77595-V, dated 28th February, 1959 (B.G., Part IV-B, page 347) - In
exercise of the powers conferred by sub-section (1) of section 118 of the Bombay Police Act, 1951
(Bombay XXII of 1951), the Government of Bombay hereby brings the said section into force in the
area within the limits of the Ratnagiri Municipality.G.N., H.D., No. BPA. 3057/100301-V, dated 2nd
October, 1959 (B.G., Part I-CS., page 965) - In exercise of the powers conferred by sub-section (1) of
section 118 of the Bombay Police Act, 1951 (Bombay XXII of 1951), the Government of Bombay
hereby brings the said section into force in that part of the State to which the said Act is extended by
the Bombay Police (Extension and Amendment) Act, 1959 (Bombay XXXIV of 1959).G.N., H.D., No.
BPA. 1460/39059-V, dated 24th November, 1960 (M.G., Part IV-B, page 362) - In exercise of the
powers conferred by sub-section (1) of section 118 of the Bombay Police Act, 1951 (Bombay XXII of
1951), the Government of Maharashtra hereby brings the said section into force in the area within
the limits of the Nagpur Municipal Corporation.G.N., H.D., No. BPA. 4461/3742-V, dated 2nd
February, 1961 (M.G., Part IV-B, page 222) - In exercise of the powers conferred by sub-section (1)
of section 118 of the Bombay Police Act, 1951 (Bombay XXII of 1951), the Government of
Maharashtra hereby brings the said section into force in the area within the limits of the whole of
Amravati District.G.N., H.D., No. BPA. 4462/510-V, dated 17th January, 1962 (M.G., Part. IV-B,
page 154) - In exercise of the powers conferred by sub-section (1) of section 118 of the Bombay Police
Act, 1951 (Bombay XXII of 1951), the Government of Maharashtra hereby brings the said section
into force in the area within the Municipal limits of Dhulia City and Nandurbar Town.G.N., H.D.,
No. BPA. 4463/99652-V, dated 21st May, 1964 (M.G., Part IV-B, page 534) - In exercise of the
powers conferred by sub-section (1) of section 118 of the Bombay Police Act, 1951 (Bombay XXII of
1951), the Government of Maharashtra hereby directs that on and with effect 1054/52106-V, dated
the 28th December, 1956 the Government of Maharashtra hereby directs that whenever a member
of the Delhi Special Police Establishment of or above the rank of Sub-Inspector investigates at any
place in the said area offences or classes of offences specified in Government of India, Ministry of
Home Affairs, Notification No. 7/5/55-AVD, dated the 6th November, 1956 as amended from time
to time issued under section 3 of the Delhi Special Police Establishment Act, 1946, he shall be
deemed to be an officer in charge of the police station within the limits of which such place is
situated.G.N., S.W.C.A.S. & T.D., No. SPB-1086/53404/CR-215/CUL-1, dated 12th November, 1986
(M.G., Part IV-B page 1084) - In exercise of the powers conferred by sub-clause (iii) of clause (wa) of
sub-section (1) of section 33 of the Bombay Police Act, 1951 (Bombay XXII of 1951), the Government
of Maharashtra is pleased to extend the tenure of the existing Stage Performance Scrutiny Board,
constituted under Government Notification No. SPB-1083/73898/CR-142/CUL, dated 21st
November, 1983, read with Government Notification of even number, dated the 18th May, 1984Bombay Police Act, 1951

upto 31st December, 1986.G.N., S.W., C.S.A. & T.D., No. SPB. 1088/839(200)/CUL-I, dated 27th
July, 1988, (M.G., Part IV-B, page 662) - In exercise of the powers conferred by sub-clause (iii) of
clause (wa) of sub-section (1) of section 33 of the Bombay Police Act, 1951 (Bombay XXII of 1951),
the Government of Maharashtra was pleased to reconstitute the State Performance Scrutiny Board
in the State of Maharashtra with effect from 12th October, 1987 wherein Shri Anil Thatte was
nominated as a member of the said Board. The nomination of Shri Anil Thatte is cancelled with
effect from the date of this notification.G.N., S.W., C.A.S. & T.D. No. SPB.
1090/325/CR-70/CUL-III, dated 3rd November, 1990 (M.G., Part IV-B, page 2718) - In exercise of
the powers conferred by sub-clause (iii) of clause (wa) of sub-section (1) of section 33 of the Bombay
Police Act, 1951 (Bombay XXII of 1951), the Government of Maharashtra is pleased to reconstitute
the State Performance Scrutiny Board in the State of Maharashtra with effect from 3rd November,
1990 and to nominate the following persons on the Board for a period of three years with effect from
that date:-
1.Shri Purushottam Darwhekar, Bombay/Nagpur  Chairman
2.Shri Daji Bhatvadekar, Bombay ..Member.
3.Shri Sudhir Damle, Bombay ..Member.
4.Shri Daya Pawar, Bombay ..Member.
5.Shri Shahir Sable, Bombay ..Member.
6.Shri Rajaram Shinde, Bombay-Chiplun ..Member.
7.Dr. Nirmalkumar Phadkule, Solapur ..Member.
8.Shri Ram Jadhav, Akola ..Member.
9.Smt. Anuradha Potdar, Pune ..Member.
10.Shri Baba Kadam, Kolhapur ..Member.
11.Dr. U.M. Pathan, Aurangabad ..Member.
12.Shri B.H. Kalyankar, Aurangabad ..Member.
13.Shri Vaman Nimbalkar, Nagpur ..Member.
14.Prof. Ashok Joshi, Chopda ..Member.
15.Shri Prabhakar Gharpure, Nashik ..Member
G.N., S.W., C.A.S. & T.D. No. SPB. 1090/325/CR-70/CUL-III, dated 6th March, 1991 (M.G., Part
IV-B, page 230) - In exercise of the powers conferred sub-section (iii) of clause (wa) sub-section (1)
of section 33 of the Bombay Police Act, 1951 (Bombay XXII of 1951), the Government of
Maharashtra has reconstituted the State Performance Scrutiny Board in the State of Maharashtra.
The Government is pleased to nominate the following three additional persons on the said Board
from the 16th day of June 1964 the said section 118 shall come into force in the areas within the
limits of,-(1)the City of Poona as constituted under the Bombay Provincial Municipal Corporations
Act, 1949 (Bombay LIX of 1949), and(2)the Cantonments of Poona and Kirkee as constituted under
the Cantonments Act, 1924 (II of 1924).G.N., H.D., No. BPA. 1985/16453-POL-3, dated 24th
September, 1985 (M.G., Part IV-B, page 2090) - In exercise of the powers conferred by sub-section
(1) of section 118 of the Bombay Police Act, 1951 (Bombay XXII of 1951), the Government of
Maharashtra hereby brings the said section into force in the area within the limits of the whole of
Akola District.G.N., H.D., No. BPA. 1186/35(282)-POL-3, dated 15th July, 1986 (M.G., Part IV-B,Bombay Police Act, 1951

page 509) - In exercise of the powers conferred by sub-section (1) of section 118 of the Bombay
Police Act, 1951 (Bombay XXII of 1951), the Government of Maharashtra hereby brings said section
into force in the area within the limits of the whole of Pandharpur Taluka of Solapur District.G.N.,
H.D., No. UNF. 1455-D dated 6th May, 1955 (B.G., Part IV-B, page 1164) - In exercise of the powers
conferred by section 149-A of the Bombay Police Act, 1951 (Bombay XXII of 1951), the Government
of Bombay hereby authorises the Inspector-General of Police, State of Bombay, for the whole of the
State and the Commissioner of Police, Greater Bombay, and the District Magistrates for the areas
within their respective jurisdictions, for the purposes of the said section 149-A.G.N., H.D., No. (Spl.)
No. REH. 0199/147/SPL-5, dated the 11th November, 1999 (M. G. Part IV-B, dated 10-2-2000, page
325) - In supersession of Order No. REH. 0199/97/SPL-5, dated the 27th September, 1999, the
Government of Maharashtra hereby empowers Principal Secretary (Appeals and Security) to the
Government of Maharashtra, Home Department to exercise all the powers of the State Government
under the 3rd proviso to sub-section (1) of section 33 of the Bombay Police Act, 1951.G.N., H.D., No.
(Spl.) No. EXT. 3199/199/SPL-5, dated the 11th November, 1999 (M. G. Part IV-B, dated 10-2-2000,
page 326) - In supersession of Order No. EXT. 3199/199/SPL-5, dated the 27th September, 1999,
the Government of Maharashtra is hereby pleased to specify Principal Secretary (Appeals and
Security) to the Government, Home Department as the "Specified Officer" to exercise the powers
conferred by section 60 of the Bombay Police Act, 1951 (Bombay XXII of 1951) and also to empower
him to exercise the powers under section 63 of the Bombay Police Act, 1951.G.N., H.D., No. DPE.
1060/30288-V, dated 27th December, 1960 (M.G., 1961, Part IV-B, page 76) - Whereas under the
Government of India, Home Department, Order No. 56/6/46-Police, dated the 1st October, 1946,
made under sub-section (1) of section 5 of the Delhi Special Police Establishment Ordinance, 1946
(No. XXII of 1946), and the Government of India, Ministry of Home Affairs, Notification No.
24-1-51-Police-III, dated the 15th April, 1952, made under sub-section (1) of section 5 of the Delhi
Special Police Establishment Act, 1946 (XXV of 1946), the powers and jurisdiction of the members
of Delhi Special Police Establishment extend to the entire area now comprised in the State of
Maharashtra for the investigation of certain offences or class of offences;And whereas, under
sub-section (2) of the said section 5, a member of the said police establishment, while discharging
the functions of a police officer in the said area is to be deemed to be a member of the police force of
that area and to be vested with the powers, functions and privileges and to be subject to the
liabilities of a police officer belonging to the police force of the area aforesaid;Now, therefore, in
exercise of the powers conferred by section 5 of the Bombay Police Act, 1951 (Bombay XXII of 1951),
and in supersession of the Government Order, Home department, No. DPF.
2. Shri Shantikumar Bhat, Member.
3. Shri Shashikant Tembe, Member.
G.N., S.W., C.A., S. & T.D. No. SPB-1180/265 (697)/D-XII, dated 9th October, 1980 (M.G., Part
IV-B, page 983) - In exercise of the powers conferred by sub-clause (iii) of clause (we) of sub-section
(1) of section 33 of the Bombay Police Act, 1951 (Bombay XXII of 1951), the Government of
Maharashtra is pleased to extend the term of the State Performances Scrutiny Board, constituted
under Government Notification, No. SPB. 1117/XII/6682/XII, dated the 31st May, 1977 and last
extended upto 30th September, 1980, under Government Notification, No. SPB.Bombay Police Act, 1951

1180/275(697)/D-XII dated the 9th September, 1980 further till the Board is reconstituted by
Government.G.O., H.D., No. CAA. 1266/38931-VII, dated 19th April, 1967 (M.G., Part IV-B, page
1371) - In exercise of the powers conferred by sub-section (2) of section 45 of the Bombay Police Act,
1951 (Bombay XXII of 1951), and in supersession of Government Notifications, Home Department,
No. 5554/6, dated the 25th May 1955 and No. 5554/6, dated the 6th September, 1955, the
Government of Maharashtra is pleased to appoint the following persons to be Veterinary
Practitioners for the purposes of the said Act, for the Greater Bombay limits:-Dr. D.S. Jadhav.Dr.
V.B. Kulkarni.Dr. V.G. Joshi.Dr. M.H. Nagamia.Dr. K.V. Joshi.Dr. V.G. Patilkulkarni.Dr. S.T. Kathe
Dr. D.M. Khare.Dr. K.M. Shingalgri.Dr. D.V. Deshpande.Dr. V.L. Paranjpe.Dr. P.V.
Naik.Notification No. CR.P.O./78/9845/Pol-3, dated the 2nd June, 1979 - In exercise of the powers
conferred by sub-section (3) of section 197 of the Code of Criminal Procedure, 1973 (II of 1974), the
Government of Maharashtra hereby directs that the provisions of sub-section (2) of that section
shall apply to the following categories of the members of the force in the State charged with the
maintenance of public order wherever they may be serving, namely:-(1)All police officers as defined
in the Bombay Police Act, 1951 (Bombay XXII of 1951), other than the Special or Additional Police
Officers appointed under section 21 or 22 of that Act.(2)All Reserve Police Officers as defined in
Bombay State Reserve Police Force Act, 1951 (Bombay XXXVII of 1951).Bombay Police Act, 1951

