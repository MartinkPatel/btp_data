Competition Commission Of India vs Bharti Airtel Ltd on 5
December, 2018
Equivalent citations: AIR 2019 SUPREME COURT 113, AIRONLINE 2018 SC
830
Author: A.K. Sikri
Bench: A.K. Sikri, Ashok Bhushan, S. Abdul Nazeer
                                                                                                REPORTABLE
                                              IN THE SUPREME COURT OF INDIA
                                                CIVIL APPELLATE JURISDICTION
                                          CIVIL APPEAL NO(S). 11843 OF 2018
                                       (ARISING OUT OF SLP (C) NO. 35574 OF 2017)
                         COMPETITION COMMISSION OF INDIA                                   .....APPELLANT(S)
                                                       VERSUS
                         BHARTI AIRTEL LIMITED AND OTHERS                                .....RESPONDENT(S)
                                                                   WITH
                                     CIVIL APPEAL NO(S). 11844-11845 OF 2018
                                 (ARISING OUT OF SLP (C) NOS. 35532-35533 OF 2017)
                                          CIVIL APPEAL NO(S). 11846 OF 2018
                                       (ARISING OUT OF SLP (C) NO. 35497 OF 2017)
                                           CIVIL APPEAL NO(S). 11852 OF 2018
                                         (ARISING OUT OF SLP (C) NO. 115 OF 2018)
                                                                    AND
                                     CIVIL APPEAL NO(S). 11847-11851 OF 2018
                                 (ARISING OUT OF SLP (C) NOS. 37285-37289 OF 2017)
                                                         JUDGMENT
A.K. SIKRI, J.Competition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

Leave granted.
2) Reliance Jio Infocomm Limited (hereinafter referred to as 'RJIL') has filed information under
Section 19(1) of the Competition Act, 2002 (hereinafter referred to as the 'Competition Act') before
the Competition Commission of India (for short, 'CCI') alleging anti- competitive agreement/cartel
having been formed by three major telecom operators, namely, Bharti Airtel Limited, Vodafone
India Limited and Idea Cellular Limited (Incumbent Dominant Operators) (hereinafter referred to
as the ‘IDOs’). Similar Informations under Section 19 of the Competition Act were also filed by one
Mr. Ranjan Sardana, Chartered Accountant, and Mr. Justice Kantilal Ambalal Puj (Retd.). These
were registered by the CCI as Case Nos. 80-81, 83 and 95 respectively. As per Section 26 of the
Competition Act, on receipt of such an information, the CCI has to form an opinion as to whether
there exists a prima facie case or not. If it is of the opinion that there exists a prima facie case, the
CCI directs the Director General to cause an investigation to be made into the matter. Apart from
the IDOs, certain allegations were also made against the Cellular Operators Association of India (for
short, 'COAI'). The CCI issued notice to these parties and after hearing the RJIL, the aforesaid
cellular companies and COAI, it passed a common order dated April 21, 2017 in all these cases (by
clubbing them together) holding a view that prima facie case exists and an investigation is
warranted into the matter. It, accordingly, directed the Director General to cause investigation in the
case.
Introduction:
3) Four writ petitions came to be filed by the Bharti Airtel Limited, Vodafone India
Limited, Idea Cellular Limited and COAI respectively. The prayed for quashing of the
aforesaid order and consequential action/proceedings on the ground that the CCI did
not have any jurisdiction to deal with such a matter. Show-cause notices were issued
pursuant to which the CCI as well as RJIL filed their counter affidavits. The mater
was heard and vide judgment dated September 21, 2017 the High Court has allowed
these writ petitions and quashed/set aside the order dated April 21, 2017 passed by
the CCI and consequently notices issued by the Director General of the CCI have also
been quashed. We may reproduce the conclusions and operative portion of the order
passed by the Bombay High Court here itself, which are as under:
"130. Conclusions:
a) All the Writ Petitions are maintainable and entertainable. This Court has territorial
jurisdiction to deal and decide the challenges so raised against impugned order
(majority decision) dated 21 April 2017, passed by the Competition Commission of
India (CCI) under the provisions of Section 26(1) of the Competition Act, 2002 in
case Nos. 81 of 2016, 83 of 2016 and 95 of 2016 and all the consequential
actions/notices of the Director General under Section 41 of the Competition Act
arising out of it.Competition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

b) The telecommunication Sector/Industry/Market is governed, regulated, controlled
and developed by the Authorities under the Telegraph Act, the Telecom Regulatory
Authority of India Act (TRAI Act) and related Regulations, Rules, Circulars, including
all government policies. All the “parties”, “persons”, “stakeholders”, “service
providers”, “consumers” and “enterprise” are bound by the statutory
agreements/contracts, apart from related policy, usage, custom, practice so
announced by the Government/Authority, from time to time.
c) The question of interpretation of clarification of any “contract clauses”, “unified
license”, “interconnection agreements”, “quality of service regulations”, “rights and
obligations of TSP between and related to the above provisions”, are to be settled by
the Authorities/TDSAT and not by the Authorities under the Competition Act.
d) The concepts of “subscriber”, “test period”, “reasonable demand”, “test phase and
commercial phase rights and obligations”, “reciprocal obligations of service
providers” or “breaches of any contract and/or practice”, arising out of TRAI Act and
the policy so declared, are the matters within the jurisdiction of the Authority/TDSAT
under the TRAI Act only.
e) The Competition Act and the TRAI Act are independent statutes. The statutory
authorities under the respective Acts are to discharge their power and jurisdiction in
the light of the object, for which they are established. There is no conflict of the
jurisdiction to be exercised by them. But the Competition Act itself is not sufficient to
decide and deal with the issues, arising out of the provisions of the TRAI Act and the
contract conditions, under the Regulations.
f) The Competition Act governs the anti-competitive agreements and its effect – the
issues about “abuse of dominant position and combinations”. It cannot be used and
utilized to interpret the contract conditions/policies of telecom
Sector/Industry/Market, arising out of the Telegraph Act and the TRAI Act.
g) The Authority under the Competition Act has no jurisdiction to decide and deal
with the various statutory agreements, contracts, including the rival
rights/obligations, of its own. Every aspects of development of telecommunication
market are to be regulated and controlled by the concerned Department/
Government, based upon the policy so declared from time to time, keeping in mind
the need and the technology, under the TRAI Act.
h) Impugned order dated 21 April 2017 passed by the Competition Commission of
India (CCI) under the provisions of Section 26(1) of the Competition Act, 2002 and
all the consequential actions/notices of the Director General under Section 41 of the
Competition Act proceeded on wrong presumption of law and usurpation of
jurisdiction, unless the contract agreements, terms and clauses and/or the related
issues are settled by the Authority under the TRAI Act, there is no question toCompetition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

initiating any proceedings under the Competition Act as contracts/agreements go to
the root of the alleged controversy, even under the Competition Act.
i) The Authority, like the Commission and/or Director General, has no power to deal
and decide the stated breaches including of “delay, “denial”, and “congestion” of POIs
unless settled finally by the Authorities/TDSAT under the TRAI Act. Therefore, there
is no question to initiate any inquiry and investigations under Section 26(1) of the
Competition Act. It is without jurisdiction. Even at the time of passing of final order,
the Commission and the Authority, will not be in a position to deal with the
contractual terms and conditions and/or any breaches, if any. The uncleared and
vague information are not sufficient to initiate inquiry and/or investigation under the
Competition Act, unless the governing law and the policy of the concerned “market”
has clearly defined the respective rights and obligations of the concerned
parties/persons.
j) Impugned order dated 21 April 2017 and all the consequential actions/notices of
the Director General under the Competition Act, therefore, in the present facts and
circumstances, are not mere “administrative directions”.
k) Impugned order dated 21 April 2017 and all the consequential actions/notices of
the Director General under the Competition Act are, therefore, illegal, perverse and
also in view of the fact that it takes into consideration irrelevant material and ignores
the relevant material and the law.
l) Every majority decision cannot be termed as “cartelisation”. Even ex-facie service
providers and its Association COAI have not committed any breaches of any
provisions of the Competition Act.
131. Hence the following ORDER
a) Impugned order dated 21 April 2017, passed by the Competition Commission of
India (CCI) under the provisions of Section 26(1) of the Competition Act, 2002 in
case Nos. 81 of 2016, 83 of 2016 and 95 of 2016 and all the consequential
actions/notices of the Director General under Section 41 of the Competition Act, are
liable to be quashed and set aside, in exercise of power under Article 226 of the
Constitution of India. Order accordingly.
b) All the Writ Petitions are allowed.
c) There shall be no order as to costs.
d) In view of the above, nothing survives in Civil Application (Stamp) No. 17736 of
2017 in Writ Petition No. 7164 of 2017 and the same is also disposed of. No costs.”Competition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

4) Gist of the aforesaid order, as per the High Court, is that insofar as the telecom
sector/industry/market is concerned, same is governed, regulated, controlled and
developed by the authorities under the India Telegraph Act, 1885 (hereinafter
referred to as the ‘Telegraph Act’), the Telecom Regulatory Authority of India Act,
1997 (for short, ‘TRAI Act’), and as well as the related Regulations, Rules, Circulars,
etc. Therefore, the question of interpretation or clarification of any “contract clauses”,
“unified license”, “interconnection agreements”, “quality of service regulations”,
“rights and obligations of TSP between and related to the above provisions”, are to be
settled by the Authorities/Telecom Disputes Settlement and Appellate Tribunal
(TDSAT) and not by the Authorities under the Act. It has also held that the
Competition Act and the TRAI Act are independent statutes and the statutory
authorities under the respective Acts are to discharge their power and jurisdiction in
the light of the objectives for which they are established. The Competition Act is itself
not sufficient to decide and deal with the issues arising out of the provisions of the
TRAI Act etc. Thus, the CCI has no jurisdiction to decide and deal with the various
statutory agreements, contracts, including rival rights/obligations, of its own. The
issues arising out of contract agreements, terms and clauses and/or the related issues
are to be settled by the authority under the TRAI Act in the first instance and unless
these issues are decided, there is no question of initiating any proceedings under the
Act. In a nutshell, it is held that insofar as contracts, etc. which are regulated by the
TRAI Act are concerned, in the first instance, it is the authority under the TRAI Act
which has to decide these questions. Once there is a determination of the respective
rights and obligations under these licenses by the authority under the TRAI Act,
which provided an information to the effect that the particular act appears to be anti-
competitive, only thereafter the CCI gets jurisdiction to go into the question of such anti-competitive
practice. Primarily the message behind the decision of the High Court is that jurisdictional facts are
to be decided by the authorities under the TRAI Act which has the exclusive jurisdiction to
determine those issues as the TRAI is the statutory authority established for this very purpose, and
unless there is a determination of these facts, the machinery under the Competition Act cannot be
invoked. To put it otherwise, the judgment proceeds to decide that it was premature for the CCI to
entertain the Information for want of determination of such issues that fall within the domain of the
TRAI Act.
5) It is obvious that the RJIL is not happy with the aforesaid outcome. Even the CCI feels aggrieved.
CCI has impugned this decision by filing four special leave petitions, while the other one has been
filed by the RJIL.
6) The material facts which are absolutely essential to determine the controversy, eschewing the
unnecessary details, may now be recapitulated:
Factual Background:Competition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

With the decision of the Government of India, more than 25 years ago, ushering into
era of globalisation and liberalisation, lot of avenues opened up. It led to the
privatisation of business in many sectors which were, hitherto, monopolistic domain
of the Government. These included aviation, insurance, telecommunication etc. With
the opening of the industrial and other activities in all spheres by placing it in the
hands of private sector led to a significant economic development. The absolute
control of the Government through public enterprise or otherwise, which had seen
licence and quota raj, virtually withered away, thereby reverting back to laissez faire
economy to a great extent, though not completely. It led to two significant
developments:
In the first instance, though the private sector was given full freedom to do the
business without any shackles in the form of controls etc., it was also deemed
necessary at the same time that in public interest, some of the aspects of the business
need to be regulated, of course, not by the Government but by an independent
regulatory authority. This necessity prompted the Government to come out with
regulatory regime in different sectors. For example, in insurance sector, we have
regulatory authority constituted under Insurance Regulatory and Development
Authority Act, 1999; for industries generating electricity, there is an electricity
regulatory authority constituted under the Electricity Act, 2003; and for telecom
sector, with which we are concerned, the TRAI is constituted under the provisions of
TRAI Act.
Secondly, this requirement to do business thereby allowing free entry to private
enterprise led to competition between different players in the private sector.
Competition is perceived as a phenomena which is in best public interest in so many
ways.
Therefore, it becomes necessary to encourage competition. At the same time,
tendency of the business enterprises to adopt practices which retard healthy
competition needed to be curbed.
There was a governing law in the field known as Monopolistic and Restrictive Trade
Practice Act, 1969. However, it was felt that a new robust statutory regime is required
to take care of the needs of the present day. This necessity prompted the Parliament
to come out with a new Act on the subject and the Competition Act, 2002 was passed
by the Parliament. Under this Act, the CCI is constituted as a statutory body which is
to ensure healthy competition in markets thereby preventing the practice of having
adverse effect on competition; to promote and sustain the competition in markets; to
protect the interest of consumers and to ensure freedom of trade. In that sense, the
CCI is also a regulator. But a unique feature of the CCI is that it is not sector based
body but has the jurisdiction across which transcends sectoral boundaries, thereby
covering all the industries, with focus on the aforesaid object and purpose behind the
Competition Act, 2002.Competition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

7) In the instant appeals, width and scope of the powers of the CCI under the
Competition Act, 2002 pertaining to telecom sector i.e. in respect of the companies in
telecom industry providing telecom services is to be defined vis-a-vis the scope of the
powers of TRAI under the TRAI Act, 1997. It has arisen in these appeals, in the
following background:
As mentioned above, TRAI is the regulatory which regulates the functioning of the
telecom service provider i.e. the telecom sector. Section 11 of the TRAI Act
enumerates various functions which TRAI is supposed to perform under the Act.
Section 13, likewise, empowers the TRAI to issue directions, from time to time, to the
service provider. In exercise of powers under Section 13 read with Section 11 of the
TRAI Act, the TRAI issued directions dated June 07, 2005 to all the telecom service
providers to provide interconnection within ninety days of the applicable payments
made by the interconnection seeker. The purpose behind providing interconnection
by one service provider to the other service provider is to ensure smooth
communication by a subscriber of one service provider to the cell number which is
provided by another service provider. In that sense, this direction facilitates smooth
functioning of the cell phone network even when it is managed by different
companies as it ensures interconnectivity i.e. connectivity from one service provider
to other service provider.
8) On October 21, 2013, RJIL was granted Unified License and Unified Access Service License under
Section 4 of the Telegraph Act by the Department of Telecom (DoT) for providing
telecommunication services in all 22 circles/licensed service areas in India. Soon thereafter, RJIL
executed interconnection agreements (ICA) with existing telecom operators inter alia including,
Bharti Airtel Limited and Bharti Hexagon Limited (hereinafter collectively referred to as the
‘Airtel’), Idea Cellular Limited (hereinafter referred to as the ‘Idea’); Vodafone India
Limited/Vodafone Mobile Services Limited (hereinafter collectively referred to as the ‘Vodafone’).
RJIL commenced test trial of its services after intimation and approval of the DoT and TRAI.
9) By its ‘firm demand’ letter of June 21, 2016, RJIL vide separate letters requested IDOs to
augment Point of Interconnection (POIs) for access, National Long Distance (NLD) and
International Long Distance (ILD) services, as according to it, the capacity already provided to it
was causing huge POI congestion, resulting in call failures on its network. According to RJIL, these
companies intentionally ignored the aforesaid request. Accordingly, RJIL sent a letter dated July 14,
2016 to TRAI stating that the POIs provided by IDOs are substantially inadequate and leading to
congestion/call failures on its network in all circles. Hence, TRAI was requested to intervene and
direct these telecom operators to augment the POI capacities as per the demands made by RJIL.
TRAI vide separate letters dated July 19, 2014 requested inter alia the aforementioned telecom
operators to augment POIs as per the RJIL’s request. Further, responses of the respective
companies were also sought on the issues raised by RJIL, within seven days. Idea responded by
sending letter dated July 26, 2016 to RJIL denying that there had been any delay in augmentation of
POIs and further stated that it is willing to fully support RJIL and that it had instructed its circle
teams to augment the POIs on the basis of traffic congestion as per the ICA. Likewise, Airtel alsoCompetition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

sent reply dated August 03, 2016 to TRAI, inter alia stating that augmentation of POIs shall be
undertaken as per the terms and conditions of the ICA and on the basis of traffic trends post their
commercial launch. RJIL was not satisfied with such responses. It sent another letter dated August
04, 2016 to TRAI reiterating its earlier request for augmentation of POIs by the subject telecom
operators. In the meantime, even Cellular Operators Association of India (COAI) intervened by
addressing communication dated August 08, 2016 to TRAI wherein it took a stand by stating that
the RJIL was providing free service to millions of users under the guise of testing which led to
choking of POIs. It was further suggested that due to the free service provided by RJIL, a substantial
imbalance in voice traffic had occurred for which the existing operators were not adequately
compensated under the Interconnection Usage Charges regulations (IUC) in place.
10) There was further exchange of correspondence between the parties and even by the parties to
the TRAI which shows that the parties stuck to their respective positions and it may not be
necessary to refer to those communications in detail. Suffice it is to mention that RJIL fixed
September 05, 2016 as the launch date, which fact was informed to other service providers as well
who were also told that the subscriber base was expected to substantially and swiftly increase
resulting in even more POI congestion. On that basis, request was made for urgent POI
augmentation vide letter dated September 02, 2016. The TRAI even facilitated a meeting between
the representatives of RJIL and other service providers (respondents herein) to sort out and resolve
the differences in the interest of the consumers. At the same time, in the said meeting, the three
telecom operators (respondents herein) also raised a grievance that free calls being provided by
RJIL has resulted in an unprecedented traffic congestion on their respective networks and the
current IUC regime is inadequate to cover the cost of efficiently maintaining such high traffic.
Thereafter, vide letter dated September 14, 2016, addressed by Airtel to RJIL, it stated that the POIs
(also known as E1s) would be converted into 50:50 ratio to outgoing and incoming E1s. In other
words, the E1s provided would be converted to ‘only outgoing’ or ‘only incoming’ i.e. one-way E1s.
RJIL replied by stating that it was acceptable to them.
11) Soon thereafter, i.e. in September 2016 itself, Mr. Rajan Sardana, a Chartered Accountant, filed
information under Section 19 of the Competition Act (registered as Case No. 81 of 2016) and similar
application was filed by Justice K.A. Puj (retired) (registered as Case No. 83 of 2016). Then, it was
followed by information under Section 19 of the Competition Act by RJIL in November, 2016
(registered as Case No. 95 of 2016).
Proceedings before TRAI:
12) As the matter was with the TRAI as well, it issued show cause notices dated
September 27, 2016 to IDOs and RJIL for violation of Standard of Quality of Service
of Basic Telephone Service (Wireline) and Cellular Mobile Telephone Service
Regulations, 2009 (hereinafter referred to as the ‘QoS’) and for provision of the
License Agreements. Similar show cause notices were also sent to other telecom
operators. On October 21, 2016, TRAI issued recommendations to DoT after finding
that IDOs have violated conditions under the QoS, interconnection agreements and
Unified License. The TRAI inter alia stated in its recommendation as under:Competition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

"21. … (vii) It is evident from the above clauses that the licensees are mandated to
provide interconnection to all eligible telecom service provider. However, as
mentioned in para 6 above, Airtel along with other service providers have jointly
through their association (COAI), declined Point of Interconnection to RJIL which is
willful violation of the above mentioned license conditions.
...(x) COAI’s letter dated 2nd September, 2016 which was confirmed by Airtel in the
meeting held on 9 th September, 2016 clearly indicates attempt by three service
providers namely, Airtel, Vodafone India Limited and Idea Cellular Limited to stifle
competition in the market and willfully violate the license conditions;…
23. While the Authority has been taking necessary steps to ensure effective
interconnection between Airtel and RJIL, it is evident from Para 21 that Airtel is in
non- compliance of the terms and conditions of license and denial of interconnection
to RJIL appears to be with ulterior motive to stifle competition and is
anti-consumer.”
13) TRAI recommended that Rs. 50 crore per local service area (LSA) be imposed on
all the above three telecom operators for failure to adhere to TRAI norms and
regulations. Similar recommendations were also issued to DoT against other telecom
operators. Against the recommendations dated October 21, 2016 of TRAI, Vodafone
filed a Writ Petition being Writ Petition (C) No. 11740 of 2016 before the High Court
at Delhi. Meanwhile, on January 17, 2017, TRAI also recommended imposition of
penalty of Rs. 1,90,000/- on Idea for its rejection of mobile number portability
(MNP) requests to RJIL’s network. Against the aforesaid recommendation, Idea has
preferred a Writ Petition being Writ Petition (C) No. 685 of 2017 before the High
Court at Delhi. The DoT after examining the matter referred it back to TRAI for fresh
consideration vide DoT’s reference dated April 05, 2017 whereby its
recommendations imposing penalty upon IDOs were sent back for reconsideration.
The TRAI sent its response dated May 24, 2017 to the DoT, wherein it took a
categorical stand that telecom operators have intentionally denied and delayed the
augmentation of POIs to RJIL.
Proceedings before CCI:
14) The CCI took the cognizance of the three informations given to it under Section 19
of the Competition Act which were registered as Case Nos. 81, 83 and 95 of 2016. It
gave hearing to the respondents service providers as well as COAI and passed order
dated April 21, 2017 under Section 26(1) of the Competition Act as per which it came
to a prima facie conclusion that case for investigation was made out and directed the
Director General to cause investigation in the case. This order was passed by majority
of 3:2 as two members of CCI dissented from the said order. Operative portion of the
majority order holds as under:Competition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

"23. The Commission notes that allegations of anti- competitive agreement as well as
abuse of dominant position have been made for the same conduct of refusal to
facilitate call termination services and denial of mobile number portability. As
discussed earlier, the Commission is satisfied that there exist a prima facie
contravention of Section 3(3)(b) of Act, as the ITOs appear to have entered into an
agreement amongst themselves through the platform of COAI, to deny POIs to RJIL.
Having been prima facie convinced that the impugned conduct is an outcome of the
anti-competitive agreement amongst ITOs, Commission does not find it appropriate
to consider the same impugned conduct as unilateral action by each of the ITOs. The
Commission therefore at this stage does not find it necessary to deal with the
allegations and submissions regarding abuse of dominance in contravention of the
provisions of Section 4 of Act.
24. In view of the foregoing, the Commission directs the DG to cause an investigation
into the matter under the provisions of Section 26(1) of the Act. Considering the
substantial similarity of allegations in all the informations, the Commission clubs
them in terms of the proviso to Section 26(1) of the Act read with Regulation 27 of the
Competition Commission of India (General) Regulations, 2009. The DO is directed to
complete the investigation and submit investigation report within a period of 60 days
from the date of receipt of this Order, if the DG finds contravention, he shall also
investigate the role of the persons who at the time of such contravention were in-
charge of and responsible for the conduct of the business of the contravening
entity/entities. During the course of investigation, if involvement of any other party is
found, DG shall investigate the conduct of such other parties also who may have
indulged in the said contravention. In case the DG finds the conduct of the Opposite
Parties in violation of the Act, the DG shall also investigate the role of the persons
who were responsible for the conduct of the Opposite Parties so as to proceed against
them in accordance with Section 48 of the Act.
25. The Commission makes it clear that nothing stated in this order shall tantamount
to final expression of opinion on the merits of the case and DG shall conduct the
investigation without being swayed in any manner whatsoever by the observations
made herein.”
15) Likewise, two members who dissented inter alia held as follows:
"...As stated above, from the various charts placed on record by the ITOs showing the
number of POIs provided by them to RJIL, the respective learned senior counsel for
Ops have tried to show that the number of POIs provided to RJIL by 08.11.2016 i.e.
within the first quarter itself, were much more than what was demanded. In fact, the
charts filed by RJIL itself corroborate this fact. The charts show that even if some of
the POIs provided (one-way POIs for connecting outgoing calls from ITOs to RJIL)
are not taken into consideration, the number of POIs provided by OP-5 and OP-7
were much more than what was demanded by RJIL. Even in case of OP-2, the sameCompetition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

were approximately 64% (NLD POIs) and 85.53% (Access POIs) as on 08.11.2016.
However, as we have already observed above, we are not expected to go into the
question of providing adequate number of POIs. Yet there is ample material on
record to show that RJIL was more to be blamed for congestion in its traffic than the
ITOs...” “...we are of the considered opinion that on the basis of material available
with the Commission, it is difficult to say that there is a prima facie case...” made out
against the Petitioner and others and accordingly, “...the instant cases ought to be
closed under Section 26(2) of the Act...” (hereafter “Dissent Note”).”
16) On June 08, 2017, the Director General issued a letter of investigation to the
appellant seeking call data records in respect of certain identified mobile numbers by
June 19, 2017. On June 19, 2017, respondent No. 2 issued a letter of investigation to
the appellant seeking detailed information/documents to be furnished by June 30,
2017. Immediately thereafter, writ petitions were filed challenging the aforesaid
order of the CCI as well as action of the Director General seeking information for
holding inquiry. After preliminary hearing, the High Court passed interim orders
dated June 30, 2017 on the basis of statement of the counsel for CCI that they shall
not proceed with the investigation, which order continued till the disposal of the writ
petitions. The High Court after hearing the matter finally allowed the writ petitions,
as already mentioned.
17) It is clear from the above that as per RJIL, the respondent service providers, along
with COAI, entered into an anti-competitive agreement/formed a cartel and acted in
an anti-competitive manner which is prohibited by the Act. On these allegations, it
approached the CCI for initiating inquiry into this anti-competitive practices. Insofar
as the nature of alleged anti-competitive agreement is concerned, the allegations of
RJIL are the following:
(i) Delay in provisioning or denial in provisioning of POIs, also known as ‘E1’ in
telecom parlance, to RJIL by IDOs during the testing phase and after commercial
launch of RJIL services.
POIs are the points where the networks of telecom operators connect. Without sufficient POIs it is
not possible for subscribers of one service provider to make calls to subscribers of another service
provider.
(ii) It was also alleged, inter alia, that IDOs are denying Mobile Number Portability (MNP) requests
of customers who wanted to switch to RJIL competing service.
(iii) It was also alleged that COAI was acting at the behest of IDOs against the interest of a
competing member, i.e. RJIL, and not for the common interest of the industry and consumers as a
whole.
Proceedings before the High Court:Competition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

18) Against the order passed by the CCI directing investigation into the aforesaid
allegations, in the writ petitions filed by the IDOs and also by COAI, challenge laid to
the aforesaid order was premised on the ground that the CCI lacked jurisdiction to
entertain such complaints/information filed under Section 19 of the Competition Act
as such a matter falls within the exclusive jurisdiction of another regulatory
authority, namely, TRAI.
19) In nutshell, it was pleaded that the violation alleged by RJIL, namely, whether
there was a delay or denial in provisioning POIs, comes within the domain of TRAI as
it is the TRAI which has the exclusive jurisdiction to deal with such a matter under
the TRAI Act and, in fact, the complaint was also made by TRAI as well which was
seized of the matter.
20) The plea of the appellants, on the other hand, was that violation of telecom
regulations, etc. was undoubtedly a matter which could be looked into by the TRAI
for which RJIL has approached the TRAI. However, the subject matter of inquiry
before the CCI was entirely different, namely, formation of cartel and a concerted
effort on the part of the service providers, in collusion with COAI, to curb the
competition in the market and, thus, the CCI was competent and had requisite
jurisdiction to look into this aspect.
To put it otherwise, according to the appellants, the CCI had decided to examine the facts purely
from the stand point as to whether the alleged Act constituted anti-competitive practice on the part
of the respondents and, therefore, contravened the provisions contained in Section 3 or Section 4 of
the Act. This aspect, they had argued, could not be gone into by the TRAI as the CCI was the only
statutory authority constituted under the Act to examine such an issue.
21) The Bombay High Court in the impugned judgment has, thus, inter alia, held as under:
"(i) the Competition Commission of India (CCI) had no jurisdiction in view of the
Telecom Regulatory Authority of India Act, 1997 and the authorities and regulations
made thereunder;
(ii) the CCI could exercise jurisdiction only after proceedings under the TRAI Act had
concluded/attained finality;
(iii) the order dated 21.04.2017 passed under section 26(1) of the Competition Act
was not an administrative direction, but rather a quasi judicial one that finally
decided the rights of parties and caused serious adverse consequences, because a
detailed hearing had been given and many materials had been tendered in the courts
of the hearings;
(iv) on the merits of the matter, there was no cartelisation as alleged and COAI was
exonerated; andCompetition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

(v) the order of the CCI was perverse and liable to be interfered with under writ
jurisdiction.” Arguments: The appellants:
22) Mr. P.S. Narasimha, learned Additional Solicitor General, appeared on behalf of
the CCI and submitted that the impugned judgment is contrary to the law. His attack
was premised on three principal propositions, which are follows:
(i) Jurisdiction of the CCI: The CCI has jurisdiction in the present case and it need
not wait till the conclusion of proceedings under the TRAI Act to conclude.
(ii) Scope of Judicial Interference under Article 226: The High Court erred in holding
that the order passed under section 26(1) was an order resulting in serious adverse
consequences merely because the CCI had granted a hearing.
(iii) The order of CCI was not perverse and the High Court erred in giving findings on
merits. The High Court erroneously exercised writ jurisdiction.
23) With respect to the first proposition, his argument was that the High Court had
failed to appreciate that issues before the CCI are altogether different than the issues
before the TRAI and they necessarily be treated differently. He argued that the CCI
and TRAI operate in entirely different fields, which is discernible from the Preambles
of the respective legislations. The TRAI Act was supposed to enable it to regulate the
telecommunication services, adjudicate dispute, dispose of appeals and protect the
interests of service providers and consumers of the telecom sector, to promote and
ensure orderly growth of the telecom sector. The CCI, on the other hand, is a body
that has been established to prevent practices having an adverse effect on
competition, to promote and sustain competition in markets, to protect the interests
of consumers and to ensure freedom of trade carried on by other participants in
markets, in India.
24) Mr. Narasimha emphasised that the issue before the CCI was whether the
opposite parties/respondents, i.e. the IDOs, were acting in concert and colluding
(forming a cartel) so as to block or hinder the entry of RJIL in the market in violation
of section 3(3)
(b) of the Act. The key issue is whether there was an anti-
competitive agreement between the IDOs, using the platform of COAI. The issue before the TRAI,
on the other hand, is whether the delay/denial of POIs has violated terms of the licence agreement
and QoS regulations. The learned ASG pointed out that all the opposite parties have argued that
they were justified in declining POIs to RJIL. However, the question before the CCI is whether the
conduct of the parties was unilateral or collective action based on an agreement? It is precisely this
issue that requires investigation by the Director General. If the conduct of the respondents in
delaying/denying POIs was unilateral (i.e. an independent decision made by each of them), then theCompetition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

conduct cannot be faulted under Section 3 of the Act since Section 3 is premised on existence of an
‘agreement’ as defined in Section 2(b). However, if the conduct of the respondents was based on an
‘agreement’, it would become illegal under Section 3(3)(b) of the Act because its intent and effect is
to ‘limit or control production, supply, markets, technical development, investment or provision of
services”. It was contended that the conduct may well be legal under the TRAI Act and regulations
or other laws. However, it is the collusive/concerted nature of the action coupled with the effect that
makes it illegal under the Competition Act.
25) He adverted to the order dated April 21, 2017 of the CCI, while taking its prima facie view and
submitted that the CCI has recognised the distinction between the issues before the TRAI and the
issues arising under the Act, as follows:
"9. It is observed that telecom sector is regulated by TRAI as the sectoral regulator.
On the allegation of insufficient POIs being provided to RJIL, the Commission notes
from the information available on TRAI’s website that, on 21st October 2016, TRAI
had recommended, through three separate communications to the Department of
Telecommunications, imposition of penalty of Rs.50 crore per License Service Area
(LSA) against Airtel, Vodafone and Idea, for violation of the provisions of License
Agreements and the Standards of QoS of Basic Telephone Service (Wireline) and
Cellular Mobile Telephone Service Regulations, 2009. Thus, TRAI as a sectoral
regulator, has held the said conduct of ITOs in violation of relevant TRAI regulations
and recommended penal action against them. However, the recommendations of
TRAI is in respect of violations of the provisions of License Agreements and the
Standards of QoS of Basic Telephone Service (Wireline) and Cellular Mobile
Telephone Service Regulations, 2009 by these OPs. Against this, mandate of the
Commission under Section 18 of the Act is ‘...to eliminate practices having adverse
effect on competition, promote and sustain competition, protect the interests of
consumers and ensure freedom of trade carried on by other participants, in markets
in India.’ Accordingly, it becomes the duty and responsibility of the Commission to
eliminate practices in the market that have an adverse effect on competition and
promote and sustain competition so as to protect the interest of consumers and
ensure freedom of trade. Further, as per Section 62 of the Act, provisions of the Act
are in addition to and not in derogation of the provisions of any other law for the time
being in force. Section 61 of the Act grants exclusive power to the Commission and
the Competition Appellate Tribunal to exercise its jurisdiction in respect of any
matter which the Act empowers the Commission or the Competition Appellate
Tribunal to determine to the exclusion of civil courts. A careful reading of these
provisions show that the Commission has the jurisdiction to inquire into the issues
alleged in the present information insofar as the same may result in contravention of
the provisions of the Act.
10. It may be noted that the primary grievance of the Informants relates to
cartelization by the Opposite Parties, amounting to violation of the provisions of
Section 3 of the Act. In this regard, it must be noted that none of the areas coveredCompetition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

under Section 3 of the Act are covered by TRAI in its mandate as a sector regulator
for TSPs. No doubt, TRAI has the responsibility/obligation to determine whether
Quality of Service regulations and interconnection norms on the levels of congestion
at the points of interconnection are complied with it not. But apart from that, none of
the other issues as envisaged under Section 3 of the Act are looked into by TRAI.
Specifically, TRAI cannot arrive at a determination as to whether the ITOs have
colluded and cartelized to deny POIs to the detriment of RJIL in violation of Section
3(3) read with Section 3(1) of the Act. The scope of the Section 3 allegation is not
whether the ITOs have breached the terms of their respective License agreement or
ICA, rather, the scope of the Section 3 allegations pertains to whether the ITOs have
entered into an anti-competitive agreement to provide insufficient POIs or delay the
provisions of POIs to RJIL. It is within the mandate of the Commission which can
adjudicate on the issue of cartelization amongst enterprises/associations and arrive
at a finding on the alleged cartelization. The Commission accordingly holds that the
issue of whether such conduct on the part of ITOs (including COAI) has resulted in
any anti-competitive effect in the market in violation of the provisions of the Act can
and needs to be examined by it.
11. The Commission recognizes the role and importance of sectoral regulators and
exercises its jurisdiction keeping in mind their role and responsibilities. The
Commission is a market regulator and has the jurisdiction to look at those issues
which affect competition in markets in India, including that of an alleged
cartelization amongst enterprises/ associations. The nature of the proceedings before
TRAI involving ITOs on the other hand different and related to whether
interconnection norms and quality of service regulations are complied with or
whether the contractual terms of ICAs have been breached or met. Palpably, these
issues are not relevant for determination in the current proceedings before the
Commission.
12. The informants have alleged that the conduct of ITOs amounts to a “cartel” in
relation to denial of POIs to RJIL. The definition of cartel has been provided under
Section 2(c) of the Act which reads as follows: ‘cartel includes an association of
producers, sellers, distributors, traders or service providers who by agreement
amongst themselves limit, control or attempt to control the production, distribution,
sale or price of or, trade in goods or provision of services.’ Further, any alleged
agreement amongst enterprises and an association of enterprises, engaged in
identical or similar trade or provision of services is covered under Section 3(3) of the
act which states that:
Any agreement entered into between enterprises or associations of enterprises or
persons or associations of persons or between any person and enterprise or practice
carried on, or decision taken by, any association of enterprises or association of
persons, including cartels, engaged in identical or similar trade of goods or provisionCompetition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

of services, which-
(a) directly or indirectly determines purchase or sale prices;
(b) limits or controls production, supply, markets, technical development, investment
or provision of services;
(c) …..
(d) …..
shall be presumed to have an appreciable adverse effect on competition.
13. On the basis of the above, the Commission notes that in addition to ITOs, conduct of COAI also
needs to be examined under the provisions of Section 3(3) of the Act.” (emphasis added)
26) He submitted that it was the statutory duty of the CCI, enumerated in Section 18 of the Act, to
eliminate anti-competitive practices and the focus of the CCI was confined to this Court’s judgment
in the case of Haridas Exports v. All India Float Glass Manufacturers’ Assn. & Ors. 1 wherein it was
held that where statutes operate in different fields and have different purposes, it cannot be said
that there is implied repeal by one, of 1 (2002) 6 SCC 600 the other. In the said case, this Court was
considering alleged conflict between the Monopolies & Restrictive Trade Practices Act, 1969 and the
Anti-Dumping Rules under the Customs Act/Customs Tariff Act. It was held:
"48. The jurisdiction of the MRTP Commission, in our opinion, is not ousted by the
anti-dumping provisions in the Customs Act. The two Acts operate in different fields
and have different purposes. The Import Control Act and the Customs Tariff Act are
concerned with import of goods into India and the duty which could be imposed on
the imported items. Import may be allowed on the basis of an import licence or,
depending upon the policy, import may be allowed under OGL — open general
licence — where no specific licence for import is required. Whether to allow import or
not and the terms on which an item may be imported is a matter of policy and
regulated by law.
xx xx xx
52. The levy or non-levy of anti-dumping or other duty being a legislative act
pursuant to the exercise of powers under the Customs Tariff Act can also not be a
subject- matter of judicial review by the MRTP Commission. The two Acts
substantially operate in different fields and the following table brings out some of the
distinctions between the MRTP Act and the anti-dumping provisions:
[table omitted] A perusal of the above chart indicates that the two statutes and
regimes operate in different and distinct spheres and there is no conflict between theCompetition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

two regimes/statutes. Hence, the question of implied repeal of the provisions of
Section 33(1)(j) of the MRTP Act, 1969 on account of the provisions of Section 9-A of
the Customs Tariff Act, 1975 does not arise.
53. It is thus seen that the provisions relating to anti-
dumping contained in the Customs Tariff Act do not in any way affect the power or jurisdiction of
the MRTP Commission. The Import Control Act and the Customs Tariff Act on the one hand and the
MRTP Act on the other operate in different independent fields and the authority under one has no
jurisdiction over the other. In other words, their paths do not cross each other. While the provisions
of the Anti-Dumping Act are concerned with the levy of anti-dumping duty, the MRTP Act in the
present case would be concerned with the agreements between the parties which relate to the
restrictive trade practices. Therefore, it would be incorrect to say that the incorporation of the
anti-dumping provisions ousts the jurisdiction of the MRTP Commission to inquire and pass orders,
inter alia, with regard to restrictive trade practice in India.” The learned ASG pointed out that the
allegation against the respondents i.e. IDOs is that they have through an anti- competitive
agreement/cartel, limited the provision of services by delaying or denying POIs to RJIL, with a view
to block its entry in the market. As per him, such an agreement would raise a presumption of
‘appreciable adverse effect’ on competition.
27) Explaining the scheme of the Act, Mr. Narasimha referred to the provisions of Section 3 which
prohibits anti-competitive agreements of the nature mentioned therein. He also referred to the
definitions of ‘agreement’, ‘cartel’, ‘enterprise’ and ‘service’ contained in Section 2 of the Act and
submitted that the definition of ‘agreement’ is not restricted to written agreements, but even extends
to ‘action in concert’, which, according to him, is wide enough to allegations of RJIL, if proved
correct, within the mischief of Section 3 of the Act. He also referred to Section 19(3) of the Act which
lists certain factors to be considered in analysing adverse effect on competition and submitted that
creation of barriers to new entrants in the market and foreclosure of competition by hindering entry
into the market are to be perceived as having adverse effect on competition. He, thus, submitted that
having regard to the aforesaid provisions, the CCI wanted to investigate the matter with focus on the
aspect as to whether there was an agreement between the respondent service providers and they
acted in concert pursuant to the said agreement; whether it amounted to anti-competitive act on the
part of these respondents and had adverse effect on the competition. In the process, the CCI was
also supposed to examine as to whether the respondents colluded with COAI and abused their
dominant position. His further argument was that inquiry into these aspects was within the
exclusive domain of the CCI as it is the CCI which is supposed to ensure that no such
anti-competitive practices are adopted by anybody and if that has happened, the CCI is empowered
to issue directions in terms of Section 27 of the Act and also impose penalties. It has power to
impose even lesser penalties as provided in Section 46 of the Act.
28) Mr. Narasimha also referred to Section 60 of the Act which provides for overriding effect for the
Act and reads as under:Competition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

"60. Act to have overriding effect. - The provisions of this Act shall have effect
notwithstanding anything inconsistent therewith contained in any other law for the
time being in force.” It was emphasised that the case of the CCI is not that the TRAI
does not have power to exercise jurisdiction at all in the present factual matrix and
there is no conflict of jurisdiction or legal regimes. Rather, both the TRAI and the CCI
exercise their jurisdiction in their respective fields. Exercise of jurisdiction by the CCI
to investigate an alleged cartel does not impinge upon TRAI’s jurisdiction to regulate
the industry in any way. Submission in this behalf was that the TRAI exercises its
jurisdiction by ensuring compliance with the interconnect agreements, license
conditions, interconnection regulations, quality of service norms and regulations etc.
Based on past experience, the TRAI frames regulations for the improvement of the
telecom industry in the future. For instance, the June 07, 2005 direction of TRAI
which provided for a 90-day period for interconnection has now been replaced by the
interconnection regulations of 2018, by which the time period for provision of POIs
has been reduced to 30 days, because it was found that due to technical
advancements, it was possible to give POIs in a much shorter time frame, and parties
were using the 90-day period to delay the provision of POIs, as in the case of RJIL.
However, the TRAI does not have the power to penalize for past conduct which was
of anti-competitive nature. It was further submitted that while the competition law
seeks to promote efficient allocation and utilization of resources by inter alia lowering
the entry barriers in the market, the primary objective of the sectoral regulators like
the TRAI is development of their respective sector. However, what is important to
bear in mind is that the promotion of competition and prevention of competitive
behaviour may not be high on the agenda of a sectoral regulator which makes it prone
to ‘regulatory capture’. The position has been very succinctly captured by the Report
of the Working Group on Competition Policy, Planning Commission of India,
Government of India, February 2007 which states as follows:
"7.2.3 The objective of a sectoral regulator is to provide good quality service at
affordable rates, but the promotion of competition and prevention of
anti-competitive behaviour may not be high on its agenda or the laws governing the
regulator may be silent on this aspect. It is not uncommon for sectoral regulators to
be more closely aligned with the interest of the firms being regulated, which is also
known as ‘regulatory capture’. Besides, a sectoral regulator may not have an overall
view of the economy as a whole and may tend to apply yardsticks which are different
from the ones used by the other sectoral regulators. In other words, there is a
possibility of the lack of consistency across sectors. On the other hand, CCI will be
able to apply uniform competition principles across all sectors of economy.”
(emphasis added) The National Competition Policy 2011 has also observed as
following:
"8.3 The objective of a sectoral regulator is to provide good quality service at
affordable rates, but the promotion of competition and prevention of
anti-competitive behaviour may not be high on its agenda or the laws governing theCompetition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

regulator may be silent on this aspect. Besides, a sectoral regulator may not have an
overall view of the economy as a whole and may tend to apply yardsticks which are
different from the ones used by the other sectoral regulators. In other words, there is
a possibility of the lack of consistency across sectors as regards competition issues.
On the other hand, the CCI, which is expected to have developed the core
competence, expertise and capacity in competition related issues, will be able to
apply uniform competition principles across all sectors of economy. Besides,
enforcement and penalizing violations of Competition Act is the exclusive area of the
CCI. Even otherwise, the general principle for economic efficiency would be, whoever
can do a thing in best and most professional manner should do it.” (emphasis added)
29) The learned ASG, on taking support from the above, submitted that the sectoral
regulators, by contrast, will not be as experienced in conducting competition analysis
as the competition authorities. Being susceptible to regulatory capture, the
day-to-day interactions between industry officials and regulatory agency may lead to
a commonality of interests that can interfere with the perspective necessary to
evaluate competitive harms and to construct remedies that will protect competition
for the benefit of the economy as a whole. While the sector specific regulators
typically impose and monitor various behavioral conditions, the competition agencies
are more likely to opt for structural remedies which would lead the sector to evolve to
a point where sufficient new entry is induced thereby promoting genuine
competition. According to him, keeping in view the aforesaid respective roles in
mind, the Parliament in its wisdom and foresight has built in a mechanism within the
Act to address apparent conflicts of jurisdiction. The ‘comity’ between the sectoral
regulator (TRAI) and the market regulator (CCI) is entirely addressed by a reading of
Section 21 and Section 21A of the Act. In any case, Section 60 of the Act had an
overriding effect. To support his argument, the learned ASG relied upon State (NCT
of Delhi) v. Sanjay2 wherein this Court dealt with the issue of whether a prescription
of offence under the Mines & Minerals Development & Regulation (MMDR) Act
would exclude the application of the Indian Penal Code. The Court held that due to
the absence of a non-obstante clause, the application of the Indian Penal Code was
not excluded. In the present case, the TRAI Act does not apply notwithstanding any
other laws, and it
2 (2014) 9 SCC 772 does not contain an overriding effect provision containing a non-
obstante clause. The relevant paragraphs of the judgment have been extracted below:
"62. Sub-section (1-A) of Section 4 of the MMDR Act puts a restriction in
transporting and storing any mineral otherwise than in accordance with the
provisions of the Act and the Rules made thereunder. In other words no person will
do mining activity without a valid lease or licence. Section 21 is a penal provision
according to which if a person contravenes the provisions of sub-section (1-A) of
Section 4, he shall be prosecuted and punished in the manner and procedureCompetition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

provided in the Act. Sub-section (6) has been inserted in Section 4 by amendment
making the offence cognizable notwithstanding anything contained in the Code of
Criminal Procedure, 1973. Section 22 of the Act puts a restriction on the court to take
cognizance of any offence punishable under the Act or any Rule made thereunder
except upon a complaint made by a person authorised in this behalf. It is very
important to note that Section 21 does not begin with a non obstante clause. Instead
of the words “notwithstanding anything contained in any law for the time being in
force no court shall take cognizance….”, the section begins with the words “no court
shall take cognizance of any offence.
63. It is well known that a non obstante clause is a legislative device which is usually
employed to give overriding effect to certain provisions over some contrary
provisions that may be found either in the same enactment or some other enactment,
that is to say, to avoid the operation and effect of all contrary provisions.”
30) He also premised his argument on the basis that the Act is a special statute in the
field of telecommunications regulation, including technical aspects connected
thereto, and in case of conflict between two special legislations, the later enactment
would prevail. In Solidaire India Ltd. v. Fairgrowth Financial Services Ltd. & Ors.3,
this Court held as under:
"7. Coming to the second question, there is no doubt that the 1985 Act is a special Act.
Section 32(1) of the said Act reads as follows:
“32. Effect of the Act on other laws.—(1) The provisions of this Act and of any rules or
schemes made thereunder shall have effect notwithstanding anything inconsistent
therewith contained in any other law except the provisions of the Foreign Exchange
Regulation Act, 1973 (46 of 1973) and the Urban Land (Ceiling and Regulation) Act,
1976 (33 of 1976) for the time being in force or in the Memorandum or Articles of
Association of an industrial company or in any other instrument having effect by
virtue of any law other than this Act.”
8. The effect of this provision is that the said Act will have effect notwithstanding
anything inconsistent therewith contained in any other law except to the provisions
of the Foreign Exchange Regulation Act, 1973 and the Urban Land (Ceiling and
Regulation) Act, 1976. A similar non obstante provision is contained in Section 13 of
the Special Court Act which reads as follows:
“13. Act to have overriding effect.—The provisions of this Act shall have effect
notwithstanding anything inconsistent therewith contained in any other law for the
time being in force or in any instrument having effect by virtue of any law, other than
this Act, or in any decree or order of any court, tribunal or other authority.”Competition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

9. It is clear that both these Acts are special Acts. This Court has laid down in no
uncertain terms that in such an event it is the later Act which must prevail. The
decisions cited in the above context are as follows: Maharashtra Tubes Ltd. v. State
Industrial & Investment Corpn. of Maharashtra Ltd. [(1993) 2 SCC 144]; Sarwan
Singh v.
Kasturi Lal [(1977) 1 SCC 750 : (1977) 2 SCR 421]; Allahabad Bank v. Canara Bank [(2000) 4 SCC
406] and Ram Narain v. Simla Banking & Industrial Co. Ltd. [AIR 1956 SC 614 : 1956 SCR 603]” 3
(2001) 3 SCC 71
31) The learned ASG endeavoured to support his proposition by referring to the contrasting
provision contained in Section 14 of the TRAI Act which provides for dispute resolution in respect of
various categories of persons before the TDSAT, which specifically carves out an exception in
respect of monopolistic trade practice, restrictive trade practice and unfair trade practice, which was
subject to the jurisdiction of the Monopolies and Restrictive Trade Practices Commission (MRTP
Commission). He submitted that this was another indicator in the TRAI Act itself from which it can
be inferred that when it comes to anti- competitive practices, an embargo is put on the TRAI to deal
with such practices, inasmuch as the Competition Act is enacted to repeal and replace the obsolete
regime of the MRTP Act. In this behalf, he drew sustenance from Section 8 of the General Clauses
Act to submit that the Competition Act could be read in place of MRTP Act while construing the
provisions of Section 14 of the TRAI Act.
32) His another submission, in this hue, was that a distinction needs to be drawn between
facilitating competition (as provided in Section 11 of the TRAI Act) on the one hand and curbing and
deterring anti-competitive conduct and practices on the other hand. His submission in this behalf
was that the function of the TRAI under Section 11(1)(a)(iv) was to facilitate competition which was
purely recommendatory in nature and not part of regulatory function of the TRAI, as held in Union
of India and Another v. Association of Unified Telecom Service Providers of India and Others4. He
also argued that TRAI has no power to enforce compliance, pass orders, or give directions of the
nature envisaged under the Act to curb anti-competitive conduct.
33) The learned ASG also relied upon the judgment of the European Commission in Deutsche
Telekom v. European Commission5 wherein it was held that it is only if the legislative framework
eliminates the possibility of competition (for example, a statutory monopoly) that the jurisdiction of
the Commission would be excluded. Following passage from the said judgment was specifically
referred to:
"80. According to the case-law of the Court of Justice, it is only if anti-competitive
conduct is required of undertakings by national legislation, or if the latter creates a
legal framework which itself eliminates any possibility of competitive activity on their
part, that Articles 81 EC and 82 EC do not apply. In such a situation, the restriction of
competition is not attributable, as those provisions implicitly require, to the
autonomous conduct of the understandings. Articles 81 EC and 82 EC may apply,
however, if it is found that the national legislation leaves open the possibility ofCompetition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

competition which may be
4 (2011) 10 SCC 543 5 Case C-280/08 P, Judgment dated 14.10.2010 prevented, restricted or
distorted by the autonomous conduct of undertakings (Joined Cases C-359/95P and C- 379/95P
Commission and France v. Ladbroke Racing (1997) ECR I-6265, paragraphs 33 and 34 and the case-
law cited).”
34) Mr. Narasimha also referred to another judgment of the General Court of the European Union
in Telefonica SA v. European Commission (T-336/07) wherein it was held that the European
Commission could intervene in the telecommunications market, even though the entry was
regulated through a sectorial regulator. He pointed out that this decision of the General Court was
upheld in appeal by the European Court of Justice vide its judgment dated July 10, 2014.
35) Mr. Narasimha also contrasted the investigative regime under the two Acts, i.e. Section 12 of the
TRAI Act vis-a-vis Section 41 read with Section 36(2) of the Competition Act and submitted that the
Director General under the Competition Act is better equipped to deal with detection and
investigation of anti-competitive agreements.
36) Labelling as erroneous, the approach of the High Court that CCI should await the outcome of the
proceedings before TRAI to attain finality, answer given by Mr. Narasimha was that this approach
was erroneous for three reasons. First, the High Court has failed to appreciate the different
fields/domains in which the CCI and the TRAI operate. Secondly, the course of action proposed by
the High Court would result in considerable delay defeating the CCI’s investigation. Thirdly, the
High Court has failed to notice the role played by Section 21A of the Act.
37) He again emphasised that CCI is not inquiring into the adequacy of POIs provided to RJIL by
the respondents, or compliance with the QoS standards of TRAI and licence conditions, but was
examining whether the conduct of the respondents was unilateral or it was the result of
anti-competitive agreement. Insofar as requirement of speedy investigation by the CCI is concerned,
he submitted that such a requirement has already been acknowledged and mandated by this Court
in Competition Commission of India v. Steel Authority of India Limited and Another6. Further, if at
any stage, prior to or after taking a decision, the CCI is of the view that opinion of TRAI is required,
it could always make reference under Section 21A of the Competition Act.
38) On the second proposition, namely, the High Court could not have entertained writ jurisdiction
in respect of an order passed 6 (2010) 10 SCC 744 under Section 26(1) of the Competition Act, Mr.
Narasimha clarified that he was not taking the position that the High Court ,in no
circumstance/situation, exercise its extraordinary jurisdiction under the said provision, in spite of
an order passed under Section 26 of the Competition Act. His submission, however, was that as per
the judgment in Steel Authority of India Limited case, such jurisdiction would be very narrow and is
to be exercised in exceptional cases. According to him, no such exceptional circumstance arises in
the instant case as order in question was only a prima facie view of the CCI and such an order was
administrative in nature. Learned ASG specifically referred to the following discussion in the case of
Steel Authority of India Limited:Competition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

"38. In contradistinction, the direction under Section 26(1) after formation of a prima
facie opinion is a direction simpliciter to cause an investigation into the matter.
Issuance of such a direction, at the face of it, is an administrative direction to one of
its own wings departmentally and is without entering upon any adjudicatory process.
It does not effectively determine any right or obligation of the parties to the lis.
Closure of the case causes determination of rights and affects a party i.e. the
informant; resultantly, the said party has a right to appeal against such closure of
case under Section 26(2) of the Act. On the other hand, mere direction for
investigation to one of the wings of the Commission is akin to a departmental
proceeding which does not entail civil consequences for any person, particularly, in
light of the strict confidentiality that is expected to be maintained by the Commission
in terms of Section 57 of the Act and Regulation 35 of the Regulations.
xx xx xx
97. The above reasoning and the principles enunciated, which are consistent with the
settled canons of law, we would adopt even in this case. In the backdrop of these
determinants, we may refer to the provisions of the Act. Section 26, under its
different sub-sections, requires the Commission to issue various directions, take
decisions and pass orders, some of which are even appealable before the Tribunal.
Even if it is a direction under any of the provisions and not a decision, conclusion or
order passed on merits by the Commission, it is expected that the same would be
supported by some reasoning. At the stage of forming a prima facie view, as required
under Section 26(1) of the Act, the Commission may not really record detailed
reasons, but must express its mind in no uncertain terms that it is of the view that
prima facie case exists, requiring issuance of direction for investigation to the
Director General. Such view should be recorded with reference to the information
furnished to the Commission. Such opinion should be formed on the basis of the
records, including the information furnished and reference made to the Commission
under the various provisions of the Act, as aforereferred. However, other decisions
and orders, which are not directions simpliciter and determining the rights of the
parties, should be well reasoned analysing and deciding the rival contentions raised
before the Commission by the parties. In other words, the Commission is expected to
express prima facie view in terms of Section 26(1) of the Act, without entering into
any adjudicatory or determinative process and by recording minimum reasons
substantiating the formation of such opinion, while all its other orders and decisions
should be well reasoned.”
39) He also drew the attention of the Court to paragraph 25 of the CCI’s order dated
April 21, 2017 as per which the Director General was asked to conduct the
investigation without being swayed in any manner whatsoever by the observations
made by the CCI in the said order. He submitted that in these circumstances the said
order was merely administrative in nature and could not be labelled as quasi-judicial
order. In the same vein his further submission was that the observations of the HighCompetition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

Court that the CCI has decided several issues and elements with clear adverse
consequences was clearly erroneous and contrary to the well-established principle of
law. In support, he also referred to the judgments of the Bombay and the Allahabad
High Courts.
40) Dilating on his third proposition, namely, the CCI order was not perverse, he
submitted that there was sufficient material before the CCI for formation of a prima
facie opinion that the conduct of the respondents was violative of Section 3(3)(b) of
the Competition Act. He submitted that such material was taken into consideration
and discussed in the order itself and he referred to certain paragraphs of the order
dated April 21, 2017 in this behalf.
In the process, he again emphasised that none of the observations made in the said order are
conclusive findings in any way and not binding on the Director General and this was only the
starting point, as held in the case of Excel Crop Care Limited.
41) M/s. Harish Salve, Dr. A.M. Singhvi, Ramji Srinivasan and Amit Sibal, learned senior advocates,
argued on behalf of RJIL. Their detailed submissions were almost on the lines on which Mr.
Narasimha, learned ASG, had argued on behalf of the CCI.
42) In the first place, it was emphasised that insofar as dragging of COAI into this investigation is
concerned, it was sought to be justified by placing reliance on Section 3 of the Act which specifically
recognises possible mischief by an association of persons or an association of enterprises. It was
stressed that Section 3(3) recognises certain agreements as per se violations, and shall be presumed
to have appreciable adverse effect on competition. Submission was that associations of enterprises,
after the operation of the Act are now liable to be viewed with great suspicion in view of the fact that
by its very nature an association of competing enterprises provides a convenient platform for such
competitors to assemble together.
43) The involvement of COAI was sought to be proved by arguing that the IDOs have not argued
that COAI letters must be ignored since the decision to provide or not to provide POIs to its
competitor was taken by each of them independently either Airtel by itself, or Vodafone by itself, or
Idea by itself. But the facts of the case disclose active involvement by that common platform called
COAI. As per the Reliance Jio, the COAI admittedly facilitated exchange of information between the
three IDOs. It draws references in its response to private letters exchanged between Reliance Jio
and each of the IDOs separately. The decisions of the COAI are not decisions of a majority
comprising of a large and diverse pool of members that could suggest a democratic decision making.
By its very constitution, the COAI’s majority views were nothing but the common views of the three
IDOs that controlled it. It was also argued that in the preliminary conference and in the High Court
defence raised was that COAI was not a front for these three IDOs but was merely espousing general
industry issues. It does not explain how it chanced upon private documents and correspondence
exchanged bilaterally between RJIL with each of the IDOs separately. It does not explain how it
voiced the common decisions on behalf of those three IDOs. The COAI was not the fourth voice but
was the prohibited chorus of those three colluding competitors. Thus, no legitimacy can beCompetition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

attributed to actions of the COAI. Attention of the Court was drawn to the letter dated August 08,
2016 (before the announcement of launch of services by Reliance Jio dated September 01, 2016) and
the letter dated September 02, 2016 (after the launch of Reliance Jio) which, according to Reliance
Jio, expose the common collusive conduct of these competitors to first delay the launch and
secondly to scuttle the launch. It was also contended that the concerted, collusive conspiracy by the
three existing IDOs (having a collective market share of 65%) to meet with each other under
auspices of their association called Cellular Operators Association of India (COAI) and evolve a
common strategy to respond to challenge posed by a new entrant RJIL, is by itself violative of
Section 3 of the Act. The learned senior counsel pointed out that the defence of the COAI is that it
was merely lobbying the Government for enacting a change in law or regulation to stop Reliance Jio
from carrying out test on such a large scale by introducing limits on number of Test- subscribers.
However, the letters of COAI revealed an active participation of taking sides of certain operators
whose interest was to hinder, or at least slowdown the entry of the new operator. COAI announced
unilateral decisions like virtual boycott (which is not the same as lobbying for change of regulation).
To support this argument, reference was made to the decisions of Supreme Court of United States in
FTC v. Supreme Court Trial Lawyers Association7 wherein it has observed that:
7 493 US 411 (1990) "no violation of the Act can be predicated upon mere attempts to influence the
passage or enforcement of laws,” even if the defendants’ sole purpose is to impose a restraint upon
the trade of their competitors. But in the Noerr case the alleged restraint of trade was the intended
consequence of public action; in this case the boycott was the mans by which respondents sought to
obtain favourable legislation. The restraint of trade that was implemented while the boycott lasted
would have had precisely the same anticompetitive consequences during that period even if no
legislation had been enacted. In Noerr, the desired legislation would have created the restraint on
the truckers’ competition; in this case the emergency legislative response to the boycott put an end
to the restraint.”
44) On the submission that the dangers of a trade association being hijacked to further the cause of
only a few competitors and yet attempt to give the entire exercise a veneer of respectability has been
also commented upon in the recent decision of this Court in Competition Commission of India v.
Coordination Committee of Artistes and Technicians of West Bengal Film and Television & Ors.8
wherein it has been observed that:
"47. In the instant case, admittedly the Coordination Committee, which may be a
“person” as per the definition contained in Section 2(l) of the Act, is not undertaking
any economic activity by itself. Therefore, if we were to look into the “agreement” of
such a “person” i.e. Coordination Committee, it may not fall under Section 3(1) of the
Act as it is not in respect of any production, supply, distribution, storage, acquisition
or control of goods or provision of services. The Coordination Committee, which as a
trade union acting by itself, and without conjunction with any other, would not be
treated as an “enterprise” or the kind of “association of persons” described in Section
3. A trade union acts as on behalf of its members in collectiveCompetition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

8 (2017) 5 SCC 17 bargaining and is not engaged in economic activity. In such circumstances, had
the Coordination Committee acted only as trade unionists, things would have been different. Then,
perhaps, the view taken by the Tribunal could be sustained. However, what is lost in translation by
the Tribunal i.e. in applying the aforesaid principle of the activity of the trade union, is a very
pertinent and significant fact, which was taken note of by the DG as well as CCI in its majority
opinion. It is this: the Coordination Committee (or for that matter even EIMPA) are, in fact,
association of enterprises (constituent members) and these members are engaged in production,
distribution and exhibition of films. EIMPA is an association of film producers, distributors and
exhibitors, operating mainly in the State of West Bengal. Likewise, the Coordination Committee is
the joint platform of Federation of Senior Technician and Workers of Eastern India and West Bengal
Motion Pictures Artistes' Forum. Both EIMPA as well as the Coordination Committee acted in a
concerted and coordinated manner. They joined together in giving call of boycott of the competing
members i.e. the informant in the instant case and, therefore, the matter cannot be viewed narrowly
by treating Coordination Committee as a trade union, ignoring the fact that it is backing the cause of
those which are “enterprises”. The constituent members of these bodies take decision relating to
production or distribution or exhibition on behalf of the members who are engaged in the similar or
identical business of production, distribution or exhibition of the films. Decision of these two bodies
reflected collective intent of the members. When some of the members are found to be in the
production, distribution or exhibition line, the matter could not have been brushed aside by merely
giving it a cloak of trade unionism. For this reason, the argument predicated on the right of trade
union under Article 19 of the Constitution, as professed by the Coordination Committee, is also not
available.” (emphasis supplied) Arguments: The respondents:
45) Mr. Darius J. Khambata, senior advocate, appeared on behalf of Idea Cellular
Ltd. Mr. Gopal Jain and Mr. Navroz Seervai, senior advocates, appeared on behalf of
Bharti Airtel Ltd. Mr. Ranjit Kumar, Mr. Arvind Datar and Mr. Sidharth Luthra,
senior advocates, appeared on behalf of Vodafone India Ltd. Mr. P. Chidambaram,
senior advocate, appeared on behalf of the COAI.
TRAI had also intervened in the matter and supported the legal submission of the IDOs, namely,
that TRAI had the exclusive jurisdiction to deal with the matter, i.e. there was a complete absence of
jurisdiction in CCI to deal with the issue at hand. Instead of taking note of the submissions of these
counsel separately, we are taking note of the submissions in a consolidated manner as that would
avoid repetition.
46) The submissions of the respondents can be paraphrased as under:
(i) The TRAI Act, being a special law, ousts the jurisdiction of CCI to examine the
telecom sector. In that sense, exclusive jurisdiction vests in TRAI to regulate the
telecom sector, including competition related issues, thereby ousting the jurisdiction
of the CCI altogether.
(ii) Even if the CCI has the jurisdiction, TRAI’s jurisdiction will prevail.Competition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

(iii) In the alternative, the jurisdictional facts, in any case, had to be determined by
the TRAI in the first place. Since there was absence of jurisdictional facts, the CCI
could not have proceeded with the matter and ordered the investigation. Thus, the
CCI’s order for carry out investigation is premature.
(iv) The impugned order passed by the CCI under Section 26(1) of the Competition
Act applies the ‘prima facie test’ and consequences of such an order are grave. Such
an order was quasi-judicial in nature and, therefore, amenable to judicial review
under Article 226 of the Constitution of India. Thus, the writ petitions filed by the
IDOs challenging this order were maintainable.
(v) On merits, the prima facie order passed by the CCI was without considering the
material submitted by the IDOs. In this behalf it was argued that the IDOs had
provided sufficient POIs and given ample proof thereof, which was not taken into
consideration by the CCI while passing the impugned order under Section 26(1) of
the Competition Act. This also becomes a valid ground to challenge the order by filing
writ petition under Article 226 of the Constitution of India.
47) Insofar as the argument of the respondents that the TRAI Act is a complete code and the
jurisdiction of CCI is totally ousted, the argument proceeded on the following basis:
The real issue which arises is comparison of two regimes – one regulated by TRAI
under the Indian Telegraph Act, 1885, Wireless Telegraphy Act, 1933 and the TRAI
Act, 1997 which together forms a comprehensive and complete code; and the other
being CCI under the Competition Act. The various provisions under these legislations
seen with the terms of the License Agreement show that the issues arising out of
interconnection between different operators shall be determined within the overall
framework of the interconnection regulations/directions/orders issued by TRAI from
time to time. The Object and Reasons of the TRAI Act itself lays down that it is
mandated to make arrangements for protection and promotion of consumer interest
and ensuring fair competition and to ensure orderly and healthy growth of
telecommunication infrastructure. Moreover, the competition in the telecom sector is
of a different kind as it has to function under the constant monitoring and regulation
of TRAI. TRAI effectively plays the role of a watchdog of the sector as otherwise the
entire sector would collapse if there is no interdependence between the telecom
operators. Moreover, under Section 11(1)(a)(iv) of the TRAI Act, the authority is
required to take measures to facilitate competition in the market. CCI can ensure
competition only in an unregulated sector and not in the likes of the telecom sector
wherein even the tariffs are capped/determined by TRAI.
48) On the aforesaid basis, the submission was that:
       (a)     The TRAI Act is a complete code.
       (b)     Exclusive jurisdiction vests in TRAI to regulate the telecomCompetition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

sector including competition related issues.
(c) The TDSAT has the exclusive jurisdiction to examine the disputes between
licensees including the one raised by RJIL before CCI.
(d) CCI has no jurisdiction to decide disputes pertaining to the telecom sector.
In this hue it was submitted that the Statement of Objects and Reasons of the TRAI Act made it
abundantly clear by satisfying that TRAI was supposed to make "arrangements for protection and
promotion of consumer interest and ensuring fair competition...". It was, thus, clear that even the
competition aspects of the telecom sector were within the domain of TRAI. The respondents also
drew comparison of the Preamble of the Competition Act with that of the TRAI Act to point out that
insofar as dealing with the issue of fair competition in telecom sector is concerned, it was
overlapping to a great extent in the following manner:
                     Competition Act                              TRAI Act
        An Act to provide, keeping in view the         An Act to provide for the
        economic development of the country,           establishment of the Telecom
        for the establishment of a Commission          Regulatory Authority of India and
        to                                             the Telecom Dispute Settlement
                                                       and Appellate Tribunal (“TDSAT”)
                                                       to
“prevent practices having adverse effect [-] on competition to promote and sustain competition in
[for protection and promotion of markets consumer interest and ensuring fair competition
(Statement of Object and Reasons)] to protect interests of consumers and to protect the interest of
the service providers and consumers of the telecom sector (Preamble) to ensure freedom of trade
carried on by to promote and ensure orderly other participants in the markets, in growth of the
telecom sectoral India for matters connected therewith or For matters connected therewith
incidental thereto” and incidental thereto
49) It was submitted that pursuant to Section 11(1)(a)(iv) read with Section 11(1)(b)(ii), (iii), (iv) of
the TRAI Act (including directions and regulations issued by TRAI), the TRAI has been statutorily
mandated to perform functions on a variety of matters including measures aimed at facilitating
competition and regulated interconnection between service providers. Reliance was also placed on
Section 12 of the TRAI Act which empowers TRAI with vast powers to discharge its functions,
including to call for information, conduct investigations and issue such necessary directions as it
may deem necessary for the discharge of its functions. Moreover, TRAI has also been empowered to
issue appropriate directions under Section 12 and make regulations under Section 36 of the TRAI
Act. Section 29 of the TRAI Act provides for penalties for contravention of directions of the TRAI.
Further, under Section 14A of the TRAI Act, it has been provided that any person may make an
application before the TDSAT. With regard to the jurisdiction, Section 15 and 27 of the TRAI Act
provide for explicit bar on jurisdiction of the civil courts to determine any matter with regard toCompetition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

which TDSAT or TRAI have been empowered by or under the TRAI Act.
50) It was submitted that in the present case, at the time RJIL filed its Information before the CCI
on November 08, 2016 as also when the prima facie order was passed on April 21, 2017, TRAI was
seized of the matter pertaining to provisioning of POIs and even made certain recommendations to
the DoT on October 21, 2016. Accordingly, TRAI had assumed jurisdiction and was exercising the
same. Thus, the dispute was being dealt with and was addressed by the TRAI and even on this
ground, the jurisdiction of the CCI stands ousted.
51) The TDSAT has the exclusive jurisdiction to examine the disputes between licensees including
the one raised by RJIL before CCI. This very submission on the exclusion of CCI’s jurisdiction was
sought to be projected from another angle. It was submitted that in the Information filed by RJIL
before the CCI, Reliance Jio stressed:
(a) The dispute raised by RJIL before the CCI pertains to the specific performance of
the Interconnect Agreement and the rights and liabilities arising therefrom;
(b) The Interconnect Agreement is completely regulated by the TRAI inter alia under
Section 11(1)(b)(ii), (iii), (iv) of the TRAI Act read with the Quality of Service
Regulations, 2009 issued thereunder.
The argument was that the prayers sought by RJIL in the Information filed before the CCI clearly
demonstrate that RJIL was seeking specific performance of the Interconnect Agreement. Hence,
RJIL has dressed up what is essentially a contractual complaint into anti-competition clothing. In
the present dispute, upon a meaningful reading of the Information it can clearly be seen that
through clever drafting, RJIL has dressed up the allegations of delay/denial of the POIs as alleged
anti-competitive behaviour. In this behalf, reliance was placed on the decision of this Court in
Begum Sabiha Sultan v. Nawab Mohd. Mansur Ali Khan & Ors.9, wherein it was held:
"10. There is no doubt that at the stage of consideration of the return of the plaint
under Order 7 Rule 10 of the Code, what is to be looked into is the plaint and the
averments therein. At the same time, it is also necessary to read the plaint in a
meaningful manner to find out the real intention behind the suit. In Moolji Jaitha
and Co. v. Khandesh Spg. and Wvg. Mills Co. Ltd. [AIR 1950 FC 83] the Federal
Court observed that: (AIR p. 92, para 24) “The nature of the suit and its purpose have
to be determined by reading the plaint as a whole.” It was further observed: (AIR p.
92, para 25) “The inclusion or absence of a prayer is not decisive of the true nature of
the suit, nor is the order in which the prayers are arrayed in the plaint. The substance
or object of the suit has to be gathered from the averments made in the plaint and on
which the reliefs asked in the prayers are based.” It was further observed: (AIR p. 98,
para 59) “It must be borne in mind that the function of a pleading is only to state
material facts and it is for the court to determine the legal result of those facts and to
mould the relief in accordance with that result.”Competition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

52) In support of the submission that a special legislation i.e. the TRAI Act, will
prevail over the provisions of the Competition Act, which according to the
respondents is general in nature, reliance
9 (2007) 4 SCC 343 has been placed on the decisions of this Court in State of Punjab v. Labour
Court, Jullundur & Ors. 10. In the said matter, the Court was inter alia seized of the issue whether
the employee-respondents were at liberty to seek the payment of gratuity by invoking the remedy
available under Section 33-C(2) of the Industrial Disputes Act, 1947 as opposed to the Payment of
Gratuity Act, 1972. In deciding the said dispute, it was held that:
"7. It is apparent that the Payment of Gratuity Act enacts a complete code containing
detailed provisions covering all the essential features of a scheme for payment of
gratuity. It creates the right of payment of gratuity, indicates when the right will
accrue, and lays down the principles for quantification of the gratuity. It provides
further for recovery of the amount, and contains an especial provision that compound
interest at nine per cent per annum will be payable on delayed payment. For the
enforcement of its provisions, the Act provides for the appointment of a controlling
authority, who is entrusted with the task of administering the Act. The fulfilment of
the rights and obligations of the parties are made his responsibility, and he has been
invested with an amplitude of power for the full discharge of that responsibility. Any
error committed by him can be corrected in appeal by the appropriate Government or
an Appellate Authority particularly constituted under the Act.
8. Upon all these considerations, the conclusion is inescapable that Parliament
intended that proceedings for payment of gratuity due under the Payment of Gratuity
Act must be taken under that Act and not under any other. That being so, it must be
held that the applications filed by the employee respondents under Section 33-C(2) of
the Industrial Disputes Act did not lie, and the Labour Court had no jurisdiction to
entertain and dispose of them. On that ground, this appeal must succeed.” (emphasis
supplied)
10 (1980) 1 SCC 4
53) Applying the aforesaid tests to the present case, the submission of the respondents is that:
(a) The subject area of competition law is dealt with by the Competition Act, 2002.
(b) The TRAI Act, 1997 is a complete code in itself and regulates the Telecom Sector.
(c) The Preamble, the Statement of Objects and Reasons and Section 11(1) of the
TRAI Act provide the TRAI with the power to inter alia regulate competition in the
telecom sector.Competition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

(d) Accordingly, being the special law regarding the telecom sector, as regards
competition issues arising in the telecom sector, the TRAI Act would prevail over the
Competition Act.
54) Replying to the argument of the appellants that the TRAI Act as well as the
Competition Act are both special statutes and hence, the rule of statutory
interpretation of special law prevailing over the general law will be inapplicable in the
present dispute, the respondents referred to the decision of this Court in Ashoka
Marketing Ltd. & Anr. v. Punjab National Bank & Ors.11. In the said case, the Court
was seized of an issue on whether the
11 (1990) 4 SCC 406 provisions of the Public Premises (Eviction of Unauthorised Occupants) Act,
1971 would override the provisions of the Delhi Rent Control Act, 1958 in relation to the premises
belonging to Punjab National Bank Ltd., a body corporate under the Banking Companies
(Acquisition and Transfer of Undertakings) Act, 1970. Each side argued that the enactment relied
upon by it is a special statute and the other enactment is general. The Court held that the Rent
Control Act is a special statute regulating the relationship of landlord and tenant in the Union
Territory of Delhi and even the Public Premises Act is a special statute relating to eviction of
unauthorised occupants from public premises. While concluding that both the enactments are
special statutes, the Court held:
""61. ...in the case of inconsistency between the provisions of two enactments, both of
which can be regarded as special in nature, the conflict has to be resolved by
reference to the purpose and policy underlying the two enactments and the clear
intendment conveyed by the language of the relevant provisions therein.
64. ...In our opinion, therefore, keeping in view the object and purpose underlying
both the enactments viz. the Rent Control Act and the Public Premises Act, the
provisions of the Public Premises Act have to be construed as overriding the
provisions contained in the Rent Control Act.” (emphasis supplied)
55) Heavy reliance was placed on the judgment of the United States Supreme Court
in the case of Credit Suisse v. Billing et al12.
Here the submission was that if the CCI is permitted to examine the information of RJIL that it was
to be provided POIs immediately despite there being a period of 90 days in the ICA, the following
would be the consequences:
(i) The same may cause a threat and may alter the functioning of telecom sector on
account of threat of intervention of CCI even where the acts are in accordance with
TRAI’s Regulations. The same would threaten efficient functioning of the telecom
sector.Competition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

(ii) The additional benefits to competition would be very small as the TRAI
Regulations anyway have been framed keeping in mind “facilitation of competition”
in telecom sector.
(iii) The same would encourage future actions before CCI when telecom related issues
will be dressed up as competition issues.
It was the fervent plea that in order to avoid such conflict of standards and norms, the TRAI Act
being the sectoral law and the TRAI is already seized of the matter, the CCI should not be allowed to
proceed.
56) According to the respondents, the jurisdictional facts in the present matter would be:
12 551 US 264 (2007)
       (a)     Failure to provide adequate POIs in the test phase; or
       (b)     Delay in providing POIs; or
       (c)     Providing inadequate POIs.
57)    Mr. Datar, in particular, submitted that from a perusal of the
extensive pleadings and findings of the High Court, it is manifest that the above issues are pending
consideration before the TRAI/DoT as well as in connected writ petitions pending adjudication
before the Delhi High Court. The emphasis was that there must first be clear findings on the above
issues in the context of the TRAI Act, Rules and Regulations. According to him, that alone is not
enough. It is necessary to establish that violation of the provisions of TRAI Act amounts to “abuse of
dominance” or “anti-competitive agreements”. As per him, Section 21 and 21A of the Competition
Act make it clear that jurisdiction of the CCI is divided into parts, viz:
(a) Economic activity not regulated by any statutory authority.
(b) Economic activity regulated by a statutory authority.
In the latter case, Section 21A is mandatory and the CCI can act only in accordance with Sections
21A(1) and (2). Submission was that in economic activity that is regulated by a statutory authority,
CCI can exercise powers under Section 26 only after complying with Section 21A. It was predicated
on the principle that when the law prescribes things to be done in a particular manner, all other
modes of action are prohibited. (Bhavnagar University v. Palitana Sugar Mill (P) Ltd. & Ors.13)
58) In this hue, it was also argued that the decision of this Court in Competition Commission ofCompetition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

India v. Steel Authority of India Ltd. & Anr.14 has no application to the present case because it does
not deal with a sector that is regulated by a statutory authority. On the other hand, reliance was
placed on the judgment in the case of Carona Ltd. v. Parvathy Swaminathan & Sons15.
59) It was submitted that the facts of the SAIL case are clearly distinguishable from the present case
as the main issue before the Supreme Court in SAIL was whether an appeal can be filed against an
order passed under Section 26(1) of the Competition Act. Distinction was sought to be drawn on the
basis of the following facts:
(a) in the present case, CCI issued notice and called the TSPs including Vodafone for
a preliminary conference to be held on
13 (2003) 2 SCC 111 14 (2010) 10 SCC 744 15 (2007) 8 SCC 559 January 31, 2017 and the parties
were heard on January 31, 2017, February 07, 2017 and February 08, 2017;
(b) hearing was held before CCI and detailed notes on arguments were submitted with supporting
documents by the TSPs including Vodafone;
(c) the prima facie order has been passed after hearing the submissions of the TSPs holding that a
prima facie case of violation of the Competition Act has been made out; and
(d) the prima facie order also provide for reasons in support of the decision arrived at by the CCI.
60) Justifying the observations of the High Court that the order of the CCI cannot be treated as an
'administrative order', it was submitted that the order was passed by the CCI after collecting the
detailed information from the parties and by holding the conferences, calling material details,
documents, affidavits and by recording the opinion. It was also submitted that the High Court had
rightly noted that majority decision of the CCI has given reasons by overlooking the law and the
record. It was a reasoned order/direction and, therefore, judicial review is permissible. In this behalf
it was submitted that the aforesaid view was taken on the basis of the following:
(a) whilst an order under Section 26(2) has been made appealable, an order under
Section 26(1) is not appealable;
(b) an order under Section 26(1) of the Competition Act is a direction simpliciter to
the Director General to cause an investigation;
(c) at the stage of passing of the order under Section 26(1), there is no adjudicatory
process undertaken by the CCI as there is no determination of any right or obligation
of the parties to the lis; and
(d) the order passed under Section 26(1) does not entail civil consequences for any
person as against a Section 26(2) order wherein rights of the informant are affected.Competition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

61) In the alternative, it was argued that the observations of the Court limited to the
extent of the nature of powers vested in the CCI under Section 26(1) needs
reconsideration by this Court.
Our discussion:
62) We have noted of three propositions which were advanced by Mr. Narasimha,
learned Additional Solicitor General. These are the main issues which arise for
consideration. In fact, other counsel for the parties have also made their submissions
on these aspects. We would, therefore, focus our discussion on the said propositions.
We would like to mention that while analysing the arguments of all the parties, we
have kept in mind their detailed submissions as well as the principles laid down in
various judgments cited by them, even if we have not made specific mention to these
judgments in our discussion.
A.     Jurisdiction of the CCI
63)    This is the principal issue which is the bone of contention.
64)    In order to discuss and analyse this aspect, it would be apt to
take note of the salient provisions of the Competition Act as well as the TRAI Act
inasmuch as that would facilitate appreciating the arguments so advanced.
65) In the wake of globalisation and keeping in view the economic development of the
country, responding to opening of its economy and resorting to liberalisation, need
was felt to enact a law that ensures fair competition in India by prohibiting trade
practices which cause an appreciable adverse effect on competition within markets in
India and for establishment of an expert body in the form of Competition
Commission of India, which would discharge the duty of curbing negative aspects of
competition, the Competition Act, 2002 has been enacted by the Parliament.
66) Having regard to this specific objective which the Act seeks to achieve, provisions
contained therein, which are relevant for deciding the instant appeals, are
reproduced below:
"2. Definitions. – xx xx xx
(b) “agreement” includes any arrangement or understanding or action in concert, –
(i) whether or not, such arrangement, understanding or action is formal or in writing;
orCompetition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

(ii) whether or not such arrangement, understanding or action is intended to be
enforceable by legal proceedings;
                                  xx             xx             xx
               (c)    “cartel” includes an association of producers, sellers,
distributors, traders or service providers who, by agreement amongst themselves,
limit control or attempt to control the production, distribution, sale or price of, or,
trade in goods or provision of services;
xx xx xx
(g) “Director General” means the Director-General appointed under sub-section (1) of
section 16 and includes any Additional, Joint, Deputy or Assistant Directors General
appointed under that section;
xx xx xx
(m) “practice” includes any practice relating to the carrying on of any trade by a
person or an enterprise;
xx xx xx (u) “service” means service of any description which is made available to
potential users and includes the provision of services in connection with business of
any industrial or commercial matters such as banking, communication, education,
financing, insurance, chit funds, real estate, transport, storage, material treatment,
processing, supply of electrical or other energy, boarding, lodging, entertainment,
amusement, construction, repair, conveying of news or information and advertising;
xx xx xx
3. Anti-competitive agreements. – (1) No enterprise or association of enterprises or
person or association of persons shall enter into any agreement in respect of
production, supply, distribution, storage, acquisition or control of goods or provision
of services, which causes or is likely to case an appreciable adverse effect on
competition within India.
(2) Any agreement entered into in contravention of the provisions contained in
sub-section (1) shall be void.
(3) Any agreement entered into between enterprises or associations of enterprises or
persons or associations of persons or between any person and enterprise or practice
carried on, or decision taken by, any association of enterprises or association of
persons, including cartels, engaged in identical or similar trade of goods or provision
of services, which –Competition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

(a) directly or indirectly determines purchase or sale prices;
(b) limits or controls production, supply, markets, technical development, investment
or provision of services;
(c) shares the market or source of production or provision of services by way of
allocation of geographical area of market, or type of goods or services, or number of
customers in the market or any other similar way;
(d) directly or indirectly results in bid rigging or collusive bidding, shall be presumed
to have an appreciable adverse effect on competition:
Provided that nothing contained in this sub-section shall apply to any agreement
entered into by way of joint ventures if such agreement increases efficiency in
production, supply, distribution, storage, acquisition or control of goods or
provisions of services. Explanation. – For the purpose of this sub-section, “bid
rigging” means by agreement, between enterprises or persons referred to in
sub-section (3) engaged in identical or similar production or trading of goods or
provision of services, which has the effect of eliminating or reducing competition for
bids or adversely affecting or manipulating the process for bidding.
xx xx xx
19. Inquiry into certain agreements and dominant position of enterprise. – (1) The
Commission may inquire into any alleged contravention of the provisions contained
in sub-section (1) of section 3 or sub-section (1) of section 4 either on its own motion
or on -
“(a) receipt of any information, in such manner and accompanied by such fee as may be determined
by regulations, from any person, consumer or their association or trade association; or
(b) a reference made to it by the Central Government or a State Government or a statutory
authority.
(2) Without prejudice to the provisions contained in sub- section (1), the powers and functions of
the Commission shall include the powers and functions specified in sub- sections (3) to (7).
(3) The Commission shall, while determining whether an agreement has an appreciable adverse
effect on competition under section 3, have due regard to all or any of the following factors, namely:
(a) creation of barriers to new entrants in the market;
(b) driving existing competitors out of the market;Competition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

(c) foreclosure of competition by hindering entry into the market;
(d) accrual of benefits to consumers;
(e) improvements in production or distribution of goods or provision of services;
(f) promotion of technical, scientific and economic development by means of
production or distribution of goods or provision of services.
xx xx xx 21A. Reference by Commission. – (1) Where in the course of a proceeding
before the Commission an issue is raised by any party that any decision, which the
Commission has taken during such proceeding or proposes to take, is or would be
contrary to any provision of this Act whose implementation is entrusted to a statutory
authority, then the Commission may make a reference in respect of such issue to the
statutory authority:
Provided that the Commission, may, suo motu, make such a reference to the
statutory authority.
(2) On receipt of a reference under sub-section (1), the statutory authority shall give
its opinion, within sixty days of receipt of such reference, to the Commission which
shall consider the opinion of the statutory authority, and thereafter give its findings
recording reasons therefor on the issues referred to in the said opinion.
xx xx xx
26. Procedure for inquiry under section 19. – (1) On receipt of a reference from the
Central Government or a State Government or a statutory authority or on its own
knowledge or information received under section 19, if the Commission is of the
opinion that there exists a prima facie case, it shall direct the Director General to
cause an investigation to be made into the matter:
Provided that if the subject matter of an information received is, in the opinion of the
Commission, substantially the same as or has been covered by any previous
information received, then the new information may be clubbed with the previous
information.
(2) Where on receipt of a reference from the Central Government or a State
Government or a statutory authority or information received under section 19,the
Commission is of the opinion that there exists no prima facie case, it shall close the
matter forthwith and pass such orders as it deems fit and send a copy of its order to
the Central Government or the State Government or the statutory authority or the
parties concerned, as the case may be.Competition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

(3) The Director-General shall, on receipt of direction under sub-section (1), submit a
report on his findings within such period as may be specified by the Commission.
(4) The Commission may forward a copy of the report referred to in sub-section (3) to
the parties concerned:
Provided that in case the investigation is caused to be made based on reference
received from the Central Government or the State Government or the statutory
authority, the Commission shall forward a copy of the report referred to in
sub-section (3) to the Central Government or the State Government or the statutory
authority, as the case may be.
(5) If the report of the Director General referred to in sub-
section (3) recommends that there is no contravention of the provisions of this Act, the Commission
shall invite objections or suggestions from the Central Government or the State Government or the
statutory authority or the parties concerned, as the case may be, on such report of the
Director-General.
(6) If, after consideration of the objections and suggestions referred to in sub section (5), if any, the
Commission agrees with the recommendation of the Director General, it shall close the matter
forthwith and pass such orders as it deems fit and communicate its order to the Central Government
or the State Government or the statutory authority or the parties concerned, as the case may be. (7)
If, after consideration of the objections or suggestions referred to in sub section (5), if any, the
Commission is of the opinion that further investigations is called for, it may direct further
investigation in the matter by the Director General or cause further inquiry to be made by in the
matter or itself proceed with further inquiry in the matter in accordance with the provisions of this
Act.
(8) If the report of the Director-General referred to in sub- section (3) recommends that there is
contravention of any of the provisions of this Act, and the Commission is of the opinion that further
inquiry is called for, it shall inquire into such contravention in accordance with the provisions of this
Act.
                                  xx             xx             xx
               36.   Power of Commission to regulate its own
               procedure. –
                                  xx             xx             xx
(2) The Commission shall have, for the purposes of discharging its functions under this Act, the
same powers as are vested in a Civil Court under the Code of Civil Procedure, 1908 (5 of 1908),
while trying a suit, in respect of the following matters, namely:–Competition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

(a) summoning and enforcing the attendance of any person and examining him on oath;
(b) requiring the discovery and production of documents;
(c) receiving evidence on affidavit;
(d) issuing commissions for the examination of witnesses or documents;
(e) requisitioning, subject to the provisions of sections 123 and 124 of the Indian Evidence Act, 1872
(1 of 1972), any public record or document or copy of such record or document from any office.
xx xx xx
41. Director General to investigate contraventions. – (1) The Director General shall, when so
directed by the Commission, assist the Commission in investigating into any contravention of the
provisions of this Act or any rules or regulations made thereunder.
(2) The Director General shall have all the powers as are conferred upon the Commission under
sub-section (2) of section 36.
(3) Without prejudice to the provisions of sub-section (2), sections 240 and 240A of the Companies
Act, 1956 (1 of 1956), so far as may be, shall apply to an investigation made by the Director General
or any other person investigating under his authority, as the apply to an inspector appointed under
that Act.
Explanation. – For the purposes of this section, –
(a) the words “the Central Government” under section 240 of the Companies Act, 1956 (1 of 1956)
shall be construed as “the Commission”;
(b) the word “Magistrate” under Section 240A of the Companies Act, 1956 (1 of 1956) shall be
construed as “the Chief Metropolitan Magistrate, Delhi”.
xx xx xx
45. Penalty for offences in relation to furnishing of information. – (1) Without prejudice to the
provisions of section 44, if a person, who furnishes or is required to furnish under this act any
particulars, documents or any information, –
(a) makes any statement or furnishes any document which he knows or has reason to believe to be
false in any material particular; or
(b) omits to state any material fact knowing it to be material; orCompetition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

(c) wilfully alters, suppresses or destroys any document which is required to be furnished as
aforesaid, such person shall be punishable with fine which may extend to rupees one crore as may be
determined by the Commission.
(2) Without prejudice to the provisions of sub-section (1), the Commission may also pass such other
order as it deems fit.
xx xx xx
60. Act to have overriding effect. – The provisions of this Act shall have effect notwithstanding
anything inconsistent therewith contained in any other law for the time being in force.
61. Exclusion of jurisdiction of civil courts. – No civil court shall have jurisdiction to entertain any
suit or proceeding in respect of any matter which the Commission or the Appellate Tribunal is
empowered by or under this Act to determine and no injunction shall be granted by any court or
other authority in respect of any action taken or to be taken in pursuance of any power conferred by
or under this Act.
62. Application of other laws not barred. – The provisions of this Act shall be in addition to, and not
in derogation of, the provisions of any other law for the time being in force.”
67) The aforesaid provisions would indicate that the Act deals with three kinds of practices which
are treated as anti-competitive and are prohibited. These are:
(a) where agreements are entered into by certain persons with a view to cause an
appreciable adverse effect on competition;
(b) where any enterprise or group of enterprises, which enjoys dominant position,
abuses the said dominant position; and
(c) regulating the combination of enterprises by means of mergers or amalgamations
to ensure that such mergers or amalgamations do not become anti-competitive or
abuse the dominant position which they can attain.
The objective behind the Act and rationale in curbing the aforesaid anti-competitive practices was
taken note of in Excel Crop Care Limited v. Competition Commission of India and Another16 and
we would like to reproduce the following passages therefrom:
"21. In the instant case, we are concerned with the first type of practices, namely,
anti-competitive agreements. The Act, which prohibits anti-competitive agreements,
has a laudable purpose behind it. It is to ensure that there is a healthy competition in
the market, as it brings about various benefits for the public at large as well as
economy of the nation. In fact, the ultimate goal of competition policy (or for that
matter, even the consumer policies) is to enhance consumer well-being. TheseCompetition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

policies are directed at ensuring that markets function effectively. Competition policy
towards the supply side of the market aims to ensure that consumers have adequate
and affordable choices. Another purpose in curbing anti-competitive agreements is to
ensure “level playing field” for all market players that helps markets to be
competitive. It sets “rules of the game” that protect the competition process itself,
rather than competitors in the market. In this way, the pursuit of fair and effective
competition can contribute to improvements in economic efficiency, economic
growth and development of consumer welfare. How these benefits accrue is explained
in the ASEAN Regional Guidelines on Competition Policy, in the following manner:
“2.2. Main Objectives and Benefits of Competition Policy 2.2.1.1. Economic efficiency:
Economic efficiency refers to the effective use and allocation of the economy's
resources. Competition tends to bring about enhanced efficiency, in both a static and
a dynamic sense, by disciplining firms to produce at the 16 (2017) 8 SCC 47 lowest
possible cost and pass these cost savings on to consumers, and motivating firms to
undertake research and development to meet customer needs.
2.2.1.2. Economic growth and development:
Economic growth—the increase in the value of goods and services produced by an
economy—is a key indicator of economic development. Economic development refers
to a broader definition of an economy's well-being, including employment growth,
literacy and mortality rates and other measures of quality of life. Competition may
bring about greater economic growth and development through improvements in
economic efficiency and the reduction of wastage in the production of goods and
services. The market is therefore able to more rapidly reallocate resources, improve
productivity and attain a higher level of economic growth. Over time, sustained
economic growth tends to lead to an enhanced quality of life and greater economic
development.
2.2.1.3. Consumer Welfare: Competition policy contributes to economic growth to the
ultimate benefit of consumers, in terms of better choice (new products), better
quality and lower prices. Consumer welfare protection may be required in order to
redress a perceived imbalance between the market power of consumers and
producers. The imbalance between consumers and producers may stem from market
failures such as information asymmetries, the lack of bargaining position towards
producers and high transaction costs. Competition policy may serve as a complement
to consumer protection policies to address such market failures.”
22. The aforesaid Guidelines also spell out few more benefits of such laws
incorporating competition policies by highlighting the following advantages:
“2.2.2. In addition, competition policy is also beneficial to developing countries. Due
to worldwide deregulation, privatisation and liberalisation of markets, developingCompetition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

countries need a competition policy, in order to monitor and control the growing role
of the private sector in the economy so as to ensure that public monopolies are not
simply replaced by private monopolies.
2.2.3. Besides contributing to trade and investment policies, competition policy can
accommodate other policy objectives (both economic and social) such as the
integration of national markets and promotion of regional integration, the promotion
or protection of small businesses, the promotion of technological advancement, the
promotion of product and process innovation, the promotion of industrial
diversification, environment protection, fighting inflation, job creation, equal
treatment of workers according to race and gender or the promotion of welfare of
particular consumer groups.
In particular, competition policy may have a positive impact on employment policies, reducing
redundant employment (which often results from inefficiencies generated by large incumbents and
from the fact that more dynamic enterprises are prevented from entering the market) and favouring
jobs creation by new efficient competitors.
2.2.4. Competition policy complements trade policy, industrial policy and regulatory reform.
Competition policy targets business conduct that limits market access and which reduces actual and
potential competition, while trade and industrial policies encourage adjustment to the trade and
industrial structures in order to promote productivity-based growth and regulatory reform
eliminates domestic regulation that restricts entry and exit in the markets. Effective competition
policy can also increase investor confidence and prevent the benefits of trade from being lost
through anti-competitive practices. In this way, competition policy can be an important factor in
enhancing the attractiveness of an economy to foreign direct investment, and in maximising the
benefits of foreign investment.”
23. In fact, there is broad empirical evidence supporting the proposition that competition is
beneficial for the economy. Economists agree that it has an important role to play in improving
productivity and, therefore, the growth prospects of an economy. It is achieved in the following
manner:
“International Competition Network — Economic Growth and Productivity
Competition contributes to increased productivity through:
Pressure on firms to control costs—In a competitive environment, firms must
constantly strive to lower their production costs so that they can charge competitive
prices, and they must also improve their goods and services so that they correspond
to consumer demands.
Easy market entry and exit—Entry and exit of firms reallocates resources from less to
more efficient firms. Overall productivity increases when an entrant is more efficient
than the average incumbent and when an existing firm is less efficient than theCompetition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

average incumbent. Entry—and the threat of entry— incentivises firms to
continuously improve in order not to lose market share to or be forced out of the
market by new entrants.
Encouraging innovation—Innovation acts as a strong driver of economic growth
through the introduction of new or substantially improved products or services and
the development of new and improved processes that lower the cost and increase the
efficiency of production. Incentives to innovate are affected by the degree and type of
competition in a market.
Pressure to improve infrastructure—Competition puts pressure on communities to
keep local producers competitive by improving roads, bridges, docks, airports and
communications, as well as improving educational opportunities.
Benchmarking—Competition also can contribute to increased productivity by
creating the possibility of benchmarking. The productivity of a monopolist cannot be
measured against rivals in the same geographic market, but a dose of competition
quickly will expose inferior performance. A monopolist may be content with
mediocre productivity but a firm battling in a competitive market cannot afford to fall
behind, especially if the investment community is benchmarking it against its rivals.”
24. Productivity is increased through competition by putting pressure on firms to control costs as
the producers strive to lower their production costs so that they can charge competitive prices. It
also improves the quality of their goods and services so that they correspond to consumers'
demands.
25. Competition law enforcement deals with anti- competitive practices arising from the acquisition
or exercise of undue market power by firms that result in consumer harm in the forms of higher
prices, lower quality, limited choices and lack of innovation. Enforcement provides remedies to
avoid situations that will lead to decreased competition in markets. Effective enforcement is
important not only to sanction anti-competitive conduct but also to deter future anti-competitive
practices.
26. When we recognise that competition has number of benefits, it clearly follows that cartels or
anti-competitive agreements cause harm to consumers by fixing prices, limiting outputs or
allocating markets. Effective enforcement against such practices has direct visible effects in terms of
reduced prices in the market and this is also supported by various empirical studies.
27. Keeping in view the aforesaid objectives that need to be achieved, Indian Parliament enacted the
Competition Act, 2002. Need to have such a law became all the more important in the wake of
liberalisation and privatisation as it was found that the law prevailing at that time, namely,
Monopolies and Restrictive Trade Practices Act, 1969 was not equipped adequately enough to tackle
the competition aspects of the Indian economy. The law enforcement agencies, which include CCI
and COMPAT, have to ensure that these objectives are fulfilled by curbing anti- competitiveCompetition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

agreements.
28. Once the aforesaid purpose sought to be achieved is kept in mind, and the same is applied to the
facts of this case after finding that the anti-competitive conduct of the appellants continued after
coming into force of provisions of Section 3 of the Act as well, the argument predicated on
retrospectivity pales into insignificance.
29. One has to keep in mind the aforesaid objective which the legislation in question attempts to
subserve and the mischief which it seeks to remedy. As pointed out above, Section 18 of the Act casts
an obligation on CCI to “eliminate” anti-competitive practices and promote competition, interests of
the consumers and free trade. It was rightly pointed out by Mr Neeraj Kishan Kaul, the learned
Additional Solicitor General, that the Act is clearly aimed at addressing the evils affecting the
economic landscape of the country in which interest of the society and consumers at large is directly
involved. This is so eloquently emphasised by this Court in Competition Commission of India v.
SAIL in the following manner: (SCC pp. 755-56 & 794, paras 6, 8-10 & 125) “6. As far as the
objectives of competition laws are concerned, they vary from country to country and even within a
country they seem to change and evolve over the time. However, it will be useful to refer to some of
the common objectives of competition law. The main objective of competition law is to promote
economic efficiency using competition as one of the means of assisting the creation of market
responsive to consumer preferences. The advantages of perfect competition are threefold: allocative
efficiency, which ensures the effective allocation of resources, productive efficiency, which ensures
that costs of production are kept at a minimum and dynamic efficiency, which promotes innovative
practices. These factors by and large have been accepted all over the world as the guiding principles
for effective implementation of competition law.
xx xx xx
8. The Bill sought to ensure fair competition in India by prohibiting trade practices which cause
appreciable adverse effect on the competition in market within India and for this purpose
establishment of a quasi-judicial body was considered essential. The other object was to curb the
negative aspects of competition through such a body, namely, “the Competition Commission of
India” (for short “the Commission”) which has the power to perform different kinds of functions,
including passing of interim orders and even awarding compensation and imposing penalty. The
Director General appointed under Section 16(1) of the Act is a specialised investigating wing of the
Commission. In short, the establishment of the Commission and enactment of the Act was aimed at
preventing practices having adverse effect on competition, to protect the interest of the consumer
and to ensure fair trade carried out by other participants in the market in India and for matters
connected therewith or incidental thereto.
9. The various provisions of the Act deal with the establishment, powers and functions as well as
discharge of adjudicatory functions by the Commission. Under the scheme of the Act, this
Commission is vested with inquisitorial, investigative, regulatory, adjudicatory and to a limited
extent even advisory jurisdiction. Vast powers have been given to the Commission to deal with the
complaints or information leading to invocation of the provisions of Sections 3 and 4 read withCompetition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

Section 19 of the Act. In exercise of the powers vested in it under Section 64, the Commission has
framed regulations called the Competition Commission of India (General) Regulations, 2009 (for
short “the Regulations”).
10. The Act and the Regulations framed thereunder clearly indicate the legislative intent of dealing
with the matters related to contravention of the Act, expeditiously and even in a time-bound
programme. Keeping in view the nature of the controversies arising under the provisions of the Act
and larger public interest, the matters should be dealt with and taken to the logical end of
pronouncement of final orders without any undue delay. In the event of delay, the very purpose and
object of the Act is likely to be frustrated and the possibility of great damage to the open market and
resultantly, country's economy cannot be ruled out.”
68) It is for the aforesaid reason that the CCI is entrusted with duties, powers and functions to deal
with three kinds of anti-competitive practices mentioned above. The purpose is to eliminate such
practices which are having adverse effect on the competition, to promote and sustain competition
and to protect the interest of the consumers and ensure freedom of trade, carried on by the other
participants, in India. For the purpose of conducting such an inquiry, the CCI is empowered to call
any person for rendering assistance and/or produce the records/material for arriving at even the
prima facie opinion. The regulations also empower the CCI to hold conferences with the concerned
persons/parties, including their advocates/authorised persons.
69) It is also relevant to mention at this stage that while inquiring into any alleged contravention
and determining whether any agreement has an appreciable adverse effect on competition, factors
which are to be taken into consideration are mentioned in sub-section (3) of Section 19. These
include creation of barriers to new entrants in the market, driving existing competitors out of the
market and foreclosure of competition by hindering entry into the market. All these activities have
connection with the ‘market’. The word ‘market’ has reference to ‘relevant market’. As per sub-
section (5) of Section 19, such relevant market can be relevant geographic market or relevant
product market. In the present case, we are concerned with the relevant product market, viz.
telecommunication market. Sub-section (7) of Section 19 enumerates the factors which are to be
kept in mind while determining the relevant product market.
70) Market definition is a tool to identify and define the boundaries of competition between firms. It
serves to establish the framework within which the competition policy is applied by the
Commission. The main purpose of market definition is to identify in a systematic way the
competitive constraints that the undertakings involved face. The objective of defining a market in
both its product and geographic dimension is to identify those actual competitors of the
undertakings involved that are capable of constraining those undertakings behaviour and of
preventing them from behaving independently of effective competitive pressure. Therefore, the
purpose of defining the ‘relevant market’ is to assess with identifying in a systematic way the
competitive constraints that undertakings face when operating in a market. This is the case in
particular for determining if undertakings are competitors or potential competitors and when
assessing the anti- competitive effects of conduct in a market. The concept of relevant market
implies that there could be an effective competition between the products which form part of it andCompetition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

this presupposes that there is a sufficient degree of interchangeability between all the products
forming part of the same market insofar as specific use of such product is concerned. In essence, it is
the notion of ‘power over the market’ which is the key to analyse many competitive issues.
71) It is an admitted position that in the instant case we are dealing with the telecom market, which
is the relevant market. An interesting feature is that this telecom market is also regulated by the
statutory regime contained in the TRAI Act. Under the said Act, TRAI is established as a regulator
which exercises control/supervision and also provides guidance to the telecom/mobile market. This
statutory body is required to function as per the provisions of the TRAI Act as well as the Rules and
Regulations framed thereunder. Additionally, the telecom companies are also governed by licence
agreements entered into between the Central Government and such service providers, for providing
telephone/telecommunication services to the customers/subscribers. At this stage, therefore, we
take note of the relevant provisions of the TRAI Act:
"11. Functions of Authority. – (1) Notwithstanding anything contained in the Indian Telegraph Act,
1885 (13 of 1885), the functions of the Authority shall be to –
(a) make recommendations, either suo moto or on a request from the licensor, on the following
matters, namely:
xx xx xx
(iv) measures to facilitate competition and promote efficiency in the operation of
telecommunication services so as to facilitate growth in such services;
xx xx xx
(b) discharge the following functions, namely:–
(i) ensure compliance of terms and conditions of licence;
(ii) notwithstanding anything contained in the terms and conditions of the licence granted before
the commencement of the Telecom Regulatory Authority of India (Amendment) Act, 2000, fix the
terms and conditions of inter-connectivity between the service providers;
(iii) ensure technical compatibility and effective inter- connection between different service
providers;
(iv) regulate arrangement amongst service providers of sharing their revenue derived from
providing telecommunication services;
(v) lay-down the standards of quality of service to be provided by the service providers and ensure
the quality of service and conduct the periodical survey of such service provided by the service
providers so as to protect interest of the consumers of telecommunication service;Competition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

(vi) lay-down and ensure the time period for providing local and long distance circuits of
telecommunication between different service providers;
(vii) maintain register of interconnect agreements and of all such other matters as may be provided
in the regulations;
(viii) keep register maintained under clause (vii) open for inspection to any member of public on
payment of such fee and compliance of such other requirement as may be provided in the
regulations;
(ix) ensure effective compliance of universal service obligations;
(c) levy fees and other charges at such rates and in respect of such services as may be determined by
regulations;
(d) perform such other functions including such administrative and financial functions as may be
entrusted to it by the Central Government or as may be necessary to carry out the provisions of this
Act:
Provided that the recommendations of the Authority specified in clause (a) of this
sub-section shall not be binding upon the Central Government.
xx xx xx
14. Establishment of Appellate Tribunal. – The Central Government shall, by
notification, establish an Appellate Tribunal to be known as the Telecom Disputes
Settlement and Appellate Tribunal to –
(a) adjudicate any dispute –
(i) between a licensor and a licensee;
(ii) between two or more service providers;
(iii) between a service provider and a group of consumers:
Provided that nothing in this clause shall apply in respect of matters relating to – (A)
the monopolistic trade practice, restrictive trade practice and unfair trade practice
which are subject to the jurisdiction of the Monopolies and Restrictive Trade
Practices Commission established under sub-
section (1) of section 5 of the Monopolies and Restrictive Trade Practices Act, 1969 (54 of 1969); (B)
the complaint of an individual consumer maintainable before a Consumer Disputes Redressal
Forum or a Consumer Disputes Redressal Commission or the National Consumer RedressalCompetition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

Commission established under section 9 of the Consumer Protection Act, 1986 (68 of 1986);
(C) dispute between telegraph authority and any other person referred to in sub-section (1) of
section 7B of the Indian Telegraph Act, 1885 (13 of 1885);
(b) hear and dispose of appeal against any direction, decision or order of the Authority under this
Act.
xx xx xx
16. Procedure and powers of Appellate Tribunal. – (1) The Appellate Tribunal shall not be bound by
the procedure laid down by the Code of Civil Procedure, 1908 (5 of 1908), but shall be guided by the
principles of natural justice and, subject to the other provisions of this Act, the Appellate Tribunal
shall have powers to regulate its own procedure.
(2) The Appellate Tribunal shall have, for the purposes of discharging the functions under this Act,
the same powers as are vested in a civil court under the Code of Civil Procedure, 1908 (5 of 1908),
while trying a suit, in respect of the following matters, namely:–
(a) summoning and enforcing the attendance of any person and examining him on oath;
(b) requiring the discovery and production of documents;
(c) receiving evidence on affidavits;
(d) subject to the provisions of section 123 and 124 of the Indian Evidence Act, 1872 (1 of 1872),
requisitioning any public record or document or a copy of such record or document, from any office;
(e) issuing commissions for the examination of witnesses or documents;
(f) reviewing its decisions;
(g) dismissing an application for default or deciding it, ex parte;
(h) setting aside any order of dismissal of any application for default or any order passed by it, ex
parte; and
(i) any other matter which may be prescribed. (3) Every proceeding before the Appellate Tribunal
shall be deemed to be a judicial proceeding within the meaning of sections 193 and 228, and for the
purposes of section 196 of the Indian Penal Code (45 of 1860) and the Appellate Tribunal shall be
deemed to be a civil court for the purposes of section 195 and Chapter XXVI of the Code of Criminal
Procedure, 1973 (2 of 1974).”Competition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

72) Other provisions in the telecom sector which are relevant for the purposes of these appeals are
taken note of by the High Court as under:
"Telecommunication laws binds all
19. The relevant licenses Unified License (UL) – The UL issued by Department of
Telecommunications, Government of India (“DoT”) for providing telecommunication
services on a pan India basis. Licence under Section 4 of Indian Telegraph Act, 1885
therefore they become Telecom Service Provider (“TSP”). Relevant clauses of the UL
(UASL) are -
(a) Clause 16 of Part-I: Other conditions: The licensee is bound by all TRAI
Orders/Directions/Reglations;
(b) Clause 27 of Part-I: Network Interconnnection, particularly, Clause 27.4, which
requires a licensee to interconnect subject to compliance with prevailing regulations
and determinations issued by TRAI, and contemplates the execution of ICAs to
establish interconnection in sufficient capacity and number to enable transmission
and reception of messages between the interconnected systems;
(c) Clause 29 of Part-I, requiring a licensee to ensure QoS standards as may be
prescribed by DoT/TRAI.
Specifically, Clause 29.4, empowers DoT/TRAI to evaluate QoS parameters prior to grant of
permission for commencement of services; and
(d) Clause 6.2 of Part-II, which requires a licensee to provide interconnection to all TSPs to ensure
that calls are completed to all destinations.
Inter-connection Agreements
20. Similar separate Interconnection Agreements (ICAs) are executed between the parties. The
relevant clauses of ICAs are as under:
Clause 2.4: “...RJIL will be required to establish Interconnection at the Switches of
IDEA as listed in Schedule I. In addition to these specified locations, the Parties may
further agree to interconnect at an additional location(s) as mutually agreed to by
and between the parties during the term of this Agreement...” Clause 5.7: “...At the
end of two years, the Parties shall convert the total E1s existing at the POIs into
one-way E1s for the Outgoing Traffic of each Party on the basis of the traffic ratio
existing 3 months prior to the expiry of the initial period of two years. These E1s shall
thereafter be continued as one-way E1s for the remaining term of the Agreement at
the cost of RJIL...” Clause 9.1: “...A minimum notice of 4 weeks has to be given by
either Party for augmentations of Interconnect Links...” Clause 9.2: “...AugmentationCompetition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

shall be completed within 90 days of receipt of requisite charges specified in Schedule
2 from RJIL...” Clause 9.3: “...Any request for augmentation of capacity shall be in
writing with Performance reports as prescribed in Schedule 4...” Clause 9.4: “...Traffic
measurements for 7 days shall be taken by both the parties during agreed busy route
hours, every 6 months after commencement of traffic at the POIs to determine
further capacity requirements...” Clause 9.5: “...RJIL shall provide a forecast in
writing in advance for its requirement of port capacity for Telephony Traffic for the
next 6 months to enable IDEA to dimension the required capacity in its network...”
21. The relevant clauses of the ICAs are:
(a) Clause 2 makes clear that the ICA will be applicable and in effect from the date of
execution;
(b) Clause 2.10 makes clear that the interconnection facilities at each POI will
conform to the applicable QoS standards prescribed by TRAI;
(c) Clause 3 – Terms and Amendments – again makes clear that the ICA becomes
applicable, effective and operational from the date of execution and is valid until both
parties hold a valid license for providing access services;
(d) Clause 4 – Applicability and Providing Services – reiterates that the ICA becomes
applicable on signing and is subject to the terms and conditions of the telecom
licence;
(e) Clause 5.2 specifically provides that for the initial two years, provision and
augmentation of transmission links shall be at the cost of RJIL;
(f) Clause 5.7 contemplates conversion of two-way E1s into one-way E1s only after
two years, which in other words mean that for two years all E1s must be two-way E1s;
(g) Clause 9 provides modalities for enhancement of ports; and
(h) Clause 10.7 again reiterates that Idea is bound to maintain QoS standards
prescribed by TRAI.
22. Quality of Service Regulations, 2009 Quality of Service Regulations (“QoS Regulations, 2009”)
issued by TRAI under Section 36 read with Section 11 of the TRAI Act. Clause 5Iiv) and Clause 14, as
relevant, are reproduced as under:
(a) Clause 5(iv) prescribes that the congestion at each individual POI cannot exceed
0.5% over a period of one month (no more than 5 out of every 100 calls can fail).Competition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

(b) Clause 14 provides that in the event of any doubt regarding interpretation of any of the
provisions of the QoS regulations, the view of the TRAI shall be final and binding.
23. The relevant clauses of the Standards of Quality of Service of Basic Telephone Service (wireline)
and Cellular Mobile Telephone Service Regulations, 2009 includes Cellular Mobile Telephone
Services. The terms “Point of Interconnection (POI)”, “Quality of Service (QoS)”, “Service Provider,
Telecommunication services” have been defined in the Regulations. The term POI congestion is also
described in 3.12 and 4.7 of POI.”
73) Some of the features which govern the telecommunication industry and noted by the High Court
may also be captured at this stage. These are:
(a) To protect the interest of the service providers and consumers of the telecom
sector and to permit and ensure technical compatibility and effective
inter-relationship between different service providers and for ensuring compliance of
licence conditions by all the service providers, TRAI was constituted under the
Telecom Regulatory Authority of India Act, 1997. TRAI is a
recommendatory/advisory and regulatory body discharging the functions envisaged
under sub-section (1) of Section 11 of the said Act. TRAI, inter alia, is charged with
ensuring fair competition amongst service providers, including fixing the terms and
conditions of entire activity between the service providers and laying down the
standards of Quality of Service (QoS) to be provided by each service provider. In
exercise of its functions, TRAI has issued detailed Regulations for telecom services,
including fixation and revision of tariffs (Tariff Order), fixation of Inter-connect
Usage Charges (IUC), prescription of quality of service standards, etc.
(b) The Telecom Service Providers, which include the respondents as well as RJIL,
provide telecommunication access service and are PAN India Telecom Service
Providers. They are governed by the Cellular Mobile Telephone Service (CMTS)/
Unified Access Service Licence (UASL) issued by the Telecommunications
Department, Government of India under section 4 of the Telegraph Act.
(c) The Central Government has the exclusive privilege of establishing, maintaining
and working telegraphs under the Telegraph Act and the Central Government is
authorised to grant licence on such terms and conditions and in consideration of such
payment as it thinks fit to any person to establish, maintain or work as telegraph
within any part of the country. By virtue of Section 4 of the Telegraph Act, a service
provider is duty bound to enter into a licence agreement with the former for unified
licence, with authorisation for provision of services, as per the terms and conditions
prescribed in the Schedule. As a condition of the said licence, the licensee agrees and
unequivocally undertakes to fully comply with the terms and conditions stipulated in
the licence agreement without any deviation or reservation of any kind. The licence is
governed by the provisions of the Telegraph Act, the Indian Wireless Telegraphy Act,
1933, the TRAI Act and the Information Technology Act, 2000, as modified orCompetition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

regulated from time to time.
74) In order to ensure that there is smooth interconnectivity and a consumer who is
the subscriber of mobile phone of one service provider, say for e.g. Vodafone, and
wants to make call to a mobile phone of his friend which is provided by another
service provider, say Idea Cellular, the unified licenses put an obligation on all these
licensees to interconnect with each other on the POI.
This is so mentioned in Clause 27.4 of Part I of the Schedule to the unified licence. Such
interconnectivity of POI is subject to compliance of regulation/directions issued by TRAI. The
interconnection agreement, inter alia, provides for the following clauses:
(a) to meet all reasonable demand for the transmission and reception of messages
between the interconnect systems;
(b) to establish and maintain such one or more POIs as are reasonably required and
are of sufficient capacity and in sufficient numbers to enable transmission and
reception of the messages by means of applicable systems; and
(c) to connect and keep connected to the applicable systems.
Some of the other clauses of the interconnection agreement are as follows:
 A minimum four weeks’ written notice has to be given by either party for
augmentation of interconnect links.  Augmentation shall be completed within 90
days of receipt of requisite charges specified in the Schedule.  Either party shall
provide a forecast in writing, in advance for its requirements of port capacity for
“Telephony Traffic” for the next six months to enable the other party to dimension
the required capacity in its network.
 The interconnection tests for reach and every interface will be carried out by
mutual arrangement between signatories of the agreement.
By virtue of the licence, the licensee is obligated to ensure quality of service as
prescribed by the licensor or TRAI and failure on their part to adhere to the quality of
service stipulated by TRAI would make the licensor liable to be treated for breach of
the terms and conditions of the licence.
In order to render effective services, it is mandatory for the licensee to
interconnect/provide POIs to all eligible telecom service providers to ensure that calls
are completed to all destinations and interconnection agreement is entered into
between the different service providers which mandates each of the party to the
agreement to provide to the other interconnection traffic carriage and all the
technical and operational quality service and time lines, i.e. the equivalent to thatCompetition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

which the party provides to itself. The interconnection agreement separately entered
into different service providers is based on the format prescribed in the
Telecommunication Interconnection (Reference Interconnect Offer) Regulations,
2002.
75) POI is defined in the agreement, in the following words:
"POI are those points between two network operators which allow voice call
originating from the work of one operator to terminate on the network by other
operator.”
76) We may also note that on June 07, 2005 a direction was issued under Section 13
read with sub-clause (i) to (v) of sub-clause (b) of Section 11 of the TRAI Act, which
provides as follows:
"In exercise of the powers vested in it under section 13 read with section 11(1)(b)(i),
(ii), (iii), (iv) and (v) of the Telecom Regulatory Authority of India Act, 1997 and in
order to ensure compliance of terms and conditions of license and effective
interconnection between service providers and to protect consumer interest, the
Authority hereby directs all service providers to provide interconnection on the
request of the interconnection seeker within 90 days of the applicable payments
made by the interconnection seeker. Further there is a direction issued by the
Government of India, Ministry of Telecommunication dated 28th August, 2005 by
which directions have been issued to provide data of subscribers in the prescribed
format.”
77) From the aforesaid analysis of the scheme contained in the TRAI Act, it becomes
clear that the functioning of the telecom companies which are granted licence under
Section 4 of the Telegraph Act is regulated by the provisions contained in the TRAI
Act. TRAI is a regulator which regulates the telecom industry, which is a statutory
body created under the TRAI Act.
The necessity of such regulators has been emphasised by a Constitution Bench of this Court in
Modern Dental College and Research Centre and Others v. State of Madhya Pradesh and Others17 in
the following words:
"Need for regulatory mechanism
87. Regulatory mechanism, or what is called regulatory economics, is the order of the
day. In the last 60-70 years, economic policy of this country has travelled from laissez
faire to mixed economy to the present era of liberal economy with regulatory regime.
With the advent of mixed economy, there was mushrooming of the public sector and
some of the key industries like aviation, insurance, railways, electricity/power,
telecommunication, etc. were monopolised by the State. Licence/permit raj prevailedCompetition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

during this period with strict control of the Government even in respect of those
industries where private sectors were allowed to operate. However, Indian economy
experienced major policy changes in early 90s on LPG Model i.e. liberalisation,
privatisation and globalisation. With the onset of reforms to liberalise the Indian
economy, in July 1991, a new chapter has dawned for India. This period of economic
transition has had a tremendous impact on the overall economic development of
almost all major sectors of the economy.
88. When we have a liberal economy which is regulated by the market forces (that is
why it is also termed as market economy), prices of goods and services in such an
economy are determined in a free price system set up by supply and demand. This is
often contrasted with a planned economy in which a Central Government determines
the price of goods and services using a fixed price system. Market economies are also
contrasted with mixed economy where the price system is not entirely free, but under
some government control or heavily regulated, which is sometimes combined with
State led economic planning that is not extensive enough to constitute a planned
economy.
89. With the advent of globalisation and liberalisation, though the market economy is
restored, at the same time, it is also felt that market economies should not exist in
pure form. Some regulation of the various industries is required rather than allowing
self-regulation by market 17 (2016) 7 SCC 353 forces. This intervention through
regulatory bodies, particularly in pricing, is considered necessary for the welfare of
the society and the economists point out that such regulatory economy does not rob
the character of a market economy which still remains a market economy.
Justification for regulatory bodies even in such industries managed by private sector
lies in the welfare of people. Regulatory measures are felt necessary to promote basic
well being for individuals in need. It is because of this reason that we find regulatory
bodies in all vital industries like, insurance, electricity and power,
telecommunications, etc.”
78) Thus, with the advent of globalisation/liberalisation leading to free market
economy, regulators in respect of each sector have assumed great significance and
importance. It becomes their bounden duty to ensure that such a regulator fulfils the
objectives enshrined in the Act under which a particular regulator is created.
Insofar as the telecom sector is concerned, the TRAI Act itself mentions the objective which it seeks
to achieve. It not only exercises control/supervision over the telecom service providers/ licensees,
TRAI is also supposed to provide guidance to the telecom/mobile market. ‘Introduction’ to the TRAI
Act itself mentions that due to tremendous growth in the services it was considered essential to
regulate the telecommunication services by a regulatory body which should be fully empowered to
control the services, in the best interest of the country as well as the service providers. Likewise, the
Statement of Objects and Reasons of this Act, inter alia, stipulates as under:Competition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

"1. In the context of the National Telecom Policy, 1994, which amongst other things,
stresses on achieving the universal service, bringing the quality of telecom services to
world standards, provisions of wide range of services to meet the customers demand
at reasonable price, and participation of the companies registered in India in the area
of basic as well as value added telecom services as also making arrangements for
protection and promotion of consumer interest and ensuring fair competition, there
is a felt need to separate regulatory functions from service providing functions which
will be in keeping with the general trend in the world. In the multi-operator situation
arising out of opening of basic as well as value added services in which private
operator will be competing with Government operators, there is a pressing need for
an independent telecom regulatory body for regulation of telecom services for orderly
and healthy growth of telecommunication infrastructure apart from protection of
consumer interest.
xx xx xx
4. The powers and functions of the Authority, inter alia, are.–
(i) ensuring technical compatibility and effective inter-relationship between different
service providers;
(ii) regulation of arrangement amongst service providers of sharing their revenue
derived from providing telecommunication services;
(iii) ensuring compliance of licence conditions by all service providers;
(iv) protection of the interest of the consumers of telecommunication service;
(v) settlement of disputes between service providers;
(vi) fixation of rates for providing telecommunication service within India and
outside India;
(vii) ensuring effective compliance of universal service obligations.”
79) TRAI is, thus, constituted for orderly and healthy growth of telecommunication
infrastructure apart from protection of consumer interest. It is assigned the duty to
achieve the universal service which should be of world standard quality on the one
hand and also to ensure that it is provided to the customers at a reasonable price, on
the other hand. In the process, purpose is to make arrangements for protection and
promotion of consumer interest and ensure fair competition. It is because of this
reason that the powers and functions which are assigned to TRAI are highlighted in
the Statement of Objects and Reasons.Competition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

Specific functions which are assigned to TRAI, amongst other, including ensuring technical
compatibility and effective inter- relationship between different service providers; ensuring
compliance of licence conditions by all service providers; and settlement of disputes between service
providers.
80) In the instant case, dispute raised by RJIL specifically touches upon these aspects as the
grievance raised is that the IDOs have not given POIs as per the licence conditions resulting into
non- compliance and have failed to ensure inter se technical compatibility thereby. Not only RJIL
has raised this dispute, it has even specifically approached TRAI for settlement of this dispute which
has arisen between various service providers, namely, RJIL on the one hand and the IDOs on the
other, wherein COAI is also roped in. TRAI is seized of this particular dispute.
81) It is a matter of record that before the TRAI, IDOs have refuted the aforesaid claim of RJIL.
Their submission is that not only required POIs were provided to RJIL, it is the RJIL which is in
breach as it was making unreasonable and excessive demand for POIs. It is specifically pleaded by
the IDOs that:
(i) RJIL raised its demand for POIs for the first time on June 21, 2016.
(ii) In the letter dated June 21, 2016, it was admitted that RJIL was in test phase.
(iii) There was no express mention of any commercial launch date.
(iv) As per the letter, immediately on commercial launch RJIL would have a 22mn
subscriber base for which number series was already allotted.
(v) As per the DoT Circular dated August 29, 2005 test customers are not considered
as subscribers and test customers can only be in the form of business partners. It was
highlighted that problem, if any, of congestion has been suffered on account of
provisioning of full-fledged services during test phase.
(vi) RJIL in its complaint before the TRAI was not considering the period of 90 days
as was prescribed in the Interconnection Agreement. It was instead proceeding on
the basis that the demand for POIs should be met on an immediate basis.
(vii) There was several errors in the forecast made by RJIL.
(viii) The tables given by the RJIL are wrong as they take into account its total
demand at the end of nine months against what was actually provided.
82) Learned counsel appearing for the IDOs had also argued that the first firm
demand for provisioning of POIs was made by RJIL on June 21, 2016. According to
the IDOs, in that letter, RJIL had expressly admitted that it was under test phase and
had not commenced ‘commercial services’. RJIL had also stated that the demand forCompetition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

POIs was being made to ‘provide seemless connectivity to targeted subscribers’ as
against ‘test consumers’.
Their submission was that it was not disclosed at all as to when RJIL was going to launch
commercial services. On the basis of the aforesaid stand taken by the IDOs, their argument is that in
the first instance it is the TRAI which is not only competent but more appropriate authority to
consider these aspects as it is the TRAI which is the specialised body going by the nature of dispute
between the parties, following aspects have to be determined by the TRAI:
(a) Whether IDOs were under any obligation to provide POIs during test period?
(b) As per the letter dated June 21, 2016 from RJIL, when IDOs were to commence
provisioning of POIs to RJIL?
(c) Whether the demand for POIs made by RJIL were reasonable or not?
(d) Whether there was any delay/denial at the end of Vodafone in provisioning of
POIs?
(e) Whether the POIs were to be provided ‘immediately’ and during ‘test phase’?
(f) Whether IDOs have provided sufficient number of POIs to RJIL in conformity
with the licence conditions?
83) We are of the opinion that as the TRAI is constituted as an expert regulatory body
which specifically governs the telecom sector, the aforesaid aspects of the disputes
are to be decided by the TRAI in the first instance. These are jurisdictional aspects.
Unless the TRAI finds fault with the IDOs on the aforesaid aspects, the matter cannot
be taken further even if we proceed on the assumption that the CCI has the
jurisdiction to deal with the complaints/information filed before it. It needs to be
reiterated that RJIL has approached the DoT in relation to its alleged grievance of
augmentation of POIs which in turn had informed RJIL vide letter dated September
06, 2016 that the matter related to inter-connectivity between service providers is
within the purview of TRAI. RJIL thereafter approached TRAI; TRAI intervened and
issued show-cause notice dated September 27, 2016; and post issuance of show-cause
notice and directions, TRAI issued recommendations dated October 21, 2016 on the
issue of inter-connection and provisioning of POIs to RJIL. The sectoral authorities
are, therefore, seized of the matter. TRAI, being a specialised sectoral regulator and
also armed with sufficient power to ensure fair, non-discriminatory and competitive
market in the telecom sector, is better suited to decide the aforesaid issues. After all,
RJIL’s grievance is that inter-
connectivity is not provided by the IDOs in terms of the licenses granted to them. TRAI Act and
Regulations framed thereunder make detailed provisions dealing with intense obligations of theCompetition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

service providers for providing POIS. These provisions also deal as to when, how and in what
manner POIs are to be provisioned.
They also stipulate the charges to be realised for POIs that are to be provided to another service
provider. Even the consequences for breach of such obligations are mentioned.
84) We, therefore, are of the opinion that the High Court is right in concluding that till the
jurisdictional issues are straightened and answered by the TRAI which would bring on record
findings on the aforesaid aspects, the CCI is ill-equipped to proceed in the matter. Having regard to
the aforesaid nature of jurisdiction conferred upon an expert regulator pertaining to this specific
sector, the High Court is right in concluding that the concepts of “subscriber”, “test period”,
“reasonable demand”, “test phase and commercial phase rights and obligations”, “reciprocal
obligations of service providers” or “breaches of any contract and/or practice”, arising out of TRAI
Act and the policy so declared, are the matters within the jurisdiction of the Authority/TDSAT under
the TRAI Act only. Only when the jurisdictional facts in the present matter as mentioned in this
judgment particularly in paras 56 and 82 above are determined by the TRAI against the IDOs, the
next question would arise as to whether it was a result of any concerted agreement between the
IDOs and COAI supported the IDOs in that endeavour. It would be at that stage the CCI can go into
the question as to whether violation of the provisions of TRAI Act amounts to ‘abuse of dominance’
or ‘anti-competitive agreements’. That also follows from the reading of Sections 21 and 21A of the
Competition Act, as argued by the respondents.
85) The issue can be examined from another angle as well. If the CCI is allowed to intervene at this
juncture, it will have to necessarily undertake an exercise of returning the findings on the aforesaid
issues/aspects which are mentioned in paragraph 82 above. Not only TRAI is better equipped as a
sectoral regulator to deal with these jurisdictional aspects, there may be a possibility that the two
authorities, namely, TRAI on the one hand and the CCI on the other, arrive at a conflicting views.
Such a situation needs to be avoided. This analysis also leads to the same conclusion, namely, in the
first instance it is the TRAI which should decide these jurisdictional issues, which come within the
domain of the TRAI Act as they not only arise out of the telecom licenses granted to the service
providers, the service providers are governed by the TRAI Act and are supposed to follow various
regulations and directions issued by the TRAI itself.
86) This takes us to the next level of the issue, viz. whether TRAI has the exclusive jurisdiction to
deal with matters involving anti- competitive practices to the exclusion of CCI altogether because of
the reason that the matter pertains to telecom sector?
87) The IDOs have argued that not only TRAI is an expert body which can deal with these issues and
has been assigned this function specifically under the TRAI Act, even the anti-competitive aspects of
telecom sector are specifically assigned to the TRAI in the TRAI Act itself. On that premise the
submission is that the TRAI Act is a special legislation which prevails over the provisions of the
Competition Act as the Competition Act is general in nature. It is also argued that even if the
Competition Act is treated as a special statute, between the two special statutes the TRAI Act would
prevail as it is a complete code in itself which regulates the telecom sector in its entirety, includingCompetition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

the aspects of competition.
88) Such a submission, on a cursory glance, may appear to be attractive. However, the matter
cannot be examined by looking into the provisions of the TRAI Act alone. Comparison of the
regimes and purpose behind the two Acts becomes essential to find an answer to this issue. We have
discussed the scope and ambit of the TRAI Act in the given context as well as the functions of the
TRAI. No doubt, we have accepted that insofar as the telecom sector is concerned, the issues which
arise and are to be examined in the context of the TRAI Act and related regime need to be examined
by the TRAI. At the same time, it is also imperative that specific purpose behind the Competition Act
is kept in mind. This has been taken note of and discussed in the earlier part of the judgment. As
pointed out above, the Competition Act frowns the anti-competitive agreements. It deals with three
kinds of practices which are treated as anti-competitive and are prohibited. To recapitulate, these
are:
(a) where agreements are entered into by certain persons with a view to cause an
appreciable adverse effect on competition;
(b) where any enterprise or group of enterprises, which enjoys dominant position,
abuses the said dominant position; and
(c) regulating the combination of enterprises by means of mergers or amalgamations
to ensure that such mergers or amalgamations do not become anti-competitive or
abuse the dominant position which they can attain.
89) The CCI is specifically entrusted with duties and functions, and in the process
empower as well, to deal with the aforesaid three kinds of anti-competitive practices.
The purpose is to eliminate such practices which are having adverse effect on the
competition, to promote and sustain competition and to protect the interest of the
consumers and ensure freedom of trade, carried on by other participants, in India. To
this extent, the function that is assigned to the CCI is distinct from the function of
TRAI under the TRAI Act. Learned counsel for the appellants are right in their
submission that the CCI is supposed to find out as to whether the IDOs were acting in
concert and colluding, thereby forming a cartel, with the intention to block or hinder
entry of RJIL in the market in violation of Section 3(3)(b) of the Competition Act.
Also, whether there was an anti-competitive agreement between the IDOs, using the platform of
COAI. The CCI, therefore, is to determine whether the conduct of the parties was unilateral or it was
a collective action based on an agreement. Agreement between the parties, if it was there, is pivotal
to the issue. Such an exercise has to be necessarily undertaken by the CCI. In Haridas Exports, this
Court held that where statutes operate in different fields and have different purposes, it cannot be
said that there is an implied repeal of one by the other. The Competition Act is also a special statute
which deals with anti-competition. It is also to be borne in mind that if the activity undertaken by
some persons is anti-competitive and offends Section 3 of the Competition Act, the consequences
thereof are provided in the Competition Act. Section 27 empowers the CCI to pass certain kinds ofCompetition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

orders, stipulated in the said provision, after inquiry into the agreements for abuse of dominant
position. The following kinds of orders can be passed by the CCI under this provision:
"27. Orders by Commission after inquiry into agreements or abuse of dominant
position. - Where after inquiry the Commission finds that any agreement referred to
in section 3 or action of an enterprise in a dominant position, is in contravention of
section 3 or section 4, as the case may be, it may pass all or any of the following
orders, namely:—
(a) direct any enterprise or association of enterprises or person or association of
persons, as the case may be, involved in such agreement, or abuse of dominant
position, to discontinue and not to re-enter such agreement or discontinue such
abuse of dominant position, as the case may be;
(b) impose such penalty, as it may deem fit which shall be not more than ten per cent
of the average of the turnover for the last three preceding financial years, upon each
of such person or enterprises which are parties to such agreements or abuse:
Provided that in case any agreement referred to in section 3 has been entered into by
a cartel, the Commission may impose upon each producer, seller, distributor, trader
or service provider included in that cartel, a penalty of up to three times of its profit
for each year of the continuance of such agreement or ten percent. of its turnover for
each year of the continuance of such agreement, whichever is higher.
(c) repealed;
(d) direct that the agreements shall stand modified to the extent and in the manner as
may be specified in the order by the Commission;
(e) direct the enterprises concerned to abide by such other orders as the Commission
may pass and comply with the directions, including payment of costs, if any;
(f) repealed;
(g) pass such other [order or issue such directions] as it may deem fit.
Provided that while passing orders under this section, if the Commission comes to a finding, that an
enterprise in contravention to section 3 or section 4 of the Act is a member of a group as defined in
clause (b) of the Explanation to section 5 of the Act, and other members of such a group are also
responsible for, or have contributed to, such a contravention, then it may pass orders, under this
section, against such members of the group. Moreover, it is within the exclusive domain of the CCI
to find out as to whether a particular agreement will have appreciable adverse effect on competition
within the relevant market in India. For this purpose, CCI is to take into consideration the
provisions contained in the Competition Act, including Section 29 thereof. Sections 45 and 46 alsoCompetition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

authorise the CCI to impose penalties in certain situations.
90) Obviously, all the aforesaid functions not only come within the domain of the CCI, TRAI is not
at all equipped to deal with the same. Even if TRAI also returns a finding that a particular activity
was anti-competitive, its powers would be limited to the action that can be taken under the TRAI Act
alone. It is only the CCI which is empowered to deal with the same anti-competitive act from the
lens of the Competition Act. If such activities offend the provisions of the Competition Act as well,
the consequences under that Act would also follow. Therefore, contention of the IDOs that the
jurisdiction of the CCI stands totally ousted cannot be accepted. Insofar as the nuanced exercise
from the stand point of Competition Act is concerned, the CCI is the experienced body in conducting
competition analysis. Further, the CCI is more likely to opt for structural remedies which would lead
the sector to evolve a point where sufficient new entry is induced thereby promoting genuine
competition. This specific and important role assigned to the CCI cannot be completely wished away
and the ‘comity’ between the sectoral regulator (i.e. TRAI) and the market regulator (i.e. the CCI) is
to be maintained.
91) The conclusion of the aforesaid discussion is to give primacy to the respective objections of the
two regulators under the two Acts. At the same time, since the matter pertains to the telecom sector
which is specifically regulated by the TRAI Act, balance is maintained by permitting TRAI in the
first instance to deal with and decide the jurisdictional aspects which can be more competently
handled by it. Once that exercise is done and there are findings returned by the TRAI which lead to
the prima facie conclusion that the IDOs have indulged in anti-competitive practices, the CCI can be
activated to investigate the matter going by the criteria laid down in the relevant provisions of the
Competition Act and take it to its logical conclusion. This balanced approach in construing the two
Acts would take care of Section 60 of the Competition Act as well.
92) We, thus, do not agree with the appellants that CCI could have dealt with this matter at this
stage itself without availing the inquiry by TRAI. We also do not agree with the respondents that
insofar as the telecom sector is concerned, jurisdiction of the CCI under the Competition Act is
totally ousted. In nutshell, that leads to the conclusion that the view taken by the High Court is
perfectly justified. Even the argument of the learned ASG is that the exercise of jurisdiction by the
CCI to investigate an alleged cartel does not impinge upon TRAI’s jurisdiction to regulate the
industry in any way. It was submitted that the promotion of competition and prevention of
competitive behaviour may not be high on the change of sectoral regulator which makes it prone to
‘regulatory capture’ and, therefore, the CCI is competent to exercise its jurisdiction from the stand
point of the Competition Act. However, having taken note of the skillful exercise which the TRAI is
supposed to carry out, such a comment vis-a-vis TRAI may not be appropriate. No doubt, as
commented by the Planning Commission in its report of February, 2007, a sectoral regulator, may
not have an overall view of the economy as a whole, which the CCI is able to fathom. Therefore, our
analysis does not bar the jurisdiction of CCI altogether but only pushes it to a later stage, after the
TRAI has undertaken necessary exercise in the first place, which it is more suitable to carry out. B.
Whether the writ petitions filed before the High Court of Bombay were maintainable?Competition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

93) Here comes the scope of judicial interference under Article 226 of the Constitution. As per the
RJIL as well as CCI, the High Court could not have entertained the writ petition against an order
passed under Section 26(1) of the Competition Act which was a pure administrative order and was
only a prima facie view expressed therein, and did not result in serious adverse consequences. It was
submitted that the finding of the High Court that such an order was quasi-judicial order is not only
erroneous but it is contrary to the law laid down in the case of Steel Authority of India Limited. The
respondents, on the other hand, have submitted that the judgment in the above case had no
application in the instant case as it did not deal with the sector that is regulated by a statutory
authority. Moreover, such an order was quasi-judicial in nature and cannot be treated as an
administrative order since it was passed by the CCI after collecting the detailed information from
the parties and by holding the conferences, calling material details, documents, affidavits and by
recording the opinion. It was submitted that judicial review against such an order is permissible and
it was open to the respondents to point out that the complete material, as submitted by the
respondents, was not taken into consideration which resulted in an erroneous order, which had
adverse civil consequences inasmuch as the respondents were subjected to further investigation by
the Director General.
94) We may mention at the outset that in the case of Steel Authority of India Limited, nature of the
order passed by the CCI under Section 26(1) of the Competition Act (here also we are concerned
with an order which is passed under Section 26(1) of the Competition Act) was gone into. The Court,
in no uncertain terms, held that such an order would be an administrative order and not a
quasi-judicial order. It can be discerned from paragraphs 94, 97 and 98 of the said judgment, which
are as under:
"94. The Tribunal, in the impugned judgment, has taken the view that there is a
requirement to record reasons which can be express, or, in any case, followed by
necessary implication and therefore, the authority is required to record reasons for
coming to the conclusion. The proposition of law whether an administrative or quasi-
judicial body, particularly judicial courts, should record reasons in support of their
decisions or orders is no more res integra and has been settled by a recent judgment
of this Court in CCT v. Shukla & Bros. [(2010) 4 SCC 785:
(2010) 2 SCC (Cri) 1201 : (2010) 2 SCC (L&S) 133], wherein this Court was primarily
concerned with the High Court dismissing the appeals without recording any reasons.
The Court also examined the practice and requirement of providing reasons for
conclusions, orders and directions given by the quasi-judicial and administrative
bodies.
xx xx xx
97. The above reasoning and the principles enunciated, which are consistent with the
settled canons of law, we would adopt even in this case. In the backdrop of these
determinants, we may refer to the provisions of the Act.Competition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

Section 26, under its different sub-sections, requires the Commission to issue various directions,
take decisions and pass orders, some of which are even appealable before the Tribunal. Even if it is a
direction under any of the provisions and not a decision, conclusion or order passed on merits by
the Commission, it is expected that the same would be supported by some reasoning. At the stage of
forming a prima facie view, as required under Section 26(1) of the Act, the Commission may not
really record detailed reasons, but must express its mind in no uncertain terms that it is of the view
that prima facie case exists, requiring issuance of direction for investigation to the Director General.
Such view should be recorded with reference to the information furnished to the Commission. Such
opinion should be formed on the basis of the records, including the information furnished and
reference made to the Commission under the various provisions of the Act, as aforereferred.
However, other decisions and orders, which are not directions simpliciter and determining the
rights of the parties, should be well reasoned analysing and deciding the rival contentions raised
before the Commission by the parties. In other words, the Commission is expected to express prima
facie view in terms of Section 26(1) of the Act, without entering into any adjudicatory or
determinative process and by recording minimum reasons substantiating the formation of such
opinion, while all its other orders and decisions should be well reasoned.
98. Such an approach can also be justified with reference to Regulation 20(4), which requires the
Director General to record, in his report, findings on each of the allegations made by a party in the
intimation or reference submitted to the Commission and sent for investigation to the Director
General, as the case may be, together with all evidence and documents collected during
investigation. The inevitable consequence is that the Commission is similarly expected to write
appropriate reasons on every issue while passing an order under Sections 26 to 28 of the Act.”
95) There is no reason to take a contrary view. Therefore, we are not inclined to refer the matter to a
larger Bench for reconsideration.
96) It was, however, argued that since the case of Steel Authority of India Limited was not dealing
with the telecom sector, which is regulated by the statutory regulator, namely, TRAI under the TRAI
Act, that judgment would not be applicable. Merely because the present case deals with the telecom
sector would not change the nature of the order that is passed by the CCI under Section 26(1) of the
Competition Act. However, it raises another dimension. Even if the order is administrative in
nature, the question raised before the High Court in the writ petitions filed by the respondents
touched upon the very jurisdiction of the CCI. As is evident, the case set up by the respondents was
that the CCI did not have the jurisdiction to entertain any such request or Information which was
furnished by RJIL and two others. The question, thus, pertained to the jurisdiction of the CCI to
deal with such a matter and in the process the High Court was called upon to decide as to whether
the jurisdiction of the CCI is entirely excluded or to what extent the CCI can exercise its jurisdiction
in these cases when the matter could be dealt with by another regulator, namely, the TRAI. When
such jurisdictional issues arise, the writ petition would clearly be maintainable as held in Barium
Chemicals Ltd. and Another v. Company Law Board and Others18 and Carona Limited. In Carona
Limited, this Court held as under:Competition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

"26. The learned counsel for the appellant company submitted that the fact as to
“paid-up share capital” of rupees one crore or more of a company is a “jurisdictional
fact” and in absence of such fact, the court has no jurisdiction to proceed on the basis
that the Rent Act is not applicable. The learned counsel is right. The fact as to
“paid-up share capital” of a company can be said to be a “preliminary” or
“jurisdictional fact” and said fact would confer jurisdiction on the court to consider
the question whether the provisions of the Rent Act were applicable. The question,
however, is whether in the present case, the learned counsel for the appellant tenant
is right in submitting that the “jurisdictional fact” did not exist and the Rent Act was,
therefore, applicable.
18 AIR 1967 SC 295
27. Stated simply, the fact or facts upon which the jurisdiction of a court, a tribunal or
an authority depends can be said to be a “jurisdictional fact”. If the jurisdictional fact
exists, a court, tribunal or authority has jurisdiction to decide other issues. If such
fact does not exist, a court, tribunal or authority cannot act. It is also well settled that
a court or a tribunal cannot wrongly assume existence of jurisdictional fact and
proceed to decide a matter. The underlying principle is that by erroneously assuming
existence of a jurisdictional fact, a subordinate court or an inferior tribunal cannot
confer upon itself jurisdiction which it otherwise does not posses.
28. In Halsbury's Laws of England (4th Edn.), Vol. 1, Para 55, p. 61; Reissue, Vol. 1(1),
Para 68, pp. 114-15, it has been stated:
“Where the jurisdiction of a tribunal is dependent on the existence of a particular
state of affairs, that state of affairs may be described as preliminary to, or collateral to
the merits of, the issue. If, at the inception of an inquiry by an inferior tribunal, a
challenge is made to its jurisdiction, the tribunal has to make up its mind whether to
act or not and can give a ruling on the preliminary or collateral issue; but that ruling
is not conclusive.” The existence of a jurisdictional fact is thus a sine qua non or
condition precedent to the assumption of jurisdiction by a court or tribunal.
xx xx xx
36. It is thus clear that for assumption of jurisdiction by a court or a tribunal,
existence of jurisdictional fact is a condition precedent. But once such jurisdictional
fact is found to exist, the court or tribunal has power to decide adjudicatory facts or
facts in issue.”
97) Thus, even when we do not agree with the approach of the High Court in labeling
the impugned order as quasi-judicial order and assuming jurisdiction to entertain the
writ petitions on that basis, for our own and different reasons, we find that the High
Court was competent to deal with and decide the issues raised in exercise of its powerCompetition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

under Article 226 of the Constitution. The writ petitions were, therefore,
maintainable.
C. Whether the High Court could give its findings on merits?
98) Once we hold that the order under Section 26(1) of the Competition Act is administrative in
nature and further that it was merely a prima facie opinion directing the Director General to carry
the investigation, the High Court would not be competent to adjudge the validity of such an order on
merits. The observations of the High Court giving findings on merits, therefore, may not be
appropriate.
99) At the same time, since we are upholding the order of the High Court on the aspect that the CCI
could exercise jurisdiction only after proceedings under the TRAI Act had concluded/attained
finality, i.e. only after the TRAI returns its findings on the jurisdictional aspects which are
mentioned above by us, the ultimate direction given by the High Court quashing the order passed by
the CCI is not liable to be interfered with as such an exercise carried out by the CCI was premature.
The result of the discussion would be to dismiss these appeals, subject to our observations on certain
aspects. Ordered accordingly.
.............................................J. (A.K. SIKRI) .............................................J. (ASHOK BHUSHAN)
NEW DELHI;
DECEMBER 05, 2018Competition Commission Of India vs Bharti Airtel Ltd on 5 December, 2018

