Crop Care Federation Of India And Anr. vs Union Of India And
Ors. on 29 July, 2019
Author: Vibhu Bakhru
Bench: Vibhu Bakhru
$-42
*    IN THE HIGH COURT OF DELHI AT NEW DELHI
+       W.P.(C) 8117/2019 and CM Nos. 33678/2019, 33679/2019 &
        33680/2019
        CROP CARE FEDERATION OF INDIA
        AND ANR.                        ..... Petitioners
                     Through: Mr Darpan Wadhwa, Sr.
                              Advocate with Mr Ankit
                              Virmani and Ms Manasi
                              Kumar, Advocates.
                          versus
        UNION OF INDIA AND ORS.             ..... Respondents
                      Through: Mr Amit Mahajan, CGSC with
                                Mr Shoumendu Mukherji, GP
                                with Mr Arjun Dev, Advocate
                                for R-1 and R-2.
        CORAM:
        HON'BLE MR. JUSTICE VIBHU BAKHRU
                     ORDER
        %            29.07.2019
VIBHU BAKHRU, J
1. The petitioners have filed the present petition, inter alia, impugning an order dated 08.01.2019
passed by the Central Government (Appellate Authority), rejecting the appeal preferred by the
petitioners under Section 10 of the Insecticides Act, 1968 (hereafter 'the Insecticides Act'). The
petitioners had preferred the said appeal against the decision of the Registration Committee
(hereafter 'RC') taken at its 370th Meeting held on 15.10.2016, to grant registration under Section
9(3) of the Insecticides Act in respect of Chlorpropham Technical (hereafter 'Chlorpropham') to be
sourced by respondent no. 4 (Rahjans Fertilizer Limited - hereafter 'RFL') from M/s Schirm GmBH,
Germany (hereafter 'Schirm').
2. Petitioner no.1 (hereafter 'CCFI') is a company registered under Section 25 of the Companies Act,
1956. It is stated that it has at least fifty members from all sections of the Indian pesticide industry.
Petitioner no.2 (hereafter 'UPL') is a public company, inter alia, engaged in manufacture, and
distribution of pesticides. It is stated that UPL had obtained a registration under Section 9(3) of theCrop Care Federation Of India And Anr. vs Union Of India And Ors. on 29 July, 2019

Insecticides Act in respect of Chlorpropham from a specified source in United Kingdom. The said
registration was granted to UPL on 22.10.2010. Thus, concededly, UPL is a competitor of RFL,
insofar as the import of Chlorpropham is concerned.
3. It is stated that in the year 2012, RFL filed an application for registration of Chlorpropham under
Section 9(3) of the Insecticides Act. RFL sought to import the same from Schirm. At the 339 th
meeting of RC held on 29.05.2013, it was observed that RFL's application was incomplete and it was
stipulated that an incomplete application could not be placed before RC.
4. At the 344th meeting of RC, held on 30.01.2014, RC observed that bio-efficacy tests had been
conducted on an expired sample. RC also found deficiencies in the bio-efficacy studies. It noted that
the 'standard check has not been done in any of the years and any of the locations for comparison
from the original registrant. As it is case of new source, comparison was essentially required; the
years are also not consecutive'.
5. RC concluded that there were irregularities in generation of bio- efficacy data and observed that
the same may be generated again on a freshly imported sample(s) and submitted for evaluation.
6. At the 340th meeting held on 27.05.2014, RC decided to constitute a sub-committee to bring out
the facts relating to RFL's application to import Chlorpropham from a new source. The Sub-
committee constituted submitted a report, which was not favorable to RFL. The same was also
considered by RC at the 356 th meeting held on 25.06.2015 and the RC decided to refer the matter
to an expert committee. The minutes of the 357th meeting of RC held on 10.08.2015 indicate that
certain comments had been received by DAC in respect of RFL's application and the same was also
sent to the Chairman of the Sub-committee.
7. There are several allegations made by the parties. It appears from the record that the petitioners
had made complaints to RC regarding RFL's application for registration. Although neither of the
petitioners had any direct interest or locus to interfere with the application filed by RFL; they filed
complaints on more than two occasions with respect to the application submitted by RFL. RFL
alleges that the petitioners had been using their influence to ensure that RFL's application was not
processed. According to RFL, its application was complete in the year 2012 itself. The same was
scrutinized and twenty-two queries had been made by bio-efficacy experts. RFL claims that the same
were addressed and thereafter, the dossier was sent for approval. RFL also claims that its
application was also processed by the toxicity department on 31.01.2013. Apparently, at that stage,
CCFI (petitioner no.1) had filed a complaint alleging that relevant guidelines had not been followed
in RFL's case. RFL states that the said complaint also mentioned that RFL's case would be presented
at the 336th meeting to be held on 01.03.2013. RFL alleges that its case was not on the agenda of the
336 th meeting of RC. RFL claims that on 12.04.2013, bio-efficacy department had raised two
queries after RFL's file had been cleared five months earlier on 26.11.2012. It is contended that such
queries were raised at the instance of the petitioners and pursuant to the complaint made by CCFI.
8. RFL claims that it submitted the additional bio-efficacy trial data on 18.11.2013. The same was
reviewed by the bio-efficacy expert on 16.01.2014 and the deficiencies were cleared. RFL claims thatCrop Care Federation Of India And Anr. vs Union Of India And Ors. on 29 July, 2019

at that stage, CCFI filed another complaint alleging that RFL had performed bio-efficacy trials using
expired samples. RFL claims that this was a false allegation. RFL also claims that there was a serious
breach of confidentiality as the data submitted by it was not in public domain or otherwise
accessible by CCFI.
9. RFL's case was once again taken up by RC at its 344 th meeting wherein RC observed that RFL
had conducted bio-efficacy trials using expired samples.
10. RFL claims that the said observations were incorrect and the said observations were made
pursuant to misleading information which had been presented to the RC. RFL also claimed that the
internal note sheets had indicated that bio-efficacy reports submitted by RFL in November, 2013
had been found acceptable and there was no question raised as to the validity of the samples. RFL
also claimed that it has obtained the necessary note sheets pursuant to applications filed under the
Right to Information Act, 2005. RFL states that on 21.03.2014, it had filed a complaint before the
vigilance department against the bio-efficacy expert and certain manipulations in the bio- efficacy
note sheets were presented to the RC at its 339 th and 344th meetings. RFL also claims that the
directions issued by the authorities were not followed and a sub-committee was formed instead.
11. At the 360th meeting of the RC held on 11.12.2015, RC decided to issue a provisional certificate
under Section 9(3B) of the Insecticides Act by virtue of which RFL was permitted to import the said
insecticides from a new source for a period of two years.
12. The petitioners challenged the decision of the RC to issue a provisional certificate under Section
9(3B) of the Insecticides Act to RFL, by filing a writ petition being W.P.(C) 306/2016 captioned
'Crop Care Federation of India and Anr. V. Union of India and Ors.'. By an order dated 15.06.2016,
the said petition was disposed of by directing that the petition be considered as a revision petition
under Section 11 of the Insecticides Act and the same be disposed of by giving an opportunity of
hearing to the petitioners. A reading of the order indicates that this Court was persuaded to pass the
said order as it was, inter alia, pointed out that RFL had not filed any application for grant of such
registration. The petitioners had contended that in the circumstances, the grant of provisional
registration under Section 9(3B) of the Insecticides Act was without jurisdiction.
13. On 18.07.2016, the petitioners also made a representation to RC alleging various deficiencies in
the application filed by RFL.
14. In compliance with the order dated 13.01.2016, the Central Government (respondent no.2)
considered the writ petition filed by the petitioners as a revision petition under Section 11 of the
Insecticides Act and passed an order dated 15.06.2016.
15. The Central Government considered the rival contentions in some detail and framed three issues
for consideration: (a) Whether RC completed evaluation of technical submissions of RFL for
registration under Section 9(3) of the Insecticides Act (b) Whether it was lawful for RC to grant
registration to RFL under Section 9(3B) of the Insecticides Act; and (c) Whether resolution no. 2.2
of 360 th RC meeting dated 11.12.2015 is liable to be quashed on merits.Crop Care Federation Of India And Anr. vs Union Of India And Ors. on 29 July, 2019

16. With regard to the question whether RC had completed the evaluation of the technical
submissions of RFL for registration under Section 9(3) of the Insecticides Act, RFL relied on file
notings to establish that its bio-efficacy data had been examined and approved by the experts. RFL
also relied on the relevant dossier to contend that it had complied with all requirements and
provided all necessary data and the concerned experts, at one time or the other, had approved the
same. RFL contended that in this view, its application for registration had been acceded to. This was
stoutly contested by the petitioners herein.
17. The Central Government examined the files and relevant dossier including the report of the
Sub-Committee and rejected RFL's contention that in terms of the notings, its registration was
required to be granted. However, the Central Government also noted that there were various
"notings, which expose doubts and prevarications that may have arisen in the minds of experts while
carrying out the technical evaluation of RFL's application." It noted that some of the deficiencies
were dropped upon re-examination of data. In this view, the Central Government decided to remand
the matter to RC for re- consideration of the RFL's application on the basis of a fresh application of
facts and circumstances, relating to the technical submission of RFL and directed that the decision
be rendered in three months. The relevant observations of the Central Government (Revisional
Authority) in this regard, are set out below:-
"Yet, this Authority cannot but take cognizance of various documents and file notings
submitted by RFL to expose doubts and prevarications that may have arisen in the
minds of experts while carrying out technical evaluation of the application for
registration. Instances have been referred to by RFL where fresh deficiencies have
been raised after completion of the evaluation promoting the Department of
Agriculture to direct the RC not to raise objections and queries in piece-meal fashion.
As is evident from the record that some of these deficiencies were then dropped on
re-examination of data. Therefore, in my opinion it would serve the ends of justice if
the case is returned back to RC for reconsideration on the basis of a fresh application
of facts and circumstances related to the technical submissions of RFL and arrive at a
decision in these months."
18. Insofar as other issues are concerned, the Central Government held that provisional registration
under Section 9(3B) of the Insecticides Act could not be granted as the registration for the
insecticides in question had already been granted earlier to UPL. Further, it also found that there
was no application for grant of provisional registration. Consequently, the decision of the RC to
grant provisional registration under Section 9(3B) of the Insecticides Act was also set aside. The
operative directions issued by the Central Government in the order dated 15.06.2016, passed under
Section 11 of the Insecticides Act, are set out below:-
"(i) The resolution 2.2 of 360th meeting to the extent that it accords approval of
registration to RFL under section 9(3B) of the Insecticides Act, 1966 will not be given
effect to.Crop Care Federation Of India And Anr. vs Union Of India And Ors. on 29 July, 2019

(ii) The RC will reconsider the RFL application afresh taking all facts raised in this
Revision, and decide the matter through a well reasoned order in three months."
19. It is important to note that the said decision has not been challenged by the petitioners. In the
aforesaid view, the contention that no application of RFL for registration under Section 9(3) of the
Insecticides Act was pending for the RC to consider, is unmerited. The direction issued by the
Central Government clearly required the RC to reconsider the RFL's application afresh by taking all
facts, raised in the revision petition, into consideration and to decide the matter by a reasoned
order. In this view, the decision of the RC to examine the matter afresh cannot be faulted.
20. In compliance with the order dated 15.06.2016, RC once again examined the dossier and
considered RFL's case for grant of registration under Section 9(3) of the Insecticides Act. The RC
noted that communications were sent to the concerned Designated National Authority (DNA) in
Germany to verify the studies of registration / manufacturing of Chlorpropham in that country.
Inquiries were also made from the Indian Embassy, Germany. The RC took note of the response
received from DNA, Germany. RC also noted that in a communication dated 09.08.2016, it had been
explained that in an earlier communication, it was informed that the Federal Office of Consumer
Protection and Food Safety is the competent authority for authorisation of plant protection products
in Germany. However, active substances for non-authorised plant protection products can also be
manufactured and treated like other chemicals if they are in compliance with German chemicals
laws. It was also informed that Federal States of Germany are responsible for the approval of
manufacturing plants with respect to pollution control. The Indian Embassy in Germany also
verified that M/s Schirm GmBH had the approval of the authority to synthesize Chlorpropham at
the factory located at Schonebek, Germany.
21. In view of the above, RC recorded that it was convinced regarding the source of Chlorpropham in
Germany as claimed by RFL. With regard to the bio-efficacy status, RC examined the same and
concluded that the data on bio-effectiveness provided by RFL was satisfactory. The RC also
examined the data on residue of Chlorpropham in Potatoes and agreed that the residue data was
satisfactory as per guidelines. RC also examined the issue regarding bio-efficacy data generated by
using samples that had passed its shelf life and after examining the data, it concluded that
bio-efficacy data of 2013 was generated within the shelf life of the product. RC, accordingly,
concluded that the petitioner's application for approval under Section 9(3) of the Insecticides Act
was required to be accepted.
22. The petitioners did not accept the aforesaid decision and filed an appeal before the Central
Government (appellate authority) under Section 10 of the Insecticides Act, impugning the RC's
decision taken at its 370th meeting held on 15.10.2016. The Appellate Authority considered the
same and concluded that the appeal under Section 10 of the Insecticides Act was not maintainable,
as the same would lie only against "non-registration/cancellation". Nonetheless, the Appellate
Authority also examined documents and observed that source verification had been done as per
prevailing procedure of source verification. It rejected the petitioners' contention that the decision
to grant registration was taken in haste and did not hold good. The allegation regarding alleged
forgeries of certain documents were also considered and it was concluded that the same had noCrop Care Federation Of India And Anr. vs Union Of India And Ors. on 29 July, 2019

bearing or relevance to the registration procedure, which was purely scientific and technical in
nature. Accordingly, the Appellate Authority rejected the appeal preferred by the petitioners.
23. This Court finds no infirmity with the impugned orders. RC is an expert body and has satisfied
itself as to the source of the insecticides. It has also satisfied itself regarding the bio-efficacy data
provided by the RFL.
24. Sub-section (3) of Section 9 of the Insecticides Act provides for registration of an insecticide by
RC after such inquiry as it deems fit. The said sub-section is set out below:-
"9(3). On receipt of any such application for the registration of an insecticide, the
Committee may, after such enquiry as it deems fit and after satisfying itself that the
insecticide to which the application relates conforms to the claims made by the
importer or by the manufacturer, as the case may be, as regards the efficacy of the
insecticide and its safety to human beings and animals, register (on such conditions
as may be specified by it) and on payment of such fee as may be prescribed, the
insecticide, allot a registration number thereto and issue a certificate of registration
in token thereof within a period of twelve months from the date of receipt of the
application :
Provided that the Committee may, if it is unable within the said period to arrive at a
decision on the basis of the materials placed before it, extend the period by a further
period of not exceeding six months.
Provided further that if the Committee is of opinion that the precautions claimed by
the applicant as being sufficient to ensure safety to human beings or animals are not
such as can be easily observed or that notwithstanding the observance of such
precautions the use of the insecticide involves serious risk to human beings or
animals it may refuse to register the insecticide."
25. It is clear from the plain language of Sub-section (3) of Section 9 of the Insecticides Act, that RC
has the full discretion to conduct such inquiries as it deems fit for satisfying itself that the
insecticides, in relation to which application is made, conforms to the claims made by the
importer/manufacturer. Plainly, in the present case, RC has conducted the inquiries as required and
has satisfied itself as to the claims made. It is relevant to note that RC is an expert body and its
decision is not subject to judicial review on merits unless it is established that the same is perverse
or malafide. In the present case, this Court finds no reason to interfere with the RC's decision.
26. It is also relevant to note that UPL is a member of CCFI and it appears that the present petition
has been filed to further the commercial interest of UPL. UPL also holds the registration in respect
of the insecticide in question. Clearly, UPL and RFL are competitors and any delay in RFL securing
a registration under Section 9(3) of the Insecticides Act would inure to the benefit of UPL.Crop Care Federation Of India And Anr. vs Union Of India And Ors. on 29 July, 2019

27. The record shows that the petitioners have filed repeated complaints before the RC and had
interfered with the registration process. It is also alleged by RFL that their complaints were based on
some confidential data furnished by RFL. Clearly, no right of the petitioners has been infringed and
it appears that the complaints and the present petition have been filed to further the commercial
interest of UPL. Clearly, the proceedings under Article 226 of the Constitution of India cannot be
used for the said purpose.
28. In Nagar Rice & Flour Mills v. N Teekappa Gowda & Bros:
AIR 1971 SC 246, the Supreme Court while considering the validity of a sanction
order for shifting the rice mill established by the appellants, held that a person
(another rice mill owner who was a competitor of the appellants) had no locus standi
under Article 226 of the Constitution of India to challenge the grant of such sanction,
even if the same was in contravention of Section 8(3)(c) of the Rice Milling Industry
(Regulation) Act, 1958. The Court observed that "the respondents would have no
locus standi for challenging the grant of the permission, because no right vested in
the respondents was infringed."
29. The decision in Nagar Rice & Flour Mills (supra) was also followed later in the case of Mithilesh
garg v Union of India: 1992 (1) SCC 168 wherein the Apex Court, while dealing with a challenge to
the decision of the Regional Transport Authority to grant permit to new operators under the Motor
Vehicles Act, 1988 held that no right of the petitioners (existing stage-carriage operators) was
infringed on account of the grant of permit to new operators, as there was no threat of any kind to
the petitioners from any authority.
30. In Gharda Chemicals Limited v. Joint Secretary, Plant Protection and Ors.: W.P.(C) 11542/2018,
decided on 26.10.2018, this Court, following the aforementioned decisions, rejected the challenge of
the petitioner therein - an insecticides manufacturer and also a competitor of the respondents - to
the decision of the Appellate Authority to allow the respondents' applications for registration of
certain insecticides. The Court held that the petitioner did not have any vested right under Article
226 of the Constitution to claim that the respondents' applications be considered as per particular
guidelines.
31. In view of the above, the present petition is dismissed. The pending applications are also
disposed of.
VIBHU BAKHRU, J JULY 29, 2019/RKCrop Care Federation Of India And Anr. vs Union Of India And Ors. on 29 July, 2019

