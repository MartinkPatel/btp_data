Ajith @ Ajithkumar vs The Principal Secretary To Government
on 20 November, 2023
Author: M.Sundar
Bench: M.Sundar
                                                                                  HCP(MD)No.1286 of 2023
                          BEFORE THE MADURAI BENCH OF MADRAS HIGH COURT
                                                      DATED : 20.11.2023
                                                           CORAM :
                                     THE HONOURABLE MR.JUSTICE M.SUNDAR
                                                    and
                                    THE HONOURABLE MR.JUSTICE R.SAKTHIVEL
                                                   HCP(MD)No.1286 of 2023
                     Ajith @ Ajithkumar                                               ... Petitioner
                                                               vs.
                     1. The Principal Secretary to Government,
                     Home, Prohibition and Excise Department,
                     Secretariat, Chennai – 600009.
                     2. The District Magistrate and District Collector,
                     Office of the District Magistrate and District Collector,
                     Virudhunagar.
                     3. The Superintendent of Prison,
                     Madurai Central Prison,
                     Madurai District.                                                ... Respondents
                                  Petition filed under Article 226 of the Constitution of India praying
                     for issuance of a Writ of Habeas Corpus, calling for the entire records,
                     connected with the detention order of the respondent No.2 in Cr.M.P.No.
                     14/2023 (Goonda) dated 29.08.2023 and quash the same and direct the
                     respondents to produce the body or person of the detenu by name Ajith
                     @ Ajithkumar son of Arokiyaraj aged about 26 years, now detained at
                     Madurai Central Prison before this Court and set him at liberty forthwith.
                                  For Petitioner     : Mr.S.Ramesh Kumar
https://www.mhc.tn.gov.in/judis
                     Page No.1 of 9
                                                                             HCP(MD)No.1286 of 2023Ajith @ Ajithkumar vs The Principal Secretary To Government on 20 November, 2023

                                  For Respondents : Mr.A.Thiruvadi Kumar
                                                        Additional Public Prosecutor
                                                        ORDER
[Order of the Court was made by M.SUNDAR, J.] When the captioned 'Habeas Corpus Petition'
[hereinafter 'HCP' for the sake of brevity] was listed in the Admission Board on 20.10.2023, a
Hon'ble Coordinate Division Bench made the following order in the Admission Board:
https://www.mhc.tn.gov.in/judis
2. It has now become necessary to set out a thumbnail sketch of factual matrix and we
do so in the paragraphs infra.
3. Today, the captioned matter is in the Final Hearing Board.
4. Mr.S.Ramesh Kumar, learned counsel on record for petitioner and Mr.A.Thiruvadi
Kumar, learned State Additional Public Prosecutor for all respondents are before us.
5. Captioned 'Habeas Corpus Petition' [hereinafter 'HCP' for the sake of convenience
and clarity] has been filed by the detenu assailing the 'preventive detention order
dated 29.08.2023 bearing reference Cr.M.P.No.14/2023 (GOONDA)' [hereinafter
'impugned preventive detention order' for the sake of brevity and convenience]. To be
noted, sponsoring authority has not been arrayed as a respondent and we find that
Station House Officer of Virudhunagar Rural Police Station, is the sponsoring
authority [hereinafter 'sponsoring authority' for convenience and brevity] and second
respondent is the detaining authority as impugned preventive detention order has
been made by second respondent.
https://www.mhc.tn.gov.in/judis
6. Impugned detention order has been made under 'The Tamil Nadu Prevention of Dangerous
Activities of Bootleggers, Cyber law offenders, Drug-offenders, Forest-offenders, Goondas, Immoral
traffic offenders, Sand-offenders, Sexual-offenders, Slum-grabbers and Video Pirates Act, 1982
(Tamil Nadu Act No.14 of 1982)' [hereinafter 'Act 14 of 1982' for the sake of convenience and clarity]
on the premise that the detenu is a 'Goonda' within the meaning of Section 2(f) of Act 14 of 1982.
7. There are two adverse cases and one ground case. The ground case which constitutes substantial
part of substratum of the impugned preventive detention order is Crime No.123 of 2023 on the file
of Virudhunagar Rural Police Station, for alleged offence under Section 302 of 'Indian Penal Code,
1860 (Act 45 of 1860)' ['IPC' for brevity] and subsequently altered into Sections 302 and 201 of IPC.
Considering the nature of the challenge to the impugned detention order, it is not necessary to delve
into the factual matrix of the case.Ajith @ Ajithkumar vs The Principal Secretary To Government on 20 November, 2023

8. In the final hearing today, learned counsel predicated his campaign against the impugned
preventive detention order on the point https://www.mhc.tn.gov.in/judis that the detenu was
arrested on 21.06.2023 but the impugned preventive detention order has been made only on
29.08.2023 resulting in live and proximate link between grounds and purpose of detention getting
snapped.
9. Mr.Thiruvadi Kumar, learned State Additional Public Prosecutor, submits that materials had to
be collected and time was consumed in this exercise.
10. We remind ourselves of Sushanta Kumar Banik's case [Sushanta Kumar Banik Vs. State of
Tripura & others reported in 2022 LiveLaw (SC) 813 : 2022 SCC OnLine SC 1333]. To be noted,
Banik case arose under 'Prevention of Illicit Traffic in Narcotic Drugs and Psychotropic Substances
Act, 1988' [hereinafter 'PIT NDPS Act' for the sake of brevity] in Tirupura, wherein after considering
a proposal by a Sponsoring Authority and after noticing the trajectory the matter took, Hon'ble
Supreme Court held that the 'live and proximate link between grounds of detention and purpose of
detention snapping' point should be examined on a case to case basis. Hon'ble Supreme Court has
held in Banik case law that this point has two facets. One facet is 'unreasonable
https://www.mhc.tn.gov.in/judis delay' and the other facet is 'unexplained delay'. We find that the
captioned matter falls under latter facet i.e., unexplained delay.
11. To be noted, Banik case has been respectfully followed by this Court in Gomathi Vs.The Principal
Secretary to Government and others reported vide Neutral Citation of Madras High Court being
2023/MHC/334, Sadik Basha Yusuf Vs. The State of Tamil Nadu and others reported vide Neutral
Citation of Madras High Court being 2023/MHC/733, Sangeetha Vs. The Secretary to the
Government and others reported vide Neutral Citation of Madras High Court being
2023:MHC:1110, N.Anitha Vs. The Secretary to Government and others reported vide Neutral
Citation of Madras High Court being 2023:MHC:1159 and a series of similar orders in HCP cases.
12. To be noted, the first adverse case is in Crime No.37 of 2023 on the file of Virudhunagar Rural
Police Station for alleged offence under Section 379 of IPC [alleged occurrence on 18.03.2023],
second adverse case is Crime No.97 of 2023 on the file of Virudhunagar Rural Police Station for
alleged offences under Sections 341, 365, 511, 506(i) of IPC and subsequently altered into Sections
341, 365, 511, 506(i) and https://www.mhc.tn.gov.in/judis 109 of IPC [alleged occurrence on
01.06.2023], ground case is Crime No.123 of 2023 on the file of Virudhunagar Rural Police Station,
for alleged offence under Section 302 of IPC and subsequently altered into Sections 302 and 201 of
IPC [alleged occurrence on 20.06.2023] and therefore time consumed remains unexplained.
13. Before concluding, we also remind ourselves that preventive detention is not a punishment and
HCP is a high prerogative writ.
14. Ergo, the sequitur is, captioned HCP is allowed. Impugned preventive detention order dated
29.08.2023 bearing reference Cr.M.P.No.14/2023 (GOONDA) made by the second respondent is set
aside and the detenu Thiru.Ajith @ Ajithkumar, aged about 26 years, son of Thiru.Arokiyaraj, is
directed to be set at liberty forthwith, if not required in connection with any other case / cases.Ajith @ Ajithkumar vs The Principal Secretary To Government on 20 November, 2023

There shall be no order as to costs.
                                                                       (M.S., J.)   (R.S.V., J.)
                     Index                    : Yes / No                     20.11.2023
                     Neutral Citation         : Yes / No
                     bala
https://www.mhc.tn.gov.in/judis
P.S: Registry to forthwith communicate this order to Jail authorities in Central Prison, Madurai. All
concerned to act on this order being uploaded in official website of this Court without insisting on
certified copies. To be noted, this order when uploaded in official website of this Court will be
watermarked and will also have a QR code.
To
1. The Principal Secretary to Government, Home, Prohibition and Excise Department, Secretariat,
Chennai – 600009.
2. The District Magistrate and District Collector, Office of the District Magistrate and District
Collector, Virudhunagar.
3. The Superintendent of Prison, Madurai Central Prison, Madurai District.
4. The Additional Public Prosecutor, Madurai Bench of Madras High Court, Madurai.
5. The Joint Secretary to Government, Public (Law and Order) Department, Secretariat, Chennai.
https://www.mhc.tn.gov.in/judis M.SUNDAR, J.
and R.SAKTHIVEL, J.
bala ORDER MADE IN DATED : 20.11.2023 https://www.mhc.tn.gov.in/judisAjith @ Ajithkumar vs The Principal Secretary To Government on 20 November, 2023

