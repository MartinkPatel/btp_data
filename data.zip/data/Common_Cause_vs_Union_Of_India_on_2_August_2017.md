Common Cause vs Union Of India . on 2 August, 2017
Author: Madan B. Lokur
Bench: Deepak Gupta, Madan B. Lokur
                                                                                  REPORTABLE
                                              IN THE SUPREME COURT OF INDIA
                                               CIVIL ORIGINAL JURISDICTION
                                          WRIT PETITION (CIVIL) NO. 114 of 2014
                         Common Cause                                             ….Petitioner
                                                             versus
                         Union of India and Ors.                                 …Respondents
                                                             WITH
                                    WRIT PETITION (CIVIL) NO. 194 of 2014
                         Prafulla Samantra and Anr.                               ….Petitioners
                                                             versus
                         Union of India and Ors.                                 …Respondents
                                                       JUDGMENT
Madan B. Lokur, J.
1. The facts revealed during the hearing of these writ petitions filed under Article 32 of the
Constitution suggest a mining scandal of enormous proportions and one involving megabucks.
Lessees in the districts of W.P. (C) Nos. 114/2014 etc. Keonjhar, Sundergarh and Mayurbhanj in
Odisha have rapaciously mined iron ore and manganese ore, apparently destroyed the environment
and forests and perhaps caused untold misery to the tribals in the area. However, to be fair to the
lessees, they did the detail steps taken to ameliorate the hardships of the tribals, but it appears to us
that their contribution is perhaps not more than a drop in the ocean – also too little, too late. Facts
leading up to the report of the Central Empowered Committee
2. Rabi Das, the editor of a daily newspaper called Ama Rajdhani filed I.A. No. 2746-2748 of 2009 in
a pending writ petition being T.N. Godavarman v. Union of India.1 He prayed, inter alia, for the
following directions from this Court:Common Cause vs Union Of India . on 2 August, 2017

“ a) Issue a direction to the Central Empowered Committee to conduct an exhaustive
fact finding study of the illegal mining in Keonjhar, Sundargarh and other Districts of
Orissa;
b) Direct appointment of a “Commission” to investigate and study the modalities of
the illegal machinations, fix responsibility on individuals (in Government and outside
it) and recommend remedial measures to be immediately implemented by the
Government of India and the Government of Orissa;
c) Direct the Respondents to take effective and appropriate action to ensure
closure/stoppage of all the illegal mining activities in the concerned areas and direct
prosecution and punish all those found guilty of this illegal mining in violation of the
Mines and Minerals (Development and Regulation) W.P. (C) Nos. 114/2014 etc. Act,
1957, Forest (Conservation) Act, 1980 and other relevant laws.”
3. The applications were taken up for consideration on 6 th November, 2009 when notice was issued
to the Central Empowered Committee (for short ‘the CEC’) to file its report/response within six
weeks.
4. On 26th April, 2010 the CEC submitted an interim report which was noted by this Court and
taken on record. The report was of a general nature but contained quite a few recommendations.
Some of the recommendations presently relevant are as follows:
“(b) Even otherwise the Rule 24-A(6), MCR, 1960 does not authorize the lessee to
operate a mine without the statutory clearances/approvals. Therefore, in respect of a
mine covered under the ‘deemed extension’ clause, the mining operations should be
permitted to be undertaken in the non forest area of the mining lease only if (i) it has
the requisite environmental clearance; (ii) it has the consent to operate from the
State Pollution Control Board under the Air and Water Acts; (iii) Mining Plan is duly
approved by the competent authority; and (iv) the NPV for the entire forest falling
within the mining lease is deposited in the Compensatory Afforestation Fund.
The mining in the forest land included in the mining lease should be permissible only
if, in addition to the above, the approval under the FC Act/TWP has been obtained;
(c) No forest land can be leased/assigned without first obtaining the approval under
the FC Act. Therefore, the forest area approved under the FC Act should not be lesser
than the total forest area included in the mining leases approved under the MMDR
Act, 1957. Both necessarily have to be the same. In view of the above, this Hon’ble
Court while permitting grant of Temporary Working Permission to the mines in
Orissa and Goa has made it one of the pre-conditions that the NPV will be paid for
the entire forest area included in the mining W.P. (C) Nos. 114/2014 etc. leases.
Similarly, all the mining lease holders in Orissa should be directed to pay the NPV for
the entire forest area, included in the mining lease;Common Cause vs Union Of India . on 2 August, 2017

(d) In Orissa, substantial areas included in the mining leases as non forest land have
subsequently been identified as DLC forest (deemed forest/forest like areas) by the
Expert Committee constituted by the State Government pursuant to this Hon’ble
Court’s order dated 12.12.1996. While processing and/or approving the proposals
under the FC Act in many cases such areas have been treated as non-forest land.
It is recommended that (i) the NPV for the entire DLC area included in the mining lease, after
deducting the NPV already paid, should be deposited by the concerned lease holder and
(ii) the mining operations in the unbroken DLC land (virgin land) should be permissible only if the
permission under the FC Act has been obtained/is obtained for such area. Keeping in view the
peculiar circumstances as was existing in Orissa and subject to the above, the mining operations in
the broken DLC land may be allowed to be continued provided the other statutory requirements and
Rules are otherwise being complied with.” The report concluded by recording as follows:
“ a) an attempt has been made for the first time by the CEC to comply and analyse the
status of all the mining leases in a State and to suggest effective and remedial
measures - something made possible because of the unstinted cooperation extended
by the senior functionaries of the Forest and Mines Departments of the State
Government; and
b) the above recommendations if accepted and implemented will, besides ensuring
that mining is done in compliance with the statutory provisions, result in recovery of
additional amount towards the NPV etc. running into hundreds of crores of rupees. It
would be appropriate that a part of this additional amount, say 50% is used through a
SPV for undertaking specific tribal welfare and area development works so as to
ensure inclusive growth of the mineral bearing areas. The CEC proposes to file
detailed schemes in this regard for seeking permission of this Hon’ble Court provided
the State W.P. (C) Nos. 114/2014 etc. of Orissa as well as the MoEF endorse the
course of action proposed above.” The significance of the second conclusion will be
discussed by us a little later.
5. Notice was issued on the report returnable on 7th May, 2010. On the adjourned date, the
following order was passed by this Court:
“The CEC has filed its Report. The State would like to file its response. Six weeks time
is granted for the same. The recommendations of the CEC which are acceptable to the
State Government can be complied with.” It may be mentioned that some of the
recommendations made by the CEC have been accepted and implemented by the
State of Odisha.
6. The issue of mining in Odisha again came up for consideration on 16 th September, 2013 and this
Court passed the following order:Common Cause vs Union Of India . on 2 August, 2017

“We call for a report from the Central Empowered Committee within a period of six
weeks. We direct that the parties of the State Government of Odisha and the Central
Government will cooperate with the Central Empowered Committee to enquire into
the matter and furnish a report.
The matter be listed on a Monday after six weeks.”
7. With reference to the order passed on 16th September, 2013 the CEC conducted an inquiry and
some information was sought from M/s Sarda Mines Private Limited (for short ‘SMPL’). This was
objected to by SMPL W.P. (C) Nos. 114/2014 etc. who filed an application which was taken up for
consideration on 9 th December, 2013. The following order was passed on that day:
“By our order dated 16th September, 2013, we had called for a Report from the
Central Empowered Committee within a period of six weeks. It is stated on behalf of
the Central Empowered Committee that the Report could not be ready as part of the
information called for have not been furnished by the State Government.
Mr. Venugopal, learned senior counsel for the applicant M/s. Sarda Mines Private
Limited in IA No.3721 submits that since some of the matters are pending before the
High Court, a prayer has been made for not furnishing the required information to
the Central Empowered Committee.
List this matter in the second week of January, 2014.
In the meantime, the Central Empowered Committee may not submit its final
Report.”
8. The matter was again taken up on 13 th January, 2014 and this Court passed the following order:
“We have heard learned counsel for the parties.
We have also perused the letter dated 17 th October, 2013 of the Member Secretary,
Central Empowered Committee sent to the Chief Secretary, Government of Odisha
along with its annexures and in particular, the Statement of Details of information
and documents sought by Central Empowered Committee for the meeting convened
on 30th October, 2013, which cover forest and environmental issues.
We, accordingly, modify the order dated 9th December, 2013 and direct the Central
Empowered Committee to submit its final report on the queries made by the State
Government with regard to the details of the documents sought for in the letter dated
17 th October, 2013 within a period of six weeks.
W.P. (C) Nos. 114/2014 etc. The Report will not cover cases other than forest and
environmental issues.Common Cause vs Union Of India . on 2 August, 2017

The lessees and others from whom information is sought for will cooperate if they do
not cooperate the Central Empowered Committee will give its report.
A copy of the interim report of 26th April, 2010 will be furnished to the learned
counsel appearing for the State of Odisha.
This matter be listed on 20th January, 2014 for consideration of the
recommendations made by the Central Empowered Committee in the said Report
dated 26th April, 2010.” Thereafter and partly based on reports given by Justice M.B.
Shah, a retired judge of this Court, holding a commission under the Commissions of
Inquiry Act, 1952 a writ petition being W.P. (C) No. 114 of 2014 was filed by Common
Cause. Several prayers were made in the writ petition, and some of the more
significant prayers read as follows:-
“(a) Issue a writ of mandamus or any other appropriate writ directing the Union of
India and Government of Odisha to immediately stop forthwith all illegal mining in
the State of Odisha and to terminate all leases that are found to be involved in illegal
mining and mining in violation of the provisions of the Forest Conservation Act 1980,
the environment laws and other laws.
(b) Issue a writ of mandamus or any other appropriate writ directing the Union of
India and Government of Odisha to take action against all the violators involved
either directly or indirectly in illegal mining including those named in the report of
Justice Shah Commission.
(c) Issue a writ of mandamus or any other appropriate writ directing a thorough
investigation by an SIT or CBI under the supervision of this Hon’ble Court, as is
recommended by the Justice W.P. (C) Nos. 114/2014 etc. Shah Commission into
illegal mining in Odisha and collusion between private companies/individuals and
public officials of the State/Central Governments.
                   xxx             xxx            xxx
                   (e)      Issue a writ of mandamus or any other appropriate writ
directing the respondents to recover the illegally accumulated wealth through illegal
mining and related activity, as per Section 21(5) of the MMDR Act, 1957 [Mines and
Minerals (Development and Regulation) Act, 1957] and launch prosecutions under
Section 21(1) of the MMDR Act 1957, and direct that the money recovered would be
used for the welfare of local communities, tribals and villagers.”
9. The writ petition was taken up for consideration on 21 st April, 2014 when the following order was
passed:Common Cause vs Union Of India . on 2 August, 2017

“We have heard the preliminary objections with regard to the writ petition and we are
not convinced that the writ petition is not maintainable.
Issue notice.
As the State of Odisha, Union of India and the CEC have already been served with the
notices, no further notices be issued to them.
Notice, however, be issued to respondent nos. 4 and 5 returnable within four weeks.
It appears from the averments in paragraph 14 of the writ petition that several lessees
are operating without clearances under the Environment (Protection) Act, 1986 and
the Forest (Conservation) Act, 1980, and without renewal by the Government. Hence,
an interim order needs to be passed in respect of these lessees who are operating the
leases in violation of the law.
For consideration of the interim order that should be passed, only this writ petition
be listed next Monday, the 28th of April, 2014, as first item. It will be open for all
parties and intervenors/proposed intervenors to file their respective affidavits.
W.P. (C) Nos. 114/2014 etc. CEC, in the meanwhile, will make out a list of such
lessees who are operating the leases in violation of the law. This list be prepared by
the CEC without reference to the Shah Commission’s Report.
Liberty is given to the parties to produce their papers before CEC. The State of
Odisha and the Union of India will cooperate with CEC to prepare the list.” Report of
the Central Empowered Committee
10. The CEC gave its final report on 25 th April, 2014 which was considered by this Court and a
detailed interim order was passed on 16 th May, 2014.2 The sum and substance of the final report
dated 25th April, 2014 and the interim order is that in the districts of Odisha that we are concerned
with, namely, Keonjhar, Sundergarh and Mayurbhanj, the total number of leases granted for mining
iron and manganese ore are 187. Of these, 102 lease holders did not have requisite environmental
clearance (under the Environment (Protection) Act, 1986) or approval under the Forest
(Conservation) Act, 1980 or approved mining plan and/or Consent to Operate under the provisions
of the Air (Prevention and Control of Pollution) Act, 1981 or the Water (Prevention and Control of
Pollution) Act, 1981. This Court directed that mining operations in these 102 mining leases shall
remain suspended but it will be open to such lease holders to move the concerned authorities for
necessary clearances, approvals or consents and “as and when the mining lessees are able to obtain
all the 2 Common Cause v. Union of India & Ors. (2014) 14 SCC 155 W.P. (C) Nos. 114/2014 etc.
clearances/approvals/consent they may move this Court for modification of this interim order in
relation to their cases.”Common Cause vs Union Of India . on 2 August, 2017

11. This Court also found that 29 out of 187 mining leases had been determined or rejected or had
lapsed. It was directed that mining operations in these 29 mining leases will also remain suspended
but it would be open to all these concerned lessees to move the authorities for necessary relief and as
and when they get the appropriate relief, they could move this Court for modification of the interim
order.
12. This Court also found that 53 iron ore/manganese ore mining leases were operational and that
they had necessary approvals under the Forest (Conservation) Act, 1980, consent to operate granted
by the Odisha State Pollution Control Board and also approved mining plans. (There is no specific
mention about environmental clearance). In addition 3 mining leases were located in forest as well
as non-forest land, but mining operations were being conducted in non-forest areas of the mining
lease as the lease holders did not have approvals under the Forest (Conservation) Act, 1980.
Therefore a total of 56 iron ore/manganese ore mining leases were operating in the State of Odisha.
13. As far as the break-up of the 56 operational mining leases is concerned, it was found that 14
mining leases were operating on first renewal basis in W.P. (C) Nos. 114/2014 etc. accordance with
the deeming provisions of Section 8(2) of the Mines and Minerals (Development and Regulation)
Act, 1957 (for short ‘the MMDR Act’) read with Rule 24-A(6) of the Mineral Concession Rules, 1960
(for short ‘the MCR’) and 16 mining leases were operating since lease deeds for grant of renewal had
been executed in their favour. The remaining 26 mining leases were operating on second and
subsequent renewal basis with the renewal applications pending a final decision with the State
Government.
14. In respect of the 14 first renewal mining leases, this Court permitted them to continue their
operations for the time being in view of the deemed renewal provisions. This Court also permitted 16
mining leases to continue to operate since they had lease deeds executed in their favour. With regard
to the remaining 26 mining leases operating on second and subsequent renewal applications, this
Court drew attention to the decision rendered on 21 st April, 2014 in Goa Foundation v. Union of
India3 wherein it was held that the provision for a second or subsequent deemed renewal was not
available in view of Section 8(3) of the MMDR Act. Consequently, these 26 lease holders were
restrained from operating until express orders were passed by the State Government under Section
8(3) of the MMDR Act. Six months time was granted to the State Government to take a final
decision on the 3 (2014) 6 SCC 590 W.P. (C) Nos. 114/2014 etc. renewal applications. This Court left
it open to the mining lease holders to apply for modification of the interim order dated 16 th May,
2014 on obtaining necessary clearances.
15. During the hearing of these petitions, we were informed that the balance 26 mining leases are
now operational in view of the amendment to Section 8(3) of the MMDR Act with effect from 12 th
January, 2015. However, we are not aware whether these 26 mining leases have the necessary
statutory clearances.
16. We may also mention that pursuant to the liberty granted to move for modification of the
interim order of 16 th May, 2014 we have received 17 interim applications for modification. Through
a chart handed over to us in Court on 3rd May, 2017 we have been informed that in respect of two ofCommon Cause vs Union Of India . on 2 August, 2017

the 17 applications, that is, Zenith Mining (I.A. No. 45) and Kavita Agrawal (I.A. No. 47), the lease
has not been extended or has been determined and they do not have any Environmental Clearance
or Forest Clearance. In respect of J.N. Pattnaik (I.A. No. 66), there is no Forest Clearance available.
We were also informed that S.A. Karim (I.A. No.9) actually had a working lease and had wrongly
been included as a non-operational lease. W.P. (C) Nos. 114/2014 etc.
17. Be that as it may, learned counsel for the lease holders drew our attention to the record of
proceedings of 16th May, 2014 and particularly the following paragraph appearing therein:
“We have passed interim order in a separate sheet. The Central Empowered
Committee will give a final report on the Writ Petition by the end of July, 2014 and
the matter will be listed in the first week of August, 2014 before the Green Bench.”
We are mentioning this in the context of the order passed on 13 th January, 2014
adverted to above to the effect that “The Report will not cover cases other than forest
and environmental issues.”
18. In its final report, the CEC has dealt with the following ten topics:
In this final report dated the CEC dealt with the following ten topics:-
“I. Production of iron ore and manganese ore without/in excess of the environmental
clearance/Mining Plan/Consent to Operate.
II. Mining leases operated in violation of the Forest (Conservation) Act, 1980.
III. Illegal mining outside the sanctioned mining lease areas.
IV. Mining leases acquired in violation of Section 6 of the MMDR Act, 1957.
V. Violation of Rule 37 of the Mineral Concession Rules, 1960 by the lessees.
VI. Illegalities involved in the mining leases of Essel Mining & Industries Ltd.
W.P. (C) Nos. 114/2014 etc. VII. Illegalities involved in the mining lease of Sharda
Mines (P) Ltd.
VIII. Massive illegal mining in Uliburu Forest land.
IX. Inordinate delays in taking decisions by the State Government regarding renewal
of the mining leases.
X. Other issues.”Common Cause vs Union Of India . on 2 August, 2017

19. By an order dated 16th January, 2015 objections to the final report were
permitted and we have since received quite a few objections. When the matter was
taken up for consideration by this Court on 7th October, 2015 and pursuant to the
order passed on that date, the learned Amicus filed a statement dated 30th October,
2015 in a tabular form dealing with each I.A. filed in respect of the observations and
recommendations made by CEC.
Thereafter, when the matter was again taken up for consideration the learned Amicus filed a note
dated 15th March, 2016 wherein the following four issues were flagged:-
“(i) Leases lapsed under Section 4A(4) of the Mines and Minerals (Development and
Regulation) Act, 1957 (hereinafter referred to as MMDR Act, 1957) (11 leases);
(ii) Violation of Rule 24 of the Minerals (other than Atomic and Hydrocarbons
Energy Minerals) Concession Rules, 2016 (hereinafter referred to as MCR, 2016) and
Rule 37 of the Mineral Concessions Rules, 1960 (hereinafter referred to as MCR,
1960) (9 leases);
(iii) Illegal mining in forest lands (20 leases); and W.P. (C) Nos. 114/2014 etc.
(iv) Iron ore produced without/in excess of the environmental clearance (each of the
operating leases involved).”
20. Insofar as the first issue is concerned, it is common ground that that issue has
been fully, conclusively and exhaustively dealt with by this Court by a judgment and
order dated 4 th April, 2016 (Common Cause v. Union of India).4 Therefore, the first
issue does not survive for consideration by us.
21. As far as the remaining three issues are concerned, these overlap with topics I, II
and V dealt with by the CEC. Detailed submissions were made before us by learned
counsel for all the appearing parties on these issues as well as by the learned Amicus
and the learned Attorney General. We propose to deal with them in this judgment
and order.
22. We may mention that submissions were also made on topics III and IV identified
by the CEC, that is, illegal mining outside the sanctioned mining lease areas and
mining leases acquired in violation of Section 6 of the MMDR Act. We will consider
these issues as well.
23. As far as topics VI and VII identified by the CEC are concerned, we would like to
hear the parties in detail in respect of these issues.
24. No challenges or submissions were made on topics VIII, IX and X and therefore
we accept the report of the CEC on these topics.Common Cause vs Union Of India . on 2 August, 2017

4 (2016) 11 SCC 455 W.P. (C) Nos. 114/2014 etc.
25. At this stage, we may mention some rather frightening figures mentioned by the CEC in its final
report. According to the CEC, excess mining without environmental clearance or beyond what was
authorized by the environmental clearance is 2130.988 lakh MT of iron ore and 24.129 lakh MT of
manganese ore making a total of 2155.117 lakh MT of iron and manganese ore. This does not include
extraction of ore without forest clearance. These figures give an indication of the extent of excess or
illegal or unlawful mining carried out.
26. In terms of rupees, according to the CEC the total notional value of minerals produced without
an environmental clearance or in excess of the environmental clearance, at the weighted average
price of minerals as proposed by the Indian Bureau of Mines comes to about Rs.17091.24 crores for
iron ore and about Rs.484.92 crores for manganese ore making a total of Rs.17,576.16 crores. Again,
this does not include mining without forest clearance. It is for this reason that we have referred to
the megabucks and rapacious mining.
Justice M.B. Shah Commission of Inquiry
27. Apparently, and it appears quite independently of all these developments, the Central
Government issued a notification on 22 nd November, 2010 under the Commissions of Inquiry Act,
1952 whereby it W.P. (C) Nos. 114/2014 etc. appointed Justice M.B. Shah, a retired judge of this
Court to conduct an inquiry on the following Terms of Reference:
“2. (i) to inquire into and determine the nature and extent of mining and trade and
transportation, done illegally or without lawful authority, of iron ore and manganese
ore, and the losses therefrom; and to identify, as far as possible, the persons, firms,
companies and others that are engaged in such mining, trade and transportation of
iron ore and manganese ore, done illegally or without lawful authority;
(ii) to inquire into and determine the extent to which the management, regulatory
and monitoring systems have failed to deter, prevent, detect and punish offences
relating to mining, storage, transportation, trade and export of such ore, done
illegally or without lawful authority, and the persons responsible for the same;
(iii) to inquire into the tampering of official records, including records relating to
land and boundaries, to facilitate illegal mining and identify, as far as possible, the
person responsible for such tampering; and
(iv) to inquire into the overall impact of such mining, trade, transportation and
export, done illegally or without lawful authority, in terms of destruction of forest
wealth, damage to the environment, prejudice to the livelihood and other rights of
tribal people, forest dwellers and other persons in the mined areas, and the financial
losses caused to the Central and State Governments.Common Cause vs Union Of India . on 2 August, 2017

3. The Commission shall also recommend remedial measures to prevent such mining, trade,
transportation and export done illegally or without lawful authority.”
28. In the preamble to the notification appointing the Commission, it was noted that there were
reports that mining, raising, transportation and export of iron ore and manganese ore illegally or
without lawful authority was being carried on in various States in one or more of the following
forms:
W.P. (C) Nos. 114/2014 etc. “(a) mining without a licence;
(b) mining outside the lease area;
(c) undertaking mining in a lease area without taking approval of the concerned State
Government for transfer of concession;
b raising of minerals without lawful authority;
c raising of minerals without paying royalty in accordance with the quantities and grade;
d mining in contravention of a mining plan;
e transportation of raised mineral without lawful authority; f mining and transportation of raised
mineral in contravention of applicable Central and State Acts and rules thereunder; g conducting of
multiple trade transactions to obfuscate the origin and source of minerals in order to facilitate their
disposal; h tampering with land records and obliteration of inter-state boundaries with a view to
conceal mining outside lease areas; i forging or misusing valid transportation permits and using
forged transport permits and other documents to raise, transport, trade and export minerals;” It is
in the above context that the Terms of Reference were framed. 29 On 1st July, 2013 the Commission
gave the First Report on Illegal Mining of Iron and Manganese Ores in the State of Odisha. The
report contains an executive summary and very briefly the Commission stated that:
(i) All modes of illegal mining, as stated in the notification dated 22 nd November,
2010 of the Central Government are being committed in the State of Odisha; (ii)
There is a complete disregard and contempt for law and W.P. (C) Nos. 114/2014 etc.
lawful authorities on the part of many of the emerging breed of entrepreneurs; (iii) It
appears that the law has been made helpless because of its systematic non
implementation. The executive summary states that the following are discussed in
the report:
“(A) Information regarding mining leases should be placed on website to make
mining operations more transparent and to display the information for each lease on
the departmental/State website with various conditions which are required to be
adhered by the lessee.Common Cause vs Union Of India . on 2 August, 2017

(B) Misuse of Rule 24-A(6) of MCR, 1960 [Mineral Concession Rules, 1960] which
provides for deemed extension of lease.
Application for renewal of mining lease is not decided for one or other pretexts, may be, there is lack
of co-ordination among various departments which are required to decide renewal application.
There is gross misuse of deemed refusal and deemed extension of both the provisions of renewal of
leases (before 27.09.1994 and after) under Rule 24-A of MCR, 1960. This casual and negative
approach has caused dearly to State exchequer in the form of hundred crores of stamp duty and
others.
-------------
(C) Violation of the provisions of the Forest (Conservation) Act, 1980, Rules & guidelines and
directions issued by the Hon’ble Supreme Court of India.
-------------
(D) Violation of the provisions of the Environment (Protection) Act, 1986.
-------------
(E) Misuse of Rules: 10 & 12 of MCDR, 1988 [Mineral Conservation and Development Rules, 1988]
which provides for modification and review of mining plan only for a specific purpose, namely,
(i) Safe and scientific mining;
             (ii)    conservation of minerals;
             (iii)   the protection of environment; and
             (iv)    in case of modification, explanation for the same.
W.P. (C) Nos. 114/2014 etc.
                      -------------
                     (F)   Encroachment:-
On the basis of Google Image, the survey report prepared by the State Government by DGPS
method, it was found that in 82 mining leases, there was encroachment. Out of the said leases,
re-survey was ordered for 37 leases.”
30. Soon thereafter, the Commission gave its Second Report on Illegal Mining of Iron and
Manganese Ores in the State of Odisha, sometime in October, 2013. This report dealt with specific
lease holders and violations committed by them. It is not necessary for us to delve into those specific
details.
31. It was submitted before us by learned counsel for the mining lease holders that the reports given
by the Commission were not acceptable on the ground that a notice had not been given to the leaseCommon Cause vs Union Of India . on 2 August, 2017

holders under Section 8B or Section 8C of the Commissions of Inquiry Act, 1952. It was submitted
that under these circumstances the reports given by the Commission were vitiated and therefore the
foundation of the writ petition filed by Common Cause was taken away. We are not in agreement
with learned counsel for the mining lease holders.
32. The first report given by the Commission was a general, overall perspective on the subject while
the second report went into specific details of several mining lease holders - but we are not
concerned with those W.P. (C) Nos. 114/2014 etc. specifics. Therefore, whether notices were or were
not issued to the lease holders who were the subject matter of discussion in the second report is of
no consequence.
33. What we are really perturbed about is the facts stated by the Commission in the first report. So
far as this is concerned, we are of the view that no irregularity or illegality has been committed so as
to vitiate the first report. Notwithstanding this, we are not relying upon any of the facts determined
by the Commission for the purposes of our judgment and order.
34. The procedure followed by the Commission has been mentioned in Volume I Part II of the first
report, but it is not necessary for us to recount each and every detail. Suffice it to say that a resume
of the procedure followed will indicate that full opportunity was given to the lease holders to have
their say.
Resume of the procedure followed by the Commission
35. In March 2011 the Commission sent the first questionnaire to the concerned Secretary of the
Government of Odisha seeking the following information regarding each lease holder:-
                        “(i)    the name of the lessee;
                        (ii)    area of the lease;
                        (iii)   date of the execution of the lease deed;
                        (iv)    present status (renewal, mining plan, mining scheme)
                                approval date;
W.P. (C) Nos. 114/2014 etc.
                        (v)     production and export particulars from the year
                                2008-09 up to January, 2011; etc.”
36. On 20th April, 2011 the Commission sent the second questionnaire to the said concerned
Secretary seeking further information in a Form consisting of 14 questions and 4 tables.
37. Thereafter, between 24th and 26th August, 2011 the Commission issued the first notice to
various mining lessees in Odisha seeking information on affidavit as per Proforma A and B enclosed
with the notice. In Proforma A the lease holder was asked to submit details which included the
details of environment clearance, forest clearance and renewal of lease and whether the leased mine
was in operation or not. In Proforma B the lease holder was asked to submit details which includedCommon Cause vs Union Of India . on 2 August, 2017

the details of dispatch, domestic consumption and export in million tonnes of iron ore and
manganese ore from 2006-07 to 2010-11.
38. The Commission visited Odisha from 7 th December, 2011 to 14th December, 2011, from 3rd
October, 2012 to 11th October, 2012 and from 31st October, 2010 to 8th November, 2012. The
purpose of the visits was to collect information and seek explanations and gather facts from the
concerned Departments of the Government of India and the Government of Odisha. During the
visits, the Commission received as many as 140 W.P. (C) Nos. 114/2014 etc. complaints alleging
illegal mining. Accordingly, a public hearing was held in Keonjhar and Bhubaneshwar on 11th and
12th December, 2011.
39. On 21st December, 2012 and 12th January, 2013 several senior counsel were given a personal
hearing by the Commission including a personal hearing to the Federation of Indian Mining
Industries (for short ‘FIMI’). Following the submissions made, a fresh notice was issued to the lease
holders from 28th January, 2013 seeking information in Proformas A to H. In terms of the fresh
notice, the lease holder was required to verify the facts stated therein (which were collected by the
Commission) and if found incorrect then to state the correct facts. The fresh notice specifically
mentioned that:
“(i) The lessee shall come fully prepared to answer, related to this matter and submit
all related records.
(ii) Explain the production from the leased area without having approval under F(C)
Act, 1980.
(iii) Explain the production during the deemed extension period without having
approval under EIA Notification dated 27.01.1994 and amendments thereon.
(iv) Explain the excess production in violation of EIA Notification dated 27.01.1994 and
amendments thereon under the EP Act, 1986.”
40. The report mentions the various dates of hearing given to learned counsel for the lease holders,
the State of Odisha, FIMI, Federation of Indian W.P. (C) Nos. 114/2014 etc. Chambers of Commerce
and Industry (FICCI) and the Ministry of Environment and Forest of the Government of India (for
short ‘MoEF’) which are as follows:
            HEARING             DATE                           PLACE
              NO.
               1.             21.12.2012        Office of the Commission, Ahmedabad.
               2.             12.01.2013                          -do-
               3.             18.02.2013                          -do-
               4.             27.02.2013        Circuit House, Bhubaneshwar (Odisha).
               5.             28.02.2013                          -do-
               6.             01.03.2013                          -do-
               7.             02.03.2013                          -do-
               8.             04.03.2013                          -do-Common Cause vs Union Of India . on 2 August, 2017

               9.             16.03.2013        Circuit House, Annexe, Ahmedabad.
              10.             20.03.2013                          -do-
              11.             23.03.2013        Office of the Commission, Ahmedabad.
              12.             02.04.2013        Circuit House, Annexe, Ahmedabad.
              13.             03.04.2013                          -do-
              14.             04.04.2013                          -do-
              15.             12.04.2013        Office of the Commission, Ahmedabad.
              16.             13.04.2013                          -do-
              17.             21.04.2013        Gujarat University Convention Centre,
                                                Nr. Helmet Cross Road, 132 ft. Ring
                                                Road, Ahmedabad.
               18.            24.05.2013        Office of the Commission, Ahmedabad.
               19.            25.05.2013                          -do-
41. The number of learned counsel and representatives who were heard by the Commission and with
whom interactions took place are mentioned in Annexure A to Volume I of the first report. The list
of learned counsel runs into 18 pages - from page 33 to page 50 of Volume I of the first report. W.P.
(C) Nos. 114/2014 etc. Some individual lawyers appeared for several lease holders but the fact of the
matter is that everybody who wanted to be heard was given a hearing.
42. The function of the Commission as stated in the first report, at the present stage, is best
described in the words of the Commission itself. It is stated as follows:-
“The function of the Commission, at this stage, is only to inquire, assess the data
collected and to submit the report on the said basis. On that basis, some remedial
measures are suggested by the Commission for controlling illegal mining and
violation of the Acts and/or Rules. For that, there is no question of issuing notices to
the lessees.
For collecting the data and assessing it, the Principles of Natural Justice are fully
complied with, as stated above. On the basis of the data submitted by the lessees and
the submissions made by Ld. Counsel for them, the report is submitted.” It is further
clarified on page 198 of Volume I of the first report that with regard to individual
mining leases in which there is a violation of the provisions of the Forest
(Conservation) Act, 1980 and/or conditions of environmental clearance etc. a report
would be submitted later on.
43. It is therefore abundantly clear that the first report is generally a limited fact finding enquiry on
the basis of information supplied by the mining lease holders. Therefore, there is absolutely no
question of any notice being issued to any mining lease holder under Section 8B or the right of cross
examination being granted to any mining lease holder under Section 8C of the Commissions of
Inquiry Act, 1952. We are satisfied that the W.P. (C) Nos. 114/2014 etc. Commission made adequate
efforts to collect the facts and this collation in the first report was possible with the assistance of the
mining lease holders and their learned counsel and representatives as well as the government
authorities and FIMI and FICCI. Under these circumstances, no lease holder can seriously contendCommon Cause vs Union Of India . on 2 August, 2017

that the procedure adopted by the Commission in collecting facts was either irregular or not in
accordance with law. As mentioned above, any mining lease holder who wanted to be heard was
given an opportunity of being heard and was fully aware of what the Commission was attempting to
achieve and if any particular mining lease holder chose not to associate with it, it was at his or her
own peril. Lack of knowledge of the proceedings before the Commission cannot be appreciated and
we are quite satisfied that all the mining lease holders were fully aware of what was going on, if not
personally then certainly through their list of learned counsel running into 18 pages or their
representatives individually or their Federation.
44. In Goa Foundation there was a challenge to the report of the Justice Shah Commission in
respect of its conclusions pertaining to the State of Goa. This was dealt with by this Court in
paragraphs 11 to 14 of its decision. This Court declined to quash the report in view of the statement
made by the learned Advocate General of Goa. But, this Court took the W.P. (C) Nos. 114/2014 etc.
view that: “we will, however, examine the legal and environmental issues raised in the Report of
Justice Shah Commission and on the basis of our findings on these issues consider granting the
reliefs prayed for in the writ petition filed by Goa Foundation and the reliefs prayed for in the writ
petitions filed by the mining lessees, which have been transferred to this Court.”
45. In the present petitions before us, there is no challenge to the reports of the Justice Shah
Commission. However, we propose (as in Goa Foundation) to confine ourselves to some limited
facts adverted to by the CEC in its final report. We do not propose to base any of our conclusions on
the reports of the Commission.
46. Learned counsel for the petitioners insisted that the illegal or unlawful mining activity carried on
in the State of Odisha as noted by the Commission deserves to be investigated by the Central Bureau
of Investigation. Reference in this regard was made to the passage in Part III of Volume I of the first
report of the Commission to the following effect:-
“Since this is one of the biggest illegal mining ever observed by the Commission, it is
strongly felt that this is a fit case to handover to Central Bureau of Investigation, for
further investigation and follow up action.” W.P. (C) Nos. 114/2014 etc.
47. Similarly, on page 125 of Chapter II of Volume I of the report, it is stated as follows:-
“Terms of Reference No. 8 provides that “The Commission may take the services of
any investigating agency of the Central Government in order to effectively address its
terms of reference.
The Commission, therefore, suggests that Central Bureau of Investigation (C.B.I.)
may be directed to investigate into allegations of corruption made against politicians,
bureaucrats and others.” We will consider this at the appropriate stage. Suffice it to
say for the time being that the Commission made certain significant observations in
Chapter II of the report to the effect that:Common Cause vs Union Of India . on 2 August, 2017

a That the tribals in the area have been displaced or stay in pathetic and miserable
conditions in same area. There is rampant air pollution with the trees having the
colour of minerals making it clear that tribals are forced to breathe polluted air and
drink polluted water.
b Streams and ground water is polluted and there is hardly any facility of drinking
water. Women have been seen fetching water from dirty nalas.
c Mining companies and beneficiation plants are drawing water from rivers and
nearby water resources are getting depleted at a fast rate. The river Baitrani has been
seriously affected by this activity.
d Basic facilities such as medical facilities, shelter/residence, education facilities are
absent. Roads have a heavy flow of traffic and on one road of the area about 7000
trucks passed during night time.
e The labour is not being paid adequate wages beyond the minimum wages even
though the income of the mine owners runs into billions of rupees.
W.P. (C) Nos. 114/2014 etc.
48. Adverting to corruption in the area due to illegal mining activities, the Commission felt that the
Vigilance Commission was unlikely to conduct an impartial and independent enquiry for arriving at
just and proper findings because of external pressures. Accordingly, it would be more appropriate if
the Central Bureau of Investigation (CBI) conducts a detailed enquiry into all cases that have been
registered between 2008 and 2011. It was also noted that the railways have issued demand notices
to the extent of Rs.1,874 crores. The latest position with regard to these notices is not available.
49. It was also noted that notices have been issued in 146 cases to various lease holders for recovery
of mined ore as per Section 21(5) of the MMDR Act. In the Koira circle notices have been issued to
55 lessees for more than Rs. 13,000 crores; in Joda circle notices have been issued to 72 lessees for
recovery of more than Rs. 44,000 crores; in Keonjhar circle notices have been issued to 4 lessees for
recovery of about Rs. 1,065 crores; in Koraput circle notices have been issued to three lessees for the
recovery of about Rs. 44 lakhs; and in Bolangir circle notice has been issued to 1 lessee for the
recovery of about Rs.29.5 crores. In Baripada circle notices have been issued to 11 lessees for
recovery of more than Rs. 467 crores. In other words notices have been issued to the lessees for
recovery of more than Rs. W.P. (C) Nos. 114/2014 etc. 59,000 crores! (According to the CEC the
figure exceeds Rs. 61,000 crores)!!
50. We have adverted to the reports of the Commission, without relying on them, only to highlight
the gravity of the situation and nothing more. The gravity of the situation is also apparent from the
report of the CEC and the Commission seems to support it.
Initial contentionCommon Cause vs Union Of India . on 2 August, 2017

51. The initial contention urged on behalf of the respondents - lease holders was that in giving the
report dated 16th October, 2014 the CEC has exceeded its remit. In this context, reference was made
to the order of 13 th January, 2014 in which it is stated that “The Report will not cover cases other
than forest and environmental issues.”
52. We are of opinion that this objection deserves immediate rejection. The subsequent orders
passed by this Court have been completely overlooked by learned counsel inasmuch on 21st April,
2014 it was specifically noted by this Court that “CEC, in the meanwhile, will make out a list of such
lessees who are operating the leases in violation of the law.” Similarly, in the record of proceedings
of 16th May, 2014 it was noted that “The Central Empowered Committee will give a final report on
the Writ Petition by the end of July, 2014………” W.P. (C) Nos. 114/2014 etc.
53. From a reading of the orders and the proceedings that have been held in this regard from time to
time, it is quite obvious to us that the jurisdiction of the CEC was not limited and it was expected to
give a detailed report on all aspects of illegal mining or mining being carried out without any lawful
authority in whatever manner. The initial objection raised on behalf of the lease holders is therefore
rejected. Central Empowered Committee
54. The Central Empowered Committee or the CEC was first constituted by this Court by an order
dated 9th May, 2002 (T.N.Godavarman v. Union of India)5 as an interim body. Thereafter, it was
constituted by a notification dated 17th September, 2002 issued under Section 3(3) of the
Environment (Protection) Act, 1986 (for short ‘the EPA’). It has continued functioning and assisting
this Court for more than a decade and even though it has been criticized on a couple of occasions, it
is now an established body which renders extremely valuable advice to this Court and provides
factual material on the basis of which this Court can make some recommendations and pass
appropriate orders.6 5 (2013) 8 SCC 198 6 T.N. Godavarman v. Union of India, (2013) 8 SCC 198
and (2013) 8 SCC 204 W.P. (C) Nos. 114/2014 etc.
55. The details of the functioning of the CEC have been discussed by this Court in Samaj Parivartana
Samudaya v. State of Karnataka.7 In that decision, questions were raised about the credibility of the
CEC and while rejecting the submissions, it was made clear that the recommendations made by the
CEC are subject to the satisfaction of this Court. We need say nothing more except that during the
course of hearing of the present petitions, some of the conclusions arrived at by the CEC were
disputed by the petitioners and even by the learned Amicus and some were supported by learned
counsel for the mining lease holders, the learned Attorney General and the learned counsel for the
State of Odisha. It is therefore quite clear that in the present cases, the CEC as a fact finding body
has functioned impartially and it is only on the conclusions arrived at by the CEC on the basis of the
facts gathered that there can be some debate and discussion. Anyone may disagree with the views of
the CEC and there is no need to make heavy weather about this at all.
56. In so far as the report given by the CEC on 16 th October, 2014 (the final report) is concerned,
before going into the details thereof, we may mention that the CEC has stated that it held meetings
with the Chief Secretary and other senior officials of the State of Odisha and others on six 7 (2013) 8
SCC 154 W.P. (C) Nos. 114/2014 etc. dates. It also heard the lease holders and others on seven datesCommon Cause vs Union Of India . on 2 August, 2017

and it held meetings with three of the lease holders that is Jindal Steel and Power Ltd. (JSPL), Sarda
Mines Pvt. Limited (SMPL) and Essel Mining and Industries Ltd. (Essel) on 10th September, 2014.
The CEC visited the site of the mining lease of SMPL from 4th March, 2014 to 7th March, 2014 and
had site visits of a number of other lessees from 12th July, 2014 to 16th July, 2014.
57. As far as the facts collected by the CEC are concerned, there is no dispute with regard to their
correctness. The CEC has recorded that there are 187 iron ore and manganese ore mining leases in
the State of Odisha. On the basis of the material and information collected, a statement was
prepared showing lease-wise and year-wise details of production of iron ore and manganese ore,
permissible production and production without environmental clearance/beyond environmental
clearance. The details in this regard have been given as Annexure R-14 to the final report.
58. Regarding the correctness of the information, the CEC has this to say:
“24. A copy of the above said statement prepared by the CEC was made available,
through the Director, Mines and Geology, Government of Odisha and also through
the Federation of Indian Mining Industries (FIMI), to the lessees of each of the
mining leases to enable them to verify the production and other details as given in the
statement.
During the hearings held before the CEC between 5th August and 12th August, 2014 and also in the
representations filed before the CEC a large number of lessees stated that the yearwise production
details are not correctly reflected in the statement. Some of them also stated that W.P. (C) Nos.
114/2014 etc. the environment clearance details are not properly reflected in the statement.
Therefore, it was decided that (a) the State Government will reconcile the annual production and
other details with the respective lessees and (b) the copies of the environmental clearances may also
be filed before the CEC by those lessees who are disputing the environmental clearances details
provided by the State. Accordingly a meeting was convened by the Director, Mines & Geology
(DMG) with the lessees on 14th August, 2014 and during which the annual production and other
details were reconciled. The reconciled leasewise and yearwise production and other details
provided to the CEC by the State of Odisha may be seen in the statement enclosed at Annexure -
R-11 to this Report. The figures modified in the said statement, after reconciliations, are shown in
bold print.”
59. The CEC noted that the Director, Mines and Geology of the Government of Odisha had informed
the CEC that each lease holder with the exception of SMPL and JSPL agreed with the reconciled
production details. On facts, therefore, there is no dispute with regard to the contents of the report
of the CEC, although the conclusions might be disputed. Separately, the CEC has dealt with the facts
concerning SMPL and JSPL pursuant to a meeting held with them on 11th September, 2014.
Statutory provisions
60. The grant of a mining lease is governed by the provisions of the Mines and Minerals
(Development and Regulation) Act, 1957 (or the MMDR Act), the Mineral Concession Rules, 1960Common Cause vs Union Of India . on 2 August, 2017

(or the MCR) and the Mineral Conservation and Development Rules, 1988 (or the MCDR). W.P. (C)
Nos. 114/2014 etc.
61. Section 4(1) of the MMDR Act provides that no person shall undertake any mining operation in
any area except under and in accordance with the terms and conditions of a mining lease granted
under the MMDR Act and the rules made thereunder. A mining operation is defined in Section 3(d)
of the MMDR Act as meaning any operation undertaken for the purpose of winning any mineral.
Section 4(2) of the MMDR Act provides that no mining lease shall be granted otherwise than in
accordance with the provisions of the said Act and the rules made thereunder.
62. Section 5(2) of the MMDR Act provides for certain restrictions on the grant of a mining lease. It
provides that the State Government shall not grant a mining lease unless it is satisfied that the
applicant has a mining plan duly approved by the Central Government or the State Government in
respect of the concerned mine and for the development of mineral deposits in the area concerned.
63. Section 10 of the MMDR act provides for the procedure for obtaining a mining lease and
sub-section (1) thereof provides that an application is required to be made for a mining lease in
respect of any land in which the mineral vests in the government and the application shall be made
to the State Government in the prescribed form and along with the prescribed fee.
64. Section 12 of the MMDR Act requires the State Government to W.P. (C) Nos. 114/2014 etc.
maintain a set of registers. Among the registers that the State Government is required to maintain
are a register of applications for mining leases and a register of mining leases. Every such register
shall be open to inspection by any person on payment of such fee as the State Government may fix.
65. Section 13 of the MMDR Act provides for the rule making power of the Central Government in
respect of minerals. The MCR are framed in exercise of power conferred by Section 13 of the MMDR
Act.
66. Section 18 of the MMDR Act makes it the duty of the Central Government to take all such steps
as may be necessary for the conservation and systematic development of minerals in India and for
the protection of the environment by preventing or controlling any pollution which may be caused
by mining operations. The MCDR are framed in exercise of power conferred by Section 18 of the
MMDR Act.
67. The distinction between the MCR and the MCDR is that the MCR deal, inter alia¸ with the grant
of a mining lease and not commencement of mining operations. However, the MCDR deal, inter
alia¸ with the commencement of mining operations and protection of the environment by
preventing and controlling pollution which might be caused by mining operations.
W.P. (C) Nos. 114/2014 etc.
68. Section 21 of the MMDR Act deals with penalties and sub-section (1) thereof provides that
whoever contravenes the provisions of sub-section (1) or sub-section (1A) of Section 4 shall beCommon Cause vs Union Of India . on 2 August, 2017

punished with imprisonment for a term which may extend to two years or with fine which may
extend to Rs. 25,000 or with both. Sub-section (5) of Section 21 of the MMDR Act provides that
whenever any person raises without any lawful authority, any mineral from any land, the State
Government may recover from such person the minerals so raised or where such mineral has been
disposed of the price thereof. In addition thereto the State Government may also recover from such
person rent, royalty or tax, as the case may be for the period during which the land was occupied by
such person without any lawful authority. Mineral Concession Rules, 1960
69. As far as the MCR are concerned, Rule 22 is of some importance and this provides for an
application to be made for the grant of a mining lease in respect of land in which the mineral vests in
the government. An application for the grant of a mining lease is required to be made by an
applicant to the State Government in Form I to the MCR. Sub rule (5) of Rule 22 deals with a mining
plan and it requires that a mining plan shall incorporate, amongst other things, a tentative scheme
of mining and annual programme and plan for excavation for year to year for five years.
W.P. (C) Nos. 114/2014 etc.
70. Rule 22A of the MCR makes it clear that mining operations shall be undertaken only in
accordance with the duly approved mining plan. Therefore, a mining plan is of considerable
importance for a mining lease holder and is in essence sacrosanct. A mining scheme and a mining
plan are a sine qua non for the grant of a mining lease.
71. Rule 27 of the MCR deals with the conditions that every mining lease is subject to. One of the
conditions is that the lessee shall comply with the MCDR.
72. The format of a mining lease is given in Form K to the MCR and this is relatable to Rule 31 of the
MCR which provides that on an application for the grant of a mining lease, if an order has been
made for the grant of such lease, a lease deed in Form K or in a form as near thereto as
circumstances of each case may require, shall be executed within six weeks of the order, or within
such extended period as the State Government may allow.
73. Part VII of Form K deals with the covenants of the lessee/lessees. Clause 10 thereof requires the
lessee to keep records and accounts regarding production and employees etc. The lessee is required,
inter alia, to maintain a record of the quantity and quality of the mineral released from the leased
land, the prices and all other particulars of all sales of the mineral and such W.P. (C) Nos. 114/2014
etc. other facts, particulars and circumstances, as the Central Government or the State Government
may require.
74. Clause 11C is of some importance and it requires that the lessee shall take measures for the
protection of the environment like planting of trees, reclamation of land, use of pollution control
devices and such other measures as may be prescribed by the Central Government or the State
Government from time to time at the expense of the lessee.Common Cause vs Union Of India . on 2 August, 2017

75. Rule 37 of the MCR deals with the transfer of a lease and provides, inter alia, that a mining lessee
shall not without the previous consent in writing of the State Government or the Central
Government, as the case may be, assign, sublet, mortgage, or in any other manner, transfer the
mining lease, or any right, title or interest therein. The lessee shall not enter into or make any bona
fide arrangement, contract or understanding whereby the lessee will or may directly or indirectly be
financed to a substantial extent in respect of its operations or undertakings or be substantially
controlled by any person or body of persons. Sub-rule (3) of Rule 37 of the MCR enables a State
Government to determine any lease if the mining lessee has committed a breach of Rule 37 of the
MCR or has transferred any lease or any right, title or interest therein otherwise than in accordance
with sub-rule (2) of Rule 37 of the MCR.
W.P. (C) Nos. 114/2014 etc. Mineral Conservation and Development Rules, 1988
76. The MCDR promulgated under Section 18 of the MMDR Act and referred to in Rule 27 of the
MCR are also of some significance. Rule 9 of the MCDR prescribes that no person shall commence
mining operations in any area except in accordance with a mining plan approved under Clause (b) of
sub-section (2) of Section 5 of the MMDR Act.
77. The mining plan may be modified in terms of Rule 10 of the MCDR in the interest of safe and
scientific mining, conservation of minerals or for protection of the environment. However, the
application for modifications shall set forth the intended modifications and explain the reasons for
such modifications. The mining plan cannot be modified just for the asking.
78. Rule 13 of the MCDR provides that mining operations are required to be carried out by every
holder of a mining lease in accordance with the approved mining plan. If the mining operations are
not so carried out, the mining operations may be suspended by the Regional Controller of Mines in
the Indian Bureau of Mines or another authorized officer.
79. From our point of view, Chapter V of the MCDR dealing with “Environment” is of significance.
In this Chapter, Rule 31 of the MCDR provides that every holder of a mining lease shall take all
possible W.P. (C) Nos. 114/2014 etc. precautions for the protection of the environment and control
of pollution while conducting any mining operations in the area.
80. Rule 37 of the MCDR requires certain precautions to be taken against air pollution and obliges
the mining lease holder to keep air pollution under control and within permissible limits specified
under various environmental laws including the Air (Prevention and Control of Pollution) Act, 1981
and the Environment (Protection) Act, 1986.
81. Rule 38 of the MCDR requires the holder of a mining lease to take all possible precautions to
prevent or reduce the passage of toxic and objectionable liquid effluents from the mine into surface
water bodies, ground water aquifer and usable lands to a minimum. It also mandates effluents to be
suitably treated, if required, to conform to the standards laid down in this regard. In other words,
the provisions of the Water (Prevention and Control of Pollution) Act, 1974 are required to be
adhered to by the mining lease holder.Common Cause vs Union Of India . on 2 August, 2017

82. Rule 41 of the MCDR requires every holder of a mining lease to carry out mining operations in
such a manner as to cause least damage to the flora of the area and the nearby areas. Every holder of
a mining lease is required to take immediate measures for planting not less than twice the number
of trees destroyed by reason of any mining operations and to look after them W.P. (C) Nos. 114/2014
etc. during the subsistence of the lease after which these trees shall be handed over to the State
Forest Department or any other appropriate authority. The holder of a mining lease is also required
to restore, to the extent possible, other flora destroyed by the mining operations.
83. Briefly therefore, the overall purpose and objective of the MMDR Act as well as the rules framed
there under is to ensure that mining operations are carried out in a scientific manner with a high
degree of responsibility including responsibility in protecting and preserving the environment and
the flora of the area. Through this process, the holder of a mining lease is obliged to adhere to the
standards laid down under the Environment (Protection) Act, 1986 or the EPA as well as the laws
pertaining to air and water pollution and also by necessary implication, the provisions of the Forest
(Conservation) Act, 1980 (for short ‘the FC Act’). Exploitation of the natural resources is ruled out. If
the holder of a mining lease does not adhere to the provisions of the statutes or the rules or the
terms and conditions of the mining lease, that person is liable to incur penalties under Section 21 of
the MMDR Act. In addition thereto, Section 4A of the MMDR Act which provides for the
termination of a mining lease is applicable. This provides that where the Central Government, after
consultation with the State Government is of opinion that it is expedient in W.P. (C) Nos. 114/2014
etc. the interest of regulation of mines and mineral development, preservation of natural
environment, prevention of pollution, etc. then the Central Government may request the State
Government to prematurely terminate a mining lease.
Environment Impact Assessment Notification of 27th January, 1994
84. As can be seen from the statutory scheme adverted to above, protection and preservation of the
environment is a significant and integral component of a mining plan, a mining lease and mining
operations  and rightly so.
85. Keeping this in mind, an Environment Impact Assessment Notification dated 27th January,
1994 was issued by the Central Government in exercise of powers conferred by Section 3(1) and
Section 3(2)(v) of the EPA read with Rule 5(3)(d) of the Environment (Protection) Rules, 1986. The
Environment Impact Assessment Notification dated 27th January, 1994 (for short ‘EIA 1994’) is a
prohibitory notification and directs that on and from the date of its publication in the official
gazette: (i) expansion or modernization of any activity (if pollution load is to exceed the existing
one) and (ii) a new project listed in Schedule I to the notification, shall not be undertaken unless it
has been accorded environmental clearance (for short EC) by the Central Government in accordance
with the procedure specified in the notification.
W.P. (C) Nos. 114/2014 etc.
86. The notification provides, among other things, that in case of mining operations, site clearance
shall be granted for a sanctioned capacity and shall be valid for a period of five years fromCommon Cause vs Union Of India . on 2 August, 2017

commencing mining operations. What this means is that on receipt of an EC a mining lease holder
can extract a mineral only from a specified site, upto the sanctioned capacity and only for a period of
five years from the date of the grant of an EC. This is regardless of the quantum of extraction
permissible in the mining plan or the mining lease and regardless of the duration of the mining
lease. Consequently, a mining lease holder would necessarily have to obtain a fresh EC every five
years and can also apply for an increase in the sanctioned capacity. There is no concept of a
retrospective EC and its validity effectively starts only from the day it is granted. Thus, the EC takes
precedence over the mining lease or to put it conversely, the mining operations under a mining lease
are dependent on and ‘subordinate’ to the EC.
87. On 4th May, 1994 an Explanatory Note was added to EIA 1994. We are concerned with the 1st
Note which deals with the expansion and modernization of existing projects. This reads as follows:
“1. Expansion and modernization of existing projects A project proponent is required
to seek environmental clearance for a proposed expansion/modernization activity if
the resultant W.P. (C) Nos. 114/2014 etc. pollution load is to exceed the existing
levels. The words “pollution load” will in this context cover emissions, liquid effluents
and solid or semi-solid wastes generated. A project proponent may approach the
concerned State Pollution Control Board (SPCB) for certifying whether the proposed
modernization/expansion activity as listed in Schedule-I to the notification is likely to
exceed the existing pollution load or not. If it is certified that no increase is likely to
occur in the existing pollution load due to the proposed expansion or modernization,
the project proponent will not be required to seek environmental clearance, but a
copy of such certificate issued by the SPCB will have to be submitted to the Impact
Assessment Agency (IAA) for information. The IAA will however, reserve the right to
review such cases in the public interest if material facts justifying the need for such
review come to light.”
88. The Note is significant and from its bare reading it is clear that if any proposed expansion or
modernization activity results in an increase in the pollution load, then a prior EC is required. The
project proponent should approach the concerned State Pollution Control Board (for short the
SPCB) for certifying whether the proposed expansion or modernization is likely to exceed the
existing pollution load or not. If the pollution load is not likely to be exceeded, the project proponent
will not be required to seek an EC but a copy of such a certificate from the SPCB will require to be
submitted to the Impact Assessment Agency which can review the certificate.
89. What is the requirement, if any, under EIA 1994 with regard to an existing mining lease where
there is no proposal for expansion or modernization? Does such a mining lease holder require an EC
to continue W.P. (C) Nos. 114/2014 etc. mining operations? This is answered in the 8th Note which
is also of some importance and this reads as follows:
“8. Exemption for projects already initiated For projects listed in Schedule-I to the
notification in respect of which required land has been acquired and all relevant
clearances of the State Government including NOC from the respective StateCommon Cause vs Union Of India . on 2 August, 2017

Pollution Control Boards have been obtained before 27 th January, 1994, a project
proponent will not be required to seek environmental clearance from the IAA.
However those units who have not as yet commenced production will inform the
IAA.”
90. The above Note makes it clear that existing mining projects that have a no objection certificate
from the SPCB before 27 th January, 1994 will not be required to obtain an EC from the Impact
Assessment Agency. Of course, this is subject to the substantive portion of EIA 1994 and the 1 st
Note. However, if the existing mining project does not have a no objection certificate from the SPCB,
then an EC will be required under EIA 1994.
91. Two questions immediately arise from a reading of the 1 st and the 8th Note. The first question
is: What is the base year for considering the pollution load while proposing any expansion activity?
The second question is: What is the duration for which an EC is not necessary for an ongoing project
which does not propose any expansion, or to put it differently, what is the validity period for a no
objection certificate from the SPCB? W.P. (C) Nos. 114/2014 etc.
92. In our opinion, as far as the first question is concerned, a reading of EIA 1994 read with the 1st
Note implies that the base year would need to be the immediately preceding year that is 1993-94.
This is obvious from the opening sentence of the 1st Note, that is, “A project proponent is required
to seek environmental clearance for a proposed expansion/modernization activity if the resultant
pollution load is to exceed the existing levels.” (Emphasis supplied). In its report, the CEC has taken
1993-94 as the base year and we see no error in this. Even the MoEF in its circular dated 28 th
October, 2004 stated with regard to the expansion in production: “If the annual production of any
year from 1994-95 onwards exceeds the annual production of 1993-94 or its preceding years (even if
approved by IBM), it would constitute expansion.” If that expansion results in an increase in the
pollution load over the existing levels, then an EC is mandated.
93. It was contended on behalf of the mining lease holders that in terms of the circular of 28th
October, 2004 the annual production even prior to 1993-94 could be considered for ascertaining if
there was an expansion or not. We cannot accept this submission for a variety of reasons. For one,
the existing levels mentioned in the 1st Note clearly have reference to the immediately preceding
year and not to a preceding year in a comparatively remote past. Secondly, a very high annual
production in any one year is not W.P. (C) Nos. 114/2014 etc. reflective of a consistent pattern of
production – it could very well be a freak year and that freak year certainly cannot be a basic
standard or the norm to measure expansion. Then if the interpretation sought to be given is
accepted, there would be an absence of consistency and a lack of uniformity with different mining
lease holders having different base years. This is hardly conducive to good governance. Finally, EIA
1994 was intended to prevent the existing environmental load from increasing based on the existing
data of the immediate past and not data of a few years gone by. We may add that the only exception
that could be made in this regard would be if there is no production during 1993-94. In that event,
the immediately preceding year would be relevant and that is the only reasonable interpretation that
we see for the use of the words “or its preceding years”.Common Cause vs Union Of India . on 2 August, 2017

94. On the question of the duration or exemption period from an EC in respect of a project that has
commenced prior to 27th January, 1994 the substantive portion of EIA 1994 and the 8th Note grant
an exemption from the requirement of obtaining an EC if there is no expansion and the existing
pollution load is not exceeded. In any event, a no objection certificate from the SPCB is necessary for
continuing the mining operations. Consequently, even if any mining lease holder does not have an
EC or does not require an EC for continuing mining operations (but has a no objection certificate
from W.P. (C) Nos. 114/2014 etc. the SPCB), the absence of an EC would not have an adverse impact
on the mining lease holder unless of course, there was an expansion in the mining operations
without any certificate from the SPCB. In addition to this, the validity period (if any) of the
certificate from the SPCB is important – we have not been made aware whether there is such a
validity period or not.
95. The contention of learned counsel for the mining lease holders that EIA 1994 was rather vague,
uncertain and ambiguous cannot be accepted. In our opinion, on a composite reading of EIA 1994, it
is clear that: (i) A no objection certificate from the SPCB was necessary for continuing mining
operations; (ii) An expansion or modernization activity required an EC unless the pollution load was
not exceeded beyond the existing levels; (iii) The base year for determining the pollution load and
therefore the proposed expansion would be with reference to 1993-94; (iv) Whether an expansion or
modernization would lead to exceeding the existing pollution load or not would require a certificate
from the SPCB which could be reviewed by the IAA; (v) New projects require an EC; and (vi)
Existing projects do not require an EC unless there is an expansion or modernization for the
duration (if any) of the validity of the certificate from the SPCB. We need not say anything more on
this subject since the CEC has proceeded to discuss the issue of mining in excess of the EC or in
excess of the mining plan only W.P. (C) Nos. 114/2014 etc. from the year 2000-01 onwards. The
prior period may, therefore, be ignored and it is the period from 2000-01 onwards which is actually
relevant for the present discussion.
96. It was submitted by learned counsel for the mining lease holders that the MoEF had caused
some confusion with regard to the requirement of an EC at the time of renewal of a mining lease. In
this connection, reference was made to a Press Note of July 1994 and a letter dated 19 th June, 1997
of the MoEF to the Chief Conservator of Forests in the MoEF.
97. Learned counsel for the mining lease holders sought to buttress their submission that EIA 1994
was vague and ambiguous by mentioning two circulars issued by the MoEF on 5th November, 1998
and 27th December, 2000 extending the period for obtaining an EC for new units. However, these
circulars are apparently not on our record (which goes into 148 volumes) and therefore we cannot
make any comment about them. These circulars were mentioned to also contend that even for new
units the absence of an EC would not have an adverse impact on them, since the period for obtaining
an EC was extended from time to time. A reference was also made to a circular dated 14th May,
2002 which later on became the subject of consideration by this Court in M.C. Mehta v. Union of
India.8 A reading of 8 (2004) 12 SCC 118 W.P. (C) Nos. 114/2014 etc. the circular of 14th May, 2002
indicates that several units had come up in violation of EIA 1994. The MoEF had taken the view that
such units may be permitted to apply for an EC by 31st March, 1999 which was then extended to
30th June, 2001 by circulars dated 5th November, 1998 and 27th December, 2000 respectively.Common Cause vs Union Of India . on 2 August, 2017

98. By the circular dated 14 th May, 2002 the deadline for applying for an EC was extended up to
31st March, 2003 as a last and final opportunity to obtain an ex post facto EC in respect of units
which had commenced mining operations without obtaining a prior EC in violation of EIA 1994. The
circular also stated that: “Suitable directions shall be issued by all States/UTs under the
Environment (Protection) Act to units to stop construction activities/operations of all such units
that fail to apply for environmental clearance by 31st March, 2003. Units which fail to comply with
these directions shall be proceeded against forthwith under the relevant provisions of the
Environment (P) Act, 1986 without making reference to this Ministry.”
99. It was submitted that in view of these ambiguous and unclear signals emanating from the MoEF
which resulted in confusion being worse confounded, the mining lease holders were not clear
whether or not they W.P. (C) Nos. 114/2014 etc. were required to obtain an EC particularly in
respect of pre-EIA 1994 mining leases and operations.
100. As mentioned above, these dates and the text of the circulars were emphasized by learned
counsel for the lease holders to contend that it was not obligatory for the mining lease holders, who
did not expand their mining operations, to obtain an EC and in any event the period for obtaining an
EC was extended till 31st March, 2003 with ex post facto approval. In this context, reliance was
placed on M.C. Mehta referred to above.
101. We are not in agreement with the contention of learned counsel for the mining lease holders on
the interpretation given to the various circulars for the reasons given above and must also correctly
appreciate the decision of this Court in M.C. Mehta.
102. In M.C. Mehta the issue that arose for consideration was whether mining activity in the Aravalli
hills causes environmental degradation and what directions are required to be issued. While
considering this issue, this Court also considered EIA 1994 and the circular dated 14 th May, 2002.
In doing so, this Court categorically held in paragraph 37 of the Report that the intention of the
MoEF was not to legalize the continuance of mining activity without complying with the requisite
stipulations. If that were unfortunately so, then it would demonstrate a lack of sensitivity of the
MoEF to the W.P. (C) Nos. 114/2014 etc. principles of sustainable development and the object
behind issuing EIA 1994. This Court said:
“It does not appear that MOEF intended to legalise the commencement or
continuance of mining activity without compliance of stipulations of the notification.
In any case, a statutory notification cannot be notified [modified] by issue of circular.
Further, if MOEF intended to apply this circular also to mining activity commenced
and continued in violation of this notification, it would also show total non-sensitivity
of MOEF to the principles of sustainable development and the object behind the issue
of notification. The circular has no applicability to the mining activity.”
103. Adverting to the MMDR Act, this Court expressed the view in paragraph 52 of the Report that
the approval of a mining plan does not imply that a mining lease holder can commence mining
operations. The mining lease holder is nevertheless obliged to comply with statutory provisionsCommon Cause vs Union Of India . on 2 August, 2017

including the EPA and other laws. It was said:
“The grant of permission for mining and approving mining plans and the scheme by
the Ministry of Mines, Government of India by itself does not mean that mining
operation can commence. It cannot be accepted that by approving mining plan and
scheme by the Ministry of Mines, the Central Government is deemed to have
approved mining and it can commence forthwith on such approval……. A mining
leaseholder is also required to comply with other statutory provisions such as the
Environment (Protection) Act, 1986, the Air (Prevention and Control of Pollution)
Act, 1981, the Water (Prevention and Control of Pollution) Act, 1974 and the Forest
(Conservation) Act, 1980. Mere approval of the mining plan by the Government of
India, Ministry of Mines would not absolve the leaseholder from complying with the
other provisions.” W.P. (C) Nos. 114/2014 etc.
104. This Court also considered the question of the applicability of EIA 1994 to the renewal of an
existing mining lease. It was held that the said notification would apply to the renewal of a mining
lease that came up for consideration post 27th January, 1994. In other words, for the renewal of a
mining lease, an EC was required by the mining lease holder. It was held in paragraph 77 of the
Report:
“We are unable to accept the contention that the notification dated 27-1-1994 would
not apply to leases which come up for consideration for renewal after issue of the
notification. The notification mandates that the mining operation shall not be
undertaken in any part of India unless environmental clearance by the Central
Government has been accorded. The clearance under the notification is valid for a
period of five years. In none of the leases the requirements of the notification were
complied with either at the stage of initial grant of the mining lease or at the stage of
renewal. Some of the leases were fresh leases granted after issue of the notification.
Some were cases of renewal. No mining operation can commence without obtaining
environmental impact assessment in terms of the notification.”
105. It is clear from the decision rendered by this Court that EIA 1994 is mandatory in character;
that it is applicable to all mining operations –expansion of production or even increase in lease area,
modernization of the extraction process, new mining projects and renewal of mining leases. A
mining lease holder is obliged to adhere to the terms and conditions of a mining lease and the
applicable laws and the mere fact that a mining plan has been approved does not entitle a mining
lease holder to commence W.P. (C) Nos. 114/2014 etc. mining operations. In M.C. Mehta this Court
concluded that EIA 1994 is clearly applicable to the renewal of a mining lease.
106. Subsequent to the decision in M.C. Mehta two clarificatory circulars were issued by MoEF on
28th October, 2004 and 25th April, 2005. These were adverted to by learned counsel for the mining
lease holders but in our opinion they are not relevant except to the extent that they make it explicit
that following the decision of this Court in M.C. Mehta, an EC is required to be obtained before the
renewal of a mining lease and that the term ‘expansion’ would include an increase in production orCommon Cause vs Union Of India . on 2 August, 2017

the lease area or both.
107. It was submitted on behalf of the mining lease holders that the possibility of getting an ex post
facto EC was a signal to the mining lease holders that obtaining an EC was not mandatory or that if
it was not obtained, the default was retrospectively condonable. We do not agree. We have referred
to various provisions of the MMDR Act and the rules framed thereunder to indicate the statutory
importance given to the protection and preservation of the environment. This was also emphasized
in M.C. Mehta in which it was also stated that “It does not appear that MOEF intended to legalise
the commencement or continuance of mining activity without compliance of stipulations of the
notification.” It appears to us that the W.P. (C) Nos. 114/2014 etc. MoEF was, in a sense, cajoling the
mining lease holders to comply with the law and EIA 1994 rather than use the stick. That the mining
lease holders chose to misconstrue the soft implementation as a licence to not abide by the
requirements of the law is unfortunate and was an act of omission or commission by them at their
own peril. We cannot attribute insensitivity to the MoEF or even to the mining lease holders to
environment protection and preservation, but at the same time we cannot overlook the obligation of
everyone to abide by the law. That the MoEF took a soft approach cannot be an escapist excuse for
non-compliance with the law or EIA 1994. Environment Impact Assessment Notification of 14th
September, 2006
108. On 14th September, 2006 another EIA Notification was issued by the MoEF. This notification
(for short EIA 2006) required prior EC for projects or activities mentioned in the Schedule to it both
for major as well as minor minerals if the leased area is 5 hectares or more. We were informed that
several mining lease holders, in compliance with EIA 2006, applied for and were granted an EC.
109. It was submitted by learned counsel for the mining lease holders that the confusion, vagueness
and uncertainty caused by EIA 1994 and subsequent circulars and other communications did not
end with the issuance of EIA 2006. Reference was made to a circular dated 13 th October, W.P. (C)
Nos. 114/2014 etc. 2006 which deals with interim operational guidelines till 13 th September, 2007
in respect of applications made under EIA 1994. We do not see the relevance of this circular (which
really dealt with transitional issues) not only for the reason given in M.C. Mehta that circulars
cannot override statutory notifications but also because it deals with the procedure for considering
applications made under EIA 1994.
110. Reference was also made to a circular dated 2 nd July, 2007. The passage relied upon reads as
follows:-
“It is clarified that all such mining projects which did not require environmental
clearance under the EIA Notification, 1994 would continue to operate without
obtaining environmental clearance till the mining lease falls due for renewal, if there
is no increase in lease area and/or there is no enhancement of production. In the
event of any increase in lease area and or production, such projects would need to
obtain prior environmental clearance. Further, all such projects which have been
operating without any environmental clearance would obtain environmental
clearance at the time of their lease renewal even if there is no increase either in termsCommon Cause vs Union Of India . on 2 August, 2017

of lease area or production.”
111. The aforesaid circular relates to three categories that is: (i) Mining leases, where no EC was
required under EIA 1994 would continue to operate without an EC; (ii) If there was an increase in
the lease area or enhancement of production, an EC was required by the mining lease holder; (iii)
All projects would require an EC at the time of renewal of the mining lease even if there was no
increase in the lease area or enhancement of production. W.P. (C) Nos. 114/2014 etc.
112. Reference was also made to an Office Memorandum dated 19th August, 2010. However a
reading of this document brings out that it basically relates to construction at site but makes it clear
that no activity relating to any project covered under EIA 2006 including civil construction could be
undertaken without obtaining a prior EC except fencing of the site to protect it from getting
encroached and construction of temporary sheds for the guards.
113. Reference was also made to Office Memorandums dated 16th November, 2010 and 12th
December, 2012 but having gone through them we find them of little relevance as they deal with
procedural issues only.
114. All that we need to say on this subject is that there is no confusion, vagueness or uncertainty in
the application of EIA 1994 and EIA 2006 insofar as mining operations were commenced on mining
leases before 27 th January, 1994 (or even thereafter). Post EIA 2006, every mining lease holder
having a lease area of 5 hectares or more and undertaking mining operations in respect of major
minerals (with which we are concerned) was obliged to get an EC in terms of EIA 2006.
115. An attempt was then made by learned counsel for the mining lease holders to get out of the
rigours of EIA 1994 and EIA 2006 by contending W.P. (C) Nos. 114/2014 etc. that some of them had
modified the mining plan (with approval) and that therefore they had extracted iron ore or
manganese ore, as the case may be, in terms of the mining plan but not necessarily in terms of the
EC that had been obtained, if at all.
116. We have already held that a mining plan is subordinate to the EC and in M.C. Mehta it was held
by this Court that having an approved mining plan does not imply that a mining lease holder can
commence mining operations. That being so, a modified mining plan without a revised or amended
EC, is of no consequence. What the contention of learned counsel suggests to us is that under the
shield of a modified mining plan, illegal or unlawful mining in the form of mining without an EC,
mining by over-reaching EIA 1994 and EIA 2006 was being carried out.
117. The contention apart, the subterfuge of obtaining a modified mining plan to get over the adverse
effects of excess and illegal or unlawful production of iron ore or manganese ore was deprecated by
the Ministry of Mines of the Government of India. In a letter dated 29 th October, 2010 addressed to
the Controller General, Indian Bureau of Mines it was pointed out that State Governments had
expressed a concern that the Indian Bureau of Mines (IBM) had been modifying mining plans for
allowing an increase in production of ore without adequate intimation to the State Governments.
W.P. (C) Nos. 114/2014 etc. A concern was raised that such a revision was often being used toCommon Cause vs Union Of India . on 2 August, 2017

increase production of ore, which is sometimes not accounted for in mining operations in the
concerned mining lease. It was made clear that all modifications of mining plans shall be effective
prospectively only and earlier instances of irregular mining shall not be regularized through a
modification of the mining plan.
118. In a subsequent letter dated 12 th December, 2011 addressed to the Chief Secretary in the
Government of Orissa the said Ministry of Mines noted that there were violations of the actual
production limit laid down in the mining plan and that the State Government had finally taken steps
to curb illegal mining in respect of over-production of minerals. There was a reference to suggest
(and we take it to be so) that 20% deviation from the mining plan (in terms of over-production)
would be reasonable and permissible. However, it appears from a reading of the communication
that illegal mining was going on beyond the 20% deviation limit and that appropriate steps were
needed to curb these violations. Learned counsel for the petitioners submitted that such egregious
violations must be firmly dealt with by cancellation or termination of the mining lease and a soft
approach is not called for.
W.P. (C) Nos. 114/2014 etc.
119. In this context, it is worth noting that a High Level Committee (called the Hoda Committee) on
the National Mineral Policy noted in its Report dated 22nd December, 2006 in paragraph 3.47 as
follows :
“3.47 An EMP [Environment Management Plan] has to be prepared under the MCDR
and got approved by IBM. However, this EMP is not acceptable to the MoEF. The
miner has to prepare two EMPs separately  one for IBM and another for MoEF.
The Committee suggests that IBM and MoEF should prepare guidelines for a
composite EMP so that IBM can approve the same in consultation with MoEF’s field
offices. This will eliminate anomalous situations where increase of even a few tonnes
in production requires project authorities to get a fresh EMP approved from the
MoEF although the IBM allows a grace of +10% per cent, keeping in view the
fluctuations in the market situation and process complexities. If a single EMP is
accepted in principle such anomalies can be resolved in advance. The Committee
feels the MoEF should also have a cushion of +10% per cent in production while
giving EIA clearance.”
120. The above passage indicates that the permissible variation in production as per the Indian
Bureau of Mines is +10% but according to the letter dated 12th December, 2011 issued by the
Ministry of Mines, the reasonable variation limit could be +20%. It is not clear why there was a shift
in the variation, but as rightly pointed out by learned counsel for the petitioners, the fact that in
some cases the variation exceeded 20% was a cause for concern which necessitated strict and
punitive action.
121. A submission was made by learned counsel for the mining lease holders to the effect that since
many of them had been granted the first W.P. (C) Nos. 114/2014 etc. deemed statutory renewal ofCommon Cause vs Union Of India . on 2 August, 2017

the mining lease under Rule 24A of the MCR, the requirements of EIA 1994 would not be applicable.
We were shown various amendments made to Rule 24A of the MCR from time to time particularly
the amendments made on 10th February, 1987, 7th January 1993, 27th September, 1994, 17th
January, 2000, 18th July, 2014 and 8th October, 2014. In our opinion, none of these are of any
consequence, the reason being that for the purposes of renewal of the mining lease, an application is
required to be made by the mining lease holders and the deemed renewal clause under Rule 24A of
the MCR will come into operation only after an application for renewal is made in Form J in
Schedule I of the MCR. Under Rule 26 of the MCR, the State Government may refuse to renew the
mining lease. That apart, the position in environmental jurisprudence with regard to the renewal of
a mining lease has been made explicit by this Court in M.C. Mehta. Even otherwise, in view of EIA
1994, it is quite clear that the renewal of a mining lease would require a prior EC.
122. We may also draw attention in this regard to a circular dated 28 th October, 2004 issued by the
MoEF wherein it was stated that in view of the decision in M.C. Mehta all mining projects of major
minerals of more than 5 hectares lease area that had not yet obtained an EC would have to do so at
the time of renewal of the lease.
W.P. (C) Nos. 114/2014 etc.
123. Finally, it was submitted that whenever an EC is granted, it would have retrospective effect
from the date of the application for grant of an EC. In this context, it was pointed out that there were
enormous delays in granting an EC and that the Hoda Committee had noted with reference to EIA
2006 that if all goes well, the grant of an EC takes about 232 days whereas the international norm is
that an EC is granted within six months or 180 days. According to the additional affidavit filed by
some mining lease holders, the period of 232 days mentioned by the Hoda Committee was actually a
conservative estimate and that in fact it takes anything upto 390 days for the grant of an EC. It was
submitted that the position was even worse under EIA 1994 since the MoEF rarely showed any
urgency in the grant of an EC. Examples were cited before us to show that in some instances the
grant of an EC took more than two years. Taking all this into consideration it was submitted that it
would be more appropriate that the EC is given retrospective effect from the date of the application.
124. We are not in agreement with learned counsel for the mining lease holders. There is no doubt
that the grant of an EC cannot be taken as a mechanical exercise. It can only be granted after due
diligence and reasonable care since damage to the environment can have a long term impact. EIA
1994 is therefore very clear that if expansion or modernization W.P. (C) Nos. 114/2014 etc. of any
mining activity exceeds the existing pollution load, a prior EC is necessary and as already held by
this Court in M. C. Mehta even for the renewal of a mining lease where there is no expansion or
modernization of any activity, a prior EC is necessary. Such importance having been given to an EC,
the grant of an ex post facto environmental clearance would be detrimental to the environment and
could lead to irreparable degradation of the environment. The concept of an ex post facto or a
retrospective EC is completely alien to environmental jurisprudence including EIA 1994 and EIA
2006. We make it clear that an EC will come into force not earlier than the date of its grant.
Illegal MiningCommon Cause vs Union Of India . on 2 August, 2017

125. A question raised by learned counsel for the mining lease holders concerned the interpretation
of the expression ‘illegal mining’. Reliance was placed on the report of the CEC which refers to Rule
2(iia) of the MCR to conclude that the violation of any rule within the mining lease area would not
come within the definition of ‘illegal mining’ except where there has been a violation of the rules
framed under Section 23C of the MMDR Act. According to the CEC:
“17. Illegal mining has been defined as mining operations undertaken by any person
in any area without holding a mining lease. It does not include violation of any rules
within the mining lease area except the Rules made under Section 23C of the MMDR
W.P. (C) Nos. 114/2014 etc. Act, 1957. The mining lease area shall be considered as an
area held with lawful authority by the lessee (refer Rule 2(iia), MCR, 1960).”
126. As can be seen from the above, there is a difference of opinion between the CEC and the
Commission on what is illegal mining or mining without lawful authority and we will give our views
on the subject.
127. According to the lessees a mining operation only outside the mining lease area would constitute
‘illegal mining’ making illegal mining lease centric. We are unable to accept this narrow
interpretation given by the CEC and relied upon by learned counsel for the mining lease holders.
128. The simple reason for not accepting this interpretation is that Rule 2(ii
a) of the MCR was inserted by a notification dated 26 th July, 2012 while we are concerned with an
earlier period. That apart, as mentioned above, the holder of a mining lease is required to adhere to
the terms of the mining scheme, the mining plan and the mining lease as well as the statutes such as
the EPA, the FCA, the Water (Prevention and Control of Pollution) Act, 1974 and the Air (Prevention
and Control of Pollution) Act, 1981. If any mining operation is conducted in violation of any of these
requirements, then that mining operation is illegal or unlawful. Any extraction of a mineral through
an illegal or unlawful mining operation would become illegally or unlawfully extracted mineral.
W.P. (C) Nos. 114/2014 etc.
129. It is not, as suggested by learned counsel, that illegal mining is confined only to mining
operations outside a leased area. Such an activity is obviously illegal or unlawful mining. Illegal
mining takes within its fold excess extraction of a mineral over the permissible limit even within the
mining lease area which is held under lawful authority, if that excess extraction is contrary to the
mining scheme, the mining plan, the mining lease or a statutory requirement. Even otherwise, it is
not possible for us to accept the narrow interpretation sought to be canvassed by learned counsel for
the mining lease holders particularly since we are dealing with a natural resource which is intended
for the benefit of everyone and not only for the benefit of the mining lease holders.
EncroachmentsCommon Cause vs Union Of India . on 2 August, 2017

130. Section 4(1) of the MMDR Act makes it clear that no person can carry out any mining
operations except under and in accordance with the terms and conditions of a mining lease granted
under the MMDR Act and the rules made thereunder. Obviously therefore, any person carrying on
mining operations without a mining lease, is indulging in illegal or unlawful mining. This would also
necessarily imply that if a mining lease is granted to a person who carries out mining operations
outside the boundaries of the W.P. (C) Nos. 114/2014 etc. mining lease, the mineral extracted would
be the result of illegal or unlawful mining.
131. In its report, the CEC has dealt with illegal mining outside the sanctioned mining areas. It is
stated that 82 mining leases for iron ore and manganese ore were identified by the Commission
where there were encroachments in the form of illegal mining pits, illegal over-burden dumps etc.
132. In respect of these 82 mining leases, the State of Odisha appointed a Committee on the
suggestion of the Commission, to survey and identify the exact extent and location of the sanctioned
lease area, lease area under occupation of the mining lease holder and the area under
encroachment/illegal mining. The Committee or the Joint Survey consisted of officers of the
Revenue Department, Forest Department and Mining Department of the State of Odisha who
carried out a field survey in respect of 39 mining leases. The findings of the field survey or the Joint
Survey were verified by a team comprising of the Director Mines, Chief Engineer, ORSAC and the
Additional Secretary, F & E Department of the Government of Odisha.
133. It is mentioned in the report of the CEC that the Joint Survey for each of the 39 mining leases is
technically sound and reliable. However, in W.P. (C) Nos. 114/2014 etc. respect of some of the
leases, it would be desirable for the State Government to take another look at the results of the field
survey. Unfortunately, the CEC has not identified these mining leases that require another look. Be
that as it may, the fact is that a joint survey has not been conducted in respect of 43 mining leases.
134. We are of the view that for completing the record and taking the report of the CEC to its logical
conclusion, it would be appropriate if a fresh Joint Survey is conducted by concerned officers of the
Government of Odisha from the Revenue Department, the Forest Department, the Mining
Department and any other department that may be deemed necessary. The Forest Survey of India,
the MoEF, the Indian Bureau of Mines and the Geological Survey of India should also be associated
in the Joint Survey. In our opinion, it would also be appropriate if the CEC is also associated in the
Joint Survey and the best and latest technology should be made use of including satellite imagery
and thereafter a report is submitted in this Court on or before 31st December, 2017 after hearing the
82 lessees identified by the Commission.
Adherence to the mining plan
135. A side issue raised by learned counsel for the mining lease holders in this regard was the
necessity (if any) of adhering to the annual plan or W.P. (C) Nos. 114/2014 etc. calendar plan of
mining. It was contended that a mining lease holder could mine in excess of the annual plan. While
it is so, this submission must be tempered and appreciated in the proper context. A mining plan is
valid for a period of five years but there could be a 20% variation in extraction over and above theCommon Cause vs Union Of India . on 2 August, 2017

mining plan. This is the maximum that is stated to be reasonably permissible according to the
Ministry of Mines. In terms of Rule 22(5) of the MCR a mining plan shall incorporate a tentative
scheme of mining and annual program and plan for excavation from year to year for five years. At
best, there could be a variation in extraction of 20% in each given year but this would be subject to
the overall mining plan limit of a variation of 20% over five years. What this means is that a mining
lease holder cannot extract the five year quantity (with a variation of 20%) in one or two years only.
The extraction has to be staggered and continued over a period of five years. If any other
interpretation is given, it would lead to an absurd situation where a mining lease holder could
extract the entire permissible quantity under the mining plan plus 20% in one year and extract
miniscule amounts over the remaining four years, and this could be done without any reference to
the EC. The submission of learned counsel in this regard simply cannot be accepted.
W.P. (C) Nos. 114/2014 etc.
136. In the letter dated 12th December, 2011 sent by the Secretary in the Ministry of Mines of the
Government of India to the Chief Secretary of the Government of Odisha (adverted to above)
concerning violation of annual production limit laid down in the approved mining plan, it was
stated, inter alia, that an analysis of production and violations in 104 mining leases for bulk
minerals in the last ten years was undertaken by the Indian Bureau of Mines. It was noted that in 71
cases there was excess ore produced beyond the reasonable variation limit of 20%. It was noted that
this was partly due to the failure of the State machinery to restrict the movement of minerals.
137. In a further letter dated 5th September, 2012 it was reiterated that any violation of the mining
plan or the mining scheme noticed by the State Government should be immediately brought to the
notice of the Indian Bureau of Mines to initiate suitable action. It was reiterated that transit passes
to such mines should not be issued by the State Government so as to stop any additional outgo. It
was added: “Needless to say any revision on the limits of production is subjected to statutory
clearances under Environment and Forest laws. Having said that, the State Mining and Geology
officials should not also lose focus on taking stringent action against any instances of illegal mining,
undertaken outside the leased area, and passed off as excess production.” It is quite clear from the
W.P. (C) Nos. 114/2014 etc. correspondence placed before us that as far as the Union of India is
concerned, any violation of the requirements of the law has to be firmly dealt with.
138. With reference to the interpretation of Section 21(5) of the MMDR Act (which we shall soon
consider) it was stated as follows:
“Section 21(5) of MMDR Act is clearly applicable on such land which is occupied
without lawful authority. It is clarified that in the context of MMDR Act, 1957,
violations pertaining to mining operations within the mining lease area are to be
dealt with only in terms of the provisions of the Mineral Conservation and
Development Rules 1988. The State Governments have clear powers to tackle any
offences related to mining outside the mining lease area in terms of Section 23C of
the MMDR Act, 1957. However, the interpretation that a land granted under a Mining
lease by the State Government can be held to be occupied without lawful authority onCommon Cause vs Union Of India . on 2 August, 2017

the grounds of violation of provisions of any other law of the land is not appropriate
and such interpretation may not stand in the Court of law. Such Act or Rules,
including the Environment (Protection) Act, 1986, or the Forest (Conservation) Act,
1980, etc. clearly provide penalties for violations under those laws. This aspect may
be clarified to the State Accountant General also.”
139. All that we need say for the present is that the interpretation given in the aforesaid letter to
Section 21(5) of the MMDR Act is not fully correct. While mining in excess of permissible limits
under the mining plan or the EC or FC on leased area may not amount to mining on land occupied
without lawful authority, it would certainly amount to illegal or unlawful mining or mining without
authority of law.
W.P. (C) Nos. 114/2014 etc. Section 21 of the MMDR Act
140. The discussion on illegal or unlawful mining takes us to the question of the consequence of
illegal or unlawful mining and the interpretation of Section 21(1) and Section 21(5) of the MMDR
Act.
141. Section 21(1) of the MMDR Act is clearly relatable to a penal offence and applies if any one
contravenes the provisions of Section 4(1) of the MMDR Act. Section 4(1) of the MMDR Act
prohibits the undertaking of any mining operation in any area except under and in accordance with
the terms and conditions of a mining lease and the rules made thereunder. Therefore, when a
person carries out a mining operation in any area other than a leased area or violates the terms of a
mining lease, which incorporates the mining plan and which requires adherence to the law of the
land, that person becomes liable for prosecution under Section 21(1) of the MMDR Act. In the event
of a conviction, he or she shall be punishable with imprisonment for a term which may extend to five
years and with fine which may extend to Rs.5 lakh per hectare of the area.
142. As far as Section 21(5) of the MMDR Act is concerned, according to the CEC the provision is
applicable only if a person indulges in illegal mining outside the mining lease area. Consequently,
Section 21(5) of the MMDR Act is not attracted even if the mineral raised within the mining W.P. (C)
Nos. 114/2014 etc. lease area is without an EC or beyond the quantity prescribed by the EC or
beyond the quantity permitted in the mining plan. In such a situation, the provisions of the EPA or
the MCR come into play. This interpretation is supported by learned counsel for the mining lease
holders who affirm that Section 21(5) of the MMDR Act is mining lease area centric. In other words,
according to the CEC and the learned counsel, for the purposes of Section 21(5) of the MMDR Act
illegal mining is mining outside the mining lease area and Section 21(5) of the MMDR Act has to be
understood in that light.
143. Reference was also made to the Explanation to Rule 2(iia) of the MCR where it is stated that for
the purposes of this clause, the violation of any rules, other than the rules made under section 23C
of the MMDR Act, within the mining lease area by a holder of a mining lease shall not include illegal
mining. In other words, it was submitted that Section 21(5) of the MMDR Act is required to be
understood in the context of Rule 2(iia) of the MCR.Common Cause vs Union Of India . on 2 August, 2017

144. It was submitted by Shri Ashok Desai learned senior counsel for one of the intervenors, that the
penalty postulated by Section 21(5) of the MMDR Act though an imposition of a pecuniary liability,
is punishment for the commission of an offence. By referring to Khemka & Co. (Agencies) W.P. (C)
Nos. 114/2014 etc. Pvt. Ltd. v. State of Maharashtra 9 it was contended that the liability sought to be
imposed by Section 21(5) of the MMDR Act is not a liability that is created by a clear, unambiguous
and express enactment.
145. As far as the Union of India is concerned, in its affidavit filed on 20 th January, 2017 by Shri
Sudhakar Shukla, Economic Advisor in the Government of India, Ministry of Mines, it is submitted
(and this submission is supported by the learned Attorney General in his oral submissions) that
Section 21(5) of the MMDR Act is in two parts. The first part refers to the raising of minerals without
any lawful authority from any land. The second part is in addition to what is recoverable under the
first part. The addition is to the effect that when a person raises a mineral from any area not in his or
her lawful authority, that person is also liable to pay the rent, royalty or tax for the period during
which the land was occupied without lawful authority.
146. It is further submitted that ‘illegal mining’ as defined in Rule 2(iia) of the MCR is also required
to be read in the context of Rule 26(4) and Rule 27(4A) of the MCR which deal with the refusal to
renew a mining lease if the mining lease holder is convicted of illegal mining and the determination
of a mining lease in the event the mining lease holder is convicted of illegal mining. It is submitted
that the definition of illegal mining in the MCR must 9 (1975) 2 SCC 22 W.P. (C) Nos. 114/2014 etc.
be strictly construed and limited to the provisions of the MCR and cannot apply to the provisions of
Section 21(5) of the MMDR Act.
147. In conclusion, it is reiterated by the Union of India on affidavit as follows:
“55. That considering all the above, the Ministry would like to submit that the
provisions of sub-section (5) of Section 21 would apply to all minerals raised without
any lawful authority, be it forest clearances or environment clearances or any other
such legal requirements.
56. That penalties would arise under section 21(5) of the MMDR Act, 1957, in respect
of any form of mining activity without lawful authority. Mining outside lease area
would on the face of it amount to mining without lawful authority and would attract
the provisions of section 21(5); and, in addition, all forms of mining without lawful
authority including that in breach of the limits imposed by the Environmental
Clearance carried out within the lease area would also invite penalties under section
21 (5).” (Emphasis given by us).
148. On behalf of the State of Odisha, it was submitted by Shri Rakesh Dwivedi learned senior
counsel by relying upon Karnataka Rare Earth v. Senior Geologist, Department of Mines &
Geology10 that what is sought to be achieved by Section 21(5) of the MMDR Act is to recover the
price of the mineral that has been illegally or unlawfully or unauthorisedly raised with an intention
to compensate the State for the loss of the mineral owned by it, the loss having been caused by aCommon Cause vs Union Of India . on 2 August, 2017

person who is not authorized by law to raise that mineral. There is no element of penalty involved in
this and the 10 (2004) 2 SCC 783 W.P. (C) Nos. 114/2014 etc. recovery of the mineral or its price is
not a penal action but is merely compensatory. This is what this Court had to say in Karnataka Rare
Earth:
“12. Is the sub-section (5) of Section 21 a penal enactment? Can the demand of
mineral or its price thereunder be called a penal action or levy of penalty?
13. A penal statute or penal law is a law that defines an offence and prescribes its
corresponding fine, penalty or punishment. (Black’s Law Dictionary, 7th Edn., p.
1421.) Penalty is a liability composed (sic imposed) as a punishment on the party
committing the breach.
The very use of the term “penal” is suggestive of punishment and may also include any extraordinary
liability to which the law subjects a wrongdoer in favour of the person wronged, not limited to the
damages suffered. (See Aiyar, P. Ramanatha: The Law Lexicon, 2nd Edn., p. 1431.)
14. In support of the submission that the demand for the price of mineral raised and exported is in
the nature of penalty, the learned counsel for the appellants has relied on the marginal note of
Section
21. According to Justice Singh, G.P.: Principles of Statutory Interpretation (8th Edn., 2001, at p.
147), though the opinion is not uniform but the weight of authority is in favour of the view that the
marginal note appended to a section cannot be used for construing the section. There is no
justification for restricting the section by the marginal note nor does the marginal note control the
meaning of the body of the section if the language employed therein is clear and spells out its own
meaning. In Director of Public Prosecutions v. Schildkamp11 Lord Reid opined that a sidenote is a
poor guide to the scope of a section for it can do no more than indicate the main subject with which
the section deals and Lord Upjohn opined that a sidenote being a brief précis of the section forms a
most unsure guide to the construction of the enacting section and very rarely it might throw some
light on the intentions of Parliament just as a punctuation mark.
15. We are clearly of the opinion that the marginal note “penalties” cannot be pressed into service for
giving such colour to the meaning 11 (1969) 3 All ER 1640 : (1970) 2 WLR 279 (HL) W.P. (C) Nos.
114/2014 etc. of sub-section (5) as it cannot have in law. The recovery of price of the mineral is
intended to compensate the State for the loss of the mineral owned by it and caused by a person who
has been held to be not entitled in law to raise the same. There is no element of penalty involved and
the recovery of price is not a penal action. It is just compensatory.”
149. We are in agreement with the view expressed by the learned Attorney General and Shri Dwivedi
as also the view expressed in Karnataka Rare Earth. The decision in Khemka & Co. is not at all
apposite. There is no ambiguity in Section 21(5) of the MMDR Act or in its application. We are also
of opinion that though Section 21(1) of the MMDR Act might be in the realm of criminal liability,
Section 21(5) of the MMDR Act is certainly not within that realm.Common Cause vs Union Of India . on 2 August, 2017

150. In our opinion, Section 21(5) of the MMDR Act is applicable when any person raises, without
any lawful authority, any mineral from any land. In that event, the State Government is entitled to
recover from such person the mineral so raised or where the mineral has already been disposed of,
the price thereof as compensation. The words ‘any land’ are not confined to the mining lease area.
As far as the mining lease area is concerned, extraction of a mineral over and above what is
permissible under the mining plan or under the EC undoubtedly attracts the provisions of Section
21(5) of the MMDR Act being extraction without lawful authority. It would also attract Section 21(1)
of the MMDR Act. In any event, Section 21(5) of the Act is certainly W.P. (C) Nos. 114/2014 etc.
attracted and is not limited to a violation committed by a person only outside the mining lease area
– it includes a violation committed even within the mining lease area. This is also because the
MMDR Act is intended, among other things, to penalize illegal or unlawful mining on any land
including mining lease land and also preserve and protect the environment. Action under the EPA
or the MCR could be the primary action required to be taken with reference to the MCR and Rule
2(ii a) thereof read with the Explanation but that cannot preclude compensation to the State under
Section 21(5) of the MMDR Act. The MCR cannot be read to govern the MMDR Act.
151. What is the significance of this discussion? It was submitted that the CEC has taken the
following view:
“…… it may be appropriate that 30% of the notional value of the iron and manganese
produced by each of the lessees without/in excess of the environmental clearances
may be directed to be recovered from the concerned lessees and with the explicit
understanding the concerned lessees as well as the officers will continue to be liable
for action under the provisions of the respective Acts.”
152. Learned counsel for the petitioners and the learned Amicus were of opinion that the provisions
of Section 21(5) of the MMDR Act require that the entire price of the illegally mined ore should be
recovered from each defaulting lessee. Similarly, in its affidavit, the Union of India differs with the
recommendation of the CEC. According to the affidavit of the Union of W.P. (C) Nos. 114/2014 etc.
India this would be contrary to the statutory scheme and in fact 100% recovery should be made
under the provisions of Section 21(5) of the MMDR. We may note that only to this extent, the
learned Attorney General differed with the view expressed by the Union of India and submitted that
the recommendation of the CEC to recover only 30% of the value of the illegally mined ore should be
accepted.
153. In our opinion, there can be no compromise on the quantum of compensation that should be
recovered from any defaulting lessee – it should be 100%. If there has been illegal mining, the
defaulting lessee must bear the consequences of the illegality and not be benefited by pocketing 70%
of the illegally mined ore. It simply does not stand to reason why the State should be compelled to
forego what is its due from the exploitation of a natural resource and on the contrary be a party in
filling the coffers of defaulting lessees in an ill gotten manner.
Calculations on meritsCommon Cause vs Union Of India . on 2 August, 2017

154. The issue now is with regard to the calculations made by the CEC with regard to the production
of iron ore and manganese ore without or in excess of the EC and/or the mining plan. As already
mentioned above, the figures were not disputed (except by JSPL and SMPL). Therefore, only the
application of the figures requires consideration and so we do not need to W.P. (C) Nos. 114/2014
etc. examine each individual case. However to understand and appreciate the manner in which the
CEC has arrived at its figures, we may state that this has been specifically mentioned by the CEC in
its report. The basis of the calculations is as follows:
“(a) the production during the year 1993-94 has been considered as the permissible
production during each year till the mining lease did not have the environmental
clearance;
(b) the permissible production for the year in which the environmental clearance was
obtained for the first time has been considered on pro rata basis of (a) the prescribed
annual production and (b) the date of the grant of the environmental clearance. For
this purpose the environmental clearance granted on or before 15th of a month has
been considered valid for the entire month. Where the environmental clearance has
been granted after 15th of a month it has been considered valid from the subsequent
month. For example if the environmental clearance for a mining lease has been
granted say on 10th October, 2008 for an annual production of say 12 lakh MT then
in that case the permissible production for the mining lease for the year 2008-09
would be taken as 6 lakh MT (12x6/12 lakh MT) and 12 lakh MT per annum in the
subsequent year; and
(c) wherever a mining lease having environmental clearance has been granted revised
environmental clearance for a higher production the permissible annual production
for the year, during which the revised environmental clearance has been granted, has
been considered on pro rata basis of the quantities prescribed in the earlier
environmental clearance and the revised environmental clearance. For example if the
mining lease was having environmental clearance for annual production of 12 lakh
MT and say on 28 th September, 2009 it has been granted revised environmental
clearance for annual production of say 24 lakh MT then in that case the permissible
production for the year 2009-10 would be taken as 18 lakh MT (12x6/12+24x6/12)
and 24 lakh MT per annum in subsequent years.” W.P. (C) Nos. 114/2014 etc.
155. A submission made by the mining lease holders was that the maximum production in any year
up to 1993-94 should be considered as the base for making the calculations. Such a contention was
also urged before the CEC and was rejected. We have examined this contention independently and
are of the view that the base year of 1993-94 is most appropriate - we have already given our reasons
for this. Some lessees might lose in the process while some of them might benefit but that cannot be
avoided. In any event, each mining lease holder is being given the benefit of calculations only from
2000-01 and is not being ‘penalized’ for the period prior thereto. We think the mining lease holders
should be grateful for this since it was submitted by learned counsel for the petitioners and the
learned Amicus that the penalty should be levied from the date of EIA 1994. In our opinion, theCommon Cause vs Union Of India . on 2 August, 2017

cut-off from 2000-2001 (without interest) is undoubtedly reasonable and there can be hardly be any
grievance in this regard. The mining lease holders cannot have their cake and eat it too, along with
the icing on top.
156. Since the recommendation made by the CEC in this regard is not totally unreasonable, we
accept that the compensation should be payable from 2000-2001 onwards at 100% of the price of
the mineral, as rationalized by the CEC.
W.P. (C) Nos. 114/2014 etc. Violation of the Forest (Conservation) Act, 1980
157. Before dealing with the violations of Section 2 of the Forest (Conservation) Act, 1980 (for short
‘the FCA’), it is necessary to give a brief background.
158. The FCA came into operation initially through the Forest (Conservation) Ordinance, 1980 with
effect from 25th October, 1980. The said Ordinance was repealed and subsequently the FCA came
into effect on 25th December, 1980.
159. Section 2 of the FCA provides that no State Government or other authority shall make, except
with the prior approval of the Central Government, any order directing, inter alia, that any forest
land or any portion thereof may be used for non-forest purposes.
160. The interpretation of Section 2 of the FCA first came up for consideration in State of Bihar v.
Banshi Ram Modi. 12 In that case, Banshi Ram Modi was granted a mining lease for mining and
winning mica. During the course of mining operations, feldspar and quartz were discovered. Modi
then applied to the Central Government to include these minerals in the lease. The State
Government agreed to do so but did not 12 (1985) 3 SCC 643 W.P. (C) Nos. 114/2014 etc. obtain the
previous approval of the Central Government for the inclusion of the two minerals in the original
lease.
161. The Central Government took the view that since its previous approval had not been obtained
for inclusion of feldspar and quartz in the mining lease, Modi could not be permitted to mine these
two minerals. This led Modi to approach the High Court with the contention that he was not
breaking up or clearing any forest land other than the land on which mining operations were already
being carried on. The High Court allowed the writ petition but feeling aggrieved, the State of Bihar
preferred an appeal in this Court.
162. The question before this Court was a narrow one, namely, whether prior approval of the Central
Government is necessary in respect of a mining lease, granted for winning a certain mineral prior to
the coming into force of the FCA, if the lessee applies to the State Government after the FCA came
into force for permission to win and carry any new mineral from the broken up area?
163. While answering this question in the negative, it was held that after the commencement of the
FCA no fresh breaking up of forest land or no fresh clearing of the forest on any such land could be
permitted by the State Government or any authority without the approval of the Central W.P. (C)Common Cause vs Union Of India . on 2 August, 2017

Nos. 114/2014 etc. Government. However, in respect of broken up land, it was held that if the State
Government permits the lessee to remove any discovered mineral, it cannot be said that there has
been a violation of Section 2 of the FCA particularly since there is no breaking up of any fresh forest
land.
164. Subsequently in Ambica Quarry Works v. State of Gujarat and Ors 13 when the lease of the
mining holder came up for renewal, the FCA had already come into force. Since the forest
department of the State of Gujarat refused to give a no objection certificate, the application for
renewal of the lease was rejected. The question that arose for consideration was whether, after
coming into force of the FCA, the mining lease holder was entitled to renewal of the mining lease.
While answering the question in the negative this Court held that the renewal of a lease cannot be
claimed as a matter of right. The primary purpose of the FCA was to prevent deforestation and
ecological imbalance as a result of deforestation. Therefore, the primary duty under the FCA was to
the community and the obligation to society must predominate over the obligation to the
individuals. While distinguishing Banshi Ram Modi this Court held that renewal of the lease would
lead to further deforestation or at least it would not help in reclaiming the area where deforestation
had already taken place. The primary purpose of the 13 (1987) 1 SCC 213 W.P. (C) Nos. 114/2014 etc.
FCA is to prevent further deforestation and any interpretation must sub-serve that purpose and
implement the FCA. Under the circumstances, it was held, considering the scheme of the FCA that
refusal to renew the lease without prior approval of the Central Government was not unjustified.
165. This view was reiterated in Rural Litigation and Entitlement Kendra v. State of U.P.14 It was
held that the FCA does not permit mining in a forest area. Reiterating the view expressed in Ambica
Quarry Works, it was observed that compliance of Section 2 of the FCA is necessary as a condition
precedent even for the renewal of a mining lease. This Court went so far as to hold that if any decree
or order has already been obtained by any of the mining lease holders, from any Court relating to
renewal of their lease, the same shall stand vacated and similarly, any appeal or other proceeding
taken to obtain a renewal or against any order or decree granting renewal shall also become non est.
166. The definition of the word ‘forest’ for the purposes of the FCA came up for consideration in T.N.
Godavarman v. Union of India.15 In its decision of 12th December, 1996 this Court observed that
during the course of hearing it appeared that there is a misconception about the true scope of 14
(1989) Supp. (1) SCC 504 15 (1997) 2 SCC 267 W.P. (C) Nos. 114/2014 etc. the FCA and the meaning
of the word ‘forest’ used therein. Consequently, there is also a misconception about the need for
prior approval of the Central Government as mandated by Section 2 of the FCA in respect of certain
activities in a forest area, which activities are more often of a commercial nature.
167. In this context, it was held that ‘forest’ must be understood according to its dictionary meaning
and it would cover all statutorily recognized forests, whether designated, reserved, protected or
otherwise. It was further held that ‘forest’ would also include any area recorded as a forest in the
government records irrespective of the ownership. With this in mind, this Court directed that prior
approval of the Central Government is required for any non-forest activity within the area of any
‘forest’. In accordance with Section 2 of the FCA all on-going activity within any forest in any State
throughout the country, without prior approval of the Central Government must cease forthwith.Common Cause vs Union Of India . on 2 August, 2017

This particular direction given by this Court is of immense significance.
168. This Court further directed each State Government to constitute within one month an Expert
Committee, inter alia, to identify areas which are ‘forest’ irrespective of whether they are so notified,
recognized or classified under any law and irrespective of the ownership of the land of such forest.
W.P. (C) Nos. 114/2014 etc.
169. Pursuant to the directions given by this Court, the State of Odisha constituted District Level
Committees (for short ‘DLC’) for identification of forest lands. After the identification process,
appropriate affidavits were filed by the State of Odisha in this Court in 1997-98, the last being dated
6 th January, 1998.
170. In the meanwhile, in T.N. Godavarman v. Union of India16 this Court passed certain directions
on 4th March, 1997 with regard to what was categorized as mining matters. The directions given by
this Court are as follows:
“9. We direct that – (1) where the lessee has not forwarded the particulars for seeking
permission under the FCA, he may do so immediately;
(2) the State Government shall forward all complete pending applications within a
period of 2 weeks from today to the Central Government for requisite decisions;
(3) applications received (or completed) hereafter would be forwarded within two
weeks of their being so made.
(4) the Central Government shall dispose of all such applications within six weeks of
their being received. Where the grant of final clearance is delayed, the Central
Government may consider the grant of working permissions as per existing practice.”
171. It was also made clear that the order passed by this Court including the earlier order dated 12th
December, 1996 shall be obeyed and carried out by 16 (1997) 3 SCC 312 W.P. (C) Nos. 114/2014 etc.
the Central Government and the State Governments notwithstanding any order or direction passed
by a court including a High Court or Tribunal to the contrary.
172. From the above, it is explicit that in terms of the orders passed by this Court, there was a
complete ban on non-forest activity on forest lands with effect from 12th December, 1996. The only
issue that remained was identification of all such lands by the District Level Committees and as
mentioned above this exercise was completed by the State of Odisha on or about 6th January, 1998.
The lands identified by the DLC are compendiously referred to as DLC lands.
173. In this background in IA Nos. 2746-2748 of 2009 in the case of T.N. Godavarman the CEC was
directed to submit a report which it did on 26th April, 2010. It was recommended by the CEC that
given the peculiar circumstances prevailing in the State of Odisha, mining operations in the entire
DLC lands included in the mining leases, may be allowed to continue on payment of the Net PresentCommon Cause vs Union Of India . on 2 August, 2017

Value (NPV) subject to the fulfillment of other statutory requirements and rules being complied
with.
174. By an order dated 7th May, 2010 this Court directed that the recommendation of the CEC
acceptable to the State Government could be complied with. Consequently, the State of Odisha
appears to have W.P. (C) Nos. 114/2014 etc. implemented the recommendations regarding recovery
of NPV and realized an amount of about Rs. 1750 crores as additional NPV.
175. We have been informed that in addition to the above, the mining lease holders have
subsequently deposited an amount under the heading of penal compensatory afforestation which
was introduced through guidelines issued by the MoEF on 3rd February, 1999. The guidelines in this
regard, were communicated by the Assistant Inspector General of Forest to the Chief Secretary of all
the State and Union Territories and the relevant portion thereof reads as follows:
“4.3.1 Cases have come to the notice of the Central Government in which permission
for diversion of forest land was accorded by the concerned State Government in
anticipation of approval of the Central Government under the Act and/or where work
has been carried out in forest area without proper authority. Such anticipatory action
is neither proper not permissible under the Act which clearly provides for prior
approval of the Central Government in all cases. Proposals seeking ex-post-facto
approval of the Central Government under the Act are normally not entertained. The
Central Government will not accord approval under the Act unless exceptional
circumstances justify condonation. However, penal compensatory afforestation
would be insisted upon by the MoEF on all such cases of condonation.
4.3.2 The penal compensatory afforestation will be imposed over the area
worked/used in violation. However, where the entire area has been deforested due to
anticipatory action of the State Government, the penal compensatory afforestation
will be imposed over the total lease area.” W.P. (C) Nos. 114/2014 etc.
176. It was submitted by learned counsel for the lessees that since additional NPV as well as an
amount towards penal compensatory afforestation has been paid by the defaulting mining lease
holders, the violation of Section 2 of the FCA stands condoned or in any event the illegal or unlawful
mining in forest lands stands regularized.
177. The CEC did not accept this submission made on behalf of the mining lease holders on the
ground that no retrospective forest clearance has been granted and even otherwise there is no
provision to condone or regularize the violation of Section 2 of the FCA.
178. We are of opinion that the view expressed by the CEC in this regard is partially correct. Given
the fact that the defaulting mining lease holders have been asked to pay and have paid additional
NPV as well as an amount towards penal compensatory afforestation, it must be assumed the
violation of the FCA has been condoned to a limited extent, more particularly since in its order dated
7th May, 2010 this Court permitted the State of Odisha to accept such recommendations of the CECCommon Cause vs Union Of India . on 2 August, 2017

made in the report dated 26 th April, 2010 as are acceptable to it. The relevant recommendations
made by the CEC read as follows:
“(c) No forest land can be leased/assigned without first obtaining the approval under
the FC Act. Therefore, the forest area approved under the FC Act should not be lesser
than the total forest area included in the mining leases approved under the MMDR
Act, 1957. W.P. (C) Nos. 114/2014 etc. Both necessarily have to be the same. In view
of the above, this Hon’ble Court while permitting grant of Temporary Working
Permission to the mines in Orissa and Goa has made it one of the pre-conditions that
the NPV will be paid for the entire forest area included in the mining leases.
Similarly, all the mining lease holders in Orissa should be directed to pay the NPV for
the entire forest area, included in the mining leases;
(d) In Orissa, substantial areas included in the mining leases as non forest land have
subsequently been identified as DLC forest (deemed forest/forest like areas) by the
Expert Committee constituted by the State Government pursuant to this Hon’ble
Court’s order dated 12.12.1996. While processing and/or approving the proposals
under the FC Act in many cases such areas have been treated as non-forest land. It is
recommended that (i) the NPV for the entire DLC area included in the mining lease,
after deducting the NPV already paid, should be deposited by the concerned lease
holder and (ii) the mining operations in the unbroken DLC land (virgin land) should
be permissible only if the permission under the FC Act has been obtained/is obtained
for such area. Keeping in view the peculiar circumstances as was existing in Orissa
and subject to the above, the mining operations in the broken DLC land may be
allowed to be continued provided the other statutory requirements and Rules are
otherwise being complied with.”
179. This still leaves open the question of violation of the order passed by this Court on 12th
December, 1996 followed by the order dated 4th March, 1997 namely that mining must cease
forthwith in forest areas. In regard to this violation, the only benefit (at best) that can be granted to
the mining lease holders that we are concerned with, is till 6 th January, 1998 when the affidavit was
filed in this Court in I.A.Nos. 2746-2748 of 2009 in T.N. Godavarman. With effect from 7th January,
1998 any mining activity in forest and DLC lands would clearly be completely illegal and
unauthorized W.P. (C) Nos. 114/2014 etc. and the benefit that the mining lease holders have derived
from this illegal mining would be subject to Section 21(5) of the MMDR Act. Therefore, the price of
the iron ore and manganese ore mined by the mining lease holders from 7th January, 1998 is
payable until forest clearance under Section 2 of the FC Act is obtained by the mining lease holders.
180. The report of the CEC dated 16th October, 2014 deals with 51 mining leases. It has been
recorded by the CEC that of them 15 mining leases have been found not involved in undertaking
mining operations in violation of the FCA. There are 16 mining leases that have violated the
provisions of the FCA between 25th October, 1980 and 1999-2000 and the State Government in
some of the cases has already issued a show cause notice to the mining lease holders. It is further
stated that most of the violations pertain to the period prior to 12th December, 1996. The CEC hasCommon Cause vs Union Of India . on 2 August, 2017

not made any particular recommendation in regard to these 16 mining leases nor do we, except to
direct the State Government to promptly take a decision on the show cause notice preferably within
a period of four months and in any case before 31 st December, 2017.
181. The CEC has also dealt with 18 others mining lease holders (other than M/s. Essel Mining and
Industries Ltd. relating to the Kasia Iron Ore Mines and Jilling-Langlotta Iron & Manganese Ore
Mines). With regard to these W.P. (C) Nos. 114/2014 etc. 18 mining lease holders, the view taken by
us above would hold good and clearly they are liable to compensate the State for the entire price of
the iron ore and manganese ore illegally mined with effect from 7 th January, 1998 until the forest
clearance was obtained by the concerned mining lease holder.
182. We have fixed 7th January, 1998 as the cut-off date despite the orders dated 12th December,
1996 and 4th March, 1997 only for the reason that it is possible that some mining lease holders (we
do not know how many) were not aware that they were inadvertently conducting mining operations
on DLC lands which were identified by the State of Odisha as forest lands on the directions of this
Court. For the purposes of Section 21(5) of the MMDR Act, they are entitled to the benefit of doubt
and along with them, the other mining lease holders before us.
The CEC in this regard has observed as follows:
“It will be seen that in the above cases the mining operations have been done in the
forest land in violation of the Forest (Conservation) Act, 1980 and consequently also
in violation of this Hon’ble Court order dated 12.12.1996. The CEC recommends that
70% of the notional value of the iron ore and manganese produced by the lessees by
undertaking mining operations in the forest land in violation of the Forest
(Conservation) Act, 1980 may be directed to be recovered from the respective lessees.
Wherever the mineral production is both from the forest land as well as non-forest
land then in such cases the notional value of the production from the forest land may
be calculated on pro rata basis of the extent of the forest land and non-forest land
involved. The notional value of the mineral, time limit for payment of the
compensation, use of the amount received as compensation and other conditions as
decided by this Hon’ble Court in respect of the production without/in excess of W.P.
(C) Nos. 114/2014 etc. the environmental clearance may be directed to be followed on
pari-passu basis.”
183. For the reasons that we have already expressed above, we are not in agreement with the CEC
that only a part of the notional value (in this case 70%) of the iron ore and manganese ore produced
by the mining lease holders should be recovered. We are of the view that Section 21(5) of the MMDR
Act should be given full effect and so we reiterate that the recovery should be to the extent of 100%.
184. There may be some overlap in the period when mining operations were conducted by the
mining lease holders without an EC and/or an FC. We make it clear that mineral extracted either
without an EC or without an FC or without both would attract the provisions of Section 21(5) of the
MMDR Act and 100% of the price of the illegally or unlawfully mined mineral must be compensatedCommon Cause vs Union Of India . on 2 August, 2017

by the mining lease holder. To the extent of the overlap or the common period, obviously only one
set of compensation is payable by the mining lease holder to the State of Odisha. We order
accordingly. However, we make it clear that whatever payment has already been made by the mining
lease holders towards NPV, additional NPV or penal compensatory afforestation is neither
adjustable nor refundable since that falls in a different category altogether.
W.P. (C) Nos. 114/2014 etc.
185. We may note that this Court has held in T.N. Godavarman v. Union of India17 that a violation
of the FCA is condonable on payment of penal compensatory afforestation charges. This obviously
would not apply to illegal or unlawful mining under Section 21(5) of the MMDR Act, but we make it
clear that the mining lease holders would be entitled to the benefit of any Temporary Working
Permission granted.
Conclusions on the issues of mining without an EC or FC or both
186. To avoid any misunderstanding, confusion or ambiguity, we make the following very clear:
(1) A mining project that has commenced prior to 27th January, 1994 and has
obtained a No Objection Certificate from the SPCB prior to that date is permitted to
continue its mining operations without obtaining an EC from the Impact Assessment
Agency. However, this is subject to any expansion (including an increase in the lease
area) or modernization activity after 27th January, 1994 which would result in an
increase in the pollution load. In that event, a prior EC is required. However, if the
pollution load is not expected to 17 (2011) 15 SCC 658 and (2011) 15 SCC 681 W.P. (C)
Nos. 114/2014 etc. increase despite the proposed expansion (including an increase in
the lease area) or modernization activity, a certificate to this effect is absolutely
necessary from the SPCB, which would be reviewed by the Impact Assessment
Agency.
(2) The renewal of a mining lease after 27th January, 1994 will require an EC even if there is no
expansion or modernization activity or any increase in the pollution load.
(3) For considering the pollution load the base year would be 1993-94, which is to say that if the
annual production after 27 th January, 1994 exceeds the annual production of 1993-94, it would be
treated as an expansion requiring an EC.
(4) There is no doubt that a new mining project after 27 th January, 1994 would require a prior EC.
(5) Any iron ore or manganese ore extracted contrary to EIA 1994 or EIA 2006 would constitute
illegal or unlawful mining (as understood and interpreted by us) and compensation at 100% of the
price of the mineral should be recovered from 2000-2001 onwards in terms of Section 21(5) of the
MMDR Act, if the extracted mineral has been disposed of. In addition, any rent, royalty or tax for
the period that such mining activity was W.P. (C) Nos. 114/2014 etc. carried out outside the miningCommon Cause vs Union Of India . on 2 August, 2017

lease area should be recovered.
(6) With effect from 14th September, 2006 all mining projects having a lease area of 5 hectares or
more are required to have an EC. The extraction of any mineral in such a case without an EC would
amount to illegal or unlawful mining attracting the provisions of Section 21(5) of the MMDR Act.
(7) For a mining lease of iron ore or manganese ore of less than 5 hectares area, the provisions of
EIA 1994 will continue to apply subject to EIA 2006.
(8) Any mining activity carried on after 7 th January, 1998 without an FC amounts to illegal or
unlawful mining in terms of the provisions of Section 21(5) of MMDR Act attracting 100% recovery
of the price of the extracted mineral that is disposed of. (9) In the event of any overlap, that is, illegal
or unlawful mining without an FC or without an EC or without both would attract only 100%
compensation and not 200% compensation. In other words, only one set of compensation would be
payable by the mining lease holder.
(10) No mining lease holder will be entitled to the benefit of any payments made towards NPV or
additional NPV or penal W.P. (C) Nos. 114/2014 etc. compensatory afforestation.
Violation of Section 6 of the MMDR Act
187. We have examined the report of the CEC with regard to the alleged violation of Section 6 of the
MMDR Act and find that there have been several amendments to Section 6 relating to the maximum
area for which a mining lease may be granted to a person. The following is the result of the
amendments:
1. From 1.6.1958 to 11.9.1972 - maximum lease area 10 sq. miles.
2. From 12.9.1972 to 9.2.1987 - maximum lease area 10 sq. km or 1000 hectares in
any one State.
3. From 10.2.1987 to 17.12.1999 – maximum lease area 10 sq.km or 1000 hectares in
any part of the country.
4. From 18.12.1999 till date – maximum lease area 10 sq.km or 1000 hectares in one
State.
188. While the word ‘person’ has not been defined in the MMDR Act, a reading of Section 5 thereof
indicates that the State Government shall not grant a mining lease to any person unless such person
is an Indian national or a company as defined in the Companies Act, 1956 and subsequently in the
Companies Act of 2013.
189. Sub-section (2) of Section 6 of the MMDR Act provides that a person acquiring by, or in the
name of, another person a mining lease which is intended for him/her shall be deemed to beCommon Cause vs Union Of India . on 2 August, 2017

acquiring it himself/herself. W.P. (C) Nos. 114/2014 etc.
190. For the purposes of determining the total area that can be acquired for mining operations,
Section 6(3) of the MMDR Act provides that the area held under a mining lease by a person as a
member of a cooperative society, company or other corporation or a Hindu Undivided Family or a
partner of a firm shall be deducted from the area referred to so that the sum total of the area held by
such person under a mining lease only as such member or partner or individually may not in any
case exceed the total area specified.
191. In this background, the CEC examined the case of seven mining lease holders. They are:
1. Essel Mining and Industries Limited
2. Rungta Mines Limited
3. Rungta Sons Pvt. Limited
4. Bonai Industrial Company Limited
5. Feegrade & Co. Pvt. Limited
6. M/s Mangilal Rungta
7. Jindal Steel & Power Limited
192. As far as Essel Mining and Industries Limited is concerned we propose to deal with this mining
lease holder on another occasion since even the CEC has placed this mining lease holder in a special
category.
193. Similarly, so far as Rungta Mines Limited, Rungta Sons Pvt. Limited and M/s Mangilal Rungta
are concerned, although the CEC has come to the conclusion that these persons have not acquired
mining leases in violation of Section 6 of the MMDR Act, there are some critical observations made
by the Commission with regard to the ‘Rungta Group’. Learned counsel for the W.P. (C) Nos.
114/2014 etc. petitioner submitted that the view of the CEC in this regard needs reconsideration.
Since the ‘Rungta Group’ was not heard by us, we propose to hear the above Rungta companies to
ascertain, inter alia, whether there has been any violation of the provisions of Section 6 of the
MMDR Act.
194. As far as Jindal Steel & Power Limited is concerned, we propose to hear this company on
another occasion since the suggestion of the CEC is that it is the benami holder of Sarda Mines Pvt.
Ltd. If it is so held to be a benami holder of Sarda Mines Pvt. Ltd. then there is a violation of Section
6 of the MMDR Act. However, the CEC has refrained from making any observations or
recommendation in this regard. Accordingly, we propose to hear Jindal Steel & Power Limited on a
later occasion on this limited issue.Common Cause vs Union Of India . on 2 August, 2017

195. As far as Bonai Industrial Company Limited and Feegrade & Co. Pvt. Limited are concerned,
the CEC has concluded that they have not violated Section 6 of the MMDR Act. That being the
position, and nothing having been shown to the contrary, we accept the recommendation of the CEC
in this regard.
Violation of Rule 37 of the Mineral Concession Rules, 1960
196. The CEC has discussed the possible violation of Rule 37 of the MCR. In this context, it was
noted that there were several mining lease holders who W.P. (C) Nos. 114/2014 etc. had entered into
raising contracts which were actually a transfer of the lease as postulated by Rule 37 of the MCR.
197. On this basis the State of Odisha constituted a Committee on 8 th July, 2011 to carry out a study
of the financial transactions between the mining lease holders and the raising contractors to
determine whether there is a prima facie violation of Rule 37 of the MCR.
198. On an examination of the material before it the Committee concluded that eight mining lease
holders violated Rule 37 of the MCR. These mining lease holders are as under:
             i)      R.P. Sao, Guali Iron Ore Mines, Keonjhar
             ii)     Indrani Patnaik, Unchabali Iron Ore Mines, Keonjhar
             iii)    M/s K.J.S. Ahluwalia, Nuagaon Iron Ore Mines, Keonjhar
             iv)     M/s Aryan Mining & Trading Corporation Pvt. Ltd.,
                     Narayanposhi Iron Ore Mines, Sundergarh
             v)      M/s Mideast Integrated Steel Ltd., Roida, Sidhamatha Iron Ore
                     Mines, Keonjhar
             vi)     Kavita Agrawal, Kusumdihi Manganese Mines, Sundergarh
             vii)    Mala Roy & Others, Jalabari Iron Ore Mines, Keonjhar
viii) M/s Sharda Mines (P) Ltd., Thakurani Iron Ores Mines, Keonjhar
199. Pursuant to the report of the Committee, a show cause notice was issued to these mining lease
holders by the State of Odisha. Six of the mining lease holders (other than M/s Aryan Mining &
Trading Corporation W.P. (C) Nos. 114/2014 etc. Pvt. Ltd. (for short Aryan) and Kavita Agrawal
(Kusumdihi Manganese Mines) challenged the show cause notice and the decision of the Committee
by filing revision petitions under Section 30 of the MMDR Act read with Rule 55 of the MCR before
the Central Government. The challenge to the show cause notice was on the ground that persons
who were not government servants could not have been included in the Committee and also that the
Committee was not notified in the official gazette as required by Section 26(2) of the MMDR Act.
200. The Central Government set aside the order constituting the Committee and the State of
Odisha has challenged the orders of the Central Government before the Orissa High Court through
writ petitions. We are told that the writ petitions filed by the State of Odisha are pending in the High
Court.Common Cause vs Union Of India . on 2 August, 2017

201. As far as Aryan is concerned, we were informed that the matter was pending with the State of
Odisha and a request was made to us to permit the State of Odisha to pass a final order on the
submissions made by Aryan. On 28th April, 2017 we had permitted the State of Odisha to pass final
orders but we are not aware whether any orders have since been passed.
202. As far as Kavita Agrawal is concerned, her lease was terminated by the State of Odisha and the
Central Government also dismissed her revision W.P. (C) Nos. 114/2014 etc. petition on 28th April,
2014. The said mining lease holder has since filed a writ petition which is pending in the Orissa High
Court.
203. During the course of hearing it was proposed by learned counsel appearing for some of the
mining lease holders that it might be appropriate if the raising contracts between these eight mining
lease holders and the raising contractors are given a fresh look. This suggestion was not acceptable
to one of the mining lease holders. However, we are of opinion that the suggestion is reasonable and
it will be appropriate if in fact a fresh look is given to the raising contracts entered into by the
mining lease holders and the raising contractors. We are also of opinion that such an order ought to
be passed with the consent of the mining lease holders since any delay in disposal of the issue would
not really sub-serve the interests of anybody including the mining lease holders.
204. Accordingly, for considering the appointment of an appropriate Committee in respect of the
eight mining lease holders mentioned above we would like to hear learned counsel for the parties.
We make it clear that the proposed Committee will be entitled to lift the corporate veil, the
importance of which in cases such as the present, has been emphasized in State of Rajasthan v.
Gotan Lime Stone Khanij Udyog (P). Ltd.18 18 (2016) 4 SCC 469 W.P. (C) Nos. 114/2014 etc.
Intergenerational equity
205. Mr. Prashant Bhushan, learned counsel for the petitioner sought to impress upon us the need
to consider intergenerational equity and if possible to place a limit on the extent of mining in the
State of Odisha by referring to an article titled: “Intergenerational equity: a legal framework for
global environment change” by Edith Brown Weiss. He laid emphasis on three principles that form
the basis of intergenerational equity.
206. The first principle relied on is called the principle of ‘conservation of options’. This requires
each generation to conserve the diversity of the natural and cultural resource base in such a manner
that the options available to future generations are not restricted. It was submitted that the extent of
mining activities being carried on in Odisha indicate that the entire iron ore will perhaps be fully
extracted within a period of 30 years and nothing would be available for future generations.
Therefore some sort of a limit would have to be placed on the mining operations.
207. The second principle relied on is the principle of ‘conservation of quality’. This was with
reference to the submission that future generations should not be subjected to a quality of the planet
worse than what it is today. In other words, future generations are also entitled to quality enjoyment
of the diversity in the natural and cultural resource base. W.P. (C) Nos. 114/2014 etc.Common Cause vs Union Of India . on 2 August, 2017

208. The third principle relied upon was the principle of ‘conservation of access’ which is to say that
future generations have an equitable right to access the diversity of the natural and cultural resource
base as is available to the present generation.
209. There is no doubt considerable substance in the submission particularly if this is considered in
the light of intergenerational rights and obligations which have been dealt with in the said article.
However, it is really not for this Court to lay down limits on the extent of mining activities that
should be permitted by the State of Odisha or by the Union of India. Nevertheless, this is an aspect
that needs serious consideration by the policy and decision makers in our country in the governance
structure. At present, keeping in mind the indiscriminate mining operations in Odisha, it does
appear that there is no effective check on mining operations nor is there any effective mining policy.
The National Mineral Policy, 2008 (effective from March 2008) seems to be only on paper and is
not being enforced perhaps due to the involvement of very powerful vested interests or a failure of
nerve. We are of opinion that the National Mineral Policy, 2008 is almost a decade old and a variety
of changes have taken place since then, including (unfortunately) the advent of rapacious mining in
several parts of the country. Therefore, it is high time that the Union of India revisits the W.P. (C)
Nos. 114/2014 etc. National Mineral Policy, 2008 and announces a fresh and more effective,
meaningful and implementable policy within the next few months and in any event before 31st
December, 2017. We are constrained to pass this direction in view of the facts disclosed in these
petitions and in judgments delivered by this Court with regard to mining in Goa and Karnataka.
Inquiry by the Central Bureau of Investigation
210. It was emphasized by Shri Prashant Bhushan that because of the rampant illegal or unlawful
mining being carried out in Odisha, there should be an enquiry by the Central Bureau of
Investigation (for short ‘the CBI’) to ascertain and determine the persons involved either in turning
a Nelson’s eye to rampant illegal or unlawful mining or being conspirators in the activity and the
extent of the illegal or unlawful mining. It was submitted that the Justice Shah Commission had very
strongly recommended an inquiry conducted by the CBI and criminal elements being brought to
book for the despoliation of the land.
211. For the present, we do not propose to direct an investigation or inquiry by the CBI for the
reason that what is of immediate concern is to learn lessons from the past so that rapacious mining
operations are not repeated in any other part of the country. This can be achieved through the
identification of lapses and finding solutions to the problems that are faced. W.P. (C) Nos. 114/2014
etc. Undoubtedly, there have been very serious lapses that have enabled large scale mining activities
to be carried out without forest clearance or environment clearance and eventually the persons
responsible for this will need to be booked but as mentioned above, the violation of the laws and
policy need to be prevented in other parts of the country. The rule of law needs to be established. We
are therefore of the view that it would be appropriate if an Expert Committee is set up under the
guidance of a retired judge of this Court to identify the lapses that have occurred over the years
enabling rampant illegal or unlawful mining in Odisha and measures to prevent this from
happening in other parts of the country.Common Cause vs Union Of India . on 2 August, 2017

212. There is no doubt that the recommendations of the Commission can form a platform for the
study but it is also necessary to use technology for maintenance of registers, records and data
through computers, satellite imagery, videography and other technology tools so that the natural
wealth of our country is not rapaciously exploited for the benefit of a few to the detriment of a large
number, many of whom are tribals inhabiting the land for several generations.
Utilization of funds by the Special Purpose Vehicle
213. In I.A. Nos.2746-2748 of 2009 filed by Rabi Das, an order was passed on 27th January, 2014
relating to the preparation of a scheme by the W.P. (C) Nos. 114/2014 etc. CEC for setting up a
Special Purpose Vehicle (SPV) for tribal welfare and area development works. The relevant extract
of the order reads thus:
"50% of the additional amounts of Net Present Value (NPV) recovered by the State of
Odisha from the mining lessees will be used by the State of Odisha through a Special
Purpose Vehicle (SPV) for undertaking specific tribal welfare and area development
works so as to ensure inclusive growth of the mineral bearing areas. The State of
Odisha will accordingly file within four weeks from today, a comprehensive plan for
the development of tribals out of the aforesaid funds, taking into consideration their
requirements of health, education, communication, recreation, livelihood and
cultural lifestyle as indicated in this Court’s judgment in T.N. Godavaraman
Thirumulpad v. Union of India & Others (2008) 2 SCC 222.”
214. Subsequently on 28th April, 2014 this Court accepted the scheme prepared by the Government
of Odisha in consultation with the Central Empowered Committee. The scheme was captioned
“Setting up of Special Purpose Vehicle (SPV) for undertaking specific tribal welfare and area
development works so as to ensure inclusive growth of mineral bearing areas in the State of Odisha”.
This Court then passed the following order on 28 th April, 2014:
“Pursuant to orders passed by this Court on 7th [27 th] January, 2014, the
Government of Odisha in consultation with the Central Empowered Committee has
prepared a Scheme captioned “Setting up of Special Purpose Vehicle (SPV) for
undertaking specific tribal welfare and area development works so as to ensure
inclusive growth of mineral bearing areas in the State of Odisha.
The Central Empowered Committee has submitted a Report dated 9th April, 2014
and has recommended that the Scheme prepared by the Government of Odisha may
be approved by this Court and the ad W.P. (C) Nos. 114/2014 etc. hoc CAMPA may be
directed to transfer to the SPV 50 per cent of the additional amount of the NPV
recovered from the mining lease holders by the State of Odisha for undertaking tribal
welfare and development works.
We have perused the Scheme prepared by the State Government of Odisha and the
recommendation of the Central Empowered Committee and we approve the SchemeCommon Cause vs Union Of India . on 2 August, 2017

and direct as hoc CAMPA to transfer to the SPV 50 per cent of the additional amount
of the NPV within a month for undertaking tribal welfare development works.
The Interlocutory applications be listed in the month of July, 2014.”
215. Some of the salient features of the Scheme are as follows:
5 The SPV will undertake specific tribal welfare and area development works so as to
ensure inclusive growth of the mineral bearing areas.
These will include works/projects related to livelihood intervention, health, water supply and
sanitation, education, special programmes for development of women and children, entrepreneurial
development of local people, communication and infrastructure projects and agro silvi-horticultural
based livelihood projects through identified agencies/Government Departments. While taking up
such projects/works a bottom up planning and participatory approach will be followed.
9 The general superintendence of the affairs will be vested in its Board of Directors including (a) to
receive grants/funds and have custody of the same, (b) to approve Annual Budget Estimates and
sanction the expenditure within the limits of the Budget, (c) to enter into any agreement for and on
behalf of the SPV; (d) institute and defend legal proceedings (e) to consider and approve the Annual
Report, audit report, annual accounts and the financial estimates of the SPV,
(f) to prescribe procedure to be followed for implementation of the projects/works and for
maintenance of accounts and (g) to undertake any other ancillary activities/works for the
furtherance of the objective of the SPV.
a The funds made available to the SPV will be utilized only for the purpose for which the SPV has
been set up and will not be used for any other purpose or transferred to any other authority; and
W.P. (C) Nos. 114/2014 etc. b The composition of the Board of Directors of the SPV, as provided in
the present scheme, will be modified only after obtaining permission from the Hon’ble Supreme
Court.
10. The accounts of the SPV will be internally audited annually by the Chartered Accountant firms
empanelled with the CAG/Principal Accountant General, Odisha. The audit of the accounts of the
SPV, receipts as well as expenditure, will be done annually by the office of the Principal Accountant
General, Odisha.
11. The State Government has, earlier, registered a Society, namely, Society for Inclusive
Development of Mineral Bearing Areas of Odisha, which has been registered vide registration
number 23354/74 of 2011-12 under the Societies Registration Act, 1860 to act as SPV for the
purpose. It is now proposed to wind up the said Society and to replace it with ‘Odisha Mineral
Bearing Areas Development Corporation’ to be set up under section 25 of the Companies Act.Common Cause vs Union Of India . on 2 August, 2017

216. It appears that the scheme has been implemented with the Chief Secretary of Odisha as the
ex-officio Chairman of the SPV. There are several other members and directors of the SPV. There is
no further information available with this Court with regard to the implementation of the scheme.
217. During the course of hearing, some of the mining lease holders represented by Shri Gopal
Subramanium, Senior Advocate offered to deposit and in fact did deposit an amount of Rs.237.05
crores for utilization by the SPV for carrying out welfare works and activities in the districts of
Keonjhar, Sundergarh and Mayurbhanj in Odisha. The deposit was made by way of a cheque on 6th
April, 2017 and was without prejudice to the rights W.P. (C) Nos. 114/2014 etc. and contentions of
lessees. In terms of our directions, the Registry has encashed the cheque and kept the amount in a
short term fixed deposit. We have mentioned this only to point out that there are huge amounts
available with the Special Purpose Vehicle for tribal welfare and area development works and we
have absolutely no idea about the utilization of the funds or whether they are in fact being used for
tribal welfare and area development works. We also expect that as a result of the orders that we are
passing today, very large amounts will again be made available to the State of Odisha. These
amounts should also be kept with the Special Purpose Vehicle.
218. To ensure that the amounts are utilized for the benefit of tribals in the affected districts and for
area development works, we would like the Chief Secretary of Odisha to file an affidavit stating the
work done as well as providing the audited accounts of the receipt and expenditure of the SPV from
its inception.
Conclusion
219. In view of findings above, we dispose of the writ petitions to the extent of the directions that we
have already given.
W.P. (C) Nos. 114/2014 etc.
220. I.A. Nos. 45 (filed by Zenith Mining) and 47 (filed by Kavita Agrawal) are dismissed since their
lease has not been extended or has been determined and they do not have any environment
clearance or forest clearance.
221. I.A. No. 66 (filed by J.N. Pattnaik) is also dismissed since there is no forest clearance available.
222. We have been informed that S.A. Karim (I.A. No.9) actually had a working lease and has
wrongly been included as a non-operational lease. Accordingly, I.A. No. 9 (filed by S.A. Karim) is
also dismissed but as being infructuous. However, it is made clear that the State Government should
ensure that the lessee S.A. Karim in fact has valid statutory clearances.
223. Pending show cause notices issued by the State Government should be decided by 31st
December, 2017 (if not already decided) after hearing the concerned noticees.Common Cause vs Union Of India . on 2 August, 2017

224. We would like to hear Jindal Steel and Power Limited, Sarda Mines Private Limited, Rungta
Group of Companies and Essel Mining and Industries Limited on the applications filed by them. For
this purpose list the matter again after two weeks so that a convenient date of hearing can be fixed.
225. The amounts determined as due from all the mining lease holders should be deposited by them
on or before 31 st December, 2017. Subject to W.P. (C) Nos. 114/2014 etc. and only after compliance
with statutory requirements and full payment of compensation and other dues, the mining lease
holders can re-start their mining operations.
226. We would also like to hear the eight concerned mining lease holders on the question of
appointing an appropriate Committee in respect of the applicability of Rule 37 of the Mineral
Concession Rules to them.
227. We would also like to hear learned counsel for all the parties with regard to setting up of an
Expert Committee presided over by a retired judge of this Court to identify the lapses that have
occurred over the years that have enabled rampant illegal and unlawful mining in Odisha and to
recommend preventive measures not only to the State of Odisha but generally to all other States
where mining activities are proceeding on a large scale. For the present, we pass no direction with
regard to any investigation by the CBI.
228. We direct the Union of India to have a fresh look at the National Mineral Policy, 2008 which is
almost a decade old, particularly with regard to conservation and mineral development. The exercise
should be completed by 31st December, 2017.
229. The Chief Secretary of Odisha should file an affidavit as indicated by us within a period of six
weeks and in any case on or before 30 th September, W.P. (C) Nos. 114/2014 etc. 2017. The Registry
will list these petitions along with the affidavit immediately after its receipt for our consideration.
230. All other pending I.A.s are disposed of in terms of our orders.
                                                             ....…..………………….J
                                                             (Madan B. Lokur)
                                                             ……..………………….J
      New Delhi;                                             (Deepak Gupta)
      August 2, 2017
W.P. (C) Nos. 114/2014 etc.Common Cause vs Union Of India . on 2 August, 2017

