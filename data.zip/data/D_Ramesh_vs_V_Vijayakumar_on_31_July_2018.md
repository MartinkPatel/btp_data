D.Ramesh vs V.Vijayakumar on 31 July, 2018
Author: R.Suresh Kumar
Bench: R.Suresh Kumar
IN THE HIGH COURT OF JUDICATURE AT MADRAS
DATED:   31.07.2018
CORAM
THE HON'BLE MR.JUSTICE R.SURESH KUMAR
Crl.R.C.Nos.271 of 2017 and 541 of 2017
Crl.R.C.No.271/2017
D.Ramesh
S/o.Duraisamy
Rep. by its Power Agent
R.Jayaprakash
S/o.Ramalingam
Door No.24/14 10th Street, M Block
Anna Nagar, Chennai                             ...
                                                 Petitioner/Complainant
                                        -vs-
1.V.Vijayakumar
   S/o.Davidraj
   No.1C-16 Annai Illam
   Patchi Amman Koil Street,
   Thevarkulam, Sankarankoil Taluk
   Tirunelveli District.
2.M.Thomas Pandian
   S/o.Maruthu Devar
   Adaikalapuram Main Road,
   Sankarankoil Taluk
   Tirunelveli District.                        ..      Respondents/Accused
Prayer: Criminal Revision Petition filed under Section 397 and 401 of the Code of Criminal Procedure against the order dated 25.01.2017 made in Cr.M.P.No.107/2017 on the file of the Metropolitan Magistrate for Exclusive Trial of CCB Cases, (Relating to cheating cases in Chennai) and CBCID, Metro cases, Chennai.
                For Petitioner  :       Mr.B.Kumarasamy
                For Respondents :       M/s.Ahmed Associates
                                                Mr.R.Rajarathinam
                                                Public Prosecutor for State 
                                                assisted by Mr.AyyapparajD.Ramesh vs V.Vijayakumar on 31 July, 2018

                                                Addl. Public Prosecutor
Crl.R.C.No.541 of 2017
M.Chezhieyan
S/o.M.S.Muthu
D.No.A114/82
3rd Avenue
Anna Nagar,
Chennai                                         ...
                                                 Petitioner/Petitioner
                                        -vs-
1.The Commissioner of Police,
   Egmore, Chennai
2.The Sub Inspector of Police,
   Central Crime Branch Team XVII  A
   Chennai.                             ..      Respondents/Respondents
Prayer: Criminal Revision Petition filed under Section 397 and 401 of the Code of Criminal Procedure against the order dated 25.01.2017 in Cr.M.P.No.1182/2016 on the file of the Metropolitan Magistrate for Exclusive Trial of CCB Cases, (Relating to cheating cases in Chennai) and CBCID, Metro cases, Chennai.
                For Petitioner  :       Mr.A.Rajarajan
                For Respondents :       Mr.R.Rajarathinam
                                                Public Prosecutor for State 
                                                assisted by Mr.Ayyapparaj
                                                Addl. Public Prosecutor
Judgment reserved on    :12.09.2017
Judgment pronounced on  : 31.07.2018
COMMON ORDER
The facts, which are required to be noticed insofar as Crl.R.C.No.271/2017 are concerned, read thus:
(i) That the revision petitioner is running a Firm in the name and style of Colour
Homes, by which, he constructs houses and sell. He has been doing the said
business for several years. During the month of May 2015, since the revision
petitioner was in need of some financial assistance to run his business, the accused
persons, who are the respondents herein, had contacted the petitioner over phone
and they introduced themselves that they are having contact with some big shots,
who are the financiers at Overseas and from whom, they will arrange loan to the tune
of Rs.25 Crores to the petitioner.
(ii) In order to strike the deal, the petitioner and the respondents had entered into a
Memorandum of Understanding on 27.05.2015, as per which, the loan would be
arranged by the respondents to the petitioner and the petitioner has to pay
commission to the respondents. Accordingly, a sum of Rs.1,10,00,000/- (Rupees one
crore ten lakhs only) was demanded as commission in advance by the respondents.
Believing the words of the respondents, the petitioner had paid a sum of
Rs.1,10,00,000/- by way of Bank RTGS.D.Ramesh vs V.Vijayakumar on 31 July, 2018

(iii) Though the said money by way of commission was received by the respondents
in advance, no action was taken by them to avail the loan by the petitioner and even
after almost one year period, since nothing was materialised, the petitioner claimed
to have met the respondents on 18.04.2016 personally at Chennai and when the
petitioner made demand of repayment of the advance commission given by him, the
petitioner was treated shabbily, thereby, the petitioner had come to the conclusion
that the respondents had cheated him. In the result, the petitioner preferred a
complaint on 21.04.2016 before the Commissioner of Police, Chennai, seeking action
against the respondents.
(iv) According to the complainant, though the said complaint of the petitioner was
forwarded by the Commissioner office file C.No.1919/COP.V/CCB/16 to the Inspector
of Police, II Team, Central Crime Branch, Chennai, the said officer ie., the Inspector
of Police, City Crime Branch (hereinafter referred to as 'CCB') had not taken into
account the said complaint and he had not filed even an FIR and he literally refused
to entertain the complaint to proceed further.
(v) Aggrieved over the non action on the part of the Investigating Officer of the CCB,
to whom, the complaint of the petitioner was forwarded by the Commissioner of
Police, the petitioner had filed a petition under Section 190(1) read with 156(3) of the
Code of Criminal Procedure (in short 'Code') before the Metropolitan Magistrate for
Exclusive trial of CCB Cases (relating to cheating cases in Chennai) and CBCID Metro
Cases, Chennai, in October 2016 seeking for a direction to the CCB, Chennai, to
register a case and to investigate the complaint against the respondents for the
offence committed under Sections 107, 109, 120(b), 405, 406, 465, 420, 294(b), 323
and 506(i) of IPC. The said petition filed under Section 156(3) of the Code was
considered and rejected through the impugned order of the learned Magistrate dated
25.01.2017 in Crl.M.P.No.107/2017. As against the said order of the learned
Magistrate, the present revision has been filed.
2. The very short facts, which are required to be noticed insofar as the case in Crl.R.C.No.541/2017 is
concerned, read as follows:
That the petitioner filed a complaint before the CCB, Chennai, to take action against
some individuals, who allegedly were trying to usurp the building property of the
petitioner. After having enquired preliminarily, the petitioner was directed to
approach the civil Court to seek remedy, by sending a report in this regard by the
second respondent on 22.07.2016. Aggrieved over the same, this petitioner also
invoking Section 156(3) of the Code, filed a petition in Crl.M.P.No.1182/2016 before
the Metropolitan Magistrate for Exclusive trial of CCB Cases (relating to Cheating
Cases in Chennai) and CBCID Metro Cases, Chennai. The said petition in
Crl.M.P.No.1182/2016 was rejected by the learned Magistrate by order dated
25.01.2017 as not maintainable. As against which, this revision case was filed.D.Ramesh vs V.Vijayakumar on 31 July, 2018

3. Since in both the cases, the learned Magistrate, who passed the respective impugned orders, had
taken into account the legal position as to whether the said petitions invoking Section 156(3) of the
Code was maintainable and had come to the conclusion that petitions were not maintainable,
accordingly dismissed the petitions.
4. In order to decide the sustainability of the said orders passed by the learned Magistrate, the facts
pertaining to the first case and the decision taken thereon are taken up for discussion herein, which
would cover the second case also.
5. In the order impugned in Crl.M.P.No.107/2017 dated 25.01.2017, the learned Magistrate has
dismissed the said petition as not maintainable primarily on two grounds:
(i) First ground was that, the Magistrate, even though is empowered to give direction
for investigation under Section 156(3) of the Code, such direction can only be given to
an officer in-charge of a police station that falls within the territorial jurisdiction of
the Court, where such investigation can be ordered. In this regard, it is the finding of
the learned Magistrate that neither the Commissioner of Police of Chennai City, who
is in charge of the CCB, Chennai, nor any other officer of CCB, Chennai, would be
deemed to be an officer in-charge of a police station within the meaning of Section
2(o) of the Code, as the CCB has never been declared as a police station under Section
2(s) of the Code.
(ii) The second ground was that, the complainant/petitioner should have complied
with the requirement of Section 154 of the Code by giving a complaint to the
concerned Police Station/Station House Officer and if at all such complaint was not
taken on file by such police officer in charge of the police station, he can send the
complaint to the Superintendent of Police concerned. Since this procedure is
contemplated under Section 154(1) and (3) of the Code and the same should be
mandatorily followed before invoking 156(3) of the Code as mandated by the Hon'ble
Supreme Court in Priyanka Srivatsava and another v. State of U.P. And others
[(2015) 6 SCC 287] (hereinafter referred to as 'Priyanka's case), the petition is not
maintainable. By giving primarily these two reasons, the learned Magistrate has
rejected the petition in the first revision case.
6. Insofar as the second revision case is concerned, apart from the aforesaid reasons, one more
additional reason was given, ie., as per Priyanka's case, every petition filed under Section 156(3) of
the Code must be supported by an affidavit to be filed by the petitioner and in absence of such
affidavit, such petition shall not be entertained and in this case, since no such affidavit admittedly
filed by the petitioner, the said petition was liable to be rejected and accordingly, for the said reason
also, the petition in the second revision case was rejected by the learned Magistrate through the
impugned order in the second case.
7. Before toiling into the arguments advanced by the learned counsel for the respective petitioners,
the learned Public Prosecutor for the State as well as other interested counsel from the Bar, who alsoD.Ramesh vs V.Vijayakumar on 31 July, 2018

made submissions for and against the stand taken by the learned Magistrate in these two cases, the
statutory position pertaining to the issue raised in these cases has to be analysed.
8. Section 156 of the Code reads thus:
56.Police Officer's power to investigate cognizable case: -
(1) Any officer in charge of a police station may, without the order of a Magistrate,
investigate any cognizable case which a Court having jurisdiction over the local area
within the limits of such, station would have power to inquire into or try under the
provisions of Chapter XIII.
(2) No proceeding of a police officer in any such case shall at any stage be called in
question on the ground that the case was one which such officer was not empowered
under this section to investigate.
(3) Any Magistrate empowered under section 190 may order such an investigation as
above-mentioned.
9. Section 154 of the Code reads thus:
54.Information in cognizable cases:- (1) Every information relating to the
commission of a cognizable offence, if given orally to an officer in-charge of a police
station, shall be reduced to writing by him or under his direction, and be read over to
the informant; and every information, whether given in writing or reduced for writing
as aforesaid, shall be signed by the person giving it and the substance thereof shall be
entered in a book to be kept by such officer in such form as the State Government
may prescribe in this behalf.
.........
(2).A copy of the information as recorded under sub-section (1) shall be given forthwith, free of cost,
to the informant.
(3).Any person aggrieved by a refusal on the part of an officer in charge of a police station to record
the information referred to in sub-section (1) may send the substance of such information, in writing
and by post, to the Superintendent of Police concerned who, if satisfied that such information
discloses the commission of a cognizable offence, shall either investigate the case himself or direct
an investigation to be made by any police officer subordinate to him, in the manner provided by this
Code, and such officer shall have all the powers of an officer in charge of the police station in
relation to that offence.
10. Section 190 of the Code reads thus:D.Ramesh vs V.Vijayakumar on 31 July, 2018

90.Cognizance of offences by Magistrates  (1) Subject to the provisions of this
Chapter, any Magistrate of the first class, and any Magistrate of the second class
specially empowered in this behalf under sub-section (2), may take cognizance of any
offence -
(a) upon receiving a complaint of facts which constitute such offence;
(b) upon a police report of such facts;
(c) upon information received from any person other than a police officer, or upon
his own knowledge, that such offence has been committed.
(2) The Chief Judicial Magistrate may empower any Magistrate of the second class to
take cognizance under sub-section (1) of such offences as are within his competence
to inquire into or try.
11. From the bare reading of the aforesaid three sections, which are having some interplay in the
present issue raised in these cases, the steps to be taken by a complainant/informant after the
commission of a cognizable offence, on the basis of number of judgments rendered by Courts of law
in this regard, can be catalogued as follows:
(i) Every information relating to the commission of a cognizable offence shall be
given to an officer in-charge of a police station either orally or in writing. If it is given
in oral, it should be reduced in writing, where the complainant/informant must sign
and a copy of such information shall be given to the informant forthwith free of cost;
(ii) If the officer in-charge of a police station refused to receive such information and
reduce in writing, the informant/complainant can send such information in writing
by post to the Superintendent of Police concerned, who after satisfying about such
information, which discloses the commission of a cognizable offence, either he can
investigate the case or can direct any other officer subordinate to him to investigate;
(iii) Independent of this provision 154 of the Code, it is the power of the police officer
to investigate and take cognizance of any offence commissioned within the
jurisdiction of the local area, where such police station would have power to enquire
into and try the case. However, under Section 156(3) of the Code, the Magistrate
concerned, who is empowered under Section 190 of the Code, has been vested with
the power to order for such investigation of any such offence ;
(iv) In Chapter XIV of the Code, the Magistrate is empowered to take cognizance of
any offence either on receipt of a complaint of facts which constitute an offence or
upon a police report or upon information received from any other source other than a
police officer ;D.Ramesh vs V.Vijayakumar on 31 July, 2018

(v) From the bare reading of the aforesaid three sections of the Code, one can
understand that, at the first instance, regarding any commission of offence, the
person, who knows the information, has to inform to an officer in-charge of a police
station and if the informant could not get a response from the in-charge police
officer, the same can be reported to the concerned Superintendent of Police ;
(vi) Only after such information, the investigation would commence. Such
investigation in cognizable offence can be straight away undertaken by the concerned
police officer and in non cognizable cases on receipt of complaint. If any police officer
in-charge of a police station and the concerned Superintendent of Police, in spite of a
cognizable offence if reported to him, not acted upon to reduce the same in writing
within the meaning of Section 154 of the Code and give a copy to the informant and
start investigating the complaint/information, then, the informant/complainant can
seek remedy from the jurisdictional Magistrate to seek for such an order to such
police officer to investigate the matter and for the said purpose, he/she can approach
the concerned Magistrate Court by invoking Section 156(3) of the Code ;
(vii) Wherever the Magistrate is empowered under Section 190 of the Code, he can
make order for such investigation under Section 156(3) of the Code. Therefore, the
power of taking cognizance of offence under Section 190 is linked with Section 156(3)
of the Code, as the Magistrate empowered under Section 190 alone can order for any
investigation in case of failure of the police officer to investigate in spite of
information received by him from any source under Section 154 of the Code.
12. Bearing in mind these interplay closely neted by the legislature in bringing these provisions in
the Code, the present issue, posed for decision in these cases, have to be dealt with.
13. In the teeth of the legal position, as has been referred to above, the orders passed by the learned
Magistrate, which are impugned herein, can be put into scanning. In the impugned orders, the
learned Magistrate has stated the following as a vital question for consideration, which arose before
him:
.Now, the vital question arises for consideration is whether this Court, which has
been specially constituted as per G.O.Ms.No.2442 Home (Courts-II) Department
dated 15.03.2012 for the exclusive trial of Central Crime Branch cases (relating to
cheating cases in Chennai) and Crime Branch Criminal Investigation Department
Metro Cases, can direct the Commissioner of Police, Chennai or the Inspector of
Police, Central Crime Branch Team XVII-A to conduct investigation by invoking
Section 156(3) of the Cr.P.C. as prayed in the petition. He further proceeded to say
after analyzing Section 156 of the Code that an order to investigation under Section
156(3) of the Code can be given only to the officer in-charge of the police station and
not to other police officers.D.Ramesh vs V.Vijayakumar on 31 July, 2018

14. The learned Magistrate, after taking note of the judgment of the Hon'ble Apex Court in Central
Bureau of Investigation, Jaipur v. State of Rajasthan [AIR 2001 SC 668] has stated that, when a
Magistrate orders investigation under Section 156(3) of the Code, he can only direct an officer
in-charge of a police station to take such investigation and not a superior officer under Section 36 of
the Code.
15. The learned Magistrate has further proceeded to analyse as to whether the CCB, Chennai is a
police station within the meaning of Section 2(s) of the Code and also whether the police officer
in-charge of CCB, ie., the Commissioner or Deputy Commissioner of Police or any other Officer
in-charge of CCB is an officer under Section 2(o) of the Code. He has stated in this regard that, the
Central Crime Branch (CCB), which is attached with the office of Police Commissioner, Chennai, is
not a regular police station, but it is only a Special Investigation Wing. The learned Magistrate
has further stated in this regard which are necessarily to be extracted herein:
4.It is also admitted one that the CCB, Chennai, is not receiving any information
from the informant directly under Section 154 of Cr.P.C. On the other hand, the CCB
registers cases only on the information forwarded by the superior officer like
Commissioner of Police or on the direction given by the Court of law. The
G.O.Ms.No.1244, Home (Pol-XIV) was applicable only for the Chennai City Suburban
area under the commissionerate of St.Thomas mount not for the Chennai City.
Inspite of sufficient time were granted, the petitioner side is unable to produce any
document or G.O. to show that the CCB, Chennai has been declared as Police Station
as required under section 2(s) of Cr.P.C.
....
17.Considering the above, this Court is of the view that the Commissioner of Police or
the officer of CCB, Chennai cannot be considered as officer-in-charge of a police
station. Therefore, this Court is of the further view that the Commissioner of Police or
the CCB, Chennai, cannot be directed to investigate any case under Section 156(3) of
Cr.P.C.
16. The learned Magistrate by following the law in Priyanka's case cited supra, has given his
findings, which reads thus:
3.The Hon'ble Supreme Court in the matter of Priyanka Srivatsava and Another v.
State of Uttar Pradesh and Others reported in 2015(6) SCC 287 clearly held that there
has to be prior application under Section 154(1) and 154(3) Cr.P.C, while filing a
petition under section 156(3) CrPC and both these aspects must be spelt out in the
application and necessary documents to that effect must be filed. In view of the above
law laid down by the Hon'ble Supreme Court, before passing the order under section
156(3) Cr.P.C. it must be ensured that before coming to the Court, the complainant
did approach the officer-in-charge of the police station for recording the information
disclosing commission of a cognizable offence and on refusal to register FIR, theD.Ramesh vs V.Vijayakumar on 31 July, 2018

complainant sent the substance of such information in writing and by post to the
Superintendent of Police under Section 154(3) CrPC.
24.In the present case, no material is available to show that the petitioner has
invoked the sections 154(1) and then 154(3) of Cr.P.C. before filing this petition for
seeking direction under Section 156(3) Cr.P.C. On the other hand, the petitioner
stated that the information about the alleged offence was informed to the
Commissioner of Police. It is worth pointing out that though it could supplement the
powers of an officer-in-charge of a police station.
17. Ultimately, the learned Magistrate had concluded that, the petitioner should have approached
the local territorial jurisdictional Magistrate Court to order such investigation to the officer
in-charge of a police station that falls within his territorial jurisdiction to investigate the alleged
offence, under Section 156(3) of the Code, after complying with the mandatory procedures laid down
for the same.
18. The learned Magistrate has further stated that, since the said Court was specially constituted for
the exclusive trial of CCB Cases (relating to Cheating Cases in Chennai) and CBCID Metro Cases,
Chennai, the said petition made under Section 156(3) of the Code seeking a direction to the CCB,
Chennai, to investigate the complaint of the petitioner was not maintainable and accordingly,
rejected.
19. In the light of the above said decision of the learned Magistrate, which is assailed herein, first, we
must look into as to whether the City Crime Branch (CCB), Chennai, is a police station under Section
2(s) of the Code and if so, whether the police officer in-charge of CCB can be termed as Officer
in-charge of a police station under Section 2(o) of the Code.
20. To examine these aspects, first, let me take the relevant provision of the Code, ie., 2(o) and 2(s),
which read thus:
(o) Officer in charge of a police station includes, when the officer in charge of
the police station is absent from the station-house or unable from illness or other
cause to perform his duties, the police officer present at the station-house who is next
in rank to such officer and is above the rank of constable or, when the State
Government so directs, any other police officer so present. (s) Police Station
means any post or place declared generally or specially by the State Government, to
be a police station, and includes any local area specified by the State Government in
this behalf.
21. In view of the categorical finding of the learned Magistrate that CCB is not a police station within
the meaning of Section 2(s) and therefore, the officer in-charge or the police officer available in that
CCB cannot be termed as an officer in-charge of a police station under Section 2(o) of the code and
therefore, the investigation cannot be directed to be undertaken by them by invoking Section 156(3)
of the Code, first, let us ascertain as to whether the CCB, Chennai was the police station and if so,D.Ramesh vs V.Vijayakumar on 31 July, 2018

when such status was given to it.
22. In this regard, when this Court specifically raised a query to the learned Public Prosecutor to
clarify whether the CCB, Chennai is a police station and if so, has it been declared so and when, the
learned Public Prosecutor has maintained the stand that, CCB, Chennai, is certainly a police station
and such declaration has been given. Since such a stand has been taken by the learned Public
Prosecutor on behalf of the prosecution, this Court by order dated 29.08.2017 had given the
following direction:
. After extensive hearing from the Bar, this Court still needs two important
clarifications from the State/Prosecution.
(1) That the stand of the State is that the City Crime Branch has already been declared
as a Police Station within the meaning of Section 2(s) of the Criminal Procedure
Code, in view of the notification issued under G.O.No. 173, Judicial, dated 1st April,
1929. It is also the stand of the State Government that the Government issued an
order in G.O.Ms.No.242 Home (Courts-II) Department, dated 15.03.2012 by and
under which sanction was accorded for the constitution of new Court in the cadre of
Civil Judge (Senior Division) in Chennai for exclusive trial of Central Crime Branch
cases (relating to cheating cases in Chennai) and Crime Branch Criminal
Investigation Department Metro Cases in Chennai. The exclusive Court has been
constituted where the offences investigated by the Central Crime Branch are being
tried.
In view of the said position whether or not the State Government issued any
Government Order or notification entrusting the class or category of the offences to
be exclusively investigated by the City Crime Branch, Chennai and if so what are all
such offences which have been specifically entrusted to the CCB (City Crime Branch)
for investigation?.
(2) Under Section 154 of the Criminal Procedure Code, an officer incharge of a Police
Station is empowered to receive information either oral or in writing and on receipt
of the same it shall be recorded in a book to be kept by said Officer, in such Forms as
may be prescribed on behalf of the State and if such Officer refused to receive the
information and enter in the book, the person aggrieved can approach the
Superintendent of Police, who have jurisdiction, before whom, if such information is
made, the Superintendent if satisfied shall either investigate the case himself or
direct the investigation to be made by any Police Officer in subordinate him.
In this context, since the City Crime Branch having been declared to be a Police Station within the
meaning of Section 2(s) of the Code, whether any such Officer/Officers-in-charge of the Police
Station for CCB has been designated by the State? and if so, the details of such officers so designated
by the State shall also be produced before this Court.D.Ramesh vs V.Vijayakumar on 31 July, 2018

3. Therefore, these two aspects i.e, the offences to be investigated by the CCB and the
Officer/Officers designated as Officer incharge of the Police Station for CCB by way of Government
Order or notification if any made or entrusted already, such documents/literature shall be filed
before this Court during the next hearing.
4. In order to enable the learned Additional Public Prosecutor to get proper instructions from the
respondents/State, Registry is directed to issue this order copy to the learned Additional Public
Prosecutor appearing for the respondents/State on or before 30.08.2017. The copy of this order may
be communicated to the Secretary to Government, Home Department, Tamil Nadu as well as The
Director General of Police, Tamil Nadu. Apart from that, the order copy be served to the
Commissioner of Police, Chennai City.
23. In response to the said query raised by this Court, the learned Public Prosecutor has filed a typed
set of papers along with the report of the Additional Commissioner of Police, CCB, Chennai. In the
typed set of papers, the prosecution side has filed a document, namely, G.O.No.173 Judicial dated
01.04.1929. For the sake of clarity and better understanding, the relevant portion of the said
notification is extracted hereunder:
Order No.173 Judicial, dated 1st April 1929.
The Government sanction with effect from the 1st April 1929 the proposals of the
Commissioner of Police for the re-organisation of the Madras City Police subject to
any modifications indicated in the following paragraphs.
2.Investigation  Central Crime Department  The Government accept the
Commissioner's proposals for the formation of a Central Crime department with the
following staff :-
-
Deputy Commissioner Assitant Commissioner Inspectors Sub Inspectors Head
constables Police constables Photographer Gazetted Staff Record section Intelligence
section General Investigation section Divisional Detachments Government house
Total
-
-+
-
-
-D.Ramesh vs V.Vijayakumar on 31 July, 2018

-
-
-
-
-
-
-
-
-
-
The pay of the photographer will be Rs.85-4-125.
The department will be in charge of Deputy Commissioner under the Commissioner
of Police assisted by an Assistant Commissioner who will be in direct charge of the
General Investigation section.
The headquarters staff of the department will be accommodated in the office below
the residence of the present Deputy Commissioner of Police, Southern Range. The
Inspector-General of Police should find rented accommodation for the office of the
Superintendent of the Government Railway police, Madras, which occupies a portion
of this building.
The Central Office of the department shall be a police station under section 4(1) (s),
Criminal Procedure Code. The following notification will be published in the Fort St.
George Gazette:-
Notification In exercise of the powers conferred by clause (s), sub-section (1) of
Section 4 of the Code of Criminal Procedure, 1898, the Governor in Council is pleased
to declare that with effect from 1st April 1929 the Central Office of the Crime
department, Madras City Police, Madras, shall be a 'Police Station' and the local area
for the said station shall be the City of Madras including all places within the local
limits of the ordinary original jurisdiction of the High Court of Judicature, Madras.
[extracted as it]D.Ramesh vs V.Vijayakumar on 31 July, 2018

24. In the said typed set of papers, the prosecution also filed copy of G.O.Ms.No.725 Home Police
(VIII) Department dated 18.08.2005. The relevant portion of the said G.O., is extracted hereunder
for easy reference:
ORDER:
The Hon'ble Chief Minister while replying to the debate in police demand No.21 on
15.03.2005 has made the following announcement amount others.
Strengthening of Central Crime Branch in Chennai City The Chennai City Central
Crime Branch investigates 2000 cases under I.P.C. annually and the existing strength
handling above cases is inadequate. In addition to this, the Chennai City Central
Crime Branch has to be reorganised and revamped so as to handle and to ensure
preemptive action against cheating, job rocket, and falsification of records. Charging
usurious interest and cyber crimes. Additional posts of 5 Inspectors, 10 Sub
Inspectors and 20 constables, will be created along with 5 jeeps, one Tempo Traveler
Van and Ten Motor Cycles at a cost of Rs.78.47 lakhs including non-recurring.
2.In order to revamp the Central Crime Branch, the Commissioner of Police, Greater
Chennai has requested to sanction additional strength of 5 Inspector of Police, 10 Sub
Inspectors, 15 Head Constables and 5 Grade I Police Constables along with 5 Jeeps. 1
Tempo Traveller and 10 motor Cycles and 5 Telephones and required furniture. With
the re-organized set up, the functional division on the basis of categories of crime
being handled in Central Crime Branch would ensure better quality of investigation
and follow up action of cases in Court. The Director General of Police has also
recommended above proposal.
3.The Government after careful examination accept the above proposal. They
accordingly sanction the creation of following additional staff in the scale of pay
noted against for strengthening and revamping of Chennai City Crime Branch for a
period of one year from the date of filling up of post or till the need ceases which ever
is earlier.
25. In the same typed set, the prosecution has also filed the organisational chart of the Central
Crime Branch, Chennai, and for the sake of convenience, the said Chart also is extracted hereunder:
ORGANISATIONAL CHART OF CENTRAL CRIME BRANCH
26. Along with the said documents, the Additional Commissioner of Police, CCB Chennai, has filed a
report and for the sake of clarity, the relevant portion of the said report is extracted hereunder:
.It is submitted that in this regard the following is submitted.D.Ramesh vs V.Vijayakumar on 31 July, 2018

Following the re-organization of the Madras City Police in 1929, Central Crime Department was
formed vide Go.No.173, Judicial dated 01.04.1929 and that the department will be in charge of
Deputy Commissioner, under the Commissioner of Police, assisted by an Assistant Commissioner,
who will be in direct charge of the General Investigation Section. It was further notified that Central
Office of the Crime Department, Madras City Police, Madras as Police Station and that the local
area shall be the city of Madras including all places within the local limits of the ordinary original
jurisdiction of the High Court of Judicature, Madras.
I.Offences to be tried by the CCB
4.It is submitted that in this regard, in G.O.Ms.No.725 Home [Pol.VIII] Department dated
18.08.2005, it has been stated that Chennai City Central Crime Branch has to be reorganized and
revamped so as to handle and to ensure preemptive action against cheating, job racket and
falsification of records, charging usurious interest and cyber crimes. It is pertinent that the Central
Crime Branch investigate cases of offences relating to
1.Cheating
2.Job racket
3.Falsification of records
4.Charging Usurious interest
5.Cyber Crimes.
5.It is submitted that apart from the above, the Central Crime Branch investigate
1.Land Grabbing cases [G.O.Ms.No.423 Home [Pol-XI] Department dated 28.07.2011.
2.Cases allotted by the Commissioner of Police [Under secton 36 of Cr.P.C., 1973]
II.OFFICER/OFFICERS DESIGNATED AS OFFICER IN-CHARGE OF THE POLICE STATION FOR
CCB
6.It is submitted that in this regard, in G.O.No.173, 1st April 1929, it has been stated that the Central
Crime Department will be in charge of Deputy Commissioner, under the Commissioner of Police,
assisted by an Assistant Commissioner who will be in direct charge of the General Investigation
Section.
7.It is submitted that in view of the above and in accordance with Section 2(o) of Cr.P.C. 1973, the
Assistant Commissioner of Police was designated as the Officer in-charge of the Central Crime
Branch [Police Station] and further that the parameters as mandated in sec 154(3) Cr.P.C. 1973 has
also been fulfilled.D.Ramesh vs V.Vijayakumar on 31 July, 2018

27. This Court has given its anxious consideration to those documents, especially, the oldest
document, namely, G.O.No.173 Judicial dated 01.04.1929.
28. On its careful perusal, this Court finds that, under Section 4(1)(s) under the old Code 1898
(equivalent to Section 2 of the present Code), the Governor in Council had declared that, from
01.04.1929, the Central Office of the Crime Department, Madras City Police, Madras, shall be the
police station and it has further been declared therein that, the local area for the said station shall be
the City of Madras including all places within the local limits of the ordinary original jurisdiction of
the High Court of Judicature at Madras.
29. This 1929 Government Order stands saved by Section 484 (2) (b) Cr.P.C. which reads as under:
84. Repeal and savings:
....
(2) Notwithstanding such repeal,--
(b) all notifications published, proclamations issued, powers conferred, forms
prescribed, local jurisdictions defined, sentences passed and orders, rules and
appointments, not being appointments as Special Magistrates, made under the Old
Code and which are in force immediately before the commencement of this Code,
shall be deemed, respectively to have been published, issued, conferred, prescribed,
defined, passed or made under the corresponding provisions of this Code.
Sometime in 2008, the Chennai City Commissionerate was bifurcated and Chennai Suburban
Commissionerate was carved out with its headquarters at St. Thomas Mount. Therefore, the Central
Crime Branch also had to be bifurcated, due to which, the Government issued G.O.Ms.No.1244,
Home (Pol-XIV) Department dated 29.09.2008 under Section 2(s) Cr.P.C., declaring the Central
Crime Branch in Chennai City Suburban area Police Commissionerate at St. Thomas Mount to be a
police station. After the change of political dispensation, the Suburban Commissionerate was once
again merged with the Chennai City Commissionerate and at present, we have a single
Commissionerate. However, G.O. Ms.No.1244, Home (Pol-XIV) Department dated 29.09.2008, has
not been repealed so far. This Court is mentioning this fact because both under the Old Code as well
under the new Code, there are notifications to the effect that the Central Crime Branch is a police
station within the meaning of Section 2(s) of the Code.
30. The said order No.173 would further reveal that, the Central Crime Department will be in-charge
of a Deputy Commissioner under the Commissioner of Police, who would be assisted by an Assistant
Commissioner and who will be in direct in-charge of the general investigating section. Based on the
said order only, since the Governor in Council has already declared the Central Office of the Crime
Department of the Madras City Police, as the police station within the meaning of Section 4(1)(s) of
the old Code (equivalent to Section 2(s) of the present Code), the said Central Office of the Crime
Department of Madras City started functioning since then.D.Ramesh vs V.Vijayakumar on 31 July, 2018

31. In the year 2005, when the Government decided to further strengthen the Chennai City, Central
Crime Branch, ie., CCB, Chennai, the Government had issued G.O.Ms.No.725 dated 18.08.2005,
which has already been extracted hereinabove. Under the said G.O., what are all the offences to be
investigated by the Additional Commissioner of Police, CCB Chennai can also be taken into aid.
According to the said Government Order, the following offences are specifically entrusted for
investigation by the CCB, Chennai. They are, (1) Cheating (2) Job rocketing (3) Falsification of
Records (4) Charging usurious interest and (5) Cyber Crimes.
32. However, at page no.5 of the RTI Manual issued by the Chennai City Police, it is stated that the
Central Crime Branch, Chennai, is a specialised organisation which deals only with specialised cases
which fall in one of the following categories:
a)Entrustment fraud, document fraud (breach of trust)
b)Gorgery cases
c)Gangsters operation and anti-extortion
d)Kandhuvaddhi and non-specialised crime and unregistered fraud
e)Job racketing
f)Video piracy and copyright act
g)Bank fraud and credit card fraud
h)Cyber crime and cyber law
i)Land grabbing and forged land documents
j)Fake passport, anti-adulteration and essential commodities, unsolved commercial
crimes.
33. As regards cases of cheating, the Commissioner of Police has passed an office order dated
08.06.2017 of which, paragraph no.2 reads as under:
(2) In the modification of the orders issued in the reference cited, it is ordered that
the amount involved in the cases handled by Central Crime Branch is increased from
the existing Rs.25 lakhs to Rs.50 lakhs and that the cases in which the amount
involved is less than Rs.50 lakhs are to be investigated by the crime section of the
local police under the direct supervision of the Assistant Commissioners of Police,
except the special cases or those specifically directed.D.Ramesh vs V.Vijayakumar on 31 July, 2018

34. In that context, the organizational Chart of the CCB, Chennai, filed by the prosecution shall also
be taken into account. According to that Chart, the Commissioner of Police is the Head of the CCB
and it must be under the control of the Full Time Additional Commissioner of Police, who is called
Additional Commissioner of Police, CCB, under whom, Deputy Commissioners of Police, Additional
Deputy Commissioners of police, Assistant Commissioners of Police, Inspectors of Police and other
Police people are pressed into service. Various types of crimes are being investigated by the CCB,
Chennai, out of which, the cheating cases is also one of the category of cases, which are being
investigated by the CCB.
35. Much argument was advanced at the Bar as to who would be the Station House Officer for the
Central Crime Branch.
36. It may also be relevant to note that at Paragraph No.7 of the report filed by the Additional
Commissioner, CCB Chennai, it is stated that, in accordance with Section 2(o) of the Code, the
Assistant Commissioner of Police was designated as the Officer in-charge of the Central Crime
Branch (Police station) and further that the parameters as mandated under Section 154(3) of the
Code has also been fulfilled.
37. It becomes imperative to test the arguments raised at the Bar in the backdrop of paragraph no.7
of the report filed by the Additional Commissioner of Police, referred to above. To appreciate these
contentions, it may be necessary to extract PSO 195 as under:
PSO 195  Station House Officers:
Sub Inspectors are normally employed as Station House Officers. However, in large
town stations, Inspectors are employed as Station House Officers.
38. Neither Section 2(o) Cr.P.C. nor PSO 195 defines who a Station House Officer is. The reason for
such mere description is not far to seek. Section 16 of the Chennai City Police Act, 1888, says that
every police officer appointed under the provisions of the Tamil Nadu District Police Act, 1859
(Central Act XIV, 1859), may be employed in the City of Chennai and while under such employment,
they shall have the same duties and powers and privileges of the police officers appointed under the
1859 Act. Section 21 of the 1859 Act is the source of power for the police to conduct investigation of a
case. This Act preceded the first Code of Criminal Procedure, viz., Criminal Procedure Code, 1861.
Therefore, every police officer was empowered to conduct investigation of a case under the Tamil
Nadu District Police Act, 1859. Section 23 of the Chennai City Police Act, 1888, is somewhat in pari
materia with Section 21 of the Tamil Nadu District Police Act, 1859. It must be remembered that the
Tamil Nadu District Police Act, 1859, is a Central Act and the Chennai City Police Act, 1888, is a
State Act. The Code of Criminal Procedure, which is also a Central Act, is only a procedural law and
it cannot have the effect of obliterating the provisions of substantive laws, viz., the Tamil Nadu
District Police Act, 1859 and the Chennai City Police Act, 1888. If a four corner definition is given to
the expression Station House Officer, it is bound to fall foul of the provisions of the Tamil Nadu
District Police Act and the Chennai City Police Act and that is why, a mere description of who is a
Station House Officer has been given in Section 2(o) Cr.P.C. and PSO 195.D.Ramesh vs V.Vijayakumar on 31 July, 2018

39. That apart, if one particular officer is declared as the Station House Officer, it will be very easy
for the others to shirk their responsibility and not take up the investigation of the crime even though
a duty has been cast upon all the police officers enrolled under the Tamil Nadu District Police Act,
1859, and the Chennai City Police Act, 1888 to suppress crimes. Therefore, the report filed by the
Additional Commissioner of Police stating that the Assistant Commissioner of Police has been
designated as officer in charge of the Central Crime Branch deserves acceptance and approval of this
Court. If the Assistant Commissioner of Police is declared as Station House Officer for the Central
Crime Branch, the Deputy Commissioner will become the authority under Section 154(3) Cr.P.C.
40. It was contended at the Bar that the FIRs in the CCB cases are registered by Inspectors and not
by the Assistant Commissioners of Police and therefore, that may give rise to new issues. The answer
to this question lies in Section 154 Cr.P.C. which clearly states that the information relating to the
commission of a cognizable offence can be reduced to writing by the officers in charge of a police
station or under his direction. Thus, on the directions of the Assistant Commissioner of Police, if an
FIR is registered by the Inspector of Police, it will not stand vitiated. This Court cannot also lose
sight of the fact that there was a time when a notorious nexus existed between the lower rung
Central Crime Branch officials and some legal practitioners, under which, FIRs were registered in
purely civil matters and settlements were arrived at in the Central Crime Branch. This nexus was
broken and the power of the Inspectors to register FIRs was clipped by administrative orders by
various Commissioners of Police to the effect that before recording an FIR, the approval of the
Commissioner should have to be obtained. This procedure was taken to such a ludicrous extent that
it was adversely commented by this Court in P. Satish Kumar vs. State (2014 (2) CTC 60), where, a
learned Single Judge of this Court (S. Nagamuthu, J., as he then was) has lamented that a complaint
of a bank fraud that was given on 11.01.2013 travelled from one desk to another and ultimately,
fruitioned into an FIR only on 07.10.2013, by which time, the accused in that case, had all the time
to cover up their tracks.
41. This Court is not for a moment saying that control levers should be dismantled, but, only exhorts
that they should not become closure valves. In Lalita Kumari vs. Government of Uttar Pradesh and
others [(2014) 2 SCC 1], a Constitution Bench of the Supreme Court has permitted preliminary
enquiries in commercial offences and has also given a six week time period for that. Therefore, the
Central Crime Branch is required to act with alacrity and complete the preliminary enquiry and also
obtain clearance from the Commissioner of police in accordance with their administrative rules
within a period of six weeks and take a decision whether to register or not to register the FIR. In the
event of deciding not to register the FIR, reasons in regard thereto, should have to be furnished to
the complainant so that the complainant can work out his remedies in the manner known to law.
42. Another argument that was advanced at the Bar is that the Commissioner of Police has no
jurisdiction to fix monetary limits for investigation by the Central Crime Branch as that would
offend the general power of the local police to register an FIR. It is true that every police officer in
the City City draws his ration of power to detect and bring offenders to justice via Section 23 of the
Chennai City Police Act, 1888, which reads as under:
3 Duties of police officers:D.Ramesh vs V.Vijayakumar on 31 July, 2018

Every police officer shall, for the purposes of this Act, be considered to be always on
duty. He shall not engage, without the written permission of the Commissioner, in
any duty other than his duties under this Act. It shall be his duty to use his best
endeavours and ability to prevent offences and public nuisances; to preserve the
peace; apprehend disorderly and suspicious characters; to detect and bring offenders
to justice; to take charge of all unclaimed property; to seize and impound stray cattle;
to collect and communicate intelligence affecting the public peace, and promptly to
obey and execute all orders and warrants lawfully issued to him; and it shall be lawful
for every Police officer, for any of the purposes mentioned in this section, without a
warrant to enter and inspect any drinking shop, gaming house or other place or
resort of loose or disorderly characters. (emphasis supplied)
43. Section 10 of the Chennai City Police Act empowers the Commissioner from time to time, subject
to the control of the State Government, to frame orders and regulations for the general governance
of the force. For effective governance of the City police, it is well within the powers of the
Commissioner to issue such directives fixing the monetary limits. Though this direction cannot have
the effect of overruling the statutory power of the local police to conduct investigation conferred by
the Code, yet, on that score alone, the directive cannot be said to be illegal. In other words, if a
Station House Officer of a local station ventures to take up the investigation of a case beyond Rs.50
lakhs in violation of the directives issued by the Commissioner, his investigation will not become
tainted. However, if he refuses to take up the investigation in compliance with the directives issued
by the Commissioner, he cannot be held criminally or departmentally liable because he is bound to
obey such directives of the Commissioner. The idea behind issuing such order is to lessen the
burden on the local police stations which are essentially required to maintain law and order,
whereas, the Central Crime Branch was not constituted to deal with day-to-day law and order issues,
but, to deal with white collar offences. Unlike the CB-CID which does not entertain complaints
directly, the Central Crime Branch has been entertaining complaints from the general public and
registering FIRs and investigating cases at least for the last 30 years. Thus, when they have been
accepting complaints from the general public, there is no reason to say that they enjoy immunity
under Section 156(3) Cr.P.C.
44. When a specific question was posed to the learned Public Prosecutor, after having gone through
these documents, especially, the document of G.O.No.173 of the year 1929 that, whether these
factors have been brought to the notice of this court before in any of such cases of this nature
considered by this Court, the answer was in the negative. It means that G.O.No.173 dated
01.04.1929, so far has not been brought to the notice of this Court.
45. Only in this context, the learned Magistrate in the impugned order at Paragraph No.14 has
specifically observed that in spite of sufficient time were granted, the petitioner side is unable to
produce any document or G.O., to show that the CCB, Chennai, has been declared as Police Station
as required under Section 2(s) of the Code.
46. Since these documents were not available before the learned Magistrate, he had come to the
conclusion that the CCB, Chennai was never declared to be a police station under Section 2(s) of theD.Ramesh vs V.Vijayakumar on 31 July, 2018

Code. When CCB is not a police station, the police people in-charge of the CCB cannot be termed as
officer in-charge of the police station within the meaning of Section 2(o) of the Code and therefore,
if at all any direction to be given invoking Section 156(3) of the Code, such direction cannot be
issued to a non police station or a non officer in-charge of a police station.
47. Only in that context, the learned Magistrate, taking into account the law laid down by the
Hon'ble Apex Court in CBI, Jaipur v. State of Rajasthan (cited supra) has come to the conclusion
that the Magistrate, who orders investigation under Section 156(3) of the Code, can only direct an
officer in-charge of a police station to take such investigation and not a superior officer.
48. The learned Magistrate in that context would further add that, since the CCB is projected as a
wing under the Commissioner of Police, such a direction, if it is given, it has to be given only to the
Commissioner of Police, who is not the officer in-charge of a police station nor the CCB is a police
station and therefore, such a direction cannot be issued by the Magistrate, as the Magistrate Court is
not empowered under Section 156(3) of the Code to issue such direction.
49. Therefore, the learned Magistrate has given a categorical finding at Paragraph No.17 of the
impugned order, as extracted hereinabove, that, the Commissioner of Police or the Officer of CCB,
Chennai, cannot be considered as an officer in-charge of a police station. Therefore, the
Commissioner of Police or the CCB, Chennai cannot be directed to investigate any case under
Section 156(3) of the Code.
50. Now, it has been clarified without any iota of doubt by virtue of the document of the year 1929,
and subsequent document that, the CCB, Chennai, has already been declared as a police station
under Section 2(s) of the Code and the Assistant Commissioner of Police, in-charge of CCB, would
be the officer in-charge of a police station. Even though the CCB is headed by the Commissioner of
Police as per the organizational chart produced by the prosecution and an Additional Commissioner
is heading the CCB, who is otherwise called as Adl. Commissioner CCB, the investigation, if at all to
be ordered by a jurisdictional Magistrate, who can take cognizance trial of the cases investigated by
the CCB, Chennai, he can do so by way of direction only to the Assistant Commissioner of Police and
not to any other higher official. Therefore, to that extent, the issue can be settled with abundant
clarity and confirmation.
51. Now, let us turn into the other ground, under which, the learned Magistrate has taken the
decision that the petitions filed before the Court below was not maintainable. According to the
learned Magistrate, as per the law declared by the Hon'ble Apex Court in Priyanka's case (cited
supra), only after exhausting the procedure contemplated under Section 154 of the Code, one can
approach the Magistrate concerned under Section 156(3) of the Code and since such steps had not
been taken, the invocation of Section 156(3) does not arise. Therefore, the petition was not
maintainable.
52. With regard to this second ground is concerned, number of judgments have been cited by the
learned counsel for the petitioners, learned Public Prosecutor as well as the members of the Bar,
who appeared before this Court as Amicus Curiae to assist the Court. Some of the judgments citedD.Ramesh vs V.Vijayakumar on 31 July, 2018

by the Bar are also examined, of course, in nutshell.
53. AIR 1961 SC 986 equivalent to 1961 23 Crl.LJ 39 [Gopal Das Sindhi and others v. State of Assam
and Another] We cannot read the provisions of Section 190 to mean that once a complaint is filed,
a Magistrate is bound to take cognizance if the facts stated in the complaint disclose the commission
of any offence. We are unable to construe the word 'may' in Section 190 to mean 'must.' The reason
is obvious. A complaint disclosing cognizable offences may well justify a Magistrate in sending the
complaint, under Section 156(3) to the police for investigation. There is no reason why the time of
the Magistrate should be wasted when primarily the duty to investigate in cases involving cognizable
offences is with the police. On the other hand, there may be occasions when the Magistrate may
exercise his discretion and take cognizance of a cognizable offence. If he does so then he would have
to proceed in the manner [provided by Chapter XVI of the Code, Numerous cases were cited before
us in support of the submissions made on behalf of the appellants. Certain submissions were also
made as to what is meant by "taking cognizance."
54. (1976) 3 SCC 252 [Devarapalli Lakshminarayana Reddy and others v. V.Narayana Reddy and
others] 3.It is well settled that when a Magistrate receives a complaint, he is not bound to take
cognizance if the facts alleged in the complaint, disclose the commission of an offence. This is clear
from the use of the words "may take cognizance" which in the context in which they occur cannot be
equated with must take cognizance". The word "may" gives a discretion to the Magistrate in the
matter. If on a reading of the complaint he finds that the allegations therein disclose a cognizable
offence and the forwarding of the complaint to the police for investigation under s. 156(3) will be
conducive to justice and save the valuable time of the Magistrate from being wasted in enquiring
into a matter which was primarily the duty of the police to investigate, he will be justified in
adopting that course as an alternative to taking cognizance of the offence, himself.
55. (1997) 8 SCC 476 [Madhu Bala v. Suresh Kumar and others] From the foregoing discussion it is
evident that whenever a magistrates directs an investigation on a 'complaint' the police has to
register a cognizable case on that complaint treating the same as the FIR and comply with the
requirements of the above Rules. It, therefore, passes our comprehension as to how the direction of
a Magistrate asking the police to 'register a case' makes an order of investigation under Section
156(3) legally unsusteinable. Indeed, eve if Magistrate does not pass a direction to register a case,
still in view of the provisions of Section 156(1) of the Code which empowers the Police to Investigate
into a cognizable 'case' and the Rules framed under the Indian Police Act, 1861 it ( the Police) is duty
bound to formally register a case and then investigate into the same. The provisions of the Code,
therefore, does not in any way stand in the way of a Magistrate to direct the police to register a case
at the police station and then investigate into the same. In our opinion when an order for
investigation under Section 156(3) of the Code is to be made the proper direction to the Police would
be to register a case at the police station treating the complaint as the First Information Report and
investigate into the same.
56. 2006(1) SCC 627 [Mohd. Yousuf v. Afaq Jahan (smt) and Another] 6.There is no particular
format of a complaint. A petition addressed to the magistrate containing an allegation that an
offence has been committed, and ending with a prayer that the culprits be suitably dealt with, as inD.Ramesh vs V.Vijayakumar on 31 July, 2018

the instant case, is a complaint.
57. (2008) 1 MWN (Cr) 47 [Muthusankaralingam v. R.Suresh] 9.In fact, Section 210, Cr.P.C. deals
with a situation where there is complaint case and a police investigation in respect of the same
offence. Section 210, Cr.P.C. reads as follows:
10.Procedure to be followed when there is a complaint case and police
investigation in respect of the same offence, -
(1) When in a case instituted otherwise than on a police report (hereinafter referred
to as a complaint case), it is made to appear to the Magistrate, during the course of
the inquiry or trial held by him, that an investigation by the police is in progress in
relation to the offence which is the subject matter of the inquiry or trial held by him,
the Magistrate shall stay the proceedings of such inquiry or trial and call for a report
on the matter from the police officer conducting the investigation.
(2) If a report is made by the investigating police officer under Section 173 and on
such export cognizance of any offence is taken by the Magistrate against any person
who is an accused in the complaint case, the Magistrate shall inquire into or try
together the complaint case and the case arising out of the police report as if both the
cases were instituted on a police report.
(3) If the police report does not relate to any accused in the complaint case or if the
Magistrate does not take cognizance of any offence on the police report, he shall
proceed with the inquiry or trial, which was stayed by him, in accordance with the
provisions of this Code.
10.Apart from that if a complaint even under Section 190(1)(a), Cr.P.C. is given the learned
Magistrate may either proceed under Chapter XV as mentioned above or under Section 156(3)
Cr.P.C. may order for an investigation by the police. Therefore, the contention of learned counsel for
the petitioner that the complaint filed directly before the learned Chief Judicial Magistrate is not
maintainable without giving any information to the police as contemplated under Section 154
Cr.P.C. is not acceptable in view of the reasons stated above.
58. (2013) 10 SCC 705 [Anilkumar and others v. M.K.Aiyappa and another] 6.A Special Judge is
deemed to be a Magistrate under Section 5(4) of the PC Act and, therefore, clothed with all the
magisterial powers provided under the Code of Criminal Procedure. When a private complaint is
filed before the Magistrate, he has two options. He may take cognizance of the offence under Section
190 Cr.P.C. or proceed further in enquiry or trial. A Magistrate, who is otherwise competent to take
cognizance, without taking cognizance under Section 190, may direct an investigation under Section
156(3) Cr.P.C. The Magistrate, who is empowered under Section 190 to take cognizance, alone has
the power to refer a private complaint for police investigation under Section 156(3) Cr.P.C.D.Ramesh vs V.Vijayakumar on 31 July, 2018

59. (2015) 6 SCC 439 [Ramdev Food Products Private Limited v. State of Gujarat] 8.In Devrapalli
Lakshminaryanan Reddy & Ors. vs. V. Narayana Reddy & Ors.[20], National Bank of Oman vs.
Barakara Abdul Aziz & Anr.[21], Madhao & Anr. vs. State of Maharashtra & Anr.[22], Rameshbhai
Pandurao Hedau vs. State of Gujarat[23], the scheme of Section 156(3) and 202 has been discussed.
It was observed that power under Section 156(3) can be invoked by the Magistrate before taking
cognizance and was in the nature of pre-emptory reminder or intimation to the police to exercise its
plenary power of investigation beginning Section 156 and ending with report or chargesheet under
Section 173. On the other hand, Section 202 applies at post cognizance stage and the direction for
investigation was for the purpose of deciding whether there was sufficient ground to proceed.
60. The learned Magistrate has heavily relied upon the Priyanka's case reported in 2015 (6) SCC
287, where, their Lordships has held as follows.
0.In our considered opinion, a stage has come in this country where Section 156(3) Cr.P.C.
applications are to be supported by an affidavit duly sworn by the applicant who seeks the
invocation of the jurisdiction of the Magistrate. That apart, in an appropriate case, the learned
Magistrate would be well advised to verify the truth and also can verify the veracity of the
allegations. This affidavit can make the applicant more responsible. We are compelled to say so as
such kind of applications are being filed in a routine manner without taking any responsibility
whatsoever only to harass certain persons. That apart, it becomes more disturbing and alarming
when one tries to pick up people who are passing orders under a statutory provision which can be
challenged under the framework of said Act or under Article 226 of the Constitution of India. But it
cannot be done to take undue advantage in a criminal court as if somebody is determined to settle
the scores.
31.We have already indicated that there has to be prior applications under Section 154(1) and 154(3)
while filing a petition under Section 156(3). Both the aspects should be clearly spelt out in the
application and necessary documents to that effect shall be filed. The warrant for giving a direction
that an the application under Section 156(3) be supported by an affidavit so that the person making
the application should be conscious and also endeavour to see that no false affidavit is made. It is
because once an affidavit is found to be false, he will be liable for prosecution in accordance with
law. This will deter him to casually invoke the authority of the Magistrate under Section 156(3). That
apart, we have already stated that the veracity of the same can also be verified by the learned
Magistrate, regard being had to the nature of allegations of the case. We are compelled to say so as a
number of cases pertaining to fiscal sphere, matrimonial dispute/family disputes, commercial
offences, medical negligence cases, corruption cases and the cases where there is abnormal
delay/laches in initiating criminal prosecution, as are illustrated in Lalita Kumari are being filed.
That apart, the learned Magistrate would also be aware of the delay in lodging of the FIR.
61. 2011 (3) SCC 496 [Mona Panwar v. High Court of Judicature of Allahabad through its Registrar
and others] 8.When the complaint was presented before the appellant, the appellant had mainly
two options available to her. One was to pass an order as contemplated by Section 156(3) of the
Code and second one was to direct examination of the complainant upon oath and the witnesses
present, if any, as mentioned in Section 200 and proceed further with the matter as provided byD.Ramesh vs V.Vijayakumar on 31 July, 2018

Section 202 of the Code. An order made under sub-section (3) of Section 156 of the Code is in the
nature of a peremptory reminder or intimation to the police to exercise its plenary power of
investigation under Section 156(1). Such an investigation embraces the entire continuous process
which begins with the collection of evidence under Section 156 and ends with the final report either
under Section 169 or submission of charge sheet under Section 173 of the Code. A Magistrate can
under Section 190 of the Code before taking cognizance ask for investigation by the police under
Section 156(3) of the Code. The Magistrate can also issue warrant for production, before taking
cognizance. If after cognizance has been taken and the Magistrate wants any investigation, it will be
under Section 202 of the Code.
19.The phrase "taking cognizance of" means cognizance of offence and not of the offender. Taking
cognizance does not involve any formal action or indeed action of any kind but occurs as soon as a
Magistrate applies his mind to the suspected commission of an offence. Cognizance, therefore, takes
place at a point when a Magistrate first takes judicial notice of an offence. This is the position
whether the Magistrate takes cognizance of an offence on a complaint or on a police report or upon
information of a person other than a police officer. Before the Magistrate can be said to have taken
cognizance of an offence under Section 190(1)(b) of the Code, he must have not only applied his
mind to the contents of the complaint presented before him, but must have done so for the purpose
of proceeding under Section 200 and the provisions following that Section. However, when the
Magistrate had applied his mind only for ordering an investigation under Section 156(3) of the Code
or issued a warrant for the purposes of investigation, he cannot be said to have taken cognizance of
an offence.
62. Full Bench of Bombay High Court in Crl. Writ Petition No.270 of 2009 [Panchabhai Popotbhai
Butani and others v. The State of Maharashtra through Senior Inspector, Mahatma Phule and
others] 4. In view of our above discussion, we record our answers to the questions of law posed
before us, as follow:-
Question No. (i) Whether in absence of a complaint to the police, a complaint can be
made directly before a Magistrate ?
Answer Normally a person should invoke the provisions of Section 154 of the Code
before he takes recourse to the power of the Magistrate competent to take cognizance
under Section 190 of the Code, under Section 156(3). Atleast an intimation to the
police of commission of a cognizable offence under Section 154(1) would be a
condition precedent for invocation of powers of the Magistrate under Section 156(3)
of the Code. We would hasten to add here that this dictum of law is not free from
exception.
There can be cases where non-compliance to the provisions of Section 154(3) would
not divest the Magistrate of his jurisdiction in terms of Section 156(3). There could be
cases where the police fail to act instantly and the facts of the case show that there is
possibility of the evidence of commission of the offence being destroyed and/or
tampered with or an applicant could approach the Magistrate underSection 156(3) ofD.Ramesh vs V.Vijayakumar on 31 July, 2018

the Code directly by way of an exception as the Legislature has vested wide discretion
in the Magistrate.
Question No. (ii) Whether without filing a complaint within the meaning of Section
2(d) and praying only for an action under Section 156(3), a complaint before a
Magistrate was maintainable ?
Answer A Petition under Section 156(3) cannot be strictly construed as a complaint in
terms of Section 2(d) of the Code and absence of a specific or improperly worded
prayer or lack of complete and definite details would not prove fatal to a petition
under Section 156(3), in so far as it states facts constituting ingredients of a
cognizable offence. Such petition would be maintainable before the Magistrate.
65 We answer the questions of law accordingly. The matters be listed before a appropriate bench for
disposal in accordance with law.
63. Supreme Court Judgment in Appeal (Crl.) 1685 of 2007 in the matter of Sakiri Vasu v. State of
U.P. And others.
4. In view of the abovementioned legal position, we are of the view that although Section 156(3) is
verybriefly worded, there is an implied power in the Magistrate under Section 156(3) Cr.P.C. to
order registration of a criminal offence and /or to direct the officer in charge of the concerned police
station to hold a proper investigation and take all such necessary steps that may be necessary for
ensuring a proper investigation including monitoring the same. Even though these powers have not
been expressly mentioned in Section 156(3) Cr.P.C., we are of the opinion that they are implied in
the above provision.
25. We have elaborated on the above matter because we often find that when someone has a
grievance that his FIR has not been registered at the police station and/or a proper investigation is
not being done by the police, he rushes to the High Court to file a writ petition or a petition under
Section 482 Cr.P.C. We are of the opinion that the High Court should not encourage this practice
and should ordinarily refuse to interfere in such matters, and relegate the petitioner to his
alternating remedy, firstly under Section 154(3) and Section 36 Cr.P.C. before the concerned police
officers, and if that is of no avail, by approaching the concerned Magistrate under Section 156(3).
26. If a person has a grievance that his FIR has not been registered by the police station his first
remedy is to approach the Superintendent of Police under Section 154(3) Cr.P.C. or other police
officer referred to in Section 36 Cr.P.C. If despite approaching the Superintendent of Police or the
officer referred to in Section 36 his grievance still persists, then he can approach a Magistrate under
Section 156(3) Cr.P.C. instead of rushing to the High Court by way of a writ petition or a petition
under Section 482 Cr.P.C. Moreover he has a further remedy of filing a criminal complaint under
Section 200 Cr.P.C. Why then should writ petitions or Section 482 petitions be entertained when
there are so many alternative remedies?D.Ramesh vs V.Vijayakumar on 31 July, 2018

27. As we have already observed above, the Magistrate has very wide powers to direct registration of
an FIR and to ensure a proper investigation, and for this purpose he can monitor the investigation
to ensure that the investigation is done properly (though he cannot investigate himself). The High
Court should discourage the practice of filing a writ petition or petition under Section 482 Cr.P.C.
simply because a person has a grievance that his FIR has not been registered by the police, or after
being registered, proper investigation has not been done by the police. For this grievance, the
remedy lies under Sections 36 and 154(3) before the concerned police officers, and if that is of no
avail, under Section 156(3) Cr.P.C. before the Magistrate or by filing a criminal complaint under
Section 200Cr.P.C. and not by filing a writ petition or a petition under Section 482 Cr.P.C.
64. Judgment of a learned Judge of this Court in Crl.O.P.No.9542 of 2015 and Crl.R.C.No.496/2015
[S.Madhiyazhagan v. State rep. by the Inspector of Police] 1.Thus the CBCID is an elite force
within the police department that has been constituted to investigate cases, on the orders of
Supreme Court, High Court, Government and Director General of Police. Therefore, the direction
issued by the Magistrate to the CBCID under Section 156(3) Cr.P.C. to investigate is not
sustainable.
65. Overall scanning of the aforesaid judgments would reveal that, the power to give direction to
investigate vested with the Magistrate concerned under Section 156(3) of the Code is not an
automatic one and once the litigant knocked the doors of the Magistrate under Section 156(3) of the
Code, it is not mandatory on the part of the Magistrate to act upon mechanically by giving a
direction to the investigating officer to investigate the complaint under Section 156(3) of the Code.
The Magistrate must look into the matter, veracity of the complaint and if he is satisfied that the
ingredients made in the complaint/petition would disclose the commission of an offence, then only,
he can give such direction to the investigating officer to investigate.
66. The learned Magistrate can also take an alternative route by invoking the provisions of Sections
200 and 202 of the Code and investigate the matter on his own.
67. Though it was held by a learned Judge of this Court in 2008 (1) MWN Crime 47, that, the
contention that the complaint filed directly before the learned Chief Judicial Magistrate was not
maintainable without giving any information to the police as contemplated under Section 154 of the
Code of Criminal Procedure, is not acceptable, the said law, in my considered view, is no longer a
good law, in view of the categorical declaration made by the Hon'ble Apex Court in Priyanka's case,
where at paragraph No.31 of the said judgment, the Hon'ble Supreme Court has held that, there has
to be a prior application under Section 154(1) and 154(3) of the Code, while filing the petitions under
Section 156(3). Since the said law, declared by the Apex Court, is binding under Article 141 of the
Constitution of India and the learned Magistrates, were directed to be vigilant and diligent, while
exercising the power under Section 156(3) of the Code, it cannot be construed that the
complainant/petitioner can straight away approach the Magistrate Court, without exhausting the
procedure contemplated under Section 154 of the Code. In view of the law declared by the Apex
Court in Priyanka's case, the observations made by the learned Magistrate in this regard has to be
sustained.D.Ramesh vs V.Vijayakumar on 31 July, 2018

68. However, in view of the judgment in Sakiri Vasu's case, where the Hon'ble Supreme Court has
held that there is an implied power with the Magistrate under Section 156(3) of the Code to order
registration of an offence and direct the officer to hold a proper investigation, such power since is
vested only with the Magistrate concerned, which cannot be abdicated by the Magistrate except for
strong legal ground.
69. Here, in the case in hand, insofar as the first case is concerned, the complaint was given to the
Commissioner of Police, who is none other than the Head of the CCB, Chennai. The Commissioner,
on receipt of the complaint of the petitioner, had forwarded the same to an Inspector of Police,
in-charge of a team of CCB Chennai for further investigation. When such investigation was not
conducted and an FIR was not registered, the complainant/petitioner approached the Magistrate
Court to exercise the power under Section 156(3) of the Code.
70. In this context, the initial approach of the complainant/petitioner before the Commissioner of
Police can only be construed as the information in writing submitted to the officer in-charge of a
police station both within the meaning of Section 154(1) and 154(3) of the Code. The reason being
that, though the CCB, Chennai is headed by the Commissioner of Police, in fact, practically, it is
headed and run by Additional Commissioner of Police, CCB, Chennai, under whom, number of
Deputy Commissioners, Assistant Commissioners and other Police Persons are employing. As per
the declaration made by the Government, ie, the then Madras Governor in Council in the year 1929,
the Assistant Commissioner in-charge of the General Investigation Section of Central Office of the
Crime Department, Madras City Police will be the direct charge. Even at that time, the said Central
Office Crime Department of Madras City Police was under the in-charge of the Commissioner of
Police, under whom, a Deputy Commissioner assisted by an Assistant Commissioner were in office.
71. Thereafter, in the year 2005, the said Central Office of the Crime Department, Madras City
Police, ie., the Central Crime Branch, called as CCB, Chennai, has been further strengthened by
deployment of more officers and staffs. Though one Assistant Commissioner was declared as an
officer in-charge of the Station for CCB in the year 1929, since the said CCB was expanded, number
of officers had been deployed. Hence, such officers ie., Assistant Commissioners, whatever number
may be, certainly be the officers in-charge of a police station and in that context every Assistant
Commissioner of the CCB will be the officer in-charge of the police station under Section 2(o) of the
Code.
72. Therefore, if at all direction is to be given by a Magistrate invoking Section 156(3) of the Code to
the CCB, Chennai, such direction can be given to the concerned Assistant Commissioner in-charge
of the CCB, who would be investigating the complaint.
73. In this case, since the petitioner had already given complaint to the Commissioner, who had
forwarded the same to the Inspector of Police for investigation, the legal requirement to approach
first the investigating agency ie., the police, has already been complied with by the
complainant/petitioner within the meaning of Section 154 of the Code and therefore, the petitioner
has satisfied the mandatory formalities as directed by the Hon'ble Apex Court in Priyanka's case.D.Ramesh vs V.Vijayakumar on 31 July, 2018

74. Therefore, for the alleged non compliance of Section 154 of the Code shall not be attributed to
the case of the petitioner herein and therefore, on that ground ie., the second ground mainly quoted
by the learned Magistrate, the petition should not have been dismissed.
75. Insofar as the second case is concerned, apart from these two reasons, a third reason has been
given by the learned Magistrate in the said impugned order, which is assailed in the second revision
that, the petitioner in support of the petition had not filed an affidavit, which is also mandated in
Priyanka's case. No doubt, in Paragraph 30 of the Priyanka's case, the Apex Court has clearly
mandated that, under Section 156(3) of the Code, the applications are to be supported by an
affidavit duly sworn by the applicant, who seeks the invocation of the jurisdiction of the Magistrate.
76. In the second case, admittedly, no affidavit was filed. Therefore, the petitioner therein had not
complied with the said mandatory direction given by the Apex Court in Priyanka's case. Hence, the
third ground or reason cited by the learned Magistrate for dismissing the said petition, can be
sustained.
77. Even in respect of the second case, the first two grounds, namely, the CCB is not a police station
nor the officer in-charge is not the officer in-charge of a police station within the meaning of
Sections 2(s) and 2(o) of the Code and also the ground that the petitioner did not approach the
police/investigating agency having jurisdiction over the issue by way of supplying information either
orally or in writing within the meaning of Section 154 of the Code, cannot be accepted, as the first
two grounds, since have been satisfied by both the petitioners in both the revision cases, on those
grounds, the petitions ought not to have been rejected.
78. The learned Magistrate has given one more reason as an off shoot of the main ground for
rejection of the petition in the following terms:
8.Further, the G.O. issued for the constitution of this Court itself would show that
this Court has been established for the exclusive trial of CCB cases (relating to
cheating cases in Chennai) and CBCID Metro Cases. It means, this Court is having
jurisdiction only to conduct trial in cheating related cases dealt by CCB, Chennai, or
the cases handled by CBCID Metro wing. Whereas, the present petition is private
complaint in nature, which cannot be construed as a CCB case (relating to cheating
case in Chennai) simply because of the reason that the petitioner requested to direct
the CCB, Chennai to investigate in the matter of the CCB, Chennai has been made as
respondent in the petition. The case is also not in trial stage. It is also to be pointed
out the basic principle is that a party cannot be permitted to opt the investigation
officer at his wish and whims.
79. In this context, the relevant G.O., under which the said Court was constituted can also be looked
into.
80. Government issued G.O.Ms.No.242 Home Courts II Department dated 15.03.2012, which reads
thus:D.Ramesh vs V.Vijayakumar on 31 July, 2018

.The Government have examined the proposal of the Registrar General, High
Court of Madras carefully and decided to accept it. Accordingly, sanction is accorded
for the constitution of a new Court in the cadre of Civil Judge (Senior Division) in
Chennai for exclusive trial of Central Crime Branch cases (relating to cheating cases
in Chennai) and Crime Branch Criminal investigation Department Metro Cases in
Chennai. Sanction is also accorded for creation of the following staff to the above
Court at a recurring expenditure of Rs.41,76,000/- under salaries. They are eligible to
draw pay and allowances under the rules in force from time to time.
81. Pursuant to the above, the Government issued G.O. (Ms.) No.522, Home (Courts II) Department
dated 17.07.2013 which reads as under:
Under sub-section (1) of Section 16 of the Code of Criminal Procedure, 1973,
(Central Act 2 of 1974), the Governor of Tamil Nadu, after consultation with the High
Court, Madras, hereby establishes a Court of Metropolitan Magistrate in the cadre of
Senior Civil Judge at Chennai for the exclusive trial of Central Crime Branch cases
relating to cheating and Crime Branch Criminal Investigation Department Metro
Cases.
82. The aforesaid Government Order has fathered the Court of Metropolitan Magistrate for the
exclusive trial of CCB/CB-CID cases. This Court has been established under Section 16 Cr.P.C. which
reads as under:
6 Courts of Metropolitan Magistrates:
1) In every metropolitan area, there shall be established as many Courts of
Metropolitan Magistrates, and at such places, as the State Government may, after
consultation with the High Court, by notification, specify.
2) The presiding officers of such Courts shall be appointed by the High Court.
3) The jurisdiction and powers of every Metropolitan Magistrate shall extend
throughout the metropolitan area.
83. The judicial officer manning this Court has not been conferred with special powers under
Section 18 of the Code. Thus, the Magistrate for CCB/CB-CID cases is yet another Metropolitan
Magistrate subordinate to the Chief Metropolitan Magistrate. Under Section 19(3) of the Code, the
Chief Metropolitan Magistrate has the power to distribute business amongst the Metropolitan
Magistrates. By virtue of the powers under Section 19(3) of the Code, the Chief Metropolitan
Magistrate has issued office orders, from time to time, assigning some Magistrates with certain
specific businesses. For instance, in Egmore, the VI Metropolitan Magistrate has been assigned the
task of dealing with Railway Protection Force cases. The jurisdiction of the Magistrate for
CCB/CB-CID Cases extends throughout the metropolitan area by virtue of Section 16 (3) Cr.P.C.
This territorial jurisdiction appears to be co-extensive with the territorial jurisdiction of the CentralD.Ramesh vs V.Vijayakumar on 31 July, 2018

Crime Branch. Just because, in G.O (Ms.) No.522, Home (Courts II) Department dated 17.07.2013,
the expression trial has been used, it does not mean that the said Magistrate does not have the
power to remand the accused or take cognizance under Section 190 Cr.P.C. When once he has the
power to take cognizance on the final report filed by the Central Crime Branch, he would
automatically have the power under Section 156(3) Cr.P.C. to order investigation.
84. When a particular Court has been constituted by the Government under the relevant provisions
of law by issuance of executive order, where the Court is entrusted with exclusive jurisdiction to try
particular type of cases, the said Court alone will have jurisdiction to try those cases. Here, in the
case in hand, the learned Magistrate Court was constituted to try cases being investigated by the
Central Crime Branch, (relating to cheating cases in Chennai) and Crime Branch Criminal
Investigation Department, Metro Cases in Chennai. With regard to these two type of cases, we have
no quarrel. With regard to CBCID Metro Cases in Chennai are concerned, as those two revision
cases are not falling under that category, these two cases, whether to be investigated by the CCB,
Chennai or by the regular police station is concerned, in view of the standing orders issued by the
Government, the crime involving more than the value of Rs.50 lakhs is to be investigated only by the
CCB, Chennai, such type of cases are taken up for investigation by the CCB, Chennai. Unless some
type of cases are investigated by the CCB, Chennai, the purpose of constituting the special Court ie.,
the present Magistrate Court under G.O.Ms.No.242 dated 15.03.2012 would be defeated.
85. The Special Court was constituted only for the exclusive trial of CCB cases as well as CBCID
cases. If particular category of cases are exclusively to be investigated only by CCB, Chennai, and in
such cases, if the CCB, Chennai has not investigated in spite of the information given by the
complainant/petitioner before the police officer concerned, certainly, such complainant/petitioner
shall be entitled to invoke the power vest with the Magistrate concerned under Section 156(3) of the
Code. Here, in the case in hand, such power to exercise under sub section 3 of Section 156 of the
Code, insofar as the cases to be investigated by the CCB are concerned, is vest only with the Special
Magistrate Court constituted under G.O.Ms.No.242.
86. When such being the position, the learned Magistrate cannot shirk his responsibility and state
that, his Court has been constituted for the purpose of exclusive trial of CCB cases and CBCID cases
and therefore, merely because a petition was filed before the said Court seeking direction to the
CCB, it cannot be construed as a case to be investigated by the CCB. Hence, such refusal to give
direction by the said Magistrate Court is absolutely unjustifiable, because, when an exclusive Court
is constituted, there must be source of litigation to that Court, where the jurisdiction will play a
major role.
87. Here, in the case in hand, the jurisdiction of the CCB, even according to the 1929 document, is
the city of Madras including all places within the local limits of the ordinary original jurisdiction of
the High Court of Judicature at Madras. If that being so, the entire City jurisdiction within the
original jurisdiction being exercised by the High Court of Judicature at Madras, shall be the
jurisdiction for the purpose of investigating cases by the CCB, Chennai.D.Ramesh vs V.Vijayakumar on 31 July, 2018

88. Therefore, the present Magistrate Court empowered to try cases investigated by CCB, Chennai,
will have the jurisdiction to give direction to the CCB, Chennai, even under Section 156(3) of the
Code, as, for such a relief, the litigant, who approached the CCB for investigation, cannot approach
any other regular Magistrate, as jurisdiction of CCB cases has been specifically mentioned and has
been entrusted to the Special Court constituted in this regard.
89. Therefore, the learned Magistrate ought not to have stated that he is the Judge of the said cases
to be tried from CCB Chennai and CBCID Chennai and therefore, he cannot give direction to the
CCB, Chennai. Such a stand will be contradictory as the learned Magistrate is empowered to
investigate only the CCB, Chennai and CBCID, Chennai cases and not any other cases. Therefore,
that additional reason also, as has been given by the learned Magistrate to reject the petition, is
untenable and therefore, the same is rejected.
90. Insofar as the cases of CBCID is concerned, since CBCID is investigating the cases on the orders
of the Supreme Court, High Court, Government and Director General of Police, it is a specialized
wing or elite force within the police department and therefore, for investigation of such kind of
cases, the learned Special Magistrate trying the cases of the CBCID is not empowered to give
direction under Section 156(3) of the Code. I am in complete agreement with the judgment of the
learned Judge of this Court made in Crl.O.P.No.9542 of 2015 and Crl.R.C.No.496/2015 in the
matter of S.Madhiyazhagan v. State rep. by the Inspector of Police. However, the said reasonings,
insofar as CBCID cases, given by the learned Judge would not be applicable to the cases to be
investigated or handled by the CCB, Chennai.
91. The birth of the CCB, Chennai has been traced now, as it has come into play from 1929 with a
proper sanction of the then Madras Presidency Governor in Council and it has already been declared
as a police station within the meaning of Section 2(s) of the Code and the Assistant Commissioner in
charge of the CCB has been declared as the officer in-charge of the police station within the meaning
of Section 2(o) of the Code. In this respect, the CCB, Chennai cannot be compared with CBCID.
92. Having regard to the aforesaid aspects by taking into account the overall scenario of the issue
raised in this case and after having gone through the various materials placed before this Court and
having considered the law declared by the Courts of law and also the authoritative pronouncements
of the Hon'ble Apex Court, especially, in Priyanka's case, this Court is of the considered view that,
the first two reasonings given by the learned Magistrate for dismissal of the petitions through the
impugned orders are unsustainable.
93. Insofar as the second case is concerned, the reason that the said petitioner had not filed any
affidavit as mandated by the Apex Court in Priyanka's case is concerned, the said reason is
sustainable and therefore, for that reason, the dismissal of the second petition, which is the subject
matter of Crl.R.C.No.541/2017, is to be accepted.
94. For the sake of clarity and for action in future, insofar as CCB, Chennai City, is concerned and
also the Special Court constituted in this regard to try exclusively the cases to be investigated by the
CCB, Chennai, the following declarations and directions are issued:D.Ramesh vs V.Vijayakumar on 31 July, 2018

(a) Central Crime Branch, Chennai City police is a police station within the meaning
of Section 2(s) of the Code of Criminal Procedure ;
(b) All Assistant Commissioners of Police employed or pressed into service in Central
Crime Branch, Chennai City, are officers in-charge of the police station within the
meaning of Section 2(o) of the Code.
(c) If the Officer in-charge ie., the Assistant Commissioner of CCB refused to
entertain/receive such complaint, the aggrieved complainant can approach the
Deputy Commissioner of Police, CCB, under Section 154(3) of the Code.
(d) Before invocation of Section 156(3) of the Code, the complainant/petitioner must
have complied with the procedure contemplated under Section 154 (1) and (3) of the
Code ;
(e) A petition filed before the Court for invocation of Section 156(3) of the Code must
be accompanied with an affidavit duly sworn in by such complainant/petitioner,
without which, such petition shall not be entertained;
(f) The Court of Metropolitan Magistrate for exclusive trial of CCB Cases (relating to
cheating cases in Chennai) and CBCID Metro Cases, Chennai constituted under
G.O.Ms.No.242, Home (Courts II) Department dated 15.03.2012 shall be the
exclusive Court only for the cases entrusted or investigated by CCB, Chennai and
CBCID, Metro cases, Chennai. The jurisdiction for the said Court insofar as the CCB
Cases are concerned, to the whole of Chennai City within the ordinary original
jurisdiction of the Madras High Court;
(g) Since the Metropolitan Magistrate Court for exclusive trial of CCB and CBCID
Cases is the special Court to try those two category of cases, such Magistrate shall be
the Magistrate for exercising power under Section 156(3) of the Code to give suitable
directions to the officers in-charge at CCB, Chennai. If any such direction is given by
the Magistrate, CCB cases, Chennai, invoking Section 156(3) of the Code, such
investigation shall be undertaken by any one of the Assistant Commissioner of Police
employing or in-charge of CCB, Chennai and such investigation shall be undertaken
only by such Assistant Commissioner, who will be assisted by other lower level
officers ;
(h) The aforesaid directions shall be scrupulously followed by the said Special
Magistrate and all the stake holders of CCB, Chennai and the litigant public;
95. In view of the aforesaid declarations and directions, the rejection order made in, by the learned
Magistrate, through the impugned order dated 25.01.2017 in Crl.M.P.No.107/2017, is set aside and
the matter is remitted back to the learned Magistrate for reconsideration under Section 156(3) of the
Code and the Magistrate is directed to pass necessary orders on merits of the said petition filed byD.Ramesh vs V.Vijayakumar on 31 July, 2018

the petitioner herein within a period of two months from the date of receipt of a copy of this order.
96. To that extent, Crl.R.C.No.271/2017 is allowed.
97. Insofar as the impugned order made in Crl.M.P.No.1182/2016 dated 25.01.2017 by the learned
Magistrate is concerned, the said order, except giving the reason of non filing of affidavit to support
the petition, for all other reasons is set aside. Since the petitioner in that case, admittedly, has not
filed any supporting affidavit to the petition, the said petition cannot be entertained and therefore,
in that aspect, the order of the learned Magistrate is upheld. However, it is open to the petitioner to
resubmit the petition with supporting affidavit by scrupulous compliance of the mandate of the
Hon'ble Apex Court in Priyanka's case reported in [(2015) 6 SCC 287].
98. To that extent indicated above, the Crl.R.C.No.541/2017 is ordered accordingly.
31.07.2018 Index : Yes Internet : Yes RR / smi To
1.The Metropolitan Magistrate for Exclusive Trial of CCB Cases, (Relating to cheating cases in
Chennai) and CBCID, Metro cases, Chennai
2.The Commissioner of Police, Egmore, Chennai
3.The Sub Inspector of Police, Central Crime Branch Team XVII  A Chennai.
4.The Public Prosecutor, Madras High Court, Madras.
R.SURESH KUMAR,J., RR / smi Orders made in Crl.R.C.Nos.271 of 2017 and 541 of 2017
31.07.2018D.Ramesh vs V.Vijayakumar on 31 July, 2018

