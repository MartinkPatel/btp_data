Faritha Begam vs The State Of Tamil Nadu on 17 July, 2023
Author: M.Sundar
Bench: M.Sundar
                                                                                      H.C.P.No.102 of 2023
                                    IN THE HIGH COURT OF JUDICATURE AT MADRAS
                                                      DATED: 17.07.2023
                                                             Coram
                                      THE HONOURABLE MR.JUSTICE M.SUNDAR
                                                     and
                                     THE HONOURABLE MR.JUSTICE R.SAKTHIVEL
                                                     H.C.P.No.102 of 2023
                     Faritha Begam                                                        .. Petitioner
                                                                vs
                     1.The State of Tamil Nadu
                       Rep. by Secretary to Government,
                       Prohibition and Excise Department,
                       Fort St.George, Chennai – 600 009.
                     2.The Commissioner of Police
                       Tambaram City
                       Office of the Commissioner of Police
                       (Goondas Section)
                        Sholinganallur
                       Chennai – 600 119
                     3. The Superintendent of Police
                        Central Prison, Puzhal
                     4. The Inspector of Police
                        T-10, Manimangalam Police Station
                        Chennai                                            .. Respondents
                                  Petition filed under Article 226 of the Constitution of India praying
                     for issuance of a writ of habeas corpus call for the records relating to the
https://www.mhc.tn.gov.in/judis
                     1/9
                                                                                      H.C.P.No.102 of 2023Faritha Begam vs The State Of Tamil Nadu on 17 July, 2023

                     detention order dated 28.12.2022 passed by the second respondent in
                     B.C.D.F.G.I.S.S.S.V.No.218 of 2022 and quash the same and direct the
                     respondents herein to produce the petitioner's son Mohamed Sadam
                     Hussan, son of Mohamed Haniffa, aged 25 years, who is presently
                     undergoing detention in the Central Prison, Puzhal before this Court and
                     set him at liberty forthwith.
                                  For Petitioner             :      Mr.M.Vetrivel
                                                                    for Mr.P.Chandra Sekar
                                  For Respondents            :      Mr.E.Raj Thilak,
                                                                    Additional Public Prosecutor
                                                              ORDER
[Order of the Court was made by M.SUNDAR, J.] When the captioned 'Habeas Corpus Petition'
[hereinafter 'HCP' for the sake of convenience and clarity] was listed in the Admission Board on
24.01.2023, this Court made the following order:
' Captioned Habeas Corpus Petition has been filed in this Court on 11.01.2023 inter
alia assailing a detention order dated 28.12.2022 bearing reference BCDFGISSSV
No.218/2022 made by 'second respondent' [hereinafter 'Detaining Authority' for the
sake of convenience and clarity]. To be noted, fourth respondent is the Sponsoring
Authority.
2. Mother of the detenu is the petitioner.
3. Ms.M.Udayarani, learned counsel representing the
https://www.mhc.tn.gov.in/judis counsel on record for habeas corpus petitioner is
before us.
Learned counsel for petitioner submits that ground case qua the detenu is for alleged offences under
Sections 147, 148, 341, 294(b), 307, 302 of IPC and Sections 3 and 4(a) of Explosive Substances Act,
1908 in Crime No.369 of 2022 on the file of T-10 Manimangalam Police Station.
4. The aforementioned detention order has been made on the premise that the detenu is a 'Goonda'
under Section 2(f) of 'The Tamil Nadu Prevention of Dangerous Activities of Bootleggers, Cyber law
offenders, Drug-offenders, Forest- offenders, Goondas, Immoral traffic offenders, Sand- offenders,
Sexual-offenders, Slum-grabbers and Video Pirates Act, 1982 (Tamil Nadu Act No.14 of 1982)'
[hereinafter 'Act 14 of 1982' for the sake of convenience and clarity].
5. The detention order has been assailed inter alia on the ground that the copy of grounds of
detention in English was not properly translated in Tamil, which prevented the detenu from making
effective representation against the detention order.
6. Prima facie case made out for admission. Admit. Issue Rule nisi returnable by four weeks.Faritha Begam vs The State Of Tamil Nadu on 17 July, 2023

7. Mr.R.Muniyapparaj, learned Additional Public Prosecutor, State of Tamil Nadu accepts notice for
all respondents. Registry to tag H.C.P.Nos.89, 90 and 101 of 2023 along with this Habeas Corpus
Petition and list accordingly.' https://www.mhc.tn.gov.in/judis https://www.mhc.tn.gov.in/judis
2. The aforementioned order made in the 24.01.2023 Admission listing shall be read as an integral
part and parcel of this order which means that the short forms, short references and abbreviations
used in the order in the Admission listing shall be used in the instant order also.
3. There is no adverse case. The solitary case which is the sole substratum of the impugned
preventive detention order is Crime No.369 of 2022 on the file of T-10, Manimangalam Police
Station for alleged offences under Sections 147, 148, 341, 294(b), 307, 302 IPC and Sections 3 and
4(a) of Explosive Substances Act, 1908. Owing to the nature of the challenge to the impugned
preventive detention order, it is not necessary to delve into the factual matrix or be detained further
by facts.
4. Mr.M.Vetrivel, learned counsel representing the counsel on record for petitioner and Mr.E.Raj
Thilak, learned State Additional Public Prosecutor for all respondents are before us.
5. At the time of admission i.e., in the Admission Board, the point that copy of grounds of detention
in English was not properly translated in Tamil impairing the detenu's right to make an effective
representation against the impugned preventive detention order was raised but in the final hearing
today learned counsel posited his argument on the point https://www.mhc.tn.gov.in/judis that
subjective satisfaction arrived at by the Detaining Authority as regards imminent possibility of
detenu being enlarged on bail is impaired.
Elaborating on this argument, learned counsel drew our attention to a portion of paragraph No.3 of
the impugned preventive detention order and that part of paragraph No.3 which is relevant for this
point reads as follows:
'3...... However it is pertinent to note that in a similar case, registered at Kundrathur
P.S. Cr.No.825/2021 u/s. 147, 148, 294(b), 201, 212, 364, 302 IPC, bail was granted
to the accused Hussain Sherif @ Sharuk Hussain by the Judicial Magistrate,
Sriperumbudur vide C.M.P.No.81 of 2021 on 28.01.2021. Hence, I infer that there is a
real possibility of his coming out on bail by filing a petition in T-10 Manimangalam
Police Station Cr.No.369 of 2022 since in the similarly placed cases, bails were
granted by the courts after a lapse of time.............' (To be noted, in the grounds of
detention the case number and date have been wrongly mentioned as C.M.P.No.81 of
2021 on 28.01.2021 instead of C.M.P.No.81 of 2022 on 28.01.2022).
The aforementioned bail order in Hussain Sherif's case has been furnished to the
detenu in the booklet and the same is at Page Nos.371 to
375. A careful perusal of this Hussain Sherif's case bail order brings to
https://www.mhc.tn.gov.in/judis light that it is a case of default bail under SectionFaritha Begam vs The State Of Tamil Nadu on 17 July, 2023

167(2) of the 'Code of Criminal Procedure, 1973 (2 of 1974)' ['Cr.P.C' for the sake of
brevity].
Therefore, relying on Hussain Sherif's case as a benchmark to arrive at subjective satisfaction qua
imminent possibility of detenu being enlarged on bail is clearly flawed and the consequence is,
impugned preventive detention order deserves to be dislodged.
6. Ergo, the sequitur is, captioned HCP is allowed. Impugned detention order dated 28.12.2022
bearing reference BCDFGISSSV No.218/2022 made by the second respondent is set aside and the
detenu Thiru.M.Mohamed Sadam Hussain, aged 25 years, son of Thiru.Mohamed Haniffa, is
directed to be set at liberty forthwith, if not required in connection with any other case / cases.
There shall be no order as to costs.
(M.S.,J.) (R.S.V.,J.) 17.07.2023 Index : Yes Neutral Citation : Yes gpa P.S: Registry to forthwith
communicate this order to Jail authorities in Central Prison, Puzhal.
https://www.mhc.tn.gov.in/judis To
1. The Secretary to Government, Prohibition and Excise Department, Fort St.George, Chennai – 600
009.
2.The Commissioner of Police Tambaram City Office of the Commissioner of Police (Goondas
Section) Sholinganallur Chennai – 600 119
3. The Superintendent of Police Central Prison, Puzhal
4. The Inspector of Police T-10, Manimangalam Police Station Chennai
5.The Public Prosecutor, High Court, Madras.
https://www.mhc.tn.gov.in/judis M.SUNDAR, J., and R.SAKTHIVEL , J., gpa 17.07.2023
https://www.mhc.tn.gov.in/judisFaritha Begam vs The State Of Tamil Nadu on 17 July, 2023

