Dabur India Limited vs Ashok Kumar And Ors on 14 September,
2022
Author: Prathiba M. Singh
Bench: Prathiba M. Singh
                          $~54, 25 to 53
                          *      IN THE HIGH COURT OF DELHI AT NEW DELHI
                                                                   Date of Decision: 14th September, 2022
                          +        CS (COMM) 135/2022 & I.As. 3423/2022, 9363/2022
                               DABUR INDIA LIMITED                                  ..... Plaintiff
                                             Through: Mr. Anirudh Bakhru, and Mr. Kripa
                                                        Pandi, Advocates. (M:9810013453)
                                             versus
                               ASHOK KUMAR AND ORS                         ..... Defendant
                                             Through: Mr. Moazzam Khan, Advocate for D-
                                                        1. (M:9987113749)
                                                        Ms. Kruttika Vijay & Ms. Aishwarya
                                                        Kane, Advs. for D-5 (M-9910083144)
                                                        Mr. K.G. Gopalakrishnan and Ms.
                                                        Nisha Mohandas, Advocates for D-7.
                                                        (M:8800556341)
                                                        Mr. Darpan Wadhwa, Sr. Advocate
                                                        with Mr. Alipak K. Banerjee, and Ms.
                                                        Shweta Sahu, Advs. for D-4 & 15.
                                                        Mr. Harish V. Shankar, CGSC with
                                                        Mr. Srish Kumar Mishra, Mr. Sagar
                                                        Mehlawat & Mr. Alexander Mathai
                                                        Paikaday, Advocates.
                                                        Ms. Hetu Arora Sethi, ASC, GNCTD
                                                        with Mr. Arjun Basra, Mr. Raman
                                                        Lamba, ACP, Cyber Cell along with
                                                        Mr. Sumeet Siddhu, IO.
                                                        ACP Raman Lamba with Insp. Suneel
                                                        Siddhu, IFSO, Special Cell.
                          (25)                      WITH
                          +        CS (COMM) 20/2019 I.A.561/2019
                               TATA SKY LIMITED                                   ..... Plaintiff
                                             Through: Mr. J. Sai Deepak, Ms. Priya
                                                        Adlakha, Mrs. Bindra Rana, Ms.
                                                        Tanvi     Bhatnagar,       Ms.       Rima
                                                        Majumdar and Ms. Shilpi Sinha,
                                                        Advocates. (M:9818202368)
                          CS (COMM) 135/2022 & connected matters                                Page 1 of 43
Signature Not Verified
Digitally Signed
By:DEVANSHU JOSHI
Signing Date:15.09.2022Dabur India Limited vs Ashok Kumar And Ors on 14 September, 2022

16:50:14
                                                                    Ms. Akshita Jain, Advocate for D-
                                                                   8/NIXI.
                                               versus
                               S G ENTERPREISES - TATA SKY SALES AND SERVICES AND
                               ORS.                                         ..... Defendants
                                               Through: Ms. Shweta Sahu, Adv. for D-5.
                          (30)                 WITH
                          +    CS (COMM) 35/2022 I.As. 819/2022, 3168/2022, 4738/2022,
                               8767/2022
                               KAJARIA CERAMICS LIMITED                             ..... Plaintiff
                                               Through: Mr. J. Sai Deepak, Ms. Priya
                                                         Adlakha, Mrs. Bindra Rana, Ms.
                                                         Tanvi     Bhatnagar,      Ms.       Rima
                                                         Majumdar and Ms. Shilpi Sinha,
                                                         Advocates. (M:9818202368)
                                               versus
                               GODADDY.COM LLC & ORS.                       ..... Defendant
                                         Through:       Mr. Ashwani Kumar, Adv. for D2.
                                                         Ms. Shweta Sahu and Mr. Alipak
                                                         Banerjee, Advs
                                                         Ms. Kirti Bhardwaj, Adv. for D-5(b).
                                                         Mr. M.K. Singh, Advocate for Mr.
                                                         Samir, Advocate (M-9810455716)
                          (28)                 WITH
                          +    CS (COMM) 176/2021 & I.As. 14924/2022, 14925/2022
                               SNAPDEAL PRIVATE LIMITED                             ..... Plaintiff
                                               Through: Ms. Tanya Varma & Ms. Devyani
                                                         Nath, Advocates. (M:7042547106)
                                               versus
                               GODADDYCOM LLC AND ORS                       ..... Defendants
                                               Through: Mr. Dayan Krishnan, Sr. Advocate
                                                         with Ms. Shweta Sahu and Mr.
                                                         Alipak Banerjee, Advs, for D-
                                                         2,3,4,23,26,31. (M:9987115749)
                                                         Mr. Darpan Wadhwa, Sr. Advocate
                                                         with Mr. Moazzam Khan, Mr. Alipak
                                                         Banerjee and Ms. Shweta Sahu,
                                                         Advocates for D-1 & 10.
                          CS (COMM) 135/2022 & connected matters                            Page 2 of 43
Signature Not Verified
Digitally Signed
By:DEVANSHU JOSHI
Signing Date:15.09.2022
16:50:14
                                                                    Ms. Kruttika Vijay and Ms.
                                                                   Aishwarya Kane, Advocates for D-9.
                                                                   (M:9910083144)
                                                                   Mr. Praveen Kumar Jain & Ms.
                                                                   Shalini    Jha,    for       D-34.
                                                                   (M:9871278525)Dabur India Limited vs Ashok Kumar And Ors on 14 September, 2022

                          (29)                  WITH
                          +    CS (COMM) 228/2021 & I.As.1412-13/2022, 12160/2022,
                               12171/2022, 14920/2022, 14923/2022, 14927/2022, 14928/2022
                                 BAJAJ FINANCE LIMITED                                    ..... Plaintiff
                                               Through:            Mr. Abhishek Singh, Mr. Jamal
                                                                   Anand, Mr. Elvin Joshy, Ms. Alisha
                                                                   Sharma & Mr. Ujjwal.
                                              versus
                                 REGISTRANT OF WWW.BAJAJ-FINSERVE.ORG
                                 & ORS.                                  ..... Defendants
                                              Through: Ms. Shweta Sahu and Mr. Alipak
                                                       Banerjee, Advocates for D-18
                                                       (M:9987115749).
                                                       Mr. Manish Paliwal, Mr. Vikas
                                                       Kumar & Ms. Lanutula Karanur,
                                                       Advocates for D-18.
                                                       Mr. Akhil Sibal, Sr. Advocate with
                                                       Mr. Aditya Gupta, Ms. Aishwarya,
                                                       Mr. Sauhard Alung and Ms. Asvari
                                                       Jain,    Advocates       for    D-19.
                                                       (M:9910083144)
                                                       Mr. Rajshekhar Rao, Sr. Advocate
                                                       with Mr. Tine Abraham, Mr. Manasa
                                                       Sundaraman C., Ms. Kshipra Pyare
                                                       and Ms. Mansi Sood Trileyal,
                                                       Advocates for D-28. (M:9324328752)
                                                       Mr. Ashok Kumar & Ms. Chhavi
                                                       Arora,    Advocates       for   D-31.
                                                       (M:9810011826).
                                                       Ms. Hetu Arora Sethi, ASC, GNCTD
                                                       with Mr. Arjun Basra, Mr. Raman
                          CS (COMM) 135/2022 & connected matters                                Page 3 of 43
Signature Not Verified
Digitally Signed
By:DEVANSHU JOSHI
Signing Date:15.09.2022
16:50:14
                                                                    Lamba, ACP, Cyber Cell along with
                                                                   Mr. Sumeet Siddhu, IO
                          (47)               WITH
                          +        CS (COMM) 26/2022 & I.As. 612-13/2022, 954/2022
                               HT MEDIA LTD                                        ..... Plaintiff
                                             Through: Mr. Sidharth Chopra, Mr. Nitin
                                                       Sharma, Mr. Yatin Garg, Mr. Ranjeet
                                                       Singh, Mr. Vivek Ayyagari, Mr.
                                                       Angad Makkar, Mr. M. J. Sudarshan,
                                                       Ms. Ramya Aggarwal and Mr. Sohrab
                                                       Mann, Advocates. (M:8017571175)
                                             versus
                               POOJA SHARMA & ORS.                        ..... DefendantsDabur India Limited vs Ashok Kumar And Ors on 14 September, 2022

                                             Through: Ms. Deepika Kathuria, Adv. for D-10.
                                                       Mr. Alipak Banerjee, Ms. Shweta
                                                       Sahu, Mr. Brijesh Ujjainwal, and
                                                       Advs. for D-19. (M:9987115749)
                                                       Mr. Vihan Dang, Ms. Aditi Umapathy
                                                       and Mr. Parva Khare, Advocates for
                                                       D-20. (M:9911983636).
                                                       Mr. M.K. Singh, Advocate for Mr.
                                                       Samir Chugh, Advocate for Airtel.
                          (48)               WITH
                          +        CS (COMM) 158/2022 & I.As. 3996-97/2022
                               MICROSOFT CORPORATION & ANR.               ..... Plaintiff
                                             Through: Mr. Pravin Anand, Mr. Saif Khan,
                                                       Mr. Shantanu Sahay, Ms. Imon Roy
                                                       and Mr. Apoorv Bansal, Advocates.
                                             versus
                               VACATION RENTAL SERVICES PRIVATE LIMITED
                               & ORS.                                     ..... Defendants
                                             Through: Mr. Ramnish Khanna, Adv. for D-7.
                                                       SI Manzoor Alam, Cyber Police
                                                       Station, South-East.
                          (49)               WITH
                          +        CS (COMM) 233/2022 & I.As. 5780-81/2022
                               BAJAJ FINACE LTD & ANR.                    ..... Plaintiffs
                                             Through: Mr. Sidharth Chopra, Mr. Nitin
                          CS (COMM) 135/2022 & connected matters                            Page 4 of 43
Signature Not Verified
Digitally Signed
By:DEVANSHU JOSHI
Signing Date:15.09.2022
16:50:14
                                                                    Sharma, Mr. Yatin Garg, Mr. Ranjeet
                                                                   Singh, Mr. Vivek Ayyagari, Mr.
                                                                   Angad Makkar, Mr. M. J. Sudarshan,
                                                                   Ms. Ramya Aggarwal and Mr. Sohrab
                                                                   Mann, Advocates.
                                              versus
                                 NIKO DAS & ANR.                                    ..... Defendants
                                              Through:             Mr. Vihan Dang, Ms. Aditi Umapathy
                                                                   and Mr. Parva Khare, Advocates for
                                                                   D-3.
                                                                   Mr. M.K. Singh, Advocate for Mr.
                                                                   Samir Chugh, Advocate for Airtel.
                          (50)                 WITH
                          +          CS (COMM) 275/2022 & I.As. 6535-36/2022
                                 HINDUSTAN UNILEVER LTD & ANR.             ..... Plaintiffs
                                               Through: Mr. Sidharth Chopra, Mr. Nitin
                                                         Sharma, Mr. Yatin Garg, Mr. Ranjeet
                                                         Singh, Mr. Vivek Ayyagari, Mr.
                                                         Angad Makkar, Mr. M. J. Sudarshan,
                                                         Ms. Ramya Aggarwal and Mr. SohrabDabur India Limited vs Ashok Kumar And Ors on 14 September, 2022

                                                         Mann, Advocates.
                                               versus
                                 UNILEVERR1.IN & ORS.                      ..... Defendants
                                               Through: Ms. Deepika Kathuria, Adv. for D-9.
                                                         Mr. S. Surender, Advocate for D-21.
                                                         Ms. Asiya Khan, Advocate for D-25
                                                         Mr. M.K. Singh, Advocate for Mr.
                                                         Samir Chugh, Advocate for Airtel.
                          (51)               WITH
                          +          CS (COMM) 364/2022 & I.As. 8518-20/2022, 12855/2022
                                 AMAZON SELLER SERVICES PRIVATE LIMITED
                                 & ANR.                                   ..... Plaintiffs
                                             Through: Mr. Sidharth Chopra, Mr. Nitin
                                                         Sharma, Mr. Yatin Garg, Mr. Ranjeet
                                                         Singh, Mr. Vivek Ayyagari, Mr.
                                                         Angad Makkar, Mr. M. J. Sudarshan,
                                                         Ms. Ramya Aggarwal and Mr. Sohrab
                          CS (COMM) 135/2022 & connected matters                             Page 5 of 43
Signature Not Verified
Digitally Signed
By:DEVANSHU JOSHI
Signing Date:15.09.2022
16:50:14
                                                                    Mann, Advocates.
                                             versus
                                 AMAZONBUYS.IN & ORS.                               ..... Defendants
                                             Through:              Mr. Sharique Hussain, Advocate for
                                                                   D-5. (M:9540535859).
                                                                   Ms. Mrinal Ojha, Mr. Debarshi Dutta
                                                                   & Mr. Aayush Kevlani, Advocates for
                                                                   D-8 (M-9167094381)
                                                                   Ms. Deepika Kathuria, Adv. for D-10.
                                                                   Mr. Vineet Dhanda, CGSC with Mr.
                                                                   Abhishek Singh, Advocate for
                                                                   UOI/D-18 & 19.
                                                                   Mr. M.K. Singh, Advocate for Mr.
                                                                   Samir Chugh, Advocate for Airtel.
                          (52)               WITH
                          +    CS (COMM) 475/2022 & I.As. 10851-52/2022, 12173-74/2022
                               FASHNEAR TECHNOLOGIES PRIVATE LIMITED ..... Plaintiff
                                             Through: Mr. Sidharth Chopra, Mr. Nitin
                                                         Sharma, Mr. Yatin Garg, Mr. Ranjeet
                                                         Singh, Mr. Vivek Ayyagari, Mr.
                                                         Angad Makkar, Mr. M. J. Sudarshan,
                                                         Ms. Ramya Aggarwal and Mr. Sohrab
                                                         Mann, Advocates.
                                             versus
                               MEESHO ONLINE SHOPPING PVT. LTD.
                               & ANR.                                       ..... Defendants
                                             Through: Ms. Hetu Arora Sethi, ASC, DelhiDabur India Limited vs Ashok Kumar And Ors on 14 September, 2022

                                                         Police with Mr. Arjun Arora,
                                                         Advocate along with Mr. Raman
                                                         Lamba, ACP, IFSO, Special Cell and
                                                         Mr. Suneel Sidhir, Inspector.
                                                         Mr. Vihan Dang, Ms. Aditi Umapathy
                                                         and Mr. Parva Khare, Advs. for D-10.
                                                         Mr. Darpan Wadhwa, Sr. Advocate
                                                         with Mr. Alipak Banerjee, Mr.
                                                         Brijesh Ujjainwal & Ms. Shweta
                                                         Sahu, Advocate for D-7.
                                                         Mr. Anurag Ahluwalia, CGSC with
                          CS (COMM) 135/2022 & connected matters                              Page 6 of 43
Signature Not Verified
Digitally Signed
By:DEVANSHU JOSHI
Signing Date:15.09.2022
16:50:14
                                                                    Mr. Abhigyan Siddhant and Mr.
                                                                   Danish Faraz Khan, Advocates for D-
                                                                   19 & 20. (M:9999999045)
                                                                   Mr. K.R. Sasiprabhu and Mr. Tushar
                                                                   Bhardwaj, Advs for Reliance Jio.
                          (41)               WITH
                          +         CS (COMM) 95/2021 & I.A. 4800/2021
                               THE HIMALAYA DRUG COMPANY & ORS. ..... Plaintiffs
                                             Through: Mr. Pravin Anand, Ms. Prachi
                                                         Agarwal and Ms. Ms. Ridhie Bajaj,
                                                         Advocates. (M:8800972785)
                                             versus
                               ASHOK KUMAR & ORS.                          ..... Defendants
                                             Through: Mr. Tushar Singh & Ms. Trisha
                                                         Patnaik, Advocates for D-25.
                                                         Mr. Surinder Singh, Advocate for D-
                                                         29 (M-9311325398)
                          (42)               WITH
                          +    CS (COMM) 154/2021 & I.A. 4692/2021, 10905/2022
                               GODREJ PROPERTIES LTD                                 ..... Plaintiff
                                             Through: Mr. Pravin Anand, Mr. Vibhav Mithal
                                                         and Mr. Achyut Tiwari, Advocates.
                                                         (M:8447458389)
                                             versus
                               ASHOK KUMAR & ANR.                              ..... Defendants
                                             Through: Mr. Darpan Wadhwa, Sr. Advocate
                                                         with, Mr. Alipak Banerjee, & Ms.
                                                         Shweta Sahu, Advocates for D-2.
                                                         (M:9987115749)
                          (43)               WITH
                          +         CS (COMM) 276/2021 & I.A. 7329/2021
                               MICROSOFT CORPORATION & ANR.                ..... Plaintiffs
                                             Through: Mr. Pravin Anand, Mr. Saif Khan,
                                                         Mr. Shantanu Sahay, Ms. Imon RoyDabur India Limited vs Ashok Kumar And Ors on 14 September, 2022

                                                         and Mr. Apoorv Bansal, Advocates.
                                             versus
                               TECH HERACLES OPC PRIVATE LIMITED
                               & ORS.                                      ..... Defendants
                          CS (COMM) 135/2022 & connected matters                             Page 7 of 43
Signature Not Verified
Digitally Signed
By:DEVANSHU JOSHI
Signing Date:15.09.2022
16:50:14
                                                         Through: None.
                          (44)                                WITH
                          +    CS (COMM)                293/2021 & I.As.7543-44/2021,
                                                                                    10308/2021,
                               15052/2021
                               TATA SONS PRIVATE LIMITED & ANR.            ..... Plaintiffs
                                             Through: Mr. Pravin Anand, Mr. Saif Khan Mr.
                                                         Achuthan Sreekumar & Mr. Rohil
                                                         Bansal Advocates. (M:9079965359)
                                             versus
                               M/S ELECTRO INTERNATIONAL & ORS.            ..... Defendants
                                             Through: Mr. M.K. Singh, Advocate for Mr.
                                                         Samir Chugh, Advocates for Airtel
                                                         (M-9810455716)
                                                         Ms. Deepika Kathuria, Adv. for D-8.
                          (45)               WITH
                          +         CS (COMM) 399/2021 & I.A. 10855/2021
                               HINDUSTAN UNILEVER LIMITED                           ..... Plaintiff
                                             Through: Mr. Sidharth Chopra, Mr. Nitin
                                                         Sharma, Mr. Yatin Garg, Mr. Ranjeet
                                                         Singh, Mr. Vivek Ayyagari, Mr.
                                                         Angad Makkar, Mr. M. J. Sudarshan,
                                                         Ms. Ramya Aggarwal and Mr. Sohrab
                                                         Mann, Advocates.
                                             versus
                               NITIN KUMAR SINGH & ORS.                    ..... Defendants
                                             Through: Mr. Ankur Prakash, Ms. Simran Gill,
                                                         Mr. Yudhishthir Bhardwaj, Mr.
                                                         Dhananjay, Mr. Amod Bidhuri & Mr.
                                                         Saquib Siddiqui, Advocates for D-1
                                                         Mr. Bbhagvan Swarup Shukla, CGSC
                                                         with Mr. Kamaldeep, Advocate for
                                                         UOI/D-18 & 19.
                                                         Mr. K.K. Singh, Advocate for D-27.
                                                         Mr. K.R. Sasiprabhu and Mr. Tushar
                                                         Bhardwaj, Advs for Reliance Jio.
                          (46)               WITH
                          +    CS (COMM) 524/2021 & I.A. 13715/2021, 4506/2022
                               KAMDHENU LIMITED                                     ..... PlaintiffDabur India Limited vs Ashok Kumar And Ors on 14 September, 2022

                          CS (COMM) 135/2022 & connected matters                          Page 8 of 43
Signature Not Verified
Digitally Signed
By:DEVANSHU JOSHI
Signing Date:15.09.2022
16:50:14
                                                         Through:   Mr. Nikhil Sonker,    Advocate.
                                                                   (M:7726021194)
                                             versus
                               RAGHUNATH VIRDHARAM BISHNOI AND ORS. .... Defendants
                                             Through: Mr. Rishabh Gupta and Mr. Abhishek
                                                         Kumar Singh, Advocates.
                                                         Mr. Rishi Kapoor and Mr. Satish Rai,
                                                         Advocates for D-3. (M:8368148214)
                                                         Ms. Shweta Sahu and Mr. Alipak
                                                         Banjerjee, Advocates for D-8.
                                                         (M:9987115749)
                                                         Mr. K.G. Gopalakrishnan and Ms.
                                                         Nisha Mohandas, Advocates for D-9.
                                                         (M:8800556341)
                                                         Mr. Vihan Dang, Ms. Aditi Umapathy
                                                         and Mr. Parva Khare, Advocates for
                                                         D-10 (M-99101983636)
                                                         Mr. K.R. Sasiprabhu and Mr. Tushar
                                                         Bhardwaj, Advs. for Reliance Jio.
                          (35)               WITH
                          +         CS (COMM) 82/2020 & I.A. 2402/2020
                               JOCKEY INTERNATIONAL INC.                            ..... Plaintiff
                                             Through: Mr. Pravin Anand, Mr. Saif Khan,
                                                         Mr. Shobhit Agarwal and Mr.
                                                         Deepank, Advs. (M:8800520258)
                                             versus
                               WWW.JOCKEYFRANCHISE.COM & ORS. ..... Defendants
                                             Through: Mr. Vivek Jain and Ms. Aastha
                                                         Tiwari,     Advs.         for        D-4.
                                                         (M:9871863446)
                          (36)               WITH
                          +    CS (COMM) 251/2020 & I.As. 5544/2020, 7655/2022
                               MICROSOFT CORPORATION & ANR.                ..... Plaintiffs
                                             Through: Mr. Pravin Anand, Mr. Saif Khan,
                                                         Mr. Shantanu Sahay, Ms. Imon Roy
                                                         and Mr. Apoorv Bansal, Advocates.
                                             versus
                               MS CZONE SOLUTIONS & ORS.                   ..... Defendants
                          CS (COMM) 135/2022 & connected matters                          Page 9 of 43
Signature Not Verified
Digitally Signed
By:DEVANSHU JOSHI
Signing Date:15.09.2022
16:50:14
                                                         Through:   Mr. Sumit Nagpal, Ms. Nancy, Ms.Dabur India Limited vs Ashok Kumar And Ors on 14 September, 2022

                                                                   Dolly Luthra and Ms. Aastha Sood,
                                                                   Advs for D-1 & 2. (M:9911995000)
                          (37)                   WITH
                          +    CS (COMM) 255/2020 & I.As. 5590-91/2020, 11099/2020,
                               6402/2022
                               INDIAMART INTERMESH LIMITED                          .... Plaintiff
                                                 Through: Mr. Sidharth Chopra, Mr. Nitin
                                                           Sharma, Mr. Yatin Garg, Mr. Ranjeet
                                                           Singh, Mr. Vivek Ayyagari, Mr.
                                                           Angad Makkar, Mr. M. J. Sudarshan,
                                                           Ms. Ramya Aggarwal and Mr. Sohrab
                                                           Mann, Advocates.
                                                 versus
                               MR. AKASH VERMA & ORS.                       ..... Defendants
                                                 Through: Mr. Uday Singh Chopra & Mr. Parva
                                                           Khare,    Advocates       for      D-2.
                                                           (M:9911983636).
                                                           Mr. Saransh, Advocate for Ms.
                                                           Nandita Rao, ASC (Crml.),GNCTD.
                          (38)                   WITH
                          +    CS (COMM) 373/2020 & I.A. 7995-96/2020, 7999/2020, 9171/2020,
                               84/2021, 430/2021 & 1371/2021
                               ITC LIMITED                                          ..... Plaintiff
                                                 Through: Mr. Pravin Anand, Ms. Vaishali, Mr.
                                                           Shivang Sharma & Mr. Siddhant
                                                           Chamola, Advocates
                                                 versus
                               ASHOK KUMAR & ORS.                           ..... Defendants
                                                 Through: Ms. Ritu Mishra, Advocate for D-6.
                                                           Mr. Hrithik Goyal and Ms. Lovleen
                                                           Goyal,    Advocates      for      D-12.
                                                           (M:8826767020)
                                                           Ms. Deepika Kathuria, Adv. for D-14.
                                                           Ms. Asmita Kumar, Advocate for D-
                                                           31. (M:9899967516)
                          (39)                   WITH
                          +                CS (COMM) 424/2020
                          CS (COMM) 135/2022 & connected matters                           Page 10 of 43
Signature Not Verified
Digitally Signed
By:DEVANSHU JOSHI
Signing Date:15.09.2022
16:50:14
                                SHOPPERS STOP LIMITED                   ..... Plaintiff
                                            Through: Ms. Shubhie Wahi, Ms. Ankita Seth
                                                      and Ms. Sanya Kapoor, Advocates.
                                                      (M:9810907412)
                                            versus
                               M/S SHOPPERSTOP & ORS.                  ..... Defendants
                                            Through: Mr. P.S. Sudheer and Ms. Anne
                                                      Mathew,      Advs.         for      D-5.Dabur India Limited vs Ashok Kumar And Ors on 14 September, 2022

                                                      (M:9891760039)
                          (40)              WITH
                          +    CS (COMM) 498/2020 & I.A. 10520-21/2020, 2506/2021,
                               2530/2021
                               MICROSOFT CORPORATION & ANR.                 ..... Plaintiffs
                                            Through: Mr. Pravin Anand, Mr. Saif Khan,
                                                      Mr. Shantanu Sahay, Ms. Imon Roy
                                                      and Mr. Apoorv Bansal, Advocates.
                                            versus
                               PCPATCHERS TECHNOLOGY PRIVATE LIMITED
                               & ORS.                                  ..... Defendants
                                            Through: Mr. Sumit Nagpal, Ms. Nancy and
                                                      Ms. Aashta Sood, Advocates for D-1,
                                                      2 & 3. (M:9911995000)
                          (32)              WITH
                          +            CS (COMM) 297/2019
                               MOTHER DAIRY FRUIT & VEGETABLE PVT. LTD...... Plaintiff
                                            Through: Mr. Pravin Anand, Mr. Saif Khan,
                                                     Mr. Shobhit Agarwal and Mr.
                                                     Deepank, Advocates.
                                            versus
                               KUMAR PRAHLAD & ANR.                   ..... Defendants
                                            Through: Mr. Yash Vardhan Singh, Advocate
                                                     for D-1.
                                                     Ms. Hetu Arora Sethi, ASC, GNCTD
                                                     with Mr. Arjun Basra, Mr. Raman
                                                     Lamba, ACP, Cyber Cell along with
                                                     Mr. Sumeet Siddhu, IO.
                          (33)              WITH
                          CS (COMM) 135/2022 & connected matters                     Page 11 of 43
Signature Not Verified
Digitally Signed
By:DEVANSHU JOSHI
Signing Date:15.09.2022
16:50:14
                           +    CS (COMM) 317/2019 & I.As. 8404-05/2019, 3270/2020
                               DHARAMPAL SATYAPAL LIMITED                             ..... Plaintiff
                                                Through: Mr. Pravin Anand, Ms. Vaishali &
                                                            Mr. Siddhant Chamola, Advocates
                                                            (M-8373944051).
                                                            Mr. Siddharth Sangal & Ms. Nilanjani
                                                            Tandon, Advocates for D-11/SBI.
                                                versus
                               RAJNIGANDHA DISTRIBUTORS PRIVATE LIMITED
                               & ORS                                          ..... Defendants
                                                Through: Mr. Mahesh, Mr. Gulshan Kumar,
                                                            Ms. Shubhangi Sood & Ms. Aashi,
                                                            Advocates for D-2,3.
                                                            Ms. Hetu Arora Sethi, ASC, GNCTD
                                                            with Mr. Arjun Basra, Mr. RamanDabur India Limited vs Ashok Kumar And Ors on 14 September, 2022

                                                            Lamba, ACP, Cyber Cell along with
                                                            Mr. Sumeet Siddhu, IO.
                          (34)                  WITH
                          +    CS (COMM) 732/2019 & I.As. 3865/2020, 9234/2020, 4171/2021,
                               4172/2021
                               MONTBLANC SIMPLO GMBH                                  ..... Plaintiff
                                                Through: Mr. Pravin Anand & Mr. Devesh
                                                            Ratan, Advs. (M:9810333571)
                                                versus
                               MONTBLANCINDIA.COM & ORS.                      ..... Defendants
                                                Through: Mr. Yajur Bhalla, Mr. Deepak
                                                            Samota and Mr. Sumer Ahuja,
                                                            Advocates for D-1, 2, 4 to 10 & 20.
                                                            (M:9711009378)
                                                            Mr. Alipak Banjerjee & Ms. Shweta
                                                            Sahu Advs for D-18.
                                                            Ms. Hetu Arora Sethi, ASC, GNCTD
                                                            with Mr. Arjun Basra, Mr. Raman
                                                            Lamba, ACP, Cyber Cell along with
                                                            Mr. Sumeet Siddhu, IO.
                          (53)                  WITH
                          +    CS (COMM) 350/2020 & I.A. 7456/2020, 9624/2020, 9629/2020,
                               996/2021, 9204/2022, 12166/2022, 12172/2022, 12175/2022
                          CS (COMM) 135/2022 & connected matters                           Page 12 of 43
Signature Not Verified
Digitally Signed
By:DEVANSHU JOSHI
Signing Date:15.09.2022
16:50:14
                                GUJARAT COOPERATIVE MILK MARKETING FEDERATION
                               LTD & ANR.                                              ..... Plaintiff
                                                Through: Mr. Abhishek Singh and Mr. J. Amal
                                                            Anand, Mr. Elvin Joshy, Ms. Alisha
                                                            Sharma & Mr. Ujjawal Verma,
                                                            Advocates. (M:9910291290)
                                                versus
                               AMUL-FRANCHISE.IN & ORS.                       ..... Defendant
                                                Through: Mr. Anil Soni, CGSC with Mr. Rahul
                                                            Mourya,      Adv.         for        UOI.
                                                            (M:9560238258)
                                                            Mr. Anurag Ahluwalia,, CGSC with
                                                            Mr. Abhigyan Siddhant, G.P. and Mr.
                                                            Danish Faraz Khan, Advocate for
                                                            UOI. (M:9811418995)
                                                            Mr. Darpan Wadhwa, Sr. Advocate
                                                            with Mr. Alipak Banerjee & Ms.
                                                            Shweta Sahu and Advocates for D-26.
                                                            Mr. Alipak Banerjee and Ms. Shweta
                                                            Shahu, Advocates for D-27, 28 & 30.
                                                            Mr. Praveen Kumar Jain, and Ms.
                                                            Shalini Jha, Advocates for D-37.Dabur India Limited vs Ashok Kumar And Ors on 14 September, 2022

                                                            (M:9871278525)
                                                            Mr. Vihan Dang and Mr. Parva Khare
                                                            & Ms. Aditi Umapathy, Advs for D-
                                                            52.
                                                            Ms. Hetu Arora Sethi, ASC, GNCTD
                                                            with Mr. Arjun Basra, Mr. Raman
                                                            Lamba, ACP, Cyber Cell along with
                                                            Mr. Sumeet Siddhu, IO.
                          (26)                  WITH
                          +    CS (COMM) 298/2019 & I.As.8189/2019, 13215/2019, 13631/2019,
                               15695-96/2019, 14210/2021, 16707/2021
                               ULTRATECH CEMENT LIMITED & ANR.                ..... Plaintiff
                                                Through: None.
                                                versus
                               WWW.ULTRATECHCEMENTS.COM & ORS. ..... Defendants
                                                Through: Mr. Darpan Wadhwa, Sr. Advocate
                          CS (COMM) 135/2022 & connected matters                            Page 13 of 43
Signature Not Verified
Digitally Signed
By:DEVANSHU JOSHI
Signing Date:15.09.2022
16:50:14
                                                                    with Ms. Binsy Susan, Ms. Swati
                                                                   Agarwal, Mr. Shashank Mishra, Ms.
                                                                   Akshi Rastogi, Ms. Vani Kaushik and
                                                                   Mr. Aashish Somasi, Advocates for
                                                                   D-5 & 7. (M:9650001297)
                                                                   Mr. Ananta Prasad Mishra & Mr.
                                                                   Gagan Gupta, Advocates for D-9.
                                                                   (M:9990937838)
                                                                   Mr. Manish Mohan, CGSC for D-
                                                                   30&31 (M-999910115)
                          (27)                         AND
                          +    CS (COMM) 324/2020 & I.As.6950 /2020, 12588/2020,
                               12611/2020, 11510/2021
                               MCDONALDS CORPORATION & ANR. ..... Plaintiffs
                                                Through: None.
                                                versus
                               NATIONAL INTERNET EXCHANGE OF INDIA
                               & ORS.                                         ..... Defendants
                                                Through: Mr. Vivek Jain & Mr. Aastha Tiwari,
                                                           Advocates     for   D-18      &     28
                                                           (M9811426480).
                                                           Mr. Alipak K. Banerjee and Ms.
                                                           Shweta Sahu, Advocates for D-5, 2, 6
                                                           7, & 8.
                                                           Mr. Ravi Prakash, CGSC with Mr.
                                                           Sahonwlah Farmani Ali, Advocate for
                                                           D-35&36 (M-9469448888)
                          (31)                         WITH
                          +    CS(COMM) 193/2019 & I.As. 5399/2019, 11497/2019, 18216/2019,Dabur India Limited vs Ashok Kumar And Ors on 14 September, 2022

                               15451/2021, 6069/2022
                               COLGATE PALMOLIVE COMPANY & ANR. ..... Plaintiffs
                                                Through: Mr. Pravin Anand, Mr. Saif Khan &
                                                           Mr.     Rohil    Bansal,     Advs.(M-
                                                           9079965359)
                                                versus
                                 NIXI & ANR.                                          ..... Defendants
                                                        Through:   Ms. Akshita Jain, Advocate for D-1
                          CS (COMM) 135/2022 & connected matters                            Page 14 of 43
Signature Not Verified
Digitally Signed
By:DEVANSHU JOSHI
Signing Date:15.09.2022
16:50:14
                                                                    (M-9990526912).
                                                                   Mr. Darpan Wadhwa, Sr. Advocate
                                                                   with Ms. Swati Agarwal, Ms. Binsy
                                                                   Susan, Mr. Shashank Mishra, Ms.
                                                                   Akshi Rastogi, Ms. Vaani Kaushik &
                                                                   Mr. Vaarish Sawlani, Advs for D-3-4.
                                                                   Mr. Anurag Ahluwalia, CGSC with
                                                                   Mr. Danish Faraz Khan, Advocate for
                                                                   UOI (M-9811418995)
                                                                   Mr. Tentu Satyanarayan, Director
                                                                   (Legal), UIDAI & Mr. Tanmaya
                                                                   Nirmal, Deputy Manager (Legal &
                                                                   Policy), UIDAI (M-9899113033).
                                                                   Mr. Kushagra Goel, Mr. Abhimanyu
                                                                   Yadav, Mr. Nikhil Jayant & Mr.
                                                                   Lovesh Goel, Advocates for D-7 (M-
                                                                   9711443294).
                                                                   SI Prince Kumar, PS Hauz Khas.
                                 CORAM:
                                 JUSTICE PRATHIBA M. SINGH
                          Prathiba M. Singh, J. (Oral)
1. This hearing has been done through hybrid mode.
2. The present set of suits and proceedings have been filed before this Court, by a large number of
trademark and brand owners, seeking reliefs against misuse of their marks / names / brands by
unauthorized persons, who register such marks as part of their domain names. The issues that arise
in these cases is that the proliferation of these fraudulent domain names has resulted in enormous
damage and monetary loss running into lakhs of rupees to innocent and gullible members of the
public, owing, inter alia, to inadequate verification of registrants and privacy protect features offered
by domain name registrars (hereinafter "DNRs").
3. The matters have been heard from time to time. There are several issues that arise in respect of
the mode of registration of domain names, verification of domain names, privacy protect features,Dabur India Limited vs Ashok Kumar And Ors on 14 September, 2022

hosting of websites on the fraudulent domain names, payments being received from innocent
persons etc. Vide order dated 3rd August, 2022, it was directed that in certain matters, copies of
petitions and any additional information for investigation of FIRs, be provided to Ms. Sethi, ld. ASC,
and Mr. Lamba, ACP, IFSO, Special Cell. A joint meeting was directed between the Delhi Police,
National Payments Corporation of India (hereinafter "NPCI"), DoT, Ministry of Electronics and
Information Technology (hereinafter "MeitY"), Department of Telecommunication (hereinafter
"DoT"), National Internet Exchange of India (hereinafter "NIXI"), and CERT-in. In addition, DNRs
were directed to place proposals or affidavits on record, and Mr. Rao, ld. Senior Counsel,
representing Internet Corporation for Assigned Names and Numbers (hereinafter "ICANN"), was to
seek further instructions to make more comprehensive submissions. Vide order dated 3rd August,
2022, the following directions were issued:
"31. ...Considering the large sums of money that are being fraudulently obtained from
various unsuspecting customers, all due to the lack of an active mechanism
identification of such fraudulent parties, it is clear to the Court that the following
aspects need to be addressed in these matters:
(i) The manner in which the details of the domain name registrants, can be verified
by the DNRs, at the time of registration of domain names;
(ii) The manner in which the privacy protect feature and proxy servers are made
available:
whether it is only upon a specific registrant choosing the said option, rather than as a
standard feature as part of a 'bundle';
(iii) If the owner of a well-known brand or a trademark contacts any DNR, the
manner in which the data related to the registrant can be provided, without the
intervention of a Court, or any governmental agency;
(iv) Whether the identity of the owner of a domain name, which consists of a
registered trademark or a known brand can be verified at the time of registration
itself;
(v) If a specific link could be provided by the CGPTDM, covering a list of well-known
marks, maintained by the Registrar of the Trademarks, or declared by any Court of
law, which can then be used for expedited blocking of domain names consisting of
such marks;
(vi) If there can be any agency that can be identified in India, such as NIXI, who can
be made a repository of the data concerning the registrant, or an agency through
which the data could be transmitted by the DNR, upon verification by NIXI, in case a
trademark owner has a grievance against a specific domain name;Dabur India Limited vs Ashok Kumar And Ors on 14 September, 2022

(vii) If any directions are issued to the DNRs, and the same are not implemented, the
manner in which the implementation of the said orders can be ensured;
(viii) Since almost all domain names are registered only after payments are made
through credit card, or other online payment methods or apps, is it possible, upon
request by any identified agency, to provide the information relating to the person
who has made the payment, to the trademark owners.
This should be discussed in the aforementioned meeting to be held on 30th August, 2022.
...
34. The report and the outcome of the meeting held on 30th August, 2022, along with the affidavits
by the DNRs, shall be placed on record, on or before 31st August, 2022."
4. Pursuant to the above directions, various parties made their submissions on 13th September,
2022 and certain issues were dealt with vide order dated 13th September, 2022. Vide the said order,
in view of the fact some urgent steps needed to be taken for ensuring compliance by DNRs, the
following directions were issued:
"13. Accordingly, the DNRs who are represented before the Court today, shall revert
by tomorrow on the following aspects:
(1) Whether they have appointed Grievance Officers in terms of IT Rules 2021?
(2) If they have done so, details of the said Grievance Officers including the name,
designation, postal address, e-mail address and telephone numbers.
14. The above details shall be placed before the Court tomorrow. List all these matters for this
specific purpose tomorrow, i.e., on 14th September, 2022 at 3:00 pm."
5. Today, further submissions have been made by the Plaintiffs, ld. Senior Counsels and counsels
representing DNRs, etc. There are various aspects on which submissions have been addressed. The
same are set out below along with further directions.
Status Reports on Probe by the Delhi Police into Unlawful Collection of Monies
6. Pursuant to the direction given vide previous order dated 3rd August, 2022, to the Delhi Police,
which has constituted a Special Investigation Team (SIT) to inquire into these and similar cases,
status reports have been filed in the following matters:
CASE NO.                         TITLE
                                     1. CS (COMM)26/2022           HT Media Ltd. vs. Pooja Sharma &
                                                                   Ors.,
                                     2. CS(COMM)233/2022           Bajaj Finance Ltd & Anr. vs. NikoDabur India Limited vs Ashok Kumar And Ors on 14 September, 2022

                                                                   Das & Anr.
                                     3. CS (COMM)255/2020          Indiamart Intermesh Ltd. vs. Akash
                                                                   Verma & Ors.
                                     4. CS (COMM)275/2022          Hindustan Unilever Ltd. & Anr. vs.
                                                                   UNILEVERR1.IN & Ors.
                                     5. CS (COMM)364/2022          Amazon Sellers Services Private
                                                                   Limited & Anr. v. Amazonbuys.in
                                                                   & Ors.
                                     6. CS(COMM) 399/2021          Hindustan Unilever Limited       v.
                                                                   Nitin Kumar Singh & Ors.
                                     7. CS(COMM) 424/2020          Shoppers Stop Limited v. M/s.
                                                                   Shopperstop & Ors.,
                                     8. CS(COMM) 193/2019          Colgate Palmolive Company & Anr.
                                                                   v. Nixi & Anr.
                                     9. CS(COMM) 293/2021          Tata Sons Private Limited & Anr.
                                                                   v. M/s. Electro International &
                                                                   Ors.
                                     10.CS(COMM) 317/2019          Dharampal Satyapal Limited v.
                                                                   Rajnigandha Distributors Private
                                                                   Limited & Ors.
                                     11.CS(COMM) 297/2019          Mother Dairy Fruit & Vegetable
                                                                   Pvt. Ltd. v. Kumar Prahlad & Anr.
                                     12.CS (COMM) 82/2020          Jockey International Inc.        v.
                                        & Ors.,                    www.jockeyfranchise.com
                                     13.CS (COMM) 95/2021          The Himalaya Drug Company &
                                                                   Ors. v. Ashok Kumar & Ors.
                                     14.CS(COMM) 373/2020          ITC Limited v. Ashok Kumar &
                                                                   Ors.
                                     15.CS(COMM) 251/2020          Microsoft Corporation & Anr. v.
                                                                   MS Czone Solutions & Ors.
16.CS(COMM) 498/2020 Microsoft Corporation & Anr. v.
PCPATCHERS Technology Private Limited & Ors.
17.CS(COMM) 276/2021 Microsoft Corporation & Anr. v.
Tech Heracles OPC Private Limited & Ors.,
18.CS(COMM) 587/2019 Pfizer Inc. & Ors. v. Beacon Pharmaceuticals Limited & Ors.
19.CS(COMM) 732/2019 Montblanc Simplo GMBH v.Dabur India Limited vs Ashok Kumar And Ors on 14 September, 2022

Montblancindia.com & Ors.
20.CS(COMM) 595/2022 Livspace PTE. Ltd. & Anr. v.
Livspace-reviews.com & Ors.
21.CS(COMM) 154/2021 Godrej Properties Ltd. v. Ashok Kumar & Anr.
22.CS(COMM) 350/2020 Gujarat Cooperative Milk Marketing Federation Ltd. & Anr.
v. Amul-Franchies.in & Ors.
23.CS(COMM) 524/2021 Kamdhenu Limited v. Raghunath Virdharam Bishnoi & Ors.
24.CS(COMM) 135/2022 Dabur India Limited v. Ashok Kumar and Ors.
25.CS(COMM) 228/2021 Bajaj Finance Limited v.
Registrant of www.bajaj.finserve.org & Ors.
7. Ms. Sethi, ld. ASC, has taken the Court through some status reports today. For instance, in CS
(COMM) 233/2022, the Delhi Police has filed a status report to the effect that 20 complaints were
received by NPCI in the name of Bajaj Finance Limited. Nine complainants have provided
documents, and FIRs have also been registered. Following this, certain bank accounts have also
been frozen. Most of the status reports show that monies have been collected illegally by using the
brand names, marks and business names of the Plaintiffs under the garb of offering
distributorships, franchisees, employment etc. The said amounts are deposited in bank accounts
opened in individual names but represented as belonging to the Plaintiffs and are withdrawn almost
instantaneously. The magnitude of the fraud being committed is still to be unearthed. Investigations
are still continuing.
8. Submissions are still being heard by the Court as to the action taken by the Delhi Police in these
matters.
9. It is directed that the investigations already continuing, shall further continue in accordance with
law and the police shall take all the necessary action. By the next date, i.e., 1st December, 2022,
further status reports shall be placed on record in respect of all the suits being considered in this
batch and any other relevant information.
Status Report by MeitY and Meeting with Stakeholders
10. Mr. Harish V. Shankar, ld. CGSC, has filed a status report on behalf of MeitY, as was directed by
the Court vide order dated 3rd August, 2022. The said report records that meetings were held on
24th and 30th August, 2022 with various stakeholders. To this end, a batch of questionnaires wasDabur India Limited vs Ashok Kumar And Ors on 14 September, 2022

prepared by MeitY and sent to the stakeholders. It is submitted that MeitY is still in the process of
receiving all responses and preparing its recommendations.
11. The said questionnaires have been compiled, along with some of the responses received and
placed on record by MeitY. As per the said status report, post the order dated 3rd August, 2022, the
following developments have taken place:
"a) To address the key issues ascertained under Para-No.10 to 15 and 31, on 3rd of
August, 2022, the Hon'ble Court directed MeITY and DoT to conduct a meeting in
MeITY premises.
b) On 21.08.2022, MeITY communicated the questionnaire to all stakeholders and
invited them to attend the pre-meeting on 24.8.2022 and the final meeting on
30.8.2022 respectively. A copy of the questionnaire is DOCUMENT D3-A(Colly).
c) On 21.08.2022 & 25.08.2022, MeITY prepared responsive information to the
questions posed to ICANN. A copy of the same is DOCUMENT D3-B.
d) On 24.08.2022, MeITY conducted a pre-meeting with the relevant stakeholders
including ICANN in which MeITY discussed the key issues of subject matter. In due
course of time, MeITY received response from various stakeholders such as Delhi
Police, CERT- IN and Domain Name Registrars.
e) On 30.08.2022, MeITY conducted the final meeting and based on the inputs
received, discussed the key issues and recommendations to be submitted before
Hon'ble High Court and the same were forwarded for conveying to this Hon'ble
Court.
f) The Action Taken Report and the outcome of the meeting alongwith all relevant
documents are DOCUMENT D3-C(COLLY)"
12. Basis the above report, this Court notes that the participants in the meeting dated 30th August,
2022, included MEITY, NIXI, DoT, Cert-IN, IFSO, Delhi Police, ICANN, NPCI and some DNRs. The
status report has also annexed the responses received from the Cyber Law and E-Security division,
MeitY, Digital Economy and Digital Payments Division, ICANN, NIXI, NPCI and Delhi Police, DoT,
to the questionnaires provided by MEITY. The office of the CGPDTM is yet to reply. The said office
shall also provide its response to MeitY by 30th September, 2022.
13. Insofar as DNRs are concerned, the questionnaires appear to have been sent to 25 DNRs, out of
which, only two DNRs have responded namely, Hiox LLC, and Newfold Digital.
14. Insofar as the remaining DNRs are concerned, some of them are represented before this Court
today. Any further DNRs who now wish to send responses to MeitY, including Hosting Concepts BV,
Public Domain Registry (PDR), Endurance International, Bigrock, and GoDaddy LLC, as also anyDabur India Limited vs Ashok Kumar And Ors on 14 September, 2022

other DNRs, shall have the opportunity to do so by 30th September, 2022. The DNRs may also
provide copies of their affidavits, filed before this Court, if they wish the same to be considered by
MeitY, to Mr. Harish V. Shankar, ld. CGSC, so that the same can be passed on to the concerned
authorities. Additionally, the DNRs who wish to participate in the said meetings with MeitY, are
permitted to do so. The details of the said meetings shall also be obtained from the ld. CGSC Mr.
Harish Vaidyanathan, if any of the parties wish to give their inputs.
15. Considering the status report filed today and the submissions made, it is directed that the
deliberations which are currently underway, shall continue. All the stakeholders to whom
questionnaires have been sent and any other stakeholders who wish to give their comments and
responses to MeitY are permitted to do so by 30th September, 2022. The responses may be sent to
the officer at the email address provided below:
Name: Sh. Pradeep Kumar Verma, Scientist D, Address: Ministry of Electronics and
Information Technology, Electronics Niketan, 6, C.G.O. Complex, New Delhi-110003.
Email ID: Pradeep.verma@meity.gov.in
16. Pursuant to these meetings, MeitY shall file recommendations in respect of the aspects contained
in paragraph 31 of the order dated 3rd August, 2022, as extracted above. Along with the
recommendations, the questionnaires sent and responses received from all parties shall be compiled
and placed on record by MeitY in all these connected matters, by 1st December, 2022.
Submissions with respect to Mismatch of Payment Details
17. At this stage, ld. Counsels for the Plaintiffs have also brought to the notice of the Court that
whenever payments for purchase of domain names are accepted, there is frequently a mismatch
between the name of the account holder of the bank account in the bank records, and the name
given in the billing details at the time of purchase using the same bank account. There is currently
no verification to check that the name of the account holder is the same as the name entered at the
time of purchase. For e.g., if the bank account is in the name of Mr. XXXX and the billing detail is
given as M/s. Dabur, the said mismatch is not checked and only the account number is verified.
18. Ld. Counsels seek directions as to whether this issue can be resolved in some manner, so that the
impostors would be unable to mislead people by representing themselves as being the owners of the
Plaintiffs' brands or businesses.
19. Let this issue be considered in the meetings to be held by MeitY with the stakeholders. NPCI
shall also give its views, so that the same can be captured in the recommendations.
Submissions of DNRs with respect to Grievance Officers and Grievance Redressal Mechanisms
20. Pursuant to the directions passed in paragraphs 31-33 of the previous order dated 3rd August,
2022 and in the previous order dated 13th September, 2022, various DNRs have made submissions
today as to their grievance officers and their mechanisms for implementation of Court orders inDabur India Limited vs Ashok Kumar And Ors on 14 September, 2022

cases of infringing and fraudulent domain names/websites.
A. Submissions on behalf of Newfold LLC and its Group Entities
21. Mr. Dayan Krishnan, ld. Senior Counsel, appears on behalf of the following six DNRs:
● Endurance Domains Technology LLP (Defendant No.2); ● BigRock Solutions Ltd.
(Defendant No.3); ● PublicDomainRegistry.com (Defendant No.4); ●
Domainshype.com, LLC (Defendant No.23); ● DomainAdministration.com, LLC
(Defendant No.26); and ● FastDomain Inc. (Defendant No.31). (hereinafter
collectively "Newfold Group")
22. With regard to the issue of grievance officers, he submits that as per the instructions which he
could obtain at short notice, a common grievance officer has been appointed by all these five DNRs.
The individual who is the Grievance Officer is Mr. Prabhat Kamat. The email details of the said
Grievance Officer, for each entity, are as under:
                                 Endurance      Domains grievance-
                                 Technology LLP         officer@publicdomainregistry.com
                                                        does not have any client facing
                                                        website. Registered through PDR
                                 BigRock Solutions Ltd.            grievance-officer@bigrock.com
                                 PDR Ltd.                          grievance-
                                                                   officer@publicdomainregistry.com
                                 Domainshype.com LLC               grievance-officer@bigrock.com
                                                                   does not have any client facing
                                                                   website
                                 FastDomain Inc                    grievance-officer@bluehost.in
23. In so far as the grievance redressal mechanism is concerned, Mr. Krishnan submits that the
Newfold Group is in compliance with Rule 3(2)(a) of the Information Technology (Intermediary
Guidelines and Digital Media Ethics Code) Rules, 2021 (hereinafter "IT Rules 2021"), as whenever
any complaint is made by any user or victim, the acknowledgment is issued to said user/victim,
within 24 hours and the complaint is disposed of within 15 days from the date of its receipt. He
further submits that if any order is issued by any Court of competent jurisdiction or any order,
notice or direction is issued by a governmental or competent authority, the same would be complied
with in terms of the IT Rules 2021. Similarly, if any order granting injunction or directions with
respect to infringing domain names or other orders with respect to infringing domain names are
passed by this Court or any Court of law, the Grievance Officer would facilitate giving effect to suchDabur India Limited vs Ashok Kumar And Ors on 14 September, 2022

orders and ensure that the same are complied with, upon receiving a communication at the email
addresses set out above. Mr. Krishnan however, submits that considering the time differences and
the fact that some coordination may be required for such compliance across different offices of the
DNRs, reasonable time of 48 to 72 hours maybe afforded for the purposes of the said compliance.
24. These submissions on behalf of the Newfold Group are recorded and the Newfold Group shall be
bound by the same, in all matters where infringing domain names are involved. If the said Grievance
Officer is changed in the future, such change shall also be notified by prominently publishing it the
websites of each of the entities of the Newfold Group.
B. Submissions on behalf of GoDaddy LLC
25. Insofar as GoDaddy LLC (hereinafter "GoDaddy") is concerned, Mr. Darpan Wadhwa, ld. Senior
Counsel, submits that they are unable to obtain instructions as to whether any grievance officer has
been appointed in terms of Rule 3 of the IT Rules, 2021. It is however submitted that from a perusal
of the website, there is one grievance officer by the name Mr. Karen Gaydos, with the following
address and e-mail:
Address: 2155 E GoDaddy Way, Tempe AZ 85284 E-mail:
grievanceofficer@godaddy.com
26. It is submitted that the said individual could be functioning as the Grievance Officer under the
IT Rules, 2021. He seeks further time to seek confirmation in this regard.
27. At this stage, ld. Counsels for the Plaintiffs have brought to the attention of this Court various
problems with compliance of previous injunction/suspension orders and orders seeking details of
registrants, where GoDaddy's current mechanism for reporting grievances has not been responsive
or failed to comply with Court orders in time. By way of illustration, the Court's attention has been
drawn to:
(i) CS(COMM) 154/2021 titled Godrej Properties Ltd. v. Ashok Kumar & Anr.:
• In this suit concerning the mark 'GODREJ PROPERTIES', vide order dated 18th
July, 2022 read with order dated 14th March, 2022, various domain names which
were brought to the notice of the said DNR are yet to be taken down. The operative
portion of the order dated 14th March, 2022, reads as under:
"2. Having heard learned Senior Counsels for the Plaintiff and Defendant No.2 and
with the consent of the parties, this Court directs that for any future domain names,
which contain the Plaintiff's trademark "Godrej Properties" or any part thereof and
which the Plaintiff believes to be the subject of phishing attempts:
(a) Plaintiff shall report to Defendant No.2, GoDaddy.com LLC these domain names,
as per their Phishing tool (available atDabur India Limited vs Ashok Kumar And Ors on 14 September, 2022

https://supportcenter.godaddy.com/AbuseReport), as detailed in paras 30 and 31 of
the reply filed by Defendant No.2 to the instant application.
(b)Defendant No.2, GoDaddy.com LLC shall process the request and act on it, if
Defendant No.2 finds the Plaintiff's request to be valid and justified.
(c) If Plaintiff is unable to get relief from Defendant No.2, Plaintiff shall be at liberty
to approach this Court by filing an affidavit or an application before the Court or the
learned Joint Registrar, as the case may be, listing the domains against which it has
lodged complaints, along with any other evidence it wishes to rely upon to seek their
suspension. Plaintiff shall serve a copy of the affidavit or application upon
GoDaddy.com LLC in advance. Upon satisfaction of the Court or the learned Joint
Registrar, as the case may be, an appropriate order shall be passed, directing
Defendant No.2 to suspend the identified domains. If and when such an order is
passed, Plaintiff shall communicate the same to Defendant No.2 for compliance.
(d)Upon Defendant No.2's assurance that it would comply with the aforementioned
order, Plaintiff agrees that Defendant No.2 shall be deleted from the array of parties
on the next date of hearing.
3. Additionally, Mr. Mehta, learned Senior Counsel appearing on behalf of the Plaintiff, during the
course of hearing, has handed over a list of domain names, in respect of which, he submits that
injunction orders are already operating and therefore Defendant No.2 be directed to disclose
directly to the Plaintiff, various details of these registrant(s) to enable the Plaintiff to implead them
as parties. List has been handed over to Mr. Darpan Wadhwa.
4. I find merit in the submissions made by Mr. Mehta. Accordingly, Defendant No.2 is directed to
disclose to the Plaintiff whatever details of the registrant(s), as enumerated in the list, are available
with Defendant No.2, within a period of two weeks from today, for the purpose of impleadment
alone. "
• Thereafter, vide order dated 18th July, 2022, this Court further directed as under:
"8. A perusal of the above domain name which has been illustratively relied upon
shows that this is a classic case of misuse of the Plaintiff's mark 'GODREJ'. The
request in this case cannot be treated as a simple phishing request, but has to be
considered in the context of the suit filed by the Plaintiff for the infringement of its
trademark 'GODREJ', as also, the order dated 14th March, 2022 passed by the Court
in respect of the same. The request of the Plaintiff in this case, therefore, has to be
processed in the background of the suit, the orders passed by the Court, as also,
GoDaddy's Abuse policy, and not on a standalone basis.
9. Since time has been sought by Mr. Wadhwa, ld. Senior Counsel, without
commenting further at this stage, the DNR - GoDaddy is directed to place an affidavitDabur India Limited vs Ashok Kumar And Ors on 14 September, 2022

on record giving the reasons and justification qua each of the domain names which
have not yet been suspended/deactivated, as to why the said domain names have not
been deactivated or suspended. In the said affidavit, the DNR shall clarify as to
whether, in respect of any of these domain names, it is offering any services apart
from domain names registration, such as hosting services, cloud servers, website
development, etc., and if so, the details of the same shall also be placed on record.
Further the complete details of the registrants of these domain names viz., name,
address, phone number, email address, IP addresses, PAN card, credit card details if
any shall also be filed in the affidavit.
10. It is made clear that if this Court finds that the DNR's stand is not sustainable in
light of the present suit, as also, the order dated 14th March, 2022, this Court would
pass appropriate directions on the next date of hearing. "
• In this regard, Mr. Wadhwa, ld. Sr. Counsel, submits that the said orders do not specifically require
GoDaddy to provide details of registrants in case of impugned domain names supplied by further
affidavit by the Plaintiffs. He submits that the directions in respect of such domain names were only
limited to their suspension. • A perusal of the above orders shows that these submissions have been
recorded clearly in the order dated 18th July, 2022 as well. Moreover, GoDaddy was directed to file
an affidavit which has still not been filed despite almost eight weeks having passed by.
(ii) CS(COMM) 95/2021 titled The Himalaya Drug Company & Ors. v. Ashok Kumar & Ors.:
• In this suit concerning the mark 'HIMALAYA' and related marks, ld. Counsel for the
Plaintiff draws attention to the order dated 18th February, 2022, where the following
directions were issued:
"12. Though this application is not listed today, it has been taken up qua the prayer in
the application, seeking interrogatories, from Defendant 16, in the form of true and
correct name, address, contact information of the person(s) who are the registrants of
the domain names www.himalayapharmacy.in, www.himalayawelness.in,
www.himalayadistributor.in, www.himalayafranchise.org.in and
www.masterfranchise.org.in.
13. Defendant 16 is directed to provide, to the plaintiff, the aforesaid details in respect
of any of the said domain names which are registered with Defendant
16."
• It is the Plaintiff's contention that the details of registrants of two of the domain names i.e.
www.himalayapharmacy.in and www.himalayawelness.in., have not been provided till date. • At this
stage, Mr. Khan, ld. Counsel on behalf of GoDaddy, submits that the two domain names which the
Plaintiffs claim to not have received registrant details for, are not registered by GoDaddy in the firstDabur India Limited vs Ashok Kumar And Ors on 14 September, 2022

place. This has in fact, been pleaded in paragraph 53(c) of the plaint.
• Ld. Counsel for the Plaintiff to communicate by way of email, to counsel for GoDaddy as to
whether any compliances are to be made or if any further details are to be given. If so, the same shall
be provided by GoDaddy, within a week, after receipt of the said email.
(iii) CS(COMM) 475/2022 titled Fashnear Technologies v. Meesho Online Shopping Pvt. Ltd.:
• In this suit concerning the Plaintiffs' mark 'MEESHO', and its related marks, it is
submitted that the Court's direction has not been complied with. The following
directions were issued vide order dated 20th July, 2022;
"4. In the meantime, all the three fake online marketplaces with the infringing
domain names being 'www.meeshogift.in', 'www.meeshogift.com' and
'www.meeshoonlineluckydraw.in' are restrained from operating and shall remain
suspended or deactivated by the Domain Name Registrar ("DNR"). The Defendant
No.19 - Department of Telecommunications (DoT) and Defendant No.20 - Ministry
of Electronics and Information Technology (MEITY) shall issue blocking orders for
the said three domain names, till further orders of this Court. All the Internet Service
Providers (ISPs) shall also give effect to these directions, within 24 hours.
5. The contact details of the persons, who have registered domain names shall be
handed over to ld.
Counsel for the Plaintiff by the DNR - GoDaddy and other Registrars. Upon the details of the
registrants of these domain names being made available to ld. Counsel for the Plaintiff, the same
shall be supplied to Ms. Sethi and Mr. Lamba, so that they can carry out further investigation into
the matter. All the concerned banks shall further ensure that the bank accounts connected to the
said three domain names are frozen and blocked.
6. The DNRs will also inform the Plaintiff, if the said domain names have availed of any other
services of the DNR such as cloud server, website development and hosting services. If so, the
details used for making any payments such as credit card details, bank accounts details and any IP
address of such persons who have registered the said domain names for availing the said services,
shall also be provided to ld. Counsel for the Plaintiff. After collecting said details, the ld. Counsel for
the Plaintiff shall forward the same to Ms. Sethi and Mr. Lamba.
7. The DNRs shall further ensure that no other fake websites/domain names containing the
mark/name 'MEESHO' is registered by them. If the Plaintiff gives notice of any other infringing
websites, the DNRs shall deactivate the said website/domain name, within 48 hours.
8. Ld. Counsel for the Plaintiff shall file an affidavit giving the details of such websites after
submitting the same to the DNR. If any domain names, which are brought to the notice of the DNR,
are not deactivated, an explanation shall be provided by the DNR to the Plaintiff as to why the saidDabur India Limited vs Ashok Kumar And Ors on 14 September, 2022

domain names were not deactivated, and the Plaintiff shall be at liberty to move an application
before the Court in this regard."
• It is submitted by Mr. Chopra, ld. Counsel for the Plaintiffs, that qua the domain names mentioned
in the subsequent affidavits filed by the Plaintiffs, the details of the registrants have not been
provided by GoDaddy. In respect of the said domain names, an email dated 4th September, 2022,
sent on behalf of GoDaddy, has been received by the Plaintiff. The said email reads as under:
"Dear Vivek, As informed by our client, GoDaddy.com LLC, the following domain
names which had been registered through it, have been locked and suspended.
1. meesholuckydraw.in
2. meeshouluckydrawcenter.com
3. meesholuckydraws.com
4. meeshouluckydrawwinnername.com
5. meeshoprizedepartment.in
6. meeshostore.shop
7. meeshowinnernamelist.com
8. meeshowinnerslist.com
9. meeshoseller.com
10.meeshoshopping.com GoDaddy would be able to provide corresponding registrant
details upon specific directions being passed by Court afore-mentioned domain
names.
Thanks and regards, Shweta "
• In response to the Plaintiff's submissions, Mr. Wadhwa, ld. Sr. Counsel, submits that the direction
does not apply in respect of further affidavits which contain additional impugned domain names, as
filed by the Plaintiffs. He submits that once the orders are passed for each of the domain names, the
orders can be implemented, and such orders have been implemented in the past. • A perusal of the
order dated 20th July, 2022 clearly shows that the impugned domain names had to be
suspended/blocked, and the details of the registrants had to be provided by the DNRs, to the
Plaintiffs. Considering that the injunction granted is a dynamic injunction, it is clear that if there is
any further affidavit is filed for suspension of additional DNRs, the said domain names must also be
deactivated/suspended/locked. If this is not done, the concerned DNR has to provide a reason forDabur India Limited vs Ashok Kumar And Ors on 14 September, 2022

the same. In any event, the Court has seen various domain names in the list of additional impugned
domain names, qua which are clearly infringing and action is yet to be taken by GoDaddy on such
domain names. The said impugned domain names are as under:
                                          S. No.                   Websites/Domain Names
                                             1                        meeshostore.shop
                                             2                       meeshomarket.com
                                             3                      meesholuckdraw.com
                                             4                      meeshopromotions.in
                                              5              meesholuckydrawheadoffice.com
                                             6                meesholuckydrawcenter.com
                                             7                       meeshopratham.com
                                             8                       meeshoshopping.com
                                             9                 meeshowinnernamelist.com
                                             10            meesholuckydrawwinnername.com
                                             11                    meeshoprizedepartment.in
• In respect of the above domain names, it is directed that they shall be blocked/suspended and
locked, and status quo shall be maintained qua them, failing which action in accordance with law,
would be liable to be taken. Further, all details as captured in the order dated 20th July, 2022 above,
available relating to the registrants of these domain names with GoDaddy, shall be provided to
counsel for the Plaintiff within a week. The same shall also be filed before this Court along with an
affidavit.
(iv) CS(COMM) 524/2022 titled Bombinate Technologies Private Limited v. KOO COIN & Ors.:
• In this suit concerning 'KOO', which is also pending before this Court though not
listed today, it is submitted that GoDaddy is yet to give effect to the directions passed
by this Court vide order dated 1st August, 2022. The directions issued vide the said
order read as under:
"23. The DNR-Go Daddy LLC, is also represented before this Court today. GoDaddy
LLC is directed to disclose to the Plaintiff the details of the registrants of these
domain names, as also any billing information, subscribers' information, and any
other information which may be available. This information be provided by ld.
Counsel for GoDaddy LLC within 48 hours. An affidavit shall be filed by GoDaddy
LLC before the Court, stating as to whether it is a customer of the Defendant No.1's
website. If any other services are being provided by GoDaddy LLC to these three
networks, details of the same shall also be stated in the said affidavit.Dabur India Limited vs Ashok Kumar And Ors on 14 September, 2022

24. Further, the URLs as mentioned in Annexure A and B of the Plaint, shall also be
blocked by MEITY, as also the ISPs."
• Thereafter, the Court issued the following directions vide order dated 24th August, 2022:
"3. On the said date, Ms. Shweta Sahu, ld. Counsel had appeared but had not received
instructions from her client. It is submitted by Ms. Sahu that they have not yet been
engaged in this matter. Ms. Shweta Sahu, ld. Counsel submits that since the counsel
had not been engaged in this matter by GoDaddy, the order dated 1st August, 2022
was not communicated to GoDaddy.
4. However, ld. Counsel for the Plaintiff submits that the copy of the order was
e-mailed to GoDaddy on 8th August, 2022 and 17th August, 2022 by her office. An
advance copy of this application is also been stated to have been served by e-mail to
GoDaddy on 22nd August, 2022 and the automatic reply of the same is stated to have
been received showing that the same has been duly sent at legal@godaddy.com and
has been delivered.
5. Ms. Majumdar, ld. Counsel for the Plaintiff submits that GoDaddy has an office in
India at Gurgaon. The contact details are set out below:
GoDaddy India Web Services Private Limited 003, Tower 4A, DLF Corporate Park,
MG Road Gurgaon - 122002 Email: legal@godaddy.com"
• However, ld. Counsel for the Plaintiffs submits that till date, no action has been taken by GoDaddy,
and in fact the Plaintiffs have filed a contempt petition in the said case.
(v) CS(COMM) 584/2022 titled Organo Gold Holdings Limited v. Origano Gold Private Limited &
Ors.:
• In this case pending before the Coordinate Bench of the IP Division, concerning the
mark 'ORGANO GOLD', despite the injunction order having been passed on 26th
August, 2022, the impugned domain name is yet to be taken down. The said order of
the Co-ordinate Bench dated 26th August, 2022, reads as under:
"15. Having considered the submissions made by the learned counsel for the plaintiff,
perused the plaint and the documents filed therewith, I am of opinion that plaintiff
has been able to make out a good prima facie case in it favour. The balance of
convenience is also in favour of the plaintiff and against the defendants. The plaintiff
and the general public are likely to suffer irreparable injury in case an ad interim
injunction, as prayed for, is not granted. The mark depicted by the defendants is
almost identical to that of the plaintiff's. The goods in questions are also similar. The
plaintiff is the registered proprietor of the mark and is therefore, statutorily entitled
to protection thereof.Dabur India Limited vs Ashok Kumar And Ors on 14 September, 2022

16. Accordingly, an ex parte ad interim injunction in terms of prayer made in
paragraph 12 of the application is granted in favour of the plaintiff and against the
defendants, till further orders."
• The email sent by the Plaintiff intimating GoDaddy of the order dated 26th August, 2022 along
with the impugned domain names as per their application, has also been sent to M/s GoDaddy vide
emails dated 27th August, 2022, 31st August, 2022, 5th September, 2022 and 7th September, 2022.
Such emails are stated to have been sent to various email addresses of GoDaddy, i.e.,
legal@godaddy.com, HQ@Godaddy.com, Courtdisputes@godaddy.com. It is the submission of ld.
Counsel for the Plaintiffs that till date, the domain name - www.origanogold.com (listed in para 12
of their application) and the website is still active.
• The Court has accessed the said domain name during the course of the hearing today and finds
that the same is still active. Mr. Wadhwa, ld. Senior Counsel, submits that he has no instructions in
this regard.
C. Submissions on behalf of Hosting Concepts B.V.
28. Ms. Kritika, ld. Counsel appearing for Hosting Concepts B.V, submits that there is a grievance
cell manned by a number of individuals, who operate between 4:30 am to 6:00 pm Central
European Time. There is also an abuse email address provided on the website. However, there is no
Grievance Officer as of now, as directed under the IT Rules, 2021. Similar directions as that passed
for GoDaddy today shall be extended to Hosting Concepts B.V as well, inasmuch as a Grievance
Officer must be appointed in consonance with the IT Rules, 2021, by 20th September, 2022.
Further, the name and contact details of the Grievance Officer shall be prominently displayed and
accessible on the website of Hosting Concepts B.V. D. Submissions on behalf of Google LLC
29. Mr. Aditya Gupta, ld. Counsel appearing for Google LLC, one of the DNRs, submits that insofar
as Google is concerned, the details of the Grievance Officer are prominently published on the
website and are as under:
"1. Legal Requests related to Content Removal If you see content on a Google product
that you believe violates applicable local laws or your rights, you can submit your
request for removal or disabling of any specific content from Google services by
filling up the appropriate webforms below ("Grievance Redressal Mechanism"):
For all Google products other than YouTube: Use the webform here where you can
submit a removal request for different legal issues including submission of a court
order that you may have obtained in your favor. This troubleshooter can be used for
all relevant Google products and services (except YouTube).
For YouTube: Use the dedicated YouTube Help Center here where you can submit a
removal request for different legal issues, including submission of a court order that
you may have obtained in your favour.Dabur India Limited vs Ashok Kumar And Ors on 14 September, 2022

These are dedicated reporting mechanisms for content removal. Submitting your
request using the above reporting mechanisms ensures that your request reaches the
relevant support team directly for their review. Providing complete information
through these dedicated reporting mechanisms (including a valid court order, if
relevant) will help us process your request expeditiously. Please note that if you
submit your request using any other means (eg. emails, faxes, physical mail etc), it
will take us longer to get to your request and to review it.
3. Service of Summons or notices to Google LLC in India If you would like to serve
any summons or notices in civil proceedings against Google LLC in India, the below
email ID and address can be used.
Please use the options for reporting content for removal as listed in Section 1 above instead if you
are not serving any summons or notices in civil proceedings.
Google LLC attn: Paul Nicholas 1600 Amphitheatre Parkway Mountain View, CA 94043 USA
E-Mail:support-in@google.com "
30. This stand of Google is taken on record.
31. This Court has been hearing these DNR matters from time to time and several orders have been
passed directing such DNRs to suspend/block infringing domain names and also provide registrant
details. Further orders seeking inputs by DNRs as to their Grievance Officer and a mechanism to
promptly ensure compliance with such orders have been passed.
32. However, insofar as GoDaddy is concerned, there is no clarity as to their position as on date.
Clearly, there is no mechanism for enforcement of the Court's orders, as there seems to be no
individual, who can be contacted through email or phone, for the purpose of giving effect to the
orders passed by the Court. It is noted that Mr. Wadhwa has sought further time to verify the same.
33. As last and final opportunity, this Court permits GoDaddy, to appoint/inform the Court of the
requisite Grievance Officers, latest by 20th September, 2022, in accordance with the IT Rules, 2021,
and notify the same prominently on their websites, making the details of the Grievance Officers
easily accessible in India. Upon failing to do so, MeitY and DoT are free to proceed against
GoDaddy, in accordance with law. If GoDaddy is in compliance with the IT Rules, 2021 by 20th
September, 2022 and appoints a Grievance Officer, it is permitted to move an application seeking
modification of today's order.
34. Insofar as those DNRs which have appointed Grievance Officers are concerned, including
Newfold Group and Google, it is made clear that they ought to function in accordance with law
including the IT Rules, 2021. In such cases, Plaintiffs are permitted to make advance service in cases
relating to domain names registered with the said DNRs to the Grievance Officers through the
contact details of the grievance officers. It would then be expected in such cases, that the said DNRs
would enter appearance or facilitate the compliance and give effect to the orders or directionsDabur India Limited vs Ashok Kumar And Ors on 14 September, 2022

passed by Courts.
35. No other DNRs have made any submissions before this Court today. MeitY is directed to look
into the issue of appointment of Grievance Officers by the other DNRs who are parties in these suits.
The said list of DNRs is as under:
                          Sl.       Domain Name Registrar                   Email ID
                          No.               (DNR)
                          1.     NameCheap Inc            legalandabuse@namecheap.com,
                                                          support@namecheap.com
                          2.     Dynadot LLC              info@dynadot.com
3. Hostinger International Ltd. / abuse@hostinger.com Hostinger UAB
4. Epik Inc. support@epik.com
5. Tucows Inc. domains@tucows.com, info@tucows.com
6. Wild West Domains LLC abuse@wildwestdomains.com
7. NameSilo LLC support@namesilo.com
8. HioxSoftwaresPvt. Ltd. support@rrpproxy.net, sales@hioxindia.com
9. 1&1 IONOS SE compliance@ionos.de
10. EPAG DomainServices compliance.epag.de
11. TLD Registrar Solutions Ltd. admin@tldregistrarsolutions.com
12. 1API GmbH registry-liaison@key-systems.net
13. Crazy Domains FZ-LLC registry@crazydomains.com, customercare@crazydomains.com
14. Appcronix Infotech Private info@vebonix.com Limited
15. Key-Systems GmbH support@rrpproxy.net
16. Free Drop Zone LLC customerservice@networksolutions.com
17. Wix.com Ltd abuse@wix.com
18. DNC Holdings Inc. inquiries@directnic.com
19. DropCatch.com domains@hugedomains.comDabur India Limited vs Ashok Kumar And Ors on 14 September, 2022

20. NameBright.com support@namebright.com
21. DNSPod Inc. info@dnspod.com
22. Dreamscape Networks legal@dreamscapenetworks.com
23. Hostgator abuse@hostgator.in
24. Milesweb sales@milesweb.com
25. NETIM support@netim.com
26. NET.4 corporatesupport@net4.in
27. Vebonix sales@vebonix.com
28. Unified Layer info@unifiedlayers.com
29. NetAlliance PTY Ltd. support@netfleet.com.au
30. Instra Corporation legal@instra.com
31. Internet Domain Service BC contact-en@internet.bs Corp
32. Shinjiru MSC SDN BHD abuse@ilovewww.com
33. Huge Domains infor@asergis.in
34. Open TLD BV (Freenom) jzuurbier@opentld.com, infoe@freenom.com
35. MarkMonitor.com abusecomplaints@markmonitor.com
36. If the said DNRs have not appointed Grievance Officers, one week's time shall be given to them
for making the appointments in accordance with the IT Rules, 2021. If the said compliance is not
made by DNRs, MeitY is free to proceed in accordance with law against such DNRs who are offering
their domain name registration, hosting and related services in India, without complying with the
local laws. A status report be put up by MeitY by the next date, on this aspect including the steps
taken by MeitY pursuant to the directions contained above.
37. List for further submissions in all connected matters, on 1st December, 2022.
38. Interim orders, wherever granted, to continue.Dabur India Limited vs Ashok Kumar And Ors on 14 September, 2022

39. The original signed copy of this order shall be placed in the lead matter being CS(COMM)
135/2022 titled Dabur India vs. Ashok Kumar, and in all other suits, the digitally signed copies shall
be placed.
40. These shall be treated as part-heard matters.
PRATHIBA M. SINGH, J.
SEPTEMBER 14, 2022 Rahul/dj/dk/ms/ssDabur India Limited vs Ashok Kumar And Ors on 14 September, 2022

