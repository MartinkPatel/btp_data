Anupam & Ors. vs University Of Delhi Through Its ... on 7
August, 2020
Equivalent citations: AIRONLINE 2020 DEL 1780
Author: Prathiba M. Singh
Bench: Prathiba M. Singh
                                                                                        SINDHU KRISHNAKUMAR
                                                                                        07.08.2020 16:45
                                $~
                                *      IN THE HIGH COURT OF DELHI AT NEW DELHI
                                                                Reserved on: 5th August, 2020
                                                             Date of decision: 7th August, 2020
                                +                        W.P.(C) 3946/2020
                                       ANUPAM & ORS.                                           ..... Petitioners
                                                         Through:     Mr. Akash Sinha, Mr. Shubham Saket
                                                                      Mr. Indrajeet Singh and Mr. Gaurav
                                                                      Prakash Shah, Advocates.
                                                                      Mr. Shivankar Sharma, Advocate for
                                                                      Intervenors.
                                                                 versus
                                       UNIVERSITY OF DELHI THROUGH ITS
                                       REGISTRAR & ORS.                            ..... Respondents
                                                     Through: Mr. Sachin Datta, Senior Advocate
                                                              with Mr. Mohinder Rupal and Mr.
                                                              Hardik    Rupal,     Advocates     for
                                                              University of Delhi.
                                                              Mr. Tushar Mehta, ld. Solicitor
                                                              General with Mr. Apoorv Kurup, Ms.
                                                              Nidhi Mittal and Mr. Siddarth
                                                              Nigotia, Advocates for R-2/UGC.
                                                              Ms. Sunieta Ojha, Advocate for R-
                                                              3/UOI.
                                       CORAM:
                                       JUSTICE PRATHIBA M. SINGH
                                                         JUDGMENT
Prathiba M. Singh, J.
1. This hearing has been held through video-conferencing. CM Appl. No. 14172/2020 (for
impleadment)Anupam & Ors. vs University Of Delhi Through Its ... on 7 August, 2020

2. Advance copy of this application has been served upon the ld. Counsels for the Respondents. The
proposed applicants are pursuing their B.A. Psychology (Hons) from Lady Shriram College (`LSR')
affiliated to the University of Delhi. They are similarly placed to the Petitioners as they are in their
final year and are aggrieved by the impugned online OBE. The proposed applicants are impleaded as
Respondents 4-8 in the present writ petition.
3. List on 22nd September, 2020.
CM Appl. No. 14163/2020 (for exemption)
4. Allowed, subject to all just exceptions. Application is disposed of. CM Appl. Nos. 14164-65/2020
(for exemptions)
5. These are applications seeking exemption from filing court fee and duly attested affidavits.
Binding the deponents of the affidavits to the contents of the applications, exemption is granted.
Insofar as court fee is concerned, the deposit of court fees with the concerned authority would be
made within one week. The physical court fee stamp would be deposited within 72 hours from the
resumption of the regular functioning of the Court. Applications are disposed of.
I.A. No. /2020 (to be numbered)
6. This application has been moved on behalf of the Petitioners seeking to place on record the
examination method adopted by Banaras Hindu University for conduct of its final-year
examinations.
7. Mr. Kurup, ld. counsel has denied the averments in the application and relied upon letter dated
5th August, 2020 sent by Banaras Hindu University to the University Grants Commission.
8. Both the University of Delhi and the University Grants Commission are permitted to file their
reply to this application within two weeks. Let the letter dated 5th August, 2020 be filed by the
University Grants Commission along with its reply. Rejoinder thereto, if any, be filed within two
weeks thereafter.
9. List on 22nd September, 2020.
W.P.(C) 3946/2020 Brief Background
10. The present writ petition is preferred by final year students of different departments and courses
of University of Delhi (hereinafter, "'DU") challenging the conduct of remote/online open book
examinations (hereinafter, "OBE") for final year/term/semester under graduate and post graduate
students, including students of the School of Open Learning (hereinafter, "SOL") and
Non-Collegiate Women Education Board (hereinafter, "NCWEB"). The Petition impugns the online
OBE which DU is to conduct for the final year/semester students of all courses. An application for
impleadment being CM. No. 14172/2020 has also been filed by the final year students studying atAnupam & Ors. vs University Of Delhi Through Its ... on 7 August, 2020

Lady Shriram College for Women (hereinafter, "LSR") raising objections to the conduct of OBE
examinations and the shortcomings in the same.
11. The petition was first listed on 6th July, 2020 on which date submissions were made on behalf of
the Petitioners as to the difficulties being faced by students in giving the online OBE including
technical glitches, crashing of portal, non-availability of internet, computer facilities, scanners for all
students etc., The University Grants Commission (hereinafter, "UGC") had, on the said date,
informed the Court that an Expert Committee headed by Professor R. C. Kuhad, which had
originally submitted a report was to submit its final report shortly. Accordingly, after recording the
various submissions of the parties, including DU, the following directions were issued:
"22. The UGC, which is an overarching body for all the universities, ought to in fact
take a decision and give its recommendations to all the Universities across the
country. UGC is a party in the present petition and it is admittedly considering the
issues relating to final year examinations. Thus, there should be no further delay in
the UGC's Committee submitting its report and the advisory from the UGC/ Ministry
of HRD, being issued to Universities in respect of conduct of final year examinations.
Accordingly, it is directed as under:
i) UGC's Committee headed by Prof. Kuhad shall submit its report to the authorities
concerned by 7th July, 2020 and the said report shall be placed on record on 7th
July, 2020 by 4:00 pm i.e., when the matter is now listed. The UGC and the Ministry
of HRD shall take a specific stand as to whether they recommend cancellation of final
year examinations. Responsible officials from the Ministry of HRD and UGC shall
join the hearing tomorrow i.e., 7th July, 2020 at 4 pm;
ii) Secondly, the DU shall place on record the following data:
a) The number of students who are studying in the final year of DU and the number
of students who are registered for the final year examinations to be conducted
through the online process;
b) A state-wise break-up of the students and from where they have to take the
examinations;
c) Preparedness of the website portal for handling of the traffic during examinations,
keeping in mind the recent technical glitches faced by students during the mock
exams;
d) The schedule of examinations i.e., evaluation of papers, date for announcement of
results and date for issuance of transcripts. While preparing and placing on record
the schedule before this Court, DU shall bear in mind the deadlines for all the final
year students who have to seek employment, deadlines for postgraduate entrance
examinations, deadlines for submission of documents to international universitiesAnupam & Ors. vs University Of Delhi Through Its ... on 7 August, 2020

where students may have secured admission etc."
12. On 7th July, 2020, DU had expressed its complete readiness to go ahead with the online OBE,
which was scheduled to commence from 10th July, 2020. However, this Court was informed that a
meeting was under-way between representatives of the Ministry of Human Resource Development
(hereinafter, "MHRD"), UGC and DU and time was sought to confirm the schedule of the online
OBE.
13. On 8th July, 2020 this Court was informed that the UGC has issued fresh guidelines on 6th July,
2020 and in the meeting held on 7th July, 2020, a decision was taken to postpone DU's online OBE
to after 15th August, 2020. In the said order, various grievances and difficulties expressed by
students were also recorded. However, keeping in view the fact that two other writ petitions relating
to the conduct of the online OBE were listed before the ld. Division Bench, the matter was placed
before the ld. Division Bench.
14. On 9th July, 2020, the present petition was listed along with WP(C) 3199/2020 titled Prateek
Sharma & Anr. v. Union of India & Anr. and other connected writ petitions. The ld. Division Bench
passed a detailed order wherein DU submitted that it would now have to work out a fresh plan and
date sheet in terms of the new UGC guidelines dated 6th July, 2020.
15. The examinations have now been directed to be held between 10th August, 2020 to 30th August,
2020. The schedule of the examination is now under consideration in Prateek Sharma (supra) and
connected matters before the ld. Division Bench. However, in this petition, the ld. Division Bench
passed the following order on 14th July, 2020:
"HEARD THROUGH VIDEO CONFERENCING CM Nos. 14163/2020, 14164/2020 & 14165/2020
(Exemption) Allowed, subject to all just exceptions.
W.P. (C) 3946/2020 & CM 14172/2020 (for impleadment)
1. The present petition has been received on transfer from the Board of a Single Judge. As we
understood, the reason for transferring the matter to this Bench was to examine the delay in
conducting the online OBE mode of examination and not the method of evaluation that the
University proposes to adopt for the final year students.
2. The scope of the other connected petitions before us is not the method of evaluating the final year
students. In other words, the online mode of examinations adopted by the Delhi University has not
been assailed in the matters placed before us.
The petitioners in the said petition are aggrieved by the lack of preparedness on the part of the Delhi
University for conducting the examinations for the final year students through the online OBE
mode, which aspect we are continuing to examine.Anupam & Ors. vs University Of Delhi Through Its ... on 7 August, 2020

3. That being the position and in view of the statement made by learned counsel for the petitioners
that the prayer of the petitioners herein, is that no manner of examination be conducted to assess
final year students and instead, they be simply evaluated on the basis of their past performance and
the OBE mode of examination be not adopted to assess them, we do not propose to link this petition
with the other petitions pending before us.
4. The present petition is accordingly detached from the batch of petitions and is directed to be
listed before the learned Single Judge for further proceedings on 20.07.2020."
Thus, the method of evaluation of the final year students, including online OBE and the challenge
thereto is to be considered in the present writ petition.
16. This matter is being heard from time to time. DU has been represented by its Sr. Counsel Mr.
Sachin Dutta along with Mr. Mohinder Rupal, Advocate and Prof. Vinay Gupta, Dean
(Examinations) and Dr. Sanjeev Singh, Joint Director, Delhi University Computer Centre (`DUCC')
have appeared before this Court from time to time. UGC has been represented by Mr. Tushar Mehta
ld. Solicitor General and Mr. Apoorv Kurup, ld. counsel. The students and the intervenors are being
represented by Mr. Akash Sinha and Mr. Shivankar Sharma. This Court had directed the UGC to
place on record the report of the Expert Committee headed by Professor Kuhad. The same has been
placed on record. This Court has also heard Mr. Dinesh Tyagi, CEO of CSC Academy, which is the
entity under which the various Community Service Centres (hereinafter, "CSC") across the country
are functioning.
17. During the pendency of this petition and certain other writ petitions which challenge DU's online
OBE, the guidelines of UGC have been challenged before the Hon'ble Supreme Court. This Court is
informed that the guidelines of UGC dated 29th April, 2020 and 6th July, 2020 are being defended
by UGC before the Hon'ble Supreme Court and the said petitions are now listed on 10th August,
2020.
Submissions of Parties
18. At the outset, Mr. Tushar Mehta, ld. Solicitor General of India, along with Mr. Apoorv Kurup, ld
counsel, have appeared for the UGC and it is their submission that the question as to whether
presentation based examinations are permissible as per the 29th April, 2020 guidelines of the UGC
is now pending in the Supreme Court as the same has been raised as a specific ground in W.P. (C)
724/2020 titled Praneeth K. & Ors. v. UGC & Ors. The grounds in the said writ petition along with
the reply thereto have been relied upon. The submission of ld. Solicitor General is therefore that
since the matter is pending before the Supreme Court, it would be advisable to defer the hearing on
this issue.
19. It is further submitted that the sanctity and credibility of examinations is very important,
especially for final year students. Reliance is placed on paragraphs 6 to 12 of UGC's affidavit which
mentions the recommendations of the Expert Committee which aided the UGC in framing the
guidelines dated 29th April, 2020 and 6th July, 2020. It is also submitted that these guidelinesAnupam & Ors. vs University Of Delhi Through Its ... on 7 August, 2020

clearly provide sufficient options to the University to conduct offline, online or a blended mode of
examination, which, however, ought to be timed i.e., for two-three hours. According to the UGC, any
other mode of examination which is without any timings whatsoever or has an enlarged timing
would be contrary to its guidelines.
20. On behalf of the Petitioners, Mr. Sinha, ld. counsel submits that the proposed OBE of DU is
violative of Articles 14, 16 and 21 of the Constitution of India. He submits that the interpretation of
the UGC guidelines given by the UGC is contrary to the spirit of its own guidelines. Ld. counsel
further submits that similarly placed students ought not to be treated dissimilarly and in the same
way, students who do not have the same kind of facilities cannot be treated similarly. He submits
that the facility of Common Service Centres (hereinafter, "CSCs") was not available for the mock
examinations and students who wish to avail of the facilities of CSCs will be using them for the first
time on 10th August, 2020. On the day of the examination, if these students find that the CSCs are
not available to them, it would place these students in a discriminatory position as against those
students who have a stable internet connection and better technological gadgets. He submits that
the counter affidavit of DU, in fact records that even in the meeting held on 2nd May, 2020 and in
subsequent meetings, DU was ready to declare the results of the examinations by 31 st July, 2020.
He submits that the sudden change in the examination schedule and seeking of a longer period for
declaration of results puts students at a completely disadvantageous position for the purposes of job
opportunities, admission to post graduate programmes, etc.,
21. Ld. counsel submits that under Article 21, DU owes a duty of care towards its students. Though
this duty of care is mentioned on paper in the minutes of meetings of the task force, the same has
not translated into action. It is further submitted that considering that 18.6 lakh people have already
been infected with COVID-19, students who have to go to CSCs and who are forced to come out of
containment zones may contract COVID-19 and have their health put in jeopardy. Further, the
insistence on conducting the examinations and the delay in conducting the same during the COVID-
19 pandemic has led to several students losing job offers etc. He submits that when the OBE itself
was conceived in April/May, 2020 the number of patients was much lower and internet connectivity
had not been affected by the monsoons, as it is today. He further submits that the first phase of the
mock examinations was a failure, which fact has also been taken note of by the ld. Division Bench of
this Court in Prateek Sharma (supra).
22. Ld. counsel urges this Court to consider the fact that the timer on the portal of DU has not been
working properly and the time limit for uploading of the paper is also not sufficient. On behalf of the
Petitioners, it is submitted that the undergraduate and post graduate students have to answer
question papers ranging from 70 marks to 100 marks in the OBE. For the said purpose, two or three
hours would not be sufficient for downloading of the question paper, writing of all the answers,
scanning each sheet, uploading each sheet separately on the DU portal etc. Accordingly, it is
submitted that a longer time-period be given to OBE students. It is further emphasized that the
guidelines of 29th April, 2020 clearly mention that the same are merely advisory in nature however,
a complete U-turn has been taken in the guidelines of 6th July, 2020 which have been changed from
advisory to mandatory.Anupam & Ors. vs University Of Delhi Through Its ... on 7 August, 2020

23. It is also submitted that the UGC's stand that more than 200 Universities have already
completed their examinations as per the guidelines is completely incorrect. The Petitioners rely
upon a crowd-sourced chart of various Universities and the manner in which their examinations
have been conducted to argue that till date the list of 200 Universities which the UGC claims have
completed their examinations have not been given. The data collected shows that NLU-Delhi,
NLU-Jodhpur, School of Environmental Sciences, JNU, RMNLU-Lucknow, TISS, Banasthali
Vidyapith, etc have all conducted their examinations with extended timelines of 24 hours to 48
hours. Thus, the stand of the UGC is contrary to the established stand of various Universities which
have already conducted their examinations and given degree-certificates to their students. It is
therefore submitted that the students of DU are being unfairly prejudiced for no rhyme or reason.
24. It is further urged that Prof. Rajnish Jain, Secretary & CVO, UGC has given an interview on
national television where he has stated that even take- home examinations, assignments, etc. are
options available to final year students. Reference is also made to the instance of Banaras Hindu
University issuing mark-sheets and declaring the results of final year students from Fiji after
intervention by the Embassy of Fiji. It is thus submitted that the OBE does not take care of any
concern of the students and is discriminatory in its current form.
25. Mr. Kurup, ld. counsel on behalf of the UGC submits on instructions that the interview of Prof.
Rajnish Jain is being misinterpreted inasmuch as the statement made by him was in the context of
internal examinations and not external examinations for final year students.
26. Mr. Shivankar Sharma, ld. counsel appearing for the intervenor, has taken the Court through
DU's brochure to argue that the total students would be approximately 6 lakhs with approximately 2
lakh students being in the undergraduate programmes, approximately 27,000 in post graduate
programmes and approximately 500 foreign students. The School of Open Learning has
approximately 4 lakh students, more than half of which are from outside Delhi. Ld. counsel submits
that the spread of students from across the country in DU shows that they are not similarly placed.
27. Ld. counsel further points out that the minutes of the Task Force constituted by DU and the
Working Group on Examinations do not show any rationale for having chosen this kind of an online
OBE, which puts the lives and careers of so many students at stake. The teachers, students and none
of the other stakeholders were consulted. There is thus no basis for DU's online OBE. It is further
submitted that the examination also discriminates between students who have stable internet
connection and those who do not. Ld. counsel submits that those students who use only 2G and 3G
connections and do not have wired broadband connectivity are unable to get quick access. It
therefore puts some students who are based out of Delhi and other metropolitan cities at a
geographical advantage whereas students from tier-2 cities face a major disadvantage.
28. Ld. counsel further submits that for a 75 mark question paper a student writes approximately 40
sheets and each sheet is to be scanned, however, no technical details have been given as to how the
scans are to be prepared. Various popular scanning apps including Cam Scanner are now banned as
they originate from China. Moreover, scanning page by page may lead to a large number of technical
difficulties as the order of the papers may be jumbled up. Alternatively, a question/answer wise scanAnupam & Ors. vs University Of Delhi Through Its ... on 7 August, 2020

could have been provided, however, then the 5 MB limit would be breached.
29. The major contention of Mr. Sharma is that the OBE is a serious invasion of privacy as the data
of all the students has been uploaded on a cloud server and the location of the said server is
unknown. The credentials of the entity Motherson Sumi Systems Pvt. Ltd., which is a private entity
which DU has entered into an agreement with has not been established. The students have provided
their names, addresses, e-mails, phone numbers etc. and the answer sheets will also be uploaded on
this cloud server. However, within DU only one person - Dr. Sanjeev Singh, Joint Director, Delhi
University Computer Centre is in charge and is working with the help of some research students.
Considering that lakhs of students are to give the OBE the technical staff is also insufficient. It is
thus submitted that DU ought to have explored other forms of evaluation including MCQs etc. Ld.
counsel relies upon paragraphs 248 and 326 of the judgment of the Supreme Court in Justice KS
Puttaswamy v. UOI, (2017) 10 SCC 1 to argue that all three dimensions of privacy, namely spatial
control, decisional autonomy and informational control are being breached without the consent of
students. It is thus submitted that though DU declares that it supports the cause of its students, the
apprehensions of the students are not being adequately addressed by the University.
30. In response to the submissions of the Petitioners that several Universities have not followed the
timed online/offline mode of examinations mandated by the UGC, ld. Solicitor General submits that
the UGC contacted the said Universities for a clarification and was informed that these Universities
had, in fact, either conducted their examination as per the guidelines or prior to the UGC's
guidelines dated 6th July, 2020.
31. Mr. Sachin Datta, ld. Senior Counsel along with Mr. Mohinder Rupal, ld. Counsel have made
their submissions on behalf of DU. On a query from the Court, they submit that the number of
students attempting the mock examination was not very high, however, the order of the ld. Division
Bench passed today permits DU to go ahead with the online OBE. It is further submitted that the ld.
Division Bench has given students, who are unable to appear in the online OBE, the option to
appear in physical mode. Mr. Datta submits that the timelines for conduct of the physical mode of
OBE and timelines for announcement of results of the same are being monitored by the ld. Division
Bench.
32. Insofar as the present petition is concerned, Mr. Datta's arguments are threefold. The first is that
the prayers made in the writ petition do not survive. He points to prayers (a) and (b) in the present
writ petition to submit that prayer (b) has become infructuous in view of the challenge to the UGC
guidelines before the Hon'ble Supreme Court. Insofar as prayer (a) is concerned, he submits that the
challenge to all three notifications, i.e. notifications dated 14th May, 2020, 30th May, 2020 and 27th
June, 2020, has also become infructuous as these notifications have been superseded by notification
dated 15th July, 2020. Thereafter, he submits that the Task Force and the Working Group on
Examinations, which were set up by DU, consisted of highly qualified academicians who have
applied their minds and after taking into consideration students' comments taken the decision that
owing to the pandemic, online OBE is the best method for evaluating students. He further submits
that the primary grievance of the Petitioners, as contained in grounds (F) and (H) of the writ
petition, proceeds on the assumption that students would not give the online OBE honestly and thatAnupam & Ors. vs University Of Delhi Through Its ... on 7 August, 2020

an undertaking, which has been taken from the students, would not suffice. In these circumstances,
where a physical examination is not conducive to the health of the students, online OBE should
come as a reprieve to students and in fact, safeguards their fundamental rights, including under
Article 21 of the Constitution of India. It is further submitted that the ld. Division Bench now having
supervised the conduct of the examinations, its timelines and results would also be announced in
the shortest possible time. He submits that if online examinations are not held, there would be a
higher risk to students in terms of the social distancing norms not being met.
33. The next submission of Mr. Dutta is that the Petitioners or the Intervenors have not expressed
any personal grievances and have raised generic grievances. It is submitted that DU has, in fact,
gone out of its way to take care of the interests of its students and that this fact is not being
appreciated. With question papers being transmitted through email and uploading of answer sheets
being allowed through the same, apprehensions regarding the portal have also been reasonably
addressed. Mr. Datta further urges that the scope of interference in education related matters is very
limited. He submits that since the decision has been taken by senior academicians, the Court should
be reluctant to interfere. Reliance is placed on AICTE v. Surinder Kumar Dhawan & Ors., (2009) 11
SCC 726 to submit that Courts have adopted a hands-off policy insofar as education related matters
are concerned. It is also urged that the mock examinations have been conducted in so many phases
that students are now completely acclimatized to the portal and to the method of giving the online
OBE. He submits that DU has, in fact, taken several steps to redress the grievances of students. The
following steps are enumerated by the counsels:
i. All question papers would be simultaneously sent to students by email at the time
of start of the online OBE; ii. The question paper has been designed for being
completed in two hours, however 3 hours' time has been given to students to submit
their answer sheets;
iii. The email address on which answer sheets may be submitted has also been
created. Notifications dated 2nd July, 2020, 5th July, 2020 and 31st July, 2020 are
relied upon. The said notifications, apart from providing central email addresses also
provide emails of the nodal persons in different colleges and different departments.
Helplines have also been created along with the emails which are stated to have been
posted on the website of DU. iv. Insofar as submission of answer sheets is concerned,
if there is any dispute raised by any student, a committee of four academicians has
been constituted on 4th August, 2020, to deal with the same. v. In relation to the size
of the file that can be uploaded, after instructions from Dr. Sanjeev Singh, Joint
Director, DUCC, it is confirmed that one file of one page between 5 to 7 MB can be
uploaded. There is also a timer on the portal. Prof. Vinay Gupta, Dean
(Examinations), who appears today has also clarified that students have the option of
scanning answer sheets question wise and submitting the same in pdf form or they
can also convert the entire answer sheet into one pdf file and send the same by email.
vi. The range of marks for regular students is 70-75 for undergraduate students and
post-graduate students, however, marks for the LLB exam are 100. Insofar as the
School of Open Learning is concerned, the marks for papers would be 100.Anupam & Ors. vs University Of Delhi Through Its ... on 7 August, 2020

34. Mr. Datta further submits that DU's decision to conduct online OBE was taken keeping in mind
the UGC guidelines dated 29 th April, 2020, which are not under challenge in the present petition.
In conclusion, Mr. Datta submits that DU is not considering this litigation to be adversarial and any
proactive and positive suggestions to ensure a smooth online OBE would be acceptable to DU.
35. Mr. Rupal submits that insofar as the intervenors are concerned, their application has not yet
been allowed. Notice has also not been issued in the said application and he would like to file a reply
to the same.
36. Ms. Sunieta Ojha, ld. counsel appearing for MHRD relies upon the short affidavit filed by MHRD
before the ld. Division Bench.
37. In rejoinder, Mr. Sinha, ld. Counsel for the Petitioners submits that the argument that the prayer
has, in fact, become infructuous, is not tenable as the notification dated 15th July, 2020, which has
been issued post the order dated 14th July, 2020 of the ld. Division Bench, is based on the original
notification dated 14th May, 2020. Secondly, it is submitted that the main Petitioner in the present
petition is from Bihar where there is a complete lockdown and ongoing floods. He further submits
that it cannot be argued by DU that generic grievances have been raised because the intention was to
give suggestions. For instance, at the time of filing of the petition, the option of receiving question
papers on email was not available. It was only during the course of hearings by this Court that such
an option has become available to the students. Ld. counsel further submits that repeated
postponements of the examinations have caused huge financial losses to the students and the
manner in which the same were decided has been completely arbitrary. He submits that the main
Petitioner could not upload his answer sheets in the mock examination. On the legal issue, it is
submitted that there is no bar on the Court to interfere in education matters, when the decision
made by the expert body is itself arbitrary.
38. Mr. Sharma, ld. Counsel for the Intervenors relies upon two judgments U.P. State Brassware
Corporation Ltd. & Anr. v. Uday Narain Pandey, (2006) 1 SCC 479 and A.P. Bankers and Pawn
Brokers' Association v. Municipal Corporation of Hyderabad, (2001) 3 SCC 646 to argue that the
Court can exercise its plenary powers to mould the reliefs. In any event, it is his submission that now
that the emphasis on the portal is not there and answer sheets can be sent through email, out of 91
colleges, emails of only 60 colleges have been published and DU ought to be directed to publish the
remaining emails. He further submits that DU should be asked to confirm whether the emails given
by them can handle the size of the attachments to be sent by students.
39. Mr. Sharma submits that out of all the Intervenors, one intervenor, who has obtained admission
in various universities in UK is unable to submit her degree and her transcript as deadlines for
uploading the same have already expired. Secondly, one of the Intervenors is from Nagaland where
she does not have proper internet connectivity and will be facing difficulty in given the online OBE.
40. In response to the said submissions by Mr. Sharma, Mr. Datta submits that none of the grounds
raised today have been raised in the impleadment application.Anupam & Ors. vs University Of Delhi Through Its ... on 7 August, 2020

41. In sur-rejoinder, Mr. Rupal submits that when the grievances of students were recorded in order
dated 8th July, 2020, the Petitioners were given an option to convert their petition into a PIL, which
option was not availed of. All these grievances cannot now be considered by this Court.
Analysis and Findings
42. The prayers in the present writ petition are as under:
"a. Issue an appropriate writ, order or direction in the nature of mandamus or any
other writ or direction as this Hon'ble Court may deem fit in the interests of justice,
thereby directing Respondent No.1 to withdraw its notifications dated 27.06.2020,
30.05.2020 and 14.05.2020.
b. Alternatively issue an appropriate writ, order or direction in the nature of
mandamus or any other writ or direction as this Hon'ble Court may deem fit in the
interests of justice, thereby directing Respondent No.1 to evaluate the final year
students based on the previous years' or semesters' results in the same manner as the
Respondent University has planned to promote the first and second year students of
the Respondent University. c. Pass any other order, this Hon'ble Court may deem fit
and proper under the facts and circumstances of the case in interest of justice."
Prayer (b) is not pressed by the Petitioners for now as the challenge to the UGC guidelines which
mandate final year examinations, is pending before the Hon'ble Supreme Court. The ld. Division
Bench in its orders passed in Prateek Sharma (supra), laid down the schedule for the OBEs. The ld.
Division Bench is also monitoring the timelines in the interests of the students so as to ensure that
the entire process is concluded at the earliest. Vide order dated 5th August 2020, the Ld. Division
Bench has noted various facts and given certain directions:
• The data relating to the first phase and the second phase of the Mock tests were
analysed and it was noted that the data relating to the second phase was more
abysmal than that of the first phase;
• There are indications that final year students are facing difficulties in uploading of
answer sheets;
• Thus all final year students who are not in a position to participate in the online
OBE will have the option to sit in physical examinations later on, even if the student
has downloaded the question paper and is unable to upload the answer sheets;
• However, those students who email the answer sheets would not be permitted to sit
in the physical examination for that subject; • Students have the option to either
upload the answer sheet or email the same;Anupam & Ors. vs University Of Delhi Through Its ... on 7 August, 2020

• Those students who are appearing for the online OBE and wish to secure admission
in a PG course will be granted admission subject to clearing the entrance
examination.
43. Prayer (a) challenges the notifications which capture the DU's decision for conduct of OBE
examinations and the modalities thereof. Thus, the entire need, mode, format and other aspects of
the OBE examinations are under challenge in this writ petition. The Petitioners in fact pray that the
online OBE itself should be cancelled. However, owing to the pendency of the petitions in the
Supreme Court as also the directions given by the Ld. Division Bench, for the present, the issues are
in a narrow compass. The online OBEs are scheduled to commence on 10th August 2020, after
repeated postponements. The question that is to be examined, at this stage, is whether any further
directions need to be issued in the conduct of online OBE, in the larger interest of the student
community, who are already under tremendous stress owing to the COVID-19 pandemic and the
uncertainty of the examinations.
44. Examinations for the final semester/term/year students (hereinafter, "Final Semester
Students") were originally scheduled to be conducted by DU in May, 2020 and results were to be
announced by the end of June/July, 2020. The lockdown came into effect in the last week of March,
2020 and DU notified its Task Force on 27th March, 2020, comprising of 21 members, for making
recommendations in respect of the academic activities of DU. The said Task Force held its meeting
on 2nd May, 2020 and suggested the following academic calendar:
                                             Online teaching learning          28th April to 14th
                                             using interactive, real time      May, 2020
                                             applications (in continuation
                                             to the semester from 1st Jan to
                                             27th April, 2020)
                                             Dispersal of classes              15th May, 2020
                                             Evaluation of Practicals,         16th May, 2020 to
                                             Internal           assessment,    31st May, 2020
                                             Dissertation, Project work,
                                             Assignment etc. Including
                                             completion of syllabus
                                             Summer Vacations               1st June, 2020 to 30th
                                                                            June, 2020
Theory Examination begin 1st July, 2020 to 31st for Terminal Semester/Year July, 2020 along with
evaluation and declaration of results Beginning of academic 1st August, 2020 session 2020-21 2nd
/3rd Years 1st September, 2020 Fresh batch (1st Semester / Year)
45. As per the minutes, an online OBE was to be conducted from 1st July, 2020 to 31st July, 2020
for a reduced duration. The relevant extract from the said minutes is set out herein below:
• "As far as third year students are concerned, the university will conduct
examinations in Open book mode with reduced duration of examination. It has been
recommended that examinations will be of 2 hours duration. Reduced duration willAnupam & Ors. vs University Of Delhi Through Its ... on 7 August, 2020

allow more number of sessions and will be logistically more manageable. Additional 1
hour will be given to the students for IT related activities (including downloading of
question paper, scanning of written answer script, uploading of answer scripts, etc).
For PWD students, the duration will be 20 minutes extra for each 01 hour duration of
Examination.
• The modalities of conduct of such examinations including coordination with the respective
authorities of the government for arrangement of online facilities in the remote areas, facilities for
the differently abled in terms of logistics and conduct of examinations, training for the paper setters
and evaluators in terms of conduct of open- book mode will be looked into by a sub-committee
consisting of Dean (Examination) and Joint Director (DUCC). A sub-committee is already engaged
in preparing the Open-Book Manual."
46. On 6th May, 2020 a Working Group on Examinations, comprising of 15 members, was
constituted to oversee examination related matters. The said Working Group met on 10th May,
2020 and decided upon the following calendar:
a) Terminal semester/year examinations:- 01.07.2020 to 15.07.2020
b) Intermediate semester/year examinations:- 16.07.2020 to 31.07.2020
c) Evaluation and declaration of results:- 31.07.2020.
47. On 30th May, 2020, guidelines for conduct of the online OBE were issued by DU, as per which
the examinations were to commence from 1 st July, 2020. The said notification contemplated the
conduct of the online OBE in terms of the notification dated 14th May, 2020. It was further
contemplated that the online OBE would be an alternative mode of examinations for final semester
students.
48. The various features of the OBE as per the said guidelines are as under:
a) OBE would be conducted through an online platform.
b) Students would download the question paper from the platform, which would be
made available as per the date-sheet, and after writing their answers, upload the
answer-sheets.
c) The question paper was also to be provided by email to the college prior to the
commencement of the examination and if required, the college would, thereafter,
send the question paper directly to the students either by email or WhatsApp.
d) If any student was unable to upload the answer sheet on the portal in case of an
emergency, the same could be sent in pdf format to the email of the college.Anupam & Ors. vs University Of Delhi Through Its ... on 7 August, 2020

e) The total duration of the OBE was to be 3 hours, out of which 2 hours were to
answer the question paper and the additional one hour was for the purposes of
downloading the question paper and uploading the answer sheets. Students
belonging to the PWD category were to be given 5 hours.
f) Students were permitted to avail of the ICT infrastructure of their respective
colleges or the facilities of the nearest CSCs. The CSCs have been engaged through
the Ministry of Electronics and Information Technology (hereinafter, "MEITY").
g) Students were also to give an undertaking to not adopt any unfair means.
h) Students from remote areas would have a further chance to appear in the
examinations after the result of the online OBE is declared.
i) Mock examinations were to be conducted to facilitate the students.
49. Thereafter, various measures are stated to have been taken by DU. According to DU, the conduct
of the online OBE is as per the UGC guidelines dated 29th April, 2020.
50. The online OBE was initially challenged in WP(C) 3411/2020 titled National Federation of the
Blind v. UOI & Ors. in which the ld. Division Bench of this Court had passed some directions
permitting the conduct of these examinations. Thereafter, in Abhishek & Ors. v. University of Delhi
[W.P. (C) 3268/, decided on 23rd June, 2020] online OBE was again considered. In Abhishek
(supra), it was recorded by the Court that mock examinations would be conducted at least one week
prior to the main examinations. Internet access was also to be provided by the colleges in order to
enable students to have adequate infrastructure facilities. The validity of the online OBE was left
open. However, the online OBE fixed for 1st July 2020 was postponed.
51. The present writ petition was then filed challenging the conduct of online OBE on various legal
and factual grounds. The writ petition was first listed on 6th July, 2020. The postponement and the
non-release of specific dates for the online OBE was also challenged. The mock test, which had
commenced, had also revealed several technical glitches. This Court was informed that students who
reached the CSCs were unable to use any facility as the CSCs had no information about the mock
test. The portal of DU was also not functioning properly and was repeatedly crashing. An
impleadment application was also moved by five students of the Lady Shri Ram College, who
informed this Court of major technological lapses. It was submitted that hundreds of students had
difficulty logging into the portal and accessing the question paper. Students were also unable to
upload their answer sheets.
52. This Court took note of all the facts, including screen shots showing crashing of the portal. It was
also noted that in DU, students hail from across the country, including remote areas. It was thus
concluded that various developments had taken place after the orders passed in National Federation
of the Blind (supra) and Abhishek (supra), including reconsideration by the UGC, postponement by
DU, mock tests not being conducted in time, technical glitches and lack of access to CSCs. In fact,Anupam & Ors. vs University Of Delhi Through Its ... on 7 August, 2020

the directions given even in these two petitions were not complied with. It was also noted that
various Universities had already completed their final semester examinations by adopting
alternative methods, including on the basis of past performance and internal assessments.
53. On 7th July, 2020 submissions on behalf of DU were recorded including the submission that
further facilities had been made available to students. On 8th July, 2020, two fresh writ petitions
being Akshay Lakra & Ors. v. University of Delhi & Ors. [W.P.(C) 4002/2020] and Kabir Sachdeva
v. University of Delhi & Ors. [W.P.(C) 4029/2020] were filed. DU had again postponed the
examinations without any specific date. The matter was then placed before the ld. Division Bench,
which re-allocated the case to this Court on 14th July, 2020 for examining the method of evaluation
proposed by DU i.e., online OBE and if any directions were to be passed in respect thereof.
54. The various legal arguments which have been raised by the Petitioners as to how the online OBE
is arbitrary and discriminatory in nature are not gone into at this stage owing to the directions
passed by the ld. Division Bench permitting DU to proceed with the online OBE. Consideration of
prayer (b) of the writ petition would also have to await the decision of the Hon'ble Supreme Court in
the challenge to the UGC Guidelines. Issues relating to the notification of the Task Force, the
Working Group on Examinations and the bypassing of the academic council and the executive
council are also not being considered at this stage as the same are also subject matter of various
other writ petitions pending in this Court both before a ld. Single Judge and the Ld. Division Bench.
55. This Court is mindful of the fact that enormous preparations have now been undertaken by
students for giving the online OBE. Under such circumstances, the Court is concerned about the
manner in which the processes in the online OBE can be further streamlined in the larger interest of
the students, including the Petitioners.
56. The challenges for students in the last six months have been of an extreme nature. Several
students have been confronted with personal tragedies, including suffering from COVID-19 or their
family members suffering from it. Several students had obtained jobs where they were to join after
graduating. A large number of media reports have also appeared wherein it is reported that students
who had pre-placement offers have been unable to join due to non-conduct of the examinations.
Several students wanting to apply for post graduate courses and appear in entrance examinations
have also been deprived of this opportunity. Some of the students who have come before this Court
had obtained admissions in foreign universities for the academic year 2020-21 but have been forced
to forfeit their admissions or miss their deadlines and seek extensions thereof. Students have also
suffered bereavements in their families but are being forced to give examinations. Students who had
been offered employment also face the threat of termination. Post graduate examinations have been
held by various other institutions across the country and DU students have been put to a
disadvantage. Above all, the traumatic mental condition of the students has not been taken into
consideration.
57. The fundamental purpose of conducting examinations is to evaluate the students on the basis of
the syllabus which has been taught. It is a matter of fact that DU had a mid-semester break till 15th
March, 2020. Immediately thereafter, the lockdown was notified. Thus, in effect, very few classes, ifAnupam & Ors. vs University Of Delhi Through Its ... on 7 August, 2020

any, were held during the entire semester. Most of the students have also not had any access to the
hard copy reading material. Some students have been able to avail of online reading material. It is
under these extreme and extra-ordinary circumstances that the final semester students are giving
their online OBE.
58. The final semester students of most courses have already completed 80% to 90% of their courses
and they are being tested in the final semester only for the subjects which are part of the final
semester. The final semester is in fact just like any other semester in the course. In view of the
manner in which the semester examinations are conducted, the final semester is not an evaluation
of the knowledge or capability of students in respect of the entire course. The subjects in each of the
semesters are different from the previous semesters and are mostly not in continuity of the previous
semester. Thus, in the final semesters, fresh subjects ought to have been taught, course material had
to be given and thereafter, examinations were to be held. However, none of this has happened and
the final semester students are now expected to give their final examinations. Students have also
faced several technical issues as they do not have access to proper internet connections and
computer facilities. As per DU's own FAQs, 4G connection is recommended in order to appear in the
online OBE.
59. The UGC was directed to place on record the Kuhad Committee report. The same has been
placed on record and perused by the Court. The first report dated 24th April, 2020 sets out the
issues looked into by the Kuhad Committee, which are as under:
"1. Continuity of educational services and also ensuring the safety and security of the
students, faculty and staff.
2. Timely completion of syllabi, conduct of the examinations and declaration of
results.
3. Facilitating the students to participate in further admissions, placement processes,
research and training etc.
4. Charting out a plan for the next academic session."
60. As per the report, members of the Committee interacted with various stakeholders including the
Vice-Chancellors of Central and State deemed universities and principals of colleges and academic
institutions. The recommendations of the Committee for the academic year 2019-20 were as under:
"2. The Committee recommends the following calendar for the academic session:
2019-2020.
                                                 Start of Even Semester             01.01.2020
                                                Suspension of Classes              16.03.2020
                                                Continuation of effective          16.03.2020 to
                                                delivery of education through e-   15.05.2020
                                                learning modeAnupam & Ors. vs University Of Delhi Through Its ... on 7 August, 2020

                                                Finalisation of                    16.05.2020 to
                                                Dissertation/Project               31.05.2020
                                                Work/Internship Reports/E-
                                                labs/Completion of
                                                Syllabus/Internal
                                                Assessment/Assignment/Students
                                                Placement Drive
                                                (Through Online Resource
                                                Only)
                                                Summer Vacations                   01.06.2020 to
                                                                                   30.06.2020
                                                Conduct of Examinations:
                                                  (i)   Terminal                   1.07.2020 to
                                                        Semester/Year              15.07.2020
                                                    (ii) Intermediate              16.07.2020 to
                                                         Semester/Year             31.07.2020
                                                Evaluation and Declaration of
                                                Result:
                                                  (i)    Terminal                  31.07.2020
                                                         Semester/Year
                                                    (ii)   Intermediate
                                                           Semester/Year           14.08.2020
                                                                                                  "
61. The Committee noted that Universities could adopt simpler modes and methods
of examination. Hiring of private agencies for conducting alternative examinations
was held to not be feasible. The Committee made significant observations in respect
of conduct of online examinations. The same are extracted herein below:
"4. Existing Modes of Examinations The learning process is a dynamic interaction
where the only way to figure out what students know is to seek evidence of their
knowledge and to evaluate it. Maintaining the sanctity of academic expectations and
integrity of examination process, the universities may adopt alternative and
simplified modes an methods of examinations to complete the process in shorter
period of time in compliance of CBCS requirements as prescribed by UGC from time
to time. These may include MCQ/OMR based examinations, Open Book
Examination, Open Choices, assignment/presentation-based assessments etc. Like
the modes of teaching-learning, most of the universities follow the physical mode
with a few exceptions. On this aspect also, the Committee noted that some of the
universities lack adequate IT infrastructure for conducting online examination. The
hiring of private agencies for the conduct of online examination does not seem
feasible n view of the fact that examinations are to be conducted simultaneously by
all the universities.
The Committee deliberated the issue at length regarding options of conducting
online/ offline examination and opined that keeping in view the basic infrastructureAnupam & Ors. vs University Of Delhi Through Its ... on 7 August, 2020

at institution level and accessibility of the internet to the students, especially in
remote areas, it is not feasible to uniformly adopt the online mode of examination.
However, the universities may choose offline/ online mode at their level following
due procedure, depending upon the support system available with them and ensuring
fair opportunity to all the students."
62. A perusal of the above shows that the Committee had categorically observed that it was not
feasible to uniformly adopt the online mode of examination, owing to the lack of access to the
internet especially in remote areas. The Committee also noted that `fair opportunity' ought to be
given to students. As per the calendar suggested by the Committee, final year examinations were to
be concluded by 15th July, 2020. Various options were given for conduct of the examinations,
however, since the interpretation of methods of examination is now pending before the Hon'ble
Supreme Court, this Court is not going into the same. What is, however, important is the emphasis
by the Committee on the commencement of the fresh academic year of 2020-21 by 1st September,
2020.
63. The above report was considered by the UGC which notified guidelines of 29th April, 2020,
along with a slightly modified academic calendar. However, a second report is stated to have been
submitted on 6 th July, 2020 in view of the prevailing pandemic and subsequent lockdown. The
Committee prepared revised guidelines and recommendations in light of problems being faced by
various Universities and Institutions regarding the conduct of examinations / assessment,
particularly in Institutions with students from remote or far flung areas of the country.
64. Thus, the expert Committee deemed it appropriate to recommend the online/offline or blended
mode for holding the examinations, which are to be completed by September, 2020. On the basis of
the said report, revised guidelines were issued by the UGC on 6th July, 2020 by which it was laid
down that examinations have to be concluded by the end of the September, 2020 in offline
/online/blended mode. The interpretation of the UGC guidelines is subject matter of the petition
before the Hon'ble Supreme Court. In the backdrop of these two reports, the online OBE
examinations by DU are being now conducted.
65. During the hearing of this writ petition, the following facts have been noted from time to time in
various hearings:
• There are a total of approximately 2.45 lakh students out of which 1.86 lakh
students are from Delhi and about 60,000 are from outside of Delhi. The spread of
students from outside Delhi ranges to almost all States in the country, barring a few.
• Several states such as West Bengal and Bihar have been affected by floods. Some states do not have
complete internet penetration. Students from outstation studying in DU have all gone back to their
respective hometowns.
• Online OBE are being held for a majority of the courses and are for the same number of marks as
the exams earlier scheduled to be held in physical mode.Anupam & Ors. vs University Of Delhi Through Its ... on 7 August, 2020

• All students especially in remote areas do not have internet facilities, computer facilities and other
hardware facilities. They are to avail of Common Service Centres i.e., CSCs which are run by the CSC
Academy under MEITY, Government of India.
• Data relating to the students who would be visiting CSCs is not available with DU and the list of
students who wish to use the services of CSCs has not been given to CSC Academy. Students have to
make their arrangements.
• Access to CSCs was not available for mock examinations as the same was not requested.
• Insofar as the portal itself is concerned, the data i.e., the question papers and answer sheets are to
be located on a cloud server. Cloud server services have been obtained by DU from M/s. Motherson
Sumi Systems Pvt. Ltd., which has in turn availed the services of Amazon Web.
• The roll numbers of the students is not to be masked.
In the backdrop of these facts it needs to be seen as to whether any directions are required to be
passed in this writ petition.
66. DU has relied on AICTE (supra) which deals with the scope of interference by Courts in
education matters to argue that no interference is called for in the OBE examinations. The said case
dealt with dilution of eligibility conditions for pursuing engineering courses. In the said context, the
Hon'ble Supreme Court held that the creation of a bridge course by the High Court to enable
students to pursue engineering would not be permissible. The Court observed as under:
"16. The courts are neither equipped nor have the academic or technical background
to substitute themselves in place of statutory professional technical bodies and take
decisions in academic matters involving standards and quality of technical education.
If the courts start entertaining petitions from individual institutions or students to
permit courses of their choice, either for their convenience or to alleviate hardship or
to provide better opportunities, or because they think that one course is equal to
another, without realising the repercussions on the field of technical education in
general, it will lead to chaos in education and deterioration in standards of
education."
Eligibility goes to the root of education. The question of eligibility and the challenge to the online
OBE as raised herein are completely different issues. AICTE (supra) raises the question as to
whether the educational standard set by AICTE should be diluted. The Court in the present case is
wrestling with circumstances which are unprecedented. The outbreak of the COVID-19 pandemic,
the non-availability of guidance of teachers for the students, lack of any exchange of views amongst
peers due to absence from campuses, absence of classroom teaching in the entire semester,
non-availability of hard copies of study material etc. are situations which were not contemplated in
AICTE (supra). Various authorities, including the Court, are grappling to find the best manner in
which students' interests can be safeguarded in these unprecedented times. The adoption of aAnupam & Ors. vs University Of Delhi Through Its ... on 7 August, 2020

hands-off approach in such a situation is neither the norm nor what was contemplated in AICTE
(supra).
67. It is a matter of record that hundreds of students have faced technical glitches while using the
online portal of DU. Since the filing of this petition, various developments have taken place, both in
the orders passed by the ld. Division Bench and by this Court. Submissions of all the parties have
been considered. In the present case, hearings over the last one month have demonstrated several
lacunae in the online OBE process. However, repeatedly, DU has taken the stand that it is fully
prepared to conduct the examinations.
68. The first postponement of examinations from 1 st July, 2020 to 10th July, 2020 took place, as
per DU, as a Deputy Registrar in DU was affected by the coronavirus. Thus, the absence of one
official due to the pandemic resulted in postponement of the examinations. Thereafter, on 7th July,
2020, the minutes of DU's High Powered Committee record as under:
"5. The Committee resolves that there is a requirement to carry out a comprehensive
review of the arrangements taken into account the following:
(i) the UGC guidelines issued on 6th July, 2020 ;
(ii) viewpoint expressed during the inter- departmental meeting attended by
representatives of DU, UGC and Ministry of HRD that the level of preparedness
should be upgraded further in light of increasing complaints;
6. The Committee also notes that the number of complaints from students have
increased during the course of mock tests in last two days that are being conducted. It
appears to the Committee that there is necessity to spread greater awareness about
the OBE examination so that there are no misgivings in any quarter either about the
credibility of the examination process or about its efficacy.
7. Taking onto account all aspects and circumstances, particularly the developments
that have taken place in the last couple of days, it is decided to postpone the holding
of examinations after 15-08-2020."
69. These facts i.e., the initial postponement from 1st July, 2020 to 10th July, 2020 and the minutes
above, which record a large number of complaints from students, resulting in further postponement,
itself are evidence of the fact that the apprehensions as to the smooth conduct of online OBE,
evaluation and declaration of results are not completely unfounded. Even the Ld. Division Bench
has noticed the abysmal record in the mock exams.
70. DU in its counter affidavit, admits that students from remote areas lack internet and hardware
facilities. Paragraphs 11 & 13 of its affidavit read as under:Anupam & Ors. vs University Of Delhi Through Its ... on 7 August, 2020

"11. The University of Delhi is bound to protect the interests of those students who
are residing in areas like Jammu and Kashmir and other such areas all over India
which lack the internet and hardware facility required for the OBE and have stuck up
at their places due to the COVID 19 pandemic.
...
13. The students shall be allowed to use the ICT infrastructure resources available
with the CSC academy for downloading and taking print out of the question papers,
scanning and uploading the answer sheets on the portal."
Thus, as per DU, CSCs are crucial for students who are in remote areas. However, the availability of
CSCs is also under a cloud. Students may therefore be compelled to use their own resources for
giving the examinations.
71. The UGC in its affidavit dated 3rd August, 2020 also recognizes the needs of students who may
obtain employment and those who intend to pursue post-graduate studies. It accordingly submits
that Universities are free to conduct their final examinations for such students on an early date or
even stagger their examinations, so that they are conducted sooner rather than later. The relevant
extract of the UGC's affidavit is extracted hereinbelow:
"... The UGC guidelines do not stipulate specific timelines for such examinations (as
long as they are conducted before the end of September 2020), or mandate a specific
mode of examination because that is a decision which must be taken by universities /
institutions after assessing their circumstances and the needs of their students,
including those who may have obtained employment or intend to pursue
post-graduate studies. Thus, for e.g. universities / institutions are free to conduct
their final / terminal examinations for such students at an early date, or may choose
to stagger such examinations so that such students are tested sooner rather than
later."
72. Thus, the Expert Committee headed by Professor Kuhad, the affidavit of DU and the affidavit of
the UGC acknowledge the existence of difficulties in accessing internet facilities as also the
difficulties for students who intend to obtain employment and appear in post-graduate courses,
entrance examinations, etc.
73. The maximum marks for various examinations in the OBE are also broadly the same as the
examinations held in physical mode. The marks for which students have to be evaluated have not
been reduced. In the physical mode, students were being given 3 hours for completing theory papers
of 70 to 100 marks. DU submits that for the same amount of marks, the question papers have been
altered so that students can complete the same in 2 hours. Issues relating to the manner in which
the question paper has been set and whether the same can be completed within two hours or not
cannot be adjudged at this stage by the Court. The qualitative assessment of question papers is not
to be done by the Court. Maximum marks for the papers being the same as that for the physicalAnupam & Ors. vs University Of Delhi Through Its ... on 7 August, 2020

mode and time given also being the same, this Court is of the opinion that some extra time needs to
be provided to students for the purpose of completing technical and procedural formalities.
This is also recognised by the DU's own task force in its Minutes dated 2nd May 2020 as extracted
above.
74. For the online OBE examinations, the steps that have to be taken by the students include -
a) To ensure that the hardware i.e., laptop/phone/computer is proper and functioning and to ensure
a stable internet connection;
b) To download the question paper from the online portal or from their emails;
c) To read the question paper and decide which questions to attempt as choices are being given to
the students.
d) To write the answers in their own hand writing;
e) To scan each page of the answer sheet and upload the same either page by page, question by
question or as a consolidated answer sheet;
f) To upload each of the pages in the proper order so as to ensure that the pages are not mixed up;
g) If the portal is not working or there is a technical glitch, time is needed to create a PDF of the said
answer sheet and to submit the said answer sheet by email.
75. This entire process cannot be completed in the same time period as is provided for the
examination in physical mode and thus, adequate time needs to be provided to students.
76. It is a matter of common knowledge, of which judicial notice can be taken, that internet
connectivity is not stable at all times. Sometimes, the connectivity is very good and sometimes there
is no connectivity at all. Rains can cause disruption in connectivity. In several states, 4G connectivity
is also not available. The internet can be slow, especially if downloading of heavy files or uploading
of heavy documents is involved.
77. Various orders have been passed by the ld. Division Bench and this Court and the improvements
made by DU over the last one month or so are part of the judicial record. In order to end the
uncertainty for lakhs of students who are appearing in the OBE and to ensure fair opportunity,
keeping in view the technical problems etc., faced by students during the mock online OBEs some
further directions on some of the aspects of the OBE as also the setting up of a grievance redressal
mechanism are being passed.
78. Considering the nature of challenge in the present petition, the technological challenges and the
fact that the evaluation is of 70-100 marks for each paper, the following steps, shall be taken:Anupam & Ors. vs University Of Delhi Through Its ... on 7 August, 2020

a) The question papers shall be made accessible for regular and NCWEB students on
http://obe.du.ac.in and for SOL students on http://solobe.du.ac.in.
b) Simultaneously, the question papers shall be sent by email to all the students. Prof.
Vinay Gupta, Dean (Examinations) has confirmed both before the Ld. Division Bench
and before this Court that DU has the emails of all the students appearing in the final
examinations and that the question papers would be emailed to all students.
c) Regular students shall be given the complete three hours for answering the
question papers. Additionally, regular students are given one more hour for scanning
the answer sheets and for uploading the same. Thus regular students would have a
total period of four hours to complete the exam, scan and upload/email the answer
sheets. Similarly, students under PWD category are also given one additional hour for
downloading the question paper, completing their answers and uploading the answer
sheets i.e., a total of six hours.
d) Students have the following options for uploading/emailing the answer scripts, as
submitted by DU -
i. Students scan the answer sheets page by page or question wise and upload the same on the DU
portal within the 7MB limit;
ii. Students can also convert their answer sheets into PDF files either question wise or in entirety
and e-mail the same to the central email address at obescript@exam.du.ac.in and/or to the
respective college/department/faculty email. The Dean (Examinations) of DU has confirmed that
the said emails have the capacity of receiving emails from all the students who are appearing in the
online OBE.
e) Those students who upload the answer sheets on the portal would receive an acknowledgement
on the online OBE portal itself.
f) In respect of students who email the answer sheets to the central email address
(obescript@exam.du.ac.in) or to the respective colleges/departments/faculties, an auto generated
email shall be sent acknowledging receipt of the answer sheets. Ld. Counsel for DU, on instructions,
has submitted that the auto-reply shall be generated so that students are aware that their answer
sheets have been received.
g) DU shall ensure that the central email id as also the email ids of all the colleges and departments
have adequate capacity to receive and store the answer sheets so that the emails sent by the students
do not bounce back.
h) The central email id for uploading of answer sheets i.e. obescript@exam.du.ac.in, shall be
publicised adequately.Anupam & Ors. vs University Of Delhi Through Its ... on 7 August, 2020

i) Under instructions, ld. counsel for the DU has informed the Court that though there are 91
colleges in DU, the online OBE is being conducted for students only in 64 colleges. The list of Nodal
officers for all the 64 colleges including their mobile numbers and email addresses has been given to
the Court. In addition, the list of Nodal Officers for SOL and NCWEB has also to be issued. Both
these lists shall be uploaded on the DU portal immediately and not later than 8th August, 2020 by
6:00 pm.
j) The details of all the Nodal Persons in the various departments/centres/faculty along with the
mobile numbers and email addresses of 55 departments has been submitted to the Court. The same
shall be uploaded on the DU portal by 6.00 pm on 8th August, 2020.
k) CSC Academy shall notify all its centres about the schedule of the online OBE by the end of today
i.e., 7th August, 2020, so that the said centres can provide assistance to students to the best extent
possible.
l) Grievance Cell: In case the students have any grievances, they shall send their grievances at
grievanceexam2020@gmail.com and grievance@exam.du.ac.in, which have already been notified by
DU. The said emails shall be monitored and supervised by Dr. Sanjeev Singh, Joint Director DUCC,
who shall entrust the same to the Grievance officers. The emails received on these email addresses
shall be addressed and resolved by the DU's Grievance Officers within 48 hours. Any grievances,
which are not addressed within the said period, shall be automatically referred to a `Grievance
Redressal Committee'. The password for the email addresses shall also be handed over by Dr.
Sanjeev Singh to the Chairperson of the Committee in a sealed cover. The Grievance Officers shall
send a chart of grievances received and grievances redressed, every two days, to the Chairperson of
the Committee. In case any grievance is not addressed by the Grievance Officers within the
stipulated time, the Committee shall take a final decision on the same.
m) Grievance Redressal Committee:
1) DU has informed this Court about the constitution of a Committee for the purposes
of redressing any grievances of students related to answer scripts received in PDF
format.
Considering the fact that students ought to have a transparent and fair resolution of their issues and
are not forced to litigate, the said Committee is reconstituted and shall constitute of the following
members:
                                             i.     Justice Pratibha Rani
                                                    (Retd. Judge, Delhi High Court)    - Chairperson
                                            ii.     Professor K. S. Rao,
                                                    Department of Botany               - Deputy ChairpersonAnupam & Ors. vs University Of Delhi Through Its ... on 7 August, 2020

                                            iii.     Professor Kavita Sharma,
                                                    Department of Commerce               - Member
                                            iv.     Mr. B. B. Gupta, Senior Advocate
                                                    (M: 9811348989)                  - Member
                                            v.      Mr. Kamal Gupta, Advocate
                                                    (M: 9810988094)                      - Member
The Grievance Redressal Committee shall deal with all the grievances of the students in respect of
downloading of question papers, uploading of answer sheets, technical glitches, delays in uploading
and any other issues faced by students during the conduct of the OBE examinations.
2) Mr. Mohinder J. S. Rupal, ld. counsel for DU (M:9811151216) shall be the Principal Coordinator
for the Committee and his role shall be to ensure the smooth functioning of the Committee and to
coordinate between the DUCC and other DU officials and the Committee.
3) The Chairperson shall be paid a lumpsum fee of Rs.3 lakhs.
The two external members have kindly consented to serve pro bono and the Principal Coordinator
shall be paid a lumpsum of Rs.1 lakh. The fees for the Chairperson and the Principal Coordinator
shall be paid by DU.
4) The Grievance Redressal Committee shall hold its meetings either virtually or in the office of the
Dean (Examinations), DU. Adequate arrangements for the same shall be made by Dean
(Examinations). The schedule of the said meetings shall be decided by the Chairperson of the
Committee. The quorum for a meeting shall be a minimum of (3) including the Chairperson.
5) The decision in respect of the grievances shall be taken by the Committee within 5 days from
receipt of the email and the student shall be duly notified of the said decision.
6) Grievance redressal shall continue during the entire period of the examinations and shall not be
postponed till the end of the examinations, in order to ensure simultaneous resolution of the same.
(n) At the end of the OBE examinations a comprehensive report of the conduct of examinations shall
be submitted by DU, within four weeks.
(o) The uploaded answer sheets of students shall also be simultaneously sent for evaluation to the
respective teachers/faculty to ensure that declaration of results is not delayed in any manner. As
seen from the past examination schedules announced by DU, results are usually announced within a
short period after conclusion of examinations and the same trend ought to be maintained. The
directions in respect of transmission of question papers by email, uploading of answer sheets by
email, notification of the various email addresses including the central email address and those of
colleges and departments, email addresses for raising grievances, generation of auto- reply, haveAnupam & Ors. vs University Of Delhi Through Its ... on 7 August, 2020

already been agreed to by DU. The grievance redressal committee as constituted by DU is
re-constituted to ensure fairness and transparency. The direction to send the uploaded answer
sheets for evaluation simultaneously is given to expedite the declaration of results, to ensure a quick
finality for students who need to move on in their careers.
79. Depending on the conduct of OBE examinations, the remaining issues raised shall be
considered, if the need arises, at a later stage. Issues relating to privacy of students, as raised by the
intervenors, as well as issues relating to the storing of data collected in the OBE examinations etc.,
would also be considered after completion of pleadings. Counter affidavit has been filed by DU. The
UGC has filed a brief affidavit in terms of the order dated 31st July, 2020 as well as an affidavit
dated 8th July, 2020 bringing on record the UGC's revised guidelines dated 6th July, 2020. If it
wishes to, the UGC is permitted to file a fresh counter affidavit dealing with the averments in the
writ petition as also averments in the impleadment application. Let the same be done within four
weeks. Rejoinders thereto, if any, be filed within two weeks thereafter.
80. Let a copy of this order be communicated to the Pro-Vice Chancellor, DU and Mr. Tyagi, CEO,
CSC Academy to ensure compliance. Additionally, all counsels appearing for the Respondents in this
matter are directed to communicate this order to their respective clients to ensure compliance by all
the authorities. Upon conclusion of the online OBE, the Grievance Redressal Committee shall also
place on record its report. The directions given today shall be duly intimated to all the students by
e-mail in the format as deemed appropriate by DU.
81. List on 22nd September, 2020.
PRATHIBA M. SINGH JUDGE AUGUST 07, 2020 dk/dj/Rahul/TAnupam & Ors. vs University Of Delhi Through Its ... on 7 August, 2020

