Chairman And M.D. B.P.L. Ltd vs S.P. Gururaja And Ors on 13
October, 2003
Author: S.B. Sinha
Bench: Ashok Bhan, S.B. Sinha
           CASE NO.:
Appeal (civil)  2166 of 1998
PETITIONER:
CHAIRMAN AND M.D. B.P.L. LTD.
RESPONDENT:
S.P. GURURAJA AND ORS.
DATE OF JUDGMENT: 13/10/2003
BENCH:
V.N. KHARE CJ & ASHOK BHAN & S.B. SINHA
JUDGMENT:
JUDGMENT 2003 Supp(4) SCR 587 (With C.A. No. 2167 of 1998) The Judgment was delivered by
S.B. SINHA, J.
How economic development of a State can be halted by a Public Interest Litigation has received the
attention of this Court in some of its decisions. The case at hand adds to the said list.
BACKDROP FACTS:
2. The Karnataka Industrial Area Development Board (hereinafter referred to as 'the
Board') is a statutory authority constituted under Karnataka Industrial Areas
Development Act, 1966. It acquired a vast tract of land inter alia for the purpose of
allotment thereof to entrepreneurs who intended to set up industries in the State of
Karnataka. The State of Karnataka with a view to accelerate economic development of
the State adopted a policy decision of dealing with the applications received from the
entrepreneurs through one window system. With a view to achieve the said objective
a High Level Committee was constituted. BPL Limited (hereinafter referred to as 'the
Company' with a view to set up industries applied for allotment of 500 acres of land
for its three projects. The said application was considered by the High Level
Committee wherein a decision was taken to allot 175 acres of land in favour of the
Company at RS. 92/-
per sq.m. The Company was held to be entitled to various other incentives for the aforementionedChairman And M.D. B.P.L. Ltd vs S.P. Gururaja And Ors on 13 October, 2003

purposes. Such allotment was made by issuing an order dated 7.4.1995 out of the land acquired by it
i.e. 296.26 acres in terms of notification dated 2/4th September, 1991 issued under Section 28(1) of
the Karnataka Industrial Areas Development Act, 1966.
PUBLIC INTEREST LITIGATION:
3. The respondents filed a public interest litigation questioning the said allotment
inter alia on the ground that the statutory purposes for which the Board can acquire
the land had been breached by reason thereof. The respondent Nos. 1 to 3 describing
themselves to be the social workers in the writ petition raised the following
contentions:
(a) That the Board can acquire the land only for the purposes (three in number a
stated in the Act).
(b) That the land to other Entrepreneurs is sold at the rate of Rs.
8,80,000/- per acre whereas it is sold to BPL at Rs. 3,72,324/- per acre.
(c) That the allotment being contrary to Regulations is arbitrary and unreasonable.
(d) That the allotment is made without inviting applications and without notifying the availability of
land to general public.
(e) That the exercise of power is mala fide and suffers from legal malice.
4. The contentions of the Board, on the other hand, were:
a) That the respondents have no locus standi to maintain the writ petition as legal
rights of the general public have not been infringed.
b) No notice under Order 1 Rule 8 of C.P.C. having published, the writ petition was
not maintainable.
c) That the Government of Karnataka in exercise of its executive powers under Article
162 of the Constitution of India has established a single window Agency to accord,
with significant authenticity, sanction/clearance/approval to the establishment of
new Industries of expansion of existing units, which include sanction of
infrastructural facilities like and, power, water, finance etc. Wherever an Industrial
Project involves an investment beyond fifty crores, the decision to accord sanction/
approval /clearance shall be taken by High Level Committee.
d) that the High Level Committee constituted under the said Government orders in
its meeting held on 10.10.1994 and 24.1.1995 recommended that:Chairman And M.D. B.P.L. Ltd vs S.P. Gururaja And Ors on 13 October, 2003

i) 220 Acres of land be made available immediately to BPL group at Dobospet
Industrial Area for implementing colour picture tube and batteries project.
ii) Additional land acquisition be initiated by the Karnataka Industrial area
Development Board on the basis of justification of total land requirement of 500
acres to be furnished by the group.
In its 28th meeting held on 29.3.1995, the Committee took notice of the requirements of the BPL
India Ltd. and after thorough discussion resolved that Karnataka Industrial Area Development
Board (KIADB for short) shall handover 175 acres of land at Dobospet Industrial Area to the BPL
India Ltd.
e) That thereafter the Government of Karnataka by its order dated 16.5.1995 cleared the three
projects of the BPL India Ltd. which involved a total investment of Rs. 663.56 crores. The
Government of Karnataka decided to allot 220 acres of land at Dobospet Industrial Area.
f) That an extent of 278.42 acres of private land near Dobospet was acquired by the State
Government under Section 28(4) of KIADB Act, 1966 for the purpose of development by this
Respondent. The final declaration is published in Karnataka Gazette dated 12.11.1992. A layout was
planned in consultation with the Director, Town Planning to form 28 plots of varying extent from 1
acre to 210 acres. Plot No.1 and 2 measuring 30 acres and 210 acres are reserved in favour of BPL
India Ltd. In the remaining 74 acres small plots are formed to accommodate non-polluting
Industries. An extent of 28.80 acres will be occupied by roads, civic amenities etc.
g) That this respondent while developing an industrial area undertakes development work like
formation of WBM Roads, with block topping, drains with dick also culverts, stream water drains,
drains supply through borewell, street lighting, avenue trees and drawing of high tension and low
tension power line. The cost incurred has to be borne by allottees. However, the land that is allotted
to BPL India Ltd. has not been entirely developed and only peripheral infrastructural facilities
would be provided.
5. The Company also filed a counter affidavit alleging that the said allotment was made pursuant to
the Board's resolution adopted by the Single Window Agency. The anticipated investment of the
Company was Rs. 600 crores. The Composition of the Committee was as follows:
________________________________________________________________
1.
Additional Chief Secretary to Government of Karnataka Chairman
2. Secretary to Government Commerce & Industries Department MemberChairman And M.D. B.P.L. Ltd vs S.P. Gururaja And Ors on 13 October, 2003

3. Commissioner and Secretary to Government, Housing & Urban Development Department
Member
4. Secretary to Government, Science & Technology & Ecology & Environment Member
5. Director of Industries & Commerce Member
6. Chairman & Managing Director, Karnataka State Industrial Investment & Development
Corporation Limited Member
7. Managing Director, Karnataka State Finance Corporation Member
8. Chairman, Karnataka Electricity Board Member
9. Chairman, Karnataka State Pollution Control Board Member
10. Chief Inspector of Factories & Boilers Member
11. Excise Commissioner Member
12. Managing Director, Karnataka Urban Water Supply & Drainage Board Member
13. Managing Director, KEONICS Member
14. Executive Member, Karnataka Industrial Area Development Board Member Secretary
15. General Manager (P & D), Karnataka State Industrial Investment & Development Corporation
Limited Member Secretary
16. Joint Director, (Industrial Development) Industries & Commerce Department Member Secretary
___________________________________________________________________________
____
6. The application filed by the Company went through various processes and several meetings of the
different committees were held. The High Level Committee also considered the matter in a number
of meetings, pursuant whereto and in furtherance whereof the aforementioned decision was taken
whereafter the Company deposited 99% of the cost of the allotted land amounting to Rs.
6,45,05,133/- with a view to obtain possession. It was further contended that only possession of 149
acres and 5.5 guntas out of 175 acres had been delivered. A lease-cum-sale agreement in terms of the
extent regulations was executed on 2.6.1995.
7. Various suits thereafter were filed by certain interested parties as a result whereof the Company
could not start its constructional activities.Chairman And M.D. B.P.L. Ltd vs S.P. Gururaja And Ors on 13 October, 2003

8. Ultimately, a lease-cum-sale agreement was executed on 17.4.1996 which came into force with
effect from 29.5.1995. The lease was for a period of 11 years and the yearly rent payable therefor was
Rs. 55,479/- and maintenance charges at Rs. 74,568/-. It was stipulated that on expiry of the said
period of 11 years the property would be sold to the lessee at the price fixed by the lessor.
9. Clause 11(b) of the said Agreement to Lease reads as follows:
"As soon as it may be convenient the LESSOR will fix the price of demised premises
at which it will be sold to the LESSEE and communicate it to the LESSEE and the
decision of the Lessor in this regard will be final and binding on the LESSEE. The
LESSEE shall pay the balance of the value of the property, if any, after adjusting the
premium and the total amount of rent paid by the LESSEE and earnest money
deposit within one month from the date of receipt of communication signed by the
LESSOR or any other officer authorised in this behalf by the LESSOR. On the other
hand, if any sum is determined as payable by the LESSOR to the LESSEE after the
adjustment as aforesaid, such sum shall be refunded to the LESSEE before the date of
execution of the sale deed."
10. The appellants also contended before the High Court that the writ petitioners-respondents had
been set up by the persons whose lands had been acquired. They were members of political parties
also.
DIRECTIONS BY THE HIGH COURT
11. The High Court called for the entire records. Upon consideration of the rival pleadings as also the
records of the case, the writ petition filed by the respondents herein was allowed directing:
"a) Quash the allotment of land made by this Petitioner in favour of BPL India Ltd.
Only in so far as excess land than the land actually utilised so far by the BPL India at
any rate not exceeding 30 acres.
b) This petitioner is directed to recover possession of remaining land forthwith.
c) After recovering possession, this petitioner is directed to form industrial plots and
allot the same to prosecutive industrialist after notifying and inviting applications.
d) In respect of land that is left with the BPL India Ltd., this Petitioner shall work out
the cost of such land at the rate of Rs. 8 lakhs per acre and after adjusting the amount
already paid by BPL India, shall refund the balance amount to BPL India together
with interest at the rate of 6% per annum from the date of receipt of the amount.
e) In order to ascertain the actual utilization of land by BPL India so far the Assistant
Director of Land Record was directed to conduct survey of the land which is actually
utilized by the BPL India Ltd. in the presence of Petitioner and the Respondents,Chairman And M.D. B.P.L. Ltd vs S.P. Gururaja And Ors on 13 October, 2003

prepare a sketch thereof and earmark the boundaries so that the Board can recover
possession of rest of the land from the BPL India Ltd.
f) The cost of Rs. 10,000/- was awarded to writ petitioners to be paid by this
Petitioner".
STATUTES OPERATING IN THE FIELD:
12. It is not in dispute that the matter relating to allotment of industrial land is governed by
Karnataka Industrial Areas Development Act, 1966 (hereinafter referred to as 'the Act'). The
appellant-Board has been constituted thereunder. In terms of the said Act, the State Government is
empowered to acquire land and to handover the same to the Board for development and allotment
to eligible industries. The relevant provisions of the said Act are as under:
"17. Directions by State Government:
The State Government may issue to the Board such directions of a general nature as it
may think necessary or expedient for the purpose of carrying out the purposes of this
Act, and the Board shall be bound to follow and act upon such directions.
41) Power to make Regulations:
1) The Board may, with the previous approval of the State Government, by
notification make regulations consistent with this Act and the rules made hereunder
to carry out the purposes of this Act.
2) In particular and without prejudice to the generality of the foregoing power, such
regulations may provide for:-
a) ...
b) the terms and conditions under which the Board any dispose of land."
13. Pursuant to and in furtherance of the power conferred upon the State, regulations were framed
known as 'Regulations governing the disposal of land by the Karnataka Industrial Area Development
Board'. Regulations 7 and 13 of the said Regulations which are relevant for the purpose of this case
are as under:
"7. Inviting applications:
The Board shall notify the availability of land, the manner of disposal, the last date
for submission of applications and such other particulars as the Board may consider
necessary in each case by giving wide publicity through newspapers having
circulating in and outside Karnataka State and invite applications from industries orChairman And M.D. B.P.L. Ltd vs S.P. Gururaja And Ors on 13 October, 2003

persons intending to start industries.
13. Allotment of plots in Special cases:
Notwithstanding anything contained in these Regulations the Board in consultation
with the State Government may allot any plot or area other than those in respect of
which applications are called for under Regulations 7 to any individual or company
for the establishment of an industry or for the provision for any amenity required in
the Industrial Area."
SUBMISSIONS:
14. Mr. Mukul Rohtagi, the learned Addl. Solicitor General and Mr. D.A. Dave, the learned senior
counsel, appearing for the appellants would submit that the High Court committed a manifest error
in passing the impugned judgment insofar as it entered into the question of validity or otherwise of
the policy decision adopted by the State. The learned counsel would submit that the requirements of
the Company for setting up its industrial units can be judged by the experts wherefor High Level
Committee was constituted and, thus, the High Court could not sit in appeal thereover. It was urged
that the High Court further committed a manifest error by arriving at the conclusion that the State
had shown undue haste in the matter of grant of allotment and that too at a price of Rs. 3,72,324/-
per acre although it received the consideration of Rs. 8,00,000/- per acre from another
entrepreneur.
15. The learned counsel would further urge that the High Court has failed to consider that the writ
petitioners had no locus standi to file the writ application as they had been set up by those whose
lands had been acquired. It was pointed out that whereas the lands were allotted on 7.4.1995, the
writ petition having been filed on 11.11.1996 suffered from gross delay and laches and in that view of
the matter too the High Court should have refused to exercise its jurisdiction in favour of the
appellants particularly in view of the fact that the Company in the meantime have changed their
position by investing about Rs. 80/- crores.
16. Mr. T.L.V. Iyer, the learned senior counsel appearing on behalf of the respondents, on the other
hand, would submit that the purported allotment was made in favour of the company by the Board
without making any enquiry as regard the area of the land it actually needed not there had been any
application of mind in relation thereto. The property having been acquired under a statute is a
public property, contends Mr. Iyer, and being trustees thereof, the Board was required to take
extreme care and caution in relation thereto. It was contended that the High Court had rightly found
that for all intent and purport such vast tract of land had been sold to the Company although
apparently allotted for a period of 11 years and thereafter the Company would be entitled to obtain
sale deed in relation to the demised Land. At the relevant time, Mr. Iyer argued, neither any project
report had been submitted by the Company nor any material was placed to show that the Company
required such vast tract of land.
SCOPE OF THE PUBLIC INTEREST LITIGATIONChairman And M.D. B.P.L. Ltd vs S.P. Gururaja And Ors on 13 October, 2003

17. The Company intended to set up more than one unit. For the purpose of achieving the objective
of economic development of the State, the State is entitled to deal with the applications of the
entrepreneurs in an appropriate manner. For the said purpose a High Level Committee was
constituted. The said Committee held its meeting on 10.10.1994 wherein not only the members
referred to hereinbefore but also various other officers were present. Presumably, prior thereto the
applications filed by the Company were scrutinized by the competent authorities. After detailed
discussions, the High Level Committee resolved:
a) to permit the unit to change the location from Malur Indl. Area. to Dobespet
Industrial Area;
b) to allot a total of 500 acres of land for the three projects viz., Colour Picture Tube,
Colour Televisions and Battery, in Dobespet Industrial Area, Nelamangala to, in lieu
of the earlier allotment of 100 acres of land at Malur Indl Area for the Colour TV sets
project, subject to the promoters indicating the individual land requirement for
Colour Picture Tube project, Colour TV project and the battery project duly justifying
the requirement with necessary plans, block diagrams, etc. As regard incentives, it
was resolved:
"(3) INCENTIVES: The HLC resolved to offer the following incentives:
100% exemption of sales tax (KST. CST & Turnover Tax) on sale of finished goods for
a period of 8 years or deferment for a period of 10 years from the date of
commencement of commercial production subject to a limit of 100% of the value of
the fixed assets. The present level of ST revenue from the company from TV
manufacturing is to be maintained.
(ii) Exemption from payment of Purchase Tax (ST on purchase by the co.) on capital
goods/equipment worth more than Rs. 1.00 crore (Rupees one crores) in each
individual case during the construction phase of the project."
18. Similar considerations were made in respect of Colour Television Picture Tube Project of the
Company and Manufacture of Batteries. The matter relating to allotment of land is a statutory
function on the part of the Board. In terms of the provisions of the Act, consultations with the State
Government is required if Regulation 13 of the Regulations in place of Regulation 7 is to be taken
recourse to. Does it mean that consultations must be held in a particular manner, i.e. by exchange of
correspondences and in no other? Answer to the said questions must be rendered in negative. The
High Level Committee was chaired by the Minister who in terms of the Rules of Executive Business
framed under Article 166 of the Constitution of India was entitled to represent the State. Once a
consultation takes place by mutual discussion and a consensus is arrived at between different
authorities performing different functions under the statutes, the purpose for which consultation
was to be made would stand satisfied. Under the Act or the Regulations framed thereunder, no
procedure for holding such consultations had been laid down. In that situation it was open to the
competent authorities to evolve their own procedure. Such a procedure of taking a decision uponChairman And M.D. B.P.L. Ltd vs S.P. Gururaja And Ors on 13 October, 2003

deliberations does not fall foul of Article 14 of the Constitution of India. No malice of fact has been
alleged in the instant case. The High Court has proceeded to pronounce its judgment inter alia on
the ground that the price of the land should have been fixed at Rs. 8,00,000/- per acre. In the
support of the said decision, the High Court has relied upon a grant at the aforementioned rate.
However, it was pointed out by the Board:
"It is submitted that the land allotted to respondent No.4 was not fully developed by
this petitioner except some infrastructural facilities which have been counted while
calculating the price of the land. The land allotted to individual entrepreneurs is fully
developed with all infrastructural facilities. There cannot be any equality between
unequals. The cost of the land is arrived at by this petitioner taking into
consideration the cost of acquisition, cost of partial development, service and
establishment charges."
19. This aspect of the matter did not receive due attention of the High Court despite its merit.
20. It is a well-settled principle of law that different considerations arises for the purpose of fixation
of price in respect of price of land i.e. for a small area vis-a-vis a large area. The allotment price was
Rs. 3,73,324/- per acre which, having regard to the policy decision of the State as also the facts and
circumstances of the case cannot be said to be wholly arbitrary warranting interference by the Court.
There cannot be any doubt whatsoever that normally allotment of such industrial plots should be
done in terms of Regulation 7 aforementioned. But the same by itself did not preclude the
authorities of the Board and the State having regard to the fact situation obtaining herein to take
recourse to Regulation 13. Once the Court finds that the power exercised by the statutory authorities
can be traced to a provision of statute, unless and until violation of mandatory provisions thereof are
found out and/ or it is held that a decision is taken for unauthorised or illegal purpose, the court will
not ordinarily interfere either with the policy decision or any decision taken by the executive
authorities pursuant to or in furtherance thereof.
21. Malice in common law or acceptance means ill will against a person, but in legal sense means a
wrongful act done intentionally without just cause or excuse.
CASE LAWS OPERATING IN THE FIELD:
22. In G.B. Mahajan and others vs. Jalgaon Municipal Council and others 1991 (3) SCC 91 ), this
Court stated:
"46. While it is true that principles of judicial review apply to the exercise by a
government body of its contractual powers, the inherent limitations on the scope of
the inquiry are themselves a part of those principles. For instance, in a matter even as
between the parties, there must be shown a public law element to the contractual
decision before judicial review is invoked. In the present case the material placed
before the court falls far short of what the law requires to justify interference."Chairman And M.D. B.P.L. Ltd vs S.P. Gururaja And Ors on 13 October, 2003

23. In Tata Cellular vs. Union of India 1994 (6) SCC 651 ), the Court laid down the following
principles in the matter of judicial review:
"94. The principles deducible from the above are:
1) The modern trend points to judicial restraint in administrative action.
2) The court does not sit as a court of appeal but merely reviews the manner in which
the decision was made.
3) The court does not have the expertise to correct the administrative decision. If a
review of the administrative decision is permitted it will be substituting its own
decision, without the necessary expertise which itself may be fallible.
4) The terms of the invitation to tender cannot be open to judicial scrutiny because
the invitation to tender is in the realm of contract.
Normally speaking, the decision to accept the tender or award the contract is reached by process of
negotiations through several tiers. More often than not, such decisions are made qualitatively by
experts.
5) The Government must have freedom of contract. In other words, a fair play in the joints is a
necessary concomitant for an administrative body functioning in an administrative sphere or
quasi-administrative sphere. However, the decision must not only be tested by the application of
Wednesbury principle of reasonableness (including its other facts pointed out above) but must be
free from arbitrariness not affected by bias or actuated by mala fides.
(6) Quashing decisions may impose heavy administrative burden on the administration and lead to
increased and unbudgeted expenditure."
24. In M.P. Oil Extraction and another vs. State of M.P. and others 1997 SCC 592 ), this Court
observed:
"44. The renewal clause in the impugned agreements executed in favour of the
respondents does not also appear to be unjust or improper. Whether protection by
way of supply of sal seeds under the terms of agreement requires to be continued for
a further period, is a matter for decision by the State Government and unless such
decision is patently arbitrary, interference by the Court is not called for. In the facts
of the case, the decision of the State Government to extend the protection for further
period cannot be held to be per se irrational, arbitrary or capricious warranting
judicial review of such policy decision. Therefore, the High Court has rightly rejected
the appellant's contention about the invalidity of the renewal clause. The appellants
failed in earlier attempts to challenge the validity of the agreement including the
renewal clause. The subsequent challenge of the renewal clause, therefore, should notChairman And M.D. B.P.L. Ltd vs S.P. Gururaja And Ors on 13 October, 2003

be entertained unless it can be clearly demonstrated that the fact situation has
undergone such changes that the discretion in the matter of renewal of agreement
should not be exercised by the State. It has been rightly contended by Dr. Singhvi that
the respondents legitimately expect that the renewal clause should be given effect to
in usual manner and according to past practice unless there is any special reason not
to adhere to such practice. The doctrine in 'legitimate expectation" has been judicially
recognised by this Court in a number of decisions. The doctrine of 'legitimate
expectation' operates in the domain of public law and in an appropriate case,
constitutes a substantive and enforceable right".
25. It was further pointed out:
"45. Although to ensure fair play and transparency in State action, distribution of
largesse by inviting open tenders or by public auction is desirable, it cannot be held
that in no case distribution of such largesse by negotiation is permissible. In the
instant case, as a policy decision protective measure by entering into agreements with
selected industrial units for assured supply of sal seeds at concessional rate has been
taken by the Government. The rate of royalty has also been fixed on some accepted
principle of pricing formula as will be indicated hereafter. Hence, distribution or
allotment of sal seeds at the determined royalty to the respondents and other units
covered by the agreements cannot be assailed. It is to be appreciated that in this case,
distribution by public auction or by open tender may not achieve the purpose of the
policy of protective measure by way of supply of sal seeds at concessional rate of
royalty to the industrial units covered by the agreements on being selected on valid
and objective considerations."
26. In Netai Bag and others vs. State of W.B. and others 2000 (8) SCC 262 ), Sethi J. speaking for
the Bench observed:
"Though the State cannot escape its liability to show its actions to be fair, reasonable
and in accordance with law, yet wherever challenge is thrown to any of such action,
initial burden of showing the prima facie existence of violation of the mandate of the
Constitution lies upon the person approaching the court. We have found in this case,
that the appellants have miserably failed to place on record or to point out to any
alleged constitutional vice or illegality. Neither the High Court nor this Court would
have ventured to make a rowing inquiry particularly in a writ petition filed at the
instance of the erstwhile owners of the land, whose main object appeared to get the
land back by any means as, admittedly, with the passage of time and development of
the area, the value of the land had appreciated manifold. It may be noticed that in the
year 1961 the erstwhile owners were paid about Rs. 5.5 lakhs and the State
Government assessed the market value of the property which was paid by
Respondent 5 at Rs. 71,59,820. The Appellants have themselves stated that the value
of the land roundabout the time, when it was leased to Respondent 5 was about Rs. 11
crores. There cannot be any dispute with the proposition that generally when anyChairman And M.D. B.P.L. Ltd vs S.P. Gururaja And Ors on 13 October, 2003

State land is intended to be transferred or the State largesse decided to be conferred,
resort should be had to be public auction or transfer by way of inviting tenders from
the people. That would be a sure method of guaranteeing compliance with the
mandate of Article 14 of the Constitution. Non-floating of tenders or not holding of
public auction would not in all cases be deemed to be the result of the exercise of the
executive power in an arbitrary manner. Making an exception to the general rule
could be justified by the State executive, if challenged in appropriate proceedings.
The constitution courts cannot be expected to presume the alleged irregularities,
illegalities or unconstitutionality nor the courts can substitute their opinion for the
bona fide opinion of the State executive. The courts are not concerned with the
ultimate decision but only with the fairness of the decision-making process.
In the backdrop of the legal position noticed herein, it has to be seen, in the instant
case, as to whether the action of Respondent 1 was illegal, arbitrary or mala fide. To
justify their action of entering into an agreement of lease by negotiation, even in the
absence of pleadings on behalf of the appellants, the State has submitted that the
entire transaction of granting the lease to Respondent 5 for an integrated food
processing unit with an abattoir in a semi-rural area, which was a low- lying land,
despite their best efforts, the State Government were unable to set up any project.
The lease was given to Respondent 5 upon consideration of all the facts and
circumstances with the object of setting up an industry in the State of West Bengal
which was likely to generate employment to more than 300 persons and earn foreign
exchange worth more than Rs. 50 acrores. The negotiations were resorted to ensure
the disposal of the slaughterhouse at Durgapur which was proved to have been
running in losses. The respondent State had failed to get any buyer for Durgapur
Project despite newspaper advertisement.
In view of the peculiar facts and circumstances of the case we are not persuaded to
hold that the action of the respondent State in executing the lease deed with
Respondent 5 was unreasonable, illegal, arbitrary or actuated by extraneous
considerations. In this regard it is worth noticing that none except the erstwhile
owners and the propounders of vegetarianism have made any grievance to the effect
that the market value of the property, as charged from Respondent 5, was either
allegedly for a song or at a throwaway price."
27. In Raunaq International Ltd. vs. I.V.R. Construction Ltd. and others 1999 (1) SCC 492 ) it was
held:
11) When a writ petition is filed in the High Court challenging the award of a contract
by a public authority or the State, the court must be satisfied that there is some
element of public interest involved in entertaining such a petition. If, for example the
dispute is purely between two tenderers, the court must be vary careful to see if there
is any element of public interest involved in the litigation. A mere difference in the
prices offered by the two tenderers may or may not be decisive in deciding whetherChairman And M.D. B.P.L. Ltd vs S.P. Gururaja And Ors on 13 October, 2003

any public interest is involved in intervening in such a commercial transaction. It is
important to bear in mind that by court intervention, the proposed project may be
considerably delayed thus escalating the cost for more than any saying which the
court would ultimately effect in public money by deciding the dispute in favour of one
tenderer or the other tenderer. Therefore, unless the court is satisfied that there is a
substantial amount of public interest, or the transaction is entered into mala fide, the
court should not intervene under Article 226 in disputes between two rival tenderers.
12) When a petition is filed as a public interest litigation challenging the award of a
contract by the State or any public body to a particular tenderer, the court must
satisfy itself that the party which has brought the litigation is litigating bona fide for
public good. The public interest litigation should not be merely a cloak for attaining
private ends or a third party or of the party bringing the petition. The court can
examine the previous record of public service rendered by the organisation bringing
public interest litigation. Even when a public interest litigation is entertained, the
court must be careful to weigh conflicting public interests before intervening.
Intervention by the court may ultimately result in delay in the execution of the
project. The obvious consequence of such delay is price escalation. If any retendering
is prescribed, cost of the project can escalate substantially. What is more important is
that ultimately the public would have to pay a much higher price is the form of delay
in the commissioning of the project and the consequent delay in the contemplated
public service becoming available to the public. If it is a power project which is thus
delayed, the public may lose substantially because of shortage in electricity supply
and the consequent obstruction in industrial development. If the project is for the
construction of a road or an irrigation canal, the delay in transportation facility
becoming available or the delay in water supply for agriculture being available, can be
a substantial setback to the country's economic development. Where the decision has
been taken bona fide and a choice has been exercised on legitimate considerations
and not arbitrarily, there is no reason why the court should entertain a petition under
Article 226.
13) Hence before entertaining a writ petition and passing any interim orders in such
petitions, the court must carefully weigh conflicting public interests. Only when it
comes to a conclusion that there is an overwhelming public interest in entertaining
the petition, the court should intervene.
14) Where there is an allegation of mala fides or an allegation that the contract has
been entered into for collateral purposes and the court is satisfied on the material
before it that the allegation needs further examination, the court would be entitled to
entertain the petition. But even here, the court must weigh the consequences in
balance before granting interim orders.
28. In Narmada Bachao Andolan vs. Union of India and others 2000 (10) SCC 664 ) this Court
opined:Chairman And M.D. B.P.L. Ltd vs S.P. Gururaja And Ors on 13 October, 2003

"47. The project, in principle, was cleared more than 25 years ago when the
foundation stone was laid by late Pandit Jawahar Lal Nehru. Thereafter, there was an
agreement of the four Chief Ministers, in 1974, namely, the Chief Ministers of
Madhya Pradesh, Gujarat, Maharashtra and Rajasthan for the project to be
undertaken. Then dispute arose with regard to the height of the dam which was
settled with the award of the Tribunal being given in 1978. For a number of years,
thereafter, final clearance was still not given. In the meantime some environmental
studies were conducted. The final clearance was not given because or the
environmental concern which is quite evident. Even though complete data which
regard to the environment was not available, the Government did not 1987 finally
give environmental clearance. It is thereafter that the construction of the dam was
undertaken and hundreds of crores have been unvested before the petitioner chose to
file a writ petition in 1994 challenging the decision to construct the dam and the
clearance as was given. In our opinion, the petitioner which had been agitating
against the dam since 1986 is guilty of laches in not approaching the Court at an
earlier point of time."
29. In Balco Employees' Union (Regd.) vs. Union of India Another others 2002 (2) SCC 333 ), it was
held:
"Public interest litigation, or PIL as it is more commonly known, entered the Indian
judicial process in 1970. It will not be incorrect to say that it is primarily the judges
who have innovated this type of litigation as there was a dire need for it. At that stage,
it was intended to vindicate public interest where fundamental and other rights of the
people who were poor, ignorant or in socially or economically disadvantageous
position and were unable to seek legal redress were required to be espoused. PIL was
not meant to be adversial in nature and was to be a cooperative and collaborative
effort of the parties and the court so as to secure justice for the poor and the weaker
sections of the community who were not in a position to protect their own interests.
Public interest litigation was intended to mean nothing more than what words
themselves said viz. "litigation in the interest of the public."
While PIL initially was invoked mostly in cases connected with the relief to the people and the
weaker sections of the society and in areas where there was violation of human rights under Article
21, but with the passage of time, petitions have been entertained in other spheres. Prof. S.B. Sathe
has summarised the extent of the jurisdiction which has now been exercised in the following words:
"PIL may, therefore, be described as satisfying one or more of the following
parameters. These are not exclusive but merely descriptive.
- Where the concerns underlying a petition are not individualist but are shared widely
by a large number of people (bonded labour, undertrial prisoners, prison inmates).Chairman And M.D. B.P.L. Ltd vs S.P. Gururaja And Ors on 13 October, 2003

- Where the affected persons belong to the disadvantaged sections of society (women,
children , bonded labour, unorganised labour etc.).
- Where judicial law making is necessary to avoid exploitation (inter- country
adoption, the education of the children of the prostitutes).
- Where judicial intervention is necessary for the protection of the sanctity of
democratic institutions (independence of the judiciary, existence of grievances
redressal forums).
- Where administrative decisions related to development are harmful to the
environment and jeopardize people's right to natural resources such as air or water."
There is, in recent years, a feeling which is not without any foundation that public interest litigation
is now tending to become publicity interest litigation or private interest litigation and has tendency
to be counterproductive.
PIL is not a pill or a panacea for all wrongs. It was essentially meant to protect basic human rights of
the weak and the disadvantage and was a procedure which was innovated where a public-spirited
persons filed a petition in effect on behalf of such persons who on account of poverty, helplessness
or economic and social disabilities could not approach the court for relief. There, have been, in
recent times, increasingly instances of abuse of PIL. Therefore, there is a need to re-emphasize the
parameters within which PIL can be resorted to by a petitioner and entertained by the court. This
aspect has come up for consideration before this Court and all be we need to do is to recapitulate
and re-emphasize the same."
30. The extent of the court's jurisdiction to entertain a public interest litigation has been pointed out
by this Court in Guruvayur Deaswom Managing Committee and Anr. vs. C.K. Rajan & others (2003)
(6) SCALE 401). After referring to a large number of decisions, this Court held:
"It is trite, where a segment of public is not interested in the cause, public interest
litigation would not ordinarily be entertained.
Existence of certain gray areas may not be ruled out but such a case was required to
be made out before the High Court which has not been done in the instant case. For
any court of law including this Court, it is difficult to draw a strict line of demarcation
as to which matters and to what extent a public interest litigation should entertained
but, as noticed hereinbefore the decisions of this Court render broad guidelines. This
Court and the High Court should, unless there exists strong reasons to deviate or
depart therefrom, not undertake an unnecessary journey through the public interest
litigation path.
The High Court should not have proceeded simply to supplant, ignore or by- pass the
statute. The High Court has not shown any strong and cogent reasons for anChairman And M.D. B.P.L. Ltd vs S.P. Gururaja And Ors on 13 October, 2003

Administrator to continue in an office even after expiry of his tenure. It appears from
the orders dated 7th February, 1993 that the High Court without cogent and
sufficient reason allowed Administrator to continue in office although his term was
over and he was posted elsewhere. He also could not have been conferred powers
wider than Section 17 of the Act. The High Court took over the power of appointment
of the Commissioner bypassing the procedure set out in the Act by calling upon the
Government to furnish the names of 5 IAS Officers to the Court so that it could
exercise the power of appointment of the Commissioner.
The Court should be circumspect in entertaining such public interest litigation for
another reason. There may be dispute amongst the devotees as to what practices
should be followed by the temple authorities. There may be dispute as regard the rites
and rituals to be performed in the temple or omission thereof. Any decision in favour
of one sector of the people may heart the sentiments of the other. The Courts
normally, thus, at the first instance would not enter into such disputed arena,
particularly when by reason thereof the fundamental right of a group of devotees
under Articles 25 and 26 may be infringed. Like any other wing of the State, the
Courts also while passing an order should ensure that the fundamental rights of a
group of citizens under Articles 25 and 26 are not infringed. Such care and caution on
the part of the High Court would be a welcome step.
Where access to justice poses a fundamental problem facing the third world today, its
importance in India has increased. Laws are designated to improve the
socio-economic conditions of the poor but making the law is not enough, it must be
implemented. The core issues which have been highlighted by the learned counsels
by the party must be considered from that angle. Administration of temple by
entertaining complaints does not lead to a happy state of affairs. Roving enquiry is
not contemplated. Principles of natural justice and fair play ought to be followed even
in the pro bono public proceedings. The Courts undoubtedly would be parens patriate
in relation to idols, but when the statute governs the field and the State takes over the
management, ordinarily the Courts would not step in.
31. It was further held:
"Mr. Subba Rao referred to N.M. Thomas (supra) for the proposition that court is
also a 'State' within the meaning of Article 12 but that would not mean that in a given
case the court shall assume the role of the Executive Government of the State.
Statutory functions are assigned to the State by the Legislature and not by the Court.
The Courts while exercising its jurisdiction ordinarily must remind itself about the
doctrine of separation of powers which, however, although does not mean that the
Court shall not step-in in any circumstance whatsoever but the Court while exercising
its power must also remind itself about the rule of self-restraint. The courts, as
indicated hereinbefore, ordinarily is reluctant to assume the functions of the
statutory functionaries. It allows them to perform their duties at the first instance.Chairman And M.D. B.P.L. Ltd vs S.P. Gururaja And Ors on 13 October, 2003

The court steps in by Mandamus when the State fails to perform its duty. It shall also
step in when the discretion is exercised but the same has not been done legally and
validly. It steps in by way of a judicial review over the orders passed. Existence of
alternative remedy albeit is no bar to exercise jurisdiction under Article 226 of the
Constitution of India but ordinarily it will not do so unless it is found that an order
has been passed wholly without jurisdiction or contradictory to the constitutional or
statutory provisions or where an order has been passed without complying with the
principles of natural justice. (See Whirlpool Corporation vs. Registrar of Trade
Marks, Mumbai and others (1998) 8 SCC 1).
Exercise of self-restraint, thus, should be adhered to, subject of course to, just
exceptions."
32. Dawn Oliver in Constitutional Reform in the UK under the heading 'the Courts and Theories of
Democracy, Citizenship, and Good Governance' at page 105 states:
"However, this concept of democracy as rights-based with limited governmental
power, and in particular of the role of the Courts in a democracy, carries high risk for
the judges- and for the public. Courts may interfere inadvisedly in public
administration. The case of Bromley London Borough Council vs. Greater London
Council (1983) 1 AC 768, HL) is a classic example. The House of Lords quashed the
GLC cheap fares policy as being based on a misreading of the statutory provisions,
but were accused of themselves misunderstanding transport policy in so doing. The
courts are not experts in policy and public administration - hence Jowell's point that
the courts should not step beyond their institutional capacity (Jowell, 2000).
Acceptance of this approach is reflected in the judgments of Laws LJ in International
Transport Roth GmbH vs. Secretary of State for the Home Department (2002) EWCA
Civ 158, (2002) 3 WLR 344), and of Lord Nimmo Smith in Adams vs. Lord Advocate
(Court of Session. Times, 8 August 2002) in which a distinction was drawn between
areas where the subject matter lies within the expertise of the courts (for instance,
criminal justice, including sentencing and detention of individuals) and those which
were more appropriate for decision by democratically elected and accountable
bodies. If the courts step outside the area of their institutional competence,
government may react by getting Parliament to legislate to oust the jurisdiction of the
courts altogether. Such a step would undermine the rule of law. Government and
public opinion may come to question the legitimacy of the judges exercising judicial
review against Ministers and thus undermine the authority of the courts and the rule
of law."
CONCLUSIONS:
33. Salient principles of law as noticed hereinbefore, were not considered by the High
Court in passing the impugned judgment.Chairman And M.D. B.P.L. Ltd vs S.P. Gururaja And Ors on 13 October, 2003

34. In the facts and circumstances, we do not find that the Board and the State had
committed any illegality which could have been a subject matter of judicial review.
The High Court in our opinion committed a manifest error insofar as it failed to take
into consideration that the delay in this case had defeated equity. The allotment was
made in the year 1995. The writ application was filed after one year. By that time the
Company had not only took possession of the land but also made sufficient
investment. Delay of this nature shall have been considered by the High Court to be
of vital importance.
35. Furthermore, the High Court ought to have taken into consideration the factum of
resistance in the matter from those persons whose lands have been acquired. Only
because the lands are vested in the State upon acquisition thereof, the same by itself
would not mean that the persons whose lands were acquired were not interested in
getting the allotment. The locus standi of the respondent ought to have been taken
into consideration having regard to the specific pleas raised in this behalf by the
appellants herein.
36. Undue haste also is a matter which by itself would not have been a ground for
exercise of power of judicial review unless it is held to be malafide. What is necessary
in such matters is not the time taken for allotment but the manner in which the
action had been taken. The court, it is trite, is not concerned with the merit of the
decision but the decision making process. In absence of any finding that any legal
malice was committed, the impugned allotment of land could not have been
interfered with. What was only necessary to be seen was as to whether there had been
a fair play in action.
37. The question as to whether any undue haste has been shown in taking an
administrative decision is essentially a question of fact. The state had devolved a
policy of Single Window System with a view to get rid of red-
tapism generally prevailing in the bureaucracy. A decision which has been taken after due
deliberations and upon due application of mind cannot be held to be suffering from malice in law on
the ground that there had been undue haste on the part of the State and the Board. (See Bangalore
Medical Trust vs. B.S. Muddappa and others 1991 (4) SCC 54 and Pfizer Ltd. vs. Mazdoor Congress
and others 1996 (5) SCC 609 ).
38. For the aforementioned reasons, we are of the opinion that the impugned judgment cannot be
sustained which is set aside accordingly. These appeals are allowed. No costs.Chairman And M.D. B.P.L. Ltd vs S.P. Gururaja And Ors on 13 October, 2003

