Bihar Factories Rules, 1950
BIHAR
India
Bihar Factories Rules, 1950
Rule BIHAR-FACTORIES-RULES-1950 of 1950
Published on 30 November 1950• 
Commenced on 30 November 1950• 
[This is the version of this document from 30 November 1950.]• 
[Note: The original publication document is not available and this content could not be
verified.]• 
Bihar Factories Rules, 1950Published vide Notification No. B/F1-106/50-L - 7802 the 30th
November, 1950No. B/F1-106/50-L-7802 the 30th November, 1950. - In exercise of the powers
conferred by the Factories Act, 1948 (LXIII of 1948), the Governor of Bihar is pleased to make the
following Rules, the same having been previously published as required under Section 115 of the
said Act:-
Chapter I
Preliminary
1. Short title, extent and commencement.
(1)These Rules may be cited as the Bihar Factories Rules, 1950.(2)These Rules shall extend to the
whole of the State of Bihar.(3)Save as otherwise expressly provided elsewhere, these Rules shall
come into force at once.
2. Definitions.
- In these Rules, unless there is anything repugnant in the subject or context:-(a)"Act" means the
Factories Act, 1948.(b)"Appendix" means an appendix appended to these Rules.(c)"Artificial
Humidification" means the introduction of moisture into the air of a room by any artificial means
whatsoever, except the unavoidable escape of steam or water vapour into the atmosphere directly
due to a manufacturing process:Provided that the introduction of air directly from outside through
moistened mats or screens placed in openings at times when the temperature of the room is 80
degrees or more, shall not be deemed to be artificial humidification.(d)"Belt" includes any driving
strap or rope.(e)"Degrees" (of temperature) means degrees on the Fahrenheit Scale.(f)"Examining
Surgeon" means a qualified medical practitioner authorised by a Certifying Surgeon under
sub-section (2) of Section 10 of the Act to exercise any of the powers of such Certifying SurgeonBihar Factories Rules, 1950

under the Act.(g)"Forum" means a forum appended to these Rules.(h)"Fume" includes gas or
vapour.(i)"Health Officer" means the Municipal Health Officer or District Health Officer or such
other official as may be appointed by the State Government in that behalf.(j)"Hygrometer" means an
accurate wet and dry bulb hygrometer conforming to the prescribed conditions as regards
constructions and maintenance.(k)"Inspector" means an officer appointed under Section 8 of the
Act and includes "Chief Inspector".(I)"Maintained" means maintained in an efficient state, in
efficient working order and in good repair.(m)"Manager" means the person responsible to the
occupier for the working of the Factory for the purposes of the Act.(n)"Section" means Section of the
Act.(o)"Schedule" means a schedule appended to these Rules.(p)"Qualified medical practitioner"
means a person holding a qualification granted by an Authority specified in the schedule to the
Indian Medical Degrees Act, 1916 (VII of 1916) or in the Schedules to the Indian Medical Council
Act, 1956 (102 of 1956).
2A. [ Procedure of grant of Certificate of Competency. [Inserted by
Notification No./F1-103/88 L & E 17, dated 9.2.1998.]
(1)The Chief Inspector may recognise any person as "competent person" within such area and for
such period as may be specified for the purposes of carrying out tests, examinations, inspections and
certification for such buildings, dangerous machinery, hoists and lifts, lifting machines and lifting
tackles, pressure plant, confined space, ventilation system and such other process or plant and
equipment as stipulated in the Act and the Rules made thereunder, located in a factory, if such
person possess the qualifications, experiences and other requirements as set out in the schedule
annexed to this Rule :Provided that the Chief Inspector may relax the requirements of qualifications
in respect of a competent person, if such a person is exceptionally experienced and knowledgeable,
but not the requirements in respect of the facilities at his command :Provided further that the
competent person recognised under this provision shall not be above the age of 62 and shall be
physically fit for the purpose of carrying out the tests, examination and inspection.(2)The Chief
Inspector may recognise an institution of repute, having person possessing qualifications and
experience as set out in the schedule annexed to sub-rule (1) for the purposes of carrying out tests,
examinations inspections and certifications for buildings, dangerous machinery hoists and lifts,
lifting machines, and lifting tackles, pressure plant, confined space ventilation system and such
other process or plant and equipment as stipulated in the Act and the Rules made thereunder, as a
competent person within such area and for such period as may be specified.(3)The Chief Inspector
on receipt of an application in the prescribed form from a person or an institution intending to be
recognised as a 'competent person' for the purposes of this Act and the Rules made thereunder, shall
register such application and after satisfying himself as regards competence and facilities available
at the disposal of the applicant may recognise the applicant as a 'competent person'. Such
application shall be disposed of either by issuing a certificate of competency in the prescribed Form
or by rejecting the same specifying reasons therefor within a period of 60 days.(4)The Chief
Inspector, if he has reason to believe that 'competent person' :-(a)has violated any condition
stipulated in the certificate of competency;(b)has carried out a test, examination and inspection or
has acted in manner inconsistent with the intent or the purpose of this Act or the Rules made
thereunder, or has omitted to act as required under the Act or Rules made thereunder;(c)for any
other reason to be recorded in writing; may revoke the certificate of competency after giving anBihar Factories Rules, 1950

opportunity to the 'competent person' for being heard.Explanation :- For the purpose of this Rule,
an institution includes an organisation.(5)The Chief Inspector may, for reasons to be recorded in
writing, require re-certification of lifting machines, lifting tackles, pressure plant or ventilation
system, as the case may be, which has been certified by a competent person outside the State.]Form
of Application for grant of certificate of Competency to a person under sub-rule (1) of Rule 2A.
1. Name.
2. Date of Birth.
3. Name of the organisation (if not self-employed).
4. Designation.
5. Educational qualification (copies of testimonials to be attached).
6. Details of professional experience (in chronological order).
Name of the Organisation Period of Service Designation Area of Responsibility
7. Membership, if any, of professional bodies.
8. (i) Details of facilities (examination, testing etc.) at his disposal.
(ii)Arrangements for calibrating and maintaining the accuracy of these facilities.
9. Purpose for which competency certificate is sought (specify Section or
Sections of the Act).
10. Whether the applicant has been declared as a competent person under
any other Statute (If so, furnish details).
11. Any other relevant information.
I, ...........hereby declare that the information furnished above is true, I undertake -(a)that in the
event of any change in the facilities at my disposal (either addition or deletion) or my leaving the
aforesaid organisation, I will promptly inform the Chief Inspector.(b)to maintain the facilities in
good working order, calibrated periodically as per manufacturers instructions or as per National
Standards; and(c)to fulfil and abide by all the conditions stipulated in the certificate of competency
and instructions issued by the Chief Inspector from time to time. To be filled in by the Institution (if
employed).I.............certify that Sri...................whose details are furnished above, is in our
employment and nominate him on behalf of the organisation for the purposes of being declared as aBihar Factories Rules, 1950

Competent Person under the Act. I also undertake that I will-(a)notify the Chief Inspector in case
the competent person leaves our employment;(b)provide and maintain in good order all facilities at
his disposal as mentioned above;(c)notify the Chief Inspector any change in the facilities (either
addition or deletion).Signature..............................Designation.........................Telephone
No......................Official Seal.Date:-Form of Application for grant of Certificate of competency to any
Institution under sub-rule (2) of Rule 2A
1. Name & full address of the organisation.
2. Organisation's status (Specify whether Government,
Autonomous,Cooperative, Corporate or Private).
3. Purpose for which Competency Certificate is sought (Specify Section (s) of
the Act).
4. Whether the Organisation has been declared as a Competent Person under
this or any other Statute. If so, give details.
5. Particulars of persons employed and possessing qualification and
experience as set out in Schedule annexed to sub-rule (1) of Rule 2A.
Sl. NoName and
DesignationQualification ExperienceSection (s) and the Rules under
which competencyis sought for
1.     
2.     
6. Details of facilities (relevant to item 3 above) and arrangements made for
their maintenance and calibration periodically.
7. Any other relevant information.
I,..............hereby, on behalf of...........certify that the details furnished above are correct to the best of
my knowledge, I undertake to -(i)maintain the facilities in good working order, calibrated
periodically as per manufacturers' instructions or as per National Standards; and(ii)to fulfil and
abide by all the conditions stipulated in the certificate of competency and instructions issued by the
Chief Inspector from time to time;Signature of Head of the Institution or the persons authorised to
sign on his behalf.Designation.Place and Date :Form of Certificate of Competency issued to a person
or an Institution in pursuance to Rule 2A.I..........in exercise of the powers conferred on me under
Section 2(ca) of the Factories Act and Rules made thereunder, hereby recognise...................(name of
the Institution)or Shri...........................employed on....................(name of the person) (name of the
organisation)to be a Competent Person for the purpose of carrying out tests, examinations,
inspections and certifications for such buildings, dangerous machinery, lifts and hoists, liftingBihar Factories Rules, 1950

machines and lifting tackles, pressure plants, confined space, ventilation system and such other
process or plant and equipment as the case may be used in a factory located in.................under
Section............and the Rules made thereunder.This certificate is valid from.............to...........This
certificate is issued subject to the conditions stipulated hereunder.............(i)The tests, examinations
and inspections shall be carried out in accordance with the provisions of the Act and the Rules made
thereunder;(ii)The tests, examinations and inspections shall be carried out under the direct
supervision of the Competent Person or by a person so authorised by an institution recognised to be
a Competent Person;(iii)The certificate of competency shall stand cancelled if the person declared
competent leaves the organisation mentioned in his application;(iv)The institution recognised as
Competent Person shall keep the Chief Inspector informed of the names, designation and
qualifications of the person authorised by it to carry out tests, examinations and
inspections.(v)............(vi)...........Station .......... Official Seal :Date :Signature of the Chief Inspector.
Schedule
Sl. No.Section or Rules
under which
competency
isrecognisedQualification requiredExperience for
the purposeFacilities at his
command.
1 2 3 4 5
1.Rules made
under Section 6
and Section
112-certificate
ofstability for
buildings.6 Degree in Civil or
Structural Engineering
or equivalent.(i) A minimum
of 10 years
experience in
the design
orconstruction
of testing or
repairs of
structures; 
(ii) Knowledge of
non-destructive
testing, various
codes ofpractices
that are current and
the effect of the
vibrations
andnatural forces
on the stability of
the building, and 
(iii) Ability to arrive
at a reliable
conclusion with
regardto the safety
of the structure or Bihar Factories Rules, 1950

the building.
2.Rules made
under Section
21(2.) -
"Dangerous
Machines".Degree in Electrical or
Mechanical or Textile
Engineering
orequivalent.(i) Minimum of
7 years
experiencein-(a)
the design or
operation
ormaintenance,
or(b) the
testing,
examination
and inspection
of
relevantmachinery,
their guards,
safety devices
and appliance.Causes for
measurement,
Instrument for
measurement of
speedand any other
equipment or
device to determine
the safety in theuse
of the dangerous
machines.
(ii) He shall-
(a) be conversant
with the safety
devices and their
properfunctioning;
(b) be able to
identify defects and
any other cause
leadingto the
failure; and
(c) have ability to
arrive at reliable
conclusion with
regardto the proper
functioning of the
safety device and
appliancesand the
Machine guard.
3. Section 28-Lifts
and Hoists.A degree in Electrical
and/or Mechanical
Engineering or
itsequivalent.(i) A minimum
experience of 7
years in -Facilities for lead
testing, tensile
testing,
gaugesequipments/
gadgets for
measurement and
any other
equipmentrequired
for determining theBihar Factories Rules, 1950

safe working
conditions of
theHoists and Lifts.
(a) design or
erection
ormaintenance;
or(b) inspection and
test procedure of
lifts and hoists.
(ii) He shall be-
(a) Conversant with
relevant codes of
practices and
testprocedures that
are current;
(b) conversant with
other statutory
requirements
covering thesafety of
Hoists and Lifts;
(c) able to identify
the defects and
arrive at a
reliableconclusion
with regard to the
safety of the Hoists
and Lifts.
4.Section
29-Lifting
Machinery and
Lifting Tackles.Degree in Mechanical
or Electrical.
Metallurgical
Engineeringor its
equivalent(i) A minimum
experience of
7years in -(a)
design or
erection
ormaintenance,
or(b) testing,
examination
and inspection
of lifting
machinery,chains,
ropes and
lifting tackles.Facilities for lead
testing tensile
testing, heat
treatment,equipment/gadget
for measurement,
gauges and such
otherequipment to
determine the safe
working conditions
of thelifting
machinery, tackles.
(ii) He shall be-
(a) conversant with
the relevant codes ofBihar Factories Rules, 1950

practices and
testprocedures that
are current;
(b) conversant with
fracture machines
and metallurgy of
thematerial of
construction;
(c) conversant with
heat
treatment/stress
relievingtechniques
as applicable to
stress bearing
components and
partsof lifting
machinery and
lifting tackles;
5.Section 31 -
'Pressure Plant'Degree in Chemical or
Electrical or
Mechanical
Engineeringor its
equivalent.(1) A minimum
experience of
10years in -(a)
design or
erection
ormaintenance
or(b) Testing,
examination
and inspection
of pressure
plants.Facilities for
carrying out
hydraulic test,
non-destructivetest,
gauges
equipment/gadgets
for measurement
and any
otherequipment or
gauges to determine
the safety in the use
ofpressure vessels.
(ii) He shall be-
(a) conversant with
the relevant codes of
practices and
testprocedures
relating to pressure
vessels;
(b) conversant with
other statutory
requirements
concerningthe
safety of unfired
pressure vessels andBihar Factories Rules, 1950

equipment
operatingunder
pressure;
(c) conversant with
the destructive
testing techniques
as areapplicable to
pressure vessels;
(d) able to identify
the defects and
arrive at a
reliableconclusion
with regard to the
safety of the
pressure plant.
6.(i) Section 36
precautions
against
dangerous
fumes.Master's degree in
Chemistry, or a degree
in the
ChemicalEngineering.(i) A minimum
of 7 years in
collection,
analysis
ofenvironmental
samples and
calibration of
monitoring
equipment; 
(ii) He shall-  
(a) be conversant
With the hazardous
properties of
chemicaland their
permissible limit
values; 
7. Ventilation
systems as
requiredunder
various
schedules
framed under
Section 87, such
asschedules
on-(i) Grinding
or glazing of
metalsand
processDegree in Mechanical
or Electrical
Engineering or
equivalent.(b) be
conversant with
the current
technique as of
a samplingand
analysis of the
environmental
contaminants;
and Bihar Factories Rules, 1950

incidental
thereto;(ii)
Cleaning or
smoothing,roughening,
etc. of articles,
by a jet of sand,
metal shot,
orgrit, or other
abrasive
propelled by a
blast of
compressed
airor steam.(iii)
Handling and
processing
ofAsbestos.(iv)
Manufacturing
of Rayon
byviscost
process.(v)
Foundary
operations.
(c) be able to arrive
at a reliable
conclusion as
regards thesafety in
respect of entering
and carrying out hot
work. 
(i) A minimum of 7
years in the design
fabrication,installation,
testing of ventilation
system and systems
used forextraction
and collection of
dusts fumes and
vapours and
otherancillary
equipment. 
(ii) He shall be
conversant with
relevant codes of Bihar Factories Rules, 1950

practiceand tests
procedures that are
current in respect of
ventilationand a
traction system for
furnaces and shall
be able to arriveat a
reliable conclusion
with regard to
effectiveness of
thesystem.
  
  
3. Approval of plans.
- [(1) No site shall be used for the location of a factory or no building shall be constructed,
re-constructed, extended or taken into use as a factory or a part of a factory unless an application in
Form No.1 along with the documents and plan as prescribed in sub-rule (2) has been submitted to,
and the plans submitted have been approved by the Chief Inspector of Factories and previous
permission in writing in respect thereof has been obtained, subject, however, to the provisions of
sub-section (2) of Section 6.] [Substituted by G.S.R. 82 dated 27.11.1976.](2)The application
mentioned in sub-rule (i) shall be in Form No. 1 and shall be accompanied by the following
documents, namely :-(a)A flow diagram or chart of the manufacturing process to be carried on in
the factory or in the part of factory.(b)A brief description of all the manufacturing processes and
work proposed to be carried on in the factory or in the part of the factory, and(c)The following plans
and drawing each in triplicate, drawn to scale :-(i)site plan of the factory showing its surrounding
including other buildings, structures, open land, roads, streams of rivers adjacent or close to the
site.(ii)lay out. - plan of the factory and its premises,(iii)plans, elevations, and all necessary
cross-Sections of all the buildings, indicating relevant details including those relating to natural
lighting, ventilation and means of escape in case of fire and showing clearly the position of the plant,
machinery, aisles, passageways and gun-ways.(3)The Chief-Inspector of Factories, may approve the
plan submitted in accordance with sub-rule (2) subject to such conditions as he may specify in
writing and where any conditions are specified, the plan shall be deemed to have been approved
only when the said conditions are fulfilled :Provided that the Chief Inspector may, if on account of
practical difficulties, is so satisfied, dispense with the details relating to the position of the plant,
machinery, aisles, passage-ways and gun-ways from the plan.(4)The Chief Inspector may require the
applicant to furnish such other documents, informations and practicals as may be lacking or as he
may consider necessary for the purpose of examination and approval of the plans.(5)The Chief
Inspector shall communicate his decision to the applicant in writing and in case any plan is
approved the Chief Inspector shall return one copy of each of the approved plans along with the
conditions, if any, imposed by him, and with such remarks as he may consider necessary.Bihar Factories Rules, 1950

3A. [ Certificate of Stability. [Inserted by S.O. 688 dated 18.7.1988.]
- No manufacturing process shall be carried on in any building of a factory constructed,
reconstructed or extended, or in any building which has been taken into use as a factory or part of a
factory until a certificate of stability in respect of the building in Form No. 34 has been sent by the
occupier or manager of the factory to the Chief Inspector, and accepted by him.]
4. Registration and grant of licence.
(1)Subject to the provisions of Rule 5, no manufacturing process shall be started or carried on in any
factory unless a licence in respect thereof has been granted by the [Inspector of Factories]
[Substituted by S.O. 1093 dated 30.10.1985.] and the same is valid for the time being.Explanation. -
The permission granted by the [Inspector of Factories] [Substituted by S.O. 1093 dated 30.10.1985.]
under sub-rule (i) of Rule 5 shall be deemed to be a licence and shall remain valid until-(a)the
licence is granted,(b)the permission granted is withdrawn for having been failed to fulfil the
conditions specified therein or any other reason,(c)the period, if any, for which the permission has
been granted expires, or(d)the [Inspector of Factories] [Substituted by S.O. 1093 dated 30.10.1985.]
communicates in writing the reason for not granting the licence.(2)The occupier of a factory shall
submit to the Chief Inspector an application in Form 2 in triplicate for the registration of the factory
and grant of licence.
5. Grant of licence.
- [(1) An application for a licence to work a factory shall be made in Form No.2 and shall be
submitted in triplicate to the Inspector of Factories of the area concerned who after making such
enquiries as he may deem fit for satisfying himself, about the correctness of the particulars and on
payment of fees specified in Schedules A, B, C and D may register the factory in a register to be kept
in his office for the purpose and grant a licence for the factory in Form IV on such terms and
conditions as may be specified with the approval of the Chief Inspector of Factories. Pending grant
of such licence the Inspector of Factories of the area concerned may grant permission to start to
carry on work in the factory subject to such conditions as he may specify in writing :Provided that in
every such case of grant of licence or permission to start or carry on work in the factory, the State
Government may call for the relevant documents from the Chief Inspector of Factories or the
Inspector of Factories of the area concerned and review the decision taken in the case and subject to
provisions of Section 107, wherever such review is made. State Government's decision in the matter
shall be final.] [Substituted by S.O. 1093 dated 30.10.1985.](2)[ Every licence granted or renewed
under this chapter shall remain valid for a period of five years and in force up to the 31st December
of the year for which it is granted or renewed.Provided that every licence granted to a factory,
declared under Section 85 of the said Factories Act, 1948, shall remain valid till the closure of the
concerned factory.] [Substituted by No. 58, dated 19.1.2010.](3)The licence or a copy thereof [x x x
x] [Omitted by S.O. 1093 dated 30.10.1985.] shall be exhibited at a conspicuous place in the factory
near the main entrance, and a signboard with the licence number allotted to the factory in bold
letters shall be displayed at the main entrance:Provided that the signboard shall not be smaller in
size than 12" x 9" and the letters thereon not less than 2" in height. The letters on the signboard shallBihar Factories Rules, 1950

be arranged as follows :-
F.A.No...............
6. Amendment of licence.
(1)A licence may be amended by the [Inspector of Factories] [Omitted by S.O. 1093 dated
30.10.1985.] with the approval of the State Government.(2)When there is any increase in the
number of workers employed or in the rated capacity of the machinery and plants installed in terms
of H.P. or K.W. installed, resulting in an increase in the amounts of fee payable for the licence as
compared to the fee already paid or when there is any other change requiring amendment in the
licence already granted or renewed, the occupier of the factory shall, within 15 days of the increase
or change as the case may be, submit an application to the [Inspector of Factories] [Substituted by
S.O. 1093 dated 30.10.1985.] for amendment of the licence, stating therein the nature of
amendment required and the reasons therefor.(3)The fee for the amendment of licence shall be [one
hundred] [Substituted by S.O. 113 dated 22.5.1992.] rupees :Provided that when the amendment is
required due to the increase in the number of workers or in the rated capacity of the machinery and
plants installed, the fee for amendment of licence shall be one hundred rupees plus the amount by
which the fee that would have been payable if the licence had originally been issued in the amended
form exceeds the fee originally paid for the licence.(4)The licence already granted shall cease to
remain valid after the change or increase in the number of the workers or in the installed capacity as
aforesaid unless the occupier has filed an application and paid the required fee as laid down in these
Rules within fifteen days from the said date of change or increase.(5)[ Every such application for
amendment of a licence will be forwarded by the Inspector of Factories concerned through of Chief
Inspector of Factories to the State Government for approval before the licence is amended.]
[Inserted by SIO. 1093 dated 30.10.1985.]
7. Renewal of licence.
- [(1) An application for renewal of licence shall also be in Form No. 2 and shall be submitted in
triplicate to the Inspector of Factories of the area concerned not later than the date on which the
licence expires and if the application is so made the factory, shall be deemed to be duly licenced until
such date as on which the Inspector of Factories renews the licence on which the Inspector of
Factories communicates in writing the reasons for not renewing the licence.] [Substituted by S.O.
1093 dated 30.10.1985.](2)The fee for the renewal of the licence shall be the same as that for grant
thereof.[If the application for renewal of licence is not received within fifteen days after the expiry of
the licence the fee payable for licence renewal application shall be fifty percent more in addition to
the fee prescribed in schedules (a), (b) and (c) for three months and after three months fee for
renewal of licence will be cent-percent more in addition to the fees prescribed in Schedules (a), (b)
and (c).] [Substituted by S.O. 113 dated 22.5.1992.](3)[ A licence may be renewed by the Inspector of
Factories with the approval of the Chief Inspector of Factories :Provided that the State Government
may call for the relevant documents from the Chief Inspector of Factories or the Inspector of
Factories of the area concerned and review the decision taken in the case and subject to the
provisions of Section 107, wherever such review is made the State Government's decision in the
matter will be final.] [Substituted by S.O. 1093 dated 30.10.1985.](4)The Chief Inspector mayBihar Factories Rules, 1950

condone the additional fee prescribed in the proviso to sub-rule (2), in case he is satisfied that the
delay in submission of application for renewal of licence was due to any reason beyond the control of
the occupier or due to any other reason of similar nature.
8. Transfer of licence.
(1)When there is any change of the occupier of factory before the expiry of the licence the new
occupier shall within 15 days of the transfer, apply to the [Inspector of Factories of the area
concerned] [Substituted by S.O. 1093 dated 30.10.1985.] for transfer of licence in his name
:Provided that in the case of the death or insolvency of an occupier, the person succeeding or taking
over the factory and functioning as the occupier shall apply for transfer and for amendment of the
licence for the remaining period as soon as practicable, but in no case later than one month after the
death or taking over:[Provided further that no such transfer of a licence will be made by the
Inspector without obtaining prior approval of the Chief Inspector.] [Inserted by S.O. 1093 dated
30.10.1985.](2)The application for transfer shall be accompanied by a letter from the previous
occupier or some other documentary evidence which may prove that the occupation of the factory
has been transferred to the applicant.(3)The fee for transfer of licence shall be [one hundred rupees]
[Substituted by S.O. 118 dated 22.5.1992.] and shall be payable by the new occupier applying for
transfer of licence under sub-rule (1).
9. Loss of licence.
- When a licence granted under these Rules is lost or destroyed, a duplicate may be granted on
payment of a fee of [Rs. Twenty five.] [Substituted by S.O. 118 dated 22.5.1992.]
10. Payment of fees.
(1)Every application under these Rules shall be accompanied by the Treasury Challan showing that
the appropriate fee has been deposited in one of the treasuries in the State of Bihar under the head
of account [087-Labour and Employment - Fees realised under the Factories Act] [Inserted by S.O.
1093 dated 30.10.1985.]:Provided that when the head of account under which the licence fees have
to be deposited is changed, the [Inspector of Factories] [Substituted by S.O. 1093 dated 30.10.1985.]
may direct the occupiers to deposit the fees payable under these Rules under such head of account
as he may specify.(2)The fee or any portion of the fee paid may be refunded to the applicant by the
[Inspector of Factories of the area concerned] [Substituted by S.O. 1093 dated 30.10.1985.] as
refund of revenue if an application for grant, renewal, amendment or transfer of a licence is rejected
or if for any other reason fee or portion of the fee so paid, is considered by the [Inspector of the area
concerned] [Substituted by S.O. 1093 dated 30.10.1985.] as not payable.
11.
It shall be the duty of the occupier to submit to the [Inspector of Factories, of the area concerned]
[Substituted by S.O. 1093 dated 30.10.1985.] application for registration and grant of licence or forBihar Factories Rules, 1950

renewal of licence or for transfer or amendment of the licence as may be necessary within the time
prescribed in the foregoing Rules.
12. Notice of occupation.
- The notice of occupation shall be in Form No.2.
12A. Notice of change of Manager.
- The notice of change of Manager shall be in Form No. 3.
12B. [ Guidelines, instructions and Record. [Inserted by Notification no.
2/F1-103/88 L & E dated 9.2.93.]
(1)Without prejudice to the general respectability of the occupier to comply with the provisions of
Section 7(A), the Chief Inspector may, from time to time issue guidelines and instructions regarding
the general duties of the occupier relating to health, safety and welfare of all workers while they are
to work in the factory.(2)The occupier shall maintain such records, as may be prescribed by the
Chief Inspector, in respect of monitor or working environment in the factory.]
Chapter II
Inspectors and Certifying Surgeons
13. Powers of Inspectors.
(1)An Inspector shall, for the purpose of giving effect to the provisions of the Act, have powers to do
all or any of the following things, that is to say :-(a)to photograph any worker; to inspect, examine,
measure, copy, photograph, sketch or test, as the case may be, any building or room, any plant,
machinery, appliance or apparatus, any register or document, or anything provided for the purpose
of securing the health, safety or welfare of the workers employed in a factory;(b)in the case of an
Inspector who is a duly qualified medical practitioner, to carry out such medical examinations as
may be necessary for the purposes of his duties under the Act;(c)to file a complaint in Court against
the manager or the occupier of a factory or against both or against any other person liable to be
punished under the Act and to prosecute, conduct or defend before a court any complaint or other
proceeding arising under the Act or in discharge of his duties as an Inspector;(d)to satisfy himself at
each inspection that-(i)The provisions of the Act and of these Rules regarding the health and safety
of the workers employed in the factory are observed;(ii)the adolescents and children employed in
the factory have been granted certificate of fitness and that no adolescent or child is employed who
is obviously unfit;(iii)the register of all workers employed in such factory, of their hours of work and
the nature of their employment, is in the prescribed form;(iv)the periods of rest and the holidays
provided by the Act are granted, and that the limits of hours of work laid down therein are not
exceeded;(v)the provisions of Section 59 and of the Rules relating to the payment of overtime areBihar Factories Rules, 1950

duly observed; and(vi)the notices required by Sections 61 and 72 and the abstracts required by
Section 108 are duly affixed and that the registers required by these Rules are properly
maintained.(e)to enquire into and investigate the cause of any accident or disease, or the possibility
of any accident or disease;(f)to note how far the defects pointed out at a previous inspection have
been removed and how far orders previously issued have been complied with;(g)to point out all such
illegalities, defects or irregularities as he may observe during the course of his inspection and to
forward a copy of the inspection note to the manager or occupier of a factory for removal of the
illegalities, defects or irregularities;(h)to seize any record or document for the purpose of
examination and satisfying himself that the provisions of the Act and the Rules thereunder were
complied with or which he may consider relevant in respect of any offence under the Act which he
may have reasons to believe or suspect, has been committed by the occupier or the manager;(i)to
direct by an order in writing the occupier or the manager to produce either personally or through his
agent any prescribed record or register at his office or at any other place where he may be
temporarily camping or at any other convenient place; and(j)to direct by an order in writing the
manager or the occupier or any other employee of a factory to appear before him personally at his
office, or at the place where he may be temporarily camping or at any other place, to be examined
and interrogated by him on any matter connected with the compliance of the provisions of the Act or
the Rules.(2)The Inspector shall keep a file of the records of his inspection in Form No. 28.(3)Every
order passed under the Act and these Rules, shall be served on the Manager of a factory-(a)by
delivering a copy of it to him personally or at his office, or(b)by registered post.
13A. Qualifications of an Inspector.
- No person shall be appointed as an Inspector for the purposes of the Act, unless he possesses the
qualifications hereunder-(a)he must not be less than 22 years or more than 35 years of age:Provided
that in the case of a candidate belonging to Scheduled Castes or Scheduled Tribes, the upper age
limit shall be 40 years.(b)he must have secured a degree or diploma, equivalent to a degree of a
recognised University in any branch of Engineering, Technology or Medicine;(c)the Government
may, in addition to the basic qualifications, by order, specify appropriate additional qualifications, if
any, for a particular post:Provided that in the case of a person who has been working as an Inspector
under the Act at the time of commencement of this Rule, the Government may, subject to such
conditions as it may specify, exempt such person from the provisions of this Rule.
14. Duties of Certifying Surgeon.
(1)For the purpose of the examination and certification of young persons who wish to obtain
certificate of fitness, the Certifying Surgeon shall arrange a suitable time and place for the
attendance of such persons, and shall give previous notice in writing of such arrangements to the
managers of factories situated within the local limits assigned to him.(2)(a)Every Certifying Surgeon
shall keep bound books containing certificates in Form No.5 respectively in foil and counterfoil. In
each book the form shall be numbered consecutively and shall be printed on cloth-backed paper.
The foil and counterfoil shall be filled in and the left thumb mark of the person or his signature in
whose name the certificate is granted shall be taken on them. On being satisfied as to the correctness
of the entries made therein and of the fitness of the person examined, the Certifying Surgeon shallBihar Factories Rules, 1950

sign the foil and initial the counterfoil and shall deliver the foil to the person in whose name the
certificate is granted.The foil so delivered shall be the certificate of fitness granted under Section 69.
All counterfoils in a book shall be preserved by the Certifying Surgeon for a period of at least two
years after the issue of the last certificate in that book.(b)A Certifying Surgeon revoking a certificate
under sub-section (4) of Section 69 shall write the word "Revoked" in red ink on the foil and
counterfoil.(3)Any authority granted by a Certifying Surgeon under sub-section (2) of Section 10 to a
qualified medical practitioner (hereinafter referred to as the Examining Surgeon) to exercise the
powers of the Certifying Surgeon under the Act shall be made in writing and shall state the factories
or area to which the jurisdiction of the Examining Surgeon is limited, and any cancellation of such
authority shall be made by the Certifying Surgeon in writing.(4)An examining Surgeon shall grant
and revoke certificate in the manner provided in sub-rule (2). The word "Provisional" shall be
printed or stamped in red ink at the top of each foil and counterfoil.(5)(a)A person who loses a
certificate of fitness which has been granted to him may apply to the Surgeon who granted it for a
copy of the certificate and the said Surgeon after making such enquiry from such person's employer
(or if such person is unemployed, from his last employer) and from such other sources, as he deems
fit, may grant a duplicate of the lost certificate. The word "Duplicate" shall be clearly written in red
ink across such duplicate certificate and initialled by the said Surgeon. The counterfoil in the bound
book of forms shall be similarly marked "Duplicate" and initialled.(b)For every copy of a duplicate
certificate granted under clause (a), a fee of fifty Naye Paise shall be charged, which shall be credited
to Government. The Certifying Surgeon or Examining Surgeon shall maintain a register in Form
No.26 of all fees paid for the issue of duplicate certificates and shall initial each entry therein.(c)No
duplicate of certificate shall be granted to any person otherwise than in accordance with the
provisions of this sub-rule.(6)(a)The Certifying Surgeon shall visit every factory within the local
limits for which he is appointed in which adolescents or children are known to be employed, atleast
once in three months. At each of these visits the manager shall produce before him all adolescents
and children employed in the factory, whether actually at work or not.(b)The Certifying Surgeon
shall personally examine every adolescent and child who is in possession of a "Provisional"
certificate granted under sub-rule (4) and shall, if satisfied that a certificate of fitness should be
granted, destroy the provisional certificate and issue his own certificate of fitness in place of it.(c)If
on such examination the Certiyfing Surgeon is of opinion that a person in possession of a child's
provisional certificate of fitness is under the age of fourteen years or is not fit for employment as a
child in a factory, or that a person in possession of an adults provisional certificate of fitness is less
than 15 years of age or is unfit to work as an adult, he shall impound the certificate, write on it the
word "Cancelled" and sign the same and shall forward the certificate with such remarks, if any, as he
may offer to the Inspector of Factories for information, and inform the Examining Surgeon who
granted such provisional certificate.(7)If the Certifying Surgeon refuses to grant any person a
certificate of fitness, or if he cancels a 'Provisional Certificate' of fitness, no fresh application for a
certificate for such person shall be entertained until after the lapse of three months from the date of
such refusal, unless the Certifying Surgeon otherwise gives permission in writing at the time of
refusing to grant the certificate or at the time of cancelling a 'Provisional Certificate':Provided that
this sub-rule shall not prevent the immediate granting of a certificate of fitness as a child to a person
whose certificate of fitness as an adult has been revoked under clause (c) of sub-rule (6), if in the
opinion of the Certifying Surgeon such person is of age and fit to work in a factory as a child.(8)The
Certifying Surgeon or the Examining Surgeon, as the case may be, at his periodical visits shall satisfyBihar Factories Rules, 1950

himself as to the fitness of all the adolescents and children employed in the factory and shall revoke
the certificate of fitness of any whom he deems to be unfit.(9)The Certifying Surgeon and the
Examining Surgeon shall hand over to the Manager a note in Form No. 27 detailing the result of
each visit to the factory.(10)The Certifying Surgeon shall, upon request by the Chief Inspector or an
Inspector, carry out such examination and furnish him with such report as he may indicate, for any
factory or class or description of factories where-(a)cases of illness have occurred which it is
reasonable to believe are due to the manufacturing process carried on, or other conditions of work
prevailing therein; or(b)by reason of any change in the manufacturing process carried on, or in the
substances used therein, or by reason of the adoption of any new manufacturing process or of any
new substance for use in a manufacturing process, there is a likelihood of injury to the health of
workers employed in that manufacturing process; or(c)young persons are, or are about to be,
employed in any work.(11)For the purpose of the examination of persons employed in processes
covered by the Rules relating to dangerous operations, the Certifying Surgeon shall visit the factories
within the local limits assigned to him at such intervals as are prescribed by the Rules relating to
such dangerous operations.(12)At such visits the Certifying Surgeon shall examine the persons
employed in such processes and shall record the results of his examination in a register known as
the Health Register (Form No. 16) which shall be kept by the factory manager and produced to the
Certifying Surgeon at each visit.(13)If the Certifying Surgeon finds as a result of his examination that
any person employed in such process is no longer fit for medical reasons to work in that process, he
shall suspend such person from working in that process for such time as he may think fit and no
person after suspension shall be employed in that process without the written sanction of the
Certifying Surgeon in the Health Register.(14)The manager of a factory shall afford to the Certifying
Surgeon facilities to inspect any process in which any person is employed or is likely to be
employed.(15)The manager of a factory shall provide for the purpose of any medical examination
which the Certifying Surgeon wishes to conduct at the factory (for his exclusive use on the occasion
of an examination) a room which shall be properly cleaned and adequately ventilated and lighted
and furnished with a screen, a table (with writing materials) and chairs.(16)[ Any register or record
of medical examination and tests therewith required to be carried out under any of the schedule,
annexed to Rule 95 in respect of any worker shall be kept available and shall be preserved till the
expiry of one year after the worker ceases to be in employment of the factory.] [Inserted by S.O. 686
dated 13.7.1988.]
14A. Fees for Certifying Surgeon for examination of young persons.
(1)The Certifying Surgeon shall be entitled to the following fees for examination and grant of
certificate of fitness under sub-section (2) of Section 69 :-(i)Rs. 4 (Rupees four) for first young
person and Re.1 (Rupee one) for every subsequent person examined in a single day in a factory for
the purpose of such examination;(ii)Rs. 2 (Rupees two) for the first young person and Re. 1 (Rupee
one) for every subsequent young person examined on a single day when the person to be examined
go to the Certifying Surgeon for the purpose of such examination;(iii)If a Certifying Surgeon has to
travel beyond a radius of five miles from his dispensary or place of posting to examine any young
person or persons, he shall be entitled to an additional fee at the rate of thirty seven Naya Paise only
per mile for the total distance travelled by him. A Certifying Surgeon who is the servant of the State
Government shall charge this additional fee from the occupier of a factory only if he does not chargeBihar Factories Rules, 1950

any travelling allowance for the journey from the State Government.(2)The Certifying Surgeon shall
send his bill of fees direct to the occupier of the factory in which the young persons are examined or
are to be employed.(3)For the purpose of his duties, as specified in sub-rule 6 of Rule 14, a
Certifying Surgeon shall be entitled to the same rate of fee for examination and grant of certificates
of fitness and the same rate of additional fee for travelling as specified in sub-rule (1) of this
Rule.(4)The fees and additional fees prescribed in this Rule shall be paid by the occupier of the
factory concerned.(5)The fees and additional fees for the renewal of certificate of fitness shall be the
same as prescribed in these Rules for grant of certificate of fitness.(6)An Examining Surgeon shall
be entitled to the same fees and additional fees as prescribed for a Certifying Surgeon.
14B. Fees for Certifying Surgeon for carrying on examination under sub-rule
(10) of Rule 14.
- A Certifying Surgeon shall be paid by the occupier of the factory besides the additional fees for
travelling, a daily professional fee at the rate of Rs. 16 per day irrespective of the number of persons
examined but this fee shall be reduced to Rs. 8 if the examination does not take more than half of a
day :Provided that if the number of factories visited exceeds four on a single day, the professional fee
payable above shall be raised to Rs. 24 per day.
14C. Fees for medical practitioners.
(1)On receipt of a report under sub-section (2) of Section 89 from a Medical Practitioner and after
getting the report confirmed by a certificate of a Certifying Surgeon or otherwise, the Chief Inspector
shall pay a fee of Rs. 4 (Rupees four) only to the Medical Practitioner concerned for each person
suffering from any disease specified in the Schedule to the Act.(2)The Chief Inspector shall send a
written demand to the occupier of the factory concerned by registered post under acknowledgement
due for the amount to be paid by him under sub-rule (1).(3)On receipt of such demand the occupier
of the factory concerned shall within a fortnight deposit the amount into the nearest Treasury or
Sub-Treasury by means of a Challan under the head ["087-Employment-Labour and Fees realised
under the Factories Act".] [S.O. No. 281, dated 18.2.1977, Published in Bihar Gazette (extraordinary)
dated February 23, 1977.] and shall immediately send the Challan in original by Registered Post to
the Chief Inspector in compliance with the notice of demand.(4)If any occupier fails to deposit the
amount demanded by the Chief Inspector within a fortnight of the receipt of the notice of demand
the Chief Inspector shall take steps to recover the amount as an arrear of Land Revenue from the
occupier of the Factory concerned.
14D. Fees for examination of persons employed in dangerous operations.
- The fees and additional fees for examination for persons employed in dangerous operations as
specified in Rule 95 shall be the same as prescribed in Rule 14-A, and shall be payable by the
occupier of the factory in which the persons examined are employed.Bihar Factories Rules, 1950

14E. Debiting of fee payable by the Chief Inspector under Rule 14-C.
- The fees payable by the Chief Inspector under Rule 14-C shall be debited to the head [281-Labour
and Employment" - Labour working condition and safety Inspector of Factories] [S.O. No. 281,
dated 18.2.1977, Published in Bihar Gazette (extraordinary) dated February 23, 1977.],
14F. Arrear of fees and additional fees to be recovered from the occupier as
arrears of land revenue.
- If the occupier of any factory fails to pay the fees or additional fees, or both, prescribed under Rules
14-A, 14-B and 14-D to any Certifying Surgeon, the same shall, on an application received from the
Certifying Surgeon by the Chief Inspector, be recoverable as an arrear of land revenue from the
occupier of the factory concerned and paid to the Certifying Surgeon concerned.
Chapter III
Health
15. Record of white washing, etc.
- The record of dates on which whitewashing, colour-washing, varnishing, etc. are carried out shall
be entered in a register maintained in Form No.7.
16. Disposal of wastes, and effluents.
(1)In this Rule, unless there be anything repugnant in the subject or context, the word "Stream"
shall include any river, stream, water course, inland water tank, reservoir, or the like, whether
natural or artificial, and "wastes" unless specifically mentioned shall include "effluents" whether
solid, liquid or gaseous.(2)Such effluents as may be harmless and as do not need any treatment to
make them harmless shall be separated from other effluents and shall be carried in separate
drains:Provided that if the quantity of such effluents is very small, the Chief Inspector may permit
all the effluents to be carried in one drain.(3)All wastes unless they are harmless shall be cleaned,
treated and purified effectively by such electrical, mechanical, chemical or other means by a
combination of any of these, as may be appropriate considering the nature and quality of the waste,
so as to make the waste innocuous and harmless.(4)The waste shall be purified to such a degree and
shall be disposed of in such a manner as may not pollute any stream or atmosphere or may not
cause any damage or harm to any fish, animal or plant life or may not cause any injury to the health
of, or be a source of nuisance to the inhabitants of the area in the vicinity of the factory or in the area
over or through which the wastes may spread or pass.(5)Efficient drains shall be provided for the
effluents from the point of origin to the place of treatment and the place of disposal.The drains shall
be of such capacity as to be adequate for draining out the entire effluents without allowing them to
over-flow and shall be constructed of masonry, concrete, or bricks and cement and shall be covered
unless iron or concrete pipes are used for carrying the effluents :Provided that the Chief InspectorBihar Factories Rules, 1950

may, by an order in writing, relax the requirements of this sub-rule to such extent and subject to
such conditions as he may specify, if he is satisfied that compliance with the provision thereof is not
necessary or practicable.(6)Wastes which are gaseous or a mixture of gases and solids shall be
removed by means of a mechanical exhaust system or by such other means as may be effective and
practicable and the system of exhaust shall be of adequate capacity and the wastes removed shall be
disposed of in such manner as to ensure that they do not escape in any work-room or that they do
not spread and cause nuisance in the vicinity of the factory.Where the gaseous wastes contain solid
particles in such quantity as may create nuisance in the locality, effective arrangements shall be
made to separate solid materials from the gaseous wastes before allowing the gaseous wastes to
escape in the atmosphere and effective arrangement shall be made for the collection and disposal of
the collected solid wastes :Provided that the provisions of this sub-rule shall not apply to a factory
which is already in existence on the date on which these amendments came into force but in case of
such factories the Chief Inspector may direct the occupier and the manager of the factory to take
such steps and to make such arrangements to prevent or minimise the nuisance as may be
practicable :Provided further that the Chief Inspector may relax the requirements of this Rule to
such extent and subject to such conditions as he may specify in writing if he is satisfied that
compliance with the provisions of this sub-rule is not practicable or necessary in consideration of
the capacity of the factory or the degree of nuisance created thereby.(7)Solid wastes shall not be
allowed to spread in any workroom or in any part of the factory. Such wastes shall be collected in
suitable receptacle at convenient places and arrangements shall be made for the disposal of such
wastes at frequent intervals.(8)In case of a factory which comes into existence after this Rule comes
into effect, no manufacturing process shall be started in the factory unless complete details, as
specified in sub-rules (9) and (10) of the arrangements for the treatment and the disposal of the
wastes and effluents have been submitted to and approved by the Chief Inspector and unless
arrangement as approved have been made :Provided that in case of factories which are already in
existence on the date on which this Rule comes into force, the above mentioned details shall be
submitted to the Chief Inspector within three months and the arrangements as approved shall be
made within six months of the date of approval. The Chief Inspector may, however, extend these
period up to six months and 12 months respectively :Provided further that the approval of the Chief
Inspector mentioned in this sub-rule shall not be necessary in the following circumstances
:-(a)Where the drainage system of the factories is connected to the public sewerage system or where
the wastes of the factory are proposed to be discharged into the public sewerage. In the case of such
a factory, complete details and particulars in respect of the proposed arrangements for the
treatment and disposal of the wastes shall be submitted to the authority under whose control the
public sewerage functions and no manufacturing process shall be started in the factory and the
wastes shall not be,discharged into the public sewerage system unless the arrangements have been
approved by the said authority, and where the approval has been given by the said authority an
attested copy of the letter of approval along with the details of the arrangements shall be submitted
to the Chief Inspector within one month of the date of approval.(b)When the arrangement and
scheme for the treatment and disposal of the wastes of the factory have been approved by the
Director of Health Services.In the case of such a factory, an attested copy of the letter of approval
with complete details of the arrangements and the scheme for the treatment and disposal of wastes
shall be submitted to the Chief Inspector within one month of the date of approval and no
manufacturing process shall be started in the factory unless the approval of the Director of HealthBihar Factories Rules, 1950

Services has been obtained and unless arrangements as approved have been made.(9)The following
details and particulars in respect of the arrangements for treatment and disposal of wastes shall be
submitted to the Chief Inspector for approval:-(a)Three copies of the layout plan of the factory
showing the point of origin and the place of discharge or disposal of the wastes and the layout and
arrangements of drains and other devices for carrying and disposal of the wastes from the point of
origin to the point of disposal or discharge.(b)Three copies of the site plan of the factory along with
its environs showing the alignment of drains or channels for carrying the wastes as well as showing
the area or through which the wastes are likely to spread or pass.In the site plan, the villages,
residential areas, agricultural fields, etc., through or over which the wastes and the effluents may
pass shall be clearly indicated.(c)Nature and description of different wastes produced in the
factory.(d)The quantity of each of the wastes produced per day.(e)The chemical composition of the
waste, chemical analysis and B.O.D. value on the liquid wastes.(f)The maximum quantity of the
wastes required to be treated and disposal of any one day.(g)The maximum temperature of the
wastes at the place where it is to be disposed of.(h)Where the wastes are to be discharged in a
stream, the lowest rate of flow of the stream, in case it is a flowing stream, and size and capacity of
the stream otherwise.(i)Three copies of the plans showing complete details of the treatment plant,
or the arrangements for the treatment of wastes.(j)Three copies of the detailed description of the
entire arrangement for treatment and disposal of wastes.(10)The Chief Inspector or an Inspector
may require such other details, particulars or informations to be furnished as he may consider
necessary in order to be able to examine the scheme for treatment and disposal of the wastes.(11)On
receipt of complete details as prescribed above, the Chief Inspector may approve the arrangements
with such conditions as he may specify in writing.(12)If the Chief Inspector finds that any
arrangement which was approved was not effective he may direct the occupier and the Manager to
re-examine and modify the arrangement in such a manner, to such an extent and within such a
period as he may specify in writing.
17. When artificial humidification not allowed.
- There shall be no artificial humidification in any room of a cotton spinning or weaving
factory-(a)by the use of stream during any period when the dry bulb temperature of that room
exceeds 85 degrees;(b)at any time when the wet bulb reading of the hygrometer is higher than that
specified in the following Schedule in relation to the dry bulb reading of the hygrometer at that time;
or as regards a dry bulb reading intermediate between any two dry bulb reading indicated
consecutively in the Schedule when the dry bulb reading does not exceed the wet bulb reading to the
extent indicated in relation to the lower of these two dry bulb readings :-
Schedule 2
Dry bulb. Wet bulb. Dry bulb. Wet bulb. Dry bulb. Wet bulb.
1 2 3 4 5 6
60.0 58.0 77.0 75.0 94.0 85.0
61.0 59.0 78.0 76.0 95.0 87.0
62.0 60.0 79.0 77.0 96.0 87.5Bihar Factories Rules, 1950

63.0 61.0 80.0 78.0 97.0 88.0
64.0 62.0 81.0 79.0 98.0 88.5
65.0 63.0 82.0 80.0 99.0 89.0
66.0 64.0 83.0 80.5 100.0 89.5
67.0 65.0 84.0 81.0 101.0 90.0
68.0 66.0 85.0 82.0 102.0 90.0
69.0 67.0 86.0 82.5 103.0 90.5
70.0 68.0 87.0 83.0 104.0 90.5
71.0 68.0 88.0 83.5 105.0 91.0
72.0 70.0 89.0 84.0 106.0 91.0
73.0 71.0 90.0 84.5 107.0 91.5
74.0 72.0 91.0 85.0 108.0 91.5
75.0 73.0 92.0 85.5 109.0 92.0
76.0 74.0 93.0 86.0 110.0 92.0
Provided, however, the clause (b) shall not apply when the difference between the wet bulb
temperature as indicated by the hygrometer in the department concerned and the wet bulb
temperature taken with a hygrometer outside in this shade is less than 3.5 degrees.
18. General Ventilation.
(1)In every room in a factory in which workers are ordinarily employed and which is not ventilated
by mechanical means, there shall be sufficient openings in the walls or roof for the admission or
egress of air to maintain the atmosphere in the room in a fresh and reasonably cool condition.(2)If
in any part of a factory the Inspector, having due regard to the weather conditions than prevailing,
considers the atmosphere to be unduly vitiated or stagnant and that this is due to insufficient
openings, he shall by written order require the manager to-(a)increase the openings in the walls or
in the roof to an aggregate area equal to 75 per cent of the area found by the applicable formula in
Appendix I or to such less extent as he deems reasonable in the circumstances, or(b)provide
mechanical means to produce a continuous charge of air at the rate of three complete charges in the
hour or at such rate as he deems sufficient in the circumstances.
19. Measures required for cooling.
- If in any room of a factory the cooling properties of the air appear to the Chief Inspector to be at
times insufficient to secure workers against injury to health or serious discomfort he may by written
order require the manager to carry out any or all the following measures before a specified
date:-(a)Electric or other fans to be used to produce adequate movement of air over the workers.
The Chief Inspector may require such movement to be such that the rate of cooling by evaporation
at a height of five feet from the floor level, as found by the use of a kata thermometer, is two and a
half times what it would be if the air were not moved by such fans;(b)The height of the room from
floor to roof or ceiling to be increased to a height of 16 feet or such less height as the Chief InspectorBihar Factories Rules, 1950

deems reasonable in the circumstances :Provided that where any process generating heat is carried
on in a building, the Chief Inspector may, by an order in writing, require the height of the roof to be
raised to eighteen feet.(c)A layer of tiles, wood or other substance which is bad conductor of heat to
be added to the roof or substituted for other materials or a ceiling or a double roof to be
provided.(d)Sun shades of specified size to be placed before or fitted to such openings as admit
direct sunlight upon the workers.
20. Ventilation and temperature in new factories or rooms.
- In any factory or part of a factory which has been built or brought into use after the enforcement of
these Rules, no worker shall be allowed to work unless-(a)if no mechanical means for general
ventilation and for reduction of temperature is employed, and(i)the width of the room exceeds 18
meters (59 ft.) or its floor area exceeds 560 sq. meters (6, 128 sq. feet), the aggregate area of
ventilating openings as approved or directed by the Chief Inspector;(ii)the width of the room does
not exceed 18 meters or its floor area does not exceed 560 sq. meters, the aggregate area of
ventilating openings is not less than the area found from the applicable formula in Appendix
I:Provided that the Chief Inspector in consideration of the special circumstances of a factory, may
permit smaller ventilating openings to be provided;Provided further that for computing the
aggregate area of ventilating openings no account shall be taken of doors (except doors without
shutters), ventilators or sky-lights.(b)If ventilating openings in any room or building are not
adequate mechanical ventilation is provided and fans or other means employed for this purpose are
of such capacity as to circulate through the room or the building six times in every hour a volume of
air equal to the cubic capacity of the room or building, and(c)The internal height of the roof or the
ceiling of any room or shed at the lowest point is not less than 14 feet from the floor level;Provided
that the Chief Inspector may allow a lower height of any roof, if-(i)the roof includes sufficient layer
of earthen ware, tiles, woods compressed asbestos or any other substance which is a bad conductor
of heat; or(ii)it is a double roof with an air space not less than six inches in depth open to the
atmosphere at the seves and in case of slopping roofs with sufficient means of egress of hot foul air
at the adex; or(iii)a ceiling with sufficient air-space has been provided under the roof; or(iv)the
room is air conditioned or other efficient arrangements have been made to keep the temperature of
the room within reasonable limits; or(v)the room has re-inforced concrete or other kind of terraced
roof; 7 or(vi)on account of the climatic or other conditions or the size of the factory the Chief
inspector considers that a height of 14 feet is not necessary or practicable:Provided further that the
Chief Inspector may require the internal height to be increased up to 20 feet, if any process
generating heat is carried on within the room or shed.
21. Provision of Hygrometer.
- In all departments of cotton spinning and weaving mills wherein artificial humidification is
adopted, hygrometers shall be provided and maintained in such position as are approved by the
Inspector. The number of hygrometers shall be regulated according to the following
scale(a)Weaving Department. - One hygrometer for departments with less than 500 looms and one
additional hygrometer for every 500 or part of 500 looms in excess of 500.(b)Other Department. -
One hygrometer for each room of less than 3.00.000 cubic feet capacity and one extra hygrometerBihar Factories Rules, 1950

for each 2.00.000 cubic feet or part thereof, in excess of this.(c)One additional hygrometer shall be
provided and maintained outside each cotton spinning and weaving factory wherein artificial
humidification is adopted, and in a position approved by the Inspector, for taking hygrometer shade
readings.
22. Exemption from maintenance of hygrometers.
- When the Inspector is satisfied that the limits of humidity allowed by the Schedule to Rule 17 are
never exceeded, he may, for any department other than the weaving department, grant exemption
from the maintenance of the hygrometer. The inspector shall record such exemption in writing.
23. Copy of Schedule to Rule 17 to be affixed near every hygrometer.
- A legible copy of the Schedule to Rule 17 shall be affixed near each hygrometer.
24. Temperature to be recorded at each hygrometer.
- At each hygrometer maintained in accordance with Rule 21, correct wet and dry bulb temperature
shall be recorded thrice daily during each working day. The temperature shall be taken between 7 A.
M. and 9 A. M. between 11 A. M. and and 2 P. M. (but not in the rest interval) and between 4 P. M.
and 5.30 P. M. In exceptional circumstances, such additional readings and between such hours, as
the Inspector may specify, shall be taken. The temperature shall be entered in a Humidity Register
in the prescribed Form No. 6 maintained in the factory at the end of the each month, the persons
who have taken the readings shall sign the register and certify the correctness of the entries. The
Register shall always be available for inspection by the Inspector.
25. Specifications of hygrometer.
(1)Each hygrometer shall comprise two mercurial thermometers of wet bulb and dry bulb of similar
construction and equal in dimensions, scale and divisions of scale. They shall be mounted on a
frame with a suitable reservoir containing water.(2)The wet bulb shall be closely covered with a
single layer of muslin kept wet by means of a wick attached to it and dropping into the water in the
reservoir. The muslin covering and the wick shall be suitable for the purpose, clean and free from
size of grease.(3)No part of the wet bulb shall be within 3 inches from the dry bulbs or less than 1
inch from the surface of the water in the reservoir and the water reservoir shall be below it, on the
side of it away from the dry bulb.(4)The bulb shall be spherical and of suitable dimensions and shall
be freely exposed on all sides to the air of the room.(5)The bores of the stems shall be such that the
position of the top of the mercury column shall be readily distinguishable at a distance of 2
feet.(6)Each thermometer shall be graduated so that accurate readings may be taken between 50
and 120 degrees.(7)Every degree from 50 degrees up to 120 degrees shall be clearly marked by
horizontal lines on the stem, each fifth and tenth degree shall be marked by longer marks than the
intermediate degrees and the temperature marked opposite each tenth degree, i.e., 50, 60, 70, 80,
90, 100, 110 and 120.(8)The markings as above shall be accurate that is to say, at no temperatureBihar Factories Rules, 1950

between 50 and 120 degrees shall be indicated readings, be in error by more than two-tenths of a
degree.(9)A distinctive number shall be indelibly marked upon the thermometer.(10)The accuracy
of each thermometer shall be certified by the National Physical Laboratory, New Delhi, or any other
Laboratory, Institution or Competent authority approved by the Chief Inspector in writing and such
certificate shall always be kept attached to the Humidity Register.
26. Thermometer to be maintained in efficient order.
- Each thermometer shall be maintained at all times during the period of employment in efficient
working order, so as to give accurate indications and in particular:-(a)the wick and muslin covering
of the wet bulb shall be renewed once a week;(b)the reservoir shall be filled with water which shall
be completely renewed once a day. The Chief Inspector may direct the use of distilled water or pure
rain water in any particular mill or mills in certain localities;(c)no water shall be applied directly to
the wick or covering during the period of employment.
27. An inaccurate thermometer not to be used without fresh certificate.
- If an Inspector gives notice in writing that a thermometer is not accurate it shall not, after one
month from the date of such notice, be deemed to be accurate unless and until it has been
re-examined as prescribed and a fresh certificate obtained which certificate shall be kept attached to
the Humidity Register.
28. Hygrometer not to be affixed to wall, etc., unless protected by wood.
(1)No hygrometer shall be affixed to a wall, pillar or other surface unless protected therefrom by
wood or other non-conducting material at least half an inch in thickness and distant at least one
inch from the bulb of each thermometer.(2)No hygrometer shall be affixed at a height of more than
5 feet 6 inches from the floor to the top of thermometer stem or in the direct draughts from a fan
window, or ventilating opening.
29. No reading to be taken within 15 minutes of renewal of water.
- No reading shall be taken for record on any hygrometer within 15 minutes of the renewal of water
in the reservoir.
30. How to introduce steam for humidification.
- In any room in which steam pipes are used for the introduction of steam for the purpose of
artificial humidification of the air, the following provisions shall apply :-(a)The diameter of such
pipes shall not exceed two inches and in the case of pipes installed after 1st day of January, 1951 the
diameter shall not exceed one inch.(b)Such pipe shall be as short as is reasonably practicable.(c)All
hangers supporting such pipes shall be separated from the bare pipes by an efficient insulator not
less than half an inch in thickness.(d)No uncovered jet from such pipe shall project more than 4 ½Bihar Factories Rules, 1950

inches beyond the outer surface of any cover.(e)The steam pressure shall be as low as practicable
and shall not exceed 70 Lbs. per square inch.(f)The pipe employed for the introduction of steam into
the air in a department shall be effectively covered with such non- conducting material, as may be
approved by the Inspector in order to minimise the amount of heat radiated by them into the
department.
31. General lighting in factories.
- Without any prejudice to the provisions of Rules 32 to 35, adequate and suitable lighting, whether
natural or artificial, shall be provided and maintained in every part of a factory including yards and
open spaces where any person may be employed or may have to pass through :Provided that if in the
opinion of an Inspector, lighting of a better standard or of a better or different quality is required in
a factory or in any part of a factory he may direct the manager or the occupier, by an order in writing
to take such measures as he may consider necessary, and the direction so given shall be carried out
within the time specified in the order, if any.
32. Lighting of interior parts.
(1)The general illumination over those interior parts of a factory whore persons are regularly
employed shall be not less than 3 feet candle measured in the horizontal plane at a level of 3 feet
above the floor:Provided that in any such parts in which the mounting height of the light source for
general illumination necessarily exceeds 25 feet measured from the floor or where the structure of
the room or the position or construction of the fixed machinery or plant prevents the uniform
attainment of this standard, the general illumination at the said level shall be not less than 1. foot
candle and where work is actually being done the illumination shall not be less than 3 feet
candles.(2)The illumination over all other interior parts of the factory over which persons employed
pass shall, when and where a person is passing, be not less than 0-5 foot candles at floor level.(3)The
standard specified in this Rule shall be without prejudice to the provisions of any additional
illumination required to render the lighting sufficient and suitable for the nature of the work.
33. Prevention of glare.
(1)Where any source of artificial light in the factory is less than 16 feet above floor level, no part of
the light source or of the light fitting having a brightness greater than 10 candles per square inch
shall be visible to persons whilst normally employed within 100 feet of the source, except where the
angle of elevation from the eye to the source or part of the fitting as the case may be exceed
20°.(2)Any local light, that is to say, an artificial light designed to illuminate particularly the area or
part of the area of work of a single objective or small group of operatives working near each other
shall be provided with a suitable shade of opaque material to prevent glare or with other effective
means by which the light source is completely screened from the eyes of every person employed at a
normal working place, or shall be so placed that no such person is exposed to glare therefrom.Bihar Factories Rules, 1950

34. Power of Chief Inspector to exempt.
- Where the Chief Inspector is satisfied in respect of any particular factory or part thereof or in
respect of any description of workroom or process that any requirement of Rules 31 to 33 is
inappropriate or is not reasonably practicable, he may by order in writing exempt the factory or part
thereof, or description of workroom or process from such requirement to such extent and subject to
such conditions as he may specify.
35. Exemption from Rule 32.
- Nothing in Rule 32 shall apply to the parts of factories respectively specified in part I of the
Schedule annexed hereto.(2)Nothing in sub-rule (1) of Rule 32 shall apply to the factories or parts of
factories respectively specified in Part II of the said Schedule.
Schedule 3
Part I
Parts of factories in which light sensitive photographic materials are made or used in an exposed
condition.
Part II – Cement work.
Works for the crushing and grinding of lime stone.Gas works.Coke oven works.Electrical
stations.Flour Mills.Meetings and breweries.Parts of factories in which the following process are
carried on :-Concrete or artificial stone making.Conversion of iron into steel.Smelting of iron
ore.Iron or steel rolling.Hot rolling or forging, tempering or annealing of metals.Glass blowing and
other working in molten glass.Tar distilling.Petroleum refining and blending.
36. Quantity of drinking water.
(1)The quantity of drinking water to be provided for the workers in every factory shall be at least as
many gallons a day as there are workers employed in the factory and such drinking water shall be
readily available at all times during working hours.(2)Where the Chief Inspector is satisfied in
respect of any particular factory that the existing arrangement of drinking water provides
substantially the same facilities, he may exempt the factory from such requirement to such extent
and subject to such conditions as he may specify.
37. Source of supply.
- The water provided for drinking shall be supplied:-(a)from a public water supply system,
or(b)from any other source approved in writing by the Health Officer.Bihar Factories Rules, 1950

38. Means of supply.
- If drinking water is not supplied direct from taps either connected with public water supply system
of the factory approved by the Health Officer, it shall be kept in suitable vessels, receptacles or tanks
fitted with taps and having dust proof covers placed on raised stand or platform in shade and having
suitable arrangements of drainage to carry away the split water, such vessels, receptacles and tanks
shall be kept clean and measures shall be taken to ensure that the water is free from contamination.
39. Cleanliness of well or reservoir.
(1)Drinking water shall not be supplied from any open well or reservoir unless it is so constructed,
situated, protected and maintained as to be free from the possibility of pollution by chemical, or
bacterial and extraneous impurities.(2)Where Drinking water is supplied from such well or reservoir
the water in it shall be sterilised once a week or more frequently if the Inspector by written order so
require, and the date on which sterilising is carried out shall be recorded:Provided that this
requirement shall not apply to any such well or reservoir of the water therein is filtered and treated
to the satisfaction of the Health Officer before it is supplied for consumption.
40. Report from Health Officer.
- The Inspector may by order in writing direct the manager to obtain at such time or at such
intervals as he may direct, a report from the Health Officer as to the fitness for human consumption
of the water supplied to the workers, and in every case to submit to the Inspector a copy of such
report as soon as it is received from the Health Officer.
41. Cooling of water.
- In every factory wherein more than two hundred and fifty workers are ordinarily employed-(a)the
drinking water supplied to the workers shall from the 1st April to the 30th Septemebr, in every year,
be cooled by ice or other effective method:Provided that if ice is placed in the drinking water, the ice
shall be clean and wholesome and shall be obtained only from a source approved in writing by the
Health Officer.(b)The cooled drinking water shall be supplied in every canteen, lunch room and rest
room and also at conveniently accessible points throughout the factory which for the purpose of
these Rules shall be called "Water Centre."(c)The water centres shall be sheltered from the weather
and adequately drained.(d)The number of water centres to be provided shall be one "Centre" for
every 150 persons employed at any one time in the factory :Provided that in the case of the factory
where the number of persons employed exceed 500 it shall be sufficient if there is one such "Centre"
as aforesaid for every 150 persons up to the first 500 and one for every 500 persons
thereafter.(e)Every "Water Centre" shall be maintained in a clean and orderly condition.(f)Every
water centre shall be in charge of a suitable person who shall distribute the water. Such person shall
be provided with clean clothes while on duty.Clause (f) shall not apply to any factory in which
suitable mechanically operated drinking water refrigerating units are installed to the satisfaction of
the Chief Inspector.Bihar Factories Rules, 1950

42. Latrine accommodation.
- Latrine accommodation shall be provided in every factory, on the followng scale :-(1)where the
maximum number of workers working at any onetime does not exceed one hundred there shall be at
least one latrine for every twenty-five of such workers;(2)where the maximum number of workers
working at any one time exceeds one hundred, there shall be one latrine for every twenty- five
workers for the first hundred workers and one for every fifty thereafter.(3)where women workers are
employed, separate latrine shall be provided for men and women and the number of latrines
required to be provided for each shall be calculated separately on the basis of their respective
numbers in the manner specified in clauses (1) and (2):Provided that in calculating the number of
latrines required under the Rule, any number of workers less than twenty-five or fifty as the case
may be, shall be reckoned as twenty-five or fifty.
43. Requirements to which latrines should conform.
- (1) Service (bucket or pan type) latrines. - All latrines provided in factories after these amendments
come into force, shall be of the sanitary (water closet or flushing) type conforming to the
specifications prescribed in this Rule :Provided that in a factory employing less than 250 workers
and is not situated in a Municipal area, the Chief Inspector may, in writing, permit the service
(bucket or pan) type of latrines, with such conditions as he may specify.(2)Sanitary (water closet or
flushing type) latrines :-(i)All sanitary (water closet or flushing type) latrines shall be connected to a
municipal or common water borne sewerage system or to a septic tank or shall be aqua privy latrines
:(ii)Closet. - Water closets in the latrines, shall be of glazed porcelain, be of the "Wash down type"
unless otherwise specified by the Inspector of Factories;(iii)Water connection. - Each water closet
shall possess a flushing rim and a suitable connection for one and half inches down pipe from the
cistern and shall be fitted with a trap which shall consist either of glazed stoneware or cast
iron;(iv)Flushing cistern. - Each water closet shall be provided with a flushing cistern of a capacity
not less than three gallons and shall also be provided with a metal-pull chain and suitable handle or
a metal ring;(v)Reserved tanks for cistern. - Unless there is twenty-four hours piped water supply a
reserve tank of proper construction and adequate capacity for supply of water to the flushing cistern
shall be provided. The capacity of this tank shall be such as to provide adequate water supply to the
cistern of all the latrines throughout the working hours of the factory.(vi)Septic tanks. - Latrines,
other than those connected with an efficient water borne sewerage system, shall be connected with
and efficient adequate septic tank along with other necessary accessories, including arrangements
for ventilation.The septic tanks shall be cleaned at intervals of not more than one year.(3)Where
service (bucket) type of latrines are provided there shall be arrangements for cleaning the buckets at
least twice in every shift.(4)All drains emanating for the latrines shall be cleaned at least once in
everyday and shall always be kept in a clean and sanitary conditions.(5)Properly constructed and
lighted approach roads or path ways shall be provided to each latrine or block of latrines and such
roads or path ways shall be regularly cleaned and maintained.Bihar Factories Rules, 1950

44. Accommodation in and privacy of latrines and urinals.
- Every latrine and urinal shall have adequate space in order to enable a person to sit comfortably
and be of adequate height and under cover and so partitioned of as to secure privacy and shall have
proper door and fastening.
45. Signboards to be displayed.
- Where workers of both sexes are employed, there shall be displayed outside each latrine and urinal
or block of latrines and urinals, a notice or a signboard, permanently fixed, in the language
understood by the majority of the workers, "for men only" or"for women only" as the case may be.
The notice or signboard shall also bear the figure of a man or of a woman, as the case may be.
46. Urinal accommodation.
(1)Where the maximum number of workers working at any one time does not exceed five hundred
there shall be at least one urinal for every fifty such workers.(2)Where the maximum number of
workers working at any one time exceeds five hundred, there shall be one urinal for every fifty
workers for the first five hundred and one for every hundred thereafter.(3)Where women workers
are employed, separate urinals shall be provided for men and women workers and the number of
urinals required to be provided shall be calculated separately on the basis of their respective
numbers in the manner specified in sub-rules (1) and (2):Provided that in calculating the number of
urinals required under the Rule any odd number of workers less than fifty or hundred as the case
may be shall be reckoned as fifty or hundred :Provided further that two feet length of urinal
accommodation shall be deemed to be equivalent to one urinal.
47. Requirements to which urinals should conform.
(1)Ordinary urinals.-In factories wherein the number of workers generally employed does not
exceed two hundred and fifty, ordinary common type of urinals connected to a sewer or drain may
be provided.(2)Sanitary (flushing type) urinals-(a)In factories wherein the number of workers
generally employed exceeds two hundred and fifty constant flushing type of urinals or any other
sanitary type approved by the Chief Inspector shall be provided.(b)Construction. - Sanitary (flushing
type) urinals shall have white glazed stoneware through and build stoneware squatting seat. The
face shall be lined with white glazed tiles to a height of four feet.(c)Flushing. - Unless it is of constant
flushing type the urinals shall be flushed from a tank, the capacity of which shall not be less than 3
gallons per urinal or seat, by a 1½ inch connection and down the faces by means of a galvanised iron
perforated pipe.(d)Sewer connection. - Unless connected to a municipal or common sewerage
system, the urinals shall be connected to septic tanks provided for sanitary latrines or provided
separately for the urinals.(3)Urinals and drains connected thereto shall be maintained in a clean and
sanitary condition in the same manner as prescribed for latrines.Bihar Factories Rules, 1950

48. Certain latrines and urinals to be connected to sewerage system.
(1)When any general system of underground sewerage with an assured water supply for any
particular locality is provided in a municipality, all latrines and urinals of factory situated in such
locality shall, if the factory is situated within 100 feet of an existing sewer, be connected with that
sewerage system.(2)No worker shall make use of any other place within the factory as latrine or
urinal, other than the latrine and the urinal accommodation provided under these Rules.(3)The
design and the site or situation of latrines and urinals accommodation shall be subject to the
approval of the Director of Public Health and the construction shall be subject to the approval of the
Chief Inspector.(4)They shall be situated, unless otherwise approved in writing by the Inspector,
within the factory precincts and so located that (a) every worker may have ready access thereto and
(b) no effluvia therefrom can rise within a work-room.
49. White-washing, colour-washing of latrines and urinals.
- The walls, ceilings and partitions of every latrine and urinal shall be white-washed or
colour-washed and the white-washing or colour-washing shall be repeated at least once in every
period of four months. The dates on which the white-washing or colour-washing is carried out shall
be entered in the register in Form no. 7. The dates on which white-washing or colour-washing is
carried out shall also be conspicuously written on the objects white-washed or colour-washed
:Provided that this Rule shall not apply to latrines and urinals, the walls, ceilings or partitions of
which are laid in glazed tiles or otherwise finished to provide a smooth, polished, impervious surface
and they are washed with suitable detergents and disinfectants at least once in every period of four
months.
50. Construction and maintenance of drains.
- All drains carrying waste or sullage water shall be constructed in masonry or other impermeable
material and shall be regularly flushed and the effluent disposed of by connecting such drains with a
suitable drainage line:Provided that, where there is no such drainage line, the effluent shall be
deodorized and rendered innocuous and then disposed of in a suitable manner to the satisfaction of
the Health Officer.
51. Water taps in latrines.
(1)Where piped water supply is available a sufficient number of water taps conveniently accessible
shall be provided in or near such latrine accommodation.(2)If piped water supply is not available,
sufficient quantity of water shall be kept stored in suitable receptacles near the latrines.
52. Number and location of spittoons.
- The number and location of the spittoons to be provided shall be to the satisfaction of the
Inspector.Bihar Factories Rules, 1950

53. Type of spittoons.
- The spittoons shall be of any of the following types:-(a)a galvanized iron container with a conical
funnel-shaped cover. A layer of suitable disinfectant liquid shall always be maintained in the
container;(b)a container filled with dry, clean sand, and covered with a layer of bleaching
powder;(c)any other type approved by the Chief Inspector.
54. Cleaning of spittoons.
- The spittoons mentioned in clause (a) of Rule 53 shall be emptied, cleaned and disinfected at least
once every day; and the spittoon mentioned in clause (b) of Rule 53 shall be cleaned by scrapping
out the top layer of sand as often as necessary or at least once every day.
Chapter IV
Safety
55. Further safety precautions.
- Without prejudice to the provisions of sub-section (1) of Section 21 in regard to the fencing of
machine, the further precautions specified in the schedules annexed hereto shall apply to the
machines noted in each schedule.[Schedule I] [Substituted by S.O. 686 dated 13.7.1988.]Textile
Machinery Except Machinery used in Jute Mills(1)Application. - The requirements of this schedule
shall apply to machinery in factories engaged in the manufacture or processing of textiles other than
Jute textiles. The schedule would not apply to machinery in factories engaged exclusively in the
manufacture of synthetic fibres.(2)Definitions. - For the purposes of this schedule-(a)"Calender"
means a set of heavy rollers mounted on vertical side frames and arranged to pass cloth between
them. Calenders may have two or more rollers, or bowls, some of which may be
heated.(b)"Embossing calender" means a calender with two or more rollers, one of which is
engraved for producing figure effects of various kinds on a fabric.(c)"Card" means a machinery
consisting of cylinders of various sizes and in certain cases flats covered with card clothing and set in
relation to each other so that fibres in staple from may be separated into individual relationship. The
speed of the cylinders and their direction of relation may vary. The finished product is delivered as a
silver. Cards include the revolving flat card, the roller and clearer card, etc.(d)"Card clothing" means
the material with which the surface of the cylinder, deffer, flats etc. of a card are covered and
consists of a thick foundation material made of, either textile fabrics, through which are pressed
many fine closely spaced specially bent wires, or mounted saw toothed wire.(e)"Comber" means a
machine for combing fibres of cotton, wool etc. The essential parts are a device for feeding forward a
fringe of fibres at regular intervals and an arrangement of combs or pins which at the right time,
pass through the fringe. All tangled fibres, short fibres and nips are removed and the long fibres are
laid parallel.(f)"Combing machinery" includes a general classification of machinery including
combers, silver lap machines, ribbon lap machines, and gill boxes but excluding cards.(g)"Rotary
staple cutter" means a machine consisting of one or more rotary blades used for the purpose of
cutting textile fibres into staple lengths.(h)"Garnet machine" means any of a number of types ofBihar Factories Rules, 1950

machines for opening hard twisted waste of wool, cotton, silk etc.Note. - Essentially, such machines
consists of a licker is one or more cylinders, each having a complement worker and stripper rolls;
and a fancy roll and offer. The action of such machine is some what like that a wool card, but it is
much more severe in that the various rolls are covered with garnet wire instead of card
clothing.(i)"Gill box" means a machine used in the worsted system of manufacturing yarns.Note. -
Its function is to arrange fibres in parallel order. Essentially, it consists of a pair of feed rolls and a
series of followers where the followers move at faster surface speed and perform a combing
action.(j)"In running roll" means any pair of rolls or drums between which there is a
"Nip".(k)"Interlocking arrangement" means a device that prevents the setting in motion of
dangerous part of any machine or the machine itself while the guard, cover door or other measures
provided to safeguard against danger is open or unlocked or not in position.Note. - Which will also
hold the guard, cover or door closed and locked while the machine or the dangerous part is in
motion, otherwise, dangerous part of any machine or the machine itself will stop or will not be set in
motion.(l)"Kier" means a large metal vat, usually a pressure type in which fabrics may be boiled out,
bleached, etc.(m)"Ribbon lapper" means a machine or a part of a machine used to prepare laps for
feeding a cotton comb.Note. - Its purpose is to provide a uniform lap in which fibres have been
straightened as much as possible.(n)"Silver lapper" means a machine or part of a machine in which
a number of parallel card silvers are drafted slightly, laid side by side in a compact sheet, and wound
into a cylindrical package.(o)"Loom"means a machine for effecting the interlocking of two series of
yarns crossing one another at right angles.The warp yarns are wound on a warp beam and pass
through headless and reeds. The filling is shot across in a shuttle and settled in place by reeds and
slay and the fabric is wound on a cloth beam.(p)"Starch mangle" means a mangle that is used
specifically for starching cotton goods.Note. - It commonly consists of two large rolls and a shallow
open vat with several immersion rolls. The vat contains the starch solution.(q)"Water mangle"
means a calender having two or more rolls used for squeezing water from fabrics before drying.
Water mangles may also be used in other ways during the finishing of various fabrics.(r)"Mule"
means a type of spinning frame having a head stock and carriage at its two main sections. The head
stock is stationary. The carriage is moveable and it carries the spindles which draft and spin the
roving into yarn. The carriage extends over the whole width of the machine and moves slowly
towards and away from the head stock during the spinning operation.(s)"Nip" is the danger zone
between the roils or drums which by virtue of their positioning and movement create a nipping
hazard.(t)"Openers and pickers" means a general classification of machinery which includes breaker
pickers, intermediate pickers, finisher pickers, single process pickers, multiple process pickers,
willow machines, card and picker, waste cleaners, thread extractors, shredding machines, roving
waste openers, shoddy pickers, bale breakers feeders, vertical openers, latice cleaner, horizontal
cleaners and any similar machinery equipped with either cylinders, screen section, calender section,
rolls, or beaters used for the preparation of stock for further processing.(u)"Paddler" means a trough
for solution and two or more squeeze rolls between which cloth passes after being passed through a
mordant or dye bath.(v)"Plaiting Machine" means a machine used to pay cloth into folds of regular
length for convenience of subsequent process or use.(w)"Roller Printing Machine" means a machine
used for printing fabrics consisting of a large central cylinder, of pressure bowl, around the lower
part of the perimeter of which is having a color through a furnisher roller, doctor blades,
etc.(x)"Continuous bleaching ranges" means a machine for bleaching of cloth in rope or open width
with the following arrangement. The cloth, after wetting out, pass through a squeeze roll into aBihar Factories Rules, 1950

saturator containing a solution of caustic soda and then to an enclosed J-box. A V-shaped
arrangement is attached to the front part of the J-box for uniform and rapid saturation of the cloth
with steam before it is packed down in the J-box. The cloth, in a single strand rope from, passes over
a guide roll down the first arm of the "V" and up the second. Steam is injected into the "V" at the
upper end of the second arm so that the cloth is rapidly saturated with the steam at this point. The
J-box capacity is such that cloth will remain hot for a sufficient time to complete the scouring
action.It then passes a series of washers with a squeeze roll in between. The cloth then passes
through a second set of saturator J-box, and washer, where it is treated with the peroxide solution.
By slight modification of the form of the unit, the same process can be applied to open width
cloth.(y)"Mercerizing range" means a 3-bowl mangle, a tenter frame, and a number of boxes for
washing and scouring. The whole set up is in a straight line and all parts operate continuously. The
combination is used to saturate the cloth with sodium hydroxide, stretch it while saturated, and
washing out most of the caustic before releasing tension.(z)"Sanforizing machine" means a machine
consisting of a large steam-heated cylinder and endless, thick woollen felt blanket which is in cloth
contact with the cylinder for most of its perimeter, and an electrically heated show which processes
the cloth against the blanket while the latter is in a stretched condition as it curves around feed in
roll.(aa)"Shearing machine" means a machine used for shearing cloth. Cutting action is provided by
a number of steal blades spirally mounted on a roller. The roller relates in close contact with a fixed
ledger blade. There may be from one to six such rollers, on a machine.(ab)"Singing machine" means
a machine which comprises heated roller, plate, or an open gas flame. The cloth or yarn is rapidly
passed over the roller or the plate or through the open gas flame to remove fuzz or hairness on yarn
or cloth by burning.(ac)"Slasher" means a machine used for applying a size mixture to warp yarn.
Essentially, it consists of a stand for holding section beams, a size box, one or more cylindrical
dryers or an enclosed hot air dryer, and a beaming and for winding the yarn on the loom
beams.(ad)"Tenter frame" means a machine for drying cloth under tension.Note. - It essentially
consists of a pair of endless travelling chains fitted with clips of the fine pins and carried on tracks.
The cloth is firmly held at the selvages by the two chains which diverge, as they move forward so
that the cloth is brought to the desired width.(ae)"Warper" means a machine for preparing and
arranging the yarns intended for the warp of a fabric, specifically a beam warper.(3)General Safety
Requirements. - (a) Every textile machine shall be provided with individual mechanical or electrical
means for starting and stopping all such machines. Belt shifter on machines driven by belts and
shafting should be provided with a belt shifter lock or an equivalent suitable positive locking
device.(b)Stopping and stating handles or other controls shall be of such design and so positioned as
to prevent the operator's hand or fingers from striking against any moving part or any other part of
the machine.(c)All belts, pulleys, gears, chains, sproket wheels, and other dangerous moving parts of
machinery which either form part of the machinery or are used in association with it shall be
securely fenced by safe guards of substantial construction which shall be constantly maintained and
kept in position while the parts of the machinery they are fencing are in motion.(4)Openers and
pickers. - (a) In all openers or pickers machinery, beaters and other dangerous parts shall be
securely fenced by suitable guards so as to prevent contact with them. Such guards and doors or
covers of openings giving access to any dangerous part of the machinery shall be provided with
interlocking arrangement:Provided that in the case of doors of opening giving access to any
dangerous part, other than beater covers, instead of the interlocking arrangement, such openings
may be so fenced by guards which prevent access to any such dangerous part and which is eitherBihar Factories Rules, 1950

kept positively locked in position or fixed in such a manner that it cannot be removed without the
use of hand tools.(b)The feed rolls on all openers and pickers machinery shall be covered with a
guard designed to prevent the operator from reaching the nip while the machinery is in
operation.(c)The lap forming rollers shall be fitted with a guard or cover which shall prevent access
to the nip at the intake of the lap roller and fluted roller as long as the weighted rack is down. The
guard or cover shall be so locked that it cannot be raised until the machine is stopped, and the
machine cannot be started until the cover or guard is closed :Provided that the foregoing provision
shall not apply to the machines equipped with automatic lap forming devices :Provided further that
any such machine equipped with an automatic lap forming device shall not be used unless the
automatic lap forming device is in efficient working order.(5)Cotton Cards. - (a) All cylinder doors
shall be secured by an interlocking arrangement which shall prevent the door being opened until the
cylinder has ceased to revolve and shall render it impossible to restart the machine until the door
has been closed :Provided that the later requirement in respect of automatic locking device shall not
apply while stripping or grinding operations are carried out:Provided further that stripping or
grinding operation shall be carried out only by specially trained adult workers wearing tight fitting
clothing whose names have been recorded in the register prescribed in this behalf as required in
sub-section (i) of Section 22 of Factories Act, 1948.(b)The licker-in shall be guarded so as to prevent
access to the dangerous parts.(c)Every card shall be equipped with an arrangement that would
enable the card cylinder to be driven by power during stripping or grinding operations without
having to either shift the main belt to the fast pulley of the machine or to dismantle the interlocking
mechanism. Such an arrangement shall be used only for stripping or grinding operations.(6)Garnett
Machine. - (a) Garnett Maker-in shall be enclosed.(b)Garnett fancy rools shall be enclosed by
guards. These shall be installed in way that keeps workers rolls reasonably accessible for removal or
adjustment.(c)The underside of the garnett shall be guarded by a screen mesh or other form of
enclosure to prevent access.(7)Gill Boxes. - (a) The feed shall be guarded so as to prevent fingers
being caught in the pins of the intersecting fallers.(b)All nips of in-running rolls shall be guarded by
suitable nip guards conforming to the following specifications.Note. - Any opening which the guard
may permit when fitted in position shall be so restricted with respect to the distance of the opening
from any nip point that the fingers of any person shall not reach that point through that opening and
in any circumstances, the maximum width of the opening shall not exceed the following :
Distance of opening from nip point  Maximum width of opening
0 to 38 mm. -6 mm.
39 to 63 mm. -10 mm.
64 to 88 mm. -13 mm.
89 to 140 mm. -15 mm.
141 to 165 mm. -19 mm.
166 to 190 mm. -22 mm.
191 to 215 mm. -32 mm.
(8)Silver and Ribbon Lappers. - The calender drums and the lap school shall be provided with a
guard to prevent access to the nip between the in-running rolls.(9)Speed Frames. - Jack box wheels
at the head stock shall be guarded and the guard shall have interlocking arrangement.(10)Spinning
Mules. - Wheels on spinning rule carriages shall be provided with substantial wheel guardsBihar Factories Rules, 1950

extending to within 6 mm. of the rails.(11)Warpers. - Swivelled double-bar gates shall be installed on
all warpers operating in excess of 410 meters/min. These gates shall have interlocking arrangement,
except for the purpose of inching or jogging :Provided that the top and bottom bars of the gate shall
be at least 1.05 and 0.53 meters high from the floor or working platforms and the gate shall be
located 38 mm. from the vertical tangentment to the beam head.(12)Slashers. - (a) Cylinder dryers. -
(i) All open nips of in-running rolls shall be guarded by nip guards conforming to the requirements
in clause 7 (b).(ii)When slashers are operated by control levers, these levers shall be connected to a
horizontal bar or treadle located not more than 100 cm. above the floor to control the operation
from any point.(iii)Slashers operated by push button control shall have stop and start buttons
located at each end of the machine, and additional buttons located on both sides of the machine at
the size box and the delivery end. If calender rolls are used, additional buttons shall be provided at
both size of the machine at points near the nips, except when slashers are equipped with an enclosed
dryer.(b)Enclosed hot air dryer. - (i) All open nips of the top squeezing rollers shall be guarded by
nip guard conforming to the requirements in clause 7(b).(ii)When slashers are operated by control
levers, these levers shall be connected to a horizontal bar or treadle located not more than 170 cm.
above the floor to control the operation from any point.(iii)Slashers operated by push button control
shall have stop and start buttons located at each end of the machine and additional stop and start
buttons located on both sides of the machines at intervals spaced not more than 1.83 meters on
centres.(13)Looms. - Each Loom shall be equipped with suitable guards designed to minimise the
danger from flying shuttles.(14)Valves of Kiers, Tanks and other Containers. - (a) Each valve
controlling the flow of steam, injurious gases or liquids into a kier or any other tank or container
into which a person is likely to enter in connection with a process, operation, maintenance or for any
other purpose, shall be provided with suitable locking arrangement to enable the said person to lock
the valve securely in the close position and retain the key with him before entering the kier, tank or
container.(b)Wherever boiling tanks, caustic tanks and any other containers from which liquids
which are hot corrosive or toxic may overflow or splash, are so located that the operator cannot see
the contents from the floor or working area emergency shut off valves which can be controlled from
a point not subject to danger of splash shall be provided to prevent danger.(15)Shearing Machine. -
All revolving blades on shearing machines shall be guarded so that the opening between the cloth
surface and the button of the guard will not exceed 10 mm.(16)Continuous Bleaching Range (Cotton
and Rayon). - The nip of all in running rolls on open width bleaching machiners rolls shall be
protected with a guard to prevent the worker from being caught at the nip. The guard shall extend
across the entire length of the nip.(17)Mercerizing Range (Piece Goods). - (a) A stopping device shall
be provided at each end of the machine.(b)A guard shall be provided at each end of the machine
frame at the in-running chain and the clip opener.(c)A nip guard shall be provided for the
in-running rolls of the mangle and washers and the guard shall conform to the requirements in
clause 7 (b).(18)Tenter Frames. - (a) A stopping device shall be provided at each end of the
machine.(b)A guard shall be provided at each end of the machine frame at the in-running chain and
the clip opener.(19)Paddlers. - Suitable nip guards conforming to the requirement in clause 7 (b)
shall be provided to all dangerous in-running rolls.(20)Centrifugal Extractors. - (a) Each extractor
shall be provided with a guard for the basket, and the guard shall have inter-locking
arrangement.(b)Each extractor shall be equipped with a mechanically or electrically operated brake
to quickly stop the basket when the power driving the basket is shut off.(21)Squeezer of wringer
extractor, water mangle, starch mangle, back washer (worsted yarn), crabbing machines andBihar Factories Rules, 1950

decating machines. - All in-running rolls shall be guarded with nip guards conforming to the
requirements in clause 7 (b).(22)Sanforizing and palmer machine. - (a) Nip guards shall be provided
on all accessible in-running rolls and these shall conform to the requirements in clause
7(b).(b)Access from the sides to the nips of in-running rolls should be fenced by suitable side
guards.(c)A safety trip rod, cable or wire centre cord shall be provided across the front and back of
all palmer cylinders extending the length of the face of the cylinder. It shall operate readily whether
pushed or pulled. The safety trip shall not be more than 170 cm. above the level at which the
operator stands and shall be readily accessible.(23)Rope washers. - (a) Splash guards shall be
installed on all rope washers unless the machine is so designed as to prevent the water or liquid
from splashing the operator, the floor or working surface.(b)A safety trip rod, cable or wire centre
cord shall be provided across the front and back of all rope washers extending the length of, the face
of the washer. It shall operate readily whether pushed or pulled. This safety trip shall be not more
than 170 cm. above the level on which the operator stands and shall be readily
accessible.(24)Laundry Washer, Tumbler or Shaker. - (a) Each drying tumbler, each double cylinder
shaker or clothes tumbler, and each washing machine shall be equipped with an interlocking
arrangement which will prevent the power operation of the inside cylinder when the outer door on
the case or shell is open, and which will also prevent the outer door on the case or sheel from being
opened without shutting off the power and the cylinder coming to a stop. This should not prevent
the movement of the inner cylinder by means of a hand operated mechanism or an inching
device.(b)Each closed barrel shall also be equipped with adequate means for holdings open the
doors on or covers of the inner and outer cylinder or shell while it is being loaded or
unloaded.(25)Printing Machine (Roller Type). - All in-running rolls shall be guarded by nip guards
conforming to the requirement in clause 7 (b).(b)The engraved roller gears and the large crown
wheel shall be guarded.(26)Calenders. - The nip at the in-running side of the rolls shall be provided
with a guard extending across the entire length of the nip and arranged to prevent the fingers of the
workers from being pulled in between the rolls or between the guard and the rolls, and so
constructed that the cloth can be fed into the rolls safely.(27)Rotary Staple Cutters. - The cutter shall
be protected by a guard to prevent hands, reaching the cutting zone.(28)Plaiting Machines. - Access
to the trap between the knife and card bar shall be prevented by a suitable guard.(29)Hand Baling
Machine. - An angle iron handle stop guard shall be installed at right angle to the frame of the
machine. The stop guard shall be so designed and so located that it will prevent the handle from
travelling beyond the vertical position should the handle slip from the operators hand when the
pawl has been released from the teeth of the take-up gear.(30)Flat-work Ironer. - Each flat-work or
coller ironer shall be equipped with a safety bar or other guard across the entire front of the feed or
first pressure rolls so arranged that the striking of the bar or guard by the hand of one operator or
other person will stop the machine. The guard shall be such that the operator or other person cannot
reach into the rolls without removing the guard. This may be either vertical guard on all sides or a
complete cover. If a vertical guard is used, the distance from the floor or working platform to the top
of guard shall be not less than 1.83 metres.
II
Cotton GinningLine Shaft. - The line shaft or second motion in cotton ginning factories, when below
floor level, shall be completely enclosed by a continuous wall or unclimbable fencing with only so
many openings as are necessary for access to the shaft for removing cotton seed, cleaning and oiling;Bihar Factories Rules, 1950

and such openings shall be provided with gates or doors which shall be kept closed and locked.
III
Wood-Working Machinery
1. Definitions. - For the purposes of this Schedule-
(a)'Wood-working' machine means a circular saw, band-saw, planning machine, chain mortising
machine or vertical spindle, moulding machine operating on wood or cork or any other article
except metal.(b)'Circular saw' means a circular saw working in a bench (including a rack bench) but
does not include a pendulum or similar saw which is moved towards the wood for the purpose of
cutting operation.(c)'Band saw' means a band saw, the cutting portion of which runs in a vertical
direction but does not include a long saw or band resawing machine.(d)'Planning machine' means a
machine for over hand planning or for thicknessing or for both operations.
2. Stopping and starting device. - An efficient stopping and starting device
shall be provided on every wood-working machine.The control of this device
shall be in such a position as to be readily and conveniently operated by the
person incharge of the machine.
3. Space around machines. - The space surrounding every wood-working
machine in motion shall be kept free from obstructions.
4. Floors. - The floor surrounding every wood-working machine shall be
maintained in good and level condition, and shall not be allowed to become
slippery, and as far as practicable shall be kept free from chips or other loose
materials.
5. Training and supervision. - (1) No person shall be employed at a
woodworking machine unless he has been sufficiently trained to work that
class of machine, or unless he works under the adequate supervision of a
person who has a thorough knowledge of the working of the machine.
(2)A person who is being trained to work on a wood-working machine shall be fully and carefully
instructed as to the dangers of the machine and the precautions to be observed to secure safe
working of the machine.
6. Circular Saws. - Every circular saw shall be fenced as follows :-
(a)Behind and in direct line with the saw there shall be a riving knife, which shall have a smooth
surface, shall be strong, rigid and easily adjustable, and shall also conform to the followingBihar Factories Rules, 1950

conditions:-(i)The edge of the knife nearer the saw shall form an arc of a circle having a radius not
exceeding the radius of the largest saw used on the bench.(ii)The knife shall be maintained as close
as practicable to the saw, having regard to the nature of the work being done at the time, and at the
level of the bench table the distance between the front edge of the knife and the teeth of the saw shall
not exceed half an inch.(iii)For a saw of a diameter of less than 24 inches, the knife shall extend
upwards from the bench table to within one inch of the top of the saw, and for a saw of a diameter of
24 inches or over shall extend upwards from the bench table to a height of at least 9 inches.(b)The
top of the saw shall be covered by a strong and easily adjustable guard, with a flange at the side of
the saw farthest from the fence. The guard shall be kept so adjusted that the said flange shall extend
below the roots of the teeth of the saw. The guard shall extend from the top of the riving knife to a
point as low as practicable at the cutting edge of the saw.(c)The part of the saw below the bench
table shall be protected by two plates of metal or other suitable material one on each side of the saw;
such plates shall not be more than 6 inches apart, and shall extend from the axis of the saw
outwards to a distance of not less than two inches beyond the teeth of the saw. Metal plates, if not
beaded, shall be of a thickness of at least 1/10 inch, or if beaded be of a thickness of at least 1/20
inch.
7. Push sticks. - A push stick or other suitable appliance shall be provided
for use at every circular saw and at every vertical spindle moulding machine
to enable the work to be done without unnecessary risk.
8. Band Saws. - Every band saw shall be guarded as follows :-
(a)Both sides of the bottom pulley shall be completely encased by sheet or expanded metal or other
suitable material.(b)The front of the top pulley shall be covered with sheet or expanded metal or
other suitable material.(c)All portions of the blade shall be enclosed or otherwise securely guarded
except the portion of the blade between the bench table and the top guide.
9. Planning machines. - (1) A planning machine (other than a planning
machine which is mechanically fed) shall not be used for overhand planning
unless it is fitted with a cylindrical cutter block.
(2)Every planning machine used for overhand planning shall be provided with a "bridge" guard
capable of covering the full length and breadth of the cutting slot in the bench, and so constructed as
to be easily adjusted both in a vertical and horizontal direction.(3)The feed roller of every planning
machine used for thicknessing, except the combined machine for overhand planning and
thicknessing, shall be provided with an efficient guard.
10. Vertical spindle moulding machines. - (1) The cutter of every vertical
spindle moulding machine shall be guarded by the most efficient guard
having regard to the nature of the work being performed.Bihar Factories Rules, 1950

(2)The wood being moulded at a vertical spindle moulding machine shall, if practicable, be held in a
jig or holder of such construction as to reduce as far as possible the risk of accident to the worker.
11. Chain mortising Machines. - The chain of every mortising machine shall
be provided with a guard which shall enclose the cutters as far as
practicable.
12. Adjustment and maintenance of guards. - The guards and other
appliances required under this Schedule shall be-
(a)maintained in an efficient state;(b)constantly kept in position while the machinery is in motion;
and(c)so adjusted as to enable the work to be done without unnecessary risk.
13. Exemptions. - Paragraphs 6, 8, 9 and 10 shall not apply to any
woodworking machine in respect of which it can be proved that other
safeguards are provided, maintained and used which render the machine as
safe as it would be if guarded in the manner prescribed in the Schedule.
IV
Rubber Mills
1. Installation of machines. - Mills for breaking down cracking, granting,
mixing, refining and warming rubber or rubber compounds shall be so
installed that the top of the front roll is not less than 46 inches above the
floor or working level. Provided that in existing installations where the top of
the front roll is below this height a strong rigid distance bar guards shall be
fitted across the front of the machine in such position that the operator
cannot reach the nip of the rolls.
2. Safety devices. - (1) Rubber mills shall be equipped with-
(a)hoppers so constructed or guarded that it is impossible for the operators to come into contact in
any manner with the nip of the rolls; and(b)horizontal safety-trip rods or tight wire cables across
both front and rear, which will when pushed or pulled operate instantly to disconnect the power and
apply the brakes, or to reverse the roils.(2)Safety-trip rods or tight wire cables on rubber mills shall
extend across the entire length of the face of the rolls and shall be located not more than sixty-nine
inches above the floor or working level.(3)Safety-trip rods and tight wire cables on all rubber mills
shall be examined and tested daily in the presence of the Manager or other responsible persons and
if any defect is disclosed by such examination and test the mill shall not be used until such defectBihar Factories Rules, 1950

has been remedied.
V
Jute Textiles
1. Fencing of machinery. - The occupier shall provide and maintain in good
order fencing's guards or safety device in respect of each individual machine
as prescribed.
2. Softening machines. - (a) A safety stopping device comprising a breast
plate in front of the feed table to operate the belt striking gear by releasing an
unbalanced weight.
No device departing from the unbalanced weight principle will be deemed to conform to this Rule
unless it has been approved in writing by the Inspector. In the case of machines provided with an
individual electric drive the device shall be arranged to act on a switch inserted in the no-volt release
circuit.(b)The feed table shall not be less than 6' in length, measured from the centre of the first
cloth roller to the centre of the first pair of cast iron rollers. The table shall be provided with side
guards reaching a height of not less than 4' 6" from the floor, and extending at that height, not less
than 3' 6" from the centre of the first pair of rollers; the height of the rest of the side guards shall not
be less than 4' from the floor.(c)The starting and stopping gear shall be arranged to comply with the
following-(i)Provision for stopping the machine at both the feed and delivery ends.(ii)Provision for
starting the machine at the feed end only, design shall be such that an operator at the feed end
cannot start the machine without the co-operation of an operator at the delivery end.(iii)When a
machine is stopped for clearing a jam or attention other-wise the starting gear shall be secured in
the "off" position at least by a lock operated by a removable key in possession of the person
attending the machine.(iv)The lever operating the unbalanced weight shall be securely
fenced.(d)Sheet steel casings completely enclosing the side shafts, i.e. the shafts and gears shall not
be exposed on the underside. The casings shall be locked or secured by a device which will ensure (i)
that they cannot be opened while the machine is in motion and (ii) that it will not be possible to start
the machine unless they are closed.
3. Carding machines. - (a) The underframe shall be guarded in such a manner
that it will not be possible for operatives to obtain access underneath the
machine until the cylinder has ceased to revolve. The lowest cross member
of the frame shall come down to a point not more than 10" from the floor and
all openings above this, large enough to permit of access underneath, shall
be filled in with sheet steel or fitted with bars or rods spaced not more than
6" apart. Any part of this protection may be in the form of a door but all such
doors shall be controlled by a device which will ensure that they cannot be
opened until the cylinder has come to rest and that the machine cannot beBihar Factories Rules, 1950

restarted until the doors are closed :
Provided that in the case of machines installed before the commencement of this Rule rigidly
secured panels filling the underframe will be deemed to comply with it.(b)A guard with panels and
sliding doors of sheet steel or closely spaced bars or rods enclosing the side gears; there shall be no
opening at the underside of this protection for access to the gears. The sliding doors shall be
controlled by a device which will ensure that they cannot be opened until the cylinder has come to
rest, and that the machine cannot be started up until the doors are closed.(c)A sheet steel guard
extending up to the centre line of the cylinder, enclosing the stripper belts and pulleys shall be
provided on all machines installed after the commencement of this Rule.(d)An adequately strong
and rigid set of bars or rods over the doffer roller securely bolted in position. This guard must follow
the radius of the roller; the space between the rods not to exceed 2"; the distance from the doffer
pinpoints to the underside of the rods to be 4"; the space between the Drawing pressing roller and
the first rod not to exceed 2"; and the width of the guard from the first to the last rod to be not less
than 12".(e)A hand or guard rail extending the full width of the Drawing pressing roller, fitted in a
convenient position in front of and higher than the roller.(f)Effective side guards to prevent
operative fingers being caught between the delivery roller and the pressing ball.(g)When a machine
is stopped for clearing a jam or attention otherwise, the starting gear shall be secured in the "off"
position at least by a lock operated by a removable key in possession of the person attending the
machine.
4. Drawing machine. - (a) A sheet steel guard completely closing the space
between the bend rail and the bottom of the retaining roller the opening and
closing of which shall be controlled by the starting gear, and the design shall
be such that the guard cannot be opened while the machine is running. The
guard plate shall swivel more or less about the centre of its height, and the
top edge shall swing inwards towards the gill bars as the guard opens, and
outwards as the guard closes :
Provided that in the case of machines installed before the commencement of this Rule, a fixed guard
will be sufficient if the clearance between the top of the guard and the underside of the retaining
roller does not exceed ⅜ :Provided further, that in the case of machines with individual electric drive
it will be sufficient if the guard is of the swivelling type and inter-linked with the driving mechanism
so that silver cannot be fed into the gills, or the guard opened, before the machine is stopped, and
that the machine cannot be started up unless the guard is closed.(b)Sheet steel or cast iron guards
completely enclosing the end gears, the design to be such that access to the gears is possible only by
removing the guard in its entirety. If doors or movable panels are provided they shall be controlled
by a locking device, operated by the starting gear, which will ensure that the machine cannot be
started unless the guard is completely closed and that no movable part can be opened whilst the
machine is in motion :Provided that in the case of machines installed before the commencement of
this Rule a guard securely held in position by automatic catches to prevent opening by vibration but
without the inter-locking arrangement will be deemed to comply with it.(c)An efficient guard which
will prevent operative's fingers or hands being caught between the delivery roller and the pressingBihar Factories Rules, 1950

ball.(d)Starting and stopping gear so designed that the machine can be stopped by operatives on the
feed and delivery sides; can be started only by an operative on the feed side but with the
co-operation of the operative on the delivery side and cannot be started by an operative on the
delivery side. The device necessitating cooperation shall be engaged before the machine
stops.(e)Shear pins driving the individual carriages shall be fitted to the pinion on the main back
shaft and not to the pinion on the carriage back shaft.
5. Roving machines. - (a) Starting and stopping gear designed to embody the
following -
(i)Provision for stopping the machine on both the feed and delivery sides.(ii)Provision for starting
the machine on the delivery side only.(iii)A device on the delivery side which will automatically lock
the belt striking gear in the "off" position. This device shall be such that the machine will not stop
before the lock is engaged nor start before it is disengaged by a worker on the delivery side.(b)Sheet
steel or cast iron guards, completely enclosing the end gears, the design to be such that access to the
gears is possible only by removing the guard in its entirety. If doors or movable panels are provided
they shall be controlled by a locking device operated by the starting gear, which will ensure that the
machine cannot be started unless the guard is completely closed and that no movable part can be
opened whilst the machine is in motion:Provided that in the case of machines installed before the
commencement of this Rule a guard securely held in position by automatic catches to prevent
opening by vibration, but without the inter-locking arrangement, will be deemed to comply with
it.(c)Shear pins driving individual carriages shall be fitted to the pinion on the main back shaft and
not to the pinion on the carriage back shaft.
6. Spinning frames. - (a) Access between the driving cylinders whilst in
motion shall be prevented by providing a door at the pass end so
inter-connected with the starting gear that neither side of the frame can be
set in motion whilst the door is open and conversely, the door cannot be
opened whilst either or both sides of the frame is/or are running:
Provided that in the case of machines installed before the commencement of this Rule hinged and
well secured doors will deemed to comply with it.(b)Sheet steel or cast iron guards completely
enclosing the end gears, the design to be such that access to the gears is possible only by removing
the guard in its entirety. If doors or movable panels are provided they shall be controlled by a
locking device operated by the starting gear' which will ensure that the machine cannot be started
unless the guard is completely closed and that no movable part can be opened whilst the machine is
in motion:Provided that in the case of machines installed before the commencement of this Rule a
guard securely held in position by automatic catches to prevent opening by vibration, but without
the interlocking arrangement, will be deemed to comply with it.Bihar Factories Rules, 1950

7. Cop Winding machines. - (a) Effective guard covering the driving end
gears. Hinged doors or panels will not be deemed to comply with this Rule
unless securely held in the closed position by automatic catches to prevent
opening by vibration.
(b)Guards covering the spindle driving gears of such design that it will not be possible to remove
them from position whilst the machine is in motion :Provided that in the case of machines installed
before the commencement of this Rule, guards rigidly secured by bolts or screws, will be deemed to
comply with it.
8. Roll Winding machines. - Effective guard for traverse or other gears and
cams; Hinged doors or panels will not be deemed to comply with this Rule
unless securely held in the closed position by automatic catches to prevent
opening by vibration.
9. Beaming and dressing machines. - (a) The flywheel shall be of the disc
type.
(b)Cross and side shafts driving the starch rollers shall be enclosed in protecting tubes.(c)A guard
securely anchored in position and protecting the nip between the top and bottom starch rollers. It
shall have an aperture large enough to pass the yarn through but not the operative's hand. A hinged
guard will not be deemed to be compliance with this Rule.(d)A guard protecting the nip between the
yarn beam pressing roller and the outer top weight roller, i.e., the top weight roller on the side at
which the beam is inserted and removed.(e)The space between any yarn guide roller and its adjacent
steam cylinder must be not less than 3'.
10. Looms. - (a) Sheet steel or cast iron guards protecting the crank and
wiper shaft spur gears shall be provided.
(b)The minimum clearance between the slay and the breast beam shall not be less than 2'.(c)Not
later than six months after the commencement of this Rule yarn beams shall be placed on looms by
mechanical or other means. Lifting into position by hand alone will not be deemed to comply with
this Rule.
11. Cropping machines. - Sheet steel guards protecting the spirals shall be
provided.
12. Calendering machines. - (a) A strong and rigid guard, securely fixed in
position, in front of the nip between the bottom cast iron roller and the paper
roller on top of same. This guard shall be constructed in such a manner that
it will be impossible for fingers of an operative to reach the nip through theBihar Factories Rules, 1950

aperture in the guard.
(b)Safety rollers protecting the nip of the upper-rollers. - These rollers must be made of steel or
wrought iron tube, as light as possible, and not more than 2½" external diameter.The safety roller
shall ride on the under-roller, and be free to lift. It shall be set in such a manner that the peripheral
clearance between it and the upper-roller, and between it and the under-roller when the safety roller
is fully raised, will not permit of an operative's fingers reaching the nip.(c)Sheet steel panels shall be
fitted on the machine gable to prevent access through same to the large spur wheel.(d)Lever weights
shall be lowered into strong and rigid guards.
13. Cloth cutting machines. - A guard preventing access to the knife from the
front, top or side shall be provided. On the underside the knife shall be
protected up to the maximum limit without interfering with the machine
operation.
14. Lapping machines. - (a) Provision for starting the machine at the feed end
only. - The design shall be such that an operator at the feed end cannot start
the machine without the co- operation of an operator at the delivery end and
that he cannot interfere with the device necessitating co-operation.
(b)A "sight panel" fitted to the feed table in such position that operators on either side of the
machine can see through to the other side.(c)The hand wheel on the driving shaft shall be of the disc
type and it shall be located at sufficient distance from the machine gable to permit of fencing being
constructed between it and the lever mechanism operating the folder.(d)The treadle mechanism
shall be such as to allow extraction of the maximum cloth lapped and no worker shall be required to
go up on the machine table to force it down.
15. Sewing machines. - An apron plate shall be fitted in front of the feed
chain and the plate shall be without holes or openings except for slots for the
jockey pulleys.
16. Press pits. - When the press table is levelled with the floor the clearance
between it and the floor shall not be less than 4".
VI
Power PressesBihar Factories Rules, 1950

1. Definition. - For the purpose of this schedule power press means a
machine used in metal or other industries for moulding, pressing, blanking,
raising, drawing and similar processes.
2. Starting and stopping mechanism. - The starting and stopping mechanism
shall be provided with a safety stop so as to prevent over running of the
press or descent of the ram during tool setting, etc.
3. Protection of tool and die. - (a) Each press shall be provided with a fixed
guard with a slip plate on the underside enclosing the front and sides of the
tool.
(b)Each die shall be provided with a fixed guard surrounding its front and sides, and extending to
the back in the form of a tunnel through which the pressed articles falls to the rear of the
press.(c)The design, construction and mutual position of the guards referred to in (a) and (b) shall
be such as to preclude the possibility of the worker's hand or fingers reaching the danger
zone.(d)The machine shall be fed through a small aperture at the bottom of the die guard, but a
wider aperture may be permitted for second or subsequent operations if feeding is done through a
chute.(e)Notwithstanding anything contained in sub-clauses (a) and (b) an automatic or an
inter-locked guard may be used in place of a fixed guard, but where such guards are used they shall
be maintained in an efficient working condition and if any guard develops a defect, the power press
shall not be operated unless the defect of the guard is removed.
55A. General safety of buildings, structures, plants, machinery, etc.
(1)No building, wall, chimney, bridge, tunnel, drain, road gallery, passage, walkway or gage-way,
ladder, stair-case, ramp floor, platform, staging, scaffolding or any other structure of bricks,
masonry, cement, concrete, steel or any other material whether of a permanent or temporary
character shall be constructed, situated, maintained or allowed to remain or be used in a factory and
no machine, plant, equipment including electric lines, wiring, fitting and apparatus [apparatus as
defined in clause (c) of Rule 2 of the Indian Electricity Rules, 1956 made under the Indian Electricity
Act, 1910], shall be constructed, provided, situated, maintained or allowed to be used or operated in
a factory, in such manner as may, or is likely to, cause any accident or any bodily injury.(2)No
process or work shall be carried on in any factory and no person shall be allowed to work on any
process or any machinery, plant or equipment or in any part of a factory or in any other work in
such manner as may, or is likely to cause any accident or any bodily injury.(3)No materials, articles
or equipments shall be kept stacked or stored in such a manner as may or is likely to cause any
accident or any bodily injury.Bihar Factories Rules, 1950

56. Employment of young persons on dangerous machines.
- The following machines shall be deemed to be of such dangerous character that young persons
shall not work at them unless the provisions of Section 23(1) are complied with:-Power presses other
than hydraulic presses;Milling machines used in the metal trades;Guillotine machines;Circular
saws;Plate printing machines.
56A. Lifting machines, chains, ropes and lifting tackles.
- No lifting machine and no chain, rope or lifting tackle, except fibre rope or fibre rope sling shall be
taken into use in any factory for the first time in that factory unless it has been tested and all parts
have been thoroughly examined by a competent person and a certificate of such a test and
examination specifying the safe working load or loads and signed by the person making the test and
the examination, has been obtained and is kept available for inspection :Provided that where lifting
machine, chains, ropes or lifting tackles are already in use of a factory such a certificate shall be
obtained within one month of the date on which this Rule comes into effect.(2)(a)Every crane fitted
with a derricking jib shall-(i)have plainly marked upon it the safe working load at various radii of
the jib and the maximum radius at which the jib may be worked; and(ii)be fitted with an accurate
indicator, clearly visible to the driver, showing the radius of the jib at any time and the safe working
load corresponding to that radius.(b)No jib crane having either a fixed or a derricking jib shall be
used after one year of the coming into effect of this Rule unless it is fitted with an accurate automatic
indicator which-(i)indicates clearly to the driver or person operating the crane when the load being
carried or lifted approaches the safe working load of the crane for the radius of the jib at which the
load is being carried or lifted; and(ii)gives an efficient sound signal when the load being carried or
lifted is in excess of the safe working load of the crane at that radius:Provided that if a table showing
the safe working loads at various radii of the jib is kept attached to the crane the requirements of
clause (b) shall not apply to-(i)any guy derrick, crane, being a crane of which the mast is held
upright solely by means of ropes with the necessary fittings and tightening screws;(ii)any hand
crane used solely for dismantling another crane;(iii)any crane having a maximum safe working load
of one ton or less.(3)A table showing the safe working loads of every kind and size of chain, rope or
lifting tackle in use, and, in the case of a multiple sling, the safe working load at different angles of
the legs shall be posted in the store in which the chains, ropes or lifting tackles are kept and in
prominent positions on the premises and no rope, chain or lifting tackles not shown in the table
shall be used. The foregoing provisions of this paragraph shall not apply in respect of any lifting
tackle if the safe working load thereof, or in the case of a multiple sling, the safe working load at
different angles of the legs, if plainly marked upon it.(4)Every travelling jib-crane on rails shall be
provided with guards to remove any loose materials from the track.(5)(a)The register to be
maintained under sub-clause (iii) of clause (a) of sub-section (1) of Section 29 shall contain the
following particulars, namely :-(i)name of the occupier of the factory;(ii)address of the
factory;(iii)distinguishing number or mark, if any; and chain, description sufficient to identify the
lifting machine, rope, or the lifting tackle;(iv)date on which the lifting machine, chain, rope or lifting
tackle was first taken into use in the factory;(v)date and number of the certificate relating to any test
and examination made under sub-rules (1) and (9) together with the name and address of the
person who issued the certificate;(vi)date of each periodical thorough examination made underBihar Factories Rules, 1950

sub-clause (iii) of clause (a) sub-section (1) of Section 29 and sub-rule (8) and the name of the
person by whom it was carried out;(vii)date of annealing or other heat treatment of the chain and
other lifting tackle made under sub-rule (7) and the name of the person by whom it was carried
out;(viii)particulars of any defects affecting the safe working load found at any such thorough
examination or after annealing and of the steps taken to remedy such defects.The register shall be
kept readily available for inspection.(b)All certificates obtained under sub-rules (1) and (9) and
reports of all examinations conducted under this Rule shall be maintained in a register and shall be
kept readily available for inspection.(6)All rails on which a travelling crane moves and every track
on which the carriage of a transporter or runway moves shall be of proper size and adequate
strength and have an even running surface and every such rail or track shall be properly laid,
adequately supported and properly maintained and provided with effective stops at the end.(7)All
chains and lifting tackles, except a rope sling, shall unless they have been subjected to such other
heat treatment as may be approved by the Chief Inspector of Factories, be effectively annealed
under the direct supervision of a competent person at the following intervals, namely:-(i)all chains,
slings, rings, hooks, shackles and swivels used in connection with molten metal or molten slag or
when they are made of half inch bar or smaller, once at least in every six months;(ii)all other chains,
rings, hooks, shackles and swivels in general use once at least in every 12 months:Provided that
chains and lifting tackles not in frequent use shall, subject to the Chief Inspector's approval, be
annealed only when necessary and particulars of such annealing shall be entered in a register
prescribed under sub-rule (5).(8)Nothing in the foregoing sub-rule (7) shall apply to following
classes of chains and lifting tackles, namely :-(i)chains made of malleable cast iron;(ii)plate link
chains;(iii)chains, rings, hooks, shackles and swivels made of steel or of an non-ferrous
metal;(iv)pitched chains, working on sprocket or sprocketed wheel;(v)rings, hooks, shackles and
swivels permanently attached to pitched chains, pulley blocks or weighing machines;(vi)hooks and
swivels having screw threaded part or ball bearing or in other case hardened parts;(vii)socket
shackles secured to wire ropes by white metal capping;(viii)Bordeaux connections.Such chains and
lifting tackles shall be thoroughly examined by a competent person once at least in every twelve
months, and particulars entered in the register kept in accordance with sub-rule (5).(9)All lifting
machines, chains, ropes and lifting tackles except a fibre rope or fibre rope sling, which have been
lengthened, altered or repaired by welding or otherwise, shall before being again taken into use, be
adequately retested and reexamined by a competent person and a certificate of such test
examination be obtained and particulars entered in the register kept in accordance with sub-rule
(5).(10)No person under eighteen years of age and no person who is not sufficiently competent and
reliable shall be employed as driver of a lifting machine whether driven by mechanical power or
otherwise or to give signals to a driver.(11)Where there are more than one lifting machines, chains,
ropes and lifting tackles in a factory, each one of them should be given a distinguishing mark or
number for the purpose of identification.(12)Where in the opinion of the State Government,
compliance with any of the provisions of this Rule is considered unnecessary or impracticable, the
Chief Inspector may, subject to the approval of the State Government, by order in writing, exempt
any lifting machine or lifting tackle therefrom, subject to such conditions as may be specified in the
said order:Provided that the Chief Inspector may subject to the approval of the State Government,
rescind or modify any such order whenever he considers it necessary without assigning any reason.Bihar Factories Rules, 1950

56B. Passage ways and clearance for over-head travelling cranes.
(1)(a)Passage-way shall be provided along and adjacent to every rail-track of every over-head
travelling crane of such width that there is a clear space of not less than 50 c.m. between any part of
any crane operating on the track and any column, fixture or fixed structure, so that no person
working or walking over the passageway may be struck by any part of the crane.(b)There should be
railings at a height of at least 90 c.m. from the floor of passage-way on both the sides, with at least
two rails and with a toe board at a height of at least 10 c.m. from the floor:Provided that if there is a
wall or sheeting on one side of the walk- way the railings may be provided on only the other
side.(c)Safe access ladders with hand rails shall be provided at convenient places and at suitable
frequent intervals so that the crane driver or any other person going up the crane or crane track may
not have to walk long distances on the passage-way.(d)Where there are more than one cranes
operating in the same way as on the same run-way, the number of access ladders shall be provided
in consideration of the easy and safe accessibility to the different cranes.(2)For the repair of the
track equipments of cranes and for greater convenience and safety in changing track wheels if there
is no sufficient distance between the end of the crane and the wall of the building, special recesses or
platform with safe access ladders shall be built at different places in the building.(3)The vertical
clearance between the floors of crane bridge or trolley foot-walks or platforms on travelling cranes
and over- head trusses, structural parts or any other permanent fixture shall not be less than two
metres.(4)The provision of sub-rule (i) shall apply only to factories constructed after the 1st
January, 1975 and also to cranes installed in existing factories after the said date and sub-rules (ii)
and (iii) shall apply to the factories constructed after the 4th February, 1963 and the cranes installed
in existing factories after said date:Provided that the Chief Inspector may, with the approval of the
State Government, exempt any such factory in respect of any particular over-head travelling crane
from the operation of any provision of the said sub-rules subject to such conditions as he may
specify in writing.(5)In respect of any over-head travelling crane already in operation on the date of
coming into force of this Rule in any factory, the Chief Inspector may, by an order in writing, direct
such measures to be taken within a specified time as he may consider practicable and necessary to
prevent accidents due to the movement of the cranes.(6)These Rules are without any prejudice to,
and in addition to and not in derogation to the provisions of Section 32 of the Factories Act, 1948;
and(7)The Chief Inspector may, with the approval of the State Government, exempt any over-head
travelling crane in any factory from the operation of any of the provisions of this Rule subject to
such conditions as he may specify in writing.
56C. Fragile roofs - Provision of crawling boards, etc.
- "(1) In any factory no person shall be allowed to stand, walk or do any work or go for any purpose
whatsoever, on a roof or ceiling covered with or constructed of sheets, plain, corrugated or
otherwise, made of cement, cement mixed with asbestos or with any other material or any other
similar materials in respect of which there may be danger of the sheet- breaking due to the weight of
a man, and no person shall be allowed to work or go for any purpose whatsoever on a sloping roof,
unless :-(a)suitable and sufficient safety devices like ladders, duck ladders, access boards and
crawling boards securely supported and fixed are provided and used;(b)suitable and sufficient
parapet wall or railing or any other equally effective device to prevent the person from falling fromBihar Factories Rules, 1950

the sloping roof is provided;(c)a notice in bold letters warning that the roof was of fragile material
and was dangerous and that no person should go on the roof unless full protective measures have
been taken is displayed at such a prominent place and in such a manner as to attract immediate
attention; and(d)a permit to work on the roof has been issued to the person by a responsible person
duly authorised for this purpose by the Manager.(2)All preparatory work like cutting, trimming,
piercing, etc., of the sheets or of any other material or articles to be used on a roof shall be carried
out on the ground and carrying out of any such work on the roof shall be totally prohibited and shall
not be allowed."
57. Pressure Plant.
(1)Every plant or machinery used in a factory and operated at a pressure greater than atmospheric
pressure shall be-(a)of good construction, sound material, adequate strength and free from any
patent defect;(b)properly maintained in a safe condition;(c)fitted with-(i)a suitable safety valve or
other effective device to ensure that a maximum permissible working pressure of the vessel shall not
be exceeded;(ii)a suitable pressure gauge easily visible and designed to show at all times the correct
internal pressure in lbs. per square inch, or in kilogram per square centimetre, and marked with a
prominent red mark at the safe working pressure of the vessel;(iii)a suitable stop valve or valves by
which the vessel may be isolated from other vessels or source of supply of pressure; and(iv)a suitable
drain cock or valves at the lowest part of the vessel for the discharge of collected
liquid.(d)thoroughly examined by a competent person :-(i)externally once in every period of six
months;(ii)internally, once in every period of twelve months :Provided that if by reason of design,
construction and use of the vessel a thorough internal examination is not possible, this examination
may be replaced by a hydraulic test which shall be carried out once in every two years in case of
vessels not in continuous processes and once in every four years in case of vessels in continuous
processes; and(iii)Hydraulically tested at intervals of not more than four years :Provided that in
respect of pressure vessels within walls such as, sizing cylinders made of copper or any other
non-ferrous metal periodic hydraulic test may be dispensed with on condition that the requirements
laid down in sub-rule (5) are fulfilled:Provided further that it shall be sufficient for the purposes of
clause (c) of this Rule if the safety valve, pressure gauge and stop valve are mounted on a pipe line
immediately adjacent to the vessel and where there is a range of two or more similar vessels in a
plant served by the same pressure lead, only one set of such mountings need be fitted in case they
cannot be isolated.(2)The requirements of this Rule shall be in addition to and not in derogation of
the requirements of any other Act, Rules or regulations in force.(3)Nothing in this Rule shall apply
to-(a)any vessel which comes within the scope of the Indian Boiler Act, 1923 (V of 1923),(b)metal
bottles or cylinders used for the storage or transport of compressed gases or liquefied or dissolved
gases under pressure covered by the Gas Cylinder Rules, 1940 framed under the Indian Explosives
Act, 1884 (IV of 1884);(c)feed pumps, steam traps, turbine casings, compressor, cylinders, cylinders
of prime-movers, steam separators or dryers, steam strainers, steam de-superheater, oil separators,
air receivers for fire sprinklers installations, air receivers of monotype machines, provided the
maximum working pressure of the air receiver does not exceed 20 lbs. per square inch and capacity,
does not exceed 3 cubic feet, air receivers of electrical circuit breakers, air receivers of electrical
relays, air vessels on pumps, pipe coils, accessories of instruments and appliances, such as cylinders
and piston assemblies used for operating relays and interlocking type of guards, vessels with liquidsBihar Factories Rules, 1950

subject to static head only and hydraulically operating cylinders other than any communicating with
an air loaded accumulator, and(d)Water sealed gas-holder mentioned in Rule 57-A.Note. - For the
purposes of this Rule, the expression-(a) "thin walled vessels,"means vessel incapable of holding
weight of water;(b)"competent person" means a person holding any of qualifications exempting him
from passing Parts A and B of the Associate Membership Examination of the Institution of
Engineers (India) or any other person whom the Chief Inspector considers competent for any
specified purpose by virtue of his experience; and(c)"vessel" means an enclosed vessel of any
capacity and include any other plant or machinery working at a pressure higher than the
atmospheric pressure.(4)(a)In respect of pressure vessels of thin walls such as sizing cylinders made
of copper or any other non-ferrous metal the safe working pressure shall be reduced at the rate of
five percent of the original working pressure for every year and no such cylinder shall be continued
to be used for more than twenty years after it was first taken into use.(b)If no information as to the
date of construction, thickness of walls and safe working pressure is available, the age of the sizing
cylinder shall be determined by the competent person in consultation with the Chief Inspector from
any other particulars available with the manager.(c)Every new and second hand cylinder of thin
walls to which rapairs which may effect its safety, have been carried out, shall be tested before use,
to at least one and a half times its working pressure.(5)Every vessel operated at a pressure greater
than atmospheric pressure, and not so constructed as to withstand with safety the maximum
permissible working pressure at the source of supply, or the maximum pressure which can be.
obtained in the pipe connecting the vessel with any other source of supply shall be fitted with a
suitable reducing valve or other suitable automatic device to prevent the safe working pressure of
the vessel being exceeded.(6)In a plant in which owing to the nature of the process or the action of
the contents of the vessel, a pressure gauge or safety valve or both cannot work reliably, a tested and
reliable working thermometer with a sufficiently large scale, on which shall be clearly marked the
maximum permissible temperature in the vessel, or barometers or rupture dices in addition to the
pressure gauge and safety valve shall be fitted.(7)If during thorough examination any doubt arises as
to the capacity of a vessel to work safely until the next examination, provided for in these Rules, the
competent person shall enter in the prescribed register his observation and remark with reasons and
may authorise the vessel to work further, subject to a lowering of pressure or to more frequent
inspection or subject to both these conditions.(8)No vessel which has undergone alterations or
repairs shall be put to use unless it is thoroughly examined by competent person.(9)A report of the
result of every examination, made shall be completed in Form 8 and signed by the person making
the examination, and shall be kept available for perusal by an Inspector at any time while the vessel
is in service.(10)No vessel which has previously been used shall be taken into use in any factory for
the first time in a factory until it has been examined and reported in accordance with these Rules
and no new vessel shall be taken into use unless there has been obtained from the maker of the
vessel, or from a competent person, a certificate specifying the maximum permissible working
pressure thereof, and stating the nature of the tests to which the vessel and its fittings (if any) have
been subjected and certificate is kept available for perusal by an Inspector and vessel is so marked as
to enable it to be identified with the certificate relating to the same.(11)Where the report of any
examination under these Rules specified conditions for securing the safe working of a vessel, the
vessel shall not be used except in accordance with those conditions.(12)The competent person
making the report of any examination under this Rule shall within seven days of the completion of
the examination send to the Inspector a copy of the report in every case where the maximumBihar Factories Rules, 1950

permissible working pressure is reduced, or where the examination shows that the plant cannot
continue to be used with safety unless certain repairs are carried out immediately or within a
specified time.(13)Where there are more than one pressure plants or vessels in a factory each such
plant or vessel should be given a distinctive number.(14)The Chief Inspector may, by an order in
writing, exempt, subject to such conditions as he may specify, from any of the provisions of this Rule
any pressure vessel or pressure plant if he is satisfied that such provision need not be applied in
consideration of the special nature of its construction or use of any other matter. Such orders may at
any time be revoked by the Chief Inspector without assigning any reason.
57A.
(1)(a)The expression "gas-holder" for the purpose of the Rule, means "water sealed
gas-holder.(b)This Rule shall apply to only such gas-holders as have a storage capacity of not less
than 141-6 cubic meters (5,000 c.ft).(2)Every gas-holder shall be of good and sound construction
and material, and of adequate strength, shall be free from defects patent or otherwise and shall be
properly maintained.(3)Where there are more than one gas-holder in a factory every gas-holder
shall be given a distinguishing number and the numbers shall be marked on the respective
gas-holders in bold letter and in a conspicuous position.(4)Every gas-holder shall be thoroughly
examined externally by a competent person at least once in every period of twelve months.(5)No
gas-holder, any lift of which has been in use for ten years,shall be used unless the internal condition
to the sheeting is thoroughly examined by a competent person, by means of an electronic device or
by a similar accurate device approved by the Chief Inspector and in case of any, gas-holder any lift of
which has already been in use for ten years or more on the date on which this Rule comes into force,
such examination shall be carried out within the period of one year from the said date but, in
exceptional cases such a period may be extended up to two years by the Chief Inspector. This
examination shall be extended up to two years by the Chief Inspector. This examination shall be
repeated once in every four years after the above mentioned first examination:Provided that if the
Chief inspector is satisfied that the devices mentioned in this sub-rule are not available, he may
permit the examination to be carried out by cutting out samples from the crown and the sides of the
gas-holder or other method approved by him:Provided further that if the above inspection raises
any doubt, an internal visual examination shall be made.(6)(a)After every examination conducted in
accordance with sub-rules (1) and (5), the manager or the occupier shall obtain report from the
person carrying out the examination in Form No. 31 and shall take immediate steps to rectify the
defects if any, pointed out in the report and carry out such repairs or take such steps as may be
recommended or suggested in the report.Entries in respect of such steps shall be made in the form
of the report as well as in the register in Form No.30.(b)All reports in Form No. 31 shall be kept and
mentioned in a bound register or in such other manner as may be convenient and shall be produced
before an Inspector whenever acquired to do so.(7)All possible steps shall be taken and device
applied to prevent ingress of any impurity in gas-holders.(8)No gas-holder shall be repaired or
demolished except under the direct supervision of a person who by his training and experience and
by his knowledge of the necessary precautions against risk of explosions and gassing, is competent
to supervise such work.(9)All samples cut under sub-rule (5) shall be kept readily available for
inspection by the Inspector.(10)A permanent bound register in Form No. 30 duly signed by the
occupier or manager shall be maintained and shall be produced before the Inspector wheneverBihar Factories Rules, 1950

required to do so.Explanation. - A competent person for the purposes of this Rule means a person
having a Degree or Diploma in Mechanical or Chemical Engineering with at least three year's
practical experience of operation, maintenance or repairs of such gas-plants, or any other person
with at least ten years experience thereof if he does not possess any such degree.
58. Excessive weights.
(1)No person shall without the aid of any other person or mechanical appliances, be allowed to lift,
carry or move manually or otherwise any material or article which exceeds the weight specified for
each class of persons in the following schedule:-
Schedule 9
 Persons  Maximum weight of material article, tool orappliances
(a)Adult male ...[55 kgs] [Substituted by S.O. 686 dated 13.7.1988.]
(b)Adult female ...30 kgs.
(c)Adolescent Male ...30 kgs.
(d)Adolescent Female ...20 kgs.
(e)Male child ...16 kgs.
(f)Female child ...13 kgs.
(2)No person shall engage, in conjunction with others in lifting, carrying or moving by hand or on
head, any material article, tool or appliance, if the weight thereof exceeds the lowest weight fixed by
the Schedule to sub-rule (1) for any of the persons engaged, multiplied by the number of persons
engaged.(3)A woman, who is pregnant, may be employed in any factory to lift, carry, or move by
hand or on head, any load not exceeding 18.5 kgs, in weight till the end of seven months of
pregnancy but she shall not be employed in any factory to lift, carry or move by hand or on head any
load after the end of seventh month.(4)The State Government or the Chief Inspector subject to the
control of the State Government may by an order in writing relax the maximum weight specified in
the schedule to sub-rule (1) in respect of any factory or class of factory for a period not exceeding
three months at a time and liable to be rescinded or withdrawn at any time without assigning any
reason and subject to such conditions as may be specified in the said order.
59. [Protection of Eyes. [Substituted by S.O. 791 dated 24.4.1976.]
- Effective screens or suitable goggles shall be provided for the protection of persons employed in or
in the vicinity or the processes specified in the schedule annexed hereto being processes which
involve risk of injury to the eyes from particles or fragments thrown in the course of the process and
also by reason of exposure to light.]
Schedule 10Bihar Factories Rules, 1950

1. Breaking, cutting, pressing or curving of bricks, stone, concrete, slag or
similar material by means of hammer chisel, pick, or any other hand tools, or
by means of a portable tool driven by power, and dry grinding of surfaces of
any such material by means of a wheel or disc driven by power.
2. Dry grinding of surface of metal or any articles of metal by applying the
same by band to a wheel disc or band driven by power, or by means of a
portable tool driven by power.
3. Dividing in to separate parts of metal, or any article of metal brick, stone
concrete or similar materials by means of a saw driven by power or by means
of an abrasive cutting wheel or disc driven by power.
4. Tuning of metal or any article of metal.
5. Drilling by means of portable tool.
6. Welding and cutting of metal or any article of metal by means of an
electric, oxy-acetylene or similar process.
7. Hot fettling of steel casting by means of a flux injected burner or air torch
and de-seaming of metal.
8. Fettling of metal casting; involving removal of metal, including runners,
gates and risers and removal of any other material during the course of such
fettling.
9. Chipping of metal or any article of metal, and chipping, knocking out
cutting out or cutting of cold river, bolt, nut lug, pin, collar or similar articles
from any structure of plant or form part of any structure of plant by means of
a hammer, chisel, punch, or similar hand tools, or by means of a portable
tool driven by power.
10. Chipping or scurfing of paint, scale, slag, rust or other corrosion from the
surface of metal or other hard material by means of a hand tool or by a
portable tool driven by power.Bihar Factories Rules, 1950

11. Breaking of scrap metal by means of a hammer or by means of a tool
driven by power.
12. Routing of metal.
13. Work on drop hammer and power hammer and work by any person not
working on such hammer but whose working is carried on in such
circumstance and in such a position that particles or fragments are liable to
be thrown off towards him.
14. Work at furnace where there is risk to eyes from molten metal.
15. Pouring or skimming of molten metal.
16. Working involving risk to the eyes from heat being thrown off.
17. Truing or dressing of abrasive wheel.
18. Handling in open vessel or manipulation of strong acid or dangerous
corrosive liquid or material, and operation, maintenance or dismantling of
plant or any part of plant, being plant or part of plant which contains or has
contained such acid, liquid or material unless the plant or part of plant has
been so prepared by isolation, reduction of pressure, or otherwise, treated,
or designed and constructed as to prevent risk of injury.
19. Any other process wherein there is any risk of injury to eyes from
particles or fragment thrown off during the course of the process.]
59A.
In every factory a register shall be maintained in Form No. 32 in which the name of every worker
(along with such other particulars as are required to be furnished in the said register) shall be
recorded, who may be employed or may be required to perform the work specified in sub-section (1)
of Section 21, and no worker shall be allowed to carry out any such duty unless his name with full
particulars has been recorded in the said register. This register shall be produced forthwith before
an Inspector whenever demanded by him.Bihar Factories Rules, 1950

59B.
(1)No young person shall be allowed to work at or near any machine specified in Sections 21, 28, 29,
30, 31 or on any machine plant, or process specified in the schedules attached to Rule 95, or on any
other plant, machine or process in which there may be any hazard of fire, explosion or of injury to
health unless (a) he has been fully instructed as to the dangers arising therefrom and the
precautions to be observed, and (b) has received sufficient training in work at the machine plant or
process, or is under the direct and adequate supervision of a person who has a thorough knowledge
and experience thereof.(2)Before any young person is allowed to work on any machine, plant or
process specified in sub-rule (2) the Manager or any other responsible person duly authorised by the
Manager, shall give a certificate in Form No. 33 and every such certificate shall be kept and
maintained in the form of a bound book and the said register shall be produced before an Inspector
forthwith whenever demanded by him.(3)This Rule is without any prejudice to and in addition to
and not in derogation to any provision of any other Rule or of the Act.
59C. [ Examination of eye sight of certain workers. [Inserted by S.O. 686
dated 13.7.1988.]
(1)No person shall be employed to operate a crane, locomotive fork-lift truck, pay loaders, dumpers
or other automobiles or to give signals to a Crane or Locomotive operator unless his eye-sight and
colour vision have been examined by a qualified opthalmologist, approved by the Inspector and
declare fit to work whether with or without the use of corrective glasses.(2)The eye-sight and colour
vision of the person employed as referred to in sub-rule (1) shall be examined at least once in every
period of 12 months up to the age of 45 years and once in every six months beyond that age.(3)Any
fee payable for an examination or any cost involved for corrective glasses under sub-rules (1) and (2)
shall be paid by the occupier and shall not be recoverable from the person.(4)The record of
examination and re-examination carried out as required in sub-rules (1) and (2) above shall be
maintained in Form No. 35 appended to this Rule and a copy thereof be sent to the Inspector within
fifteen days from date of examination.]
60. Minimum dimensions of manholes.
- Every chamber, tank, vat, pipe, flue or other confined space, which persons may have to enter and
which may contain dangerous fumes to such an extent as to involve risk of the persons being
overcome thereby, shall, unless there is other effective means of egress, be provided with a manhole
which may be rectangular, oval or circular in shape and which shall-(a)in the case of a rectangular or
oval shape, be not less than 16 inches long and 12 inches wide.(b)in the case of a circular shape, be
not less than 16 inches in diameter.
61. Exemptions.
- The requirements of sub-section (4) of Section 37 shall not apply to the following processes carried
on in any factory(a)The operation of repairing a water-sealed gas-holder by the electric weldingBihar Factories Rules, 1950

process, subject to the following conditions :-(i)The gas-holder shall contain only the following
gases, separately or mixed at a pressure greater than atmospheric pressure, namely, town gas,
cokeoven gas, producer gas, blast furnace gas, or gases, other than air, used in their
manufacture:Provided that this exemption shall not apply to any gasholder containing acetylene or
mixture of gases to which acetylene has been added intentionally;(ii)Welding shall only be done by
the electric welding process and shall be carried out by experienced operative under the constant
supervision of a competent person.(b)The operations of cutting or welding steel or wrought iron gas
mains and services by the application of heat, subject to the following conditions:-(i)The main or
services shall be situated in the open air, and it shall contain only the following gases, separately or
mixed at a pressure greater than atmospheric pressure, namely, gas, coke-oven gas, producer gas,
blast furnace gas or gases other than air, used in their manufacture;(ii)The main or service shall not
contain acetylene or any gas or mixture of gases to which acetylene has been added
intentionally;(iii)The operation shall be carried out by an experienced person or persons and at least
two persons (including those carrying out the operations) experienced in work on gas mains and
over 18 years of age shall be present during the operation;(iv)The site of the operation shall be free
from any inflammable or explosive gas or vapour;(v)Where acetylene gas is used as a source of heat
in connection with an operation, it shall be compressed and contained in a porous substance in a
cylinder; and(vi)Prior to the application of any flame to the gas main or service this shall be pierced
or drilled and the escaping gas ignited.(c)The operation of repairing an oil tank on any ship of the
electric weldings process shall be subject to the following conditions :-(i)The only oil contained in
the tank shall have a flash point of not less than 150°F (close test) and a certificate to this effect shall
be obtained from a competent analyst;(ii)The analyst's certificate shall be kept available for
inspection by an Inspector, or by any person employed or working on the ship;(iii)The welding
operation shall be carried out only on the exterior surface of the tank at a place (a) which is free
from oil or oil leakage in inflammable quantities and (b) which is not less than one foot below the
nearest part of the surface of the oil within the tank; and(iv)Welding shall be done only by the
electric welding and shall be carried out by experienced operatives under the constant supervision of
a competent person.General
62. [ [Inserted by S.O. 686 dated 13.7.1988.]
(1)Processes, equipment, plant, etc. involving serious fire hazard. -(a)All processes involving serious
explosion and flash fire hazard shall be located in segregated buildings where the equipment shall be
so arranged that only a minimum number of employees are exposed to such hazards at any one
time.(b)All industrial processes involving serious fire hazard should be located in building or work
place separated from one another by walls of fire resistant construction.(c)Equipment and plant
involving serious fire or flash fire hazard shall, wherever possible, be so constructed and installed
that in case of fire, they can be easily isolated.(d)Ventilation ducts, pneumatic conveyors and similar
equipment, involving a serious fire risk should be provided with flame arresting or automatic fire
extinguishing appliances.(e)In all work places having serious fire or flash-fire hazards, passages
between machines, installations or piles of material should be at least 90 cm.Fire
Prevention(2)Protection against lighting. - Protection from lighting shall be provided for
:-(a)buildings in which explosive or highly flammable substances are manufactured, used, handled
or stored;(b)storage tanks containing oils, paints or other flammable liquids;(c)grain elevators;Bihar Factories Rules, 1950

and(d)buildings, tall chimneys or stacks where flammable gases, fumes, dust or lint are likely to be
present.(3)Explosives. - All explosives shall be handled, transported, stored and used in accordance
with the provisions in the Indian Explosives Act, 1884.(4)Precautions against ignition. - Wherever
there is danger of fire or explosion from accumulation of flammable or explosive substances in
air-(a)all electrical apparatus shall either be excluded from the area of risk or they shall be of such
construction and so installed and maintained as to prevent the danger or their being a source of
ignition;(b)effective measures shall be adopted for prevention of accumulation of static charges to a
dangerous extent;(c)Workers shall wear shoes without iron or steel nails or any other exposed
materials of such nature.(d)smoking, lighting or carrying of matches, lighters or smoking materials,
ferrous materials which is likely to cause sparks by friction;shall be prohibited;(e)transmission belts
with iron fasteners shall not be used; and(f)all other precautions, as are reasonably practicable shall
be taken to prevent initiation of ignition from all other possible sources such as open flames,
frictional sparks, overheated surfaces of machinery or plants, chemical or physical chemical reaction
and radiant heat.(5)Spontaneous ignition. - Where materials are likely to induce spontaneous
ignition, care shall be taken to avoid formation of air pocket and to ensure adequate
ventilation.(6)Cylinders containing compressed gas. - Cylinders containing compressed gas may
only be stored in open if they are protected against excessive variation of temperature, direct rays of
sun, or continuous dampness. Such cylinders shall never be stored near highly flammable
substances, furnaces or hot processes. The room where such cylinders are stored shall have
adequate ventilation.(7)Storage of flammable liquids. - (a) The quantity of flammable liquids in any
work room shall be the minimum required for the process or processes carried on in such room.
Flammable liquids shall be stored in suitable containers with close fitting covers:Provided that not
more than 20 litres of flammable liquids having a flash point of 21°C or less shall be kept or stored
in any work room.(b)Flammable liquids shall be stored in closed containers and in limited
quantities in well ventilated of fire resistant construction which are isolated from the remainder or
the building by fire walls and self closing arc doors.(c)Large quantities of such liquids shall be stored
in isolated adequately ventilated building or fire resisting construction or in storage tanks,
preferably under-ground and at a distance from any building as required in the petroleum Rules,
1976.(d)Effective steps shall be taken to prevent leakage of such liquids into basements, sumps or
drains and to confine any escaping liquids within safe limits.(8)Accumulation of flammable dust,
gas, fume or vapour in air or flammable waste material on the floors. - (a) Effective steps shall be
taken for removal or prevention of the accumulation in the air of flammable dust, gas, fume or
vapour to an extent which is likely to be dangerous.(b)No waste material of a flammable nature shall
be permitted to accumulate on the floors and shall be removed at least once in a day or shift, any
more often when possible. Such materials shall be placed in suitable metal containers with covers
wherever possible.Emergent Fire Exits(9)Fire exits. - (a) In this Rule-(i)"horizontal exit" means an
arrangement which allows alternative egres from a floor area to another floor at or near the same
level in a adjoining part of the same building with adequate separation; and(ii)"travel distance"
means the distance an occupant has to travel to reach an exit.(b)An exit may be door-way, corridor,
passageway to an internal or extern? stairway or to a verandah. An exit may also include a
horizontal exit leading to adjoining building at the same level.(c)Lifts, escalators and
revolving-doors shall not be considered as exits for the purpose of this sub-Rule.(d)In every room of
a factory exits sufficient to permit safe escape of the occupants in case of fire or other emergency
shall be provided which shall be free of any obstruction.(e)The exits shall be clearly visible andBihar Factories Rules, 1950

suitably illuminated with suitable arrangement, whatever artificial lighting is to be adopted for this
purpose to maintain the required illumination in case of failure of the normal source of electric
supply.(f)The exits shall be marked in a language understood by the majority of the workers.(g)Fire
resisting doors or roller shutters shall be provided at appropriate places along the escape routes to
prevent spread of fire and smoke particularly at the entrance of lifts or stairs where funnel of flue
effect may be created inducing an upward spread of fire.(h)All exits shall provide continuous means
of egress to the exterior of a building or to an exterior open space leading to a street.(i)Exits shall be
so located that the travel distance on the floor shall not exceed 30 meters.(j)In case of those factories
where high hazard materials are stored or used, the travel distance to the exit shall not exceed 22.5
meters and there shall be at least two ways of escape from every room, however, small except toilet
rooms, so located that the points of access thereto are out of or suitably shielded from area of high
hazard.(k)Wherever more than one exit is required for any room space or floor exits shall be placed
as remote from each other as possible and shall be arranged to provide direct access in separate
directions from any point in the area served.(I)The unit of exit width used to measure capacity of
any exit shall be 50 cm. A clear width of 25 cm. shall be counted as an additional half unit. Clear
width of less than 25 cm. shall not be counted for exit width.(m)Occupants per unit width shall be
50 for stairs and 75 for doors.(n)For determining the exits required the occupant load shall be
reckoned on the basis of actual number of occupants within any floor area or 1.0 square meters per
person, whichever is more.(o)There shall not be less than two exits serving every floor area above
and below the ground floor, and at least one of them shall be an internal enclosed stairway.(p)For
every building or structure used for storage only, and every section thereof considered separately,
shall have access to at least one exit so arranged and located as to provide a suitable means of escape
for any person employed therein, and in any such room wherein more than 10 persons may be
normally present at least two separate means of exit shall be available, as remote from each other as
practicable.(q)Every storage area shall have access to at least one means of exit which can be readily
opened.(r)Every exit doorway shall open into an enclosed stairway, a horizontal exit, on a corridor
or passageway providing continuous and protected means of egress.(s)No exit doorway shall be not
less than 100 cm. in width. Doorways shall be not less than 200 cm. in height.(t)Exit doorways shall
open outwards, that is, away from the room but shall not obstruct the travel along any exit. No door
when opened, shall reduce the required width of stairway or landing to less than 90 cm. over head or
sliding doors shall not be installed for this purpose.(u)An exit door shall not open immediately upon
a flight of stairs. A landing equal to at least the width of the doorway shall be provided in the
stairway at each doorway. The level of landing shall be the same as that of the floor which it
serves.(v)The exit doorways shall be openable from the side which they serve without the use of a
key.(w)Exit corridors and passageways shall be of a width not less than the aggregate required width
of exit doorways leading from there in the direction of travel to the exterior.(x)Where stairways
discharge through corridors and passageways the height of the corridors and passageways shall not
be less than 2.4 meters.(y)Internal stairs shall be constructed of non-combustible materials
throughout,(z)Internal stairs shall be constructed as a self contained with at least one side adjacent
to an external wall and shall be completely enclosed.(aa)A staircase shall not be arranged around a
lift shatt unless the latter is totally enclosed by a material having a fire resistance rating not lower
than that of the type of construction of the former.(ab)Hollow combustible construction shall not be
permitted.(ac)The minimum width of an internal stair case shall be 100 cm.(ad)The minimum width
of treads without nosing shall be 25 cm. for an internal staircase. The treads shall be constructedBihar Factories Rules, 1950

and maintained in a manner to prevent slipping.(ae)The maximum height of a riser shall be 19 cm.
and the number of risers shall be limited to 12 per flight.(af)Hand rails shall be provided with a
minimum height of 100 cm. and shall be firmly supported.(ag)The use of spiral staircase shall be
limited to low occupant lead and to a building of height of 9 meters, unless they are connected to
platforms such as balconies and terraces to allow escapes to pause. A spiral staircase shall be not
less than 300 cm. diameter and have adequate head room.(ah)The width of a horizontal exit shall be
same as for the exit doorway.(ai)The horizontal exit shall be equipped with at least one fire door of
self closing type.(aj)The floor area on the opposite or refuge side of a horizontal exit shall be
sufficient to accommodate occupants of the floor area served, allowing not less than 0.3 square
meter per person. The refuge area shall be provided with exits adequate to meet the requirements of
this sub-rule. At least one of the exits shall lead directly to the exterior or street.(ak)Where there is
difference in level between connected areas for horizontal exit, ramps not more than 1 in 8 slope
shall be provided. For this purpose steps shall not be used.(al)doors in horizontal exits shall be
operable at all times.(am)Ramps with a slope of not more than 1 in 10 may be substituted for the
requirements of staircase. For all slopes exceeding 1 in 10 and wherever the use is such as to involve
danger of slipping the ramp shall be surfaced with non-slipping material.(an)In any building not
provided with automatic fire alarm a manual fire alarm system shall be provided if the total capacity
of the building is over 500 persons, or if more than 25 persons are employed above or below the
ground floor, except that no manual fire alarm shall be required in one storey buildings where the
entire area is undivided and all parts thereof are clearly visible to all occupants.Fire
Fighting(10)First-aid fire fighting arrangements. - In every factory there shall be provided and
maintained adequate and suitable fire fighting equipment for fighting fires in the early stages, those
being referred to as first-aid fire fighting equipment in this Rule.(11)The types of first aid fire
fighting equipment to be provided shall be determined by considering the different types of fire risk
which are classified as follows:-(a)"Class A fire". - (a) Fire due to combustible materials such as
wood, textiles, paper, rubbish and the like-(i)"Light hazard". - Occupancies like offices, assembly
halls, canteens, restrooms, ambulance room and the like;(ii)"Ordinary hazard."-Occupancies like
saw mills, carpentary shop, small timber yards, book binding shops engineering workshop and the
like;(iii)"Extra Hazard". - Occupancies like large timber yards godowns storing fibrous materials,
flour mills, cotton mills, jute mills, large wood working factories and like;(b)Class B fire. - Fire in
flammable liquids like oil, petroleum products, solvents, grease, paint, etc.(c)Class C fire. - Fire
arising out of gaseous substances.(d)Class D fire. - Fire from reactive chemicals, active materials and
the like;(e)Class E fire. - Fire involving electrical equipment and delicate machinery and the
like;(12)The number and types of first-aid fire fighting equipment to be provided shall be as per the
following scale :-(a)Class A fire -(i)Light hazard. - One 9 litre water bucket for every 100 square
metres of floor area or part thereof and 9 litre water type (soda), acid or gas pressure or bucket
pump extinguisher shall be provided for each 6 buckets or part thereof with a minimum of the
extinguisher and two buckets per compartment of the building. These equipments shall be as
distributed over the entire area that a person have to travel not more than 25 metres from any point
to reach the nearest equipment.(ii)Ordinary hazard. - One 9 litre water bucket for every 100 square
metres of floor area or part thereof and one 9 litre water type (soda), acid gas pressure or bucket
pump) extinguisher minimum of 2 extinguisher and 4 buckets per compartment of the building. The
equipment shall be so distributed over the entire floor area that a person shall have to travel not
more than 15 metre from any point to reach the nearest equipment.(iii)Extra hazard. - The scale ofBihar Factories Rules, 1950

equipment would be what is prescribed for ordinary hazard and in addition such extra equipment as
in the opinion of the Inspector are necessary, having regard to the special nature of
occupancy:Provided that in special case, the Inspector, after taking into consideration the
circumstances, authorise that the buckets prescribed in this clause may be dispensed with, provided
the number of the extinguishers provided is double than that is prescribed.(b)Class B fire. - There
shall be at least one fire extinguisher either foam type or carbon dioxide or dry powder per 50
square metres of floor area and shall be so distributed that no person is required to travel more than
15 metres from any point to reach the nearest equipment. In addition to the requirement of
extinguishers specified here, requirements as laid down in clause (a) shall also be provided.(c)Class
C fire. - Carbon dioxide or dry chemical powder extinguishers shall be provided near each plant or
group of plants.(d)Class D fire. - Special dry power (chloride based) type of extinguishers, or sand
buckets shall be provided on a scale as laid down for class B fire. The Inspector may require a higher
scale of portable equipment to be provided depending upon the risk involved.(e)Class E fire. -
Carbon dioxide or dry powder type extinguishers shall be provided near each plant or group of
plants depending upon the risk involved.(13)The first-aid fighting equipment shall confirm to the
relevant Indian Standards.(14)As far as possible the first-aid fire fighting equipment shall be similar
in shape and appearance and shall have the same method of operation.(15)All first-aid fire fighting
equipments shall be placed in a conspicuous position and shall be readily and easily accessible for
immediate use. Generally, these equipments shall be placed as near as possible to the exits or stair
landing or normal routes of escape.(16)All water buckets and bucket pump type extinguishers shall
be filled with clean water. All sand buckets shall be filled with clean, dry and fine sand.(17)All other
extinguishers shall be charged appropriately in accordance with the instruction of the
manufacture.(18)Each first-aid fire fighting equipment shall be allotted a serial number by which it
shall be referred to in the records. The following details shall be painted with white paint on the
body of each equipment:-(i)Serial number;(ii)Date of last refilling; and(iii)Date of last
inspection.(19)First-aid fire fighting equipment shall be placed on platform or in Cabinets in such a
way that their bottom is 750 mm. above the floor level. Fire buckets shall be placed on hooks
attached at a suitable stand or wall in such a way that their bottom is 750 mm. above the floor level.
Such equipment if placed out side the building, shall be under sheds or covers.(20)All extinguishers
shall be thoroughly cleaned and re-charged immediately after discharged sufficient refill material
shall be kept readily available for this purpose at all times.(21)All first-aid fire fighting equipment
shall be subject to routine maintenance, inspection, and testing to be carried out by properly trained
persons. Periodicity of the routine maintenance, inspection and test shall confirm to the relevant
Indian Standards. Records in respect of Inspection, maintenance and testing of all first-aid fire
fighting equipment shall be maintained in a bound register and shall be produced for inspection on
demand.(22)Other fire fighting arrangement. - (a) In every factory, adequate provision of water
supply for fire-fighting shall be made and where the amount of water required in litre per minute, as
calculated from the formula A + B + C + D divided by 20 is 550 or more power driven trailer pumps
of adequate capacity to meet the requirement of water as calculated above shall be provided and
maintained.In the above formulaA = The total area in square metres of all floors including galleries
in all buildings of the factory;B = The total area in square metres of all floors and galleries including
open spaces in which combustible materials are handled or stored;C = The total area in square
metres of all floors over 15 metres above ground level; andD = The total area in square metres of all
floors of all building other than those of fire resisting construction:Provided that in areas where theBihar Factories Rules, 1950

fire risk involved does not require use of water, such areas under B, C, or D may, for the purpose of
calculation, be halved :Provided further that where the areas under B, C, or D are protected by
permanent automatic fire-fighting installations approved by any fire association on fire insurance
company such areas may, for the purpose of calculation, be halved:Provided also that where the
factory is situated at not more than 3 kilometers from an establishment of city or town fire service,
the pumping capacity based on the amount of water arrived at by the formula above may be reduced
by 25 per cent, but no account shall be taken of this reduction in calculating water supply required
under clause (a)(b)(i)Each trailer pump shall be provided with equipment as per schedule appended
to this Rule.(ii)In addition to the equipments specified in the said schedule each trailer pump shall
be provided with adequate breathing apparatus.(iii)The Chief Inspector may by an order in writing
direct the occupier and/or Manager of a factory to provide such additional equipments and
breathing apparatus and of such type as he may consider necessary in consideration of the nature
and degree of hazards.(iv)The equipment specified in this sub-rule shall conform to such Indian
Standards specification as may be in existence.(c)Trailer pumps shall be housed in a separate shed
or sheds which shall be sited close to a principal source of water supplies in the vicinity of the main
risks of the factory.(d)In factories where the area is such as cannot be reached by men hauling of
trailer pumps within reasonable time, vehicles with towing attachment shall be provided at the scale
of one for every four trailer pumps with a minimum of one such vehicle kept available at all
times.(e)Water supply shall be provided to give flow of water as required under clause (a) for at least
100 minutes. At least 50 per cent of this water-supply for 4,50,000 litres whichever is less, shall be
in the form of static tanks of adequate capacities (not less than 4,50,000 litres each) distributed
round the factory with due regard to the potential fire risk in the factory (which piped supply is
provided, the size of the main shall not be less than 15 centimeters diameter and it shall be
supplying a minimum of 4,500 litres per minute at a pressure of not less than 7 kilograms per
square centimeter.(f)All trailer pumps including the equipment provided with them and vehicles for
towing them shall be maintained in good condition and subjected to periodical inspection and
testing as required.(23)Personnel in charge of equipment and for fire-fighting, fire drills, etc. - (a)
The first aid and other fire-fighting equipment to be provided as required shall be in charge of a
trained responsible person :Provided that in factories where power driven trailer pumps, fire engine
or similar devices are provided or are required to t?e provided under these Rules, adequate number
of wholetime suitable and adequately trained persons shall be employed throughout the day and
night and on all days whether working day or a holiday, who shall be responsible for the
maintenance, upkeep and operation of these machines and vehicles. In such factories there shall be
a Senior Fire Officer who shall be in overall charge of fire-fighting, arrangement and operations and
who shall be responsible for training the workers in the use of fire extinguishers and other
fire-fighting equipments.(b)Sufficient number of persons shall be trained in the proper handling of
fire fighting equipments and their use against the types of fire for which they are intended, to ensure
that adequate number of persons are available for fire-fighting both by means of first-aid fire
fighting equipment and others. Wherever vehicles with towing attachment are to be provided as
required in clause (d) of sub-rule 22 sufficient number of persons shall be trained in driving where
the need arises. Those vehicles to ensure that trained persons are available for driving them.(c)Fire
fighting drills shall be held at least once in every 3 months, and records in respect of such periodical
drills shall be maintained in a bound register and shall be produced for inspection on
demand.(24)Automatic sprinklers and fire hydrants shall be in addition and not in substitution ofBihar Factories Rules, 1950

the requirement in sub-rules (10) and (22).(25)Access for fire-fighting buildings and plants shall be
so laid out and roads, passageways etc. so maintained as to permit unobstructed access for
firefighting.(26)If the Chief Inspector is satisfied in respect of any factory or any part of the factory
that owing to the exceptional circumstances such as inadequacy of water-supply or infrequency of
the manufacturing process or for any other reason to be recorded in writing all or any of the
requirements of the Rules are impracticable or not necessary for the protection of workers, he may
by order in writing (which he may at his discretion revoke) exempt such factory or part of the factory
from all or any of the provisions of the Rules subject to conditions as he may by such order
prescribe.]
Schedule 11
[See Rules 62 (22) (25) (1)]Equipment to be provided with Trailer Pump.For light trailer pump of a
capacity of 860 litres/minute. -
1. Armoured suction hose of 9 metres length, with wrenches.
1. Metal suction strainer.
1. Basket strainer.
1. Two-way suction collecting-head.
1. Suction adapter.
10. Unlined or rubber lined 70 mm. delivery hose of 25 metres length
complete with quick-release couplings.
1. Dividing breaching-piece.
2. Branch-pipes with 15 mm, nozzles.
1. Diffuser nozzle.
1. Standpipe with blank cap.
1. Hydrant key.
4. Collapsible canvas bucket.Bihar Factories Rules, 1950

1. Fire hook (preventer) with cutting edge.
1. 25 mm. manila rope of 30 metres length.
1. Extension ladder of 9 meters length (where necessary).
1. Heavy axe.
1. Spade.
1. Pick axe.
1. Crowbar.
1. Saw.
1. Hurricane lamp.
1. Electric torch.
1. Pair-rubber gloves.
For large trailer pump of a capacity of 1,800 litres/minute.
1. Armoured suction hose of 9 metres length, with wrenches.
1. Metal strainer.
1. Basket strainer.
1. Three-way suction collecting-head.
1. Suction adapter.
14. Unlined or rubber lined 70 mm. delivery hose of 25 metres length
complete with quick-release couplings.
1. Dividing breaching piece.Bihar Factories Rules, 1950

1. Collective breaching piece.
4. Branch pipes with one 25 mm, two 20 mm. and one diffuser nozzles.
2. Stand pipe with blank caps.
2. Hydrant keys.
6. Collapsible canvas buckets.
1. Ceiling hook (preventor) with cutting edge.
1. 50 mm, manila rope of 10 metre length.
1. Extension ladder of 9 metres length (where necessary).
1. Heavy Z axe.
1. Spade.
1. Pick axe.
1. Crowbar.
1. Saw.
1. Hurricane lamp.
7. Electric torch.
1. Pair rubber gloves.
Note. - If it appears to the Chief Inspector of Factories that in any factory the provision of breathing
apparatus is necessary he may by order in writing require the occupier to provide suitable breathing
apparatus in addition to the equipment for light trailer pump or large trailer pump as the case may
be.
62A.
[x x x x] [Omitted by S.O. 686 dated 13.7.1988.]Bihar Factories Rules, 1950

62B. [ Safety Officers. [Substituted by S.O. 686 dated 13.7.1988.]
(1)Definitions. - In these Rules unless there is anything repugnant in the subject or context "Safety
Officer" means any officer by whatever designation known, possessing the qualifications prescribed
in this Rule and employed by the occupier of a factory to look after the duties of a safety officer
prescribed in this Rule.(2)Qualification. - (a) A person shall not be eligible for appointment as a
Safety Officer unless he-(i)Possesses a recognised degree in any branch of engineering or technology
and has had practical experience of working in a factory in a supervisory capacity for a period of not
less than 2 years; or a recognised degree in physics or chemistry and has a practical experience of
working in a factory in a supervisory capacity for a period of not less than 6 years; or a recognised
diploma in any branch of engineering or technology and has had practical experience of working in a
factory in a supervisory capacity for a period of not less than 4 years.(ii)Possesses degree or diploma
in industrial safety recognised by the State Government in this behalf; or has qualified at a written
and viva-voce examination conducted by the Chief Inspector:Provided that such examinations shall
be conducted only till adequate number of persons possessing degree or diploma in safety
recognised by the State Government are not available.(b)Notwithstanding the provisions in clause
(a) any person who possesses a recognised degree in engineering or technology and has had
experience of not less than 2 years, in a department of the Central or State Government which deals
with the administration of the Factories Act, 1948.Possesses a recognised degree or diploma in
engineering or technology and has had experience of not less than 5 years, full time, on training,
education, consultancy, or research in the field of accident prevention in industry or in any
recognised institution, shall also be eligible for appointment as a Safety Officer:Provided that the
Chief Inspector may, subject to such conditions as it may specify, grant exemption from the
requirements of whole or part of sub-rule (2); if in his opinion a suitable person possessing the
necessary qualifications and experience is not available for appointment:Provided further that in the
case of a person who has been working as a Safety Officer for a period not less than 3 years on the
date of commencement of this Rule, the Chief Inspector may, subject to such conditions as he may
specify in writing relax all or any of the above said qualifications.(3)Conditions of Service. - (a)
Where the number of Safety Officers, to be appointed in a factory exceeds one, one of them shall be
designated as the Chief Safety Officer and shall have a status higher than that of the others. The
Chief Safety Officer shall be in overall charge of the safety functions as envisaged in sub-rule (4), the
other Safety Officers working under his control.(b)The Chief Safety Officer shall be given the status
of Departmental Head and shall work directly under the control of the Chief Executive of the
factory. All other Safety Officers shall be given appropriate status to enable them to discharge their
functions effectively.(c)The scale of pay and the allowance to be granted to the Safety Officers
including the Chief Safety Officer, and the other conditions of their service shall be the same as
those of the other officers of corresponding status in the factory.(d)In the case of dismissal or
discharge, a Safety Officer shall have a right to appeal to the Chief Inspector:Provided that all
disputes against the orders of the Chief Inspector shall be settled by an appeal to the State
Government, whose decision thereon shall be final:Provided further that no punishment of any kind
shall be inflicted unless the Officer has first been informed in writing of the grounds on which it is
proposed to take action and have been offered an adequate opportunity of defending
himself.(4)Duties of Safety Officers. - (a) The duties of a Safety Officer shall be to advice and assist
the Factory Management in the fulfilment of its obligations, statutory or otherwise, concerningBihar Factories Rules, 1950

prevention of personal injuries and maintaining a safe and healthy working environment. These
duties shall include the following, namely:-(i)to advise the concerned departments in planning and
organising measures necessary for the effective control of personal injuries;(ii)to advise on safety
aspect in all job studies, and to carry out detailed job safety studies on selected jobs;(iii)to check and
evaluate the effectiveness of the action taken or proposed to be taken to prevent personal
injuries;(iv)to advise the purchasing and stores departments in ensuring availability of high quality
personal protective equipment;(v)to render advice on matters relating to carrying out of plant safety
inspections;(vi)to carry out plant safety inspections in order to observe the physical conditions of
work and the work practices and procedures followed by workers and to render advice on measures
to be adopted for removing the unsafe physical conditions and preventing unsafe actions by
workers;(vii)to render advice on matters related to reporting and investigations of industrial
accidents and diseases;(viii)to investigate accidents, locate cause and render advice or measures to
be adopted for removing the causes of accidents. Accident shall include all major or minor injury
cases;(ix)to investigate the cases of industrial diseases contracted and dangerous occurrences
reportable under Rule 96;(x)to advise on the maintenance of such records relating to accidents,
dangerous occurrences and industrial diseases as are necessary;(xi)to promote setting up of safety
committees according to the provisions of Rule 62-A.[It may kindly be noted that the provisions of
Rule 62 A under clause XI of Rule 62 B does not exist because Rule 62 A has been deleted vide S.O.
686 dated 13.7.1988 - Ed.](xii)to organise in association with the concerned departments, awards,
campaigns, competitions and other activities which will develop and sustain the interest of the
workers in establishing and maintaining safe conditions of work and procedures; and(xiii)to design
and conduct either independently or in collaboration with the training departments, suitable
training and educational programme related to and required for the prevention of personal
injuries.(5)Employment of Safety Officers. - The minimum number of Safety Officers to be
employed by the occupier of any factory shall be as follows :-(a)For all factories wherein 1,000 or
more workers are ordinarily employed-(i)Where the number of workers ordinarily employed in a
factory is not less than 1,000 and not more than 1,500 - one Safety Officer;(ii)Where the number of
workers ordinarily employed in a factory is more than 1,500, but does not exceed 10,000 - one
additional Safety Officer for every 1,500 workers in excess of 1,500:Provided that in calculating the
number of Safety Officers under this clause any odd number of workers less than 1,500 shall be
reckoned as 1,500;(iii)Where the number of workers ordinarily employed exceeds 10,000 One
Safety Officer for every 2,000 workers above 10,000:Provided that for calculating the number of
additional Safety Officers under this clause any odd number of workers less than 2,000 shall be
reckoned as 2,000: Provided further that, where the number of workers exceeds 10,000 there shall
be one Chief Safety Officer in addition to the Safety Officers required to be employed under this Rule
in the rank of at least of a Chief Engineer.(b)For all factories wherein manufacturing processes or
operations declared to be dangerous under Section 87 of Factories Act, 1948, by Rule 95 of Bihar
Factories Rules, 1950 are carried on :-(i)Where the number of workers ordinarily employed in a
factory is more than 500-one Safety Officer;(ii)Where the workers ordinarily employed in a factory
is more than 1,000, number of Safety Officers to be employed shall be as specified in sub-rule 5
(a).(c)For all Factories wherein apart from normal manufacturing operations construction,
demolition, modification or similar works are carried on and where in more than 500 workers are
ordinarily employed for such work one additional Safety Officer shall be employed. If the number of
workers ordinarily employed in such jobs exceeds 1,000 additional Safety Officers shall be employedBihar Factories Rules, 1950

in accordance with the provision of sub-rule 5 (a).(6)Exemption. - The State Government may by
notification in the Official Gazette exempt any factory or class or description of factories from all or
any of the provisions of these Rules subject to compliance with such alternative arrangements as
may be approved.(7)Facilities to be provided. - An occupier of the factory shall provide equipments,
office staff, library, books, safety journals and periodicals and such other facilities as are necessary
to enable him to discharge his duties effectively.(8)Prohibition of performance of other duties. - No
Safety Officer, shall be required or permitted to do any work which is inconsistent with or
detrimental to the performance of the duties prescribed in sub-rule (4)]
62C. [ Safety Committee. [Inserted by Notification No. 2/F1 103/88 L & E 47
dated 9.2.92.]
- In every factory :-(a Wherein 250 or more workers are ordinarily employed; or(b)Which carries on
any process or operation declared to be dangerous under Section 87 of the Act; or(c)Which carries
on 'hazardous process' as defined under Section 2 (cb) of the Act;There shall be a safety
committee.(2)The representatives of the management of Safety Committee shall include:-(a)A
senior official, who by his position in the organisation can contribute effectively to the functioning of
the committee, shall be the Chairman;(b)A Safety Officer and a Factory Medical Officer, wherever
available and the Safety Officer in such a case shall be the Secretary of the Committee;(c)A
representative each from the production, maintenance and purchase departments.(3)The workers
representatives on this committee shall be elected by the workers.(4)The tenure of the Committee
shall be two years.(5)Safety Committee shall meet as often as necessary but at least once in every
quarter. The minutes of the meeting shall be recorded and produced to the Inspector on
demand.(6)Safety Committee shall have the right to :-(a)ask for necessary information concerning
health and safety of the workers,(b)Seek any relevant information concerning health and safety of
the workers.(7)Function and duties of the Safety Committee shall include :-(a)assisting and
co-operating with the Management in achieving the aims and objectives in the Health and Safety
Policy of the occupier;(b)Dealing with all matters concerning health safety and environment and to
arrive at practicable solutions to problems encountered;(c)creating safety awareness amongst all
workers;(d)undertaking educational, training and promotional activities;(e)deliberating on reports
of safety environmental and occupational health surveys, emergency plans, safety audits, risk
assessment and implementation of the recommendations made in the reports;(f)carrying out health
and safety surveys and to identify causes of accidents;(g)looking into any complaint made on the
likelihood of an imminent danger to the safety and health of the workers and suggest corrective
measures; and(h)reviewing the implementation of the recommendations made by it.(8)Where
owing to the size of the factory, or any other reason, the functions referred to in sub-rule (7) cannot
be effectively carried about by the Safety Committee, it may establish sub- committees as may be
required to assist it.][Chapter IV-A] [Inserted by Notification No. 2/F.-103/88 L & E 47 dated
9.2.92.]
62AH. Site Appraisal Committee.
- Rules prescribed under sub-section (1) of Section 41A - (1) The following provisions shall govern
the functioning of the Site Appraisal Committee, hereinafter referred to as the "Committee" in theseBihar Factories Rules, 1950

Rules:-(a)The State Government may constitute a Site Appraisal Committee and reconstitute the
committee as and when necessary;(b)The State Government may appoint a Senior Official of the
Factories Inspectorate, preferably with qualification in Chemical Engineering to be the Secretary of
the committee;(c)The State Government may appoint the following as members of the
Committee:-(i)A representative of the Fire Service Organisation of the State Government;(ii)A
representative of the State Department of Industries;(iii)A representative of the Director General of
Factory Advice Service and Labour Institutes, Bombay.(2)No member, unless required to do so by a
Court of Law, shall disclose otherwise than in connection with the purposes of the Act, at any time
any information relating to manufacturing of commercial business or any working process which
may come to his knowledge during his tenure as a Member of the Committee.(3)Applications for
appraisal of sites:-(a)Applications for appraisal of sites in respect of the factories covered under
Section 2 (eb) of the Act shall be submitted to the Chairman of the State Appraisal
Committee.(b)The application for site appraisal alongwith 15 copies thereof shall be submitted in
the Form annexed to this Rule. The committee may dispense with furnishing information on any
particular item in the Application Form if it considers the same to be not relevant to the application
under consideration.(4)Functions of the Committee :-(a)The Secretary shall arrange to register the
applications received for appraisal of site in a separate register and acknowledge the same within a
period of 7 days.(b)The Secretary shall fix up meeting in such a manner that all the applications
received and registered are referred to the Committee within a period of one month from the date of
their receipt.(c)The Committee may adopt a procedure for its working keeping in view the need for
expeditious disposal of applications.(d)The Committee shall examine the application for appraisal of
a site with reference to the prohibitions and restrictions of the location of industry and the carrying
on of processes and operations in different areas as per the provisions of Rule 5 of the Environment
(Protection) Rules, 1986 framed under the Environment Protection Act, 1986.(e)The Committee
may call for documents, examine experts, inspect the site if necessary and take other steps for
formulating its view in regard to the suitability of the site.(f)Wherever the proposed site requires a
clearance by the Ministry of Industry or the Ministry of Environment and Forests, the application
for Site Appraisal will be considered by the Site Appraisal Committee only after such clearance has
been received.Format of Application to the Site Appraisal Committee
1. Name and address of the applicant:
2. Site ownership data :
2.1Revenue details of site such as Survey no. Plot no. etc.2.2Whether the site is classified as forest
and if, so, whether approval of the Central Government under Section 5 of the Indian Forests Act,
1927 has been taken.2.3Whether the proposed site attracts the provisions of Section 3 (2) (v) of the
E.P Act, 1986, if so, the nature of the restrictions.2.4Local authority under whose jurisdiction the
site is located.
3. Site plan :
3.1Site plan with clear identification of boundaries and total area proposed to be occupied and
showing the following details nearby the proposed site.(a)Historical Monument, if any, in theBihar Factories Rules, 1950

vicinity.(b)Names of neighbouring manufacturing units and human habitats, educational and
training institutions, petrol installations, storages of LPG and other hazardous substances in the
vicinity and their distances from the proposed unit.(c)Water sources (rivers, streams, canals, dams,
water filtration plants' etc.) in the vicinity.(d)Nearest hospitals, fire-stations, civil defence stations
and police stations and their distances.(e)High tension electrical transmission lines, pipe lines for
water, oil, gas or sewerage, railway lines, roads, stations, jatties and other similar
installations.3.2Details of soil conditions and depth of which hard strata obtained.3.3Contour map
of the area showing nearby hillocks and difference in levels.3.4Plot plant of the factory showing the
entry and exit points, roads within, water drains etc.
4. Project Report :
4.1A summary of the salient features of the Project.4.2Status of the organisation (Government,
semi-Government) Public or Private etc.4.3Maximum number of persons, likely to be working in the
factory.4.4Maximum amount of power and water requirements and source of their supply.4.5Block
diagram of the buildings and installations in the proposed supply.4.6Details of housing colony,
Hospital, School, and other infrastructural facilities proposed.
5. Organisation structure of the proposed manufacturing Unit Factory.
5.1organisation diagrams of- Proposed enterprise in general- Health Safety and Environment
protection departments and their linkage to operation and technical departments.5.2Proposed
Health and Safety policy.5.3Area allocated for treatment of wastes and effluent.5.4Percentage outlay
on safety, health and environment protection measures.
6. Meteorological data relating to the site :
6.1Average, minimum and maximum of- Temperature- Humidity- Wind velocities during the
previous ten years.6.2Seasonal variations of wind direction.6.3Highest water level reached during
the floods in the area recorded so far.6.4Lightning and seismic data of the area.
7. Communication Links :
7.1Availability of telephone/telex/wireless and other Communication facilities for outside
communication.7.2Internal Communication facilities proposed.
8. Manufacturing process Information :
8.1Process flow diagram.8.2Brief write up on process and technology.8.3Critical process parameters
such as pressure build up temperature rise and runaway reactions.8.4Other external effects critical
to the process having safety implications, such as ingress of moisture or water, contact with
incompatible substances, sudden power failure.8.5Highlights of the build in safety/pollution control
devices or measures/incorporated in the manufacturing technology.Bihar Factories Rules, 1950

9. Information of Hazardous materials :
9.1Raw materials, intermediates, products and by-products and their quantities (Enclose Materials
Safety Data Sheet in respect of each hazardous substance).9.2Main and intermediate storages
proposed for raw materials, intermediate/products/by-products (maximum quantities to be stored
at anytime).9.3Transportation methods to be used for materials inflow and outflow their quantities
and likely recourse to be followed.9.4Safety measures proposed for:- Handling of materials- Internal
and external transportation, and- Disposal (packing and forwarding of finished products)
10. Information on Dispersal/Disposal of waters and pollutants.
10.1Major pollutant (gas, liquid, solid, their characteristics and quantities (average and at peak
loads).10.2Quality and quantity of solid wastes generated, method of their treatment and
disposal.10.3Air, water and Soil pollution problems anticipated and the proposed measures to
control the same, including treatment and disposal of effluents.
11. Process Hazards information.
11.1Enclose a copy of the report on environmental impact assessment.11.2Enclose a copy of the
report on Risk Assessment study.11.3Published (open or classified) reports, if any, on accident
situations/ occupational health hazards or similar plants elsewhere within or outside the country).
12. Information of proposed Safety and Occupational Health Measures.
12.1Details of fire fighting facilities and minimum quantity of water, C02 and/or other fire fighting
measures needed to meet the emergencies.12.2Details of in-house medical facilities proposed.
13. Information on Emergency preparedness.
13.1Proposed arrangements, if any, for mutual aid scheme with the group of neighbouring factories.
14. Any other relevant information.
I certify that the information furnished above is correct to the best of my knowledge and nothing of
importance has been concealed while furnishing it.Name and Signature of the Appellant
62BH. Health and Safety policy.
(1)Occupier of every factory, except as provided for in sub-rule (2), shall prepare a written report of
his policy in respect of health and safety of workers at work.(2)All factories-(a)Covered under
Section 2(m) (i) but employing less than 50 workers;(b)Covered under Section 2(m) (ii) but
employing less than 100 workers, are exempted from requirements of sub-rule (1):Provided that
they are not covered in the First Schedule under Section 2 (c) or carrying out processes orBihar Factories Rules, 1950

operations declared to be dangerous under Section 87 of the Act.(3)Notwithstanding anything
contained in sub-rule (2), the Chief Inspector may require, the Occupiers of any of the factories or
class or description of factories to comply with the requirements of sub-rule (1) if, in his opinion, it
is expedient to do so.(4)The Health and Safety policy should contain or deal with:-(a)declared
intention and commitment of the top management to health, safety and environment and
compliance with all the relevant statutory requirements;(b)organisational set up to carry out the
declared policy clearly assigning the responsibility at different levels; and(c)arrangements for
making the policy effective.(5)In particular, the policy should specify the
following:-(a)arrangements for involving the workers;(b)intention of taking into account the health
and safety performance of individuals at different levels while considering their career
advancement;(c)fixing the responsibility of the contractors, sub-contractors, transporters and other
agencies entering the premises;(d)providing a resume of health and safety performance of the
factory in its Annual Report;(e)relevant techniques and methods, such as safety, audit and risk
assessment for periodical assessment of the status on health, safety and environment and taking all
the remedial measures;(f)stating its intention to integrate health and safety in all decisions
including those dealing with purchase of plant, equipment, machinery and material as well as
selection and placement of personnel;(g)arrangement for informing, educating and training and
retraining its own employees at different levels and the public, wherever required.(6)A copy of the
declared Health and Safety Policy signed by the Occupier shall be made available to the Inspector
having jurisdiction over the factory and to the Chief Inspector.(7)The Policy shall be made widely
known by-(a)making copies available to all workers including contract workers, apprentices,
transport workers, suppliers etc;(b)displaying copies of the policy at conspicuous places; and(c)any
other means of communication;in a language understood by majority of workers.(8)The Occupier
shall revise the Safety Policy as often as may be appropriate, but it shall necessarily be revised under
the following circumstances:-(a)Whenever any expansion or modification as approved by the Chief
Inspector of Factories having implications of safety and health of persons at work is made;
or(b)whenever new substance or articles are introduced duly approved by the Chief Inspector of
Factories in the manufacturing process having implications on health and safety of persons exposed
to such substances.
62CH. Collection and development and dissemination of information.
- (i) The occupier of every factory carrying on a hazardous process shall arrange to obtain or develop
information in the form of Material Safety Data Sheet (MSDS) in respect of every hazardous
substance or material handled in the manufacture, transportation and storage in factory. It shall be
accessible upon request to a worker for reference.Material Safety Data Sheet (a) Every such Material
Safety Data Sheet shall include the following information-(i)The identity used on the
label;(ii)Hazardous ingredients of the substance;(iii)Physical and Chemical characteristics of the
Hazardous substance;(iv)The physical hazards of the hazardous, substance;(v)The health hazards of
the hazardous substance, including sign and symptoms of exposure, and any medical conditions
which are generally recognised as being aggravated by exposure to the substance;(vi)The primary
route (sentry;)(vii)The permissible limits of exposure prescribed in the second schedule under
Section 41-F of the Act and in respect of a chemical not covered by the said schedule, any exposure
limit used or recommended by the manufacturer, importer or occupier;(viii)Any generallyBihar Factories Rules, 1950

applicable precautions for safe handling and use of the hazardous substance, which are known,
including appropriate hygienic practices, protective measures during repairs and maintenance of
contaminated equipment procedures for clean-up of spills and leaks;(ix)Any generally applicable
control measures such as appropriate engineering, controls, work practices, or use of personal
protective equipment;(x)Emergency and first aid procedures;(xi)The date of preparation of the
Materials Safety Data Sheet, or the last change to it; and(xii)(a)The name, address and telephone
number of the manufacturer importer, occupier or other responsible party preparing or distributing
the Material Safety Data Sheet, who can provide additional information on the hazardous substance
and appropriate emergency procedures, if necessary.(b)The occupier while obtaining or developing
a Material Safety Data Sheet in respect of a hazardous substance shall ensure that the information
recorded accurately reflects the scientific evidence used in making the hazard determination. If he
becomes newly aware of any significant information regarding the hazards of a substance, or ways to
protect against the hazards, this new information shall be added to the Material Safety Data Sheet as
soon as practicable.(c)An example of such Material Safety Data Sheet is given in the Schedule to this
Rule.Labelling.(a)Every container of a hazardous substance shall be clearly labelled or marked to
identify:-(a)The contents of the container;(b)The name and address of the manufacturer or importer
of the hazardous substance;(c)The physical and health hazards; and(d)The recommended personal
protective equipment needed to work safely with the hazardous substance.(b)In case a container is
required to be transported by road outside the factory premises it should in addition be labelled or
marked in accordance with the requirements laid down under Rule 62-LH.
62DH. Disclosure of information to workers.
(1)The occupier of factory carrying on a 'hazardous process' shall supply to all workers the following
information in relation to handling of hazardous materials or substances in the manufacture,
transportation, storage and other processes:-(a)Requirements of Sections 41B, 41C and 41H of the
Act;(b)A list of 'hazardous processes' carried on in the factory;(c)Location and availability of all
Material Safety Data Sheets as per Rule 62 CH;(d)Physical and health hazards arising from the
exposure to or handling of substances;(e)Measures taken by the occupier to ensure safety and
control of physical and health hazards;(f)Measures to be taken by the workers to ensure safe
handling, storage and transportation of hazardous substances;(g)Personal Protective Equipment
required to be used by workers employed in 'hazardous process' or dangerous
operations;(h)Meaning of various labels and marking used on the containers of hazardous
substances as provided under Rule 62-CH:(i)Signs and symptoms likely to be manifested on
exposure to hazardous substances and to whom to report;(j)Measures to be taken by the workers in
case of any spillage or leakage of a hazardous substances;(k)Rule or workers vis-a-vis the emergency
plan of the factory, in particular the evacuation procedures;(I)Any other information considered
necessary by the occupier to ensure Safety and Health of workers.(2)The information required by
sub-rule (1) shall be compiled and made known to workers individually through supply of booklets
or leaflets and display of cautionary notices at the work places.(3)The booklets, leaflets and the
cautionary notices displayed in the factory shall be in the language understood by the majority of the
workers, and also explained to them.(4)The Chief Inspector may direct the occupier to supply
further information to the workers as deemed necessary.Bihar Factories Rules, 1950

62EH. Disclosure of information to general public.
(1)The occupier of every factory carrying on a 'hazardous process' shall in consultation with the
District Emergency Authority designated by the State Government, take appropriate steps to inform
the general public who are likely to be in the area which might be affected by an accident such
information shall include:(a)Name of the factory and address where situated;(b)Identification by
name and position, of the person giving the information;(c)Confirmation that the factory has
approval from the Factories Inspectorate and Pollution Control Board;(d)An explanation in simple
terms of the hazardous process (s) carried on in the premises;(e)The common names of the
hazardous substances used which could give rise to an accident likely to affect them with an
indication of their principal harmful characteristics;(f)Brief description of the measures to be taken
to minimise the risk of such an accident in compliance with its legal obligations under relevant
Safety Statutes;(g)Salient features of the approved disaster control measures adopted in the
factory;(h)Details of the factory's emergency warning system for the General Public;(i)General
advice on the action, members of the public should take on hearing the warning;(j)Brief description
of arrangements in the factory, including liason with the emergency services, to deal with
foreseeable accidents of such nature and to minimise their effects; and(k)Details of where further
information can be obtained.(2)The occupier shall also supply any further information-(a)To
general public as directed by the Emergency Planning Officer from time to time;(b)To the elected
representatives of the general public on request.(3)The Occupier shall endeavour to enter an
agreement with the Emergency Planning Officer for the area, within whose jurisdiction the factory is
situated, for the Emergency Planning Officer to take appropriate steps to inform the general public
outside the factory who are likely to be affected by an accident as required in sub-rule (1).(4)The
information prescribed in sub-rule (1) shall be in the regional language and in English or Hindi.
62FH. Disclosure of information to the Local Authority.
- The occupier of every factory carrying on a 'hazardous process' shall furnish the following
information in writing to the local authority having jurisdiction over the area in which the factory is
situated:-(a)the information furnished to general public as prescribed in Rule 62 EH;(b)a statement
of the names and quantities generally stored or in process of hazardous substances included in the
list of chemicals prescribed under clauses (vi) and (vii) of sub-Section (2) of Section 3 of the
Environment (Protection) Act, 1986.
62GH. Disclosure of information to District Emergency Authority.
- The occupier of a factory carrying on a hazardous process, shall intimate the District Emergency
Authority designated by the State Government, all information having an bearing on preparation of
an on site emergency plan and a disaster control and management plan in respect of the
factory.Without prejudice to the generality of this clause, the occupier shall furnish to the District
Emergency Authority the following:-(a)a report on status relating to risk assessment and
environmental impact assessment and the measures taken for prevention of
accidents;(b)completion of Material Data Sheets in respect of hazardous substances used, produced
or stored in the factory;(c)a statement on all possible sources of accidents involving fire, explosion,Bihar Factories Rules, 1950

release or leakage of toxic substances and the plan of the premises where such an accident may
occur;(d)a statement on resources and facilities available for dealing with an emergency including
any agreement entered into with a neighbouring factory for aid and assistance in the event of an
emergency;(e)a map of the area showing the approach to the factory, location of emergency facilities
such as hospitals, police, fire service;(f)the organisation of the management and the responsibility
for safety indicating therein the persons responsible for on-site Emergency action;(g)details relating
to alert system;(h)information on availability of antidotes for poisoning resulting from an
accident;(i)any other information as may be considered relevant by the occupier or asked for by the
District Emergency Authority.
62HH. Disclosure of information to the Chief Inspector.
(1)The Occupier of every factory carrying on hazardous process shall furnish, in writing to the Chief
Inspector a copy of all the information furnished to the workers, local authority, general public and
the District Emergency Authority.(2)A copy of compilation of Material Safety Data Sheet in respect
of hazardous substances used, produced or stored in the factory shall be furnished to the Chief
Inspector, and the local inspector.(3)The occupier shall also furnish any other information asked for
by the Chief Inspector from time to time for the purpose of this Act and Rules made thereunder.
62IH. Emergency Plan.
(1)The Occupier of a factory carrying on a hazardous process shall prepare a draft on-side
emergency plan and submit it to the Chief Inspector. The Chief Inspector may make such
modifications in the plan as necessary in consultation with the occupier and approve the
same.(2)The Occupier will submit a copy of the approved plan to the District Emergency
Authority.(3)The occupier will intimate the workers the provisions of the emergency plan and held
rehearsals of the plan periodically. He shall review the plan from time to time and make necessary
changes therein under information to the Chief Inspector and the District Emergency
Authority.(4)The Chief Inspector may issue guidelines relating to formulation of emergency plans.
He may also direct modifications of the emergency plan in respect of any factory as may be
necessary, from time to time.
62JH. Disaster Control and Management Plan.
(1)The occupier of every factory carrying on a hazardous process, shall prepare a draft disaster
control and management plan in respect of his factory and submit the same to the Chief Inspector
and the District Emergency Authority.(2)The District Emergency Authority on receipt of the plan
shall hold consultation with the occupier, representatives of the Chief Inspector, Local Authority as
well as police, health, fire brigade and other authorities concerned and finalise the plan.(3)The
District Emergency Authority shall forward a copy of the final plan to the occupier and all
authorities concerned. The occupier shall intimate the workers the contents of the plan.(4)The
occupier in consultation with the District Emergency Authority will arrange rehearsals of the plan at
least once a year.(5)The Chief Inspector may issue guidelines for formulation of disaster control and
management plans. The Chief Inspector as well as the District Emergency Authority in consultationBihar Factories Rules, 1950

with the Chief Inspector may also direct modifications of the disaster control and management plan
in respect of a factory as may be necessary from time to time.
62KH. Information on industrial wastes.
(1)The information furnished under Rules 62-DH, 62-FH, 62-GH and 62-HH shall include the
quantity of the solid and liquid wastes generated per day, their characteristics and the method of
treatment such as incineration of solid wastes, Chemical and Biological treatment of liquid wastes
and arrangements for their final disposal.(2)It shall also include information on the quality and
quantity of gaseous waste discharged through the stacks or other openings, and arrangements such
as provision of scrubbers, cyclone separators, electrostatic precipitators or similar such
arrangements made for controlling pollution of the environment.(3)The occupier shall also furnish
the information prescribed in the sub-rules (1) and (2) to the State Pollution Control Board.
62LH. In Review of the information furnished to workers, etc.
(1)The occupier shall review once in every calendar year and modify, if necessary, the information
furnished under Rules 62-DH to 62-HH to the workers, general public, Local Authority,Chief
Inspector and the District Emergency Authority.(2)In the event of any change in the process or
operations or methods of work or when any new substance is introduced in the process or in the
event of a serious accident taking place, the information so furnished shall be reviewed and modified
to the extent necessary.
62MH. Confidentiality of information.
- The occupier of a factory carrying on hazardous process shall disclose all information needed for
protecting safety and health of the workers and the general public in the neighbourhood to-(a)his
workers;(b)the Chief Inspector, and(c)District Emergency Authority.As required under Rules 62
DH, 62 GH. If the occupier is of the opinion that the disclosure of details regarding the process and
formation, while adversely affect his business interests, he may make a representation to the Chief
Inspector stating the reasons for withholding such information.The Chief Inspector shall give an
opportunity to the occupier of being heard and pass an order on the representation.An occupier
aggrieved by an order of Chief Inspector, may prefer an appeal before the State Government within a
period of 30 days. The State Government shall give an opportunity to the occupier of being heard
and pass an order. The order of the State Government shall be final.
62NH. Medical Examination.
(1)Workers employed in a 'hazardous process shall be medically examined by a qualified medical
practitioner hereinafter referred to as Factory Medical Officer in the following manner:-(a)Once
before employment, to ascertain physical fitness of the person to do the particular job;(b)Once in a
period of 6 months, to ascertain the health status of all the workers in respect of occupational health
hazards to which they are exposed; and in cases where in the opinion of the Factory Medical OfficerBihar Factories Rules, 1950

it is necessary to do so at a shorter interval in respect of any worker;(c)The details of
pre-employment and periodical medical examination carried out as aforesaid shall be recorded in
the Health Register in Form 24.(2)No person shall be employed for the first time without a
certificate of Fitness in Form 33 granted by the Factory Medical Officer. If the Factory Medical
Officer declares a person that for being employed in any process covered under sub-rule (1), such a
person shall have the right to appeal to the Inspector who shall refer the matter to the Certifying
Surgeon whose opinion shall be final in this regard, if the Inspector himself is also a Certifying
Surgeon, he may dispose of the application himself.(3)Any findings of the Factory Medical Officer
revealing any abnormality or unsuitability of any person employed in the process shall immediately
be reported to the Certifying Surgeon who shall in turn, examine the concerned worker and
communicate his findings to the occupier within 30 days, If the Certifying Surgeon is of the opinion
that the worker so examined is required to be taken away from the process for health protection he
will direct the occupier accordingly, who shall not employ the said worker in the same process.
However, the worker so taken away be provided with alternate placement unless he is fully
incapacitated, in the opinion of the Certifying Surgeon, in which case the worker affected shall be
suitably rehabilitated:Provided that the Certifying Surgeon on his own may examine any worker
when he considers it necessary to do so for ascertaining the suitability of his employment in the
'hazardous' process' or for ascertaining the health status of any worker.(4)The worker taken away
from employment in any process under sub-rule (2) may be employed again in the same process
only after obtaining the fitness certificate from the Certifying Surgeon and after making entry to that
effect in the Health Register.(5)An Inspector may, if he deems it necessary to do so refer worker to
the Certifying Surgeon for Medical examination as required under sub-rule (1) or if he is a Certifying
Surgeon himself conduct such medical examination.The opinion of the Certifying Surgeon in such a
case shall be final. The fee required for this Medical examination shall be paid by the
occupier.(6)The worker required to undergo medical examination under these Rules and for any
medical survey conducted by or on behalf of the Central or the State Government shall not undergo
such medical examination.
62OH. Occupational Health Centres.
(1)In respect of any factory carrying on 'hazardous process' there shall be provided and maintained
in good order an occupational Health Centre with the services and facilities as per scale laid down
hereunder:-(a)For factories employing up to 50 workers:-(i)The services of a factory Medical Officer
on retainership basis, in his clinic to be notified by the occupier. He will carry out pre-employment
and periodical Medical examination as stipulated in Rule 62 NH and render Medical assistance
during any emergency.(ii)A minimum of 5 persons trained in first aid procedures amongst whom at
least one shall always be available during the working period;(iii)A fully equipped first-aid
box.(b)For factories employing 51 to 200 workers:-(i)An occupational Health Centre having a room
with a minimum floor area of 15 sq. m. with floors and walls made of smooth and impervious
surface and with adequate illumination and ventilation as well as equipment as per the schedule
annexed to this Rule.(ii)A part time factory Medical officer shall be in over all charge of the centre
who shall visit the factory at least twice in a week and whose services shall be readily available
during medical emergencies;(iii)One qualified and trained dresser-cum-compounder on duty
throughout the working period.(iv)A fully equipped first-aid box in ail departments.(c)For factoriesBihar Factories Rules, 1950

employing above 200 workers:-(i)One full-time Factory Medical Officer for factories employing up
to 500 workers and one more Medical Officer for every additional 1000 workers or part
thereof.(ii)An occupational Health Centre having at least 2 rooms with a minimum floor area of 15
sq. m. with floors and walls made of smooth and impervious surface and adequate illuminations and
ventilation as well as equipment as per the schedule annexed to this Rule.(iii)There shall be one
nurse, one dresser-cum-compounder and one sweeper cum ward boy throughout the working
period.(iv)The occupational Health Centre shall be suitably equipped to manage medical
emergencies.(2)The Factory Medical Officer required to be appointed under sub-rule (1) shall have
qualification included in Schedules to the Indian Medical Degrees Act of 1916 or in the Schedules to
the Indian Medical Council Act, 1956 and possess certificate of Training in Industrial Health of
minimum three months duration provided that:-(i)A person possessing a Diploma in Industrial
Health or equivalent shall not be required to possess the certificate of training as aforesaid.(ii)The
Chief Inspector may subject to such conditions as he may specify grant exemption from the
requirement of this sub-rule if in his opinion a suitable person possessing the necessary
qualification is not available for appointment.(iii)In case of a person who has been working as a
Factory Medical Officer for a period of not less than three years on the date of commencement of
this Rule, the Chief Inspector may, subject to the condition that the said person shall obtain the
aforesaid certificate of training within a period of three years, relax the qualification.(3)The syllabus
of the course leading to the above certificate, and the organisations conducting the State Course
shall be approved by the D.G. FASLI or the Government in accordance with the guidelines issued by
the [D.G. FASLI] [[Director General, Factory Advice Service and Labour Institutes-Pub.]].Within
one month of the appointment of a Factory Medical Officer, the Occupier of the Factory shall furnish
to the Chief Inspector the following particulars:-(a)Name and address of the Factory Medical
Officer;(b)Qualification;(c)Experience, if any; and(d)The sub-rule under which appointed.
62PH. Ambulance Van.
(1)In any factory carrying on 'Hazardous process' there shall be provided and maintained in good
condition, a suitably constructed ambulance van equipped with items as per sub-rule (2) and
manned by a full time Driver cum-Mechanic and a Helper trained in first-aid for the purposes of
transportation of serious cases of accidents or sickness. The ambulance van shall not be used for any
purpose other than the purpose stipulated herein and will normally be stationed at or near to the
Occupation Health Centre:Provided that a factory employing less than 200 workers, may make
arrangements for procuring such facility at short notice from nearby hospital or other places, to
meet any emergency.(2)The Ambulance should have the following equipments:(a)General:A
wheeled stretcher with folding and adjusting devices with the head of the Stretcher capable of being
tilted upward;Fixed suction unit with equipment;Fixed Oxygen supply with equipment;Pillow with
Case Sheets, Blankets, Towels,Emesis bag. Bed pan, Urinal, Glass.(b)Safety equipments:Flares with
life of 30 minutes-Flood lights.Flash lights-Fire extinguisher dry powder type;Insulated
gauntlets.(c)Emergency care equipment:(i)Resuscitations:Portable Suction Unit; Portable Oxygen
Units;Bag-valve-mask, hand operated artificial ventilation unit;Airways, Mouth gage, Tracheotomy
adopters;Short spine board; I.V. Fluids with administration unit;B.P. manometer, Gngg,
Stethoscope.(ii)Immobilization:Long and short padded boards-Wire ladder splints;Triangular
bandage-Long and short spine boards.(iii)Dressings:Gauze pads-4" x 4:-Universal dressing 10" xBihar Factories Rules, 1950

36"Roll of Aluminium foils, soft roller bandages 6" x 5"Yeards-Adhesive tape in 3" roll-Safety
pins;Bandage Sheets-Burn Sheet.(iv)Poisoning;Syrup of Ipeac-Activated Charcoal pre-packeted in
doses, Snake bite kit;Drinking Water.(v)Emergency Medicines:-As per requirement - (under the
advice of Medical Officer only.)
62QH. Decontamination facilities.
- In every factory carrying out 'hazardous process', the following provisions shall be made to meet
emergency-(a)fully equipped first aid box;(b)readily accessible means of drenching with
water:-(i)workers;(ii)parts of body of workers; and(iii)clothing of workers which have been
contaminated with hazardous and corrosive substance; and with such means shall be as per the
scale shown in the Table below:-Table
 No. of persons employed at any time No. of drenching showers.
(i) Upto 50 workers ... 2
(ii) Between 51 to 200 workers ... 2 + 1 for every additional 50 or part thereafter.
(iii) Between 201 to 500 workers ... 5 + 1 for every additional 100 or part thereafter.
(iv) 501 workers and above ... 8 + 1 for every additional 200 or part thereafter.
(c)a sufficient number of eye wash bottles filled with distilled water or suitable liquid, kept in boxes
or cupboards conveniently situated and clearly indicated by a distinctive sign which be visible at all
times.
62RH. Making available Health Records to workers.
(1)The occupier of every factory carrying out 'hazardous process' shall make accessible the health
records including the record of workers' exposure to hazardous process or as the case may be, the
medical records of any worker for his perusal under the following conditions:-(a)Once in every six
months or immediately after the medical examination whichever is earlier.(b)If the factory Medical
Officer or the Certifying Surgeon as the case may be, is of the opinion that the worker has
manifested signs and symptoms of any notifiable disease as specified in the Third Schedule of the
Act;(c)If the worker leaves the employment;(d)If any of the following authorities so direct;- the
Chief Inspector of Factories;- the Health Authority of the Central or State Government;-
Commissioner of Workmen's Compensation;- The Director General, Employees State Insurance
Corporation;- The Director Employees State Insurance Corporation (Medical Benefits); and- The
Director General, Factory Advice Service and Labour Institutes. (2) A copy of the up-to-date health
records including the record of worker's exposure to hazardous process or, as the case may be, the
medical records shall be supplied to the worker on receipt of an application from him, X-Ray plates
and other medical diagnostic reports may also be made available for reference to his medical
practitioner.Bihar Factories Rules, 1950

62SH. Qualifications, etc., of Supervisors.
(1)All persons who are required to supervise the handling of hazardous substances shall possess the
following qualification and experience:(a)(i)A degree in Chemistry or Diploma in Chemical
Engineering or Technology with 5 years experience; or(ii)A Master's Degree in Chemistry or a
Degree in Chemical Engineering or Technology with 5 years, experience.The experience stipulated
above shall be of process operation and maintenance in the Chemical Industry.(b)The Chief
Inspector may require the Supervisor to undergo training in Health and Safety.(2)The Syllabus and
duration of the above training and the organisations conducting the training shall be approved by
the D.G. FASLI or the State Government in accordance with the guidelines issued by the D.G.
FASLI.
62TH. Issue of guidelines.
- For the purpose of compliance with the requirements of sub-sections (1), (4) and (7) of Section
41-B or 41-C the Chief Inspector may, if deemed necessary, issue guidelines from time to time to the
occupiers of factories carrying on 'hazardous process'. Such guidelines may be based on National
Standard Codes of Practice, or recommendations of International Bodies such as ILO and WHO.
I (Rule 62-CH)
(Material Safety Data Sheet)
Material Safety DataSheetSAMPLE
MODELSection-I-Material
Identification and use
Material
Name/IdentifierManufacturer's
NameSupplier's Name
Street Address Street Address
City Province City Province
Postal CodeEmergency
Telephone No.Postal CodeEmergency
Telephone No.
Chemical Name Chemical Identity
Trade Name and Synonyms Product Use
Section-II-Hazardous Ingredients of
Material
Hazardous IngredientsApproximate
Concentration %C.A.S. or UN
numbersLD 50 (Specify
Species &
Route)LD 50
(Specify
Species
& Route)
SECTION-III-PHYSICAL DATABihar Factories Rules, 1950

FOR MATERIAL
Physical
State........Gas.......Liquid.........Odour-Solid
appearanceOdour
Threshold
(P.P.M)Specific
Gravity.
Vapour Pressure (mm)Vapour density
(Air-I)Evaporation
Rate.Boiling Point
(°C)Freezing
Point
(°C)
Solubility in water (20°C) Hp Density (g/m)Co-efficient of
water oil
Distribution.
SECTION IV-FIRE AND
EXPLOSION HAZARD OF
MATERIAL
Flammability
... ... Yes ... No if yes, under what
conditions.Means ofExtinction.
Special procedures
Flash point (°C)and MethodUpper Explosion
Limit (% by
Volume)Lower Explosion
(Limit (% by
Volume)
Auto-ignition Temperature (°C) TDG FlammabilityHazardous
Combustion
products
Explosion Date-Sensitivity to Chemical ImpactSensitivity to
Static
Discharge
SECTION V-REACTIVITY DATA
Chemical Stability... ... ...Yes ... ...
No.If no, under what
conditions.
Incompatibility to other
substances... ... Yes ... No.Reactivity
and under what conditionsIf no, under what
conditions.
Hazardous Decomposition products
Material Name/Identifier
SECTION VI-TOXICOLOGICAL
PROPERTIES OF MATERIAL
Route of Entry... ... ... Skin Contact
... ......Skin Absorption ... ... ...Eye
Contact.- - - Inhalation Acute - - -
Inhalation Chronic - - -IngestionBihar Factories Rules, 1950

Effects of Acute Exposure to
Material
Effects of Chronic Exposure to
Material
66Irritency of
Material
Sensitization to Material
Synergistic
Materials
SECTION VII-PREVENTIVE
MEASURES
PERSONAL PROTECTIVE
EQUIPMENT
Gloves (Specify)Footwear (Specify)Respiratory
(Specify)Clothing
(Specify)Eyes
(Specify)Other
(Specify)
Engineering Controls (e.g.
ventilation, enclosed process,etc.)
Please Specify.
Leak and spill procedures
Waste Disposal
Handling Procedures and
Equipment
Storage Requirements Information
Special Shipping Information
SECTION VIII-FIRST AID
MEASURES
First Aid Measures
Sources used
Additional Information
SECTION IX-PREPARATION
DEPTT. OF M. D.A.
Prepared by (Group Department,
etc.) Phone. No.State
Note. - 1. CAS or UN Number Chemical Abstract Service or United Nations (UN) Number.
2. L.D. 5. - Lethal Doze-50% (LD 50-Specify species & route)Bihar Factories Rules, 1950

3. LC 50 Lethal Concentration-50% (LC-50 Specify Species & route)
4. TDG Flammability-Transport of Dangerous Goods Flammability
Classification by United Nations.
II
Equipment for Occupational Health Centre in Factories
1. A glazed sink with hot and cold water always available
2. A table with a smooth top at least 180 cm. x 105 cm.
3. Means for sterlizing instruments
4. A couch
5. Two buckets or containers with close fitting lids
6. A kettle and spirit stove or other suitable means of boiling water.
7. One bottle or spiritus ammoniac aromatious (120 ml.)
8. Two medium size sponges
9. Two 'Kidney' trays
10. Paurakes of toilet, preferably antiseptic soap
11. Two clinical thermometers
12. Two glass tumblers and two wing glasses
13. Two tea spoons
14. Two graduated (12 ml.) measuring glassesBihar Factories Rules, 1950

15. One wash bottle (1000 cc) for washing eyes
16. One bottle (one litre) carbolic lotion 1 in 20
17. Three chairs
18. One screen
19. One electric hand torch
20. An adequate supply of tetanus toxoid
21. Coramine liquid (60 ml.)
22. Tablets-antihistaminic, antispasmodic (25 each)
23. Syringes with needles-2cc, 5cc and 10cc
24. Two needle holders, big and small
25. Suturing needles and materials
27. One dressing forceps
28. One scalpels
29. One stethoscope
30. Rubber bandage-pressure bandage
31. Oxygen cylinder with necessary attachments
32. One Blood pressure apparatus
33. One patellar hammer
34. One Peak, flow meter for lung function measurementBihar Factories Rules, 1950

35. One Stomach wash set
36. Any other equipment recommended by the Factory Medical Officer
according to specific need relating to manufacturing process.
37. In addition-
(1)For factories employing 51 to 200 workers-
1. Four plain wooden splints 900 mm x 100 mm. x 6 mm.
2. Four plain wooden splints 350 mm x 75 mm x 6 mm.
3. Two plain wooden splints 250 mm x 50 mm x 12 mm.
4. One pair artery forceps
5. Injections-morphia, pethidine, atropine, adrenaline, coramine, novocain (2
each).
6. One surgical scissors.
(2)For factories employing above 200 workers-
1. Eight plain wooden splints 900 mm x 100 mm x 6 mm.
2. Eight plain wooden splints 350 mm x 75 mm x 6 mm
3. Four plain wooden splints 250 mm x 50 mm x 12 mm.
4. Two pairs of artery forceps
5. Injections-morphia, pethidine, atropine, adrenaline, coramine, novocain (4
each).
6. Two surgical scissors.
Chapter VBihar Factories Rules, 1950

63. Washing facilities.
(1)There shall be provided and maintained in every factory for the use of employed persons
adequate and suitable facilities for washing which shall include soap and nail brushes or other
suitable means of cleaning and the facilities shall be conveniently accessible and shall be kept in a
clean and orderly condition.(2)Without prejudice to the generality of the foregoing provisions the
washing facilities shall include-(a)a trough with taps or jets at intervals of not less than two feet,
or(b)wash-basins with taps attached thereto, or(c)taps on stand-pipes, or(d)showers controlled by
taps, or(e)circular trough of the fountain type:Provided that the Inspector may, having regard to the
needs and habits of the workers, fix the proportion in which the aforementioned types of facilities
shall be installed.(3)(a)Every trough and basin shall have a smooth impervious surface and shall be
fitted with a waste-pipe and plug.(b)The floor or ground under and in the immediate vicinity of
every trough, tapjet, wash-basin, stand-pipe and shower shall be so laid or finished as to provide a
smooth impervious surface and shall be adequately drained.(4)For person whose work involves
contact with any injurious or noxious substance there shall be at least one tap for every fifteen
persons working at any time in the factory and for persons whose work does not involve such
contact, the numbers of taps shall be as follows:-
No. of workers - working at any one time No. of taps.
Up to 20 ... ......1
21 to 35 ... ......2
36 to 50 ... ......3
51 to 150 ... ......4
151 to 200 ... ......5
Exceeding 200 but not exceeding 500 5 plus one tap for every 50 or fraction of 50.
Exceeding 500 11 plus one tap for every 100 or fraction of 100.
(5)If female workers are employed, separate washing facilities shall be provided and so enclosed or
screened that the interiors are not visible from any place where persons of the other sex work or
pass. The entrance to such facilities shall bear conspicuous notice in the language understood by the
majority of the workers "For Women only" and shall also be indicated pictorially.(6)The
water-supply to the washing facilities shall be capable of yielding at least six gallons a day for each
person employed in the factory and shall be from a source approved in writing by the Health Officer.
Provided that where the Chief Inspector is satisfied that such an yield is not practicable he may by
certificate in writing permit the supply of a smaller quantity not being less than one gallon per day
for every person employed in the factory.
63A. Facilities for storing and drying of clothings.
(1)In such parts of every factory in which any of the operations or processes specified in the
Schedule hereto annexed is carried on, adequate number of pegs, racks and similar facilities, for
hanging and keeping of clothings shall be provided for the use of workers.(2)The Inspector may
direct the manager or the occupier of any factory to provide such additional pegs, racks and similarBihar Factories Rules, 1950

facilities and at such places, as he may consider necessary and convenient and he may specify the
time within which the direction shall be carried out.(3)(a)The Chief Inspector may direct the
manager or the occupier of any factory to provide such cloak-rooms, lockers, pegs and such other
facilities for the use of the workers for drying and storing of clothings, as he may consider necessary
and may specify the time within which the direction shall be carried out.(b)Where a direction under
clause (a) has been given the manager or the occupier, as the case may be, shall submit the details in
respect of the site and plans elevations and necessary cross-section of the cloak room and full details
of other facilities to be provided to the Chief Inspector for approval within the time specified.(c)The
Chief Inspector may approve the details and the plans, subject to such conditions as he may specify,
and the cloak room and other facilities shall be provided in accordance with the plans and details as
approved by the Chief Inspector, and within the time specified.(4)These Rules shall be without any
prejudice to any Rules framed under Section 87.
Schedule 14
1. Manufacture of glass articles.
2. Manufacture of rubber or rubber goods or any other process in which
rubber is used.
3. Repairs, servicing and painting of Automobiles.
4. Processes carried out in foundaries.
5. Processes of and connected with dressing, packing and tanning of hides
and skins.
6. Processes using lead compounds.
7. Manufacture of Iron and Steel.
8. Manufacture of Potteries.
9. Manufacture of Refractory materials.
10. Electro-plating.
11. Operation of Boilers.Bihar Factories Rules, 1950

12. Operation of Coal Handling plants.
13. Manufacture of Chemicals.
64. First-aid appliance.
- The first-aid boxes or cupboards shall be distinctively marked with a red cross on a white ground
and shall contain the following equipments, namely:-(A)For factories in which the number of
persons employed does not exceed ten (or in case of factories in which mechanical power is not
used) does not exceed fifty persons. Each first-aid box or cupboard shall contain the following
equipments:-(i)Six small size sterilized dressings;(ii)Three medium size sterilized
dressings;(iii)Three large size sterilized dressings;(iv)Three large size sterilized burn
dressings;(v)One (60 ml.) bottle of cetrimide solution (1 per cent) or a suitable antiseptic
solution;(vi)One (30 ml.) bottle of mercurochrome solution (2 per cent) in water;(vii)One (30 ml.)
bottle containing sal-volatile having the dose and mode of administration indicated in the
label;(viii)A snake-bite lancet;(ix)One (30 ml.) bottle containing potassium permanganate
crystals;(x)One pair of scissors;(xi)One roll of adhesive plaster (2 cm. x 1 metre);(xii)Six pieces of
sterilized eye pads in separate sealed packets;(xiii)A bottle containing 100 tablets (each of 5 grains)
of aspirin or any other analgesic;(xiv)One polythene wash bottle (½ litre i.e. 500 c.c.) for washing
eye;(xv)One copy of first-aid leaflet issued by the Chief Inspector of Factories, Bihar; and(xvi)A
foolscap size bound register for maintaining the record of first-aid cases.(B)For factories in which
mechanical power is used in which the number of persons employed exceeds ten but does not
exceed fifty -Each first-aid box or cupboard shall contain the following equipments:-(i)Twelve small
size sterilized dressings;(ii)Six medium size sterilized dressings;(iii)Six large size sterilized
dressings;(iv)Six large size sterilized burn dressings;(v)Six 15 gm. packets of sterilized cotton
wool;(vi)One (120 ml.) bottle of cetrimide solution (1 per cent) or a suitable antiseptic
solutions;(vii)One (60 ml.) bottle of mercurochrome solution (2 per cent) in water;(viii)One (60 ml.)
bottle containing sal-volatile having the dose and mode of administration indicated on the
label;(ix)Snake bite lancet;(x)One (30 ml.) bottle containing potassium permanganate
crystals;(xi)One pair of scissors;(xii)Two rolls of adhesive plaster (2 c.m. x 1 meter);(xiii)Eight pieces
of sterilized eye pads in separate sealed packets;(xiv)One tourniquet;(xv)One dozen safety
pins;(xvi)A bottle containing 100 tablets (each of 5 grains) of aspirin or any other
analgesic;(xvii)One polythene wash bottle (½) litre i.e. 500 c.c.) for washing eyes;(xviii)One copy of
first-aid leaflet issued by the Chief Inspector of Factories, Bihar; and(xix)A foolscap size bound
register for maintaining the record of first aid cases.(C)For factories employing more than fifty
persons each first-aid box or cupboard shall contain the following equipments:-(i)Twenty-four small
size sterilized dressings;(ii)Twelve medium size sterilized dressings;(iii)Twelve large size sterilized
dressings;(iv)Twelve large size sterilized burn dressings;(v)Twelve (15 gm.) packets of sterilized
cotton wool;(vi)One (200 ml.) bottle of cetrimide solution (1 per cent) or a suitable antiseptic
solution;(vii)One (200 ml.) bottle of mercurochrome (2 per cent) solution in water;(viii)One (200
ml.) bottle of sal-volatile having the dose and mode of administration indicated on the label;(ix)One
pair of scissors;(x)Two rolls of adhesive plaster (6 cms. x 1 metre);(xi)Two rolls of adhesive plaster
(2 cms. x 1 metre);(xii)Twelve pieces of sterilized eye pads in separate sealed packets;(xiii)A bottle
containing 100 tablets (each of 5 grains) of aspirin or any other analgesic;(xiv)One polythene washBihar Factories Rules, 1950

bottle (500 c.c.) for washing eyes;(xv)Twelve roller bandages 10 cms. wide;(xvi)Twelve roller
bandages 5 cms. wide;(xvii)Six triangular bandages;(xviii)One tourniquet;(xix)A supply of suitable
splints;(xx)Two packets of safety pins;(xxi)Kidney tray;(xxii)A snake bite lancet;(xxiii)One (30 ml.)
bottle containing potassium permanganate crystals;(xxiv)First-aid leaflet issued by the Chief
Inspector of Factories, Bihar; and .(xxv)A foolscap size bound register for maintaining the record of
first-aid cases:Provided that items (xiv) to (xxi) inclusive need not be included in the standard
first-aid box or cupboard-(a)Where there is a properly equipped ambulance room, or(b)If at least
one box containing such items and placed and maintained in accordance with the requirements of
Section 45 is separately provided.(D)In lieu of the dressings required under items (i) and (ii) there
may be substituted adhesive wound dressings approved by the Chief Inspector of Factories, Bihar
and other equipments or medicines that may be considered essential and recommended by the Chief
Inspector of Factories, Bihar from time to time.(E)Notice regarding first aid-A notice containing the
names of the persons working within the precincts of the factory who are trained in first-aid
treatment and who are incharge of the first-aid boxes or cupboards shall be pasted in every factory
at a conspicuous place and near each such box or cupboard. The notice shall also indicate workroom
where the said person shall be available. The names of the nearest hospital and its telephone
number shall also be mentioned prominently in the notice.(F)Without prejudice to the generality of
the provision of sub-section (3) of Section 45, every first-aid box or cupboard shall be kept under the
charge of a person who is trained in first-aid treatment and has a certificate of proficiency in the said
treatment granted by any of the following authorities or persons, namely:-(a)St. John's Ambulance
Association;(b)Civil Surgeon;(c)Certifying Surgeon appointed under sub-section (1) of Section 10 of
the Act;(d)Medical Officer-Incharge of the Ambulance room of the factory in which the said person
is for the time being employed; or(e)Medical Inspector of Factories appointed under Section 8 of the
Act:Provided that the Chief Inspector may, by an order in writing, authorise any other registered
Medical Practitioner to grant the said certificate in respect of persons employed in any particular
factory:Provided further that the Chief Inspector may at any time withdraw and revoke the said
order:Provided also that the Medical Inspector of Factories, may as and when he may so desire or
consider necessary, or as directed by the Chief Inspector, carry out such tests or examinations of any
person under whose charge any first-aid box or cupboard has been kept, as he may deem necessary
to assess his proficiency in first-aid treatment and may by a written order cancel and nullify the
certificate already granted to him by any other authority in which case the said person shall be
deemed not to have any certificate of training in first-aid treatment.(G)If there is an ambulance
room in a factory according to Rule 65, the Chief Inspector of Factories may grant exemption from
certain requirements of Rule 64 to that factory by a written order subject to the condition that in
place of necessary facilities as required under Rule 64, such other facilities may be given or such
other arrangement may be made which he thinks fit. This exemption may be granted for a
prescribed period and may be revoked or cancelled at any time by a written order by the Chief
Inspector of Factories served on the occupier of the factory.
64A.
In every factory, wherein the maximum number of workers "(taking all the shifts and relays into
account) employed on any one day in the preceding twelve months is 50 or more, the following
equipments and articles (in addition to the medicines, equipments and articles prescribed in RuleBihar Factories Rules, 1950

(4) shall be provided and maintained in such a manner and condition and at such a place, as to be
readily available at any moment for removing workers injured in any accident or who may be sick to
an ambulance room, dispensary or a hospital namely:-Stretcher - 2;Blanket - 2:Provided that this
Rule shall not apply to the factories to which Rule 65 is applicable".
65. Ambulance Room.
(1)Every ambulance room or dispensary shall be under the charge of at least one whole-time
qualified medical practitioner (hereinafter referred to as Medical Officer) assisted by at least one
qualified nurse or dresser cum-compounder and one nursing attendant in each shift:Provided that
where a factory works in more than one shift, the Chief Inspector, if he is satisfied that on account of
the size of the factory, nature of hazards or frequency of accidents, it is not necessary to employ a
whole-time Medical Officer for each shift separately may, with the previous approval of the State
Government, relax the Rule and permit only one whole- time Medical Officer to be employed for
more than one or all shifts, subject to the conditions that-(a)there shall be no relaxation in respect of
nursing and other subordinate staff;(b)the Medical Officer shall be available in all shifts and shall
attend to all injuries and sickness except in very minor ones;(c)the Medical Officer shall be provided
with a residence close to the factory and shall be provided with a telephone and where there is no
telephone an alternative arrangement shall be made for informing and calling the Medical Officer
quickly; and(d)the Medical Officer shall not be employed for any other purpose.(2)The Ambulance
Room or dispensary shall be separate from the rest of the factory and shall be used only for the
purpose of first-aid treatment and rest. It shall have a floor area of at least 24-sq. metres and
smooth, hard and impervious walls and floors and shall be adequately ventilated and lighted by both
natural and artificial means. An adequate supply of whole-some drinking water shall by laid on and
the room shall contain at least-(i)A glazed sink with hot and cold water always available;(ii)A table
with smooth top at least 180 cms. x 105 cms;(iii)Means for sterilizing instruments:(iv)A
coach;(v)Two stretchers;(vi)Two buckets or containers with close fitting lids.(vii)Two rubber hot
water bags;(viii)A kettle and spirit stove or other suitable means of boiling water;(ix)Twelve plain
wooden splints 900 mm. x 100 mm. x 6 mm.(x)Twelve plain wooden splints 350 mm. x 75 mm. x 12
mm.(xi)Six plain wooden splints 250 mm. x 53 mm. x 12 mm.(xii)Six woollen blankets;(xiii)Three
pairs of artery forceps(xiv)One bottle of spiritus Ammoniac Aromatics (120 ml.);(xv)Smelling salt
(60 gms.)(xvi)Two medium size sponges;(xvii)Four kidney trays;(xix)Four cakes of antiseptic
soap;(xx)Two glass tumblers and two wine glasses;(xxi)Two clinical thermometers;(xxii)Teaspoons -
two;(xxiii)Graduated (120 ml.) measuring glass - two;(xxiv)Mini measuring glass-two;(xxv)One
wash bottle (1000 c.c.) for washing eye.(xxvi)One bottle (one litre) carbolic lotion 1 in
20;(xxvii)Three chairs;(xxviii)One screen;(xxix)One electric hand torch;(xxx)Four first-aid boxes or
cupboards, stocked to the standards prescribed under (C) of Rule 64;(xxxi)An adequate supply of
anti tetanus toxoid;(xxxii)Injections-Morphia, Pethidine, Atropine, Adrenaline Coramin Novocain -
6 ampules each;(xxxiii)Coramin liquid (60 ml.);(xxxiv)Tablets antihistaminic, antispasmodic (25
each);(xxxv)Syringes with needles 2 c.c., 5 c.c., 10 c.c., 50 c.c.;(xxxvi)Surgical scissors -
three.(xxxvii)Needle holders;(xxxviii)Suturing needles and materials;(xxxix)Dissecting
forceps-three.(xl)Dressing forceps - three.(xli)Scalpels - three.(xlii)Stethoscope - one;(xliii)Rubber
bandage-pressure bandage; and(xliv)Oxygen Cylinder with necessary attachments:Provided
that:-(1)In case of any factory wherein the number of workers generally employed exceeds oneBihar Factories Rules, 1950

thousand the Chief Inspector of Factories may require that the size of the ambulance room and the
equipment to be provided shall be such as he may, by order in writing, specify.(2)Where there is a
hospital or a dispensary belonging to the occupier of the factory situated in close proximity to the
boundary of the factory, the Chief Inspector may, by an order in writing, declare that, subject to the
conditions mentioned below, the said hospital or dispensary shall be deemed to be an ambulance
room for the purpose of this Rule-(a)the said hospital or dispensary shall have all such medicines,
equipments and other articles and all such facilities as prescribed in this Rule;(b)there shall be at
least one whole-time Medical Officer in the hospital or dispensary in each shift unless relaxation in
respect thereof has been allowed under the proviso of sub-rule (1),(c)there shall be adequate nursing
and other subordinate staff in each shift as prescribed in sub-rule (1) or as directed by the Chief
Inspector,(d)efficient transport facilities shall be provided to remove serious cases of injury and
sickness to the hospital or to the dispensary most speedily.(3)In every factory to which these Rules
apply an ambulance van shall be provided and maintained in a perfect working condition and shall
always be made available during working hours of the factory for the purposes of removing serious
cases of accidents or sickness:Provided that where arrangements have been made for obtaining such
ambulance van from any neighbouring hospital and the Chief Inspector is satisfied that the
ambulance van will always be available for removing cases of accidents or sickness, he may, by an
order in writing and subject to such conditions as he may specify, exempt the factory from
maintaining such a van:Provided further that the Chief Inspector, if he is satisfied that on account of
the proximity of a Hospital or Dispensary, the financial position of the Factory, the employment or
frequency of accidents or any other reasonable case, it is not necessary or practicable to provide an
ambulance van in any factory, and if he is satisfied that alternative arrangements for quick transfer
of any injured person to the nearest Hospital or Dispensary are available during all working hours of
the factory, may, by an order in writing, relax the sub-rule in respect of that factory to such extent,
subject to such conditions and for such period as may be specified in the said order".(4)There shall
be displayed in the ambulance room or dispensary a notice giving the name, address and telephone
number of the Medical Officer Incharge and the hours during which he is on duty at the time in the
ambulance room. The name of the nearest hospital and its telephone number shall also be
mentioned prominently in the said notice.(5)A record of all cases of accident and sickness treated at
the room shall be kept and produced to the Inspector or Certifying Surgeon when required.
66. Canteen.
(1)The State Government may, by a notification in the Official Gazette, specify the names of factories
in which more than 250 workers are ordinarily employed. Within six months of such notification,
the occupiers of said factories shall provide an adequate canteen in or near the factory according to
the standard prescribed in these Rules:Provided that the Chief Inspector may, by a written order,
relax this time limit and may direct the occupier to provide a canteen within such period as he may
specify:Provided further that where more factories than one belonging to the same occupier are
situated in close vicinity of one another, the State Government may, by a written order, permit the
canteen centrally situated to be used for some or all of the factories subject to such conditions as the
State Government may specify.(2)(i)The following plans of the canteen buildings in duplicate shall
be submitted to the Chief Inspector for approval:-(a)site plan;(b)the plan, elevation and necessary
cross-sections of the buildings, indicating all relevant details including those of natural lighting,Bihar Factories Rules, 1950

ventilation, etc.(ii)The Chief Inspector may require such other details and particulars to be
furnished as he considers necessary and may approve the plan with such conditions or
modifications as may be specified by him.(3)The canteen building shall be situated not less than fifty
feet away from any latrine, urinal, boiler house, coal stack, ash dump and any other source of dust,
smoke or obnoxious fumes:Provided that the Chief Inspector may for reasons to be recorded in
respect of any particular factory, relax the provisions of this sub-rule to such extent as may be
necessary and reasonable in the circumstances and may require measure to be taken to secure the
essential purpose of this sub-rule; and(4)The canteen building shall be constructed in accordance
with the plans approved by the Chief Inspector and shall accommodate at least a dining hall,
kitchen, store room, pantry, a cloak-room for the staff and washing places separately for workers
and for utensils.(5)In canteen the floor and inside wall upto a height of 4 feet from the floor shall be
made of smooth and impervious material; the remaining portion of the inside walls shall be made
smooth by cement plaster or in any other manner approved by the Chief Inspector.(6)The doors and
windows of a canteen building shall be of flyproof construction and shall allow adequate
ventilation.(7)The canteen shall be sufficiently lighted at all times when any persons have access to
it.(8)(a)In every canteen-(i)all inside walls of rooms and all ceilings and passages and staircases
shall be lime-washed or colour-washed at least once in each year or painted once in each year or
painted once in three years, dating from the period when last lime washed, or painted as the case
may be;(ii)all wood work shall be varnished or painted once in three years dating from the period
when last varnished or painted;(iii)all internal structural iron or steel work shall be varnished or
painted once in three years dating from the period when last varnished or painted:Provided that
inside walls of the kitchen shall be lime washed once every four months.(b)Records of dates on
which lime-washing, colour-washing, varnishing or painting is carried out shall be maintained in
Register in Form No.7.(9)The precincts of the canteen shall be maintained in a clean and sanitary
condition. Waste water shall be carried away in suitable covered drains and shall not be allowed to
accumulate so as to cause a nuisance. Suitable arrangement shall be made for the collection and
disposal of garbage.
67. Dining hall.
(1)The floor space of each dining room shall not be less than 8 square feet for every diner to be
accommodated. For calculating the minimum floor area to be provided in a proposed canteen it will
be assumed that 25 per cent of the maximum number of workers employed in the factory at any one
time shall make use of the canteen and the floor area in any canteen shall not be less than the figure
worked out on this basis:Provided that in case of factories employing more than one thousand
workers at a time the Chief Inspector may at his discretion reduce the assumption of 25 per cent to
15 percent.(2)A portion of the dining hall and service counter shall be partitioned off and reserved
for women workers in proportion to their number. Washing places for women shall be separate and
screened to secure privacy.(3)Sufficient tables, chairs or benches shall be provided for the number of
diners to be accommodated as prescribed in sub-rule (1)-Bihar Factories Rules, 1950

68. Equipment.
(1)There shall be provided and maintained sufficient utensils, crockery, cutlery, furniture and any
other equipment necessary for the efficient running of the canteen. Suitable clean clothes for the
employees serving on the canteen shall also be provided and maintained.(2)The furniture, utensils
and other equipment shall be maintained in a clean and hygienic condition and shall be replaced
whenever required. A service counter if provided shall have a top of smooth and impervious
material, suitable facilities including an adequate supply of hot water shall be provided for the
cleaning of utensils and equipment.
69. Prices to be charged.
(1)Food, drink and other items served in the canteen shall be sold on a no-profit basis and the prices
charged shall be subject to the approval of the Canteen Managing Committee:Provided that where
the canteen is managed by a Co-operative Society registered under any law for the time being in
force in respect of Co-operative Societies, such society may be allowed to include in the charges to be
made for the food-stuffs served, a profit up to 5 per cent on its working capital applied in running
the canteen.(2)The charge per portion of food-stuff, beverages and any other item served in the
canteen shall be conspicuously displayed in the canteen.(3)In computing the prices referred to in
sub-rule (1) the following items of expenditure shall not be taken into consideration, but will be
borne by the occupier:-(a)the rent for land and building,(b)the depreciation and maintenance
charge of the building and equipment provided for the canteen,(c)the cost of purchase, repair and
replacement for equipment including furniture, crockery, cutlery and utensils,(d)the water charges
and expenses for providing lighting and ventilation,(e)the interest of the amount spent on the
provision and maintenance of the building, furniture and equipment provided for the canteen.(f)the
cost of fuel required for cooking or heating food-stuffs or water, and(g)the wages of employees
serving in the canteen and the cost of uniforms, if any, provided to them.
70. Accounts.
(1)All books of accounts, registers and any other documents used in connection with the running of
the canteen shall be produced on demand to an Inspector.(2)The accounts pertaining to the canteen
shall be audited once every twelve months by registered accountants and auditors. The balance
sheet prepared, by the said auditors, shall be submitted to the Canteen Managing Committee not
later than two months after the closing of the audited accounts:Provided that the accounts
pertaining to the canteen in a Government Factory having its own Accounts Department may be
audited in such department:Provided further that where the canteen is managed by a Co-operative
Society registered under any law for the time being in force in respect of the Co-operative Societies,
the accounts pertaining to such canteen may be audited in accordance with the provisions of the
said law.Bihar Factories Rules, 1950

71. Canteen Managing Committee.
(1)The Manager shall within one month from the date on which the canteen starts functioning, or in
cases where a Canteen Managing Committee already exists, within one month from the date this
Rule comes into force constitute or reconstitute as the case may be, a Canteen Managing Committee
(hereinafter to be called the Committee) for the running and supervision of the canteen, and a list
containing the names of the members and Chairman of the Committee shall be sent to the Inspector
and the Chief Inspector within seven days of the constitution of the Committee, and a copy thereof
shall also be displayed on a notice board in the canteen which shall be maintained in a clear and
legible condition.(2)The Canteen Managing Committee shall-(a)exercise general supervision over
the running and management of the canteen and advise the Manager for such improvement and
changes as may be necessary;(b)bring to the notice of the Manager, any malpractice or any defect
that may be observed,(c)advise the Manager on matters relating to-(i)the quality and quantity of
food, tea, snacks and other items served or to be served in the canteen,(ii)the arrangement of menu
and times of meals,(iii)the method and means of serving and distributing articles served in the
canteen, and(iv)make such other suggestions and recommendation as in the opinion of the
Committee may be necessary for proper functioning of or for improvement in the Canteen.(3)The
Manager shall normally take steps to give effect to the recommendations of the Committee but when
any advice or recommendation is not accepted, the reason therefor shall be communicated to the
Committee in writing within a fortnight and a copy thereof shall be sent to the Inspector and the
Chief Inspector.(4)The Manager shall decide the number of members in the Canteen Managing
Committee which shall not be less than four excluding the Chairman.(5)The Canteen Managing
Committee shall include representatives of workers whose number shall be equal to the number of
members representing the employer, excluding the Chairman who shall be a nominee of the
Manager.(6)Where there is a Welfare Officer in the Factory, he shall be nominated by the Manager
to be a member of the Canteen Managing Committee and he shall be the Secretary to the
Committee, unless he is nominated to be the Chairman of the Committee:Provided that where there
is no Welfare Officer, or where there is only one Welfare Officer and he is the Chairman of the
Committee any other member of the Committee may be nominated by the Manager to be the
Secretary.(7)The members representing the employer shall be nominated by the Manager and the
members representing the workers shall be nominated by the recognised union. In case where there
is no recognised union or there is dispute about the office-bearer of the recognised union then the
representatives of the workers shall be elected by the workers themselves in such manner as may be
decided by the Manager in consultation with the Chief Inspector subject to revision of the same by
the State Government on appeal:Provided that in case where the representatives of workers are
elected by the workers in the manner indicated above these representatives of workers will be
replaced by the nominees of the recognised union as soon as there is a recognised union in that
particular establishment or the dispute of the office bearers of the recognised union has been
decided:Provided further that where there is Works Committee constituted under the Industrial
Disputes Act, 1947, the Manager shall ask the said Committee to nominate members representing
the workers. If no communication is received from the Works Committee within the time specified
by the Manager and the Inspector of Factories and the Chief Inspector of Factories are satisfied that
the Works Committee is deliberately not submitting the names of the representatives of the workers,
then the Manager may elect members representing the workers in such manner as may be decidedBihar Factories Rules, 1950

by him in consultation with the Chief Inspector subject to a revision by the State Government on
appeal.(8)(i)The Manager shall in consultation with and on the recommendation of the Committee
prepare the Rules of business of the Committee, within one month of the constitution of the
Committee in which the duties of the Secretary shall also be specified and a copy of these Rules shall
be sent to the Inspector and the Chief Inspector.(ii)Where there is any difference between the
Manager and the Committee with regard to the preparations of the Rules of business of the
Committee, the matter shall be referred to the Chief Inspector whose decision thereon shall, subject
to a revision by the State Government on appeal, be final.(9)(i)The Chairman shall conduct the
business of and preside over the meeting of the Committee and shall cast his vote only in the case of
equality of votes.(ii)The Chairman shall prepare a panel of names of the members of the Committee
arranged in order of priority who shall preside over and conduct the meetings of the Committee,
during his absence.(10)The Canteen Managing Committee shall function for one year where after
the Manager shall dissolve the Committee and shall form a new Committee within one month of the
dissolution of the Committee:Provided that so long as a new Canteen Managing Committee is not
constituted the old Committee shall continue to function.(11)(i)The proceedings of the meeting of
the Canteen Managing Committee shall be kept in a register and shall be produced for inspection
whenever demanded by an Inspector.(ii)A copy of the proceedings of the meeting of the Canteen
Managing Committee shall be forwarded to the Inspector and the Chief Inspector.
71A.
The State Government may exempt any factory from compliance with the provisions of Rules 66 to
71 provided the factory makes provisions for the following matters, namely:-(a)an adequate dining
hall with a kitchen;(b)adequate washing facilities in the dining hall;(c)arrangements for supply of
snacks and tea and such other articles of food as may be required by the workers; or in keeping with
the general food habits of the workers;(d)the plan of the dining hall shall be submitted to the Chief
Inspector and prior approval thereof shall be obtained from him. Such modifications, addition or
improvement shall be made therein as may be directed by the Chief Inspector;(e)the articles of food
shall be sold on no-profit basis, shall be prepared and sold by the occupier departmentally and not
through a contractor or any other agency;(f)the building, furniture, utensils, crockeries as well as
other equipments shall be supplied by the occupier direct;(g)the occupier shall bear the cost of fuel,
light, water and staff, and no charge in respect thereof shall be added to the price of articles sold in
the canteen; and(h)the dining hall and kitchen shall be kept clean at all times, shall have adequate
staff and the staff shall be provided with clean dresses and uniforms.
71B. [ Medical Examination. [Inserted vide S.O. 1011, dated 18th August 1975,
Published in Bihar Gazette Para-II, dated 20.8.1975.]
(1)Annual Medical Examination for fitness for each member of the canteen staff who handles
foodstuffs shall be carried out by the Factory Medical Officer or the Certifying Surgeon, which
should include the following:-(i)Chest X-Ray,(ii)Routine blood examination,(iii)Routine and
bacteriological testing of faeces and urine for germs of dysentry and typhoid fever.(2)Workers who
have any skin sores must not be allowed to work in the canteen.(3)A certificate of fitness to work in
a canteen shall be issued to all the staff which shall be produced on demand before an Inspector.]Bihar Factories Rules, 1950

72. Shelters, rest rooms and lunch rooms.
(1)All factories shall conform to this Rule within three months from the date of enforcement of these
Rules.(2)The Manager of a factory shall submit for the approval of the Chief Inspector a site plan in
duplicate of the building to be constructed or adapted for the shelters, or rest rooms and lunch
rooms which shall conform to the following standards:-(a)All the walls and roof of the building shall
be of suitable heat resisting materials and shall be waterproof. The floors and walls to a height of 3
feet shall be so laid or finished as to provide a smooth, hard and impervious surface.(b)The height of
every room in the building shall be not less than 12 feet from floor level to the lowest part of the roof
and there shall be at least 12 square feet of floor area for every person and the accommodation shall
not be less than ten per cent of the number of workers employed at any one time:Provided that (i)
workers who habitually go home for their meals during the rest periods may be excluded with the
approval of the Chief Inspector in calculating the number of workers to be accommodated, and (ii)
in the case of factories in existence at the date of commencement of the Act, where it is
impracticable; owing to lack of space to provide 12 square feet of floor area for each person, such
reduced floor area per person shall be provided as may be approved in writing by the Chief
Inspector.(c)Effective and suitable provision shall be made in every room for securing and
maintaining adequate ventilation by the circulation of fresh air and there shall also be provided and
maintained sufficient and suitable natural or artificial lighting.(d)Every room shall be adequately
furnished with chairs or benches with back- rests.(e)Sweepers shall be employed whose primary
duty is to keep the rooms, buildings and precincts thereof in a clean and tidy condition.(f)[ suitable
provisions shall be made in every room for supply and/or cool drinking water and adequate facilities
for washing.] [Inserted by S.O. 686 dated 13.7.1988.]
73. Creches.
(1)All factories shall conform to Rules 73 to 76 within six months from the date of enforcement of
these Rules.(2)The creche shall be conveniently accessible to the mothers of the children
accommodated therein and so far as is reasonably practicable it shall not be situated in close
proximity to any part of the factory where obnoxious fumes, dust or odours are given off or in which
excessively noisy processes are carried on.(3)The building in which the creche is situated shall be
soundly constructed and all the walls and roof shall be of suitable heat resisting materials and shall
be waterproof. The floor and internal walls of the creche shall be cement plastered or so laid or
finished as to provide a smooth impervious surface.(4)The height of the rooms in the building shall
be not less than 12 ft. from the floor to the lowest part of the roof and there shall be not less than 12
square feet of floor area for each child to be accommodated.(5)Effective and suitable provision shall
be made in every part of the creche for securing and maintaining adequate ventilation by the
circulation of fresh air.(6)The creche shall be adequately furnished and equipped and in particular
there shall be one suitable cot or cradle with the necessary bedding for each child, atleast one chair
or equivalent seating accommodation for the use of each mother while she is feeding or attending to
her child, and a sufficient supply of suitable toys for the older children:Provided that for children
over two years of age it will be sufficient if suitable bedding is made available.(7)A suitable fenced
and shady open air playground shall be provided for the older children:Provided that the Chief
Inspector may by order in writing exempt any factory from compliance with this sub-rule if he isBihar Factories Rules, 1950

satisfied that there is no sufficient space available for the provision of such a playground.(8)The
manager shall appoint necessary staff in the creche to look after the children during the absence of
their mothers.
74. Wash room.
(1)There shall be in or adjoining the creche a suitable wash-room for the washing of the children and
their clothings. The wash-room shall conform to the following standards, namely:-(a)The floor and
internal walls of the room to a height of 3 feet shall be so laid or finished as to provide a smooth
impervious surface. The room shall be adequately lighted and ventilated and the floor shall be
effectively drained and maintained in a clean and tidy condition.(b)There shall be at least one basin
or similar vessel for every four children accommodated in the creche at any one time together with a
supply of water provided, if practicable, through taps from a source approved by the Health Officer,
such source shall be capable of yielding for each child a supply of at least five gallons of water a
day.(c)An adequate supply of clean clothes, soap and clean towels shall be made available for each
child while it is in the creche.(2)Adjoining the washing-room referred to above, a latrine shall be
provided for the sole use of the children in the creche. The design of latrine and the scale of
accommodation to be provided shall either be approved by the Public Health Authorities or where
there is no such Public Health Authority, by the Chief Inspector.
75. Supply of milk and refreshment.
- Atleast half a pint of clean pure milk shall be available for each child on every day it is
accommodated in the creche and the mother of such a child shall be allowed, in the course of her
daily work, intervals of atleast 15 minutes each to feed the child. For children above two years of age
there shall be provided in addition an adequate supply of wholesome refreshment.
76. Cloths for creche staff.
- The creche staff shall be provided with suitable clean cloths for use while on duty in the creche.
Chapter VI
Workings Hours of Adults
77. Compensatory holidays.
(1)Except in the case of workers engaged in any work which for technical reasons must be carried on
continuously throughout the day, the compensatory holidays to be allowed under sub-section (1) of
Section 53 of the Act, shall be so spaced that not more than two holidays are given in one
week.(2)The Manager of the factory shall display, on or before the end of the month in which
holidays are lost, a notice in respect of workers allowed compensatory holidays during the following
month and of the dates thereof, at the place at which the notice of periods of work prescribed underBihar Factories Rules, 1950

Section 61 is displayed. Any subsequent change in the notice in respect of any compensatory
holidays shall be made not less than three days in advance of the date of that holiday.(3)Any
compensatory holiday or holidays to which a worker is entitled shall be given to him before he is
discharged or dismissed and shall not be reckoned as part of any period of notice required to be
given before discharge or dismissal.(4)The Manager shall maintain a Register in Form No.
9:Provided that, if the Chief Inspector is of the opinion that any Muster-Roll or register maintained
as part of the routine of the factory or return made by the manager, gives in respect of any or all of
the workers in the factory the particulars required for the enforcement of Section 52, he may, by
order in writing, direct that such Muster-Roll or register or return shall, to the corresponding extent,
be maintained in place of and be treated as the register or return required under this Rule for the
factory.(5)The register maintained under clause (a) shall be preserved for a period of three years
after the last entry in it and shall be produced before the Inspector on demand.
78. Muster-Roll exempted factories.
- The manager of every factory in which workers are exempted under Section 64 or 65 from the
provisions of Section 51 or 54 shall keep a Muster-Roll in Form No. 10 showing the normal
piecework rate of pay; or the rate of pay per hour, of all exempted employees. In this Muster-Roll
shall be correctly entered the overtime hours of work and payments therefor of all exempted
workers. The Muster-Roll in Form No. 10 shall always be available for inspection.
78A. Computation of cash equivalent of concessional sale of food grains etc.
- The cash equivalent of the advantage accruing through the concessional sale to a worker of
foodgrains and other articles shall be computed at the end of every wage period fixed under the
provisions of the Payment of Wages Act, 1936 (IV of 1936).
78B. Cash equivalent of concessional sale of food grains allowed for
overtime work.
- For the purposes of computing cash equivalent to the advantage accruing through the concessional
sale to a worker of food grains and other articles, the difference between the value of the foodgrains
and other articles at the average rates prevailing during the wage period in the nearest market, in
which such worker worked overtime and value of foodgrains and articles supplied at concessional
rates shall be calculated and allowed for the number of overtime hours during which he worked
overtime.Note. - This Rule shall not apply to any Railway Factory, whose alternative method of
computation has been approved by the State Government.
79. Notice of periods of work for adults.
- The notice of periods of work for adult workers shall be in Form No.11 and it shall be maintained in
the manner prescribed in sub-section (2) of Section 108 of the Act.Bihar Factories Rules, 1950

80. Register of adult workers.
- The register of adult workers shall be in Form No. 12, and shall be maintained in accordance with
the following provisions:-(1)Where a worker is transferred from one group to another, or from one
relay to another, the following particulars of his transfer shall be entered against his name:-(a)under
the group from which he has been transferred-(i)the date and actual time of finishing work in the
group or relay, and(ii)the group or relay to which he has been transferred, and(b)under the group to
which he has been transferred-(i)the date and actual time of commencing work in the group or
relay, and(ii)the group or relay from which he has been transferred.(2)Where a worker is discharged
from or leaves his employment, the date of his leaving or discharge, as the case may be, shall be
entered against his name in the "remarks" column.(3)All entries in the registers shall be made in ink
and shall be legible.
80A. [ Issue of Identity Cards to workers. [Inserted by S.O. 764 dated
18.6.1986.]
(1)The State Government may by notification in the Official Gazette, specify the type of
industries/factories which are required to issue identity cards to its workers.(2)The identity card
shall be in Form No. 12-A and shall be prepared in duplicate and one copy shall be given to the
worker and another shall be retained by the Occupier/Manager of the factory.(3)A passport size
photograph of the worker, duly attested by the Occupier/Manager, shall be affixed on the identity
card in the place provided for it.(4)The cost of photograph shall be borne by the
Occupier/Manager.(5)If the identity card is lost or damaged by the worker, a duplicate may be
issued to him on payment of Rs. 5.(6)The Occupier/Manager of the Factory shall also maintain a
register showing the names, designation, address and the number of the identity card of the workers
to whom identity card have been issued and a copy of the attested photograph mentioned in
sub-rule (3) shall also be affixed in it against the name of the workmen.(7)The identity card shall be
shown to the Inspector, if demanded in course of Inspection].
81. Persons defined to hold position of supervision and management.
- The following persons shall be deemed to hold positions of supervision and management:-(a)All
persons specified in the Schedule annexed hereto;(b)Any other person, who, in the opinion of the
Chief inspector, holds a position of supervision or management and has been declared by him as
such in writing.
Schedule 15
List of Persons Deemed to hold Positions of Supervision and Management in Factories.(1)All
Managers, General Managers, Deputy General Managers, Assistant Managers and Works
Managers.(2)Chief Engineers, Chief Chemists and Chief Metallurgist, Deputy Chief Chemists and
Deputy Chief Metallurgist.(3)Deputy Chief Engineers, Deputy Chief Chemists and Deputy Chief
Metallurgist.(4)Heads of Departments.Bihar Factories Rules, 1950

82. Persons defined to hold confidential position.
- The following persons employed in a factory shall be deemed to be employed in confidential
positions:-(a)Time-Keepers.(b)Personal Assistants and Stenographers attached to persons specified
in the Schedule annexed to Rule 81 and declared to be persons holding positions of supervision or
management under clause (b) of the said Rule.(c)Head Store-Keeper.(d)Head Clerk and Office
Superintendents.(e)Cashier.(f)Clerk dealing with accounts.(g)Labour Officers, Labour Welfare
Officers, Personnel Officers and Welfare Officers.(h)Administrative and Assistant Administrative
Officer.(i)Watch and Ward and Security Staff.(j)Any other person declared in writing by the Chief
Inspector to be holding a confidential position.
83. List to be maintained of persons holding confidential position or position
of supervision and management.
- A list showing the names and designation of all persons specified in Rules 81 and 82 shall be
maintained in every factory and shall be produced before the Inspector whenever required.
84. Exemption of certain adult workers.
(1)Adult male workers engaged in factories or in plants attached to factories, specified in column 2
of the Schedule hereto annexed, on any work specified in column 3 of the said Schedule shall be
exempted from the provisions of the Sections specified in column 4 subject to the conditions, if any,
specified in column 5 of the said Schedule:Provided that except in case of workers exempted under
clause (a) of subsection (2) of Section 64:-(i)the total number of hours of work in any day shall not
exceed ten;(ii)the total number of hours of overtime work shall not exceed fifty in any one
quarter;(iii)the spread over, inclusive of intervals for rest, shall not exceed twelve hours in any one
day.(2)Adult male workers engaged in any work which for technical reasons must be carried on
continuously and who have been exempted from Sections 52 and 55 under Section 64(2) (d) in
sub-rule (1) shall be further exempted from the provisions of Sections 51, 54, 56 and 61 of the
Factories Act, 1948 and the restrictions imposed in clauses (i) and (ii) of sub-section (4) of Section
64 shall not apply in case of such workers subject to the following conditions, namely:-(a)that this
exemption shall apply only when the worker is not relieved at the end of the period of his work
owing to failure of the reliever to report for duty at the appointed hours;(b)that the total hours of
overtime shall not exceed fifty in any one quarter.Explanation. - 'Quarter' means a period of three
consecutive months beginning on the 1st of January, the 1st of April, the 1st of July and the 1st of
October, respectively.
Schedule 16
Sl.
No.Section of the
Act
empowering
grant
ofexemption.Class of Factory. Nature of exempted work.Extent of
exemption.Remarks.Bihar Factories Rules, 1950

1 2 3 4 5 6
1. 64(2)(a) and
64 (3)All factories Urgent
repairs,Explanation.- (1)
The following shall be
considered to be urgent
repairs:-(a) Repairs to
anypart of the machinery
plant or structure of a
factory which isof such a
nature that delay in the
execution may involve
dangerto human life or
safety or stoppage of any
manufacturingprocess.(b)
Break-downrepair to
motive power, transmission
or other essential plantsor
machinery or other
factories, collieries,
railways,dock-yards and
harbours, tramways, motor
transport and
steamnavigation services,
gas generating stations,
electricgenerating station
and transmission systems,
pumping stations,or similar
essential or public utility
services, carried out inany
general engineering
work-shop or foundry
which may beessential to
enable such concerns and
services to maintain
theirnormal manufacturing
processes, production
operation or service.(c)
Repairs to shipsand
aircrafts done in a factory
which are essential to
enablesuch ships or
aircrafts to leave port at
proper time or tocontinue
their normal operations inSections,
51, 52, 54,
55, 56 and
61.Within 24 hours of
the commencement
of work, anotice shall
be sent to the
Inspector describing
the nature ofthe
urgent repairs and
the period likely to
be required for
itscompletion. A
copy of the same
notice shall be
displayed on
theNotice Board
prior to the
commencement of
the urgent repair.Bihar Factories Rules, 1950

a sea or air
worthyconditions as the
case may be.(d) Repairs
inconnection with a change
of motive power, for
example, fromsteam to
electricity or vice versa,
when such work cannot
bedone without stoppage of
the normal manufacturing
process.(e) Urgent
repairsto earth moving or
other vita machinery or
plants used in
theconstruction of dams
and other works of
engineering
constructioncarried out in
an engineering works shop
0r foundry, providedthe
work is of such a nature
that if the repair is not
carriedout, the main work
of construction is liable to
be held up.(f) Break down
repairs of Automobiles
carriedout in an
Automobile 01 Engineering
Workship.
2. 64(2)(b) and
64 (2).All factories
other than those
which work
throughout the
dayin a system
of relays.(i) Work in foundryon
operation of a cupola and
steel furnaces and pouring
ofmetals and any other
work connected or
incidental thereto.(ii) Work
inconnection with the
maintenance of mill
gearing, electricdrives,
mechanical oi electrical
lifts, steam or water pipes
andpumps.(iii) Work
ofexamining 01 repairing of
any machinery or other
plant which isnecessary forSections
51,54, 55,
56 and 61.As above serial no. 1.Bihar Factories Rules, 1950

carrying or the work in the
factory.(iv) Work of lighting
fire in Boiler Houses
andEngine Rooms, in order
to raise steam, or generate
gas,preparatory to the
commencement of regular
work in the factory.
3.64(2)(b) and
64 (3).Factories
manufacturing
explosives.(i) Cartridging
ofexplosives.(ii) Cleaning of
plantin the packing, mixing
and ingredient preparation
sections.(iii) Packing of
explosives.Sections 51,
54, 55, 56
and 61. 
4. Ditto,Factories
manufacturing
beverages;Preparation and handling
of syrup and
otheringredients and same
materials, filing and
cleaning of bottlesand other
work incidental thereto.Ditto. ...
5.64 (2) (c) and
64 (3).All factories
other than those
which work
through the day
ina system of
relays.(i) Work of drivers
andattendant upon
lighting, ventilating and
humidifying plants.(ii)
Work of Fire Pump Men.Sections 51,
54, 55 and
61....
6.64(2) (c) and
64 (3).Cold storage
and
refrigeration
factories or for
Cold storageand
regrigration
plants attached
with other
factories.Work of loading
andunloading and
transports of
articles.Explanation. - The
work of loading
andunloading includes
work of and in connection
with stocking ofarticles fro
preservation in the storage
rooms and
removaltherefrom besides,
loading and unloading on
transport vehicles.Section 51,
54, 55 and
61....
7. Ditto All factories. Operation of locomotives
and rolling stocks,loading
and unloading of goods
transported by trucks andDitto  Bihar Factories Rules, 1950

motorsvehicles, operation
of motor vehicles for
transport of
materialswithin the factory
and any other work
connected or,
incidentalthereto.
8. Ditto Rice MillsDrying lifting and storing of
paddy or any otherwork
incidental thereto.Ditto ...
9. 64(2)(d) Iron and steel
Smelting and
rolling and wire
drawing
andwirerope
making factories
and similar
plants attached
to
otherfactories.Operation of blast furnaces,
steel, smeltingfurnances
rolling mills and wire
drawing machines and
making ofwireropes.Sections 51,
54, 55 and
61.(1) Every
suchworkers shall be
allowed adequate
time to take
lightrefreshments or
meals at the place of
his employment in a
roomor a place
specially provided
for the purpose,
arranged in sucha
manner that it may
not cause
inconvenience to the
workers andat the
same time may not
require stopping of
any plant,machinery
or process or the
normal functioning
of the factory.(2)
Every workershall be
allowed atleast one
weekly holiday in
every week on
theaverage and
whenever in any
week the permitted
hours of workdaily
or weekly is
exceeded, extra
wages for overtime
on any.(3) A notice
describing theBihar Factories Rules, 1950

system of
work,change of
shifts, and, grant of
weekly holidays,
shall be sentto the
Inspector and the
Chief Inspector in
advance and
nochange shall be
made therein
without prior
intimation to
theInspector and
Chief Inspector and
subject further to
theprovisions of
Sections 61 and 63.
10. 64(3)(d)Foundries and
Forge plants
and General
Engineering
factories.Operation of Cupola, and
other Iron or Steelsmelting
furnaces, and Heat
treatment furnaces and
plants ovensand other
furnaces making of patterns
and moulds and
forgingoperations.Ditto Ditto
11. DittoCopper smelting
and Copper and
brass rolling
factories.Operation of rope ways,
handling of raw
materials,concentration,
smelting, refining,
manufacture of alloys
androlling.Ditto ...
12. DittoCoke
manufacturing
works and such
plants attached
to
otherfactories.(i) Operation of
cokeovens.(ii) Recovery
and treatment of
by-products.Ditto Ditto.
13. DittoCoke-bye
products
recovery and
treatment
factories.Recovery and treatment of
by-productsDitto Ditto
14. 64(3)(d) Ditto As above serial no. 9.Bihar Factories Rules, 1950

Electric power
generating and
transforming
factories
andBoiler
houses or such
plants attached
to other
factories.(i) Operation of orattending
upon boilers and its
accessories.(ii) Operation of
orattending upon prime
movers, generators, motor
generators,rotary
convertors boosters,
transformers or similar
otherplants.(iii) Attending
uponstorage batteries.(iv)
Operation of or attending
upon switch boards.Driving
or attending upon engines,
motors, pumps and
otheraccessories.
15. DittoWater pumping
and filtration
factories or such
plantsattached
to other
factories.Driving or attending upon
engines, motors, pumpsand
other accessories.Ditto Ditto
16. DittoIce factories and
cold
storage/plants
or such plants
attachedto other
factories.Operation of or attending
upon compressors,
pumpsand other plants and
equipments.  
17. 64(2)(d)Factories
manufacturing
gas or any gas
plants in any
otherfactory.Production of oxygen,
carbon dioxide, acetylene
orany other gas.Ditto Ditto
18. DittoCement
Factories.Work on -(i)
Handling,preparation,
grinding and treatment of
raw materials.(ii) Kilns;(iii)
Cement grinding,packing
and storing;(iv) Testing
andsamples in
laboratories;(v) Ropeways.Ditto Ditto
19. Ditto Refractories and
potteries.(i) Operation of
andattending upon
disintegrators, grindingDitto DittoBihar Factories Rules, 1950

mills and pug mills.(ii)
Moulding(iii) Firing and
attending upon kilns.
20. Ditto Glass factories(i) Mixing, grindingand
handling of raw
materials.(ii) Operation of
and attending upon
furnaces andchanging of
and attending upon potsDitto Ditto.
21. Ditto Paper FactoriesWork on-(i) Preparation of
rawmaterials;(ii)
Digesters;(iii)
Diffusers,washing and
sorting;(iv) Soda
recoveryplant;(v) Bleaching
breachmaking plant(vi)
Breaking andbeating
plant;(vii) Paper-making
cutting and finishing.Ditto Ditto
22. 64(2)(d)Vegetable Oil
Hydrogenation
factories.(i) Refining;(ii)
Hydrogenation;(iii)
Deodorising;(iv)
Production and
compression of Hydrogen
andOxygen.55 and 61. As above serial no. 9.
23. DittoChemical and
Fertilizer
Factories and
such plants
attached toother
factoriesManufacture of sulphuric,
hydrochloric and
nitricacids, sulphates,
sulphides, nitrates
superphosphates,
alum,oxides of iron and
explosives.Ditto Ditto
24. Ditto Oil RefineriesHandling of crude oil and
all the process of
andconnected with
manufacture of petroleum
and petroleum products.,Ditto Ditto
25. Ditto Land FactoriesWorks on sintering plant
and reducing furnace
andoperation of and
attending upon any plant
for recovery of anyother
metals.Ditto DittoBihar Factories Rules, 1950

26. DittoFactories in
which wheels,
wheel tyres and
Axels,
Locomotive,Automobiles
or Railway
wagons or
carriages are
manufactured
orsuch plants
attached to
other factories.Manufacture of wheel,
Tyres and Axles,
Locomotive.Automobile or
Railway carriages and
wagons.Ditto Ditto
27. DittoRoller Flour
Mills.Milling and bagging of
flour;Ditto Ditto
28. Ditto Sugar factories.Work on -(i) Handling
andcrushing of cane and
handling of 'Gur';(ii)
Filtration,Clarification and
crystallization of cane juice
and "gur"liquor;(iii) Curing
of motherliquor;(iv)
Drying, crushing,bagging
and handling of sugar.(v)
Burning of limstone and
sulphur.Ditto Ditto
29. Ditto PlywoodPreparation of glue, gluing,
combining, pressingand
drying.Ditto Ditto
30. Ditto Oil MillsOperation of Ghanies and
Oil expellers.Ditto Ditto
31. DittoAluminium
Factories,
including
manufacture of
Aluminium.Work on-(i)
Handling,preparation of
raw materials(ii)
Digesters.(iii) Filters.(iv)
Settling tanks.(v)
Precipitators.(vi) Kiln(vii)
Refining, Rolling and
pressing.Ditto Ditto
32. Ditto Distilleries and
BrewariesWork on...(i) Diffusion of
Mahua;(ii) Dilution
ofmolasses;(iii)
Fermentation;(iv) Yeast
propagation;(v)Ditto DittoBihar Factories Rules, 1950

Distillation,(vi) Handling
and preparation of raw
materials forfermentation.
33. Ditto Coal WasheriesHandling, Crushing,
Washing, floation grading
andconveying of coal.Ditto Ditto
34. DittoJute, Cotton and
other Textile
Mills.Handling and preparation
of raw material,
Carding,Spinning and
weaving yarns and textiles.Ditto Ditto
35. DittoAll factories
exempted under
Section 64 (2)
(d) and
mentionedin
serial 9 to 33 of
this Schedule.(i) Operation of orattending
upon boilers, prime movers
and plants for
lightingventilating or
humidifying.(ii) Such other
work and process which
areincidental to or
connected with and which
must proceedconcurrently
with the exempted work
and processes, and
whichmust for technical
reasons be carried on
continuously.Ditto Ditto
36. 64(2)(i)
64(3).Factories
wherein
printing of
newspaper is
carried on.Printing of newspapers
including such other work
which may beincidental or
connected thereto.Sections 51,
54, 56 and
61.(i) This
exemptionshall be
applicable only to
the workers engaged
in the printingof
newspapers who are
held up on account
of break down
ofmachinery.(ii)
Within 24 hours of
break-down a
noticeshall be sent to
the Inspector
describing the
nature of
thebreakdown and
giving a list of the
workers along with
hours ofover timeBihar Factories Rules, 1950

worked by each.
37.64(2) (i) and
64 (3)All factoriesLoading and unloading of
railway wagons.Sections 51,
52, 54, 55,
56 and 61.1. When any
workeris allowed to
work over time
under this
exemption,
noticethereof shall
be sent to the
Inspector.2.
Whenever
anyworker is allowed
to work on a weekly
holiday and
substitutedholiday is
not granted as per
Section 52
compensatory
holidayshall be
granted as provided
in Section 53.3. The
workers shall be
allowed sufficient
timeto take light
refreshment during
any period exceeding
fourhours.
Chapter VII
Employment of Young Persons
85. Notice of periods of work for children.
- The notice of periods of work for child workers shall be in Form No. 13, and it shall be maintained
in the manner prescribed in sub-section (2) of Section 108 of the Act.
86. Register of child workers.
- The register of child workers shall be in Form No. 14, and shall be maintained in accordance with
the following provisions:-(1)Where a child is transferred from one group to another, or from one
relay to another the following particulars of his transfer shall be entered against his name:-(a)Under
the group from which he has been transferred-(i)the date and actual time of finishing work in the
group of relay, and(ii)the group or relay to which he has been transferred, and-(b)under the group to
which he has been transferred-(i)the date and actual time of commencing work in the group or
relay, and(ii)The group or relay from which he has been transferred.(2)Where a child is dischargedBihar Factories Rules, 1950

from or leaves his employment the date of his leaving or discharge, as the case may be, shall be
entered against his name in the 'remarks' column.(3)All entries in the registers shall be made in ink
and shall be legible.
Chapter VIII
Leave with wages
87. Leave with wages Register.
(1)The Manager shall keep a Register in Form No. 15, hereinafter called the Leave with Wages
Register:Provided that if the Chief Inspector is of the opinion that any Muster-Roll or register
maintained as part of the routine of the factory, or return made by the Manager, gives, in respect of
any or all of the workers in the factory; the particulars required for the enforcement of Chapter VIII
of the Act, he may, by order in writing, direct that such Muster-Roll or register or return shall, to the
corresponding extent, be maintained in place of and be treated as the register or return required
under this Rule in respect of that factory.(2)The Leave with Wages Register shall be preserved for a
period of three years after the last entry in it and shall be produced before the Inspector on demand.
87A. Calculation of cash equivalent of the advantages accruing through
concessional sale of foodgrains in respect of worker proceeding on leave.
- The cash equivalent of the advantage accruing through the concessional sale of food grains and
other articles payable to workers proceeding on leave shall be the difference between the value at the
average rates in the nearest market prevailing during the month immediately preceding his leave
and the value of the concessional rates allowed of foodgrains and other articles he is entitled
to.Explanation. - For the purpose of calculating the cash equivalent, monthly average market rate of
foodgrains and other articles shall be computed at the end of every month.
88. Leave book.
(1)The Manager shall provide every worker with a Leave book in Form No. 15 not later than the 31st
of January, of the year following the year in which the worker is employed in the factory. The Leave
Book shall be the property of the worker and the worker shall not be required to produce it except
for the purpose of making necessary entries therein and a Leave Book so produced shall be returned
to the worker within seven days :Provided that-(a)when a worker is discharged or dismissed or
when his service is otherwise terminated during the course of a year, the Manager shall give him an
abstract of the Leave with Wages Register within a week of the date of discharge or dismissal or of
termination of service, as the case may be;(b)the Leave with Wages Register shall always be kept
complete and up-to-date and whenever any entry is made in the said register corresponding entry
shall simultaneously be made in the Leave Book.(c)whenever any application for grant of leave is
refused an entry to the effect shall be made in the Leave with Wages Register and in the Leave
Book.Explanation. - The term 'year' means "calendar year".(2)If a worker loses his Leave Book, theBihar Factories Rules, 1950

Manager shall provide him with another copy on the payment of fifty paise and shall complete it
from his record.
89. Medical Certificate.
- If any worker is absent from work due to illness and he wants to avail himself of the leave with
wages due to him to cover the whole or part of period of his illness under clause (7) of Section 29 of
Chapter VIII, he shall, if required by the Manager, produce a medical certificate signed by a
Registered Medical Practitioner or recognised Vaid or Hakim stating the cause of the absence and
the period for which the worker, is, in the opinion of such medical practitioner, unable to attend to
his work, or other reliable evidence to prove that he was actually sick during the period for which the
leave is to be availed of.
90. Notice to Inspector involuntary of unemployment.
- The Manager shall give, as soon as possible, a notice to the Inspector of every case of involuntary
unemployment of workers, giving number of unemployed and the reason for their unemployment.
Entries to this effect shall be made in the Leave with Wages Register and the Leave Book in respect
of each worker concerned.
91. Notice by worker.
- Before or at the end of every calendar year, a worker who may be required to avail of leave in
accordance with sub-section (8) of Section 79, may give notice to the Manager of his intention not to
avail himself of the leave with wages falling due during the following calendar year. The Manager
shall make an entry to that effect in the Leave with Wages Register and in the Leave Book of the
Worker concerned.
92. Notice of Leave with Wages.
- In the case of a factory in which a scheme for regulating the leave allowable under Section 79 of the
Act has been drawn up under sub-section (4) of Section 79-(1)As far as circumstances permit,
members of same family, comprising him and, wife and children shall be allowed leave on the same
date.(2)A worker may exchange the period of his leave with another worker, subject to the approval
of the Manager.
93. Payment of wages if the worker dies.
- If a worker dies before he resumes work, the balance of his pay, due for the period of leave, with
wages not availed of shall be paid to his nominee within one week of the intimation of death of the
worker. For this purpose each worker shall submit a nomination in Form No. 25 duly signed by
himself and attested by two witnesses. The nomination shall remain in force until it is cancelled or
revised by another nomination.Bihar Factories Rules, 1950

94. Register to be maintained in case of exemption under Section 84.
(1)Where an exemption is granted under Section 84, the Manager shall maintain a register showing
the position of each worker as regards leave due, leave taken and wages granted.(2)He shall display
at the main entrance of the factory, a notice giving full details of the system established in the
factory for leave with wages and shall send a copy of it to the Inspector.(3)No alteration shall be
made in the Leave Rule approved by the State Government at the time of granting exemption under
Section 84 without its previous sanction.
Chapter IX
Special Provisions
95. Dangerous operations.
(1)The following operations when carried on in any factory are declared to be dangerous operations
under Section 87 :-(1)Manufacture of aerated water and processes incidental thereto.(2)Electrolytic
plating or oxidation of metal articles by use of an electrolyte containing chromic acid or other
chromium compounds.(3)Manufacture and repair of electric accumulators.(4)Glass
manufacture.(5)Grinding or glazing of metals.(6)Manufacture and treatment of Lead and certain
compounds of Lead.(7)Generating petrol gas from petrol.(8)Cleaning, smoothing or roughening,
etc., of articles by a jet of sand, metal shot or grit or other abrasive propelled by a blast of
compressed air or steam.(9)Liming and tanning of raw hides and skins and process/incidental
thereto.(10)Certain Lead processes carried on in printing Presses and Type
Foundries.(11)Manufacture of Pottery and Processes incidental thereto.(12)Manufacture of articles
from refractory materials including manufacture of refractory bricks.(13)All operations, in which
any chemical is manufactured, recovered, handled, used or processed and any other work or process
connected or incidental thereto, carried on in any factory.(14)Compression of Oxygen and
Hydrogen.(15)Handling and processing of asbestos, manufacture of any article of asbestos and any
other process of manufacture or otherwise in which asbestos is used in any form.(16)Manufacture or
manipulation of Manganese and its compounds.(17)[Manufacture and manipulation of dangerous
pesticides.] [Inserted by S.O. 1086 dated 12th August, 1978, Published in Bihar Gazette, Part-II
dated August 16, 1978.](18)[Manufacture, use, storing, handling or manipulating of Benzene or any
substance containing Benzene. For this purpose Benzene includes all aromatic hydrocarbons having
the chemical formula C6H6] [Added by S.O. 632, dated 30.3.1979.](19)[ Process of extraction of oil
or other substances from oil-cakes, rice bran or from any other material or substance by the use of
any solvent] [Inserted by S.O. 686 dated 13.7.1988.](20)[ Operation involving High Noise levels.]
[Inserted by S.O. 686 dated 13.7.1988.](21)[ Transformation of stone or any other material
containing free silica.] [Added by Notification No. S.O. 126 dated 25.7.2017 (w.e.f. 30.11.1950).]
I
Manufacture of Aerated Waters and Processes incidental thereof.Bihar Factories Rules, 1950

1. Fencing of machines. - All machines for filling bottles, or syphons shall be
so constructed, placed or fenced, as to prevent, as far as may be practicable
a fragment of a bursting bottle or syphon from striking any person employed
in this factory.
2. Face-guards and gauntlets. - (1) The occupier shall provide and maintain in
good condition for the use of all persons engaged in filling bottles or
syphons-
(a)suitable face-guards to protect the face, neck and throat and(b)suitable gauntlets for both arms to
protect the whole hand and arms : Provided that-(i)Paragraph 2(1) shall not apply where bottles are
filled by means of an automatic machine so constructed that no fragment of a bursting bottle can
escape; and(ii)where a machine is so constructed that only one arm of the bottler at work upon it is
exposed to danger, a gauntlet need not be provided for the arm which is not exposed to
danger.(2)The occupier shall provide and maintain in good condition for the use of all persons
engaged in corking, crowning, screwing, wiring, foiling, capsuling, sighting or labelling bottles or
syphons-(a)suitable face-guards to protect the face, neck and throat, and(b)suitable gauntlets for
both arms to protect the arm and at least half of the palm and the space between the thumb and
forefinger.
3. Wearing of face-guards and gauntlets. - All persons engaged in any of the
processes specified in paragraph 2 shall, while at work in such processes
wear the face-guards and gauntlets provided under the provisions of the said
paragraph.
II
Electrolytic Plating or Oxidation of Metal Articles by use of an Electrolyte Containing Chromic Acid
or Other Chromium Compounds.
1. Definitions. - For the purposes of this Schedule :-
(a)"Electrolytic Chromium process" means the elctrolytic plating or oxidation of metal articles by
the use of an electrolyte containing Chromic acid or other Chromium compounds.(b)"Bath" means
any vessel used for an electrolytic Chromium process or for any subsequent process.(c)"Employed"
means in paragraphs 5, 7, 8 and 9 of this Schedule, employed in any process involving contact with
liquid from a bath.(d)"Suspension" means suspension from employment in any process involving
contact with liquid from any bath by written certificate in the Health Register, signed by the
Certifying Surgeon, who shall have power of suspension as regards all persons employed in any such
process.Bihar Factories Rules, 1950

2. Exhaust draught. - An efficient exhaust draught shall be applied to every
vessel in which an electrolytic Chromium process is carried on. Such
draught shall be provided by mechanical means and shall operate on the
vapour or spray given off in the process as near as may be at the point of
origin. The exhaust draught appliance shall be so constructed, arranged and
maintained as to prevent the vapour or spray entering into any room or place
in which work is carried on.
3. Prohibitions relating to women and young persons. - No woman
adolescent or child shall be employed or permitted to work at a bath.
4. Floor of work-rooms. - The floor of every room containing a bath shall be
impervious to water. The floor shall be maintained in good and level
condition and shall be washed down at least once a day.
5. Protective clothing. - (1) The occupier of the factory shall provide and
maintain in good and clean condition the following articles of protective
clothing for the use of all persons employed on any process at which they
are liable to come in contact with liquid from a bath and such clothing shall
be worn by the persons concerned:-
(a)waterproof aprons and bibs, and(b)for persons actually working at a bath, lose-fitting rubber
gloves and rubber boots or other waterproof foot-wear.(2)The occupier shall provide and maintain
for the use of all persons employed suitable accommodation for the storage and adequate
arrangements for the drying of the protective clothing.
6. Medical requisites. - The occupier shall provide and maintain a sufficient
supply of suitable ointment and impermeable water-proof plaster in a
separate box readily accessible to the workers and used solely for the
purpose of keeping the ointment and plaster.
7. Medical Examinations. - (a) Every person employed in the process shall be
examined by a Medical Officer of the Factory at least twice in every week, and
by the Certifying Surgeon at least once in every three months. -
(b)In a factory in which whole time Medical Officer is not employed, the weekly examinations may
be carried out by any qualified medical practitioner, or by. a responsible person especially trained
for this purpose and certified by the Certifying Surgeon or by the Medical Inspector of Factories, to
be competent to carry out this examination.(c)A register containing the names of all personsBihar Factories Rules, 1950

employed in the process shall be kept in Form No. 16 and the result of all examinations, whether
weekly or otherwise, shall be duly entered in the said register by the person carrying out the
examination and shall be duly signed by him. The said register shall be produced before and
examined by the Certifying Surgeons at every visit or at least once in every three months.(d)It shall
be the duty of the Manager and the Occupier to arrange for the medical and other examinations as
prescribed in this clause and to produce all persons required to be examined at the place and time
appointed for the said purpose and every person employed in the process shall whenever required
himself at the appointed time and place.(e)No person after suspension shall be employed in the
process without the written permission of the Certifying Surgeon duly entered in the register in
Form No. 16.The suspended person may be employed during the period of suspension on such other
job as may be advised or recommended by the Certifying Surgeon.
8. Cautionary placard. - A cautionary placard in the form specified by the
Chief Inspector and printed in the language of the majority of the workers
employed shall be affixed in a prominent place in the factory where it can be
easily and conveniently read by the workers.
9. Weekly examination. - A responsible person appointed in writing by
occupier of the factory shall twice in every week inspect the hands and
forearms of all persons employed and shall keep a record of such
inspections in the Health Register.
III
Manufacture and Repair of Electric Accumulators
1. Saving. - This Schedule shall not apply to the manufacture or repair of
electric accumulators or parts thereof not containing Lead or any compound
of Lead; or to the repair on the premises, of any accumulator forming part of
a stationary battery.
2. Definitions. - For the purposes of this Schedule :-
(a)"Lead process" means the melting of Lead or any material containing Lead, casting, pasting, Lead
burning, or any other work, including trimming, or any other abrading or cutting of posted plates
involving the use, movement or manipulation of; or contract with any oxide of
Lead.(b)"Manipulation of raw oxide of Lead" means any Lead process involving any manipulation or
movement of raw oxides of Lead other than its conveyance in a receptacle or by means of an
implement from one operation to another.(c)"Suspension" means suspension from employment in
any Lead process by written certificates in the Health Register (Form No. 16) signed by the
Certifying Surgeon, who shall have power of suspension as regards all persons employed in any suchBihar Factories Rules, 1950

process.
3. Prohibition relating to women and young persons. - No woman or young
person shall be employed or permitted to work in any Lead process or in any
room in which the manipulation of raw oxide of Lead or pasting is carried on.
4. Separation of certain processes. - Each of the fallowing processes shall be
carried on in such a manner and under such conditions as to secure
effectual separation from one another, and from any other process :-
(a)Manipulation of raw oxide of Lead;(b)Pasting;(c)Drying of pasted plates;(d)Formation with Lead
burning ("lacking") necessarily carried on in connection therewith;(e)Melting down of pasted plates.
5. Air space. - In every room in which a Lead process is carried on, there
shall be at least 500 cubic feet of air space for each person employed therein,
and in computing this air space no height over 12 feet shall be taken into
account.
6. Ventilation. - Every work-room shall be provided with inlets and outlets of
adequate size as to secure and maintain efficient ventilation in all parts of the
room.
7. Distance between workers in pasting room. - In every pasting room the
distance between the centre of the working position of any paster and that of
the paster working nearest to him shall not be less than five feet.
8. Floor of work-rooms. - (1) The floor of every room in which a Lead process
is carried on shall be-
(a)of cement or similar material so as to be smooth and impervious to water;(b)maintained in sound
condition;(c)kept free from materials, plant or other obstruction not required for, or produced in the
process carried on in the room.(2)In all such rooms other than grid casting shop the floor shall be
cleansed daily after being thoroughly sprayed with water at a time when no other work is being
carried on in the room.(3)In grid casting shops the floor shall be cleansed daily.Without prejudice to
the requirements of sub-paragraphs (1), (2) and (3), where manipulation of raw oxide of Lead or
pasting is carried on, the floor shall also be-(a)kept constantly moist while work is being
done;(b)provided with suitable and adequate arrangements for drainage;(c)thoroughly washed daily
by means of a hose pipe.Bihar Factories Rules, 1950

9. Work benches. - The work-benches at which any Lead process is carried
on shall-
(a)have a smooth surface and be maintained in sound condition;(b)be kept free from all materials or
plant not required for or produced in, the process carried on there at;and all such work-benches
other than those in grid casting shop shall-(c)be cleansed daily either after being thoroughly damped
or by means of a suction cleaning apparatus at a time when no other work is being carried on there
at;and all such work benches in grid casting shops, shall-(d)be cleansed daily;and every work-bench
used for pasting shall-(e)be covered throughout with sheet Lead or other impervious material;(f)be
provided with raised edges;(g)be kept constantly moist while pasting is being carried on.
10. Exhaust draught. - The following processes shall not be carried on
without the use of an efficient exhaust draught:-
(a)Melting of Lead or materials containing Lead;(b)Manipulation of raw oxide of Lead, unless done
in an enclosed apparatus so as to prevent the escape of dust into the work-
room;(c)pasting;(d)Trimming, brushing, filing or any other abrading or cutting of pasted plates
giving rise to dust;(e)Lead burning, other than-(i)"tacking" in the formation room;(ii)chemical
burning for the making of Lead linings for cell cases necessarily carried on in such a manner that the
application of efficient exhaust is impracticable.Such exhaust draught shall be effected by
mechanical means and shall operate on the dust or fume given off as nearly as may be at its point of
origin, so as to prevent it entering the air of any room in which persons work.
11. Fumes and gases from melting pots. - The products of combustion
produced in the heating of any melting pot shall not be allowed to escape
into a room in which persons work.
12. Container for dross. - A suitable receptacle with tightly fitting cover shall
be provided and used for dross as it is removed from every melting pot. Such
receptacle shall be kept covered while in the work-room, except when dross
is being deposited therein.
13. Container for Lead waste. - A suitable receptacle shall be provided in
every work-room in which old plates and waste material which may give rise
to dust shall be deposited.
14. Racks and Shelves in drying room. - The racks or shelves provided in any
drying room shall not be more than 8 feet from the floor not more than 2 feet
in width, provided that as regards racks or shelves set or drawn from both
sides the total width shall not exceed 4 feet.Bihar Factories Rules, 1950

Such racks or shelves shall be cleansed only after being thoroughly damped unless an efficient
suction cleaning apparatus is used for this purpose.
15. Medical examination. - (a) Every person employed in a Lead process shall
be examined by the Certifying Surgeon within the seven days preceding or
following the date of his first employment in such process and thereafter
shall be examined by the Certifying Surgeon once in every calendar month,
or at such other intervals as may be specified in writing by the Chief
Inspector, on a day of which due notice shall be given to all concerned.
"First employment" means first employment in a Lead process in the factory or workshop and also
re-employment therein in a Lead process following any cessation of employment in such process for
a period exceeding three calendar months.(b)A Health Register in Form No. 16 containing the
names of all persons employed in lead process shall be kept.(c)No person after suspension shall be
employed in Lead process without written sanction from the Certifying Surgeon entered in or
attached to the Health Register.
16. Protective clothing. - Protective clothing shall be provided and
maintained in good repair for all persons employed in :-
(a)manipulation of raw oxide of Lead;(b)pasting;(c)the formation room;and such clothing shall be
worn by the persons concerned. The protective clothing shall consist of a waterproof apron and
waterproof foot-wear; and, also, as regards persons employed in the manipulation of raw oxide of
Lead or in pasting, head coverings. The head coverings shall be washed daily.
17. Mess-room. - There shall be provided and maintained for the use of all
persons employed in a Lead process and remaining on the premises during
the meal intervals, a suitable mess-room, which shall be furnished with (a)
sufficient tables and benches and (b) adequate means for warming food.
The mess-room shall be placed under the charge of a responsible person, and shall be kept clean.
18. Cloak-room. - There shall be provided and maintained for the use of all
persons employed in Lead process :-
(a)a cloak-room for clothing put off during working hours with adequate arrangements for drying
the clothing if wet. Such accommodation shall be separate from any mess-room.(b)separate and
suitable arrangements for the storage of protective clothing provided under paragraph 16.Bihar Factories Rules, 1950

19. Washing facilities. - There shall be provided and maintained in a cleanly
state and in good repair for the use of all persons employed in a Lead
process :-
(a)A wash place under cover, with either:-(i)a trough with a smooth impervious surface fitted with a
waste pipe, without plug, and of sufficient length to allow of at least, two feet for every five such
persons employed at any one time, and having a constant supply of water from taps or jets above the
trough at intervals of not more than two feet; or(ii)at least one wash basin for every five such
persons employed at any one time, fitted with a waste pipe and plug and having a constant supply of
water laid on;(iii)a sufficient supply of clean towels made of suitable materials renewed daily, which
supply, in the case of pasters and persons employed in the manipulation of raw oxide of Lead, shall
include a separate marked towel for each such worker; and(iv)a sufficient supply of soap or other
suitable cleansing material and of nail brushes.(b)There shall in addition be provided means of
washing in close proximity to the rooms in which manipulation of raw oxide of Lead or pasting is
carried on if required by notice in writing from the Chief Inspector.
20. Time to be allowed for washing. - Before each meal and before the end of
the day's work, at least ten minutes, in addition to the regular meal times,
shall be allowed for washing to each person who has been employed in the
manipulation of raw oxide of lead or in pasting :
Provided that if there be one basin or two feet of trough for each such person this Rule shall not
apply.
21. Facilities for bathing. - Sufficient bath accommodation to the satisfaction
of the Chief Inspector shall be provided for all persons engaged in the
manipulation of raw oxide of Lead or in pasting, and a sufficient supply of
soap and clean towels.
22. Foods, drinks, etc., prohibited in work-rooms. - No food, drink, "pan" and
"supari" or tobacco shall be consumed or brought by any worker into any
work room in which any Lead process is carried on.
IV
Glass Manufacture
1. Exemption. - If the Chief Inspector is satisfied in respect of any factory or
any class of process, that, owing to the special method of work or the special
conditions in a factory or otherwise any of the requirements of this ScheduleBihar Factories Rules, 1950

can be suspended or relaxed without danger to the persons employed
therein, or that the application of this Schedule or any part thereof is for any
reason impracticable, he may by certificate in writing authorise such
suspension or relaxation as may be indicated in the certificate for such
period and on such conditions as he may think fit.
2. Definitions. - For the purpose of this Schedule. - (a) "Efficient exhaust
draught" means localised ventilation effected by mechanical means for the
removal of gas, vapour, dust or fumes so as to prevent, them (as far as
practicable under the atmospheric conditions usually prevailing) from
escaping into the air of any place in which work is carried on. No draught
shall be deemed efficient which fails to remove smoke generated at the point
where such gas, vapour, fume or dust originates.
(b)"Lead compound" means any compound of Lead other than galena which, when treated in the
manner described below, yields to an aqueous solution of hydrochloric acid a quantity of soluble
Lead compound exceeding, when calculated as Lead monoxide, five per cent of the dry weight of the
portion taken for analysis.The method of treatment shall be as follows :-A weighed quantity of the
material which has been dried at 100°C and thoroughly mixed shall be continuously shaken for one
hour, at the common temperature with 1,000 times its weight of an aqueous solution of
hydrochloric acid containing 0.25 percent by weight of hydrogen chloride. This solution shall
thereafter be allowed to stand for one hour and then filtered. The Lead salt contained in the clear
filtrate shall then be precipitated as Lead Sulphide and weighed as Lead Sulphate.(c)"Suspension"
means suspension from employment in any process specified in paragraph 3 by written certificate in
the Health Register Form No. 16 signed by the Certifying Surgeon who shall have power of
suspension as regards all persons employed in any such process.
3. Exhaust draught. - The following processes shall not be carried on except
under an efficient exhaust draught or under such other conditions as may be
approved by the Chief Inspector:-
(a)The mixing of raw materials to form a "batch".(b)The dry grinding, glazing and polishing of glass
or any article of glass.(c)All processes in which Hydrofluoric acid, fumes or Ammoniacal vapours are
given off.(d)All processes in making of furnace moulds or "pots" including the grinding or crushing
of used "pots".(e)All processes involving the use of a dry Lead compound.
4. Prohibition relating to women and young persons. - No woman or young
person shall be employed or permitted to work in any of the operations
specified in paragraph 3 or at any place where such operations are carried
on.Bihar Factories Rules, 1950

5. Floors and work-benches. - The floor and work benches of every room in
which a dry compound of Lead is manipulated or in which any process is
carried on giving of silica dust shall be kept moist and shall comply with the
following requirements:-
The floors shall be-(a)of cement or similar material so as to be smooth and impervious to
water;(b)maintained in sound condition; and(c)cleansed daily after being thoroughly sprayed with
water at a time when no other work is being carried on in the room.The work-benches shall-(a)have
a smooth surface and be maintained in sound condition, and(b)be cleansed daily either after being
thoroughly damped or by means of a suction cleaning apparatus at a time when no other work is
being carried on thereat.
6. Use of Hydrofluoric acid. - The following provisions shall apply to rooms in
which glass is treated with Hydrofluoric acid :-
(a)There shall be inlets and outlets of adequate size so as to secure and maintain efficient ventilation
in all parts of the room;(b)The floor shall be covered with guttaparcha and be tight and shall slope
gently down to a covered drain;(c)The work places shall be so enclosed in projecting hoods that
openings required for bringing in the objects to be treated shall be as small as practicable;
and(d)The efficient exhaust draught shall be so contrived that the gases are exhausted downwards.
7. Storage and transport of Hydrofluoric acid. - Hydrofluoric acid shall not be
stored or transported except in cylinders or receptacles, made of Lead or
rubber.
8. Blow-pipe. - Every glass blower shall be provided with a separate blowpipe
bearing the distinguish mark of the person to whom it is issued and suitable
facilities shall be readily available to every glass blower for sterilising his
blow-pipe.
9. Food, drinks, etc., prohibited in work rooms. - No food, drink, 'pan' and
'supari' or tobacco shall be brought into or consumed by any worker in any
room or work place wherein any process specified in paragraph 3 is carried
on.
10. Protective clothing. - The occupier shall provide, maintain in good repair
and keep in a clean condition for the use of all persons employed in the
processes specified in paragraph 3 suitable protective clothing, foot-wear
and goggles according to the nature of the work and such clothing,
foot-wear, etc, shall be worn by the persons concerned.Bihar Factories Rules, 1950

11. Washing facilities. - There shall be provided and maintained in a cleanly
state and in good repair for the use of all persons employed in the processes
specified in paragraph 3 :-
(a)a wash place with either-(i)a trough with a smooth impervious surface fitted with a waste pipe,
without plug and of sufficient length to allow of at least two feet for every five such persons
employed at any one time and having a constant supply of water from taps or jets above the trough
at intervals of not more than 2 feet; or(ii)at least one wash basin for every five such person employed
at any one time, fitted with a waste pipe and plug and having an adequate supply of water laid on or
always readily available; and(b)a sufficient supply of clean towels made of suitable material renewed
daily with a sufficient supply of soap or other suitable cleansing material and of nail brushes;
and(c)a sufficient number of stand pipes with taps. - The number and location of such stand pipes
shall be to the satisfaction of the Chief Inspector.
12. Medical Examination. - (a) Every person employed in any process
specified in paragraph 3 shall be examined by the Certifying Surgeon within
seven days preceding or following, the date of his first employment in such
process and thereafter shall be examined by the Certifying Surgeon once in
every calendar month or at such other intervals as may be specified in
writing by the Chief Inspector on a day of which due notice shall be given to
all concerned.
(b)A Health Register in Form No. 16 containing the names of all persons employed in any process
specified in paragraph 3 shall be kept.(c)No person after suspension shall be employed in and
process specified in paragraph 3 without written sanction from the Certifying Surgeon entered in or
attached to the Health Register.
V
Grinding or Glazing of Metals and Processes Incidental thereto
1. Definitions. - For the purposes of this Schedule-
(a)"Grindstone" means a grindstone composed of natural or manufactured sandstone but does not
include a metal wheel or cylinder into which blocks of natural or manufactured sand stones are
fitted.(b)"Abrasive wheel" means a wheel manufactured of bonded emery or similar
abrasive.(c)"Grinding" means the abrasion, by aid of mechanical power, of metal, by means of a
grindstone or abrasive wheel.(d)"Glazing" means the abrading, polishing or finishing, by aid of
mechanical power, of metal, by means of any wheel, buff, mop or similar appliance to which any
abrading or polishing substance is attached or applied.(e)"Racing" means the tuning up, cutting or
dressing of a revolving grindstone before it is brought into use for the first time.(f)"Hacking" means
the chipping of the surface of a grindstone by hack or similar tool.(g)"Rodding" means the dressing
of the surface of a revolving grindstone by the application of a rod, bar or strip of metal to suchBihar Factories Rules, 1950

surface.
2. Exceptions. - (1) Nothing in this Schedule shall apply to any factory in
which only repair are carried on except any part thereof in which one or more
persons are wholly or mainly employed in the grinding or glazing of metals.
(2)Nothing in this Schedule except paragraph 4 shall apply to any grinding or glazing of metals
carried on intermittently and at which no person is employed for more than 12 hours in any
week.(3)The Chief Inspector may, by certificate in writing, subject to such conditions as he may
specify therein, relax or suspend any of the provisions of this Schedule in respect of any factory if
owing to the special methods of work or otherwise such relaxation or suspension is practicable
without danger to the health or, safety of the persons employed.
3. Equipment for removal of dust. - No racing, dry grinding or glazing shall be
performed without:-
(a)a hood or other appliance so constructed, arranged, placed and maintained as substantially to
intercept the dust thrown off; and(b)a duct of adequate size, air tight and so arranged as to be
capable of carrying away the dust, which shall be kept free from obstruction and shall be provided
with proper means of access for inspection and cleaning, where practicable, with a connection at the
end remote from the fan to enable the Inspector to attach thereto any instrument necessary for
ascertaining the pressure of air in the said duct; and(c)a fan or other efficient means of producing a
draught sufficient to extract the dust;Provided that the Chief Inspector may accept any other
appliance that is, in his opinion, as effectual for the interception, removal and disposal of dust
thrown off as a hood, duct and fan would be.
4. Restriction on employment on grinding operations. - Not more than one
person shall at any time perform the actual process of grinding or glazing
upon a grindstone, abrasive wheel or glazing appliance :
Provided that this paragraph shall not prohibit the employment of persons to assist in the
manipulation of heavy or bulky articles at any such grindstone, abrasive wheel or glazing appliance.
5. Glazing. - Glazing or other processes, except processes incidental to wet
grinding upon a grindstone shall not be carried on in any room in which wet
grinding upon a grindstone is done.
6. Hacking and rodding. - Hacking or rodding shall not be done unless during
the process either (a) an adequate supply of water is laid on at the upper
surface of the grindstone or (b) adequate appliance for the interception of
dust are provided in accordance with the requirements of paragraph 3.Bihar Factories Rules, 1950

7. Examination of dust equipment. - (a) All equipments for the extraction or
suppression of dust shall, at least once in every six months be examined and
tested by a competent person, and any defect disclosed by such examination
and test shall be rectified as soon as practicable.
(b)A register containing particulars of such examination and test shall be kept in a Form approved
by the Chief Inspector.
VI
Manufacture and Treatment of Lead and Certain Compounds of Lead
1. Exemption. - Where the Chief Inspector is satisfied that all or any of the
provisions of this Schedule are not necessary for the protection of the
persons employed, he may by certificate in writing exempt any factory from
all or any of such provision, subject to such conditions as he may specify
therein.
2. Definitions. - For the purposes of this Schedule :-
(a)"Lead Compound" means any compound of Lead other than galena which when treated in the
manner described below, yields to an aqueous solution of hydrochloric acid, a quantity of soluble
Lead compound exceeding, when calculated as Lead monoxide, five per cent of the dry weight of the
portion taken for analysis. In the case of paints and similar products and other mixtures containing
oil or fat the "dry weight" means the dry weight of the material remaining after the substance has
been thoroughly mixed and treated with suitable solvents to remove, oil, fats, varnish or other
media.The method of treatment shall be as follows :-A weighed quantity of the material which has
been dried at 100°C and thoroughly mixed shall be continuously shaken for one hour, at the
common temperature with 1,000 times its weight of an aqueous solution of hydrochloric acid
containing 0.25 percent by weight of hydrogen chloride. This solution shall thereafter be allowed to
stand for one hour and then filtered. The Lead salt contained in the clear filtrate shall then be
precipitated as Lead Sulphide and weighed as Lead Sulphate.(b)"Efficient Exhaust Draught" means
localised ventilation effected by heat or mechanical means, for the removal of gas, vapour, dust or
fumes so as to prevent them (as far as practicable under the atmospheric conditions usually
prevailing) from escaping into the air of any place in which work is carried on. No draught shall be
deemed efficient which fails to remove smoke generated at the point where such gas, vapour, fumes
or dust originate.
3. Application. - This Schedule shall apply to all factories or parts of factories
in which any of the following operations are carried on :-
(a)Work at a furnace where the reduction or treatment of Zinc or Lead ores is carried on.(b)TheBihar Factories Rules, 1950

manipulation, treatment or reduction of ashes containing Lead, the desilverising of Lead or the
melting of scrap Lead or Zinc.(c)The manufacture of solder or alloys containing more than ten per
cent of Lead.(d)The manufacture of any oxide, carbonate, sulphate, chromate, acetate, nitrate or
silicate of Lead.(e)Handling or mixing of Lead tetra-ethyl.(f)Any other operation involving the use of
a Lead compound.(g)The cleaning of work-rooms where any of the operation aforesaid are carried
on.
4. Prohibition relating to women and young persons. - No woman or young
person shall be employed or permitted to work in any of the operation
specified in paragraph 3.
5. Requirements to be observed. - No person shall be employed or permitted
to work in any process involving the use of Lead compound if the process is
such that dust or fume from a Lead compound is produced therein, or the
persons employed therein are liable to be splashed with any Lead compound
in the course of their employment unless the provisions of paragraphs 6 to
14 are complied with.
6. Exhaust draught. - Where dust, fume, gas or vapour is produced in the
process, provision shall be made for removing them by means of an efficient
exhaust draught so contrived as to operate on the dust, fume, gas or vapour
as closely as possible to the point of origin.
7. Certificate of fitness. - A person medically examined under paragraph 8
and found fit for employment shall be granted by a Certifying Surgeon a
certificate of fitness in Form No. 24 and such certificate shall be in the
custody of the Manager of the Factory. The certificate shall be kept readily
available for inspection by any Inspector and the person granted such a
certificate shall carry with him; while at a work a token giving reference to
such certificate.
8. Medical Examination. - (1) The person so employed shall be medically
examined by a Certifying Surgeon within 14 days of his first employment in
such process and thereafter shall be examined by the Certifying Surgeon at
intervals of not more than three months, and a record of such examination
shall be entered by the Certifying Surgeon on the special certificate of fitness
granted under paragraph 7.Bihar Factories Rules, 1950

(2)If at any time the Certifying Surgeon is of opinion that any person is no longer fit for employment
on the grounds that continuance therein would involve special danger to health, he shall cancel the
special certificate of fitness of that person.(3)No person whose special certificate of fitness has been
cancelled shall be employed unless the Certifying Surgeon, after re-examination, again certifies him
to be fit for employment.
9. Food, drinks, etc., prohibited in work-rooms. - No food, drink, 'pan' and
'supari' or tobacco shall be brought into or consumed by any worker in any
workroom in which the process is carried on and no person shall remain in
any such room during intervals for meals or rest.
10. Protective clothing. - Suitable protective overalls and head coverings
shall be provided, maintained and kept clean by the factory occupier and
such overalls and head coverings shall be worn by the person employed.
11. Cleanliness of work-rooms, tools, etc. - The rooms in which the persons
are employed and all tools and apparatus used by them shall be kept in a
clean state.
12. Washing facilities. - (1) The occupier shall provide and maintain for the
use of all persons employed suitable washing facilities consisting of-
(a)a trough with a smooth impervious surface fitted with a waste pipe without plug and of sufficient
length to allow at least two feet for every ten persons employed at any one time, and having a
constant supply of clean water from taps or jets above the trough at intervals of not more than two
feet; or(b)at least one wash-basin for every ten persons employed at any one time, fitted with a
waste pipe and plug and having a constant supply of clean water.Together with, in either case, a
sufficient supply of nail brushes, soap or other suitable cleansing material and clean towels.(2)The
facilities so provided shall be placed under the charge of a responsible person and shall be kept
clean.
13. Mess-room or Canteen. - The occupier shall provide and maintain for the
use of the persons employed suitable and adequate arrangements for taking
their meals. The arrangements shall consist of the use of a room separate
from any workroom which shall be furnished with sufficient tables and
benches, and unless a canteen serving hot meals is provided, adequate
means of warming food. The room shall be adequately ventilated by the
circulation of fresh air, shall be placed under the charge of a responsible
person and shall be kept clean.Bihar Factories Rules, 1950

14. Cloak-room. - The occupier shall provide and maintain for the use of
persons employed, suitable accommodation for clothing not worn during
working hours, and for the drying of wet clothing.
VII
Generating Petrol Gas from Petrol
1. Prohibition relating to women and young persons. - No woman or young
person shall be employed or permitted to work in or shall be allowed to enter
any building in which the generating of petrol gas from petrol is carried on.
2. Flame traps. - The plant for generating petrol gas from petrol and
associated piping and fittings shall be fitted with at least two efficient flame
traps so designed and maintained as to prevent a flash back from any burner
to the plant. One of these traps shall be fitted as close to the plant as
possible. The plant and all pipes and valves shall be installed and maintained
free from leaks.
3. Generating building or room. - All plants for generating petrol gas from
petrol erected after the coming into force of the provisions specified in this
Schedule, shall be erected outside the factory building proper in a separate
well ventilated building (hereinafter referred to as the "generating building").
In the case of such plant erected before the coming into force of the
provisions specified in this Schedule there shall be no direct communication
between the room where such plants are erected (hereinafter referred to as
"the generating room") and the remainder of the factory building. So far as
practicable, all such generating rooms shall be constructed of fire resisting
materials.
4. Fire extinguishers. - An efficient means of extinguishing petrol fires shall
be maintained in an easily accessible position near the plant for generating
petrol gas from petrol.
5. Plant to be approved by Chief Inspector. - Petrol gas shall not be
manufactured except in a plant for generating petrol gas, the design and
construction of which has been approved by the Chief Inspector.Bihar Factories Rules, 1950

6. Escape of petrol. - Effective steps shall be taken to prevent petrol from
escaping into any drain or sewer.
7. Prohibition relating to smoking. - No person shall smoke or carry matches,
fire or naked light or other means of producing a naked light or spark in the
generating room or building or in the vicinity thereof and a warning notice in
the language understood by the majority of the workers shall be posted in
the factory prohibiting smoking and the carrying of matches, fire or naked
light or other means of producing a naked light or spark into such room or
building.
8. Access to petrol or container. - No unauthorised person shall have access
to any petrol or to a vessel containing or having actually contained petrol.
9. Electric fittings. - All electric fittings shall be of flame proof construction
and all electrical conductors shall either be enclosed in metal conduits or be
Lead sheathed.
10. Construction of doors. - All doors in the generating room or building shall
be constructed to open outwards or to slide and no door shall be locked or
obstructed or fastened in such a manner that it cannot be easily and
immediately opened from the inside while gas is being generated and any
person is working in the generating room or building.
11. Repair of containers. - No vessel that has contained petrol shall be
repaired in a generating room or building and no repairs to any such vessel
shall be undertaken unless live steam has been blown into the vessel and
until the interior is thoroughly steamed out or other equally effective steps
have been taken to ensure that it has been rendered free from petrol or
inflammable vapour.
12. Unless there be anything repugnant in the subject or context, the word
'petrol' wherever used in this Schedule includes 'dangerous petroleum' as
defined in the Petroleum Act, 1934.
13. The Chief Inspector may, with the previous approval of the State
Government, exempt any factory or plant from any of the provisions of this
Schedule subject to such conditions as may be specified in writing by theBihar Factories Rules, 1950

Chief Inspector. The exemption granted may, with the like approval, be
revoked at any time.
VIII
Cleaning for Smoothing, Roughening, etc., of Articles by a Jet of Sand, Metal Shot, or Grit, or Other
Abrasive Propelled by a Blast of Compressed Air or Steam.(Blasting Regulations)
1. Definitions. - For the purposes of this Schedule "Blasting" means cleaning,
smoothing, roughening or removing of any part of the surface of any article
by the use as an abrasive of a jet of sand, metal shot, or grit or other
material, propelled by a blast of compressed air or steam.
"Blasting enclosure" means a chamber, barrel, cabinet or any other enclosure designed for the
performance of blasting therein."Blasting chamber" means a blasting enclosure in which any person
may enter at any time in connection with any work or otherwise."Cleaning of castings" where done
as an incidental or supplemental process in connection with the making of metal castings, means
the freeing of the casting from adherent sand or other substance and include the removal of cores
and the general smoothening of a casting but does not include the freeing of castings from scales
formed during annealing or heat-treatment.
2. Prohibition of sand blasting. - Sand or any other substance containing free
silica shall not be introduced as an abrasive into any blasting apparatus and
shall not be used for blasting :
Provided that this clause shall come into force two years, after coming into operation of this
schedule.
3. Prohibition of employment of women and young persons. - No woman or
young person shall be employed or permitted to work at any operation of
sand blasting.
4. Precautions in connection with blasting operations. - (1) Blasting to be
done in blasting enclosure. - Blasting shall not be done except in a blasting
enclosure and no work other than blasting and any work immediately
incidental thereto and clearing and repairing of the enclosure including the
plants and appliances situated therein, shall be performed in a blasting
enclosure. Every door, aperture and joint of blasting enclosure shall be kept
closed and air-tight while blasting is being done therein.Bihar Factories Rules, 1950

(2)Maintenance of blasting enclosure. - Blasting enclosure shall always be maintained in good
condition and effective measure shall be taken to prevent dust escaping from such enclosures, and
from apparatus connected therewith, into the air of any room.(3)Provision of separating apparatus.
- There shall be provided and maintained for and in connection with every blasting enclosure
efficient apparatus for separating so far as practicable, abrasive which has been used for blasting
and which is to be used again as an abrasive, from dust or particles of other materials arising from
blasting; and no such abrasive shall be introduced into any blasting apparatus and used for blasting
until it has been so separated :Provided that this clause shall not apply, except in the case of blasting
chambers, to blasting enclosures constructed or installed before the coming into force of this
Schedule, if the Chief Inspector is of opinion that it is not reasonably practicable to provide such
separating apparatus.(4)Provision of ventilating plant. - There shall be provided and maintained in
connection with every blasting enclosure efficient ventilating plant to extract by exhaust draught
effected by mechanical means dust produced in the enclosure. The dust extracted and removed shall
be disposed of by such method and in such manner that it shall not escape into the air of any room
and every bag used for the settling of dust and every other filtering or setting device situated in a
room in which persons are employed, other than persons attending to such bag or other filtering or
setting device, shall be completely separated from the general air of that room in an enclosure
ventilated to the open air.(5)Operation of ventilating plant. - The ventilating plant provided for the
purpose of sub-paragraph (4) shall be kept in continuous operation whenever the blasting enclosure
is in use whether or not blasting is actually taking place therein, and in the case of a blasting
chamber, it shall be in operation even when any person in inside the chamber for the purpose of
cleaning or repairs.
5. Inspection and examination. - (1) Every blasting enclosure shall be
specially inspected by a competent person at least once in every week in
which it is used for blasting. Every blasting enclosure, the apparatus
connected therewith and the ventilating plant shall be thoroughly examined
and in the case of ventilating plant, tested by a competent person at least
once in every month.
(2)Particulars of the result of every such inspection, examination and test shall forthwith be entered
in a register and shall be available for inspection by any workman employed in or in connection with
blasting in the factory. Any defect found on any such inspection examination or test shall be
immediately reported by the person carrying out the inspection, examination or test to the occupier,
manager or other appropriate person and without prejudice to the foregoing requirements of this
Schedule, shall be removed without avoidable delay.
6. Provision of protective helmets, gauntlets and overalls. - (1) There shall be
provided and maintained for the use of all persons who are employed in a
blasting chamber whether in blasting or in any work connected therewith or
in cleaning such a chamber, protective helmets of type approved by a
certificate of the Chief Inspector, and every such person shall wear theBihar Factories Rules, 1950

helmet provided for this use whilst he is in the chamber and shall not remove
it until he is outside the chamber.
(2)Each protective helmet shall carry a distinguish mark indicating the person by whom it is
intended to be used and no person shall be allowed or required to wear a helmet not carrying his
mark or a helmet which has been worn by another person and has not since been thoroughly
disinfected.(3)Each protective helmet when in use shall be supplied with clean and not
unreasonably cold air at a rate of not less than six cubic feet per minute.(4)Suitable gauntlets and
overalls shall be provided for the use of all persons while performing blasting or assisting at blasting,
at every such person shall while so engaged wear the gauntlet and overall provided.
7. Precaution in connection with cleaning and other work. - (1) Where any
person is engaged upon cleaning of any blasting apparatus or blasting
enclosure or of any apparatus or ventilating plant connected therewith or the
surrounding thereof or upon any other work in connection with any blasting
apparatus or blasting enclosure or with any apparatus or ventilating plant
connected therewith so that he is exposed to the risk of inhaling dust which
has arisen from blasting all practicable measures shall be taken to prevent
such inhalation.
(2)In connection with any cleaning operation referred to in clause 5, and with the removal of dust
from filtering or settling devices all practicable measures shall be taken to dispose of the dust in
such a manner that it does not enter the air of any room. Vacuum cleaners shall be provided and
used wherever practicable for such cleaning operations.
8. Storage accommodation for protective wear. - Adequate and suitable
storage accommodation for the helmets, gauntlets and overalls required to
be provided by clause 5 shall be provided outside and conveniently near to
every blasting enclosure and such accommodation shall be kept clean.
Helmets, gauntlets and overalls when not in actual use shall be kept in this
accommodation.
9. Maintenance and cleaning of protective wear. - All helmets, gauntlets,
overalls and other protective devices or clothing provided and worn for the
purposes of this schedule shall be kept in good condition and so far as is
used. Where dust arising from the cleaning of such protective clothing or
devices is likely to be inhaled, all practicable measures shall be taken to
prevent such inhalation. Vacuum cleaners shall, whenever practicable, be
used for removing dust from such clothing and compressed air shall not beBihar Factories Rules, 1950

used for removing dust from any clothing.
10. Maintenance of vacuum cleaning plant. - Vacuum cleaning plant used for
the purpose of this schedule shall be properly maintained.
11. Restrictions in employment of young persons. - (1) No person under 18
years of age shall be employed in blasting or assisting at blasting or in any
blasting chamber or in the cleaning of any blasting apparatus or any blasting
enclosure or any apparatus or ventilating plant connected therewith or be
employed on maintenance or repair work at such apparatus, enclosure or
plant.
(2)No person under 18 years of age shall be employed in work regularly within twenty feet of any
blasting enclosure unless the enclosure is in a room and he is outside that room where he is
effectively separated from any dust coming from the enclosure.
12. Power to exempt or relax. - (1) If the Chief Inspector is satisfied that in
any factory or any class of factory, the use of sand or other substance
containing free silica as an abrasive in blasting is necessary for a particular
manufacture or process (other than the process incidental or supplemental
to making of metal castings) and that the manufacture or process cannot be
carried on without the use of such abrasive or that owning to the special
condition or special method of work or otherwise any requirement of this
Schedule can be suspended either temporarily or permanently, or can be
relaxed without endangering the health of the persons employed or that
application of any of such requirements is for any reason impracticable or
inappropriate, he may, with the previous sanction of the State Government,
by an order in writing exempt the said factory or class of factories from such
provisions of this Schedule, to such an extent and subject to such conditions
and for such period as may be specified in the said order.
(2)Where an exemption has been granted under sub-clause (1), a copy of the order shall be
displayed at a notice board at a prominent place at the main entrance or entrances to the factory,
and also at the place where the blasting is carried on.
IX
Liming and Tanning of Raw Hides and Skins and Processes Incidental theretoBihar Factories Rules, 1950

1. Cautionary notices. - (1) Cautionary notices as to anthrax in the form
specified by the Chief Inspector shall be affixed in prominent position in the
factory where they may easily and conveniently be read by the persons
employed.
(2)A copy of a warning notice as to anthrax in the form specified by the Chief Inspector shall be
given to each person employed when he is engaged and subsequently if still employed, on the first
day of each calendar year.(3)Cautionary notices as to the effect of chrome on the skin shall be affixed
in prominent positions in every factory in which Chrome solutions are used and such notices shall
be so placed as to be easily and conveniently read by the persons employed.(4)Notices shall be
affixed in prominent places in the factory stating the position of the "First Aid" box or cupboard and
the name of the person in charge of such box or cupboard.(5)If any person employed in the factory is
illiterate, effective steps shall be taken to explain carefully to such illiterate person the contents of
the notices specified in paragraphs 1, 2 and 4 and if Chrome solutions are used in the factory, the
contents of the notice specified in paragraph 3.
2. Protective clothing. - The occupier shall provide and maintain in good
condition the following articles of protective clothing :-
(a)waterproof footwear, leg coverings, aprons and rubber gloves for persons employed in processes
involving contact with chrome solutions including the preparation of such solutions;(b)protective
footwear, aprons and gloves for persons employed in the handling of hides or skins other than in
processes specified in clause (a):Provided that gloves shall not be required for persons fleshing by
hand or where there is no risk of contact with lime, sodium sulphide or other caustic liquor.
3. Washing facilities, mess-room and cloak-room. - There shall be provided
and maintained in a cleanly state and in good repair for the use of all persons
employed-
(a)a trough with a smooth impervious surface fitted with a waste-pipe without plug, and of sufficient
length to allow at least two feet for every ten persons employed at any one time, and having a
constant supply of water from taps or jets above the trough at intervals of not more than two feet;
or(b)at least one wash-basin for every ten such persons employed at any one time, fitted with a
waste pipe and plug and having a constant supply of water; together with, in either case, a sufficient
supply of nail brushes, soap or other suitable cleaning material and clean towels;(c)a suitable
mess-room adequate for the number remaining on the premises during the meal intervals, which
shall be furnished with (1) sufficient tables and benches and (2) adequate means for warming food
and for boiling water.The mess-room shall (1) be separate from any room or shed in which hides or
skins are stored, treated or manipulated, (2) be separate from the cloak-room and (3) be placed
under the charge of a responsible person;(d)suitable accommodation for clothing not worn during,
working hours with adequate arrangements for drying the clothing if wet. The accommodation so
provided shall be placed under the charge of a responsible person.Bihar Factories Rules, 1950

4. Food, drink, etc., prohibited in work-rooms. - No food, drink, 'pan' and
'supari' or tobacco shall be brought into or consumed by any worker in any
workroom or shed in which hides or skins are stored, treated or manipulated.
5. First aid arrangements. - The occupier shall-
(a)arrange for an inspection of the hands of all persons coming into contact with Chrome solution to
be made twice a week by a responsible person;(b)provide and maintain a sufficient supply of
suitable ointment and impermeable waterproof plaster in a box readily accessible to the workers and
used solely for the purpose of keeping the ointment and plaster.
X
Printing Presses and Type Foundaries - Certain Lead Process Carried Therein
1. Exemption. - Where the Chief Inspector is satisfied that all or any of the
provisions of this Schedule are not necessary for the protection of persons
employed, he may by a certificate in writing exempt any factory from all or
any of such provisions subject to such conditions as he may specify therein.
Such certificate may at any time be revoked by the Chief Inspector.
2. Definition. - In these regulations. -
"Lead Material" - 1. Means material containing not less than 5 per cent of Lead.
2. "Lead process" means. -
(a)The melting of Lead or any Lead material for casting and mechanical composing; and(b)the
re-charging of machines with used Lead material or(c)any other work including removal of dross
from melting pots, cleaning of plungers; and(d)manipulation, movement or other treatment of Lead
material."Efficient exhaust draught" means localised ventilation effected by heat or mechanical
means, for the removal of gas, vapour, fume or dust at the point where they originate.
3. "Exhaust draught". - None of the following processes shall be carried on
except with the efficient exhaust draught:-
(a)melting Lead material, or slugs;(b)heating Lead material, so that vapour containing Lead is given
off;unless carried on in such a manner as to prevent free escape of gas, vapour, fume or dust into
any place in which the work is carried on; orUnless carried on in electrically heated and
thermostatic-controlled melting pots. Such exhaust draught shall be effected by mechanical means
and as contrived as to operate on the dust, fume, gas or vapour given of as closely as may be at its
point of origin.Bihar Factories Rules, 1950

4. Prohibition relating to women and young persons. - No woman or young
person shall be employed or permitted to work in any Lead process.
5. Separation of certain processes. - Each of the following processes shall be
carried on in such a manner and under such conditions as to secure
effectual separation from one another and from any other process :-
(a)melting of Lead or any Lead material;(b)casting of Lead ingots;(c)mechanical composing.
6. Container for dross. - A suitable receptacle with tightly fitting cover shall
be provided and used for dross as it is removed from every melting pot. Such
receptacle shall be kept covered while in the work-room near the machine
except when the dross is being deposited therein.
7. Floor of work-room. - The floor of every work-room where the Lead
process is carried on shall be-
(a)of cement or of similar material so as to be smooth and impervious to water.(b)maintained in
sound condition; and(c)cleaned throughout daily after being thoroughly damped with water at a
time no other work is being carried on at the place.
8. Mess-room. - There shall be provided and maintained for the employees in
a Lead process and remaining on the premises during the meal intervals, a
suitable mess-room, which shall be furnished with sufficient tables and
benches.
9. Washing facilities. - There shall be provided and maintained in a cleanly
state and in good repair for the use of all persons employed in a Lead
process-
(a)(i)a trough with a smooth impervious surface, fitted with a water-pipe without plug, and of
sufficient length to allow at least two feet for every five such persons employed at any one time and
having a constant supply of water from taps or jets above the trough at intervals of not more than 2
feet; or(ii)at least one wash-basin for every five such persons employed at any one time, fitted with a
waste-pipe and plug and having an adequate supply of water laid on or always readily available;
or(b)a sufficient supply of clean towels made of suitable material, renewed daily with a sufficient
supply of soap or other suitable cleansing material.Bihar Factories Rules, 1950

10. Medical Examination. - (a) Every person employed in a Lead process shall
be examined by a Certifying Surgeon within 14 days on his first employment
in such processes and at intervals of not more than 3 months, and a record
of such examination shall be entered by the Certifying Surgeon in the form of
special certificate of fitness in Form No. 24.
(b)A health register containing names of all persons employed in a Lead process shall be kept in
Form No. 16.(c)No person after suspension shall be employed in a Lead process without the written
sanction from the Certifying Surgeon, entered in the health register.
11. Food, drinks, etc., prohibited in work-room. - No food, drink, 'pan' and
'supari' or tobacco shall be consumed or brought by any worker into any
workroom in which any Lead process is carried on.
XI
Manufacture of Pottery
1. Application. - This Schedule shall apply to all factories wherein
manufacture and decoration of pottery as hereinafter defined, and the
manufactures and processes, named below are carried on :-
(a)Calcining, crushing, grinding sieving of flint or quartz;(b)Mixing of flint or quartz with clay or
other materials in preparation of a pottery body;(c)Manufacture of lithographic transfers, frits or
glazes for use in the manufacture or decoration of pottery; and(d)Processes incidental to the
manufactures and processes mentioned above:Provided that these Rules shall not apply to factories
in which any of the following articles, but no other potteries are made :-(i)Unglazed or salt glazed
bricks and tiles; or(ii)Architectural terra-cotta made from plastic clay, either unglazed or glazed with
leadless glaze only :Provided further that these Rules shall be in addition to and not in derogation of
any of the provisions of the Factories Act, 1948 or any other Rules made thereunder or any other Act
or Rules.
2. Definitions. - For the purposes of this Schedule-
(i)"Pottery" includes earthen ware, stone ware, porcelain, china tiles and any other articles made
from clay or from a mixture containing clay and other materials;(ii)"Potter's Shop" includes all
places where a pottery is formed by pressing or by any other process and all places where fettling,
shaping or other treatment of pottery articles prior to placing for the biscuit ware is carried
on;(iii)"Fettling" includes scalloping, towing, sand-papering, sand-sticking and any other process of
fettling and cleaning of pottery;(iv)"Moist method" when this expression is used in relation to
cleaning, means a method of cleaning in which damp saw-dust or other suitable damp material isBihar Factories Rules, 1950

used and which prevents dust from rising into the air during the cleaning process;(v)"Stopping of
biscuit ware" means the filling up of cracks in ware which has been fired but to which glaze has not
been applied.(vi)"Thimble picking" means the picking over, sorting or re-arranging for further use
of thimbles, stilts, spurs, strips, saddles or any similar articles which has been used for the support
of pottery articles during the process of glost firing.(vii)"Wedging of clay" means the treatment of
clay which has not been pugged or rolled, by raising one piece of clay by hand and bringing it down
upon another piece; but does not include the process, frequently known as "slopping of clay" in
which two pieces of clay each small enough to be held in one hand are slopped
together;(viii)"Leadless glaze" means a glaze which does not contain more than one per cent of its
dry weight of a lead compound calculated as Lead monoxide, when determined in the manner as
specified in the definition of "low solubility glaze".(ix)"Low solubility glaze" means a glaze which
does not yield to dilute hydrochloric acid more than five per cent of its dry weight of a soluble Lead
compound calculated as Lead monoxide when determined in the manner described below :-A
weighed quantity of the material which has been dried at 100°C and thoroughly mixed shall be
continuously shaken for one hour, at the common temperature with 1,000 times its weight of an
aqueous solution of hydrochloric acid containing 0.25 per cent by weight of hydrogen chloride. This
solution shall thereafter be allowed to stand for one hour and filtered. The Lead salt contained in the
clear filtrate shall then be precipitated as Lead Sulphide and weighed as Lead Sulphate;(x)"Ware
cleaning" means the removal of surplus glaze from ware after the application of the glaze but before
glost firing and includes panel-cutting;(xi)"Lithographic transfer making" includes the wiping of
colour and subsequent brushing of transfer sheets;(xii)"Flint or quartz milling" includes the
calcining of flint and the sieving, crushing, grinding or any other manipulation of flint and quartz in,
or incidental to the manufacture of ground flint or quartz;(xiii)"Ground or powdered flint or quartz"
does not include natural sands;(xiv)"Efficient Exhaust draught" means localised ventilation effected
by mechanical or other means, for the removal of gas, vapour, dust or fumes so as to prevent it from
escaping into the air of any place in which work is carried on. No arrangement or device shall be
deemed efficient which fails to remove effectively the gas, vapour, dust or fumes generated at the
point where it originates, and which permits the substance removed to escape into or re-enter the
same or any other work place either directly or indirectly;(xv)"Damp fettling" means fettling done
either-(a)wholly with a wet sponge or any other suitable wet material, or(b)while they were being
fettled is still so damp that no dust is given off,(xvi)"Slip house" includes any place where plunging
is carried on;(xvii)"Flintless stoneware" means stoneware the body of which consists of natural clay
to which no flint or quartz or other form of free silica has been added;(xviii)"Flow material" means
any material which contains a Lead compound and which is placed in saggars with a view to its
entire or a partial volatilisation during the glost firing of the ware;(xix)"Galena" means the native
sulphide of Lead containing not more than five percent of soluble Lead compound calculated as
Lead monoxide when determined in the manner described in the definition of low(xx)"Glaze" does
not include an engobe or slip;(xxi)"Glost placing" includes-(i)the placing of ware coated with unfired
glaze on to cranks or similar articles prior to their transference to saggars, trucks, ovens or kilns for
glost firing;(ii)the placing of such ware into saggars or on to trucks or on to oven-conveyors;(iii)the
placing of saggars containing such ware into ovens or kilns or on to trucks; and(iv)the removal and
carrying of saggars or cranks from the oven, kiln or truck after glost firing except in the case of
tunnel ovens.Bihar Factories Rules, 1950

3. Exhaust Draught. - (1) The following processes shall not be carried on
without the use of an efficient exhaust draught:-
(i)all processes involving the manipulation or use of a dry and unfritted Lead compound;(ii)fettling
operation of any kind, whether on green ware or biscuit, provided that this shall not apply to the wet
fettling and to the occasional finishing of pottery articles without the aid of mechanical
power;(iii)sifting of clay dust or any other material for making tiles or other articles by pressure,
except where-(a)this is done in a machine so enclosed as to effectively prevent the escape of dust;
or(b)the material to be sifted is so damp that no dust can be given off;(iv)pressing of tiles from clay
dust, an exhaust opening being connected with each press, this clause shall also apply to the
pressing from clay dust of articles other than tiles, unless the material is so damp that dust is given
off;(v)fettling of tiles made from clay dust by pressure, except where the fettling is done wholly on,
or with, damp material, this clause shall apply to the fettling or other articles made from clay dust,
unless the material is so damp that no dust is given off;(vi)process of loading and unloading of
saggars where handling and manipulation of ground and powered flint, quartz, alumina or other
materials are involved;(vii)brushing of earthen ware biscuit, unless the process is carried on in a
room provided with efficient general mechanical ventilation or other ventilation which is certified by
the Inspector of Factories as adequate, having regard to all the circumstances of the
case;(viii)fettling of biscuit ware which has been fired in powdered flint or quartz except where this
is done in a machine so enclosed as to effectively prevent the escape of dust;(ix)ware cleaning after
the application of glaze by dipping or other process;(x)crushing and dry grinding of materials for
pottery bodies and saggars unless carried on in machines so enclosed as to effectively prevent the
escape of dust or is so damp that no dust can be given off;(xi)sieving or manipulation of powered
flint, quartz, clay grog, or mixture of these materials unless it is so damp that no dust can be given
off;(xii)grinding of tiles on a power driven wheel unless an efficient water spray is used on the
wheel;(xiii)lifting and conveying materials by elevators and conveyors unless they are effectively
enclosed and so arranged as to prevent escape of dust into the air or near to any place in which
persons are employed;(xiv)preparation or weighing out of flow material, lawning of dry colours,
colour dusting and colour blowing;(xv)mould making unless the bins or similar receptacles used for
holding plaster of paris are provided with suitable covers;(xvi)manipulation of calcined material
unless the material has been made and remains so wet that no dust is given off;(xvii)fettling other
than damp fettling;(xviii)placing of china for the biscuit fire if alumina or other powdered material
is used;(xix)emptying of china biscuit flatware from saggars after firing in alumina or other
powdered materials;(xx)sieving of alumina or other powdered placing material;(xxi)processes using
alumina or other powdered substance as placing materials;(xxii)polishing of ware;(xxiii)grinding of
ware on a dry sand-stone wheel;(xxiv)sorting of glost ware with a power driven tool;(xxv)ground
laying or colour dusting, or the wiping off, of colour after either of those processes.(2)Every process
for which an exhaust draught is required shall be carried on inside a suitable hood.(3)Air discharged
from exhaust ventilating plant used in connection with any of the processes specified in clause 3 (1)
shall, whether or not it has been passed through dust collecting apparatus, be discharged directly
into the open air from where it is not liable to be drawn into the air of any work-room.Bihar Factories Rules, 1950

4. Each of following processes shall be carried on in such a manner and
under such condition as to secure effectual separation from one another, and
from other wet processes :-
(a)Crushing and dry grinding or sieving of materials, fettling, pressing of tiles, drying of clay and
greenware, loading and un- loading saggars;(b)all processes involving the use of a dry Lead
compound.
5. Every slip hose shall for the purpose of excluding dust be effectively
separated from-
(a)any place in which clay is dried;(b)any place in which clay is taken from a drier; and(c)any place
in which the dry grinding or sieving of materials for pottery bodies is carried on.
6. Any glaze which is not a Leadless glaze or low solubility glaze shall not be
used in a factory in which pottery is manufactured.
7. No woman or young person shall be employed or allowed to work in any of
the operations specified in clause 3 (1) or at any place where such operations
are carried on in the following processes :-
(i)the wedging of clay :(ii)wheel turning for a thrower of wheel turning for pressing tiles;
8. The potter's wheel (Jolly and Jigger) shall be provided with screens or so
constructed as to prevent clay scrapings being thrown off beyond the wheel.
9.
(1)All possible measures shall be taken by damping or otherwise to prevent dust arising during
cleaning of floors and wall.(2)Damp saw dust or other suitable material shall be used to render the
moist method effective in preventing dust arising into the air during the cleaning process which
shall be carried out after work has ceased.(3)All materials for thimble picking which is collected
from floors or workbenches shall be riddled in an enclosed receptacle before it is taken to the place
where thimble picking is to be done.(4)The following requirements shall apply to potter's shops and
to any other place where clay is dried or clay dust is prepared :-All parts of beams, ledges, and
fixtures, more than six feet six inches above the floor shall be cleaned at least once in every period of
six months with an efficient vacuum cleaning apparatus or by some other effective and suitable
method, and not by sweeping.Bihar Factories Rules, 1950

10.
(1)The floors of potters shops, slip houses, dipping houses, ware cleaning rooms, such drying stoves
as are entered by work people and the floors of all places where sieving, crushing or grinding of flint
and quartz is carried on shall:-(i)be smooth and impervious;(ii)be kept in good repair so that they
can be properly cleaned by a moist method and so that no dust can fall through into any room
below;(iii)be capable of being swilled or washed.(2)All the floors shall be cleaned either:-(i)daily by
a moist or wet method after work has ceased for the day and two hours before the hour of starting of
the work the following day, or(ii)daily with an efficient vacuum cleaner.
11.
(1)All persons employed in any process included under clause 3 shall be examined by the Certifying
Surgeon within seven days preceding or following the date of their first employment in the factory in
such process; thereafter all persons employed in any process included in sub-clauses (i) and (xiv) of
clause 3 shall be examined by the Certifying Surgeon once in every three calendar months and those
employed in any process included in sub-clauses (ii) to (xiii) and (xv) and(xvi)of clause 3 once in
every [12 months] [Substituted for '12 months' by S.O. 593, dated 11.6.1971.] by the Certifying
Surgeon. Records of such examinations shall be entered by the Certifying Surgeon in the Health
Register.(1A)[ X'ray examination of the chest of every worker employed in any process specified in
sub-clauses (ii) to (xiii), (xv) and (xvi) of clause 3 shall be carried out:-(i)if he is already in
employment the date on which this Rule comes into force, within six months of the said date, and at
an interval of every three years thereafter: and(ii)if he is employed after the date on which this Rules
comes into force, within six months of the said date, and at an interval of every three years
thereafter.The result of every X'ray examination along with the X'ray plate shall be produced before
the Certifying Surgeon within a month of the said examination.] [Added by S.O. 593, dated
11.6.1971.](1B)[ Without any prejudice to the provision of sub-clause (1A) if the Certifying Surgeon
during the course of the medical examination of any worker has any reason to suspect that the said
worker had been affected or was being affected by any chest diseases he may direct the manager or
the occupier in writing to get the said workers X'rayed and to produce the result of the X'ray
examination along with X'ray plate within a specified time.] [Substituted for '12 months' by S.O.
593, dated 11.6.1971.](1C)[ If as a result of the general medical examination or of the X'ray
examination, the Certifying Surgeon is of the opinion that any special or expert clinical or
pathological or any other special examination or test is necessary to diagnose or to determine
whether or not the worker had been affected or was being affected by any diseases arising out of his
occupation or to protect the health of the worker, he may direct the manager or the occupier in
writing to get any such examination or test carried out and to produce the report and the result
thereof within a specified time.] [Substituted for '12 months' by S.O. 593, dated 11.6.1971.]It shall be
the duty of the manager or the occupier as the case may be to carry out the direction given by the
Certifying Surgeon under sub-clause (1B) and (1C)(2)If at any time the Certifying Surgeon is of
opinion that any person employed in any process specified in clause 3 is no longer fit for
employment on the ground that continuance would involve damage to his health, he shall make an
entry to that effect in the Health Register.(3)Any person who has been declared unfit by the
Certifying Surgeon at any time shall not be re-employed without written sanction from theBihar Factories Rules, 1950

Certifying Surgeon and entered in the Health Register.(4)A worker declared unfit by the Certifying
Surgeon may be employed only in such other process or works as may be specified by the Certifying
Surgeon.
12.
(1)The occupier shall provide and maintain suitable overalls and head coverings for all persons
employed in processes included under clause 3.(2)The occupier shall provide and maintain suitable
aprons of water-proof or similar materials, which can be sponged daily, for the use of the dipper,
dipper's assistants, throwers, jolly workers' casters, mould makers and filter press and pug mill
workers.(3)No person shall be allowed to work in emptying sacks of dusty materials, weighing out
and mixing of dusty materials and charging of ball mills and blungers without wearing a suitable
and efficient dust respirator which shall be supplied by the occupier.
13. Before each meal and before the end of the day's work at least ten
minutes, in addition to the regular rest interval for meals, shall be allowed for
washing to each person employed in any of the processes included under
clause (3)
14. No food, drink, 'pan' and 'supari', or tobacco shall be brought into, or
consumed by any worker in any work-place in which any of the processes
included under clause 3 are carried on and no person shall remain in any
such work-place during intervals for meals or rest.
15. There shall be provided and maintained for the use of all persons
employed in any of the processes included under clause 3-
(a)a cloak-room for clothings put off during working hours. It shall be outside any room in which is
carried on any of the processes included under clause 3, and shall be enclosed from the general air of
any such room;(b)separate and suitable arrangements for accommodation of protective clothing and
equipment provided under clause 12.
16. Every drying stove, dryer and mangle shall be so ventilated that there is
no flow of hot air from the stove, dryer or mangle into any place where any
person works, the drying of pottery articles shall be carried out in rooms set
apart for that purpose.
17. In all potter's shops and in all drying stoves which are entered by work
people, boxes shall be provided for the reception of clay scraps and broken
ware.Bihar Factories Rules, 1950

18. Washing facilities. - The occupier shall provide and maintain, in a cleanly
state and in good repair, for the use of all persons employed in any of the
processes specified in clause 3 a wash place under cover; with either:-
(a)(i)a trough with smooth impervious surface fitted with a waste pipe, without plug, and of
sufficient length to allow at least two feet for every five such persons employed at any one time and
having a constant supply of clean water from taps or jets above the trough at intervals of not more
than two feet; or(ii)at least one tap or stand pipe for every five such persons employed at any one
time, and having a constant supply of clean water, the tap or stand pipe being spaced not less than 4
feet apart; and(b)a sufficient supply of clean towels made of suitable material changed daily, with
sufficient supply of nail brush and soap.
19. Mess-room. - (1) There shall be provided and maintained for use of all
persons remaining within the premises during the rest intervals, a suitable
mess-room providing accommodation of 10 square feet per head and
furnished with. -
(i)a sufficient number of tables and chairs or benches with back rest;(ii)arrangements for washing
utensils;(iii)adequate means for warming food; and(iv)adequate quantity of drinking water.(2)The
room shall be adequately ventilated by the circulation of fresh air, placed under the charge of a
responsible person and shall be kept clean.
20. If in respect of any factory the Chief Inspector of Factories is satisfied
that all or any of the provisions of this schedule are not necessary for the
protection of the persons employed in such factory he may by an order in
writing exempt such factory from all or any of such provisions, subject to
such conditions as he may specify therein. Such order may at any time be
revoked by the Chief Inspector of Factories without assigning any reason.
XII
Manufacture of Articles from Refractory Materials
1. Application. - This Schedule shall apply to the following processes :-
(1)handling, moving, breaking, crushing, grinding or sieving of any refractory materials, containing
not less than 25 percent total silica for the purpose of manufacture. -(a)of articles used in the
construction of furnaces and flues;(b)of crucibles; and(c)of compositions or other material's used in
the preparation of moulds in which metals are cast; or(2)any process in the manufacture of
refractory bricks as hereinafter defined:Provided that nothing in this Schedule shall apply-(a)to
handling, moving, mixing or sieving of natural sand; or(b)to the manipulation of rotten rock in theBihar Factories Rules, 1950

preparation of moulds used in metal foundries :Provided further that if the Chief Inspector of
Factories is satisfied in respect of any factory or part thereof that owing to the special conditions of
work or otherwise, any of the requirements of this Schedule can be suspended or relaxed without
any danger to the health of the persons employed therein, he may by an order in writing grant such
suspension or relaxation for such period and on such conditions as he may think fit. Any such order
may be revoked at any time.
2. Definitions. - (a) "Refractory material" means any refractory material
containing not less than 25 per cent total Silica.
(b)"Refractory brick" means any brick or article composed of refractory material and containing not
less than 25 per cent total Silica.(c)"Efficient exhaust draught" means localised ventilation by
mechanical means for the removal of dust so as to prevent dust from escaping into the air of any
place in which work is carried on. No draught shall be deemed to be efficient which fails to remove
the dust produced at the point where such dust originates.
3. No refractory material shall be broken in pieces by manual labour unless
the process is carried out in the open air:
Provided that where it is not practicable to carry out this process in open air, the process shall be
carried out under an efficient exhaust draught.
4. No refractory material unless it is so wet that dust will not be produced,
shall be crushed or ground in a stone crushing or a grinding machine unless
such machine is provided with-
(a)an efficient exhaust draught and efficient dust collecting appliances; or(b)an efficient water or
steam spray :Provided that every grinding machine wherein any refractory material is ground in dry
state, shall be, totally enclosed and connected to a mechanical exhaust system so as to prevent
effectively and escape of dust outside the casting of the machine by maintaining a pressure below
the atmospheric pressure within the casting of the machine :Provided further that all processes of
crushing and grinding shall be effectively isolated from other processes.
5. All chutes, conveyors, elevators, screens, sieves and mixers used for
manipulating refractory material shall, unless that material is so wet that dust
will not be produced, be enclosed and be provided with efficient exhaust
draught.
6. No refractory material be so dry as to produce dust shall-
(a)be loaded into any wagon or other receptacle for transport unless it has been placed in a suitable
dust-proof container so damped as to preclude dust; or(b)be unloaded from any wagon or otherBihar Factories Rules, 1950

receptacle for transport unless it has been so damped as to preclude dust or unless the work is done
under an efficient exhaust draught;(c)be shovelled or raked or otherwise manipulated by means of
hand tools in any manufacturing process unless it has been so damped as to preclude dust or unless
the work is done under an efficient exhaust draught:Provided that paragraph (b) of this Rule shall
not apply to refractory material in the form of rock or pebbles before it is manipulated in any
manufacturing process.
7. (a) The floors of all places where refractory bricks are dried, other than the
floors of tunnel ovens or chamber driers not normally entered by person
employed shall after each lot of refractory bricks has been removed, be
carefully cleaned of all debris and the part being cleaned shall be kept damp
while the cleaning is being done.
(b)There shall be provided in every such place a constant supply of water laid on under adequate
pressure with sufficient connections and a flexible branch pipe and sprinkler to enable water to be
supplied directly to every part of the floor.
8. No drying stoves in which refractory bricks are baked by fires before being
placed in the kilns shall be used.
9. The surface of every floor or place where persons are liable to pass shall
be cleaned of debris of refractory material once at least during each daily
period of employment or where shifts are worked, once during each shift.
Such debris unless it is immediately required for use in the process shall be
effectively damped and either be placed in covered receptacles, or be
otherwise stored in such manner as to prevent the escape of dust into the air
in or near to any place where any person is employed.
10. Where plates are used, whether portable or forming part of the floor, on
which refractory bricks are dried, such plates shall be freed from adherent
material only by a wet method or by such other method as will prevent the
escape of dust into the air.
11. The dust or powder of refractory materials shall not be used for
sprinkling the moulds in refractory brick making :
Provided that nothing in this paragraph shall be deemed to prevent the use of natural sand for the
purpose of sprinkling the moulds.Bihar Factories Rules, 1950

12. No worker shall be allowed to work on any dusty process or at any place
where dust of any refractory materials is present in the atmosphere:
Provided that in an emergency, a worker may be allowed to work at such process or place if he wears
a suitable and efficient dust mask or breathing apparatus.
13. Medical examination. - (a) Every worker employed on any of the
processes specified in sub-paragraphs (1) and (2) of paragraph 1 shall be
medically examined in such manner and at such intervals as may be
specified by any Rules made under the Workmen's Compensation Act, 1923
(VIII of 1923) or if no such Rules have been framed under the said Act, every
such worker shall be medically examined by the Certifying Surgeon before
employment on any of the aforesaid processes and at intervals not
exceeding six months thereafter.
(b)Subject to sub-paragraph (c), an X'ray examination of the chest of every worker referred to in
sub-paragraph (a) shall be carried out-(i)if he is already in employment on the date of coming into
force of the sub-paragraph, within six months of such date and at an interval of every three years
thereafter;(ii)if he is employed after such date within one month of the date of his employment and
at an interval of every three years thereafter;and the result of every such X'ray examination shall be
produced before the Certifying Surgeon within a month of the examination.(c)If the Certifying
Surgeon, during the course of medical examination of any worker under sub-paragraph (a), has
reason to suspect onset of any chest disease, he may direct the manager or the occupier to get an
X'ray examination of the worker done and to produce the X'ray plate before him within a specified
time and on receipt of such direction the manager or the occupier, as the case may be, shall carry out
the direction.(d)The Certifying Surgeon shall grant to each worker examined a certificate specifying
therein whether or not the worker was considered fit to be employed on any of the aforesaid
processes.(e)The manager shall maintain a register in which the findings and recommendations of
the Certifying Surgeon in respect of every worker and in respect of every medical examination shall
be maintained duly signed by the Certifying Surgeon.(f)A worker not declared fit shall not be
employed on any of the aforesaid processes and he shall be employed on only such other process or
he shall be subjected to such other examination or treatment as may be directed by the Certifying
Surgeon.(g)No fees shall be charged from any worker for the medical examination and it shall be the
responsibility of the occupier and the manager to comply with the provisions of this Schedule.
14. In case any existing plant or machinery needs alteration, modification or
replacement or in case any new plant is required to be installed, to comply
with the requirements of this Schedule, such alteration, modification,
replacement or installation of the plant or machinery shall be carried on
within a period not exceeding one year from the date of publication of this
Rule:Bihar Factories Rules, 1950

Provided that the Chief Inspector of Factories in consideration of special and exceptional
circumstances by an order in writing may extend this period for such reasonable length of time as he
may think fit.
XIII
Part I – Chemical Works
1. Application. - This Schedule shall apply to all factories wherein, the
operations specified in clause (13) of sub rule (1) of Rule-95 are carried on.
These Rules shall be in addition to and not in derogation of any provisions of
the Factories Act, 1948 or any other Rules made thereunder, or any other Act
or Rules.
2. Definitions. - In this Schedule, unless there is anything repugnant in the
subject or context:-
(i)"Chemical works" means any factory or part of any factory in which any Chemical process is
carried on.(ii)"Chemical process" means manufacture, recovery, handling or storing of chemicals or
any other process in which any chemical is used.(iii)"Breathing apparatus" means a helmet of
face-piece with necessary connections by means of which, a person using it in a poisonous,
asphyxiating or irritant atmosphere breathes ordinary air, or any other suitable apparatus approved
in writing by the Chief Inspector.(iv)"Life belt" means a belt made of leather or other suitable
materials which can be securely fastend round the body, with a suitable length of rope-attached to it,
each of which is sufficiently strong to sustain the weight of a man, and the stresses caused due to the
impact caused by the fall of a man.(v)"Efficient exhaust draught" means localised ventilation
effected by mechanical or other means, for the removal of gas, vapour, dust or fumes so as to
prevent it from escaping into the air of any place in which work is carried on. No arrangement or
device shall be deemed efficient which fails to remove effectively the gas, vapour dust or fumes
generated at the point where it originates, and which permits the substance removed to escape into
or re-enter the same or any other work place either directly or indirectly.(vi)"Surgeon" means a
Certifying Surgeon appointed under Section 10 of the Factories Act, 1948.(vii)"Suspension" means
suspension by written certificate in the Health Register, signed by the Surgeon, from employment in
any process mentioned in the certificate.(vii)"Bleaching powder" means the bleaching powder
commonly called chloride of lime;(ix)"Chlorate" means chlorate or perchlorate;(x)"Caustic" means
hydroxide of Potassium or Sodium;(xi)"Caustic pot" means a metal pot fixed over a furnace or flue
used for concentrating or boiling caustic liquor or any other liquor.(xii)"Chrome process' means
manufacture of Chromate or Bichromate of Potassium, or Sodium, or the manipulation, movement
or other treatment of these substances in connection with their manufacture and use.(xiii)"Nitro or
Amino process' means the manufacture of nitro or amino derivatives of Phenol and of Benzene or its
homologues, and the making of explosive with the use of any of these substances.Bihar Factories Rules, 1950

3. Exception. - If the Chief Inspector is satisfied in respect of any factory or
any process that, owing to the special conditions or special methods of
works, or for any other reason all or any of the requirements of this Schedule
are not necessary for the protection of persons employed in any factory or
process, he may by an order in writing exempt such factory or process from
all or any of the provisions of this Schedule, subject to such conditions as he
may by such order specify.
He may in his discretion at any time revoke whole or part of such order.
4. Register and records. - All registers and records required to be maintained
under this Schedule shall be maintained in the factory in a suitable form or in
such form as may be prescribed or directed by the Chief Inspector and shall
be produced before an Inspector, whenever required to do so.
Part II – General
5. The provisions of Part II of this Schedule shall apply to all chemical works
specified in Appendix I attached to the Schedule.
6. House keeping. - (a) Every part of the ways, works, machinery and plant
shall be maintained in a clean and tidy condition.
(b)Any spillage of materials shall be cleaned up without delay.(c)Floors, platforms, stairways,
passages and gangways shall be kept free of any obstruction whether permanent or
temporary.(d)There shall be provided easy means of access to all parts of the plant and adequate
and proper implements to facilitate cleaning, maintenance and repair.
7. Improper use of chemicals. - (a) No chemical or solvent shall be used by
any worker for any purpose other than the process for which it is supplied.
(b)Workers shall be instructed on the possible dangers arising from such misuse. These instructions
shall further be displayed in bold letters in prominent places in the different Sections of the works.
8. Storage and use of food and testing of materials used in any chemical
process. - (a) No food, drink, tobacco, "pan" or "Supari" or similar article
shall be stored or consumed on or near any place where any chemical
process is carried on.Bihar Factories Rules, 1950

(b)Workers shall be instructed on the possible dangers arising from testing of any material used in
any chemical process or of the use for drinking purposes of any vessel or container used in, or in
connection with any chemical process. These instructions shall further be displayed in bold letters in
prominent places in the different Sections of the work.
9. Process hazards. - (a) Before commencing any experimental work pilot
project, or any new chemical process, adequate steps shall be taken to
ascertain definitely all the hazards involved, both in actual operation and in
the chemical reactions. The properties of the raw materials used, the final
products to be made, the middle products and any bye-products arising shall
be carefully studied and adequate precautions shall be taken for dealing with
any hazards including effects thereof on the workers. In the design and
layout of the buildings and plants, adequate provisions shall be made to
guard against any hazards.
(b)The Chief Inspector shall be informed in writing about the commencement of the operation of
any pilot or experimental plant or process, and safety of persons exposed to the hazards likely to
arise therefrom mentioned in sub-clause (a) shall be ensured, and where necessary advice shall be
obtained from the Chief Inspector on measures to be taken in this regard.
10. Unauthorised personnel. - (a) Unauthorised persons shall not be
permitted to enter any Section of a chemical works where there is any special
danger.
(b)Visitors shall be provided, where necessary, with suitable safety equipments and shall be
accompanied around dangerous plants by a responsible person of the factory.
11. Instruments. - All instruments, such as pressure gauges, thermometers,
flow-meters, weighing machines, etc., shall be tested at regular intervals by a
competent person and records of these tests shall be kept in a register.
12. Cocks and valves. - Suitable and easily accessible valves shall be
provided in all service lines at sufficiently short intervals for convenience in
blanking off etc. All cocks and valves shall be operated at least once in a
month and tested periodically by a competent person, and records of these
tests shall be kept in a register. A plan of all service installations shall be
kept readily available.Bihar Factories Rules, 1950

13. Man-holes. - No man-holes shall be opened for entry until effective
fencing has been erected round it.
14. Emergency instructions.- Special instructions in simple language shall be
framed to ensure that effective measures may be carried out in cases of
emergency, to deal with escape of inflammable poisonous or deleterious
gases, vapours, liquids or dust. These instructions shall be further displayed
in bold letters at prominent places in the different Section of the works. All
workers shall be trained and instructed in the action to be taken in such
emergencies.
15. Protection of reaction mixtures. - Suitable arrangements shall be made to
ensure that no foreign matter of any short can fall in to reaction mixtures.
16. Electrical apparatus. - Electrical plant, fittings and conductors shall, if
exposed to a damp or corrosive atmosphere, be adequately protected.
Periodic tests shall be carried out on all electrical circuits to detect any
defect or fault and any defect or fault detected shall be removed immediately.
17. Place of work. - (a) Workers shall be allowed only in those places in which
they have been given orders to work.
(b)In dangerous Sections of a factory the number of workers shall be kept to a minimum compatible
with the process.
18. Packing, storage and transport of chemicals. - (a) Chemicals shall be
packed and stored in containers suitable for the purpose and of adequate
strength for storage or transport. All such container shall be stored and
transported in such a manner as to ensure that, in the event of a spillage they
will neither produce a reacting mixture, nor cause the development of toxic
or fire risk in contact with other materials in its vicinity, or with walls, floors
or dust therein.
(b)No corrosive chemical or substance shall be stored or transported except in containers of a
suitable material upon which the corrosive substance may have no chemical action, of adequate
strength and of suitable design and construction and no such container shall be transported, carried
or moved from one place to other except in crates or receptacles of adequate strength and suitable
design and construction.(c)Crates or receptacles for containers with a capacity of 11.5 litres (2.5
gallons) or more and containing any corrosive substance shall be transported or moved from oneBihar Factories Rules, 1950

place to other on suitable rubber wheeled-trucks or trolleys or any other device approved by the
Inspector;Provided that such containers, crates and receptacles may be carried manually by not less
than two persons, at a height below the waist-line of the persons carrying and by means of a suitable
and adequate device designed and constructed for the purpose.(d)On every container containing any
chemical substance a label shall be securely affixed and attached mentioning clearly and legibly in
bold letters the name of chemical:Provided that if there is any Indian Standard of labelling of such
containers the same shall be adopted.(e)If in the opinion of an Inspector the system of storage and
transport of any chemical is not safe, he may direct such system and devices to be used as he may
consider safe and desirable.Fire and Explosion Risk
19. Isolation of building and site and fire resistance. - (a) Buildings and plants
shall be sited with due regards to the dangers which may arise from the
processes involved and in particular shall be spaced at a distance which are
deemed safe for the fire and explosion risk connected with the processes in
adjacent buildings. Consideration shall be given to the effect of any process
carried out in adjacent factories or plants.
(b)Where special dangers exist separate buildings shall be used for the different parts of a process.
They shall be spaced at sufficient distances apart and shielded to prevent damage to each other on
the event of fire or explosion, and shall be safe-guarded by the provision of suitable blow-out panel
or roofs. Where the risk of fire or explosion is considerable, the building shall be divided by blast or
protective screen walls.(c)No combustible materials shall be used in the erection of working
buildings, unless there are special reasons necessitating their use, in which case they shall be of light
fire resistant construction, and floors shall be of impervious fire-resistant material and shall be
regularly maintained in such condition.
20. Dangers of ignition (including lighting installation). - (a) No internal
combustion engine, and no electric motor or other electric equipment,
capable of generating sparks or otherwise causing combustion shall be
installed or used in a building or danger zone. Electric conductor shall be
encased in screwed steel conduit.
(b)All hot exhaust pipe shall be installed outside a building and other hot pipes inside the plant be
suitably protected.(c)Portable electric lamps shall not be used, unless of an intrinsically safe type,
and portable electric tools connected by flexible wires shall not be used unless of the flame proof
type.(d)Where an inflammable atmosphere may occur, the soles of foot wear worn by workers shall
have no metal on them, and the wheels of trucks, or conveyors shall be of a material which shall be a
good conductor and non sparking. Adequate precautions shall be taken to prevent the ignition of
explosive or inflammable substances by sparks emitted from locomotives or other vehicles operated
in the factory or on public lines.(e)No electric arc lamp or naked light, fixed or portable, shall be
used, and no person shall have in his possession any match or any apparatus of any kind for
producing a naked light or spark in, or on, or about any part of the factory, where there is anyBihar Factories Rules, 1950

likelihood of fire or explosion from inflammable gas, vapour or dust, and all incandescent electric
lights in such parts shall be in double air tight glass covers.(f)Prominent notice in the language
understood by the majority of the workers and legible by day and by night, prohibiting smoking, the
use of naked lights and the carrying of matches or any apparatus for producing a naked light or
spark, shall be affixed at the entrance of every room or place where there is any risk of fire or
explosion from inflammable gas, vapour or dust. In the case of illiterate workers the contents of the
notices shall be fully and carefully explained to them when they commence work in the factory for
the first time and again when they have completed one week at the factory.(g)A sufficient supply of
spades, scrapers and pails made from non-sparking materials shall be provided for the use of
persons employed in cleaning out or removing residue from any chamber, still tank or any other
vessel wherein there may be risk of ignition or explosion, or in cleaning or removing any substance
which may cause evolution of Arseniretted hydrogen or any other substance which may be
inflammable or likely to cause explosion, and in no case any tool other than non-sparking tool shall
be used on any such work or, while undertaking any repair or maintenance work at any such place
or plant.Note. - The risk is not always obvious and may arise, for example through the production of
hydrogen or other explosive substances in acid tanks.
21. Static electricity and lightening protection. - (a) All pipe lines and belts
and other machinery and plants on which static electricity is likely to
accumulate, shall be effectively earthed. Receptacles for inflammable liquids
shall have metallic connections to the earthed supply tanks to prevent
sparking of static electricity. Where necessary humidity shall be controlled.
(b)Mobile tank wagons shall be earthed during filling and discharge, and precautions shall be taken
to ensure that earthing is effective before such filling or discharge takes place.(c)Lightening
protection apparatus shall be fitted where necessary, and shall be maintained in good condition.
22. Process heating. - The method of providing heat for a process shall be as
safe as possible and where the use of naked flame is unavoidable the plant
shall be so constructed as to prevent any escaping inflammable gas, vapour,
or dust coming into contact with the flame, or exhaust gases, or other hot
agency likely to cause ignition and, unless impracticable, the heating
medium shall be automatically controlled at a pre-determined temperature
below the danger temperature.
23. Escape of materials. - (a) Provision shall be made in all plants, sewers
drains, flues, ducts, culverts and burried pipes to prevent the escape and
spread of any liquid, gas, vapour, fume or dust likely to give rise to fire or
explosion, during normal working, cleaning or overhauling or in the event of
accident or emergency.Bihar Factories Rules, 1950

(b)If escape occurs, such substances shall be removed expeditiously and efficiently at the point of
liberation. The effluent shall be trapped and rendered safe outside the danger area.
24. Leakage of inflammable or dangerous liquids. - Provision shall be made
to confine by means of bund, walls, sumps, etc., possible leakages from
vessels containing inflammable or dangerous liquids.
Adequate and suitable fixed fire fighting appliances shall be installed in the vicinity of such vessels.
25. Cleaning of empty containers and storage of combustible materials. - (a)
All empty containers which have held any inflammable or poisonous material
and metal containers which have held sulphuric acid shall be rendered
permanently and completely safe and shall not be repaired, or destroyed;
until their cleaning in such manner as to make them completely and
permanently safe has been completed.
(b)Combustible and inflammable materials shall not be stored in close proximity to chemicals which
are liable to cause ignition.(c)Rubbish shall be removed from buildings without delay and placed in
special metal containers provided with close fitting lids. The contents shall be removed daily and
suitably dealt with. Waste products containing inflammable or explosive materials shall not be
placed on rubbish heaps but shall be destroyed in an appropriate manner.
26. Installing of pipe lines for inflammable liquids. - All pipe lines for the
transport of inflammable liquids shall be protected against damage or
breakage, shall be arranged so that there is no risk of mechanical damage
from vehicles and shall be so laid that, they drain throughout without the
collection of deposits at any part. All flanged joints, bends and other
connections shall be regularly inspected. Cocks and valves shall be so
constructed that explosive residues cannot collect therein. The open and
closed positions of all cocks and valves shall be clearly indicated on the
outside.
27. Packing of reaction vessels. - Packing and joining materials for reaction
vessels (including covers, man-hole covers, and exhaust pipes) and in pipe
lines and high or low temperature insulating materials shall not contain
materials which are combustible or which react with the products of the
plant.Bihar Factories Rules, 1950

28. Safety valves. - Every still and every closed vessel in which gas is
evolved or into which gas is passed, and in which the pressure is likely to
rise to a dangerous degree, shall have attached to it a pressure gauge and a
proper safety valve or other equally efficient means to relieve the pressure
maintained in good condition. But this will not apply to metal bottles or
cylinders used for the transport of compressed gases.
29. Vigorous or delayed reactions. - Suitable provision, such as, automatic
and distant control shall be made for controlling the effects of unduly
vigorous or delayed reactions. Automatic flooding or blanketing shall be
provided for in the event of an accident.
30. Examination, testing and repair of plant. - Examination, testing and repair
of plant parts which have been in contact with explosive and inflammable
material or which is under pressure, shall be carried out only under proper
supervision.
31. Alarm systems. - (a) Gravity or pressure-feed systems for supplying
inflammable materials to the various parts of the buildings or plant shall be
fitted with alarm systems automatic cut-offs of other devices to prevent
overcharging or otherwise endangering the plant.
(b)The amount of inflammable material taken into a building in bulk containers shall be kept as low
as practicable at any one time.(c)Adequate steps shall be taken to prevent the escape of inflammable
and , explosive vapours from any container into the atmosphere of any building.Gas, Vapour, Fume
or Dust Risks.
32. Escape of gases, etc. - (a) Effective steps shall be taken to prevent the
escape of dangerous gases, vapours, fumes or dust from any part of the
plant, by total enclosure of the process involved or by provision of efficient
exhaust draught. Effective arrangements shall be made to ensure that in the
event of failure of the control measure provided in compliance of the
foregoing, the process shall stop immediately.
(b)In the event of any such escape, provision shall be made to trap the materials and render them
safe.Bihar Factories Rules, 1950

33. Danger due to effluents. - (a) Adequate precautions shall be taken to
prevent the mixing of effluents which may cause dangerous or poisonous
gases to be evolved.
(b)Effluents which may contain or give rise to such gases in the presence of other effluents shall be
provided with independent drainage system to ensure that they may be trapped and rendered safe.
34. Staging. - (a) Staging shall not be erected over any open vessel unless
the vessel is so constructed and ventilated as to prevent the emission of
vapour or fumes about such staging.
(b)Where such staging is provided to give access to higher level in large plants, effective means shall
be provided at all levels with direct means of access to the outside of the room or building and
thence to ground level.(c)Such staging shall be fitted with suitable hand-rails and toe-boards and the
floors and staging shall be impervious and easily cleanable.
35. Instruction as regards risk. - Before commencing work, every worker
shall be fully instructed on the properties of the materials they have to
handle and of the dangers arising from any gas, fumes, vapour or dust which
may be evolved during the process. Workers shall also be instructed in the
measures to be taken to deal with the escape of such gas, fumes or vapours
in the event of emergency.
36. Breathing apparatus. - (a) There shall be provided in every factory where
dangerous gas or fume is liable to escape a sufficient supply of-
(i)Breathing apparatus of an approved make for the hazards involved,(ii)Oxygen and suitable means
of its administration, and(iii)Life-belts.The breathing apparatus and other appliances required by
this clause shall be maintained in good order and kept in an ambulance-room or in some other
suitable place; which shall be within easy approach, and inspected once in every month by a
competent person, appointed in writing by the occupier and a record of their condition shall be
entered in a register provided for that purpose:Provided that the Inspector of Factories may direct to
keep the breathing apparatus and other appliances at such convenient place as he may consider
suitable.(b)Worker shall be trained, and given a periodic refresher course, at least once in every five
months in the use of breathing apparatus and respirators.Respirators shall be kept properly labelled
in clean dry light proof cabinets, and if liable to be affected by fumes, shall be protected by suitable
containers. Respirators shall be dried and cleaned after use and shall be periodically disinfected.Bihar Factories Rules, 1950

37. Treatment of persons. - In every room or place where there is any danger
of gassing and burns, there shall be a fixed official cautionary notice
regarding gassing and burns. Such notices shall be legible by day and by
night and shall be printed in the language understood by the majority of the
workers.
38. Personnel protection equipment. - (a) Suitable protective clothing shall be
provided for the use of operatives :-
(i)When operating valves or cocks controlling fluids which by their nature, pressure or temperature
would be dangerous if a blow-out occurred or when cleaning chokes in systems containing such
fluids if pressure is likely to exist behind the chokes;(ii)when there is danger of injury by absorption
through the skin during the performance of normal duties or in the event of emergency;(iii)when
there is any risk of injury while handling corrosive substances, hot or cold articles, or sharp or rough
object; and(iv)when there is any risk of poisonous materials being carried on their clothes.(b)There
shall be provided for the use of persons employed in the processes specified in Appendix II of this
Schedule an adequate supply of such suitable protective equipments as indicated in the said
appendix.Respirators shall be of a type suitable for the process for which they are to be used,
provided that the Inspector may, by an order in writing, direct that a particular type of respirator or
any other equipment shall be used for a particular process.(c)Protective equipments shall be
provided and stored in an appropriate place and in a manner so that they may, be easily accessible
and readily available without any unnecessary delay, whether for normal use or for use during
abnormal conditions and emergencies.(d)Arrangements shall be made for the proper and efficient
cleaning of all such protective equipments.
39. Cloak-rooms. - There shall be provided and maintained for the use of all
persons employed in the processes specified in appendix II to this Schedule
a suitable cloak-rom, for clothing put off during working hours and a suitable
place, separate from the cloak-room, for the storage of overalls or working
clothes. The rooms provided shall be placed in the charge of an attendant
and shall be kept clean.
40. Special bathing accommodation. - Without prejudice to the requirements
of Rule 63 of the Bihar Factories Rules, 1950 there shall be provided and
maintained by the occupier for the use of persons employed in the processes
specified in Appendix III to this Schedule, specifically allocated washing and
bathing facilities. The washing and bathing facilities shall satisfy the
following requirements :-
(a)Basins and trought shall have smooth impervious upper surface and be fitted with waste pipe andBihar Factories Rules, 1950

plug and shall have supply of running water laid on and available at all times. Every trough shall
have a supply of running water laid on at points above the trough at intervals of not less than two
feet and available at all times.(b)Basins and troughs shall be sufficient in number to provide at least
one unit for every ten workers. For calculating the number of units required the remainder left after
dividing the number of workers by ten shall be counted as ten. For the purposes of this clause a unit
means one basin or two feet of length of a trough or in the case of circular or oval troughs two feet of
the circumference of a trough.(c)There shall be at least one enclosed bath room with a tap on a stand
pipe or shower with soap and towel for every ten persons and the running water supply shall be
capable of yielding at least ten gallons a day for each person, which shall be available at all times.
41. Entry into vessels. - Before any person enters, for any purpose except
that of rescue, any absorber, boiler, culvert, drain, flue, gas purifier, sewer,
still, tank, tower, vitriol chamber or any other place where there is reason to
apprehend the presence of dangerous gas or fume, a responsible person,
appointed in writing by the occupier or the manager for the purpose,shall
personally examine such place and shall certify in writing in a book kept for
the purpose either that such place is isolated and sealed from every source
of such gas or fume and is free from danger or that it is not so isolated and
sealed and is free from danger. No person shall enter any such place which
is not certified to be so isolated and sealed and free from danger unless he is
wearing a breathing apparatus, and (where there are no cross stays or
obstructions likely to cause entanglement) a life-belt, the free end of the rope
attached to which shall be left with a man outside, whose sole duty shall be
to keep watch and to draw out, the worker, if he appears to be affected by
gas or fume. The belt and rope shall be so adjusted and worn that the wearer
can be drawn up head foremost through any man-hole or opening. Similar
precautions shall be taken in case of a person entering for the purpose of
rescue any such place for which a clearance certificate has not been issued.
42. Examination and repair of plant. - Where poisonous materials are likely to
be present the examination and repair of plant and piping shall only be done
under the supervision of a competent person and after the plant and piping
has been thoroughly cleaned and ventilated. When opening vessels and
breaking joints in pipe lines, respirators, goggles and protective clothing
shall be worn to the extent required by the competent person.Bihar Factories Rules, 1950

43. Storage of acid carboys. - Carboys containing Nitric acid or "Mixed" acid
shall be stored in open-sided sheds detached from other buildings, and
placed on a flooring of sand-stone, brick, or other suitable inorganic material.
A passageway shall be provided and kept free from obstruction between
every four rows of such carboys. An ample supply of water shall be available
for washing away spilt acid and all necessary precautions shall be taken to
prevent workers being exposed to fumes.
Corrosive or Deleterious Substances Risks
44. Buildings. - All buildings and plants shall be sited with due regard to
possible dangers from accidental liberation or splashing of corrosive and
deleterious liquids, and shall be so designed as to facilitate through washing
and cleaning. The construction of staging and other parts of buildings shall
be carried out with materials impervious and resistant to corrosion so far as
practicable.
45. Leakage. - (a) All plants shall be so designed and constructed as to
obviate the escape of corrosive liquid, where necessary, separate buildings,
rooms or protective structures shall be used for the dangerous stages of the
process and the buildings shall be so designed as to localise any escape of
liquids.
(b)Catch pits and bund walls shall be provided or other suitable precautions shall be taken to restrict
the serious effects of such leakages. Catch pits shall be placed below joints in pipe- lines where there
is danger involved to maintenance and other workers from such leakage.(c)Passages and
work-stations shall not be situated directly below any part of plant where there is risk of escape of
dangerous liquid. Access to such parts shall so far as practicable, be prohibited, and danger notices
shall be affixed at suitable points.
46. Precautions against escape. - Adequate precautions shall be taken to
prevent the escape of corrosive or deleterious substances and means shall
be provided for rendering safe any such escape.
47. Drainage. - Adequate drainage shall be provided and shall lead to special
treatment tanks where deleterious material shall be neutralised or otherwise
rendered safe, before it is discharged into ordinary drains or sewers.Bihar Factories Rules, 1950

48. Covering of vessels. - (a) No worker shall be allowed to climb over any
fixed vessel or structure containing any dangerous material, which is not so
covered as to eliminate any risk of accidental immersion in it of any portion
of the body of a worker. Such vessels and structures shall be so constructed
that there is no foothold on the top or the sides.
(b)Such vessel, shall unless its edge is at least three feet above the adjoining ground or platform, be
securely fenced to a height of at least three feet above such adjoining ground or platform.(c)No
plank or gangway shall be placed across or inside any such vessel, unless such plank or gangway is at
least 18 inches wide and is securely fenced on both sides by rails spaced 9 inches apart to a height of
at least three feet, or by other equally efficient means.(d)Where such vessels adjoin and the space
between them clear of any surrounding brick or other work, is not securely fenced on both sides to a
height of at least three feet, secure barriers shall be so placed as to prevent passage between
them:Provided that sub-clause (b) of this clause shall not apply to-(i)saturators used in the
manufacture of Sulphate of Ammonia, and(ii)that part of the sides of brine evaporating pans which
require raking, drawing or filling.
49. Ventilation. - Adequate ventilation shall be provided and maintained at all
times in rooms or buildings where dangerous gas, vapour, fume or dust may
be evolved.
50. Means of escape. - Adequate means of escape from rooms or buildings in
the event of leakage of corrosive liquid shall be provided and maintained.
51. Treatment of personnel. - In all places where strong acids or other
corrosive liquids are used-
(a)there shall be provided for use in an emergency-(i)adequate and readily accessible means of
drenching with cold water, persons and the clothing of persons, who may get splashed with such
liquid;(ii)adequate and special arrangements to deal with any person who has been splashed with
poisonous material that can be absorbed through the skin;(iii)sufficient number of eye-wash bottles,
filled with distilled water or other suitable liquid, kept in boxes, or cupboard conveniently situated
and clearly marked by a distinctive sign which shall be visible at all times.(b)Except where the
manipulation of such corrosive liquids is so carried on as to prevent risk of personal injury from
splashing or otherwise, there shall be provided for those who have to manipulate such liquids
sufficient and suitable goggles and gloves or other suitable protection for the eyes and hands. If
gloves are provided they shall be collected, examined, and cleansed at the close of the day's work
and shall be repaired or renewed whenever necessaryBihar Factories Rules, 1950

52. Maintenance. - (a) Before any examination or repair is carried out on a
plant or a pipe-line a competent person shall issue a clearance certificate
permitting such examination or repair.
(b)Adequate precautions shall be taken to liberate any pockets of gas or liquid which may have been
formed in pipe-lines, and which may cause spray of the gas or the liquid at the point where
dismantling takes place.
52A. [ Permissible levels in work environment. [Inserted by S.O. 686 dated
13.7.1988.] - 'Permissible levels of certain chemical substances in work
environment'. With prejudice to the requirements in any other provisions in
the Act or the Rules, the following requirements with respect to permissible
levels of certain chemical substances in work environment shall apply to all
chemical work:
(i)Definitions. - For the purpose of this clause-(a)"mg/.m3" means milligrams of a substance per
cubic meter of air;(b)"mppcm" means million particles of a substance per cubic meter of
air;(c)"ppm" means parts of a substance per million parts of air volume at 25°C and 760 mm.of
mercury pressure;(d)"time weighted average concentration" means the average concentration of a
substance in the air at any work location in a factory computed from evaluation of adequate number
of air samples taken at that location, spread over the entire shift on any day, after giving weightage
to the duration for which each such sample is collected and the concentration prevailing at the time
of taking the sample.]
The weighted average concentration CT+ CT+ CT
11 22 nn
T+ T+ T+
2 2 m
Where C/1 represents the concentration of the substance for duration T/1 (in hours).C/2 represents
the concentration of the substance for duration T/2 (in hours); and C/n represents the
concentration of the substance for duration T/n (in hours).(e)"Work location" means a location in a
factory at which a worker works or may be required to work at any time during any shift on any
day.(ii)Limits of concentrations of substances at work locations. - The time weighted average
concentration of any substance listed in Table 1 or 2 of the clause, at any work vacation in a factory
during any shift on any day shall not exceed the limit of the permissible time weighted average
concentration specified in respect of that substance.(iii)In the case of substance mentioned in Table
1 in respect of which a limit in form of short term maximum concentration is indicated, the
concentration of such a substance may exceed the permissible limit of the time weighted average
concentration for the substance for short periods not exceeding 15 minutes at time, subject to the
condition that-(a)Such periods during which the concentration exceeds the prescribed time
weighted average concentration are restricted to not more than 4 per shift;(b)the time interval
between any two such periods of higher exposure shall not be less than 60 minutes; and(c)at noBihar Factories Rules, 1950

time, the concentration of the substance in the air shall exceed the limit of short term maximum
concentration.(iv)In the case of any substance given in Table 3, the concentration of the substance at
any work location in factory at any time during any day shall not exceed the limit of exposure for
substance specified in the table.(v)In the cases where the word "skin" has been indicated against
certain substances mentioned in Tables 1 and 3 appropriate measures shall be taken to prevent
absorption through cutaneous routes particularly skin, mucous, membrances, and eyes as the limits
specified in these. Tables are for conditions where the exposure is only through respiratory
tract.(vi)In case, the air at any work location contains a mixture of such substance mentioned in
Tables 1, 2 and 3 which have similar toxic properties, the time weighted concentration of each of
these substances during the shift should be such, that when these time weighted concentration
divided by the respective permissible time weighted average concentration specified in the above
mentioned tables, are added together, the total shall not exceed unity.C1 + C2 ... ... ... ... ... ... ... Cm
shall not exceed unity when C1, C2. ... ... ... ... L1.. L2 Ln... ... ... ... ... ... Cn are the time weighted
concentration of toxices, substances 1,2, ... and respectively determined after measurement at work
location.and L1, L2... ... ...Ln are the permissible time weighted average concentration of the toxic
substances 1, 2... ... ... ... ... ... ... ... and respectively.(vii)In the case the air at any work location
contains a mixture of substances, mentioned in Tables 1, 2 and 3 and these do not have similar toxic
properties, then the time weighted concentration of each of these substances shall not exceed the
permissible time weighted average concentration specified in the above mentioned tables, for that
particular substances:Provided that the requirements in sub-clauses (vi) and (vii) shall be in
addition to the requirements in sub-clauses (ii), (iii) and (iv).(viii)Sampling and evaluation
procedures. - (a) Notwithstanding provisions in any other paragraphs, the sampling and evaluation
procedures to be adopted for checking compliance with the provisions in the clause shall be as per
standard procedures in vogue from time to time or as approved by the Chief
Inspector.(b)Notwithstanding any other provisions the following conditions regarding the sampling
and evaluation procedures relevant to checking compliance with the provisions in the clause are
specified :-(A)For determination of the number of particles per cubic meter samples are to be
collected by standard or midget impinger and the counts made by light-field technique.(B)The
percentage of quartz in the 3 formula given in item 1 (a) (i) of Table 2 is to be determined from air
borne samples.(C)For determination of number of fibres as specified in item 2 (a) of Table 2, the
membrances filter method at 430 x phase contrast should be used.(D)Both for determination of
concentration and percentage of quartz for use of the formula given in item 1 (a) (i) (2) of Table 2,
the fraction passing through a size selector with the following characteristic should only be
considered.
Aerodynamic diameter(Unit density sphere).   Percentage allowed by Size-selector.
2.0 ......90
2.5 ......75
3.5 ......50
5.0 ......25
10.0 ......0
(ix)Power to require assessment of concentration of substance. - (a) An inspector may by an order in
writing direct the Occupiers or Managers of factory to get before any specified date, the assessment
of the time weighted average concentration at any work location at any of the substances mentionedBihar Factories Rules, 1950

in Tables 1, 2 or 3 carried out.(b)The results of such assessment as well as the method followed for
air sampling and analysis for such assessment shall be sent to the Inspector within 3 days from the
date of completion of such assessment and also a record of the same maintained in the bound
register and kept readily available for inspection by an Inspector.(x)Exemption. - If in respect of any
factory or a part of factory, the Chief Inspector is satisfied that by virtue of the pattern of working
time of the workers at different work locations or on account of other circumstances no worker
exposed, in the air at the work locations, to a substance or substances specified in Tables 1, 2 or 3 to
such an extent as is likely to be injurious to his health, he (the Chief Inspector) may by an order in
writing exempt the factory or part of the factory from such requirements, subject to such conditions,
if any, as he may specify therein.Table 1
Substance  Permissible limits of
exposure
 Time weighted average
concentration.Short-term maximum
Concentration.
 ppm mg/m3 ppm mg/m3
1  2 3 4 5
Acetic Acid ... 10 25 15 7
Acrolein ... 0.1 0.25 0.3 0.8
Aldrin (Skin) ... ... 0.25 ... 0.75
Ammonia ... 25 18 35 27
Aniline (Skin) ... 2 10 5 20
Anilidine (Opisomers Skin) ... 0.1 0.5 ... ...
Arsenic & Compounds (as As) ... ... 0.2 ... ...
Benzene ... 10 30 ... ...
Bromine ... 0.1 0.7 0.5 2
2 Butanone (Methyl-Ethyl
Ketone MEK)... 200 590 300 885
n-Butyle Acetate ... 150 710 200 950
Sectert. Butyl Acetate ... 200 950 250 1190
Cadmium dust and salts (as
Cd)... ... 0.05 ... 0.2
Calcium Oxide ... ... 2 ... ...
Carbaryl (Sevin) ... ... 5 ... 10
Carbofuran (Furadan) ... ... 0.1 ... ...
Carbon disulphide (Skin) ... 20 60 30 90
Carbon monoxide ... 50 55 400 440
Carbon tetrachloride (Skin) ... 10 65 20 130
Carbonyl chloride (phosgene) ... 0.1 0.4 ... ...
Chlordance (Skiri) ... ... 0.5 ... 2Bihar Factories Rules, 1950

Chlorobenzene
(monochloro-Bezene)... 75 350 ... ...
Chlorine ... 1 3 3 9
Bis-chloromethyl ether ... 0.001 ... ... ...
Chromic acid and Chromites
(as Cr.)... ... 0.05 ... ...
Chromium, Sel. Chormic
Chromous... ... 0.5 ... ...
Salts (as Cr.) ... ... ... ... ...
Copper Fume ... ... 0.2 ... ...
Cotton dust raw ... ... 0.2 ... 0.6
Cresol, all isomers (Skin) ... 5.22 ... ... ...
Cyanides (as CN)-(Skin) ... ... 5 ... ...
Cyanogen ... 10 20 ... ...
DDT (Dichloriodiphenyl
trichloroethane)... ... 1 ... 3
Demeton skin ... ... 0.1 0.02 0.3
Diazinon-skin ... ... 0.1 ... 0.3
Dibutyle Phthalate ... ... 5 ... 10
Dichlorves (DD VP)-skin ... 0.1 1 0.3 3
Dield-rin-skin ... ... 0.25 ... 0.75
Dinitro Benzene (all
isomers-skin)... 0.15 1 0.5 3
Dinitrotoluene-skin ... ... 1.5 0.6 4
Diphenyl ... 0.2 1.5 0.6 4
Endrin-skin ... ... 0.1 ... 0.3
Ethyl Acetate ... 400 1000 ... ...
Methyl Amine ... 10 18 ... ...
Ethyl Amine ... 10 18 ... ...
Ethyl Alcohol ... 1000 1900 ... ...
Flourides (as F) ... ... 2.5 ... ...
Flourine ... 1 2 2 4
Hydrogen cyanide-skin ... 10 1 15 16
Hydrogen Sulphide ... 10 15 15 27
Iron oxide from (Fe2O3 as Fe) ... ... 5 ... 10
Isoamyl Acetate ... 100 525 125 655
Isobutyl Alcohol ... 50 150 75 225
Isoamyl Alcohol ... 100 360 125 450Bihar Factories Rules, 1950

Lead, inorg, fumes and dust
(as Pb)... ... 0.15 ... 0.15
Linda-he-skin ... ... 0.5 ... 1.5
Malathoion-skin ... ... 10 ... ...
Manganese fume (as Mn) ... ... ... 1 3
Mercury (as Hg) ... ... 0.05 ... 0.15
Mercury (aidyl compounds
skin) (as Hg)... 0.001 0.01 0.003 0.03
Methyl Alcohol (methanol)
skin... 200 260 250 310
Methyl collosove-skin
(2-methoxy ethanol)... 25 80 35 120
Methyl isobutyl Ketone-skin ... 100 410 125 510
Napthalene ... 10 50 15 75
Nickel carbonyl (as Ni) ... 0.05 0.35 ... ...
Nitric Acid ... 2 5 4 10
Nitric Oxide ... 25 30 35 45
Nitrobenzine-skin ... 1 5 2 10
Oil mist-mineral ... ... 5 ... 10
Parathion-skin ... ... 0.1 ... 0.3
Phenol-skin ... 5 19 10 38
Phroate (Thimet)-skin ... ... 0.65 ... ...
Phosgene (Carbonyl chloride) ... 0.1 0.4 ... ...
Phosphine ... 0.3 0.4 1 1
Phosphorus (Yellow) ... ... 0.1 ... 0.3
Posphorus pentachloride ... ... 1 ... 3
Phosphorus trichloride ... 0.5 3 ... ...
Picric acid-skin ... ... 0.1 ... 0.3
Pyridine ... 5 15 10 30
Sila-ne (Sillicon tetrahydrine) ... 0.5 0.7 1 1.5
Styrene, monomer (phenyl,
othylene)... 100 420 125 525
Sulfur dioxide ... 5 15 ... ...
Sulfuric acid ... ... 1 ... ...
Toluene (toluo) skin ... 100 375 1545 560
O-Toludine ... 5 22 10 44
Trichloroethylene ... 100 535 150 800
Vinyl chloride ... 5 10 ... ...Bihar Factories Rules, 1950

Wielding Fumes (NOC) ... ... 5 ... ...
Xylene (o-m-p-isomers) skin ... 100 435 150 655
Table 2
Substance  Permissible time-weighted average concentration.
1  2
1. Silica-   
(a) Crystalline-   
(i) Quartz-   
(1) In terms of dust count  {|
1060% Quartz + 10| mppCm
|-| (2) In terms of respirable dust||
10% respirable quartz + 2| Mg/m3
|-| (3) In terms of total dust||
30% quartz - 3| Mg/m3
|-| (ii) Cristobalite| ...| Half the limits given against quartz.|-| (iii) Tridymite| ...| Half the limits
given against quartz.|-| (iv) Silica fused| ...| Same limit as for quartz.|-| (v) Tripoli| ...| Same limit as
in formula in item 2 given against quartz.|-|| ...| 750 mppcm.|-| 2. Silicate having less than 1% free
silca by weight-|||-| (a) Asbestos-fibres longer than 5microns-|||-| (i) Amosite| ...| 0.5 fibre/cubic
centimeter.|-| (ii) Chrysolite| ...| 2 fibres/cubic centimeter.|-| (iii) Crocidolite| ...| 0.2 fibre/cubic
centimeter.|-| (iv) Other form| ...| 2 fibres/cubic centimeter.|-| (b) Mica| ...| 705 mppcm.|-| (c)
Mineral wool fibre| ...| 10 mg/m3|-| (d) Porlite| ...| 1060 mppcm.|-| (e) Portland cement| ...| 1060
mppcm.|-| (f) Soap stone| ...| 705 mppcm.|-| (g) Talc (non-abosti form)| ...| 705 mppcm.|-| (h) Talc
(fibrous)| ...| Same limit as for asbestos.|-| (i) Tromolite| ...| Same limit as for asbestos.|-| 3. Coal
dust-|||-| (1) For air born dust having lessthan - 2mg/m3|| 5% silicon dioxide by weight.|-| (2) For
air-borne dust havingover 5% silicon dioxide.|| Same limit as prescribed by formula item (2) against
quartz.|}Table 3
  Permissible limit of exposure.
Substance  ppm mg/m3
1  2 3
Acetic an hydride ...5 20
O-Dichlorobenzene ...50 300
Formaldehyde ...2 3
Hydrogen Choloride ...5 7
Manganese 1 Compounds (as Mn) ...... 5
Nitrogen-dioxide ...5 9
Nitroglycerine-skin ...02 2
Potassium hydroxide ...... 2
Sodium hydroxide ...... 2
2, 4, 6 - Trinitrotoluene (TNT) ...... 0.5Bihar Factories Rules, 1950

53. Washing facilities. - (a) There shall be provided and maintained in every
chemical works for the use of employed persons adequate and suitable
facilities for washing which shall include soap and nail brushes or other
suitable means of cleaning and the facilities shall be conveniently accessible
and shall be kept in a clean and orderly condition.
(b)If female workers are employed, separate washing facilities shall be provided and so enclosed or
screened that the interiors are not visible from any place where persons of the other sex work or
pass. The entrance to such facilities shall bear conspicuous notice in the language understood by the
majority of the workers "For woman only" and shall also be indicated pictorially.
54. Lunch room facilities. - In every chemical works there shall be provided
and maintained for the use of those remaining on the premises during the
rest intervals, suitable and adequate lunch room which shall be adequately
furnished and shall have sufficient drinking water supply.
55. Medical Examination. - (a) The provisions of sub-clauses (b), (c), (d) and
(e) shall apply in respect of the following processes :-
(i)Manufacture, processing, handling, or use of hexa ethyl tetra phosphate, Tetra ethyl pyro
phosphate, Mercury derivatives, O.O. Diethyl O. P-nitrophenyl, Thiophosphate (parathion),
Nicotine, Nicotine sulphate, Methyl Bromide, Cyanides Arsenical derivatives.(ii)Chrome
processes.(iii)Nitro or Amino processes.(b)Every person employed in any process specified in
sub-clause (a) of this clause shall be examined by the Certifying Surgeon once in every three months
on a date or dates of which due notice shall be given to all concerned and records of such
examinations shall be maintained in the Health Register.(c)No person shall be allowed to work
unless a certificate of fitness has been granted after examination by the Certifying Surgeon and a
signed entry made in the Health Register.(d)Every person so employed shall present himself at the
appointed time for examination by the Certifying Surgeon as provided in clause (b) of this Rule.(e)if
the Certifying Surgeon finds as a result of his examination that any person employed in such process
is no longer fit for medical reasons to work in that process, he shall suspend such person from
working in that process, for such time as he may think fit and no person after suspension shall be
employed in that process without the written sanction of the Certifying Surgeon in the Health
Register.Duties of Workers
56. Duties of workers. - (i) Every person employed shall-
(a)report to his Foreman any defect in any fencing, breathing apparatus, appliances or other
requisite provided in pursuance of this Schedule, as soon as he becomes aware of such defect;(b)use
the articles, appliances or accommodation required by this Schedule for the purpose for which they
are provided;(c)Wear the breathing apparatus and life-belt where required under this
Schedule.(ii)No person shall,-(a)remove any fencing provided, unless duly authorised,(b)stand onBihar Factories Rules, 1950

the edge or on the side of any vessel to which clause 48 applies;(c)pass or attempt to pass any
barrier erected in pursuance of clause 48;(d)place across or inside any vessel to which clause 48
applies any plank of gangway which does not comply with the Schedule or make use of any such
plank or gangway while in such position;(e)take a naked light or any lamp or matches or any
apparatus for producing a naked light or spark into, or smoke in any part of the works where there is
likelihood of explosion or fire from inflammable gas, vapour or dust;(f)use a metal spade scraper or
pail which is not non-sparking when cleaning out or removing the residues from any chamber, still
tank or other vessel which has contained sulphuric acid or hydrochloric acid or other substance
which may cause evolution of arsenirated hydrogen; or in which there is risk or ignition or
explosion;(g)remove from a First-Aid box or cupboard or from the Ambulance room any First-Aid
appliance or dressing, except for the treatment of injuries in the works.
Part III – 57. The provisions of Part III shall apply to all chemical
works and parts thereof in which-
(i)caustic potash are used; or(ii)chlorate or bleaching powder is manufactured; or(iii) (a)gas tar or
coal-tar is distilled, handled or used in any process of chemical manufacture; or(b)a nitro or amino
process is carried on; or(c)a chrome process is carried on; or(iv)crude shell-oil is refined or
processes incidental thereto are carried on; or(v)nitric acid is used in the manufacture of nitro
compounds; or(vi)evaporation of brine in open pans and the stoving of salt are carried on;
or(vii)manufacture or recovery of hydrochloric acid or any of its salts is carried on; or(viii)work at a
furnace is carried on where the treatment of zinc ores is done; or(ix)insecticides mentioned in
Appendix I are manufactured, mixed, blended or packed.
58. Entry in gas tar or coal-tar still. - Before any person enters a gas-tar or
coal-tar still for any purpose, except that of rescue it shall be completely
isolated from adjoining tar stills, either by disconnecting-
(a)the pipe leading from the swan-neck to the condenser worm, or(b)the waste gas pipe fixed to the
worm and/or receiver. In addition, blank flanges shall be inserted between the disconnected parts,
and the pitch discharge pipe or cock at the bottom of the still shall be disconnected.
59. Entry into bleaching powder chamber. - No person shall enter a chamber
for the purpose of withdrawing the charge of bleaching powder unless and
until-
(i)the chamber is efficiently ventilated; and(ii)air in the chamber has been tested and found to
contain not more than 2.5 grains of free chlorine gas per cubic foot of air.A register containing
details of all such tests shall be kept in a suitable form or in a form approved by the Chief Inspector.Bihar Factories Rules, 1950

60. Special precautions for nitro processes. - In a Nitro or Amino process-
(a)if crystallised substances are broken or any liquor agitated by hand, means shall be taken to
prevent as far as practicable, the escape of dust or fume into the air of any place in which any person
is employed. The handles of all implements used in the operations shall be cleaned
daily;(b)cartridges shall not be filled by hand, except by means of a suitable scope;(c)every drying
stove shall be efficiently ventilated to the outside air in such a manner that hot air from the stove
shall not be drawn into any work-room.(d)no person shall enter a stove to remove the contents,
until a free current of air has been passed through it;(e)every vessel containing nitro or amino
derivatives of Phenol or of Benzene or its homologues shall, if steam is passed into or around it, or if
the temperature of the contents be at or above the temperature of boiling water, be covered in such a
way that steam or vapour shall be discharged into the open air at a height of not less than 25 feet
from the ground or the working platform, and at a point from where it cannot be blown back again
into the workroom.
61. Precautions during caustic grinding, etc. - Every machine used for
grinding or crushing caustic shall be enclosed; and an efficient exhaust
draught shall be provided where any of the following processes are carried
on :-
(i)Grinding or crushing of caustic;(ii)packing of ground caustic;(iii)grinding, sieving, evaporating or
packing in chrome processes;(iv)crushing, grinding or mixing of material or cartridge filling in a
nitro or amino process.
62. Chlorate manufacture. - (a) Chlorate shall not be crystallised, ground or
packed, except in a room or place not used for any other purpose, the floor
of which room or place shall be of cement or other smooth, impervious and
incombustible material, and shall be thoroughly cleaned daily.
(b)Wooden vessels shall not be used for the crystallisation chlorate, or to contain crystallised or
ground chlorate; provided that this shall not prohibit the packing of chlorate for sale into wooden
casks or other wooden vessels.
63. Restrictions on the employment of young persons and women. - (a)
Persons under 18 years of age and women shall not be employed in any
process in which hydrofluoric acid fumes or ammoniacal vapours are given
off or in any of the following operations:-
(i)evaporation of brine in open pans;(ii)stoving of salt;(iii)work at furnace where the treatment of
zinc ores is carried on; and(iv)cleaning of work-room where the process mentioned in (iii) is carried
on.(b)No person under 18 years of age shall be employed in a Chrome process or in a Nitro or Amino
process or in a process in which the carbon bi-sulphide, chlorides of sulphur, Benzene, carbonBihar Factories Rules, 1950

chlorine compound or any mixture containing any of such materials are used or where the vapour of
such materials is given off.
64. Duties of employees. - (a) Every worker shall use and wear the protective
clothing, foot-wear, respirators, goggles, gloves or other protective
appliances provided under this Schedule and shall deposit the overalls or
suits or working clothings so provided, as well as clothings put off during
working hours, at the place provided under clause 39.
(b)Every worker employed in any process to which clause 40 applies shall carefully wash his hands
and face before partaking of any food or leaving the premises.Appendix IAll chemical works in
which-
1. Chemical processes relating to the following are carried on;-
(a)Carbonates, chromates, chlorates, oxides or hydroxides of Potassium, Sodium, Iron, Aluminium,
Cobalt, Nickel, Arsenic, Antimony, Zinc or Magnesium,(ia)[ Cadmium and its salts, carbon
disulphide, chlorides and Chlorine and compounds, Copper, cyanides, Fluorine and compounds,
Lead, Manganese, Mercury, Phosphorous and compounds, [Inserted by S.O. 686 dated
13.7.1988.](ib)Oxides of Calcium, Iron, Nitrogen, Sulphur and Carbon and Silica, Asbestos, Mica,
Mineral Wool, Prolite, Portland Cement, Soap Stone, Talcum, Tromolite, Coal.](b)Ammonia and the
hydroxide and salts of ammonium,(c)Sulphurous, sulphuric, nitric, hydrochloric, hydrofluoric,
hydroiodic, hydrosulphuric, boric, phosphoric, oxalic, arsenious, arsenic, lactic, acetic, tartaric or
citric acids and their metallic or organic salts, and(d)Cyanogen compounds.
2. A wet process for the extraction of metal from ore or from any bye-product
or residual material is carried on.
3. Electrical energy is used in any process of chemical manufacture.
4. Alkali waste or effluents therefrom is subjected to any chemical process
for the recovery of sulphur, or for the utilisation of any constituent of such
waste or effluent.
5. Carbon bisulphide is made or hydrogen sulphide is evolved by the
decomposition of metallic sulphides or hydrogen sulphide is used in the
production of such sulphides.Bihar Factories Rules, 1950

6. Bleaching powder is manufactured or chlorine gas is made or is used in
any process of chemical manufacture.
7. (a) Gas-tar or coal-tar or any compound product or residue of such tars is
distilled or is used in any process of chemical manufacture.
(b)Synthetic colouring matters or their intermediates are made.
8. Refining of crude shale oil or any process incidental thereto is carried out.
9. Nitric acid is used in the manufacture of nitro compounds.
10. Explosives are made with the use of nitro compounds.
11. Insecticides, which may be of phosphorus, nicotine, mercury,
naphthalene, cyanogen, arsenic, fluorine, copper, benzene and ethane
compounds or derivatives and methyl bromide, are manufactured, mixed,
blended, and packed.
12. Viscose rayon is manufactured or processes incidental thereto are
carried out.
13. Phosgene (carbonyl chloride) is manufactured, stored, handled,
processed or used.
14. Aliphatic or Aromatic compounds including petroleum and petroleum
products and their derivatives or substituted derivatives are manufactured,
processed or recovered.
Appendix II
1. A nitro or amino process (overall suits or working clothes and protective
footwear).
2. Grinding raw materials in a chrome process (overall suits).
3. The crystal department and in packing in a chrome process (protective
coverings).Bihar Factories Rules, 1950

4. Packing in a chrome process (respirators).
5. Any room or place in which chlorate is crystallised, ground, parked
(clothing of woollen material and boots or over shoes, the soles of which
have no metal on them).
6. Any room in which caustic is ground or crushed to machine (goggles and
gloves or other suitable protection for the eyes and hands).
7. Bleaching powder chambers, or in packing charges drawn from such
chambers (suitable respirators).
8. Drawing off of molten sulphur from sulphur pots in the process of carbon
disulphide manufacture (overalls, face shields, gloves and footwear of
fire-proof materials).
9. (i) Manufacture, mixing, blending and packing of insecticides which are
phosphorus, nicotine, naphthalene, cyanogen, arsenic, fluorine, mercury and
copper compounds or derivatives and methyl chromide (rubber aprons
chemicals type goggles and suitable respirators, and in addition rubber
gloves and boots for phosphorus and nicotine derivatives, synthetic rubber
aprons, gloves and boots when working with oil solutions, and washable
working clothes laundered daily).
(ii)Manufacture, mixing, blending and packing of insecticides which are derivatives of benzene or
ethane (rubber aprons, and suitable respirators, separate work clothes laundered
frequently).Appendix III
1. A Nitro or Amino process.
2. The crystal department and the packing room in a Chrome process.
3. The process of distilling gas or coal-tar (other than blast furnace tar) and
any process of chemical manufacture in which such tar is used.
4. The manufacture, mixing, blending and packing of insecticides mentioned
in Appendix I.Bihar Factories Rules, 1950

XIV
Compression of Oxygen and Hydrogen
1. The room in which electrolyser plant is installed shall be separate from the
plant for storing and compressing of Oxygen and Hydrogen and also from
the electric generator room.
2.
The purity of Oxygen and Hydrogen shall be tested by a competent person at hourly intervals at the
following points;-(i)In the electrolyser room,(ii)At the gas-holder in-let, and(iii)At the Section end of
the Compressor.The figures relating to the degree of purity as obtained from the test carried out
shall be recorded systematically in a register or a log book maintained only for this purpose and
shall be signed by the person carrying out the test:Provided, however, that if the electrolyser plant is
fitted with an automatic device for recording the purity of the gases along with visual warning
signals, it shall be sufficient if the purity of the gases is tested at hourly intervals at the suction and
of the compressor only.
3. The Oxygen and Hydrogen gases shall not be compressed if their purity
determined by the test carried out under clause 2 falls below 98 per cent at
any time.
4. [ Effective negative pressure switch shall be provided adjacent to the
suction main close to the gas-holder and between the gas-holder and the
hydrogen compressor in such manner that the compressor is automatically
stopped at a predetermined safe pressure in the gas-holder.
The negative pressure switch provided shall be tested and examined for its effective working once
every shift by a competent person and records of all such examinations shall be maintained in a
register signed by the Manager of the factory.
5. The belt of any gas-holder shall be permitted to go within 30 cms. (12
inches) of its lowest position when empty and a limit switch shall be
provided for this purpose in the gas-holder with adequate alarm indicators
both visible and audible to indicate that the gas-holder has reached the limit.]
[Inserted by S.O. 344, dated 28.2.1977.]Bihar Factories Rules, 1950

6. The water and caustic soda used for making lye shall be chemically pure
within pharmaceutical limit.
7. Electrical connections at the electrolyser cells and at the electric generator
terminals shall be so constructed as to preclude any possibility of any wrong
connection, leading to reversal of polarity, and in addition and automatic
device shall be provided to cut off power in the event of reversal of polarity
owing to wrong connection either at the switch board or at the electric
generator terminals.
8. Oxygen and Hydrogen gas pipes shall be painted with distinct colours so
that they may be clearly and easily distinguished and in the event of any
leakage at any joint of the Hydrogen gas pipe, the pipe after reconnection
shall be completely purged of air before drawing in Hydrogen.gas.
9. All electrical apparatus, equipments and appliances including wirings,
machines, switch-gears, light points, switches, plugs, sockets, etc., in the
electrolyser room shall be of flame proof construction or enclosed in
flame-proof fittings and no naked light or flame shall be allowed to be taken
in or near the electrolyser room or where compression and filling of any gas
is carried on, and warning notices to such effect shall be displaced at
prominent places.
10. No part of the electrolyser plant and the gas-holder and compressor shall
be subjected to welding, brazing, soldering or cutting until all explosive
substances have been completely removed from that part so as to render the
part safe for such operation and after the completion of such operation no
explosive substance shall be allowed to enter that part until the metal has
cooled sufficiently to eliminate any risk of explosion.
11. (a) All sources of starting an ignition or of producing a spark whether
electrical or otherwise shall be eliminated from such parts of the plant or
factory where there may be any risk of explosion.
(b)In all such parts of the factory or plant, shoes with nails, belts or synthetic clothes, likely to
generate spark due to friction or discharge of static electricity (unstatic electricity to earth
continuously) or use of tools likely to produce a spark shall not be allowed, and all such plants, parts
or machines whereon static electricity may build up shall be solidly and effectively earthed.Bihar Factories Rules, 1950

12. No person shall be permitted to enter any place or area where there is
risk of explosion, while carrying a match box or a lighter, and arrangement
shall be made to collect all such articles outside before the person enters
any such place or area.
13. No work of operation, repair or maintenance shall be undertaken except
under the direct supervision of a person who by his training and experience
possesses the knowledge of the necessary precautions against risk of
explosion and is competent to supervise such work. An electric generator
connected to an electrolyser after erection or repairs shall not be switched
on, unless the same is certified by the competent person under whose direct
supervision erection or repairs are carried on, to be safe, and the terminals
have been checked for the polarity as required under clause 7.
14. Every part of an electrolyser plant, gas holder and compressor shall be
checked and overhauled at suitable intervals regularly and every defect
noticed shall be rectified forthwith.
15. Detailed instructions with regard to the operation of the plant,
precautions to be taken, and the steps to be taken in case of an emergency,
shall be prepared and displayed at prominent places close to the plant.
16. A register or a log book in convenient form shall be maintained in which
all operations carried out in such factories and plants shall be regularly
recorded and signed by the person incharge of the plant carrying out the
operation as well as by the person.
XV
1. Application. - This Schedule shall apply to factories in which any of the
following processes is carried on :-
(i)Breaking, crushing, disintegrating, opening, grinding, mixing or sieving of asbestos and any other
processes involving handling and manipulation of asbestos incidental thereto;(ii)All processes in the
manufacture of asbestos textiles including preparatory and finishing processes;(iii)making of
insulation slabs or Section, composed wholly or partly of asbestos, and processes incidental
thereto;(iv)making or repairing of insulating mattresses, composed wholly or partly of asbestos, and
processes incidental thereto;(v)manufacture of asbestos card-board and paper;(vi)manufacture of
asbestos cement products;(vii)application of asbestos by spray method;(viii)sawing, grinding,Bihar Factories Rules, 1950

turning, abrading and polishing, in the dry state of articles composed wholly or partly of
asbestos;(ix)cleaning of any room, vessel, chambers, fixture or appliances for the collection or
removal of asbestos dust:Provided that if the Chief Inspector is satisfied that in respect of any
factory or workshop or part thereof, by reason of the restricted use of asbestos or the method of
working, of occasional nature of work, or otherwise, all or any of the provisions of this Schedule, can
be suspended or relaxed without danger to the health of the persons employed therein, he may by an
order in writing grant suspension or relaxation subject to such conditions or for such period as he
may think fit. Any such order may be revoked at any time.
2. Definition. - For the purpose of this Schedule:-
(i)"asbestos" means any fibrous silicate mineral, and any admixture containing any such mineral,
whether crude, crushed or opened;(ii)"asbestos textiles" means yarn or cloth composed of asbestos
or asbestos mixed with any other material;(iii)"preparing" means crushing, disintegrating, and any
other process in or incidental to the opening of asbestos;(iv)"approved" means approved for the
time being in writing by the Chief Inspector;(v)"breathing apparatus" means a helmet or face piece
with necessary connection by means of which a person using it breathes air free from dust, or any
other approved apparatus.
3. An exhaust draught effected by mechanical means which prevents the
escape of asbestos dust into the air of any room in which persons work,
shall be provided and maintained for-
(a)manufacturing and conveying machinery, namely :-(i)preparing, grinding or dry mixing
machines;(ii)carding, card-waste-end ring spinning, machines, and looms;(iii)machines or other
plant fed with asbestos;(iv)machines used for the sewing, grinding, turning, abradihg or polishing,
in the dry state, of articles composed wholly or partly of asbestos;(b)cleaning, and grinding of the
cylinders or other part of a carding machine;(c)chambers, hopers or other structures into which
loose asbestos is delivered or passes;(d)work benches for asbestos waste sorting or for other
manipulation of asbestos by hand.(e)work places at which the filling and emptying of sacks, skips or
other portable containers, weighing or other process incidental thereto which is effected by hand, is
carried on.(f)sack-cleaning machines:Provided that his clause shall not apply - (i) to a machine or
other plant which does not give rise to asbestos dust or is so enclosed as to prevent escape of
asbestos dust into the air of any room in which persons work, or (ii) where the asbestos is so wet or
so treated with grease or other materials as to prevent the evolution of dust, or (iii) to the making or
repairing of insulating mattresses, or (iv) to mixing or blending by hand of asbestos.
4.
(1)Mixing or blending by hand of asbestos shall not be carried on except with an exhaust draught
effected by mechanical means so designed and maintained as to ensure as far as practicable the
suppression of dust during the processes.(2)In premises which are constructed or reconstructed
after this Schedule comes into force, the mixing or blending by hand of asbestos shall not be doneBihar Factories Rules, 1950

except in a special room or place in which no other work is ordinarily carried on.(3)(a)The making
or repairing of insulating mattresses composed wholly or partly of asbestos shall not be carried on in
any room in which any other work is done.(b)In every room in which the making or repairing of
insulating mattresses is carried on:-(i)adequate exhaust and in-let ventilation in accordance with
arrangements to be approved in each case shall be provided and maintained;(ii)no person other
than those engaged in filling, beating or levelling shall be present whilst such processes are being
carried on and work shall not be resumed in the room after filling, beating or levelling for at least
ten minutes;(iii)the floors and benches shall be kept damped so as to effectively prevent dust arising
therefrom;(iv)The covers shall be effectively damped immediately after being cut out and in the case
of fibre filled mattresses, shall be kept damp whilst filling, beating or levelling is being carried
on.(4)(a)Storage chambers or bins for loose asbestos shall in the case of premises constructed or
reconstructed after this Schedule comes into force, be effectively separated from any work room and
in the case of other premises be effectively separated from any work room in which the asbestos is
not required for the purposes carried on in the room.(b)Chambers or apparatus for dust settling and
filtering shall not be allowed in any work room.(c)Effective arrangements shall be made to prevent
asbestos dust discharged from exhaust apparatus being drawn into the air of any work room.(5)All
machinery used in preparing, grinding of asbestos carding,card roller cleaning and grinding, and
sack cleaning and all card waste-end machinery latrices, elevators, chutes, and conveyers shall be so
constructed and maintained that dust or debris containing asbestos cannot escape from any part
thereof, other than dust removed by air exhaust draught provided in accordance with clause 3 of the
Schedule.(6)(a)Cleaning by hand of the cylinders (including the deffer cylinders) of a carding
machine, shall not be done whilst any person other than those performing or assisting at the
cleaning is present.(b)After six months from the date on which this Schedule comes into force such
cleaning as aforesaid shall not be done by means of hand strickles or other hand tools:Provided that
the Inspector or the Chief Inspector may direct such other measures and precaution to be taken, as
may be considered necessary for securing the health of the workers, employed on processes and
work specified in clause 4.
5.
(1)In every room in which any of the requirements of this Schedule apply:-(a)The floors, work
benches and plant shall be kept in a cleanly state and free from asbestos, debris and suitable
arrangements shall be made for the storage of asbestos not immediately required for use, and(b)The
floors shall be kept free from any materials, plant or other articles not immediately required for the
work carried on in the room which would obstruct the proper cleaning of the floor.(2)Every room as
aforesaid shall be adequately lighted.
6. (a) A sack which has contained asbestos shall not be cleaned by hand
beating but by a machine, complying with clause 3 and sub-clause (5) of
clause 4.
(b)All sacks used as containers for the purpose of transport of asbestos within the factory shall be
constructed of impermeable material and shall be kept in good repair.Bihar Factories Rules, 1950

7. (a) All ventilating plant used for the purpose of extracting or suppressing
dust as required by this Schedule shall at least once in every six months be
thoroughly examined and tested by a competent person and any defect
disclosed by such examination and test shall be rectified forthwith.
(b)A register containing particulars of such examination and test and the state of the plant and the
repairs or alterations (if any) found to be necessary shall be kept, and shall be available for
inspection by an Inspector.
8. A breathing apparatus shall be provided for every employee :-
(a)In chamber containing loose asbestos;(b)In cleaning dust setting or filtering chambers or
apparatus;(c)In cleaning the cylinders, including the deffer cylinders, or other part of the carding
machine by means of hand-strickles; and(d)in filling, beating or levelling in the manufacture or
repair of insulating mattresses.
9. There shall be provided and maintained for the use of all persons
employed in the cleaning of dust settling and filtering chambers, tunnels and
dusts, suitable overalls and head coverings.
10. No young person shall be employed in or in connection with the
manufacture of insulating mattresses, in mixing or blending of asbestos by
hand, in sack cleaning, in chambers, or apparatus for dust settling or
filtering; in chambers containing loose asbestos, or in stripping or grinding
the cylinders including the deffer cylinders or other part of a carding
machine.
11. Medical examination. - (a) No worker shall be employed in any factory on
any of the processes specified in clause I, unless he has been medically and
radiologically examined and has been declared fit and has been granted a
certificate of fitness in Form No. 25.
(b)Every worker employed on any of the aforesaid processes on the date on which the Schedule
comes into force shall be medically and radiologically examined within three months of the said
date.(c)Every worker employed on any of the aforesaid processes shall be medically examined at
intervals of six months after the first medical examination conducted under sub-clauses (a) and (b)
and radiologically at intervals of 3 years after the first radiological examination conducted under sub
clauses (a) and (b).(d)A worker already in employment and declared unfit by the Certifying Surgeon
shall not be allowed to work on any of the processes specified in clause I, unless he has been
examined again and has been certified to be cured and fit to work on the said process again.(e)A
worker declared to be unfit to work on any of the aforesaid processes, may be employed on suchBihar Factories Rules, 1950

other work or process as may be considered safe and as may be advised by the Certifying Surgeon
:Provided that if the Certifying Surgeon declares that a worker has been completely incapacitated
and he was not fit to be employed on any process, such worker shall not be allowed to continue to
work on any work or process.(f)The Certifying Surgeon may direct that a worker may be X-Rayed or
he may be subject to further examination by a specialist or to any other examination, clinical,
pathological or otherwise or that he should undergo a specified treatment, and it shall be the
responsibility of the Employer (Occupier and the Manager) to arrange for the specified examination
and/or treatment and to bear all expenses thereof or in connection therewith:[Provided that in
factories in which the Employees' State Insurance Schemes is in Operation, the Certifying Surgeon
shall refer the case of insured workers to the Medical Officer Incharge of the Employees' State
Insurance Dispensary with his findings and recommendations.] [Inserted by S.O. 1877 dated
24.7.1974.](g)The Certifying Surgeon shall after such examination grant a certificate in Form
No.26.(h)The Manager shall maintain all the certificates in a proper register or file and shall
produce all the certificates before an Inspector whenever demanded.(i)The Manager shall maintain
the detail of every medical examination in Form No.17 and the register shall be produced before an
Inspector whenever demanded.(j)The term "medical examination" whenever used in this clause
means "Medical Examination carried out by the Certifying Surgeon."(k)It shall be the responsibility
of the Employer (Manager and Occupier) to get the workers medically and radiologically examined
and to bear the cost of such examinations.(l)Reports of radiological (X-Ray) examination along with
the X-Ray plate shall be produced before the Certifying Surgeon within 15 days of the examination,
for his examination, advice and such action as he may consider necessary.
XVI
Manufacture or Manipulation of Manganese and its Compounds
1. Definitions. - For the purpose of this Schedule-
(a)"Manganese process" means processing, manufacture or manipulation of Manganese or any
compound of Manganese or any ore or any mixture containing Manganese;(b)"First employment"
means first employment in any manganese process and includes also re-employment in any
manganese process following any cessation of employment for a continuous period exceeding three
calendar months;(c)"Manipulation" means mixing, blending, filling, emptying, grinding, sieving,
drying, packing, sweeping or otherwise handling of Manganese, or a compound of Manganese, or an
ore or mixture containing Manganese; and(d)"Efficient exhaust ventilation" means localized
ventilation effected by mechanical means for the removal of dust or fume or mist at its source of
origin so as to prevent it from escaping into the atmosphere of any place where any work is carried
on. No draught shall be deemed to be efficient which fails to remove the dust or fume or mist at the
point where it is generated and fails to prevent it from escaping into and spreading into the
atmosphere of a work place.
2. Application. - This Schedule shall apply to every factory in which or in any
part of which any manganese process is carried on.Bihar Factories Rules, 1950

3. Exemption. - If in respect of any factory, the Chief Inspector is satisfied
that owing to any exceptional circumstances, or infrequency of the process,
or for any other reason, application of all or any of the provision of this
Schedule is not necessary for the protection of the persons employed in
such factory he may, by an order in writing which he may at his discretion
revoke, exempt such factory from all or any of the provisions on such
conditions and for such period as he may specify in the said order.
4. Isolation or process. - Every Manganese process which may give rise to
dust, vapour or mist containing Manganese, shall be carried on in a totally
enclosed system or otherwise effectively isolated from other processes so
that other plants and process and other parts of the factory and person on
other work or process may not be affected by the same.
5. Ventilation of process. - No process in which any dust, vapour or mist
containing Manganese is generated Shall be carried out except under an
efficient exhaust ventilation which shall be applied as near to the point of
generation as practicable.
6. Medical examination. - (1) Every person employed in a Manganese process
shall be medically examined by a Certifying Surgeon within 14 days of his
first employment and thereafter at intervals of not more than three months.
(2)If a person on medical examination is found fit for employment on a Manganese process, the
Certifying Surgeon shall grant a certificate of fitness in Form No. 27 which shall be kept in the
custody of the Manager of the factory. The certificate shall be readily produced by the Manager
whenever required by any Inspector, and the certified person shall be provided with a token made of
metal with the number of the certificate inscribed thereon and the said person shall always carry the
said token on his person while at work.(3)If a person is found unfit to work on any Manganese
process the Certifying Surgeon shall grant a certificate to that effect and such person shall not be
allowed to work in any Manganese process.(4)If the Certifying Surgeon finds that any worker who
had been granted a certificate of fitness at a previous medical examination is no longer fit to be
employed on any Manganese process he may revoke the previous certificate and no person whose
certificate of fitness has been revoked shall be allowed to work on any Manganese process.The
Certifying Surgeon may require such person to be produced before him for fresh medical
examination after such period as he may specify in writing on the revoked certificate and the Health
Register.(5)If the Certifying Surgeon is of the opinion that a person had become permanently unfit
for employment of any manganese process, he shall make an entry to that effect in the certificate
and in the Health Register and no such person shall be allowed to work in any manganese
process.(6)If the Certifying Surgeon is of the opinion that a person had become permanently unfitBihar Factories Rules, 1950

for any work in any factory or any process he shall grant a certificate to that effect.(7)If the
Certifying Surgeon is of the opinion that any special expert examination or test is necessary for a
proper diagnosis in a doubtful case, he may direct the Manager and/or the Occupier, to get the
worker examined by such expert, or to get such tests carried out as may be specified by him and the
Manager and/or the Occupier, as the case may be, shall comply with direction given within the
specified time and produce the report of examination or test as the case may be before the Certifying
Surgeon.(8)If the Certifying Surgeon is of the opinion that any person is not fit for employment in
any Manganese process but is fit to be employed on any other work he may advise accordingly and
shall grant a certificate to that effect in which case the Manager and/or the Occupier may employ
the said person of such other job as may be safe for him.(9)If any person has any doubt regarding
the diagnosis of the Certifying Surgeon he may make an appeal to the Chief Inspector of Factories
and Chief Inspector may refer the case to the Medical Inspector of Factories or to a Medical
Committee constituted by him for this purpose of which the Medical Inspector of Factories shall be a
member.The decision of the Medical Inspector or the Committee as the case may be shall be final in
the matter.
7. Personal Protective Equipment. - (1) The Occupier of the factory shall
provide and maintain in good and clean condition suitable overalls and head
coverings for all persons employed in any manganese process and such
overall and head covering shall be worn by the person while working on a
manganese process.
(2)The Occupier of the factory shall provide suitable respiratory protective equipment for use by
workers in emergency to prevent inhalation of dusts, fumes or mists. Sufficient number of complete
sets of such equipment shall always be kept near the work place and the same shall be properly
maintained and kept always in a condition to be used readily.(3)The occupier shall provide and
maintain for the use of all persons employed suitable accommodation for the storage and make
adequate arrangement for cleaning and maintenance of personal protective equipment.
8. Prohibition relating to women and young persons. - No woman or a young
person shall be employed or permitted to work in any manganese process.
9. Food, drinks prohibited in the work rooms. - No food, drink, Pan, Supari or
tobacco shall be allowed to be brought into or consumed by any worker in
any work room in which any manganese process is carried on.
10. Mess-room. - There shall be provided and maintained for the use of the
persons employed in a manganese process a suitable mess room which
shall be furnished with sufficient tables and benches and adequate means
for warming of food. The mess room shall be placed under the charge of a
responsible person and shall be kept clean.Bihar Factories Rules, 1950

11. Washing facilities. - There shall be provided and maintained in a clean
state and in good condition for the use of persons employed on manganese
process, a wash place undercover, with either-
(1)a trough with a smooth impervious surface fitted with a waste pipe without plug. The trough shall
be of sufficient length to allow at least 60 centimetres for every ten such persons employed at any
one time, and having a constant supply of water from taps or jets above the trough at intervals of not
more than 60 centimetres or at least one wash basin for every five such persons employed at any
time, fitted with a waste pipe and plug and having a constant supply of water; or(2)sufficient supply
of soap or other suitable cleaning material and nail brushes and clean towels.
12. Cloak room. - If the Chief Inspector so requires there shall be provided
and maintained for the use of persons employed in manganese process a
cloak room for clothing put off during working hours with adequate
arrangement for drying the clothing.
13. Cautionary placard and instructions. - Cautionary notice in the following
form and printed in the language of the majority of the workers employed,
shall be affixed at prominent places in the factory where they can be easily
and conveniently read by the workers and arrangement shall be made by the
Occupier to instruct periodically all workers employed in a manganese
process regarding the heath hazards connected with their duties and the
best preventive measures and methods to protect themselves. The notices
shall always be maintained in a legible condition.
Cautionary NoticeManganese and Manganese Compounds.(1)Dusts, fumes and mists of Manganese
and its compounds are toxic, when inhaled or when ingested.(2)Do not consume food or drink near
the work place.(3)Take good wash before taking meals.(4)Keep the working area clean.(5)Use the
protective clothing and equipment provided.(6)When required to work in situations where dusts,
fumes, or mists are likely to be inhaled, use respiratory protective equipment provided for the
purpose.(7)If you get severe headaches, prolonged sleeplessness or any abnormal sensations on the
body, report to the Manager who would make arrangements for your examination and
treatment.[Schedule XVII] [New Schedule Inserted vide S.O. 1086 dated 12th Authst 1978,
Published in Bihar Gazette Part-II, dated August, 16, 1978.]Manufacture and Manipulation of
Dangerous Pesticides
1. Definitions. - For the purpose of this Schedule the following definitions
shall apply:-
(i)'Dangerous pesticides' means any chemical or substance used for controlling, destroying or
repelling any pest or for preventing growth thereof or for mitigating effect of such growth includingBihar Factories Rules, 1950

any of its formulations which is considered toxic under and is covered by the Insecticides Act, 1968
and the Rules made thereunder, and any other substance, which may be notified from time to time
by the State Government to be a dangerous pesticides.(ii)'Manipulation' includes mixing, blending,
formulating, filling, emptying, packing or otherwise handling.(iii)'Efficient exhaust draught' means
localized mechanical ventilation for removal of smoke gas, vapour, dust, fume or mist so as to
prevent the same from escaping in the air of any work place where any work is carried on. No
arrangement or device shall be deemed efficient if it fails to remove the smoke fume or mist
generated at the point where it originates, and which permits the substance removed to escape into
or re-enter the same or any other place of work either directly or indirectly.(iv)'First Employment'
shall mean first employment in any manufacturing process to which this Schedule applies and shall
also include reemployment in said manufacturing process following any cessation of employment
for a continuous period exceeding three calendar months.(v)'Suspension' means suspension from
employment in any process wherein a dangerous pesticides is manipulated by a written certificate in
the Health Register in Form No.16 signed by the Certifying Surgeon who shall be competent to
suspend any person employed in such process.
2. Application. - (1) This Schedule shall apply in respect of all factories or any
plant of any factory in which the process of manufacture or manipulation of
any dangerous pesticide hereinafter referred to as the said "Manufacturing
process" is carried on.
(2)These Rules shall be in addition and not in derogation to any other provisions of the Act or the
Rules or to the provisions of any other Act in force.
3. Instruction of workers. - Every worker on his first employment shall be
fully instructed on the properties including dangerous property of the
chemical used or handled in the said manufacturing process and the hazards
involved. The worker shall also be instructed in the measures to be taken to
deal with any emergency. Such instructions shall be repeated periodically.
4. Cautionary Notice and placards. - Cautionary notices and placards in the
form specified in Appendix I of this Schedule and printed in the language of
the majority of the workers shall be displayed in all work places in which the
said manufacturing process is carried on so that they can be easily and
conveniently read by the workers.
5. Prohibition relating to employment of women or young persons. - No
woman or young person shall be employed or permitted to work in any room
in which the said, manufacturing process is carried on or in any room in
which any dangerous pesticide is stored.Bihar Factories Rules, 1950

6. Food, drinks and smoking prohibited. - (1) No food, drink, tobacco, pan or
supari shall be brought in or consumed by any worker in any work room in
which the said manufacturing process is carried out.
(2)Smoking shall be prohibited in any work room in which the said manufacturing process is carried
out.
7. Medical Examination. - (1) Every worker proposed to be employed in the
said manufacturing process shall be examined by a Certifying Surgeon
before his first employment and shall be employed on the said
manufacturing process only, if declared fit for such employment and a
certificate to this effect is granted in Form No. 24.
(2)Every worker already employed on the said manufacturing process on the date on which these
Rules come into force shall be examined by a Certifying Surgeon within one month of the said date
and shall be allowed to continue on the said manufacturing processes only, if declared fit for such
employment and a certificate to this effect is granted in Form No. 24.(3)Every worker employed in
the said manufacturing processes shall be reexamined by a Certifying Surgeon at least once in three
calendar months and a record thereof shall be kept in Form No.25.(4)No worker after suspension
shall be employed without written sanction from the Certifying Surgeon entered in or attached to
the Health Register.
8. Medical facilities. - A qualified medical practitioner shall be employed in
every factory in which the said manufacturing processes is carried on who
shall examine every worker employed on the said manufacturing process at
least once in every week and when necessary treat for the effects of
excessive absorption of the dangerous pesticides.
(2)Effective arrangements shall be made to ensure quick availability of a qualified medical
practitioner in emergency.(3)Necessary and adequate medicines and antedotes and other
equipments required for treatment of excessive absorption of dangerous pesticides shall be provided
and maintained at all times.(4)Record of examination and treatment and tests shall be maintained
in Form No. 16 and shall be made available to an Inspector for inspection.(5)The Chief Inspector
may direct by an order in writing any suitable clinical tests to be carried out at specified intervals in
respect of workers employed in any factory in which the said manufacturing process is carried on.
9. Protective clothing and protective equipment. - (1) Protective clothing
consisting of long pants and shirts or overalls with long sleeves, and head
covering shall be provided for all workers employed in the said
manufacturing process.Bihar Factories Rules, 1950

(2)(a)Protective equipments consisting of rubber gloves, gum-boots, rubber aprons, chemical safety
goggles and respirators shall be provided for all workers employed in the said manufacturing
process.(b)Gloves, boots, aprons shall be made from synthetic rubber where a pesticide contains
oil.(3)Protective clothing and equipment shall be worn by the worker supplied with such clothing
and equipment whenever he works on the said manufacturing process.(4)Protective clothing and
equipment shall be washed daily from inside and outside if the workers handle pesticides containing
nicotine or phosphorous and shall be washed as frequently as necessary, if handling other
pesticides, depending upon the nature thereof.(5)Protective clothing and equipment shall be
maintained in good repair.
10. Floors and work benches. - (1) Floors in every work room where
dangerous pesticides are manipulated shall be of cement or other
impervious material giving a smooth surface.
(2)Floors shall be maintained in good repair, provided with adequate slope leading to a drain and
thoroughly washed once a day with hose pipe.(3)Work benches where dangerous pesticides are
manipulated shall be made of smooth, non-absorbing material preferably stainless steel and shall be
cleaned at least once daily.
11. Spillage and waste. - (1) If a dangerous pesticides during its manipulation
splashes or spillis on the work benches floor or on the protective clothing
worn by a Worker, immediate action shall be taken for thorough
decontamination of the workbench, floor or protective clothing as the case
may be.
(2)Cloth, rag, paper or other material soaked or soiled with any dangerous pesticides shall be
deposited in a suitable receptacle with tight fitting cover. Contaminated waste shall be destroyed by
burning at least once a week.(3)Suitable deactivating agents, where available, shall be kept in a
readily accessible place for use in attending to a spillage.(4)Easy means of access shall be provided
to all parts of the plant for cleaning, maintenance and repairs.
12. Empty containers used for dangerous pesticides. - Containers used for
dangerous pesticides shall be thoroughly cleaned of their contents and
treated with an inactivating agent before being discarded, destroyed or
disposed of.
13. Manual handling. - (1) A dangerous pesticides shall not be required or
allowed to be manipulated by hand except by means of a long handled
scoop.
(2)Direct contact of any part of the body with a dangerous pesticides shall be avoided.Bihar Factories Rules, 1950

14. Ventilation. - (1) In every work room or area where any dangerous
pesticide is manipulated, adequate ventilation shall be provided at all times
by the circulation of fresh air.
(2)Unless the plant and the process is completely enclosed the following operations in connection
with the manipulation of a dangerous pesticides shall not be allowed to be carried out or undertaken
without an efficient exhaust draught:-(a)employing a container holding a dangerous
pesticides.(b)blending a dangerous pesticide.(c)preparing a liquid or powder formulation containing
a dangerous pesticides.(d)Changing or filling a dangerous pesticides into any container including
small size container, tank hopper or machine.(3)In the event of a failure of the exhaust draught
provided, the operations mentioned in sub-rule (2) shall be stopped forthwith.
15. Time allowed for washing. - (1) Before each meal and before end of the
day's work at least ten minutes in addition to the regular rest interval shall be
allowed for washing to each worker engaged in the manipulation of any
dangerous pesticide.
(2)Every worker engaged in the manipulation of dangerous pesticides shall have thorough wash
before consuming any food and also at the end of the day's work.
16. Washing and bathing facilities. - (1) There shall be provided and
maintained in clean state and in good repair for the use of the workers
employed on the said manufacturing process adequate washing and bathing
places having a constant supply of water under cover at the rate of one such
place for every such 5 workers employed at any one time:
Provided that the provisions of sub-rule (4) of Rule 63 relating to persons, whose work involves
contact with an injurious or noxious substance shall not apply in respect of workers employed on the
said manufacturing process:Provided further that for computation of the number of workers,
maximum number of workers employed at any one time on any day shall be the basis.(2)The
washing places shall have stand pipes placed at interval of not less than one meter.(3)Not less than
one-half of the total number of washing place shall be provided with bath-rooms.(4)Sufficient
supply of clean towels made of suitable material shall be provided:Provided that such towels shall be
supplied individually for each worker, if so ordered by the Inspector.(5)Sufficient supply of soap and
nail brushes shall be provided.
17. Cloak-rooms. - There shall be provided and maintained for the use of the
workers employed in the said manufacturing process:-
(1)a cloak-room for clothings put off during working hours with adequate arrangements for drying
of the clothings, if wet.(2)Separate cupboards or some other suitable arrangement for the storage ofBihar Factories Rules, 1950

protective clothings provided under paragraph 9.
18. Mess-room. - There shall be provided and maintained for the use of the
workers employed in the factory in which the said manufacturing process is
carried on a suitable mess-room which shall be furnished with:-
(1)Sufficient tables and benches with back-rest;(2)adequate number of wash-basins;
and(3)adequate means for warming food.The mess-room shall be placed under the charge of
wholetime attendant and shall be kept clean.
19. Exemption. - If in respect of any factory the Chief Inspector is satisfied
that owing to the exceptional circumstances or infrequency of the said
manufacturing process or for any other reason which he shall record in
writing all or any of the provisions of this Schedule are not necessary for the
protection of the workers employed in the factory, he may by an order in
writing, exempt, such factory, from all or any of the provisions of this
Schedule on such condition as he may specify therein, such order may at
any time be revoked by the Chief Inspector after recording his reasons
therefor.
20. Manipulation not to be undertaken. - Manufacture or manipulation of a
pesticide shall not be started in any factory unless a certificate regarding its
dangerous nature or otherwise is obtained from the Chief Inspector.
Appendix ICautionary NoticeInsecticides and Pesticides
1. Chemicals handled in this plant are poisonous.
2. Smoking, taking food or drink, chewing tobacco in this area is prohibited.
No food or drink shall be brought in this area.
3. Some of these chemicals may be absorbed through skin and may cause
poisoning.
4. A good wash shall be taken before every meal.
5. A good bath shall be taken at the end of the shifts.Bihar Factories Rules, 1950

6. Protective clothing and equipment supplied shall be used while working in
this area.
7. Containers of pesticides shall not be used for keeping any food staff or
drink.
8. Spillage of any chemical on any part of the body or on the floor or work
bench shall be immediately washed away with water.
9. Clothing contaminated due to splashing shall be removed immediately.
10. Scrupulous cleanliness shall be maintained in this area.
11. Do not handle pesticides with bare hands, use scoops provided with
handle.
12. In case of any sickness like nausea, vomiting, giddiness, the superior
Officer, the Manager, the Plant Medical Officer if there is any, should be
informed who will make necessary arrangements for treatment.
13. All workers shall report for the prescribed medical examination and test
regularly and when required to protect their own health.
XVIII
Process Involving Manufacture, Use, Storing, Handling or Manipulating of Benzene or any
Substance Containing Benzene.
1. Application. - This Schedule shall apply in respect of all factories or to any
part of any factory in which Benzene is manufactured, stored, handled, or
otherwise used or manipulated.
2. This Schedule shall be without any prejudice to and in addition to and not
in derogation to any provision of the Act or other Rule or of any provision of
any other Act, Rule or regulation.
3. Definitions. - For the purpose of this Schedule:-
(a)"Benzene" means an aromatic hydrocarbon C6H6 and Benzene or all substances containingBihar Factories Rules, 1950

Benzene shall be treated as "Benzene" for the purposes of this Schedule.(b)"Effective substitute"
means a chemical or any other substance which can be used as a substitute to Benzene and which is
not toxic or the toxicity of which is so low as not to be dangerous and unsafe for the health of any
human being.(c)"Enclosed apparatus" means an apparatus or system fully enclosed such that it will
not allow any escape of Benzene vapour or fume from the apparatus into the atmosphere at any
state.(d)"Efficient exhaust draught" means localised ventilation effected by mechanical or other
means for the removal of vapour or fumes so as to prevent the vapour or fume from escaping into
the air of any place in which work is carried on. No arrangement or device shall be deemed to be
efficient which fails to remove effectively vapour or fume generated at the point where it originates,
and which permits the said vapour or fume removed to escape into or re-enter the same or any other
work' place either directly or indirectly.(e)"Air-line respirator" means an apparatus for supply of air
of required purity at required temperature and pressure in properly laid out pipe line with facilities
to draw the breathing air from those pipe lines through a hose line to the face mask for the purposes
of breathing fresh and pure air.(i)Air-line respirator shall comprise containing breathable air with
facilities for necessary nose connection and shall have suitable breathing mask provided so that a
person working in poisonous or irritable atmosphere is able to breath pure and fresh air from the
pipe line during the period of work, without any harm or injury to health or discomfort to
him.(ii)Air-line respirator shall also include any other suitable apparatus for the purpose of
breathing pure and fresh air approved in writing by the Chief Inspector.
4. Cautionary Placards. - Cautionary notice in the form specified in Appendix
A attached to this Schedule and in the language of the majority of workers
employed shall be displayed at prominent places in the area, where there
may be likelihood of presence or escape of Benzene, either accidentally or
under normal condition.
5. Substitution. - [(a) Use of Benzene and substances containing Benzene is
prohibited in the following processes:-
(i)Manufacture of varnishes, paints and thinners; and(ii)cleaning and degreasing
operations.](b)Wherever any effective substitute is available, Benzene shall not be used.(c)The Chief
Inspector, by an order in writing, may allow the use of Benzene, if he is satisfied in respect of any
factory or any process that owing to the special condition or special method or work or for any other
reason it is not necessary to substitute Benzene, subject to such conditions as he may specify. He
may in his discretion at any time revoke the whole or part of such order.
6. Prohibition relating to employment of women and young persons. - No
woman or young person shall be employed or permitted to work in any room
or place in which Benzene is used.Bihar Factories Rules, 1950

7. Improper use of Benzene. - (a) Workers shall be prohibited to use Benzene
for any purpose other than the process for which the Benzene is supplied or
provided.
(b)Workers shall be instructed regarding the possible dangers arising from such misuse and a
cautionary notice in respect thereof shall be displayed.
8. Instructions as regards risks. - Every worker in his first employment shall
be fully introduced on the properties of Benzene which he may have to
handle, of the dangers involved and the precautions that would be taken.
Workers shall also be instructed on the measures to be taken to deal with
any emergency:
Provided further that such instructions shall be imparted by duly qualified medical or industrial
hygiene officer or by duly qualified safety officer or in smaller factories where such officers are not
available, by a duly qualified person and a record thereof shall be maintained in a register which
shall be signed by the instructor as well as the manager and which shall be produced for inspection
on demand.
9. Prohibition on consuming food etc., in work places. - No worker shall store
or consume food, drink, tobacco, pan or any similar article on or near any
part of the work place where Benzene is manufactured, handled, stored or
used.
10. Enclosure of process. - (a) All processes involving use of Benzene shall
be carried out in enclosed apparatus or plant.
(b)The Chief Inspector, if he is satisfied in respect of any factory or any process that owing to special
conditions or special method or work or any other reason the work or process involving the use of
Benzene may be carried out in an apparatus which is not fully enclosed he may by an order in
writing permit such a process to be carried out otherwise subject to such conditions as he may in his
order specify.He may in his discretion at any time revoke whole or part of such order.
11. Efficient exhaust draught. - Where a process using benzene cannot be
carried out in an apparatus or plant totally enclosed, the Inspector may
permit the factory to carry out such process under efficient exhaust draught
with such condition that he may specify.Bihar Factories Rules, 1950

12. Floor of work room. - The floor of every work room in which Benzene is
manufactured, used, stored, or handled shall be:-
(a)made of such material which may not absorb Benzene;(b)Smooth and impervious to
water;(c)maintained in sound condition;(d)with adequate slope and provided with efficient drains;
and(e)thoroughly washed daily by means of hose pipe and the drain water shall be led into a sewer
through a closed channel.
13. Collection of waste. - (a) A suitable receptacle made of metal with a tightly
fitting cover, shall be provided and used in each work room by depositing
wastes, like cloth, paper or other material soiled with Benzene.
(b)All such contaminated waste material shall be destroyed by burning at a safe place either when
the receptacle is full or once in a day whichever is earlier.
14. Empty containers. - Empty containers used for holding Benzene shall be
thoroughly cleaned of their contents and treated with an inactivating agent
before being discarded or disposed of.
15. Decontamination of pit, tank etc. - (a) No part of any plant which has
contained Benzene shall be repaired or opened for repair, unless it has been
emptied of Benzene, thoroughly cleaned and decontaminated and properly
tested that it does not contain any trace of Benzene.
(b)Before a worker enters a tank, pit, kettle or any other confined space which has contained
Benzene it shall be thoroughly washed and decontaminated and tested and certified by competent
person that the tank, pit, kettle, or the confined space, as the case may be, is free of Benzene and safe
for any person to enter.(c)Record of such test shall be maintained in a register which shall be signed
by the competent person and the register shall be made available for inspection whenever required
by an Inspector provided that the Chief Inspector may direct that the said register shall be
maintained in a form specified by him.
16. Proper labelling. - Every container containing Benzene shall have a
proper label which shall include the following information:-
(a)Benzene-Poisonous.(b)Benzene content-Percentage.(c)Warning about the toxicity.(d)Warning
about inflammability.(e)Appropriate symbols.Bihar Factories Rules, 1950

17. Washing facilities. - (a) At the place wherein Benzene is manufactured or
used, stored or handled there shall be provided and maintained in clean state
and in good repair washing facilities as specified below for the use of all
persons employed in the process:-
(i)An enclosed washing place under cover, with soap and towel and with at least one tap for every 10
persons working at any one time at the place and having a constant supply of water.(ii)The washing
facilities shall be located in a place easily accessible to workers.(iii)A clean towel shall be provided
individually to each worker if so directed by the Inspector.(b)All workers employed in any process in
which Benzene is used, before taking food or leaving the factory shall have a thorough wash.Proper
and adequate supervision shall be maintained over the workers so that they have thorough wash
before meals and before leaving the factory at the end of the day's work. An Inspector may by an
order in writing direct that sufficient quantity of hot water for washing during winter season shall be
provided.
18. Appropriate work clothes. - Every worker exposed to Benzene shall be
provided with suitable work clothes:
Provided that the Inspector may specify the type of work clothes to be provided to the workers
exposed to Benzene.
19. Cloak-room. - There shall be provided and maintained in a clean state and
in good repair for the use of the workers employed in processes in which
Benzene is manufactured, used, handled or manipulated-
(a)a cloak room with a locker for each worker having two compartments one for street clothes and
the other for work clothes, and(b)a place separate from the labour room and from the mess room for
the storage of protective equipments.The accommodation so provided shall be under the care of
responsible person:Provided that the Inspector may direct the factory in writing to provide suitable
drying or other facilities in the cloak room.
20. Lunch room. - There shall be provided and maintained for the use of the
workers employed in the factory and remaining on the premises during the
rest or lunch intervals, a lunch room which shall be properly ventilated and
furnished with tables and benches and means for warming food. The lunch
room shall be placed under the charge of a responsible person and shall be
kept clean and well maintained at all times.Bihar Factories Rules, 1950

21. Non-sparking tools. - No tool which is likely to produce any spark due to
impact or friction shall be allowed to be used and only non-sparking tools
shall be used in any areas where benzene vapour is likely to be present
whether normally or accidentally.
22. Safe limits for Benzene. - (1)The concentration of Benzene shall not be
allowed to exceed 25 parts of vapour or gas per million parts of air by volume
or 60 milligram per cubic meter of air, in any part of the factory:
Provided that the Chief Inspector by an order in writing may change this limit at any time as and
where he considers the same necessary.(2)Concentration of Benzene in the work environment shall
be determined at least once a day by adopting suitable tests. The result of such tests shall be entered
in a register approved by the Chief Inspector and shall be produced whenever required by the
Inspector.Immediate steps shall be taken to reduce the concentration if found in excess of the
specified safe limit. Where for special reasons workers may be exposed for short periods to
concentration which exceeds the maximum limit referred to in sub-clause (1), they shall be provided
with adequate means of personal protection against the risk of inhaling Benzene vapour or of
absorbing benzene through the skin.
23. Protective wear and equipment. - (a) Sufficient quantity of the following
protective wear and equipment of appropriate and good quality shall be
provided for the use of workers employed on any process of manufacture,
storing, using, handling or manipulating Benzene and they shall be properly
maintained so as to be always in a condition to be used:-
(1)Gloves, (2) Aprons. (3) Boots, (4) Goggles (5) Respirators, and (6) Self-contained breathing
apparatus.(b)The above equipments shall be inspected regularly and maintained in proper
conditions:Provided that the Inspector may direct that such additional protective wear as he may
specify in writing shall be provided for the use of any particular category of workers:Provided
further that in case there is any controversy or dispute regarding supply of any protective wear or
equipment the matter shall be referred to the Chief Inspector whose decision would be final.
24. Medical facilities. - (a) With the prior approval of the Chief Inspector a
qualified medical practitioner shall be appointed in every factory in which
Benzene is manufactured, used, stored, handled or manipulated to be
here-in-after called the Plant Medical Officer:
Provided that-(1)This Rule shall not apply to a factory to which sub-rules (1) and (2) of Rule 65 are
applicable; and(2)in a small factory or in a factory in which workers employed on processes of
manufacturing, storing, using, handling or manipulating of Benzene the Chief Inspector may permit
the employment of a part-time Plant Medical Officer or may permit the Certifying Surgeon toBihar Factories Rules, 1950

perform the duties of the Plant Medical Officer, subject to such conditions as he may
specify.(b)Every worker exposed to benzene shall be medically examined dnd necessary tests to
determine the condition of his health shall be carried out by the Plant Medical Officer once in every
three months:Provided that if such a worker suffers from cough or breathlessness, his condition of
health shall be immediately examined by the Plant Medical Officer and necessary steps will be taken
for his treatment.(c)The result of such examination and test shall be entered in a suitable register
which shall be produced before the Inspector, whenever required.(d)Adequate Supply of suitable
antidotes shall be maintained for treatment of acute case of poisoning.(e)For the purpose of medical
examination which the Plant Medical Officer may conduct at the factory premises shall be provided
for his exclusive use along with one adequately ventilated, lighted and furnished room with a screen
and instruments for such examination.
25. Medical Examination. - (a) Every worker employed in any process of
manufacturing, using, storing, handling, or manipulating Benzene shall be
thoroughly examined by the Certifying Surgeon within seven days following
the date of his first employment in any of the said processes and thereafter
shall be thoroughly examined by the Certifying Surgeon once in a year or at
such shorter intervals as may be specified in writing by the Chief Inspector.
The examination shall also include X-Ray of lungs and a blood test. 'First
Employment' includes re-employment in the said process following
cessation of employment in such process for a period exceeding three
months.
(b)A health register in Form No. 16 containing the names of all workers employed in the said
processes shall be maintained.(c)If the Plant Physician after examination, at any time, as per clauses
23 (a), (b) and (c) is of opinion that a person has developed signs and symptoms of Benzene
exposure he shall make a record of his findings in the said register and inform the Manager in
writing regarding the same.(d)A worker so found exposed, shall be sent to the Certifying Surgeon
with a report of the Plant Physician. The Certifying Surgeon after satisfying himself with the findings
of the Plant Physician and conducting further examination if he considers the same necessary, may
issue an order for temporary suspension of the person from work in the said process or may advice
the worker to be employed on some other work which may be safe for him, or may declare him to be
permanently unfit as the case may be.(e)The medical examination of workers shall be arranged by
the Occupier and Manager and the person so examined shall not bear any expense for it.
26. Isolation of building and site and fire resistance. - (a) Building and plant
shall be sited with due regards to the dangers which may arise from the
processes involved and in particular shall be spaced at distances which are
deemed safe for the fire and explosion risk. Consideration shall be given to
the effect of any process carried out in adjacent factories or plants.Bihar Factories Rules, 1950

(b)Where special dangers exist, separate building shall be used for the different parts of a process.
They shall be spaced at sufficient distances apart and shielded to prevent damage to each other in
the event of fire or explosion, and shall be safeguarded by the provision of suitable blow-out panels
for roofs. Where the risk of fire or explosion is considerable, the buildings shall be divided by blast
or protective screen walls.(c)No combustible material shall be used in the erection of working
buildings, unless there are special reasons necessitating their use, in which case they shall be used
only after being rendered fire-resistant. The roof shall be of light fire resistant construction and
floors impervious fire-resistant materials and shall be regularly maintained in such condition.
27. Dangers of ignition including lighting installation. - (a) No internal
combustion engine, and no electric motor or other electric equipment
capable of generating sparks or otherwise causing combustion shall be
installed or used in a building or danger zone. Electric conductor shall be
encased in screwed steel conduit.
(b)All hot exhaust pipes shall be installed outside a building and other hot pipe inside the plant be
suitably protected.(c)Portable electric lamps shall not be used, unless of an intrinsically safe type
and portable electric tools connected by flexible wires shall not be used unless of the flame proof
type.(d)Where an inflammable atmosphere may occur, the soles of foot-wear worn by workers shall
have no metal on them, and the wheels of trucks, or conveyors shall be of a material which shall be a
good conductor and non-sparking. Adequate precautions shall be taken to prevent ignition by
sparks emitted from locomotives or other vehicles operated in the factory or on public lines.(e)No
electric arc lamp, or naked light, fixed or portable shall be used, and no person shall have in his
possession any match or any apparatus of any kind for producing a naked light or spark in, or on or
about any part of the factory, where there is any likelihood of fire or explosion from inflammable
vapour or fume, and all incandescent electric lights in such parts shall be in double air tight glass
covers.(f)Prominent notice in the language understood by the majority of the workers and legible by
day and night prohibiting smoking, the use of naked lights, and the carrying of matches or any
apparatus for producing a naked light or spark shall be affixed at the entrance of every room or place
where there is any risk of fire or explosion from inflammable vapour or fume. In the case of illiterate
workers, the contents of the notices shall be fully and carefully explained to them when they
commence work in the factory for the first time and again when they have completed one week at
the factory.(g)A sufficient supply of spades, scrappers and pails made from non-sparking materials
shall be provided for the use of persons employed in cleaning out or removing residues from any
chamber, still, tank or any other vessel wherein there may be risk of ignition or explosion, and in no
case any tool other than non-sparking tool shall be used on any such work or, while undertaking any
repair or maintenance work at any such place or plant.
28. Static electricity and lightening protection. - (a) All pipe lines and belts
and other machinery and plants on which static electricity is likely to
accumulate shall be effectively earthed. Receptacles for inflammable liquids
shall have metallic connections to the earthed supply tanks to preventBihar Factories Rules, 1950

sparking of static electricity, where necessary humidity shall be controlled.
(b)Mobile tank wagons shall be earthed during filling and discharge, and precautions shall be taken
to ensure that earthing is effective before such filling or discharge takes place.(c)Lightening
protection apparatus shall be fitted where necessary, and shall be maintained in good condition.
29. Process heating. - The method of providing heat for a process shall be
safe as possible, the heating medium shall be automatically controlled at a
predetermined temperature below the danger temperature.
30. Escape of materials. - (a) Provision shall be made in all plants sewers,
drains, flues, ducts, culverts and buried pipes to prevent the escape and
spread of any liquid, vapour or fume likely to give rise to fire or explosion,
during normal working, cleaning or overhauling or in the event of accident or
emergency.
(b)If escape occurs, such substances shall be removed expeditiously and efficiently at the point of
liberation. The effluent shall be trapped and rendered safe outside the danger area.
31. Leakage of inflammable or dangerous liquids. - Provision shall be made
to confine by means of bund, walls, sumps, etc., possible leakages from
vessels containing inflammable or dangerous liquids.
Adequate and suitable fixed fire fighting appliances shall be installed in the vicinity of such vessels.
32. Cleaning of empty containers. - (a) All empty containers which have held
inflammable or poisonous material shall be rendered permanently and
completely safe and shall not be repaired or destroyed, until their cleaning in
such manner as to make them completely and permanently safe has been
completed.
(b)Combustible and inflammable materials shall not be stored in close proximity to chemicals which
are liable to cause ignition.(c)Rubbish shall be removed from buildings without delay and placed in
special metal containers provided with close fitting lids. The contents shall be removed daily and
suitably dealt with. Waste products containing inflammable or explosive materials shall not be
placed on rubbish heaps but shall be destroyed in an appropriate manner.
33. Installing of pipe lines for inflammable liquids. - All pipe lines for the
transport of inflammable liquids shall be protected against damage or
breakage, shall be arranged so that there is no risk or mechanical damageBihar Factories Rules, 1950

from vehicles and shall be so laid that, they drain throughout without the
collection of deposits at any part. All flanged joints, bends and other
connections shall be regularly inspected. Cocks and valves shall be so
constructed that explosive residues cannot collect therein. The open and
closed positions of all cocks and valves shall be clearly indicated on the
outside.
34. Packing of reaction vessels. - Packing and joining materials for reaction
vessels (including covers, man-hole covers and ventilation pipes) and in pipe
lines and high or low temperature insulating materials shall not contain
materials which are combustible or which react with the products of the
plant.
35. Safety valves. - Every still and every closed vessel in which vapour is
evolved, and in which the pressure is likely to rise to a dangerous degree,
shall have attached to it a pressure gauge and a proper safety valve or other
equally efficient means to relieve the pressure maintained in good condition.
36. Vigorous or delayed reaction. - Suitable provisions, such as, automatic
and distant control shall be made for controlling the effect of unduly
vigorous or delayed reactions. Automatic flooding or blanketing shall be
provided for in the event of an accident.
37. Examination, testing and repair of plant. - Examination, testing and repair
of plant parts which have been in contact with explosives and inflammable
material or which is under pressure shall be carried out only by proper
supervisions.
38. Alarm system. - (a) Gravity of pressure, feed system of supplying
inflammable materials to the various parts of the buildings or plant shall be
fitted with alarm systems, automatic cut-offs or other devices to prevent
overcharging or otherwise endangering the plant.
(b)The amount of inflammable material taken into a building in bulk containers shall be kept as low
as practicable at any one time.(c)Adequate steps shall be taken to prevent the escape of inflammable
and explosive vapour from any container into the atmosphere of any building.Appendix
ACautionary Notice(Clause 4)(1)Benzene and substances containing Benzene are poisonous and
inflammable substance.(2)Handle, use and process such substances with care. In case of spils and
splashes remove contaminated clothing at once and take a wash.(3)Wear protective equipmentBihar Factories Rules, 1950

provided and keep yourself safe.(4)For better safety from these chemicals, maintain good personal
cleanliness.(5)In case of symptoms like nausea, vomiting, giddiness, nervous depression during
work, report immediately to the Factory Manger who would arrange for treatment.(6)Keep your
work place clean.(7)Benzene can be absorbed through skin, hence avoid direct contact.(8)Avoid
inhalation of the toxic vapours.(9)Smoking and taking food, drink, chewing tobacco are prohibited
in this area.(10)Report for clinical tests to protect your health.[Schedule XIX] [Inserted by S.O. 637
dated 15.4.1982 and re-numbered by S.O. 347 dated 13.3.1986.]Solvent Extraction Plants
1. Definition. - (a) "Solvent Extraction Plant" means any plant in which the
process of extraction of oil or any other substance from oil-cake, rice bran or
any other articles or substances by the use of any solvent is carried on and
the word 'Plant' wheresoever used in these Rules, unless otherwise specified
shall be deemed to mean solvent extraction plant.
(b)"Solvent" means an inflammable liquid having flash point below 120 degree F.(c)"Flame-proof"
enclosure as applied to electrical machinery or apparatus means an enclosure that will withstand,
when covers or other access doors are properly secured, the pressure of any internal explosion of
any inflammable gas or vapour which may enter or which may originate inside the enclosure
without suffering any damage and without any allowing internal inflammable or product of
explosion to the external atmosphere.(d)"Competent Person" means a person having a degree or
equivalent diploma in Mechanical or Chemical Engineering or in Chemistry with at least 5 years
experience in a chemical plant or any other person who by virtue of his other qualification and
experience is considered by the Chief Inspector to be a competent person for this purpose:Provided
that no person would be deemed to be a competent person who has not obtained a certificate of
competency from the Chief Inspector.
2. Location and Lay-out. - (a) No solvent extraction plant shall be permitted to
be constructed or extended to within a distance of 30 metres from the
nearest residential or office building.
(b)An adequate and continuous wire fencing at a height of at least 15 metres from the ground shall
be provided around the solvent extraction plant at a minimum distance o' 15 metres from any point
of the buildings of the plant.(c)No person shall be allowed to carry any match, cigarette lighter or
any other similar device or any device whereby flame or fire can be generated. Any open flame or
fire inside the area bound by the fencing.(d)Boiler houses and other buildings where any process
involving open flame or fire is carried on shall be located at least 30 metres away from the
plant.(e)If any godown or any preparatory process is at a distance of less than 30 metres from the
plant, the same shall be at a distance of not less than 15 metres from the plant, and a continuous
barrier wall of non-combustible material, at least 1.5 metres high shall be erected at a distance of not
less than 15 metres from the plant.Bihar Factories Rules, 1950

3. Electrical Installations. - (a) An electrical motors, wirings, fittings,
switches, switch gears and other electrical apparatus, installed or housed in
or close to any solvent extraction plant, shall be of flame proof
constructions, approved and certified by the Central Research Mining
Station, Dhanbad, or by any other competent authority approved in writing by
the Chief Inspector.
Note. - These Rules shall be in addition to Schedule VIII - Chemical Works - Rule 95 of the Bihar
Factories Rules, 1950 or any other relevant provision of the Factories Act, 1948 and the said Rules
shall be not in derogation of any of them.(b)All metal parts of the plant and buildings, including
pipes, tanks and containers where solvent is stored or is present and all parts of electrical equipment
not required to be energised shall be properly bounded together and connected to effectively earthed
as to avoid accidental rise in the electrical potential of such parts above the earths potential and the
earth connection shall at all times be maintained in an effective condition.
4. Restriction on Smoking. - Smoking shall be strictly prohibited within 15
metres distance from the plant. For this purpose "No Smoking"signs shall be
boldly and permanently displayed and maintained in the area in such manner
that it is clearly visible by day and by night.
5. Precautions against friction. - (a) All tools and equipments including
ladders, chains and other lifting tackle required to be used in a solvent
extraction plant shall be of non-sparking type.
(b)No machinery or equipment in solvent extraction plant shall be belt driven.(c)No person shall be
allowed to enter and work in the solvent extraction plant if wearing clothes made of Nylon or such
other synthetic fibre that can generate static electrical charge, or wearing foot-wear which is likely to
cause sparks by friction:Devices shall be provided wherever necessary in every room of the plant for
effectively discharging of body static electricity likely to be generated for wearing apparel and
equipment.
6. Fire-Fighting Apparatus. - (a) Adequate number of portable fire
extinguishers suitable for use against flammable liquid fire shall be provided
in the solvent extraction plant.
(b)An automatic water spray sprinkler system or a wetpipe or open head deluge system with
sufficient supply of water shall be provided throughout the solvent extraction plant and throughout
the building housing such plant.Bihar Factories Rules, 1950

7. Precautions against Power Failure. - Provision shall be made for the
automatic-cutting off of steam in the event of power failure and also for
emergency overhead water supply for feeding water by gravity to
condensors which shall come into play automatically with the power failure.
8. Magnetic separators. - Raw materials for use in a Solvent Extraction Plant
shall be fed to the extractor by a conveyor through a hopper, and an efficient
magnetic separator shall be provided to remove any piece of iron from the
raw materials and interlocking device shall be provided which shall stop
feeding of raw materials if magnetic separator is not working.
9. Venting. - (a) Tanks containing solvent shall be provided with emergency
vent to relieve excessive internal pressure in the event of fire.
(b)All emergency relief vents shall terminate at least 6 metres above the ground and be so located
that vapours or substances vented out may not under any circumstance so re-enter the building in
which solvent extraction plant is located or in any other building.
10. Ventilation. - The building or shed housing the solvent extraction plant
shall be well ventilated and if required the building shall be provided with
mechanical ventilation with provision for at least six air changes per hour.
11. Waste water. - Process waste water shall be passed through flash
evaporate devices to remove last traces of solvent before it is discharged
into a sump.
12. (a) Solvent shall not be stored in an area covered by solvent extraction
plant except in small quantities which shall be stored in labelled safety cans
approved by the Inspector.
(b)Waste materials such as oily rags, other wastes and absorbents used to wipe off solvent and
paints and oils shall be deposited in containers approved by the Inspector and removed from the
premises at least once a day.(c)Space within the solvent extraction plant and within 15 metres from
the plant shall be kept free from any combustible material, and any spill of oil or solvent shall be
cleaned up immediately.
13. Examination and Repairs. - (a) The solvent extraction plant shall be
examined by a competent person to determine any weakness or corrosion or
wear, once in every 12 months. Report of such examination shall, be sent toBihar Factories Rules, 1950

the Inspector with his observation as to whether or not the plant is in safe
condition to work.
(b)No repairs shall be carried out to the machinery or plant except under the direct supervision of
the competent person.(c)Suitable facility shall be provided for [purging] [Substituted by S.O. 686
dated 13.7.1988.] the plant with inert gas [on steam] [Inserted by S.O. 686 dated 13.7.1988.] before
opening for cleaning or repairs and before introducing solvent after repairs.
14. Operating personnel. - The operation of the plant and machinery in the
solvent extraction plant shall be in the charge of only such qualified and
trained persons as are certified by the competent person to be fit for the
purpose and no other person shall be allowed to operate the plant and
machinery.
15. Employment for women and young persons. - No woman or young
person shall be employed in any solvent extraction plant.
16. Vapour Detention. - (a) A suitable type of combustible gas indicator shall
be provided and maintained in good working order and a schedule of routine
sampling of atmosphere at various locations as approved by the Chief
Inspector shall be drawn out and entered in a register maintained for the
purpose.
(b)When any solvent is removed from any batch extractor by vacuum, gauges shall be provided and
tests shall be carried out to ensure that a minimum vacuum of 620 mm. (26" - 0) mercury is
obtained and maintained steadily for a minimum period of 30 minutes before the extractor is
allowed to be opened for discharge of cake or for persons to enter or for any other purpose.
17. (a) When on opening the door of a batch extractor the extracted meal
cannot be dislodged from the extractor freely, the door shall be closed and
the material reheated adequately before the door is reopened:
Provided that if even after adequate reheating, tools must be used for the removal of the extracted
meal only non-sparking tools shall be used.(b)Where solvent is removed by steam heating the
presence of the solvent shall be tested at the vent provided on the top of the vessel before opening
the vessel.(c)A log book of operations giving the following details and informations shall be
maintained and made available on demand to the Inspector:-(i)Vacuum gauge reading for each
charge.(ii)Testing of continuity of electrical bonding and earthing system.(iii)Loss of solvent every
24 hours or loss per tonne of materials used:Provided further that the Chief Inspector may require
such further information to be maintained in the log-book as he may consider necessary.Bihar Factories Rules, 1950

18. (a) An emergency action plans shall be prepared and all personnel shall
be properly trained. Training should be followed by periodic emergency
action drills.
(b)Emergency instructions shall be boldly displayed at suitable places in the language understood by
the majority of workers.
19. (a) All persons employed in the plant shall be made fully aware of the
toxic properties of the solvent being used, stored and handled.
(b)All persons exposed to any toxic solvent shall be medically examined by the Certifying Surgeon
once in six months and at more frequent intervals by the Medical Officer of the factory:Provided
that the Chief Inspector may reduce the period of six months in case he considers that more
frequent examination of the health of the workers is necessary to secure their health and
safety.[Schedule XX] [Inserted by S.O. 686 dated 13.7.1988.]Operations Involving High noise Levels
1. Application. - This Schedule shall apply to all operations in any
manufacturing process having high noise level.
2. Definitions. - (a) For the purpose of the Schedule-
(a)"Noise" means any unwanted sound.(b)"High noise level" means any noise level measured on
a-weighed Scale is 90 dB or above.Table 1
1 105*
*¾ 107
½ 110
¼ 115
* In Hindi version of Bihar Gazette these figures are 106 and 2/4 respectively.Notes. - (1) No
exposures in excess of 115 dBA is to be permitted.(2)For any period of exposure falling in between
any figures and the next higher or lower figure as indicated in column 1, the permissible noise level
is to be determined by extrapolation on a proportionate basis.Table 2Permissible Exposure Level of
Impulsive or Impact Noise.
Peak noise level in dB. Permitted number of impulses or impacts per day.
140 100
135 315
130 1,000
125 3,160
120 10,000
Notes. - (1) No exposure in excess of 140 dB peak noise level is permitted.(2)For any peak noise level
falling in between any figure and the next higher or lower figure as indicated in column 1 theBihar Factories Rules, 1950

permitted number of impulses or impacts per day is to be determined by extrapolation on a
proportionate basis.(b)For the purposes of this Schedule, if the variations in the noise level involve
maxima at intervals of one second or less, the noise is to be considered as continuous one and the
criteria given in Table 1 would apply. In other cases, the noise is to be considered as impulsive or
impact and the criteria given in Table 2 would apply.(c)When the daily noise exposure is composed
of two or more periods of noise exposure at different levels their combined effect should be
considered rather than the individual effect of
each. The mixed exposure should be considered to exceed the limit value if the sum of fraction|
C1C2CnT1T2Tn| exceed - unity:
Where the C1, C2 etc. indicate the total time of actual exposure at a specified noise level and T1 T2
etc. denote the time of exposure permissible at that level. Noise exposure of levels less than 90 dBA
may be ignored in the above calculation.(d)Where it is not possible to reduce the noise exposure to
the levels specified in sub-rule 3 (a) by reasonable practicable engineering control or administrative
measures, the noise exposure shall be reduced to the greatest extent feasible by such control
measures, and each worker so exposed shall be further provided with suitable ear protectors so as to
reduce the exposure to noise to the levels specified in sub-rule 3 (a).(e)Where the ear protectors
provided in accordance with sub-rule 3(d) and worn by a worker cannot still attenuate the noise
reaching near his ear as determined by subtracting the attenuation value in dBA of the ear
protectors concerned from the measured noise level, to a level permissible under Table 1 or Table 2
as the case may be, the noise exposure period shall be suitably reduced to correspond to the
permissible noise exposure time specified in sub-rule 3 (a).(f)(i)In all cases where the prevailing
noise levels exceed the permissible levels specified in sub-rule 3(a) there shall be administered
ineffective hearing conservation programme which shall include among other hearing conservation
measures, pre-employment and periodical auditory surveys conducted on workers exposed to noise
exceeding the permissible levels, and rehabilitation of such workers either by reducing the exposure
to the noise levels or by transferring them to places where noise levels are relatively less or by any
other suitable means.(ii)Every worker employed in areas where the noise exceeds maximum
permissible exposure levels specified in sub-rule 3 (a) shall be subjected to an auditory examination
by a Certifying Surgeon within 14 days of his first employment and thereafter, shall be re-examined
at least once in every 12 months. Such initial and periodical examinations shall include tests which
the Certifying Surgeon may consider appropriate and shall include determination of auditory
thresholds for pure tones of 125, 250, 500, 1,000 2,000 4,000 and 8,000 cycles per
second:Provided that the Certifying Surgeon may require examination of such workers by an ear
specialist and report of all such examinations shall be made available to the Certifying
Surgeon:Provided further that all costs of examination by ear specialists shall be borne by the
occupier of the factory and the persons being examined shall not bear any expenditure.[Schedule
-XXI] [Added by Notification No. S.O. 126 dated 25.7.2017 (w.e.f. 30.11.1950).]Transformation of
stone or any other material containing free silica.The following manufacturing activities shall be
considered as transformation of stone or other material containing free silica:-
1. Stone CrushersBihar Factories Rules, 1950

2. Gem and Jewellery
3. Slate Pencil Making
4. Agate Industry
5. Cement Industry
6. Pottery
7. Glass Manufacturing
1. Application of this schedule. - This schedule shall apply to all factories or
parts of factories in which the above said manufacturing activities containing
free silica is carried on.
2. Definitions. - For the purpose of this schedule -
(a)"Transformation" means crushing, breaking, chipping, dressing, grinding, sieving, mixing,
grading or handling of stone or any other material containing free silica or any other operation
involving such stone or material.(b)"stone or any other material containing free silica" means a
stone or any other solid material containing not less than 5% by weight of free silica.
3. Protective and Controlling Measures. - No Transformation shall be carried
out in a factory or part of a factory unless one or more of the following
protective and controlling measures are adopted:-
(1)Engineering Control Measures. - (i) Wet Methods: -(a)Airborne Silica Dust should be minimized
or suppressed by applying water to the process or clean up;(b)Water should be provided to drilling
or sawing of concrete or masonry.(ii)Ventilation. - (a) Local exhaust systems should be used to
remove silica dust from industrial processes.(b)Dilution / Ventilation may be used to reduce free
silica dust concentration to below the permissible limits in large areas.(c)Dust collectors / HEPA
filter should be set up so that dust shall be removed from the source and all transfer points to
prevent contamination work areas.(d)Ventilation systems should be kept in good working
conditions.(iii)Isolation. - (a) Containment methods should be used while carrying out sand
blasting.(b)Cabins of vehicles or machinery cutting & drilling that might contain free silica should be
enclosed and sealed.(iv)Dust Control. - (a) Vacuum system with High Efficiency Particle Air (HEPA)
filter shall be used to remove dust from work areas and at all transfer points.(b)The belt conveyors
transferring crushed material shall be totally enclosed throughout its length.Provided that such
control measures as above said are not necessary if the process or operation itself is such that the
level of dust created and prevailing does not exceed the permissible limit of Exposure specified in
the Second Schedule of the Act.(2)Medical Control Measures. - (i) The occupier of every factory inBihar Factories Rules, 1950

which a worker employed in the processes specified in Sub Rule 1, shall ensure that every worker
employed be examined by a Medical Inspector of Factories / Certifying Surgeon within 15 days of his
first employment. Such medical examination shall include tests for lead in urine and blood. ALA in
urine, haemoglobin content, stippling of cells and steadiness test. No worker shall be allowed to
work after 15 days of his first employment in the factory unless certified fit for such employment by
the Certifying Surgeon.(ii)Every worker employed in the said processes shall be re-examined by a
Certifying Surgeon at least once in every twelve month. Such re-examination shall, wherever the
Certifying Surgeon considers appropriate, include all the tests as specified in sub-paragraph (1)
except chest X-ray shall be read by a radiologist specialized/trained in the field of reading ILO
Radiographs on Pneumoconiosis and which will at least once in 3 Years.(iii)The Certifying Surgeon
after examining a worker shall issue a Certificate of Fitness in the prescribed Form. The record of
examination and re-examinations carried out shall be entered in the Certificate and the Certificate
shall be kept in the custody of the manager of factory. The record of each examination carried out
under sub-paragraphs (1) and (2), including the nature and the results of the tests, shall be entered
by the Certifying Surgeon in a health register Form.(iv)If at any time Certifying Surgeon is of the
opinion that a worker is no longer fit for employment in the said process on the ground that
continuance therein would involve special danger to the health of the worker he shall make a record
of his findings in the said Certificate and the health register. The entry of his findings in these
documents should also include the period for which he considers that the said person is unfit for
work in the said processes. The person so suspended from the process shall be provided with
alternate placement facilities unless he is fully incapacitated in the opinion of the Certifying
Surgeon, in which case the person affected shall be suitably rehabilitated.(v)No person who has been
found unfit to work as said in sub-paragraph (4) above shall be re-employed or permitted to work in
the said processes unless the Certifying Surgeon, after further examination, again certifies him fit for
employment in those processes.(vi)The occupier of every factory to which the schedule applies,
shall-(a)employ a qualified medical practitioner for medical surveillance of the workers employed
therein whose employment shall be subject to the approval of the Chief Inspector of Factories
and(b)provide to the said medical practitioner all the necessary facilities for the purpose referred to
in clause (a).(vii)The record of medical examination and appropriate tests carried out by the said
medical practitioner certificate of fitness and health shall be maintained in separate register
approved by the Chief Inspector of Factories, which shall be kept readily available for inspection by
the Inspector and produce on demand.(viii)The Health Records of each workman shall be kept for a
period of 40 years from the date of beginning of the employment or 10 years after the cessation of
the employment, whichever is later.(ix)The Health Records of the workers exposed to silcosis, shall
be kept up to a minimum period of 40 years from the beginning of the employment of 15 years after
retirement or cessation of the employment, whichever is later and shall be accessible to workers
concerned or their representatives.(3)Administrative Control Measures. - (i) Work place/
Environment Monitoring. - The occupier to ensure work place/ environment monitoring to be
performed to determine magnitude of exposure/concentration to evaluate engineering controls,
selecting respiratory protection, work practices and the need for medical surveillance.(a)Exposure /
concentration measurements should be made in the employee's actual breathing zone.(b)Total
sampling time shall be at least 7 hours.(c)Work place/Environment Monitoring shall be repeated
quarterly.(d)The report of dust sampling by occupier shall be made available to the
public.(ii)Training / Awareness- Workers shall be trained in the following:-(a)Health effects of freeBihar Factories Rules, 1950

silica dust exposure.(b)Operations and material that produce free silica dust hazards.(c)Engineering
controls and work practice controls that reduce dust concentration.(d)The importance of good
house keeping and cleanliness.(e)Proper use of personal protective equipment such as respirators
etc.(f)Personal hygiene practices to reduce exposure.(iii)Housekeeping: Maintenance of floors. - (a)
All floors or place where fine dust is likely to settle on and whereon any person has to work or pass
shall be of impervious material and maintained in such condition that they can be thoroughly
cleaned by a moist method or any other method which would prevent dust being airborne in the
process of cleaning once at least during each shift.(b)For this purpose dry sweeping or compressed
air shall be used for cleanup of dust or wet methods or vacuum system with a HEPA filter shall be
used.(c)Dust on over head ledges and equipment should be removed before it becomes airborne due
to vibration, traffic and random air current.(iv)Change room and washing facilities. - (a) Washing
and bathing facilities shall be conveniently located at a place easily accessible to the
workers.(b)Cloak room with individual lockers shall be provided for employees to store
uncontaminated clothing.(c)Workers shall take bath and change the work clothes before they leave
the work site.(d)Work clothes shall not be cleaned by blowing or shaking.(e)Eating / lunch areas
shall be located away from exposed areas.(v)Display of Notices. - (a) Warning signs / Posters shall
be displayed conspicuously in a prominent place.(b)The warning signs / posters shall contain the
Hazards precautions.(c)The display of notice shall be in the local language and also in the language
understood by the majority of the workers.(vi)Personal Protective Equipment. - The occupier of the
every factory to which this schedule apply shall provide the following PPEs as per relevant BIS
Standards and as applicable to a given work place.(a)Dust respirator.(b)HEPA filter respirator or
fume respirator.(c)HEPA filter respirator with full face piece.(d)Self contained breathing apparatus
(SCBA).(e)Supplied air respirator with a full face piece, helmet or hood.(f)SCBA with full face
piece.(g)Powered air purifying respirator with a HEPA filter.(vii)Prohibition relating young
person's. - No young person shall be employed or permitted to work in any of the operations
involving manipulation or at any place where such operations are carried out.(viii)Exemptions. - If
in respect of any factory, the Chief Inspector is satisfied that owing to the exceptional circumstances
or in frequency of the processes or for any other reason, all or any of the provisions of this schedule
is not necessary for protection of the workers in the factory, the Chief Inspector may be a certificate
in writing, which he may in his discretion revoke at any time, exempt such factory from all or any of
such provision subject to such conditions, if any, as he may specify therein.(ix)The notification of
silicosis and free silica related occupational diseases by Medical Practitioner / Certifying Surgeon
should be strictly enforced and in case of any violation, the Medical Practitioner/Certifying Surgeon
shall be liable to be prosecuted under sec 89 (4) of the Factories Act, 1948. The fine so collected shall
be deposited in the silicosis relief fund.
96. Notification of accidents.
(1)When any accident specified in the Schedule takes place in a factory; the manager of the factory,
shall forthwith send notice thereof by telephone, special messenger or telegram to the Inspector and
if the accident is fatal or of such a serious nature that it is likely to prove fatal notice as aforesaid
shall also be sent to-(a)the District Magistrate or Sub-divisional Officer,(b)the Officer-in-charge of
the nearest police station, and(c)the nearest relative of the injured or deceased person.(2)The notice
so given shall be confirmed by the Manager of the factory to the abovementioned authorities withinBihar Factories Rules, 1950

12 hours of the occurrence by sending to them a written report into the prescribed Form No.
17-A:Provided that the Inspector, subject to the approval of the Chief Inspector may permit any
factory or any class of factories installed for purposes connected with the Defence of India, to submit
the notice of accident in any other form if he is satisfied that the said Form furnished all the
informations as required by Form 17-A.(3)In case of every accident which is not fatal and in which
any person is injured a supplementary notice in Form No. 17-B shall be sent to the Inspector and the
Chief Inspector respectively within 7 days of the date on which the injured worker returns to work.
Schedule 34
1. Accidents which cause-
(a)death to any person'(d)such bodily injury as prevents or will probably prevent the person injured
from working for a period of 48 hours immediately following the accident.(c)such injury as may not
prevent the injured person from working immediately after the accident, but as may develop
subsequently in to an injury due to any infection or due to any other reason which may prevent the
injured person from working for not less than 48 hours during any period after the accident.
2. The following classes of accidents, whether or not they are attended by
personal injury of disablement-
(a)Bursting of a plant (including any part or accessory thereof) for containing or supplying steam
under pressure greater than atmospheric pressure.(b)Collapse or failure of a crane, derrick, winch,
hoist or other appliances used in raising or lowering persons or goods, or any part thereof, or the
overturning of a crane.(c)Explosion or fire causing or liable to cause damage to any building or
property or liable to cause any personal injury.(d)Explosion of a receiver or container used for the
storage at a pressure greater than atmospheric pressure of any gas or gases (including air) or any
liquid or solid.(e)Collapse or subsidence of any floor, gallery, roof, bridge, tunnel chimney, wall or
building forming part of a factory or within the compound or curtilage of factory.(f)Bursting of
fly-wheels, wheels of grinding machinery, or any other part of a revolving machinery, or plant.
97. Notice of poisoning or disease.
- As soon as any worker in any factory contacts any disease specified in the Schedule appended to
the Act, the Manager of the factory shall send a notice thereof in Form No. 18 to the following
authorities.(1)Chief Inspector,(2)Inspector,(3)Medical Inspector,(4)Certifying Surgeon,
Chapter X
SupplementalBihar Factories Rules, 1950

98. Procedure in appeals.
(1)An appeal presented under Section 107 shall lie to the Chief Inspector, or in cases where the order
appealed against is an order passed by that Officer, to the State Government or to such authority as
the State Government may appoint in this behalf and shall be in the form of a memorandum setting
forth concisely the grounds of objection to the order and bearing Court Fees Stamp in accordance
with Article 11 of Schedule II to the Court Fees Act, 1870, and shall be accompanied by a copy of the
order appealed against.(2)Appointment of assessors. - On receipt of the memorandum of appeal the
Appellate Authority shall, if it thinks fit or if the appellant has requested that the appeal should be
heard with the aid of assessors, call upon the body declared under sub-rule (3) to be representatives
of the industry concerned, to appoint an assessor within a period of 14 days. If an assessor is
nominated by such body, the Appellate Authority shall appoint a second assessor itself. It shall then
fix a date for the hearing of the appeal and shall give due notice of such date to the appellant and to
the Inspectors whose order is appealed against, and shall call upon the two assessors to appear upon
such date to assist in the hearing of the appeal.(3)The appellant shall state in the memorandum
presented under sub-rule (1) whether he is a member of one or more of the following bodies-(1)The
Bihar Chamber of Commerce.(2)The Bihar Sugar Mills Association.(3)The Bihar Industries
Association.(4)The Engineering Association of India.The body empowered to appoint the assessor
shall-(a)if the appellant is a member of one of such bodies, be that body;(b)if he is a member of two
such bodies, be the body which the appellant desires should appoint such assessor; and(c)if the
appellant is not a member of the aforesaid bodies, or if he does not state in the memorandum which
of such bodies he desires should appoint the assessor, be the body which the appellate body
considers as the best fitted to represent the industry concerned.(4)Remuneration of assessors. - An
assessor appointed in accordance with the provisions of sub-rules (2) and (3) shall receive for the
hearing of the appeal, also to be fixed by the State Government, subject to a maximum of fifty rupees
per diem. He shall also receive the actual travelling expenses. The fees and travelling expenses shall
be paid to the assessor by Government; but where assessors have been appointed at the request of
the appellant and the appeal has been decided wholly or partly against him, the State Government
may direct that the fees and travelling expenses of the assessor shall be paid in whole or in part by
the appellant.
99. Display of notices.
- The abstract of the Act and of the Rules required to be displayed in every factory shall be in Form
No. 19.
100.
(1)Annual Returns. - The Manager of every factory shall furnish to the Chief Inspector not latter
than the 15th January of the year subsequent to that to which it relates, a return in Form
20:Provided that-(i)The information regarding canteen shall be furnished only by the Manager of
every factory notified by the State Government wherein more than 250 workers are ordinarily
employed.(ii)The informations regarding creche shall be furnished only by the Manager of every
factory wherein more than 50 women workers are ordinarily employed, and(iii)The informationsBihar Factories Rules, 1950

regarding shelters, rest-rooms shall be furnished by the Manager of every factory wherein more than
150 workers are ordinarily employed.(2)Half Yearly Return. - The Manager of every factory shall
furnish to the Chief Inspector on or before the 15th July of each year a half yearly return in Form
21.(3)Annual Return of Holidays. - The Manager of every factory shall before the end of each year
furnish a return giving notice of all the days on which it is intended to close the factory during the
next year. This return shall be submitted whether the factory is or is not working during the year
preceding the year to which it relates:Provided that the State Government may dispense with this
return in the case of any specified factory or of any class of factories or of the factories in any
particular area:Provided further that instead of specifying the actual dates or days of holidays only
the system of grant of holidays may be mentioned in the return in case of the factories in
which-(a)Sundays are observed as weekly holiday regularly,(b)a fixed day in the week is observed as
a holiday regularly, or(c)holidays are observed according to a list approved by the Chief
Inspector:Provided further that where the Manager of any factory makes any departure from such a
holidays or a list of holidays as aforesaid, prior intimation shall be given to the Inspector.
100A.
The Occupier or Manager of every factory shall report to the State Government and to the Inspector
any intended closure of the factory or any Section or department thereof immediately it is decided to
do so or any abrupt closure of the factory or any Section or department thereof immediately it takes
place intimating the reason for the closure, the number of workers on the register on the date of the
report, the number of workers affected by the closure and the probable period of the closure. An
intimation should also be sent to the State Government and to the Inspector as soon as the factory
or the portion or the department of the factory, as the case may be, starts working again, provided
that intended closure does not include closure due to holidays.(2)The Occupier or Manager of every
factory shall furnish the information prescribed in sub-rule (I) in Form No.29.
101. Service of notices.
- The despatch by post under registered cover of any notice or order shall be deemed sufficient
service on the Occupier, Owner or Manager of a factory of such notice or order.
102. Information required by the Inspector.
- The Occupier, Owner or Manager of a factory shall furnish any information that an Inspector may
require for the purpose of satisfying himself whether any provision of the Act or Rules thereunder
has been complied with or whether any order of an Inspector has been duly carried out. Any
demand by an Inspector for any such information, if made, during the course of an inspection, shall
be complied with forthwith if the information is available in the factory, or, if made in writing, shall
be complied with within seven days of receipt thereof.Bihar Factories Rules, 1950

103. Muster roll.
- The Manager of every factory shall maintain a muster-roll of all the workers employed in the
factory in Form 22, showing (a) the name of each worker, (b) the nature of his work and (c) the daily
attendance of the worker:Provided that, if the daily attendance is noted in the Register of Adult
Worker in Form No. 12 or the particulars required under this Rule are noted in any other register, a
separate muster-roll required under this Rule need not be maintained.
103A. Overtime slips.
- Any work done by a worker beyond the normal period of work, shall be entered in a overtime slip
in Form No. 10-A in duplicate indicating therein the actual period of overtime worked by him and a
copy thereof, duly signed by the Manager or by some other responsible person shall be given to the
worker immediately after the completion of the overtime work:Provided that if the Chief Inspector is
satisfied for reasons to be recorded that it is not necessary to enforce this Rule in any factory or in
any class of factories or that any other record maintained in any factory fulfils the purpose of this
Rule, he may exempt the factory or the class of factories by an order in writing subject to such
conditions and to such extent as he may specify.
104. Register of Accidents.
- In every factory a register of accidents shall be maintained in Form No.26 in which complete
details as required to be furnished in the said Form, in respect of every accident, as specified in
Section 88 of the Act and in the Schedule attached to Rule 96, which may occur in the factory shall
be clearly and legibly entered within twelve hours of the occurrence of the accident:Provided that
the information required to be furnished in column 6 of Form 23 may be entered within twelve
hours of the return of the injured worker to his duties; and:Provided further that in case of an
accident as specified in Sub-Clause (c) of Clause (i) of the Schedule attached to Rule 96, the details
of the accident may be entered in the register within 12 hours of the time when the fact that the
injury was likely to prevent the injured person from working for not less than 48 hours comes to the
notice of the Manager or of the person under whom the said person was employed.
105. Maintenance of inspection book.
- The Manager of every factory shall maintain a bound inspection book and shall produce it when so
required by the Inspector or Certifying Surgeon.
106.
The Manager shall be responsible for the supply and replacements of tight fitting clothings referred
to in Section 22.Bihar Factories Rules, 1950

107. Railways in factories.
- Rules 108 to 122 shall apply to Railways in the precincts of a factory which are not subject to the
Indian Railways Act, 1890.
108. Gateways.
- A gateway through which a railway track passes shall not be used for the general passage of
workers into or out of a factory.
109. Barriers and turngates.
(1)Where buildings or walls contain doors or gates which open on to railway track, a barrier about 3
feet 6 inches high shall be fixed parallel to and about 2 feet away from the building or wall outside
the opening and extending several feet beyond it at either end, so that a person passing out may
become aware of an approaching train when his pace is checked at the barrier.If the traffic on the
nearest track is all in one direction, the barrier shall be in the form of an L with the end of the short
leg abutting on to the wall and the other end opening towards an approaching train.(2)If the
distance between wall and track cannot be made to accommodate such a barrier, the barrier or a
turngate shall be placed at the inside of the opening.(3)Where a footway passes close to a building or
other obstruction as it approaches a railway track, a barrier shall be fixed at the corner of the
building projecting several feet from it in a direction parallel to the track, so that person
approaching the track is compelled to move away from the building and thus obtain timely sight of a
train approaching behind it. Where the footway is too narrow to permit of this a turngate shall be
installed.
110. Crowds.
(1)Workers pay-windows, first-aid stations and other points where a crowd may collect shall not be
placed near a railway track.(2)At those times of the day when the employees are starting or ending
work, all railway traffic shall cease for not less than five minutes:Provided that the Chief Inspector
may by an order in writing exempt a specified factory from the provision of sub-rule (2) if he is
satisfied that in the special circumstances of such factory the enforcement of the Rule is not
necessary to safeguard the employees.
111. Locomotives.
(1)Every locomotives (and tender) shall be provided with efficient brakes, all of which shall be
maintained in good working order. Brake shoes shall be examined at suitably fixed intervals and
those that are worn out replaced at once.(2)Water gauge glasses of every locomotive, whatever its
boiler pressure may be, shall be protected with substantial glass or metal screens.(3)Every
locomotive shall be fitted with a"cow catcher" or if this is impracticable, with 'guard-irons', at each
end.(4)It shall be clearly indicated on every locomotive crane in English and in the vernacular forBihar Factories Rules, 1950

what weight of load and at what radius the crane is safe.
112. Wagons.
- Every wagon (and passenger coach, if any shall be provided either with continuous Self-acting
brakes or with efficient handbrakes in good working order and capable of being applied by a person
on the ground and fitted with a device for retaining them in the applied position.
113. Riding on vehicles.
(1)No person shall be permitted to be upon (whether inside or outside) any locomotive or vehicle
except where secure foothold and holds are provided.
114. Attention to brakes and doors.
(1)No vehicle shall be left unattended unless its brakes are firmly applied and, where the railway is
on a gradient, without sufficient number of properly constructed scotches placed firmly in
position.(2)No train shall be set in motion until the shunting Jamadar has satisfied himself that all
wagon doors are securely fastened.
115. Projecting loads and cranes.
(1)If the load on a wagon projects beyond its length, a guard or dummy-truck shall be used beneath
the projection.(2)Loco-crane shall travel light unless the jib is completely lowered into the running
position in line with the track.(3)When it is necessary for a loco-crane to travel with a load, the jib
shall not be swung until the crane has come to rest.
116. Loose-shunting.
(1)Loose shunting shall be permitted only when it cannot be avoided. It shall never be performed on
a vehicle not accompanied by a man capable of applying and pinning down the brakes. A vehicle not
provided with brakes in good working order and capable of being easily pinned down shall not be
loose-shunt unless attached to it at least one other vehicle with such brakes. Loose-shunting shall
not be performed with, or against a vehicle containing passengers, live-stock or explosives.(2)For
the purpose of this Rule "loose-shunting" means the placing of a vehicle by giving it such an impetus
from the locomotive that it can run along to the desired position.
117. Fly shunting.
(1)Fly-shunting shall not be permitted on any factory railway.(2)For the purposes of this Rule
"fly-shunting" means giving an impetus to vehicles as in loose shunting but with the vehicles
unattached (with or without some distance between them), and placing one vehicle (or set of
vehicles) on one track and then smartly reversing the points so that the following vehicle orBihar Factories Rules, 1950

locomotive take the other track.
118. The shunting jamadar.
(1)Every train in motion in a factory shall be in charge of properly trained jamadar.(2)Before
authorising the driver to proceed, the shunting jamadar shall satisfy himself that no person is under
or between the vehicles or on the track in front of the train. He shall not call on the driver while any
person is going off the track but only when all persons have gone off it.
119. Hand signals.
- The hand signals used by the shunting jamadar by day and night shall be those prescribed by the
Shunting Rules of Railways working under the Indian Railway Act (IX of 1890).
120. Night work and fog.
(1)In factories where employees work at night no movements of railway vehicles otherwise than by
hand shall be permitted by the Manager between sunset and sunrise unless the tracks and their
vicinity are lighted on a scale of not less than one foot candle as measured at ground level out of
doors by any recognised type of photometer or illumination meter at a time when the atmosphere is
free from dust or obscuring fumes.(2)In no circumstances shall any train be moved, otherwise than
by hand between sunset and sunrise or at any time when there is fog unless it carries a white head
light and a red rear light.
121. Speed control.
(1)Train shall not be permitted by the manager to proceed at speeds greater than four miles per
hour.(2)A train shall not be moved by mechanical or electrical power unless it is proceeded at a
distance of not less than 30 yards during the whole of its journey by the shunting jamadar. He shall
be provided with the signalling flags or lamp necessary for its control by day or by night, and with a
whistle for calling the attention of the driver:Provided that the Chief Inspector may by an order in
writing exempt a specified factory or specified part of it, or all or any of the trains traversing it, from
the operation of all or any of the provisions of this Rule on such terms and conditions as he
considers necessary for safety.
122. Railway tracks.
(1)Trains shall not be moved by power upon any railway track installed in a factory unless the
railway, its equipments and vehicles conform with this Rule.(2)The distances (a) between tracks and
(b) between tracks and buildings or blind walls and (c) between tracks and materials deposited on
the ground shall be respectively not less than:-(a)from centre to centre of parallel tracks, the overall
width of the widest wagon of that gauge plus twice the width of the door of such a wagon when
opened directly outward, plus 3 feet;(b)from a building or wall other than a loading platform to theBihar Factories Rules, 1950

centre of the nearest track, half the overall width of widest wagon of that gauge, plus the width of the
door of such wagon when opened directly outward, plus 5 feet;(c)from material staked or deposited
alongside the track, on the ground or on a loading platform, to the centre of the track, half the width
of the widest wagon of that gauge, plus the width of its door when opened directly outward, plus 3
feet:Provided that the Chief Inspector may by an order in writing exempt a specified factory or
specified part of it from all or any of the provisions of this sub-rule to such extent and on such
conditions as he deems necessary.(3)Within the factory precincts sleeper shall not be raised above
ground level.(4)All track ends shall be equipped with buffer stops of ample strength.(5)Barriers of
substantial construction shall be securely and permanently fixed across any doorway or gateway in a
building or a wall which conceals an approaching train from view, between the building and the
track as prescribed in sub-rule (1) of Rule 109.(6)Where tracks are carried on a gantry or other
elevation, a safe footway or footways with hand rails and toe-boards shall be provided at all
positions where persons work or pass on foot; and where there is an opening in the stage of an
elevated track for the dropping of material to a lower level, the position shall be adequately fenced or
the opening itself provided with a grill through which a person cannot fall.(7)All point levers shall
have their movements parallel to, not across, the direction of the track.(8)All loading platforms
which are more than 2 feet above the level of the ground on which the track is laid and more than 50
feet in length shall be provided with steps at intervals not greater than 50 feet apart to enable the
platform to be easily mounted from the track.(9)On every locomotive weighing 15 tons or more
when empty the brakes shall be capable of being applied by steam or other power as well as by hand;
or there are separate and distinct power and hand brakes.
123. Motor vehicles.
- Speed of cars. - No road motor vehicle shall be permitted to be driven at a speed exceeding [16
kilometers] [Substituted by 10 miles.] per hour within the precincts of a factory:Provided that in the
case of large factories with departments separated by considerable distances and having roads of
ample width, the Inspector may grant exemption by an order in writing from this Rule to such
extent and on such terms as he deems suitable.
124. Car lights.
- No motor vehicle shall be driven at night within the precincts of a factory unless it conforms in
respect of lights to the law in force on public roads in that locality.FormsForm No. 1Application for
Permission to Construct, Extend or Take into use any Building as a Factory.
1.Applicant's Name ...
 Applicant's Calling ...
 Applicant's Address ...
2.Full Name and Postal Address of factory. ...
3.Situation of the factory-  
 Province ...Bihar Factories Rules, 1950

 District ...
 Town or Village ...
 Nearest Police Station ...
 Nearest Railway Station or ...
 Steamer Ghat ...
4.Particulars of Plant to be installed.  
Signature of Applicant.......................Date................Note. - This application shall be accompanied by
the following documents :-(a)A flow chart of the manufacturing process supplemented by a brief
description of the process in its various stages.(b)Plans, in duplicate, drawn to scale, showing-(i)the
site of the factory and immediate surroundings including adjacent buildings and other structures,
roads, drain, etc; and(ii)the plan elevation and necessary cross-sections of the various buildings,
indicating all relevant details relating to natural lighting, ventilation and means of escape in case of
fire. The plans shall also clearly indicate the position of the plant and machinery, aisles and passage
way; and(c)Such other particulars as the Chief Inspector may require.Form No. 2Application for
Registration and Grant or Renewal of Licence for the year........., and Notice of occupation specified
in, Sections 6 and 7 (to be submitted in triplicate).
1. Full name of the factory with licence number; if already registered from
before.
2. (a) Full postal address and situation of the factory.
(b)Full address to which communications relating to the factory should be sent.
3. Nature of manufacturing process/processes-
(a)carried on in the factory during the last 12 months (in the case of factories already in
existence);(b)to be carried on in the factory during the next 12 months (in the case of all factories).
4. Names and values of principal products manufactured during the last 12
months.
5. (i) Maximum number of workers proposed to be employed on any one day
during the year.
(ii)Maximum number of workers employed on any one day during the last 12 months.(iii)Number of
workers ordinarily employed during the last 12 months.(iv)Number of workers proposed to be
ordinarily employed during the year for which licence is to be obtained.Bihar Factories Rules, 1950

6. (i) Nature and total amount of power (H. P.) installed or proposed to be
installed.
(ii)Maximum power (H. P.) proposed to be used.
7. Full name and residential address of the person who shall be the Manager
of the factory for the purpose of the Act.
8. Full name and residential address of the Occupier-
(i)The Proprietor of the factory in case of private firm/proprietary concern.(ii)Directors in the case
of a Public Limited Liability Company/firm.(iii)Where a Managing Agent has been appointed the
name of Managing Agents and Directors thereof.(iv)Shareholders in the case of a private Company
where no Managing Agents have been appointed.(v)The Chief Administrative Head in case of
Government or local fund factory.
9. Full name and address of the owner of the premises or building (including
the precincts thereof) referred to in Section 93.
10. In case of a factory constructed or extended after the date of
commencement of the Bihar Factories Rules, 1950-
(a)Reference number and date of approval of the plans for site whether for old or new building and
for construction or extension of factory by the State Government/Chief Inspector.(b)Reference
number and date of approval of the agreement, if any, made for the disposal of trade waste and
effluents and the name of the authority granting such approval.
11. Amount of fee Rs..............(Rupees........).......
(i)Paid in Treasury on vide challan no. (enclosed).(ii)Transmitted by Crossed Cheque/Postal Order
no. ..........dated.........on the bank of the.........../Post Office, drawn in favour of the Chief Inspector of
Factories.Signature of Occupier ...Date ...Signature of Manager ...Date ...Form No. 3Notice of
Change of Manager(See Rule 12-A)
1. Name of factory with licence number.
2. Postal address.
3. Name of outgoing Manager.Bihar Factories Rules, 1950

4. Name of new Manager with postal address of his residence and telephone
number, if installed.
5. Date of appointment of the new Manager.
6. Permanent and home address of the new Manager.
DateSignature of new ManagerSignature of OccupierNote 1. - This form should be completed in ink
in block letters or typed. See over Leaf for other notes.Note 2. - If power is not used at the time of
filling up this form, but is introduced latter, the fact should be communicated to the Chief Inspector
immediately.Note 3. - If any of the persons named against item 8 is minor, the fact should be clearly
stated.Note 4. - In the case of a factory, where under the proviso to sub-sections (1) and (2) of
Section 100, a person had been nominated as the Occupier, information required in item 8, should
be supplied only in the respect of that person.Note 5. - In the case of a factory where a Managing
Agent or Agents has/have been appointed as Occupier(s) under the Indian Companies Act, 1913 (VII
of 1913), information required in item 8, should be supplied only in respect of that person or
persons.Note 6. - The term "Ordinarily employed" used in item 5 means the number of workers
whose names are ordinarily borne on the Register of Attendance or Muster Roll and includes
managerial supervisory and such other staff as come within the definition of term "worker".Form
No. 4Government of BiharFactory Inspection DepartmentLicence to work a factory.Registration
No............... Fees Rs........................Granted/Renewed for the calendar year...Name of
Factory...Address and location of Factory ...Name(s) of Occupier (s) of the Factory ...Maximum
number of workers to be employedTotal Installed Capacity of Horse Power.In case of Electric
Generating and transforming stations total installed capacity in K.W's..........Chief Inspector of
Factories, Bihar.The...........19.Form No. 5Certificate of Fitness.
1.Serial No... ... ... ... ...
... ... ...Serial No... ... ... ... ... ... ...
 Date Date... ... ... ... ... ... ...
2.NameI certify that I have personallyexamined (name) ... ... ... ... son/daughter
of ... ... ... ...... . residing at ... ... ... ... ... who is desirous of beingemployed
in a factory, and that his/her age as nearly as can beascertained from my
examination, is ... ... years, and thathe/she is fit for employment in
factory as an adult/child.His/Her descriptive marks are ... ... ... ... ... ... ...
...... ... ... ... ... ... ... ... ... ... ...
3.Father's name... ... ...
... ... ... ... ...
4.Sex... ... ... ... ... ... ... ...
5.Residence... ... ... ... ...
... ...
6.Date of birth if
available and/oBihar Factories Rules, 1950

certified age... ... ...
...... ... ...
7.Physical fitness ... ... ...
... ... ... ...
8.Descriptive marks... ...
... ... ... ... ... ...
9.Reasons for -
 (1) refusal of
certificate... ... ... ... ...
... ... ...... ... ... ... ... ... ...
... ... ... ... ...
 (2) certificate being
revoked.... ... ... ... ... ...
...... ... ... ... ... ... ... ... ...
... ... ... ...
Thumb Impression.  Thumb Impression.
Initials of Certifying Surgeon  Certifying Surgeon.
Note - Exact details of cause of physical disability should be clearly stated.Form No. 6Humidity
RegisterDepartment - ... ... ... ... ... ... ... ... ... ... ... ... ... ... ... ... ... ... ... ... ... ... ... ... ... ... ... ...
...Hygrometer. Distinctive mark or number ... ... ... ... ... ... ... ... ... ... ... ... ... ... ... ...Position in
department ... ... ... ... ... ... ... ... ... ... ... ... ... ... ... ... ... ...
Date, Year, Month, DayReading of
Hygrometer.
Between 7 and 9 a.m.Between 11 a.m. and
2 p.m. (but not in
the restperiod).Between 4
and 5.30
p.m.If no
humidity
insert none.Remarks
Dry bulb Wet bulb Dry bulb Wet bulb Dry bulbWet
bulb
1st -2nd -3rd -4th -5th -6th -7th -8th
-9th -10th -11th -12th -13th -14th
-15th -16th -17th -18th -19th -20th
-21st -22nd -23rd -24th -25th -26th
-27th -28th -29th -30th -31th -     
(Signed)............Certified that the above entries are correct.(Signed)............Form No. 7Record of
Lime-washing, Paintings, etc.
Part of
Factory, e.g.
name of
room.Paint, lime washed,
painted varnished or
oiled,e.g., walls,
ceilings, wood work
etc.Treatment,
whether lime
washed painted,
varnishedor oiled.Date on which lime
washing, painting,
varnishingor oiling was
carried out (according to
the English calendar)Remarks
Day Month YearBihar Factories Rules, 1950

1 2 3 4 5 67
       
Signature of ManagerForm No. 8Report of examination of Pressure Vessel
1.Name of Occupier of factory –
2.Location and address of Factory –
3.Name, description and distinctive number of Pressure vessel. –
4.Name and address of manufacture –
5.Nature of process in which it is used –
6.Particulars of vessel –
 (a) Year of manufacture –
 (b)Date on which the vessel
was first taken into use.–
 (c) Thickness of walls –
 (d)Safe working pressure
recommended by the
manufacturer.–
 (e)History of the vessel in
brief.–
 (f)Has the examiner seen the
last examination and test
report ?–
 Was the vessel subjected to hydrostatic test ? –
 If yes, the pressure applied. –
7.Is the vessel is open, or otherwise exposed to weather or todamp ? –
8.Details of an examination made and test conducted by
theexaminer.–
9.What pressure was applied in hydraulic test was conducted bythe
examiner?–
10.What parts, if any, were inaccessible ? –
11.Condition of vessel (State any defects materially affectingthe safe
working pressure or the safe working of the vessel)–
 External –
 Internal –
12.Are fittings and appliances provided in accordance with theRules
for Pressure Plants? (Name fittings and appliancesprovided).–
13.Are all fittings and appliances properly maintained and ingood
condition? If not the defects should be recorded.–
14.Repairs, if any required,, and the period within which theyshould
be executed and any other condition which the personmaking the–Bihar Factories Rules, 1950

examination thinks it necessary to specify forsecuring safe
working.
15.Safe working pressure, calculate from dimensions and from
thethickness and other data ascertained by the present
examination,due allowance being made for conditions of working
if unusual orexceptionally severe. (State minimum thickness of
walls measuredduring the examination).–
16.Where repairs affecting the safe working pressure arerequired,
state the working pressure–
 (a)Before the expiration of
the period specified in
(15).–
 (b)After the expiration of
such period if the required
repairshave not been
completed.–
 (c)After the completion of
the required repairs.–
17.Other observations. –
I certify that on .................the pressure vessel described above was thoroughly cleaned and (so far its
construction permits) made accessible for thorough examination and that on the said date, I
thoroughly examined this pressure vessel, including its fittings and that the above is a true report of
my
examination.Signature............................Qualification.......................Address.............................Date.................If
employed by a company or association give name and address of the Company or
Association....Form No. 9Register of Compensatory Holidays
Sl.
No.Number in the register of
workersNameGroup or Relay
no.No. and date of exempting
order.Year.
1 2 3 4 5 6
      
Weekly rest
days lost
due to the
exemption
in-Date of
compensatory
holidays given
in -Lost rest
days carried
to the next
year.Remarks.
January to
MarchApril to June.July to
September.October to
December.January
to
March.April
to
June.July to
September.October to
December.
7 8 9 10 11 12 13 14 1516
          
Form No. 10Overtime Muster Roll for Examination WorkersMonth ending ... ... ... ... ... ... ... ... ... ...
19Bihar Factories Rules, 1950

No. in
RegisterName DepartmentDates on which
overtime has
been workedExtent of
overtime on
each occasionTotal overtime worked
or production in
casesplace workersNormal
hours
1 2 3 4 5 6 7
       
Normal
rate of
payOvertime
rate of payNormal
earning.Overtime
earning.Cash equivalent of
advantage accuring through
theconcessional sale of
foodgrains and other
articles.Total
earnings.Date on which
overtime
payment
made.
8 9 10 11 12 13 14
       
N.B. - Columns between overtime earning and total earnings, added by Notification No.
11/FI-1075/58 - 11988, dated 15.7.1958.Form No. 10AOvertime Slip
1. Name of the worker.
2. Token No. or the No. in the Register of adult workers.
3. Designation or nature of employment.
4. Department.
5. Work for which overtime work was done.
6. Normal hours of work (as notified in the notice of period of work)-
From To
7. Period of overtime. -
From To
8. Such additional details as may be necessary for workers whose wages is
piece rate or is a combination of time and piece rate (incentive wages).
Manager/Designation of the person if signed by a responsible person if not signed by the
Manager.Form No. 11Notice of Periods of Work for Adult Workers.Name of Factory
............................. Place ............................. District ...........................
Period of work. MenBihar Factories Rules, 1950

GroupsTotal number of
men employed.
A B CDE
Relays 1 23123123123123
On working daysFrom -To -From -To -From
-To-On partial working days From -To -From -To
-               
WomenDescription of
groups
Total number of
women employed.Nature of workGroup of
lettersRemarks
F G H I J
1 2 3 1 23123123123
               ABCDEFGHIJ   
Date on which this notice first exhibited 2000 (Signed) on Manager
Form No. 12Register of Adult Workers
Serial No.Name and
address.Father's
name.Nature
of
work.Letter of
group as
in Form
No. 11Number of
relay, if
working in
shifts.No. and date of
certificate if an
adolescent.Remarks.
No. of
certificate
and date.Token number
giving
reference to the
certificate.
1 2 3 4 5 6 7 8 9
         
[Form No. 12 A] [Inserted by S.O. 764 dated 18.6.1986.](See Rule 80-A)Identity Card of Workers
1. Name and address of the Factory. {|
PHOTO
|-| 2.| Name (with Token no.) and address of the worker.|-| 3.| Father's name.|-| 4.| Date of joining
in the factory.|-| 5.| Age (Date of birth) of workers.|-| 6.| Mark of identification.|-| 7.| Designation
or nature of work.|-| 8.| Blood group of the worker.| Signature of Occupier/Manager|-|| Signature
of the worker.Date| Date (with seal)|}Form No. 13Notice of Periods of Work for Child
Workers.Name of Factory .......................... Place ........................... District ..................
Periods of work. ChildrenDescription of
group.Remarks.
Total number of children
employed.
Groups. A B CGroup
letterNature of
workBihar Factories Rules, 1950

Relay 1 2 1 2 1 2
FromTo       ABC   
Date on which this notice is first exhibited....20(Signed)..........ManagerForm No. 14Register of Child
Workers.
Serial
No.Name
and
addressFather's
name.Date of first
employment.No. of
certificate
and its
date.Token
number
giving
reference
to
certificate.Letter
of
groups
as in
Form
13.No. of
relay, if
working
in shifts.Date of
birth or
age as
certified
by
theCertifying
Surgeon.The
nature
of his
work.Remarks.
1 2 3 4 5 6 7 8 9 10 11
           
Form No. 15Register of Leave with wages
Serial No. Date of entry into Service-
Department- Date of discharge-
Name - Adult/ChildLeave at his
credit-
Father's name-Earned in the preceding calendar
year-
Serial no. in the Register of Adult/child
workers-Earned during the current year-
Wage period from .............. to ............ Wages paid in lieu of leave.
 Amount-
 Date-
Calendar
year in
which leave
is to be
availed.Wage
period
from.......
to.........Wage
earned
during the
wage
periodNo. of days
worked during
the preceding
Calendaryear.Leave to
credit.
No. of days
of works
performed.No. of
days of
lay off.No. of days
of
maternity
leave.No. of days if
leave u/s 79
enjoyed.Total of
Columns
5 to 7.Balance of
leave carried
forward from
previousyear.Leave
earned
during the
year
preceding
the
yearmentioned
in column 1.
1 2 3 4 5 6 7 8910
          Bihar Factories Rules, 1950

Leave to
credit.
Total of
columns
9 & 10.Whether
leave in
accordance
with Scheme
underSection
79 (8) was
refused
Reference
and date.Leave
enjoyedBalance
of leave
to credit
at the end
of
theyear.Normal
rate of
wages.Cash
equivalent of
advantage
accruing
throughconcessional
sale or
foodgrains
and other
articles.Rate of
wages
for the
leave
(Period
(Total
ofCols.
16 & 17)Wages
paid for
the
leave
period
with
date.Remarks
From - To
11 12 13 14 15 16 17 18 19 20
          
Form No. 16Health Register(In respect of persons employed in occupations declared to be
dangerous operations under Section 87.)
Name of Certifying Surgeon :
(a) Mr. ....... From..... To....
(b) Mr. ....... From..... To....
(c) Mr. ....... From..... To....
Serial
No.Works
No.Name of
workers.Sex.Age (last
birthday).Date of
employment on
present work.Date of
leaving or
transfer to
other work.Reason of
leaving or
transfer or
discharge.Nature of job
occupation.
1 2 3 4 5 6 7 8 9
         
Raw material or
by-products
handled.Date of medical
examination by
Certifying
SurgeonIf suspended
from works,
state period
ofsuspension
with detailed
reasons.Re-certified fit
to resume duty
on
(withsignature
of Certifying
Surgeon).If Certificate of
unfitness or
suspension
issuedto
worker.Signature,
with date, of
Certifying
Surgeon.
       
Result of
Medial
Examination.
10 11 12 13 14 15
      
Note. - (i) Column 8 : detailed summary of reason for transfer or discharge should be
stated.(ii)Column 11 : should be expressed as fit/unfit/suspended.Form No. 17ANotice of Accident
or dangerous occurrence(To be sent forthwith to the Inspector of Factories)(See instructions onBihar Factories Rules, 1950

reverse)
1. Name of Occupier (or Factory).
2. Address of Works where accident or dangerous occurrence happened.
3. Nature of Industry.
4. Branch or Department and exact place where the accident or dangerous
occurrence happened.
5. Injured person's name and address.
6. (a) Sex.
(b)Age (last birthday and Occupation of injured (a)-(b)-(c)-person.
7. Date and hour of accident or dangerous occurrence.
8. Hour at which he started work on day of accident.
9. (a) Cause or nature of accident or dangerous (a) (a)occurrence.
(b)If caused by machinery-(i)Give name of the machine and part (b) (i)causing the accident,
and(ii)State whether it was moved by (b) (ii) mechanical power at the time.(c)State exactly what
injured person was (c) doing at the time.
10. Nature and extent of injuries (e.g., total loss of finger, fracture of leg,
scalp, scratch followed by sepsis).
11. If accident is not fatal, state whether injured person was disable for 48
hours or more.
12. Name of Medical Officer in attendance on injuredperson.
I certify that to the best of my knowledge and belief the above particulars are correct in every
respect.Signature of Occupier or Manager..............Note. - To be completed in legible hand-writing or
preferably typewritten. This space to be completed by Inspector of Factories.District ... ... ... ... ... ...
... ... ...Date of Receipt ... ... ... ... ...Accident no. ... ... ... ... ... ...Industry no. ... ... ... ... ... ... ...Causation
no. ... ... ... ... ... ...Sex. (M., W., B or G :) ... ...Other particulars (e.g., fatal, leg, injury, arm injury,
etc.).Date of Investigation ... ... ...Result of Investigation ... ...Notification of AccidentsExtract FromBihar Factories Rules, 1950

the Factories Act, 1948, (Section 88)Where in any factory an accident occurs which causes death or
which causes any bodily injury by reason of which the person injured is prevented from working for
a period of forty-eight hours or more immediately following the accident, or which is of such nature
as may be prescribed in this behalf the Manager of the factory shall send notice thereof to such
authorities, and in such form and within such time, as may be prescribed.Extract from the Bihar
Factories Rules, 1950 (Rule 96)When any accident or occurrence specified in the Schedule takes
place in a factory the Manager of the factory shall forthwith send notice thereof by telephone, special
messenger or telegram to the Inspector and if the accident is fatal, or of such a serious nature that it
is likely to prove fatal, notice as aforesaid shall also be sent to(a)the District Magistrate or
Sub-divisional Officer, and(b)the Officer-in-charge of the nearest police-station.(c)the nearest
relative of the injured or deceased person.(2)The notice so given shall be confirmed by the Manager
of the factory to the above mentioned authorities within 12 hours of the occurrence by sending to
them a written report in the prescribed Form No. 18.
Schedule 35
1. Accidents which cause-
(a)death to any person;(b)such bodily injury as prevents or will probably prevent the person injured
from working for a period of 48 hours immediately following the accident.
2. The following classes of occurrence, whether or not they are attended by
personal injury or disablement:-
(a)Bursting of a boiler or vessel used for containing steam under pressure greater than atmospheric
pressure;(b)Collapse or failure of a crane, derrick, winch, hoist or other appliance used in raising or
lowering person or goods, or any part thereof, or the overturning of a crane.(c)Explosion or fire
causing damage to any room or place in which pressure greater than atmospheric pressure of any
gas or gases (including air) or any liquid or solid resulting from the compression of gas.(d)Collapse
or subsidence of any floor, gallery, roof, bridge, tunnel, chimney, wall or building forming part of a
factory or within the compound or curtilage of factory.Form No. 17BSupplementary notice of
accident.
1. Name of the factory and location-
2. Name of the injured person-
3. Date of accident
4. Reference of the first notice of accident in Form No. 17A.Bihar Factories Rules, 1950

5. Date on which the worker returned to work
6. Man days lost due to the accident-
Signature of the Manager or OccupierForm No. 18(See Rule 97)Notice of poisoning or disease
1. Name of factory .........
2. Address and location of factory ........
3. Name of work affected by poisoning or disease.
4. Sex ........... Age
5. Serial number of the worker in the register of adult/child workers.
6. Permanent or home address of the worker.
7. Department and process or operation on which the worker was normally
employed.
8. Department, process or operation on which the worker was employed at
the time when the poisoning or disease was detected or reported.
9. Nature of poisoning/disease
10. Date on which the poisoning/disease was detected/reported.
11. Was the poisoning/disease detected or reported by the Certifying
Surgeon.
Date-Copy to-the Chief Inspector of Factories,the Inspector of Factories,the Medical Inspector of
Factories,the Certifying Surgeon.To be filled by the Chief Inspector/Inspector/Medical
Inspector,Serial no. of case ... ... ... ... ...Remarks ... ... ... ... ...(Reverse)Notice of poisoning or
diseaseExtract from the Factories Act, 1948Where any worker in a factory contracts any disease
specified in the Schedule, the Manager of the factory shall send notice thereof to such authorities,
and in such form and within such time, as may be prescribed.Extract from the Bihar Factories Rules,
1950.(Rule 97)A notice in Form No. 18 should be sent forthwith both to the Chief Inspector and to
the Certifying Surgeon, by the Manager of a Factory in which there occurs a case of Lead,
Phosphorus Mercury, Manganese, Arsenic carbon bisulphide or Benzene poisoning; or poisoning by
nitrous fumes, or by halogens or halogen derivatives of the hydrocarbons of aliphatic series, or ofBihar Factories Rules, 1950

Chrome ulceration, anthrax, Silicosis, toxic insomnia, toxic jaundice, primary Opitheliomatious
cancer of skin, or pathological manifestations due to Radium or other radioactive substance or
X-rays.Form No. 19Abstract of the Factories Act, 1948, and the Bihar Factories Rules, 1950.(To be
affixed in a conspicuous and convenient place at or near the main entrance to the
factory)Interpretation"Worker" means a person employed, directly or through any agency whether
for wages or not in any manufacturing process, or in cleaning any part of the machinery or premises
used for a manufacturing process, or in any other kind of work incidental to, or connected with, the
manufacturing process, or the subject of the manufacturing process.Working Hours, Holidays,
Intervals For Rest, Etc.
1. Hours of Work (Adults). - Sections 51 and 54. - No adult worker shall be
required, or allowed, to work in a factory for more than 48 hours in any week
and for more than 9 hours in any day.
2. Relaxation of Hours of Work (Adults). - Section 64. - The ordinary limits in
working hours of adults may be relaxed in certain special cases, e.g. workers
engaged on urgent repairs in preparatory or complementary work which
must necessarily be carried on outside the limits laid down for the general
working for the factory; in work which is necessarily so intermittent that the
intervals during which they do not work while on duty ordinarily amount to
more than the intervals for rest; in work which for technical reasons must be
carried on continuously throughout the day; in making or supplying articles
of prime necessity which must be made or supplied every day; in a
manufacturing process which cannot be carried on except during fixed
seasons, or at times dependant on the irregular action of natural forces; in
engine rooms or boiler houses or in attending to power plant or transmission
machinery in the printing of newspaper which are held up on account of the
break down of machinery in the loading and unloading of the railway
wagons, and when a worker is not relieved at the end of the period of his
work owing to the failure of reliever to come at the appointed hour.
Except in case of urgent repairs and a reliever not turning up in time the relaxation shall not exceed
the following limits :-(i)the total number of hours of work in any day shall not exceed ten;(ii)the
total number of hours of overtime work shall not exceed 50 for any one quarter;(iii)the spread-over
inclusive of intervals for rest shall not exceed 12 hours in any one day.In the case of any or all adult
workers in any factories, the ordinary limits on working hours of adults may be relaxed for a periods
not exceeding in the aggregate 3 months in any year, to enable the factory to deal with an
exceptional pressure of work, subject to the above noted conditions.Bihar Factories Rules, 1950

3. Payment of Overtime. - Section 59. - Where a worker works in a factory for
more than 9 hours in any day or for more than 48 hours in any week he shall,
in respect of overtime work, be entitled to wages at the rate of twice his
ordinary rate of wages.
Ordinary rate of wages means the basic wages plus such allowances including the cash equivalent of
the advantage accruing through the concessional sale to worker of foodgrains and other articles but
does not include a bonus.
4. Weekly Holiday (Adults). - Section 52. - No adult worker shall be required,
or allowed to work in a factory on the first day of the week, unless he has or
will have, a holiday for a whole day on one of the three days immediately
before or after the said day, and the manager of the factory has, before the
said day or the substituted day whichever is earlier, delivered a notice at the
office of the Inspector of his intention to require the worker to work on the
said day and on the day which is to be substituted and displayed a notice to
that effect in the factory:
Provided that so substitution shall be made which will result in any worker working for more than
ten days consecutively without a holiday for a whole day.Where a worker in a factory, as a result of
exemption from the ordinary provisions relating to weekly holidays, is deprived of any of the weekly
holidays, he shall be allowed, within the month in which the holidays were due to him or within the
two months immediately following that month compensatory holidays of equal number to the
holidays so lost.
5. Intervals for Rest (Adults). - Sections 55 and 56. - The periods of work of
adult workers in a factory each day shall be so fixed that no period shall
exceed 5 hours before he had an interval for rest of at least half an hour and
that inclusive of his intervals for rest they shall not spread-over more than
10½ hours in any day, or with the permission of the Chief Inspector in
writing, 12 hours.
6. Prohibition of Double Employment. - Sections 60, 71 and 99. - No child or,
except in certain circumstances an adult worker, shall be required or allowed
to work in any factory on any day on which he has already been working in
any other factory.
If a child works in a factory on any day on which he has already been working in another factory the
parent or guardian of the child or the person having custody of or control over him or obtaining any
direct benefit from his wages shall be punishable with fine, which may extend to Rs. 50 unless itBihar Factories Rules, 1950

appears to the Court that the child so worked without the consent or connivance of such parent,
guardian or person.
7. Prohibition of Employment of Children under 14. - Section 67. - No child
who has not completed his fourteenth year shall be required or allowed to
work in any factory.
8. Hours of work (Children). - Section 71 - No child shall be employed or
permitted to work in any factory for more than 4½ hours in any day and
between the hours of 7 P.M. and 6 A.M. the periods of work of all children
employed in a factory shall be limited to two shifts which shall not overlap or
spread over more than 5 hours each and each child shall be employed in
only one of the relays.
The provision relating to weekly holidays shall also apply to child workers and no exemption from
this provision may be granted in respect of any child.
9. Prohibition of Employment of Women. - Section 66. - No woman shall in,
any circumstances be employed in any factory for more than 9 hours on any
day or between hours of 7 P.M. and 6 A.M. They may be allowed to work up to
10 P.M. in special circumstances.
The change of shift of a woman worker shall take place only after a holiday.Leave With Wages
10. Leave with Wages. - Sections 79, 80 and 83 and Rules. - Every worker
who has worked for a period of 240 days or more in a factory during a
calendar year, shall be allowed during the subsequent calendar year leave
with wages for a number of days calculated at the rate of-
(i)if an adult, one day for every twenty days of work performed by him during the previous calendar
years;(ii)if a child, one day for every 15 days of work performed by him during the previous calendar
year:Provided that a period of leave shall be exclusive of all holidays which may occur during such or
at either end of the period of leave.(2)A worker, whose service commence otherwise than on the first
day of January, shall be entitled to leave with wages at the rate laid down in clause (i) or, as the case
may be, clause (ii) of sub-section (1); if he has worked for two-third of the total number of days in
the remainder of the calendar year.(3)If a worker is discharged or dismissed from service during the
course of the year he shall be entitled to wages in lieu of the leave earned till that date at the rates
specified above even if he has not worked for 240 days in that year. If a worker entitled to leave with
wages is discharged from the factory before he has taken the entire leave to which he is entitled, or if
having applied for and having not been granted such leave, he quits his employment before he has
taken the leave, the Occupier of the factory shall pay him the amount payable in respect of the leaveBihar Factories Rules, 1950

not taken and such payment shall be made before the expiry of the second working day after the day
on which his employment is terminated.The Manager shall maintain a leave with wages register in
the prescribed Form No. 15 and shall provide each worker with a book called the 'Leave Book' in the
prescribed Form No. 16. The Leave Book shall be the property of the worker and the Manager or his
agent shall not demand it except to make entries of the dates of holidays or interruptions in service
and shall not keep it for more than a week at a time. If a worker loses his Leave Book, the Manager
shall provide him with another copy on payment of six paise and shall complete it from his
record.Health
11. Cleanliness. - Section 11. - Except in cases specially exempted all inside
walls and partitions, all ceilings or tops of rooms and walls sides and tops of
passages and stair cases in a factory shall be kept white-washed or
colour-washed. The white- washing or colour-washing shall be carried out at
least once in every period of fourteen months. The floors of every workroom
shall be cleaned at least once in every week by washing, using disinfectant,
where necessary, or some other method.
12. Disposal of Wastes and Effluents. - Section 12. - Effective arrangements
shall be made in every factory for the disposal of wastes and effluents due to
the manufacturing process carried on therein.
13. Ventilation and Temperature. - Section 13. - Effective and suitable
provisions shall be made in every factory for securing and maintaining in
every workroom adequate ventilation by the circulation of fresh air and such
a temperature as will secure to workers therein reasonable conditions of
comfort and prevent injury to health.
14. Overcrowding. - Section 16. - Unless exemption has been granted there
shall be in every workroom of a factory in existence on 1st April, 1949 at least
350 cubic feet and of a factory built after this date at least 500 cubic feet of
space for every worker employed therein and for this purpose no account
shall be taken of any space which is more than 14 feet above the level of the
floor of the room.
15. Lighting. - Section 17. - In every part of a factory workers are working or
passing, there shall be provided and maintained sufficient and suitable
lighting, natural or artificial or both.Bihar Factories Rules, 1950

16. Drinking water. - Section 18. - In every factory effective arrangements
shall be made to provide and maintain at suitable points, conveniently
situated for all workers employed therein, a sufficient supply of whole-some
drinking water.
In every factory wherein more than 250 workers are ordinarily employed the drinking water shall,
during the hot weather, be cooled by ice or other effective methods. The cooled drinking water shall
be supplied in every canteen, lunchroom and rest room and also at conveniently accessible points
throughout the factory.
17. Latrines and urinals. - Section 19 and Rules. - In every factory, sufficient
latrine and urinal accommodation of the prescribed type (separate enclosed
accommodation for male and female workers) shall be, provided
conveniently situated and accessible to workers at all times while they are at
the factory. Every latrine shall be under cover and so partitioned off as to
secure privacy and shall have proper door and fastenings. Sweepers shall be
employed whose primary duty it would be to keep clean latrines, urinals and
washing places.
In every factory, wherein more than 250 workers are ordinarily employed, all latrines and urinals
accommodation shall be of prescribed sanitary type.
18. Spittoons. - Section 20. - In every factory, there shall be provided a
sufficient number of spittoons of the type prescribed in convenient places
and they shall be maintained in a clean and hygienic condition. No person
shall spit within the premises of a factory except in the spittoons provided
for the purpose. Whoever spits in contravention of this provision shall be
punishable with fine not exceeding five rupees.
Safety
19. Fencing of Machinery. - Section 21. - In every factory dangerous parts of
machines, e.g. every moving part of a prime-mover and every flywheel
connected to a prime-mover, etc, etc, shall be securely fenced by safeguards
of substantial construction which shall be kept in position while the parts of
machinery they are fencing are in motion or in use.Bihar Factories Rules, 1950

20. Work on or near Machinery in motion. - Section 22. - No woman or child
shall be allowed in any factory to clean, lubricate or adjust any part of the
machinery while that part is in motion, or to work between moving parts, or
between fixed and moving parts of any machinery which is in motion.
21. Employment of Young Persons on Dangerous Machinery. - Section 23. -
No young person shall work at any machine declared to be dangerous unless
he has been fully instructed as to the danger arising in connection with the
machine and the precautions to be observed and has received sufficient
training in work at the machine or is under adequate supervision by a person
who has a thorough knowledge and experience of the machine.
22. Prohibition of Employment of women and children near Cotton Openers. -
Section 27. - No woman or child shall be employed in any part of a factory for
pressing cotton in which a cotton opener is at work.
23. Excessive Weights. - Section 34. - No woman or young person shall
unaided by another person lift, carry or move by hand or on head, any
material, article, tool or appliance exceeding the following limits :-
Adolescent male ...65 lbs.
Adolescent female ...45 lls.
Male child ...35 lbs.
Female child ...30 lbs.
24. Protection of Eyes. - Section 35. - Effective screens or suitable goggles
shall be provided for the protection of person employed in or in the vicinity
of processes which involve risk of injury to the eyes from particles or
fragment thrown off in the course of the process which involves risk or injury
to the eyes by reason of exposure to excessive light.
25. Washing Facilities. - Section 42. - In every factory adequate and suitable
facilities for washing shall be provided and maintained for the use of the
workers therein. Such facilities shall include soap and nail brushes or other
suitable means of cleaning and the facilities shall be conveniently accessible
and shall be kept in a clean and orderly condition.
If female workers are employed separate facilities shall be provided and so enclosed or screened that
the interiors are not visible from any place where persons of the other sex work or pass.Bihar Factories Rules, 1950

26. First-Aid Ambulance Room. - Section 45. - There shall in every factory be
provided, and maintained so as to be readily accessible during all working
hours first-aid boxes or cupboards equipped with the prescribed contents.
All such boxes and cupboards shall be kept in the charge of a responsible
person who is trained in first-aid treatment and who shall always be available
during the working hours of the factory. The number of first aid boxes shall
not be less than one for every 150 workers ordinarily employed.
In every factory wherein more than 500 workers are employed there shall be provided and
maintained an ambulance room of the prescribed size and containing the prescribed equipments.
The ambulance room shall be in charge of a qualified medical practitioner assisted by atleast one
qualified nurse and such other staff as may be prescribed.
27. Canteen. - Section 46 and Rules. - In specified factories wherein more
than 250 workers are ordinarily employed, a canteen or canteens shall be
provided and maintained by the occupier for the use of the workers. Food,
drink and other items served in the canteen shall be sold on a non-profit
basis and the prices charged shall be subject to the approval of a Canteen
Managing Committee which shall be appointed"by the Manager and shall
consist of an equal number of persons nominated by the Occupier and
elected by the workers. The number of elected workers shall be in the
proportion of 1 for every 1000 workers employed in the factory provided that
in no case shall there be more than 5 or less than 2 workers on the
Committee. The Committee shall be consulted from time to time as to the
quality and quantity of foodstuffs to be served in the Canteen, the
arrangement of the menus, etc.
28. Shelter, Rest Rooms and Lunch Rooms. - Section 47. - In every factory
wherein more than 150 workers are ordinarily employed, adequate and
suitable shelters or rest rooms and a suitable lunch room with provision for
drinking water, where workers can eat meals brought by them shall be
provided and maintained for the use of the workers.
29. Creches. - Section 48 and Rules. - In every factory wherein more than 50
woman workers are ordinarily employed there shall be provided and
maintained a suitable room or rooms for the use of children under the age of
six years of such women. The creches shall be adequately furnished and
equipped and in particular there shall be one suitable cot or a cradle with theBihar Factories Rules, 1950

necessary bedding for each child, at least one chair or equivalent seating
accommodation for the use of the mother while she is feeding or attending to
her child and a sufficient supply of suitable toys for older children.
There shall be in or adjoining the creche a suitable wash-room for the washing of the children and
their clothing. An adequate supply of clean clothes, soap and clean towels shall be made available for
each child while it is in the creche. At least half a pint of clean pure milk shall be available for each
child on every day it is accommodated in the creche and the mother of such child shall be allowed in
the course of her daily work suitable intervals to feed the child. For children above two years of age,
there shall be provided, in addition an adequate supply of whole some refreshment. A suitable,
fenced and shady open air play-ground shall also be provided for the older children.
30. No charge for Facilities and Conveniences. - Section 114. - No fee or
charge shall be realised from any worker in respect of any arrangements or
facilities to be provided or any equipments or appliances to be supplied by
the occupier under the provisions of the Act.
31. Obligation of workers. - Sections 97 and 111. - No worker in a factory-
(i)shall wilfully interfere with or misuse, any appliance convenience or other thing provided in a
factory for the purposes of securing the health, safety or welfare of the workers therein;(ii)shall
wilfully and without any reasonable cause do any thing likely to endanger himself or others;
and(iii)shall wilfully neglect to make use of any appliance or other thing provided in the factory for
the purpose of securing the health or safety of the workers therein.If any worker employed in a
factory contravenes any of these provisions or any Rule or order made thereunder, he shall be
punishable with imprisonment for a term which may extend to three months, or with fine which
may extend to Rs. 100 or with both.If any worker employed in a factory contravenes any provision of
the Act or any Rule or orders made thereunder imposing any duty or liability on workers he shall be
punishable with fine which may extend to Rs. 20.
32. A notice of periods of work for adults and a notice of periods of work for
children in the prescribed Form Nos. 11 and 13 shall be correctly maintained
and displayed in every factory. No adult worker or child shall be required or
allowed to work in any factory otherwise than in accordance with their
respective notices of periods of work displayed in the factory.
The Owners, Occupiers or Managers of factories shall submit the prescribed periodical returns to
the Inspector regularly.[Form No. 20] [Substituted by S.O. 686 dated 10.7.1988.][Prescribed under
Rule 100(1)]Annual Return for year ending 31st December, 200.Bihar Factories Rules, 1950

1. Registration number of factory ...
2. Name of factory ...
3. Name of Occupier...
4. Name of the Manager...
5. District...
6. Full postal address of factory ...
7. Nature of Industry...
Number of workers and particulars of employment.
8. No. of days worked in the year.
9. No. of man-days worked during the year-
(a)Men(b)Women(c)Children
10. Average number of workers employed daily (see explanatory note) :-
(a)Adults-(i)Men(ii)Women(b)Adolescent-(i)Men(ii)Women(c)Children-(i)Men(ii)Women
11. Total no. of man-hours worked including overtime:-
(a)Men(b)Women(c)Children
12. Average number of hours worked per week (see explanatory note)-
(a)Men(b)Women(c)Children
13. (a) Does the factory carry out any process or operations declared as
dangerous under Section 87 (see Rule 95)
(b)If so give the following information-
Name of the dangerous process or
operations carried on -Average no. of persons employed daily in each of the
processesor operations given in col. 1.Bihar Factories Rules, 1950

(i)(ii)(iii)etc. Leave with Wages.
14. Total number of workers employed during the year.......
(a)Men(b)Women(c)Children
15. Number of workers who were entitled to annual leave with wages during
the year-
(a)Men(b)Women(c)Children
16. Number of workers who were granted leave during the year-
(a)Men(b)Women(c)Children
17. (a) Number of workers who were discharged or dismissed from the
service, or quit employment or were superannuated, or died while in service
during the year,
(b)Number of such workers in respect of whom wages in lieu of leave were paid.Safety Officers
18. (a) Number of Safety Officers required to be appointed as per Rule
notified under Section 40-B.
(b)Number of Safety Officers already appointed.Ambulance room
19. Is there an ambulance room provided in the factory as required under
Section 45?
Canteen
20. (a) Is there a canteen provided in the factory as required under Section
46?
(b)Is the canteen provided managed-(i)departmentally, or(ii)through a contractor?Shelters or Rest
Room and Lunch Rooms.
21. (a) Are there adequate and suitable shelters or rest rooms provided in the
factory as required under Section 47?Bihar Factories Rules, 1950

(b)Are there adequate and suitable Lunch rooms provided in the factory as required under Section
47?Creches
22. Is there a creche provided in the factory as required under Section 48?
23. (a) Number of Welfare Officers to be appointed as required by Rule
notified under Section 49.
(b)Number of Welfare Officers appointed.
24. (a) Total number of accidents (see explanatory note)-
(ii)None-fatal.,(b)Accidents in which workers returned to work during the year to which this return
relates-(i)Accidents (workers injured) occurring during the year in which injured worker returned to
work during the same year-(aa)Number of accidents,(bb)Man days lost due to
accident.,(ii)Accidents (worker injured) occurring in the previous year in which injured workers
returned to work during the year to which this return relates-(aa)Number of accidents,(bb)Man days
lost due to accidents.(c)Accidents (worker injured) occurring during the year in which injured
workers did not return to work during the year to which the return relates-(i)Number of accidents
...(ii)Man days lost due to accidents.Certified that the information furnished above is to the best of
my knowledge and belief, correct.Date......Signature of the Manager.Explanation. - (1) The average
number of workers employed daily should be calculated by dividing the aggregate number of
attendance on working days (that is, man days worked) by the number of working days in the year.
In reckoning attendance, attendance by temporary as well as permanent employees should be
counted and all employees should be included, whether they are employed directly, or under
contractors. Attendance on separate shifts (e.g. night and day shifts) should be counted separately.
Days on which the factory was closed for whatever cause, and days on which the manufacturing
processes were not carried on should not be treated as working days partial attendance for less than
half a shift on a working day should be ignored, while attendance for half a shift or more on such
days should be treated as full attendance.(2)For seasonal factories, the average number of workers
employed during the working seasons and the off seasons should be given separately. Similarly the
number of days worked and average number of man-hours worked per week during the working and
off season should be given separately.(3)The average number of hours worked per week means the
total actual hours worked by all workers during the year excluding the rest intervals but including
overtime work divided by the product of total number of workers employed in the factory during the
year and 52. In case the factory has not worked for the whole year the number of week during which
the factory worked should be used in place of the figure 52. In case the factory has not worked for
the whole year, the number of weeks during which the factory worked should be used in place of the
figure 52.(4)Every person killed or injured should be treated as one separate accident. If in one
occurrence six persons were injured or killed. It should be counted as six accidents.(5)In item 24(c),
the number of accidents which took place during the year should be given. In case of non-fatal
accidents only those accidents which prevented workers from working for 48 hours or more should
be indicated.Form No. 21Half yearly returnPeriod ending 30th June 19/31st December, 200Bihar Factories Rules, 1950

Name of Factory ...
Name of Occupier ...
Name of Manager ...
(1) District ...
(2) Postal Address ...
(3) Nature of Industry ...
*(4)Average number of workers
employed daily- 
 Men ...
 Women ...
Adolescents ...
 Male ...
 Female ...
Children ...
 Male ...
 Female ...
(5)Number of days worked
during the year ending 30th
June, 200.
Certified that the information furnished above is to the best of my knowledge and belief
correctSignature of Manager.* The average daily number should be calculated by dividing the
aggregate number of attendances on working days by the number of working days during the
half-year. In reckoning attendances by temporary as well as permanent employees should be
counted, and all employees should be included, whether they are employed directly or under
contractors. Attendances on separate shifts (e.g. night and day shifts) should be counted separately.
Days on which the factory was closed, for whatever cause, and days on which the manufacturing
process were not carried on should not be treated as working days.Form No. 22Muster RollName of
Factory ... ... ... ... ... ... ... ... Place ... ... ... ... ... district ... ... ... ... ... ...
Serial no. Name Father's name Nature of work For the period ending Remarks
    1 2 345    
[Form No. 23] [Substituted by S.O. 180, dated 6.12.1975.]Register of Accidents.
Serials no.
of
accidentsDate and
time of
accidentName of
persons
injured
and
killedName &
nature of
accidentDate of
reporting
(in Form
No. 17) to
Inspector.Date of
return of
injured
person.No. of days
injured
person work
due to
theaccident.Signature
of the
Manager
or any
person
dulyauthorised
in writing
by the
Manager.Bihar Factories Rules, 1950

Injured Killed PlaceBrief
Description.
1 2 3 4 5 6 7 8 910
          
Provided further than in case of an accident as specified in sub-clause (c) of clause (i) of the
schedule attached to Rule 96, the details of the accident may be entered in the register within 12
hours of the time when the fact that the injury was likely to prevent the injured person from working
for not less than 48 hours comes to the notice of the Manager or of the person under whom the said
person was employed.Form No. 24Special Certificate of Fitness(In respect of persons employed in
operations involving use of Lead compounds.)Serial no. ... ...Date ... ...I hereby certify that I have
personally examined .............................................................. son of
.............................................................. residing at ........................................... who is desirous of
being employed as ....................................... and that his/her age as nearly as can be ascertained from
my examination is............................................. years, and that he/she is in my opinion, fit for
employment at work involving the use of Lead compounds. His/her descriptive marks are:
….................................................................................................….................................................................................................
L.T.I. of person examined.Certifying
Surgeon.
I certify that I examined the
person mentioned above on.....I extend this
certificate until...Signature of
Certifying Surgeon.Note of symptom of
Lead poisoning if any.
    
Form No. 25Certificate of Fitness for Dangerous Operations.s(Rule 96)
1. Serial Number.2. Name of person
examined.3. Father's name.4. Sex.5.
Address.6. Name of the factory in
whichemployed/in which wishes to
be employed.7. Process of
department in
whichemployed/wishes to be
employed.8. Whether certificate
granted.9. Whether declared unfit
andcertificate refused.10. Reference
number of previouscertificate
granted or refused.L.T.I. of persons
examined.Signature of Certifying
Surgeon.Serial NumberI certify that I have
personallyexamined............... (Name) son of..............
(Father'sname) residing at................ (address) who is
desirable ofbeing employed as............... (Name of
factory)in............... (Dept. & Process),............ that asnearly as
can be ascertained from by examination, he is fit/unfitfor
employment at the above noted factory.2. He is fit to be
employed and maybe employed on some other non hazardous
operation such as.......3. He may be produced for
furtherexamination after a period of...4. He is advised
following furtherexaminations..........5. He is advised
followingtreatment.6. The serial number of theprevious
certificate is.................L.T.I. of the person
examined.Signature of Certifying Surgeon.NOTE. - 1. The
counterfoil shouldbe retained by the Certifying Surgeon and
maintained in a boundbook or in a file.2. The para which does
not applymay be cancelled.
Form No. 26Register of Surgeon's Fees for the issue of Duplicate Certificates.Paid into Treasury at ...
... ... ... ... ... ... on (date) ... ... ... ...Signature of Certifying Surgeon.
Date Serial no. Number of previous
certificate.Name of person to whom
granted.Initial of
CertifyingBihar Factories Rules, 1950

Surgeon.
1 2 3 4 5
     
Form No. 27Certifying Surgeon's Visit Note.Visit to (Factory) on (date) ..... 200Name of Certifying
SurgeonExamination and Certificates(A)Children-
1. Original examination .... Number examined ... Number granted certificates..
2. Examination of those holding provisional certificates .... Number examined
............. Number granted certificates Number of impounded provisional
certificates....
3. Re-examination of those holding
certificates.....Number-examined.........Number of certificates
cancelled.......Reason for cancellation in each case (i.e., general nature of
unfitness)
(B)Adolescents-
1. Original examination....Number examined Number granted certificates...
2. Examination of those holding provisional certificates...Number examined
Number granted certificates....Number of impounded provisional certificates..
3. Re-examination of those holding certificates....Number examined Number
of certificates cancelled....Reason for cancellation in each case (i.e., general
nature of unfitness)...
SignedCertifying SurgeonForm No. 28Diary of Inspector of FactoriesFor the week ending Saturday
the ... ... ... ... ... ... 200 ....
DateFactories visited or other work done (if visitedfor a
special purposes, state what.)Defects found and order
issued. Remarks
Sunday ...   
Monday   
Tuesday   
Wednesday   
Thursday   
Friday   Bihar Factories Rules, 1950

Saturday   
Reverse Side of Form No. 28
Analysis of visits, etc.Under the Act at time
of first visit.Not under the Act at
time of first visit.Found
closed.Remarks
Factories visited, etc.     
" " twice ...     
" " thrice...     
" " more than thrice.     
Time (etc.) of visit... Factories... Visits ...   
During legal working hours.     
During rest intervals ...     
Before or after legal working
hours.    
On Sundays or holidays.     
For enquiring into accidents.     
For special purpose ...     
Total...     
Number of factories visited
(all classes).    
Number of visits paid (all
classes).    
The prosecution against
occupied....days    
Prosecutions... Other work, if
any days....    
Signature.......................Inspector of FactoriesDate......................Form No. 29Closure Report of
Factory
Name of the Factory .........
Registration number of Factory .........
Name of Occupier .........
Name of Manager .........
Postal Address .........
Name of section or
department which has
closed.If the whole
factory has closed
please write "Total
closure"Date of
closure.Reason
of
closure.Number of workers
on the register of
factory orpart of the
factory which is
closed on the date
of closure.Number of
workers
affected by
the closure.Probable
period of
closure.Remarks
1 2 3 4 5 6 7Bihar Factories Rules, 1950

       
Form No. 30(See Rule 57-A)Register of Water-sealed Gas-holder
1.Name and address of Factory ..................
2.Distinguishing number of the gas-holder ..................
3.Location and department ..................
4.Type of gas-holder ..................
5.Fuel used ..................
6.Name and address of manufacturer ..................
7.Date of manufacture ..................
8.Capacity in cu. metres/cu. ft ..................
9.Number of lifts ..................
10.Pressure thrown by holder when full of gas ..................
Serial no.Date of
examination
carried on
under
sub-rules(4)
and (5).Name,
qualifications,
designation of
examiningperson.Method and
details of
examination
carried out.Remarks and
observations
of the
examining
person.Signature
of the
examining
person.Signature
of the
Manager
or
Occupier.Details with
dates of
painting
overhauling
otherroutine
maintenance
work carried
out.Details with
dates of
repairs,
modifications
oralternations
carried out.Signature
with date
of
Manager
or
Occupier.
Particulars
and
description.Name,
qualification
and
designation
of the
personcarrying
out the
repairs.
1 2 3 4 5 6 7 8 9 10 11
           
Note. - Separate page will be allotted to each gas-holder.Form No. 31(See Rule 57-A)Report of
examination of Water sealed Gas-holder
Part I – 1. Name and address of the Factory.
2. Department where the gas-holder is located.
3. Details of the Gas-holder. -
(a)Distinguishing number of the gas-holder.(b)Type and description of the gas-holder.(c)Name and
address of the manufacturer.(d)Date of manufacture.(e)Other details, if any.Bihar Factories Rules, 1950

4. Particulars of gas to be stored in holder.
5. Particulars of the condition of the following as observed at the time of
examination:-
(a)Crown.(b)Side sheeting, including grips and cups.(c)Guiding mechanism, (Roller carriages,
rollers, pins, guide rails and ropes).(d)Tank.(e)Other structure, if any, including columns, framing
and bracing.(f)Any other observation.
6. Particulars of the position of the lift as observed at the time of
examination.
7. Were the tank and lifts found sufficiently level for safe working ?
If not, the steps necessary to remedy the defects.
8. Fittings and appliances-
(a)Are all fittings and appliances properly maintained and in a good condition ?(b)Repairs if any,
required.(c)The period within which the repairs must be carried out.
9. Any other condition or measure that the examining person may consider
necessary for safe working of the gas-holder.
10. Is the gas-holder in such a condition as not to be considered safe to be
kept in operation ?
11. Other remarks and observations.
12. Date of Examination.
I certify that on the gas-holder described above was thoroughly examined and such of the tests as
were necessary made on the same day and that the above is a true report of my
examination.Signature of the Examiner.(Full
name.........................................)Date.....................................Qualifications......................Address
..............................Signature of Manager or Occupier.
Part II
Detail of the repairs carried out or other steps or measures taken to remove the defects and to
comply with the suggestions, recommendations and observations made by the examining personBihar Factories Rules, 1950

with dates.
Details. Dates.
(1)  
(2)  
(3)  
Signature of Manager or Occupier.Form No. 32Register of trained adult male workers employed to
carry out mounting or shifting of Belts, Lubrications, etc.[Section 22 (1) and Rule 59-A]
1. Name of the Factory, location and address
2. Registration number.............................
Sl.
no.Name of
the
worker.Serial no. in register of
adult workers
(formno....) and ticket
number if any.Department in
which
employed.Work on which
employed. Details
of training.Signature of
Manager.Remarks.
1 2 3 4 5 6 7
       
Form No. 33Certificate to young person considered fit to work at Machine, Plant or Process of
dangerous character
1. Serial number...
2. Name of the Factory and location ...
3. Registration number of Factory ...
4. Name of the young person ...
5. Serial number in the register of adult worker (Form no...) or register of
child workers (Form no...)
6. Number and reference of the certificate of fitness granted by the Certifying
Surgeon.
7. Department and machine,, plant and process on which the young person is
to be employed.
Certified that the young persons mentioned above have been fully instructed by me as to the dangersBihar Factories Rules, 1950

arising in connection with the Machine/Plant/Process mentioned above and as to the precautions to
be observed and has received sufficient training in work on the Machine/Plant/Process and that in
my opinion he is fit to be employed on the said Machine/Plant/Process.
2. He is fit to be employed under the adequate and direct supervision of.........
Signature of the Manager.Signature of the Certifying Officer.Full name and designation.[Form No.
34] [Inserted by S.O. 686 dated 13.7.1988.][See Rule 3-A]Form of Certificate of Stability
1. Name of the Factory.........
2. Village,, town and district in which the factory is situated.......
3. Full postal address of the Factory.......
4. Name of the Occupier of the Factory..........
5. Nature of manufacturing progress to be carried on in the factory.......
6. Number of floors on which workers will be employed.
I certify that I have inspected the building/buildings the plans of which have been approved by the
Chief Inspector in his letter no.... dated.... and examined the various parts including the foundations
with special reference to the machinery, plant, etc., that have been installed. I am of the opinion that
the building/buildings which has/have been constructed/reconstructed/extended/taken into use
is/are in accordance with the plans approved by the Chief Inspector in his letter mentioned above,
that its/their is/are structurally sound and that its/their stability will not be endangered by its/their
use as a factory/part of a factory for the manufacture of......for which the machinery, plant, etc., is
intended.Signature .............................Qualification ........................Address ...............................Date
....................................If employed by a company or association, name and address of the Company
or Association;The certificate of stability shall be signed by a "competent person" as defined
below:-"Competent person" means a person holding any of qualifications exempting him from
passing Parts A and B of the Associate Membership Examination of the Institution of Engineers
(India) whom the Chief Inspector considers competent for any specified purpose by virtue of his
experience.[Form No. 35] [Inserted by S.O. 686 dated 13.7.1988.][See sub-rule (4) of Rule
59-C]Record of Eye Examination
Sl. no. Deptt/works Name of Worker Sex Age (on last birth day).
1 2 3 4 5
Occupation Examination of eye sight Signature of Opthalmologist Remarks
Nature of work Date of Employment Date Result
6 7 8 9 1011Bihar Factories Rules, 1950

[Schedule "A"] [Substituted by No. 58, dated 19.1.2010.](Rule - 5)Fee Payable for original licence
and for Annual Renewal of Licences for Factories and defined in Section 2 (m) of the Factories Act,
1948.Other than Electricity Generating, Transforming or Transmitting Factories.
Sl.
no.Total rated
Capacity
(Power) of
the
machineriesand
plants
Installed
expressed in
HORSE
POWER.Maximum
number
of persons
proposed
to
beemployed
on any
one day
during
the year
for which
licence is
tobe
taken.
  20 50 100 250 500 750 1,000 2,000 5,000 10,000 25,000Over
250,000
1 2 3 4 5 6 7 8 9 10 11 12 13 14
1. Nil...  500 1950 2250 2750 3750 5000 7500 8750 10000 11250 12250 15000
2.Not
Exceeding10 1125 2000 2750 3750 5750 10000 12500 15000 22500 47500 50000 125000
3. Ditto 50 2250 3250 3750 5250 8250 10750 15500 17500 25000 50000 62500 150000
4. Ditto 100 3250 5000 7500 10750 12500 20000 22500 27500 32500 62500 76250 150000
5. Ditto 250 5000 7500 10750 12500 20000 22500 27500 32500 40000 78750 126250 187500
6. Ditto 500 15000 22500 23750 25000 27500 35150 41450 46875 84375 105525 164450 243750
7. Ditto 1000 22500 23750 25000 30750 35625 41700 46875 58575 91700 112500 180450 253500
8. Ditto 2000 23750 25000 30750 41750 46875 59375 62750 67750 98450 119825 189000 262500
9. Ditto 5000 30750 41750 45000 47750 50000 62750 67750 70375 112500 128875 205000 276750
10. Ditto 10000 45000 47500 50000 62750 66750 70375 112500 128875 152500 205000 228250 302500
11. Ditto 25000 67750 70375 112500 128875 152500 205000 228250 252750 275000 302500 40000 425000
12.Not
exceeding
over25000 70375 128875 152500 205000 228250 252750 275000 327500 400000 422500 425000 450000
[Schedule "B"] [Substituted by No. 58, dated 19.1.2010.]Scale of fees payable for Licence and Annual
Renewal of Licence by All Electricity Generating. Transforming and Transmitting station
(Factories).(a)Generating and Transforming stations (Factories):-
 Total installed Generating
Capacity in K.W.Generating
Station.Transforming (including
Conversion Station)
 K.W. Rs. Rs.Bihar Factories Rules, 1950

Not
exceeding50 1250 750
Ditto 100 2250 1250
Ditto 150 3250 2250
Ditto 300 3750 3500
Ditto 500 5000 3750
Ditto 750 7500 5625
Ditto 10000 2000 7500
Ditto 2500 17500 10750
Ditto 5000 22500 12500
Ditto 10000 27500 15000
Ditto 25000 37500 22500
Ditto 50000 60000 30000
Ditto 75000 75000 37500
Ditto 100000 97500 45000
Ditto 150000 120000 60000
Ditto 200000 150000 90000
Ditto 300000 19500 120000
Ditto 300000 240000 150000
(b)All transmitting Stations (Factories) Rs. 22,500.00[Schedule "C"] [Substituted by No. 58, dated
19.1.2010.]Scale of fees payable for licence and annual renewal of licence for factories declared
under Section 85 of the Factories Act, 1948 (Act, 63 of 1948) other than Electricity Generating,
Transforming and Transmitting Stations (Factories) Rs. 525.00.Appendix IApertures for natural
ventilation.The formula for lateral apertures (ventilating openings) for natural ventilation referred
to in Rules 18 and 20 are :-(a)(British measure)
(1) A = {|
F| (| 1 +| √F100| )
|-|
10| (| 1 +| L - B10B| )
|}
(2) A = {|
F| (| √F100| )| (| 1 +| L - B5B| )
|-| 10|}L = Length of room in feet.B = Breadth of room in feet.F = Floor area in square feet.A =
Aggregate area of ventilating openings in sq. feet,(b)Metric System.
(1) A = {|
F| (| 1 +| √F30.48| )
|-|
10| (| 1 +| F - B10B| )
|}Bihar Factories Rules, 1950

(2) A = {|
F| (| 1 +| √F30.48| )| (| 1
+| L - B5B| )
|-| 1|}L = Length of room in metres.B = Breadth of room in metres.F = Floor area in square
metres.A = Aggregate area of ventilating openings in sq. metres.Note. - Formula (1) applies to rooms
of ordinary shape or when the ventilating openings are well distributed in rooms of any
shape.Formula (2) applies to elongated rooms ventilated at the ends only.NotificationsUnder
Section 85 :No. 11/F1 -1027/65-L&E - 5494, the 7th July, 1965. - In exercise of the powers conferred
by sub-section (1) of Section 85 of the Factories Act, 1948 (LXIII of 1948) and in supersession of the
Notification No. II/FI - 109/64 - L.&E. - 8096, dated the 29th August, 1964, Governor of Bihar is
pleased to declare that all the provisions of the said Act and the Rules made thereunder, shall apply
to any place in the State of Bihar wherein the manufacturing process specified in the Schedule
annexed hereto is carried on without the aid of power and wherein 20 or more persons generally
work notwithstanding that any or all persons working therein are not employed by the Owner
thereof but are working, with the permission of, or under agreement with such Owner:Provided that
nothing in this Notification shall apply to any place where in a manufacturing process is carried on
by the Owner himself or only with the aid of his family, and no other person is ever employed
therein.
Schedule 36
Manufacture of Bidi.The 12th January, 1985S.O. 131, dated the 24th January, 1985. - In exercise of
the powers conferred by sub-section (1) of Section 85 of the Factories Act, 1948 (LXIII of 1948), and
in supersession of the Government Notification No 2/FI-107/75-L. & E. - 2251, dated the 30th
September, 1975, the Governor of Bihar is pleased to declare :-(A)That the provisions of the said Act
and the Rules made thereunder as specified in Schedule 'X' annexed hereto shall apply to any place
in the State of Bihar, wherein any manufacturing process specified in Schedule 'Y' annexed hereto is
carried on with the aid of power or is so ordinarily carried on notwithstanding that:-(i)the number
of persons employed therein is less than ten; and(ii)the persons working therein are not employed
by the Owner, but are working with the permission of or under agreement with such Owner.(B)That
the provisions of the said Act and the Rules specified Schedule 'X' and those of Section 42 of the said
Act shall apply to any place in the State of Bihar wherein manufacturing process-(a)of composing
types for printing, printing by letter press, lithography, photographer or other similar
processes;(b)of Lead type founding;(c)of repairs, maintenance or painting of automobiles and motor
vehicles including earth moving machinery;(d)of tar distillation and manufacture of bye-products
from tar;(e)of manufacture and repairs of machinery or machine parts, manufacture of any other
article of metal founding or electroplating, polishing or galvanising of any article of metal;(f)of
manufacture of repair of storage Batteries (Electric Accumulators);(g)of manufacture of bricks, tiles,
refractory material, ceramic or mosaic goods;(h)manufacture of Soap;(i)declared to be dangerous
under Section 87 of the Factories Act, 1948 and specified under Rule 95 of the Bihar Factories Rules,
1950 is carried on with or without the aid of power or is so ordinarily carried on notwithstanding
that-(i)the number of persons employed is less than ten, if working with the aid of power, and less
than twenty, if working without the aid of power; and(ii)the persons working therein are not
employed by the Owner but are working with the permission of or under agreement with suchBihar Factories Rules, 1950

Owner;(C)That the provisions of the said Act and the Rules specified in Schedule 'X' shall apply to
any place in the State of Bihar wherein the manufacturing process of-(a)jute bailing and
pressing;(b)manufacturing of Guns and fire arms;(c)manufacturing of silicate of soda;(d)moulding
and retreading of tyres;(e)manufacture of fire works; and(f)body building of automobiles, is carried
on or is so ordinarily carried on with or without the aid of power, notwithstanding that-(i)the
number of persons employed therein is less than ten, if working with the aid of power and less than
twenty, if working without the aid of power, and(ii)the persons working therein are not employed by
the Owner but are working with the permission of, or under agreement with such Owner:Provided
that nothing in this Notification shall apply to any place wherein manufacturing process is carried
on by the Owner only with the aid of his family.
'X'
I. (a) Chapters I and II.(b)Sections 11,12, 13, 14, 16, 17 and 18 of Chapter III.(c)Chapter
IV.(d)Sections 45 and 50 of Chapter V, and(e)Chapters VI to XI of the Factories Act, 1948.II. The
Bihar Factories Rules, 1950 except Rule 3.
'Y'
1. Sawing of Timber.
2. Manufacture of ice and ice candy.
3. Manufacture of Oil.
4. Flour milling and grinding, grinding, breaking and crushing of any other
cereal or material.
5. Rice Milling.
6. Dal Milling.
7. Generation and Conversion of electricity excluding transformation by State
transformers.
8. Manufacture of tea.
9. Spinning, Weaving, Knitting or finishing (including dyeing) of any textile
material, including hosiery and carding and breaking of cotton.Bihar Factories Rules, 1950

10. Pumping of sewerage including treatment and disposal thereof.
11. Chaff cutting.
12. Laundering, including cleaning and dyeing of textiles materials or
apparels.
13. Manufacture of plastic and plastic products.
14. Canning and preservation of food materials, fruits and vegetables.
15. Filling bottles with aerated water or drinks and processes incidental
thereto.
16. Manufacture of packing cases;
17. Transforming of power.
18. Manufacture of any electrical equipment, apparatus, appliances or device.
19. Manufacture of any explosive material, including safety fuses detonators,
cartridges or any other component thereof.
Under Rule 71 A:S. O. 87 dated 14th April, 1967 (Bihar Gazette extraordinary dated 14th August,
1967). - In exercise of the powers conferred by Rule 71-A of Bihar Factories Rules, 1950, the
Governor of Bihar is pleased to exempt all mica splitting factories, wherein splitting, dressing or
sieving of mica or processes concerned or incidental thereto is carried on, and all glass factories
wherein glass works are manufactured (except sheet glass factories), employing more than 250
workers and notified under Rule 66 of the said Rules, from the provisions of Rules 66, 68 and 71 of
the said Rules subject to the following conditions :-(1)In every such factory :-(a)an adequate dining
hall with a kitchen hereinafter called canteen shall be provided;(b)adequate washing facilities shall
be provided in the canteen;(c)the plan, elevation and necessary cross-sections of the canteen shall
be submitted to the Chief Inspector of Factories and approval thereof shall be obtained before
starting the construction of the canteen. Such modifications, additions or improvement shall be
made therein as may be directed by the Chief Inspector;(d)arrangements shall be made for the
supply of tea and snacks and such other articles of food in the canteen as may be required by the
workers, or as may be in keeping with the general food habits of the workers;(e)the articles of food
shall be sold in the canteen on no- profit basis and shall be prepared and sold by the Occupier
departmentally and not through any contractor or any other agency;(f)the building, furniture,
utensils, crockeries and other equipments required for the canteen shall be supplied by the Occupier
free and no charge in respect thereof shall be added to the price of the articles sold in the
canteen;The Inspector of Factories may direct the Occupier and/or the Manager to make suchBihar Factories Rules, 1950

improvements in these arrangements as he may consider necessary;(g)the Occupier shall bear the
cost of fuel, light, water and canteen staff and no charge in respect thereof shall be added to the
price of articles sold in the canteen;(h)the canteen and the surroundings shall be kept neat and clean
at all times;(i)the Occupier shall provide adequate staff at all times when work is going on in the
factory and when tea, snacks, etc. are required by the workers and all the staff shall be provided with
clean dresses and uniforms; and(j)the Inspector of Factories may direct the Occupier and/or the
Manager to increase the staff if he finds that the staff provided was not adequate.(2)Any direction
given by the Inspector of Factories in accordance with these conditions shall be subject to appeal to
the Chief Inspector whose decision would be final.The 26th July 1988S.O. 841, dated the 12th
August 1988. - In exercise of the powers conferred by sub-Rule (1) of Rule 80-A of the Bihar
Factories Rules, 1950, the Governor of Bihar is pleased to notify the following types of factories as
defined under Section 2(m) of the Factories Act, 1948 and all such factories as have been notified
under Section 85 of the Factories Act, 1948 to be the factories (but employing more than five
workers) which shall issue identity cards to their workers:-
Schedule 39
1. Printing Press.
2. Brick kilns.
3. Mica Factory.
4. Rice, Dal, Oil and Flour Mills.
5. Saw Mills.
6. Automobiles repairs and maintenance workshops.
7. Refractories.
8. Glass Factories.
9. Hard Coke and Coal briquetting Factories.
10. Shellac Industries.
11. Stone Crushing Factories.
12. Card Board and Paper Industries.Bihar Factories Rules, 1950

13. Power looms.
[Existing clauses (a) & (b) re-numbered as (b) & (c) thereof and clause (a) Inserted by S.O. 686
dated 13.7.1988.]Bihar Factories Rules, 1950

