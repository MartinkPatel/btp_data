Engineering Analysis Centre Of ... vs The Commissioner Of
Income Tax on 2 March, 2021
Equivalent citations: AIRONLINE 2021 SC 102
Author: R.F. Nariman
Bench: B.R. Gavai, Hemant Gupta, R. F. Nariman
                                                             REPORTABLE
                             IN THE SUPREME COURT OF INDIA
                            CIVIL APPELLATE JURISDICTION
                          CIVIL APPEAL NOS. 8733-8734 OF 2018
                ENGINEERING ANALYSIS CENTRE OF
                EXCELLENCE PRIVATE LIMITED                   …APPELLANT
                                        Versus
                THE COMMISSIONER OF INCOME            …RESPONDENTS
                TAX & ANR.
                                       WITH
                          CIVIL APPEAL NOS. 8735-8736 OF 2018
                          CIVIL APPEAL NOS. 8737-8941 OF 2018
                          CIVIL APPEAL NOS. 8942-8947 OF 2018
                          CIVIL APPEAL NOS. 8950-8953 OF 2018
                          CIVIL APPEAL NOS. 8948-8949 OF 2018
                             CIVIL APPEAL NO. 4419 OF 2012
                             CIVIL APPEAL NO. 4420 OF 2012
                            CIVIL APPEAL NO. 10114 OF 2013
                            CIVIL APPEAL NO. 10097 OF 2013
Signature Not Verified   CIVIL APPEAL NOS. 10112-10113 OF 2013
Digitally signed by
Jayant Kumar Arora
Date: 2021.03.02
16:50:08 ISTEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

Reason:                     CIVIL APPEAL NO. 10106 OF 2013
                          CIVIL APPEAL NOS. 8954-8955 OF 2018
                                                                          1
CIVIL APPEAL NOS. 10115-10117 OF 2013
    CIVIL APPEAL NO. 8956 OF 2018
    CIVIL APPEAL NO. 8957 OF 2018
    CIVIL APPEAL NO. 8990 OF 2018
   CIVIL APPEAL NO. 10103 OF 2013
   CIVIL APPEAL NO. 10104 OF 2013
    CIVIL APPEAL NO. 8960 OF 2018
    CIVIL APPEAL NO. 8966 OF 2018
    CIVIL APPEAL NO. 8958 OF 2018
    CIVIL APPEAL NO. 8959 OF 2018
    CIVIL APPEAL NO. 8962 OF 2018
    CIVIL APPEAL NO. 8961 OF 2018
    CIVIL APPEAL NO. 8963 OF 2018
    CIVIL APPEAL NO. 8964 OF 2018
    CIVIL APPEAL NO. 8965 OF 2018
    CIVIL APPEAL NO. 8969 OF 2018
    CIVIL APPEAL NO. 8967 OF 2018
    CIVIL APPEAL NO. 8968 OF 2018
    CIVIL APPEAL NO. 8972 OF 2018
    CIVIL APPEAL NO. 8971 OF 2018
    CIVIL APPEAL NO. 8970 OF 2018
                                        2
  CIVIL APPEAL NO. 4629 OF 2014
  CIVIL APPEAL NO. 8973 OF 2018Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

  CIVIL APPEAL NO. 4631 OF 2014
  CIVIL APPEAL NO. 4630 OF 2014
CIVIL APPEAL NOS. 8974-8975 OF 2018
CIVIL APPEAL NOS. 6386-6387 OF 2016
  CIVIL APPEAL NO. 10105 OF 2013
  CIVIL APPEAL NO. 7852 OF 2012
CIVIL APPEAL NOS. 1416-1418 OF 2013
  CIVIL APPEAL NO. 1403 OF 2013
  CIVIL APPEAL NO. 1405 OF 2013
  CIVIL APPEAL NO. 1410 OF 2013
  CIVIL APPEAL NO. 1421 OF 2013
  CIVIL APPEAL NO. 1409 OF 2013
  CIVIL APPEAL NO. 1415 OF 2013
  CIVIL APPEAL NO. 1414 OF 2013
  CIVIL APPEAL NO. 1412 OF 2013
  CIVIL APPEAL NO. 1413 OF 2013
  CIVIL APPEAL NO. 1419 OF 2013
  CIVIL APPEAL NO. 1411 OF 2013
  CIVIL APPEAL NO. 1420 OF 2013
                                      3
    CIVIL APPEAL NO. 1404 OF 2013
    CIVIL APPEAL NO. 1406 OF 2013
    CIVIL APPEAL NO. 1408 OF 2013
    CIVIL APPEAL NO. 1407 OF 2013
    CIVIL APPEAL NO. 2304 OF 2013
    CIVIL APPEAL NO. 2305 OF 2013
    CIVIL APPEAL NO. 2306 OF 2013Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

CIVIL APPEAL NOS. 10098-10102 OF 2013
 CIVIL APPEAL NOS. 2307-2308 OF 2013
 CIVIL APPEAL NOS. 4666-4667 OF 2013
    CIVIL APPEAL NO. 6764 OF 2013
    CIVIL APPEAL NO. 4634 OF 2014
    CIVIL APPEAL NO. 8976 OF 2018
 CIVIL APPEAL NOS. 8977-8988 OF 2018
    CIVIL APPEAL NO.781 OF 2021
    (@ SLP(C) NO. 37580 OF 2016)
    CIVIL APPEAL NO.782 OF 2021
    (@ SLP(C) NO. 28867 OF 2016)
    CIVIL APPEAL NO. 783 OF 2021
    (@ SLP(C) NO. 28868 OF 2016)
   CIVIL APPEAL NO. 10673 OF 2016
    CIVIL APPEAL NO. 784 OF 2021
    (@ SLP(C) NO. 29571 OF 2016)
                                        4
                      CIVIL APPEAL NO. 10674 OF 2016
                         CIVIL APPEAL NO. 785 OF 2021
                        (@ SLP(C) NO. 36782 OF 2016)
                      CIVIL APPEAL NO. 3402 OF 2017
                      CIVIL APPEAL NO. 10758 OF 2017
                      CIVIL APPEAL NO. 9486 OF 2017
                      CIVIL APPEAL NO. 8711 OF 2018
                      CIVIL APPEAL NO. 8722 OF 2018
                      CIVIL APPEAL NO. 8724 OF 2018
                      CIVIL APPEAL NO. 8725 OF 2018
                      CIVIL APPEAL NO. 9551 OF 2018
                        CIVIL APPEAL NO. 786 OF 2021Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

                         (@ SLP(C) NO. 450 OF 2019)
                      CIVIL APPEAL NO. 2006 OF 2019
                        CIVIL APPEAL NO. 790 OF 2021
                        (@ SLP(C) NO. 6736 OF 2020)
                               JUDGMENT
R.F. Nariman, J.
1. Leave granted.
2. The appeals in these cases are by both the assessees as well as the Department of Revenue,
Ministry of Finance [“Revenue”]. Whereas the assessees have succeeded in the question that was
posed before the High Court of Delhi,1 the Revenue has succeeded insofar as the same question was
posed before the High Court of Karnataka,2 and in the ruling by the Authority for Advance Rulings
[“AAR”], impugned in C.A. No. 8990/2018.
This includes the judgments impugned in C.A No. 8990/2018, C.A Nos. 6386- 6387/2016, SLP(C)
No. 37580/2016, SLP(C) No. 28867/2016, SLP(C) No. 28868/2016, C.A No. 10673/2016, SLP(C)
No. 29571/2016, C.A No. 10674/2016, SLP(C) No. 36782/2016, C.A No. 10758/2017, C.A No.
9486/2017, C.A No. 8711/2018, C.A No. 8722/2018, C.A No. 8724/2018, C.A No. 8725/2018, C.A
No. 9551/2018, SLP(C) NO. 450/2019, SLP(C) No. 6736/2020. This includes the judgments
impugned in C.A Nos. 8735-8736/2018, C.A Nos. 8737- 8941/2018, C.A Nos. 8942-8947/2018, C.A
Nos. 8950-8953/2018, C.A Nos. 8948- 8949/2018, C.A No. 4419/2012, C.A No. 4420/2012, C.A No.
10114/2013, C.A No. 10097/2013, C.A Nos. 10112-10113/2013, C.A No. 10106/2013, C.A Nos. 8954-
8955/2018, C.A Nos. 10115-10117/2013, C.A No. 8956/2018, C.A No. 8957/2018, C.A No.
10103/2013, C.A No. 10104/2013, C.A No. 8960/2018, C.A No. 8966/2018, C.A No. 8958/2018, C.A
No. 8959/2018, C.A No. 8962/2018, C.A No. 8961/2018, C.A No. 8963/2018, C.A No. 8964/2018,
C.A No. 8965/2018, C.A No. 8969/2018, C.A No. 8967/2018, C.A No. 8968/2018, C.A No.
8972/2018, C.A No. 8971/2018, C.A No. 8970/2018, C.A No. 4629/2014, C.A No. 8973/2018, C.A
No. 4631/2014, C.A No. 4630/2014, C.A Nos. 8974-8975/2018, C.A No. 10105/2013, C.A No.
7852/2012, C.A Nos. 1416-1418/2013, C.A No. 1403/2013, C.A No. 1405/2013, C.A No. 1410/2013,
C.A No. 1421/2013, C.A No. 1409/2013, C.A No. 1415/2013, C.A No. 1414/2013, C.A No. 1412/2013,
C.A No. 1413/2013, C.A No. 1419/2013, C.A No. 1411/2013, C.A No. 1420/2013, C.A No. 1404/2013,
C.A No. 1406/2013, C.A No. 1408/2013, C.A No. 1407/2013, C.A No. 2304/2013, C.A No.
2305/2013, C.A No. 2306/2013, C.A Nos. 10098-10102/2013, C.A Nos. 2307-2308/2013, C.A Nos.
4666-4667/2013, C.A No. 6764/2013, C.A No. 4634/2014, C.A No. 8976/2018, C.A Nos.
8977-8988/2018, C.A No. 3402/2017, C.A No. 2006/2019.
3. One group of appeals arises from a common judgment of the High Court of Karnataka dated
15.10.2011 reported as CIT v. Samsung Electronics Co. Ltd., (2012) 345 ITR 494, by which the
question which was posed before the High Court, was answered stating that the amounts paid by the
concerned persons resident in India to non- resident, foreign software suppliers, amounted toEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

royalty and as this was so, the same constituted taxable income deemed to accrue in India under
section 9(1)(vi) of the Income Tax Act, 1961 [“Income Tax Act”], thereby making it incumbent upon
all such persons to deduct tax at source and pay such tax deductible at source [“TDS”] under section
195 of the Income Tax Act. This judgment dated 15.10.2011 has been relied upon by the subsequent
impugned judgments passed by the High Court of Karnataka to decide the same question in favour
of the Revenue.
4. The appeals before us may be grouped into four categories:
i) The first category deals with cases in which computer software is purchased
directly by an end-user, resident in India, from a foreign, non-resident supplier or
manufacturer.3 This category includes C.A. Nos. 8733-8734/2018, C.A. No.
10114/2013, C.A. Nos.
10112-10113/2013, C.A. No. 10106/2013, C.A. No. 10103/2013, C.A. No. 10104/2013, C.A. Nos.
10098-10102/2013, C.A. Nos. 8735-8736/2018, C.A. Nos. 8948-8949/2018, C.A. No. 8956/2018,
C.A. No. 8957/2018, C.A. No. 7852/2012, C.A. Nos. 8974-8975/2018, C.A. No. 2304/2013, C.A. No.
2305/2013, C.A. No. 2306/2013,
ii) The second category of cases deals with resident Indian companies that act as distributors or
resellers, by purchasing computer software from foreign, non-resident suppliers or manufacturers
and then reselling the same to resident Indian end-users.4
iii) The third category concerns cases wherein the distributor happens to be a foreign, non-resident
vendor, who, after purchasing software from a foreign, non-resident seller, resells the same to
resident Indian distributors or end-users.5
iv) The fourth category includes cases wherein computer software is affixed onto hardware and is
sold as an integrated unit/equipment C.A. Nos. 2307-2308/2013, C.A. No. 10097/2013, C.A. No.
8976/2018, C.A. No. 3402/2017, SLP(C) No. 450/2019, C.A. No. 2006/2019. This category includes
C.A Nos. 8737-8941/2018, C.A No. 8942-8947/2018, C.A No. 4420/2012, C.A No. 8959/2018, C.A
No. 8963/2018, C.A No. 8962/2018, C.A No. 8958/2018, C.A No. 8961/2018, C.A No. 8960/2018,
C.A Nos. 8950-8953/2018, C.A No. 8966/2018, C.A No. 8973/2018, C.A No. 8965/2018, C.A No.
8972/2018, C.A No. 8969/2018, C.A No. 8971/2018, C.A No. 8970/2018, C.A No. 8964/2018, C.A
No. 8967/2018, C.A No. 8968/2018, C.A No. 1403/2013, C.A No. 1414/2013, C.A No. 1412/2013,
C.A No. 1413/2013, C.A Nos. 1416-1418/2013, C.A No. 1405/2013, C.A No. 1410/2013, C.A No.
1421/2013, C.A No. 1409/2013, C.A No. 1415/2013, C.A No. 1419/2013, C.A No. 1411/2013, C.A No.
1420/2013, C.A No. 1404/2013, C.A No. 1406/2013, C.A No. 1408/2013, C.A No. 1407/2013, C.A
Nos. 4666-4667/2013, C.A No. 6764/2013, C.A No. 4419/2012, C.A Nos. 8977-8988/2018, C.A No.
4629/2014, C.A No. 4631/2014, C.A No. 4630/2014, C.A No. 10105/2013. This category includes
C.A. No. 10758/2017, C.A. No. 8990/2018, C.A. No. 9486/2017, C.A. No. 8711/2018, C.A. No.
8722/2018, C.A. No. 8724/2018, C.A. No. 8725/2018, C.A. No. 9551/2018, SLP(C) No. 6736/2020,
C.A. No. 4634/2014. by foreign, non-resident suppliers to resident Indian distributors or
end-users.6Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

5. These cases have a chequered history. The facts of C.A. Nos. 8733- 8734/2018 shall be taken as a
sample, indicative of the points of law that arise from the various appeals before us. In this case, the
appellant, Engineering Analysis Centre of Excellence Pvt. Ltd. [“EAC”], is a resident Indian end-user
of shrink-wrapped computer software, directly imported from the United States of America [“USA”].
The assessment years that we are concerned with are 2001-2002 and 2002-2003.
6. The Assessing Officer by an order dated 15.05.2002, after applying Article 12(3) of the Double
Taxation Avoidance Agreement [“DTAA”], between India and USA, and upon applying section
9(1)(vi) of the Income Tax Act, found that what was in fact transferred in the transaction between
the parties was copyright which attracted the payment of royalty and thus, it was required that tax
be deducted at source by the Indian importer and end-user, EAC. Since this was not done for both
the assessment years, EAC was held liable to pay the This category includes C.A. Nos.
10115-10117/2013, C.A. Nos. 6386-6387/2016, C.A. Nos. 8954-8955/2018, SLP(C) No. 37580/2016,
SLP(C) No. 28867/2016, SLP(C) No. 28868/2016, C.A. No. 10673/2016, SLP(C) No. 29571/2016,
C.A. No. 10674/2016, SLP(C) No. 36782/2016.
amount of Rs. 1,03,54,784 that it had not deducted as TDS, along with interest under section
201(1A) of the Income Tax Act amounting to Rs. 15,76,567. The appeal before the Commissioner of
Income Tax [“CIT”] was dismissed by an order dated 23.01.2004. However, the appeal before the
Income Tax Appellate Tribunal [“ITAT”] succeeded vide an order dated 25.11.2005, in which the
ITAT followed its previous order dated 18.02.2005, passed in Samsung Electronics Co. Ltd. v.
Income Tax Officer, ITA Nos. 264-266/Bang/2002.
7. An appeal was made from the order of the ITAT to the High Court of Karnataka by the Revenue.
The Division Bench of the High Court of Karnataka heard a batch of appeals and framed nine
questions, of which question nos. 8 and 9 are important and are set out as follows:
“8. Whether the Tribunal was correct in holding that since the assessee had
purchased only a right to use the copyright i.e. the software and not the entire
copyright itself, the payment cannot be treated as Royalty as per the Double Taxation
Avoidance Agreement and Treaties, which [are] beneficial to the assessee and
consequently section 9 of the Act should not take into consideration.
9. Whether the Tribunal was correct in holding that the payment partakes the
character of purchase and sale of goods and therefore cannot be treated as royalty
payment liable to Income Tax.”
8. In answering these questions, through a judgment dated 24.09.2009, the Division Bench of the
High Court of Karnataka relied heavily upon the judgment of this Court in Transmission Corpn. of
A.P. Ltd. v. CIT, (1999) 7 SCC 266 [“AP Transco”] and held that since no application under section
195(2) of the Income Tax Act had been made, the resident Indian importers became liable to deduct
tax at source, without more, under section 195(1) of the Income Tax Act.Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

9. This view of the High Court was set aside by this Court in GE India Technology Centre (P) Ltd. v.
CIT, (2010) 10 SCC 29 [“GE Technology”], which ultimately found that the judgment of the High
Court dated 24.09.2009 had misread AP Transco (supra). Consequently, this Court remanded the
matter to the High Court of Karnataka to decide, on merits, the question of law framed as follows:
“24. In our view, Section 195(2) is based on the “principle of proportionality”. The
said sub-section gets attracted only in cases where the payment made is a composite
payment in which a certain proportion of payment has an element of “income”
chargeable to tax in India. It is in this context that the Supreme Court stated:
(Transmission Corpn. case [(1999) 7 SCC 266 : (1999) 239 ITR 587] , SCC p. 274,
para
10) “10. … If no such application is filed income tax on such sum is to be deducted
and it is the statutory obligation of the person responsible for paying such ‘sum’ to
deduct tax thereon before making payment. He has to discharge the obligation [to
TDS].” (emphasis supplied) If one reads the observation of the Supreme Court, the
words “such sum” clearly indicate that the observation refers to a case of composite
payment where the payer has a doubt regarding the inclusion of an amount in such
payment which is exigible to tax in India. In our view, the above observations of this
Court in Transmission Corpn. case [(1999) 7 SCC 266 : (1999) 239 ITR 587] which is
put in italics has been completely, with respect, misunderstood by the Karnataka
High Court to mean that it is not open for the payer to contend that if the amount
paid by him to the non-resident is not at all “chargeable to tax in India”, then no TAS
is required to be deducted from such payment. This interpretation of the High Court
completely loses sight of the plain words of Section 195(1) which in clear terms lays
down that tax at source is deductible only from “sums chargeable” under the
provisions of the IT Act i.e. chargeable under Sections 4, 5 and 9 of the IT Act.
25. Before concluding we may clarify that in the present case on facts ITO(TDS) had taken the view
that since the sale of the software concerned, included a licence to use the same, the payment made
by the appellant(s) to foreign suppliers constituted “royalty” which was deemed to accrue or arise in
India and, therefore, TAS was liable to be deducted under Section 195(1) of the Act. The said finding
of ITO(TDS) was upheld by CIT(A). However, in the second appeal, ITAT held that such sum paid by
the appellant(s) to the foreign software suppliers was not a “royalty” and that the same did not give
rise to any “income” taxable in India and, therefore, the appellant(s) was not liable to deduct TAS.
However, the High Court did not go into the merits of the case and it went straight to conclude that
the moment there is remittance an obligation to deduct TAS arises, which view stands hereby
overruled.
26. Since the High Court did not go into the merits of the case on the question of payment of royalty,
we hereby set aside the impugned judgment of the High Court and remit these cases to the High
Court for de novo consideration of the cases on merits. The question which the High Court will
answer is: whether on facts and circumstances of the case ITAT was justified in holding that the
amount(s) paid by the appellant(s) to the foreign software suppliers was not “royalty” and that theEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

same did not give rise to any “income” taxable in India and, therefore, the appellant(s) was not liable
to deduct any tax at source?”
10. The impugned judgment of the High Court of Karnataka, dated 15.10.2011, reported as CIT v.
Samsung Electronics Co. Ltd., (2012) 345 ITR 494, dealt with a whole group of appeals, and was
thus faced with the following question so posed by this Court:
“The question which the High Court will answer is— “whether, on facts and
circumstances of the case, the Income-tax Appellate Tribunal was justified in holding
that the amount(s) paid by the appellant(s) to the foreign software suppliers was not
“royalty” and that the same did not give rise to any “income” taxable in India and,
therefore, the appellant(s) was not liable to deduct any tax at source?”” (page 498)
11. After setting out the facts in one of the appeals treated as the lead matter, namely
ITA No. 2808/2005 concerning Samsung Electronics Co. Ltd., and the relevant
provisions of the Income Tax Act, India’s DTAAs with USA, France and Sweden
respectively, the High Court of Karnataka, on an examination of the End-User
Licence Agreement [“EULA”] involved in the transaction, found that what was sold
by way of computer software included a right or interest in copyright, which thus
gave rise to the payment of royalty and would be an income deemed to accrue in
India under section 9(1)(vi) of the Income Tax Act, requiring the deduction of tax at
source.
12. Leading the charge on behalf of the appellants in the appeals against this
impugned judgment of the High Court of Karnataka, Shri Arvind Datar, learned
Senior Advocate, appearing on behalf of IBM India Ltd.
[“IBM India”] in C.A. No. 4419/2012, which is a resident Indian distributor of computer software
products purchased from IBM Singapore Pte Ltd. [“IBM Singapore”], submitted that his client is a
non- exclusive distributor, which purchases off-the-shelf copies of shrink- wrapped computer
software from a foreign company in Singapore for onward sale to Indian end-users under a
Remarketer Agreement. He stressed that IBM India, the distributor, is not party to the EULA
between IBM Singapore and the ultimate end-users/customers in India. The Indian end-user pays
IBM India, and in turn, IBM India pays this amount to IBM Singapore after deducting a portion of
profit. Importantly, under the Remarketer Agreement, IBM India does not own any right, title or
interest in copyright and other intellectual property owned by IBM Singapore, and merely markets
IBM Singapore’s software products in India.
13. Shri Datar further argued that the computer software that is imported for onward sale from
Singapore constitutes “goods” and thus was directly covered by this Court’s judgment in Tata
Consultancy Services v. State of A.P., 2005 (1) SCC 308. He assailed the impugned judgment of the
High Court of Karnataka by referring to Article 12 of the Agreement between the Government of the
Republic of India and the Government of the Republic of Singapore for the Avoidance of Double
Taxation and the Prevention of Fiscal Evasion with respect to Taxes on Income,7 [“India-SingaporeEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

DTAA”], and the definition of “royalties” contained therein. He argued that the definition of
“royalties” did not extend to derivative products of the copyright, for example, a book or a music CD
or software products. He relied upon the judgment in Union Notification No. GSR 610(E), Dated
8-8-1994 As Amended by Notification No. SO 1022(E), Dated 18-7-2005; No. S.O. 2031(E), Dated
1-9-2011 and No. S.O. 935(E), Dated 23-3-2017.
of India v. Azadi Bachao Andolan, (2004) 10 SCC 1 [“Azadi Bachao Andolan”] to argue that by virtue
of section 90(2) of the Income Tax Act, the DTAA would prevail over domestic law to the extent it is
more beneficial to the deductor of tax under section 195 of the Income Tax Act. According to him,
even assuming that under section 9(1)(vi) of the Income Tax Act IBM India’s transaction would
entail parting with copyright and attract royalty, upon applying the more beneficial provisions of the
India-Singapore DTAA, it would be made clear that the amounts payable were not in the nature of
royalty, and no income in the hands of the foreign supplier would be deemed to accrue in India.
Thus, no tax had to be deducted by the Indian importer under section 195(1) of the Income Tax Act.
Equally, he submitted that the retrospective amendment to section 9(1)(vi) of the Income Tax Act
brought in by the Finance Act 2012, which added explanation 4 to the provision and expanded its
ambit with effect from 01.06.1976, could also not be applied to the DTAA in question.
14. Pointing to the provisions of the Copyright Act, 1957 [“Copyright Act”], Shri Datar argued that
there was a difference between a copyright in an original work and a copyrighted article, and that
this was recognised in section 14(b) of the Copyright Act, which refers to a “computer program” per
se and a “copy of a computer program” as two distinct subject matters. He emphasized that under
the Remarketer Agreement, no copyright was given by IBM Singapore and that even the end-user in
India only received a limited licence to use the product by itself, with no right to sub-license, lease,
make copies etc. The licence to use such shrink-wrapped computer software was thus incidental to
and essential to effectuate the use of the product. He strongly relied upon the Commentaries on the
Articles of the Model Tax Convention on Income and on Capital [“OECD Commentary”] by the
Organisation for Economic Co-operation and Development [“OECD”] which distinguishes between
the sale of a copyrighted article and the sale of copyright itself. He further argued that the doctrine
of first sale/principle of exhaustion was cemented in section 14(b)(ii) of the Copyright Act post the
amendment brought in vide Act 49 of 1999, with effect from 15.01.2000 [“1999 Amendment”],
thereby making it clear that the foreign supplier’s distribution right would not extend to the sale of
copies of the work to other persons beyond the first sale. Importantly, he added that the importer,
IBM India, being only a distributor, had no right to use the computer software, and merely
purchased a sealed, shrink- wrapped product and resold it in the same, sealed condition, and
thereby did not pay any consideration for any transfer of or interest in copyright. He cited a number
of judgments and other authorities to buttress his submissions.
15. Shri Percy Pardiwala, learned Senior Advocate appearing on behalf of Rational Software
Corporation India Ltd. in C.A. No. 8962/2018, supplemented Shri Datar’s submissions, and
adverted to the provisions of the India-Singapore DTAA, Income Tax Act and the relevant EULA
and Remarketer Agreement. Coming to the Finance Act 2012 which added explanation 4 to section
9(1)(vi) of the Income Tax Act, he argued that the words “any right, property or information used or
services utilised” which occur in section 9(1)(vi)(b), make it clear that explanation 4, read bothEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

textually and contextually would only apply to section 9(1)(vi)(b), and not expand the scope of the
definition of royalty contained in explanation 2 to section 9(1)(vi). Further, he referred to Circular
No. 10/2002 dated 09.10.2002 by the Central Board of Direct Taxes [“CBDT”] in which “remittance
for royalties” and “remittance for supply of articles or…computer software” were addressed as
separate and distinct payments, the former attracting the “royalty” provision under Article 12 of the
DTAA, and the latter being taxable as business profits under Article 7 of the DTAA, provided that the
foreign, non-resident supplier or manufacturer had a permanent establishment [“PE”] in India.
16. Shri S. Ganesh, learned Senior Advocate appearing on behalf of Sonata Information Technology
Ltd. in C.A. Nos. 8737-8941/2018, submitted that to comprehend the nature of a licence, one would
have to refer to section 52 of the Indian Easements Act 1882. He stressed the fact that the ruling by
the AAR in the case of Dassault Systems, K.K., In Re., (2010) 322 ITR 125 (AAR), as followed in
Geoquest Systems B.V. Gevers Deynootweg, In Re., (2010) 327 ITR 1 (AAR), was not appealed
against by the Revenue, and the exhaustive statement of law contained therein is something that he
relied upon. According to him, if the position of the Revenue were correct, arbitrary results would
ensue, inasmuch as his client, receiving a 2% commission, would, however, after the disallowance of
the deduction under section 40(a)(ia) of the Income Tax Act, end up paying tax of a huge amount,
way beyond the commission, resulting in extreme financial hardship. Thus, if section 195 of the
Income Tax Act could be construed in a manner so as to avoid such a result, this must be done.
Further, he relied heavily upon the OECD Commentary and went on to argue that mere
nomenclature, such as the use of the term “licence”, was not conclusive as to the character of the
transaction. He also relied upon section 52(1)(aa) of the Copyright Act to argue that what is
mentioned in the provision is exactly what the transactions in these appeals are concerned with, and
therefore, the making of copies only in order to utilise the product to the extent permitted by the
EULA, would not constitute an infringement of copyright, as expressly stated in this provision.
Going by what the originator or creator holds by way of copyright, which he either passes on or
retains, and what is mentioned in section 52(1)(aa) of the Copyright Act, he submitted that what was
resold by his client in this case was not copyright, but merely a copyrighted article, which
constituted goods in the hands of the end- user, without any right to transfer the same. He also cited
several judgments to buttress his submissions.
17. Shri Ajay Vohra, learned Senior Advocate appearing on behalf of Sasken Communications Tech
Ltd. in C.A. Nos. 10114/2013 and 8957/2018, relied upon the Convention between the Government
of the United States of America and the Government of the Republic of India for the Avoidance of
Double Taxation and the Prevention of Fiscal Evasion with respect to Taxes on Income,8
[“India-USA DTAA”] and echoed the submissions of his predecessors. In addition, he argued that
the retrospective amendment to section 9(1)(vi) of the Income Tax Act adding explanation 4, could
not be applied as the assessment years Notification No. GSR 992(E), dated 20-12-1990. that we are
concerned with in all these cases are prior to 2012, and that the law cannot compel one to do the
impossible, namely, to deduct tax at source on an expanded definition of royalty which did not exist
at the time of the payment/deduction to be made under section 195 of the Income Tax Act. He cited
various judgments and relied upon the proposition that where no assessment to tax can be made on
a foreign, non-resident supplier, the appellants could not be held to be assessees in default for not
deducting tax at source under section 195 of the Income Tax Act.Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

18. Shri Preetesh Kapur, learned Senior Advocate appearing on behalf of Sunray Computers Pvt.
Ltd. in C.A. Nos. 10115-10117/2013, stressed upon the language of section 14(b)(ii) of the Copyright
Act, both pre and post the 1999 Amendment, brought in with effect from 15.01.2000, and cited the
doctrine of first sale/principle of exhaustion, arguing that the amendment, after deleting the words
“regardless of whether such copy has been sold or given on hire on earlier occasions”, was a
statutory application of the doctrine of first sale/principle of exhaustion. This, he argued, made it
clear that since no distribution right by the original owner extended beyond the first sale of the
copyrighted goods, it can be said that only the goods, and not the copyright in the goods, had passed
onto the importer.
19. Shri Sachit Jolly, learned advocate appearing on behalf of Engineering Analysis Centre of
Excellence Pvt. Ltd. in C.A. Nos. 8733-8734/2018, and GE India Technology Centre Pvt. Ltd. in C.A.
Nos. 8735- 8736/2018, also echoed these submissions and in particular, relied upon judgments
which made it clear that a retrospective amendment to a statute cannot be applied to an assessment
year in which, as a matter of fact, the expanded definition of royalty did not exist.
20. Shri Kunal Verma, learned advocate appearing on behalf of Infineon Technologies India Pvt.
Ltd. in C.A. No. 2006/2019, argued that in any case, in the facts of his case, the payments made by
the assessee were in the nature of reimbursement of costs under a cost-sharing agreement with a
German supplier of software, and thus no “sum chargeable under the provisions of [the] Act” had
been paid, attracting section 195 of the Income Tax Act. To buttress his submission, he relied in
particular upon the judgment in Director of Income Tax v. A.P. Moller Maersk AS, (2017) 5 SCC 651.
21. Per contra, Shri Balbir Singh, the learned Additional Solicitor General appearing on behalf of the
Revenue, took us through the provisions of the Income Tax Act, the Copyright Act, the India-USA
DTAA and some of the EULAs between the parties. He argued that explanation 2(v) to section
9(1)(vi) of the Income Tax Act applied to payments to a non- resident by way of royalty for the use of
or the right to use any copyright.
For this, he relied upon the language of explanation 2(v) and stressed that the words “in respect of”
have to be given a wide meaning. He then relied upon CBDT Circular No. 152 dated 27.11.1974,9
together with the statement of the Finance Minister made before the Lok Sabha on 07.09.1990,10
and CBDT Notification No. 21/2012 dated 13.06.2012,11 to submit that explanation 4 to section
9(1)(vi) of the Income Tax Act is clarificatory of the position in law right from 01.06.1976 when
section 9(1)(vi) of the Income Tax Act was first brought into force. He then argued that the
provisions for TDS are distinct from and exist apart from provisions for assessment under the
Income Tax Act. This being so, it is clear that the India-USA DTAA and other such DTAAs would not
apply to the persons spoken of in section 195 of the Income Tax Act who are not assessees, since the
provisions of the DTAAs, when read with section 90 of the Income Tax Act, applied only to persons
who could be described as assessees. He also relied upon Article 30 of the India-USA DTAA which,
for the USA, fixes different dates for the entry into force of Circular No. 152 [F.No.
484/31/74-FTD-II], dated 27.11.1974. As recorded in CBDT Circular No. 588 dated 02.01.1991.
Notification No. 21/2012 [F.No.142/10/2012-SO(TPL)] S.O. 1323(E), dated 13.06.2012.Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

the provisions concerning withholding taxes and other taxes, unlike the entry into force provision
for India, which makes no such distinction. This, he argued, would make it clear that persons who
have to make deductions under section 195 of the Income Tax Act do not fall within the subject
matter of the India-USA DTAA and other such DTAAs. He then relied heavily upon AP Transco
(supra) and other judgments which make it clear that a “payer” under section 195 and an “assessee”
under section 2(7) of the Income Tax Act are distinct. He also relied heavily upon a recent judgment
of this Court in PILCOM v. CIT, West Bengal- VII, 2020 SCC Online SC 426 [“PILCOM”], which
dealt with section 194E of the Income Tax Act, for the proposition that tax has to be deducted at
source irrespective of whether tax is otherwise payable by the non-resident assessee. He then relied
upon CBDT Circular No. 588 dated 02.01.1991,12 which clarified that tax concessions were not
available in relation to payments in respect of software imported separately or independently of
computer hardware.
22. Coming to the Copyright Act, the learned Additional Solicitor General relied upon sections
2(a)(v), 19(3), 30A, 52(1)(ad), 58 and 65A of the Copyright Act to buttress the submission that in
some of the cases 187 ITR (St.) 0063.
before us, since adaptation of software could be made, albeit for installation and use on a particular
computer, copyright is parted with by the original owner. He added that section 51(b) of the
Copyright Act makes it clear that when any person makes for sale or hire, or sells or lets for hire, or
distributes, either for the purpose of trade or to such an extent as to affect prejudicially the owner of
the copyright, or imports into India, any infringing copies of the work, such importation into India
without a licence would amount to infringement of copyright. Further, section 58 of the Copyright
Act regards infringing copies of any work as the property of the owner of the copyright, who
accordingly may take proceedings for the recovery of possession thereof or in respect of the
conversion thereof. From section 52(1)(ad) of the Copyright Act, the learned Additional Solicitor
General sought to argue that only the making of copies or the adaptation of a computer programme
from a legally obtained copy for non-commercial, personal use would not amount to infringement,
and therefore in the appeals before us, where such copies were made for commercial use, the
converse would be true. He relied strongly upon the AAR’s ruling in Citrix Systems Asia Pacific Ptyl.
Ltd., In Re., (2012) 343 ITR 1 (AAR), arguing that it approached the subject correctly and that the
findings made therein are different and preferable to the findings made by the AAR in Dassault
Systems, K.K., In Re., (2010) 322 ITR 125 (AAR) and Geoquest Systems B.V. Gevers Deynootweg, In
Re., (2010) 327 ITR 1 (AAR), and the other judgments of the High Court of Delhi.
23. The learned Additional Solicitor General further pointed out that the Indian Government had
expressed its reservations on the OECD Commentary, especially on the parts of the OECD
Commentary dealing with the parting of copyright and royalty. He also relied upon on the Report of
the High Powered Committee on ‘Electronic Commerce and Taxation’ constituted by the CBDT,13
[“HPC Report 2003”] and the Report of the Committee on the Taxation of E-Commerce [“E-
Commerce Report 2016”], which proposed an equalization levy on specified transactions. He then
went on to rely on certain judgments to state that even if the OECD Commentary could be relied
upon, it being a rule of international law contrary to domestic law, to the extent it was contrary to
explanations 2 and 4 of section 9(1)(vi) of the Income Tax Act, it must give way to domestic law.Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

Referring to the doctrine of first sale/principle of exhaustion, he cited a number of judgments in
order to show that under section 14(b)(ii) of the Copyright Act, this doctrine cannot be said to apply
insofar as distributors are concerned. He finally F. No 500/ 122/ 99 dated December 16, 1999.
concluded his arguments by stating that the judgments which deal with computer software under
sales tax law and excise law have no relevance to income tax law, as the laws relating to indirect
taxes are fundamentally different from the laws relating to direct taxes, since they must follow the
drill of the chargeability under the Income Tax Act, which is different from chargeability under sales
tax law or excise law. THE INCOME TAX ACT, 1961
24. Having heard the learned counsels appearing on behalf of various parties, we first set out the
relevant provisions of the Income Tax Act that we are directly concerned with:
“2. Definitions.
In this Act, unless the context otherwise requires,— xxx xxx xxx (7) "assessee" means
a person by whom any tax or any other sum of money is payable under this Act, and
includes—
(a) every person in respect of whom any proceeding under this Act has been taken for
the assessment of his income or assessment of fringe benefits or of the income of any
other person in respect of which he is assessable, or of the loss sustained by him or by
such other person, or of the amount of refund due to him or to such other person ;
(b) every person who is deemed to be an assessee under any provision of this Act ;
(c) every person who is deemed to be an assessee in default under any provision of
this Act ;
xxx xxx xxx (37A) “rate or rates in force” or “rates in force”, in relation to an assessment year or
financial year, means— xxx xxx xxx
(iii) for the purposes of deduction of tax under section 194LBA or section 194LBB or section 194LBC
or section 195, the rate or rates of income-tax specified in this behalf in the Finance Act of the
relevant year or the rate or rates of income-tax specified in an agreement entered into by the Central
Government under section 90, or an agreement notified by the Central Government under section
90A, whichever is applicable by virtue of the provisions of section 90, or section 90A, as the case
may be;” “4. Charge of income-tax.
(1) Where any Central Act enacts that income-tax shall be charged for any assessment year at any
rate or rates, income-tax at that rate or those rates shall be charged for that year in accordance with,
and subject to the provisions (including provisions for the levy of additional income-tax) of, this Act
in respect of the total income of the previous year of every person:Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

Provided that where by virtue of any provision of this Act income-tax is to be charged
in respect of the income of a period other than the previous year, income-tax shall be
charged accordingly.
(2) In respect of income chargeable under sub-section (1), income-tax shall be
deducted at the source or paid in advance, where it is so deductible or payable under
any provision of this Act.” Substituted by the Finance Act 1992 (18 of 1992), sec. 3(c)
(w.e.f. 1-6-1992).
“5. Scope of total income.
(1) Subject to the provisions of this Act, the total income of any previous year of a
person who is a resident includes all income from whatever source derived which—
(a) is received or is deemed to be received in India in such year by or on behalf of
such person ; or
(b) accrues or arises or is deemed to accrue or arise to him in India during such year ;
or
(c) accrues or arises to him outside India during such year :
Provided that, in the case of a person not ordinarily resident in India within the
meaning of sub-section (6) of section 6, the income which accrues or arises to him
outside India shall not be so included unless it is derived from a business controlled
in or a profession set up in India. (2) Subject to the provisions of this Act, the total
income of any previous year of a person who is a non-resident includes all income
from whatever source derived which—
(a) is received or is deemed to be received in India in such year by or on behalf of
such person ; or
(b) accrues or arises or is deemed to accrue or arise to him in India during such year.
Explanation 1.—Income accruing or arising outside India shall not be deemed to be received in India
within the meaning of this section by reason only of the fact that it is taken into account in a balance
sheet prepared in India. Explanation 2.—For the removal of doubts, it is hereby declared that
income which has been included in the total income of a person on the basis that it has accrued or
arisen or is deemed to have accrued or arisen to him shall not again be so included on the basis that
it is received or deemed to be received by him in India.” “9. Income deemed to accrue or arise in
India.
(1) The following incomes shall be deemed to accrue or arise in India:— xxx xxx xxxEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

(vi) income by way of royalty payable by— xxx xxx xxx
(b) a person who is a resident, except where the royalty is payable in respect of any right, property or
information used or services utilised for the purposes of a business or profession carried on by such
person outside India or for the purposes of making or earning any income from any source outside
India;
xxx xxx xxx Explanation 2.—For the purposes of this clause, "royalty" means consideration
(including any lump sum consideration but excluding any consideration which would be the income
of the recipient chargeable under the head "Capital gains") for—
(i) the transfer of all or any rights (including the granting of a licence) in respect of a patent,
invention, model, design, secret formula or process or trade mark or similar property;
(ii) the imparting of any information concerning the working of, or the use of, a patent, invention,
model, design, secret formula or process or trade mark or similar property ;
(iii) the use of any patent, invention, model, design, secret formula or process or trade mark or
similar property ;
Inserted by the Finance Act 1976 (66 of 1976), sec 4(b) (w.e.f. 1-6-1976).
(iv) the imparting of any information concerning technical, industrial, commercial or scientific
knowledge, experience or skill ;
(iva) the use or right to use any industrial, commercial or scientific equipment but not including the
amounts referred to in section 44BB;
(v) the transfer of all or any rights (including the granting of a licence) in respect of any copyright,
literary, artistic or scientific work including films or video tapes for use in connection with television
or tapes for use in connection with radio broadcasting; or
(vi) the rendering of any services in connection with the activities referred to in 17[sub-clauses (i) to
(iv), (iva) and
(v)].
Explanation 3.—For the purposes of this clause, "computer software" means any computer
programme recorded on any disc, tape, perforated media or other information storage device and
includes any such programme or any customized electronic data.
Explanation 4.—For the removal of doubts, it is hereby clarified that the transfer of all or any rights
in respect of any right, property or information includes and has always included transfer of all or
any right for use or right to use a Inserted by the Finance Act 2001 (14 of 2001), sec. 4(i) (w.e.f.Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

1-4-2002). Substituted by the Finance Act 2001 (14 of 2001), sec. 4(ii), for “sub-clauses (i) to
(v)” (w.e.f. 1-4-2002).
Substituted by the Finance Act 2000 (10 of 2000), sec. 4, for Explanation 3 (w.e.f. 1-4-2001).
Explanation 3 before substitution, stood as under:
“Explanation 3.- For the purposes of this clause, the expression “computer software”
shall have the meaning assigned to it in clause
(b) of the Explanation to section 80HHE”.
Inserted by the Finance Act 2012 (23 of 2012), sec 4(b) (w.r.e.f 1-6-1976). computer software
(including granting of a licence) irrespective of the medium through which such right is transferred.
Explanation 5.—For the removal of doubts, it is hereby clarified that the royalty includes and has
always included consideration in respect of any right, property or information, whether or not—
(a) the possession or control of such right, property or information is with the payer;
(b) such right, property or information is used directly by the payer;
(c) the location of such right, property or information is in India.” “90. Agreement with foreign
countries or specified territories.
(1) The Central Government may enter into an agreement with the Government of any country
outside India or specified territory outside India,—
(a) for the granting of relief in respect of—
(i) income on which have been paid both income-
tax under this Act and income-tax in that country or specified territory, as the case may be, or
(ii) income-tax chargeable under this Act and under the corresponding law in force in that country
or specified territory, as the case may be, to promote mutual economic relations, trade and
investment, or
(b) for the avoidance of double taxation of income under this Act and under the corresponding law
in force in that country or specified territory, as the case may be, Inserted by the Finance Act 2012
(23 of 2012), sec 4(b) (w.r.e.f 1-6-1976). without creating opportunities for non-taxation or reduced
taxation through tax evasion or avoidance (including through treaty-shopping arrangements aimed
at obtaining reliefs provided in the said agreement for the indirect benefit to residents of any other
country or territory), orEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

(c) for exchange of information for the prevention of evasion or avoidance of income-tax chargeable
under this Act or under the corresponding law in force in that country or specified territory, as the
case may be, or investigation of cases of such evasion or avoidance, or
(d) for recovery of income-tax under this Act and under the corresponding law in force in that
country or specified territory, as the case may be, and may, by notification in the Official Gazette,
make such provisions as may be necessary for implementing the agreement.
(2) Where the Central Government has entered into an agreement with the Government of any
country outside India or specified territory outside India, as the case may be, under sub-section (1)
for granting relief of tax, or as the case may be, avoidance of double taxation, then, in relation to the
assessee to whom such agreement applies, the provisions of this Act shall apply to the extent they
are more beneficial to that assessee.
xxx xxx xxx Explanation 4.—For the removal of doubts, it is hereby declared that where any term
used in an agreement entered into under sub-section (1) is defined under the said agreement, the
said term shall have the same meaning as assigned to it in the agreement; and where the term is not
defined in the said agreement, but defined in the Act, it shall Inserted by the Finance Act 2017, sec.
39 (w.e.f. 1-4-2018). have the same meaning as assigned to it in the Act and explanation, if any,
given to it by the Central Government.” “195. Other sums.
(1) Any person responsible for paying to a non-resident, not being a company, or to a foreign
company, any interest (not being interest referred to in section 194LB or section 194LC) or section
194LD or any other sum chargeable under the provisions of this Act (not being income chargeable
under the head "Salaries") shall, at the time of credit of such income to the account of the payee or at
the time of payment thereof in cash or by the issue of a cheque or draft or by any other mode,
whichever is earlier, deduct income-tax thereon at the rates in force:
Provided that in the case of interest payable by the Government or a public sector
bank within the meaning of clause (23D) of section 10 or a public financial institution
within the meaning of that clause, deduction of tax shall be made only at the time of
payment thereof in cash or by the issue of a cheque or draft or by any other mode.
Explanation 1.—For the purposes of this section, where any interest or other sum as
aforesaid is credited to any account, whether called "Interest payable account" or
"Suspense account" or by any other name, in the books of account of the person liable
to pay such income, such crediting shall be deemed to be credit of such income to the
account of the payee and the provisions of this section shall apply accordingly.
Explanation 2.—For the removal of doubts, it is hereby clarified that the obligation to
comply with sub-section (1) and to make deduction thereunder applies and shall be
deemed to have always applied and extends and shall be Inserted by the Finance Act
2012 (23 of 2012), sec. 77(a)(ii) (w.r.e.f. 1-4-1962).Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

deemed to have always extended to all persons, resident or non-resident, whether or
not the non-resident person has—
(i) a residence or place of business or business connection in India; or
(ii) any other presence in any manner whatsoever in India.
(2) Where the person responsible for paying any such sum chargeable under this Act
23(other than salary) to a non-
resident considers that the whole of such sum would not be income chargeable in the case of the
recipient, he may make an application in such form and manner to the Assessing Officer, to
determine in such manner, as may be prescribed, the appropriate proportion of such sum so
chargeable, and upon such determination, tax shall be deducted under sub- section (1) only on that
proportion of the sum which is so chargeable.” “201. Consequences of failure to deduct or pay. (1)
Where any person, including the principal officer of a company,—
(a) who is required to deduct any sum in accordance with the provisions of this Act; or
(b) referred to in sub-section (1A) of section 192, being an employer, does not deduct, or does not
pay, or after so deducting fails to pay, the whole or any part of the tax, as required by or under this
Act, then, such person, shall, without prejudice to any other consequences which he may incur, be
deemed to be an assessee in default in respect of such tax:
Provided that any person, including the principal officer of a company, who fails to
deduct the whole or any part of the Substituted by the Finance Act 2003 (32 of
2003), sec. 80(b) (w.e.f. 1-6-2003).
tax in accordance with the provisions of this Chapter on the sum paid to a payee or on
the sum credited to the account of a payee shall not be deemed to be an assessee in
default in respect of such tax if such payee—
(i) has furnished his return of income under section 139;
(ii) has taken into account such sum for computing income in such return of income;
and
(iii) has paid the tax due on the income declared by him in such return of income, and
the person furnishes a certificate to this effect from an accountant in such form as
may be prescribed:
Provided further that no penalty shall be charged under section 221 from such
person, unless the Assessing Officer is satisfied that such person, without good and
sufficient reasons, has failed to deduct and pay such tax.”Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

25. The scheme of the Income Tax Act, insofar as the question raised before us is concerned, is that
for income to be taxed under the Income Tax Act, residence in India, as defined by section 6, is
necessary in most cases. By section 4(1), income tax shall be charged for any assessment year at any
rate or rates, as defined by section 2(37A) of the Income Tax Act, in respect of the total income of
the previous year of every person. Under section 4(2), in respect of income chargeable under
sub-section (1) thereof, income tax shall be deducted at source or paid in advance, depending upon
the provisions of the Income Tax Act. Importantly, under section 5(2) of the Income Tax Act, the
total income of a person who is a non-resident, includes all income from whatever source derived,
which accrues or arises or is deemed to accrue or arise to such person in India during such year.
This, however, is subject to the provisions of the Income Tax Act. Certain income is deemed to arise
or accrue in India, under section 9 of the Income Tax Act, notwithstanding the fact that such income
may accrue or arise to a non-resident outside India. One such income is income by way of royalty,
which, under section 9(1)(vi) of the Income Tax Act, means the transfer of all or any rights,
including the granting of a licence, in respect of any copyright in a literary work.
26. That such transaction may be governed by a DTAA is then recognized by section 5(2) read with
section 90 of the Income Tax Act, making it clear that the Central Government may enter into any
such agreement with the government of another country so as to grant relief in respect of income tax
chargeable under the Income Tax Act or under any corresponding law in force in that foreign
country, or for the avoidance of double taxation of income under the Income Tax Act and under the
corresponding law in force in that country. What is of importance is that once a DTAA applies, the
provisions of the Income Tax Act can only apply to the extent that they are more beneficial to the
assessee and not otherwise. Further, by explanation 4 to section 90 of the Income Tax Act, it has
been clarified by the Parliament that where any term is defined in a DTAA, the definition contained
in the DTAA is to be looked at. It is only where there is no such definition that the definition in the
Income Tax Act can then be applied. This position has been recognised by this Court in Azadi
Bachao Andolan (supra), which held:
“21. The provisions of Sections 4 and 5 of the Act are expressly made “subject to the
provisions of this Act”, which would include Section 90 of the Act. As to what would
happen in the event of a conflict between the provision of the Income Tax Act and a
notification issued under Section 90, is no longer res integra.” “28. A survey of the
aforesaid cases makes it clear that the judicial consensus in India has been that
Section 90 is specifically intended to enable and empower the Central Government to
issue a notification for implementation of the terms of a Double Taxation Avoidance
Agreement. When that happens, the provisions of such an agreement, with respect to
cases to which they apply, would operate even if inconsistent with the provisions of
the Income Tax Act. We approve of the reasoning in the decisions which we have
noticed. If it was not the intention of the legislature to make a departure from the
general principle of chargeability to tax under Section 4 and the general principle of
ascertainment of total income under Section 5 of the Act, then there was no purpose
in making those sections “subject to the provisions of the Act”. The very object of
grafting the said two sections with the said clause is to enable the Central
Government to issue a notification under Section 90 towards implementation of theEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

terms of DTACs which would automatically override the provisions of the Income Tax
Act in the matter of ascertainment of chargeability to income tax and ascertainment
of total income, to the extent of inconsistency with the terms of DTAC.” (emphasis
supplied)
27. The machinery provision contained in section 195 of the Income Tax Act is inextricably linked
with the charging provision contained in section 9 read with section 4 of the Income Tax Act, as a
result of which, a person resident in India, responsible for paying a sum of money, “chargeable
under the provisions of [the] Act”, to a non-resident, shall at the time of credit of such amount to the
account of the payee in any mode, deduct tax at source at the rate in force which, under section
2(37A)(iii) of the Income Tax Act, is the rate in force prescribed by the DTAA. Importantly, such
deduction is only to be made if the non- resident is liable to pay tax under the charging provision
contained in section 9 read with section 4 of the Income Tax Act, read with the DTAA. Thus, it is
only when the non-resident is liable to pay income tax in India on income deemed to arise in India
and no deduction of TDS is made under section 195(1) of the Income Tax Act, or such person has,
after applying section 195(2) of the Income Tax Act, not deducted such proportion of tax as is
required, that the consequences of a failure to deduct and pay, reflected in section 201 of the Income
Tax Act, follow, by virtue of which the resident-payee is deemed an “assessee in default”, and thus, is
made liable to pay tax, interest and penalty thereon. This position is also made amply clear by the
referral order in the concerned appeals from the High Court of Karnataka, namely, the judgment of
this Court in GE Technology (supra).
28. However, the learned Additional Solicitor General relied strongly upon the recent judgment of
this Court in PILCOM (supra). This judgment dealt with payments made to non-resident
sportspersons or sports associations, the relevant provision under section 194E of the Income Tax
Act reading as follows:
“194-E. Payments to non-resident sportsmen or sports associations. - Where any
income referred to in Section 115-BBA is payable to a non-resident sportsman
(including an athlete) who is not a citizen of India or a non-resident sports
association or institution, the person responsible for making the payment shall, at the
time of credit of such income to the account of the payee or at the time of payment
thereof in cash or by issue of a cheque or draft or by any other mode, whichever is
earlier, deduct income tax thereon at the rate of ten percent”
29. It is in this context that this Court referred to the judgment in GE Technology (supra) (see
paragraph 16) and distinguished the same, stating:
“16.1 The submission that unless permission was obtained under Section 195(2) of
the Act, the liability to deduct Tax at Source must be with respect to the entire
payment, was not accepted. Relying on the expression “chargeable under the
provisions of the Act” occurring in Section 195(1) of the Act, it was held “the
obligation to deduct TAS, is however, limited to the appropriate proportion of the
income chargeable under the Act forming part of the gross sum of money payable toEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

the non-resident”.
16.2 This decision, in our view, has no application insofar as payments at serial nos.
(vi) and (vii) are concerned. To the extent the payments represented amounts which
could not be subject matter of charge under the provisions of the Act, appropriate
benefit already stands extended to the Appellant.”
30. It was in the context of section 194E of the Income Tax Act, that the Court went on to observe:
“18. We now come to the issue of applicability of DTAA. As observed by the High
Court, the matter was not argued before it in that behalf, yet the issue was dealt with
by the High Court. In our view, the reasoning that weighed with the High Court is
quite correct. The obligation to deduct Tax at Source under Section 194E of the Act is
not affected by the DTAA and in case the exigibility to tax is disputed by the assessee
on whose account the deduction is made, the benefit of DTAA can be pleaded and if
the case is made out, the amount in question will always be refunded with interest.
But, that by itself, cannot absolve the liability under Section 194E of the Act.
19. In the premises, it must be held that the payments made to the Non Resident
Sports Associations in the present case represented their income which accrued or
arose or was deemed to have accrued or arisen in India. Consequently, the Appellant
was liable to deduct Tax at Source in terms of Section 194E of the Act.”
31. It will be seen that section 194E of the Income Tax Act belongs to a set of various provisions
which deal with TDS, without any reference to chargeability of tax under the Income Tax Act by the
concerned non- resident assessee. This section is similar to sections 193 and 194 of the Income Tax
Act by which deductions have to be made without any reference to the chargeability of a sum
received by a non-resident assessee under the Income Tax Act. On the other hand, as has been noted
in GE Technology (supra), at the heart of section 195 of the Income Tax Act is the fact that
deductions can only be made if the non- resident assessee is liable to pay tax under the provisions of
the Income Tax Act in the first place.
32. Thus, the judgment of this Court in PILCOM (supra), dealing with a completely different
provision in a completely different setting, has no application to the facts of this case.
THE COPYRIGHT ACT, 1957
33. The relevant provisions of the Copyright Act are as follows:
“2. Interpretation.—In this Act, unless the context otherwise requires,—
(a) “adaptation” means,-
xxx xxx xxxEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

(v) in relation to any work, any use of such work involving its rearrangement or alteration;
xxx xxx xxx
(d) “author” means,—
(vi) in relation to any literary, dramatic, musical or artistic work which is computer-generated, the
person who causes the work to be created;
xxx xxx xxx (fa) “commercial rental” does not include the rental, lease or lending of a lawfully
acquired copy of a computer programme, sound recording, visual recording or cinematographic film
for non-profit purposes by a non-profit library or non-profit educational institution;
xxx xxx xxx (ffb) “computer” includes any electronic or similar device having information processing
capabilities (ffc) “computer programme” means a set of instructions expressed in words, codes,
schemes or in any other form, including a machine readable medium, capable of causing a computer
to perform a particular task or achieve a particular result;
xxx xxx xxx Substituted by Act 38 of 1994, sec. 2 (w.e.f. 10-5-1995). Inserted by Act 27 of 2012, sec.
2(ii) (w.e.f. 21-6-2012).
(m) "infringing copy" means--
(i) in relation to a literary, dramatic, musical or artistic work, a reproduction thereof otherwise than
in the form of a cinematograph film;
(ii) in relation to a cinematographic film, a copy of the film made on any medium by any means;
(iii) in relation to a sound recording, any other recording embodying the same sound recording,
made by any means;
(iv) in relation to a programme or performance in which such a broadcast reproduction right or a
performer's right subsists under the provisions of this Act, the sound recording or a
cinematographic film of such programme or performance,;
if such reproduction, copy or sound recording is made or imported in contravention of the
provisions of this Act; xxx xxx xxx
(o) "literary work" includes computer programmes, tables and compilations including computer
databases;” “14. Meaning of copyright.-- For the purposes of this Act, copyright means the exclusive
right subject to the provisions of this Act, to do or authorise the doing of any of the following acts in
respect of a work or any substantial part thereof, namely--
(a) in the case of a literary, dramatic or musical work, not being a computer programme,--Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

(i) to reproduce the work in any material form including the storing of it in any medium by
electronic means;
Substituted by Act 38 of 1994, sec. 2 (w.e.f. 10-5-1995).
(ii) to issue copies of the work to the public not being copies already in circulation;
(iii) to perform the work in public, or communicate it to the public;
(iv) to make any cinematograph film or sound recording in respect of the work;
(v) to make any translation of the work;
(vi) to make any adaptation of the work;
(vii) to do, in relation to a translation or an adaptation of the work, any of the acts specified in
relation to the work in sub-clauses (i) to (vi);
(b) in the case of a computer programme--
(i) to do any of the acts specified in clause (a);
(ii) to sell or give on commercial rental or offer for sale or for commercial rental any copy of the
computer programme:
Provided that such commercial rental does not apply in respect of computer
programmes where the programme itself is not the essential object of the rental.” “16.
No copyright except as provided in this Act.-- No person shall be entitled to copyright
or any similar right in any work, whether published or unpublished, otherwise than
under and in accordance with the provisions of this Act or of any other law for the
time being in force, but nothing in this section shall be construed as abrogating any
right or jurisdiction to restrain a breach of trust or confidence.” “18. Assignment of
copyright.-- (1) The owner of the copyright in an existing work or the prospective
owner of the Substituted by Act 49 of 1999, sec. 3 (w.e.f. 15-1-2000).
copyright in a future work may assign to any person the copyright either wholly or
partially and either generally or subject to limitations and either for the whole term of
the copyright or any part thereof:
Provided that in the case of the assignment of copyright in any future work, the
assignment shall take effect only when the work comes into existence.
Provided further that no such assignment shall be applied to any medium or mode of
exploitation of the work which did not exit or was not in commercial use at the timeEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

when the assignment was made, unless the assignment specifically referred to such
medium or mode of exploitation of the work:
Provided also that the author of the literary or musical work included in a
cinematograph film shall not assign or waive the right to receive royalties to be
shared on an equal basis with the assignee of copyright for the utilisation of such
work in any form other than for the communication to the public of the work along
with the cinematograph film in a cinema hall, except to the legal heirs of the authors
or to a copyright society for collection and distribution and any agreement to
contrary shall be void:
Provided also that the author of the literary or musical work included in the sound
recording but not forming part of any cinematograph film shall not assign or waive
the right to receive royalties to be shared on an equal basis with the assignee of
copyright for any utilisation of such work except to the legal heirs of the authors or to
a collecting society for collection and distribution and any assignment to the contrary
shall be void.
Inserted by Act 27 of 2012, sec. 8 (w.e.f. 21-6-2012).
(2) Where the assignee of a copyright becomes entitled to any right comprised in the
copyright, the assignee as respects the rights so assigned, and the assignor as respects
the rights not assigned, shall be treated for the purposes of this Act as the owner of
copyright and the provisions of this Act shall have effect accordingly.
(3) In this section, the expression "assignee" as respects the assignment of the
copyright in any future work includes the legal representatives of the assignee, if the
assignee dies before the work comes into existence.” “19. Mode of assignment.— xxx
xxx xxx (3) The assignment of copyright in any work shall also specify the amount of
royalty and any other consideration payable, to the author or his legal heirs during
the currency of the assignment and the assignment shall be subject to revision,
extension or termination on terms mutually agreed upon by the parties.” “30.
Licences by owners of copyright-- The owner of the copyright in any existing work of
the prospective owner of the copyright in any future work may grant any interest in
the right by licence in writing by him or by his duly authorised agent:
Provided that in the case of a licence relating to copyright in any future work, the
licence shall take effect only when the work comes into existence.
Explanation.--Where a person to whom a licence relating to copyright in any future
work is granted under this section dies before the work comes into existence, his legal
representatives shall, in the absence of any provision to the contrary in the licence, be
entitled to the benefit of the licence.Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

30A. Application of section 19.— The provisions of section 19 shall, with any
necessary adaptations and modifications, apply in relation to a licence under section
30 as they apply in relation to assignment of copyright in a work.” “51. When
copyright infringed. Copyright in a work shall be deemed to be infringed--
(a) when any person, without a licence granted by the owner of the copyright or the
Registrar of Copyrights under this Act or in contravention of the conditions of a
licence so granted or of any condition imposed by a competent authority under this
Act--
(i) does anything, the exclusive right to do which is by this Act conferred upon the
owner of the copyright, or
(ii) permits for profit any place to be used for the communication of the work to the
public where such communication constitutes an infringement of the copyright in the
work, unless he was not aware and had no reasonable ground for believing that such
communication to the public would be an infringement of copyright; or
(b) when any person--
(i) makes for sale or hire, or sells or lets for hire, or by way of trade displays or offers
for sale or hire, or
(ii) distributes either for the purpose of trade or to such an extent as to affect
prejudicially the owner of the copyright, or Inserted by Act 38 of 1994, s. 10 (w.e.f.
10-5-1995).
(iii) by way of trade exhibits in public, or
(iv) imports into India, any infringing copies of the work:
Provided that nothing in sub-clause (iv) shall apply to the import of one copy of any
work for the private and domestic use of the importer.] Explanation.-- For the
purposes of this section, the reproduction of a literary, dramatic, musical or artistic
work in the form of a cinematograph film shall be deemed to be an "infringing copy".
“52. Certain acts not to be infringement of copyright.
(1) The following acts shall not constitute an infringement of copyright, namely,--
xxx xxx xxx (aa) the making of copies or adaptation of a computer programme by the lawful
possessor of a copy of such computer programme, from such copy--
(i) in order to utilise the computer programme for the purpose for which it was supplied; orEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

(ii) to make back-up copies purely as a temporary protection against loss, destruction or damage in
order only to utilise the computer programme for the purpose for which it was supplied;
xxx xxx xxx (ad) the making of copies or adaptation of the computer programme from a personally
legally obtained copy for non-commercial personal use;” “58. Rights of owner against persons
possessing or dealing with infringing copies.— All infringing copies of any work in which copyright
subsists, and all plates used or Inserted by Act 38 of 1994, sec. 17 (w.e.f. 10-5-1995). intended to be
used for the production of such infringing copies, shall be deemed to be the property of the owner of
the copyright, who accordingly may take proceedings for the recovery of possession thereof or in
respect of the conversion thereof:
Provided that the owner of the copyright shall not be entitled to any remedy in
respect of the conversion of any infringing copies, if the opponent proves—
(a) that he was not aware and had no reasonable ground to believe that copyright
subsisted in the work of which such copies are alleged to be infringing copies; or
(b) that he had reasonable grounds for believing that such copies or plates do not
involve infringement of the copyright in any work.”
34. A reading of the aforesaid provisions leads to the following conclusions. Under section 2(o) of
the Copyright Act, a literary work includes a computer programme and a computer programme has
been defined under section 2(ffc) of the Copyright Act to mean a set of instructions expressed in
words, codes, schemes or in any other form capable of causing a computer to perform a particular
task or achieve a particular result.
35. Though the expression “copyright” has not been defined separately in the “definitions” section of
the Copyright Act, yet, section 14 makes it clear that “copyright” means the “exclusive right”, subject
to the provisions of the Act, to do or authorise the doing of certain acts “in respect of a work”. When
an “author” in relation to a “literary work” which includes a “computer programme”, creates such
work, such author has the exclusive right, subject to the provisions of the Copyright Act, to do or
authorise the doing of several acts in respect of such work or any substantial part thereof. In the case
of a computer programme, section 14(b) specifically speaks of two sets of acts – the seven acts
enumerated in sub-clause (a) and the eighth act of selling or giving on commercial rental or offering
for sale or for commercial rental any copy of the computer programme. Insofar as the seven acts that
are set out in sub-clause (a) are concerned, they all delineate how the exclusive right that is with the
owner of the copyright may be parted with, i.e., if there is any parting with the right to reproduce the
work in any material form; the right to issue copies of the work to the public, not being copies
already in circulation; the right to perform the work in public or communicate it to the public; the
right to make any cinematograph film or sound recording in respect of the work; the right to make
any translation of the work; the right to make any adaptation of the work; or the right to do any of
the specified acts in relation to a translation or an adaptation.Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

36. In essence, such right is referred to as copyright, and includes the right to reproduce the work in
any material form, issue copies of the work to the public, perform the work in public, or make
translations or adaptations of the work. This is made even clearer by the definition of an “infringing
copy” contained in section 2(m) of the Copyright Act, which in relation to a computer programme,
i.e., a literary work, means reproduction of the said work. Thus, the right to reproduce a computer
programme and exploit the reproduction by way of sale, transfer, license etc. is at the heart of the
said exclusive right.
37. Section 14(b)(ii) of the Copyright Act was amended twice, first in 1994 and then again in 1999,
with effect from 15.01.2000. Prior to the 1999 Amendment, section 14(b)(ii) of the Copyright Act
read as follows:
“(ii) to sell or give on hire, or offer for sale or hire any copy of the computer
programme, regardless of whether such copy has been sold or given on hire on earlier
occasions;” What is conspicuous by its absence is the phrase “regardless of whether
such copy has been sold or given on hire on earlier occasions”.
38. Importantly, no copyright exists in India outside the provisions of the Copyright Act or any other
special law for the time being in force, vide section 16 of the Copyright Act. When the owner of
copyright in a literary work assigns wholly or in part, all or any of the rights contained in section
14(a) and (b) of the Copyright Act, in the said work for a consideration, the assignee of such right
becomes entitled to all such rights comprised in the copyright that is assigned, and shall be treated
as the owner of the copyright of what is assigned to him (see section 18(2) read with section 19(3) of
the Copyright Act). Also, under section 30 of the Copyright Act, the owner of the copyright in any
literary work may grant any interest in any right mentioned in section 14(a) of the Copyright Act by
licence in writing by him to the licensee, under which, for parting with such interest, royalty may
become payable (see section 30A of the Copyright Act). When such licence is granted, copyright is
infringed when any use, relatable to the said interest/right that is licensed, is contrary to the
conditions of the licence so granted. Infringement of copyright takes place when a person “makes for
sale or hire or sells or lets for hire” or “offers for sale or hire” or “distributes…so as to affect
prejudicially the owner of the copyright”, vide section 51(b) of the Copyright Act. Importantly, the
making of copies or adaptation of a computer programme in order to utilise the said computer
programme for the purpose for which it was supplied, or to make up back-up copies as a temporary
protection against loss, destruction or damage so as to be able to utilise the computer programme
for the purpose for which it was supplied, does not constitute an act of infringement of copyright
under section 52(1)(aa) of the Copyright Act. In short, what is referred to in section 52(1)(aa) of the
Copyright Act would not amount to reproduction so as to amount to an infringement of copyright.
39. Section 52(1)(ad) is independent of section 52(1)(aa) of the Copyright Act, and states that the
making of copies of a computer programme from a personally legally obtained copy for
non-commercial personal use would not amount to an infringement of copyright. However, it is not
possible to deduce from this what is sought to be deduced by the learned Additional Solicitor
General, namely, that if personally legally obtained copies of a computer programme are to be
exploited for commercial use, it would necessarily amount to an infringement of copyright. SectionEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

52(1)(ad) of the Copyright Act cannot be read to negate the effect of section 52(1)(aa), since it deals
with a subject matter that is separate and distinct from that contained in section 52(1)(aa) of the
Copyright Act.
DOUBLE TAXATION AVOIDANCE AGREEMENTS
40. These appeals concern the DTAAs between India and the following countries/parties:
1. Commonwealth of Australia
2. Canada
3. People’s Republic of China
4. Republic of Cyprus
5. Republic of Finland
6. Republic of France
7. Federal Republic of Germany
8. Hong Kong Special Administrative Region of the People's Republic of China
9. Republic of Ireland
10. Republic of Italy
11. Japan
12. Republic of Korea
13. Kingdom of Netherlands
14. Republic of Singapore
15. Kingdom of Sweden
16. India-Taipei Association in Taipei (Taiwan)
17. United States of America
18. United Kingdom of Great Britain and Northern IrelandEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

41. Insofar as is material, each of these DTAAs is based on the OECD Model Tax Convention on
Income and on Capital, and are therefore substantially similar, if not identical, in respect of the
provisions concerning “business profits” and “royalties”. The provisions of one of these DTAAs,
namely the India-Singapore DTAA, are set out as follows:
“ARTICLE 2 - TAXES COVERED
1. The taxes to which this Agreement shall apply are:
(a) in India: income-tax including any surcharge thereon (hereinafter referred to as
"Indian tax");
(b) in Singapore: the income tax (hereinafter referred to as "Singapore tax").
2. The Agreement shall also apply to any identical or substantially similar taxes which are imposed
by either Contracting State after the date of signature of the present Agreement in addition to, or in
place of, the taxes referred to in paragraph 1. The competent authorities of the Contracting States
shall notify each other of any substantial changes which are made in their respective taxation laws.”
“ARTICLE 3 - GENERAL DEFINITIONS xxx xxx xxx
2. As regards the application of the Agreement by a Contracting State, any term not defined therein
shall, unless the context otherwise requires, have the meaning which it has under the law of that
State concerning the taxes to which the Agreement applies.” “ARTICLE 7 - BUSINESS PROFITS
1. The profits of an enterprise of a Contracting State shall be taxable only in that State unless the
enterprise carries on business in the other Contracting State through a permanent establishment
situated therein. If the enterprise carries on business as aforesaid, the profits of the enterprise may
be taxed in the other State but only so much of them as is directly or indirectly attributable to that
permanent establishment.” “ARTICLE 12 - ROYALTIES AND FEES FOR TECHNICAL SERVICES
1. Royalties and fees for technical services arising in a Contracting State and paid to a resident of the
other Contracting State may be taxed in that other State.
2. However, such royalties and fees for technical services may also be taxed in the Contracting State
in which they arise and according to the laws of that State, but if the recipient is the beneficial owner
of the royalties or fees for technical services, the tax so charged shall not exceed:
(a) in the case of royalties referred to in paragraph 3(a) and fees for technical services
as defined in this Article (other than services described in subparagraph (b) of this
paragraph), 15% of the gross amount of the royalties and fees;
(b) in the case of royalties referred to in paragraph 3(b) and fees for technical services
as defined in this Article that are ancillary and subsidiary to the enjoyment of
property for which royalties under paragraph 3(b) are received, 10% of the grossEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

amount of the royalties and fees.
3. The term "royalties" as used in this Article means payments of any kind received as a
consideration for the use of, or the right to use:
(a) any copyright of a literary, artistic or scientific work, including cinematograph
films or films or tapes used for radio or television broadcasting, any patent, trade
mark, design or model, plan, secret formula or process, or for information concerning
industrial, commercial or scientific experience, including gains derived from the
alienation of any such right, property or information;
(b) any industrial, commercial or scientific equipment, other than payments derived
by an enterprise from activities described in paragraph 4(b) or 4(c) of Article
8.” “ARTICLE 30 - ENTRY INTO FORCE
1. Each of the Contracting States shall notify the other of the completion of the
procedures required by its law for the bringing into force of this Agreement. This
Agreement shall enter into force on the date of the later of these notifications and
shall thereupon have effect:
(a) in India: in respect of income arising in any fiscal year beginning on or after the
first day of April 1994;
(b) in Singapore: in respect of income arising in any fiscal year beginning on or after
the first day of January 1994.
2. The Agreement between the Government of the Republic of India and the Government of the
Republic of Singapore for the avoidance of double taxation and the prevention of fiscal evasion with
respect to taxes on income signed in Singapore on 20th April, 1981 shall terminate and cease to be
effective from the date on which this Agreement comes into effect.”
42. The subject matter of each of the DTAAs with which we are concerned is income tax payable in
India and a foreign country. Importantly, as is now reflected by explanation 4 to section 90 of the
Income Tax Act and under Article 3(2) of the DTAA, the definition of the term “royalties” shall have
the meaning assigned to it by the DTAA, meaning thereby that the expression “royalty”, when
occurring in section 9 of the Income Tax Act, has to be construed with reference to Article 12 of the
DTAA. This position is also clarified by CBDT Circular No. 333 dated 02.04.1982,31 which states as
follows:
“Circular : No. 333 dated 2-4-1982.
Specific provisions made in double taxation avoidance agreement - Whether it would
prevail over general provisions contained in Income-tax ActEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

1. It has come to the notice of the Board that sometimes effect to the provisions of
double taxation avoidance agreement is not given by the Assessing Officers when
they find that the provisions of the agreement are not in conformity with the
provisions of the Income-tax Act, 1961.
2. The correct legal position is that where a specific provision is made in the double
taxation avoidance agreement, that provisions will prevail over the general provisions
contained in the Income-tax Act. In fact that the double taxation avoidance
agreements which have been entered into by the Central Government under section
90 of the Income-tax Act, also provide that the laws in force in either country will
continue to govern the assessment and taxation of income in the respective countries
except where provisions to the contrary have been made in the agreement.
F. No. 506/42/81-FTD.
3. Thus, where a double taxation avoidance agreement provides for a particular mode of
computation of income, the same should be followed, irrespective of the provisions in the
Income-tax Act. Where there is no specific provision in the agreement, it is basic law, i.e., the
Income-tax Act, that will govern the taxation of income.”
43. Thus, by virtue of Article 12(3) of the DTAA, royalties are payments of any kind received as
consideration for “the use of, or the right to use, any copyright” of a literary work, which includes a
computer programme or software.
END-USER LICENCE AGREEMENTS AND DISTRIBUTION AGREEMENTS
44. Certain sample clauses of the EULAs that are illustrative of the transactions with which we are
concerned in each category (outlined in paragraph 4 of this judgment), are set out hereinbelow:
44. i) Category 1:
The EULA between Samsung Electronics Co. and the end-user (updated on
16.11.2016) contains, inter alia, the following terms:
“This End User Licence Agreement ("EULA") is a legal agreement between you
(either an individual or a single entity) and Samsung Electronics Co., Ltd.
("Samsung") for software, whether pre-installed or downloaded, owned by Samsung
and its affiliated companies and its third party suppliers and licensors, that
accompanies this EULA, which includes computer software and may include
associated media, content and data, printed materials, or electronic documentation
in connection with your use of Samsung Mobile Device, which will be defined below
("Samsung Software").
xxx xxx xxxEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

1. GRANT OF LICENCE. Samsung grants you a limited non-exclusive licence to
install, use, access, display and run one copy of the Samsung Software on a single
Samsung Mobile Device, local hard disk(s) or other permanent storage media of one
computer and you may not make Samsung Software available over a network where it
could be used by multiple computers at the same time. You may make one copy of the
Samsung Software in machine readable form for backup purposes only; provided that
the backup copy must include all copyright or other proprietary notices contained on
the original.
Certain items of the Samsung Software may be subject to open source licences. The open source
licence provisions may override some of the terms of this EULA. We make the applicable open
source licenses available to you on the Legal Notices section of the Settings menu of your device.
2. RESERVATION OF RIGHTS AND OWNERSHIP.
Samsung reserves all rights not expressly granted to you in this EULA. The Software is protected by
copyright and other intellectual property laws and treaties. Samsung or its suppliers own the title,
copyright and other intellectual property rights in the Samsung Software. The Samsung Software is
licenced, not sold.
3. LIMITATIONS ON END USER RIGHTS. You shall not, and shall not enable or permit others to,
copy, reverse engineer, decompile, disassemble, or otherwise attempt to discover the source code or
algorithms of, the Software (except and only to the extent that such activity is expressly permitted by
applicable law notwithstanding this limitation), or modify, or disable any features of, the Software,
or create derivative works based on the Software. You may not rent, lease, lend, sublicense or
provide commercial hosting services with the Software. You may not transfer this EULA or the
rights to the Samsung Software granted herein to any third party unless it is in connection with the
sale of the mobile device which the Samsung Software accompanied. In such event, the transfer
must include all of the Samsung Software (including all component parts, the media and printed
materials, any upgrades, this EULA) and you may not retain any copies of the Samsung Software.
The transfer may not be an indirect transfer, such as a consignment. Prior to the transfer, the end
user receiving the Samsung Software must agree to all the EULA terms. Where Samsung Mobile
Device is being used by your employee or other person using the Samsung Mobile Device as part of
your undertaking ("Your Staff"), that member of your Staff is licenced to use the Samsung Software
as if it were you and must comply with these terms on the same basis. Any failure to comply with
these terms by your Staff shall be deemed [to be a] failure to comply with these terms by you.
xxx xxx xxx
7. EXPORT RESTRICTIONS. You acknowledge that the Samsung Software is subject to export
restrictions of various countries. You agree to comply with all applicable international and national
laws that apply to the Samsung Software, including all the applicable export restriction laws and
regulations.” (emphasis supplied)Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

44. ii) Category 2:
44. ii) a. The Remarketer Agreement dated 01.10.2004, between IBM Singapore, a
foreign, non-resident supplier of computer programmes and IBM India, an Indian
distributor/remarketer, with which C.A. No. 4419/2012 is concerned, contains, inter
alia, the following terms:
“IMB Distribution Agreement General Terms
1.Definitions IMB shall mean International Business Machines Corporation
Customer is either an End User or a Remarketer. You may market to End User or
Remarketers or both.
End User is anyone, who is not a Related Company, who acquires Programs for its own use and not
for resale. Programs shall mean instructions written, contained or recorded on materials,
documents or machine readable media capable of being executed on, or used in the operation of a
machine and information technology or data related thereto. The term shall include, but is not
limited to, instructions, documentation, information or data recorded on reels of magnetic tape,
magnetic disks, microfiche cards, and other similar media, and logic manuals, flow charts,
operational instruction guides, interface specifications, detailed listings, application manuals,
modification guides, operating Instructions, functional specifications and design specifications
containing or related to such information, instruments or data. In particular, the term Programs
includes, but is not limited to supervisors, monitors, operating systems, language compiles, sorts
conversion aid programs, general purpose utilities, industry application programs and other general
purpose application programs. IMB Programs shall mean programs protected by IBM's Patents or
IMB's Copyrights, other than or in addition to Remarketer's Patents and Remarkets, which are
marketed by IMB or its Subsidiaries.” xxx xxx xxx “3. Our Relationship Responsibilities Each of us
agrees that:
1. you are an independent contractor, and this Agreement is non-exclusive. Neither of
us is a legal representative or legal agent of the other. Neither of us is legally a partner
of the other (for example, neither of us is responsible for debts incurred by the other),
and neither of us is an employee or franchise of the other nor does this Agreement
create joint venture between us xxx xxx xxx
5. We may withdraw a Program from marketing at any time” “Other Responsibilities
You agree:
xxx xxx xxx
2. that your rights under this Agreement are not property rights and therefore, you
can not transfer them to anyone else or encumber them in any way. For example, you
can not sell your approval to market our Programs or your rights to use Trademarks;Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

3. Not to assign or otherwise transfer this Agreement, your rights under it, or any of
its approvals or delegate any duties, other than to a Related Company, unless
expressly permitted to do so under this Agreement.” “7. Patents, Copyrights and
Intellectual Property Rights.
You agree that you do not and shall not own any right, title or interest in and to any and all patents,
copyrights and intellectual property rights.
You shall not alter, deface, remove, cover, mutilate, or add to, in any manner whatsoever, any patent
notice, copyright notice, trademark, service mark, trade name, serial number, model number, brand
name or legend that we may attach or affix to the Programs.
If a third party claims that Program we provide under this Agreement infringes that part's patents or
copyrights, we will defend you against that claim at our expense and pay all costs, damages, and
attorney's fees that a court finally awards, provided that you:
1. promptly notify us in writing of the claim; and
2. allow us to control, and cooperate with us in the defense and any related
settlement negotiations;” “You may market to your Customers the Programs we sell
to you. We will notify you from time to time of the types of Programs that are
available for purchase by you under this Agreement. These terms apply to all
methods of distribution including to End Users and through distributors, resellers,
solution providers, and systems integrators.” (emphasis supplied)
44. ii) b. The EULA dated 01.07.2019, involved in C.A. No. 4419/2012, granting
resident Indian end-users the licence to use the software remarketed or distributed in
India through IBM India, contains the following terms:
“1. Definitions and Interpretation 1.1 In this Agreement, unless the context requires
otherwise, the following words and expressions shall have the following meanings:
″Authorized Use″ – the specified level at which Licensee is authorized to execute or
run the Program. That level may be measured by number of users, millions of service
units (″MSUs″), Processor Value Units (″PVUs″), or other level of use specified by
IBM.
″IBM″ – International Business Machines Corporation or one of its subsidiaries.
″License Information″ (″LI″) – a document that provides information and any
additional terms specific to a Program.
″Program″ – the following, including the original and all whole or partial copies:Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

1) machine-readable instructions and data,
2) components, files and modules
3) audio-visual content (such as images, text, recordings, or pictures),
4) related licensed materials (such as keys and documentation).” “2. License Grant
The Program is owned by IBM or an IBM supplier, and is copyrighted and licensed,
not sold. Licensee receives a license to the Programs from Assimil8 Limited through
a sublicensing agreement between IBM and Assimil8 Limited. Assimil8 Limited
grants Licensee a nonexclusive license to
1) use the Program up to the Authorized Use specified in the PoE
2) make and install copies to support such Authorized Use, and
3) make a backup copy, all provided that a. Licensee has lawfully obtained the
Program and complies with the terms of the Agreement;
b. The backup copy does not execute unless the backed-up Program cannot execute c. Licensee
reproduces all copyright notices and other legends of ownership on each copy, or partial copy of the
Program d. … e. Licensee does not:
1) use, copy, modify, or distribute the Program except as expressly permitted in this
agreement;
2) reverse assemble, reverse compile, otherwise translate, or reverse engineer the
program, except as expressly permitted by law without the possibility of contractual
waiver;
3) use any of the Program’s components, files, modules, audio-visual content, or
related licensed materials separately from that program; or
4) sublicense, rent, or lease the Program;” (emphasis supplied)
44. iii) Category 3:
The standard-form EULA accompanying Microsoft software products sold to resident
Indian end-users by Microsoft Corporation, a non-
resident, foreign vendor includes the following terms:
“1. GRANT OF LICENSE: This EULA grants you the following rights:Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

a. Systems Software -
You may install and use one copy of the SOFTWARE PRODUCT on a single
computer, including a workstation, terminal, or other digital electronic device
(“COMPUTER”). You may permit a maximum of five (5) COMPUTERS to connect to
the single COMPUTER running the SOFTWARE PRODUCT solely to access the
Internet using the Internet Connection Sharing feature of the SOFTWARE
PRODUCT. You may not allow these connected COMPUTERS to use any other
components of the SOFTWARE PRODUCT, nor to invoke application sharing as
described below. The five (5) connection maximum includes any indirect connections
made through software or hardware that pools or aggregates connections.
b. Storage/Network Use -
You may also store or install a copy of the SOFTWARE PRODUCT on a storage device, such as a
network server, used on to install or run the SOFTWARE PRODUCT on your other COMPUTERS
over an internal network: however, you must acquire and run a licence for each separate
COMPUTER on or from which the SOFTWARE PRODUCT is installed, used, accessed, displayed, or
forgoing any number of COMPUTERS may access or otherwise utilize the file and print services and
peer web services of the SOFTWARE PRODUCT. In addition, you may use the “Multiple Display”
feature of the SOFTWARE PRODUCT to expand your desktop as described in the online Help file
without obtaining a license for each display.” “2. DESCRIPTION OF OTHER RIGHTS AND
LIMITATIONS xxx xxx xxx Limitations on Reverse Engineering, Decompilation, and Disassembly -
You may not reverse engineer, decompile, or disassemble the SOFTWARE PRODUCT, except and
only to the extent that such activity is expressly permitted by applicable law nothwithstanding this
limitation.” “4. COPYRIGHT- All title and intellectual property rights in and to the SOFTWARE
PRODUCT (including but not limited to any images, photographs, animations, video, audio, music,
text, and “applets” incorporated into the SOFTWARE PRODUCT), the accompanying printed
materials, and any copies of the SOFTWARE PRODUCT are owned by Microsoft or its suppliers. All
title and intellectual property rights in and to the content that is not contained in the Software
Product, but may be accessed through use of the Software Product, is the property of the respective
content owners and may be protected by applicable copyright or other intellectual property laws and
treaties. This EULA grants you no rights to use such content. All rights not expressly granted are
reserved by Microsoft.” “6. BACKUP COPY- After installation of one copy of the SOFTWARE
PRODUCT pursuant to this EULA, you may keep the original media on which the SOFTWARE
PRODUCT was provided by Microsoft solely for backup or archival purposes. If the original media is
required to use the SOFTWARE PRODUCT on the COMPUTER, you may make one copy of the
SOFTWARE PRODUCT solely for backup or archival purposes. Except as expressly provided in this
EULA, you may not otherwise make copies of the SOFTWARE PRODUCT or the printed materials
accompanying the SOFTWARE PRODUCT” (emphasis supplied)
44. iv) Category 4 The Supply Contract (undated) between a resident Indian company, JT Mobiles
Ltd., and a Swedish supplier, Ericsson Radio Systems A.B. concerning the supply of a Mobile
Telephone System in C.A. Nos. 6386- 6387/2016, states the following in respect of the softwareEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

licence granted:
“20.LICENSE 20.1 Subject to the terms of conditions set forth in this Article 20,
Licence, JT MOBILES is hereby granted a non-
exclusive restricted licence to use the Software and Documentation, but only for JT MOBILES' own
operation and maintenance of the System in accordance with this contract, and not otherwise.
20.2 Notwithstanding anything this Contract to the contrary, it is understood that JT MOBILES
receives no title or ownership rights to the Software or Documentation, and all such rights shall
remain with Contractor or its suppliers.
20.3 JT MOBILES agrees that the Software or Documentation provided to it by Contractor under
this Contract or any renewals, extension, or expansions thereof, shall, as between the parties hereto,
be treated as proprietary and a trade secret of Contractor or its suppliers, and be subject to the
provisions of Article 30, Confidentiality.
20.4 In pursuance of the foregoing JT MOBILES shall:
a) not provide or make the Software or Documentation or any portions or aspects
thereof (including any methods or concepts utilized or expressed therein) available to
any person except to its employees on a "need to know" basis;
b) not make any copies of Software or Documentation or parts thereof, except for
archival backup purposes;
c) when making permitted copies as aforesaid transfer to the copy/copies any
copyright or other marking on the Software or Documentation.
d) not use the Software or Documentation for any other purpose than permitted in
this Article 20, License or sell or in any manner alienate or part with its possession.
e) not use or transfer the Software and/or the Documentation outside India without
the written consent of the Contractor and after having received necessary export or
re-export permits from relevant authorities.
20.5 JT MOBILES and any successor to JT MOBILES title to the Hardware or part of Hardware
shall have the right without further consent of Contractor to transfer this license to a third party
which acquires the System, provided any such third party agrees in writing to abide by all the terms
and conditions of this license.
20.6. The obligations of JT MOBILES under this Article 20, Licence, shall survive the termination or
expiration of this Contract for any reason.Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

20.7 The Software licensed under this Contract is delivered in an inseparable package also
containing other software functionality than the Software. In order to avoid doubt JT MOBILES
may not in any use that other part of the software functionality. However, upon JT MOBILES'
request Contractor shall offer a licence to use such other software functionality to JT MOBILES on
the same terms and conditions as stipulated in this Contract but not price.” (emphasis supplied)
45. A reading of the aforesaid distribution agreement would show that what is granted to the
distributor is only a non-exclusive, non-transferable licence to resell computer software, it being
expressly stipulated that no copyright in the computer programme is transferred either to the
distributor or to the ultimate end-user. This is further amplified by stating that apart from a right to
use the computer programme by the end-user himself, there is no further right to sub-license or
transfer, nor is there any right to reverse-engineer, modify, reproduce in any manner otherwise than
permitted by the licence to the end-user. What is paid by way of consideration, therefore, by the
distributor in India to the foreign, non-resident manufacturer or supplier, is the price of the
computer programme as goods, either in a medium which stores the software or in a medium by
which software is embedded in hardware, which may be then further resold by the distributor to the
end-user in India, the distributor making a profit on such resale. Importantly, the distributor does
not get the right to use the product at all.
46. When it comes to an end-user who is directly sold the computer programme, such end-user can
only use it by installing it in the computer hardware owned by the end-user and cannot in any
manner reproduce the same for sale or transfer, contrary to the terms imposed by the EULA.
47. In all these cases, the “licence” that is granted vide the EULA, is not a licence in terms of section
30 of the Copyright Act, which transfers an interest in all or any of the rights contained in sections
14(a) and 14(b) of the Copyright Act, but is a “licence” which imposes restrictions or conditions for
the use of computer software. Thus, it cannot be said that any of the EULAs that we are concerned
with are referable to section 30 of the Copyright Act, inasmuch as section 30 of the Copyright Act
speaks of granting an interest in any of the rights mentioned in sections 14(a) and 14(b) of the
Copyright Act. The EULAs in all the appeals before us do not grant any such right or interest, least of
all, a right or interest to reproduce the computer software. In point of fact, such reproduction is
expressly interdicted, and it is also expressly stated that no vestige of copyright is at all transferred,
either to the distributor or to the end-user. A simple illustration to explain the aforesaid position will
suffice. If an English publisher sells 2000 copies of a particular book to an Indian distributor, who
then resells the same at a profit, no copyright in the aforesaid book is transferred to the Indian
distributor, either by way of licence or otherwise, inasmuch as the Indian distributor only makes a
profit on the sale of each book. Importantly, there is no right in the Indian distributor to reproduce
the aforesaid book and then sell copies of the same. On the other hand, if an English publisher were
to sell the same book to an Indian publisher, this time with the right to reproduce and make copies
of the aforesaid book with the permission of the author, it can be said that copyright in the book has
been transferred by way of licence or otherwise, and what the Indian publisher will pay for, is the
right to reproduce the book, which can then be characterised as royalty for the exclusive right to
reproduce the book in the territory mentioned by the licence.Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

48. An instructive judgment of this Court in this respect is to be found in State Bank of India v.
Collector of Customs, (2000) 1 SCC 727. In this case, the State Bank of India imported a
consignment of computer software and manuals from Kindle Software Ltd., Dublin, Ireland, and
cleared the goods for home consumption, and filed an application before the Additional Collector of
Customs, claiming a refund of customs duty. After setting out section 14 of the Customs Act 1962
and rule 9(1)(c) of the Customs Valuation (Determination of Price of Imported Goods) Rules, 1988,
the Court stated:
“9. Now, if we refer to the interpretative note relating to Rule 9(1)(c) it says that
royalties and licence fees may include, among other things, payments in respect to
patents, trademarks and copyrights. There is, however, an exception which says that
the charges for the right to reproduce the imported goods in the country of
importation shall not be added to the price actually paid or payable for the imported
goods in determining the customs value. Further payments made by the buyer for the
right to distribute or resell the imported goods shall not be added to the price actually
paid or payable for the imported goods if such payments are not a condition of the
sale for the exports to the country of importation of the imported goods.
xxx xxx xxx
11. What we have now to see is if under the agreement SBI has the right to reproduce
the imported software and for that purpose SBI has paid “royalties and licence fee”
which have been added to the price actually paid for the imported software for use at
the principal place called the Support Centre. If that is so under the press note no
customs duty is leviable on the royalty so paid. This takes us to the relevant terms of
the agreement which would indicate as to whether or not the royalty/licence fees
needed to be included in the value of the imported goods."
49. The contention of the State Bank of India that the countrywide licence fee paid by it by way of
royalty was for the reproduction of the said software and was thus exempt from customs duty, was
turned down by this Court as follows:
“17. The question that arises for consideration is if licence fee charged towards
countrywide use of software in the second invoice could be the charges for the right to
reproduction and were these added to the price actually paid or payable for the
imported goods. If we refer to the agreement, software is not sold to SBI as such but
it was to remain the property of Kindle. There is no other value of the software
indicated in the agreement except the licence fee. Price is payable only for allowing
SBI to use the software in a limited way at its own centres for a limited period and
that is why the amount charged is called the licence fee. After five years SBI is
required to pay only recurring licence fee. Countrywide use of the software and
reproduction of software are two different things and licence fee for countrywide use
cannot be considered as the charges for the right to reproduce the imported goods.
Under the agreement copying, storage, removal, etc. are under the strict control ofEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

Kindle and all copies are the property of Kindle. SBI can use the software for its
internal requirements only. Licence has been given to SBI to use the property of
Kindle at its branches and not for reproduction of the software as claimed by SBI.
The words in the agreement are specific that “SBI shall pay the licensor the initial
licence fee and the recurring licence fees for use under the provisions of this
agreement”.”
50. The Court then made an important observation, stating:
“21. Reproduction and use are two different things. Now under the agreement user is
specifically limited to licence sites. The transaction as a whole is to be seen. The press
note is of no help to SBI. Rule 9(1)(c) and the interpretative note thereto did not
apply as nothing was added to the price actually paid for the imported goods by way
of royalties etc. Refund would be allowable only if there was something added on to
the royalty payment which was not in the present case. The invoice originally
presented was complete in itself. The second invoice was not filed along with the bill
of entry. In the second invoice also it is the licence fee for the right to use countrywide
and it is not the right to reproduce as claimed by SBI. Schedule I to the agreement is
module and copies are modalities for the use of software by SBI with various
restrictions. If we again refer to clause 6.4 of the agreement there is a complete
restraint on SBI which says SBI shall not use, print, copy, reproduce or disclose the
software or documentation in whole or in part except as is expressly permitted by the
agreement nor shall SBI permit any of the foregoing. SBI is also barred from allowing
access to its software or documentation except what is permitted under the
agreement. Again SBI is barred from selling, charging or otherwise making the
software or documentation available to any person except what is expressly permitted
under the agreement. Clause 6.5 of the agreement says that SBI shall not copy or
permit copying of the software supplied to it by Kindle save as may be strictly
required for delivery to licence sites. The terms of the agreement also apply to the
copies.” (emphasis supplied) Though this judgment has been delivered under the
Customs Act 1962, yet the important differentiation made between the right to
reproduce and the right to use computer software has been recognized by this
judgment. Whereas the former would amount to a parting of copyright by the owner
thereof, the latter would not.
51. An argument was advanced by the learned Additional Solicitor General that in some of the
aforestated EULAs, it was clearly stated that what was licensed to the distributor/end-user by the
non-resident, foreign supplier would not amount to a sale, thereby making it clear that what was
transferred was not goods. This argument has no legs to stand on. It is settled law that in all such
cases, the real nature of the transaction must be looked at upon reading the agreement as a whole.
Thus, in Sundaram Finance Ltd. v. State of Kerala, (1966) 2 SCR 828, one of the questions that was
raised before this Court was as to the execution of a “sale letter” acknowledging the sale of a vehicle.
This “sale letter” was dealt with by the Court as follows:Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

“The appellants are financiers and their business is to advance loans on favourable
terms on the security of vehicles. This is effected by obtaining a promissory-note for
repayment of the amount advanced, and a hire-purchase agreement which provides a
mechanism for recovery of the amount. It is true that a “sale letter” is obtained from
the customer, but the consideration for the sale letter is only the balance remaining
payable to the dealer, after giving credit against the price of the vehicle the amount
paid by the customer. The application for a loan, and the letter addressed to the
appellants undertaking to insure the vehicle expressly mention that a loan is asked
for and granted on the security of the motor-vehicle under the hire- purchase
agreement. It is the customer who insures the vehicle, and in the books of the Motor
Vehicle Authorities he remains, with the consent of the appellants, owner of the
vehicle. Undue importance to the acknowledgment of sale in the “sale letter” and the
recital of sale in the bill and in the receipt cannot therefore be attached. These
documents — “sale letter”, bill and receipt — must be read with the application for
granting a loan on the security of the vehicles, the letter in which the customer
requests the appellants to pay the balance of the price remaining to be paid by him to
the dealer, the promissory-note executed by him for that amount, the undertaking to
insure the vehicle, and intimation to the Motor Vehicles Authorities to make note of
the hire- purchase agreement.” (page 839) “The true effect of a transaction may be
determined from the terms of the agreement considered in the light of the
surrounding circumstances. In each case, the Court has, unless prohibited by statute,
power to go behind the documents and to determine the nature of the transaction,
whatever may be the form of the documents. An owner of goods who purports
absolutely to convey or acknowledges to have conveyed goods and subsequently
purports to hire them under a hire-purchase agreement is not estopped from proving
that the real bargain was a loan on the security of the goods. If there is a bona fide
and completed sale of goods, evidenced by documents, anterior to and independent
of a subsequent and distinct hiring to the vendor, the transaction may not be
regarded as a loan transaction, even though the reason for which it was entered into
was to raise money. If the real transaction is a loan of money secured by a right of
seizure of the goods, the property ostensibly passes under the documents embodying
the transaction, but subject to the terms of the hiring agreement, which become part
of the buyer's title, and confer a licence to seize. When a person desiring to purchase
goods and not having sufficient money on hand borrows the amount needed from a
third person and pays it over to the vendor, the transaction between the customer
and the lender will unquestionably be a loan transaction. The real character of the
transaction would not be altered if the lender himself is the owner of the goods and
the owner accepts the promise of the purchaser to pay the price or the balance
remaining due against delivery of goods. But a hire- purchase agreement is a more
complex transaction. The owner under the hire-purchase agreement enters into a
transaction of hiring out goods on the terms and conditions set out in the agreement,
and the option to purchase exercisable by the customer on payment of all the
instalments of hire arises when the instalments are paid and not before. In such a
hire-purchase agreement there is no agreement to buy goods; the hirer being underEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

no legal obligation to buy, has an option either to return the goods or to become its
owner by payment in full of the stipulated hire and the price for exercising the option.
This class of hire- purchase agreements must be distinguished from transactions in
which the customer is the owner of the goods and with a view to finance his purchase
he enters into an arrangement which is in the form of a hire-purchase agreement
with the financier, but in substance evidences a loan transaction, subject to a hiring
agreement under which the lender is given the license to seize the goods.” (pages
841-842) (emphasis supplied) “In the light of these principles the true nature of the
transactions of the appellants may now be stated. The appellants are carrying on the
business of financiers: they are not dealing in motor-vehicles. The motor-vehicle
purchased by the customer is registered in the name of the customer and remains at
all material times so registered in his name. In the letter taken from the customer
under which the latter agrees to keep the vehicle insured, it is expressly recited that
the vehicle has been given as security for the loan advanced by the appellants. As a
security for repayment of the loan, the customer executes a promissory- note for the
amount paid by the appellants to the dealer of the vehicle. The so-called “sale letter”
is a formal document which is not made effective by registering the vehicle in the
name of the appellants and even the insurance of the vehicle has to be effected as if
the customer is the owner. Their right to seize the vehicle is merely a licence to
ensure compliance with the terms of the hire-purchase agreement. The customer
remains qua the world at large the owner and remains in possession, and on
condition of performing the covenants, has a right to continue to remain in
possession. The right of the appellants may be extinguished by payment of the
amount due to them under the terms of the hire- purchase agreement even before the
dates fixed for payment. The agreement undoubtedly contains several onerous
covenants, but they are all intended to secure to the appellants recovery of the
amount advanced. We are accordingly of the view that the intention of the appellants
in obtaining the hire-purchase and the allied agreements was to secure the return of
loans advanced to their customers, and no real sale of the vehicle was intended by the
customer to the appellants. The transactions were merely financing transactions.”
(page 844)
52. There can be no doubt as to the real nature of the transactions in the appeals before us. What is
“licensed” by the foreign, non-resident supplier to the distributor and resold to the resident
end-user, or directly supplied to the resident end-user, is in fact the sale of a physical object which
contains an embedded computer programme, and is therefore, a sale of goods, which, as has been
correctly pointed out by the learned counsel for the assessees, is the law declared by this Court in the
context of a sales tax statute in Tata Consultancy Services v. State of A.P., 2005 (1) SCC 308 (see
paragraph 27).
APPLICABILITY OF THE DOUBLE TAXATION AVOIDANCE AGREEMENT’S PROVISIONS
53. The learned Additional Solicitor General sought to reopen a contention made by the Revenue in
the earlier round of litigation in GE Technology (supra) which led to this Court framing the questionEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

of law and sending it back to the High Court to decide “on merits”. He sought to argue, based in
particular on Article 30 of the India-USA DTAA, that the DTAA’s provisions in these cases would not
apply at all, inasmuch as provisions relatable to deduction of TDS under section 195 of the Income
Tax Act do not refer to tax at all, but are deductions that are to be made before assessments to tax
are made. He argued that these deductions do not partake the character of tax at all, section 195 of
the Income Tax Act speaking of “any person responsible to pay”, as opposed to an “assessee”. He
therefore differentiated between the language used in section 9 and section 195 of the Income Tax
Act and argued that the deductions made under section 195, not being in the nature of tax at all and
at a stage prior to the person responsible for paying defaulting, and being declared an assessee in
default (under section 201 of the Income Tax Act), the DTAA provisions would not apply at all.
54. There is no doubt that section 9 of the Income Tax Act refers to persons who are non-residents
and taxes their income as income which is deemed to accrue or arise in India, thus, making such
persons assessees under the Income Tax Act, who are liable to pay tax. There is also no doubt that
the “person responsible for paying” spoken of in section 195 of the Income Tax Act is not a
non-resident assessee, but a person resident in India, who is liable to make deductions under
section 195 of the Income Tax Act when payments are made by it to the non-resident assessee. The
submission of the learned Additional Solicitor General is answered by the judgment of this Court in
GE Technology (supra). This judgment, after setting out section 195 of the Income Tax Act, held:
“8. The most important expression in Section 195(1) consists of the words chargeable
under the provisions of the Act. A person paying interest or any other sum to a non-
resident is not liable to deduct tax if such sum is not chargeable to tax under the IT
Act. For instance, where there is no obligation on the part of the payer and no right to
receive the sum by the recipient and that the payment does not arise out of any
contract or obligation between the payer and the recipient but is made voluntarily,
such payments cannot be regarded as income under the IT Act.
9. It may be noted that Section 195 contemplates not merely amounts, the whole of
which are pure income payments, it also covers composite payments which have an
element of income embedded or incorporated in them. Thus, where an amount is
payable to a non-resident, the payer is under an obligation to deduct TAS in respect
of such composite payments. The obligation to deduct TAS is, however, limited to the
appropriate proportion of income chargeable under the Act forming part of the gross
sum of money payable to the non-resident. This obligation being limited to the
appropriate proportion of income flows from the words used in Section 195(1),
namely, “chargeable under the provisions of the Act”. It is for this reason that vide
Circular No. 728 dated 30-10-1995 CBDT has clarified that the tax deductor can take
into consideration the effect of DTAA in respect of payment of royalties and technical
fees while deducting TAS. It may also be noted that Section 195(1) is in identical
terms with Section 18(3-B) of the 1922 Act.
xxx xxx xxxEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

11. While deciding the scope of Section 195(2) it is important to note that the tax which is required to
be deducted at source is deductible only out of the chargeable sum. This is the underlying principle
of Section 195. Hence, apart from Section 9(1), Sections 4, 5, 9, 90, 91 as well as the provisions of
DTAA are also relevant, while applying tax deduction at source provisions.
xxx xxx xxx
13. If the contention of the Department that the moment there is remittance the obligation to deduct
TAS arises is to be accepted then we are obliterating the words “chargeable under the provisions of
the Act” in Section 195(1). The said expression in Section 195(1) shows that the remittance has got to
be of a trading receipt, the whole or part of which is liable to tax in India. The payer is bound to
deduct TAS only if the tax is assessable in India. If tax is not so assessable, there is no question of
TAS being deducted. (See Vijay Ship Breaking Corpn. v. CIT [(2010) 10 SCC 39 : (2009) 314 ITR
309] .)
14. One more aspect needs to be highlighted. Section 195 falls in Chapter XVII which deals with
collection and recovery. Chapter XVII-B deals with deduction at source by the payer. On analysis of
various provisions of Chapter XVII one finds the use of different expressions, however, the
expression “sum chargeable under the provisions of the Act” is used only in Section 195. For
example, Section 194-C casts an obligation to deduct TAS in respect of “any sum paid to any
resident”. Similarly, Sections 194-EE and 194-F inter alia provide for deduction of tax in respect of
“any amount” referred to in the specified provisions. In none of the provisions we find the
expression “sum chargeable under the provisions of the Act”, which as stated above, is an expression
used only in Section 195(1). Therefore, this Court is required to give meaning and effect to the said
expression. It follows, therefore, that the obligation to deduct TAS arises only when there is a sum
chargeable under the Act.
xxx xxx xxx
18. If the contention of the Department that any person making payment to a non-resident is
necessarily required to deduct TAS then the consequence would be that the Department would be
entitled to appropriate the monies deposited by the payer even if the sum paid is not chargeable to
tax because there is no provision in the IT Act by which a payer can obtain refund. Section 237 read
with Section 199 implies that only the recipient of the sum i.e. the payee could seek a refund. It must
therefore follow, if the Department is right, that the law requires tax to be deducted on all payments.
The payer, therefore, has to deduct and pay tax, even if the so-called deduction comes out of his own
pocket and he has no remedy whatsoever, even where the sum paid by him is not a sum chargeable
under the Act. The interpretation of the Department, therefore, not only requires the words
“chargeable under the provisions of the Act” to be omitted, it also leads to an absurd consequence.
The interpretation placed by the Department would result in a situation where even when the
income has no territorial nexus with India or is not chargeable in India, the Government would
nonetheless collect tax. In our view, Section 195(2) provides a remedy by which a person may seek a
determination of the “appropriate proportion of such sum so chargeable” where a proportion of the
sum so chargeable is liable to tax.Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

xxx xxx xxx
20. We find no merit in these contentions. As stated hereinabove, Section 195(1) uses the expression
“sum chargeable under the provisions of the Act”. We need to give weightage to those words.
Further, Section 195 uses the word “payer” and not the word “assessee”. The payer is not an
assessee. The payer becomes an assessee-in-default only when he fails to fulfil the statutory
obligation under Section 195(1). If the payment does not contain the element of income the payer
cannot be made liable. He cannot be declared to be an assessee-in-default.
21. The abovementioned contention of the Department is based on an apprehension which is
ill-founded. The payer is also an assessee under the ordinary provisions of the IT Act. When the
payer remits an amount to a non-resident out of India he claims deduction or allowances under the
Income Tax Act for the said sum as an “expenditure”. Under Section 40(a)(i), inserted vide the
Finance Act, 1988 w.e.f. 1-4-1989, payment in respect of royalty, fees for technical services or other
sums chargeable under the Income Tax Act would not get the benefit of deduction if the assessee
fails to deduct TAS in respect of payments outside India which are chargeable under the IT Act. This
provision ensures effective compliance with Section 195 of the IT Act relating to tax deduction at
source in respect of payments outside India in respect of royalties, fees or other sums chargeable
under the IT Act. In a given case where the payer is an assessee he will definitely claim deduction
under the IT Act for such remittance and on inquiry if the AO finds that the sums remitted outside
India come within the definition of royalty or fees for technical service or other sums chargeable
under the IT Act then it would be open to the AO to disallow such claim for deduction. Similarly,
vide the Finance Act, 2008 w.e.f. 1-4-2008 sub-section (6) has been inserted in Section 195 which
requires the payer to furnish information relating to payment of any sum in such form and manner
as may be prescribed by the Board. This provision is brought into force only from 1-4-2008. It will
not apply for the period with which we are concerned in these cases before us. Therefore, in our
view, there are adequate safeguards in the Act which would prevent revenue leakage.
xxx xxx xxx
24. In our view, Section 195(2) is based on the “principle of proportionality”. The said sub-section
gets attracted only in cases where the payment made is a composite payment in which a certain
proportion of payment has an element of “income” chargeable to tax in India. It is in this context
that the Supreme Court stated: (Transmission Corpn. case [(1999) 7 SCC 266 : (1999) 239 ITR 587] ,
SCC p. 274, para
10) “10. … If no such application is filed income tax on such sum is to be deducted and it is the
statutory obligation of the person responsible for paying such ‘sum’ to deduct tax thereon before
making payment. He has to discharge the obligation [to TDS].” (emphasis supplied) If one reads the
observation of the Supreme Court, the words “such sum” clearly indicate that the observation refers
to a case of composite payment where the payer has a doubt regarding the inclusion of an amount in
such payment which is exigible to tax in India. In our view, the above observations of this Court in
Transmission Corpn. case [(1999) 7 SCC 266 : (1999) 239 ITR 587] which is put in italics has been
completely, with respect, misunderstood by the Karnataka High Court to mean that it is not open forEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

the payer to contend that if the amount paid by him to the non-resident is not at all “chargeable to
tax in India”, then no TAS is required to be deducted from such payment. This interpretation of the
High Court completely loses sight of the plain words of Section 195(1) which in clear terms lays
down that tax at source is deductible only from “sums chargeable” under the provisions of the IT Act
i.e. chargeable under Sections 4, 5 and 9 of the IT Act.
25. Before concluding we may clarify that in the present case on facts ITO(TDS) had taken the view
that since the sale of the software concerned, included a licence to use the same, the payment made
by the appellant(s) to foreign suppliers constituted “royalty” which was deemed to accrue or arise in
India and, therefore, TAS was liable to be deducted under Section 195(1) of the Act. The said finding
of ITO(TDS) was upheld by CIT(A). However, in the second appeal, ITAT held that such sum paid by
the appellant(s) to the foreign software suppliers was not a “royalty” and that the same did not give
rise to any “income” taxable in India and, therefore, the appellant(s) was not liable to deduct TAS.
However, the High Court did not go into the merits of the case and it went straight to conclude that
the moment there is remittance an obligation to deduct TAS arises, which view stands hereby
overruled.”
55. What is made clear by the judgment in GE Technology (supra) is the fact that the “person”
spoken of in section 195(1) of the Income Tax Act is liable to make the necessary deductions only if
the non-resident is liable to pay tax as an assessee under the Income Tax Act, and not otherwise.
This judgment also clarifies, after referring to CBDT Circular No. 728 dated 30.10.1995, that the tax
deductor must take into consideration the effect of the DTAA provisions. The crucial link, therefore,
is that a deduction is to be made only if tax is payable by the non-resident assessee, which is
underscored by this judgment, stating that the charging and machinery provisions contained in
sections 9 and 195 of the Income Tax Act are interlinked.
56. This conclusion is also echoed in Vodafone International Holdings BV v. Union of India, (2012)
6 SCC 613, wherein the following observations were made on the scope and applicability of section
195 of the Income Tax Act:
“171. Section 195 casts an obligation on the payer to deduct tax at source (“TAS”, for
short) from payments made to non- residents which payments are chargeable to tax.
Such payment(s) must have an element of income embedded in it which is chargeable
to tax in India. If the sum paid or credited by the payer is not chargeable to tax then
no obligation to deduct the tax would arise. Shareholding in companies incorporated
outside India (CGP) is property located outside India. Where such shares become
subject-matter of offshore transfer between two non-residents, there is no liability for
capital gains tax. In such a case, question of deduction of TAS would not arise.
172. If in law the responsibility for payment is on a non-
resident, the fact that the payment was made, under the instructions of the non-resident, to its
agent/nominee in India or its PE/Branch Office will not absolve the payer of his liability under
Section 195 to deduct TAS. Section 195(1) casts a duty upon the payer of any income specifiedEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

therein to a non-resident to deduct therefrom TAS unless such payer is himself liable to pay income
tax thereon as an agent of the payee. Section 201 says that if such person fails to so deduct TAS he
shall be deemed to be an assessee-in- default in respect of the deductible amount of tax (Section
201).
173. Liability to deduct tax is different from “assessment” under the Act. Thus, the person on whom
the obligation to deduct TAS is cast is not the person who has earned the income. Assessment has to
be done after liability to deduct TAS has arisen. The object of Section 195 is to ensure that tax due
from non-resident persons is secured at the earliest point of time so that there is no difficulty in
collection of tax subsequently at the time of regular assessment.” (emphasis supplied)
57. The absurd consequence that the resident in India, after making the deduction/payment, would
not then get any excess payment made by way of refund when regular assessment takes place, as the
non- resident assessee alone would be entitled to such refund, is also pointed out in paragraph 18 of
the judgment in GE Technology (supra). It was after keeping all this in view that this Court then set
aside the judgment of the High Court of Karnataka dated 24.09.2009 and remanded the case to the
High Court for a decision of the question “on merits”, i.e., on the sole question as to whether the
ITAT was justified in holding that the amounts paid by the appellants to the foreign software
suppliers did not amount to royalty, as a result of which, no liability to deduct TDS arose.
58. Even otherwise, a look at Article 12(2) of the India-Singapore DTAA would demonstrate the
fallacy of the aforesaid submission of the learned Additional Solicitor General. Under Article 12(2) of
the India- Singapore DTAA, royalties may be taxed in the Contracting State in which they arise
(India) and according to the laws of that Contracting State (Indian laws), if the recipient is a
beneficial owner of the royalties, and the tax so charged is capped at the rate of 10% or 15%. If the
learned Additional Solicitor General is correct in his submission, as the DTAA would then not apply,
royalty would be liable to be taxed in India at the rate mentioned in the Income Tax Act which can
be much higher than the DTAA rate, as a result of which, the deduction made under section 195 of
the Income Tax Act by the “person responsible” would have to be a proportion of a much higher sum
than the tax that is ultimately payable by the non-resident assessee. This equally absurd result
cannot be countenanced given the fact that the person liable to deduct tax is only liable to deduct tax
first and foremost if the non- resident person is liable to pay tax, and second, that if so liable, is then
liable to deduct tax depending on the rate mentioned in the DTAA.
59. Further, tearing an article of a specific DTAA, namely Article 30 of the India-USA DTAA, out of
context in order to buttress his submission, in a manner far removed from the actual rationale
behind that provision, does not commend itself to us.
59. i) Article 30 of the India-USA DTAA, relied upon by the learned Additional Solicitor General,
reads:
“1. Each Contracting State shall notify the other Contracting State in writing, through
diplomatic channels, upon the completion of their respective legal procedures toEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

bring this Convention into force.
2. The Convention shall enter into force on the date of the latter of such notifications
and its provisions shall have effect:
(a) in the United States
(i) in respect of taxes withheld at source, for amounts paid or credited on or after the
first day of January next following the date on which the Convention enters into
force;
(ii) in respect of other taxes, for taxable periods beginning on or after the first day of
January next following the date on which the Convention enters into force; and
(b) in India, in respect of income arising in any taxable year beginning on or after the
first day of April next following the calendar year in which the Convention enters into
force.”
59. ii) By way of contrast, under the Convention between the Republic of India and
the Kingdom of Netherlands for the Avoidance of Double Taxation and the
Prevention of Fiscal Evasion with respect to Taxes on Income and on Capital,32
[“India-Netherlands DTAA”], Article 29 reads:
“1. Each of the States shall notify to the other the completion of the procedures
required by its law for the bringing into force of this Convention. This Convention
shall enter into force on the thirtieth day after the latter of the dates on which the
respective Governments have notified each other in writing that the formalities
constitutionally required in their respective States have been complied with, and its
provisions shall have effect:
(a) in the Netherlands for taxable years and periods beginning on or after the first day
of January next following the calendar year in which the latter of the notifications is
given ;
(b) in India in respect of income arising in any fiscal year beginning on or after the
first day of April next following the calendar year in which the latter of the
notifications is given.
2. Notwithstanding the provisions of paragraph 1, the provisions of Article 8 shall have effect:
Notification No. GSR 382(E), dated 27-3-1989, as amended by Notification No. S.O.
693(E), dated 30-8-1999.Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

(a) in the Netherlands for taxable years and periods beginning on or after the first day
of January, 1987 ;
(b) in India in respect of income arising in any fiscal year beginning on or after the
first day of April, 1987.”
59. iii) Under the Convention between the Government of Japan and the Government
of the Republic of India for the Avoidance of Double Taxation and the Prevention of
Fiscal Evasion with respect to Taxes on Income,33 [“India-Japan DTAA”] Article 28
is set out in the following terms:
“1. This Convention shall be ratified and the instruments of ratification shall be
exchanged at Tokyo as soon as possible.
2. This Convention shall enter into force on the thirtieth day after the date of the
exchange of instruments of ratification and shall have effect :
(a) In Japan : as regards income for any taxable year beginning on or after the first
day of January of the calendar year next following that in which this Convention
enters into force ; and
(b) in India : as regards income for any 'previous year' beginning on or after the first
day of April of the calendar year next following that in which this Convention enters
into force.
Notification : No. GSR 101(E), dated 1-3-1990, as amended by Notification Nos. SO 753(E), dated
16-8-2000 (w.r.e.f. 1-10-1999), SO 1136(E), dated 19-7-2006, w.r.e.f. 28- 6-2006 and SO 2528(E),
dated 8-10-2008, w.e.f. 1-10-2008.
3. The Agreement between Japan and India for the Avoidance of Double Taxation in respect of
Taxes on Income signed at New Delhi on January 5, 1960 shall terminate and cease to have effect in
respect of income to which this Convention applies under the provisions of paragraph 2.”
59. iv) Under the Convention between the Government of the Republic of India and the Government
of the United Kingdom of Great Britain and Northern Ireland for the Avoidance of Double Taxation
and the Prevention of Fiscal Evasion with respect to Taxes on Income and Capital Gains,34
[“India-UK DTAA”] Article 30 reads as follows:
(1) Each of the Contracting States shall notify to the other the completion of the
procedures required by its law for the bringing into force of this Convention. This
Convention shall enter into force on the date of the later of these notifications and
shall thereupon have effect:
(a) in the United Kingdom:Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

(i) in respect of income tax and capital gains tax, for any year of assessment
beginning on or after 6th April in the calendar year next following that in which the
later of the notifications is given;
(ii) in respect of corporation tax, for any financial year beginning on or after 1st April
in the calendar year next following that in which the later of the notifications is given;
GSR 91(E), dated 11-2-1994, as amended by Notification No. 10/2014 [F.No. 505/1986 FTD-I],
dated 10-2-2014.
(iii) in respect of petroleum revenue tax, for any chargeable period beginning on or after 1st January
in the calendar year next following that in which the later of the notifications is given;
(b) in India, in respect of income arising in any fiscal year beginning on or after the first day of April
next following the calendar year in which the later of the notifications is given.
(2) Subject to the provisions of paragraph (3) of this Article, the Convention between the
Government of the United Kingdom of Great Britain and Northern Ireland and the Government of
India for the Avoidance of Double Taxation and the Prevention of Fiscal Evasion with Respect to
Taxes on Income and Capital Gains signed in New Delhi on 16th April 1981 (hereinafter referred to
as "the 1981 Convention") shall terminate and cease to be effective from the date upon which this
Convention has effect in respect of the taxes to which this Convention applies in accordance with the
provisions of paragraph (1) of this Article.
(3) Where any provisions of the 1981 Convention would have afforded any greater relief from tax
than is due under this Convention, any such provision as aforesaid shall continue to have effect: (a)
in the United Kingdom, for any year of assessment or financial year; and (b) in India, for any fiscal
year; beginning, in either case, before the entry into force of this Convention.”
59. v) Article 28 of the Agreement between the Government of the Republic of India and the
Government of the People's Republic of China for the Elimination of Double Taxation with respect
to Taxes on Income and the Prevention of Tax Evasion and Avoidance,35 [“India-China DTAA”], is
again worded differently, as follows:
“This Agreement shall enter into force on the thirtieth day after the date on which
diplomatic notes indicating the completion of internal legal procedures necessary in
each country for the entry into force of this Agreement have been exchanged. This
Agreement shall have effect :
(a) in China, in respect of income arising in any taxable year beginning on or after the
first day of January next following the calendar year in which this Agreement enters
into force;Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

(b) in India, in respect of income arising in any previous year beginning on or after
the first day of April next following the calendar year in which this Agreement enters
into force.”
60. Obviously, the logic behind Article 30 of the India-USA DTAA is for reasons connected with
USA’s municipal taxation laws, and has nothing to do with Indian municipal law governing the
liability of persons to deduct tax at source under section 195 of the Income Tax Act. This is
reinforced by the fact that the OECD Commentary on Articles 30 and 31 acknowledges the fact that
the “entry into force” provisions, unlike Notification No. GSR 331(E), dated 5-4-1995, as amended
by Notification No. S.O. 2562(E) [No.54/2019/F.No. 503/02/2008-FTD-II], dated 17-7-2019. the
rest of the provisions in the OECD Model Tax Convention on Income and on Capital, depend on the
domestic laws of Contracting States, as follows:
“COMMENTARY ON ARTICLES 30 AND 31 CONCERNING THE ENTRY INTO FORCE AND THE
TERMINATION OF THE CONVENTION xxx xxx xxx
3. It is open to Contracting States to agree that the Convention shall enter into force when a
specified period has elapsed after the exchange of the instruments of ratification or after the
confirmation that each State has completed the procedures required for such entry into force.
4. No provisions have been drafted as to the date on which the Convention shall have effect or cease
to have effect, since such provisions would largely depend on the domestic laws of the Contracting
States concerned. Some of the States assess tax on the income received during the current year,
others on the income received during the previous year, others again have a fiscal year which differs
from the calendar year. Furthermore, some conventions provide, as regards taxes levied by
deduction at the source, a date for the application or termination which differs from the date
applying to taxes levied by assessment.” (emphasis supplied)
61. For all these reasons, we do not permit the learned Additional Solicitor General to have a second
bite at the same cherry, albeit through the ingenious argument made by him based on Article 30 of
the India-USA DTAA.
DEFINITION OF ROYALTY IN THE DTAAs VIS-À-VIS THE INCOME TAX ACT
62. In order to ascertain whether the question which was posed by this Court in GE Technology
(supra) was correctly answered by the High Court of Karnataka vide the impugned judgment dated
15.10.2011,36 the first expression that has to be considered by us is the expression “royalty”.
63. Firstly, it will be seen that when Article 12 of the India-Singapore DTAA defines the term
“royalties” in sub-article (3) thereof, it does so stating that such definition is exhaustive – it uses the
expression “means”. Secondly, the term “royalties” refers to payments of any kind that are received
as a consideration for the use of or the right to use any copyright in a literary work. As opposed to
this, the definition contained in explanation 2 to section 9(1)(vi) of the Income Tax Act, is wider in at
least three respects:Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

CIT v. Samsung Electronics Co. Ltd., (2012) 345 ITR 494.
i. It speaks of “consideration”, but also includes a lump-sum consideration which
would not amount to income of the recipient chargeable under the head “capital
gains”;
ii. When it speaks of the transfer of “all or any rights”, it expressly includes the
granting of a licence in respect thereof; and iii. It states that such transfer must be “in
respect of” any copyright of any literary work.
64. However, even where such transfer is “in respect of” copyright, the transfer of all or any rights in
relation to copyright is a sine qua non under explanation 2 to section 9(1)(vi) of the Income Tax Act.
In short, there must be transfer by way of licence or otherwise, of all or any of the rights mentioned
in section 14(b) read with section 14(a) of the Copyright Act.
65. In State of Madras v. Swastik Tobacco Factory, (1966) 3 SCR 79, this Court construed the words
“in respect of” used in rule 5(1)(i) of the Madras General Sales Tax (Turnover and Assessment) Rules
1939, as follows:
“The House of Lords in Inland Revenue Commissioners v. Coutts & Co. [(1963) 2 All
ER 722, 732], in the context of payment of estate duty, construed the words “in
respect of” in Section 5(2) of the Finance Act, 1894 (57 & 58 Vict, c. 30) and observed
that the phrase denoted some imprecise kind of nexus between the property and the
estate duty. The House of Lords in Asher v. Seaford Court Estates Ltd. [LR 1950 AC
608] in construing the provisions of Section 2, sub- section (3) of Increase of Rent
and Mortgage Interest (Restrictions) Act, 1920 (10 & 11 Geo. 5, c. 17), held that the
expression “in respect of” must be read as equivalent to “attributable”. The Privy
Council in Bicher Ltd. v. CIT [(1962) 3 All ER 294] observed that the said words
could mean more than “consisting of” or “namely”.
It is not necessary to refer to other decisions. It may be accepted that the said expression received a
wide interpretation, having regard to the object of the provisions and the setting in which the said
words appeared. On the other hand, Indian tax laws use the expression “in respect of” as
synonymous with the expression “on”: see Article 288 of the Constitution of India; Section 3 of the
Indian Income Tax Act, 1922; Sections 3(2) and 3(5), Second Proviso, of the Madras General Sales
Tax Act, 1939; Section 3(1-A) of the Central Excise and Salt Act, 1944; and Section 9 of the Kerala
Sales Tax Act. We should not be understood to have construed the said provisions, but only have
referred to them to state the legislative practice. Consistent with the said practice, Rule 5(1)(i) of the
Rules uses the same expression. When the said Rule says “excise duty paid in respect of the goods”,
the excise duty referred to is the excise duty paid under Section 3(1), read with the Schedule of the
Central Excises and Salt Act, 1944 (1 of 1944). Under the said Section, read with the Schedule, excise
duty is levied on the goods described in the Schedule. Therefore, when Rule 5(1)(i) of the Rules
refers to the duty paid in respect of the goods to the Central Government, it necessarily refers to the
duty paid on the goods mentioned in the Schedule. As the duty exempted from the gross turnover isEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

the duty so paid under the Central Act, read with the Schedule, the expression “in respect of” in the
context can only mean excise duty paid on goods. In our view, the expression “in respect of the
goods” in Rule 5(1)(i) of the Rules means only “on the goods”. Even if the word “attributable” is
substituted for the words “in respect of”, the result will not be different, for the duty paid shall be
attributable to the goods. If it was paid on the raw material it can be attributable only to raw
material and not to the goods. We, therefore, hold that only excise duty paid on the goods sold by
the assessee is deductible from the gross turnover under Rule 5(1)(i) of the Rules.” (pages 82-83)
(emphasis supplied)
66. The aforesaid meaning accords with the meaning to be given to the expression “in respect of”
contained in explanation 2(v) to section 9(1)(vi) of the Income Tax Act.
ROYALTY UNDER THE INCOME TAX ACT
67. The insertion of sub-sections (v), (vi) and (vii) in section 9(1) of the Income Tax Act, by way of an
amendment through the Finance Act 1976,37 was to introduce source-based taxation for income in
the hands of a non-resident by way of interest, royalty and fees for technical services. In
Carborandum & Co. v. CIT, (1977) 2 SCC 862, this Court, applying residence-based rules of taxation,
held that the technical Act 66 of 1976, (w.e.f 1-6-1976).
service fees received by the non-resident assessee (relatable to the assessment year 1957-1958) could
only be deemed to accrue in India if such income could be attributed to a business connection in
India. In the facts of that case, since no part of the foreign assessee’s operations were carried on in
India, the technical services being rendered wholly in foreign territory, it was held that no part of the
technical service fees received by the foreign assessee accrued in India.
68. This position of law was altered by the Finance Act 1976, which introduced a “source-rule” to tax
income by way of royalty in the hands of a non-resident, noted in the Memorandum explaining the
provisions of the Finance Bill 1976, as follows:
38. “Source rule” regarding place of accrual of income by way of interest, royalty and
fees for technical services. - A non-resident taxpayer is chargeable to tax in India in
respect of income from whatever source derived which is received or is deemed to be
received in India or which accrues or arises or is deemed to accrue or arise to him in
India. The existing provisions in the Income-tax Act which provide that certain
incomes will be deemed to accrue or arise in India are couched in general language.
The absence of a clear-
cut source rule sometimes creates uncertainty about the chargeability of certain types of incomes in
the case of non- residents. In order to avoid any doubt or dispute in regard to the accrual of income
by way of interest, royalty and fees for technical services in the case of non-residents, it is proposed
to make certain provisions in the Income-tax Act clearly specifying the circumstances in which such
income shall be deemed to accrue or arise in India.Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

xxx xxx xxx
40. Income by way of royalty payable by the Government will be deemed to accrue or arise in India.
Royalty payable by a person who is resident in India will also be deemed to accrue or arise in India,
except in cases where the royalty is payable for the transfer of any right or the use of any property or
information or for utilising the services of the recipient for the purposes of a business or profession
carried on outside India or for the purposes of making or earning any income from a source outside
India. Royalty payable by a non-resident will be deemed to accrue or arise in India only in cases
where the royalty is payable in respect of any right, property or information used or services utilised
for the purposes of a business or profession carried on by the non- resident in India or for the
purposes of making or earning any income from any source in India.”
69. Consequently, section 9(1)(vi) of the Income Tax Act was brought into force. The definition of
royalty contained in explanation 2(v) of section 9(1)(vi) of the Income Tax Act includes the transfer
of all or any rights (including the granting of a licence) “in respect of any copyright, literary, artistic
or scientific work”.
70. The comma after the word “copyright” does not fit as copyright is obviously spoken of as existing
in a literary, artistic or scientific work. As a matter of fact, this drafting error was rectified in the
Draft Taxes Code 2010,38 under Chapter XIX in Part H thereof, which set out the definition of
“royalty” as follows:
“PART H - CHAPTER XIX INTERPRETATIONS AND CONSTRUCTIONS xxx xxx
xxx (314)(220) “royalty” means consideration (including any lump-sum
consideration but excluding any consideration which would be the income of the
recipient chargeable under the head “Capital gains”) for— xxx xxx xxx
(g) the transfer of all or any rights (including the granting of a licence) in respect of —
(i) any copyright of literary, artistic or scientific work; (ii) cinematographic films or
work on films, tapes or any other means of reproduction; or (iii) live coverage of any
event” (emphasis supplied)
71. The transfer of “all or any rights (including the granting of a licence) in respect of any copyright”,
in the context of computer software, is referable to sections 14(a), 14(b) and 30 of the Copyright Act.
As has been held hereinabove, the expression “in respect of” is equivalent to “in” or “attributable to”.
Thus, explanation 2(v) to section 9(1)(vi) of the Income Tax Act, when it speaks of “all of any
rights…in respect of This Code has, however, remained in draft form and was never enacted.
copyright” is certainly more expansive than the DTAA provision, which speaks of the “use of, or the
right to use” any copyright. This has been recognised by the High Court of Delhi in CIT v. DCM
Limited, ITA Nos. 87-89/1992 in its judgment dated 10.03.2011, as follows:
“9. A bare perusal of Article XIII(3) would show that the expression “payments of any
kind” is circumscribed by the latter part of the definition which speaks of
consideration received (including in the form of rentals) for "use of" or "right to use"Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

intellectual properties. The Tribunal, in our view, rightly observed that the CIT(A)
had erred in coming to the conclusion that the expression “payments of any kind”
was broad enough to include even an outright sale. To drive home this point the
Tribunal, once again, has correctly drawn a distinction between the definition of
royalty as appearing in the DTAA and that which finds mention in explanation 2 to
section 9(1)(vi) of the I.T. Act. A perusal of the provisions of the said explanation
would show that it brings within the ambit of royalty a wider range of transactions
which would include payments made for "transfer of all" or "any right" in patents,
inventions, model, design, etc. apart from payments based for use of such right,
patent, innovation, model, design, secret formula or process or trade mark or similar
property. As a matter of fact, a perusal of clause (i) of explanation 2 of section 9(1)(vi)
of the I.T. Act would show that "transfer of all" or "any right" could take place by
execution of licences as well, which was the methodology adopted by Tate and the
assessee in the present case…”
72. However, when it comes to the expression “use of, or the right to use”, the same position would
obtain under explanation 2(v) of section 9(1)(vi) of the Income Tax Act, inasmuch as, there must,
under the licence granted or sale made, be a transfer of any of the rights contained in sections 14(a)
or 14(b) of the Copyright Act, for explanation 2(v) to apply. To this extent, there will be no difference
in the position between the definition of “royalties” in the DTAAs and the definition of “royalty” in
explanation 2(v) of section 9(1)(vi) of the Income Tax Act.
73. Even if we were to consider the ambit of “royalty” only under the Income Tax Act on the footing
that none of the DTAAs apply to the facts of these cases, the definition of royalty that is contained in
explanation 2 to section 9(1)(vi) of the Income Tax Act would make it clear that there has to be a
transfer of “all or any rights'' which includes the grant of a licence in respect of any copyright in a
literary work. The expression “including the granting of a licence” in clause (v) of explanation 2 to
section 9(1)(vi) of the Income Tax Act, would necessarily mean a licence in which transfer is made of
an interest in rights “in respect of” copyright, namely, that there is a parting with an interest in any
of the rights mentioned in section 14(b) read with section 14(a) of the Copyright Act. To this extent,
there will be no difference between the position under the DTAA and explanation 2 to section
9(1)(vi) of the Income Tax Act.
74. However, the learned Additional Solicitor General presses the application of the amendment
made vide the Finance Act 2012 with retrospective effect from 01.06.1976, which added explanation
4 to section 9(1)(vi) of the Income Tax Act.
75. The Memorandum explaining the provisions in the Finance Bill 2012 states:
“Section 9(1)(vi) provides that any income payable by way of royalty in respect of any
right, property or information is deemed to be accruing or arising in India. The term
“royalty” has been defined in Explanation 2 which means consideration received or
receivable for transfer of all or any right in respect of certain rights, property or
information. Some judicial decisions have interpreted this definition in a mannerEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

which has raised doubts as to whether consideration for use of computer software is
royalty or not; whether the right, property or information has to be used directly by
the payer or is to be located in India or control or possession of it has to be with the
payer. Similarly, doubts have been raised regarding the meaning of the term
processed.
Considering the conflicting decisions of various courts in respect of income in nature
of royalty and to restate the legislative intent, it is further proposed to amend the
Income Tax Act in following manner:-
(i) To amend Section 9(1)(vi) to clarify that the consideration for use or right to use of
computer software is royalty by clarifying that transfer of all or any rights in respect
of any right, property or information as mentioned in Explanation 2, includes and
has always included transfer of all or any right for use or right to use a computer
software (including granting of a licence) irrespective of the medium through which
such right is transferred.
(ii) To amend section 9(1)(vi) to clarify that royalty includes and has always included
consideration in respect of any right, property or information, whether or not
(a) The possession or control of such right, property or information is with the payer;
(b) Such right, property or information is used directly by the payer;
(c) The location of such right, property or information is in India
(iii) To amend section 9(1)(vi) to clarify that the term “process” includes and shall be
deemed to have always included transmission by satellite (including up-linking,
amplification, conversion for down-linking of any signal), cable, optic fibre or by any
other similar technology, whether or not such process is secret.
These amendments will take effect retrospectively from 1st June, 1976 and will accordingly apply in
relation to the assessment year 1977-78 and subsequent assessment years.”
76. Shri Pardiwala argued that explanation 4, that was inserted with retrospective effect, uses the
language that is contained in section 9(1)(vi)(b) of the Income Tax Act, namely, that the expression
“any right, property or information” occurring in section 9(1)(vi)(b) alone is the subject matter of
explanation 4, explanation 4 not expanding the scope of the definition of royalty contained in
explanation 2, which does not contain the aforesaid expression. A reference to the Memorandum
explaining the provisions in the Finance Bill 2012 set out hereinabove, would make it clear that the
expression “as mentioned in Explanation 2” in sub-para (i) of the aforesaid Memorandum shows
that explanation 4 was inserted retrospectively to expand the scope of explanation 2(v). In any case,
explanation 2(v) contains the expression, “the transfer of all or any rights” which is an expression
that would subsume “any right, property or information” and is wider than the expression “anyEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

right, property or information”. It is therefore difficult to accept Shri Pardiwala’s argument that
explanation 4 does not expand the scope of the expression “royalty” as contained in explanation 2 to
section 9(1)(vi) of the Income Tax Act.
77. It is equally difficult to accept the learned Additional Solicitor General’s submission that
explanation 4 to section 9(1)(vi)of the Income Tax Act is clarificatory of the position as it always
stood, since 01.06.1976, for which he strongly relied upon CBDT Circular No. 152 dated 27.11.1974.
Quite obviously, such a circular cannot apply as it would then be explanatory of a position that
existed even before section 9(1)(vi) was actually inserted in the Income Tax Act vide the Finance Act
1976. Secondly, insofar as section 9(1)(vi) of the Income Tax Act relates to computer software,
explanation 3 thereof, refers to “computer software” for the first time with effect from 01.04.1991,
when it was introduced, which was then amended vide the Finance Act 2000. Quite clearly,
explanation 4 cannot apply to any right for the use of or the right to use computer software even
before the term “computer software” was inserted in the statute. Likewise, even qua section 2(o) of
the Copyright Act, the term “computer software” was introduced for the first time in the definition of
a literary work, and defined under section 2(ffc) only in 1994 (vide Act 38 of 1994).
78. Furthermore, it is equally ludicrous for the aforesaid amendment which also inserted
explanation 6 to section 9(1)(vi) of the Income Tax Act, to apply with effect from 01.06.1976, when
technology relating to transmission by a satellite, optic fibre or other similar technology, was only
regulated by the Parliament for the first time through the Cable Television Networks (Regulation)
Act, 1995, much after 1976. For all these reasons, it is clear that explanation 4 to section 9(1)(vi) of
the Income Tax Act is not clarificatory of the position as of 01.06.1976, but in fact, expands that
position to include what is stated therein, vide the Finance Act 2012.
79. The learned Additional Solicitor General then relied upon the Finance Minister’s statement
made before the Lok Sabha on 07.09.1990, which allowed lump sum payments to be made without
the deduction of tax at source under section 195(1) of the Income Tax Act and did away with the dual
levy, both by way of customs duty and income tax, on royalty payments for the licensing of software.
This statement, again, in no manner furthers the case of the Revenue that explanation 4 is merely
clarificatory of the legal position as it always stood. Likewise, Notification No. 21/2012 dated
13.06.2012, which deals with section 194J of the Income Tax Act, does no more than providing that
a transferee is exempt from deducting TDS under section 194J when TDS has already been deducted
under section 195 on the payment made in the previous transfer of the same software which the
transferee acquires without any modification. In any case, this notification being issued on
13.06.2012, i.e., after explanation 4 was inserted vide the Finance Act 2012, it would not assist the
Revenue in asserting that explanation 4 clarifies the legal position as it always stood.
80. The learned Additional Solicitor General then argued that being covered by explanation 4 of
section 9(1)(vi) of the Income Tax Act, the persons liable to deduct TDS under section 195 of the
Income Tax Act ought to have deducted tax at source on the footing that explanation 4 existed on
the statute book with effect from 1976. We have, therefore, to examine as to whether persons liable
to deduct TDS under section 195 of the Income Tax Act can be held liable to deduct such sums at a
time when explanation 4 was factually not on the statute book, all deductions liable to be made andEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

the assessment years in question being prior to the year 2012.
81. This question is answered by two latin maxims, lex non cogit ad impossibilia, i.e., the law does
not demand the impossible and impotentia excusat legem, i.e., when there is a disability that makes
it impossible to obey the law, the alleged disobedience of the law is excused. Recently, in the
judgment in Arjun Panditrao Khotkar v. Kailash Kushanrao Gorantyal, (2020) 7 SCC 1 delivered by
this Court, this Court applied the said maxims in the context of the requirement of a certificate to
produce evidence by way of electronic record under section 65B of the Evidence Act, 1872 and held
that having taken all possible steps to obtain the certificate and yet being unable to obtain it for
reasons beyond his control, the respondent in the facts of the case, was relieved of the mandatory
obligation to furnish a certificate. In so holding, this Court referred to previous judgments dealing
with the doctrine of impossibility and concluded as follows:
“47. However, a caveat must be entered here. The facts of the present case show that
despite all efforts made by the respondents, both through the High Court and
otherwise, to get the requisite certificate under Section 65-B(4) of the Evidence Act
from the authorities concerned, yet the authorities concerned wilfully refused, on
some pretext or the other, to give such certificate. In a fact-circumstance where the
requisite certificate has been applied for from the person or the authority concerned,
and the person or authority either refuses to give such certificate, or does not reply to
such demand, the party asking for such certificate can apply to the court for its
production under the provisions aforementioned of the Evidence Act, CPC or CrPC.
Once such application is made to the court, and the court then orders or directs that
the requisite certificate be produced by a person to whom it sends a summons to
produce such certificate, the party asking for the certificate has done all that he can
possibly do to obtain the requisite certificate. Two Latin maxims become important at
this stage. The first is lex non cogit ad impossibilia i.e. the law does not demand the
impossible, and impotentia excusat legem i.e. when there is a disability that makes it
impossible to obey the law, the alleged disobedience of the law is excused. This was
well put by this Court in Presidential Poll, In re [Presidential Poll, In re, (1974) 2 SCC
33] as follows : (SCC pp. 49-50, paras 14-15) “14. If the completion of election before
the expiration of the term is not possible because of the death of the prospective
candidate it is apparent that the election has commenced before the expiration of the
term but completion before the expiration of the term is rendered impossible by an
act beyond the control of human agency. The necessity for completing the election
before the expiration of the term is enjoined by the Constitution in public and State
interest to see that the governance of the country is not paralysed by non-compliance
with the provision that there shall be a President of India.
15. The impossibility of the completion of the election to fill the vacancy in the office
of the President before the expiration of the term of office in the case of death of a
candidate as may appear from Section 7 of the 1952 Act does not rob Article 62(1) of
its mandatory character. The maxim of law impotentia excusat legem is intimately
connected with another maxim of law lex non cogit ad impossibilia. ImpotentiaEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

excusat legem is that when there is a necessary or invincible disability to perform the
mandatory part of the law that impotentia excuses. The law does not compel one to
do that which one cannot possibly perform.
‘Where the law creates a duty or charge, and the party is disabled to perform it, without any default
in him, and has no remedy over it, there the law will in general excuse him.’ Therefore, when it
appears that the performance of the formalities prescribed by a statute has been rendered
impossible by circumstances over which the persons interested had no control, like the act of God,
the circumstances will be taken as a valid excuse.
Where the act of God prevents the compliance with the words of a statute, the statutory provision is
not denuded of its mandatory character because of supervening impossibility caused by the act of
God. (See Broom's Legal Maxims, 10th Edn. at pp. 162-63 and Craies on Statute Law, 6th Edn. at p.
268.)” It is important to note that the provision in question in Presidential Poll, In re [Presidential
Poll, In re, (1974) 2 SCC 33] was also mandatory, which could not be satisfied owing to an act of
God, in the facts of that case. These maxims have been applied by this Court in different situations
in other election cases — See Chandra Kishore Jha v. Mahavir Prasad [Chandra Kishore Jha v.
Mahavir Prasad, (1999) 8 SCC 266] (at paras 17 and 21); Special Reference No. 1 of 2002, In re
(Gujarat Assembly Election matter) [Special Reference No. 1 of 2002, In re (Gujarat Assembly
Election matter), (2002) 8 SCC 237] (at paras 130 and 151) and Raj Kumar Yadav v. Samir Kumar
Mahaseth [Raj Kumar Yadav v. Samir Kumar Mahaseth, (2005) 3 SCC 601] (at paras 13 and 14).
48. These Latin maxims have also been applied in several other contexts by this Court. In Cochin
State Power & Light Corpn. Ltd. v. State of Kerala [Cochin State Power & Light Corpn. Ltd. v. State
of Kerala, (1965) 3 SCR 187 : AIR 1965 SC 1688] , a question arose as to the exercise of an option of
purchasing an undertaking by the State Electricity Board under Section 6(4) of the Electricity Act,
1910. The provision required a notice of at least 18 months before the expiry of the relevant period to
be given by such State Electricity Board to the State Government. Since this mandatory provision
was impossible of compliance, it was held that the State Electricity Board was excused from giving
such notice, as follows : (1965) 3 SCR 187, at p. 193 : AIR pp. 1691-92, para 8 “8. Sub-section (1) of
Section 6 expressly vests in the State Electricity Board the option of purchase on the expiry of the
relevant period specified in the licence. But the State Government claims that under sub-section (2)
of Section 6 it is now vested with the option. Now, under sub-section (2) of Section 6, the State
Government would be vested with the option only ‘where a State Electricity Board has not been
constituted, or if constituted, does not elect to purchase the undertaking’. It is common case that the
State Electricity Board was duly constituted. But the State Government claims that the State
Electricity Board did not elect to purchase the undertaking. For this purpose, the State Government
relies upon the deeming provisions of sub-section (4) of Section 6, and contends that as the Board
did not send to the State Government any intimation in writing of its intention to exercise the option
as required by the sub-section, the Board must be deemed to have elected not to purchase the
undertaking. Now, the effect of sub- section (4) read with sub-section (2) of Section 6 is that on
failure of the Board to give the notice prescribed by sub-section (4), the option vested in the Board
under sub-section (1) of Section 6 was liable to be divested. Sub-section (4) of Section 6 imposedEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

upon the Board the duty of giving after the coming into force of Section 6 a notice in writing of its
intention to exercise the option at least 18 months before the expiry of the relevant period. Section 6
came into force on 5-9-1959, and the relevant period expired on 3-12-1960. In the circumstances,
the giving of the requisite notice of 18 months in respect of the option of purchase on the expiry of
2-12-1960, was impossible from the very commencement of Section 6. The performance of this
impossible duty must be excused in accordance with the maxim, lex non cogitia ad impossibilia (the
law does not compel the doing of impossibilities), and sub-section (4) of Section 6 must be
construed as not being applicable to a case where compliance with it is impossible. We must,
therefore, hold that the State Electricity Board was not required to give the notice under sub-section
(4) of Section 6 in respect of its option of purchase on the expiry of 25 years. It must follow that the
Board cannot be deemed to have elected not to purchase the undertaking under sub-section (4) of
Section 6. By the notice served upon the appellant, the Board duly elected to purchase the
undertaking on the expiry of 25 years. Consequently, the State Government never became vested
with the option of purchasing the undertaking under sub-section (2) of Section 6. The State
Government must, therefore, be restrained from taking further action under its notice, Ext. G, dated
20-11-1959.”
49. In Raj Kumar Dey v. Tarapada Dey [Raj Kumar Dey v. Tarapada Dey, (1987) 4 SCC 398] , the
maxim lex non cogit ad impossibilia was applied in the context of the applicability of a mandatory
provision of the Registration Act, 1908, as follows : (SCC pp. 402-03, paras 6-7) “6. We have to bear
in mind two maxims of equity which are well settled, namely, actus curiae neminem gravabit — An
act of the court shall prejudice no man. In Broom's Legal Maxims, 10th Edn., 1939 at p. 73 this
maxim is explained that this maxim was founded upon justice and good sense;
and afforded a safe and certain guide for the administration of the law. The above maxim should,
however, be applied with caution. The other maxim is lex non cogit ad impossibilia (Broom's Legal
Maxims, p. 162) — The law does not compel a man to do that which he cannot possibly perform. The
law itself and the administration of it, said Sir W. Scott, with reference to an alleged infraction of the
revenue laws, must yield to that to which everything must bend, to necessity; the law, in its most
positive and peremptory injunctions, is understood to disclaim, as it does in its general aphorisms,
all intention of compelling impossibilities, and the administration of laws must adopt that general
exception in the consideration of all particular cases.
7. In this case indisputably during the period from 26-7-1978 to December 1982 there was subsisting
injunction preventing the arbitrators from taking any steps. Furthermore, as noted before the award
was in the custody of the court, that is to say, 28-1- 1978 till the return of the award to the
arbitrators on 24-11-1983, arbitrators or the parties could not have presented the award for its
registration during that time. The award as we have noted before was made on 28-11-1977 and
before the expiry of the four months from 28-11-1977, the award was filed in the court pursuant to
the order of the court. It was argued that the order made by the court directing the arbitrators to
keep the award in the custody of the court was wrong and without jurisdiction, but no arbitrator
could be compelled to disobey the order of the court and if in compliance or obedience with court of
doubtful jurisdiction, he could not take back the award from the custody of the court to take any
further steps for its registration then it cannot be said that he has failed to get the award registeredEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

as the law required. The aforesaid two legal maxims — the law does not compel a man to do that
which he cannot possibly perform and an act of the court shall prejudice no man would, apply with
full vigour in the facts of this case and if that is the position then the award as we have noted before
was presented before the Sub-Registrar, Arambagh on 25-11-1983 the very next one day of getting
possession of the award from the court. The Sub-Registrar pursuant to the order of the High Court
on 24-6-1985 found that the award was presented within time as the period during which the
judicial proceedings were pending that is to say, from 28-1-1978 to 24-11-1983 should be excluded in
view of the principle laid down in Section 15 of the Limitation Act, 1963. The High Court [Tarapada
Dey v. District Registrar, Hooghly, 1986 SCC OnLine Cal 101 : AIR 1987 Cal 107] , therefore, in our
opinion, was wrong in holding that the only period which should be excluded was from 26-7-1978
till 20-12-1982. We are unable to accept this position. 26-7-1978 was the date of the order of the
learned Munsif directing maintenance of status quo and 20-12-1982 was the date when the interim
injunction was vacated, but still the award was in the custody of the court and there is ample
evidence as it would appear from the narration of events hereinbefore made that the arbitrators had
tried to obtain the custody of the award which the court declined to give to them.” (emphasis in
original)
50. These maxims have also been applied to tenancy legislation — see B.P. Khemka (P) Ltd. v.
Birendra Kumar Bhowmick [B.P. Khemka (P) Ltd. v. Birendra Kumar Bhowmick, (1987) 2 SCC 407]
(at para 12), and have also been applied to relieve authorities of fulfilling their obligation to allot
plots when such plots have been found to be unallottable, owing to the contravention of the Central
statutes — see Hira Tikkoo v. State (UT of Chandigarh) [Hira Tikkoo v. State (UT of Chandigarh),
(2004) 6 SCC 765] (at paras 23 and 24).
51. On an application of the aforesaid maxims to the present case, it is clear that though Section
65-B(4) is mandatory, yet, on the facts of this case, the respondents, having done everything
possible to obtain the necessary certificate, which was to be given by a third party over whom the
respondents had no control, must be relieved of the mandatory obligation contained in the said
sub-section.”
82. As a matter of fact, even under the Income Tax Act, the High Court of Bombay has taken a view,
applying the aforestated maxims in the context of the provisions of the relevant DTAAs, to hold that
persons are not obligated to do the impossible, i.e., to apply a provision of a statute when it was not
actually and factually on the statute book.
83. In CIT v. NGC Networks (India) Pvt. Ltd., ITA No. 397/2015, a question arose as to the
applicability of explanation 6 to Section 9(1)(vi), in the context of section 194J of the Income Tax
Act, which explanation was inserted with retrospective effect. The High Court of Bombay, applying
the aforesaid maxim, held:
“(d) We find that [the] view taken by the impugned order dated 9th July, 2014 of the
Tribunal that a party cannot be called upon to perform an impossible act i.e. to
comply with a provision not in force at the relevant time but introduced later by
retrospective amendment. This is in accord with the view taken by this Court in CITEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

v/s. Cello Plast (2012) 209 Taxmann 617 – wherein this Court has applied the legal
maxim lex non cogit ad impossibilia (law does not compel a man to do what he
cannot possibly perform).
(e) In the present facts, the amendment by introduction of Explanation-6 to Section
9(1)(vi) of the Act took place in the year 2012 with retrospective effect from 1976.
This could not have been contemplated by the Respondent when he made the
payment which was subject to tax deduction at source under Section 194C of the Act
during the subject Assessment Year, would require deduction under Section 194J of
the Act due to some future amendment with retrospective effect.”
84. In CIT v. Western Coalfields Ltd., ITA No. 93/2008, the High Court of Bombay dealt with the
insertion of an explanation to section 17(2)(ii) of the Income Tax Act with retrospective effect and
held:
“11) We see no merit in the above contentions. The Apex Court in Arun Kumar's case
(supra) while upholding the validity of Rule 3 has held that in the absence of any
“deeming fiction” in the Act, it is open to the assessee to contend that there is no
concession in the matter of accommodation provided by the employer to the
employees and the case is not covered by Section 17(2)(ii) of the Act. In other words,
even after the substitution of Rule 3 with effect from 1/4/2001, in the absence of any
specific provision under the Act, it was open to the assessee not to deduct tax at
source relating to the accommodation given to the employees on the ground that no
concession in rent has been given to the employees. This contention of the assessee
has been in fact upheld by the Apex Court in the case of Arun Kumar (supra). To
overcome the above decision, the law has been amended by Finance Act, 2007 with
retrospective effect from 1/4/2002. The retrospective amendment merely takes away
the above argument, which was available to the assessee. Once the salary is paid by
the employer after deducting tax at source as per the law prevailing on the date of
paying the salary, then any subsequent amendment in law brought about
retrospectively cannot require the employer to deduct tax at source for the past
period, because the salary for that period has already been paid. Consequently, the
employer cannot be made liable for the consequences set out in Section 201 of the Act
on account of the retrospective amendment to Section 17(2) of the Act.”
85. It is thus clear that the “person” mentioned in section 195 of the Income Tax Act cannot be
expected to do the impossible, namely, to apply the expanded definition of “royalty” inserted by
explanation 4 to section 9(1)(vi) of the Income Tax Act, for the assessment years in question, at a
time when such explanation was not actually and factually in the statute.
RULINGS OF THE AAR AND JUDGMENTS OF HIGH COURTS
86. The question of law posed before us in these appeals has been answered in several rulings –
some by the AAR, some by the High Court of Karnataka, and some by the High Court of Delhi. TheseEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

authorities will now be dealt with sequentially.
87. The first and most comprehensive authority dealing with the question raised in these appeals is
by the AAR in its ruling in Dassault Systems, K.K., In Re., (2010) 322 ITR 125 (AAR) [“Dassault
(AAR)”]. In that case, the applicant was a company incorporated under the laws of Japan, which
marketed licensed computer software products, through a distribution channel comprising value
added resellers [“VAR”], who were independent third-party resellers in the business of selling
software to end-users. The question posed by the AAR to itself was as follows:
“Whether on the facts and circumstances of the case and in law the payment received
by Dassault Systems K.K. (hereinafter referred to as the “the applicant”) from sale of
software products to independent third party resellers will be taxable as business
profits under Article 7 of the India-Japan Double Taxation Avoidance Agreement
(“India-Japan DTAA” or “Treaty”) and will not constitute ‘royalties and fee for
technical services’ as defined in Article 12 of India-Japan DTAA?” (pages 129-130)
88. After setting out Article 12 of the India-Japan DTAA, which is in the same terms as Article 12 of
the India-Singapore DTAA and the other DTAAs that we are concerned with, and after adverting to
the definition of “royalty” that is contained in explanation 2 to section 9(1)(vi) of the Income Tax
Act, the AAR then set out, from the locus classicus on copyright law, the following passage:
“Before entering into a discussion on the applicability of the royalty definition, it is
appropriate to recapitulate certain basic principles concerning the copyright as a legal
concept. We may, in this connection, refer to some passages from the classic treatise
of Copinger and Skone James on Copyright (1999 Edn):
“Copyright gives the owner of the copyright in a work of any description the exclusive
right to authorize or prohibit the Copyright, Designs and Patents Act, 1988 of UK
exploitation of the copyright work by third parties. This includes the right to copy the
work itself and also to use the work in other ways protected under the law”.(p. 26)
Copyright is often described as a negative right. This idea is conveyed by Copinger in
the following words:
“Copyright, however, does not essentially mean a right to do something, but rather a
right to restrict others from doing certain acts, and, when copyright is referred to as
“an exclusive right,” the emphasis is on the word ‘exclusive’. Thus, the 1988 Act,
whilst not defining “copyright” otherwise than as a property right, which is
transmissible as personal or moveable property, provides that the owner of the
copyright in a work has the exclusive right to do the acts restricted by the copyright in
a work of that description specified in the 1988 Act. [Copyright, Designs and Patents
Act, 1988 of UK.]” (p. 27) The following passage also deserves notice:
“It is important to recognize that ownership of copyright in a work is different from
the ownership of the physical material in which the copyright work may happen to beEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

embodied. Just as the owner of the physical material on which a copyright work is
first recorded is not necessarily the first owner of the copyright, so the transfer of title
to the original physical material does not by itself operate to transfer the title to the
copyright… Thus, to take an obvious example, the purchaser of a book or video
recording becomes the owner of the physical article but he does not thereby become
the owner of any part of the copyright in the works reproduced in it. The copyright in
the literary work remains with the copyright owner, who enjoys and is entitled to
enforce all the exclusive rights of copying, publication, adaptation, sale, rental and so
on conferred on him by copyright law. The purchaser does not acquire by his
purchase any right, either by way of assignment or licence, to exercise any of those
exclusive rights. (p. 217)” Referring to the position of a licensee and an exclusive
licensee, the legal position was stated as follows at p. 310:
“A mere licence from the copyright owner confers no proprietary interest on the
licensee enabling him, for example, to bring proceedings in his own name, unless
coupled with the grant of some other interest, for example, the right to take property
away. Statute apart, even an exclusive licence, which is merely the leave to do a thing
coupled with a promise not to do, or give anyone else permission to do that thing,
gives the licensee no right to sue in his own name for infringement nor any other
proprietary interest. In copyright law this general rule is altered by statute in the case
of exclusive licences which comply with prescribed formalities. The 1988 Act confers
on such a licensee a procedural status which enables him to bring proceedings but
otherwise the rule is unchanged: an exclusive licensee has no proprietary interest in
the copyright.”” (pages 132-134)
89. After setting out various provisions of the Copyright Act, the terms of the Distribution
Agreement between the applicant and the VAR, as well as the provisions of the EULA, the AAR then
held:
“In the instant case, the end-user is not given the authority to do any of the acts
contemplated in sub-clauses (i) to (vii) of clause (a) of Section 14, not to speak of the
exclusive right to do the said acts. In fact, the restrictions placed on the end- user and
the VAR which have been referred to earlier coupled with a declaration that the
intellectual property rights in the licensed programmes will remain exclusively with
the applicant (or its licensors) and the non-exclusive and non- transferable character
of licence are all meant to ensure that none of the rights vesting in the applicant as
copyright- holder can be claimed or enjoyed by the licensee and that they will remain
intact and are preserved. The entire tenor of the Agreement and the various
stipulations contained therein make it clear that no rights in derogation of the
applicant's exclusive rights in relation to the copyright have been conferred on the
licensee i.e., the end-user or VAR. The core of the transaction is to authorize the
end-user to have access to and make use of the licensed software products over which
the applicant has exclusive copyright, without giving any scope for dealing with them
any further.Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

Passing on a right to use and facilitating the use of a product for which the owner has
a copyright is not the same thing as transferring or assigning rights in relation to the
copyright. The enjoyment of some or all the rights which the copyright owner has, is
necessary to trigger the royalty definition. Viewed from this angle, a non-exclusive
and non- transferable licence enabling the use of a copyrighted product cannot be
construed as an authority to enjoy any or all of the enumerated rights ingrained in a
copyright. Where the purpose of the licence or the transaction is only to establish
access to the copyrighted product for internal business purpose, it would not be
legally correct to state that the copyright itself has been transferred to any extent. It
does not make any difference even if the computer programme passed on to the user
is a highly specialized one. The parting of intellectual property rights inherent in and
attached to the software product in favour of the licencee/customer is what is
contemplated by the definition clause in the Act as well as the Treaty. As observed
earlier, those rights are incorporated in Section 14. Merely authorizing or enabling a
customer to have the benefit of data or instructions contained therein without any
further right to deal with them independently does not, in our view, amount to
transfer of rights in relation to copyright or conferment of the right of using the
copyright. However, where, for example, the owner of copyright over a literary work
grants an exclusive license to make out copies and distribute them within a specified
territory, the grantee will practically step into the shoes of the owner/grantor and he
enjoys the copyright to the extent of its grant to the exclusion of others. As the right
attached to copyright is conveyed to such licencee, he has the authority to
commercially deal with it. In case of infringement of copyright, he can maintain a suit
to prevent it. Different considerations will arise if the grant is non-exclusive, that too
confined to the user purely for in- house or internal purpose. The transfer of rights in
or over copyright or the conferment of the right of use of copyright implies that the
transferee/licencee should acquire rights - either in entirety or partially co-extensive
with the owner/transferor who divests himself of the rights he possesses pro tanto.
That is what, in our view, follows from the language employed in the definition of
‘royalty’ read with the provisions of Copyright Act, viz., Section 14 and other
complementary provisions.
We may refer to one more aspect here. In the definition of royalty under the Act, the
phrase “including the granting of a licence” is found. That does not mean that even a
non- exclusive licence permitting user for in-house purpose would be covered by that
expression. Any and every licence is not what is contemplated. It should take colour
from the preceding expression “transfer of rights in respect of copyright”. Apparently,
grant of ‘licence’ has been referred to in the definition to dispel the possible
controversy [that a] licence — whatever be its nature, can be characterized as
transfer.” (pages 144-145)
90. The AAR then concluded:Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

“As stated in Copinger's treatise on Copyright, “the exclusive right to prevent copying
or reproduction of a work is the most fundamental and historically oldest right of a
copyright owner”. We do not think that such a right has been passed on to the
end-user by permitting him to download the computer programme and storing it in
the computer for his own use. The copying/reproduction or storage is only incidental
to the facility extended to the customer to make use of the copyrighted product for his
internal business purpose. As admitted by the Revenue's representative, that process
is necessary to make the programme functional and to have access to it and is
qualitatively different from the right contemplated by the said provision because it is
only integral to the use of copyrighted product. Apart from such incidental facility,
the customer has no right to deal with the product just as the owner would be in a
position to do. In so far as the licensed material reproduced or stored is confined to
the four corners of its business establishment, that too on a non- exclusive basis, the
right referred to in sub-clause (i) of Section 14(a) would be wholly out of place.
Otherwise, in respect of even off the shelf software available in the market, it can be
very well said that the right of reproduction which is a facet of copyright vested with
the owner is passed on to the customer. Such an inference leads to unintended and
irrational results. We may in this context refer to Section 52(aa) of C.R. Act (extracted
supra) which makes it clear that “the making of copies or adaptation” of a computer
program by the lawful possessor of a copy of such program, from such copy (i) in
order to utilize the computer program, for the purpose for which it was supplied or
(ii) to make back up copies purely as a temporary protection against loss, destruction,
or damage in order to utilize the computer program for the purpose of which it was
supplied” will not constitute infringement of copyright. Consequently, customization
or adaptation, irrespective of the degree, will not constitute ‘infringement’ as long as
it is to ensure the utilization of the computer program for the purpose for which it
was supplied. Once there is no infringement, it is not possible to hold that there is
transfer or licensing of ‘copyright’ as defined in CR Act and as understood in common
law. This is because, as pointed out earlier, copyright is a negative right in the sense
that it is a right prohibiting someone else to do an act, without authorization of the
same, by the owner.
It seems to us that reproduction and adaptation envisaged by Section 14(a)(i) and (vi)
can contextually mean only reproduction and adaptation for the purpose of
commercial exploitation. Copyright being a negative right (in the sense explained in
para 9 supra), it would only be appropriate and proper to test it in terms of
infringement. What has been excluded under S. 52(aa) is not commercial
exploitation, but only utilizing the copyrighted product for one's own use. The
exclusion should be given due meaning and effect; otherwise, Section 52(aa) will be
practically redundant. In fact, as the law now stands, the owner need not necessarily
grant licence for mere reproduction or adaptation of work for one's own use. Even
without such licence, the buyer of product cannot be said to have infringed the
owner's copyright. When the infringement is ruled out, it would be difficult to reach
the conclusion that the buyer/licensee of product has acquired a copyright therein.Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

The following observations of the Constitution Bench of the Supreme Court in Tata
Consultancy Services v. The State of Andhra Pradesh case are quite apposite, though
made in a different context:
“a software programme may consist of various commands which enable the computer
to perform a designated task. The copyright in that programme may remain with the
originator of the programme. But the moment copies are made and marketed, [they
become] goods, which are susceptible to sales tax.” Viewed from any angle, we have
no hesitation in rejecting the contention of the Revenue referred to in para 18 supra.”
(pages 147-148)
91. Referring to section 14(b)(ii) of the Copyright Act, the AAR then held:
“Next, it has been argued on behalf of the Revenue that the right to sell or offer for
sale the applicant's software product has been conferred on the VAR and therefore
such authority given to VAR amounts to conferment of rights in or over the copyright
in view of cl. (b)(ii) of Section 14. We are unable to sustain this contention. First of
all, this contention of Revenue goes contrary to its stand that the product was
licensed but not sold. Be that as it may, even for other reasons, the contention has to
be rejected. VAR has not been given an independent right to sell or offer for sale the
software products of the applicant to the end-users. What the VAR does in the course
of carrying out its marketing function is to canvass for orders, collect the purchase
order from the interested customer and forward that offer to the applicant. It is the
applicant that accepts or rejects that offer. For this purpose, a non-exclusive and
non-transferable license to distribute the product has been given to VAR. The
transaction emanating from the order of the end-user followed up by back to back
order of VAR is finalized by the applicant and unless the purchase order is accepted
by the applicant, the transaction does not materialize. The VAR's role is only to
forward the order to the applicant with the necessary documents. It is upto the
applicant to accept it or not to accept it. Once the product is delivered to the end-
user, the sale if any by VAR takes place simultaneously and that transaction is a
different one. In the absence of an independent right to conclude the sale or offer for
sale, sub- clause (ii) of clause (b) of Section 14 cannot be invoked to bring the case
within the fold of Art. 12.3 of the Treaty or Section 9(1)(vi) of the Act. It is also
noteworthy that VAR is not an exclusive distributor for a territory and he does not
pay any consideration to the applicant distinctly for acquiring the distribution rights.
He gets the discount for each individual transaction at the agreed rate.” (pages
148-149)
92. Consequently, the question posed to itself was answered by the AAR as follows:
“The answer to the question framed by the applicant is broadly in the negative. It is
ruled that the payment received by the applicant from VARs. (“third party re-sellers”)Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

on account of supplies of software products to the end- customers (from whom the
licence fee is collected and appropriated by VAR) does not result in income in the
nature of royalty to the applicant and moreover payments received by the applicant
cannot be taxed as business profits in India in the absence of permanent
establishment as envisaged by Article 7 of the India-Japan Tax Treaty.” (pages
157-158)
93. Close on the heels of this determination, the AAR followed this determination in Geoquest
Systems B.V. Gevers Deynootweg, In Re., (2010) 327 ITR 1 (AAR) [“Geoquest (AAR)”] qua an
applicant which was a company incorporated in the Netherlands and sold certain software packages
to the Oil and Natural Gas Corporation in India. After referring to and relying upon the
determination in Dassault (AAR) (supra), the AAR concluded that the amount payable to the
applicant did not amount to “royalties” within the meaning of Article 12 of the India- Netherlands
DTAA.
94. However, a discordant note was soon struck by the AAR in Citrix Systems Asia Pacific Ptyl. Ltd.,
In Re., (2012) 343 ITR 1 (AAR) [“Citrix Systems (AAR)”], which ruling is impugned in C.A. No.
8990/2018 before us. In this case, the same question that arose before the AAR in the earlier two
cases, namely Dassault (AAR) (supra) and Geoquest (AAR) (supra), arose. The case concerned an
applicant incorporated in Australia that had entered into a distribution agreement with an
independent Indian company engaged in the business of distribution of computer software and
hardware. “Ingram” was appointed as the non-exclusive distributor of the products of the applicant
in India. This time, the AAR, after referring to the provisions of the Income Tax Act and the
Convention between the Government of the Republic of India and the Government of Australia for
the Avoidance of Double Taxation and the Prevention of Fiscal Evasion with respect to Taxes on
Income,39 [“India-Australia DTAA”], together with the provisions of the Copyright Act, arrived at a
conclusion diametrically opposite to that contained in the rulings in Dassault (AAR) (supra) and
Geoquest (AAR) (supra). The AAR held as follows:
“Thus, a reference to the Copyright Act indicates that use of a copyright either by an
owner or a licensee, would not be an infringement of a copyright. The transfer of
ownership can be by an assignment to another of the copyright either wholly or
partially, either generally or with special limitations and either for the whole term of
the copyright or any part thereof. Similarly, a license can be granted by the owner of
the copyright of any interest in the right. An exclusive right also can be granted
excluding even oneself from the right to use the copyright owned. So, a transgression
of the limitations of an assignment or of a license would prime facie be an
infringement of the copyright and invite the consequences provided for under the
Act. Similarly, the act of taking copies or act of adaptation will not be an infringement
only if it is done by a lawful possessor of a copy of the computer programme. A lawful
possessor can only be an assignee, an exclusive licensee or a licensee of the
programme. When he acquires a computer programme, he also gets the right to use
that programme to a limited extent. This in our view, is on the basis that in so
acquiring the computer programme, he has also got a right, absolute or limited to useEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

the copyright.
When a software is created by a person who acquires a copyright for it, he becomes
the owner of that copyright. He Notification No. GSR 60(E), dated 22-1-1992 as
amended by Notification No.74/2013 [F.No.503/1/2009-FTD-II]/SO 2820(E), dated
20-9-2013.
can transfer or license that right either by himself or through an agent. When he sells
or licenses the software for use, he is also selling or licensing the right to use the
copyright embedded therein. If a software is used without being lawfully acquired
either by purchase or by license, that would amount to an infringement of the
copyright obviously because of the copyright embedded in the software. The software
is a literary work and clearly the copyright of the creator over the software is an
important and commercially valuable right. So, whenever a software is assigned or
licensed for use, there is involved an assignment of the right to use the embedded
copyright in the software or a license to use the embedded copyright, the Intellectual
Property Right in the software. Therefore, it appears to us that it is not possible to
divorce the software from the Intellectual Property Right of the creator of the
software embedded therein. The amendment to Section 14(1)(b) of the Copyright Act,
by Act 49 of 1999, clarifying that in the case of a computer programme, copyright
means the right to sell or give on commercial rental or offer for sale or commercial
rental any copy of the computer programme, seems to be significant. This addition
would suggest that even the right to sell or give on rental, would amount to a
copyright and would be a right to be dealt with as a copyright.” (pages 13-14)
95. The AAR disagreed with the determination in Dassault (AAR) (supra), stating:
“In Dassault (AAR 821 of 2009), it was noticed that the core of the transaction in that
case was to authorise the end-user to have access to and make use of the licensed
software products over which the applicant had exclusive copyright without giving
any scope for dealing with them any further.
The reasoning or the line of reasoning in Factset on applicability of the Copyright Act,
in this context, was followed. It was also noticed that in Tata Consultancy Services
(271 ITR 401), the Supreme Court had held that “a software programme may consist
of various commands which enable the computer to perform a designated task. The
copyright in that programme may remain with the originator of the programme. But,
the moment copies are made and marketed it becomes goods which are susceptible to
sales-tax.” The Supreme Court was speaking in the context of the Sales-tax Act. The
Court had no occasion to consider what was involved in the sale of a software
programme. The Court had no occasion to consider what all are the rights that pass
on to the grantee when a software programme is transferred or licensed to him. It
was concluded in Dassault, that in the absence of an independent right to conclude a
sale or offer for sale, section 14 could not be invoked to bring the case within SectionEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

9(1)(vi) of the Act by invoking sub-clause (ii) of Clause (b) of that section. It was
concluded that no right to use the copyright as such has been conferred on the
licensee. In our view whenever software is transferred or licensed for use, it takes
within it the copyright embedded in the software and the one cannot be divorced
from the other.” (page 17)
96. The AAR then reasoned that the fact that a licence had been granted would be sufficient to
conclude that there was a transfer of copyright, and that there was no justification for the use of the
doctrine of noscitur a sociis to confine the transfer by way of a licence to only include a licence which
transferred rights in respect of copyright, by referring to explanation 2 to section 9(1)(vi) of the
Income Tax Act. It then held:
“Considerable arguments are raised on the so-called distinction between a copyright
and copyrighted articles. What is a copyrighted article? It is nothing but an article
which incorporates the copyright of the owner, the assignee, the exclusive licensee or
the licencee. So, when a copyrighted article is permitted or licensed to be used for a
fee, the permission involves not only the physical or electronic manifestation of a
programme, but also the use of or the right to use the copyright embedded therein.
That apart, the Copyright Act or the Income-tax Act or the DTAC does not use the
expression ‘copyrighted article’, which could have been used if the intention was as
claimed by the applicant. In the circumstances, the distinction sought to be made
appears to be illusory.” (page 19)
97. This ruling of the AAR flies in the face of certain principles. When, under a non-exclusive
licence, an end-user gets the right to use computer software in the form of a CD, the end-user only
receives a right to use the software and nothing more. The end-user does not get any of the rights
that the owner continues to retain under section 14(b) of the Copyright Act read with sub-section
(a)(i)-(vii) thereof. Thus, the conclusion that when computer software is licensed for use under an
EULA, what is also licensed is the right to use the copyright embedded therein, is wholly incorrect.
The licence for the use of a product under an EULA cannot be construed as the licence spoken of in
section 30 of the Copyright Act, as such EULA only imposes restrictive conditions upon the end-user
and does not part with any interest relatable to any rights mentioned in sections 14(a) and 14(b) of
the Copyright Act.
98. As a matter of fact, even otherwise, on first principles, the extract from Copinger and Skone
James on Copyright (14th Edition) (1999) referred to in Dassault (AAR) (supra) makes it clear that
the ownership of copyright in a work is different from the ownership of the physical material in
which the copyrighted work may happen to be embedded. This important passage correctly relied
upon by the AAR in the Dassault (AAR) (supra) ruling has been completely missed.
99. Further, it is difficult to understand the reasoning contained in this determination. It is
self-contradictory when it says that the DTAA which defines “royalties” must somehow be given a
go-bye, as this term must be understood as it is commonly understood. It is also difficult to
understand the holding that the AAR need not be constrained by the definition of “copyright”Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

contained in section 14 of the Copyright Act, when construing a DTAA, when we have already seen
how section 16 of the Copyright Act makes it clear that no person shall be entitled to copyright
otherwise than under the provisions of the Copyright Act or any other law in force.
100. Also, any ruling on the more expansive language contained in the explanations to section
9(1)(vi) of the Income Tax Act would have to be ignored if it is wider and less beneficial to the
assessee than the definition contained in the DTAA, as per section 90(2) of the Income Tax Act read
with explanation 4 thereof, and Article 3(2) of the DTAA. Further, the expression “copyright” has to
be understood in the context of the statute which deals with it, it being accepted that municipal laws
which apply in the Contracting States must be applied unless there is any repugnancy to the terms of
the DTAA. For all these reasons, the determination of the AAR in Citrix Systems (AAR) (supra) does
not state the law correctly and is thus set aside.
101. The High Court of Karnataka, in a judgment impugned in various appeals before us, namely,
CIT v. Samsung Electronics Co. Ltd., (2012) 345 ITR 494, also held that what was sold/licensed by
way of computer software, included the grant of a right or interest in copyright, and thus gave rise to
the payment of royalty, which then required the deduction of TDS. The reasoning of this judgment
under appeal is set out as follows:
“…Accordingly, we hold that right to make a copy of the software and use it for
internal business by making copy of the same and storing the same in the hard disk of
the designated computer and taking back up copy would itself amount to copyright
work under section 14(1) of the Act and licence is granted to use the software by
making copies, which [would], but for the licence granted, have constituted
infringement of copyright and the licensee is in possession of the legal copy of the
software under the licence. Therefore, the contention of the learned senior counsel
appearing for the respondents that there is no transfer of any part of copyright or
copyright and transaction only involves sale of copy of the copyright software cannot
be accepted.
It is also to be noted that what is supplied is the copy of the software of which the
respondent-supplier continues to be the owner of the copyright and what is granted
under the licence is only right to copy the software as per the terms of the agreement,
which, but for the licence would amount to infringement of copyright and in view of
the licence granted, the same would not amount to infringement under section 52 of
the Copyright Act as referred to above.
Therefore, the amount paid to the non-resident supplier towards supply of shrink-wrapped
software, or off-the-shelf software is not the price of the C.D. alone nor software alone nor the price
of licence granted. This is a combination of all and in substance, unless licence is granted permitting
the end user to copy, and download the software, the dumb C.D. containing the software would not
in any way be helpful to the end user as software would become operative, only if it is downloaded to
the hardware of the designated computer as per the terms and conditions of the agreement and that
makes, the difference between the computer software and copyright, in respect of books orEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

prerecorded music [C.D.], as book and prerecorded music C.D. can be used once they are purchased,
but so far as software stored in dumb C.D. is concerned, the transfer of dumb C.D. by itself would
not confer any, right, upon the end user and the purpose of the C.D. is only to enable the end user to
take a copy of the software and to store it in the hard disk of the designated computer if licence is
granted in that behalf and in the absence of licence, the same would amount to infringement of
copyright, which is exclusively owned by non-resident suppliers, who would continue to be the
proprietor of copyright. Therefore, there is no similarity between the transaction of purchase of the
book or prerecorded music C.D. or the C.D. containing software and in view of the same, the
Legislature in its wisdom, has treated the literary work like books and other articles separately from
“computer” software within the meaning of the “copyright” as referred to above under section 14 of
the Copyright Act.
It is also clear from the abovesaid analysis of the DTAA, the Income-tax Act, the Copyright Act that
the payment would constitute “royalty” within the meaning of article 12(3) of the DTAA and even as
per the provisions of section 9(1)(vi) of the Act as the definition of “royalty” under clause 9(1)(vi) of
the Act is broader than the definition of “royalty” under the DTAA as the right that is transferred in
the present case is the transfer of copyright including the right to make copy of software for internal
business, and payment made in that regard would constitute “royalty” for imparting of any
information concerning technical, industrial, commercial or scientific knowledge, experience or skill
as per clause (iv) of Explanation 2 to section 9(1)(vi) of the Act. In any view of the matter, in view of
the provisions of section 90 of the Act, agreements with foreign countries DTAA would override the
provisions of the Act. Once it is held that payment made by the respondents to the non-resident
companies would amount to “royalty” within the meaning of article 12 of the DTAA with the
respective country, it is clear that the payment made by the respondents to the non-resident supplier
would amount to royalty. In view of the said finding, it is clear that there is obligation on the part of
the respondents to deduct tax at source under section 195 of the Act and consequences would follow
as held by the hon'ble Supreme Court while remanding these appeals to this court. Accordingly, we
answer the substantial question of law in favour of the Revenue and against the assessee by holding
that on the facts and in the circumstances of the case, the Income-tax Appellate Tribunal was not
justified in holding that the amount(s) paid by the respondents) to the foreign software suppliers
was not “royalty” and that the same did not give rise to any “income” taxable in India and wherefore,
the respondent(s) were not liable to deduct any tax at source and pass the following order:
All the appeals are allowed. The order passed by the Income-tax Appellate Tribunal,
Bangalore Bench “A” impugned in these appeals is set aside and the order passed by
the Commissioner of Income-tax (Appeals) confirming the order passed by the
Assessing Officer (TDS)-I is restored.” (pages 527-528)
102. The reasoning of this judgment also does not commend itself to us. The same error as was
made by the AAR in Citrix Systems (AAR) (supra), was made in this judgment, i.e., no distinction
was made between computer software that was sold/licensed on a CD/other physical medium and
the parting of copyright in respect of any of the rights or interest in any of the rights mentioned in
sections 14(a) and 14(b) of the Copyright Act. This being the case, the reasoning of this judgment
suffers from the same fundamental defect that the ruling in Citrix Systems (AAR) (supra) suffersEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

from. By no stretch of imagination, can the payment for such computer software amount to royalty
within the meaning of Article 12 of the DTAA or section 9(1)(vi) of the Income Tax Act.
103. In another judgment of the High Court of Karnataka, dated 03.08.2020, in CIT v. Synopsis
International Old Ltd., ITA Nos. 11-15/2008 [“Synopsis Intl.”],40 the High Court relied upon the
expression “in respect of” in section 9(1)(vi) of the Income Tax Act, holding:
“27. The words "in respect of" [denote] the intention of the Parliament to give a
broader meaning. The words “in respect of” admit of a wide connotation, than the
word "in" or "on". The expression "in respect of" means “attributable to". If it is given
a wider meaning "relating to or with reference to", it has been used in the sense of
being “connected with”. Whether it is a fiscal legislation or any legislation for that
matter, the golden rule of interpretation equally applies to all of them, i.e., the words
in a statute should be given its literal meaning. In respect of fiscal legislation those
words should be strictly construed. If those words are capable of two meanings that
meaning which is beneficial to an assessee should be given. However, when the
meaning of the words used are clear, unambiguous, merely because it is a fiscal
legislation, the meaning cannot be narrowed down and it cannot be interpreted so as
to give benefit to the assessee only. Then it would be re-writing the section, under the
guise of interpreting a fiscal legislation, which is totally This judgment has been
relied upon by several judgments of the High Court of Karnataka impugned in the
appeals before us.
impermissible in law. When the legislature has advisedly used the words “in respect
of”, the intention is clear and manifest. The said phrase being capable of a broader
meaning, the same is used in the section to bring within the tax net all the incomes
from the transfer of all or any of the rights in respect of a copyright. In a taxing
statute provisions enacted to prevent tax evasion are to be given a liberal
construction to effectuate the purpose of suppressing tax evasion, although
provisions imposing a charge are construed strictly there being no a priori liability to
pay a tax and the purpose of charging section being only to levy a charge on persons
and activities brought within its clear terms. Therefore, the specific words used in a
taxing statute, charging tax cannot be ignored. It is not the consideration for transfer
of all or any of the rights in the copyright. Without transferring a right in the
copyright it is possible to receive consideration for the use of the intellectual property
for which the owner possesses a copyright. Ultimately, the consideration paid is for
the usefulness of the material object in respect of which there exists a copyright.
Therefore, the intention was not to exclude the consideration paid for the use of such
material object which is popularly called as copyrighted article. Even in respect of a
copyrighted article the same is transferred, no doubt the right in the copyright is not
transferred, but a right in respect of a copyright contained in the copyrighted article
is transferred. Therefore, the Parliament thought it fit to use the phrase “in respect
of” as contra distinct from the word “in” copyright. The meaning is clear, intention is
clear, there is no ambiguity. Therefore, there is no scope for interpretation of thisEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

expressed term inasmuch as in the context in which it is used in the provision. Any
other interpretation would lead to the aforesaid provision becoming otiose.”
104. After so holding, the High Court of Karnataka went on to state:
“32. … Therefore, the expression 'copyright' used in the Act cannot be the same as
used in the Income-tax Act, when the legislature advisedly used the word 'in respect
of a copyright' it cannot be construed as a right in the copyright and assign the
meaning assigned in the Copyright Act to the second explanation. The language in
Explanation (2) explicitly makes it clear for the purpose of clause (vi) of sub-section
(1) of section 9 royalty means consideration for transfer of all or any rights including
the granting of a licence in respect of any copyright, literary, artistic or scientific
work.
Therefore, the word exclusive right used in section 14 of the Act do not fit into the meaning of the
word 'royalty' in Explanation 2 because royalty means the consideration for the transfer of all or any
rights including the granting of a licence which is certainly not an exclusive right or transfer of all
rights in the copyright or literary work. Payments made for the acquisition of partial rights in the
copyright without the transfer fully alienating the copyright rights will represent a royalty where the
consideration is for granting of lights to use the program[m]e in a manner that would, without such
license, constitute an infringement of copyright. In these circumstances, the payments are for the
right to use the copyright in the program i.e., to exploit the rights that would otherwise be the sole
prerogative of the copyright holder. Therefore, to constitute royalty under the Income-tax Act it is
not necessary that there should be transfer of exclusive right in copyright, it is sufficient if there is
transfer of any interest in the right and also a licence and consideration paid for grant of a licence
constitutes royalty for the purpose of the said clause in the Income-tax Act. It is in this background,
the discussion whether the payment is for a copyright or for a copyright article would be totally
irrelevant. The crux of the issue is whether any consideration is paid for any right, or for granting of
licence in respect of a copyright. The word 'in respect of’ gives a broader meaning. It has been used
in the sense of being connected with. When the legislature has advisedly used the words 'in respect
of', the intention is clear and manifest. The said phrase being capable of a broader meaning, the
same is used in the section to bring within the tax net all the incomes from the transfer of all or any
of the rights in respect of the copyright.
xxx xxx xxx
35. The copyright subsists in a computer program. It is not only unauthorised reproduction but also
the storage of a program in a computer constitutes copyright infringement. Copying a literary work
(such as a computer program) includes storing the work in any medium by electronic means.
Copying includes the making of copies which are transient or some other use of the work.
xxx xxx xxxEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

39. It is no doubt true the provisions of the DTAA overrides the provisions of the Income-tax Act. In
the DTAA the term 'royalty' means payments of any kind received as a consideration for the use or
the right to use any copyright of literary, artistic or scientific work whereas in the Income-tax Act,
royalty means consideration for the transfer of all or any rights including the granting of a licence.
Therefore, under the DTAA to constitute royalty there need not be any transfer of or any rights in
respect of any copyright. It is sufficient if consideration is received for use of or the right to use any
copyright. Therefore, if the definition of royalty in the DTAA is taken into consideration it is not
necessary there should be a transfer of any exclusive right. A mere right to use or the use of a
copyright falls within the mischief of Explanation (2) to clause (v) of sub-section (1) of section 9 and
is liable to tax. Therefore, we do not see any substance in the said contention.
xxx xxx xxx
43. A licence is a permission to do something that would otherwise be unlawful. The question arises,
therefore, as to what legal permission is granted by a software licence. The answer is, briefly, that in
some cases the licence will be a permission to use confidential information, and in virtually [...] all
cases it will be a permission to copy a copyright work. If the software has been kept secret by the
producer, or only supplied on conditions of confidentiality and has not been published too widely,
then the software licence will be akin to a licence of confidential information or know-how. The
owner or licensor of a copyright, has a right to grant permission to use the software or a computer
programme, in respect of which they have a copyright, without transferring the right in copyright. It
is one of the right[s] of a copyright owner or licensor. Without such right being transferred, the
end-user has no right to use the software or computer programme. If he uses it, it amounts to
infringement of copyright. For transfer of such right if consideration is paid, it is not a consideration
for transfer of a copyright but for use of intellectual property embedded in the copyright, and
therefore it is for transfer of one of those rights of the owner of the copyright. It is not a right in
copyright but it is in respect of a copyright. When a copyrighted article is sold also, the end-user gets
the right to use the intellectual property embedded in the copyright and not a right in the copyright
as such. Therefore the mode adopted or the terminology given is not decisive to decide the nature of
transfer. Ultimately, it is the substance which has to be looked into.”
105. The reasoning of the High Court of Karnataka in Synopsis Intl. (supra) does not commend itself
to us. First and foremost, as held in State of Madras v. Swastik Tobacco Factory, (1966) 3 SCR 79,
the expression “in respect of”, when used in a taxation statute, is only synonymous with the words
“on” or “attributable to”. Such meaning accords with the meaning to be given to the expression “in
respect of” contained in explanation 2(v) to section 9(1)(vi) of the Income Tax Act, and would not in
any manner make the expression otiose, as has wrongly been held by the High Court of Karnataka.
106. Secondly, section 16 of the Copyright Act, which states that “no person shall be entitled to
copyright…otherwise than under and in accordance with the provisions of this Act or of any other
law for the time being in force” has been completely missed, thus making it clear that the expression
“copyright” has to be understood only as is stated in section 14 of the Copyright Act and not
otherwise.Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

107. Thirdly, when it comes to computer programmes, the High Court in Synopsis Intl. (supra) was
wholly incorrect in stating that the storage of a computer programme per se would constitute
infringement of copyright. This, again, would directly be contrary to the terms of section 52(1)(aa) of
the Copyright Act.
108. Fourthly, the High Court is not correct in referring to section 9(1)(vi) of the Income Tax Act
after considering it in the manner that it has and then applying it to interpret the provisions under
the Convention between the Government of the Republic of India and the Government of Ireland for
the Avoidance of Double Taxation and for the Prevention of Fiscal Evasion with respect to Taxes on
Income And Capital Gains,41 [“India-Ireland DTAA”]. Article 12 of the aforesaid treaty defining
“royalties” would alone be relevant to determine taxability under the DTAA, as it is more beneficial
to the assessee as compared to section 9(1)(vi) of the Income Tax Act, as construed by the High
Court. Here again, section 90(2) of the Income Tax Act, read with explanation 4 thereof, has not
been properly appreciated.
109. Fifthly, the finding that when a copyrighted article is sold, the end-user gets the right to use the
intellectual property rights embodied in the copyright which would therefore amount to transfer of
an exclusive right of the copyright owner in the work, is also wholly incorrect. For all these reasons,
therefore, the judgment of the High Court of Karnataka in Synopsis Intl. (supra) also does not state
the law correctly.
Notification : No. GSR 105(E) [45/2002 (F. No. 503/6/99-FTD)], dated 20-2-2002.
110. A series of judgments by the High Court of Delhi have dealt with the same question that now
lies before us. In Director of Income Tax v. Ericsson A.B., (2012) 343 ITR 470 [“Ericsson A.B.”],
which happens to be impugned in C.A. Nos. 6386-6387/2016 before us, the assessee was a company
incorporated in Sweden which entered into an agreement with Indian cellular operators, pursuant
to which the assessee supplied various equipment (hardware) embedded with software to the said
cellular operators. The High Court in this case, found:
“Once we proceed on the basis of aforesaid factual findings, it is difficult to hold that
payment made to the assessee was in the nature of royalty either under the
Income-Tax Act or under the DTAA. We have to keep in mind what was sold by the
assessee to the Indian customers was a GSM which consisted both of the hardware as
well as the software, therefore, the Tribunal is right in holding that it was not
permissible for the Revenue to assess the same under two different articles. The
software that was loaded on the hardware did not have any independent existence.
The software supply is an integral part of the GSM mobile telephone system and is
used by the cellular operator for providing the cellular services to its customers.
There could not be any independent use of such software. The software is embodied
in the system and the revenue accepts that it could not be used independently. This
software merely facilitates the functioning of the equipment and is an integral part
thereof. On these facts, it would be useful to refer to the judgment of the Supreme
Court in TATA Consultancy Services v. State of Andhra Pradesh, 271 ITR 401,Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

wherein the Apex Court held that software which is incorporated on a media would
be goods and, therefore, liable to sales tax. Following discussion in this behalf is
required to be noted:-
“In our view, the term “goods” as used in Article 366(12) of the Constitution of India
and as defined under the said Act are very wide and include all types of movable
properties, whether those properties be tangible or intangible. We are in complete
agreement with the observations made by this Court in Associated Cement
Companies Ltd. (supra). A software programme may consist of various commands
which enable the computer to perform a designated task. The copyright in that
programme may remain with the originator of the programme. But the moment
copies are made and marketed, it becomes goods, which are susceptible to sales tax.
Even intellectual property, once it is put on to a media, whether it be in the form of
books or canvas (In case of painting) or computer discs or cassettes, and marketed
would become “goods”. We see no difference between a sale of a software programme
on a CD/floppy disc from a sale of music on a cassette/CD or a sale of a film on a
video cassette/CD. In all such cases, the intellectual property has been incorporated
on a media for purposes of transfer. Sale is not just of the media which by itself has
very little value. The software and the media cannot be split up. What the buyer
purchases and pays for is not the disc or the CD. As in the case of paintings or books
or music or films the buyer is purchasing the intellectual property and not the media
i.e. the paper or cassette or disc or CD. Thus a transaction sale of computer software
is clearly a sale of “goods” within the meaning of the term as defined in the said Act.
The term “all materials, articles and commodities” includes both tangible and
intangible/incorporeal property which is capable of abstraction, consumption and
use and which can be transmitted, transferred, delivered, stored, possessed etc. The
software programmes have all these attributes.” In Advent Systems Ltd. v. Unisys
Corpn, 925 F. 2d 670 (3rd Cir. 1991), relied on by Mr. Sorabjee, the court was
concerned with interpretation of uniform civil code which “applied to transactions in
goods”. The goods therein were defined as “all things (including specially
manufactured goods) which are moveable at the time of the identification for sale”. It
was held:
“Computer programs are the product of an intellectual process, but once implanted in
a medium are widely distributed to computer owners. An analogy can be drawn to a
compact disc recording of an orchestral rendition. The music is produced by the
artistry of musicians and in itself is not a “good”, but when transferred to a laser-
readable disc becomes a readily merchantable commodity. Similarly, when a
professor delivers a lecture, it is not a good, but, when transcribed as a book, it
becomes a good.
That a computer program may be copyrightable as intellectual property does not alter
the fact that once in the form of a floppy disc or other medium, the program is
tangible, moveable and available in the marketplace. The fact that some programsEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

may be tailored for specific purposes need not alter their status as “goods” because
the Code definition includes “specially manufactured goods.” A fortiorari when the
assessee supplies the software which is incorporated on a CD, it has supplied tangible
property and the payment made by the cellular operator for acquiring such property
cannot be regarded as a payment by way of royalty.
(pages 499-500) “Be that as it may, in order to qualify as royalty payment, within the
meaning of Section 9(1)(vi) and particularly clause
(v) of Explanation-II thereto, it is necessary to establish that there is transfer of all or
any rights (including the granting of any license) in respect of copyright of a literary,
artistic or scientific work. Section 2(o) of the Copyright Act makes it clear that a
computer programme is to be regarded as a ‘literary work’. Thus, in order to treat the
consideration paid by the cellular operator as royalty, it is to be established that the
cellular operator, by making such payment, obtains all or any of the copyright rights
of such literary work. In the presence case, this has not been established. It is not
even the case of the Revenue that any right contemplated under Section 14 of the
Copyright Act, 1957 stood vested in this cellular operator as a consequence of Article
20 of the Supply Contract. Distinction has to be made between the acquisition of a
“copyright right” and a “copyrighted article”.
Mr. Dastur is right in this submission which is based on the commentary on the OECD Model
Convention. Such a distinction has been accepted in a recent ruling of the Authority for Advance
Ruling (AAR) in Dassault Systems KK 229 CTR 125. We also find force in the submission of Mr.
Dastur that even assuming the payment made by the cellular operator is regarded as a payment by
way of royalty as defined in Explanation 2 below Section 9(1)(vi), nevertheless, it can never be
regarded as royalty within the meaning of the said term in article 13, para 3 of the DTAA. This is so
because the definition in the DTAA is narrower than the definition in the Act. Article 13(3) brings
within the ambit of the definition of royalty a payment made for the use of or the right to use a
copyright of a literary work. Therefore, what is contemplated is a payment that is dependent upon
user of the copyright and not a lump sum payment as is the position in the present case.
We thus hold that payment received by the assessee was towards the title and GSM system of which
software was an inseparable parts incapable of independent use and it was a contract for supply of
goods. Therefore, no part of the payment therefore can be classified as payment towards royalty.”
(pages 501-502)
111. This judgment was followed in Director of Income Tax v. Nokia Networks OY, (2013) 358 ITR
259 [“Nokia Networks OY”],42 with the High Court of Delhi, adverting, this time, to the further
expanded definition of “royalty” that is contained in the retrospective amendment that inserted
explanation 4 to section 9(1)(vi) of the Income Tax Act. In this case, the High Court was concerned
with the Agreement between the Republic of India and the Republic of Finland for the Avoidance of
This judgment has been relied upon by various judgments of the High Court of Delhi impugned in
the appeals before us.Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

Double Taxation and the Prevention of Fiscal Evasion with respect to Taxes on Income,43
[“India-Finland DTAA”]. After setting out the rationale for the clarificatory amendment made vide
the Finance Act 2012, the High Court held :
“He, thus submitted that the question of “copyrighted article” or actual copyright
does not arise in the context of software both in the DTAA and in the Income Tax Act
since the right to use simpliciter of a software program itself is a part of the copyright
in the software irrespective of whether or not a further right to make copies is
granted. The decision of the Delhi Bench of the ITAT has dealt with this aspect in its
judgment in Gracemac Co. v. ADIT 134 TTJ (Delhi) 257 pointing out that even
software bought off the shelf, does not constitute a “copyrighted article” as sought to
be made out by the Special Bench of the ITAT in the present case. However, the
above argument misses the vital point namely the assessee has opted to be governed
by the treaty and the language of the said treaty differs from the amended Section 9
of the Act. It is categorically held in CIT v. Siemens Aktiongesellschaft, 310 ITR 320
(Bom) that the amendments cannot be read into the treaty. On the wording of the
treaty, we have already held in Ericsson (supra) that a copyrighted article does not
fall within the purview of Royalty. Therefore, we decide question of law no. 1 & 2 in
favour of the assessee and against the Revenue.” (page 281) Notification No. 36/2010
[F. No. 501/13/1980-FTD-I], dated 20-5-2010.
The High Court then followed its own judgment in Ericsson A.B. (supra), deciding the case in favour
of the assessee.
112. In Director of Income Tax v. Infrasoft Ltd., (2014) 264 CTR 329 [“Infrasoft”],44 a Division
Bench of the High Court of Delhi, by an exhaustive analysis of the provisions contained the
India-USA DTAA, the Income Tax Act and the Copyright Act, dealt with a situation in which the
assessee who was primarily into the business of developing and manufacturing civil engineering
software, licensed the said software to persons engaged in civil engineering work in India. The High
Court referred to a decision of the Special Bench of the ITAT (New Delhi) in Motorola Inc. v. Deputy
CIT, dated 22.06.2005 [“Motorola (ITAT)”] as follows:
“65. The issue whether consideration for software was royalty came up for
consideration before the Special Bench of the Tribunal in Delhi in the case of
Motorola Inc v. Deputy Cit And Deputy Cit V. Nokia (2005) 147 TAXMAN 39
(DELHI). The Tribunal has held as under:
155. It appears to us from a close examination of the manner in which the case has
proceeded before the Income-tax authorities and the arguments addressed before us
that the crux of the issue is whether the payment is for a copyright or This judgment
has been relied upon by various judgments of the High Court of Delhi impugned in
the appeals before us.Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

for a copyrighted article. If it is for copyright, it should be classified as royalty both under the
Income-tax Act and under the DTAA and it would be taxable in the hands of the Assessee on that
basis. If the payment is really for a copyrighted article, then it only represents the purchase price of
the article and, therefore, cannot be considered as royalty either under the Act or under the DTAA.
This issue really is the key to the entire controversy and we may now proceed to address this issue.
156. We must look into the meaning of the word “copyright” as given in the Copyright Act, 1957.
Section 14 of this Act defines “Copyright” as “the exclusive right subject to the provisions of this Act,
to do or authorize the doing of any of the following acts in respect of a work or any substantial part
thereof [ … ] It is clear from the above definition that a computer programme mentioned in Clause
(b) of the section has all the rights mentioned in Clause (a) and in addition also the right to sell or
give on commercial rental or offer for sale or for commercial rental any copy of the computer
programme. This additional right was substituted w.e.f. 15.1.2000. The difference between the
earlier provision and the present one is not of any relevance. What is to be noted is that the right
mentioned in Sub-clause (ii) of Clause (b) of Section 14 is available only to the owner of the
computer programme. It follows that if any of the cellular operators does not have any of the rights
mentioned in Clauses (a) and (b) of Section 14, it would mean that it does not have any right in a
copyright. In that case, the payment made by the cellular operator cannot be characterized as royalty
either under the Income-tax Act or under the DTAA. The question, therefore, to be answered is
whether any of the operators can exercise any of the rights mentioned in the above provisions with
reference to the software supplied by the Assessee.
157. We may first look at the supply contract itself to find out what JTM, one of the cellular
operators, can rightfully do with reference to the software. We may remind ourselves that JTM is
taken as a representative of all the cellular operators and that it was common ground before us that
all the contracts with the cellular operators are substantially the same. Clause 20.1 of the
Agreement, under the title “License”, says that JTM is granted a non-exclusive restricted license to
use the software and documentation but only for its own operation and maintenance of the system
and not otherwise. This clause appears to militate against the position, if it were a copyright, that the
holder of the copyright can do anything with respect to the same in the public domain. What JTM is
permitted to do is only to use the software for the purpose of its own operation and maintenance of
the system. There is a clear bar on the software being used by JTM in the public domain or for the
purpose of commercial exploitation.
158. Secondly, under the definition of “copyright” in Section 14 of the Copyright Act, the emphasis is
that it is an exclusive right granted to the holder thereof. This condition is not satisfied in the case of
JTM because the license granted to it by the Assessee is expressly stated in Clause 20.1 as a “non
exclusive restricted license”. This means that the supplier of the software, namely, the Assessee, can
supply similar software to any number of cellular operators to which JTM can have no objection and
further all the cellular operators can use the software only for the purpose of their own operation
and maintenance of the system and not for any other purpose. The user of the software by the
cellular operators in the public domain is totally prohibited, which is evident from the use of the
words in Article 20.1 of the agreement, “restricted” and “not otherwise”. Thus JTM has a very
limited right so far as the use of software is concerned. It needs no repetition to clarify that JTM hasEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

not been given any of the seven rights mentioned in Clause
(a) of Section 14 or the additional right mentioned in Sub-clause (ii) of Clause (b) of the section
which relates to a computer programme and, therefore, what JTM or any other cellular operator has
acquired under the agreement is not a copyright but is only a copyrighted article.”” (pages 362-364)
113. Further, the Court noted that the same argument that found favour with the AAR in Citrix
Systems (AAR) (supra) was pressed into service by the learned senior counsel who appeared for the
Revenue in the case of Motorola (ITAT) (supra), and this was correctly turned down as follows:
“163. We may now briefly deal with the objections of Mr. G.C. Sharma, the learned
senior counsel for the Department. He contended that if a person owns a copyrighted
article then he automatically has a right over the copyright also. With respect, this
objection does not appear to us to be correct. Mr. Dastur filed an extract from
Iyengar's Copyright Act (3rd Edition) edited by R.G. Chaturvedi. The following
observations of the author are on the point:
“(h) Copyright is distinct from the material object, copyrighted:
It is an intangible incorporeal right in the nature of a privilege, quite independent of
any material substance, such as a manuscript. The copyright owner may dispose of it
on such terms as he may see fit. He has an individual right of exclusive enjoyment.
The transfer of the manuscript does not, of itself, serve to transfer the copyright
therein. The transfer of the ownership of a physical thing in which copyright exists
gives to the purchaser the right to do with it (the physical thing) whatever he pleases,
except the right to make copies and issue them to the public” (underline is ours).”
The above observations of the author show that one cannot have the copyright right
without the copyrighted article but at the same time just because one has the
copyrighted article, it does not follow that one has also the copyright in it. Mr.
Sharma's objection cannot be accepted.” (pages 365-366)
114. Referring to the High Court’s earlier judgments in Ericsson A.B. (supra) and Nokia Networks
OY (supra) and the determinations of the AAR in Dassault (AAR) (supra) and Geoquest (AAR)
(supra), the High Court concluded:
“87. In order to qualify as royalty payment, it is necessary to establish that there is
transfer of all or any rights (including the granting of any licence) in respect of
copyright of a literary, artistic or scientific work. In order to treat the consideration
paid by the Licensee as royalty, it is to be established that the licensee, by making
such payment, obtains all or any of the copyright rights of such literary work.
Distinction has to be made between the acquisition of a “copyright right” and a
“copyrighted article”. Copyright is distinct from the material object, copyrighted.
Copyright is an intangible incorporeal right in the nature of a privilege, quite
independent of any material substance, such as a manuscript. Just because one hasEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

the copyrighted article, it does not follow that one has also the copyright in it. It does
not amount to transfer of all or any right including licence in respect of copyright.
Copyright or even right to use copyright is distinguishable from sale consideration
paid for “copyrighted” article. This sale consideration is for purchase of goods and is
not royalty.
88. The license granted by the Assessee is limited to those necessary to enable the
licensee to operate the program.
The rights transferred are specific to the nature of computer programs. Copying the program onto
the computer's hard drive or random access memory or making an archival copy is an essential step
in utilizing the program. Therefore, rights in relation to these acts of copying, where they do no
more than enable the effective operation of the program by the user, should be disregarded in
analyzing the character of the transaction for tax purposes. Payments in these types of transactions
would be dealt with as business income in accordance with Article 7.
89. There is a clear distinction between royalty paid on transfer of copyright rights and
consideration for transfer of copyrighted articles. Right to use a copyrighted article or product with
the owner retaining his copyright, is not the same thing as transferring or assigning rights in
relation to the copyright. The enjoyment of some or all the rights which the copyright owner has, is
necessary to invoke the royalty definition. Viewed from this angle, a non-exclusive and non-
transferable licence enabling the use of a copyrighted product cannot be construed as an authority to
enjoy any or all of the enumerated rights ingrained in Article 12 of DTAA. Where the purpose of the
licence or the transaction is only to restrict use of the copyrighted product for internal business
purpose, it would not be legally correct to state that the copyright itself or right to use copyright has
been transferred to any extent. The parting of intellectual property rights inherent in and attached
to the software product in favour of the licensee/customer is what is contemplated by the Treaty.
Merely authorizing or enabling a customer to have the benefit of data or instructions contained
therein without any further right to deal with them independently does not, amount to transfer of
rights in relation to copyright or conferment of the right of using the copyright. The transfer of
rights in or over copyright or the conferment of the right of use of copyright implies that the
transferee/licensee should acquire rights either in entirety or partially co-extensive with the
owner/transferor who divests himself of the rights he possesses pro tanto.” (pages 385-386)
115. The High Court of Delhi also expressed its disagreement with the impugned judgment of the
High Court of Karnataka dated 15.10.2011, in CIT v. Samsung Electronics Co. Ltd., (2012) 345 ITR
494, as follows:
“96. The amount received by the Assessee under the licence agreement for allowing
the use of the software is not royalty under the DTAA.
97. What is transferred is neither the copyright in the software nor the use of the
copyright in the software, but what is transferred is the right to use the copyrighted
material or article which is clearly distinct from the rights in a copyright. The rightEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

that is transferred is not a right to use the copyright but is only limited to the right to
use the copyrighted material and the same does not give rise to any royalty income
and would be business income.
98. We are not in agreement with the decision of the [Karnataka] High Court in the
case of SAMSUNG ELECTRONICS CO. LTD (SUPRA) that right to make a copy of
the software and storing the same in the hard disk of the designated computer and
taking backup copy would amount to copyright work under section 14(1) of the
Copyright Act and the payment made for the grant of the licence for the said purpose
would constitute royalty. The license granted to the licensee permitting him to
download the computer programme and storing it in the computer for his own use
was only incidental to the facility extended to the licensee to make use of the
copyrighted product for his internal business purpose. The said process was
necessary to make the programme functional and to have access to it and is
qualitatively different from the right contemplated by the said provision because it is
only integral to the use of copyrighted product. The right to make a backup copy
purely as a temporary protection against loss, destruction or damage has been held
by the Delhi High Court in DIT v.
Nokia Networks OY (Supra) as not amounting to acquiring a copyright in the software.” (page 388)
116. Likewise, in CIT v. ZTE Corporation, (2017) 392 ITR 80 [“ZTE”],45 a Division Bench of the
High Court of Delhi dealt with the India-China DTAA and after referring to its earlier judgments,
held as follows:
“The misconception that the revenue harbors stems from its flawed appreciation of a
copyright license. True, “copyright” is not defined; yet what works are capable of
copyright protection is spelt out in the Copyright Act. Sections 13 and 14 of the
Copyright Act flesh out the essential ingredients that make copyright a property
right.” (page 93) “Thus, Section 14 categorically provides that copyright “means the
exclusive right to do or authorizing the doing of any of the acts mentioned in Section
14 (a) to (e) or any “substantial part thereof”. The content of copyright in respect of
computer programmes is spelt out in Section 14 (b). A joint reading of the controlling
provisions of the earlier part of Section 14 with clause (b) implies that in the case of
computer programs, copyright would mean the doing or authorizing the doing-in
respect of work (i.e. the programme) or any substantial part thereof —
(b) In the case of a computer programme,-
(i) to do any of the acts specified in clause (a) This judgment has been relied upon by various
judgments of the High Court of Delhi impugned in the appeals before us.
(ii) to sell or give on commercial rental or offer for sale or for commercial rental any copy of the
computer programme:Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

Provided that such commercial rental does not apply in respect of computer
programmes where the programme itself is not the essential object of the rental.
The reference to clause (a) and (b) means that all the rights which are in literary
works i.e.“(i) to reproduce the work in any material form including the storing of it in
any medium by electronic means; (ii) to issue copies of the work to the public not
being copies already in circulation; (iii) to perform the work in public, or
communicate it to the public; (iv) to make any cinematograph film or sound
recording in respect of the work; (v) to make any translation of the work; (vi) to make
any adaptation of the work; (vii) to do, in relation to a translation or an adaptation of
the work, any of the acts specified in relation to the work in sub clauses (i) to (vi)”
inhere in the owner of copyright of a computer programme. Therefore, the copyright
owner's rights are spelt out comprehensively by this provision. In the context of the
facts of this case, the assessee is the copyright proprietor; it made available, through
one time license fee, the software to its customers; this software without the
hardware which was sold, is useless. Conversely the hardware sold by the assessee to
its customers is also valueless and cannot be used without such software. This
analysis is to show that what was conveyed to its customers by the assessee bears a
close resemblance to goods-significantly enough, Section 14(1) talks of sale or rental
of a “copy”. The question of conveying or parting with copyright in the software itself
would mean that the copyright proprietor has to assign it, divesting itself of the title
implying that it has divested itself of all the rights under Section 14. This would mean
an outright sale of the copyright or assignment, under Section 18 of the Act. Section
16 of the Copyright Act enacts that there cannot be any other kind of right termed as
“copyright”.
In the present case, the facts are closely similar to Ericsson. The supplies made (of the software)
enabled the use of the hardware sold. It was not disputed that without the software, hardware use
was not possible. The mere fact that separate invoicing was done for purchase and other
transactions did not imply that it was royalty payment. In such cases, the nomenclature (of license
or some other fee) is indeterminate of the true nature. Nor is the circumstance that updates of the
software are routinely given to the assessee's customers. These facts do not detract from the nature
of the transaction, which was supply of software, in the nature of articles or goods. This court is also
not persuaded with the submission that the payments, if not royalty, amounted to payments for the
use of machinery or equipment. Such a submission was never advanced before any of the lower tax
authorities; moreover, even in Ericsson (supra), a similar provision existed in the DTAA between
India and Sweden.” (pages 95-96)
117. The conclusions that can be derived on a reading of the aforesaid judgments are as follows:
i) Copyright is an exclusive right, which is negative in nature, being a right to restrict
others from doing certain acts.Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

ii) Copyright is an intangible, incorporeal right, in the nature of a privilege, which is
quite independent of any material substance.
Ownership of copyright in a work is different from the ownership of the physical material in which
the copyrighted work may happen to be embodied. An obvious example is the purchaser of a book or
a CD/DVD, who becomes the owner of the physical article, but does not become the owner of the
copyright inherent in the work, such copyright remaining exclusively with the owner.
iii) Parting with copyright entails parting with the right to do any of the acts mentioned in section 14
of the Copyright Act. The transfer of the material substance does not, of itself, serve to transfer the
copyright therein. The transfer of the ownership of the physical substance, in which copyright
subsists, gives the purchaser the right to do with it whatever he pleases, except the right to
reproduce the same and issue it to the public, unless such copies are already in circulation, and the
other acts mentioned in section 14 of the Copyright Act.
iv) A licence from a copyright owner, conferring no proprietary interest on the licensee, does not
entail parting with any copyright, and is different from a licence issued under section 30 of the
Copyright Act, which is a licence which grants the licensee an interest in the rights mentioned in
section 14(a) and 14(b) of the Copyright Act. Where the core of a transaction is to authorize the
end-user to have access to and make use of the “licensed” computer software product over which the
licensee has no exclusive rights, no copyright is parted with and consequently, no infringement takes
place, as is recognized by section 52(1)(aa) of the Copyright Act. It makes no difference whether the
end-user is enabled to use computer software that is customised to its specifications or otherwise.
v) A non-exclusive, non-transferable licence, merely enabling the use of a copyrighted product, is in
the nature of restrictive conditions which are ancillary to such use, and cannot be construed as a
licence to enjoy all or any of the enumerated rights mentioned in section 14 of the Copyright Act, or
create any interest in any such rights so as to attract section 30 of the Copyright Act.
vi) The right to reproduce and the right to use computer software are distinct and separate rights, as
has been recognized in SBI v. Collector of Customs, 2000 (1) SCC 727 (see paragraph 21), the former
amounting to parting with copyright and the latter, in the context of non-exclusive EULAs, not being
so.
118. Consequently, the view contained in the determinations of the AAR in Dassault (AAR) (supra)
and Geoquest (AAR) (supra) and the judgments of the High Court of Delhi in Ericsson A.B. (supra),
Nokia Networks OY (supra), Infrasoft (supra), ZTE (supra), state the law correctly and have our
express approval. We may add that the view expressed in the aforesaid judgments and
determinations also accords with the OECD Commentary on which most of India’s DTAAs are
based.
DOCTRINE OF FIRST SALE/PRINCIPLE OF EXHAUSTIONEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

119. The learned Additional Solicitor General argued that on the facts of these cases, the doctrine of
first sale/principle of exhaustion would have no application inasmuch as this doctrine is not
statutorily recognised in section 14(b)(ii) of the Copyright Act. This being so, since the distributors
of copyrighted software “license” or sell such computer software to end-users, there would be a
parting of a right or interest in copyright inasmuch as such “license” or sale would then be hit by
section 14(b)(ii) of the Copyright Act.
120. As has been mentioned hereinabove, section 14(b)(ii) of the Copyright Act was amended twice,
first in 1994 and then again in 1999, with effect from 15.01.2000. Prior to the 1999 Amendment,
section 14(b)(ii) of the Copyright Act read as follows:
“(ii) to sell or give on hire, or offer for sale or hire any copy of the computer
programme, regardless of whether such copy has been sold or given on hire on earlier
occasions;” (emphasis supplied) After the 1999 Amendment, what is conspicuous by
its absence is the phrase “regardless of whether such copy has been sold or given on
hire on earlier occasions”. This is a statutory recognition of the doctrine of first
sale/principle of exhaustion.
121. The doctrine of first sale/principle of exhaustion is explained by the locus classicus on this
subject, Copinger and Skone James on Copyright (14th Edition) (1999), as follows:
“The distribution right: general. One of the acts restricted by the copyright in all work
is the issue of the original or copies of the work to the public, often called the
“distribution right”. This right is provided for in section 18 of the 1988 Act.
Infringement of the distribution right is a primary infringement under UK law, and
so there is no need to prove knowledge or reason to believe that the copy in question
is infringing. Thus it is a powerful weapon against those at the top of a chain of
distribution. In accordance with general principles, section 18 must be interpreted so
far as possible in such a way as to conform with relevant EU Directives, in this
instance, the Software Directive and the Information Society Directive. Recent case
law of the CJEU has made a conforming interpretation more difficult. An important
aspect of the distribution right is that it is exhausted in relation to a particular article
by the first sale (and, in the case of the Information Society Directive, the first
transfer of ownership) of that article in the Community by the rightholder or with his
consent. For the purposes of the Software Directive, certain forms of distribution of
electronic copies are considered to exhaust the distribution right in respect of such
copies.” (pages 613-614) “Exhaustion of the distribution right: tangible objects.
Exhaustion applies to the tangible object into which a protected work or its copy is
incorporated if it has been placed on the market with the copyright holder’s consent.
In the case of artistic works, the consent of the copyright holder does not cover the
distribution of an object incorporating his work if that object has been altered after
its initial marketing in such a way that it constitutes a new reproduction of the work;
in such an event, the distribution right is exhausted only upon the first sale or
transfer of ownership of that new object with the consent of the rightholder.Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

Accordingly, where a defendant (without the licence of the rightholder) transferred
an image of a work of a famous painter from a poster onto canvas by physically lifting
the ink from the poster, producing a result closer to the original and leaving a blank
piece of paper behind, and this amounted to copying, the rightholder’s distribution
right had not been exhausted.
Exhaustion: computer programs. Similar considerations apply in relation to tangible
copies of computer programs as to other works: the first sale of a copy of a program
by the rightholder or with his consent exhausts the distribution right with the
exception of the right to control further rental of the program or a copy thereof. As to
copies made available in intangible form (e.g. by downloading from a website), for
these purposes the word “sale” is to be given an autonomous Community
interpretation. Where a seller makes a program available for download under a
licence for an unlimited period in return for a licence fee, the intention is to make the
copy usable by the customer, permanently, in return for payment of a fee designed to
enable the copyright owner to obtain a remuneration corresponding to the economic
value of the copy of the work. Accordingly, that amounts to a transfer of the right of
ownership of the copy in question and thus a sale for the purposes of the exhaustion
of the distribution right. The same applies if the copy is made available by means of a
material medium such as a CD- ROM or DVD and if the download is free but the
licence is granted and paid for separately. It does not matter if the software is the
subject of a maintenance agreement: the exhaustion applies to the copy as corrected
and updated pursuant to the agreement. Any other interpretation would undermine
the effectiveness of article 4(2) of the Directive since suppliers would merely have to
call a contract a licence rather than a sale in order to circumvent the rule of
exhaustion and divest it of all scope. The result is that a purchaser from the original
licensee and any subsequent acquirer are lawful acquirers of the software for the
purposes of article 5(1) of the Software Directive and benefit from the right of
reproduction provided for in that provision.” (pages 621-622)
122. In Warner Bros. Entertainment Inc. v. Santosh V.G., CS (OS) No. 1682/2006 [“Warner Bros.”]
reported in 2009 SCC OnLine Del 835, a Single Judge of the High Court of Delhi dealt with
copyright in a cinematograph film, as a result of which, section 14(d)(ii) of the Copyright Act, before
it was amended in 2012,46 came up for consideration. The said section, prior to being amended in
2012, read as follows:
“14. Meaning of Copyright.— For the purposes of this Act, “copyright” means the
exclusive right subject to the provisions of this Act, to do or authorise the doing of
any of By Act 27 of 2012, s. 5(ii)(b) (w.e.f. 21.06.2012).
the following acts in respect of a work or any substantial part thereof, namely xxx xxx
xxx
(d) in the case of a cinematograph film,— xxx xxx xxxEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

(ii) to sell or give on hire or offer for sale or hire, any copy of the film, regardless of
whether such copy has been sold or given on hire on earlier occasion”
123. The learned Single Judge of the High Court of Delhi explained the principle of exhaustion as
follows:
“57. The doctrine of exhaustion of copyright enables free trade in material objects on
which copies of protected works have been fixed and put into circulation with the
right holder's consent. The “exhaustion” principle in a sense arbitrates the conflict
between the right to own a copy of a work and the author's right to control the
distribution of copies. Exhaustion is decisive with respect to the priority of ownership
and the freedom to trade in material carriers on the condition that a copy has been
legally brought into trading. Transfer of ownership of a carrier with a copy of a work
fixed on it makes it impossible for the owner to derive further benefits from the
exploitation of a copy that was traded with his consent. The exhaustion principle is
thus termed legitimate by reason of the profits earned for the ownership transfer,
which should be satisfactory to the author if the work is not being exploited in a
different exploitation field.
58. Exhaustion of rights is linked to the distribution right. The right to distribute
objects (making them available to the public) means that such objects (or the
medium on which a work is fixed) are released by or with the consent of the owner as
a result of the transfer of ownership. In this way, the owner is in control of the
distribution of copies since he decides the time and the form in which copies are
released to the public. Content-wise the distribution right are to be understood as an
opportunity to provide the public with copies of a work and put them into circulation,
as well as to control the way the copies are used. The exhaustion of rights principle
thus limits the distribution right, by excluding control over the use of copies after
they have been put into circulation for the first time.” (emphasis in original)
124. The learned Single Judge then arrived at the following conclusion:
“62. … The court is of opinion therefore that the existence or applicability of the
“exhaustion” principle cannot be inferred automatically; it would have to depend on
the situation, and the structure of the legislation in question.”
125. Coming to section 14(a)(ii) of the Copyright Act, the learned Single Judge then held:
“63. The defendant in this case, accepts that the renting/hiring of films carried on by
it is without the plaintiffs' license. The Plaintiffs urge that since the importation, for
the purpose of renting of these cinematographic films has not been authorized by
them in India, the copies are infringing copies. Hence their import would be barred
under Section 51(b)(iv). The defendant's argument, however, is that the copies were
legitimately purchased in the course of trade; they are rental copies, and can be usedEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

for purpose of renting, in India. He says that the device of zoning, whereby the
plaintiffs restrict the licensee owner to use it in territories other than what is
indicated by them, is artificial, and unenforceable. Such “long arm” conditions are
inapplicable. Particular reference is made to the explanation to Section 14, which
describes the content of copyright; it clarifies that “For the purposes of this section, a
copy which has been sold once shall be deemed to be a copy already in circulation.”
Though attractive, this contention is unfeasible for more than one reason. The
reference to copies in circulation is in the context of copyright in literary, artistic,
dramatic or musical work, — not computer programme — (Section 14(a); the statute
enables the copyright owner to “issue copies of the work to the public not being
copies already in circulation”. But for the explanation, it could arguably be said that
the copyright owner lost his domain, or right to control the manner of further dealing
in copies which were in circulation. Yet, a careful reading of Section 14 would reveal
that the content of copyrights in respect of each nature of work (literary, dramatic, or
musical work, on the one hand, computer programme, artistic work, cinematograph
film, etc on the other) are distinct — evident from the listing out of such rights,
separately, in clauses (a) to (f) of the section. The reference to “copies in circulation”
has to be therefore, in the context; the phrase is used to limit the copyright owner's
right to dictate further use of a literary, musical and dramatic work (Section
14(a)(ii)). None of the owners of other classes of work are subject to that limitation.
The restriction of one class of copyright owner, structured in the statute serves a dual
purpose- it limits the owner of that class of copyright; and at the same time leaves it
open to the copyright owner of other kinds of work, to place such restrictions.”
(emphasis in original)
126. Contrasting the aforesaid with section 14(d)(ii) of the Copyright Act, as it stood prior to the
amendment in 2012, the learned Single Judge then went on to hold:
“64. The second reason is that Section 14(1)(d) provides that the copyright owner has,
in case of cinematographic films, the exclusive right to sell or give on hire or offer for
sale or hire, any copy of the film, regardless of whether such copy has been sold or
given on hire on earlier occasion. The copyright owner, therefore continues to be
entitled to exercise rights in a particular copy of the film regardless of whether it has
been sold previously- in express contrast to literary works, which are “already in
circulation”. This is reinforced by Section 51(b)(i), which unambiguously provides
that copyright in a work shall be infringed if a person does anything the exclusive
right do which is by the Act, conferred upon the owner of the copyright; it is also
emphasized by Section 51(b)(i) which makes for sale or hire, or sells or lets for hire,
or by way of trade displays or offers for sale or hire, any infringing copies of the work.
The proviso, crucially, exempts from the definition importation of a single infringing
copy for “the private and domestic use of the importer”. As noted earlier, importation
of a copy into India, in contravention of the Act — for instance, without the license, or
authorization of the copyright owner, is an infringement; such copy is an infringing
copy under Section 2(m).” (emphasis in original)Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

127. Thus, the Single Judge concluded:
“67. The express indication in Section 14(a)(ii) that a copyright owner of literary
works cannot exercise domain over copies in circulation, shows that exhaustion, if
one may term it, applies only in relation to the class of copyrights in Section 14(a) and
to the extent specified in clause (ii). Thus, the copyright owner of a literary work,
cannot dictate how and under what conditions a copy can be re-sold, once it is
“circulated”. This limited “exhaustion” negates the applicability of the principle in
regard to other classes of copyrights. Thus, Parliament having intervened in one
category of copyrights to grant a limited kind of “exhaustion” and consciously chosen
not to extend it to others, sleight of judicial reasoning cannot extend its application…”
128. However, the learned Additional Solicitor General relied upon the judgment of another learned
Single Judge of the High Court of Delhi who had occasion to consider the aforesaid doctrine in John
Wiley & Sons Inc. v. Prabhat Chander Kumar Jain, IA No. 11331/2008 in CS(OS) No. 1960/2008
reported in 2010 SCC OnLine Del 2000. The case involved the sale of low-priced editions of books
meant for the Indian market in foreign territories, contrary to the terms prescribed by the copyright
licence. After referring to a number of authorities, the learned Single Judge held:
“68. The legal propositions which emanate from this discussion are as under:
a) That the court will measure the infringement of the copyright from the rights of
the owner of the copyright when the owner is before the court for violation of its
rights.
b) That the rights of the owner may be broader than the limited rights of the exclusive
licencee, although the exclusive licencee has the independent right to sue for
infringement of the copyright.
c) The rights of the owner and exclusive licencee may not be the same and the rights
of the exclusive licensee shall also be subject to the fetters imposed by the agreement
between the licensor and licencee.
69. Applying these principles to the present case, it can be seen that the plaintiff no. 1, 3 and 5 are
the worldwide owners of the books and their copyright as mentioned and averred in the plaint. The
plaintiff nos. 2, 4 and 6 are the exclusive licensees licensed to publish the said books in India and
other territories. The plaintiffs' grievance is that Defendant no. 3 Technischer Overseas Pvt. Ltd.
which is a bookseller in Delhi is purchasing the said Low Price Editions of the books meant for the
Indian market and the territories defined from the plaintiffs no. 2, 4, 6 and is offering the said low
prize books from the websites www.alibris.com, www.biblio.com to territories outside the prescribed
ones on the book is infringing the copyright of the plaintiffs.
70. The said acts of the defendants of purchase of the books from the exclusive licensees/licensees
are legitimate in nature and do not hinder or take away anyone's rights including the rights ofEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

exclusive licensees/licensee. But once the said defendant no. 3 offers for sale the books or
publications (which are fettered by territorial restrictions purchased from exclusive licensees) and
puts them into circulation by selling or offering for sale or by taking orders for sale to the territories
beyond the ones for which permission has been granted by the owners of the copyright, the said acts
are prima facie tantamount to putting into circulation or issuance of copies not being in circulation
in other territories where the right to do so is of the owner to exercise and violates the rights of the
owner of the copyright under Section 14 read with Section 51 of the Act, if not the rights of the
exclusive licensee. In other words, the said acts of selling the books from India or offering for sale
from India through website and thereafter accepting the money and couriering the books to an
unauthorized territory will violate the right of the owners of the copyright which are plaintiff no. 1, 3,
5 to issue the copies to the public not already in circulation (not of exclusive licensees) and thus will,
prima facie, infringe their copyright.
xxx xxx xxx
79. The said position of the licensee is equally applicable in cases of computer software and is seen
in normal course when anyone purchases the software. Computer software are mostly licensed and
are sold and distributed with their own conditions and limitations. The purchasers of the said
computer software either from the owner or from the licensee is aware of the arrangement or license
agreement that the said computer software for instance is meant for single user or multiple usage.
The said purchaser is within notice while making purchase of the said software and is thus bound by
the said conditions of the license. Once the said purchaser violates the condition of the said license,
he/she becomes liable for infringement of copyright of the owner.
80. Likewise is the case with the books in the present matter. Once the defendants purchase the Low
Price Editions books of the plaintiffs from their exclusive licensee, they are conscious of the fact that
the said editions are subject to territorial restrictions which are meant to be sold within the limited
territories only. The notice on the book itself gives knowledge to the purchaser about the said
territorial restriction. The said knowledge is also evident when the defendant themselves offer the
same books to the customers outside the territories while representing that “it is an international
edition in paperback. The contents are identical to the American Edition, word for word. The ISBN
differs from the American Edition and the book is in black and white but the contents are
completely same as the American Edition at a great price.””
129. The learned Single Judge then embarked upon a discussion of the doctrine of first
sale/principle of exhaustion, finding the absence of an express provision in the Copyright Act
recognising international exhaustion, and summed up its impact in the context of the facts before
him as follows:
“100. a) At the outset, again, I would like to reiterate the three propositions a) the
meaning of copyright has been defined under Section 14 of the Copyright Act as is
clear from the opening words of the Section; b) The rights of the owner have to be
looked into as per Section 51 of the Act while measuring infringement; c) The rights
of the owner may be broader than that of the licensee. In the present case, the firstEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

sale has been effected by the exclusive licensees plaintiff nos. 2, 4, 6 and their rights
are limited and are subject to the conditions and limitations imposed by the
agreement. That being so, the applicability of the first sale doctrine qua the sales
effected by the exclusive licensee to the defendants will at best exhaust the rights of
the exclusive licensees to complain and not the rights of the owner. The right of the
owner to complain for remaining infringement in unauthorised territories for
violation of the permission granted and violation of the rights will remain intact.
Thus, the applicability of first sale doctrine will partially exhaust the rights of the
licencee and not of the owner of the copyright i.e. plaintiff nos. 1, 3 and 5.
xxx xxx xxx
104. The discussion makes it apparent that the learned single judge has doubted the
mode of the applicability of the first sales doctrine in India as per the existing law.
The same may lead to partial or regional exhaustion or international exhaustion. As
per my opinion, as the express provision for international exhaustion is absent in our
Indian law, it would be appropriate to confine the applicability of the same to
regional exhaustion. Be that as it may, in the present case, the circumstances do not
even otherwise warrant this discussion as the rights if at all are exhausted are to the
extent to which they are available with the licensees as the books are purchased from
the exclusive licensees who have limited rights and not from the owner. In these
circumstances, the question of exhaustion of rights of owner in the copyright does not
arise at all.”
130. Thus, since copies of the low-priced editions could not be said to be “copies already in
circulation” in the foreign territories that they were resold in, the learned Single Judge concluded
that the principle of exhaustion would not apply. On the other hand, in the facts of the appeals
before us, the distributors resell shrink-wrapped copies of the computer programmes that are
already put in circulation by foreign, non- resident suppliers/manufacturers, since they have been
sold and imported into India via distribution agreements, and are thus not hit by section 14(a)(ii) of
the Copyright Act. This is made clear by the explanation to section 14 of the Copyright Act, which
states as follows:
“Explanation.--For the purposes of this section, a copy which has been sold once shall
be deemed to be a copy already in circulation.”
131. In UsedSoft GmbH v. Oracle International Corp. (Case C-128/11) [“UsedSoft v. Oracle (ECJ)”],
the European Court of Justice [“ECJ”] was concerned with Article 4 of Directive 2001/29/EC of the
European Parliament and of the Council of 22 May 2001 on the harmonisation of certain aspects of
copyright and related rights in the information society [“EC Directive 2001/29”], which provides as
follows:
“Article 4 Distribution rightEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

1. Member States shall provide for authors, in respect of the original of their works or
of copies thereof, the exclusive right to authorise or prohibit any form of distribution
to the public by sale or otherwise.
2. The distribution right shall not be exhausted within the Community in respect of
the original or copies of the work, except where the first sale or other transfer of
ownership in the Community of that object is made by the rightholder or with his
consent.”
132. Coming to Article 4(2) of EC Directive 2001/29, the ECJ posed a question, thus:
“35. By its second question, which should be addressed first, the referring court
essentially seeks to know whether and under what conditions the downloading from
the internet of a copy of a computer program, authorised by the copyright holder, can
give rise to exhaustion of the right of distribution of that copy in the European Union
within the meaning of Article 4(2) of Directive 2009/24.
36. It should be recalled that under Article 4(2) of Directive 2009/24 the first sale in
the European Union of a copy of a computer program by the rightholder or with his
consent exhausts the distribution right within the European Union of that copy.
37. According to the order for reference, the copyright holder itself, in this case
Oracle, makes available to its customers in the European Union who wish to use its
computer program a copy of that program which can be downloaded from its website.
38. To determine whether, in a situation such as that at issue in the main
proceedings, the copyright holder’s distribution right is exhausted, it must be
ascertained, first, whether the contractual relationship between the rightholder and
its customer, within which the downloading of a copy of the program in question has
taken place, may be regarded as a ‘first sale … of a copy of a program’ within the
meaning of Article 4(2) of Directive 2009/24.”
133. Concluding that the transfer of a copy of a computer programme, accompanied by the
conclusion of an EULA constituted a “first sale… of a copy of a program” within the meaning of
Article 4(2) of EC Directive 2001/29 (see paragraph 48), the ECJ then went on to describe the
principle of exhaustion as follows:
“70. An original acquirer who resells a tangible or intangible copy of a computer
program for which the copyright holder’s right of distribution is exhausted in
accordance with Article 4(2) of Directive 2009/24 must, in order to avoid infringing
the exclusive right of reproduction of a computer program which belongs to its
author, laid down in Article 4(1)(a) of Directive 2009/24, make his own copy
unusable at the time of its resale. In a situation such as that mentioned in the
preceding paragraph, the customer of the copyright holder will continue to use theEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

copy of the program installed on his server and will not thus make it unusable.
71. Moreover, even if an acquirer of additional user rights for the computer program
concerned did not carry out a new installation — and hence a new reproduction — of
the program on a server belonging to him, the effect of the exhaustion of the
distribution right under Article 4(2) of Directive 2009/24 would in any event not
extend to such user rights. In such a case the acquisition of additional user rights
does not relate to the copy for which the distribution right was exhausted at the time
of that transaction. On the contrary, it is intended solely to make it possible to extend
the number of users of the copy which the acquirer of additional rights has himself
already installed on his server.
72. On the basis of all the foregoing, the answer to Question 2 is that Article 4(2) of
Directive 2009/24 must be interpreted as meaning that the right of distribution of a
copy of a computer program is exhausted if the copyright holder who has authorised,
even free of charge, the downloading of that copy from the internet onto a data
carrier has also conferred, in return for payment of a fee intended to enable him to
obtain a remuneration corresponding to the economic value of the copy of the work
of which he is the proprietor, a right to use that copy for an unlimited period.”
134. The ECJ concluded that the copyright owner exhausts his distribution right in copies of a
computer programme upon making the first sale, provided that the copy is made unusable by the
first acquirer, as follows:
“78. Admittedly, as stated in paragraph 70 above, the original acquirer of a tangible
or intangible copy of a computer program for which the copyright holder’s
distribution right is exhausted in accordance with Article 4(2) of Directive 2009/24
who resells that copy must, in order to avoid infringing that rightholder’s exclusive
right of reproduction of his computer program under Article 4(1)(a) of Directive
2009/24, make the copy resale.
79. As Oracle rightly observes, ascertaining whether such a copy has been made
unusable may prove difficult. However, a copyright holder who distributes copies of a
computer program on a material medium such as a CDROM or DVD is faced with
the same problem, since it is only with great difficulty that he can make sure that the
original acquirer has not made copies of the program which he will continue to use
after selling his material medium. To solve that problem, it is permissible for the
distributor — whether ‘classic’ or ‘digital’ — to make use of technical protective
measures such as product keys.
80. Since the copyright holder cannot object to the resale of a copy of a computer
program for which that rightholder’s distribution right is exhausted under Article
4(2) of Directive 2009/24, it must be concluded that a second acquirer of that copy
and any subsequent acquirer are ‘lawful acquirers’ of it within the meaning of ArticleEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

5(1) of Directive 2009/24.
81. Consequently, in the event of a resale of the copy of the computer program by the
first acquirer, the new acquirer will be able, in accordance with Article 5(1) of
Directive 2009/24, to download onto his computer the copy sold to him by the first
acquirer. Such a download must be regarded as a reproduction of a computer
program that is necessary to enable the new acquirer to use the program in
accordance with its intended purpose.”
135. The learned Additional Solicitor General, however, strongly relied upon the decision of the
United States Court of Appeals for the Ninth Circuit in Vernor v. Autodesk, Inc., 621 F.3d 1102 (9th
Cir. 2010), wherein it dealt with the doctrine of first sale/principle of exhaustion. The facts of the
case were set out as follows:
“A. Autodesk's Release 14 software and licensing practices The material facts are not
in dispute. Autodesk makes computer-aided design software used by architects,
engineers, and manufacturers. It has more than nine million customers. It first
released its AutoCAD software in 1982. It holds registered copyrights in all versions
of the software including the discontinued Release 14 version, which is at issue in this
case. It provided Release 14 to customers on CD-ROMs.
Since at least 1986, Autodesk has offered AutoCAD to customers pursuant to an
accompanying software license agreement (“SLA”), which customers must accept
before installing the software. A customer who does not accept the SLA can return
the software for a full refund. Autodesk offers SLAs with different terms for
commercial, educational institution[s], and student users. The commercial license,
which is the most expensive, imposes the fewest restrictions on users and allows
them software upgrades at discounted prices.
The SLA for Release 14 first recites that Autodesk retains title to all copies. Second, it
states that the customer has a nonexclusive and nontransferable license to use
Release
14. Third, it imposes transfer restrictions, prohibiting customers from renting,
leasing, or transferring the software without Autodesk's prior consent and from
electronically or physically transferring the software out of the Western Hemisphere.
Fourth, it imposes significant use restrictions:
YOU MAY NOT: (1) modify, translate, reverse engineer, decompile, or disassemble
the Software … (3) remove any proprietary notices, labels, or marks from the
Software or Documentation; (4) use the Software outside of the Western
Hemisphere; (5) utilize any computer software or hardware designed to defeat any
hardware copy-protection device, should the software you have licensed be equipped
with such protection; or (6) use the Software for commercial or other revenue-Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

generating purposes if the Software has been licensed or labeled for educational use only.
Fifth, the SLA provides for license termination if the user copies the software without authorization
or does not comply with the SLA's restrictions. Finally, the SLA provides that if the software is an
upgrade of a previous version:
[Y]ou must destroy the software previously licensed to you, including any copies
resident on your hard disk drive ․ within sixty (60) days of the purchase of the
license to use the upgrade or update․ Autodesk reserves the right to require you to
show satisfactory proof that previous copies of the software have been destroyed.
Autodesk takes measures to enforce these license requirements. It assigns a serial
number to each copy of AutoCAD and tracks registered licensees. It requires
customers to input “activation codes” within one month after installation to continue
using the software.1 The customer obtains the code by providing the product's serial
number to Autodesk. Autodesk issues the activation code after confirming that the
serial number is authentic, the copy is not registered to a different customer, and the
product has not been upgraded. Once a customer has an activation code, he or she
may use it to activate the software on additional computers without notifying
Autodesk.”’ (pages 1104-1105)
136. The Court noted that the application of the doctrine turned on the following question:
“This case requires us to decide whether Autodesk sold Release 14 copies to its
customers or licensed the copies to its customers. If CTA owned its copies of Release
14, then both its sales to Vernor and Vernor's subsequent sales were non-infringing
under the first sale doctrine. However, if Autodesk only licensed CTA to use copies of
Release 14, then CTA's and Vernor's sales of those copies are not protected by the
first sale doctrine and would therefore infringe Autodesk's exclusive distribution
right.” (page 1107) (emphasis supplied)
137. On these facts, the doctrine of first sale/principle of exhaustion, as applicable in USA, was set
out as follows:
“A. The first sale doctrine The Supreme Court articulated the first sale doctrine in
1908, holding that a copyright owner's exclusive distribution right is exhausted after
the owner's first sale of a particular copy of the copyrighted work. See Bobbs-Merrill
Co. v. Straus, 210 U.S. 339, 350-51 (1908). In Bobbs-Merrill, the plaintiff-copyright
owner sold its book with a printed notice announcing that any retailer who sold the
book for less than one dollar was responsible for copyright infringement. (Id. at
341). Plaintiff sought injunctive relief against defendants-Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

booksellers who failed to comply with the price restriction. (Id. at 341-42). The Supreme Court
rejected the plaintiff's claim, holding that its exclusive distribution right applied only to first sales of
copies of the work. (Id. at 350-51). The distribution right did not permit [the] plaintiff to dictate that
subsequent sales of the work below a particular price were infringing. Id. The Court noted that its
decision solely applied to the rights of a copyright owner that distributed its work without a license
agreement. (Id. at 350) (“There is no claim in this case of contract limitation, nor license agreement
controlling the subsequent sales of the book.”). Congress codified the first sale doctrine the following
year. See 17 U.S.C. § 41 (1909). In its current form, it allows the “owner of a particular copy” of a
copyrighted work to sell or dispose of his copy without the copyright owner's authorization. (Id. §
109(a) (enacted 1976)). The first sale doctrine does not apply to a person who possesses a copy of the
copyrighted work without owning it, such as a licensee. See id. § 109(d); cf. Quality King Distribs.,
Inc. v. L'Anza Research Int'l Inc., 523 U.S. 135, 146-47 (1998) (“[T]he first sale doctrine would not
provide a defense to ․ any non-owner such as a bailee, a licensee, a consignee, or one whose
possession of the copy was unlawful.”).” (pages 1107-1108)
138. Given the restrictions specifically imposed by the software licence agreement in the facts of the
case, the Court held that the copyright owner retained the title to the copies of the software, and
thus the resale of such copies violated the distribution right of the copyright owner, as follows:
“B. Analysis We hold today that a software user is a licensee rather than an owner of a
copy where the copyright owner (1) specifies that the user is granted a license; (2)
significantly restricts the user's ability to transfer the software; and (3) imposes
notable use restrictions.12 Applying our holding to Autodesk's SLA, we conclude that
CTA was a licensee rather than an owner of copies of Release 14 and thus was not
entitled to invoke the first sale doctrine or the essential step defense.
Autodesk retained title to the software and imposed significant transfer restrictions:
it stated that the license is non-transferable, the software could not be transferred or
leased without Autodesk's written consent, and the software could not be transferred
outside the Western Hemisphere. The SLA also imposed use restrictions against the
use of the software outside the Western Hemisphere and against modifying,
translating, or reverse-engineering the software, removing any proprietary marks
from the software or documentation, or defeating any copy protection device.
Furthermore, the SLA provided for termination of the license upon the licensee's
unauthorized copying or failure to comply with other license restrictions. Thus,
because Autodesk reserved title to Release 14 copies and imposed significant transfer
and use restrictions, we conclude that its customers are licensees of their copies of
Release 14 rather than owners.
CTA was a licensee rather than an “owner of a particular copy” of Release 14, and it
was not entitled to resell its Release 14 copies to Vernor under the first sale doctrine.
17 U.S.C. § 109(a). Therefore, Vernor did not receive title to the copies from CTA and
accordingly could not pass ownership on to others. Both CTA's and Vernor's salesEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

infringed Autodesk's exclusive right to distribute copies of its work. Id. § 106(3).”
(pages 1111-1112)
139. As a result, given the conditions of the software licence agreement in the facts before it, the
Court held that the doctrine of first sale would not apply, as Autodesk, the copyright owner, did not
part with title to the copies of the software. On the other hand, as has been held in paragraph 52 of
this judgment, the EULAs and distribution agreements that the appeals before us are concerned
with, do not grant a licence in terms of section 30 of the Copyright Act, but do in fact convey title to
the material object embedded with a copy of the computer software to the distributors/end-users.
140. A conspectus of the aforesaid authorities would show that the doctrine of first sale/principle of
exhaustion is dependent, in the first place, upon legislation which either recognises or refuses to
recognise the doctrine (thereby continuing to vest distribution rights in the copyright owner, even
beyond the first sale of the copyrighted work). Thus, for example, prior to the amendment of section
14(d)(ii) in 2012, dealing with a cinematograph film, the distribution right to sell or give on hire or
offer for sale or hire, any copy of the film, would continue to vest in the copyright owner, “regardless
of whether such copy ha[d] been sold or given on hire on earlier occasion”, which manifested the
legislative intent against the application of the doctrine of first sale/principle of exhaustion. Post
2012, however, the balance between the copyright owner’s distribution right and the right of the
purchaser to further resale, was tilted in favour of the latter, the words “regardless of whether such
copy has been sold or given on hire on earlier occasion” being deleted by the amendment. Likewise,
when it comes to section 14(a)(ii) of the Copyright Act, the distribution right subsists with the owner
of copyright to issue copies of the work to the public, to the extent such copies are not copies already
in circulation, thereby manifesting a legislative intent to apply the doctrine of first sale/principle of
exhaustion, as has been found by the High Court of Delhi in Warner Bros. (supra).
141. Like section 14(d)(ii) of the Copyright Act, section 14(b)(ii), has, after the 1999 Amendment,
with effect from 15.01.2000, also deleted the words “regardless of whether such copy has been sold
or given on hire on earlier occasions'', thereby making it clear that the same tilt that had been made
in section 14(d)(ii) of the Copyright Act vide the amendment in 2012 in favour of the purchaser, is
also to be found post the 1999 Amendment, in section 14(b)(ii) of the Copyright Act.
142. The language of section 14(b)(ii) of the Copyright Act makes it clear that it is the exclusive right
of the owner to sell or to give on commercial rental or offer for sale or for commercial rental “any
copy of the computer programme”. Thus, a distributor who purchases computer software in material
form and resells it to an end-user cannot be said to be within the scope of the aforesaid provision.
The sale or commercial rental spoken of in section 14(b)(ii) of the Copyright Act is of “any copy of a
computer programme”, making it clear that the section would only apply to the making of copies of
the computer programme and then selling them, i.e., reproduction of the same for sale or
commercial rental.
143. The object of section 14(b)(ii) of the Copyright Act, in the context of a computer program, is to
interdict reproduction of the said computer programme and consequent transfer of the reproduced
computer programme to subsequent acquirers/end-users. By way of contrast, once a book is sold,Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

on further resale of the same book, the purchaser loses the material book altogether, as such
purchaser has, for consideration, parted with the book once and for all. This may not be so in the
case of a computer programme, which is why the ECJ in UsedSoft v. Oracle (ECJ) (supra) held that
unless a further resale of a computer software stored on a floppy disc/CD is accompanied by the
destruction of the said software on the computer of the reseller/first acquirer, the copyright owner’s
rights would be easily infringed by mere reproduction thereof. This is also recognised in section 65A
of the Copyright Act which punishes the circumvention of technological protection measures, such
as encryption codes, product keys etc. designed to ensure that the first acquirer’s copy is made
unusable. Thus, once it is understood that the object of section 14(b)(ii) of the Copyright Act is not
to interdict the sale of computer software that is “licensed” to be sold by a distributor, but that it is
to prevent copies of computer software once sold being reproduced and then transferred by way of
sale or otherwise, it becomes clear that any sale by the author of a computer software to a distributor
for onward sale to an end-user, cannot possibly be hit by the said provision. Further, as has rightly
been pointed out by Shri S. Ganesh, learned Senior Advocate appearing on behalf of Sonata
Information Technology Ltd. in C.A. Nos. 8737- 8941/2018, the distributor cannot use the computer
software at all and has to pass on the said software, as shrink-wrapped by the owner, to the end-user
for a consideration, the distributor’s profit margin being that of an intermediary who merely resells
the same product to the end-user.
144. For all these reasons, we cannot accede to the argument made by the learned Additional
Solicitor General that the distribution of copyrighted computer software, on the facts of the appeals
before us, would constitute the grant of an interest in copyright under section 14(b)(ii) of the
Copyright Act, thus necessitating the deduction of tax at source under section 195 of the Income Tax
Act.
INTERPRETATION OF TREATIES, OECD COMMENTARY AND THE REVENUE’S OWN
UNDERSTANDING
145. The DTAAs that have been entered into by India with other Contracting States have to be
interpreted liberally with a view to implement the true intention of the parties. This Court, in Azadi
Bachao Andolan (supra) put it thus:
“98. In John N. Gladden v. Her Majesty the Queen [85 DTC 5188 at p. 5190] the
principle of liberal interpretation of tax treaties was reiterated by the Federal Court,
which observed:
“Contrary to an ordinary taxing statute a tax treaty or convention must be given a
liberal interpretation with a view to implementing the true intentions of the parties. A
literal or legalistic interpretation must be avoided when the basic object of the treaty
might be defeated or frustrated insofar as the particular item under consideration is
concerned.”” “Interpretation of treaties
130. The principles adopted in interpretation of treaties are not the same as those in
interpretation of a statutory legislation. While commenting on the interpretation of aEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

treaty imported into a municipal law, Francis Bennion observes:
“With indirect enactment, instead of the substantive legislation taking the
well-known form of an Act of Parliament, it has the form of a treaty. In other words,
the form and language found suitable for embodying an international agreement
become, at the stroke of a pen, also the form and language of a municipal legislative
instrument. It is rather like saying that, by Act of Parliament, a woman shall be a
man. Inconveniences may ensue. One inconvenience is that the interpreter is likely to
be required to cope with disorganised composition instead of precision drafting. The
drafting of treaties is notoriously sloppy usually for a very good reason. To get
agreement, politic uncertainty is called for.
… The interpretation of a treaty imported into municipal law by indirect enactment
was described by Lord Wilberforce as being ‘unconstrained by technical rules of
English law, or by English legal precedent, but conducted on broad principles of
general acceptation. This echoes the optimistic dictum of Lord Widgery, C.J. that the
words ‘are to be given their general meaning, general to lawyer and layman alike …
the meaning of the diplomat rather than the lawyer’.” [Francis Bennion:
Statutory Interpretation, p. 461 [Butterworths, 1992 (2nd Edn.)].]
131. An important principle which needs to be kept in mind in the interpretation of
the provisions of an international treaty, including one for double taxation relief, is
that treaties are negotiated and entered into at a political level and have several
considerations as their bases. Commenting on this aspect of the matter, David R.
Davis in Principles of International Double Taxation Relief [ David R. Davis:
Principles of International Double Taxation Relief, p. 4 (London, Sweet & Maxwell,
1985).] , points out that the main function of a Double Taxation Avoidance Treaty
should be seen in the context of aiding commercial relations between treaty partners
and as being essentially a bargain between two treaty countries as to the division of
tax revenues between them in respect of income falling to be taxed in both
jurisdictions. It is observed (vide paragraph 1.06):
“The benefits and detriments of a double tax treaty will probably only be truly
reciprocal where the flow of trade and investment between treaty partners is
generally in balance. Where this is not the case, the benefits of the treaty may be
weighed more in favour of one treaty partner than the other, even though the
provisions of the treaty are expressed in reciprocal terms. This has been identified as
occurring in relation to tax treaties between developed and developing countries,
where the flow of trade and investment is largely one-way. Because treaty
negotiations are largely a bargaining process with each side seeking concessions from
the other, the final agreement will often represent a number of compromises, and it
may be uncertain as to whether a full and sufficient quid pro quo is obtained by bothEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

sides.” And, finally, in paragraph 1.08:
“Apart from the allocation of tax between the treaty partners, tax treaties can also
help to resolve problems and can obtain benefits which cannot be achieved
unilaterally.””
146. Further, the House of Lords in Ostime (Inspector of Taxes) v. Australian Mutual Provident
Society, [1959] AC 259 by a judgment dated 16.07.1959 remarked upon, what it termed the
“international tax language” of bilateral taxation agreements, as follows :
“Bilateral agreements for regulating some of the problems of double taxation began,
at any rate so far as the United Kingdom was concerned, in 1946. The form employed,
which, for obvious reasons, employs similar forms and similar language in all
agreements, is derived, I believe, from a set of model clauses proposed by the
financial commission of the League of Nations. The aim is to provide by treaty for the
tax claims of two governments, both legitimately interested in taxing a particular
source of income either by resigning to one of the two the whole claim or else by
prescribing the basis on which the tax claim is to be shared between them. For our
purpose it is convenient to note that the language employed in this agreement is what
may be called international tax language and that such categories as “enterprise,”
“commercial or industrial profits” and “permanent establishment” have no exact
counterpart in the taxing code of the United Kingdom.” (page 480)
147. All the DTAAs with which we are concerned, have, as their starting point, either the OECD
Model Tax Convention on Income and Capital [“OECD Model Tax Convention”] and/or the United
Nations Model Double Taxation Convention between Developed and Developing Countries [“UN
Model Convention”] insofar as the taxation of royalty for parting with copyright is concerned.
148. The OECD Model Tax Convention speaks of the importance of the OECD Commentary, as
follows:
“2. It has long been recognised among the member countries of the Organisation for
Economic Co-operation and Development that it is desirable to clarify, standardise,
and confirm the fiscal situation of taxpayers who are engaged in commercial,
industrial, financial, or any other activities in other countries through the application
by all countries of common solutions to identical cases of double taxation. These
countries have also long recognised the need to improve administrative co-operation
in tax matters, notably through exchange of information and assistance in collection
of taxes, for the purpose of preventing tax evasion and avoidance.
3. These are the main purposes of the OECD Model Tax Convention on Income and
on Capital, which provides a means of settling on a uniform basis the most common
problems that arise in the field of international juridical double taxation. As
recommended by the Council of OECD, member countries, when concluding orEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

revising bilateral conventions, should conform to this Model Convention as
interpreted by the Commentaries thereon and having regard to the reservations
contained therein and their tax authorities should follow these Commentaries, as
modified from time to time and subject to their observations thereon, when applying
and interpreting the provisions of their bilateral tax conventions that are based on
the Model Convention.” “29.2 Similarly, taxpayers make extensive use of the
Commentaries in conducting their businesses and planning their business
transactions and investments. The Commentaries are of particular importance in
countries that do not have a procedure for obtaining an advance ruling on tax matters
from the tax administration as the Commentaries may be the only available source of
interpretation in that case.” (OECD Model Tax Convention 2017 - Condensed
Version) (emphasis supplied)
149. The OECD Model Tax Convention, in Article 12 thereof, defines the term “royalties” as follows:
“Article 12 ROYALTIES xxx xxx xxx
2. The term “royalties” as used in this Article means payments of any kind received as
a consideration for the use of, or the right to use, any copyright of literary, artistic or
scientific work including cinematograph films, any patent, trade mark, design or
model, plan, secret formula or process, or for information concerning industrial,
commercial or scientific experience.”
150. When the definition of “royalties” is seen in all the DTAAs that we are concerned with, it is
found that “royalties” is defined in a manner either identical with or similar to the definition
contained in Article 12 of the OECD Model Tax Convention. This being the case, the OECD
Commentary on the provisions of the OECD Model Tax Convention then becomes relevant. The
OECD Commentary has been referred to and relied upon in several earlier judgments. See:
i. Union of India v. Azadi Bachao Andolan, (2004) 10 SCC 1 at pages 42-43;
ii. Formula One World Championship Ltd. v. CIT, (2017) 15 SCC 602 at pages 629-630; and iii. CIT
v. E-Funds IT Solution Inc., (2018) 13 SCC 294 at pages 322-323.
151. The importance of the OECD Commentary, when it comes to DTAAs, was also underscored by
the High Court of Australia in Thiel v. Federal Commissioner of Taxation, High Court of Australia,
[1990] 94 ALR 647, which put it thus:
“Article 31 of the Vienna Convention provides that a treaty is to be interpreted “in
good faith in accordance with the ordinary meaning to be given to the terms of the
treaty in their context and in the light of its object and purpose''. The context
includes, in addition to the text, any instrument which was made by one or more
parties in connection with the conclusion of the treaty and accepted by the other
parties as an instrument related to the treaty. For my part, I do not see why theEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

OECD model convention and commentaries should not be regarded as having been
made in connection with and accepted by the parties to a bilateral treaty
subsequently concluded in accordance with the framework of the model. However,
some doubts have been expressed about the applicability, as a matter of language, of
Art. 31 to the commentaries in the case of a bilateral treaty such as a double taxation
agreement: see Jones et al., “The Interpretation of Tax Treaties with Particular
Reference to Article 3(2) of the OECD Model-II'', (1984) British Tax Review 90 at p.
92.
I turn, therefore, to Art. 32 of the Vienna Convention which allows recourse to be had
to supplementary means of interpretation, including the preparatory work of the
treaty and the circumstances of its conclusion, in order to confirm the meaning
resulting from the application of Art. 31, or to determine the meaning when the
interpretation according to Art. 31 leaves the meaning ambiguous or obscure or leads
to a result which is manifestly absurd or unreasonable. Whilst the model convention
and commentaries may not strictly amount to work preparatory to the double
taxation agreement between Australia and Switzerland, they are documents which
form the basis for the conclusion of bilateral double taxation agreements of the kind
in question and, as with treaties in pari materia, provide a guide to the current usage
of terms by the parties. They are, therefore, a supplementary means of interpretation
to which recourse may be had under Art. 32 of the Vienna Convention.”47
(Concurring Opinion of Dawson J., pages 653-654) This Court, in Ram Jethmalani v.
Union of India, (2011) 8 SCC 1, noted that though India is not a party to the Vienna
Convention on the Law of Treaties, the principles of international law and the
principle of interpretation contained in Article 31 thereof provide broad guidelines to
interpret treaties in the Indian context also. (See paragraph 69).
“The Agreement is a treaty and is to be interpreted in accordance with the rules of
interpretation recognised by international lawyers: Shipping Corporation of India
Ltd. v. Gamlen Chemical Co. (A/Asia) Pty. Ltd. (1980) 147 C.L.R. 142 at p. 159. Those
rules have now been codified by the Vienna Convention on the Law of Treaties to
which Australia, but not Switzerland, is a party. Nevertheless, because the
interpretation provisions of the Vienna Convention reflect the customary rules for the
interpretation of treaties, it is proper to have regard to the terms of the Convention in
interpreting the Agreement, even though Switzerland is not a party to that
Convention: Fothergill v.
Monarch Airlines Ltd. (1981) A.C. 251 at pp. 276, 282, 290; Commonwealth v. Tasmania (the
Tasmanian Dam case) (1983) 158 C.L.R. 1 at p. 222; Golder case (1975) 57 I.L.R. 201 at pp. 213-214.
Article 31 of the Convention requires a treaty to be interpreted in accordance with the ordinary
meaning to be given to its terms “in their context and in the light of its object and purpose''. The
context includes the preamble and annexes to the treaty: Art. 31(2). Recourse may also be had to
“supplementary means of interpretation, including the preparatory work of the treaty and the
circumstances of its conclusion'' to confirm the meaning resulting from the application of Art. 31 orEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

to determine the meaning of the treaty when interpretation according to Art. 31 leaves its meaning
obscure or ambiguous or leads to a result which is manifestly absurd or unreasonable: Art. 32. The
Agreement is one “for the avoidance of double taxation with respect to taxes on income''.
Accordingly, it is necessary to interpret the words of the Agreement with that particular purpose in
mind. Moreover, the term “enterprise'' in Art. 3 and 7 of the Agreement is ambiguous because, on
the one hand, it can mean a project or activity undertaken and, on the other hand, it can mean a
framework for making and carrying out decisions in respect of activities and projects. Consequently,
it is proper to have regard to any “supplementary means of interpretation'' in interpreting the
Agreement. In this case, the “supplementary means of interpretation'' are the 1977 OECD Model
Convention for the Avoidance of Double Taxation with respect to Taxes on Income and on Capital,
which was the model for the Agreement, and a commentary issued by the OECD in relation to that
model convention. But before referring to those two documents, it is necessary to describe the
Agreement in more detail.” (Concurring Opinion of McHugh J., pages 658-659)
152. The OECD Commentary on royalty payments under Article 12 is instructive, and states as
follows :
“12. Whether payments received as consideration for computer software may be
classified as royalties poses difficult problems but is a matter of considerable
importance in view of the rapid development of computer technology in recent years
and the extent of transfers of such technology across national borders. In 1992, the
Commentary was amended to describe the principles by which such classification
should be made. Paragraphs 12 to 17 were further amended in 2000 to refine the
analysis by which business profits are distinguished from royalties in computer
software transactions. In most cases, the revised analysis will not result in a different
outcome.
12.1 Software may be described as a program, or series of programs, containing
instructions for a computer required either for the operational processes of the
computer itself (operational software) or for the accomplishment of other tasks
(application software). It can be transferred through a variety of media, for example
in writing or electronically, on a magnetic tape or disk, or on a laser disk or CD-Rom.
It may be standardised with a wide range of applications or be tailor-made for single
users. It can be transferred as an integral part of computer hardware or in an
independent form available for use on a variety of hardware.
12.2 The character of payments received in transactions involving the transfer of
computer software depends on the nature of the rights that the transferee acquires
under the particular arrangement regarding the use and exploitation of the program.
The rights in computer programs are a form of intellectual property. Research into
the practices of OECD member countries has established that all but one protect
rights in computer programs either explicitly or implicitly under copyright law.
Although the term “computer software” is commonly used to describe both the
program — in which the intellectual property rights (copyright) subsist — and theEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

medium on which it is embodied, the copyright law of most OECD member countries
recognises a distinction between the copyright in the program and software which
incorporates a copy of the copyrighted program. Transfers of rights in relation to
software occur in many different ways ranging from the alienation of the entire rights
in the copyright in a program to the sale of a product which is subject to restrictions
on the use to which it is put. The consideration paid can also take numerous forms.
These factors may make it difficult to determine where the boundary lies between
software payments that are properly to be regarded as royalties and other types of
payment. The difficulty of determination is compounded by the ease of reproduction
of computer software, and by the fact that acquisition of software frequently entails
the making of a copy by the acquirer in order to make possible the operation of the
software.
13. The transferee’s rights will in most cases consist of partial rights or complete
rights in the underlying copyright (see paragraphs 13.1 and 15 below), or they may be
(or be equivalent to) partial or complete rights in a copy of the program (the
“program copy”), whether or not such copy is embodied in a material medium or
provided electronically (see paragraphs 14 to 14.2 below). In unusual cases, the
transaction may represent a transfer of “know-how” or secret formula (paragraph
14.3).
13.1 Payments made for the acquisition of partial rights in the copyright (without the
transferor fully alienating the copyright rights) will represent a royalty where the
consideration is for granting of rights to use the program in a manner that would,
without such license, constitute an infringement of copyright. Examples of such
arrangements include licenses to reproduce and distribute to the public software
incorporating the copyrighted program, or to modify and publicly display the
program. In these circumstances, the payments are for the right to use the copyright
in the program (i.e. to exploit the rights that would otherwise be the sole prerogative
of the copyright holder). It should be noted that where a software payment is
properly to be regarded as a royalty there may be difficulties in applying the copyright
provisions of the Article to software payments since paragraph 2 requires that
software be classified as a literary, artistic or scientific work. None of these categories
seems entirely apt. The copyright laws of many countries deal with this problem by
specifically classifying software as a literary or scientific work. For other countries
treatment as a scientific work might be the most realistic approach.
Countries for which it is not possible to attach software to any of those categories might be justified
in adopting in their bilateral treaties an amended version of paragraph 2 which either omits all
references to the nature of the copyrights or refers specifically to software.
14. In other types of transactions, the rights acquired in relation to the copyright are limited to those
necessary to enable the user to operate the program, for example, where the transferee is granted
limited rights to reproduce the program. This would be the common situation in transactions for theEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

acquisition of a program copy. The rights transferred in these cases are specific to the nature of
computer programs. They allow the user to copy the program, for example onto the user’s computer
hard drive or for archival purposes. In this context, it is important to note that the protection
afforded in relation to computer programs under copyright law may differ from country to country.
In some countries the act of copying the program onto the hard drive or random access memory of a
computer would, without a license, constitute a breach of copyright. However, the copyright laws of
many countries automatically grant this right to the owner of software which incorporates a
computer program. Regardless of whether this right is granted under law or under a license
agreement with the copyright holder, copying the program onto the computer’s hard drive or
random access memory or making an archival copy is an essential step in utilising the program.
Therefore, rights in relation to these acts of copying, where they do no more than enable the
effective operation of the program by the user, should be disregarded in analysing the character of
the transaction for tax purposes. Payments in these types of transactions would be dealt with as
commercial income in accordance with Article 7.
14.1 The method of transferring the computer program to the transferee is not relevant. For
example, it does not matter whether the transferee acquires a computer disk containing a copy of
the program or directly receives a copy on the hard disk of her computer via a modem connection. It
is also of no relevance that there may be restrictions on the use to which the transferee can put the
software.
14.2 The ease of reproducing computer programs has resulted in distribution arrangements in which
the transferee obtains rights to make multiple copies of the program for operation only within its
own business. Such arrangements are commonly referred to as “site licences”, “enterprise licenses”,
or “network licences”. Although these arrangements permit the making of multiple copies of the
program, such rights are generally limited to those necessary for the purpose of enabling the
operation of the program on the licensee’s computers or network, and reproduction for any other
purpose is not permitted under the license. Payments under such arrangements will in most cases
be dealt with as business profits in accordance with Article 7.
14.3 Another type of transaction involving the transfer of computer software is the more unusual
case where a software house or computer programmer agrees to supply information about the ideas
and principles underlying the program, such as logic, algorithms or programming languages or
techniques. In these cases, the payments may be characterised as royalties to the extent that they
represent consideration for the use of, or the right to use, secret formulas or for information
concerning industrial, commercial or scientific experience which cannot be separately copyrighted.
This contrasts with the ordinary case in which a program copy is acquired for operation by the end
user.
14.4 Arrangements between a software copyright holder and a distribution intermediary frequently
will grant to the distribution intermediary the right to distribute copies of the program without the
right to reproduce that program. In these transactions, the rights acquired in relation to the
copyright are limited to those necessary for the commercial intermediary to distribute copies of the
software program. In such transactions, distributors are paying only for the acquisition of theEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

software copies and not to exploit any right in the software copyrights. Thus, in a transaction where
a distributor makes payments to acquire and distribute software copies (without the right to
reproduce the software), the rights in relation to these acts of distribution should be disregarded in
analysing the character of the transaction for tax purposes. Payments in these types of transactions
would be dealt with as business profits in accordance with Article
7. This would be the case regardless of whether the copies being distributed are delivered on
tangible media or are distributed electronically (without the distributor having the right to
reproduce the software), or whether the software is subject to minor customisation for the purposes
of its installation.
15. Where consideration is paid for the transfer of the full ownership of the rights in the copyright,
the payment cannot represent a royalty and the provisions of the Article are not applicable.
Difficulties can arise where there is a transfer of rights involving:
— exclusive right of use of the copyright during a specific period or in a limited
geographical area; — additional consideration related to usage;
— consideration in the form of a substantial lump sum payment.
16. Each case will depend on its particular facts but in general if the payment is in consideration for
the transfer of rights that constitute a distinct and specific property (which is more likely in the case
of geographically-limited than time limited rights), such payments are likely to be business profits
within Article 7 or a capital gain within Article 13 rather than royalties within Article 12. That follows
from the fact that where the ownership of rights has been alienated, the consideration cannot be for
the use of the rights. The essential character of the transaction as an alienation cannot be altered by
the form of the consideration, the payment of the consideration in instalments or, in the view of
most countries, by the fact that the payments are related to a contingency.
17. Software payments may be made under mixed contracts. Examples of such contracts include
sales of computer hardware with built-in software and concessions of the right to use software
combined with the provision of services. The methods set out in paragraph 11 above for dealing with
similar problems in relation to patent royalties and know-how are equally applicable to computer
software. Where necessary the total amount of the consideration payable under a contract should be
broken down on the basis of the information contained in the contract or by means of a reasonable
apportionment with the appropriate tax treatment being applied to each apportioned part.”
(emphasis supplied)
153. However, the learned Additional Solicitor General has taken us through the positions taken by
India (in the capacity of an OECD non- member) with regard to Article 12 of the OECD Model Tax
Convention and the OECD Commentary, first in 2008, reiterated in 2014 and 2017, as follows:
“4.1 India reserves the right to: tax royalties and fees for technical services at source;
define these, particularly by reference to its domestic law; define the source of suchEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

payments, which may extend beyond the source defined in paragraph 5 of Article 11,
and modify paragraphs 3 and 4 accordingly.” “17. India reserves its position on the
interpretations provided in paragraphs 8.2, 10.1, 10.2, 14, 14.1, 14.2, 14.4, 15, 16 and
17.3; it is of the view that some of the payments referred to may constitute royalties”
(Positions on Article 12, OECD Commentary 2014)
154. From these positions taken, which use the language “reserves the right to” and “is of the view
that some of the payments referred to may constitute royalties”, it is not at all clear as to what
exactly the nature of these positions are. This may be contrasted with the categorical language used
by India in its positions taken with respect to other aspects (“India does not agree to”), as follows:
“18. India does not agree with the interpretation that information concerning
industrial, commercial or scientific experience is confined to only previous
experience.” “20. India does not agree with the interpretation in paragraph 9.1 of the
Commentary on Article 12 according to which a payment for transponder leasing will
not constitute royalty.
This notion is contrary to the Indian position that income from transponder leasing constitutes an
equipment royalty taxable both under India’s domestic law and its treaties with many countries. It is
also contrary to India’s position that a payment for the use of a transponder is a payment for the use
of a process resulting in a royalty under Article 12. India also does not agree with the conclusion
included in the paragraph concerning undersea cables and pipelines as it considers that undersea
cables and pipelines are industrial, commercial or scientific equipment and that payments made for
their use constitute equipment royalties.
21. India does not agree with the interpretation in paragraph 9.2 of the Commentary on Article 12. It
considers that a roaming call constitutes the use of a process. Accordingly, the payment made for the
use of that process constitutes a royalty for the purposes of Article 12. It is also the position of India
that a payment for a roaming call constitutes a royalty since it is a payment for the use of industrial,
commercial or scientific equipment.
22. India does not agree with the interpretation in paragraph 9.3 of the Commentary on Article 12. It
considers that a payment for spectrum license constitutes a royalty taxable both under India’s
domestic law and its treaties with many countries.” (Positions on Article 12, OECD Commentary
2014)
155. In Director of Income Tax v. New Skies Satellite BV, (2016) 382 ITR 114 [“New Skies Satellite”],
a Division Bench of the High Court of Delhi correctly observed that mere positions taken with
respect to the OECD Commentary do not alter the DTAA’s provisions, unless it is actually amended
by way of bilateral re-negotiation. This was put thus:
“68. On a final note, India's change in position to the OECD Commentary cannot be a
fact that influences the interpretation of the words defining royalty as they stand
today. The only manner in which such change in position can be relevant is if suchEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

change is incorporated into the agreement itself and not otherwise. A change in
executive position cannot bring about a unilateral legislative amendment into a treaty
concluded between two sovereign states. It is fallacious to assume that any change
made to domestic law to rectify a situation of mistaken interpretation can
spontaneously further their case in an international treaty. Therefore, mere
amendment to Section 9(1)(vi) cannot result in a change. It is imperative that such
amendment is brought about in the agreement as well. Any attempt short of this,
even if it is evidence of the State's discomfort at letting data broadcast revenues slip
by, will be insufficient to persuade this Court to hold that such amendments are
applicable to the DTAAs.” (emphasis in original)
156. It is significant to note that after India took such positions qua the OECD
Commentary, no bilateral amendment was made by India and the other Contracting
States to change the definition of royalties contained in any of the DTAAs that we are
concerned with in these appeals, in accordance with its position. As a matter of fact,
DTAAs that were amended subsequently, such as the Convention between the
Republic of India and the Kingdom of Morocco for the Avoidance of Double Taxation
and the Prevention of Fiscal Evasion with respect to Taxes On Income,48
[“India-Morocco DTAA”], which was amended on 22.10.2019,49 incorporated a
definition of royalties, not very different from the definition contained in the OECD
Model Tax Convention, as follows:
“The term "royalties" as used in this Article means:
(a) payments of any kind received as a consideration for the use of, or the right to use,
any copyright of a literary, artistic or scientific work, including cinematograph films
or recordings on any means of reproduction for use for radio or television
broadcasting, any patent, trade mark, design or model, plan, computer software
programme, secret formula or process, or for information concerning industrial,
commercial or scientific experience; and
(b) payments of any kind received as consideration for the use of, or the right to use,
any industrial, commercial or scientific equipment” (Article 12.3)
157. Similarly, though the India-Singapore DTAA came into force on 08.08.1994, it
has been amended several times, including on Notification : No. GSR 245(E), dated
15-3-2000.
Amended by Notification No. S.O. 3789(E) [No.84/2019/F.No.503/09/2009-FTD-II], Dated
22-10-2019.
01.09.2011,50 and 23.03.2017.51 However, the definition of “royalties” has been retained without
any changes. Likewise, the Convention between the Government of the Republic of India and the
Government of Mauritius for the Avoidance of Double Taxation and the Prevention of Fiscal EvasionEngineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

with respect to Taxes on Income and Capital Gains and for the Encouragement of Mutual Trade and
Investment,52 [“India-Mauritius DTAA”] was entered into on 06.12.1983, and was amended
subsequently on 10.08.2016,53 without making any change to the definition of “royalties”.
158. It is thus clear that the OECD Commentary on Article 12 of the OECD Model Tax Convention,
incorporated in the DTAAs in the cases before us, will continue to have persuasive value as to the
interpretation of the term “royalties” contained therein.
159. Viewed from another angle, persons who pay TDS and/or assessees in the nations governed by
a DTAA have a right to know exactly where they stand in respect of the treaty provisions that govern
them. Such Notification No. S.O. 2031(E).
Notification No. S.O. 935(E).
Notification No. GSR 920(E).
Notification No. S.O. 2680(E) (No.68/2016 (F.No.500/3/2012-FTD-II). persons and/or assessees
can thus place reliance upon the OECD Commentary for provisions of the OECD Model Tax
Convention, which are used without any substantial change by bilateral DTAAs, in the absence of
judgments of municipal courts clarifying the same, or in the event of conflicting municipal decisions.
From this point of view also, the OECD Commentary is significant, as the Contracting States to
which the persons deducting tax/assessees belong, can conclude business transactions on the basis
that they are to be taxed either on income by way of royalties for parting with copyright, or income
derived from licence agreements which is then taxed as business profits depending on the existence
of a PE in the Contracting State.
160. The learned Additional Solicitor General, however, relied upon the HPC Report 2003 and the
E-Commerce Report 2016. The HPC Report 2003, noting the various characterisation issues in
relation to e-commerce payments, recommended as follows:
“...The Committee also recommends that a clear position on each category of
transactions should be taken by the Central Board of Direct Taxes (“CBDT”). This will
ensure uniformity of approach among all the assessing officers. Since new categories
of transactions are likely to emerge at a fast pace with advances in technology, it is
also recommended that the CBDT should closely monitor the developments and issue
guidelines to the assessing officers on new emerging categories of transactions as a
continuing process. The monitoring should be through an expert advisory body on
which the tax administration, the profession and the concerned industry is
represented.” (pages 146-147)
161. The E-Commerce Report 2016 proposed an equalization levy to be chargeable on specified
digital services (see paragraph 11.2) and noted that its recommendation to impose a withholding tax
on digital transactions would require an express inclusion in tax treaties in order to be feasible, as
follows:Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

“108. After taking cognizance of these observations, the Committee considers that the
option of “withholding tax” offers a practical way of allocating partial taxing rights in
respect of income from digital economy, which shares attributes that may be similar
to royalty or fee for technical services, and which can be complied in respect of B2B
transactions by the process of withholding. However, such a tax on income would be
feasible only if it is included in the tax treaties, which take precedence over Indian
domestic laws, unless it is designed as a tax on the gross payment.” (emphasis
supplied)
162. These reports also do not carry the matter much further as they are recommendatory reports
expressing the views of the committee members, which the Government of India may accept or
reject. When it comes to DTAA provisions, even if the position put forth in the aforementioned
reports were to be accepted, a DTAA would have to be bilaterally amended before any such
recommendation can become law in force for the purposes of the Income Tax Act.
163. The learned Additional Solicitor General also sought to rely on a decision of the Audiencia
Nacional (Spanish National Court) in Case No. 207019/1990 dated 28.02.1995 and a decision of the
Tribunal Supremo (Spanish Supreme Court) in Case No. 8066/1994 dated 02.10.1999. Quite apart
from the fact that he only presented certain extracts and not the entire judgment rendered in these
cases, these authorities have no relevance to the appeals before us, having been decided on the basis
of the taxation law of Spain.
164. The learned Additional Solicitor General then referred to the judgment of this Court in
Commissioner of Customs v. G.M. Exports, (2016) 1 SCC 91, and in particular on the four
propositions that were culled out in the context of the levy of an anti-dumping duty in consonance
with the General Agreement on Tariffs and Trade (GATT), 1994, as follows:
“23. A conspectus of the aforesaid authorities would lead to the following
conclusions:
(1) Article 51(c) of the Constitution of India is a directive principle of State policy
which states that the State shall endeavour to foster respect for international law and
treaty obligations. As a result, rules of international law which are not contrary to
domestic law are followed by the courts in this country. This is a situation in which
there is an international treaty to which India is not a signatory or general rules of
international law are made applicable. It is in this situation that if there happens to
be a conflict between domestic law and international law, domestic law will prevail.
(2) In a situation where India is a signatory nation to an international treaty, and a
statute is passed pursuant to the said treaty, it is a legitimate aid to the construction
of the provisions of such statute that are vague or ambiguous to have recourse to the
terms of the treaty to resolve such ambiguity in favour of a meaning that is consistent
with the provisions of the treaty.Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

(3) In a situation where India is a signatory nation to an international treaty, and a
statute is made in furtherance of such treaty, a purposive rather than a narrow literal
construction of such statute is preferred. The interpretation of such a statute should
be construed on broad principles of general acceptance rather than earlier domestic
precedents, being intended to carry out treaty obligations, and not to be inconsistent
with them.
(4) In a situation in which India is a signatory nation to an international treaty, and a
statute is made to enforce a treaty obligation, and if there be any difference between
the language of such statute and a corresponding provision of the treaty, the statutory
language should be construed in the same sense as that of the treaty. This is for the
reason that in such cases what is sought to be achieved by the international treaty is a
uniform international code of law which is to be applied by the courts of all the
signatory nations in a manner that leads to the same result in all the signatory
nations.”
165. The conclusions in the aforestated paragraph have no direct relevance to the facts at hand as
the effect of section 90(2) of the Income Tax Act, read with explanation 4 thereof, is to treat the
DTAA provisions as the law that must be followed by Indian courts, notwithstanding what may be
contained in the Income Tax Act to the contrary, unless more beneficial to the assessee.
For all these reasons therefore, these submissions of the learned Additional Solicitor General are
rejected.
166. At this juncture, it is also important to point out that vide Circular No. 10/2002 dated
09.10.2002, the Revenue, after referring to section 195 of the Income Tax Act and deciding that a No
Objection Certificate from the Department would not be necessary if the person making the
remittance is to submit an undertaking along with the certificate of an accountant to the Reserve
Bank of India [“RBI”], has itself made a distinction in the proforma of the certificate to be issued in
Annexure B to the aforesaid Circular, between remittances for royalties (see Row No. 5) and
remittances for supply of articles or computer software (see Row No. 7), as follows:
ANNEXURE ‘B’ CERTIFICATE
1. Name and address of the beneficiary :
of the remittance and the name of the foreign country to which remittance is being
made.
2. Amount of remittance is foreign :
currency indicating the proposed date/month and bank through which remittance is
being made.Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

3. Details of tax deducted at source, rate : Foreign Indian at which tax has been
deducted and date of deduction.
     Amount to be remitted                             .....    .....
     Tax deducted at source                            .....    ......
     Actual Amount remitted                            .....    .....
     Rate at which deducted                            .....    .....
     Date of Deduction                                 ......   .....
4.   In case the remittance as indicated in        :
     (2) above is net of taxes, whether tax
     payable has been grossed up? If so,
     computation thereof may be indicated.
5. If the remittance is for royalties, fee for :
technical services, interest, dividend, etc., the clause of the relevant DTAA under
which the remittance is covered along with reasons and the rate at which tax is
required to be deducted in terms of such clause of the applicable DTAA.
6. In case that tax has been deducted at :
a rate lower than the rate prescribed under the applicable DTAA, the reasons thereof.
7. In case remittance is for supply of :
articles or things (e.g., plant, machinery, equipment, etc.) or computer software,
please indicate :— i. Whether there is any permanent establishment in India through
which the beneficiary of the remittance is directly or indirectly carrying on such
activity of supply of articles or things? ii. Whether such remittance is attributable to
or connected with such permanent establishment?
iii .If so, the amount of income comprised in such remittance which is liable to tax.
iv. If not, the reasons in brief therefor.
8. In case remittance is on account of business income please indicate :— :
i. Whether such income is liable to tax in India?
ii. If so, the basis for arriving at the rate of deduction of tax.
iii. If not, the reasons thereof.Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

9. In case tax is not deducted at source :
for any other reason, details thereof.
(emphasis supplied)
167. The Revenue, therefore, when referring to “royalties” under the DTAA, makes a distinction
between such royalties, no doubt in the context of technical services, and remittances for supply of
computer software, which is then treated as business profits, taxable under the relevant DTAA
depending upon whether there is a PE through which the assessee operates in India. This is one
more circumstance to show that the Revenue has itself appreciated the difference between the
payment of royalty and the supply/use of computer software in the form of goods, which is then
treated as business income of the assessee taxable in India if it has a PE in India.
CONCLUSION
168. Given the definition of royalties contained in Article 12 of the DTAAs mentioned in paragraph
41 of this judgment, it is clear that there is no obligation on the persons mentioned in section 195 of
the Income Tax Act to deduct tax at source, as the distribution agreements/EULAs in the facts of
these cases do not create any interest or right in such distributors/end-users, which would amount
to the use of or right to use any copyright. The provisions contained in the Income Tax Act (section
9(1)(vi), along with explanations 2 and 4 thereof), which deal with royalty, not being more beneficial
to the assessees, have no application in the facts of these cases.
169. Our answer to the question posed before us, is that the amounts paid by resident Indian
end-users/distributors to non-resident computer software manufacturers/suppliers, as
consideration for the resale/use of the computer software through EULAs/distribution agreements,
is not the payment of royalty for the use of copyright in the computer software, and that the same
does not give rise to any income taxable in India, as a result of which the persons referred to in
section 195 of the Income Tax Act were not liable to deduct any TDS under section 195 of the Income
Tax Act. The answer to this question will apply to all four categories of cases enumerated by us in
paragraph 4 of this judgment.
170. The appeals from the impugned judgments of the High Court of Karnataka are allowed, and the
aforesaid judgments are set aside. The ruling of the AAR in Citrix Systems (AAR) (supra) is set
aside. The appeals from the impugned judgments of the High Court of Delhi are dismissed.
…………………..………………J. (R. F. Nariman) ……………..……………………J. (Hemant Gupta)
……………..……………………J. (B.R. Gavai) New Delhi.
March 02, 2021.Engineering Analysis Centre Of ... vs The Commissioner Of Income Tax on 2 March, 2021

