Facebook Inc vs Competition Commission Of India & Anr. on 25
August, 2022
Author: Subramonium Prasad
Bench: Chief Justice, Subramonium Prasad
                          *      IN THE HIGH COURT OF DELHI AT NEW DELHI
                                                                 Date of decision: 25th AUGUST, 2022
                                 IN THE MATTER OF:
                          +      LPA 163/2021 & CM APPLs. 15908/2021, 16893/2021,
                                 18800/2021, 18910/2021, 46058/2021, 46059/2021, 46655/2021
                                 WHATSAPP LLC                                           ..... Appellant
                                                      Through:   Mr. Harish Salve, Sr. Advocate with
                                                                 Mr. Tejas Karia, Mr. Shashank
                                                                 Mishra, Ms Supritha Prodaturi and
                                                                 Mr. Shashank Mishra, Advocates.
                                                      versus
                                 COMPETITION COMMISSION OF INDIA & ANR .... Respondents
                                                      Through:   Mr. N. Venkataraman, ASG with
                                                                 Mr.V. Chandrashekara Bharathi,
                                                                 Ms.Amritha Chandramouli, Mr. S.
                                                                 Ram Narayan, Mr. Samar Bansal,
                                                                 Mr.Madhav Gupta, Mr. Vedant
                                                                 Kapur, Advocates for R-1.
                                                                 Ms Binsy Susan, Ms. Anjali Kumar,
                                                                 Mr. Shyamal Anand and Mr. Vishesh
                                                                 Sharma,     Advocates     for    Meta
                                                                 Platforms Inc.
                                                                 Mr. Parag Tripathi, Sr. Advocate with
                                                                 Mr. Ajit Warrier, Mr. Yaman Verma,
                                                                 Mr. Swati Aggarwal and Ms. Mishika
                                                                 Bajpai, Advocates for Facebook India
                                                                 in CM APPL. 40334/2021.
                          +      LPA 164/2021 & CM APPLs. 15931/2021,                    18798/2021,
                                 18912/2021, 40334/2021, 40335/2021, 46656/2021
                                 FACEBOOK INC                                           ..... Appellant
                                                      Through:   Mr. Mukul Rohatgi, Sr. Advocate
Signature Not Verified
Digitally Signed          LPA 163/2021&LPA 164/2021                                          Page 1 of 49
By:RAHUL SINGH
Signing Date:26.08.2022
09:30:24
                                                                  with Ms. Sweta Shroff Chopra,Facebook Inc vs Competition Commission Of India & Anr. on 25 August, 2022

                                                                 Mr.Gauhar Mirza and Ms. Nitika
                                                                 Dwivedi, Advocates.
                                                      versus
                                 COMPETITION COMMISSION OF INDIA & ANR .... Respondents
                                                      Through:   Mr. Balbir Singh, ASG with
                                                                 Ms.Monica Benjamin, Ms. Anu Sura,
                                                                 Mr. Samar Bansal, Mr. Madhav
                                                                 Gupta, Mr. Vedant Kapur, Advocates
                                                                 for R-1
                                                                 Mr. Varun Pathak, Mr. Mitali
                                                                 Daryani, Mr. Yash Karunakaran and
                                                                 Ms. Vani Kaushik, Advocates for R-
                                                                 2
                                                                 Mr. Parag Tripathi, Sr. Advocate with
                                                                 Mr. Ajit Warrier, Mr. Yaman Verma
                                                                 and Ms. Mishika Bajpai, Advocates
                                                                 for Facebook India in CM APPL.
                                                                 40334/2021.
                                 CORAM:
                                 HON'BLE THE CHIEF JUSTICE
                                 HON'BLE MR. JUSTICE SUBRAMONIUM PRASAD
                                                          JUDGMENT
SUBRAMONIUM PRASAD, J
1. The Appellant seeks to challenge the Judgement dated 22.04.2021, passed by the learned Single
Judge in W.P.(C) 4378/2021 & W.P.(C) 4407/2021 by which the learned Single Judge rejected the
Writ Petition filed by the Appellants. The Appellants herein, by way of the abovementioned Writ
Petition, had sought to challenge the Order dated 24.03.2021 passed by the Respondent No.1 herein
directing the Director-General, CCI, to initiate investigation into the 2021 Terms of Service and
Privacy Policy of the Appellant in LPA No.163/2021 on the ground that it violates the provisions of
the Competition Act, 2002 (hereinafter referred to as 'the Act').
2. The facts, in brief, leading to the instant Appeals are as under:-
i. Prior to 25.08.2016, WhatsApp (the Appellant in LPA 163/2021), a messaging
platform, was governed by its Terms of Service and Privacy Policy of July 2012. In the
year 2014, WhatsApp was acquired by Facebook (the Appellant in LPA 164/2021).
Facebook Inc. is now known as "Meta Platforms", however, for ease of
comprehension, this Court shall refer to the Appellant in LPA 164/2021 by its former
nomenclature. ii. On 25.08.2016, the Terms and Services and the Privacy Policy of
WhatsApp (hereinafter referred to as "2016 Policy") was updated, and WhatsApp
users were informed of Facebook's acquisition of WhatsApp and how Facebook
would use WhatsApp's information for its advertisement and products. A one-time
opportunity was given to WhatsApp users to opt out of Facebook using theirFacebook Inc vs Competition Commission Of India & Anr. on 25 August, 2022

information that was shared over WhatsApp. However, users who joined WhatsApp
after the 2016 Policy, were not offered this option. iii. The 2016 Policy, was
challenged by way of a writ petition in Karmanya Singh Sareen & Anr. v. Union of
India &Ors., W.P.(C) 7663/2016, and the policy was upheld vide Judgement dated
23.09.2016. This Judgment has been challenged before the Hon'ble Supreme Court
and adjudication on the same is pending.
iv. On 04.01.2021, WhatsApp announced an update to its Terms of Service and
Privacy Policy (hereinafter referred to as "2021 Policy"). The 2021 Policy was also
challenged before this Court as well as the Hon'ble Supreme Court, and the said
matters are still pending.
v. It is stated that cognizance was taken by the Respondent No.1, Competition
Commission of India (hereinafter referred to as the "CCI"), of the 2021 Policy, and
accordingly vide Order dated 24.03.2021, the CCI initiated a suo motu case under
Section 26(1) of the Act by directing the Director-General, CCI (DG) to conduct an
investigation in order to examine the potential abuse of dominance exercised by both
the Appellants under Section 4 of the Act.
vi. This Order dated 24.03.2021 under Section 26(1) of the Act was challenged before this Court in
W.P.(C) 4378/2021 and W.P.(C) 4407/2021 by the Appellants herein. Vide Judgment dated
22.04.2021, the learned Single Judge held that the CCI- Respondent No.1 in both the Appeals would
not be divested of its jurisdiction that it possesses under the Act merely because an issue may be
pending before the Supreme Court or the High Court. Furthermore, it was observed that the Order
passed under Section 26(1) of the Act is purely administrative in nature and does not entail any
consequence on the civil rights of the Appellants herein. Accordingly, the learned Single Judge
dismissed the petitions filed by the Appellants herein. vii. Aggrieved by the Judgment dated
22.04.2021, passed by the learned Single Judge in W.P.(C) 4378/2021 and W.P.(C) 4407/2021, the
Appellants have approached this Court by filing the instant Appeals.
3. Mr. Harish Salve, learned Senior Counsel appearing for Appellant in LPA 163/2021, submits that
WhatsApp provides an end-to-end encryption service for sending and receiving of messages to
safeguard the privacy of its users. He submits that this very issue has been considered by this Court
in Karmanya Singh Sareen & Anr. v. Union of India & Ors., W.P.(C) 7663/2016, and this Court vide
Judgment dated 23.09.2016 had upheld the 2016 Policy by holding that the users of WhatsApp,
having voluntarily opted to avail services of the said application, were bound by the terms of service
offered by WhatsApp, and it is always open to users of WhatsApp who do not want their information
to be shared with Facebook to opt for deletion of their accounts. Mr. Salve further relies upon Vinod
Kumar Gupta v. Whatsapp Inc., (Case No. 99/2016), wherein the CCI, i.e. Respondent No.1 upheld
the 2016 Policy with the finding that there had been no abuse of dominance by the Appellant. He
also states that the Ministry of Electronics and Information Technology (MeiTY) is in the process of
promulgating a Personal Data Protection Bill and the policies of the Appellant would be answerable
to the provisions stipulated in the same, and therefore, the CCI should refrain from adjudicating on
this issue before the Bill is promulgated.Facebook Inc vs Competition Commission Of India & Anr. on 25 August, 2022

4. The learned Senior Counsel further submits that the preliminary order makes it clear that the
issues before the Supreme Court and the issues before Respondent No.1 are identical and
overlapping. He states that as per the principle of judicial discipline, Respondent No.1 must exercise
restraint and refrain from issuing the CCI order on the ground that the Supreme Court in Karmanya
Singh Sareen v. Union of India and Ors., [SLP (Civil) No. 804 of 2017] and this Court in Chaitanya
Rohilla v. Union of India &Ors., [W.P.(C) No. 677 of 2021] and Dr. Seema Singh v. Union of India
&Ors., [W.P.(C) No. 1355 of 2021] are already seized of the issues pertaining to the same subject
matter. In this regard, he also brings to notice of this Court paragraph 33 of the impugned
Judgement wherein the learned Single Judge has observed that "maybe, it would have been prudent
for the respondent no.1 to have awaited the outcome of the above-referred petitions". He submits
that the order of CCI is not merely administrative, as has been held by the learned Single Judge, as
the powers of the DG are quite drastic. He relies upon the Order dated 24.03.2021 to state that
Respondent No.1 itself in Paragraph 4 of the said Order has referred to a previous case on the same
issue, i.e. Vinod Kumar Gupta v. Whatsapp Inc., (Case No. 99/2016) wherein the CCI has held that
2016 Policy does not institute anti- competition practices. He further submits that the 2021 Policy
also falls within the purview of the information technology law framework and that a reading of the
letter dated 18.05.2021 issued by the MeiTY also demonstrates that the issues are overlapping.
5. Mr. Harish Salve, learned Senior Counsel, relies on the judgment of the Supreme Court in
Competition Commission of India v. Bharti Airtel, (2019) 2 SCC 521, to submit that in the said case,
the Supreme Court had rejected the Respondent No.1's attempt to exercise jurisdiction over matters
that were being considered by the sectoral regulator, i.e. TRAI, despite the matter involving
competition related issues. He submits that the learned Single Judge has come to the conclusion
that there is an overlap of jurisdiction in paragraph 33 of the impugned Judgment and, after
arriving at the said conclusion, the learned Single Judge has observed that it would be prudent for
the Commission to keep its hands off till the issues pending before the Supreme Court are decided.
He states that a perusal of the additional affidavit demonstrates that the questions that have been
posed by MeiTY in its letter dated 18.05.2021 with regard to the 2021 Policy to the Appellant are the
same as the questions that have been referred by Respondent No.1 to the Appellant. Therefore, the
learned Senior Counsel argues that if the same issue is decided by different authorities, then it might
lead to conflicting opinions being rendered.
6. Mr. Salve contends that the challenge is not to any inquiry under Section 26 of the Act, but the
challenge is jurisdictional in nature. He states that currently the challenge to the policy itself is
pending, and if the Appellant's right to continue a particular action is in itself in question, then the
question of CCI inquiry does not arise. He further brings to the notice of this Court Section 57 of the
Act and Regulation 35 of the Competition Commission of India (General) Regulations, 2009, and
states that these provisions do not ensure that the confidentiality of the matter is maintained as the
same is only dependent on the discretion of the CCI at the end of the day. Further, there is no
guarantee regarding the maintenance of confidentiality as is evident by the fact that other entities
such as the Internet Freedom Foundation (IFF) and one Prachi Kohli have filed intervention
applications on being made aware of the issue. He states that, therefore, an intrusive and
unnecessary investigation by the DG would have the potential of revealing the internal workings of
the Appellant to the public, thereby hampering its business.Facebook Inc vs Competition Commission Of India & Anr. on 25 August, 2022

7. Mr. Mukul Rohatgi, learned Senior Counsel appearing for Appellant in LPA 164/2021, at the
outset, states that he is adopting the arguments of Mr. Harish Salve, learned Senior Counsel
appearing for the Appellant in LPA 163/2021, and submits that the Appellant in LPA 164/2021 has
been roped in the instant matter by virtue of a few references made in the CCI's Order dated
24.03.2021. He submits that there is no material that would lead to a prima facie opinion being
formed that there exists abuse of dominance as per Section 4 of the Act by the Appellant, and that,
therefore, it does not satisfy the requirements of the Act to establish a prima facie case of abuse of
dominance.
8. Mr. Rohatgi submits that Section 26(1) of the Act prohibits Respondent No.1 from exercising
jurisdiction over and initiating an investigation into the Appellant, unless it first establishes a prima
facie case of abuse of dominance. He states that Respondent No.1 has failed to satisfy any of the
requirements stipulated under Section 4 of the Act that could establish abuse of dominance. He
states that the Appellant has a right to carry on his business in accordance with law and relies upon
Barium Chemicals v. Company Law Board & Ors., 1966 Supp. SCR 311. He states that the subject of
investigation is WhatsApp, i.e. Appellant in LPA 163/2021, and that just because the Appellant in
LPA 164/2021 is a common owner, it would not mean that they are required to share the burden. He
further states that it is the 2016 Policy and the 2021 Policy which are under challenge, and that these
updates are not the policies of the Appellant in LPA 164/2021. He, therefore, states that just because
information can be shared by virtue of those policies, it is not a ground to investigate into the affairs
of Facebook.
9. Mr. Rohatgi also relies upon Vinod Kumar Gupta v. Whatsapp Inc., (Case No. 99/2016), wherein
the CCI had found that no prima facie case of contravention of the provisions of Section 4 of the Act
had been made out with regard to the 2016 Policy, and CCI did not have jurisdiction over violations
arising out of the Information Technology Act, 2000, to submit that the CCI is bound by its own
order and that judicial discipline requires the CCI not to intrude into this arena when the highest
authority of the land is seized of the matter. He also places on record a judgement of NCLAT dated
02.08.2022 wherein the NCLAT upheld the Order of the CCI in Vinod Kumar Gupta (supra),
thereby cementing the findings of the CCI. The learned Senior Counsel submits that Section 26 of
the Act stipulates the procedure of inquiry into complaints under Section 19 of the Act, which in turn
is regarding inquiry into certain agreements and dominant position of enterprise. He further states
that Section 4 of the Act stipulates what constitutes dominant position and there is nothing in the
Order to indicate that the Appellant is abusing its dominant position.
10. The learned Senior Counsel submits that the interpretation of the learned Single Judge of
Competition Commission of India v. Bharti Airtel (supra) is misplaced as in the said matter, the
issue was between two regulators. In the instant case, it is the Constitution Bench of the Supreme
Court which is seized of the matter pertaining to the 2021 Policy, and therefore, judicial propriety
would dictate that CCI should stay its hands before initiating any investigation whatsoever before
the Supreme Court has rendered its decision.
11. Mr. Parag Tripathi, learned Senior Counsel appearing for Facebook India Online Services Pvt.
Ltd. (hereinafter referred to as the "Applicant") by way of an Impleadment Application, submits thatFacebook Inc vs Competition Commission Of India & Anr. on 25 August, 2022

there is no material which clubs the Applicant with the Appellants herein and that the Applicant has
nothing to do with the activities of Facebook Inc. itself. He contends that the entity has been
incorporated to carry out business in India and abroad, inter alia, online support services, software
development, providing technical support, and services, and that it is not operating the social media
website, and thus, it has nothing to do with the instant matter.
12. The learned Senior Counsel relies on the Judgement of the Supreme Court in Competition
Commission of India v. Steel Authority of India Limited, (2010) 10 SCC 744, to submit that there
has to be an element of reasoning at the stage of forming a prima facie view by the CCI. He states
that CCI does not need detailed reasoning, but must express in no uncertain terms that it is of the
view that there exists a prima facie case, requiring issuance of a direction for investigation to the
Director General. As per Mr. Tripathi, CCI's Order lacks the reasoning required to embark upon the
journey of investigating into the anti-competitive concerns that have been raised.
13. Mr. Tripathi contends that unless there is some kind of finding that the Applicant has violated
any of the conditions under Section 4 of the Act, he cannot be subjected to any scrutiny under the
Act. He states that without there being a modicum of allegation under Section 4 of the Act, there is
no jurisdiction of the CCI to conduct a roving inquiry. He further states that since the learned Single
Judge had already upheld the Order passed by the CCI, no useful purpose would have been served
by approaching the Single Judge. He, therefore, submits that the Applicant has moved the present
application for impleadment in the instant LPAs.
14. Mr. Tripathi further places reliance on Union of India v. Special Tehsildar (ZA) &Ors., (1996) 2
SCC 332, Jatan Kumar Golcha v. Golcha Properties Pvt. Ltd., (1970) 3 SCC 573, Harvinder Singh v.
Paramjit Singh, (2013) 9 SCC 261, and V.N. Krishna Murthy v. Ravikumar, (2020) 9 SCC 501, to
argue that the impleadment application of the Facebook India Online Services Pvt. Ltd. should be
allowed as the rights of the party are being directly affected by the actions of the CCI and, thus, the
Applicant falls within the four corners of the category of an "aggrieved person" whose standing shall
be in jeopardy if the investigation is allowed to be continued and if a right of hearing is not provided.
Relying on the aforesaid judgements, he states that it is always open to a person who is aggrieved by
an Order to approach in appeal which arises out of those proceedings.
15. Per contra, Mr. N. Venkataraman, learned ASG appearing for Respondent No.1/CCI, submits
that there is no overlap factually with any pending proceedings across other Courts. He states that
the Order of the CCI indicates that a careful and thoughtful consideration of the matter was done
before arriving at the conclusion that there were concerns regarding violation of the provisions of
the Act. He states that the CCI is examining the 2021 Policy through the prism of the Competition
Act, 2002, in a bid to discharge its statutory functions as a competition law regulator and is,
therefore, not concerned with the possible violation of fundamental rights that is being delved into
by the Supreme Court. Mr. Venkataraman, therefore, argues that the scope of jurisdiction of the CCI
lies on a different plane than that of a Constitutional Court, and the fact that the latter is seized of
the matter has no bearing on the investigation that is being conducted by the DG, CCI. Furthermore,
attention has been drawn to Sections 60 and 62 of the Act to state that the Act shall have an
overriding effect, and that the application of other laws would not be barred.Facebook Inc vs Competition Commission Of India & Anr. on 25 August, 2022

16. The learned ASG submits that the reliance of the Appellants on Paragraph 23 of the impugned
Judgement is misplaced on the ground that the learned Single Judge had merely implied that
though the underlying transactions were the same, however, plural examination was required. He
states that the learned Single Judge has aptly noted that the reliance of the Appellants on
Competition Commission of India v. Bharti Airtel (supra) is erroneous to the extent that the said
Judgement deals with a conflict between the scope of jurisdiction of a sectoral regulator, which is
the TRAI, and a market regulator which is the CCI, and that the market regulator's jurisdiction is
not ousted solely for the reason that the sectoral regulator is seized of the matter; it only entails for
the sectoral regulator to conduct its investigation prior to the market regulator. The learned ASG
further submits that the case needs to be read factually as the Supreme Court had therein found that
it was primarily a telecom issue, not a competition issue.
17. Mr. Venkataraman relies upon S. Sukumar v. Secretary, Institute of Chartered Accountants of
India and Ors., (2018) 14 SCC 360, to state that in the said matter, the Supreme Court had held that
a case had been made out for examination not only by the Enforcement Directorate as well as the
Institute of Chartered Accountants of India (ICAI), but also by the Central Government with regard
to issues of violation of RBI/FDI policies and The Chartered Accountants Act, 1949. He states that,
similarly, in the instant case, as different aspects of the 2021 Policy were to be considered and the
CCI would not be denuded of its power to conduct the investigation solely on the basis that the
Supreme Court was also looking into the aspect of violations of right to privacy.
18. Further reliance has been placed on Panther Fincap and Management Services Ltd. v Union of
India, (2005 SCC OnLine Bom 386), and the following paragraph of the Bombay High Court
judgement has been cited:
"33. I have considered these rival submissions of the parties and I am of the opinion
that the jurisdiction and the power of the various investigating authorities derived
from the jurisdiction vested in them by the various legislations or statutes, the
authority which is doing the inquiry and or conducting the investigation is required
to carry out investigation keeping in mind the legal provisions and legal limitations
which are stipulated under the respective statute. Undoubtedly it can be that there
may be an overlapping investigation but in my opinion such an eventuality cannot
prevent any investigating authority from carrying out investigation in respect of their
jurisdiction conferred on them under the statute. I am also of the further opinion that
the investigation in respect of the corporate fraud can be initiated and considered by
the central government under section 237(b)(i) of the companies Act. I have not been
able to come across any provisions under the SEBI act in which any corporate fraud
can be investigated by the SEBI. Undoubtedly it can be investigated under normal
criminal law by the CBI. I am further of the opinion that merely because the material
on the basis of which investigation is being undertaken is identical to the material
which is subject matter of investigation by the other authority it can not be stated
that both the authorities can not simultaneously investigate pursuant to power
conferred on them under their respective statutes. I am of the opinion that every
authority is entitled to investigate even may be in respect of the same material as wellFacebook Inc vs Competition Commission Of India & Anr. on 25 August, 2022

as from the angle and facet in which they have been asked to carry out investigation.
It is possible that the SEBI may be investigating the same material on the ground of
breach of the various provisions of the SEBI act and other security related legislations
whereas the central government, department of company affairs can consider and/or
investigate the fraud and/or breach of various provisions of law in the light and
context of the provisions of the companies act may be in respect of the same material.
However, I am of the opinion that the contentions advanced by the learned counsel
for the appellant cannot be accepted particularly in view of the fact that every
authority has been conferred various powers in their respective legislation. A similar
issue aroused before the English Court under the identical provisions of investigation
under the Companies Law and the Court of Appeal in the case of Re London United
Investments plc reported in 1992 BCLC 285 equivalent to 1971 All England Law
Reports page 849 it is held as under:
"The power of the secretary of state to appoint inspectors to investigate the affaris of
a company and to report is an important regulatory mechanism for ensuring probity
in the management of companies' affairs. That of course is in the public interest.
Since the Secretary of State's powers under s 432(2) are exercisable where there are
circumstances suggesting fraud, it is likely that in many cases where inspectors are
appointed an investigation by the police or the Serious Fraud Office could also be
appropriate. But the code under the 1985 Act is a separate code even though it may
overlap the field of criminal investigation.""
19. The learned ASG relies upon Section 4(2) of the Act to submit that the focus of a competition
law-based investigation is apparent from a reading of the said provision. It has further been
submitted that the learned Single Judge has rightly observed that the CCI Order records that
WhatsApp is a dominant entity in the relevant market for OTT messaging apps through
smartphones in India [as has been held by CCI in Harshita Chawla v. WhatsApp Inc and Anr., (Case
No. 15 of 2020)], and that the 2021 Policy is a product that emanates out of the entrenched
dominant position of WhatsApp in the said market. Furthermore, Paragraph 25 of the CCI Order
has been referred to in order to argue that the CCI, after duly analysing how the "take it or leave it"
nature of the 2021 Policy and Terms of Service of WhatsApp, and the information sharing
stipulations therein, has held that the same merit a detailed investigation in view of the market
position and market power enjoyed by WhatsApp. He further states that the existence of Regulation
35 of the Competition Commission of India (General) Regulations, 2009, ensures that whatever
happens during the course of investigation is kept confidential.
20. Mr. Venkataraman refers to the letter dated 18.05.2021 issued by MeiTY to state that the
Ministry had warned WhatsApp as to how the 2021 Policy was violative of not only the right to
privacy enshrined in our Constitution of India, 1950, but further violated the legal framework under
the Information Technology Act, 2000, the Competition Act, 2002, and other statutory provisions.
He states that WhatsApp's response dated 22.05.2021 to the said letter reveals that the entity has
not stopped the exercise of its policy. He further submits that Rule 5(7) of the Information
Technology (Reasonable Security Practices and Procedures and Sensitive Personal Data orFacebook Inc vs Competition Commission Of India & Anr. on 25 August, 2022

Information) Rules, 2011 (hereinafter referred to as the "SPDI Rules") can at the most be said to
overlap with Article 21, but cannot be said to impinge upon provisions related to anti-competitive
practices, and that an investigation under Section 4(2) of the Act cannot be stopped merely because
there is an overlap. Furthermore, by no stretch of imagination can it be said that by way of the said
letter, the Ministry seeks to investigate into the 2021 Policy.
21. The learned ASG relies upon Monsanto Holdings Pvt. Ltd. and Ors. v. Competition Commission
of India and Ors., 2020 SCC OnLine Del 598, to argue that the legislative intent of the Competition
Act was to ensure that its provisions were implemented in addition to provisions of other statutes.
Mr. Venkataraman concludes his submissions by relying upon Flipkart Internet Pvt. Ltd. v
Competition Commission of India and Ors., MANU/KA/3124/2021, State of West Bengal and Ors.
v. Swapan Kumar Guha and Ors., (1982) 1 SCC 561, Skoda Auto Volkswagen (India) Pvt. Ltd. v.
State of Uttar Pradesh, (2021) 5 SCC 795, and Eastern Spinning Mills and Virendra Kumar Sharda
and Anr. v. Rajiv Poddar and Ors., 1989 Supp (2) SCC 385, to largely submit that once an offence is
disclosed an investigation into the offence must necessarily follow in the interests of justice, and that
Courts and other judicial processes should not interfere in the course of investigation which must
proceed unhampered by Court orders.
22. Mr. Balbir Singh, learned ASG, supplements the submissions of Mr. N. Venkataraman, and
argues that the long-term objective of such technology and devices is to consume every inch of
human time, and to capitalise on it. He states that in pursuance of this, exclusionary tactics are
adopted by such entities which are backed by the dominant position that these entities occupy. He
submits that there is a design and object behind these tech companies, and that the Competition
Act, 2002, was brought in to ensure that these companies did not use their position to institute anti-
competitive practices to the detriment of their users. He further submits that the principle of res
judicata would not apply in the case of Vinod Kumar Gupta (supra) for the reason that it was the
2016 Policy which was under
assessment therein and that there had been a varied change in circumstances since
the said Policy.
23. Mr. Singh contends that competition is not a conduct; it is a behaviour, and that Section 4 of the
Act categorically uses the term "enterprise" to denote the concept of a group. He states that it would
not be in the realm of law to investigate only WhatsApp and not Facebook, and that the language of
Section 26 itself indicates that the issue is not about a party, but about the matter. He further states
that by virtue of being a group company as well as the holding company of WhatsApp, Facebook
inhabits a position whereby they can virtually use the information being shared by WhatsApp and
potentially misuse the same.
24. The learned ASG concludes his submissions by reiterating that the Competition Commission of
India v. Bharti Airtel (supra) is not applicable in the instant case as the issue in that case was a Point
of Interconnect which was in realm of the telecom sector, and that it had never been said that CCI
had no jurisdiction at all. Furthermore, Mr. Singh submits that there is enough material to showcase
that the entire group, including Facebook India Online Services Pvt. Ltd. which is seekingFacebook Inc vs Competition Commission Of India & Anr. on 25 August, 2022

impleadment in the instant matter, belongs to the Facebook company. The learned ASG, in this
regard, relies upon Cadila Healthcare Limited v. Competition Commission of India, 2018 SCC
OnLine Del 11229, and Competition Commission of India v. Grasim Industries Ltd., 2019 SCC
OnLine Del 10017, to submit that when Section 26(1) of the Act is in operation, at this stage, the
investigation is quasi-inquisitorial, to the extent that the report given is inconclusive of the rights of
the parties. However, he states that, stemming from Excel Crop Care Ltd. v. Competition
Commission of India, (2017) 8 SCC 47, the DG has the right to investigate the subject matter, along
with other allied and unenumerated issues, involving others (i.e. third parties). He additionally
states that once you are a part of the Facebook company, you mechanically fall under the purview of
Section 4 of the Act. Furthermore, it is judicially prudent for the Applicant to implead itself in
appeal when the principle Order has not been challenged.
25. Heard Mr. Harish Salve, learned Senior Counsel appearing for Appellant in LPA 163/2021, Mr.
Mukul Rohatgi, learned Senior Counsel appearing for Appellant in LPA 164/2021, Mr. N.
Venkataraman and Mr. Balbir Singh, learned ASGs for CCI-Respondent No.1 in both the appeals,
and Mr.Parag Tripathi, learned Senior Advocate for the Applicant in CM APPL. 40334/2021, and
perused the material on record.
26. At the outset, it becomes pertinent to delineate the objective of the Competition Act, 2002, and
the role of the CCI. The objective of the Act is set out in the Preamble itself, i.e. to establish a
Commission to prevent practices having adverse effect on competition, to promote and sustain
competition in markets, to protect the interests of consumers, and to ensure the freedom of trade
carried on by other participants in markets, in India, and for matters connected therewith or
incidental thereto. Chapter II of the Competition Act prohibits certain agreements, abuse of
dominant position, and regulation of combinations, with Section 4 specifically prohibiting the abuse
of dominant position. Chapter IV of the Act deals with provisions which set out the duties, powers
and functions of the CCI, with Section 18 stating that it shall be the duty of the Commission to
eliminate practices relating to the principles set down in the Preamble itself [Refer to Competition
Commission of India v. State of Mizoram and Ors., 2022 SCC OnLine SC 63].
27. Therefore, as has been succinctly enumerated by the Supreme Court in Competition Commission
of India v. Steel Authority of India (supra), the main objective of competition law is to promote
economic efficiency using competition as one of the means of assisting the creation of a market
responsive to consumer preferences. Satisfactory implementation of competition law would lead to a
threefold advantageous system wherein there would be allocative efficiency, which ensures effective
allocation of resources; productive efficiency, which ensures that costs of production are kept at a
minimum; and dynamic efficiency, which promotes innovative practices. One can only proceed
ahead with a matter entailing an attack to the jurisdiction of the CCI by keeping these objectives of
the Competition Act in mind.
28. The primary issue that has been submitted before this Court is with regard to the overlapping
jurisdiction of the CCI and the Constitutional Courts, and whether CCI should abstain from
exercising its jurisdiction to maintain comity between decisions of different authorities on the same
issues. In this context, the Appellants have placed heavy reliance on Competition Commission ofFacebook Inc vs Competition Commission Of India & Anr. on 25 August, 2022

India v. Bharti Airtel (supra) to submit that therein the sectoral regulator, i.e. TRAI, had been given
leeway by the Supreme Court to conduct its inquiry, over CCI.
29. The learned Single Judge has culled out the relevant portion of the said Judgement wherein the
scope and ambit of the two specialised regulators have been considered to deal with a complaint
regarding denial of Points of Interconnection to one of the telecom operators. This Court deems it fit
to reproduce the relevant paragraphs of the said Judgement as follows:
"100. In the instant case, dispute raised by RJIL specifically touches upon these
aspects as the grievance raised is that the IDOs have not given POIs as per the licence
conditions resulting into non- compliance and have failed to ensure inter se technical
compatibility thereby. Not only RJIL has raised this dispute, it has even specifically
approached TRAI for settlement of this dispute which has arisen between various
service providers, namely, RJIL on the one hand and the IDOs on the other, wherein
COAI is also roped in. TRAI is seized of this particular dispute.
*****
103. We are of the opinion that as TRAI is constituted as an expert regulatory body
which specifically governs the telecom sector, the aforesaid aspects of the disputes
are to be decided by TRAI in the first instance. These are jurisdictional aspects.
Unless TRAI finds fault with the IDOs on the aforesaid aspects, the matter cannot be
taken further even if we proceed on the assumption that CCI has the jurisdiction to
deal with the complaints/information filed before it. It needs to be reiterated that
RJIL has approached the DoT in relation to its alleged grievance of augmentation of
POIs which in turn had informed RJIL vide letter dated 6-9-2016 that the matter
related to interconnectivity between service providers is within the purview of TRAI.
RJIL thereafter approached TRAI; TRAI intervened and issued show-cause notice
dated 27-9- 2016; and post issuance of show-cause notice and directions, TRAI
issued recommendations dated 21-10- 2016 on the issue of interconnection and
provisioning of POIs to RJIL. The sectoral authorities are, therefore, seized of the
matter. TRAI, being a specialised sectoral regulator and also armed with sufficient
power to ensure fair, non-discriminatory and competitive market in the telecom
sector, is better suited to decide the aforesaid issues. After all, RJIL's grievance is that
interconnectivity is not provided by the IDOs in terms of the licences granted to
them. The TRAI Act and Regulations framed thereunder make detailed provisions
dealing with intense obligations of the service providers for providing POIs. These
provisions also deal as to when, how and in what manner POIs are to be provisioned.
They also stipulate the charges to be realised for POIs that are to be provided to
another service provider. Even the consequences for breach of such obligations are
mentioned.
104. We, therefore, are of the opinion that the High Court is right in concluding that
till the jurisdictional issues are straightened and answered by TRAI which wouldFacebook Inc vs Competition Commission Of India & Anr. on 25 August, 2022

bring on record findings on the aforesaid aspects, CCI is ill-equipped to proceed in
the matter. Having regard to the aforesaid nature of jurisdiction conferred upon an
expert regulator pertaining to this specific sector, the High Court is right in
concluding that the concepts of "subscriber", "test period", "reasonable demand",
"test phase and commercial phase rights and obligations", "reciprocal obligations of
service providers" or "breaches of any contract and/or practice", arising out of the
TRAI Act and the policy so declared, are the matters within the jurisdiction of the
Authority/Tdsat under the TRAI Act only. Only when the jurisdictional facts in the
present matter as mentioned in this judgment particularly in paras 72 and 102 above
are determined by TRAI against the IDOs, the next question would arise as to
whether it was a result of any concerted agreement between the IDOs and COAI
supported the IDOs in that endeavour. It would be at that stage CCI can go into the
question as to whether violation of the provisions of the TRAI Act amounts to "abuse
of dominance" or "anti-competitive agreements". That also follows from the reading
of Sections 21 and 21-A of the Competition Act, as argued by the respondents.
105. The issue can be examined from another angle as well. If CCI is allowed to
intervene at this juncture, it will have to necessarily undertake an exercise of
returning the findings on the aforesaid issues/aspects which are mentioned in para
102 above. Not only TRAI is better equipped as a sectoral regulator to deal with these
jurisdictional aspects, there may be a possibility that the two authorities, namely,
TRAI on the one hand and CCI on the other, arrive at conflicting views. Such a
situation needs to be avoided. This analysis also leads to the same conclusion,
namely, in the first instance it is TRAI which should decide these jurisdictional
issues, which come within the domain of the TRAI Act as they not only arise out of
the telecom licences granted to the service providers, the service providers are
governed by the TRAI Act and are supposed to follow various regulations and
directions issued by TRAI itself.
*****
108. Such a submission, on a cursory glance, may appear to be attractive. However,
the matter cannot be examined by looking into the provisions of the TRAI Act alone.
Comparison of the regimes and purpose behind the two Acts becomes essential to
find an answer to this issue. We have discussed the scope and ambit of the TRAI Act
in the given context as well as the functions of TRAI. No doubt, we have accepted that
insofar as the telecom sector is concerned, the issues which arise and are to be
examined in the context of the TRAI Act and related regime need to be examined by
TRAI. At the same time, it is also imperative that specific purpose behind the
Competition Act is kept in mind. This has been taken note of and discussed in the
earlier part of the judgment. As pointed out above, the Competition Act frowns at the
anti-competitive agreements. It deals with three kinds of practices which are treated
as anti-competitive and are prohibited. To recapitulate, these are:Facebook Inc vs Competition Commission Of India & Anr. on 25 August, 2022

(a) where agreements are entered into by certain persons with a view to cause an
appreciable adverse effect on competition;
(b) where any enterprise or group of enterprises, which enjoys dominant position,
abuses the said dominant position; and
(c) regulating the combination of enterprises by means of mergers or amalgamations
to ensure that such mergers or amalgamations do not become anti-competitive or
abuse the dominant position which they can attain.
109. CCI is specifically entrusted with duties and functions, and in the process empower as well, to
deal with the aforesaid three kinds of anti-competitive practices. The purpose is to eliminate such
practices which are having adverse effect on the competition, to promote and sustain competition
and to protect the interest of the consumers and ensure freedom of trade, carried on by other
participants, in India. To this extent, the function that is assigned to CCI is distinct from the
function of TRAI under the TRAI Act. The learned counsel for the appellants are right in their
submission that CCI is supposed to find out as to whether the IDOs were acting in concert and
colluding, thereby forming a cartel, with the intention to block or hinder entry of RJIL in the market
in violation of Section 3(3)(b) of the Competition Act. Also, whether there was an anti-competitive
agreement between the IDOs, using the platform of COAI. CCI, therefore, is to determine whether
the conduct of the parties was unilateral or it was a collective action based on an agreement.
Agreement between the parties, if it was there, is pivotal to the issue. Such an exercise has to be
necessarily undertaken by CCI. In Haridas Exports [Haridas Exports v. All India Float Glass
Manufacturers' Assn., (2002) 6 SCC 600] , this Court held that where statutes operate in different
fields and have different purposes, it cannot be said that there is an implied repeal of one by the
other. The Competition Act is also a special statute which deals with anti-competition. It is also to be
borne in mind that if the activity undertaken by some persons is anti- competitive and offends
Section 3 of the Competition Act, the consequences thereof are provided in the Competition Act.
*****
112. Obviously, all the aforesaid functions not only come within the domain of CCI, TRAI is not at all
equipped to deal with the same. Even if TRAI also returns a finding that a particular activity was
anti- competitive, its powers would be limited to the action that can be taken under the TRAI Act
alone. It is only CCI which is empowered to deal with the same anti-
competitive act from the lens of the Competition Act. If such activities offend the provisions of the
Competition Act as well, the consequences under that Act would also follow. Therefore, contention
of the IDOs that the jurisdiction of CCI stands totally ousted cannot be accepted. Insofar as the
nuanced exercise from the standpoint of the Competition Act is concerned, CCI is the experienced
body in conducting competition analysis. Further, CCI is more likely to opt for structural remedies
which would lead the sector to evolve a point where sufficient new entry is induced thereby
promoting genuine competition. This specific and important role assigned to CCI cannot be
completely wished away and the "comity" between the sectoral regulator (i.e. TRAI) and the marketFacebook Inc vs Competition Commission Of India & Anr. on 25 August, 2022

regulator (i.e. CCI) is to be maintained.
113. The conclusion of the aforesaid discussion is to give primacy to the respective objections (sic
objectives) of the two regulators under the two Acts. At the same time, since the matter pertains to
the telecom sector which is specifically regulated by the TRAI Act, balance is maintained by
permitting TRAI in the first instance to deal with and decide the jurisdictional aspects which can be
more competently handled by it. Once that exercise is done and there are findings returned by TRAI
which lead to the prima facie conclusion that the IDOs have indulged in anti-
competitive practices, CCI can be activated to investigate the matter going by the criteria laid down
in the relevant provisions of the Competition Act and take it to its logical conclusion. This balanced
approach in construing the two Acts would take care of Section 60 of the Competition Act as well.
114. We, thus, do not agree with the appellants that CCI could have dealt with this matter at this
stage itself without availing the inquiry by TRAI. We also do not agree with the respondents that
insofar as the telecom sector is concerned, jurisdiction of CCI under the Competition Act is totally
ousted. In a nutshell, that leads to the conclusion that the view taken by the High Court is perfectly
justified. Even the argument of the learned ASG is that the exercise of jurisdiction by CCI to
investigate an alleged cartel does not impinge upon TRAI's jurisdiction to regulate the industry in
any way. It was submitted that the promotion of competition and prevention of competitive
behaviour may not be high on the change of sectoral regulator which makes it prone to "regulatory
capture" and, therefore, CCI is competent to exercise its jurisdiction from the standpoint of the
Competition Act. However, having taken note of the skilful exercise which TRAI is supposed to carry
out, such a comment vis-à-vis TRAI may not be appropriate. No doubt, as commented by the
Planning Commission in its report of February 2007, a sectoral regulator, may not have an overall
view of the economy as a whole, which CCI is able to fathom. Therefore, our analysis does not bar
the jurisdiction of CCI altogether but only pushes it to a later stage, after TRAI has undertaken
necessary exercise in the first place, which it is more suitable to carry out." (emphasis supplied)
30. A reading of the aforesaid paragraphs of the Judgement indicates that the sole issue therein was
a conflict between the jurisdiction of a sectoral regulator and the market regulator. The Supreme
Court came to a finding that the matter pertained to the telecom sector, which was specifically
regulated by the TRAI Act. However, it noted that the jurisdiction of TRAI would not oust that of
CCI to deal with violations of Competition Act and violations thereunder. Moreover, Paragraph 100
of the Judgement states that in the case therein, the dispute pertained to how Incumbent Dominant
Operators (IDOs) had not given Points of Interconnect (POIs) as per the license conditions, and
Reliance Jio Infocomm Ltd. (RJIL) had specifically approached TRAI for the settlement of this
dispute. TRAI, being the authority that would mandate the adherence to licensing conditions, was,
therefore, deemed fit to be seized of the matter before the charge of investigation could be given to
the CCI.
31. It is the contention of the Appellants that since the underlying issues arising before the Apex
Court and this Court, and the investigation that is sought to be conducted by the CCI are common,
this can potentially lead to conflicting opinions. This contention of the Appellants is not acceptable.Facebook Inc vs Competition Commission Of India & Anr. on 25 August, 2022

It is the case of the Appellants that while the Apex Court is looking into whether the 2021 Policy is
violative of the right to privacy under Article 21 of the Constitution of India or not, the investigation
by CCI is confined to whether the 2021 Policy is in furtherance of the dominant position occupied by
WhatsApp and institutes anti-competitive practices. The sphere of operation of both are vastly
different. Neither this Court nor the Supreme Court are analysing the 2021 Policy through the prism
of competition law. The Order dated 24.03.2021 rendered by the CCI also notes the same:
"13. In relation to the above mentioned contentions of WhatsApp, the Commission is
of the view that the judgments relied by WhatsApp have no relevance to the issues
arising in the present proceedings and its plea is misplaced and erroneous. The
judgment of the Hon'ble Supreme Court in Bharti Airtel Case has no application to
the facts of the present case as the thrust of the said decision was to maintain 'comity'
between the sectoral regulator (i.e. TRAI, in the said case) and the market regulator
(i.e. the CCI). WhatsApp has failed to point out any proceedings on the subject matter
which a sectoral regulator is seized of. Needless to add, the Commission is examining
the policy update from the perspective of competition lens in ascertaining as to
whether such policy updates have any competition concerns which are in violation of
the provisions of Section 4 of the Act. Further, the Commission is of the considered
view that in a data driven ecosystem, the competition law needs to examine whether
the excessive data collection and the extent to which such collected data is
subsequently put to use or otherwise shared, have anti-competitive implications,
which require anti-trust scrutiny. The reliance of WhatsApp on Vinod Kumar Gupta
and other cases is also misplaced as the Commission has only observed that breach of
the Information Technology Act does not fall within its purview. However, in digital
markets, unreasonable data collection and sharing thereof, may grant competitive
advantage to the dominant players and may result in exploitative as well as
exclusionary effects, which is a subject matter of examination under competition law.
It is trite to mention that the provisions of the Act are in addition to and not in
derogation of the provisions of any other law, as declared under Section 62 of the
Act."
32. The observation of the learned Single Judge that certain issues that the CCI is seized of "may
substantially be in issue before the Supreme Court and this Court" does not lead to a conclusion that
the Supreme Court or this Court are adjudicating upon the same issue. Contrary to what has been
submitted by the Appellants, this observation cannot be interpreted as a holding that the issues
being considered by both the authorities are the same. Even if the issues are the same, the approach
of the authorities is vastly dissimilar, and there exists no inviolable rule that the CCI would
completely lack jurisdiction in the instant matter. Parallel inquiries by two different authorities in
their respective spheres of adjudication is not uncommon and a slight overlap between the inquiries
does not mean that one must lead to the ouster of the other. Therefore, in the absence of any
irreconcilable repugnancy between the jurisdiction of both the authorities, i.e. CCI and the
Constitutional Courts, the CCI has the liberty to proceed ahead with its investigation under Section
26(1) of the Act.Facebook Inc vs Competition Commission Of India & Anr. on 25 August, 2022

33. The investigation conducted by the CCI will not be affected by the outcome of the proceedings
pending before the Apex Court and this Court. In the event the Supreme Court upholds the 2021
Policy, then surely CCI can venture into the question as to whether the provisions of the Act have
been violated or not. In the event that the 2021 Policy is set aside by the Supreme Court, the CCI will
still possess the jurisdiction to investigate the violation of the Act, if any, during the pendency of the
matter before the Supreme Court when the 2021 Policy was in operation. In either of the cases, it
cannot be stated that the CCI does not have the authority look into this affair being the market
regulator.
34. It further becomes necessary to examine the scope and ambit of Section 26(1) of the Act which
has been done in Competition Commission of India v. Steel Authority of India (supra) and has been
relied upon by the learned Single Judge. The relevant portion of the said Judgement is as follows:
"38. In contradistinction, the direction under Section 26(1) after formation of a prima
facie opinion is a direction simpliciter to cause an investigation into the matter.
Issuance of such a direction, at the face of it, is an administrative direction to one of
its own wings departmentally and is without entering upon any adjudicatory process.
It does not effectively determine any right or obligation of the parties to the lis.
Closure of the case causes determination of rights and affects a party i.e. the
informant; resultantly, the said party has a right to appeal against such closure of
case under Section 26(2) of the Act. On the other hand, mere direction for
investigation to one of the wings of the Commission is akin to a departmental
proceeding which does not entail civil consequences for any person, particularly, in
light of the strict confidentiality that is expected to be maintained by the Commission
in terms of Section 57 of the Act and Regulation 35 of the Regulations.
39. Wherever, in the course of the proceedings before the Commission, the
Commission passes a direction or interim order which is at the preliminary stage and
of preparatory nature without recording findings which will bind the parties and
where such order will only pave the way for final decision, it would not make that
direction as an order or decision which affects the rights of the parties and therefore,
is not appealable.
*****
91. The jurisdiction of the Commission, to act under this provision, does not
contemplate any adjudicatory function. The Commission is not expected to give
notice to the parties i.e. the informant or the affected parties and hear them at length,
before forming its opinion. The function is of a very preliminary nature and in fact, in
common parlance, it is a departmental function. At that stage, it does not condemn
any person and therefore, application of audi alteram partem is not called for.
Formation of a prima facie opinion departmentally (the Director General, being
appointed by the Central Government to assist the Commission, is one of the wings of
the Commission itself) does not amount to an adjudicatory function but is merely ofFacebook Inc vs Competition Commission Of India & Anr. on 25 August, 2022

administrative nature. At best, it can direct the investigation to be conducted and
report to be submitted to the Commission itself or close the case in terms of Section
26(2) of the Act, which order itself is appealable before the Tribunal and only after
this stage, there is a specific right of notice and hearing available to the
aggrieved/affected party. Thus, keeping in mind the nature of the functions required
to be performed by the Commission in terms of Section 26(1), we are of the
considered view that the right of notice or hearing is not contemplated under the
provisions of Section 26(1) of the Act.
93. We may also usefully note that the functions performed by the Commission under
Section 26(1) of the Act are in the nature of preparatory measures in contrast to the
decision-making process. That is the precise reason that the legislature has used the
word "direction" to be issued to the Director General for investigation in that
provision and not that the Commission shall take a decision or pass an order
directing inquiry into the allegations made in the reference to the Commission."
35. A reading of the above Judgement indicates that the jurisdiction of the CCI under Section 26(1)
does not contemplate an adjudicatory function, but is merely a function of an administrative nature.
Accordingly, there is no right of notice or hearing contemplated under the provisions of Section
26(1) of the Act. It is in nature of preparatory measures in contrast to the decision- making process,
and this nature is evident from the usage of the term "direction" that is issued to the Director
General for investigation in that provision. In light of this, it becomes clear as day that the function
that is performed by the CCI under Section 26(1) of the Act would not be affected by the
adjudication by the Supreme Court or this Court while analysing the potential violation of
fundamental rights instigated by the 2021 Policy.
36. Moreover, the contention of the Appellants that the CCI in Vinod Kumar Gupta (supra) has
already assessed the 2016 Policy, and has come to conclusion that the breach of the IT Act, 2000,
does not fall within the purview of the CCI, is irrelevant on the ground that, as has been stated in the
CCI Order as well, the CCI is only concerned with data accumulation that may result in exploitative
and exclusionary competitive practices as well as the effect of data sharing on market capture and
competitors' offerings. Furthermore, it is pertinent to note that the 2021 Policy is a substantially
modified version of the 2016 Policy inasmuch as the 2016 Policy had an "opt-out" option, which is
absent from the 2021 Policy that places its users in a "take-it-or-leave-it" situation. It is the
"opt-out" option that primarily led to CCI rendering its conclusion that the 2016 Policy did not
violate the Competition Act, 2002. However, in the face of changed circumstances, considering the
dominant position occupied by WhatsApp, the investigation proposed to be conducted by CCI does
not warrant interference, and res judicata would, thus, not be applicable in the instant case. In view
of this, the fact that the Order of the CCI in Vinod Kumar Gupta (supra) has been upheld by the
NCLAT vide Order dated 02.08.2022 is of no relevance and does not sway the opinion of this Court.
Similarly, the emphasis placed by the Appellants on the letter dated 18.05.2021 is wholly irrelevant
as the mere mentioning of the Competition Act does not denote that MeiTY is seized of the
violations that may be incited by the 2021 Policy. The sphere of jurisdiction occupied by MeiTY is
different from that of the CCI, and solely because the said letter alludes to possible violations of theFacebook Inc vs Competition Commission Of India & Anr. on 25 August, 2022

Act does not oust the jurisdiction of the CCI. Per contra, the letter only strengthens the contention of
Respondent No.1 that there does exist a prima facie violation of the provisions of Competition Act,
2002. It is further a matter of public knowledge that the Personal Data Protection Bill, as of date,
has been withdrawn.
37. The second issue which has been agitated before this Court by both the Appellants is that the CCI
has failed to discern a prima facie case that would entail a direction to the DG to investigate the
alleged anti-competitive practices. Before delving into this, it would be prudent to reproduce
relevant portions of Sections 4, 19 and 26 of the Act:
"4. [(1) No enterprise or group shall abuse its dominant position.] (2) There shall be
an abuse of dominant position [under sub-section (1), if an enterprise or a group].---
(a) directly or indirectly, imposes unfair or discriminatory--
(i) condition in purchase or sale of goods or service; or
(ii) price in purchase or sale (including predatory price) of goods or service.
Explanation.-- For the purposes of this clause, the unfair or discriminatory condition in purchase or
sale of goods or service referred to in sub-clause (i) and unfair or discriminatory price in purchase or
sale of goods (including predatory price) or service referred to in sub-clause (ii) shall not include
such discriminatory condition or price which may be adopted to meet the competition; or
(b) limits or restricts--
(i) production of goods or provision of services or market therefor; or
(ii) technical or scientific development relating to goods or services to the prejudice of consumers; or
(c) indulges in practice or practices resulting in denial of market access [in any manner]; or
(d) makes conclusion of contracts subject to acceptance by other parties of supplementary
obligations which, by their nature or according to commercial usage, have no connection with the
subject of such contracts; or
(e) uses its dominant position in one relevant market to enter into, or protect, other relevant market.
Explanation.--For the purposes of this section, the expression--
(a) "dominant position" means a position of strength, enjoyed by an enterprise, in the relevant
market, in India, which enables it to--
(i) operate independently of competitive forces prevailing in the relevant market; orFacebook Inc vs Competition Commission Of India & Anr. on 25 August, 2022

(ii) affect its competitors or consumers or the relevant market in its favour.
(b) "predatory price" means the sale of goods or provision of services, at a. price which is below the
cost, as may be determined by regulations, of production of the goods or provision of services, with a
view to reduce competition or eliminate the competitors."
*****
19. (1) The Commission may inquire into any alleged contravention of the provisions contained in
subsection (1) of section 3 or sub-section (1) of section 4 either on its own motion or on--
(a) [receipt of any information, in such manner and] accompanied by such fee as may be determined
by regulations, from any person, consumer or their association or trade association; or
(b) a reference made to it by the Central Government or a State Government or a statutory authority
*****
19. (4) The Commission shall, while inquiring whether an enterprise enjoys a dominant position or
not under section 4, have due regard to all or any of the following factors, namely:--
(a) market share of the enterprise;
(b) size and resources of the enterprise;
(c) size and importance of the competitors;
(d) economic power of the enterprise including commercial advantages over
competitors;
(e) vertical integration of the enterprises or sale or service network of such
enterprises;
(f) dependence of consumers on the enterprise;
(g) monopoly or dominant position whether acquired as a result of any statute or by
virtue of being a Government company or a public sector undertaking or otherwise;
(h) entry barriers including barriers such as regulatory barriers, financial risk, high
capital cost of entry, marketing entry barriers, technical entry barriers, economies of
scale, high cost of substitutable goods or service for consumers;
(i) countervailing buying power;
(j) market structure and size of market;Facebook Inc vs Competition Commission Of India & Anr. on 25 August, 2022

(k) social obligations and social costs; (I) relative advantage, by way of the
contribution to the economic development, by the enterprise enjoying a dominant
position having or likely to have an appreciable adverse effect on competition;
(m) any other factor which the Commission may consider relevant for the inquiry
*****
26. (1) On receipt of a reference from the Central Government or a State Government
or a statutory authority or on its own knowledge or information received under
section 19, if the Commission is of the opinion that there exists a prima facie case, it
shall direct the Director General to cause an investigation to be made into the matter:
Provided that if the subject matter of an information received is, in the opinion of the
Commission, substantially the same as or has been covered by any previous
information received, then the new information may be clubbed with the previous
information."
38. Whether or not the Appellants occupy a dominant position in the relevant
geographical market and the relevant product market has been decided by the CCI in
Harshita Chawla v. WhatsApp Inc and Anr. (supra).
The relevant portion of the said Order which elaborates the finding that, given its popularity and
wide usage, WhatsApp seems to be dominant, has been reproduced as under:
"84. Such data shows that WhatsApp messenger is the most widely used app for
social messaging, followed by Facebook Messenger in the relevant market delineated
by the Commission supra. Further, it is way ahead of other messaging apps like
Snapchat, WeChat etc. showing its relative strength. Given that WhatsApp messenger
and Facebook Messenger are owned by the same group, they do not seem to be
constrained by each other, rather adding on to their combined strength as a group.
Moreover, WhatsApp Messenger works on direct network effects where an increase
in usage of a particular platform leads to a direct increase in the value for other
users--and the value of a platform to a new user will depend on the number of
existing users on that platform. Thus, given its popularity and wide usage, for
one-to-one as well as group communications and its distinct and unique features,
WhatsApp seems to be dominant.
85. The Commission is cognizant that the data relied upon by the Informant cannot
be said to be free from infirmities and is based on global usage or users. However, in
the absence of concrete data/information available in the Indian context other than
the subjective information on popularity of WhatsApp, the Commission is of the view
that these trends and results can be used as a proxy. More so, these trends appear to
be intuitively in sync with the information available in public domain, which though
does not confirm market share/strength of WhatsApp in any quantitative terms,Facebook Inc vs Competition Commission Of India & Anr. on 25 August, 2022

nevertheless point towards its dominance.
86. Further, with respect to the dependence of consumers on the enterprise and
countervailing buyer power, WhatsApp undeniably has the advantage of reaping the
benefits of network effect. Network effect in turn ensures that customers do not
switch to other platforms easily unless there is a new competitor entering the market
with an altogether disruptive technology. Moreover, lack of interoperability between
platforms is another concern, as a result of which customers may be unwilling to
incur switching costs, despite the same being primarily psychological.
87. As regards the barriers to entry, they may arise indirectly as a result of the
networks effects enjoyed by the dominant player in the market, i.e. WhatsApp, in the
present case. Since networks effects lead to increased switching costs, new players
may be disincentivized from entering the market.
88. Thus, in view of the aforementioned factors, the Commission prima facie finds
WhatsApp to be dominant in the first relevant market i.e. „market for OTT messaging
apps through smartphones in India."
39. The dominance of the Appellant in LPA 163/2021 has also been deliberated upon by the
Respondent No.1 and the following has been stated by the same in its Order dated 24.03.2021:
"20. Based on the above, the Commission concluded that WhatsApp is dominant in
the relevant market for OTT messaging apps through smartphones in India. As such,
in light of the said holding of the Commission in Harshita Chawla case, there is no
occasion to separately and independently examine the issue of relevant market and
dominance of WhatsApp therein, when there is no change in the market construct or
structure since the passing of the said order in August, 2020 and announcing of the
new policy by WhatsApp on January 04, 2021 - which itself seems to emanate out of
the entrenched dominant position of WhatsApp in the said relevant market, as
detailed in this order. The Commission has also taken note of the recent
developments wherein the competing apps, i.e. Signal and Telecom witnessed a surge
in downloads after the policy announcement by WhatsApp. However, apparently this
has not resulted in any significant loss of users for WhatsApp. FUliher, as elaborated
in detail in succeeding paras, the network effects working in favour of WhatsApp
reinforces its position of strength and limit its substitutability with other functionally
similar apps/platforms."
40. The learned Single Judge, after a careful consideration of the CCI Order dated 24.03.2021, has
also arrived at the same conclusion that WhatsApp assumes a dominant position in the relevant
product market and the relevant geographical market, and has recorded its observations as under:
"20. A reading of the above would show that the respondent no. 1 has prima facie
concluded that WhatsApp is dominant in the relevant market for Over- the-TopFacebook Inc vs Competition Commission Of India & Anr. on 25 August, 2022

(OTT) messaging apps through smartphones in India; due to lack of/restricted
interoperability between platforms, the users may find it difficult to switchover to
other applications except at a significant loss; there is opacity, vagueness,
open-endedness and incomplete disclosures in the 2021 Update on vital information
categories; concentration of data in WhatsApp and Facebook itself may raise
competition concerns; data-sharing amounts to degradation of non-price parameters
of competition."
Therefore, as can be discerned from the foregoing, WhatsApp occupies a dominant position in a
market for OTT messaging apps through smartphones in India.
41. Having arrived at this conclusion, it becomes relevant for the CCI to have formed a prima facie
case before issuing a direction to the Director General to cause an investigation to be made into the
matter under Section 26(1). The term "prima facie case" has been discussed in various cases by the
Supreme Court, such as Competition Commission of India v. Steel Authority of India (supra)
wherein it was observed as under:
"37. As already noticed, in exercise of its powers, the Commission is expected to form
its opinion as to the existence of a prima facie case for contravention of certain
provisions of the Act and then pass a direction to the Director General to cause an
investigation into the matter. These proceedings are initiated by the intimation or
reference received by the Commission in any of the manners specified under Section
19 of the Act. At the very threshold, the Commission is to exercise its powers in
passing the direction for investigation; or where it finds that there exists no prima
facie case justifying passing of such a direction to the Director General, it can close
the matter and/or pass such orders as it may deem fit and proper. In other words, the
order passed by the Commission under Section 26(2) is a final order as it puts an end
to the proceedings initiated upon receiving the information in one of the specified
modes. This order has been specifically made appealable under Section 53-A of the
Act.
*****
97..........Even if it is a direction under any of the provisions and not a decision,
conclusion or order passed on merits by the Commission, it is expected that the same
would be supported by some reasoning. At the stage of forming a prima facie view, as
required under Section 26(1) of the Act, the Commission may not really record
detailed reasons, but must express its mind in no uncertain terms that it is of the
view that prima facie case exists, requiring issuance of direction for investigation to
the Director General. Such view should be recorded with reference to the information
furnished to the Commission. Such opinion should be formed on the basis of the
records, including the information furnished and reference made to the Commission
under the various provisions of the Act, as aforereferred. However, other decisions
and orders, which are not directions simpliciter and determining the rights of theFacebook Inc vs Competition Commission Of India & Anr. on 25 August, 2022

parties, should be well reasoned analysing and deciding the rival contentions raised
before the Commission by the parties. In other words, the Commission is expected to
express prima facie view in terms of Section 26(1) of the Act, without entering into
any adjudicatory or determinative process and by recording minimum reasons
substantiating the formation of such opinion, while all its other orders and decisions
should be well reasoned.
98. Such an approach can also be justified with reference to Regulation 20(4), which
requires the Director General to record, in his report, findings on each of the
allegations made by a party in the intimation or reference submitted to the
Commission and sent for investigation to the Director General, as the case may be,
together with all evidence and documents collected during investigation. The
inevitable consequence is that the Commission is similarly expected to write
appropriate reasons on every issue while passing an order under Sections 26 to 28 of
the Act."
42. Therefore, while forming a prima facie case, the CCI, while not being required to record detailed
reasons, must take into account all the material present, before expressing its mind, and this should
be done without entering into any adjudicatory or determinative process. A prima facie case need
not be a case proved to the hilt, but a case which can be said to be established if the evidence which
is led in support of the same were to be believed [Refer to Management of the Bangalore Woollen
Cotton and Silk Mills Co. Ltd. v. B. Dasappa, AIR 1960 SC 1352].
43. The contention of the Appellants is that the CCI Order does not meet the jurisdictional threshold
as no prima facie case has been established against the Appellants and the learned Single Judge has
erred in upholding the Order dated 24.03.2021. However, a perusal of the CCI Order dated
24.03.2021 reveals that sufficient reasoning has been provided before the CCI arrived at the
conclusion that a prima facie case of violation of Section 4 of the Act was made. The paragraphs of
the said Order indicating the same are as under:
"25. Having considered the overarching terms and conditions of the new policy, the
Commission is of prima facie opinion that the 'take-it-or-Ieave-it' nature of privacy
policy and terms of service of WhatsApp and the information sharing stipulations
mentioned therein, merit a detailed investigation in view of the market position and
market power enjoyed by WhatsApp. The Commission has also taken note of the
submission ofWhatsApp that 2021 Update does not expand WhatsApp's ability to
share data with Facebook and the said 'update intends to provide users with further
transparency about how WhatsApp collects, uses and shares data. The veracity of
such claims would also be examined during the investigation by the DG.
26. WhatsApp is the most widely used app for instant messaging in India. A
communication network/platform gets more valuable as more users join it, thereby
benefiting from network effects. The OTT messaging platforms not being
interoperable, communication between two users is enabled only when both areFacebook Inc vs Competition Commission Of India & Anr. on 25 August, 2022

registered on the same network. Thus, the value of a messaging apps platform
increases for users with an increasing number of their friends and acquaintances
joining the network. In India, the network effects have indubitably set in for
WhatsApp, which undergird its position of strength and limit its substitutability with
other functionally similar apps/platforms. This, in turn, causes a strong lock-in effect
for users, switching to another platform for whom gets difficult and meaningless until
all or most of their social contacts also switch to the same other platform. Users
wishing to switch would have to convince their contacts to switch and these contacts
would have to persuade their other contacts to switch. Thus, while it may be
technically feasible to switch, the pronounced network effects of" WhatsApp
significantly circumscribe the usefulness of the same. The network effects have been
reflected when despite increase in downloads of the competing apps like Signal and
Telegram, user base of WhatsApp apparently did not suffer any significant loss. As
pointed out in Harshita Chawla case (supra), the second largest player in terms of
market share in the relevant market of instant messaging and thus the next sizeable
alternative available to users is Facebook Messenger, which too is a Facebook Group
company. Thus, the conduct' of WhatsApp/ Facebook under consideration merits
detailed scrutiny.
27. The Commission is of further opinion that users, as owners of their personalised
data, are entitled to be informed about the extent, scope and precise purpose of
sharing of such data by WhatsApp with other Facebook Companies. However, it
appears from the Privacy Policy as well as Terms of Service (including the FAQs
published by WhatsApp), that many of the informati0n categories described therein
are too broad, vague and unintelligible. For instance, information on how users
"interact with others (including businesses)" is not clearly defined, what would
constitute "service-related information", "mobile device information", "payments or
business features", etc. are also undefined. It is also pertinent to note that at
numerous places in the policy while illustrating the data to be collected, the list is
indicative and not exhaustive due to usage of words like 'includes', 'such as', 'For
example', etc., which suggests that the scope of sharing may extend beyond the
information categories that have been expressly mentioned in the policy. Such
opacity, vagueness, open-endedness and incomplete disclosures hide the actual data
cost that a user incurs for availing WhatsApp services. It is also not clear from the
policy whether the historical data of users would also be shared with Facebook
Companies and whether data would be shared in respect ofthose WhatsApp users
also who are not present on other apps of Facebook i.e., Facebook, Instagram, etc.
28. Further, users are not likely to expect their personal data to be shared with third
parties ordinarily except for the limited purpose of providing or improving
WhatsApp's service. However, it appears from the wordings of the policy that the
data sharing scheme is also intended to, inter alia, 'customise', 'personalise' and
'market' the offerings of other Facebook Companies. Under competitive market
condition, users would have sovereign rights and control over decisions related toFacebook Inc vs Competition Commission Of India & Anr. on 25 August, 2022

sharing oftheir personalised data. However, this is not the case with WhatsApp users
and moreover, there appears to be no justifiable reason as to why users should not
have any control or say over such cross-product processing of their data by way of
voluntary consent, and not as a precondition for availing WhatsApp's services.
29. As pointed out previously, users earlier had such control over sharing of their
personal data with Facebook, in terms of an 'opt-out' provision available for 30 days
in the previous policy updates. However, the same has not been made available to
users this time. Thus, users are required to accept the unilaterally dictated
'take-it-or-leave-it' terms by a dominant messaging platform in their entirety,
including the data sharing provisions therein, if they wish to avail their service. Such
"consent" cannot signify voluntary agreement to all the specific processing or use of
personalised data, as provided in the present policy. Users have not been provided
with appropriate granular choice, neither upfront nor in the fine prints, to object to
or opt-out of specific data sharing terms, which prima facie appear to be unfair and
unreasonable for the WhatsApp users.
30. On a careful and thoughtful consideration of the matter, the conduct of
WhatsApp in sharing of users' personalised data with other Facebook Companies, in
a manner that is neither fully transparent nor based on voluntary and specific user
consent, appears prima facie unfair to users. The purpose of such sharing appears to
be beyond users reasonable and legitimate expectations regarding quality, security
and other relevant aspects of the service for which they register on WhatsApp. On of
hte stated purposes of data sharing viz. Targeted ad offerings on other Facebook
products rather indicates the intended use being that of building user profiles
through cross-linking of data collected across services. Such data concentration may
itself raise competition concerns where it is perceived as a competitive advantage.
The impugned conduct of data-sharing by WhatsApp with Facebook apparently
amounts to degradation of non-price parameters of competition viz. quality which
result in objective detriment to consumers, without any acceptable justification. Such
conduct prima facie amounts to imposition of unfair terms and conditions upon the
users ofWhatsApp messaging app, in violation of the provisions of Section 4(2)(a)(i)
of the Act.
31. Given the pronounced network effects it enjoys, and the absence of any credible
competitor in the instant messaging market in India, WhatsApp appears to be in a
position to compromise quality in terms of protection of individualised data and can
deem it unnecessary to even retain the user-friendly alternatives such as 'opt- out'
choices, without the fear of erosion of its user base. Moreover, the users who do not
wish to continue with WhatsApp may have to lose their historical data as porting
such data from WhatsApp to other competing apps is not only a cumbersome and
time consuming process but, as already explained, network effects make it difficult
for the users to switch apps. This would enhance and accentuate switching costs for
the users who may want to shift to alternatives due to the policy changes.Facebook Inc vs Competition Commission Of India & Anr. on 25 August, 2022

32. Today's consumers value non-price parameters of services viz. quality, customer
service, innovation, etc. as equally if not more important as price. The competitors in
the market also compete on the basis of such non-price parameters. Reduction in
consumer data protection and loss of control over their personalised data by the
users can be taken as reduction in quality under the antitrust law. Lower data
protection by a dominant firm can lead to not only exploitation of consumers but can
also have exclusionary effects as WhatsApp/Facebook would be able to further
entrench/reinforce their position and leverage themselves in neighbouring or even in
unrelated markets such as display advertising market, resulting in insurmountable
entry barriers for new entrants.
33. Data and data analytics have immense relevance for competitive performance of
digital enterprises. Cross-linking and integration strengthen data advantage besides
safeguarding and reinforcing market power of dominant firms. For Facebook, the
processing of data collected from WhatsApp can be a means to supplement the
consumer profiling that it does through direct data collection on its platform, by
allowing it to track users and their communication behaviour across a vast number of
locations and devices outside Facebook platform. Therefore, the impugned data
sharing provision may have exclusionary effects also in the display advertising
market which has the potential to undermine the competitive process and creates
further barriers to market entry besides leveraging, in violation of the provisions of
Section 4(2)( c) and (e) of the Act. As per the 2021 update to the privacy policy, a
business may . give third-party service provider such as Facebook access to its
communications to send, store, read, manage, or otherwise process them for the
business. It may be possible that Facebook will condition provision of such services to
businesses with a requirement for using the data collected by them. The DG may also
investigate these aspects during its investigation.
34. In view of the foregoing, the Commission is of the considered opinion that
WhatsApp has prima /clcie contravened the provisions of Section 4 of the Act
through its exploitative and exclusionary conduct, as detailed in this order, in the
garb of policy update. A thorough and detailed investigation is required to ascertain
the full extent, scope and impact of data sharing through involuntary consent of
users."
44. It is not in dispute that WhatsApp occupies a dominant position in the relevant product market
and that there exists a strong lock-in effect which renders its users incapable of shifting to another
platform despite dissatisfaction with the product - as is exemplified by how, despite an increase in
the downloads of Telegram and Signal when the 2021 Policy was announced, the number of users of
WhatsApp have remained unchanged. By and large, to ensure retention of its user base and to
prevent any other disruptive technology from entering the market, data is utilised by tech
companies to customise and personalise their own platforms so that its userbase remains hooked.
When data concentration is seen through this prism, it does give meaning to the new adage that
"data is the new oil", and, as noted in the CCI Order dated 24.03.2021, it raises competitionFacebook Inc vs Competition Commission Of India & Anr. on 25 August, 2022

concerns because it prima facie amounts to imposition of unfair terms and conditions upon its
users, thereby violating Section 4(2)(a)(i) of the Act.
45. Furthermore, as Paragraph 33 of the CCI Order dated 24.03.2021 (which has been reproduced
hereinabove) states, accumulation and processing of personal data from WhatsApp, in addition to
its own direct data collection, can be done by Facebook for the purposes of consumer profiling that
allows for targeted ads, inter alia, which in turn has the potential to undermine competitive
processes and create further barriers to market entry in stark violation of Section 4(2)(c) and (e) of
the Act. In view of these observations, it is evident that CCI has, after due consideration, arrived at
its decision that a prima facie case of violation of provisions of the Competition Act, 2002, has been
made out against the Appellants herein that would require an investigation to be initiated by the
DG. The learned Single Judge has taken into consideration all these factors before observing that
concentration of data in the hands of WhatsApp may raise competition concerns, thereby resulting
in the violation of Section 4 of the Act.
46. Additionally, the reliance of the Appellants on CCI's Order in Vinod Kumar Gupta (supra) is
misplaced for the simple reason that 2016 Policy provided its users the option to "opt-out" of
sharing user account information with Facebook within 30 days of agreeing to the updated Terms of
Service and Privacy Policy. The 2021 Policy, however, places its users in a "take-it-or-leave-it"
situation, virtually forcing its users into agreement by providing a mirage of choice, and then
sharing their sensitive data with Facebook Companies envisaged in the policy. Therefore, it cannot
be said that the CCI is bound by its own findings in Vinod Kumar Gupta (supra) when the issue at
hand as well as the circumstances are different.
47. Apart from the aforesaid two issues, it is also the contention of the Appellant in LPA 164/2021
that it is a separate and distinct legal entity from WhatsApp, and therefore, it should not be
subjected to an intensive and intrusive investigation by the DG in pursuance of the findings of the
CCI under Section 26(1) of the Act. In this regard, the Court finds merit in the submission of the
learned ASGs that one of the key issues with the 2021 Policy is its propensity to share the data of its
users with Facebook Inc., the parent company of WhatsApp. Solely for the reason that the policies
itself do not emanate out of Facebook Inc., the Appellant cannot hide behind the fact that it is the
direct and immediate beneficiary of the data sharing mechanism envisaged by the policies. These
circumstances necessitate the presence of the Appellant in LPA 164/2021 as a proper party in the
investigation pertaining to the 2021 Policy and the alleged anti-competitive practices they trigger.
48. With regard to the submissions on behalf of Facebook India Online Services Pvt. Ltd., this Court
does not find any merit on the aspect of impleading the said party on account of the fact that the
decision of the DG to issue notice to the Applicant, designating it as an "Opposite Party", stems from
the information it has secured from Internet Freedom Foundation in Case No. 30 of 2021 regarding
its relevance in the investigation. The decision taken by the DG lies in the fact that a thorough
investigation can only be conducted if the Applicant cooperates in the same.
49. Furthermore, it is not contemplated in law that a party should be impleaded at the stage of an
appeal when it has not been a party to the matter at the stage when the decision from which theFacebook Inc vs Competition Commission Of India & Anr. on 25 August, 2022

appeal arises has been given, and the remedy of the Applicant only lies by way of a writ against the
Order by which it is aggrieved. The contention of Mr. Tripathi that the Applicant has chosen to
implead itself in the appeal filed by Facebook cannot be accepted by this Court. The Applicant will
have to first make out a prima facie case before the learned Single Judge that there is no allegation
against it in the Order of the CCI. The case of the Applicant would involve independent application
of mind by the learned Single Judge. The instant appeals are primarily on the issue as to whether the
CCI ought to wait till final adjudication of the issues which are pending before the Apex Court. The
Impleadment Application cannot be entertained in the instant appeals which have been filed by
Facebook Inc. and WhatsApp. This Court, therefore, does not deem it fit to scuttle the investigation
at a nascent stage and defers to the wisdom of the DG and the CCI, and rejects the Impleadment
Application. However, the Applicant is granted the liberty to take all such steps as required by it, in
accordance with law, to impugn the CCI Order.
50. In light of the aforesaid observations, this Court is of the opinion that the impugned Judgement
dated 22.04.2021, passed by the learned Single Judge in W.P.(C) 4378/2021 & W.P.(C) 4407/2021,
is well reasoned, and that the appeals filed by the Appellants are devoid of merit and substance that
would warrant the interference of this Court.
51. Accordingly, the instant appeals are dismissed, along with pending application(s), if any.
SATISH CHANDRA SHARMA, C.J.
SUBRAMONIUM PRASAD, J AUGUST 25, 2022 hsk.Facebook Inc vs Competition Commission Of India & Anr. on 25 August, 2022

