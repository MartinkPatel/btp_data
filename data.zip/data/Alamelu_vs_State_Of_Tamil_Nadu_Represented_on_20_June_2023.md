Alamelu vs State Of Tamil Nadu Represented on 20 June, 2023
Author: M.Sundar
Bench: M.Sundar
                                                                                      H.C.P.No.591 of 2023
                                    IN THE HIGH COURT OF JUDICATURE AT MADRAS
                                                      DATED: 20.06.2023
                                                             Coram
                                      THE HONOURABLE MR.JUSTICE M.SUNDAR
                                                     and
                                     THE HONOURABLE MR.JUSTICE R.SAKTHIVEL
                                                     H.C.P.No.591 of 2023
                     Alamelu                                                          .. Petitioner
                                                                vs
                     1.State of Tamil Nadu represented
                       By Secretary to Government
                       Home, Prohibition and Excise Department,
                       Fort St. George, Chennai – 600 009.
                     2.The Commissioner of Police,
                       Greater Chennai
                     3.The Superintendent of Prison,
                       Central Prison, Puzhal, Chennai.
                     4.State Rep. By Inspector of Police,
                      H-3, Tondiarpet Police Station
                      Chennai                                              .. Respondents
                                  Petition filed under Article 226 of the Constitution of India praying
                     for issuance of a writ of habeas corpus to call for the records of the 2 nd
                     respondent pertaining to the order made in No.348/BCDFGISSSV/2022
                     dated 10.10.2022 in detaining the detenu under the Tamilnadu Act
https://www.mhc.tn.gov.in/judis
                     1/10
                                                                                    H.C.P.No.591 of 2023
                     14/1982 as a Goonda and quash the same and direct the respondents toAlamelu vs State Of Tamil Nadu Represented on 20 June, 2023

                     produce the detenu, namely Ajithkumar @ Pongu, aged 22 years, son of
                     Ragavan who is detained at the Central Prison, Puzhal, Chennai before
                     this Court and set him at liberty.
                                  For Petitioner           :     Mr.P.Sridhar
                                  For Respondents          :     Mr.E.Raj Thilak,
                                                                 Additional Public Prosecutor
                                                            ORDER
[Order of the Court was made by M.SUNDAR, J.] Captioned 'Habeas Corpus Petition' ['HCP' for the
sake of brevity] has been filed by mother of detenu assailing a 'preventive detention order dated
10.10.2022 bearing reference BCDFGISSSV No.348/2022' [hereinafter 'impugned detention order'
for the sake of convenience and brevity]. To be noted, fourth respondent is the sponsoring authority
and second respondent is the detaining authority as impugned detention order has been made by
second respondent.
https://www.mhc.tn.gov.in/judis
2. When the captioned HCP was listed for admission before this Court, proceedings/orders dated
26.04.2023 was made in the 'Admission Board' and the same reads as follows:
' Read this in conjunction with and in continuation of earlier proceedings made in the
previous listing on 24.04.2023.
2. Mr.S.Ramachandran, learned counsel on record for petitioner expresses regret for
what happened in the previous listing.
3. Be that as it may, today, learned counsel has placed before us Sushanta Kumar
Banik's case [Sushanta Kumar Banik Vs. State of Tripura & others reported in CDJ
2022 SC 1064].
4. Captioned Habeas Corpus Petition has been filed in this Court on 06.04.2023 inter
alia assailing a detention order dated 10.10.2022 bearing reference
No.348/BCDFGISSSV/2022 made by 'second respondent' [hereinafter 'Detaining
Authority' for the sake of convenience and clarity]. To be noted, fourth respondent is
the Sponsoring Authority.
5. Mother of detenu is the petitioner.
6. Learned counsel for petitioner submits that ground case qua the detenu is for
alleged offence under Sections 147, 148, 341, 294(b), 307 and 506(ii) of 'The IndianAlamelu vs State Of Tamil Nadu Represented on 20 June, 2023

Penal Code (45 of 1860)' [hereinafter 'IPC' for the sake of convenience and clarity]
subsequently altered into Sections 147, 148, 341, 294(b), 307, 506(ii) and 109 of IPC
in Crime No.236 of 2022 on the file of H3 Tondiarpet Police Station.
https://www.mhc.tn.gov.in/judis
7. The aforementioned detention order has been made on the premise that the detenu is a 'Goonda'
under Section 2(f) of 'The Tamil Nadu Prevention of Dangerous Activities of Bootleggers, Cyber law
offenders, Drug-offenders, Forest-offenders, Goondas, Immoral traffic offenders, Sand-offenders,
Sexual-offenders, Slum- grabbers and Video Pirates Act, 1982 (Tamil Nadu Act No.14 of 1982)'
[hereinafter 'Act 14 of 1982' for the sake of convenience and clarity].
8. The detention order has been assailed inter alia on the ground that there is delay in passing the
impugned detention order since the detenu was arrested on 18.08.2022 and the impugned
detention order was passed on 10.10.2022.
9. Prima facie case made out for admission. Admit. Issue Rule nisi returnable by four weeks.
10. Mr.R.Muniyapparaj, learned Additional Public Prosecutor, State of Tamil Nadu accepts notice
for all respondents. List the captioned Habeas Corpus Petition accordingly.'
3. The aforementioned proceedings/orders made in the 'Admission Board' captures short facts
essential and imperative for appreciating this order and therefore without setting out the same
again, we deem it appropriate to say that aforementioned proceedings shall be read as an integral
part and parcel of this order. https://www.mhc.tn.gov.in/judis https://www.mhc.tn.gov.in/judis
4. There are two adverse cases. The ground case which constitutes substantial part of substratum of
the impugned detention order is Crime No.236 of 2022 on the file of H3 Tondiarpet Police Station
for the alleged offences under Sections 147, 148, 341, 294(b), 307 and 506(ii) of 'The Indian Penal
Code (45 of 1860)' [hereinafter 'IPC' for the sake of convenience and clarity] altered to 147, 148, 341,
294(b), 307, 506(ii) and 109IPC. Owing to the nature of the challenge to the impugned detention
order, it is not necessary to delve into the factual matrix or be detained further by facts.
5. Mr.P.Sridhar, learned counsel on record for petitioner and Mr.E.Raj Thilak, learned State
Additional Public Prosecutor for all respondents are before us.
6. Learned counsel for petitioner submits that 'live and proximate link' between the grounds of
detention and purpose of detention has snapped as date of remand in the ground case is 18.08.2022
but the impugned detention order has been made only on 10.10.2022.
7. Mr.E.Raj Thilak, learned State Additional Public Prosecutor, submits to the contrary by saying
that materials had to be collected and time was consumed for the same. Considering the facts and
circumstances of the case and nature of ground case, we find that this
https://www.mhc.tn.gov.in/judis explanation of learned State Additional Public Prosecutor isAlamelu vs State Of Tamil Nadu Represented on 20 June, 2023

unacceptable.
8. We remind ourselves of Sushanta Kumar Banik's case [Sushanta Kumar Banik Vs. State of
Tripura & others reported in 2022 LiveLaw (SC) 813 : 2022 SCC OnLine SC 5913]. To be noted,
Banik case law arose under 'Prevention of Illicit Traffic in Narcotic Drugs and Psychotropic
Substances Act, 1988' [hereinafter 'PIT NDPS Act' for the sake of brevity] in Tirupura, wherein after
considering the proposal by the Sponsoring Authority and after noticing the trajectory the matter
took, Hon'ble Supreme Court held that the 'live and proximate link between grounds of detention
and purpose of detention snapping' point should be examined on a case to case basis. Hon'ble
Supreme Court has held in Banik case law that this point has two facets. One facet is 'unreasonable
delay' and other facet is 'unexplained delay'. We find that the captioned matter falls under latter
facet i.e., unexplained delay.
9. To be noted, Banik case has been respectfully followed by this Court in Gomathi Vs.The Principal
Secretary to Government and others reported vide Neutral Citation of Madras High Court being
2023/MHC/334, Sadik Basha Yusuf Vs. The State of Tamil Nadu and others reported vide Neutral
Citation of Madras High Court being https://www.mhc.tn.gov.in/judis 2023/MHC/733, Sangeetha
Vs. The Secretary to the Government and others reported vide Neutral Citation of Madras High
Court being 2023:MHC:1110, N.Anitha Vs. The Secretary to Government and others reported vide
Neutral Citation of Madras High Court being 2023:MHC:1159 and a series of other orders in HCP
cases.
10. Before concluding, we also remind ourselves that preventive detention is not a punishment and
HCP is a high prerogative writ.
11. Ergo, the sequitur is, captioned HCP is allowed. Impugned detention order dated 10.10.2022
bearing reference BCDFGISSSV No.348/2022 made by the second respondent is set aside and the
detenu Thiru.Ajith Kumar @ Pongu, aged 22 years, son of Thiru.Raghavan, is directed to be set at
liberty forthwith, if not required in connection with any other case / cases. There shall be no order
as to costs.
(M.S.,J.) (R.S.V.,J.) 20.06.2023 Index : Yes Neutral Citation : Yes gpa P.S: Registry to forthwith
communicate this order to Jail authorities in Central Prison, Puzhal, Chennai.
https://www.mhc.tn.gov.in/judis To
1. The Secretary to Government Home, Prohibition and Excise Department, Fort St. George,
Chennai – 600 009.
2.The Commissioner of Police, Greater Chennai
3.The Superintendent of Prison, Central Prison, Puzhal, Chennai.
4.The Inspector of Police, H-3, Tondiarpet Police Station ChennaiAlamelu vs State Of Tamil Nadu Represented on 20 June, 2023

5.The Public Prosecutor, High Court, Madras.
https://www.mhc.tn.gov.in/judis M.SUNDAR, J., and R.SAKTHIVEL , J., gpa 20.06.2023
https://www.mhc.tn.gov.in/judisAlamelu vs State Of Tamil Nadu Represented on 20 June, 2023

