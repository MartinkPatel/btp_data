B.Ramkumar Adityan vs Secretary on 13 August, 2021
Bench: Sanjib Banerjee, Senthilkumar Ramamoorthy
                                                                                  W.P.No.11716 of 2020
                                   IN THE HIGH COURT OF JUDICATURE AT MADRAS
                                                Reserved on        : 06.08.2021
                                                Pronounced on : 13.08.2021
                                                        CORAM :
                           THE HON'BLE MR.SANJIB BANERJEE, THE CHIEF JUSTICE
                                                 AND
                         THE HON'BLE MR.JUSTICE SENTHILKUMAR RAMAMOORTHY
                                               W.P.No.11716 of 2020
                                                         and
                                       W.M.P.Nos.14401, 14408 and 14409 of 2020
                     B.Ramkumar Adityan                                                  .. Petitioner
                                                              Vs
                     1. Secretary,
                        Department of Higher Education,
                        Ministry of Education,
                        No.122/C, Shastri Bhavan,
                        New Delhi – 110 001.
                     2. Principal Secretary,
                        Higher Education Department,
                        Government of Tamil Nadu,
                        Chennai – 600 009.
                     3. The Secretary,
                        Bar Council of India,
                     __________
                     Page 1 of 27
https://www.mhc.tn.gov.in/judis/
                                                                             W.P.No.11716 of 2020B.Ramkumar Adityan vs Secretary on 13 August, 2021

                         21, Rouse Avenue Institutional Area,
                         Near Bal Bhawan, New Delhi-110 002.
                     4. Joint Secretary,
                        Distance Education Bureau (DEB),
                        University Grants Commission (UGC),
                        Bahadur Shah Zafar Marg,
                        New Delhi – 110 002.
                     5. The Secretary,
                        Bar Council of Tamil Nadu and Pondicherry,
                        High Court Buildings, Chennai – 600 104.
                     6. The Registrar,
                        Annamalai University,
                        Annamalai Nagar – 608 002.
                     7. Director,
                        Directorate of Distance Education,
                        Annamalai University,
                        Annamalai Nagar – 608 002.
                     8. The High Court of Judicature At Madras,
                        Rep. by the Registrar General,
                        Chennai – 600 104.
                     (R8 suo-motu impleaded vide order
                     dated 27.11.2020 made in WP.11716/2020)            .. Respondents
                     PRAYER: Petition under Article 226 of the Constitution of India seeking
                     issuance of a writ of Certiorarified Mandamus, calling for the records of the
                     respondents 6 and 7 with respect to S.No.(3) LL.B (General) (4) LL.B
                     (Academic) of Law Programmes of the distance education Admission
                     __________
                     Page 2 of 27
https://www.mhc.tn.gov.in/judis/
                                                                            W.P.No.11716 of 2020
                     Notification No.DDE/S/009/2020-21 dated 07.08.2020 published in Tamil
                     Daily News Paper, Daily Thanthi dated 09.08.2020 and quash the same as
                     illegal and consequently direct the respondents 6 and 7 to withdraw all the
                     Two years LL.B (General) and Three Years LL.B (Academic) course
                     certificates issued in past if any to change name of the Two years LL.B(
                     General) and Three years LL.B(Academic) Courses.
                                    For Petitioner        : Mr.S.Sankar
                                    For respondents       : Mr.P.Ayyasamy, CGSPC for R1B.Ramkumar Adityan vs Secretary on 13 August, 2021

                                                            Mr.P.Muthukumar, for R2
                                                            Mr.S.R.Raghunathan
                                                            Assisted by
                                                            Mr.K.V.Kartik Subramanian
                                                            Mr.Vigneshwar Elango
                                                            Ms.M.Mathangi for R3
                                                            Mr.B.Rabu Manohar for R4
                                                            Mr.J.Pothiraj for R5
                                                            Mr.R.Shunmugasundaram,
                                                            Advocate General
                                                            Assisted by
                                                            Mr.V R Kamalanathan
                                                            for R6 and R7
                                                            Mr.V.Vijaya Shankar for R8
                     __________
                     Page 3 of 27
https://www.mhc.tn.gov.in/judis/
                                                                                  W.P.No.11716 of 2020
                                                           ORDER
[Order of the Court was made by SENTHILKUMAR RAMAMOORTHY,J] The petitioner, a public
interest litigant, has brought to the notice of the Court a matter of considerable significance. The
Annamalai University offers courses leading to bachelor and master of laws degrees, diplomas and
post-graduate diplomas by the distance education mode and the petitioner complains that such
courses cannot be conducted without the approval of the Bar Council of India (the BCI), which is
sovereign in the field of legal education in the country.
2. The BCI wholeheartedly supports the petitioner and contends that its functions and, therefore,
powers extend not only to recognizing centres of legal education that offer law degrees that enable
the holders thereof to enrol at the bar, but also any other legal education degrees, diplomas or even
certificate courses. The BCI traces the provenance of its rule-making __________
https://www.mhc.tn.gov.in/judis/ authority to Entries 66, 77 and 78 of List I of the VII Schedule to
the Constitution and says that it occupies the field completely in the realm of legal education. The
Bar Council of Tamil Nadu lends its weight to the BCI by reiterating that recognizing institutions
that provide legal education is the exclusive domain of the BCI.
3. The University Grants Commission (the UGC) is a party, and its stand is that it no longer grants
recognition to open or distance education in the field of law. A recent circular is cited to draw
attention to the prohibition on open and distance education in law.B.Ramkumar Adityan vs Secretary on 13 August, 2021

4. The lone adversary is the Annamalai University which asserts that the jurisdiction of the BCI is
limited to recognizing law degrees that enable the holders thereof to enrol as advocates in terms of
the Advocates Act, 1961 (the Advocates Act). Annamalai University says in its notices inviting
applications for law courses, it carries a clear and categorical caveat that persons who receive its
degrees and diplomas in law would not be entitled __________ https://www.mhc.tn.gov.in/judis/
to enrol as advocates and practice law, and that such disclaimer takes these courses outside the
jurisdictional control of the BCI. Annamalai University claims to be recognized by the UGC as
regards its distance education law courses. Annamalai University also brings to the notice of the
Court that several Universities across India offer distance legal education leading to degrees or
diplomas and that such courses have been offered for several decades. In the absence of statutory
authority over legal education, which does not enable enrollment as an advocate, Annamalai
University contends that the writ petition is devoid of merit.
5. The principal parties were heard at length through learned counsel/ senior counsel. The
petitioner was represented by Mr.S.Sankar, learned counsel; the BCI by Mr.S.Raghunathan, learned
counsel; the Bar Council of Tamil Nadu by Mr.Pothiraj, learned counsel; the UGC by Mr.B.Rabu
Manohar, learned counsel; and Annamalai University by Mr.Shanmugasundaram, learned Senior
Counsel, assisted by Mr.V.R.Kamalanathan, learned counsel.
__________ https://www.mhc.tn.gov.in/judis/
6. The petitioner set the ball rolling by referring to the expansive role played by the BCI under the
Advocates Act. The Bar Council of India Rules were also adverted to and Rule 8 of the Rules of Legal
Education in Part IV thereof was relied on to emphasise that the BCI had set standards for courses
in law, and that Annamalai University, which admittedly did not obtain approval or recognition
from the BCI, cannot be permitted to offer the impugned courses. The petitioner says that it is
inimical to public interest to permit a University to offer such courses as it has the effect of deceiving
naive youth into enrolling for such courses in the mistaken belief that they would be permitted to
enrol at the bar or practice law.
7. The BCI opened its submissions by tracing its authority to Section 7 of the Advocates Act. Section
7 prescribes the functions of the BCI. For purposes of this case, the BCI referred to clauses (h) and
(i) of sub-section 1 of Section 7. The said clauses are as under:
“7. Functions of Bar Council of India (1) The functions of __________
https://www.mhc.tn.gov.in/judis/ the Bar Council of India shall be -
....
(h) to promote legal education and to lay down standards of such education in
consultation with the Universities in India imparting such education and the State
Bar Councils;B.Ramkumar Adityan vs Secretary on 13 August, 2021

(i) to recognize Universities whose degree in law shall be a qualification for
enrolment as an advocate and for that purpose to visit and inspect Universities [or
cause the State Bar Councils to visit and inspect Universities in accordance with such
directions as it may give in this behalf] ”
8. On the above basis, the BCI contends that it derives its authority not only from clause (i) of
Section 7 (1) but also from clause (h) of such sub-section. According to the BCI, while clause (i)
empowers it to recognize Universities whose degree in law shall be a qualification for enrolment as
an advocate, clause (h) is not limited to a degree in law which could lead to enrolment as an
advocate. To put it differently, the BCI claims that clause (h) would be rendered redundant if it were
construed as being __________ https://www.mhc.tn.gov.in/judis/ limited to legal education that
leads to a degree in law that would enable the holder thereof to enrol as an advocate. In effect, the
BCI canvasses the case that its functions in terms of clause (i) extend to the entire gamut of legal
education and that the BCI has the principal authority, albeit in consultation with universities
imparting such education and State Bar Councils, to lay down standards of such education.
9. Several judgments were cited especially to underscore the origins of the BCI's exclusive
rule-making authority. The judgment of the Hon'ble Supreme Court in O.N.Mohindroo v. Bar
Council of India, AIR 1968 SC 888, was placed in support of the proposition that the power of the
Delhi State Bar Council to take action under the Advocates Act was traceable to Entries 77 and 78 of
List-1 of the VII Schedule to the Constitution. Paragraph 7 of such judgment was referred to wherein
the Supreme Court held that “the power to legislate in regard to persons entitled to practise before
the Supreme Court and the High Courts is thus excluded from Entry 26 in List-3 and is made the
exclusive field for legislation by Parliament __________ https://www.mhc.tn.gov.in/judis/ only.”
The judgment of the Supreme Court in Bar Council of India v. Board of Management, Dayanand
College of Law (2007) 2 SCC 202 was relied on for the principle that the Bar Council of India is
concerned with the standards of the legal profession and in equipping those who seek entry into
such profession with the relevant knowledge and skills. The judgment in the Institution of
Mechanical Engineers v. State of Punjab (2019) 16 SCC 95, which dealt with the power of the AICTE,
was placed in support of the proposition that distance education courses in law cannot be offered by
any University unless the BCI approves of the same. In the aforesaid judgment, the Supreme Court
recognized that the AICTE is the sole repository of power to lay down parameters or qualitative
norms for technical education and that it was within the exclusive domain of AICTE to consider and
decide whether subjects leading to degrees in engineering could be taught in the distance education
mode. By relying on paragraphs 39 to 41 of the aforesaid judgment, the BCI equated its status in
legal education with that of the AICTE in technical education. Further, paragraph 46 of the said
judgment was relied upon to contend that the entirety of the __________
https://www.mhc.tn.gov.in/judis/ field concerning technical education is within the domain of
AICTE. By analogy, it is contended that the BCI plays a similar role as regards legal education.
10. The next judgment that was relied upon by the BCI was the judgment in Tamil Nadu Medical
Officer's Association v. Union of India (2020) SCC Online SC 699. By placing paragraphs 4, 11, 102,
104 and 105 of the said judgment, the BCI contended that Entry 66 of List-1 is a specific entry
dealing with coordination and determination of standards in institutions of higher education orB.Ramkumar Adityan vs Secretary on 13 August, 2021

research. Thus, the prescription of standards for such institutions was within the exclusive domain
of Parliament. In exercise of legislative power by delegation, the BCI contended that it has exclusive
authority to set standards of legal education, subject to consultation with other stakeholders. As a
consequence, it was asserted that the UGC stands divested of authority in the realm of legal
education.
__________ https://www.mhc.tn.gov.in/judis/
11. The BCI also referred to the Bar Council of India Rules and, in particular, to Part-IV thereof
which prescribes the Rules of Legal Education. By placing considerable emphasis on the fact that
such Rules of Legal Education were framed in exercise of functions under both clauses (h) and
(i) of Section 7 as well as other provisions of the Advocates Act, the BCI contended that this
establishes conclusively that its functions are not restricted to legal education that enable the
successful student to enrol as an advocate.
12. The UGC's submissions were brief. It relied primarily on a public notice issued by its Distance
Education Bureau. Paragraph 4 of such public notice contains a warning against admission in
prohibited programmes. Item
(iii) in the list pertains to programmes in law. The UGC clarified that this public notice was issued
on 14.08.2020, which incidentally is a few days after the admission notification was issued by
Annamalai University on 07.08.2020. By drawing reference to paragraph 14 of its counter-affidavit,
the UGC articulated its stand that it had not accorded recognition to any law __________
https://www.mhc.tn.gov.in/judis/ courses in the open, distance education or online mode.
13. Annamalai University relied heavily on the prospectuses issued for the academic years
2011-2012, 2019-2020 and 2020-2021. The express disclaimer in such prospectuses was pointed
out. The disclaimer set out therein is as under:
“Under the Advocates Act, 1961 and Rules framed thereunder by the Bar Council of
India, the holder of B.B.L., LL.B.(Academic), and LL.B (General), degree is not
eligible for enrolment as an advocate”
14. Annamalai University next placed the Distance Education Council (DEC) recognition list of
Universities in different States of India. As regards Tamil Nadu, Annamalai University pointed out
that the Bachelor of Academic Law and Bachelor of General Law degrees were recognized by the
DEC till 2014-2015.
__________ https://www.mhc.tn.gov.in/judis/
15. By drawing reference to the Bar Council of India Rules, Annamalai University contended that
Rule 4 makes it clear that it would apply only to degrees in law which are recognized by the BCI for
the purposes of enrolment as an advocate. A Division Bench judgment of this Court in S.R.Deepak v.B.Ramkumar Adityan vs Secretary on 13 August, 2021

The Tamil Nadu Dr.Ambedkar Law University, 2016-2-LW-64, was relied upon to contend that the
Division Bench recognized that the BCI should split the law degree course into two streams:
one intended for those who would become advocates and the other for those who
intend to acquire knowledge of law. The BCI was, however, quick to point out that
S.R.Deepak is no longer good law because a Full Bench of this Court in G.S.Jagadeesh
v. The Chairman, 3 Year LL.B. Admission, 2016-2017, The Tamil Nadu Dr. Ambedkar
Law University, AIR 2018 Mad 243, disagreed with the ratio therein.
16. Annamalai University pointed out that about 32 Universities in India are conducting distance
education courses in law and that any interference with the continuation of such courses would have
a massive __________ https://www.mhc.tn.gov.in/judis/ and adverse impact on legal education
in India.
17. Annamalai University also placed reliance on the University Grants Commission (Open and
Distance Learning Programmes and Online Programmes) Regulations, 2020 in order to
substantiate the contention that open and distance education is permissible provided the specified
accreditation agencies', namely, NAAC and NIRF, ranking requirements are satisfied.
18. The contentions of the petitioner, the BCI, the UGC and Annamalai University raise several
issues. While the BCI dilated on legislative competence, such competence is not under challenge in
this petition and, therefore, no findings are rendered on such issue. Foremost among the issues that
should be determined is the ambit of the BCI's authority with regard to legal education. Clauses (h)
and (i) of Section 7(1) of the Advocates Act clearly delineate two distinct functions of the BCI
__________ https://www.mhc.tn.gov.in/judis/ with regard to legal education. While clause (h)
deals with the promotion of legal education and the laying down of standards of such education,
clause
(i) confers upon the BCI the power to recognize universities whose degree in law would qualify the
holder thereof to enrol as an advocate. If clause (h) were to be construed in the manner advocated
by Annamalai University, the BCI's functions would be limited to setting the standards for degrees
in law that could lead to enrolment as an advocate. When the text of clause (h) is compared and
contrasted with clause (i), it is noticeable that clause (i) uses the words “degree in law”, whereas
clause (h) does not. Similarly, clause (i) is further qualified by the phrase “whose degree in law shall
be a qualification for enrolment as an advocate”, whereas the text of clause (h) contains no such
qualification or restriction. In the context of clause (i), the BCI undoubtedly has the power to grant
or refuse recognition to Universities offering degrees in law. On the contrary, in exercise of functions
under clause (h), the BCI does not have the power to grant or refuse recognition. Its function in the
context of clause (h) is confined to promoting legal education and laying down standards of legal
education but __________ https://www.mhc.tn.gov.in/judis/ such function is not limited to
degrees in law leading to an entitlement to enrol as an advocate; it extends to all forms of legal
education and all courses of study, whether leading to a bachelor or master of laws degree, a
diploma, a post-graduate diploma or even a certificate course. We see little reason to whittle down
the breadth of the expression “legal education” or “standards of such education” in clause (h).B.Ramkumar Adityan vs Secretary on 13 August, 2021

19. Against this backdrop, the role of the BCI should be examined in the specific factual context of
this case. The Annamalai University has issued an admission notification in relation to law courses
for the academic year 2020-2021. The law programmes indicated in such admission notification are
as under:
“1. LLM- Three years
2. BBL – Three years
3. LL.B (General) – Two years Duration : Two years
4. LL.B (Academic) – Three years Duration : One year __________
https://www.mhc.tn.gov.in/judis/
5. P.G Diploma in Cyber Law
6. P.G. Diploma in Criminology and Forensic Science
7. Diploma in Labour Laws with Administrative Law
8. Diploma in Law of Taxation”
20. The question that arises for consideration is whether all the above courses or some of them
require the recognition of the BCI. Another question of significance also arises: has the BCI set
standards in respect of all or some of the above courses and, if so, whether the courses offered by
Annamalai University meet the prescribed standards? The bachelor of laws degree programmes are
examined first. Three bachelor of laws degree courses are on offer by Annamalai University. The Bar
Council of India Rules contain Rules of Legal Education in Part-IV thereof. It is noticeable that such
Rules have been framed by drawing on both clauses (h) and (i) of Section 7(1) of the Advocates Act.
Rule 4 of Part-IV is of particular significance and reads, in relevant part, as under:
“4. Law courses – there shall be two courses of law leading to Bachelors Degrees in
Law as hereunder, – __________ https://www.mhc.tn.gov.in/judis/
(a) a three year Degree course in law undertaken after obtaining a Bachelors' Degree
in any discipline of studies from a University or any other qualification considered
equivalent by the Bar Council of India:
Provided that admission to such a course of study for a degree in law is obtained from
a University whose degree in law is recognized by the Bar Council of India for the
purpose of enrolment.
(b) a double degree integrated course combining Bachelors' Degree course as
designed by the University concerned in any discipline of study together with theB.Ramkumar Adityan vs Secretary on 13 August, 2021

Bachelors' Degree course in law, which shall be of not less than five years' duration
leading to the integrated degree in the respective discipline of knowledge and Law
together.
Provided that such an integrated degree programme in law of the University is recognized by the Bar
Council of India for the purpose of enrolment....” __________ https://www.mhc.tn.gov.in/judis/
Rule 5 of the said Rules sets out the eligibility for admission, Rule 8 sets out the standard of courses,
and the Schedules prescribe the academic standards, curriculum and the like.
21. Annamalai University contended that Rule 4 does not apply unless the bachelor's degree in law
leads to eligibility for enrolment as an advocate. By relying upon the disclaimer in the prospectus,
Annnamalai University contended that the courses offered by it are outside the jurisdictional ambit
of the BCI, including the Rules of Legal Education. This contention should, therefore, be tested. In
effect, Annamalai University contended that the respective provisos to clauses (a) and (b) of Rule 4
have the effect of restricting the scope of the principal clause to bachelor of laws degree courses that
enable the holder thereof to enrol as an advocate.
22. A proviso plays the role of qualifying the principal provision or clause. However, the manner in
which the principal clause is qualified would depend on the text and context of both the principal
clause and the __________ https://www.mhc.tn.gov.in/judis/ relevant proviso. Such qualification
may be by curtailing the scope of or imposing conditions in relation to or even expanding the scope
of the principal clause or provision. Indeed, subject to legislative competence, there is no reason to
limit the role that a proviso could play merely because of the traditional role that the appellation
“proviso” brings to mind. When the text of the principal clause in clauses (a) and (b) are examined,
there can be little doubt that they prescribe a three-year law degree and a five-year double
integrated law degree, respectively, as the only bachelor of laws degree courses. Turning to the
respective provisos, they further restrict such bachelor of laws degrees to those offered by
universities, which are recognised by the BCI for the purpose of enrolment. Thus, the principal
clauses and the provisos thereto when read together indicate that either a three-year degree course
in law or a five-year degree course in law may be offered at the bachelor's level subject to the
condition that, in either case, such degrees are obtained from a University which is recognized by
the Bar Council of India for the purposes of enrolment. Given the fact that clause (i) of Section 7(1)
of the Advocates Act is limited to degrees in law, the BCI __________
https://www.mhc.tn.gov.in/judis/ cannot impose a recognition requirement except for degree
courses. Even in the context of degree courses, the BCI's power to confer recognition appears to be
restricted to courses that qualify the recipient to apply for enrolment at the bar. However, its
functions extend to setting standards both for courses that would lead to an eligibility for enrolment
and those that do not. In the former case, recognition from the BCI is mandatory, whereas, in the
latter, compliance with the prescribed standards would be sufficient.
23. At this point of time, the Rules of Legal Education, which are in force, set standards for and
recognise only two bachelor of laws degree courses. While Annamalai University could contend with
a measure of justification that the BCI is not entitled to enforce the recognition requirement with
regard to bachelor of laws degrees that do not enable the holder thereof to apply for enrolment, at aB.Ramkumar Adityan vs Secretary on 13 August, 2021

minimum, the standards set by the BCI should have been met by Annamalai University. Thus, if not
for any other reason, the three bachelor of laws degree courses offered by Annamalai University
contravene the Rules of Legal Education because the __________
https://www.mhc.tn.gov.in/judis/ standards prescribed in relation to such courses have not been
adhered to by Annamalai University.
24. The other courses offered by Annamalai University leading to a master's degree in law or
diplomas in law fall into a distinct category. The BCI has not set binding standards as regards such
courses. More importantly, the condition that universities offering such courses should be
recognized by the BCI would undoubtedly not apply to such courses. The reason for such conclusion
is that the BCI's role under clause (h) of Section 7(1) is a more limited standard-setting role, albeit
spanning the breadth of legal education, unlike its larger role while recognizing universities that
offer bachelor of laws degrees that create an eligibility for the holder thereof to enrol as an advocate.
Although the BCI stated that it has set standards for masters' degrees in law, it appears that such
standards have been challenged and have not been implemented as on date.
__________ https://www.mhc.tn.gov.in/judis/
25. The upshot of the above discussion and analysis is that Annamalai University is prohibited from
offering any bachelor of laws degree in law without at least adhering to the standards set by BCI in
the Rules of Legal Education. As a consequence, no new students should be admitted to such
courses and those already admitted should be instructed to seek alternative admissions in
recognised courses. The State should extend all possible assistance in this regard to mitigate the
hardship of the affected students. As regards the other courses in law, in the absence of standards in
such regard by the BCI and given the limited role of BCI in such regard, Annamalai University
cannot be prevented from offering such courses. Needless to say, once the BCI frames and
implements standards in respect of such courses, all universities, including Annamalai University,
would be under an obligation to ensure that the courses offered by them meet the standards set by
the BCI.
__________ https://www.mhc.tn.gov.in/judis/
26. In fine, W.P.No.11716 of 2020 is disposed of in the above terms without any order as to costs.
Consequently, connected W.M.P.Nos.14401, 14408 and 14409 of 2020 are closed.
                                                                      (S.B., CJ.)      (S.K.R., J.)
                                                                                13.08.2021
                     Index           : Yes/No
                     Internet        : Yes/No
                     pkn
                     Note : In view of the present lock down
                     owing to COVID-19 pandemic, a web
                     copy of the order may be utilized for
                     official purposes, but, ensuring that
                     the copy of the order that is presentedB.Ramkumar Adityan vs Secretary on 13 August, 2021

                     is the correct copy, shall be the
                     responsibility of the advocate/litigant
                     concerned.
                     To:
                     1. Secretary,
                        Department of Higher Education,
                        Ministry of Education,
                        No.122/C, Shastri Bhavan,
                        New Delhi – 110 001.
                     2. Principal Secretary,
                     __________
https://www.mhc.tn.gov.in/judis/
                         Higher Education Department,
                         Government of Tamil Nadu,
                         Chennai – 600 009.
                     3. The Secretary,
                        Bar Council of India,
                        21, Rouse Avenue Institutional Area,
                        Near Bal Bhawan, New Delhi-110 002.
                     4. Joint Secretary,
                        Distance Education Bureau (DEB),
                        University Grants Commission (UGC),
                        Bahadur Shah Zafar Marg,
                        New Delhi – 110 002.
                     5. The Secretary,
                        Bar Council of Tamil Nadu and Pondicherry,
                        High Court Buildings, Chennai – 600 104.
                     6. The Registrar,
                        Annamalai University,
                        Annamalai Nagar – 608 002.
                     7. Director,
                        Directorate of Distance Education,
                        Annamalai University,
                        Annamalai Nagar – 608 002.
                     8. The High Court of Judicature At Madras,B.Ramkumar Adityan vs Secretary on 13 August, 2021

                        Rep. by the Registrar General,
                        Chennai – 600 104.
                     __________
https://www.mhc.tn.gov.in/judis/
                                           THE HON'BLE CHIEF JUSTICE
                                                                AND
                                     SENTHILKUMAR RAMAMOORTHY, J.
                                                                     pkn
                                                              13.08.2021
                     __________
https://www.mhc.tn.gov.in/judis/B.Ramkumar Adityan vs Secretary on 13 August, 2021

