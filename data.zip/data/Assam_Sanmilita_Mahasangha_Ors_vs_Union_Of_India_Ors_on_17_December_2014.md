Assam Sanmilita Mahasangha & Ors vs Union Of India & Ors on
17 December, 2014
Equivalent citations: AIR 2015 SUPREME COURT 783, 2015 AIR SCW 296,
AIR 2015 SC (CIVIL) 456, (2015) 2 WLC(SC)CVL 275, (2015) 1 GAU LT 191,
(2015) 1 MAD LJ 219, 2015 (3) SCC 1, 2015 (1) KCCR SN 51 (SC), (2015) 147
ALLINDCAS 231 (SC), (2014) 14 SCALE 101, AIR 2015 SC (CIV) 456, 2015
(111) ALR SOC 3 (SC), 2015 (1) KLT SN 57 (SC)
Author: R.F. Nariman
Bench: Ranjan Gogoi, Rohinton Fali Nariman
                                                                              REPORTABLE
                        IN THE SUPREME COURT OF INDIA
                         CIVIL ORIGINAL JURISDICTION
                    WRIT PETITION (CIVIL) NO. 562 OF 2012
Assam           Sanmilita            Mahasangha            &            Ors.
...Petitioners
                                   Versus
Union of India & Ors.                                    ...Respondents
                                    WITH
                    WRIT PETITION (CIVIL) NO. 274 OF 2009
Assam                              Public                              Works
...Petitioner
                                   Versus
Union of India & Ors.                                    ...Respondents
                                    WITH
                    WRIT PETITION (CIVIL) NO. 876 OF 2014
All Assam Ahom Association & Ors.Assam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

...Petitioners
                                   Versus
Union              of               India               &               Ors.
      ...Respondents
                               J U D G M E N T
R.F. Nariman, J.
1. A Prophet is without honour in his own country. Substitute 'citizen' for 'prophet' and you will get
the gist of the various writ petitions filed under Article 32 of the Constitution of India assailing
Section 6A of the Citizenship Act.
2. It all began when the Burmese ceded Assam to the British on 24th February, 1826 as per the
treaty of Yandabo, thus bringing to an end Ahom rule in Assam which had begun sometime in the
13th century. The British annexed Assam and placed it as an administrative unit of the Bengal
Province. As early as 1931, C.S. Mullan, the Census Superintendent in his census report stated:
"Probably the most important event in the province during the last 25 years- an
event, moreover, which seems likely to alter permanently the whole feature of Assam
and to destroy the whole structure of Assamese culture and civilization has been the
invasion of a vast horde of land-hungry immigrants mostly Muslims, from the
districts of East Bengal. ... wheresoever the carcass, there the vultures will gathered
together "
(Politics of Migration by Dr. Manju Singh, Anita Publications, Jaipur, 1990, Page 59)
3. In 1935, when the Government of India Act was promulgated, Assam was, under Section 46(1),
stated to be a Governor's province. It was in this scenario that the Foreigners Act of 1946 was
enacted under which the burden of proving whether a person is or is not a foreigner lies upon such
person. At the commencement of the Constitution of India, Article 5 stated that every person who
has his domicile in the territory of India and who was either born in the territory of India; or either
of whose parents were born in the territory of India; or who has been ordinarily resident in the
territory of India for not less than 5 years immediately preceding such commencement shall be a
citizen of India. As an exception, Article 6, which is important for the determination of some of the
questions arising in these writ petitions, states as follows:
"Rights of citizenship of certain persons who have migrated to India from Pakistan.
--Notwithstanding anything in Article 5, a person who has migrated to the territory of
India from the territory now included in Pakistan shall be deemed to be a citizen of
India at the commencement of this Constitution ifAssam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

(a) he or either of his parents or any of his grand-parents was born in India as
defined in the Government of India Act, 1935 (as originally enacted); and
(b)(i) in the case where such person has so migrated before the nineteenth day of
July, 1948 , he has been ordinarily resident in the territory of India since the date of
his migration, or
(ii) in the case where such person has so migrated on or after the nineteenth day of
July, 1948 , he has been registered as a citizen of India by an officer appointed in that
behalf by the Government of the Dominion of India on an application made by him
therefor to such officer before the commencement of this Constitution in the form
and manner prescribed by that Government: Provided that no person shall be so
registered unless he has been resident in the territory of India or at least six months
immediately preceding the date of his application."
4. 19th July, 1948, therefore, became the baseline for such persons as were referred to in Article 6
for being citizens of India.
5. At this stage, the Immigrants (Expulsion from Assam) Act, 1950 was enacted to protect the
indigenous inhabitants of Assam. The statement of objects and reasons of this Act says "during the
last few months a serious situation had arisen from the immigration of a very large number of East
Bengal residents into Assam. Such large migration is disturbing the economy of the province,
besides giving rise to a serious law and order problem. The bill seeks to confer necessary powers on
the Central Government to deal with the situation."
6. In pursuance of this object, Sections 2 and 4 of this Act which also have a bearing on some of the
issues raised in these petitions state as follows:
"2. Power to order expulsion of certain immigrants.-
If the Central Government is of opinion that any person or class of persons, having
been ordinarily resident in any place outside India, has or have, whether before or
after the commencement of this Act, come into Assam and that the stay of such
person or class of persons in Assam is detrimental to the interests of the general
public of India or of any section thereof or of any Scheduled Tribe in Assam, the
Central Government may by order--
(a) direct such person or class of persons to remove himself or themselves from India
or Assam within such time and by such route as may be specified in the order; and
(b) give such further directions in regard to his or their removal from India or Assam
as it may consider necessary or expedient;Assam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

Provided that nothing in this section shall apply to any person who on account of civil disturbances
or the fear of such disturbances in any area now forming part of Pakistan has been displaced from or
has left his place of residence in such area and who has been subsequently residing in Assam.
4. Power to give effect orders, etc.-
Any authority empowered by or in pursuance of the provisions of this Act to exercise any power
may, in addition to any other action expressly provided for in this Act, take or cause to be taken such
steps, and use or cause to be used such force, as may in its opinion be reasonably necessary for the
effective exercise of such power."
7. It was during the census of 1951 that a National Register of Citizens was prepared under a
directive of the Ministry of Home Affairs containing information village-wise of each and every
person enumerated therein. Details such as the number and names of persons, the houses or
holdings belonging to them, father's name or husband's name, nationality, age, the means of
livelihood were all indicated therein.
8. Between 1948 and 1971, there were large scale migrations from East Pakistan to Assam. As is well
known, West Pakistan commenced hostilities against East Pakistan on 25th March, 1971
culminating in the war which dismembered the two parts of Pakistan and in which a new nation,
Bangladesh, was born. It is interesting to note that immediately after the successful culmination of
the war in Bangladesh, on 19th March, 1972, a treaty for friendship, co-operation and peace was
signed between India and Bangladesh. Article 8 of the said treaty is in the following terms:
"In accordance with the ties of friendship existing between the two countries each of
the High Contracting Parties solemnly declares that it shall not enter into or
participate in any military alliance directed against the other party. Each of the High
Contracting Parties shall refrain from any aggression against the other party and
shall not allow the use of its territory for committing any act that may cause military
damage to or constitute a threat to the security of the other High Contracting Party"
9. Given the continuing influx of illegal migrants from Bangladesh into Assam, the All Assam
Students Union first submitted a memorandum to the then Prime Minister of India (in 1980)
inviting her urgent attention to this issue. As a result of such representations, Parliament enacted
the Illegal Migrants (Determination by Tribunal) Act, 1983. This Act was made applicable only to
Assam and was expected to be a measure which speeded up the determination of illegal migrants in
the State of Assam with a view to their deportation.
10. Not being satisfied with this parliamentary measure, and in view of large scale agitations in the
State of Assam, an accord was signed known as the "Assam Accord" on 15th August, 1985 between
the AASU, AAGSP and the Central and the State Governments. This Accord is worth quoting in
extenso:Assam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

"ASSAM ACCORD 15th August, 1985 (Accord between AASU, AAGSP, Central and
State Government on the Foreigner Problem Issue) MEMORANDUM OF
SETTLEMENT
1. Government have all along been most anxious to find a satisfactory solution to the
problem of Foreigners in Assam. The All Assam Students' Union (AASU) and the All
Assam Gana Sangram Parishad (AAGSP) have also expressed their Keenness to find
such a solution.
2. The AASU through their Memorandum dated 2nd February, 1980 presented to the
Late Prime Minister Smt. Indira Gandhi, conveyed their profound sense of
apprehensions regarding the continuing influx of foreign nationals into Assam and
the fear about adverse affects upon the political, social, cultural and economic life of
the State.
3. Being fully alive to the genuine apprehensions of the people of Assam, the then
Prime Minister initiated the dialogue with the AASU/AAGSP. Subsequently, talks
were held at the Prime Minister's and Home Ministers levels during the period
1980-83. Several rounds of informal talks were held during 1984. Formal discussions
were resumed in March, 1985.
4. Keeping all aspects of the problem including constitutional and legal provision,
international agreements, national commitments and humanitarian considerations,
it has been decided to proceed as follows :-
Foreigners Issue:
5.
1. For purpose of detection and deletion of foreigners, 1-1-1966 shall be the base date
and year.
2. All persons who came to Assam prior to 1-1-1966, including those amongst them
whose names appeared on the electoral rolls used in 1967 elections, shall be
regularized.
3. Foreigners who came to Assam after 1-1-1966 (inclusive) and upto 24th March,
1971 shall be detected in accordance with the provisions of the Foreigners Act, 1946
and the Foreigners (Tribunals) Order, 1939.
4. Names of foreigners so detected will be deleted from the electoral rolls in force.
Such persons will be required to register themselves before the Registration Officers
of the respective districts in accordance with the provisions of the Registration of
Foreigners Act, 1939 and the Registration of Foreigners Rules, 1939.Assam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

5. For this purpose, Government of India will undertake suitable strengthening of the
governmental machinery.
6. On the expiry of the period of ten year following the date of detection, the names of
all such persons which have been deleted from the electoral rolls shall be restored.
7. All persons who were expelled earlier, but have since re-entered illegally into
Assam, shall be expelled.
8. Foreigners who came to Assam on or after March 25, 1971 shall continue to be
detected, deleted and expelled in accordance with the law. Immediate and practical
steps shall be taken to expel such foreigners.
9. The Government will give due consideration to certain difficulties express by the
AASU/AAGSP regarding the implementation of the Illegal Migrants (Determination
by Tribunals) Act, 1983.
Safeguards and Economic Development:
6. Constitutional, legislative and administrative safeguards, as may be appropriate,
shall be provided to protect, preserve and promote the cultural, social, linguistic
identity and heritage of the Assamese people.
7. The Government takes this opportunity to renew their commitment for the speedy
all round economic development of Assam, so as to improve the standard of living of
the people. Special emphasis will be placed on the education and Science &
Technology through establishment of national institutions.
Other Issues:
8.
1. The Government will arrange for the issue of citizenship certificate in future only
by the authorities of the Central Government.
2. Specific complaints that may be made by the AASU/AAGSP about irregular
issuance of Indian Citizenship Certificates (ICC) will be looked into.
9.
1. The international border shall be made secure against future infiltration by
erection of physical barriers like walls barbed wire fencing and other obstacles at
appropriate places. Patrolling by security forces on land and riverine routes all along
the international border shall be adequately intensified. In order to furtherAssam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

strengthen the security arrangements, to prevent effectively future infiltration, an
adequate number of check posts shall be set up.
2. Besides the arrangements mentioned above and keeping in view security
considerations, a road all along the international border shall be constructed so as to
facilitate patrolling by security forces. Land between border and the road would be
kept free of human habitation, wherever possible. Riverine patrolling along the
international border would be intensified. All effective measures would be adopted to
prevent infiltrators crossing or attempting to cross the international border.
10. It will be ensured that relevant laws for prevention of encroachment of
government lands and lands in tribal belts and blocks are strictly enforced and
unauthorized encroachers evicted as laid down under such laws.
11. It will be ensured that the law restricting acquisition of immovable property by
foreigners in Assam is strictly enforced.
12. It will be ensured that Birth and Death Registers are duly maintained.
Restoration of Normalcy:
13. The All Assam Students Unions (AASU) and the All Assam Gana Sangram
Parishad (AAGSP) call off the agitation, assure full co-operation and dedicate
themselves towards the development of the Country.
14. The Central and the State Government have agreed to:
1. Review with sympathy and withdraw cases of disciplinary action taken against
employees in the context of the agitation and to ensure that there is no victimization;
2. Frame a scheme for ex-gratia payment to next of kin of those who were killed in
the course in the agitation.
3. Give sympathetic consideration to proposal for relaxation of upper age limit for
employment in public service in Assam, having regard to exceptional situation that
prevailed in holding academic and competitive examinations etc. in the context of
agitation in Assam:
4. Undertake review of detention cases, if any, as well as cases against persons
charged with criminal offences in connection with the agitation, except those charged
with commission of heinous offences.
5. Consider withdrawal of the prohibitory orders/ notifications in force, if any:Assam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

15. The Ministry of Home Affairs will be the nodal Ministry for the implementation of
the above.
Sd/-
Sd/-
(P.K.     Mahanta)                                                     (R.D.
Pradhan)
President                                                               Home
Secretary
All Assam Students' Union                    Government of India
                                                                        Sd/-
           Sd/-
(B.K.   Phukan)                                             (Smt.   P.    P.
Trivedi)
General Secretary                                         Chief Secretary
All Assam Students' Union                  Government of Assam
     Sd/-
 (Biraj Sharma)
    Convenor
All Assam Students' Union
                                                                   In    the
Presence of
       Sd/-
                                                                      (Rajiv
Gandhi)
                                                             Prime  Minister
of India
Date: 15th August, 1985
Place: New Delhi"Assam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

11. It was in pursuance of this accord that Section 6A was inserted in the Citizenship Act in 1985.
The Statement of Objects and Reasons of the Act specifically states that it is legislation required to
give effect to the Assam Accord. Section 6A states as follows:
"6A. Special provisions as to citizenship of persons covered by the Assam Accord.-
(1) For the purposes of this section-
(a) "Assam" means the territories included in the State of Assam immediately before
the commencement of the Citizenship (Amendment) Act, 1985;
(b) "detected to be a foreigner" means detected to be a foreigner in accordance with
the provisions of the Foreigners Act, 1946 (31 of 1946) and the Foreigners (Tribunals)
Order, 1964 by a Tribunal constituted under the said Order;
(c) "specified territory" means the territories included in Bangladesh immediately
before the commencement of the Citizenship (Amendment) Act, 1985;
(d) a person shall be deemed to be of Indian origin, if he, or either of his parents or
any of his grandparents was born in undivided India;
(e) a person shall be deemed to have been detected to be a foreigner on the date on
which a Tribunal constituted under the Foreigners (Tribunals) Order, 1964 submits
its opinion to the effect that he is a foreigner to the officer or authority concerned.
(2) Subject to the provisions of sub-sections (6) and (7), all persons of Indian origin
who came before the 1st day of January, 1966 to Assam from the specified territory
(including such of those whose names were included in the electoral rolls used for the
purposes of the General Election to the House of the People held in 1967) and who
have been ordinarily resident in Assam since the dates of their entry into Assam shall
be deemed to be citizens of India as from the 1st day of January, 1966.
(3) Subject to the provisions of sub-sections (6) and (7), every person of Indian origin
who-
(a) came to Assam on or after the lst day of January, 1966 but before the 25th day of
March, 1971 from the specified territory; and
(b) has, since the date of his entry into Assam, been ordinarily resident in Assam; and
(c) has been detected to be a foreigner, shall register himself in accordance with the
rules made by the Central Government in this behalf under section 18 with such
authority (thereafter in this sub-section referred to as the registering authority) as
may be specified in such rules and if his name is included in any electoral roll for anyAssam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

Assembly or Parliamentary constituency in force on the date of such detection, his
name shall be deleted therefrom.
Explanation.-In the case of every person seeking registration under this sub-section, the opinion of
the Tribunal constituted under the Foreigners (Tribunals) Order, 1964 holding such person to be a
foreigner, shall be deemed to be sufficient proof of the requirement under clause (c) of this
sub-section and if any question arises as to whether such person complies with any other
requirement under this sub-section, the registering authority shall,-
(i) if such opinion contains a finding with respect to such other requirement, decide
the question in conformity with such finding;
(ii) if such opinion does not contain a finding with respect to such other requirement,
refer the question to a Tribunal constituted under the said Order having jurisdiction
in accordance with such rules as the Central Government may make in this behalf
under section 18 and decide the question in conformity with the opinion received on
such reference.
(4) A person registered under sub-section (3) shall have, as from the date on which
he has been detected to be a foreigner and till the expiry of a period of ten years from
that date, the same rights and obligations as a citizen of India (including the right to
obtain a passport under the Passports Act, 1967 (15 of 1967) and the obligations
connected therewith), but shall not be entitled to have his name included in any
electoral roll for any Assembly or Parliamentary constituency at any time before the
expiry of the said period of ten years.
(5) A person registered under sub-section (3) shall be deemed to be a citizen of India
for all purposes as from the date of expiry of a period of ten years from the date on
which he has been detected to be a foreigner.
(6) Without prejudice to the provisions of section 8,-
(a) if any person referred to in sub-section (2) submits in the prescribed manner and
form and to the prescribed authority within sixty days from the date of
commencement of the Citizenship (Amendment) Act, 1985, for year a declaration
that he does not wish to be a citizen of India, such person shall not be deemed to have
become a citizen of India under that sub-
section;
(b) If any person referred to in sub-section (3) submits in the prescribed manner and form and to
the prescribed authority within sixty days from the date of commencement the Citizenship
(Amendment) Act, 1985, for year or from the date on which he has been detected to be a foreigner,
whichever is later, a declaration that he does not wish to be governed by the provisions of thatAssam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

sub-section and sub-sections (4) and (5), it shall not be necessary for such person to register himself
under sub-section (3).
Explanation.-Where a person required to file a declaration under this sub- section does not have the
capacity to enter into a contract, such declaration may be filed on his behalf by any person
competent under the law for the time being in force to act on his behalf.
(7) Nothing in sub-sections (2) to (6) shall apply in relation to any person-
(a) who, immediately before the commencement of the Citizenship (Amendment) Act, 1985, for year
is a citizen of India;
(b) who was expelled from India before the commencement of the Citizenship (Amendment) Act,
1985, for year under the Foreigners Act, 1946 (31 of 1946).
(8) Save as otherwise expressly provided in this section, the provisions of this section shall have
effect notwithstanding anything contained in any other law for the time being in force."
12. It will be seen that as part of the Assam Accord, a huge number of illegal migrants were made
deemed citizens of India. It is interesting to note that Parliament has not enacted any law pertaining
to refugees from other countries. Refugee status can be granted and has been granted in India
through executive orders passed by the Central Government. In any case, Section 6A did not merely
rest content with granting refugee status to those who were illegal migrants from East Pakistan but
went on to grant them the benefit of citizenship of India so that all persons who had migrated before
1966 and all persons who migrated before 25th March, 1971 respectively were to become citizens of
India either immediately or as is mentioned by the Act after a period of 10 years once there has been
a determination that they have in fact settled in India between 1966 and 1971.
13. On 8th of November, 1998, Lieutenant General S.K. Sinha, the then Governor of Assam,
submitted an extensive report to the then President of India on the grave threat posed by the influx
of people from Bangladesh to Assam. He said:
"The dangerous consequences of large scale illegal migration from Bangladesh, both
for the people of Assam and more for the Nation as a whole, need to be
empathetically stressed. No misconceived and mistaken notions of secularism should
be allowed to come in the way of doing so.
As a result of population movement from Bangladesh, the spectre looms large of the
indigenous people of Assam being reduced to a minority in their home state. Their
cultural survival will be in jeopardy, their political control will be weakened and their
employment opportunities will be undermined.
The silent and invidious demographic invasion of Assam may result in the loss of the
geo-strategically vital districts of lower Assam. The influx of illegal migrants isAssam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

turning these districts into a Muslim majority region. It will then only be a matter of
time when a demand for their merger with Bangladesh may be made. The rapid
growth of international Islamic fundamentalism may provide the driving force for
this demand. In this context, it is pertinent that Bangladesh has long discarded
secularism and has chosen to become an Islamic State. Loss of lower Assam will
severe the entire land mass of the North East, from the rest of India and the rich
natural resources of that region will be lost to the Nation."
14. It was in this backdrop that a writ petition being Writ Petition No. 131 of 2000 was filed by
Sarbananda Sonowal assailing the Constitutional validity of "The Illegal Migrants (Determination by
Tribunals) Act, 1983"
and the rules made thereunder.
15. In a judgment reported in (2005) 5 SCC 665, this Court referred to the Assam
Accord and to the huge influx of illegal migrants into the State of Assam and came to
the conclusion that the 1983 Act and the rules made thereunder operated in the
reverse direction i.e. instead of seeing that illegal migrants are deported, it did the
opposite by placing the burden of proof on the State to prove that a person happens
to be an illegal migrant. This Court went on to hold that Article 355 of the
Constitution had been violated, in as much as the Union had failed to protect the
State of Assam against the external aggression and internal disturbance caused by the
huge influx of illegal migrants from Bangladesh to Assam and went on to hold the
1983 Act to be violative of Article 14 as well. In as much as this Act was struck down,
the Immigrants (Expulsion from Assam) Act 1950 together with the Foreigners Act
and the Foreigners Tribunal Order of 1964 were now to be the tools in the hands of
Government to do the job of detecting illegal migrants who were then to be deported.
16. On 14th July, 2004, in response to an unstarred question pertaining to
deportation of illegal Bangladeshi migrants, the Minister of State, Home Affairs,
submitted a statement to Parliament indicating therein that the estimated number of
illegal Bangladeshi immigrants into India as on 31st December, 2001 was 1.20 crores,
out of which 50 lakhs were in Assam.
17. Given the magnitude of the problem, a Foreigners (Tribunals for Assam) Order of
2006 was promulgated which was again struck down being found to be unreasonable
and arbitrary and which instead of expeditiously discovering illegal migrants and
deporting them, again did the opposite. It was in (2007) 1 SCC 174, in the second
Sonowal writ petition, that the Supreme Court struck down this order.
18. In the year 2012 and in 2014 large scale riots took place in Assam resulting in the
deaths of a large number of persons. It is in this background that the present writ
petitions have been filed.Assam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

19. A preliminary submission was urged by the learned Additional Solicitor General
of India Mr. Neeraj Kaul that Section 6A having been enacted in 1985, a challenge
made in 2012 would be barred by delay and laches. We will first advert to this
preliminary submission in order to see whether we will proceed further to determine
the issues raised in these writ petitions.
20. Writ Petition (Civil) No. 562 of 2012 which was taken up by us first contains the
following prayers:
"a) a writ in the nature of Certiorari or any other appropriate writ(s), order(s) or
direction(s) declaring Section 6A of The Citizenship Act, 1955 as discriminatory,
arbitrary and illegal and consequently striking down the impugned provision as
ultra-vires the Constitution of India;
b) a writ in the nature of Mandamus or any other appropriate writ(s), order(s) or
direction(s) directing the respondent no.1 and 3 not to update the National Register
of Citizens with respect to the State of Assam by taking into account the electoral rolls
prior to March 24th (midnight) 1971;
c) a writ in the nature of Mandamus or any other appropriate writ(s), order(s) or
direction(s) directing the respondent no 1 and 3 to update the National Register of
Citizens with respect to the State of Assam relying only on the details incorporated in
the National Register of Citizens prepared in 1951 ;
d) a writ in the nature of Mandamus or any other appropriate writ(s), order(s) or
direction(s) directing the respondents to treat 1951 as the base year for the purpose of
detection and deportation of illegal immigrants in the State of Assam;
e) a writ in the nature of Mandamus or any other appropriate writ(s), order(s) or
direction(s) directing the respondents no 1 and 2 to immediately take effective steps
towards ensuring the deportation of the illegal immigrants from the territory of
India;
f) Issue Rule Nisi in terms of prayers (a), (b), (c), (d) and (e) above;
g) Pass such other further or other writ, orders or directions as your Lordships may
deem fit and proper in the facts and circumstances of the instant case."
21. Article 32 of the Constitution which has been described as the "heart and soul" of the
Constitution guarantees the right to move the Supreme Court for the enforcement of all or any of the
fundamental rights conferred by Part III of the Constitution. This Article is, therefore, itself a
fundamental right and it is in this backdrop that we need to address the preliminary submission.Assam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

22. In Tilokchand Motichand v. H.B. Munshi (1969) 1 SCC 110, a Constitution Bench was asked to
decide on the Constitutional validity of Section 12A (4) of the Bombay Sales Tax Act. The precise
ground for challenge was a violation of Article 19(1)(f) of the Constitution. A majority of three out of
five Judges held that the petition was hit by the doctrine of laches and hence dismissed the petition.
In so holding, each of the Judges arrived at differing reasons as to why petitions under Article 32
ought to be dismissed on the ground of delay/laches. In paragraphs 9, 10 and 11 Hidayatullah, C.J.,
held:
"9. In India we have the Limitation Act which prescribes different periods of
limitation for suits, petitions or applications. There are also residuary articles which
prescribe limitation in those cases where no express period is provided. If it were a
matter of a suit or application, either an appropriate article or the residuary article
would have applied. But a petition under Article 32 is not a suit and it is also not a
petition or an application to which the Limitation Act applies. To put curbs in the way
of enforcement of Fundamental Rights through legislative action might well be
questioned under Article 13(3). The reason is also quite clear. If a short period of
limitation were prescribed the Fundamental Right might well be frustrated.
Prescribing too long a period might enable stale claims to be made to the detriment
of other rights which might emerge.
10. If then there is no period prescribed what is the standard for this Court to follow?
I should say that utmost expedition is the sine qua non for such claims. The party
aggrieved must move the Court at the earliest possible time and explain satisfactorily
all semblance of delay. I am not indicating any period which may be regarded as the
ultimate limit of action for that would be taking upon myself legislative functions. In
England a period of 6 months has been provided statutorily, but that could be
because there is no guaranteed remedy and the matter is one entirely of discretion. In
India I will only say that each case will have to be considered on its own facts. Where
there is appearance of avoidable delay and this delay affects the merits of the claim,
this Court will consider it and in a proper case hold the party disentitled to invoke the
extraordinary jurisdiction.
11. Therefore, the question is one of discretion for this Court to follow from case to
case. There is no lower limit and there is no upper limit. A case may be brought
within Limitation Act by reason of some article but this Court need not necessarily
give the total time to the litigant to move this Court under Article 32. Similarly in a
suitable case this Court may entertain such a petition even after a lapse of time. It will
all depend on what the breach of the Fundamental Right and the remedy claimed are
when and how the delay arose."
Justice Sikri held as follows:
"18. It seems to me, however, that the above solution is not quite appropriate for
petitions under Article 32. A delay of 12 years or 6 years would make a strangeAssam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

bed-fellow with a direction or order or writ in the nature of mandamus, certiorari and
prohibition. Bearing in mind the history of these writs I cannot believe that the
Constituent Assembly had the intention that five Judges of this Court should sit
together to enforce a fundamental right at the instance of a person, who had without
any reasonable explanation slept over his rights for 6 or 12 years. The history of these
writs both in England and the U.S.A. convinces me that the underlying idea of the
Constitution was to provide an expeditious and authoritative remedy against the
inroads of the State. If a claim is barred under the Limitation Act, unless there are
exceptional circumstances, prima facie it is a stale claim and should not be
entertained by this Court. But even if it is not barred under the Indian Limitation Act,
it may not be entertained by this Court if on the facts of the case there is
unreasonable delay. For instance, if the State had taken possession of property under
a law alleged to be void, and if a petitioner comes to this Court 11 years after the
possession was taken by the State, I would dismiss the petition on the ground of
delay, unless there is some reasonable explanation. The fact that a suit for possession
of land would still be in time would not be relevant at all. It is difficult to lay down a
precise period beyond which delay should be explained. I favour one year because
this Court should not be approached lightly, and competent legal advice should be
taken and pros and cons carefully weighed before coming to this Court. It is common
knowledge that appeals and representations to the higher authorities take time; time
spent in pursuing these remedies may not be excluded under the Limitation Act, but
it may ordinarily be taken as a good explanation for the delay.
30. In my opinion the petitioner was under a mistake of law, when he paid up, the
mistake being that he thought that Section 12-A(4) was a valid provision in spite of its
imposing unreasonable restrictions. This mistake he discovered like all assessees
when this court struck down Section 12- A(4) of the Bombay Sales Tax Act. He has
come to this Court within six months of that day and there is no delay".
Bachawat J., held as follows:
"41. Similarly this Court acts on the analogy of the statute of limitation in respect of a
claim under Article 32 of the Constitution though such claim is not the subject of any
express statutory bar of limitation. If the right to a property is extinguished by
prescription under Section 27 of the Limitation Act, 1963, the petitioner has no
subsisting right which can be enforced under Article 32 (see Sobbraj Odharmal v.
State of Rajasthan) [(1963) Supp (1) SCR 99, 111] . In other cases where the remedy
only and not the right is extinguished by limitation, it is on grounds of the public
policy that the court refuses to entertain stale claims under Article 32. The statutes of
limitation are founded on sound principles of public policy. As observed in Whitley
Stoke's Anglo-Indian Codes, Vol. 11, p. 940; "The law is founded on public policy, its
aim being to secure the quiet of the community, to suppress fraud and perjury, to
quicken diligence, and to prevent oppression". In Her Highness Ruckmaboye v.
Luloobhoy Mottickchund [(1851-52) 5 MIA 234, 251] the Privy Council observed thatAssam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

the object of the statutes of limitation was to give effect to the maxim, "interest
reipublicoe ut sit finis litium" (co litt 303) the interest of the State requires that there
should be a limit to litigation. The rule of res judicata is founded upon the same rule
of public policy, see Daryao v. State of U.P. at p. 584. The other ground of public
policy upon which the statutes of limitation are founded is expressed in the maxim
"vigilantibus non dormientibus jura subveniunt" (2 Co Inst. 690) the laws aid the
vigilant and not those who slumber. On grounds of public policy the court applies the
principles of res judicata to writ petitions under Article 32. On like grounds the court
acts on the analogy of the statutes of limitation in the exercise of its jurisdiction
under Article 32. It follows that the present petition must be dismissed"
Mitter J., held as follows:
"66. In my view, a claim based on the infraction of fundamental rights ought not to be
entertained if made beyond the period fixed by the Limitation Act for the
enforcement of the right by way of suit. While not holding that the Limitation Act
applies in terms, I am of the view that ordinarily the period fixed by the Limitation
Act should be taken to be a true measure of the time within which a person can be
allowed to raise a plea successfully under Article 32 of the Constitution. "
The sole dissentient was Hegde, J., who decided that Article 32 itself being a fundamental right,
there is no question of delay being used to non- suit a petitioner at the threshold. His minority view
is as follows:
"75. There has been some controversy whether an aggrieved party can waive his
fundamental right. That question was elaborately considered in Basheshar Nath v.
CIT, Delhi, Rajasthan [(1959) Supp (1) SCR 528] by a Constitution Bench consisting
of S.R. Das, C.J., and Bhagwati, S.K. Das, J.L., Kapur and Subba Rao, JJ. The learned
Chief Justice and Kapur, J., held that there could be no waiver of a fundamental right
founded on Article 14. Bhagwati and Subba Rao, JJ., held that no fundamental right
can be waived and S.K. Das, J., held that only such fundamental rights which are
intended to the benefit of a party can be waived. I am mentioning all these aspects to
show how zealously this court has been resisting every attempt to narrow down the
scope of the rights guaranteed under Part III of our Constitution.
76. Admittedly the provisions contained in the Limitation Act do not apply to
proceedings under Article 226 or Article 32. The Constitution makers wisely, if I may
say with respect, excluded the application of those provisions to proceedings under
Articles 226, 227 and 32 lest the efficacy of the constitutional remedies should be left
to the tender mercies of the legislatures. This Court has laid down in I.C. Golaknath v.
State of Punjab [(1967) 2 SCR 762] that the Parliament cannot by amending the
Constitution abridge the fundamental rights conferred under Part III of the
Constitution. If we are to bring in the provisions of Limitation Act by an indirect
process to control the remedies conferred by the Constitution it would mean thatAssam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

what the Parliament cannot do directly it can do indirectly by curtailing the period of
limitation for suits against the Government. We may console ourselves by saying that
the provisions of the Limitation Act will have only persuasive value but they do not
limit the power of this Court but the reality is bound to be otherwise. Very soon the
line that demarcates the rule of prudence and binding rule is bound to vanish as has
happened in the past. The fear that forgotten claims and discarded rights may be
sought to be enforced against the Government after lapse of years, if the fundamental
rights are held to be enforceable without any time limit appears to be an exaggerated
one. It is for the party who complains the infringement of any right to establish his
right. As years roll on his task is bound to become more and more difficult. He can
enforce only an existing right. A right may be lost due to an earlier decision of a
competent court or due to various other reasons. If a right is lost for one reason or
the other there is no right to be enforced. In this case we are dealing with an existing
right even if it can be said that the petitioners' remedy under the ordinary law is
barred. If the decision of Bachawat and Mitter, JJ., is correct, startling results are
likely to follow. Let us take for example a case of a person who is convicted and
sentenced to a long period of imprisonment on the basis of a statute which had been
repealed long before the alleged offence was committed. He comes to know the repeal
of the statute long after the period prescribed for filing appeal expires. Under such a
circumstance according to the decision of Bachawat and Mitter, JJ., he will have no
right - the discretion of the court apart - to move this court for a writ of habeas
corpus.
77. Our Constitution makers in their wisdom thought that no fetters should be placed
on the right of an aggrieved party to seek relief from this court under Article 32. A
comparison of the language of Article 226 with that of Article 32 will show that while
under Article 226 a discretionary power is conferred on the High Courts the mandate
of the Constitution is absolute so far as the exercise of this court's power under
Article 32 is concerned. Should this court, an institution primarily created for the
purpose of safeguarding the fundamental rights guaranteed under Part III of the
Constitution, narrow down those rights? The implications of this decision are bound
to be far reaching. It is likely to pull down from the high pedestal now occupied by the
fundamental rights to the level of other civil rights. I am apprehensive that this
decision may mark an important turning point in downgrading the fundamental
rights guaranteed under the Constitution. I am firmly of the view that a relief asked
for under Article 32 cannot be refused on the ground of laches. The provisions of the
Limitation Act have no relevance either directly or indirectly to proceedings under
Article 32. Considerations which are relevant in proceedings under Article 226 are
wholly out of place in a proceeding like the one before us. The decision of this court
referred to in the judgment of Bachawat and Mitter, JJ., where this court has taken
into consideration the laches on the part of the petitioners are not apposite for our
present purpose. None of those cases deal with proceedings under Article 32 of the
Constitution. The rule enunciated by this court in the State of M.P. v. Bhailal Bhai,
[(1964) 6 SCR 261] is only applicable to proceedings under Article 226. At p. 271 ofAssam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

the report, Das Gupta, J., who spoke for the court specifically referred to this aspect
when he says:
"That it has been made clear more than once that power to relief under Article 226 is
a discretionary power."
23. It will thus be seen that Hidayatullah, C.J., did not lay down any fixed period. According to him,
there is no lower limit or upper limit except that utmost expedition is a sine qua non for moving a
petition under Article 32. The learned Chief Justice left it to be decided on the facts of each case
depending on what the breach of the fundamental right is, what the remedy claimed is, and when
and how the delay arose. Sikri J., on the other hand was in favour of an inflexible time limit that is
not beyond one year. Both Bachawat and Mitter, J., would ask the question as to whether time
under the Limitation Act had run out, and if so, whether the writ petition ought to be dismissed as a
result.
24. It is clear from a reading of these differing judgments that the ratio of this Constitution bench
judgment can broadly be stated to be that a writ petition filed under Article 32 can be dismissed on
the ground of delay. Beyond that, there is no discernible ratio as no majority can be cobbled up for
deciding on what basis such writ petition can be so dismissed.
25. Close on the heels of this judgment in Rabindranath Bose & Ors. v. Union of India & Ors., (1970)
1 SCC 84, a fervent plea was made to reconsider the judgment in Tilokchand Motichand. This plea
was turned down and it was held that a stale claim of 15 years to challenge appointments and
promotions already made without any explanation for so moving after 15 years would result in
dismissal of an Article 32 petition, more so when rights had accrued to the respondents in that case.
The Court held:
"31. But insofar as the attack is based on the 1952 Seniority Rules, it must fail on
another ground. The ground being that this petition under Article 32 of the
Constitution has been brought about fifteen years after the 1952 Rules were
promulgated and effect given to them in the Seniority List prepared on August 1,
1953. Learned counsel for the petitioners says that this Court has no discretion and
cannot dismiss the petition under Article 32 on the ground that it has been brought
after inordinate delay. We are unable to accept this contention. This Court by
majority in Tilokchand Moti Chand v. H.B. Munshi [(1969) 1 SCC 110] held that delay
can be fatal in certain circumstances. We may mention that in Laxmanappa
Hanumantappa Jamkhandi v. Union of India [AIR 1955 SC 3, (1955) 1 SCR 769]
Mahajan, C.J., observed as follows:
"From the facts stated above it is plain that the proceedings taken under the
impugned Act 30 of 1947 concluded so far as the Investigation Commission is
concerned in September 1952 more than two years before this petition was presented
in this Court. The assessment orders under the Income Tax Act itself were made
against the petitioner in November 1953. In these circumstances, we are of theAssam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

opinion that he is entitled to no relief under the provisions of Article 32 of the
Constitution. It was held by this Court in Ramjilal v. ITO that as there is a special
provision in Article 265 of the Constitution that no tax shall be levied or collected
except by authority of law, clause (1) of Article 31 must therefore be regarded as
concerned with deprivation of property otherwise than by the imposition or
collection of tax, and inasmuch as the right conferred by Article 265 is not a right
conferred by Part III of the Constitution, it could not be enforced under Article 32. In
view of this decision it has to be held that the petition under Article 32 is not
maintainable in the situation that has arisen and that even otherwise in the peculiar
circumstances that have arisen, it would not be just and proper to direct the issue of
any of the writs the issue of which is discretionary with the Court."
(emphasis supplied).
32. The learned counsel for the petitioners strongly urges that the decision of this Court in
Tilokchand Motichand case [(1969) 1 SCC 110] needs review. But after carefully considering the
matter, we are of the view that no relief should be given to petitioners who, without any reasonable
explanation, approach this Court under Article 32 of the Constitution after inordinate delay. The
highest Court in this land has been given original jurisdiction to entertain petitions under Article 32
of the Constitution. It could not have been the intention that this Court would go into stale demands
after a lapse of years. It is said that Article 32 is itself a guaranteed right. So it is, but it does not
follow from this that it was the intention of the Constitution-makers that this Court should discard
all principles and grant relief in petitions filed after inordinate delay.
33. We are not anxious to throw out petitions on this ground, but we must administer justice in
accordance with law and principles of equity, justice and good conscience. It would be unjust to
deprive the respondents of the rights which have accrued to them. Each person ought to be entitled
to sit back and consider that his appointment and promotion effected a long time ago would not be
set aside after the lapse of a number of years. It was on this ground that this Court in Jaisinghani
case observed that the order in that case would not affect Class II officers who have been appointed
permanently as Assistant Commissioners. In that case, the Court was only considering the challenge
to appointments and promotions made after 1950. In this case, we are asked to consider the validity
of appointments and promotions made during the periods of 1945 to 1950. If there was adequate
reason in that case to leave out Class II officers, who had been appointed permanently Assistant
Commissioners, there is much more reason in this case that the officers who are now permanent
Assistant Commissioners of Income Tax and who were appointed and promoted to their original
posts during 1945 to 1950, should be left alone."
26. In Ramchandra Shankar Deodhar v. State of Maharashtra, (1974) 1 SCC 317, a Constitution
Bench was invited to dismiss a petition filed under Article 32 on the ground of laches. The petitioner
having approached the court after a delay of at least eight years, the Court held that barring a writ
petition containing stale claims is not a rule of law but a rule of practice based on sound and proper
discretion. There is no inviolable rule that whenever there is a delay, the court must necessarily
refuse to entertain the petition. After referring to Tilokchand Motichand and Rabindranath Bose,Assam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

the Court held that the claim for enforcement of the fundamental right of equal opportunity under
Article 16 cannot be dismissed solely on the ground of delay/laches etc. The Court also went on to
hold that promotions being provisional, no rights have been conferred on those who are promoted
whose interest can therefore be defeated if ultimately it is found that such promotions are not
warranted in law.
27. In Express Publication (Madurai) Ltd. v. Union of India, (2004) 11 SCC 526, the employer
newspaper wished to challenge paragraph 80 of the Employees Provident Fund Scheme, 1952,
which came into force in 1956. The challenge was made in a writ petition under Article 32, 45 years
later in 2001. This was turned down by a Bench of two Judges with a caveat, that if it was the case of
the petitioners that with the passage of time, a certain provision had become unconstitutional, then
obviously the very passage of time would not amount to delay for which a writ petition would not be
entertained.
28. Similarly in T.K. Dingal v. State of West Bengal, (2009) 1 SCC 768, a Bench of two Judges held
that there is no upper and no lower limit when it comes to an Article 32 petition. It all depends on
the breach of the particular fundamental right, the remedy claimed, and how the delay arose. On
facts, the petition was turned down as there was an unexplained delay of ten years.
29. In Bangalore City Co-operative Housing Society v. State of Karnataka, (2012) 3 SCC 727, a two
Judge Bench of this Court understood the ratio of Tilokchand Motichand as follows:
"46. In Tilokchand Motichand v. H.B. Munshi [(1969) 1 SCC 110] the Constitution
Bench considered the question whether the writ petition filed under Article 32 of the
Constitution for refund of the amount forfeited by the Sales Tax Officer under Section
21(4) of the Bombay Sales Tax Act, 1953, which, according to the petitioner, was ultra
vires the powers of the State Legislature should be entertained ignoring the delay of
almost nine years. Sikri and Hedge, JJ. were of the view that even though the
petitioner had approached the Court with considerable delay, the writ petition filed
by it should be allowed because Section 12-A(4) of the Bombay Sales Tax Act, 1946
was declared unconstitutional by the Division Bench of the High Court (sic
Constitution Bench of the Supreme Court) [Ed.:
S. 12-A(4) of the Bombay Sales Tax Act, 1946 (corresponding to S. 21(4) of the
Bombay Sales Tax Act, 1953) was struck down by the Constitution Bench of the
Supreme Court in Kantilal Babulal v. H.C. Patel, AIR 1968 SC 445 : (1968) 1 SCR 735
: 21 STC 174 for being violative of Art. 19(1)(f) of the Constitution.] . Bachawat and
Mitter, JJ. opined that the writ petition should be dismissed on the ground of delay.
47. Hidayatullah, C.J. who agreed with Bachawat and Mitter, JJ. in Tilokchand case[(1969) 1 SCC
110] noted that no period of limitation has been prescribed for filing a petition under Article 32 of
the Constitution and proceeded to observe: (SCC p. 116, para 11) "11. Therefore, the question is one
of discretion for this Court to follow from case to case. There is no lower limit and there is no upper
limit. A case may be brought within the Limitation Act by reason of some article but this Court needAssam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

not necessarily give the total time to the litigant to move this Court under Article 32. Similarly in a
suitable case this Court may entertain such a petition even after a lapse of time. It will all depend on
what the breach of the fundamental right and the remedy claimed are when and how the delay
arose."
48. The ratio of the aforesaid decision is that even though there is no period of limitation for filing
petitions under Articles 32 and 226 of the Constitution, the petitioner should approach the Court
without loss of time and if there is delay, then cogent explanation should be offered for the same.
However, no hard-and-fast rule can be laid down or a straitjacket formula can be adopted for
deciding whether or not this Court or the High Court should entertain a belated petition filed under
Article 32 or Article 226 of the Constitution and each case must be decided on its own facts."
30. It will be seen that, in the present case, the petitioners in the various writ petitions represent an
entire people - the tribal and non- tribal population of the State of Assam. In their petition, they
have raised a plea that the sovereignty and integrity of India is itself at stake as a massive influx of
illegal migrants from a neighboring country has affected this core Constitutional value. That, in fact,
it has been held in Sonowal's case that such an influx is "external aggression" within the meaning of
Article 355 of the Constitution of India, and that the Central Government has done precious little to
stem this tide thereby resulting in a violation of Article 355. As a result of this huge influx, periodic
clashes have been taking place between the citizens of India and these migrants resulting into loss of
life and property, sounding in a violation of Articles 21 and 29 of the Constitution of the Assamese
people as a whole. Not only is there an assault on the life of the citizenry of the State of Assam but
there is an assault on their way of life as well. The culture of an entire people is being eroded in such
a way that they will ultimately be swamped by persons who have no right to continue to live in this
country. The petitioners have also argued that this Hon'ble Court in Sonowal's case has specifically
held in para 79 thereof that Bangladeshi nationals who have illegally crossed the border and have
trespassed into Assam or are living in other parts of the country have no legal right of any kind to
remain in India and are liable to be deported. They have also raised a fervent plea that Article 14
also continues to be violated as Section 6A (3) to (5) are not time bound but are ongoing.
31. Given the contentions raised specifically with regard to pleas under
Articles 21 and 29, of a whole class of people, namely, the tribal and non- tribal
citizens of Assam and given the fact that agitations on this core are ongoing, we do
not feel that petitions of this kind can be dismissed at the threshold on the ground of
delay/laches. Indeed, if we were to do so, we would be guilty of shirking our
Constitutional duty to protect the lives of our own citizens and their culture. In fact,
the time has come to have a relook at the doctrine of laches altogether when it comes
to violations of Articles 21 and 29.
32. Tilokchand Motichand is a judgment involving property rights of individuals. Ramchandra
Deodhar's case, also of a Constitution Bench of five judges has held that the fundamental right
under Article 16 cannot be wished away solely on the 'jejune' ground of delay. Since Tilokchand
Motichand's case was decided, there have been important strides made in the law. Property RightsAssam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

have been removed from part III of the Constitution altogether by the Constitution 44th
Amendment Act. The same amendment made it clear that even during an emergency, the
fundamental right under Article 21 can never be suspended, and amended Article 359 (1) to give
effect to this. In Maneka Gandhi v. Union of India, (1978) 1 SCC 248 decided nine years after
Tilokchand Motichand, Article 21 has been given its new dimension, and pursuant to the new
dimension a huge number of rights have come under the umbrella of Article 21 (for an enumeration
of these rights, see Kapila Hingorani v. State of Bihar, (2003) 6 SCC 1 at para 57). Further, in Olga
Tellis & Ors. v. Bombay Municipal Corporation, (1985) 3 SCC 545, it has now been conclusively held
that all fundamental rights cannot be waived (at para 29). Given these important developments in
the law, the time has come for this Court to say that at least when it comes to violations of the
fundamental right to life and personal liberty, delay or laches by itself without more would not be
sufficient to shut the doors of the court on any petitioner.
33. Coming now to the merits, we have heard several counsels for the petitioners who have raised a
number of points, which have been rebutted by the counsel for the Union of India, the State of
Assam and several interveners. We feel that the following questions need to be answered by an
appropriate Bench as most of them are substantial questions as to the interpretation of the
Constitution which have to be decided by a minimum of 5 Judges under Article 145(3). An
enumeration of these questions is as follows:
(i) Whether Articles 10 and 11 of the Constitution of India permit the enactment of
Section 6A of the Citizenship Act in as much as Section 6A, in prescribing a cut-off
date different from the cut-off date prescribed in Article 6, can do so without a
"variation" of Article 6 itself; regard, in particular, being had to the phraseology of
Article 4 (2) read with Article 368 (1)?
(ii) Whether Section 6A violates Articles 325 and 326 of the Constitution of India in that it has
diluted the political rights of the citizens of the State of Assam;
(iii) What is the scope of the fundamental right contained in Article 29(1)? Is the fundamental right
absolute in its terms? In particular, what is the meaning of the expression "culture" and the
expression "conserve"? Whether Section 6A violates Article 29(1)?
(iv) Whether Section 6A violates Article 355? What is the true interpretation of Article 355 of the
Constitution? Would an influx of illegal migrants into a State of India constitute "external
aggression"
and/or "internal disturbance"? Does the expression "State" occurring in this Article
refer only to a territorial region or does it also include the people living in the State,
which would include their culture and identity?
(v) Whether Section 6A violates Article 14 in that, it singles out Assam from other
border States (which comprise a distinct class) and discriminates against it. Also
whether there is no rational basis for having a separate cut-off date for regularizingAssam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

illegal migrants who enter Assam as opposed to the rest of the country; and
(vi) Whether Section 6A violates Article 21 in that the lives and personal liberty of the
citizens of Assam have been affected adversely by the massive influx of illegal
migrants from Bangladesh.
(vii) Whether delay is a factor that can be taken into account in moulding relief under
a petition filed under Article 32 of the Constitution?
(viii) Whether, after a large number of migrants from East Pakistan have enjoyed
rights as Citizens of India for over 40 years, any relief can be given in the petitions
filed in the present cases?
(ix) Whether section 6A violates the basic premise of the Constitution and the
Citizenship Act in that it permits Citizens who have allegedly not lost their
Citizenship of East Pakistan to become deemed Citizens of India, thereby conferring
dual Citizenship to such persons?
(x) Whether section 6A violates the fundamental basis of section 5 (1) proviso and
section 5 (2) of the Citizenship Act (as it stood in 1985) in that it permits a class of
migrants to become deemed Citizens of India without any reciprocity from
Bangladesh and without taking the oath of allegiance to the Indian Constitution?
(xi) Whether the Immigrants (Expulsion from Assam) Act, 1950 being a special
enactment qua immigrants into Assam, alone can apply to migrants from East
Pakistan/Bangladesh to the exclusion of the general Foreigners Act and the
Foreigners (Tribunals) Order, 1964 made thereunder?
(xii) Whether Section 6A violates the Rule of Law in that it gives way to political
expediency and not to Government according to law?
(xiii) Whether Section 6A violates fundamental rights in that no mechanism is
provided to determine which persons are ordinarily resident in Assam since the dates
of their entry into Assam, thus granting deemed citizenship to such persons
arbitrarily?
34. These matters be placed before the Chief Justice for constitution of an appropriate bench to
answer the above questions. As notice is yet to be issued in Writ Petition (Civil) No. 876 of 2014, we
direct that notice be issued and served on the Respondents in the said writ petition.
35. As Section 6A of the Citizenship Act must be deemed to be valid until the larger Bench decides
these matters, we will proceed, for the purposes of this order, on the footing that Section 6A of the
Citizenship Act is valid.Assam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

36. As the statement of objects and reasons for the enactment of Section 6A states, the said Section
was inserted into the statute book in 1985 to implement one part of the Assam Accord dated 15th
August, 1985. The Assam Accord contained various provisions providing for reciprocal obligations.
These are largely contained in paragraphs 5, 6, 9 and 10 which read as under:
"5.
1. For purpose of detection and deletion of foreigners, 1-1-1966 shall be the base date
and year.
2. All persons who came to Assam prior to 1-1-1966, including those amongst them
whose names appeared on the electoral rolls used in 1967 elections, shall be
regularized.
3. Foreigners who came to Assam after 1-1-1966 (inclusive) and upto 24th March,
1971 shall be detected in accordance with the provisions of the Foreigners Act, 1946
and the Foreigners (Tribunals) Order, 1939.
4. Names of foreigners so detected will be deleted from the electoral rolls in force.
Such persons will be required to register themselves before the Registration Officers
of the respective districts in accordance with the provisions of the Registration of
Foreigners Act, 1939 and the Registration of Foreigners Rules, 1939.
5. For this purpose, Government of India will undertake suitable strengthening of the
governmental machinery.
6. On the expiry of the period of ten year following the date of detection, the names of
all such persons which have been deleted from the electoral rolls shall be restored.
7. All persons who were expelled earlier, but have since re-entered illegally into
Assam, shall be expelled.
8. Foreigners who came to Assam on or after March 25, 1971 shall continue to be
detected, deleted and expelled in accordance with the law. Immediate and practical
steps shall be taken to expel such foreigners.
9. The Government will give due consideration to certain difficulties express by the
AASU/AAGSP regarding the implementation of the illegal Migrants (Determination
by Tribunals) Act, 1983.
6. Constitutional, legislative and administrative safeguards, as may be appropriate,
shall be provided to protect, preserve and promote the cultural, social, linguistic
identity and heritage of the Assamese people.Assam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

9.
1. The international border shall be made secure against future infiltration by
erection of physical barriers like walls barbed wire fencing and other obstacles at
appropriate places. Patrolling by security forces on land and riverine routes all along
the international border shall be adequately intensified. In order to further
strengthen the security arrangements, to prevent effectively future infiltration, an
adequate number of check posts shall be set up.
2. Besides the arrangements mentioned above and keeping in view security
considerations, a road all along the international border shall be constructed so as to
facilitate patrolling by security forces. Land between border and the road would be
kept free of human habitation, wherever possible. Riverine patrolling along the
international border would be intensified. All effective measures would be adopted to
prevent infiltrators crossing or attempting to cross the international border.
10. It will be ensured that relevant laws for prevention of encroachment of
government lands and lands in tribal belts and blocks are strictly enforced and
unauthorized encroachers evicted as laid down under such laws."
37. Sarbananda Sonowal v. Union of India & Anr., (2005) 5 SCC 665, dealt with the Assam Accord in
some detail in as much as The Illegal Migrants (Determination by Tribunals) Act, 1983 was under
challenge in that case. This Court examined a writ petition filed under Article 32 and various
affidavits filed by the Union of India and the State of Assam regarding implementation of the Assam
Accord. The following paragraphs from the judgment will show that whereas a part of paragraph 5
of the Accord has been fully implemented by enacting Section 6A, precious little has been done by
the Union of India and the State of Assam to implement the other parts of the Accord.
"2...................... As a result of the students' movement and ensuing negotiations, a
memorandum of settlement dated 15-8-1985 was entered into between All Assam
Students' Union and the Union of India and the State of Assam, which is commonly
known as "Assam Accord". The terms of the Accord specifically provided that steps
would be taken to detect and deport illegal migrants from Assam and it also
contained a clause that "the Government will give due consideration to certain
difficulties expressed by AASU/AAGSP regarding the implementation of the Illegal
Migrants (Determination by Tribunals) Act, 1983". The Accord further provided that
foreigners who have entered into India after 25-3-1971 will continue to be detected,
their names deleted from the electoral rolls and they will be deported from India. In
pursuance of this provision, the Citizenship Act, 1955 was amended by Act 65 of 1985
and Section 6-A was inserted with the heading "Special provisions as to citizenship of
persons covered by the Assam Accord". It provides that the term "detected to be a
foreigner" shall mean so detected under the Foreigners Act and the Foreigners
(Tribunals) Order, 1964 framed thereunder. Under the said provision a person of
Indian origin as defined under Section 6-A (3) who entered into Assam prior to 1-1-Assam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

1966 and has been resident in Assam since then is deemed to be a citizen of India.
However, if such a person entered into Assam between 1-1-1966 and before 25-3-1971
and has been detected to be a foreigner under the Foreigners Act then he is not
entitled to be included in the electoral list for a period of 10 years from the date of
detection. This amendment of the Citizenship Act makes it clear that the question of
determination or detection of a foreigner is to be governed by the provisions of the
existing Central legislation viz. the Foreigners Act, 1946 and the Foreigners
(Tribunals) Order, 1964.
4. The Union of India filed a counter-affidavit on 18-7-2000, which has been sworn
by Shri Jatinder Bir Singh, Director, Ministry of Home Affairs. In para 7 of this
affidavit, it was stated that a proposal to repeal the IMDT Act is under consideration
of the Government of India. A copy of the reply given by Shri I.D. Swami, Minister of
State in the Ministry of Home Affairs in the Rajya Sabha on 8-3-2000 has been filed
as Annexure R-2 to the counter-affidavit, wherein the Minister had said that in the
State of Assam Foreigners Tribunals under the Foreigners Act, 1946 are functioning
for detection of illegal migrants, who had come to the State of Assam after 1-1-1966
and up to 24-3-1971 and the Illegal Migrants Determination Tribunals under the
IMDT Act have been constituted for detection and deportation of illegal migrants,
who had entered into India on or after 25- 3-1971. The Hon'ble Minister had further
stated that the Government is of the view that application of the IMDT Act to the
State of Assam alone is discriminatory and a proposal to repeal the said Act is under
consideration of the Government. A true copy of the latest status report filed by the
Government in Writ Petition No. 125 of 1998, which has been filed seeking
deportation of all Bangladeshi nationals from India, has been filed as Annexure R-1
to the counter-affidavit and paras 3 to 7 of the said status report are being
reproduced below:
"3. Continuing influx of Bangladeshi nationals into India has been on account of a
variety of reasons including religious and economic. There is a combination of factors
on both sides which are responsible for continuing influx of illegal immigration from
Bangladesh. The important 'Push Factors' on the Bangladesh side include:
(a) steep and continuous increase in population;
(b) sharp deterioration in land-man ratio;
(c) low rates of economic growth particularly poor performance in agriculture;
The 'Pull Factors' on the Indian side include:
(a) ethnic proximity and kinship enabling easy shelter to the immigrants;
(b) porous and easily negotiable border with Bangladesh;Assam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

(c) better economic opportunities;
(d) interested religious and political elements encouraging immigration;
4. It is difficult to make a realistic estimate of the number of illegal immigrants from
Bangladesh because they enter surreptitiously and are able to mingle easily with the
local population due to ethnic and linguistic similarities. The demographic
composition in the districts bordering Bangladesh has altered with the illegal
immigration from Bangladesh. The districts of Assam and West Bengal bordering
Bangladesh have recorded growth of population higher than the national average.
The States of Meghalaya, Mizoram and Tripura have also recorded high rates of
population growth. Illegal immigrants from Bangladesh have also been using West
Bengal as a corridor to migrate to other parts of the country.
5. The large-scale influx of illegal Bangladesh immigrants has led to large tracts of
sensitive international borders being occupied by foreigners.
This has serious implications for internal security.
6. The types of illegal migrants are as follows:
(a) those who came with valid visa/documents and overstayed;
(b) those who came with forged visa/documents; and
(c) those who entered surreptitiously.
7. During talks between the Prime Ministers of India and Bangladesh in February 1972, the Prime
Minister of Bangladesh had assured the return of all Bangladesh nationals who had taken shelter in
India since 25-3-1971. Accordingly a circular was issued by the Government of India on 30-9-1972
setting out guidelines for action to be taken in respect of persons who had come to India from
Bangladesh. According to this circular, those Bangladesh nationals who had come to India before
25-3-1971 were not to be sent back and those who entered India in or after the said date were to be
repatriated."
5. In para 12 of the counter-affidavit it is stated that "the basic objection of the petitioner is under
consideration of the Central Government that the IMDT Act and the Rules made thereunder are not
effective in comparison to the Foreigners Act, 1946, which is applicable to the whole country except
to the State of Assam". In para 18 of the counter- affidavit it is stated that the administrative powers
in respect of the IMDT Act have been delegated to the Government of Assam under Section 21 of the
aforesaid Act. The second sub-paragraph of para 18 and para 19 of the counter-affidavit are
important and are being reproduced below:Assam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

"It is further submitted that the detection/expulsion of illegal migrants under the
IMDT Act, has been extremely dismal. According to the information furnished by the
Government of Assam, the progress in respect of detection/expulsion of illegal
migrants (those who entered Assam on or after 25-3-1971 up to 30-4-2000) is as
follows:
1. Total number of enquiries initiated 3,10,759
2. Total number of enquiries completed 3,07,955
3. Total number of enquiries referred to the Screening 3,01,986 Committee
4. Total number of enquiries made by the Screening 2,98,465 Committee
5. Total number of enquiries referred to IM(DT)s 38,631
6. Total number of enquiries disposed of by IM(DT)s 16,599
7. Total number of persons declared as illegal migrants 10,015
8. Total number of illegal migrants physically expelled 1481
9. Total number of illegal migrants to whom expulsion 5733 order served
10. Total number of enquiries pending with the Screening 3521 Committee
11. Total number of enquiries pending with the Tribunal 22,072 In reply to para 9, it
is submitted that the Chief Minister of Assam had requested the then Prime Minister
vide his letter dated 22-6-1996 regarding repeal of the IMDT Act. The Chief Minister
again reiterated for scrapping the IMDT Act, vide his letter dated 31-7-1996
addressed to the Home Minister. This view has been reconfirmed by the State
Government vide its message dated 23-4-1998."
11. The Union of India filed a counter-affidavit sworn by Shri Jatinder Bir Singh, Director, Ministry
of Home Affairs, in reply to the additional affidavit of the State of Assam. It is averred therein that
the matter of constitutional validity of the IMDT Act does not depend on political issues, but
depends on facts and legal grounds. The relevant part of the opening part of the affidavit which has
some relevance is being reproduced below:
"In this context, it is submitted that detection of illegal migrants, who belong to the
same ethnic stock as Indians is not an easy task. However, large-scale illegal migrants
from Bangladesh have not only threatened the demographic structure of the area but
have seriously impaired the security of the nation, particularly in the present
circumstances. The need for expeditious identification of illegal migrants is moreAssam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

pressing now than ever. It is not a matter of dealing with a religious or linguistic
group. It is a question of identifying those who illegally crossed over the border and
continue to live in India contrary to the Indian law and the Constitution.
The facts and figures which have been stated by the Union of India in its affidavit
filed in the case titled 'Jamiat Ulama-E-Hind v. Union of India [WP (C) No. 7 of
2001]' clearly indicate that it is the existence of the IMDT Act, which has been the
single factor responsible for dismal detection and expulsion of illegal migrants in
Assam. It has also been pointed out that in the neighbouring States, where this law is
not in force, the process of detection (although far from satisfactory) has been far
more effective than in the State of Assam. The application of the IMDT Act, 1983 in
Assam virtually gives the illegal migrants, in the State, preferential protection in a
matter relating to the citizenship of India. This is clearly unconstitutional and
violative of the principles of equality. The affidavit of the State seems to suggest that
the matter has now become a political rather than a legal issue. However, it is
submitted that as far as the present pleadings are concerned, the issues indicated in
the present affidavit of the State under reply, are not relevant. None of the
submissions made in the connected affidavit, referred to above filed by the Union of
India in connected Writ Petition No. 7 of 2001, are controverted by the State of
Assam in present affidavit. Besides this, the State has not given any fresh facts and
figures, which would seek to suggest that this Act has secured the object of dealing
with illegal infiltrators."
13. The petitioner has also filed a reply to the additional affidavit filed on behalf of the State of
Assam, where besides reiterating his earlier pleas, it is averred that the Indian National Congress
representatives from North-East have themselves alluded to the problem of illegal migration in the
past. Reference is made to a report of the General Secretaries to the Seventh General Conference of
the North-Eastern Congress (I) Coordination Committee dated 3-7-1992 wherein it was recorded as
under:
"20.1 There are infiltrations - though it is a difficult task to examine the precise
number.
20.2 The infiltrations are not only by minorities of Bangladesh but also from the
majority Muslims. In absolute terms, the number of Muslims crossing into India is
likely to be much larger than that of non-Muslims. 20.3 An ideological support is
given to the phenomenon by the Islamic Fundamentalists creating the vision of a
larger country comprising Bangladesh and the entire North-East where its economic
problems will be solved and security ensured.
20.4 There is a direct correlation between the rise of fundamentalism and increase in
influx."Assam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

16. In IA No. 6 of 2004, the copy of the memorandum submitted before the Parliamentary Standing
Committee of Home Affairs on "the Illegal Migrants Laws (Replacing and Amending) Bill, 2003" on
behalf of the Government of Assam has been filed, which contains the figures regarding inquiries
conducted up to 31-8-2003 and the same is as under:
1. Total number of enquiries initiated 3,86,249
2. Total number of enquiries completed 3,79,521
3. Total number of enquiries referred to the Screening 3,62,592 Committee
4. Total number of enquiries made by the Screening 3,59,733 Committee
5. Total number of enquiries referred to IM(DT)s 76,228
6. Total number of enquiries disposed of by IM(DT)s 21,169
7. Total number of persons declared as illegal migrants 11,636
8. Total number of illegal migrants physically expelled 1517
9. Total number of illegal migrants to whom expulsion 6159 order served
10. Total number of enquiries pending with the Screening 2859 Committee
11. Total number of enquiries pending with the Tribunal 55,059"
38. The State of Assam has prepared a White Paper on the Foreigners Issue dated
20th October, 2012. We propose to extract large portions of this paper only to show
that even as on October 20, 2012, very little has been done to implement paragraphs
5(part), 6, 9 and 10 of the Assam Accord.
2.3.5. The 21 IMDTs functioning in Assam were wound up and replaced by 21 new
Foreigners Tribunals. The learned judges and staff of IMDT were redeployed in the
newly created additional Foreigners Tribunals. As a result, after 2005, 32(21 new + 11
existing) Foreigners Tribunals started functioning. The number of Foreigners
Tribunal has now been raised to 36 with the functioning of 4 new Foreigners
Tribunals. The performance of Foreigners Tribunal over different time period is
presented in the table below:
                         Foreigners Tribunals Cases
|Peri|Cases   |Cases     |Cases     |Persons|No. of        |
|od  |referred|disposed  |pending   |declare|declared      |Assam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

|    |        |          |(cumulativ|d as   |foreigners    |
|    |        |          |e)        |Foreign|pushed        |
|    |        |          |          |ers    |Back/deported |
|1985|32991   |15929     |17062     |14801  |133           |
|-90 |        |          |          |       |              |
|1991|482     |5909      |11635     |4005   |267           |
|-95 |        |          |          |       |              |
|1996|2986    |3552      |11069     |6026   |235           |
|-200|        |          |          |       |              |
|0   |        |          |          |       |              |
|2001|6094    |2216      |14947     |4593   |39            |
|-200|        |          |          |       |              |
|5   |        |          |          |       |              |
|2006|65666   |45456     |35157     |12913  |221           |
|-Jul|        |          |          |       |              |
|y   |        |          |          |       |              |
|2012|        |          |          |       |              |
|Tota|108219  |73062     |35157     |42338  |895           |
|l   |        |          |          |       |              |
Consolidated total of deported/pushed back illegal migrants on being declared as
foreigners by IMD(T)s and Foreigners Tribunals collectively till July 2012-
1547+895=2442.
2.5.4. In the absence of a proper laid down procedure for deportation of illegal
migrants between the Government of India and the Government of Bangladesh, it
has become difficult to carry out deportations. As such, deportation of foreigners is
mainly carried out through the 'push back' method. However, to overcome this
problem, the Ministry of Home Affairs has recently prescribed a detailed proforma
which has been circulated to all State Governments for collecting data of such
foreigners who are presently being detained in detention centres. The matter of
deportation of foreigners who have illegally entered into India needs to be taken up
by the Government of India with the Government of Bangladesh so that a proper
policy could be evolved and the process of deportation of such declared foreigners
become easier and hassle free.
3.1. CLAUSE 6 3.1.1. As per the Clause 6 of the Assam Accord, constitutional,
legislative and administrative safeguards as may be appropriate shall be provided to
protect, preserve and promote the cultural, social, linguistic identity and heritage of
the Assamese people. For this purpose the Government of Assam had earlier
constituted a Committee of Ministers for Clause 6 under notification No. IAA
51/2005/29 dated 19th October 2006 to examine all the issues relating to the
implementation of the Clause 6 of the Assam Accord including the definition of
'Assamese people'. This Committee had held a number of meetings and also met
Political Parties. It sought the views of different Political Parties, Sahitya Sabhas,
Youth Organisations, Student Bodies etc on the definition of 'Assamese People' andAssam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

deliberated on the same. After the present Government assumed office in May 2011, a
Cabinet Sub-Committee was constituted in July 2011 to inter alia deal with the matter
of implementation of Clause 6 of the Assam Accord. The entire matter is now under
examination of the Cabinet Sub- Committee.
3.1.2. A cultural centre called the Srimanta Sankardeva Kalashetra Complex has been
established in 1992 at a cost of Rs 18.85 crores in Guwahati. Out of this, an amount of
Rs 3.15 crores were spent during 1991-1995 and the remaining Rs 15.75 crores spent
during 1996-2000. The Jyoti Chitraban Film Studio (Phase I &II) at Guwahati has
been modernised at a cost of Rs 8.79 crores, of which Rs 4.79 crores were spent
during 1998-2000 and Rs 4.20 crores were spent during 2001-2003. The Phase III
(Part I) of the modernisation of the Jyoti Chitraban Film Studio for Rs 10 crores has
also been sanctioned by the Govt. of India in 2007. Against the release of Rs 10.00
crores by the Govt. of India, the State Govt. has already sanctioned Rs 6.66 crores to
the Jyoti Chitraban Film Studio Society (JCFSS), which is implementing the scheme.
A Technical Committee and a Monitoring & Supervision Committee have been
constituted to implement the project. An amount of around Rs 2.64 crores have been
spent so far and works are under progress.
3.1.3. In addition to the two Monuments at Poa-Mecca, Hajo and Urvarsi
Archaeological Site that were taken over by the Archaeological Survey of India in 1919
and 1918 respectively, the Archaeological Survey of India has taken up another three
Monuments for their preservation in 2005. These Monuments are the Hayagriva
Madhava Temple, Hajo, the Kedar Temple, Hajo and the Ganesh Temple, Hajo.
3.1.4. The Government of Assam has also taken up the development of Historical
Monuments and Archaeological Sites in Assam. During 2009-10, three Historical
Monuments and Archaeological Sites have been taken up for Rs 2.00 crores and
another 8 taken up for Rs 5.00 crores during 2010-11. An amount of Rs 5.00 crores
has been provided during 2012-13 for taking up the development of more Historical
Monuments and Archaeological Sites in Assam.
3.1.5. The Government of Assam has also taken up the protection, preservation and
development of Sattras in Assam. During 2009-10, three Sattras were taken up for Rs
3.00 crores and during 2011-12, Rs 10.00 crores was provided for the protection,
preservation and development of 87 Sattras in Assam. An amount of Rs 15.00 crores
has been provided during 2012-13 for the protection, preservation and development
of 85 Sattras in Assam.
3.1.6. The Executive Council of the Jawaharlal Nehru University has approved the
establishment of an Assamese Chair in the Centre of Indian Language, Literature and
Culture Studies of the University in 2007.Assam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

3.4. CLAUSES 9.1 & 9.2 3.4.1. BORDER FENCING & BORDER ROADS 3.4.1.1. The
Indo-Bangladesh border with Assam has a length of 267.30 km. Out of this 223.068
km is the land border and 44.232 km are river stretches and other non-feasible gaps
across the river border. Within 44.232 km, the Brahmaputra river has a stretch of
32.750 km in Dhubri District. Details of the river border areas is given in the
Annexure-12. Roads and Fences are erected only on land border and the length of
44.232 km is unfenced.
3.4.1.2. Roads and Fences have been taken up for construction on the land border in
three phases. In the Phase-I, construction of new roads and fencing was taken up in
1986 by Assam PWD and works completed in 2003. In the Phase-II, construction of
remaining new roads and fencing was taken up by Assam PWD in 2000-01.
Subsequently some parts of this Phase-II works were handed over to the National
Building Construction Corporation (NBCC) by the Assam PWD. While Assam PWD
has almost completed its works, that of NBCC are in progress. Under the Phase-III
reconstruction of the fences constructed in Phase-I was taken up from 2006-07
through NBCC and NPCC (National Projects Construction Corporation). While NBCC
has completed its Phase-III assigned works, works of NPCC are in progress.
3.4.1.3 A total of 228.118 km of new fencing was sanctioned under Phase- I&II, out of
which, based on field conditions, the actual required length was 224.694 km. Against
this 218.170 km of fencing (97.1%) has been completed. A stretch of 2.874 km could
not be taken up at Lathitila- Dumabari area Karimganj district due to an
international dispute. Works in respect of 150 meters of fencing are in progress with
Assam PWD. These inter alia relate to approaches of two bridges and are targeted for
completion within 31, December 2012. A length of 3.50 km in Karimganj Town could
not be taken up earlier as it was within 150 metres of the Bangladesh border. It has
now been decided to take up single fencing in this stretch in Karimganj Town, for
which actions have been initiated by the NBCC.
3.4.1.4. A total of 251.558 km of new roads were sanctioned under Phase- I&II, out of
which, based on field conditions, the actual required length was 246.073 km. Against
this 234.153 km of roads (95.16%) have been completed. Assam PWD is yet to
complete 60 metres of roads, which is targeted to be completed by 31st December
2012. NBCC is yet to complete 11.86 km of roads out of which 3.50 km relates to
Karimganj Town, where work is yet to be started, and 8.36 km relates to Masalabari
area in Dhubri district where work is in progress and scheduled to be completed this
year.
3.4.1.5. A total of 144.961 km of reconstruction Phase-I fencing was sanctioned under
Phase-III, out of which based on field conditions the actual required length was
134.727 km. Against this 121.707 km (90.34%) has been completed. NBCC has
completed all works assigned to it. Works are in progress in respect of 13.020 km of
fencing being constructed by NPCC, which are targeted to be completed by 31stAssam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

March 2013. The Government of India has sanctioned the Phase-III of the fencing
project, entailing the use of concertina with double coil wire fencing for replacing the
entire fencing constructed under Phase- I. Due to persistent efforts from Chief
Minister, Assam, phase II fencing was designed to be double row where concertina
with double coil wire has been used in contrast to Phase I fencing which was only
single row. A copy of the DO letter written by Chief Minister, Assam to Union Home
Minister in 2004 is placed as annexure 13.
3.4.1.6. The period-wise achievement in respect of Phase I & II works done by Assam
PWD since 1986 is given in annexure-14 and works done by all agencies is at
annexure- 15. A summary of the works done by all the agencies is given in the table
below:
                Progress under Phase-I and Phase-II (Fencing)
                                                                    (in Kms)
|Phase|Sanctioned/|Actual    |Completed |Disputed  |Balan|
|     |Actual     |required  |          |          |ce   |
|     |Length     |          |          |          |     |
|Phase|150.55     |147.17    |144.3     |2.87      |0    |
|-I   |           |          |          |          |     |
|Phase|77.57      |77.52     |73.87     |0         |3.65 |
|-II  |           |          |          |          |     |
|Phase|228.12     |224.69    |218.17    |2.87      |3.65 |
|-I & |           |          |          |          |     |
|II   |           |          |          |          |     |
|Phase|144.96     |134.73    |121.71    |0         |13.02|
|-III |           |          |          |          |     |
|Fenci|           |          |          |          |     |
|ng   |           |          |          |          |     |
3.4.1.7 While Assam has almost completed its fencing project under phase I and II
with around 97% of the work having been completed, the work in other states
bordering Bangladesh is lagging behind as indicated below:
|State |Total length of |Total length of |Percentage | | |border fencing |border fencing
|of | | |sanctioned under |completed under |completion | | |Phase-I and |Phase-I and
| | | |Phase-II |Phase-II | | |West |1528 km |1222 km |80% | |Bengal| | | |
|Meghal|470.23 km |380.06 km |81% | |aya | | | | |Tripur|856 km |730.50 km |85% |
|a | | | | |Mizora|352.32 km |206.80 km |59% | |m | | | | |Assam |224.69 km |218.17
km |97% | 3.4.1.8. The total unfenced portion of the Assam-Bangladesh border at
present is given in the table below:Assam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

                                    (In Km)
|1.|River stretches and other non-feasible    |44.23|     |
|  |gaps across the river border              |     |     |
|  |Unfenced River Border                     |     |44.23|
|2.|Phase-II fencing yet to be completed by   |3.65 |     |
|  |APWD & NBCC                               |     |     |
|3.|Disputed land in Lathila-Dumabari         |2.87 |     |
|4.|Earlier completed fence in Phase-I, now   |13.02|     |
|  |under reconstruction by NPCC and yet to be|     |     |
|  |completed                                 |     |     |
|5.|Unfenced Land Border:                     |     |19.55|
|  |Total unfenced length along               |     |63.79|
|  |Assam-Bangladesh Border:                  |     |     |
3.4.2. BORDER PATROLLING AND GUARDING
3.4.2.1. In order to strengthen border domination and to prevent any transborder
crimes including infiltration and exfiltration, after 2001 in the Assam portion of the
Indo-Bangladesh border 11 new BOPs have been established. More BSF troops have
been deployed and water wing personnel have been made active on duty round the
clock in the riverine border areas. At present the BSF and the state police are doing
joint patrolling of the borders. A total of 6 battalions of BSF are deployed for
guarding of the Indo-Bangladesh border (Assam portion). There are 91 BOPs at
present and the distance between two BOPs has been reduced) Night vision devices,
thermal indicators and radar for better surveillance are being used by the BSF at the
border. The state police are also having BOPs for providing a second line of defence.
To strengthen the Government machinery for the purpose of detection and
deportation of foreigners, the Government of India has sanctioned 1,280 additional
posts in different ranks under the PIF Scheme. Including these 1,280 posts, the total
sanctioned strength of the Assam Police Border Organisation is 4,002 police
personnel in different ranks.
3.4.3. COMMITTEE FOR PREVENTING INFILTRATION THROUGH THE
UNPROTECTED RIVERINE AREAS 3.4.3.1 The actions taken for completing the
fencing of the land border have been detailed above. Initiative has also been taken to
ensure that infiltration is prevented from the river stretches and other non-feasible
gaps across the river border. With this end in view the Governor of Assam constituted
a Committee vide the notification No. 1AA 56/2011/1 dated 12th September 2011 to
examine and recommend ways and means for preventing infiltration through the
unprotected riverine areas in the Assam-Bangladesh border. The Committee visited
the riverine border areas of Dhubri district in October 2011 and the riverine border
areas of Karimganj and Cachar districts in November 2011. During these visits
extensive discussions were held with BSF and other local authorities. VariousAssam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

technical options of preventing infiltration through such riverine areas are presently
being considered.
3.4.4. FLOOD LIGHTING 3.4.4.1. To enable proper vigilance of the international
border during the night, action has been taken to provide floodlighting all along the
Assam- Bangladesh border. Floodlighting works are being implemented by the
CPWD in the Assam. These works are divided between the Guwahati sector and the
Silchar sector and the total length comes to 213.74 kms. The Guwahati sector
comprises a stretch of 37.60 km in Dhubri sub-sector and 43.44 km in Mancachar
sub-sector. Work has started in both these sub-sectors and is scheduled to be
completed within 2012-13. The Silchar sector comprises three sub-sectors. The works
in respect of the first, from BP. No. 1338 to 1356 & 680635 for 40.50 km have started
and are scheduled to be completed within 2012-13. Works in respect of the remaining
two sub-sectors having stretches of 46.70 km and 45.50 km are yet to be started and
are scheduled to be completed within 2013-14.
3.5. CLAUSE 10 3.5.1. Land administration in the Protected Belts and Blocks in
Assam is carried out as per provisions of Chapter X of the Assam land and Revenue
Regulation 1886 and Rules framed there under. Steps are taken for removal of
encroachment on a continuous basis.
4.2 PROGRESS IN DETECTION AND DISPOSAL OF CASES 4.2.1. There has been a
substantial increase in the number of cases detected during the last 11 years. The
disposal of cases also has shown a significant increase during this time period. The
following table provides a comparative picture of the cases registered and disposed of
by Foreigners Tribunal & IMDT:
                        FOREIGNERS' TRIBUNAL AND IMDT
|Period      |Cases referred          |Cases disposed of |
|1985-2000   |80252                   |43631             |
|2001 July   |140758                  |53452             |
|2012        |                        |                  |
4.2.2. It may be seen that the progress in 10 years time period from 2001- 2012 far
exceeds the progress made during the 15 years time period from 1985 to 2000.
Keeping in view that the disposal mechanism is a judicial process and also subject to
judicial review, the disposal of cases has not been able to keep pace with the number
of cases registered in the Foreigners Tribunals. Therefore, there has been a large
cumulative pendency of cases in the Tribunals which needs to be addressed through
special measures.Assam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

4.3. STRENGTHENING OF MACHINERY FOR DETECTION AND DEPORTATION
4.3.1. In order to prevent infiltration into the State through Riverine Routes 4(four)
River Police Stations and 7(seven) River Police Out Posts have been set up under
River Police Organization. In addition, a new I.R. Battalion for River Police has also
been raised and steps are being taken to provide necessary equipments and training
to this riverine battalion. The Assam Police Border Organization has set up 159
Watch Posts in the infiltration prone areas of 17 districts of Assam for detection of
illegal infiltrators.
4.3.2. The ex-servicemen employed under PIF scheme have been given the status of
regular government servants so that they do not suffer from uncertainties of
employment. Government has paid more than Rs 22 crores as arrears to these
ex-servicemen deployed since 1988 during 2011-2012.
4.3.3. The number of Foreigner's Tribunals which was hovering between 4 and 11
from 1964 to 2005 increased to 36 Tribunals in 2009. All of them have been made
functional. Standard staffing pattern and service order governing service conditions
of FT staff have been notified. Proposal for providing additional staff depending on
workload is submitted to MHA for approval. Power of appointment of vacant staff
position has been delegated to Member FT based on a transparent selection process
by a board headed by Deputy Commissioner.
4.3.4. New terms and conditions have been issued for appointment of Members so as
to make the service conditions attractive. The upper age limit has been relaxed from
65 to 67 years, remuneration has been made more attractive besides providing other
amenities like vehicle, orderly peons etc. This has led to significant reduction in
vacancy position of Judicial members of Foreigners Tribunals - 33 members are in
place and other 4 applications are in process to achieve 100 % occupancy. It is noted
that till February 2011 there were as many as 13 vacancies of Members, Foreigners
Tribunal. The Government of Assam has also received 7 nominations from the
registrars of the High Courts of other states and 3 members have been appointed so
far from outside the state. There is a paucity of suitable judicial officers in the State
and all efforts have been made to fill up all the posts of members. This is the biggest
impediment to our efforts in increasing the number of tribunals.
4.3.5. Office infrastructure of Foreigners Tribunals has been improved by providing
computers, printers: telephone, fax, photocopiers etc. The Government of Assam is
making every effort to overcome the constraints of inadequate infrastructure
including office space for all the Foreigners Tribunals.
ANNEXURE - 5 (Copy) Copy of Letter NO.PLB.171164/34 dated Shillong, 25th June,
1966 from Shri S.P. Hazarika, A.C.S., Deputy Secretary to the Government of Assam,
Political Department, to the Inspector General of Police, Assam, Shillong.Assam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

Subject: Procedure for deportation of Pak infiltrants I am directed to say that a review of the latest
position of deportation of Pak infiltrants shows that the total number of Pakistani infiltrants in our
State as determined by the Registrar General of Census In 1961 was 2,20,691. It appears that since
1961 till 31-5-66, 2,15,794 infiltrants have been detected and notices for deportation were served or
prosecution was started against 2,15,355. Out of these, according to the figures confirmed by the
Check Posts, 1,43,438 have already left the country. About 28,999 of the remaining number on
whom notices have been served have preferred appeal. It may also be assumed that about 25,000
persons on whom deportation notices were served have left by routes other than by the check posts.
The number of infiltrants who have been detected but have not left the country would come to about
40,000 plus the number resulting from natural increase, new infiltration and re-entry of deported
the total number of Pakistani infiltrants on the basis of 1961 census who are yet to be detected comes
to about 5,000 or so. To this we have to add the number resulting from the natural increase during
this period, fresh infiltration and re-entry of some deported persons. But the total number of such
people should not be many. Therefore, the number of cases to be detected is gradually decreasing.
Now, more and more marginal cases would be detected. Therefore, time has come when we have to
be more careful in deportation.
In the light of the above background, Govt. think that from now onward, each and every case of
deportation should receive the cases where there is slightest doubt, no deportation notice should be
reserved, but prosecution should be started in Court of law and deportation notices should be served
on the basis of the judgment in the court of law. The following categories of cases, however, would
be warrant service of deportation notices without reference to Court:-
(1) A person with Pak passport overstaying illegally in India;
(2) A person already deported but has re-entered India illegally; and (3) A new
infiltrant entering India.
In these categories of cases, after service of deportation notice, the present procedure of Tribunal
will follow.
You are, therefore, requested to issue necessary instructions of the points mentioned above to all
concerned under intimation to Government. These instructions are intended to make our officers
cautions the matter of detection and deportation and should not be interpreted to mean any
relaxation in the matter of vigilance, detection and deportation of Pakistani infiltrants.
SECRET MemoNo.PA(VII)/62/200 Dated, Shillong the 29th June, 1966.
Copy to Shri H.K. Bhattacharyya, IPS (AIl D.ls. G/Ss. P) for information and necessary action.
Sd/-
B.K. Barua, Inspector General of Police, Assam.Assam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

39. It will be seen that the number of tribunals set up is abysmally low resulting in an abysmally low
number of decisions by these tribunals. What is interesting to know is that whereas almost 1,50,000
persons were deported between 1961 to 1965 under The Immigrants (Expulsion of Assam) Act, 1950,
the number of deportations from 1985 till date is stated to be a mere 2,000 odd. Even these
deportees are mostly if not all "push backs"
which results in the same deportees coming back post deportation from a border
which is completely porous.
40. It will be seen that the Assam portion of the border with Bangladesh is 267 Kms. Out of which
44 Kms. are riverine. We are given to understand that the entire border between India and
Bangladesh is roughly 4000 Kms. The White Paper shows that large portions of the border with
Assam are yet to be fenced with double coil wire fencing, making the border an easy place to cross.
Also, we are given to understand that most parts of the border with West Bengal and other
North-Eastern States are also porous and very easy to cross.
41. We are at loss to understand why 67 years after independence the Eastern border is left porous.
We have been reliably informed that the entire Western border with Pakistan being 3300 Kms. long,
is not only properly fenced but properly manned as well and is not porous at any point.
42. In the light of the above, we have considered the necessity of issuing appropriate directions to
the Union of India and the State of Assam to ensure that effective steps are taken to prevent illegal
access to the country from Bangladesh; to detect foreigners belonging to the stream of 1.1.1966 to
24.3.1971 so as to give effect to the provisions of Section 6(3) & (4) of the Citizenship Act and to
detect and deport all illegal migrants who have come to the State of Assam after 25.3.1971. Before
issuing any such directions, we had thought it proper to require the Union as well as the State of
Assam to state, on affidavits, their respective stands in the matter and also their suggestions, if any.
Both the Union as well as the State of Assam have responded by filing affidavits sworn by duly
authorized officials. We have taken note of the contents of the said affidavits which disclose that
both the Union and the State are broadly in agreement in respect of the steps that are required to be
taken as well as the action taken till date and further the measures that are required to be taken in
the future. It will be appropriate if the relevant contents of the affidavit filed by the Union are
extracted below.
"5(VIII). Effective Border guarding to check and control illegal immigration
(i) Intensive 24x7 patrolling by the Border Security Force (BSF) along the
Indo-Bangladesh border.
(ii) Identification of vulnerable patches/routes by 15th January 2015 from where
Bangladeshi nationals are managing to enter into the country illegally. After
identification of these vulnerable patches/routes, security and vigilance will be
strengthened at these points along the identified routes used for illegal infiltration.Assam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

(iii) Persons who are intercepted at the international border will be sent back then
and there to Bangladesh.
(iv) Illegal infiltrators will be interrogated by the State Police in the presence of BSF
personnel who have managed to enter into the territory of the country for
identification of routes they had taken for entering into the country. Security will be
further strengthened on such routes/areas. BSF personnel, if any, found to be
involved in helping illegal infiltrators for crossing international border will be
punished as per law-. BSF will keep close vigil on the international border through its
intelligence branch with immediate effect.
(v) Besides, intelligence agencies will be geared up with immediate effect for keeping
close vigil along the international border and also reporting to the concerned
authorities including BSF on illegal infiltrations.
(vi) Border fencing: A project worth Rs.6337 crore has been sanctioned for fencing
3326 km of Indo-Bangladesh border including restoration of damaged fence (total
length 4096.7 km of the border of which 2980.7 km. is land border and 1116 km. is
riverine border [the length of riverine border keeps varying from season to season]).
Out of 3326 Km, fencing has been completed in 2828 km. Construction work of
fencing is in progress in 78.80 km. which is likely to be completed by May 2016. In
102.4 km fencing is not feasible due to low-lying/difficult hilly terrain. Work in 24.2
km is at estimate/revised estimate stage. Due to boundary issues which are yet to be
resolved between India and Bangladesh in 19 km, construction of fencing could not
be completed. Action has been initiated to resolve the boundary issues with
Bangladesh. Fencing work cannot be started in 188 km due to delay in land
acquisition by the concerned State Governments of Tripura (11 Km.), West Bengal
(86 Km.) and Assam (3.5 Km.). In case of Meghalaya State earlier the issue of
pending land acquisition was for about 135 km.
However, due to constant persuasion by the Ministry of Home Affair at the highest level, the matter
was partially resolved and fencing is completed in such stretches except for 23.63 km. in which work
in progress. Presently, the land acquisition is pending for about 87.5 km. in Meghalaya. The Matter
has been taken up with the State Governments of Meghalaya, Tripura, West Bengal and Assam for
early acquisition of land for construction of fencing at various levels. Matter is being followed up
with them regularly. Besides, environmental/ forest clearance is also required for erection of fencing
in 61.6 km. areas falling in Dampa Tiger Reserve, Mizoram. The matter was discussed in the
National Board of Wildlife (NBWL) meeting held on 12th August, 2014. The NBWL had
recommended the project with certain conditions. Action has been initiated for compliance of the
conditions imposed by the NBWL. Public protest is continuing in 24 km by the people of Meghalaya
opposing the construction of fencing along India- Bangladesh border. The State of Meghalaya has
been requested to resolve the issue expeditiously. It may be mentioned that where construction of
fencing work is in progress or fencing is to be constructed in future, in such areas the presence of
BSF will be increased to ensure that illegal Bangladeshi nationals may not sneak into the IndianAssam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

territory clandestinely.
(vii) Construction of roads: To facilitate proper patrolling by the BSF along Indo-Bangladesh border,
a project for construction of road has been undertaken. Construction of 4379 km length of road
along Indo-Bangladesh border has been sanctioned. Out of which 3769.9 km construction work has
been completed and work is in progress in 160.23 km which is likely to be completed by May 2016.
In 222.07 km construction work is not feasible due to hilly terrain/low-lying areas. Work in 52.153
km is at estimate/revised estimate stage. In 174.65 km work cannot be started due to various
reasons mainly delay in land acquisition by the State Governments concerned. Matter has been
taken up with the State Governments of Meghalaya, Tripura, West Bengal and Assam for early
acquisition of land for construction of roads. Matter is being followed up with them regularly.
(viii) Installation of Flood lights along Indo-Bangladesh border: Further, a project worth Rs. 1327
crore for installation of flood lights along the border to keep close vigil at night has been started in
2840 km along Indo- Bangladesh border areas. Work has been completed in 1874 kms. Work is in
progress in 330 km. which is likely to be completed by May 2016. Installation of flood lights is not
feasible in 219.4 km due to low-lying area/difficult hilly terrain. It may be mentioned that the flood
lights can be installed only after construction of fence and roads along the border. Therefore, the
work of floodlights in about 416.6 km. could not be started due to pending fence work. As stated
above, the matter has been taken up with the State Governments of Meghalaya, Tripura, West
Bengal and Assam for early acquisition of land. Matter is being followed up with them regularly.
(ix) Initially, 802 Border Out Posts (BOPs) were set up along Indo- Bangladesh border for effective
guarding of the border. In order to reduce the gap between the two BOPs, 383 additional BOPs have
been sanctioned. Out of these, 65 BOPs have been established. Work is going on in 78 BOPs which is
targeted to be completed by December, 2016. For the remaining BOPs, work can be started only
after the acquisition of land by the State Governments concerned. Matter has been taken up with the
State Governments of Meghalaya, Tripura, West Bengal and Assam for early acquisition of land for
construction of BOPs. Matter is being followed up with them regularly.
(x) BSF has deployed 28 numbers of speed boats (single engine), 40 numbers of rigid inflatable
speed boats, 48 numbers of aluminium country boats, 2 double engine speed boats, 58 engine fitted
country boats along Indo-Bangladesh border (Assam sector) for guarding of riverine areas. In order
to make effective guarding of riverine international border additional 10 double engine speed boats
and five 20 meters medium vessels will be procured within six to 12 months. Effective guarding of
riverine areas in other sectors are also being done by the BSF.
(xi) It may be mentioned that the timelines indicated above, for the border infrastructure works, are
tentative in nature and the targets are subject to the condition that the "in-progress" works are not
stalled due to the unforeseen situations like floods, land-slides, public protests, litigations, etc.
Further, it is stated that the sanctioned and completed status of the border infrastructure mentioned
in paras (vi) to (ix) are dynamic in nature due to the difficult terrain along the border areas coupled
with floods, land-slide, breach in fence, etc.Assam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

(xii) Regular village co-ordination meetings are being organised by the field commanders of BSF to
sensitise the border population. Further, effective action will be taken for sensitising the villagers
living along the border areas, particularly in case any new person is seen in the village, they should
report the matter to the local police chowki. Besides, village defence parties shall also be activated
within one month along the international border to keep close vigil in this regard who will report to
the local Police Stations.
(xiii) 3153 Security personnel provided to the State of Assam under Prevention of Infiltration of
Foreigners (PIF) scheme to act as second line of defence and assist the BSF to check the illegal
infiltration from Bangladesh. The State of Assam will be advised to use and deploy the PIF
personnel to act effectively with immediate effect.
(xiv) 4 additional battalions of BSF will be raised in the next financial year 2015-16 for deployment
along the international Indo Bangladesh border. Out of 4 BSF battalions, one each will be deployed
along Indo-Bangladesh border (Assam sector and West Bengal sector), remaining two will be as
training battalions."
43. In addition to what has been extracted above, the Union, in the affidavit filed, has also stated
that for the purpose of detection of illegal migrants 500 police units/task force will be activated in
the State within one month.
44. The affidavit of the Union also indicates that in addition to the 36 Foreigners Tribunals which
are claimed to be functioning in the State of Assam, 64 additional Tribunals have been sanctioned in
June, 2013. The affidavit of the State of Assam indicates that steps are underway for making the
aforesaid Tribunals functional.
45. Insofar as the mechanism of deportation of illegal migrants after they are detected to be illegal
migrants is concerned, paragraph 25 of the affidavit of the Union which deals with the said aspect of
the matter may also be noticed:
"25. It is submitted that the existing mechanism/procedure for verification of
nationality inter alia include that State Government provides details of declared
person in a prescribed format indicating full details/contact address in Bangladesh
including photographs to the Ministry of Home Affairs. Such cases received from the
State Government are referred to the Ministry of External Affairs for taking up the
matter of verification of nationality with Bangladesh authorities through diplomatic
channel. The Ministry of External Affairs refers such cases to Bangladesh authorities.
Such cases are investigated by the Bangladesh Home Ministry and they send their
report to Bangladesh Foreign Ministry. In turn they intimate Indian Ministry of
External Affairs about the nationality verification or status of such persons. If some
of the cases are not confirmed by them, in that event we request the Bangladesh
authorities from the Bangladesh High Commission or Deputy High Commissions in
Kolkata or Mumbai, as the case may be, to avail of consular access for interaction
with such detained persons. The Bangladesh authorities depute their representativeAssam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

for interaction with such persons who are detained in detention centres/jails. If such
persons disclose their addresses in the Bangladesh then their nationality is
confirmed. Some of them still claim that they are Indian nationals and in that event
Bangladesh authorities are unable to confirm/nationality of such persons. Persons
whose nationalities are confirmed by the Bangladesh authorities, are repatriated to
Bangladesh immediately. It is mentioned that many of the declared illegal migrants
do not disclose their address, contacts of their relatives in Bangladesh. In such cases,
it becomes very difficult for Bangladesh authorities for verification of nationality of
these persons. In the current years nationality of 32 Bangladeshi nationals who were
in the detention centres/jails in Assam were confirmed by the Bangladesh authorities
and they have been repatriated."
46. On an overall consideration of the immediate dimensions of the issues and the potential that the
same have for the future we issue the following directions under Article 142 of the Constitution of
India.
I. Border fencing, Border Roads and provision for flood lights The Union will take all effective steps
to complete the fencing (double coiled wire fencing) in such parts/portions of the Indo-Bangla
border (including the State of Assam) where presently the fencing is yet to be completed. The vigil
along the riverine boundary will be effectively maintained by continuous patrolling. Such part of the
international border which has been perceived to be inhospitable on account of the difficult terrain
will be patrolled and monitored at vulnerable points that could provide means of illegal entry.
Motorable roads alongside the international border, wherever incomplete or have not yet been built,
will be laid so as to enable effective and intensive patrolling. Flood lights, wherever required, will
also be provided while maintaining the present arrangements. The completed part of the border
fencing will be maintained and repaired so as to constitute an effective barrier to cross border
trafficking.
The progress achieved at the end of 3 months from today as against the position on the ground
mentioned in the affidavit of the Union extracted above will be monitored by this Court and,
depending on what is revealed upon such monitoring, further directions including a definite time
schedule for completion of the works relating to border fencing, border roads and flood lights may
be made by this Court.
II. Foreigners Tribunals The Gauhati High Court is requested to expedite and to finalise the process
of selection of the Chairperson and Members of the Foreigners Tribunals, if required in phases,
depending on the availability of officers opting to serve in the Tribunals. Within 60(sixty) days of the
selection being finalized by the Gauhati High Court, the State of Assam will ensure that the
concerned Foreigners Tribunal become operational.
The Chief Justice of the Gauhati High Court is requested to monitor the functioning of the Tribunals
by constituting a Special Bench which will sit at least once every month to oversee the functioning of
the Tribunals.Assam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

III. Existing Mechanism of Deportation of Declared Illegal Migrants While taking note of the
existing mechanism/procedure for deportation keeping in view the requirements of international
protocol, we direct the Union of India to enter into necessary discussions with the Government of
Bangladesh to streamline the procedure of deportation. The result of the said exercise be laid before
the Court on the next date fixed.
47. The implementation of the aforesaid directions will be monitored by this Court on the expiry of
three months from today. In the event it becomes so necessary, the Court will entrust such
monitoring to be undertaken by an empowered committee which will be constituted by this Court, if
and when required.
48. Insofar as Writ Petition (C) No. 274/2009 is concerned, we are of the view that on and from the
date of this judgment the following time schedule should govern the work of updating of the NRC in
Assam so that the entire updated NRC is published by the end of January, 2016.
1. Preparatory work such as selection of vendor system (system integrator); development by system
integrator; appointment of staff and training etc. has already been directed to be completed by the
end of January 2015 by order dated 27.11.2014 of the Court.
2. The remaining work of updating the NRC will now conform to the following time schedule which
will be strictly adhered to.
|Sl. |Task                |Period in |Start         |End             |
|No. |                    |Months    |              |                |
|1.  |Publication of      |          |              |                |
|    |Records-Search/looki|1         |February, 2015|February, 2015  |
|    |ng up of linkage by |          |              |                |
|    |public              |          |              |                |
|2.  |Receipt of          |3         |March, 2015   |May, 2015       |
|    |applications        |          |              |                |
|3.  |Verification        |4         |June, 2015    |September, 2015 |
|4.  |Draft Publication   |          |1st October,  |                |
|    |                    |          |2015          |                |
|5.  |Receipt of Claims & |1         |October, 2015 |October, 2015   |
|    |Objections          |          |              |                |
|6.  |Disposal of Claims &|2         |November, 2015|December, 2015  |
|    |Objections          |          |              |                |
|7.  |Finalization of     |          |1st January,  |                |
|    |final updated NRC   |          |2016          |                |
|    |Total Time Period in|11        |              |                |
|    |Months              |          |              |                |
49. All the cases be listed in the last week of March, 2015 to take note of the progress of
implementation of the above directions.Assam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

....................................J. (Ranjan Gogoi) ....................................J. (R.F. Nariman) New Delhi;
December 17, 2014.Assam Sanmilita Mahasangha & Ors vs Union Of India & Ors on 17 December, 2014

