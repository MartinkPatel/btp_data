Chief Information Commissioner vs High Court Of Gujarat on 4
March, 2020
Equivalent citations: AIR 2020 SUPREME COURT 4333, AIRONLINE 2020 SC
336
Author: R. Banumathi
Bench: Hrishikesh Roy, A.S. Bopanna, R. Banumathi
                                                                      REPORTABLE
                                        IN THE SUPREME COURT OF INDIA
                                         CIVIL APPELLATE JURISDICTION
                                     CIVIL APPEAL NO(S).1966-1967 OF 2020
                                      (Arising out of SLP(C) No.5840 of 2015)
                         CHIEF INFORMATION COMMISSIONER                            …..Appellant
                                                         VERSUS
                         HIGH COURT OF GUJARAT AND
                         ANOTHER                                               …..Respondents
                                                    JUDGMENT
R. BANUMATHI, J.
Leave granted.
2. The point falling for determination in this appeal is as regards the right of a third party to apply
for certified copies to be obtained from the High Court by invoking the provisions of Right to
Information Act without resorting to Gujarat High Court Rules prescribed by the High Court.
3. Brief facts which led to filing of this appeal are as follows:-
An RTI application dated 05.04.2010 was filed by respondent No.2 seeking
information pertaining to the following cases – Civil Application No.5517 of 2003 and
Civil Application No.8072 of 1989 along with all relevant documents and certified
copies. In reply, by letter dated 29.04.2010, Public Information Officer, Gujarat High
Court informed respondent No.2 that for obtaining required copies, he should make
an application personally or through his advocate on affixing court fees stamp of
Rs.3/- with requisite fee to the “Deputy Registrar”. It was further stated that as
respondent No.2 is not a party to the said proceedings, as per Rule 151 of the GujaratChief Information Commissioner vs High Court Of Gujarat on 4 March, 2020

High Court Rules, 1993, his application should be accompanied by an affidavit stating
the grounds for which the certified copies are required and on making such
application, he will be supplied the certified copies of the documents as per Rules 149
to 154 of the Gujarat High Court Rules, 1993.
4. Being aggrieved, respondent No.2 preferred Appeal No.84 of 2010 before the Appellate
Authority-Registrar Administration under Section 19 of the Right to Information Act, 2005 (for
short “RTI Act”). The appeal was dismissed vide order dated 04.08.2010 on the ground that for
obtaining certified copies, the alternative efficacious remedy is already available under the Gujarat
High Court Rules, 1993 and that under the provisions of RTI Act, no certified copies can be
provided.
5. Respondent No.2 then filed Second Appeal No.1437 of 2010- 11 before the Appellant-Chief
Information Commissioner and notice was sent to respondent No.1. Respondent No.1-High Court
filed its response reiterating the position that there are provisions under Rules 149 to 154 of the
Gujarat High Court Rules for anybody who wants to obtain the certified copies as per which,
application/affidavit should be filed stating the grounds for which the documents are required and
with requisite court fee stamps. Respondent No.1 stated that despite the letter dated 02.07.2010 by
the Deputy Registrar (CC Section), Decree Department, Gujarat High Court to respondent No.2
informing him of the procedure for getting certified copies, respondent No.2 has not made
application as per the rules of the High Court and that the Public Information Officer cannot be
compelled to breach the High Court Rules and hence, the appeal filed before the Chief Information
Commissioner (CIC) is liable to be dismissed. Relying upon Sections 6(2) and 22 of the RTI Act, the
appellant-Chief Information Commissioner vide its order dated 04.04.2013 directed Public
Information Officer of the Gujarat High Court to provide the information sought by respondent
No.2 within twenty days.
6. Challenging the order of Chief Information Commissioner, respondent No.1 filed Special Civil
Application No.7880 of 2013 before the High Court. The learned Single Judge, while admitting the
petition, passed an interim order dated 11.10.2013 directing respondent No.1 to provide the
information sought by respondent No.2 within four weeks. The learned Single Judge held that the
legality and validity of the direction given by the appellant and the right of respondent No.2 to
receive the copies under RTI Act will be considered at the stage of final hearing. It was however
clarified that supply of information by respondent No.1 shall not be construed as acceptance of
applicability of RTI Act to the High Court.
7. Being aggrieved by the interim order, respondent No.1-High Court preferred Letters Patent
Appeal No.1348 of 2013 before the Division Bench contending that the party who seeks certified
copies has to make an application along with the copying charges and requisite court fees stamp as
per Rules 149 to 154 of the Gujarat High Court Rules. As per the Rules, if the certified copy is sought
by a person who is not a party to the litigation, his application has to be accompanied by an affidavit
stating therein the purpose for which he requires the certified copies. Vide impugned order, the
High Court allowed the Letters Patent Appeal holding that when a particular field is governed by the
rules which are not declared ultra-vires, then there is no question of applying the fresh rules andChief Information Commissioner vs High Court Of Gujarat on 4 March, 2020

make the situation confusing. The High Court held that in the light of the High Court Rules, certified
copies may be given on payment of charges as per the Rules and also the applicant (respondent
No.2) has to file an affidavit disclosing the purpose for which the certified copies are required and
there is no question of making an application under the RTI Act. The Division Bench set aside the
order of the Chief Information Commissioner by observing that when a copy is demanded by any
person, the same has to be in accordance with the Rules of the High Court on the subject.
8. As the question involved is concerned with all the High Courts and having regard to the
importance of the matter, we have requested Mr. Atmaram N.S. Nadkarni, learned Additional
Solicitor General (ASG) to appear as amicus curiae to assist the Court which the learned ASG readily
agreed. Mr. Nadkarni collected information from all the High Courts and filed a compilation of the
information obtained by him about the Rules framed by various High Courts in exercise of their
power under Article 225 of the Constitution of India and under Section 28 of the Right to
Information Act, 2005.
9. Mr. Preetesh Kapoor, learned Senior counsel for the appellant has contended that Section 6(2) of
the RTI Act specifically provides that an applicant making a request for information shall not be
required to give reasons for requesting the information sought and whereas under the Gujarat High
Court Rules, applications made by third parties seeking copies of the documents shall be
accompanied by an affidavit stating the grounds on which they are required and there is direct
inconsistency between the provisions of the RTI Act and the Gujarat High Court Rules, 1993. It was
submitted that in view of the inconsistency between the provisions of the RTI Act and the Gujarat
High Court Rules, harmonious construction between the two is not possible and in the event of
conflict between the provisions of RTI Act and any other law made by the Parliament or State
Legislature or any other authority, the former must prevail. It was submitted that Section 22 of the
RTI Act specifically provides that the provisions of the RTI Act will have an overriding effect over
any other laws for the time being in force. The learned Senior counsel submitted that the High Court
Rules have been framed in exercise of the powers under Article 225 of the Constitution of India
which would be subject to any other law and the non-obstante clause in Section 22 of the RTI Act
shows that the provisions of the RTI Act would override the High Court Rules. The learned Senior
counsel inter alia relied upon the recent judgment of the Constitution Bench in Central Public
Information Officer, Supreme Court of India v. Subhash Chandra Agrawal 2019 (16) SCALE 40.
10. Mr. Prashant Bhushan, learned counsel appearing for the intervenors submitted that there can
be no apprehension that allowing an applicant to seek information from the High Court under RTI
Act can prejudicially affect the privacy/rights of other parties or the administration of justice.
Reiterating the submission of Senior counsel, Mr. Preetesh Kapoor, Mr. Prashant Bhushan
submitted that Rule 151 of the Gujarat High Court Rules is not in consonance with Section 6(2) of
the RTI Act and the provisions of RTI Act prevails over the relevant Rules of Public
Authorities/Gujarat High Court Rules. Taking us through Section 22 of the RTI Act, learned counsel
submitted that RTI Act is a general law made by the Parliament with the avowed object of
dissemination of information and ensuring transparency in the functioning of the Public Authorities
and in view of non obstante clause of Section 22 of the RTI Act, in case of any conflict regarding
“access to information from public authorities”, the provisions of RTI Act will prevail over any otherChief Information Commissioner vs High Court Of Gujarat on 4 March, 2020

law. In support of his contention, the learned counsel placed reliance upon Institute of Companies
Secretaries of India v. Paras Jain 2019 SCC Online SC 764 and the Constitution Bench judgment in
Subhash Chandra Agrawal.
11. Mr. Aniruddha P. Mayee, learned counsel appearing for respondent No.1-High Court of Gujarat
submitted that the Gujarat High Court Rules 149 to 154 do not stipulate anything contra to Section
22 of the RTI Act and the Gujarat High Court Rule 151 is in consonance with the RTI Act. The
learned counsel submitted that respondent No.2 was only informed to make an application as per
the procedure stipulated under the Gujarat High Court Rules, 1993 and since respondent No.2 was
not a party to the proceedings, he was informed that his application shall be accompanied with an
affidavit stating the grounds for which the certified copies are required. The learned counsel
submitted that when an efficacious remedy is available under Rule 151 of the Gujarat High Court
Rules which is in consonance with the provisions of RTI Act, the provisions of the RTI Act cannot be
invoked and the High Court rightly held that there is no question of making an application under the
RTI Act and rightly quashed the order of the appellant-Chief Information Commissioner.
12. Mr. Nadkarni, learned amicus has taken us through the information received from the various
High Courts and submitted that in exercise of power under Article 225 of the Constitution of India,
the High Court Rules are framed and the Rules provide for a mode for furnishing of information by
way of certified copies to persons who are party to the litigation after making payment of requisite
fees. It was submitted that insofar as third parties i.e. persons who are not party to the litigation are
concerned, the same is also provided under the Rules, if the third party files an affidavit stating the
reasonable grounds to receive such information/certified copies. The learned amicus submitted that
there is no inconsistency between the RTI Act and the Rules framed by the High Court so as to
furnish information. It was also submitted that although Section 22 of the RTI Act has an overriding
effect over any other laws, in case there are inconsistencies, Section 22 of the RTI Act does not
contemplate to override those legislations which also aim to ensure access to information. The
learned amicus submitted that so far as the information on the judicial side of the High Court, the
Rules framed by the High Court provide for dissemination of information to third party as per the
High Court Rules by filing an application with requisite fee and filing an affidavit stating the
grounds. Insofar as the information on the administrative side of the High Court, the learned amicus
submitted that access to such information could be had through the Rules framed by the various
High Courts and the Rules framed under the RTI Act by the High Courts. Drawing our attention to
the judgment of the Delhi High Court in The Registrar, Supreme Court of India v. RS Misra (2017)
244 DLT 179 and judgment of the Karnataka High Court in Karnataka Information Commissioner v.
State Public Information Officer and another WP(C) No.9418 of 2008, the learned amicus
submitted that the High Courts have taken a consistent view that the information can be accessed
through the mechanism provided under the Supreme Court Rules, 2013 and the High Court Rules
and once any information can be accessed through the mechanism provided under the Statute or the
Rules framed, the provisions of the RTI Act cannot be resorted to.
13. We have carefully considered the contentions and perused the impugned judgment and
materials on record. The following points arise for consideration in this appeal:-Chief Information Commissioner vs High Court Of Gujarat on 4 March, 2020

(i) Whether Rule 151 of the Gujarat High Court Rules, 1993 stipulating that for
providing copy of documents to the third parties, they are required to file an affidavit
stating the reasons for seeking certified copies, suffers from any inconsistency with
the provisions of RTI Act?
(ii) When there are two machineries to provide information/certified copies – one
under the High Court Rules and another under the RTI Act, in the absence of any
inconsistency in the High Court Rules, whether the provisions of RTI Act can be
resorted to for obtaining certified copy/information?
14. Section 2(f) of the Right to Information Act, 2005 explains the meaning of the term
“information” which reads as under:-
2. Definitions. – In this Act, unless, the context otherwise requires,-
………
(f) "information" means any material in any form, including records, documents, memos, e-mails,
opinions, advices, press releases, circulars, orders, logbooks, contracts, reports, papers, samples,
models, data material held in any electronic form and information relating to any private body
which can be accessed by a public authority under any other law for the time being in force;
15. Section 2(h) of the RTI Act defines “public authority”. The term “public authority” has been given
very wide meaning in the RTI Act. Section 2(h) of the RTI Act reads as under:-
2. Definitions. – In this Act, unless, the context otherwise requires,-
………
(h) "public authority" means any authority or body or institution of self-government established or
constituted,—
(a) by or under the Constitution;
(b) by any other law made by Parliament;
(c) by any other law made by State Legislature;
(d) by notification issued or order made by the appropriate Government, and includes any—
(i) body owned, controlled or substantially financed;
(ii) non-Government Organisation substantially financed, directly or indirectly by funds provided by
the appropriate Government;Chief Information Commissioner vs High Court Of Gujarat on 4 March, 2020

16. Section 2(i) of the RTI Act defines “record” which is an inclusive definition. Section 2(j) explains
“right to information”. Sections 2(i) and 2(j) of the RTI Act read as under:-
2. Definitions. – In this Act, unless, the context otherwise requires,-
………
(i) "record" includes—
(i) any document, manuscript and file;
(ii) any microfilm, microfiche and facsimile copy of a document;
(iii)any reproduction of image or images embodied in such microfilm (whether enlarged or not); and
(iv) any other material produced by a computer or any other device;
(j) "right to information" means the right to information accessible under this Act which is held by
or under the control of any public authority and includes the right to—
(i) inspection of work, documents, records;
(ii)taking notes, extracts or certified copies of documents or records;
(iii) taking certified samples of material;
(iv) obtaining information in the form of diskettes, floppies, tapes, video cassettes or in any other
electronic mode or through printouts where such information is stored in a computer or in any other
device;
17. Section 8(1) of the RTI Act provides for exemption from disclosure of information. Right to
information is subject to exceptions or exemptions stated in Section 8(1)(a) to 8(1)(j) of the RTI Act.
There are ten clauses of Section 8(1) of the RTI Act. Clause (a) of sub-section (1) of Section 8 deals
with information that would compromise the sovereignty or integrity of the country and like matter;
clause (b) covers any information which has been expressly forbidden to be published by any court
of law or tribunal or the disclosure of which may constitute contempt of court; clause
(c) covers such matters which would cause a breach of privilege of the Parliament or the State
Legislatures; clause (d) protects information of commercial nature and trade secrets and intellectual
property; clause (e) exempts the disclosure of any information available to a person in his fiduciary
relationship, unless the competent authority is satisfied that the larger public interest warrants the
disclosure of such information; clause (f) prevents information being disseminated, if it is received
in confidence from any foreign Government; clause (g) exempts the disclosure of any information
which endanger the life or physical safety of any person or identify the source of information orChief Information Commissioner vs High Court Of Gujarat on 4 March, 2020

assistance given in confidence for law enforcement or security purposes; clause (h) bars access to
such information which would impede the process of investigation or apprehension or prosecution
of offenders; clause (i) forbids records and papers relating to deliberations of ministers and officers
of the executive being made available, subject to a proviso; and, clause (j) prohibits disclosure of
personal information unless there is an element of public interest involved.
18. In Central Public Information Officer, Supreme Court of India v. Subhash Chandra Agrawal 2019
(16) SCALE 40, the Supreme Court upheld the order passed by the Central Information
Commissioner directing the CPIO, Supreme Court of India to furnish information as to the assets
declared by the Hon’ble Judges of the Supreme Court. The Constitution Bench held that such
disclosure would not, in any way, impinge upon the personal information and right to privacy of the
Judges. The fiduciary relationship rule in terms of Section 8(1)(e) of the RTI Act was held
inapplicable. Learned counsel appearing for the parties extensively relied upon the observations of
the Supreme Court in Subhash Chandra Agarwal. Since the issue before us is the High Court Rules
vis-a- vis., the RTI Act, we do not propose to refer the various observations copiously relied upon by
the learned counsel appearing for the parties.
19. Article 124 relates to the establishment and constitution of the Supreme Court. Article 124 states
that the Supreme Court of India consist of Chief Justice of India and other Judges. Under Article 145
of the Constitution, the Supreme Court may, from time to time, with the approval of the President,
make Rules for regulating generally the Practice and Procedure of the Court. In exercise of the
powers under Article 145 of the Constitution, the Supreme Court has framed “Supreme Court
Rules”. Order XIII of the Supreme Court Rules lays down the procedure in respect of grant of
certified copies of pleadings, judgments, documents, decrees or orders, deposition of the witnesses,
etc. to the parties to the litigation and also to the third parties. The parties to a proceeding in the
Supreme Court shall be entitled to obtain certified copies by making appropriate application and the
court fees payable as per the “Supreme Court Rules”. So far as the third parties are concerned, as per
Order XIII Rule 2 of the Supreme Court Rules, the court on the application of a person who is not a
party to the case, appeal or matter, pending or disposed of, may on good cause shown, allow such
person to receive such copies as is or are mentioned in the Order XIII Rule 1 of the Supreme Court
Rules. Thus, as per the Supreme Court Rules also, the third party is required to show good cause for
obtaining certified copies of the documents or orders.
20. Article 216 relates to the constitution of High Courts. Every High Court consists of a Chief
Justice and other Judges as the President of India may from time to time appoint. The High Court
Rules are framed under Article 225 of the Constitution of India. The procedure followed for
furnishing of copies/certified copies of orders/documents etc., being information on the judicial
side, are governed by the Rules framed by the High Court under Article 225 of the Constitution of
India. Insofar as the RTI Act is concerned, in exercise of the powers under Section 28 of the RTI Act,
various High Courts have framed the Rules under RTI Act and the information on the
administrative side of the High Court can be accessed as per the Rules framed by the High Courts
under RTI Act.Chief Information Commissioner vs High Court Of Gujarat on 4 March, 2020

21. In the present case, we are concerned with Gujarat High Court Rules. Grant of certified copies to
parties to the litigation and third parties are governed by Rules 149 to 154 of Gujarat High Court
Rules. As per the Rules, on filing of application with prescribed court fees stamp, litigants/parties to
the proceedings are entitled to receive the copies of documents/orders/judgments etc. The third
parties who are not parties in any of the proceedings, shall not be given the copies of judgments and
other documents without the order of the Assistant Registrar. As per Rule 151 of the Gujarat High
Court Rules, the applications requesting for copies of documents/judgments made by third parties,
shall be accompanied by an affidavit stating the grounds for which they are required. Rule 151 reads
as under:-
“151. Parties to proceedings entitled to copies; application by third parties to be
accompanied by affidavits. Copies of documents in any Civil or Criminal Proceedings
and copies of judgment of the High Court shall not be given to persons other than the
parties thereto without the order of the Assistant Registrar. Applications for copies of
documents or judgment made by third parties shall be accompanied by an affidavit
stating the grounds on which they are required, provided that such affidavit shall be
dispensed with in case of applications made by or on behalf of the Government of the
Union, the Government of any State or the Government of any foreign State.”
22. The learned amicus has obtained information from various High Courts as to the
procedure followed by the High Courts for furnishing certified copies of
orders/judgments/documents. As per the Rules framed by various High Courts,
parties to the proceedings are entitled to obtain certified copies of
orders/judgments/documents on filing of application along with prescribed court
fees stamp.
Insofar as furnishing of certified copies to third parties, the Rules framed by the High Courts
stipulate that the certified copies of documents/orders or judgments or copies of proceedings would
be furnished to the third parties only on the orders passed by the court or the Registrar, on being
satisfied about the reasonable cause and bona fide of the reasons seeking the information/certified
copies of the documents. We may refer to the Rules framed by the High Courts of Bombay, Gujarat,
Himachal Pradesh, Karnataka, Madras and various other High Courts which stipulate similar
provisions for furnishing information/certified copies to third parties. The Rules stipulate that for
the third parties to have access to the information on the judicial side or obtaining certified copies of
documents/judgments/orders, the third parties will have to make an application stating the reasons
for which they are required and on payment of necessary court fees stamp. As pointed out earlier,
Supreme Court Rules also stipulate that certified copies of documents or orders could be supplied to
the third parties only on being satisfied about the reasonable cause. Be it noted, the access to the
information or certified copies of the documents/judgments/orders/court proceedings are not
denied to the third parties. The Rules of the High Court only stipulate that the third parties will have
to file an application/affidavit stating the reasons for which the information/certified copies are
required. The Rules framed by the Gujarat High Court are in consonance with the provisions of the
RTI Act. There is no inconsistency between the provisions of the RTI Act with the Rules framed by
the High Court in exercise of the powers under Article 225 of the Constitution of India.Chief Information Commissioner vs High Court Of Gujarat on 4 March, 2020

23. Mr. Preetesh Kapoor, learned Senior counsel for the appellant has submitted that Section 6(2) of
the RTI Act grants a substantive right and the person who is seeking information/copies is not
required to give any reason and this right cannot be curtailed or whittled down by procedural laws
framed by the High Court under Article 225 of the Constitution of India. In support of his
contention that the rules framed by the High Court in exercise of powers under Article 225 cannot
make or curtail any substantive law, reliance was placed upon Raj Kumar Yadav v. Samir Kumar
Mahaseth and Others (2005) 3 SCC 601. Learned Senior counsel further submitted that Section 22
of the RTI Act specifically provides that the provisions of the RTI Act will have an overriding effect
over other laws for the time being in force. It was therefore, submitted that in the event of any
conflict between the provisions of the RTI Act and any other laws made by the Parliament or a State
Legislature or any other authority, the provisions of the RTI Act must prevail and therefore, the RTI
Act would prevail over the rules framed by the High Court. Mr. Prashant Bhushan, learned counsel
for the intervention applicants also reiterated the same submission.
24. In order to consider the contentions urged by the learned Senior counsel for the appellant and
Mr. Prashant Bhushan, let us briefly refer to the various categories of information held by the High
Court, which are broadly as under:-
(a) information held by the High Court relating to the parties to the
litigation/proceedings – pleadings, documents and other materials and memo of
grounds raised by the parties;
(b) orders and judgments passed by the High Court, notes of proceedings, etc.;
(c) In exercise of power of superintendence over the other courts and tribunals,
information received in the records submitted/called for by those courts and
tribunals like subordinate judiciary, various tribunals like Income Tax Appellate
Tribunal, Customs Excise and Service Tax Appellate Tribunal and other tribunals;
(d) information on the administrative side of the High Court viz. appointments,
transfers and postings of the judicial officers, staff members of the High Court and
the district judiciary, disciplinary action taken against the judicial officers and the
staff members and such other information relating to the administrative work.
(e) Correspondence by the High Court with the Supreme Court, Government and
with the district judiciary, etc.;
and
(f) information on the administrative side as to the decision taken by the collegium of
the High Court in making recommendations of the Judges to be appointed to the
High Court; information as to the assets of the sitting Judges held by the Chief
Justice of the High Court.Chief Information Commissioner vs High Court Of Gujarat on 4 March, 2020

25. Information under the categories (a), (b) and (c) and other information on the judicial side can
be accessed/certified copies of documents and orders could be obtained by the parties to the
proceedings in terms of the High Court Rules and the parties to the proceedings are entitled to the
same. So far as the third parties are concerned, as of right, they are not entitled to access the
information/obtain the certified copies of documents, orders and other proceedings. As per rules
framed by the High Court, a third party can obtain the certified copies of the documents, orders or
judgments or can have access to the information only by filing an application/affidavit and by
stating the reason for which the information/copies of documents or orders are required. Insofar as
on the administrative side i.e. categories (d), (e) and (f), one can have access to the information or
copies of the documents could be obtained under the rules framed by the various High Courts or
under the rules framed by the High Court under the RTI Act. Insofar as the disclosure of
information as to the assets of the Judges held by the Chief Justice of the High Court, the same is
now covered by the judgment of the Constitution Bench reported in Central Public Information
Officer, Supreme Court of India v. Subhash Chandra Agrawal 2019 (16) SCALE 40.
26. The preamble to the RTI Act suggests that the Act was enacted “to promote transparency and
accountability in the working of every public authority…….”. The Act was enacted by keeping in view
the right of “an informed citizenry and transparency of information which are vital to its functioning
and also to contain corruption and to hold Governments and their instrumentalities accountable to
the governed…..”. The preamble opens with a reference to the Constitution having established a
democratic republic and the need therefore, for an informed citizenry. The preamble reveals that
legislature was conscious of the likely conflict with other public interest including efficient
operations of the Governments and optimum use of limited fiscal resources and the preservation of
confidentiality of sensitive information and the necessity to harmonise these conflicting interests. A
citizen of India has every right to ask for any information subject to the limitation prescribed under
the Act. The right to seek information is only to fulfill the objectives of the Act laid down in the
preamble, that is, to promote transparency of information.
27. Rule 151 of the Gujarat High Court Rules, 1993 requires a third party applicant seeking copies of
documents in any civil or criminal proceedings to file an application/affidavit stating the reasons for
which those documents are required. As such, the High Court Rules do not obstruct a third party
from obtaining copies of documents in any court proceedings or any document on the judicial side.
It is not as if the information is denied or refused to the applicant. All that is required to be done is
to apply for the certified copies with application/affidavit stating the reasons for seeking the
information. The reason insisting upon the third party for stating the grounds for obtaining certified
copies is to satisfy the court that the information is sought for bona fide reasons or to effectuate
public interest. The information is held by the High Court as a trustee for the litigants in order to
adjudicate upon the matter and administer justice. The same cannot be permitted by the third party
to have access to such personal information of the parties or information given by the Government
in the proceedings. Lest, there would be misuse of process of court and the information and it would
reach unmanageable levels. If the High Court Rules framed under Article 225 provide a mechanism
for invoking the said right in a particular manner, the said mechanism should be preserved and
followed. The said mechanism cannot be abandoned or discontinued merely because the general law
– RTI Act has been enacted.Chief Information Commissioner vs High Court Of Gujarat on 4 March, 2020

28. As discussed earlier, the object of the RTI Act itself recognizes the need to protect the
institutional interest and also to make optimum use of limited fiscal resources and preservation of
confidentiality of sensitive information. The procedure to obtain certified copies under the High
Court Rules is not cumbersome and the procedure is very simple – filing of an application/affidavit
along with the requisite court fee stating the reasons for seeking the information. The information
held by the High Court on the judicial side are the “personal information” of the litigants like title
cases and family court matters, etc. Under the guise of seeking information under the RTI Act, the
process of the court is not to be abused and information not to be misused.
29. In exercise of supervisory jurisdiction under Article 227 of the Constitution of India, if the
records are received by the High Court from tribunals like Income Tax Appellate Tribunal, it may
contain the details disclosed by an assessee in his Income Tax Return. As held in Girish
Ramchandra Deshpande v. Central Information Commissioner and Others (2013) 1 SSC 212, the
details disclosed by a person in his Income Tax Return are personal information which stands
exempted from disclosure unless it involves a larger public interest and the larger public interest
justifies the disclosure of such information. While seeking information or certified copies of the
documents, the High Court Rules which require the third party to a proceeding to file an affidavit
stating the reasons for seeking the information, the same cannot be said to be inconsistent with the
provisions of the RTI Act in as much as the rejection if any, made thereafter will be for the very
reasons as stipulated in Section 8 of the RTI Act.
30. Considering the implementation of RTI Act and observing that the existing mechanism for
invoking the said right should be preserved and operated, in Institute of Chartered Accountants of
India v. Shaunak H. Satya and Others (2011) 8 SCC 781, the Supreme Court held as under:-
“24. One of the objects of democracy is to bring about transparency of information to
contain corruption and bring about accountability. But achieving this object does not
mean that other equally important public interests including efficient functioning of
the governments and public authorities, optimum use of limited fiscal resources,
preservation of confidentiality of sensitive information, etc. are to be ignored or
sacrificed. The object of the RTI Act is to harmonise the conflicting public interests,
that is, ensuring transparency to bring in accountability and containing corruption on
the one hand, and at the same time ensure that the revelation of information, in
actual practice, does not harm or adversely affect other public interests which include
efficient functioning of the governments, optimum use of limited fiscal resources and
preservation of confidentiality of sensitive information, on the other hand. While
Sections 3 and 4 seek to achieve the first objective, Sections 8, 9, 10 and 11 seek to
achieve the second objective.
25. Therefore, when Section 8 exempts certain information from being disclosed, it
should not be considered to be a fetter on the right to information, but as an equally
important provision protecting other public interests essential for the fulfilment and
preservation of democratic ideals. Therefore, in dealing with information not falling
under Sections 4(1)(b) and (c), the competent authorities under the RTI Act will notChief Information Commissioner vs High Court Of Gujarat on 4 March, 2020

read the exemptions in Section 8 in a restrictive manner but in a practical manner so
that the other public interests are preserved and the RTI Act attains a fine balance
between its goal of attaining transparency of information and safeguarding the other
public interests.”
31. While examining the issue of where two mechanisms exist for obtaining the information i.e. the
Supreme Court Rules and the RTI Act, in The Registrar Supreme Court of India v. R S Misra (2017)
244 DLT 179, the Delhi High Court held that “once any information can be accessed through the
mechanism provided under another statute, then the provisions of the RTI Act cannot be resorted
to.” In (2017) 244 DLT 179, the Delhi High Court held as under:-
“53. The preamble shows that the RTI Act has been enacted only to make accessible
to the citizens the information with the public authorities which W.P.(C) 3530/2011
Page 22 of 36 hitherto was not available. Neither the Preamble of the RTI Act nor
does any other provision of the Act disclose the purport of the RTI Act to provide
additional mode for accessing information with the public authorities which has
already formulated rules and schemes for making the said information available.
Certainly if the said rules, regulations and schemes do not provide for accessing
information which has been made accessible under the RTI Act, resort can be had to
the provision of the RTI Act but not to duplicate or to multiply the modes of accessing
information.
54. This Court is further of the opinion that if any information can be accessed
through the mechanism provided under another statute, then the provisions of the
RTI Act cannot be resorted to as there is absence of the very basis for invoking the
provisions of RTI Act, namely, lack of transparency. In other words, the provisions of
RTI Act are not to be resorted to if the same are not actuated to achieve transparency.
55. Section 2(j) of the RTI Act reveals that the said Act is concerned only with that
information, which is under the exclusive control of the 'public authority'. Providing
copies/certified copies is not separate from providing information. The SCR not only
deal with providing 'certified copies' of judicial records but also deal with providing
'not a certified copy' or simply a 'copy' of the document.
The certification of the records is done by the Assistant Registrar/Branch Officer or any officer on
behalf of the Registrar. In the opinion of this Court, in case of a statute which contemplates
dissemination of information as provided for by the Explanation to Section 4 of the RTI Act then in
such situation, public will have minimum resort to the use of the RTI Act to obtain such
information.
56. There are other provisions of the RTI Act which support the said position, namely, Sections 4(2),
(3) and (4) which contemplate that if an information is disseminated then the public will have
minimum resort to the use of the RTI Act to obtain information. In the present case, the
dissemination of information under the provisions of the SCR squarely fits into the definition ofChief Information Commissioner vs High Court Of Gujarat on 4 March, 2020

“disseminated” as provided in the aforesaid Explanation to Section 7(9) and the Preamble
contemplate a bar for providing information if it „disproportionally diverts the resources of the
public authority”.
57. Section 4(2) also provides that it shall be constant endeavour of every public authority to take
steps in accordance with the requirements of subSection (1) thereof and to provide as much
information suo-motu to the public at regular intervals through various means of communications
including intervals so that the public has minimum resort to the use of the RTI Act to obtain
information.” [Underlining added] The same view was taken up by the Karnataka High Court in
State Public Information Officer and Deputy Registrar (Establishment) v. Karnataka Information
Commission and Another WP No.26763 of 2013 dated 09.01.2019.
32. We fully endorse above views of the Delhi High Court. When the High Court Rules provide for a
mechanism that the information/certified copies can be obtained by filing an application/affidavit,
the provisions of the RTI Act are not to be resorted.
33. Sub-section (2) of Section 4 of the RTI Act provides that every public authority to take steps to
provide as much information suo motu to the public at regular intervals through various means of
communications including internet, so that the public have minimum resort to the use of the RTI
Act to obtain information. Suo motu disclosure of information on important aspects of working of a
public authority is therefore, an essential component of information regime. The judgments and
orders passed by the High Courts are all available in the website of the respective High Courts and
any person can have access to these judgments and orders. Likewise, the status of the pending cases
and the orders passed by the High Courts in exercise of its power under Section 235 of the
Constitution of India i.e. control over the subordinate courts like transfers, postings and promotions
are also made available in the website. In order to maintain the confidentiality of the documents and
other information pertaining to the litigants to the proceedings and to maintain proper balance,
Rules of the High Court insist upon the third party to file an application/affidavit to obtain
information/certified copies of the documents, lest such application would reach unmanageable
proportions apart from the misuse of such information.
34. Section 22 of the RTI Act lays down that the provisions of the RTI Act shall have effect
notwithstanding anything inconsistent therewith contained in the Official Secrets Act, 1923, and any
other law for the time being in force or in any instrument having effect by virtue of any law other
than RTI Act. Learned Senior counsel for the appellant has submitted that since the requirement
under Rule 151 of the Gujarat High Court Rules of filing an affidavit stating the grounds for seeking
the information is directly contrary to Section 6(2) of the RTI Act and there is direct inconsistency
between the provisions of the RTI Act and the Gujarat High Court Rules and in the event of conflict
between the provisions of the RTI Act and any other law made by the Parliament or a State
Legislature or any other authority, the RTI Act must prevail.
35. In the non obstante clause of Section 22 of the RTI Act, three categories have been mentioned:-
(i) the Official Secrets Act, 1923; and (ii) any other law for the time being in force; or (iii) any
instrument having effect by virtue of any law other than this Act. In case of inconsistency of any lawChief Information Commissioner vs High Court Of Gujarat on 4 March, 2020

with the provisions of the Right to Information Act, overriding effect has been given to the
provisions of the Right to Information Act. Section 31 of the RTI Act which is a repealing clause
repeals only the Freedom of Information Act, 2002 and not other laws. The Right to Information
Act has not repealed the Official Secrets Act or any of the laws providing confidentiality which
prohibits the authorities to disclose information. Therefore, all those enactments including Official
Secrets Act, 1923 continue to be in force. This Act however, has an overriding effect to the extent
they are inconsistent.
36. The non-obstante clause of the RTI Act does not mean an implied repeal of the High Court Rules
and Orders framed under Article 225 of the Constitution of India; but only has an overriding effect
in case of inconsistency. A special enactment or rule cannot be held to be overridden by a later
general enactment simply because the latter opens up with a non-obstante clause, unless there is
clear inconsistency between the two legislations. In this regard, we may usefully refer to the
judgment of the Supreme Court in R.S. Raghunath v. State of Karnataka (1992) 1 SCC 335 wherein,
the Supreme Court held as under:-
“38. In Ajoy Kumar Banerjee v. Union of India (1984) 3 SCC 127, Sabyasachi
Mukharji, J. (as His Lordship then was) observed thus :
“As mentioned hereinbefore if the scheme was held to be valid, then the question
what is the general law and what is the special law and which law in case of conflict
would prevail would have arisen and that would have necessitated the application of
the principle “generalia specialibus non derogant”. The general rule to be followed in
case of conflict between the two statutes is that the later abrogates the earlier one. In
other words, a prior special law would yield to a later general law, if either of the two
following conditions is satisfied:
(i) The two are inconsistent with each other.
(ii) There is some express reference in the later to the earlier enactment.
If either of these two conditions is fulfilled, the later law, even though general, would prevail.”
37. As pointed out earlier, Section 31 of the RTI Act repeals only the Freedom of Information Act,
2002 and not other laws. If the intention of the legislature was to repeal any other Acts or laws
which deal with the dissemination of information to an applicant, then the RTI Act would have
clearly specified so. In the absence of any provision to this effect, the provisions of the RTI Act
cannot be interpreted so as to attribute a meaning to them which was not intended by the
legislature. In the RTI Act, there is no specific reference to the rules framed by the various High
Courts or any other special law excepting the Freedom of Information Act, 2002.
38. As discussed earlier, Rule 151 of the Gujarat High Court Rules requires a third party to the
proceedings to file an affidavit and state the reasons for seeking access to the information or grant of
certified copies of records and there is no inconsistency of the High Court Rules with the provisionsChief Information Commissioner vs High Court Of Gujarat on 4 March, 2020

of the RTI Act. The Gujarat High Court Rules neither prohibit nor forbid dissemination of
information or grant of certified copies of records. The difference is only insofar as the stipulation of
filing an application/affidavit or payment of fees, etc. is concerned, there is no inconsistency
between the two provisions and therefore, the RTI Act has no overriding effect over Rule 151 of the
Gujarat High Court Rules.
39. Ten categories of information are exempted from disclosure under Section 8(1)(a) to (j) of the
RTI Act. Section 8(1)(j) excludes disclosure of personal information, the disclosure of which:- (i) has
no relationship to any public activity or interest; or (ii) would cause unwarranted invasion of the
privacy of the individual. However, in both the cases, the Central Public Information Officer or the
appellate authority may order disclosure of such information, if they are satisfied that larger public
interest justifies disclosure. This would imply that personal information which has some
relationship to any public activity or interest may be liable to be disclosed. An invasion of privacy
may be held to be justified if the larger public interest so warrants.
40. The information held by the High Court on the judicial side are the personal information of the
parties to the litigation or information furnished by the Government in relation to a particular case.
There may be information held by the High Court relating to the cases which have been obtained
from the various tribunals in exercise of the supervisory jurisdiction of the High Court under Article
227 of the Constitution of India. For instance, the matters arising out of the orders by the Income
Tax Appellate Tribunal, Customs Excise and Service Tax Appellate Tribunal and other tribunals over
which the High Court exercises the supervisory jurisdiction. The orders/judgments passed by the
High Court though are the documents which are concerned to the rights and liabilities of the parties
to the litigation. Under Section 8(1)(j) of the RTI Act, the Central Public Information Officer or the
appellate authority may order disclosure of personal information if they are satisfied that the larger
public interest justifies disclosure. Insofar as the High Court Rules are concerned, if the information
or certified copies of the documents/record of proceedings/orders on the judicial side of the Court is
required, all that the third party is required to do is to file an application/affidavit stating the
reasons for seeking such information. On being satisfied about the reasons for requirement of the
certified copy/disclosure of information, the Court or the concerned Officer would order for grant of
certified copies. As discussed earlier, Order XIII Rule 3 of the Supreme Court Rules also stipulate
the same procedure insofar as the third party seeking certified copy of the documents/records.
41. Yet another contention advanced is that the information held by the High Court may be
furnished to the applicant by following the procedure under Section 11 of the RTI Act. Section 11 of
the Act deals with third party information. As per Section 11 of the Act, if the requisite information
or record or part thereof has been supplied by a third party and has been treated as confidential by
that third party, then the Central Public Information Officer or State Public Information Officer, as
the case may be, within five days of receipt of the request give a written notice to such third party of
the request and of the fact that the Central Public Information Officer or State Public Information
Officer, as the case may be, intends to disclose the information or record or part thereof and invite
the third party to make a submission in writing or orally regarding whether such information should
be disclosed and such submission of the third party shall be kept in view while taking a decision
about the disclosure of the information.Chief Information Commissioner vs High Court Of Gujarat on 4 March, 2020

42. We do not find any merit in the above submission and that such cumbersome procedure has to
be adopted for furnishing the information/certified copies of the documents. When there is an
effective machinery for having access to the information or obtaining certified copies which, in our
view, is a very simple procedure i.e. filing of an application/affidavit with requisite court fee and
stating the reasons for which the certified copies are required, we do not find any justification for
invoking Section 11 of the RTI Act and adopt a cumbersome procedure. This would involve wastage
of both time and fiscal resources which the preamble of the RTI Act itself intends to avoid.
43. We summarise our conclusion:-
(i) Rule 151 of the Gujarat High Court Rules stipulating a third party to have access to
the information/obtaining the certified copies of the documents or orders requires to
file an application/affidavit stating the reasons for seeking the information, is not
inconsistent with the provisions of the RTI Act; but merely lays down a different
procedure as the practice or payment of fees, etc. for obtaining information. In the
absence of inherent inconsistency between the provisions of the RTI Act and other
law, overriding effect of RTI Act would not apply.
(ii) The information to be accessed/certified copies on the judicial side to be obtained
through the mechanism provided under the High Court Rules, the provisions of the
RTI Act shall not be resorted to.
44. In the light of aforesaid reasonings, the impugned order dated 13.03.2014 passed by the High
Court of Gujarat at Ahmedabad in Letters Patent Appeal No.1348 of 2013 is confirmed and these
appeals are dismissed. We place on record the valuable assistance rendered by Mr. Atmaram N.S.
Nadkarni as amicus.
..…………………….J. [R. BANUMATHI] ..…………………….J. [A.S. BOPANNA] ..……………………….J.
[HRISHIKESH ROY] New Delhi;
March 04, 2020.Chief Information Commissioner vs High Court Of Gujarat on 4 March, 2020

