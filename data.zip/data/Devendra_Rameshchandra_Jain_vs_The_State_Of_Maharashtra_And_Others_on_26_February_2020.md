Devendra Rameshchandra Jain vs The State Of Maharashtra
And Others on 26 February, 2020
Author: M. G. Sewlikar
Bench: T.V. Nalawade, M.G. Sewlikar
                                 -1-
         IN THE HIGH COURT OF JUDICATURE OF BOMBAY
                     BENCH AT AURANGABAD
                 CRIMINAL APPLICATION NO. 2562 OF 2019
Awadhesh Kumar Paras Nath Pathak
age 58 years, occ. Service
r/o Mundegaon Igatpuri
Dist. Nashik                                              Applicant
       Versus
1.     The State of Maharashtra
       Through Cidco Waluj Police Station
       District Aurangabad.
2.     Jagdeepkumar Ashokkumar Tyagi
       IT Head Cosmo Films Ltd. Co.
       age 58 years, occ. Service
       r/o B-14/8-9, MIDC Area
       Waluj, Dist. Aurangabad.                           Respondents
Mr. V.D. Sapkal, Advocate holding for Mr. P.P. Uttarwar, Advocate for
the applicant.
Mrs. V.S.Choudhary, APP for respondent No. 1.
Mr. Bharat Chugh & Irshan Dewan, Advocates holding for Mr. K.C.
Sant, Advocate for respondent No. 2.
                                 WITH
                 CRIMINAL APPLICATION NO. 1988 OF 2019
Devendra Rameshchandra Jain
age 33 years, occ. Business
having address at Row House No. E5
Khinwasra Orange Pride,
Gut No. 176, Opp. Abbas Petrol Pump
Waluj Mahanagar -1,
Aurangabad
Dist. Aurangabad.                                         Applicant
       VersusDevendra Rameshchandra Jain vs The State Of Maharashtra And Others on 26 February, 2020

 ::: Uploaded on - 27/02/2020               ::: Downloaded on - 28/02/2020 07:57:13 :::
                                      -2-
1.     The State of Maharashtra
       A t the instance of
       The Police Inspector & Investigating Offcer
       Satara Police Station, Aurangabad City
       Aurangabad
       Dist. Aurangabad.
       Presently investigated by
       The Police Inspector & Investigating Offcer
       Economic Offences Wing, Aurangabad
       Having offce at The Economic Offences Wing
       The Offce of the Commissioner of Police
       Aurangabad, Dist. Aurangabad.
2.     The Commissioner of Police
       The Offce of the Commissioner of Police
       Aurangabad City, Aurangabad
       Dist. Aurangabad
3.     Mr. Ravindra s/o Prahladrao Gokhale
       Age 50 years, occ. Business
       Having address at
       Resident of Plot No. 45, Gat No. 102,
       Behind Surya Lawns,
       Datnagar, Beed Bypass road
       Aurangabad.                                  Respondents
Mr. A.D. Ostwal with Mr. Kiran D. Jadhav with Mr. Shubham
Nabriya, advocates for applicants.
Mrs. V.S Choudhary, APP for respondents No. 1 and 2.
Mr. R.F. Totla, Advocate holding for Mr. Rahul Totla, Advocate for
respondent No. 3
                              CORAM : T.V. Nalawade &
                                      M.G. Sewlikar, JJ.
                            RESERVED ON : 24th January, 2020.
                          PRONOUNCED ON : 26th February, 2020.
ORDER ( PER M. G. SEWLIKAR, J.)
1. Both these criminal applications are being dealt with together as a common question is involved
in both the applications.
2. Facts in Criminal Application No. 2562/2020 are as under :-Devendra Rameshchandra Jain vs The State Of Maharashtra And Others on 26 February, 2020

Applicant Awadhesh Kumar Paras Nath Pathak (hereinafter referred to as the
'applicant') was employed in Cosmo Films Limited Company (hereinafter referred to
as 'Cosmo Films').
Head offce of Cosmo Films is at Delhi and has a plant at Waluj MIDC, Aurangabad.
Applicant was employed as Technical Manager since 05.08.1996. He tendered
resignation on 04.12.2018. At that time, he was the managing head of the said plant.
His resignation was accepted on 31.12.2018. Thereafter the applicant got employment
in Jindal Polyflms Ltd., Igatpuri, Dist. Nasik.
3. It is further alleged that the complainant (arrayed as respondent No. 2 in this application and
hereinafter referred to as Respondent No. 2) is the Information Technology Head in Cosmo Films.
Respondent No. 2 fled a complaint against the applicant alleging that during the continuance of
employment of the applicant with Cosmo Films, the applicant was provided with a laptop by Cosmo
Films. On the day the applicant demitted the offce i.e. on 31.12.2018, the applicant was asked to
return the said laptop. At that time, the applicant requested one Sachin Gore, who is the employee of
Cosmo Films, to copy his personal data which was stored in the said laptop under the folder
AKP-115 and provide the same to the applicant as the said folder contained applicant's personal
data. The said Sachin Gore believing the representation of the applicant, copied the data from the
folder AKP-115 in a pen drive and provided it to the applicant. In the year 2018, in Delhi offce there
was theft of data of the company which was committed by one Varun Sangi who was the employee of
Cosmo Films. This aroused suspicion of respondent No. 2, for the reason of which he checked the
folder AKP- 115 and to his astonishment, he found that the said folder contained the data regarding
manufacturing of flm, rates of products, commission value, manufacturing line, production line etc.
This folder contained many important fles relating to production and business plans of Cosmo
Films. On these allegations, complaint was lodged by respondent No. 2 with Police Station MIDC
Waluj, Aurangabad, on the basis of which, offence under Sections 408, 420 of the Indian Penal Code
and 43(b), 66 C and 72 of the Information Technology Amendment Act, 2008, came to be registered
against the applicant.
4. The facts in Criminal Application No. 1988/2019 are that complainant Ravindra Prahlad Gokhale
is working in Accounts and Administration Department of Grind Master Machines Pvt. Ltd., owned
by Mr. Milind Kelkar. The said Ravindra Gokhale (hereinafter referred to as 'respondent No. 2')
lodged a complaint with Railway Station MIDC Police Station, Aurangabad, that the applicant
joined the said Grind Master Machines Pvt. Ltd. On 27.10.2010 as an Engineer. He executed an
undertaking on bond paper of Rs. 100/- to the effect that the applicant would not share or mis-use
any design, technology, information, plans, technological matters and documents relating to
drawings with any one. Similar agreement was executed by one Jayesh Dudkekar and Arun Tidke,
who joined Grind Master Machines on 11.03.2006 and 05.03.2012 respectively. Applicant tendered
resignation on 26.10.2017 which was accepted on 01.12.2017. Jayesh Dudkekar tendered resignation
on 09.06.2018 which was accepted on 13.09.2018 and the resignation of Arun Tidke was accepted
was 04.09.2017.Devendra Rameshchandra Jain vs The State Of Maharashtra And Others on 26 February, 2020

5. It is further alleged in the complaint that in the month of October 2018, Human Resource
Manager (HR Manager) Sandip Pimple noticed that Arun Tidke had joined Trysing Automation
Company. On further probe, it was noticed that applicant, Arun Tidke and Jayesh Dudkekar had
entred into a partnership on 28.02.2018 and all of them tendered resignation at regular intervals
with a pre-arranged plan. Jayesh Dudkekar, during continuation of employment with Grind Master
Machines, under active connivance with applicant, had committed theft of the technology by
transmitting drawings and quotations of the company through his personal email id
jayesh.dudkekar2012@gmail.com to the applicant. The said information was mailed on the email id
of the applicant and one Shekhar Gudekar, the owner of Sunrise Automation. The said Shekhar
Gudekar by using the technology of Grind Master Machine, prepared a replica of Robot Cell For Hot
Label pasting on Coil machine as being manufactured by Grind Master Machine. This machine was
sold by Shekhar Gudekr to Plastochem India Private Limited at Kolkata on 31.08.2018 for Rs.
1,32,97,000/-. The production cost of the said machine manufactured by Grind Master Machine is
Rs. 1,06,37,600/-. In this manner, Grind Master Machine is deprived of proft of Rs. 26,59,400/-.
Applicant, during the period from 27.10.2010 to 01.12.2017 i.e. during the continuation of
employment with Grind Master Machine, committed theft of data relating to the said company
which was stored in its system. In this manner, applicant, Jayesh Dudkekar and Arun Tidke cheated
Grind Master Machine. On these allegations, offence under Sections 406, 420 read with section 34
of the Indian Penal Code and Sections 72 of the Information Technology Act, 2000 ( hereinafter
referred to as "I.T. Act" for short) and Section 63 and 63-B of the Copyright Act, 1957 has been
registered against them.
6. Heard learned counsel for the respective parties.
7. Learned counsel for applicants placed reliance on the case of Sharat Babu Digumarti Vs.
Government of NCT of Delhi reported in AIR 2017 SC 150. In this authority, the Honourable Apex
Court has held as under :-
32. The aforesaid passage clearly shows that if legislative intendment is discernible
that a latter enactment shall prevail, the same is to be interpreted in accord with the
said intention. We have already referred to the scheme of the IT Act and how
obscenity pertaining to electronic record falls under the scheme of the Act. We have
also referred to Sections 79 and 81 of the IT Act. Once the special provisions having
the overriding effect do cover a criminal act and the offender, he gets out of the net of
the Indian Penal Code and in this case, Section 292. It is apt to note here that
electronic forms of transmission is covered by the IT Act, which is a special law. It is
settled position in law that a special law shall prevail over the general and prior laws.
When the Act in various provisions deals with obscenity in electronic form, it covers
the offence Under Section 292 Indian Penal Code.
Thus, the Honourable Apex Court has held that if legislative intendment is clear then the latter
enactment shall prevail and the same is to be interpreted in accord with the said intention. If the
special provisions having the overriding effect covers the criminal act and the offender, he gets out
of the net of the Indian Penal Code.Devendra Rameshchandra Jain vs The State Of Maharashtra And Others on 26 February, 2020

8. Reliance was also placed on the case of Gagan Harsh Sharma and other Vs. The State of
Maharashtra and others reported in 2019 Cri.L.J. 1398. After taking into consideration the entire
scheme of the I.T. Act and also the law laid down by the Honourable Apex Court in the case of
Sharat Babu (Supra), the Division Bench of this Court came to the conclusion that the criminal act
under sections 389, 406 and 420 of the Indian Penal Code is covered by section 43 read with section
66 and 72 of the Information and Technology Act, 2000. The Division Bench in paragraphs No. 27
and 28 has held as under :-
27. Applying the aforesaid principles to the facts involved in the case, perusal of the
complaint would reveal that the allegations relate to the use of the data code by the
employees of the complainant company by accessing the Code and stealing the said
data by using the computer source code. The Act of accessing or securing access to
computer/computer system or computer network or computer resources by any
person without permission of the owner or any person who is in charge of the
computer, computer system, computer network or downloading of any such data or
information from computer in a similar manner falls within the purview of Section 43
of the Information Technology Act, 2000. When such Act is done dishonestly and
fraudulently it would attract the punishment under Section 66 of the Information
Technology Act, such Act being held to be an offence. The ingredients of dishonesty
and fraudulently are the same which are present if the person is charged with Section
420 of the Indian penal Code. The Offence of Section 379 in terms of technology is
also covered under Section 43.
Further, as far as Section 408 is concerned which relates to criminal breach of trust, by a clerk or
servant who is entrusted in such capacity with the property or with any dominion over property,
would also fall within the purview of Section 43 would intents to cover any act of accessing a
computer by stealing of any data, computer data base or any information from such computer or a
computer system including information or data held or stored in any removable storage medium
and if it is done with fraudulent and dishonest intention then it amounts to an offence. The
ingredients of an offences under which are attracted by invoking and applying the Section 420, 408,
389 of the Indian Penal Code are covered by Section 66 of the Information Technology Act, 2000
and prosecuting the petitioners under the both Indian Penal Code and Information Technology Act
would be a brazen violation of protection against double jeopardy.
28. In such circumstances if the special enactment in form of the information Technology Act
contains a special mechanism to deal with the offences falling within the purview of information
Technology Act, then the invocation and application of the provisions of the Indian Penal Code
being
- 10 -
applicable to the same set of facts is totally uncalled for. Though the learned APP as well as Shri
Gupte has vehemently argued that the prosecution under the provisions of the Indian Penal Code
can be continued and at the time of taking cognizance the Competent Court can determine theDevendra Rameshchandra Jain vs The State Of Maharashtra And Others on 26 February, 2020

provisions of which enactments are attracted and it is too premature to exclude the investigation in
the offences constituted under the Indian Penal Code, we are not ready to accept the said contention
of the learned Senior Counsel, specifcally in the light of the observations of the Hon'ble Apex Court
in the case of Sharat Babu Digumarti (Surpa). We are of the specifc opinion that it is not permissible
to merely undergo the rigmarole of investigation although it is not open for the Investigating Offcer
to invoke and apply the provisions of the Indian Penal Code, in light of the specifc provisions
contained in the Information Technology Act, 2000 and leave it to the discretion of the Police
Authorities to decide in which direction the investigation is to be proceeded. The Information
Technology Act, 2000 being a special enactment, it requires an able investigation keeping in mid the
purpose of the enactment and to look the new venturing of crimes with the assistance of the
Technology.
9. Learned counsel Shri Ostwal argued that Gagan Harsh Sharma case was challenged before the
Honourable Supreme Court and the Honourable Supreme Court dismissed it in lemine. The
Honourable Supreme Court has held in the case of State of Uttar Pradesh Vs. Aman Mittal &
another in Criminal Appeal Nos. 1328- 1329 of 2019 decided on 04.09.2019 as under :
"(iv) An order refusing special leave to appeal may be a non-speaking order or a
speaking one. In
- 11 -
either case it does not attract the doctrine of merger. An order refusing special leave to appeal does
not stand substituted in place of the order under challenge. All that it means is that the Court was
not inclined to exercise its discretion so as to allow the appeal being fled."
10. We do not agree with the observations of the Division Bench for the following reasons :-
The offence leveled against the applicants in both the applications are under sections
406, 408, 420 of the Indian Penal Code and Sections 43(D), 66C and 72 of I.T. Act.
For this purpose, defnition of Section 415 of the Indian Penal Code will have to be
looked into which reads thus :
S. 415 - Cheating - Whoever, by deceiving any person, fraudulently or dishonestly
induces the person so deceived to deliver any property to any person, or to consent
that any person shall retain any property, or intentionally induces the person so
deceived to do or omit to do anything which he would not do or omit if he were not so
deceived, and which act or omission causes or is likely to cause damage or harm to
that person in body, mind, reputation or property, is said to "cheat".
Explanation - A dishonest concealment of facts is a deception within the meaning of
this section.Devendra Rameshchandra Jain vs The State Of Maharashtra And Others on 26 February, 2020

11. The Honourable Supreme Court in the case of M/s Medchl Chemicals and Pharma Pvt. Ltd. Vs.
M/s Biological E. Ltd.
- 12 -
And others reported in AIR 2000 Supreme Court 1869 has explained the ingredients of Section 415
as under :-
10. The ingredients require to constitute an offence under Section 415 has been
lucidly dealt with by this Court in the Case of Ram Jas v. State of U.P. (1970) 2 SCC
740 : (AIR 1974 SC 1811 : 1974 Cri LJ 1261) wherein this Court observed as below :
"The ingredients required to constitute the offence of cheating are -
(I) there should e fraudulent or dishonest inducement of a person by deceiving him.
(ii) (a) the person so deceived should be induced to deliver any property to any
person, or to consent that any person shall retain any property; or
(b) the person so deceived should be intentionally induced to do or omit to do
anything which he would not do or omit if he were not so deceived; and
(ii) in cases covered by (ii)(b) the act or omission should be one which cause or is
likely to cause damage or harm to the person induced in body, mind, reputation or
property."
12. Section 420 of the Indian Penal Code deals with cheating and dishonestly inducing delivery of
property which reads as under :-
S.420 Cheating and dishonestly inducing delivery of property -
Whoever cheats and thereby dishonestly induces the person deceived to deliver any
property to any person, or to make, alter or destroy the whole or any part of a
valuable security, or anything which is signed or sealed, and which is capable of being
- 13 -
converted into a valuable security, shall be punished with imprisonment of either
description for a term which may extend to seven years, and shall also be liable to
fne.
                    Thus, the ingredients of section 420 are
i)         There has to be cheating.Devendra Rameshchandra Jain vs The State Of Maharashtra And Others on 26 February, 2020

ii)        There has to be dishonest inducement
iii)       The person is deceived and is induced to deliver any property to
any person or to make, alter or destroy the whole or any part of a valuable security, or
anything which is signed or sealed and which is capable of being converted into a
valuable security.
13. The Honourable Supreme Court in the case of M/s Medchl Chemicals (Supra) has observed that
in order to attract the provisions of section 418 and 420 of the Indian Penal Code, guilty intent at
the time of making promise is required and subsequent failure to fulfll the promise by itself does not
attract the provisions of sections 418 or 420 of the Indian Penal Code. Mens rea is one of the
essential ingredients of the offence of cheating under section 420 of the Indian Penal Code.
14. Other offences leveled against applicants in both the applications are under Sections 406 and
408 of the Indian Penal
- 14 -
Code i.e. criminal breach of trust. Section 405 of the Indian penal Code defnes criminal breach of
trust as under :-
S. 405 Criminal breach of trust - Whoever, being in any manner entrusted with
property, or with any dominion over property, dishonestly misappropriates or
converts to his own use that property, or dishonestly uses or disposes of that property
in violation of any direction of law prescribing the mode in which such trust is to be
discharged, or of any legal contract, express or implied, which he has made touching
the discharge of such trust, or willfully suffers any other person so to do, commits
"criminal breach of trust".
Section 405 of the Indian Penal Code deals with criminal breach of trust. A careful
reading of the Section 405 of the Indian Penal Code shows that a criminal breach of
trust involves the following ingredients :
(a) a person should have been entrusted with property, or entrusted with dominion
over property;
(b) that person should dishonestly misappropriate or covert to his own use that
property, or dishonestly use or dispose of that property or wilfully suffer any other
person to to do so;
(c) that such misappropriation, conversion, use or disposal shouldDevendra Rameshchandra Jain vs The State Of Maharashtra And Others on 26 February, 2020

- 15 -
be in violation of any direction of law prescribing the mode in which such trust is to be discharged,
or of any legal contract which the person has made, touching the discharge of such trust.
15. Section 406 of the Indian Penal Code prescribes punishment for criminal breach of trust as
defned in Section 405 of the Indian Penal Code. For the offence punishable under Section 406 of the
Indian Penal code, the following conditions are required to be fulflled :
(i) that the accused was entrusted with property or with dominion over it and
(ii) that he (a) misappropriated it,or (b) converted it to his own use, or (c) used it, or
(d) disposed of it.
16. The gist of the offence is misappropriation done in a dishonest manner. There are two distinct
parts of the said offence. The frst involves the fact of entrustment, wherein an obligation arises in
relation to the property over which dominion or control is acquired. The second part deals with
misappropriation which should be contrary to the terms of the obligation which is created. Thus,
once it is proved that the benefcial interest in the property was
- 16 -
vested in some other person other than the accused and the accused has held that property on behalf
of that person, appropriation of that benefcial interest in the property by the accused for his own
amounts to 'criminal breach of trust'.
17. So far as Section 420 of the Indian Penal Code is concerned, it deals with cheating. Essential
ingredients of Section 420 of the Indian Penal code are :- (i) cheating; (ii) dishonest inducement to
deliver property or to make, alter or destroy any valuable security or anything which is sealed or
signed or is capable of being converted into a valuable security, and (iii) mens rea of the accused at
the time of making the inducement.
18. It is, thus, clear from this defnition that to attract the provisions of Section 405 of the Indian
Penal Code, there has to be dishonest misappropriation of the property to one's own use or
dishonest use or disposal of that property in violation of any direction of law or any legal contract. If
any of these ingredients is absent, Section 405 will not be attracted. Section 406 of the Indian Penal
Code deals with punishment for criminal breach of trust and Section 408 deals with criminal breach
of trust by clerk or servant.
- 17 -
19. Now, it will have to be examined whether these criminal acts are covered by the I. T. Act. Section
43 of the I. T. Act deals with penalties, compensation and adjudication and Section 66 makes the
acts referred to in Section 43 punishable with imprisonment if they are done dishonestly orDevendra Rameshchandra Jain vs The State Of Maharashtra And Others on 26 February, 2020

fraudulently. Section 43 of the I. T. Act reads as under :-
43. Penalty and compensation for damage to computer, computer system,etc. If any
person without permission of the owner or any other person who is incharge of a
computer, computer system or computer network --
(a) accesses or secures access to such computer, computer system or computer
network [or computer resource];
(b) downloads, copies or extracts any data, computer data base or information from
such computer, computer system or computer network including information or data
held or stored in any removable storage medium;
(c) introduces or causes to be introduced any computer contaminant or computer
virus into any computer, computer system or computer network;
(d) damages or causes to be damaged any computer, computer system or computer
network, data, computer data base or any other programmes residing in such
computer, computer system or computer network;
(e) disrupts or causes disruption of any computer, computer system or computer
network;
(f) denies or causes the denial of access to any person
- 18 -
authorised to access any computer, computer system or computer network by any means;
(g) provides any assistance to any person to facilitate access to a computer, computer system or
computer network in contravention of the provisions of this Act, rules or regulations made
thereunder;
(h) charges the services availed of by a person to the account of another person by tampering with or
manipulating any computer, computer system, or computer network,
(i) destroys, deletes or alters any information residing in a computer resource or diminishes its value
or utility or affects it injuriously by any means;
(j) steel, conceals, destroys or alters or causes any person to steal, conceal, destroy or alter any
computer source code used for a computer resource with an intention to cause damage; [he shall be
liable to pay damages by way of compensation to the person so affected].
Explanation.Devendra Rameshchandra Jain vs The State Of Maharashtra And Others on 26 February, 2020

For the purposes of this section:
(i) "computer contaminant" means any set of computer instructions that are designed
--
(a) to modify, destroy, record, transmit data or programme residing within a
computer, computer system or computer network; or
(b) by any means to usurp the normal operation of the computer, computer system,
or computer network;
(ii) "computer data base" means a representation of information, knowledge, facts,
concepts or instructions in text, image, audio, video that are being prepared or have
been prepared in a formalised manner or have been produced by a computer,
computer system or computer
- 19 -
network and are intended for use in a computer, computer system or computer network;
(iii) "computer virus" means any computer instruction, information, data or programme that
destroys, damages, degrades or adversely affects the performance of a computer resource or
attaches itself to another computer resource and operates when a programme, data or instruction is
executed or some other event takes place in that computer resource;
(iv) "damage" means to destroy, alter, delete, add, modify or rearrange any computer resource by
any means.
(v) "computer source code" means the listing of programmes, computer commands, design and
layout and programme analysis of computer resource in any form.
20. Dishonestly has been defned in Section 24 of the Indian Penal Code which reads as under :-
24. "Dishonestly" - Whoever does anything with the intention of causing wrongful
gain to one person or wrongful loss to another person, is said to do that thing
"dishonestly".
The term "fraudulently" is defned in Section 25 of the Indian Penal Code which reads as under :-
25. "Fraudulently" - A person is said to do a thing fraudulently if he does that thing
with intent to defraud but not otherwise.
21. Section 43 of the Information Technology Act does not contemplate the cases in which
permission is obtained by cheatingDevendra Rameshchandra Jain vs The State Of Maharashtra And Others on 26 February, 2020

- 20 -
the owner or a person in charge of computer. It simply says that if these acts are done without
permission they are penalised if they are done dishonestly or fraudulently. The expression
dishonestly means the acts done with the intention of causing wrongful gain to oneself and wrongful
loss to another. Fraudulently is defned to mean the acts done with intent to defraud others. Under
Section 420 of the Indian Penal Code, 'dishonestly' is one of the ingredients but not the sole
ingredient. For attracting offence under Section 420 of the Indian Penal Code, in addition to
dishonest intention, elements of cheating and inducement to deliver property are also the essential
ingredients which are lacking in Section 43 read with Section 66 of the I.T Act. Therefore, in our
considered opinion, Section 43 does not cover the criminal act contemplated in Section 420 of the
Indian Penal Code.
22. Section 66 of the I.T. Act deals with the cases involving the acts enumerated in Section 43(a) to
(j) of the Act done dishonestly or fraudulently. In Criminal Application no. 2562/2019, the
allegations are that the applicant deceived Sachin Gore by misrepresenting that the folder APK-115
contains his personal data and Sachin Gore was induced to copy the said folder and give it to
- 21 -
the applicant. But, infact, the said folder contained valuable data regarding designs etc. In our
opinion, Section 43 read with Section 66 of the I.T. Act does not cover the acts alleged in Criminal
Application no. 2562/2019. The acts done dishonestly or fraudulently will not cover the cases where
allegations of deception are made.
23. Moreover, in the case of The State of Uttar Pradesh Vs. Aman Mittal (supra), the Honourable
Supreme Court has kept this question open and observed as under :-
25. The Bombay High Court in Gagan Harsh Sharma has found that even a dishonest
and fraudulent act falls within the scope of Section 66 of IT Act. We are not called
upon in the present appeals to examine whether an accused can be tried for an
offence under IPC in view of Section 66 of IT Act. Such question can be raised and
decided in an appropriate case.
24. It was argued that Section 72 of the Information and Technology Act, 2000 deals with the acts
involving criminal breach of trust. Section 72 of the Act reads as under :-
72. Penalty for breach of confdentiality and privacy -
Save as otherwise provided in this Act or any other law for the time being in force, any person who,
in pursuance of any of the powers conferred under this Act, rules or regulations made thereunder,
has secured access to any electronic record, book, register,
- 22 -Devendra Rameshchandra Jain vs The State Of Maharashtra And Others on 26 February, 2020

correspondence, information, document or other material without the consent of the person
concerned discloses such electronic record, book, register, correspondence, information, document
or other material to any other person shall be punished with imprisonment for a term which may
extend to two years, or with fne which may extend to one lakh rupees, or with both.
Thus, following are the ingredients of Section 72 of the Information and Technology Act :-
i) A person should disclose electronic record, book, register, correspondence,
information, document or any other material to any other person;
ii) The person who discloses electronic record etc. should have secured the access to
them in pursuance of any of the powers conferred under this Act, rules or regulations
made thereunder.
iii) The electronic record etc. should have been disclosed without the consent of the
person concerned.
25. Reliance was placed on Section 72-A of the Act which reads as under :-
Section 72A - Punishment for disclosure of information in breach of lawful contract.
-Save as otherwise provided in this Act or any other law for the time being in force,
any person including an intermediary who, while providing services under the terms
of lawful contract, has secured access to any material containing
- 23 -
personal information about another person, with the intent to cause or knowing that
he is likely to cause wrongful loss or wrongful gain discloses, without the consent of
the person concerned, or in breach of a lawful contract, such material to any other
person, shall be punished with imprisonment for a term which may extend to three
years, or with fne which may extend to fve lakh rupees, or with both.] The ingredients
of Section 72-A of the Act are -
i) Any person has secured access to any material containing personal information
about another person and this access has been secured by providing service in terms
of lawful contract.
ii) Such person with intent to cause wrongful loss or wrongful gain discloses without
consent of the person concerned or in breach of lawful contract such material to any
other person.
Thus, Section 72-A will not come into play only when access has been secured while providing
service in terms of lawful contract. Both the applications i.e. Criminal Application No. 2562/2019
and 1988/2019 do not contain allegations that access has been secured while providing service inDevendra Rameshchandra Jain vs The State Of Maharashtra And Others on 26 February, 2020

terms of lawful contract. Therefore, Section 72-A will have no application.
26. As indicated above, for invoking section 406 of the Indian
- 24 -
Penal Code, there has to be entrustment or dominion over the property and the said property is
misappropriated or converted to his own use without the consent of the person concerned or in
breach of the directions or lawful contract. Therefore, the essential requirement for pressing into
service the provisions of Section 406 of the Indian Penal Code are that the property entrusted has
been misappropriated or converted to one's own use dishonestly. Section 72 of the I.T. Act can be
pressed into service only when information is disclosed to another person without permission of the
person concerned. It does not contemplate the situation wherein the property, in the case in hand,
electronic record, is misappropriated or converted to one's own use. Disclosure of electronic record
etc. to any person without permission of the concerned person is made punishable under Section 72
of the I.T. Act. Section 72 does not make punishable the act of converting the electronic record to
one's own use. Therefore, Section 72 does not cover the criminal act contemplated in Section 406,
408 and 409 of the Indian Penal Code.
27. In Criminal Application No. 1988/2019, the allegations
- 25 -
are that the applicant and his associates not only disclosed the electronic record etc. but also used
this information, electronic record, data for their own business. This act was done by them during
the continuance of the employment with Grind Master Machines. Therefore, in our opinion, Section
72 of the I.T. Act does not cover the case of converting the said electronic record to their own use.
28. In view of this, following questions are required to be referred to the Larger Bench :-
1) Whether Section 43 read with Section 66 of I.T. Act covers the cases :-
a) Involving the obtaining of permission, by cheating the owner or any other person,
who is incharge of computer, computer system or computer network, and thereby
induced the owner or person in charge of the computer, computer system or
computer network for doing the act enumerated in Section 43 of the I.T. Act ?
b) The expression fraudulently or dishonestly covers the cases in which permission is
obtained from the owner or person who is
- 26 -
incharge of computer or computer system or computer network by cheating him ?Devendra Rameshchandra Jain vs The State Of Maharashtra And Others on 26 February, 2020

c) Whether Section 72 of the I.T. Act covers all the ingredients of Sections 406, 408, 409 of the
Indian Penal Code especially cases in which access is secured dishonestly to any electronic
correspondence, information, document or other material and the said electronic record
correspondence, information, document or material in misappropriated or converted for one's own
use ?
d) Whether the acts done under Sections 43 or 72 of the I.T. Act cover the criminal acts done with
common intention ?
29. The Registrar (Judicial) of this Court, is therefore requested to place before the Hon'ble the
Chief Justice, the papers of these criminal applications along with the copy of this order in
accordance with Rule 7 of Chapter I of the Bombay High Court Appellate Side Rules, 1960.
( M. G. SEWLIKAR )                                   ( T.V. NALAWADE )
        Judge                                                Judge
dybDevendra Rameshchandra Jain vs The State Of Maharashtra And Others on 26 February, 2020

