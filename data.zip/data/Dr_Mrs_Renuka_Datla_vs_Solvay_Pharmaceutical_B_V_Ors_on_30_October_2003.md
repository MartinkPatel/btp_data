Dr. Mrs. Renuka Datla vs Solvay Pharmaceutical B.V. & Ors on
30 October, 2003
Equivalent citations: 2003 (6) SLT 649, AIR 2004 SUPREME COURT 321, 2004
(1) SCC 149, 2003 AIR SCW 6192, 2004 CLC 159 (SC), 2004 (1) COM LJ 106
SC, 2004 (1) ALL CJ 554, (2004) 1 COMLJ 106, 2003 (9) SCALE 147, (2003) 8
JT 193 (SC), (2004) 135 TAXMAN 200, (2003) 4 CURCC 276, (2003) 11 INDLD
688, (2003) 117 COMCAS 585, (2004) 265 ITR 435, (2004) 181 TAXATION 136,
(2003) 57 CORLA 134, (2003) 8 SUPREME 14, (2003) 9 SCALE 147
Author: P. Venkatarama Reddi
Bench: S. Rajendra Babu, P. Venkatarama Reddi, Arun Kumar
           CASE NO.:
Special Leave Petition (civil)  18035 of 2000
Special Leave Petition (civil)  18041-18042 of 2000
PETITIONER:
Dr. Mrs. Renuka Datla                         
RESPONDENT:
Solvay Pharmaceutical B.V. & Ors.
DATE OF JUDGMENT: 30/10/2003
BENCH:
S. RAJENDRA BABU, P. VENKATARAMA REDDI & ARUN KUMAR
JUDGMENT:
JUDGMENT WITH INTERLOCUTORY APPLICATION NO.2/2002 With Interlocutory application
Nos. 3 & 4/2002 P. Venkatarama Reddi, J.
The dispute is between the shareholders of two pharmaceutical companies which figure as
respondents herein. Suits were filed by the petitioners, who are the wife and husband, in the City
Civil Court, Hyderabad impleading the Companies and the third respondent by name Shri D. Vasant
Kumar, the subject matter of the suits broadly being the transfer of shareholdings. The suit O.S.No.
551 of 2000 was filed by the petitioner in S.L.P.No. 18035/2000. Along with the suit the
petitioner-plaintiff applied for an interim injunction restraining the defendants-respondents 1 and 3
(Solvay Pharmaceutical B.V. and Shri D. Vasant Kumar) from transferring/exchanging their
shareholdings in defendant Companies 2 & 4 pending disposal of the suit. The other two Suits of
similar nature were filed by the petitioner in S.L.P.Nos. 18041 & 18042 of 2000 and interim
injunction was sought for. The I.A. filed in O.S.No. 551 of 2000 under Order 39 Rules 1 & 2 wasDr. Mrs. Renuka Datla vs Solvay Pharmaceutical B.V. & Ors on 30 October, 2003

dismissed by the learned trial Judge while vacating the ex-parte injunction granted earlier.
However, the ad interim injunction granted in the suits filed by the petitioner in SLPs 18041 &
18042/2000 remained in force.
Aggrieved parties filed three appeals in the High Court under Order 43 Rule 1 C.P.C. The appeal
filed by the petitioner in the first S.L.P. against the refusal of injunction was dismissed by the High
Court and the other two appeals filed by the aggrieved defendants were allowed and the ad interim
injunction in both the cases was vacated. Against this common order of the High Court, the present
S.L.Ps. were filed by the plaintiffs namely, Mrs. Renuka Datla and Dr. Vijay Kumar Datla. On the
initiative taken by this Court while hearing the S.L.Ps., the parties settled the disputes and the terms
of mutual settlement were reduced to writing and they were signed by all the parties. This Court
passed the following order on 15th July, 2002 to give effect to the settlement.
"Counsel for the parties state that the dispute between them has been settled. A copy
of the terms of mutual settlement signed by the parties has been filed in Court and
initialed by the Court Master. Terms of settlement are recorded. The terms
contemplate valuation to be done of the intrinsic worth of the two companies and the
value of 4.91% shares in the said two companies held by the petitioners. Valuation
has to be completed within a period of four weeks. The terms of mutual settlement
shall form part of this order. Copy of the order be sent to Shri Y.M. Malegam,
Chartered Accountant, M/s. S.B. Billimoria & Co., Mumbai-400 038."
According to the terms of settlement, M/s. Solvay Pharmaceuticals (R1) and Mr. Vasant Kumar (R3)
have agreed to purchase 4.91% shares held by the petitioners in the two companies namely Duphar
Pharma India Ltd. (DPIL renamed as Solvay Pharma India Ltd.) and Duphar Interfran Ltd. (DIL),
the petitioners having agreed to sell the said shares. Shri Y.H. Malegam, Chartered Accountant,
Mumbai had to evaluate the intrinsic worth of both the Companies— DPIL and DIL as going
concerns and the value of the said 4.91% shares held by the petitioners in those two Companies "by
applying the standard and generally accepted method of valuation". Shri Malegam should give
opportunity to the respective parties to make their submissions. The valuation of Shri Malegam shall
be regarded as final and binding on all the parties to the settlement. The relevant date for valuation
was fixed as 31st March, 2001. The payment for shares shall be made within two weeks of the
submission of the valuation report and the statutory approvals thereof failing which the respondents
shall pay interest at the rate of 15% p.a. simultaneously with receipt of the total consideration for
4.91% shares, the petitioner shall effect the transfer of shares. The respondent Shri Vasant Kumar
shall withdraw the Suits filed in the City Civil Court, Hyderabad; likewise, the petitioners shall
withdraw the Suits filed by them in the City Civil Court and also the appeals in this Court—C.A.Nos.
8316-8321 of 2001 as well as the application filed by Smt. Renuka Datla under Section 399(4) of the
Companies Act before the Central Government. It was agreed that the S.L.P. shall be kept pending
for passing the final orders in terms of the settlement.
Mr. Malegam submitted his valuation report with his covering letter dated 28.9.2002. After
assessing the intrinsic worth of the two Companies as going concerns, the value of 4.91% shares was
arrived at at Rs.8.24 crores. A brief reference to the salient features of valuation may be appropriate.Dr. Mrs. Renuka Datla vs Solvay Pharmaceutical B.V. & Ors on 30 October, 2003

The Valuer considered three methods of valuation. (1) Asset based (2) Earning based (3) Market
based. While working out the earning based valuation, the value on the basis of capitalization of past
earnings was adopted. The discounted cash flow method which is the commonly used methodology
for future earnings based valuation was eschewed from consideration. The reasons given by the
valuer are; (1) No independent (third party) projections have been provided; (2) Both parties have
provided projections which differ substantially as illustrated in Tables 1.1 and 1.2.
The basic principle and method of evaluation has been stated thus:
"The intrinsic value of the share would be based on the asset and earnings based
value with appropriate weightages given to the two methods. Since the value of a
company/business would be more influenced by its earnings value a higher
weightage is given to the earnings value as compared to its asset value. The asset
value is considered as an integral part of the intrinsic value as it has a persuasive
impact. Thus, I have considered the following weightages for determing the intrinsic
value * Asset based value 1/3rd weightage * Earnings based value 2/3rd weightage
The market (for listed company—its market price) based value indicates the value
ascribed by the buyer/seller of the share at a given point in time. This is influenced by
? the floating stock and the supply and demand, which gets reflected in the volume
and price of market transactions ? market perceptions related to — the overall market
— the industry — the company The recommended value is the higher of the intrinsic
value or the market based value. Though rationally speaking, the recommended value
should be the intrinsic value, it may be possible that the market based value at a
given point of time is higher than the intrinsic value, which is indicative of a bullish
phase / perception of the market and/or industry and/or the company. Therefore, to
take into account this practical reality, I have suggested the higher of the two.
The intrinsic worth of the two Companies and the value of 4.91% shares in the two
Companies are set out at Para 7.3.1. As already stated, the value of 4.91% shares has
been worked out as 8.24 crores.
It was made clear that the above value has been determined on the basis that 4.91%
shareholding carries no special rights. In this context, the Valuer has referred to the
claim of the petitioners that the value of 4.91% holding should be higher than the
value derived by applying the percentage to the intrinsic worth of the Companies. In
other words, the contention of the petitioners was that the shares are to be valued on
the basis that 4.91% forms part of the combined holding of 25% of the Indian
promoters' shareholding. The respective contentions in this regard have been
analysed by the Valuer as follows:— "If the shares are to be valued on the basis of a
holding of 4.91%, then this holding does not give any special advantage to the holder
or in this case even to the purchaser since the respondents collectively hold in the two
companies 60.5% of the share capital of each company. On that consideration, the
value of the shares can only be 4.91% of the intrinsic worth of the two companies.Dr. Mrs. Renuka Datla vs Solvay Pharmaceutical B.V. & Ors on 30 October, 2003

On the other hand, if the shares are to be valued on the basis that the 4.91% forms
part of the combined holding of 25% and therefore carries special rights, then there
has to be a premium attached to the value of the shares. Accordingly, the value of the
4.91% shareholding would be the value determined by taking 4.91% of the intrinsic
worth of the two companies and adding thereto a control premium."
The Valuer concluded that he was not competent to decide upon this controversial legal issue and
therefore, the valuation was done without adding the element of control premium.
Another aspect debated before the Valuer was whether the value of the 'Vertin' and 'Colospa' brands
which are the original research products of the foreign promoter, should be considered in the
valuation of the 4.91% shares in DIL. It was contended by the petitioners that DIL was legally
entitled to carry on its business in 'Vertin' and 'Colospa' along with other brands. The rights over
these two brands were transferred to Dupen Laboratories Private Ltd. and such transfer, according
to the petitioner, was in breach of contractual obligations under the Trademark License Agreement
dated 15.7.1975 etc. The Valuer, after referring to the contentions, observed thus:
"…The brands VERTIN and COLOSPA have been purchased by Solvay
Pharmaceuticals BV from Dupen Laboratories Private Limited. As such, these are not
the assets of DIL. DIL also has no investment in Dupen Laboratories Private Limited.
Whatever may be the claims of the petitioners in this matter against the respondents,
this is not a matter which should affect the valuation of the shares of DIL."
The petitioners have objected to the valuation by filing IA Nos. 2, 3 and 4 of 2002 wherein a prayer
has been made to submit a supplementary valuation report after adding 'control premium' to 4.91%
shares and by adopting the DCF method of valuation and including therein the value of Vertin and
Colopsa brands. In other words, the main objections are :
1. That the control premium has not been added;
2. the value of the brands Vertin and Colopsa, which according to the petitioners
continued to be the property of DIL, has not been included;
3. discounted cash flow method has not been adopted though it is a generally
accepted method, even according to the Valuer.
The learned senior counsel appearing for the petitioners relying on the decisions in Dean vs. Prince
& Ors. [1954 (1) All ER 749] and Burgess vs. Purchase & Sons [1983 (2) All ER 4] has contended that
notwithstanding the finality attached to the decision of the Valuer, the Court can intervene if the
valuation was made on a fundamentally erroneous basis or a patent mistake has been committed by
the Valuer. Even accepting this principle, we are unable to hold that the valuation is vitiated by a
demonstrably wrong approach or a fundamental error going to the root of the valuation.Dr. Mrs. Renuka Datla vs Solvay Pharmaceutical B.V. & Ors on 30 October, 2003

The first and foremost contention has focused itself on the non addition of control premium. It is
the contention of the petitioners that 4.91 per cent shareholding which the respondents Mr. Vasant
Kumar and another have agreed to purchase is part of the promoters' shareholding of 25% and they
consciously avoided buying the other shares which were acquired by the petitioners from the
market. Certain special rights and privileges were attached to these promoters' shareholding and,
therefore, the intrinsic worth of the shares should have been assessed by adding the control
premium. As already noticed, the Valuer has adverted to the respective contentions in this regard
and indicated the implications of treating or not treating 4.91 per cent shares as part of the
combined shareholding of the promoters. The Valuer rightly refrained from going into this
contentious issue. However, the Court has to necessarily address itself to this issue canvassed before
us. In answering this question, the terms of settlement must be kept uppermost in the mind. It may
be that the respondent Shri Vasant Kumar agreed to purchase only 4.91 per cent shares of the
petitioners on account of these shares forming part of the promoters' shareholding and in that sense
they may have some additional value. But, the Court has to go by the terms of settlement which is
the last word on the subject. The terms do not, either in express terms or by necessary implication,
contemplate the valuation by determining the intrinsic worth of 4.91% shares, having due regard to
their special or distinctive characteristics. The terms of the settlement, as already noticed,
contemplate the valuation of the intrinsic worth of the two companies—DIL and DPIL as going
concerns and the value of 4.91 per cent shareholding by the petitioners has to be worked out on that
basis. As rightly contended by the learned senior counsel for the respondents, if the parties wanted a
special treatment to be given to these shares and a control premium or the like has to be added, it
should have been specifically and expressly mentioned in the terms of settlement. Such an
important aspect would not have been omitted while framing the terms of settlement if the parties
had agreed to the valuation on that basis. What has not been said in the terms of settlement in
specific and clear terms cannot be superimposed by the Court while interpreting the terms of
settlement. The language employed in the terms of settlement which we presume would have been
drafted after obtaining expert legal advice does not even necessarily imply that special weightage in
the form of 'control premium' has to be given to these 4.91 per cent shares. If the petitioners had
insisted on the incorporation of such a provision, it could very well be that the other party or parties
would not have agreed to such stipulation. The Court cannot, therefore, give any direction in regard
to control premium.
The next objection is directed against the non-inclusion of Vertin and Colopsa brands while valuing
the intrinsic worth of the company DIL. In our view, the learned Valuer has given relevant reasons
for non-inclusion of the said brand of drugs which stood transferred to Solvay Pharmaceuticals BV
from Dupen Laboratories Pvt. Ltd. They are not the existing assets of DIL. In fact, the petitioners
have put in issue in one of the suits filed by them the legality of transfer and sought for a declaration
that DIL continues to be the proprietor of the two brands. The petitioners have agreed to withdraw
various suits. In any case, the petitioners cannot be permitted to thwart the terms of the settlement
by inviting the Valuer or this Court to go into the extraneous issue as regards the validity of the
transfer or incidental matters. The assets as per the relevant records have to be taken into account
by the Valuer and that has been done. We, therefore, find no apparent error in excluding those
brands.Dr. Mrs. Renuka Datla vs Solvay Pharmaceutical B.V. & Ors on 30 October, 2003

The other objection is about DCF method of valuation which the Valuer has described as a
commonly accepted method in adopting 'future earning based valuation'. This involves "discounting
the net free cash flow of a business at an appropriate discount rate". We have already adverted to the
reasons given by the Valuer for not adopting this method of valuation. Those reasons cannot be said
to be irrelevant. It is contended that if the data and projections furnished by the parties is not
reliable the Valuer should have secured the relevant data from independent sources or could have
called for further particulars. We find no merit in this argument. The DCF method is adopted while
resorting to valuation based on future earnings. It is not the case of the petitioners that the future
earning based valuation is the only reliable method of 'earnings based valuation'. Moreover, the
petitioners have not placed any facts and figures to show that such method of valuation would result
in a definite increase in the share value going by independent projections. When there are vast
discrepancies between the projection given by the parties and independent projections have not
been provided, the Valuer has chosen the best possible method of evaluation by capitalizing the past
earnings. In doing so, the future maintainable profits based on past performance is also an element
that has gone into the calculation. No prejudice whatsoever is shown to have been caused to the
petitioners by the earnings based valuation.
The petitioners have relied on the decision of this Court in Commissioner of Gift Tax, Bombay Vs.
Smt. Kusumben D. Mahadevia [(1980) 2 SCC 238]. After referring to Mahadeo Jalan's case [(1973) 3
SCC 157] wherein certain principles regarding valuation of shares were laid down, it was observed
thus:
"It is clear from this decision that where the shares in a public limited company are
quoted on the stock exchange and there are dealings in them, the price prevailing on
the valuation date would represent the value of the shares. But where the shares in a
public limited company are not quoted on the stock exchange or the shares are in a
private limited company the proper method of valuation to be adopted would be the
profit-earning method. This method may be applied by taking the dividends as
reflecting the profit-earning capacity of the company on reasonable commercial basis
but if it is found that the dividends do not correctly reflect the profit- earning capacity
because only a small proportion of the profits is distributed by way of dividends and a
large amount of profits is systematically accumulated in the form of reserves, the
dividend method of valuation may be rejected and the valuation may be made by
reference to the profits. The profit-earning method takes into account the profits
which the company has been making and should be capable of making and the
valuation, according to this method is based on the average maintainable profits."
We do not think that the valuation in the instant case runs counter to the principles laid down
therein. As seen from Enclosures 6.1 and 6.2 to the valuation report, the Valuer had arrived at
market based valuation in addition to the other modes of valuation and observed that the
recommended value is the higher of the intrinsic value or the marked based value. Thus, the
petitioners had the benefit of higher valuation. The first principle laid down in the above decision
has been kept in view. Moreover, the profit earning method which has been referred to in the above
decisions in the context of valuation of shares of a private limited Company has also been applied,Dr. Mrs. Renuka Datla vs Solvay Pharmaceutical B.V. & Ors on 30 October, 2003

though future earnings based valuation has not been done in the absence of reliable figures. As
observed by us earlier, the profit earning capacity of the Company has not been excluded from
consideration. Thus, the Valuer's mode of valuation does not in anyway infringe the principles laid
down in the said decisions to the extant they are applicable. In final analysis, we are of the view that
the Valuer approached the question of valuation having due regard to the terms of settlement and
applying the standard methods of valuation. The valuation has been considered from all appropriate
angles. No case has been made out that any irrelevant material has been taken into account or
relevant material has been eschewed from consideration by the Valuer. The plea that the valuation is
vitiated by fundamental errors cannot but be rejected. In the result IA Nos. 2 to 4/2002 are liable to
be rejected. However, there is one direction concerning the interest which we consider it appropriate
to give in the given facts and circumstances of the case. Though the grant of interest, as prayed for
by the petitioners, from 31.05.2002—the stipulated date of submission of valuation report is not
called for, we feel that the ends of justice would be adequately met if the respondents concerned are
directed to pay the interest at the rate of 9 per cent on 8.24 crores, which is the value of shares fixed
by the Valuer, for a period of 12 months. True, the petitioners contested the valuation and thereby
delayed the implementation of settlement. However, having regard to the bona fide nature of the
dispute and the fact that the respondents have retained the money otherwise payable to the
petitioners during this period of 12 months and could have profitably utilized the same, we have
given this direction taking an overall view. In the result IAs 2,3 and 4 of 2002 are dismissed subject
to the above direction as to payment of interest. The SLP(c) Nos. 18035, 18041-18042 of 2002 shall
stand disposed of in terms of the settlement on record coupled with the direction to pay the sum of
Rs. 8.24 crores representing the value of 4.91% shares together with interest @ 9 per cent for a
period of 12 months within a period of four weeks from today subject to the receipt of share transfer
forms and the fulfillment of other formalities by the petitioners. The suits which have given rise to
these SLPs, and other suits and proceedings mentioned in the Memorandum of settlement shall
stand dismissed as withdrawn. Accordingly, the SLPs are disposed of. No order as to costs.Dr. Mrs. Renuka Datla vs Solvay Pharmaceutical B.V. & Ors on 30 October, 2003

