Bhuvaneswari vs State Rep By on 29 September, 2023
Author: M.Sundar
Bench: M.Sundar
                                                                                    H.C.P.No.968 of 2023
                                  IN THE HIGH COURT OF JUDICATURE AT MADRAS
                                                  DATED: 29.09.2023
                                                         Coram
                                      THE HON'BLE MR.JUSTICE M.SUNDAR
                                                     and
                                    THE HON'BLE MR. JUSTICE R.SAKTHIVEL
                                                 H.C.P.No.968 of 2023
                  Bhuvaneswari
                  W/o.Arumugam                                       .. Petitioner/Mother of detenu
                                                            vs
                  State Rep by
                  1.The Secretary to Government,
                    Home, Prohibition and Excise Department,
                    Secretariat,
                    Fort St.George,
                    Chennai – 600 009.
                  2.The Commissioner of Police,
                    Salem City.
                  3.The Superintendent of Prison,
                    Central Prison,
                    Salem.
                  4.The Inspector of Police,
                    Kitchipalayam Police Station,
                    Salem City.                                    .. Respondents
                            Petition filed under Article 226 of the Constitution of India praying for
                  issuance of a writ of habeas corpus to call for the records in
                 1/10
https://www.mhc.tn.gov.in/judis
                                                                                   H.C.P.No.968 of 2023
                  C.M.P.No.37/Goonda/Salem City/2023 dated 15.05.2023 on the file of theBhuvaneswari vs State Rep By on 29 September, 2023

                  Commissioner of Police, Salem City, the second respondent herein and quash
                  the same as illegal and direct the respondents to produce the detenu,
                  Duraisamy @ Monnaiyan, S/o.Arumugam, aged about 22 years, now
                  confined at Central Prison, Salem before this Court and set him at liberty.
                                  For Petitioner       : Ms.S.Sengkodi
                                  For Respondents : Mr.E.Raj Thilak
                                                    Additional Public Prosecutor
                                                         ORDER
[Order of the Court was made by M.SUNDAR, J.] When the captioned 'Habeas Corpus Petition'
(hereinafter 'HCP' for the sake of convenience and clarity) was listed in the Admission Board on
09.06.2023, the following order was made:
M.SUNDAR, J., and K.GOVINDARAJAN THILAKAVADI, J., [Order of the Court was
made by M.SUNDAR. J] Captioned Habeas Corpus Petition has been filed in this
Court on 02.06.2023 inter alia assailing a detention order dated
https://www.mhc.tn.gov.in/judis 15.05.2023 bearing reference
C.M.P.No.37/Goonda/Salem City/2023 made by 'second respondent' [hereinafter
'Detaining Authority' for the sake of convenience and clarity]. To be noted, fourth
respondent is the Sponsoring Authority.
2. To be noted, mother of the detenu is the petitioner.
3. Ms.S.Sengkodi, learned counsel on record for habeas corpus petitioner is before us.
Learned counsel for petitioner submits that ground case qua the detenu is for alleged
offences under Section 147, 148, 341, 294(b) and 307 of 'Indian Penal Code, 1860
(Act 45 of 1860)' ['IPC' for brevity] in Crime No.91 of 2023 on the file of
Kitchipalayam Police Station
4. The aforementioned detention order has been made on the premise that the
detenu is a 'Goonda' under Section 2(f) of 'The Tamil Nadu Prevention of Dangerous
Activities of Bootleggers, Cyber law offenders, Drug-offenders, Forest-
offenders, Goondas, Immoral traffic offenders, Sand-offenders, Sexual-offenders, Slum-grabbers
and Video Pirates Act, 1982 (Tamil Nadu Act No.14 of 1982)' [hereinafter 'Act 14 of 1982' for the
sake of convenience and clarity].
5. The detention order has been assailed inter alia on the ground that family members were not
informed about the detention of the detenu.
6. Prima facie case made out for admission. Admit. Issue Rule nisi returnable by four weeks.Bhuvaneswari vs State Rep By on 29 September, 2023

7. Mr.R.Muniyapparaj, learned Additional Public Prosecutor, State of Tamil Nadu accepts notice for
all respondents. List the captioned Habeas Corpus Petition accordingly.'
https://www.mhc.tn.gov.in/judis
2. The aforementioned 09.06.2023 Admission Board order captures all essentials, i.e., all facts that
are imperative for appreciating the final order and therefore, we are not setting out the facts again in
this final order. Suffice to say that aforementioned Admission Board order shall be read as an
integral part and parcel of this final order. Be that as it may, we are using the short forms, short
references and abbreviations used in the Admission Board order in this order also for the sake of
convenience and clarity.
3. To be noted, 'detention order dated 15.05.2023 bearing reference C.M.P.No.37/Goonda/Salem
City/2023 made by the Detaining Authority' shall hereinafter be referred to as 'impugned preventive
detention order' in this order for the sake of brevity, convenience and clarity.
4.There is one adverse case and one ground case. The ground case which constitutes substantial part
of substratum of the impugned preventive detention order is Crime No.92 of 2023 on the file of
Kitchipalayam Police Station for alleged offences under Sections 341, 395, 397 and 506(ii) of 'The
Indian Penal Code (45 of 1860)' [hereinafter 'IPC' for the sake of convenience
https://www.mhc.tn.gov.in/judis and clarity]. Owing to the nature of the challenge to the impugned
detention order, it is not necessary to delve into the factual matrix or be detained further by facts.
5. Ms.S.Sengkodi, learned counsel on record for petitioner and Mr.E.Raj Thilak, learned State
Additional Public Prosecutor for all respondents are before us.
6. As would be evident from paragraph 5 of the Admission Board order, at the time of admission
learned counsel for petitioner predicated her challenge to the impugned preventive detention order
on the point that family members were not informed about the detention of the detenu, however in
the final hearing board today learned counsel submitted that the detenu was arrested on 03.04.2023
but the impugned preventive detention order has been made only on 15.05.2023 and therefore, live
and proximate link between the grounds and purpose of detention has snapped.
7. Mr.E.Raj Thilak, learned State Additional Public Prosecutor, submits to the contrary by saying
that materials had to be collected /collated and time https://www.mhc.tn.gov.in/judis was
consumed in this exercise. Considering the facts and circumstances of the case and nature of ground
case, we find that this explanation of learned Prosecutor is unacceptable.
8. We remind ourselves of Sushanta Kumar Banik's case [Sushanta Kumar Banik Vs. State of
Tripura & others reported in 2022 LiveLaw (SC) 813 : 2022 SCC OnLine SC 1333]. To be noted,
Banik case law arose under 'Prevention of Illicit Traffic in Narcotic Drugs and Psychotropic
Substances Act, 1988' [hereinafter 'PIT NDPS Act' for the sake of brevity] in Tirupura, wherein after
considering the proposal by the Sponsoring Authority and after noticing the trajectory the matter
took, Hon'ble Supreme Court held that the 'live and proximate link between grounds of detention
and purpose of detention snapping' point should be examined on a case to case basis. Hon'bleBhuvaneswari vs State Rep By on 29 September, 2023

Supreme Court has held in Banik case law that this point has two facets. One facet is 'unreasonable
delay' and other facet is 'unexplained delay'. We find that the captioned matter falls under latter
facet i.e., unexplained delay.
https://www.mhc.tn.gov.in/judis
9. To be noted, Banik case has been respectfully followed by this Court in Gomathi Vs.The Principal
Secretary to Government and others reported vide Neutral Citation of Madras High Court being
2023/MHC/334, Sadik Basha Yusuf Vs. The State of Tamil Nadu and others reported vide Neutral
Citation of Madras High Court being 2023/MHC/733, Sangeetha Vs. The Secretary to the
Government and others reported vide Neutral Citation of Madras High Court being
2023:MHC:1110, N.Anitha Vs. The Secretary to Government and others reported vide Neutral
Citation of Madras High Court being 2023:MHC:1159 and a series of other orders in HCP cases.
10. Besides ground case, one adverse case has been referred to in the grounds of impugned
preventive detention order. The adverse case is Crime No.91 of 2023 on the file of Kitchipalayam
Police Station, Salem City (occurrence was on 02.04.2023) and therefore, the delay remains
unexplained.
11. Before concluding, we also remind ourselves that preventive detention is not a punishment and
HCP is a high prerogative writ. https://www.mhc.tn.gov.in/judis
12. Apropos, the sequitur is, captioned HCP is allowed. Impugned detention order dated 15.05.2023
bearing reference C.M.P.No.37/Goonda/Salem City/2023 made by the second respondent is set
aside and the detenu Thiru.Duraisamy @ Monnaiyan, S/o.Thiru.Arumugam, aged about 22 years, is
directed to be set at liberty forthwith, if not required in connection with any other case / cases.
There shall be no order as to costs.
(M.S.,J.) (R.S.V.,J.) 29.09.2023 Index : Yes Neutral Citation : Yes Speaking order rsi P.S: Registry to
forthwith communicate this order to Jail authorities in Central Prison, Salem.
https://www.mhc.tn.gov.in/judis To
1.The Secretary to Government Home, Prohibition and Excise Department, Secretariat, Fort
St.George, Chennai – 600 009.
2.The Commissioner of Police, Salem City.
3.The Superintendent of Prison, Central Prison, Salem.
4.The Inspector of Police, Kitchipalayam Police Station, Salem City.
5.The Public Prosecutor High Court, Madras.Bhuvaneswari vs State Rep By on 29 September, 2023

https://www.mhc.tn.gov.in/judis M.SUNDAR, J.
and R.SAKTHIVEL, J.
rsi 29.09.2023 https://www.mhc.tn.gov.in/judisBhuvaneswari vs State Rep By on 29 September, 2023

