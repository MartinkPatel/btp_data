Exe.Engr.Road Dev.Division No.Iii & ... vs Atlanta Ltd on 16
January, 2014
Equivalent citations: AIR 2014 SUPREME COURT 1093
Author: Jagdish Singh Khehar
Bench: Jagdish Singh Khehar, A.K. Patnaik
                                                                “REPORTABLE”
                        IN THE SUPREME COURT OF INDIA
                        CIVIL APPELLATE JURISDICTION
                        CIVIL APPEAL NO. 673  OF 2014
                  (Arising out of SLP (C) No.18980 of 2013)
Executive Engineer, Road Development
Division No.III, Panvel & Anr.                                … Appellants
                                   Versus
Atlanta Limited                                          … Respondent
                               J U D G M E N T
Jagdish Singh Khehar, J.
1. State of Maharashtra, through its Public Works Department, awarded a contract dated 12.7.2000
to the respondent-Atlanta Limited (a public limited company) for the construction of the Mumbra
byepass. On 11.5.2005, a supplementary agreement for additional work was executed between the
parties. It would be relevant to mention, that the Mumbra byepass falls on National highway no. 4.
The construction envisaged in the contract awarded to the respondent-Atlanta Limited was, from
kilometer 133/800 to kilometer 138/200. The contract under reference envisaged, settlement of
disputes between the parties, through arbitration. Atlanta Limited raised some disputes through a
communication dated 1.10.2009. It also invoked the arbitration clause for resolution of the said
disputes. The State of Maharashtra as also Atlanta Limited nominated their respective arbitrators,
who in turn, appointed the presiding arbitrator. On the culmination of proceedings before the
arbitral tribunal, an award was rendered on 12.5.2012. Almost all the claims raised by Atlanta
Limited were granted. In sum and substance, Atlanta Limited was awarded a sum of
Rs.58,59,31,595/- along with the contracted rate of interest (of 20 per cent per annum), with effect
from 1.10.2009. Atlanta Limited was also awarded a sum of Rs.41,00,000/- towards costs. All the
counter claims raised by the State of Maharashtra, before the arbitral tribunal, were simultaneouslyExe.Engr.Road Dev.Division No.Iii & ... vs Atlanta Ltd on 16 January, 2014

rejected.
2. On 7.8.2012, the State of Maharashtra moved Miscellaneous Application no. 229 of 2012 and
Miscellaneous Application no. 230 of 2012 under Section 34 of the Arbitration and Conciliation Act,
1996 (hereinafter referred to as the ‘Arbitration Act’) before the District Judge, Thane. The State of
Maharashtra through the aforesaid Miscellaneous Applications sought quashing and setting aside of
the arbitral award dated 12.5.2012.
3. On the same day, i.e., 7.8.2012, Atlanta Limited filed Arbitration Petition no.1158 of 2012 before
the High Court of Judicature at Bombay (hereinafter referred to as the ‘High Court’), for the setting
aside of some of the directions issued by the arbitral tribunal (in its award dated 12.5.2012). Atlanta
Limited also claimed further compensation, which according to the respondent, had wrongfully not
been considered by the arbitral tribunal.
4. A perusal of the averments made in the foregoing two paragraphs reveal, that on the same day i.e.,
on 7.8.2012, the State of Maharashtra as also Atlanta Limited questioned the award of the arbitral
tribunal dated 12.5.2012. Whilst the State of Maharashtra questioned the same before the District
Judge, Thane; Atlanta Limited raised its challenge before the High Court. Since the same award
dated 12.5.2012 was subject matter of challenge before two different courts, Atlanta Limited
preferred Miscellaneous Civil Application no. 162 of 2012 under Section 24 of the Code of Civil
Procedure, 1908 praying for transfer of Miscellaneous Application no. 229 of 2012, as also,
Miscellaneous Application No.230 of 2012 (both filed by the State of Maharashtra) before the
District Court, Thane, to the original side of the High Court, for being heard along with Arbitration
Petition No.1158 of 2012. The aforestated Miscellaneous Civil Application No.162 of 2012 was
allowed by the High Court on 15.3.2013. The operative part of the order passed by the High Court is
being extracted hereunder:
“32. In the light of the above conclusion, the argument that this Court can only direct
consolidation of both Petitions without passing any order with regard to their
transfer, need not be considered in this case. Apart therefrom, once I find that the
Respondents have no objection to consolidation of the proceedings so as to avoid
conflicting decisions or simultaneous trial/hearing, then, all the more, the powers to
transfer needs to be exercised in this case. It is undisputed that the parties are
common to both matters. In both matters the same Award is under scrutiny. In such
circumstances, the argument that both Petitions need to be consolidated but before
the District Court at Thane cannot be accepted. That would mean two Courts render
decisions and more or less on the same issue and may be at the same time. The
arbitration petition filed by the Petitioners in this Court is already placed before the
Single Judge of this Court and is now adjourned. It would be proper if the
proceedings before the District Court, Thane are brought and are heard along with
the Petition filed by the Petitioners in this Court.
33. As a result of the above discussion, this application succeeds.Exe.Engr.Road Dev.Division No.Iii & ... vs Atlanta Ltd on 16 January, 2014

It is made absolute in terms of prayer clause (a) with no order as to costs.” The above determination
by the High Court, vide its order dated 15.3.2013, is the subject matter of challenge through Special
leave Petition (C) No.18980 of 2013.
5. Leave granted.
6. The contention advanced at the hands of the learned counsel for the State of Maharashtra, while
assailing the impugned order of the High Court dated 15.3.2013 was, that it was improper for the
High Court to transfer the proceedings initiated by the appellant through Miscellaneous Application
No.229 of 2012 and Miscellaneous Application No.230 of 2012 under Section 34 of the Arbitration
Act before the Court of the District Judge, Thane to the High Court. In this behalf, the pointed
submission of the learned counsel for the appellant was, that only the District Judge, Thane, had the
jurisdiction to determine the controversy emerging out of the award of the arbitral tribunal dated
12.5.2012. It was also submitted, that the proceedings initiated by Atlanta Limited through
Arbitration Petition no. 1158 of 2012, ought to have been transferred from the High Court to the
District Judge, Thane. In order to make good the aforesaid submission, learned counsel for the
appellant placed reliance on the definition of the term “Court” expressed in Section 2(1)(e) of the
Arbitration Act. Section 2(1)(e) aforementioned is being reproduced hereunder :
“2 – Definitions— (1) In this Part, unless the context otherwise requires,—
(e) "Court" means the principal Civil Court of original jurisdiction in a district, and
includes the High Court in exercise of its ordinary original civil jurisdiction, having
jurisdiction to decide the questions forming the subject-matter of the arbitration if
the same had been the subject-matter of a suit, but does not include any civil court of
a grade inferior to such principal Civil Court, or any Court of Small Causes.” Drawing
the court’s pointed attention to the definition of the term “Court”, it was the
vehement contention of the learned counsel for the appellant, that to determine
which court would have jurisdiction to decide the subject matter of an arbitral
dispute, it was essential to find out the particular court which would have had
jurisdiction in the matter, had the dispute been agitated through a civil suit.
According to learned counsel, the latter determination, would answer the
jurisdictional avenue of the arbitral dispute, in terms of Section 2(1)(e) extracted
above. In this behalf it was submitted, that in the absence of any express exclusion
clause between the parties, on the subject matter under reference, in order to settle
the dispute inter-parties, it would have been imperative for the parties to raise their
respective challenges only before the District Judge, Thane.
7. For the above submission, learned counsel also placed reliance on Section 16 of the Code of Civil
Procedure. Section 16, according to learned counsel, would be relevant to determine the
jurisdictional court, if the dispute had been agitated through a civil suit. Section 16 aforementioned
is being extracted hereunder:Exe.Engr.Road Dev.Division No.Iii & ... vs Atlanta Ltd on 16 January, 2014

“16. Suits to be instituted where subject-matter situate.—Subject to the pecuniary or
other limitations prescribed by any law, suits,--
(a) for the recovery of immovable property with or without rent or profits,
(b) for the partition of immovable property,
(c) for foreclosure, sale or redemption in the case of a mortgage of or charge upon
immovable property,
(d) for the determination of any other right to or interest in immovable property,
(e) for compensation for wrong to immovable property,
(f) for the recovery of movable property actually under distraint or attachment, shall
be instituted in the Court within the local limits of whose jurisdiction the property is
situate:
Provided that a suit to obtain relief respecting, or compensation for wrong to,
immovable properly held by or on behalf of the defendant may, where the relief
sought can be entirely obtained through hi s personal obedience, be instituted either
in the Court within the local limits of whose jurisdiction the property is situate, or in
the Court within the local limits of whose jurisdiction the defendant actually and
voluntarily resides, or carries on business, or personally works for gain.
Explanation .--In this section "property" means property situate in India.” Relying on
Section 16 extracted above, it was asserted by learned counsel, that the original
agreement between the parties dated 12.7.2000, and the supplementary agreement
dated 11.5.2005, related to the construction of the Mumbra byepass. The said
construction is from Kilometer 133/800 to Kilometer 138/200. The aforesaid
location of construction, according to the undisputed position between the parties, is
within Thane District, and as such, within the territorial jurisdiction of the Sessions
Division, Thane. Therefore, according to learned counsel for the appellant, only the
“principal civil court of original jurisdiction” in District Thane i.e., the District Judge,
Thane, would have jurisdiction in the matter. It was also the submission of the
learned counsel for the appellant, that the toll stations for collecting toll constructed
by the respondent-Atlanta Limited, are also located at the venue of the Mumbra
byepass. Thus viewed, according to the learned counsel for the appellant, the
collection of toll (which inter alia constitutes the subject of dispute, between the
parties) is also carried on by the respondents within District Thane, i.e., within the
territorial jurisdiction of the District Judge, Thane. Based on Section 16 of the Code
of Civil Procedure, and more particularly of clauseExe.Engr.Road Dev.Division No.Iii & ... vs Atlanta Ltd on 16 January, 2014

(d) thereof, it was the pointed submission of the learned counsel for the appellant,
that only the District Judge, Thane has the jurisdiction to entertain an arbitral
dispute, arising between the rival parties to the present appeal.
8. In order to further support his contention, that the District Judge, Thane alone would have
jurisdiction in the matter, learned counsel for the appellant, also placed emphatic reliance on
Section 20 of the Code of Civil Procedure which is being reproduced hereunder:
“20. Other suits to be instituted where defendants reside or cause of action
arises.—Subject to the limitations aforesaid, every suit shall be instituted in a Court
within the local limits of whose jurisdiction
--
(a) the defendant, or each of the defendants where there are more than one, at the
time of the commencement of the suit, actually and voluntarily resides, or carries on
business, or personally works for gain; or
(b) any of the defendants, where there are more than one, at the time of the
commencement of the suit, actually and voluntarily resides, or carries on business, or
personally works for gain, provided that in such case either the leave of the Court is
given, or the defendants who do not reside, or carry or business, or personally work
for gain, as aforesaid, acquiesce in such institution ; or
(c) the cause of action, wholly or in part, arises.
Explanation .--A corporation shall be deemed to carry on business at its sole or principal office in
India or, in respect of any cause of action arising at any place where it has also a subordinate office,
at such place.
Illustrations
(a) A is a tradesman in Calcutta, B carries on business in Delhi. B , by his agent in Calcutta, buys
goods of A and requests A to deliver them to the East Indian Railway Company. A delivers the goods
accordingly in Calcutta. A may sue B for the price of the goods either in Calcutta, where the cause of
action has arisen or in Delhi, where B carries on business.
(b) A resides at Simla, B at Calcutta and C at Delhi, A, B and C being together at Benaras, B and C
make a joint promissory note payable on demand, and deliver it to A. A may sue B and C at Benaras,
where the cause of action arose. He may also sue them at Calcutta, where B resides, or at Delhi,
where C resides; but in each of these cases, if the non-resident defendant objects, the suit cannot
proceed without the leave of the Court.” Relying on the above provision, it was asserted, that a
reading of Section 20 of the Code of Civil Procedure shows, that a preference has been postulated for
certain provisions including Section 16 of the Code of Civil Procedure, which was evident from theExe.Engr.Road Dev.Division No.Iii & ... vs Atlanta Ltd on 16 January, 2014

opening words of Section 20 of the Code of Civil Procedure, which clearly denoted, that the issue of
jurisdiction expressed in Section 20 of the Code of Civil Procedure, would be subject to the
overriding effect in the matter of jurisdiction, expressed in the provisions preceding Section 20 (i.e.
including Section
16).
9. Learned counsel for the respondent-Atlanta Limited, however, strongly opposed the submissions
advanced at the hands of the learned counsel for the appellant, on the issue of jurisdiction. In this
behalf, learned counsel for the respondent invited our attention to the reply affidavit filed on behalf
of the State of Maharashtra, to Miscellaneous Civil Application No.162 of 2012 (filed by Atlanta
Limited before the High Court), para 8 of the reply affidavit which was pointedly brought to our
notice is being extracted hereunder :
“8. In fact it is an admitted position and common ground that both; this Hon’ble
Court and the District Court at Thane have jurisdiction in respect of the
subject-matter in issue. Peculiarly this Hon’ble Court falls within the definition of the
term “Court” under Section 2(e) of the Arbitration Act by virtue of being a High Court
in the Mumbai District having Original Jurisdiction, and on the other hand the
District Court at Thane being the Principal Civil Court of original jurisdiction in the
Thane District also falls within the same definition.” (emphasis is ours) In view of the
stand adopted in writing by the appellants, in response Miscellaneous Civil
Application no. 162 of 2012, it was sought to be asserted, that the appellants had no
right to raise the issue of jurisdiction before this Court.
10. Despite the objection noticed in the aforegoing paragraphs, it was the vehement contention of
the learned counsel for the respondent, that the High Court and not the District Judge, Thane, had
the jurisdiction to adjudicate the controversy raised by the rival parties with reference to the award
of the arbitral tribunal dated 12.5.2012. In order to make good the aforesaid submission, it was
asserted, that the contractual agreement dated 12.7.2000, as also, the supplementary agreement
dated 11.5.2005, were executed at Mumbai. Additionally, it was submitted that the parties had
mutually agreed, that the seat of arbitration in case of any disputes arising between the parties,
would be at Mumbai. Relying on the aforesaid undisputed factual position, learned counsel for the
respondent invited our attention to the determination rendered by this Court in Bharat Aluminium
Company & Ors. vs. Kaiser Aluminium Technical Services Inc & Ors. (2012) 9 SCC 559, and made
pointed reliance to the following observations recorded therein:
“96. xxx xxx xxx xxx We are of the opinion, the term "subject matter of the arbitration"
cannot be confused with "subject matter of the suit". The term "subject matter" in
Section 2(1)(e) is confined to Part I. It has a reference and connection with the
process of dispute resolution. Its purpose is to identify the courts having supervisory
control over the arbitration proceedings. Hence, it refers to a court which would
essentially be a court of the seat of the arbitration process. In our opinion, theExe.Engr.Road Dev.Division No.Iii & ... vs Atlanta Ltd on 16 January, 2014

provision in Section 2(1)(e) has to be construed keeping in view the provisions in
Section 20 which give recognition to party autonomy. Accepting the narrow
construction as projected by the Learned Counsel for the Appellants would, in fact,
render Section 20 nugatory. In our view, the legislature has intentionally given
jurisdiction to two courts i.e. the court which would have jurisdiction where the cause
of action is located and the courts where the arbitration takes place. This was
necessary as on many occasions the agreement may provide for a seat of arbitration
at a place which would be neutral to both the parties. Therefore, the courts where the
arbitration takes place would be required to exercise supervisory control over the
arbitral process. For example, if the arbitration is held in Delhi, where neither of the
parties are from Delhi, (Delhi having been chosen as a neutral place as between a
party from Mumbai and the other from Kolkata) and the tribunal sitting in Delhi
passes an interim order Under Section 17 of the Arbitration Act, 1996, the appeal
against such an interim order under Section 37 must lie to the Courts of Delhi being
the Courts having supervisory jurisdiction over the arbitration proceedings and the
tribunal. This would be irrespective of the fact that the obligations to be performed
under the contract were to be performed either at Mumbai or at Kolkata, and only
arbitration is to take place in Delhi. In such circumstances, both the Courts would
have jurisdiction, i.e., the Court within whose jurisdiction the subject matter of the
suit is situated and the courts within the jurisdiction of which the dispute resolution,
i.e., arbitration is located.
97. The definition of Section 2(1)(e) includes "subject matter of the arbitration" to
give jurisdiction to the courts where the arbitration takes place, which otherwise
would not exist. On the other hand, Section 47 which is in Part II of the Arbitration
Act, 1996 dealing with enforcement of certain foreign awards has defined the term
"court" as a court having jurisdiction over the subject-matter of the award. This has a
clear reference to a court within whose jurisdiction the asset/person is located,
against which/whom the enforcement of the international arbitral award is sought.
The provisions contained in Section 2(1)(e) being purely jurisdictional in nature can
have no relevance to the question whether Part I applies to arbitrations which take
place outside India.
98. We now come to Section 20, which is as under:
“20. Place of arbitration—(1) The parties are free to agree on the place of arbitration.
(2) Failing any agreement referred to in Sub-section (1), the place of arbitration shall
be determined by the arbitral tribunal having regard to the circumstances of the case,
including the convenience of the parties.
(3) Notwithstanding Sub-section (1) or Sub-section (2), the arbitral tribunal may,
unless otherwise agreed by the parties, meet at any place it considers appropriate for
consultation among its members, for hearing witnesses, experts or the parties, or forExe.Engr.Road Dev.Division No.Iii & ... vs Atlanta Ltd on 16 January, 2014

inspection of documents, good or other property."
A plain reading of Section 20 leaves no room for doubt that where the place of arbitration is in
India, the parties are free to agree to any "place" or "seat" within India, be it Delhi, Mumbai etc. In
the absence of the parties' agreement thereto, Section 20(2) authorizes the tribunal to determine the
place/seat of such arbitration. Section 20(3) enables the tribunal to meet at any place for conducting
hearings at a place of convenience in matters such as consultations among its members for hearing
witnesses, experts or the parties.” (emphasis is ours)
11. We have heard learned counsel for the parties.
12. We have recorded hereinabove the foundation, on the basis whereof, the present controversy was
adjudicated before the High Court. As noticed above, the challenge to the impugned order passed by
the High Court, is based on the question of jurisdiction. While the learned counsel for the appellants
has placed reliance on Section 2(1)(e) of the Arbitration Act read with the provisions of Code of Civil
Procedure to contend, that the District Judge, Thane, alone would have the jurisdiction in the
matter; the contention raised on behalf of the respondent is, that the High Court alone in exercise of
its “ordinary original civil jurisdiction”, has the jurisdiction to determine the controversy arising out
of the impugned award dated 12.5.2012.
13. In our view, it is not open to the appellants to advance such submission before this Court. Firstly,
because the appellants had in paragraph 8 of the reply affidavit filed before the High Court, clearly
acknowledged the legal position, that both the High Court as also the District Judge, Thane, in so far
as the present controversy is concerned, fall within the definition of the term “Court” under Section
2(1)(e) of the Arbitration Act. And secondly, because the impugned order passed by the High Court
expressly notices in paragraph 10, that it was admitted by the rival parties before the High Court,
that the High Court on the original side, as also the District Judge, Thane, had the jurisdiction in
respect of the subject matter. Relevant part of para 10 of the impugned judgment of the High Court
is being extracted hereunder:-
“10. Mr. Vashi, learned counsel appearing on behalf of the Petitioner submitted that
in the Affidavit-in-Reply which has been filed in this petition, it is admitted by the
Respondents that the place of arbitration in terms of the arbitration clause in the
contract was Mumbai. It is also admitted that both, this Court on the Original Side
and the District Court at Thane have jurisdiction in respect of the subject matter in
issue.” (emphasis is ours) It was therefore not open to the appellants to canvass
before this Court that the High Court of Bombay in exercise of its “ordinary original
civil jurisdiction” could not adjudicate upon the present controversy, on account of
lack of jurisdiction. We shall therefore proceed in the first instance, on the premise
that both the courts referred to above had jurisdiction in the matter. We shall
independently record our reasons for the same, while dealing with the submissions
advanced before us. We have chosen to do so, because we are of the view, that an
important jurisdictional issue has been raised, which needs to be settled, one way or
the other. We shall therefore, decide the controversy on merits, irrespective of theExe.Engr.Road Dev.Division No.Iii & ... vs Atlanta Ltd on 16 January, 2014

position expressed by the appellant, on the issue of jurisdiction.
14. During the course of hearing before us, learned counsel for the appellant had highlighted for our
consideration, the factual/legal controversy which was agitated by the rival parties before the High
Court. In this behalf it was further pointed out, firstly, that the respondent’s case before the High
Court was, that since the arbitral tribunal had its seat at Mumbai, and the works contract was
executed at Mumbai, the original side of the High Court of Bombay was competent to entertain the
controversy. On the other hand, the appellants before the High Court had pointed out, that since the
works contract relating to the construction and maintenance of the Mumbra byepass on the
Mumbai-Pune road (located on national highway no. 4), and the toll collection site were situated
within Thane District, the District Judge, Thane, was the “more suitable” court for determining the
controversies raised by the rival parties. Secondly, it was pointed out, that before the High Court an
application under Section 24 of the Code of Civil Procedure was filed in the matter pending before
the High Court, for transfer of proceedings filed by the respondents. It was submitted, that through
the above application, it was not open to the High Court to have transferred the proceedings
pending before the District Judge, Thane. It was further pointed out, that before the High Court the
appellants had orally submitted, that if the High Court was inclined to invoke its jurisdiction under
Section 24 of the Code of Civil Procedure, the proceedings filed by the respondent before the High
Court should have been transferred to the District Judge, Thane, and not the other way around.
According to the learned counsel, the instant submission has been duly noticed in the impugned
judgment. Lastly, it was contended, that Section 24 of the Code of Civil Procedure could not be
invoked in a petition filed under Section 34 of the Arbitration Act, and therefore, Section 24 of the
Code of Civil Procedure ought not to have been relied upon by the High Court for transferring the
proceedings from the Court of District Judge, Thane, to the High Court of Bombay.
15. The following submissions were advanced before us. Firstly, considering clause (c) of the
operative part of the award, according to learned counsel it was clear, that enforcement of such a
clause in the award was site-specific, since Mumbra byepass is located on the Mumbai-Pune road
(on national highway no. 4) and falls in Thane District, the District Judge, Thane, ought to be
“natural choice” for consideration of the issues advanced by the appellants, as also the respondent.
Secondly, according to the learned counsel for the appellants, the definition of the term “Court”
expressed in Section 2(1)(e) of the Arbitration Act uses the expression “subject matter” and not
“cause of action”. While “cause of action” can be referable to places where the works contract is
executed, or where arbitration proceedings were conducted; the term “subject matter” used in
Section 2(1)(e) of the Arbitration Act is only referable to the subject matter of the works contract,
with respect to which the dispute is raised (with respect to which, there was a direction for extension
of the concession period, under the award). Accordingly it was submitted, that although the High
Court may also have jurisdiction, the District Court Thane is “more natural”, “more suitable” and
“more appropriate” for the adjudication of the claims, raised by the rival parties. Thirdly it was
contended, that the original side of the High Court of Bombay, vis-à-vis, the District Judge, Thane,
is a “superior” Court. According to the learned counsel for the appellants, even if it is acknowledged
that the “ordinary original civil side” of the High Court of Bombay as also the “principal Civil Court
of original jurisdiction” for the District Thane i.e., the District Judge, Thane, both have jurisdiction
in the matter, there were many attributes on the basis of which it could be clearly established, thatExe.Engr.Road Dev.Division No.Iii & ... vs Atlanta Ltd on 16 January, 2014

the original side of the High Court of Bombay, is superior to the Court of the District Judge, Thane.
In this behalf it was sought to be pointed out, that the High Court could take cognizance of contempt
of its own orders, and furthermore, a judgment delivered by the original side of a High Court
operated as a binding precedent. It was submitted, that the District Court, Thane, does not have any
such attributes. In the above view of the matter it was submitted, that reliance could be placed on
Section 15 of the Code of Civil Procedure, to determine which of the two courts should adjudicate
upon the matter. Section 15 is being extracted hereunder:-
“15. Court in which suits to be instituted-
Every suit shall be instituted in the Court of the lowest grade competent to try it.”
Based on Section 15 extracted above it was submitted, that in case jurisdiction could
be exercised by two Courts, it was imperative to choose the Court of the lowest grade
competent to try the suit. Accordingly, it was contended, that from amongst the
original side of the High Court of Bombay and the District Court, Thane, in terms of
the mandate of Section 15 of the Code of Civil Procedure, the District Court, Thane,
being the Court lower in grade than the original side of the High Court of Bombay,
ought to have been chosen to adjudicate upon the matters. It was also pointed out,
that the choice of District Court, Thane, would even otherwise be beneficial to the
rival parties on account of the fact, that the determination by the said Court, would be
open for re-examination before the High Court of Bombay, which exercises
supervisory jurisdiction over it.
16. Additionally, it was contended, that the choice would fall in favour of the District Judge, Thane,
even on account of the likely expeditious disposal of the matter by the District Judge, Thane, in
comparison with the “original side of the High Court of Bombay”. In this behalf it was submitted,
that there were only 42 petitions filed under Section 34 of the Arbitration Act before the District
Judge, Thane, during the entire year 2012, whereas, there were 1317 petitions filed under Section 34
before the High Court of Bombay, under its “ordinary original civil jurisdiction”, during the year
2012. Referring to the preceding three years, namely, 2009, 2010 and 2011 it was submitted,
whereas a very few petitions were filed under Section 34 of the Arbitration Act before the District
Judge, Thane, as many as, 1033, 1443 and 1081 petitions respectively (were filed under Section 34 of
the Arbitration Act) were filed during the three years before the High Court of Bombay. Based on the
above factual position it was submitted, that it could be expected that the District Judge, Thane,
would dispose of the matters under reference within a short period of about five years, whereas it
was likely that the disposal of the said matters will take more than two decades if the matters are
required to be adjudicated by the original side of the High Court of Bombay. On the instant aspect of
the matter also, referring to available data it was submitted, that it takes more than 20 years for a
suit to be heard and decided by the High Court of Bombay under its “ordinary original civil
jurisdiction”, whereas, it does not take more than 5 years for a suit filed before the District Judge,
Thane, to be disposed of. Accordingly it was contended, that keeping in view the burden of litigation,
the “natural choice” for adjudication of the matters under reference ought to be the District Judge,
Thane, rather than the High Court of Bombay.Exe.Engr.Road Dev.Division No.Iii & ... vs Atlanta Ltd on 16 January, 2014

17. Besides the above submissions, no other contention was advanced before us.
18. We shall first endeavour to address the submissions advanced at the hands of the learned
counsel for the appellants, with reference to Section 15 of the Code of Civil Procedure. In terms of
the mandate of Section 15 of the Code of Civil Procedure, the initiation of action within the
jurisdiction of Greater Mumbai had to be “in the Court of lowest grade competent to try it”. We are,
however, satisfied, that within the area of jurisdiction of Principal District Judge, Greater Mumbai,
only the High Court of Bombay was exclusively the competent Court (under its “ordinary original
civil jurisdiction”) to adjudicate upon the matter. The above conclusion is imperative from the
definition of the term “Court” in Section 2(1)(e) of the Arbitration Act. Firstly, the very inclusion of
the High Court “in exercise of its ordinary original civil jurisdiction, within the definition of the term
“Court”, will be rendered nugatory, if the above conclusion was not to be accepted. Because, the
“principal Civil Court of original jurisdiction in a district” namely the District Judge concerned,
being a court lower in grade than the High Court, the District Judge concerned would always
exclude the High Court from adjudicating upon the matter. The submission advanced by the learned
counsel for the appellant cannot therefore be accepted, also to ensure the inclusion of “the High
Court in exercise of its ordinary original civil jurisdiction” is given its due meaning. Accordingly, the
principle enshrined in Section 15 of the Code of Civil Procedure cannot be invoked whilst
interpreting Section 2(1)(e) of the Arbitration Act. Secondly, the provisions of the Arbitration Act,
leave no room for any doubt, that it is the superior most court exercising original civil jurisdiction,
which had been chosen to adjudicate disputes arising out of arbitration agreements, arbitral
proceedings and arbitral awards. Undoubtedly, a “principal Civil Court of original jurisdiction in a
district”, is the superior most court exercising original civil jurisdiction in the district over which its
jurisdiction extends. It is clear, that Section 2(1)(e) of the Arbitration Act having vested jurisdiction
in the “principal Civil Court of original jurisdiction in a district”, did not rest the choice of
jurisdiction on courts subordinate to that of the District Judge. Likewise, “the High Court in exercise
of its ordinary original jurisdiction”, is the superior most court exercising original civil jurisdiction,
within the ambit of its original civil jurisdiction. On the same analogy and for the same reasons, the
choice of jurisdiction, will clearly fall in the realm of the High Court, wherever a High Court
exercises “ordinary original civil jurisdiction”. Under the Arbitration Act, therefore, the legislature
has clearly expressed a legislative intent, different from the one expressed in Section 15 of the Code
of Civil Procedure. The respondent had chosen to initiate proceedings within the area of Greater
Mumbai, it could have done so only before the High Court of Bombay. There was no other court
within the jurisdiction of Greater Mumbai, where the respondent could have raised their challenge.
Consequently, we have no hesitation in concluding, that the respondent by initiating proceedings
under Section 34 of the Arbitration Act, before the original side of the High Court of Bombay, had
not violated the mandate of Section 2(1)(e) of the Arbitration Act. Thus viewed, we find the
submission advanced at the hands of the learned counsel for the appellants, by placing reliance on
Section 15 of the Code of Civil Procedure, wholly irrelevant.
19. Reliance placed on Section 16 of the Code of Civil Procedure, by the learned counsel for the
appellants, for the ouster the jurisdiction of the High Court of Bombay is equally misplaced. All that
needs to be stated while dealing with the aforesaid contention is, that the controversy between the
parties does not pertain to recovery of immoveable property, partition of immoveable property,Exe.Engr.Road Dev.Division No.Iii & ... vs Atlanta Ltd on 16 January, 2014

foreclosure sale or redemption of immoveable property, determination of any other right to
immoveable property, for determination of compensation for wrong to immoveable property and/or
for the recovery of moveable property under distraint or attachment. It is only in the aforesaid
exigencies that Section 16 of the Code of Civil Procedure could have been invoked. The construction
of the Mumbra byepass, would only entitle Atlanta Limited to payments contemplated under the
contract dated 12.7.2007, and no more. A brief description of the reliefs sought by the rival parties,
in the separate proceedings initiated by them, does not indicate that either of the parties were
claiming any right to or interest in any immovable property. Since none of the above exigencies
contemplated in Section 16 prevail in the dispute between the rival parties, reliance on Section 16 of
the Code of Civil Procedure is clearly misplaced.
20. Insofar as the jurisdiction within the District Thane, is concerned, the “principal Civil Court of
original jurisdiction” is the court of the District Judge, Thane. Consequently, within the territorial
jurisdiction of District Thane, in terms of Section 2(1)(e) of the Arbitration Act, the challenge could
have only been raised before the “principal Civil Court of original jurisdiction” of the district,
namely, before the District Judge, Thane. There was no other court within the jurisdiction of District
Thane, wherein the instant matters could have been agitated. Therefore, the appellants having
chosen to initiate the proceedings before the District Judge, Thane, i.e., in respect of a cause of
action falling in the territorial jurisdiction of the District Thane, they too must be deemed to have
chosen the rightful court i.e., the District Judge, Thane.
21. Shorn of the aforesaid determination, our only understanding of the submission advanced at the
hands of the learned counsel for the appellants would be, that as a matter of “natural choice”, as a
matter of “suitable choice”, as also, as a matter of “more appropriate choice”, the controversies
raised by the rival parties ought to be collectively determined by the District Court, Thane, and not
by the High Court of Bombay (in exercise of its “ordinary original civil jurisdiction”). In order to
supplement the aforesaid contention, learned counsel for the appellant had depicted the quantum of
filing of similar petitions before the High Court, as also, before the District Court Thane, and the
time likely to be taken for the disposal of such matters by the Courts under reference. There is no
statutory provision to our knowledge, wherein the determination of jurisdiction, is based on such
considerations. No such provision was brought to our notice by learned counsel. The question of
jurisdiction, is a pure question of law, and needs to be adjudicated only on the basis of statutory
provisions. In view of the deliberations recorded hereinabove, it may not be wrong to observe, that
the submissions advanced at the behest of the learned counsel for the appellants on the issue of
jurisdiction, are submissions without reference to any principles known to law. To the credit of the
learned counsel for the appellants, it may however be observed, that the above considerations may
constitute a relevant basis for transfer of proceedings from one court to the other. Before the above
considerations can be examined, there would be one pre- condition, namely, that the above
considerations could be applied for transfer of a case, where statutory provisions (express or
implied) do not provide for the exercise of a definite choice. As a matter of expressing ourselves
clearly, it may be stated, that inference of legislative intent from statutory provisions, would exclude
from the realm of consideration, submissions of the nature relied upon by the learned counsel for
the appellant.Exe.Engr.Road Dev.Division No.Iii & ... vs Atlanta Ltd on 16 January, 2014

22. The first issue which needs to be examined is, whether a challenge to an arbitration award (or
arbitral agreement, or arbitral proceeding), wherein jurisdiction lies with more than one court, can
be permitted to proceed simultaneously in two different courts. For the above determination, it is
necessary to make a reference to Section 42 of the Arbitration Act. The aforesaid provision
accordingly is being extracted hereunder:
“42. Jurisdiction - Notwithstanding anything contained elsewhere in this Part or in
any other law for the time being in force, where with respect to an arbitration
agreement any application under this Part has been made in a Court, that Court alone
shall have jurisdiction over the arbitral proceedings and all subsequent applications
arising out of that agreement and the arbitral proceedings shall be made in that Court
and in no other Court.” A perusal of Section 42 of Arbitration Act reveals a clear
acknowledgment by the legislature, that the jurisdiction for raising a challenge to the
same arbitration agreement, arbitral proceeding or arbitral award, could most
definitely arise in more than one court simultaneously. To remedy such a situation
Section 42 of the Arbitration Act mandates, that the court wherein the first
application arising out of such a challenge is filed, shall alone have the jurisdiction to
adjudicate upon the dispute(s), which are filed later in point of time. The above
legislative intent must also be understood as mandating, that disputes arising out of
the same arbitration agreement, arbitral proceeding or arbitral award, would not be
adjudicated upon by more than one court, even though jurisdiction to raise such
disputes may legitimately lie before two or more courts.
23. Ordinarily Section 42 of the Arbitration Act would be sufficient to resolve such a controversy.
For the determination of the present controversy, however, reliance cannot be placed on Section 42
of the Arbitration Act, because the State of Maharashtra had moved Miscellaneous Civil Application
No. 229 and Miscellaneous Civil Application No 230 of 2012 under Section 34 of the Arbitration Act
before the District Judge, Thane, on the same day as Atlanta Limited had filed Arbitration Petition
No. 1158 of 2012 before the High Court. In this behalf it may be mentioned, that both the parties had
approached the courts referred to hereinabove on 7.8.2012. The answer to the jurisdictional
question, arising out in the facts and circumstances of this case, will therefore not emerge from
Section 42 of the Arbitration Act. All the same it is imperative for us to give effect to the legislative
intent recorded under Section 42 aforementioned, namely, that all disputes arising out of a common
arbitration agreement, arbitral proceeding or arbitral award, would lie only before one court.
24. The very fact that the appellants before this Court, have chosen to initiate proceedings against
the arbitral award before “principal Civil Court of original jurisdiction in a district” i.e., before the
District Judge, Thane, and the respondent before this Court, has raised a challenge to the same
arbitral award before the “ordinary original civil side” of the High Court of Bombay, clearly
demonstrates, that the underlying principle contained in Section 42 of the Arbitration Act would
stand breached, if two different courts would adjudicate upon disputes arising out of the same
arbitral award. There can be no doubt, that adjudication of a controversy by different courts, can
easily give rise to different conclusions and determinations. Therefore, logic and common sense also
require, the determination of all such matters, by one jurisdictional court alone. In the present case,Exe.Engr.Road Dev.Division No.Iii & ... vs Atlanta Ltd on 16 January, 2014

the complication in the matter has arisen only because, the proceedings initiated by the appellants
before the District Judge, Thane, and proceedings initiated by the respondent on the “ordinary
original civil side” of the High Court of Bombay, were filed on the same day (i.e. on 7.8.2012).
Therefore, Section 42 of the Arbitration Act, cannot be of any assistance in the matter in hand.
25. All the same, it is imperative for us to determine, which of the above two courts which have been
approached by the rival parties, should be the one, to adjudicate upon the disputes raised. For an
answer to the controversy in hand, recourse ought to be made first of all to the provisions of the
Arbitration Act. On the failure to reach a positive conclusion, other principles of law, may have to be
relied upon. Having given out thoughtful consideration to the issue in hand, we are of the view, that
the rightful answer can be determined from Section 2(1)(e) of the Arbitration Act, which defines the
term “Court”. We shall endeavour to determine this issue, by examining how litigation is divided
between a High Court exercising “ordinary original civil jurisdiction”, and the “principal civil court
of original jurisdiction” in a district. What needs to be kept in mind is, that the High Court of
Bombay is vested with “ordinary original civil jurisdiction” over the same area, over which
jurisdiction is also exercised by the “principal Civil Court of original jurisdiction” for the District of
Greater Mumbai (i.e. the Principal District Judge, Greater Mumbai). Jurisdiction of the above two
courts on the “ordinary original civil side” is over the area of Greater Mumbai. Whilst examining the
submissions advanced by the learned counsel for the appellant under Section 15 of the Code of Civil
Procedure, we have already concluded, that in the above situation, jurisdiction will vest with the
High Court and not with the District Judge. The aforesaid choice of jurisdiction has been expressed
in Section 2(1)(e) of the Arbitration Act, without any fetters whatsoever. It is not the case of the
appellants before us, that because of pecuniary dimensions, and/or any other consideration(s),
jurisdiction in the two alternatives mentioned above, would lie with the Principal District Judge,
Greater Mumbai. Under the scheme of the provisions of the Arbitration Act therefore, if the choice is
between the High Court (in exercise of its “ordinary original civil jurisdiction”) on the one hand, and
the “principal civil court of original jurisdiction” in the District i.e. the District Judge on the other;
Section 2(1)(e) of the Arbitration Act has made the choice in favour of the High Court. This in fact
impliedly discloses a legislative intent. To our mind therefore, it makes no difference, if the
“principal civil court of original jurisdiction”, is in the same district over which the High Court
exercises original jurisdiction, or some other district. In case an option is to be exercised between a
High Court (under its “ordinary original civil jurisdiction”) on the one hand, and a District Court (as
“principal Civil Court of original jurisdiction”) on the other, the choice under the Arbitration Act has
to be exercised in favour of the High Court.
26. In the present controversy also, we must choose the jurisdiction of one of two courts i.e. either
the “ordinary original civil jurisdiction” of the High Court of Bombay; or the “principal civil court of
original jurisdiction” in District Thane i.e. the District Judge, Thane. In view of the inferences drawn
by us, based on the legislative intent emerging out of Section 2(1)(e) of the Arbitration Act, we are of
the considered view, that legislative choice is clearly in favour of the High Court. We are, therefore
of the view, that the matters in hand would have to be adjudicated upon by the High Court of
Bombay alone.Exe.Engr.Road Dev.Division No.Iii & ... vs Atlanta Ltd on 16 January, 2014

27. In view of the conclusions drawn by us above, we uphold the order passed by the High Court
requiring the matters to be adjudicated on the “ordinary original civil side” by the High Court of
Bombay. The reasons recorded by the High Court, for the above conclusion, were different. The
reasons for our consideration have already been notice above. In view of the above, we dispose of the
instant appeal, with a direction that Arbitration Petition No. 1158 of 2012 filed by the Atlanta
Limited (the respondent herein) before the High Court of Judicature at Bombay, and Miscellaneous
Application No. 229 of 2012 and Miscellaneous Application No. 230 of 2012 filed by the appellants
before the District Judge, Thane, shall be heard and disposed of by the High Court of Bombay. We
accordingly hereby direct the District Judge, Thane, to transfer the files of Miscellaneous
Application No. 229 of 2012 and Miscellaneous Application No. 230 of 2012 to the High Court, for
disposal in accordance with law.
…..…………………………….J. (A.K. Patnaik) …..…………………………….J. (Jagdish Singh Khehar) New
Delhi;
January 16, 2014.Exe.Engr.Road Dev.Division No.Iii & ... vs Atlanta Ltd on 16 January, 2014

