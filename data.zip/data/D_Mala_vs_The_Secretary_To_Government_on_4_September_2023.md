D.Mala vs The Secretary To Government on 4 September, 2023
Author: M.Sundar
Bench: M.Sundar
                                                                                 H.C.P.No.638 of 2023
                                  IN THE HIGH COURT OF JUDICATURE AT MADRAS
                                               DATED: 04.09.2023
                                                      CORAM
                                   THE HONOURABLE MR.JUSTICE M.SUNDAR
                                                  AND
                                  THE HONOURABLE MR.JUSTICE R.SAKTHIVEL
                                             H.C.P.NO.638 OF 2023
                     D.Mala                                             ..    Petitioner
                                                        VS
                     1.The Secretary to Government
                       Home, Prohibition and Excise Department
                       Secretariat
                       Fort St. George
                       Chennai – 600 009
                     2.The Commissioner of Police
                       Office of the Commissioner of Police
                       Avadi
                     3.The Superintendent of Police
                       Central Prison
                       Puzhal, Chennai.
                     4. The Inspector of Police
                        T-12, Poonamallee Police Station
                        Chennai                                         ..    Respondents
                     PRAYER: Petition filed under Article 226 of the Constitution of India
                     praying for issuance of a Writ of Habeas Corpus to call for the records of
https://www.mhc.tn.gov.in/judis
                     1/8
                                                                                             H.C.P.No.638 of 2023D.Mala vs The Secretary To Government on 4 September, 2023

                     pertaining to the order of detention passed by the second respondent in
                     his proceedings in No.69/BCDFGISSSV/2023 dated 18.03.2023 and
                     quash the same as illegal and produce the detenu namely Vishwa @
                     Scale, son of Duraisamy, aged 22 years, who is now confined in Central
                     Prison, Puzhal, Chennai, before this Court and set him at liberty.
                                       For Petitioner        :      Mr.S.Lokesh
                                       For Respondents :            Mr.E.Raj Thilak,
                                                                    Additional Public Prosecutor
                                                             ORDER
[Order of the Court was made by M.SUNDAR, J.] When the captioned 'Habeas Corpus Petition'
[hereinafter 'HCP' for the sake of convenience and clarity] was listed in the Admission Board on
24.04.2023, this Court made the following order:
'Captioned Habeas Corpus Petition has been filed in this Court on 11.04.2023 inter
alia assailing a detention order dated 18.03.2023 bearing reference
69/BCDFGISSSV/2023 made by 'second respondent' [hereinafter 'Detaining
Authority' for the sake of convenience and clarity]. To be noted, fourth respondent is
the Sponsoring Authority.
2. To be noted, mother of detenu is the petitioner.
3. Mr.C.Raja, learned counsel on record for habeas corpus petitioner is before us. Learned counsel
for petitioner submits that ground case qua the detenu is for alleged offences under Sections 341,
294(b), 336, 392, 397 and 506(ii) of 'The Indian Penal Code (45 of 1860)' [hereinafter 'IPC' for the
sake https://www.mhc.tn.gov.in/judis of convenience and clarity] in Crime No.116 of 2023 on the
file of T-12, Poonamalle Police Station.
4. The aforementioned detention order has been made on the premise that the detenue is a 'Goonda'
under Section 2(f) of 'The Tamil Nadu Prevention of Dangerous Activities of Bootleggers, Cyber law
offenders, Drug-offenders, Forest- offenders, Goondas, Immoral traffic offenders, Sand-offenders,
Sexual-offenders, Slum-grabbers and Video Pirates Act, 1982 (Tamil Nadu Act No.14 of 1982)'
[hereinafter 'Act 14 of 1982' for the sake of convenience and clarity].
5. The detention order has been assailed inter alia on the ground that the detenu has not moved any
bail application and hence, the subjective satisfaction arrived at by the detaining authority regarding
real possibility of detenu coming out on bail reflects non-application of mind.
6. Prima facie case made out for admission. Admit. Issue Rule nisi returnable by four weeks.
7. Mr.E.Raj Thilak, learned Additional Public Prosecutor, State of Tamil Nadu accepts notice for all
respondents. List the captioned Habeas Corpus Petition accordingly.'D.Mala vs The Secretary To Government on 4 September, 2023

2. The aforementioned Admission Board order captures all essentials that are imperative for
appreciating this order and therefore, we are not setting out the same again in this order. Suffice to
say that aforementioned Admission Board order shall be read as an integral part and parcel of this
order. Be that as it may, we are using the short forms, https://www.mhc.tn.gov.in/judis short
references and abbreviations used in the Admission Board in this order also for the sake of
convenience and clarity. To be noted, 'detention order dated 18.03.2023 bearing reference
69/BCDFGISSSV/2023 made by the Detaining Authority' shall hereinafter be referred to as
'impugned preventive detention order' in this order for the sake of brevity, convenience and clarity.
3. Mr.S.Lokesh, learned counsel on record for petitioner and Mr.E.Raj Thilak, learned State
Additional Public Prosecutor for all respondents are before us.
4. As would be evident from paragraph 5 of the Admission Board order, at the time of admission
learned counsel posited his challenge to the impugned preventive detention order on the point that
detenu has not moved any bail application and hence the subjective satisfaction arrived at by the
detaining authority regarding real possibility of detenu coming out on bail reflects non-application
of mind but in the final hearing today, learned counsel for petitioner drew our attention to a portion
of paragraph 4 of the impugned preventive detention order which reads as follows:
'4...In a similar case registered at under section 294(b), 341, 323, 397, 336, 427 and
506(ii) IPC, in J-4 Kotturpuram Police Station Crime
https://www.mhc.tn.gov.in/judis No.43/2018, the bail was granted by the Court of
Principal Sessions Judge at Chennai in Crl.M.P.No.1759/2018. Hence, I infer that
there is a real possibility of his coming out on bail in P-5 MKB Nagar Police Station
Cr. No.110/2023 and T-12 Poonamallee Police Station Crime No.116/2023 cases by
filing bail application before the appropriate court, since in a similar case, the bail
was granted by the court after a lapse of time...'
5.Thereafter, learned counsel placed before us the grounds booklet as served on the detenu and
drew our attention to page Nos.187 to 190 thereat which contain Aravind case bail order (similar
case) made in English by the learned Sessions Judge and what according to the Detaining Authority
is Tamil translation version of the same i.e., Aravind case bail order. A perusal of the bail order in
English and the Tamil translated version brings to light that the bail order in English refers to
pending cases against the petitioner with specificity as regards calendar years in paragraph (6) but
in the Tamil translation, the same is missing.
6.Learned Prosecutor in response to the above argument submitted that only mentioning of the
calender years of pending cases with specificity is missing, the same is clerical error but otherwise
the translation is largely correct.
7.We carefully considered the rival submissions. We find from the confession statement of the
detenu at page Nos. 98 and 99 of the grounds https://www.mhc.tn.gov.in/judis booklet that the
literacy level of the detenu is XII Standard in School. Therefore, it is not merely a case of improper
translation it is also a case of giving orders with different contents in English and Tamil versionD.Mala vs The Secretary To Government on 4 September, 2023

which can baffle a person whose literacy level is only XII Standard in School. This means that (when
a detenu is baffled), his right to make an effective representation against the impugned preventive
detention order gets impaired.
8.Ergo, the sequitur is, captioned HCP is allowed. Impugned detention order dated 18.03.2023
bearing reference No.69/BCDFGISSSV/2023 made by the second respondent is set aside and the
detenu Thiru. Vishwa @ Scale, aged 22 years, Son of Thiru.Duraisamy, is directed to be set at liberty
forthwith, if not required in connection with any other case / cases. There shall be no order as to
costs.
                                                                     (M.S., J.)       (R.S.V., J.)
                                                                             04.09.2023
                     Index : Yes
                     Neutral Citation : Yes
                     Speaking order
                     gpa
P.S: Registry to forthwith communicate this order to Jail authorities in Central Prison, Puzhal,
Chennai.
https://www.mhc.tn.gov.in/judis To
1.The Secretary to Government Home, Prohibition and Excise Department Secretariat Fort St.
George, Chennai – 600 009.
2.The Commissioner of Police Office of the Commissioner of Police Avadi
3.The Superintendent of Police Central Prison Puzhal, Chennai.
4. The Inspector of Police T-12, Poonamallee Police Station Chennai
5.The Public Prosecutor High Court, Madras.
https://www.mhc.tn.gov.in/judis M.SUNDAR, J.
AND R.SAKTHIVEL , J.
gpa H.C.P.NO.638 OF 2023 04.09.2023 https://www.mhc.tn.gov.in/judisD.Mala vs The Secretary To Government on 4 September, 2023

