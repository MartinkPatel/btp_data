Adani Gas Limited vs Petroleum And Natural Gas Regulatory ...
on 17 February, 2020
Equivalent citations: AIRONLINE 2020 SC 450
Author: D.Y. Chandrachud
Bench: Hemant Gupta, Dhananjaya Y Chandrachud
                                                                          Reportable
                              IN THE SUPREME COURT OF INDIA
                               CIVIL APPELLATE JURISDICTION
                                 Civil Appeal No 3992 of 2019
          Adani Gas Limited                                          ...Appellant
                                         Versus
          Petroleum and Natural Gas Regulatory Board & Ors.        ...Respondents
                                            With
                              Civil Appeal Nos 3234-3235 of 2019
                                            With
                              Civil Appeal Nos 3247-3248 of 2019
                                            With
                                 Civil Appeal No 3289 of 2019
                                            With
                                 Civil Appeal No 4527 of 2019
                                             With
                                    T.C. (C) No 27 of 2019Adani Gas Limited vs Petroleum And Natural Gas Regulatory ... on 17 February, 2020

                                            With
Signature Not Verified              T.C. (C) No 26 of 2019
Digitally signed by
SANJAY KUMAR
Date: 2020.02.17
13:49:24 IST
Reason:                                   And With
                                 Civil Appeal No 106 of 2020
                                              1
                                     JUDGMENT
Dr Dhananjaya Y Chandrachud J
1.       In 2018 the Petroleum and Natural Gas Regulatory Board1 conducted the
ninth round of bidding for City or Local Natural Gas Distribution Networks 2. On 14
September 2018, a press release was placed on the Board‘s website notifying
details of the successful bidders in various Geographical Areas3. The contest in
the present batch of appeals has arisen over the grant of authorisation for laying,
building, operating or expanding CGD networks in the following GAs:
         (i)      GA 51 - Puducherry District;
         (ii)     GA 61 - Kanchipuram District; and
         (iii)    GA 62 – Chennai & Tiruvallur Districts.
2.       The Appellate Tribunal for Electricity4 was seized of two appeals – Appeal
No 292 of 2018, instituted by Adani Gas Limited and Appeal No 323 of 2018,
instituted by IMC Limited. These appeals were instituted before the APTEL under
Section 30(1) of the Petroleum and Natural Gas Regulatory Board Act 2006 5. By
their separate judgments dated 28 February 2019, the Chairperson and Member
Technical (Petroleum and Natural Gas) rendered divergent findings, following
which the Chairperson directed that the proceedings in the two appeals be placedAdani Gas Limited vs Petroleum And Natural Gas Regulatory ... on 17 February, 2020

before the judicial member. The judicial member recused from hearing the
1
  ―the Board
2
  ―CGD Networks
3
  ―GAs"
4
  ―APTEL or ―Tribunal
5
  ―PNGRB Act
                                             2
appeals on 7 March 2019. This led to the institution of the present appeals before
this Court. Noting that no other judicial member was available in the APTEL to
conduct the hearing, this Court by its order dated 1 April 2019 admitted the
appeals and issued directions in exercise of its powers under Article 142 of the
Constitution for the transfer of the proceedings before the APTEL to this Court in
order to bring finality to the present dispute. In assessing the merits, the Court
has had the benefit of appraising the differing views which have been expressed
by the Chairperson and by the Member Technical (Petroleum and Natural Gas).
3.    The APTEL has been constituted in terms of sub-Section (1) of Section 30
of the PNGRB Act which is extracted below:
             ―30. Appellate Tribunal. (1) Subject to the provisions of this
             Act, the Appellate Tribunal established under section 110 of
             the Electricity Act, 2003 (36 of 2003) shall be the Appellate
             Tribunal for the purposes of this Act and the said Appellate
             Tribunal shall exercise the jurisdiction, powers and authority
             conferred on it by or under this Act:
             Provided that the Technical Member of the Appellate Tribunal
             for the purposes of this Act shall be called the Technical
             Member (Petroleum and Natural Gas) and shall have the
             qualifications specified in sub-section (2) of section 31.
Section 33 stipulates that any person aggrieved by an order or decision of the
Board has recourse to an appeal to the Tribunal. The jurisdiction of the APTELAdani Gas Limited vs Petroleum And Natural Gas Regulatory ... on 17 February, 2020

while hearing an appeal is spelt out in sub-Section (6) of Section 33 in the
following terms:
             ―33.(6) The Appellate Tribunal may, for the purpose of
             examining the legality or propriety or correctness of any order
             or decision of the Board referred to in the appeal filed under
             sub-section (1), either on its own motion or otherwise, call for
             the records relevant to disposing of such appeal and make
             such orders as it thinks fit.
                                              3
An appeal lies to this Court against an order of the APTEL, other than an
interlocutory order, under Section 37 on the grounds set out in Section 100 of the
Code of Civil Procedure 1908. With this background, we now turn to the PNGRB
Act under the aegis of which the ninth round of CGD bidding occurred.
PNGRB Act and regulations
4.     The content of the PNGRB Act is summarised by its long title as:
                ―An Act to provide for the establishment of Petroleum and
                Natural Gas Regulatory Board to regulate the refining,
                processing, storage, transportation, distribution, marketing
                and sale of petroleum, petroleum products and natural gas
                excluding production of crude oil and natural gas so as to
                protect the interests of consumers and entities engaged in
                specified activities relating to petroleum, petroleum products
                and natural gas and to ensure uninterrupted and adequate
                supply of petroleum, petroleum products and natural gas in all
                parts of the country and to promote competitive markets and
                for matters connected therewith or incidental thereto.
The PNGRB Act came into force, in terms of the provisions contained in Section
1(3) on 1 October 2007, save and except for Section 16. Section 16 which
provides for the authorisation for building or expanding CGD Networks, came into
force on 15 July 2010. Section 16, insofar as is material contains the following
stipulations:
                ―16. Authorisation.—No entity shall—
                (a) lay, build, operate or expand any pipeline as a commonAdani Gas Limited vs Petroleum And Natural Gas Regulatory ... on 17 February, 2020

                carrier or contract carrier,
                (b) lay, build, operate or expand any city or local natural gas
                distribution network, without obtaining authorisation under this
                Act: … 
Under Section 19 of the PNGRB Act, the Board may grant an authorisation for a
city or local natural gas distribution network either on the basis of an application
                                                 4
or suo moto. Before it does so in a specified GA, the Board is under a mandate to
give wide publicity of its intent to do so. Upon inviting applications from interested
parties, the Board may select an entity ―in an objective and transparent manner
as specified by regulations for such activities.
5.         On 19 March 2008, the Petroleum and Natural Gas Regulatory Board
(Authorizing Entities to Lay, Build, Operate or Expand City or Local Natural Gas
Distribution Networks) Regulations 20086 were notified. The CGD Authorisation
Regulations were amended on 21 June 2013, 7 April 2014 and 6 April 2018. The
CGD Authorisation Regulations, as amended in 2018, substituted new criteria for
bidding which applied to the ninth round of bidding with which the present batch
of appeals is concerned.
6.         Regulation 6 of the CGD Authorisation Regulations provides for the
invitation by the Board for laying, building, operating or expanding of a CGD
network in a specific city or GA. The procedure stipulated in Regulation 5 is to
apply, except for those aspects relating to expressions of interest. Under
Regulation 5(6), the Board can scrutinise only those bids which are received in
response to an advertisement and from entities which fulfil certain minimum
eligibility criteria. Regulation 5(6)(b) spells out the criteria, which are designed to
ensure that the entity bidding is technically capable of laying and building a CGDAdani Gas Limited vs Petroleum And Natural Gas Regulatory ... on 17 February, 2020

network in the relevant city or GA. Regulation 5(6)(c) enunciates criteria which
ensure that the entity is technically capable of operating and maintaining a CGD
6
    ―CGD Authorisation Regulations
                                          5
network. Besides the technical criteria, the Regulations also spell out certain
financial criteria which potential bidders must satisfy. Regulation 5(6)(e) provides:
              ―(6)     The Board shall scrutinise the bids received in
              response to the advertisement in respect of only those
              entities which fulfil the following minimum eligibility criteria,
              namely:-
              …
              (e)      the entity has adequate financial strength to execute
              the proposed project, operate and maintain the same in the
              authorised area and shall meet the following financial criterion
              to qualify for bidding for a single CGD network namely:-
               Population in the             Minimum net worth of the bidder entity
          geographical area as per
            2011 Census of India
       (1)                                 (2)
       5 million or more                   Rs. 1,500 million for a population of 5 million,
                                           plus additional Rs. 300 million for each 1
                                           million of population or part thereof, in excess
                                           of 5 million (refer Note-3)
       2 million or more but less   than   Rs.1,000 million
       5 million
       1 million or more but less   than   Rs. 750 million
       2 million
       0.5 million or more but      less   Rs. 500 million
       than 1 million
       0.25 million or more but     less   Rs. 250 million
       than 0.50 million
       0.1 million or more but      less   Rs. 100 million
       than 0.25 million
       Less than 0.1 million               Rs. 50 million
                                                                                              
The minimum net-worth of the bidding entity is thus linked to the population of the
GA the entity is bidding for, as set out in 2011 Census data.Adani Gas Limited vs Petroleum And Natural Gas Regulatory ... on 17 February, 2020

7.    Regulation 7 of the CGD Authorisation Regulations provides the criteria for
determining how the Board should evaluate rival bids for the same GA.
Regulation 7 is quoted below, in its entirety:
        ―7.   Bidding criteria.
                                                6
 1(a) The Board, while considering the proposal for authorisation, shall
 tabulate and compare all financial bids meeting the minimum eligibility
 criteria, as per the bidding criteria specified below, namely:-
Sl.        Bidding Criteria         Weightage               Explanation
No                                      %
1     Lowness of transportation         10         Bidder is required to quote
      rate for CGD – in rupees                     transportation rate for CGD
      per million British Thermal                  only for the first contract
      Unit (Rs./MMBTU)                             year which shall not be less
                                                   than Rs.30/MMBTU. Rates
                                                   for the subsequent contract
                                                   years shall be derived
                                                   considering the quoted rate
                                                   and escalation as per Note.
2     Lowness of transportation            10      Bidder is required to quote
      rate for CNG – in rupees                     transportation rate for CNG
      per kilo gram (Rs./kg)                       only for the first contract
                                                   year which shall not be less
                                                   than Rs.2/kg. Rates for the
                                                   subsequent contract years
                                                   shall be derived considering
                                                   the    quoted     rate   and
                                                   escalation as per Note.
3      Highness of number of             20                      -
       CNG stations (online and
       daughter booster stations)
       to be installed within 8
       contract years from the
       date of authorisation
4      Highness of number of             50                      -
       domestic piped natural gas
       connections to be achieved
       within 8 contract years from
       the date of authorisation
5      Highness of inch-kilometre        10                      -
       of steel pipeline (including
       sub-transmission        steel
       pipelines) to be laid within
       8 contract years from the
       date of authorisationAdani Gas Limited vs Petroleum And Natural Gas Regulatory ... on 17 February, 2020

Note – Annual escalation shall be considered from the second contract year
and onwards based on the ―Wholesale Price Index (WPI) Data (2011-12 =100)
for ―All Group/ Commodity, as normally available on the website of the Office of
the Economic Adviser, Government of India, Ministry of Commerce and
Industry, Department of Industrial Policy and Promotion (DIPP) on the link
―http://eaindustry.nic.in/home.asp.
                                       7
Provided that in the case of the geographical areas of (i) Bilaspur, Hamirpur and
Una Districts; (ii) Panchkula (Except area already authorised), Shimla, Solan and
Sirmaur Districts and (iii) Barmer, Jaisalmer and Jodhpur Districts, it is not
mandatory to supply natural gas through steel-pipes. However natural gas has to
reach in all charge areas. The bidding parameters and their respective weightage
will, accordingly, be as under:-
Sl.       Bidding Criteria        Weightage               Explanation
No                                   %
1     Lowness              of    10               Bidder is required to quote
      transportation rate for                     transportation rate for CGD
      CGD – in rupees per                         only for the first contract
      million British Thermal                     year which shall not be less
      Unit (Rs./MMBTU)                            than Rs.30/MMBTU. Rates
                                                  for the subsequent contract
                                                  years shall be derived
                                                  considering the quoted rate
                                                  and escalation as per Note.
2     Lowness               of   10               Bidder is required to quote
      transportation rate for                     transportation rate for CNG
      CNG – in rupees per kilo                    only for the first contract
      gram (Rs./kg)                               year which shall into be less
                                                  than Rs.2/kg. Rates for the
                                                  subsequent contract years
                                                  shall be derived considering
                                                  the    quoted     rate    and
                                                  escalation as per Note.
3      Highness of number of 25                                 -
       CNG stations (online
       and daughter booster
       stations) to be installed
       within 8 contract years
       from     the     date   of
       authorisation
4      Highness of number of 55                                -
       domestic piped natural
       gas connections to be
       achieved      within     8
       contract years from the
       date of authorisation
Note: Annual escalation shall be considered from the second contract year and
onwards based on the ―Wholesale Price Index (WPI) Data (2011-12=100) for
―All Group / Commodity, as normally available on the website of the Office of
the Economic Adviser, Government of India, Ministry of Commerce andAdani Gas Limited vs Petroleum And Natural Gas Regulatory ... on 17 February, 2020

Industry, Department of Industrial Policy and Promotion (DIPP) on the link
―http://eaindustry.nic.in/home.asp.
                                      8
a(b) Successful bidder shall be required to achieve the year-wise work
programme within 8 contract years as per details given below, namely:-
PNG Connections         CNG stations              Inch-km of steel pipeline
     (cumulative)       (cumulative)              (cumulative)
By the     % of work    By the    % of work       By the   % of work
end of     programme end of       programme end of         programme
contract                contract                  contract
year                    year                      year
  st                         st
1              Nil         1            Nil          1st            5
2nd            10         2nd           15           2nd            20
3rd            20          3rd          30           3rd            40
4th            30          4th          45           4th            60
  th                         th                        th
5              40          5            60           5              70
  th                         th                        th
6              60          6            75           6              80
7th            80          7th          90           7th            90
  th                         th                        th
8              100         8           100           8             100
Note:- In case derived numbers are in fraction, the same shall be rounded off
to the nearest whole number and fraction 0.5 shall be rounded off to next
higher whole number.
Provided that in the case of the geographical areas of (i) Bilaspur, Hamirpur
and Una Districts; (ii) Panchkula (Except area already authorised), Shimla,
Solan and Sirmaur Districts and (iii) Barmer, Jaisalmer and Jodhpur Districts,
successful bidder shall be required to achieve the year-wise work programme
within 10 contract years as per details given below, namely:-
PNG Connections (cumulative)                CNG stations (cumulative)
By the end of     % of work         By the end of      % of work
contract year     programme         contract year      programme
       1st               Nil                 1st                 Nil
         nd                                   nd
       2                 10                 2                    10
         rd                                   rd
       3                 20                 3                    20
       4th               30                 4th                  30
         th                                   th
       5                 40                 5                    40
       6th               50                 6th                  50
         th                                   th
       7                 60                 7                    60Adani Gas Limited vs Petroleum And Natural Gas Regulatory ... on 17 February, 2020

         th                                   th
       8                 70                 8                    70
       9th               80                 9th                  80
          th                                   th
      10                100                 10                   100
Note – In case derived numbers are in fraction, the same shall be rounded off
to the nearest whole number and fraction 0.5 shall be rounded off to next
higher whole number.
(2) ***********
                                      9
         (3) Bidder entity with the highest composite score, considering the criteria
         under sub-regulation (1) and as illustrated in Schedule C (1), shall be
         declared as successful bidder.
         Provided that in case of tie in the evaluated composite score, the successful
         bidder shall be decided based on the highness of numbers of PNG
         connections among the tied bidding entities. In case there is tie on number of
         PNG connections also, highness of inch-kilometer steel pipeline shall be
         considered and thereafter in case of tie in inch-kilometer as well, highness of
         numbers of CNG stations shall be considered;
Under Regulation 7, the Board while considering proposals for authorisation,
shall tabulate and compare all financial bids which meet the minimum eligibility
criteria in accordance with the bidding criteria set out as enunciated. The table
set out in Regulation 7(1)(a) provides for the tabulation of all eligible financial bids
on the basis of five parameters. The table enunciates the five bidding criteria and
the weightage which is to be ascribed to each of them. The criteria are as follows:
       (i)    The first criterion is the ‗lowness‘ of the transportation rate for CGD
              computed in rupees per million for a British Thermal Unit. The
              weightage ascribed to this criterion is 10 per cent. The explanation
              stipulates that a bidder is required to quote the transportation rate
              for CGD only for the first contract year at a rate not less than Rs 30Adani Gas Limited vs Petroleum And Natural Gas Regulatory ... on 17 February, 2020

              per MMBTU;
       (ii)   The second criterion is the ‗lowness‘ of the transportation rate for
              CNG expressed in rupees per kilogram. The weightage ascribed to
              this criterion is 10 per cent. The bidder is required to quote the
              transportation rate only for the first contract year at a rate of not less
              than Rs 2 per kilogram;
                                               10
      (iii)   The third criterion is the ‗highness‘ of the number of CNG stations to
              be installed within eight contract years from the date of
              authorisation. The weightage ascribed to this parameter is 20 per
              cent;
      (iv)    The fourth criterion is the ‗highness‘ of the number of domestic
              piped natural gas connections to be achieved within eight contract
              years from the date of authorisation. The weightage ascribed to this
              criterion is 50 per cent; and
      (v)     The fifth criterion is the ‗highness‘ of the inch-kilometre of steel
              pipeline to be laid within eight contract years from the date of
              authorisation. The weightage ascribed to this parameter is 10 per
              cent.
Regulation 7(1)(b) sets out a year-wise work programme indicating the progress
which must be achieved by the successful bidder every year during the course of
eight contract years from the date of authorisation. Under Regulation 7(3), a
bidding entity with the highest composite score, in terms of the criteria contained
in sub-regulation (1), is to be declared as the successful bidder. This is illustrated
in Schedule C(1) of the CGD Authorisation Regulations. Schedule C(1) containsAdani Gas Limited vs Petroleum And Natural Gas Regulatory ... on 17 February, 2020

the following illustration of the manner in which the weightage for PNG
connections is to be ascribed:
              ―(E) Number of PNG domestic connections
              Let,
              P1 = Number of PNG domestic connections by the 1st
              entity
                                          11
             P2 = Number of the PNG domestic connections by the
             2nd entity
             P3 = Number of the PNG domestic connections by the
             3rd entity
             Assume P1 is higher than P2 and P2 is higher than
             P3.;
             The highest number of PNG domestic connections bid
             (HP1) shall be given a score of 100% and the number of
             the other PNG domestic connections bids shall be given a
             score in relation to HP1 on a pro-rata basis as under :-
             HP1                      =        100%
             HP2                      =        100 % x (P2 ÷ P1)
             HP3                      =        100 % x (P3 ÷ P1)
                                                                          
This illustration shows that the entity which has quoted the highest number of
PNG domestic connections to be achieved is allotted a score of 100 per cent.
The entities below the highest will be assigned a score in relation to the first entity
on a proportionate basis.
8.    Under Regulation 9, the grant of an authorisation is to be issued to a
successful entity after it furnishes a performance bond. The quantum of the
performance bond is based on the population of the GA as determined withAdani Gas Limited vs Petroleum And Natural Gas Regulatory ... on 17 February, 2020

reference to the census data of 2011. Regulation 9 states:
             ―9.      Performance bond.
             (1)     Grant of authorisation shall be issued to the
             successful entity after it furnishes the performance bond
             in the form of demand draft or pay order or bank
             guarantee from any scheduled bank for the amount as per
             details given below, namely:-
             Serial      Population       in        the   Amount     of
                                               12
                  Number   Geographical Area, as          Performance
                           pre 2011 Census of India       Bond (Rupees)
                  1        5 million or more              500 million
                  2        2 million or more but less     330 million
                           than 5 million
                  3        1 million or more but less     250 million
                           than 2 million
                  4        0.5 million or more but less   150 million
                           than 1 million
                  5        0.25 million or more but       80 million
                           less than 0.50 million
                  6        0.1 million or more but less   30 million
                           than 0.25 million
                  7        Less than 0.1 million          15 million
                                                                          
Under Regulation 10, the successful entity is to be issued a letter of intent7 upon
the finalisation of the bid. Under the CGD Authorisation Regulations, the
authorised entity must also obtain financial closure for the project from a bank or
financial institution within 270 days of authorisation.
9.          The period of implementation of the project under the ninth round of CGD
bidding is 2018 to 2026. The period for commercial operation is between 2018
and 2043.Adani Gas Limited vs Petroleum And Natural Gas Regulatory ... on 17 February, 2020

10.         From an analysis of the CGD Authorisation Regulations, it becomes
evident that the 2011 census figures have been utilised to peg the net-worth
requirement in Regulation 5(6)(e) and the value of the performance bond to be
submitted to the Board post authorisation in Regulation 9. Significantly,
Regulation 7, which provides a table specifying the five bidding criteria to
7
    ―LOI
                                               13
evaluate competing bids, does not link the said criteria with the census figures of
2011.
Facts of the present appeals
11. On 12 April 2018, the Board initiated the bidding process for authorising entities to lay, build,
operate or expand CGD networks for the ninth round. The bids were invited by means of an
application-cum-bid-document for each GA.8 The bidding process covered various GAs, including
those of (i) GA 51 - Puducherry District; (ii) GA – 61 Kanchipuram District; and (iii) GA 62
-Chennai- Tiruvallur.
12. Clause 1.1. of the Bid Document was titled ‗Geographical area and related information‘. Clause
1.1.1 stipulated that the Board had identified a GA and was accordingly inviting
applications-cum-bids for the grant of authorisation for developing a CGD network in the GA. Each
GA was depicted in a map at Annexure-1 of the Bid Document for the relevant GA. Under Clause
1.1.3, it was the responsibility of each bidder to obtain all information related to the present gas
supply availability, pipeline connectivity and information about existing customers, if any, in the
specified GA. Clause 1.1.3 stated:
―1.1.3. It is the bidder’s responsibility to obtain all information related to the present
gas supply availability and pipeline connectivity and also existing customers, if any,
in the specified geographical area. The bidder can also refer to list of
NOCs/Permissions granted by PNGRB to various entities under the provisions of the
Internal Guidelines for grant of NOC/Permission for (i) supply/distribution of
CBM/natural gas through cascades; and (ii) setting up of CNG/LNG Daughter
Booster Stations (DBS), in the areas where the Board has not yet authorized any
entity for With respect to the relevant GA, ―Bid Document developing or operating
CGD networks at http://www.pngrb.gov.in/CGD-NOCs.html. (Emphasis supplied)
The scope of work was defined in Clause 1.2 of the Bid Document:Adani Gas Limited vs Petroleum And Natural Gas Regulatory ... on 17 February, 2020

―The entities bidding for this work shall be required to lay, build, operate or expand
the CGD networks to meet requirement of natural gas in domestic, commercial and
industrial segments including Natural Gas in the vehicular segment in the said
geographical area to be authorized and also comply with the relevant regulations
notified from time to time.
The entities shall be required to carry out the development of CGD project in line
with the regulations laid down by the PNGRB.
13. Clause 2.1.1 required the bidders to examine the contents of the Bid Document and the
regulations of the Board. Clause 2.1.2 described Annexure-1 as the map depicting the GA and charge
areas. Under Clause 2.2.1, any clarifications were required to be obtained from the Secretary of the
Board on or before the bid closing date. Clause 4.2 stipulated that all financial bids would be
tabulated and compared in accordance with the bidding criteria specified in Regulation 7 and
Schedule-C(1) of the CGD Authorisation Regulations. Moreover, the bidder with the highest
composite score would be declared as successful in the bid. Under Clause 4.4 of the Bid Document,
the Board reserved the right to accept or reject any bid which it considered to be ―unreasonably high
or low:
―4.4 PNRGB'S RIGHT TO ACCEPT OR REJECT ANY OR ALL
APPLICATION-CUM-BIDS 4.4.1 PNRGB reserves the right to reject any Application-
cum-Bid comprising quoted work programme considered by it to be unreasonably high or low. On
31 May 2018, Addendum-1 to the Bid Document was issued by the Board. Clause 14.2, inserted as a
result of Addendum-1, contained the following clarification:
―14.2 What should be considered to be the level of "unreasonably high" or
"unreasonably low" quotes shall be decided by Board at the time of bid evaluation on
a case to case basis after considering the relevant factors. According to the above
stipulation, the Board clarified that the determination of an unreasonably high or low
quote would be made by the Board at the time of bid evaluation on a case to case
basis after considering the relevant factors.
14. On 10 July 2018, three bid evaluation committees9 were nominated by the Board for evaluating
the bid documents. On 12 July 2018, a press release was issued by the Board setting out the date and
time for the opening of technical bids for different GAs. The technical bids for GA 51 (Puducherry)
were to be opened on 16 July 2018 at 14.00 hours; for GA 61 (Kanchipuram) on 17 July 2018 at
12.30 hours; and for GA 62 (Chennai-Tiruvallur) on 17 July 2018 at 13.30 hours. The technical bids
were opened by the Board in the presence of the bidders‘ representatives.
15. On 23 July 2018, a note10 was moved for the approval of the members of the Board with a view
to encourage serious bidders and to avoid unrealistic/unreasonable bidding in terms of Clause 4.4.1
of the Bid Document. The Board Note, insofar as is material provided:Adani Gas Limited vs Petroleum And Natural Gas Regulatory ... on 17 February, 2020

(―BECs) ―Board Note ―Subject: Reasonability of Bidding Parameters Bid
evaluation for technical bid is under progress for all 86 GAs. Technical bid queries
are being issued and it is expected that the Financial bid opening may be started from
this week (24th July onwards) for various GAs. The bidding parameters have been
completely changed in current round. In order to promote serious bidders and to
avoid any unrealistic/unreasonable bidding number committed by entity, PNGRB
has included a rejection clause in Para 4.4.1 of application-cum-bid documents. The
clause is reproduced below:
―PNGRB reserves the right to reject any Application-cum-Bid comprising quoted
work programme considered by it to be unreasonably high or law. Since technical
bids for some of the GAs are about to be concluded, it is essential to decide upon the
reasonability of the bidding parameters which are constituting work programme. In
this regard, following is proposed:
1. No of PNG Domestic connections:
Lower Limit: Ministry of Petroleum and Natural Gas (MoP&NG) vide letter No L-
16021/9/2013-GP-1 (pt.) dated 16th August 2016, constituted a committee to
examine the City Gas Distribution (CGD) bidding related issues. The committee in its
report recommended minimum work programme (MWP) for inter-alia PNG
domestic connections as 7.5% of within district headquarters/ municipal limit. Prior
to 9th round, MWP for PNG domestic connections was fixed for 5 % total household.
Considering above it is proposed that 2 % of total Household (Census 2011 data) may
be considered as minimum.
Maximum Limit: In order to reach at maximum value various possibilities has been discussed in
house which includes conversion of LPG to PNG, maximum penetration at present in GAs etc. It is
proposed to keep maximum limit of PNG Domestic connections as 100 % of Household (Census
2011 data).
Beyond 100 % household may be treated as unreasonable quote. The Board Note was approved by
the members of the Board including the Chairperson. Between 24 July 2018 and 18 August 2018,
the financial bids submitted by the bidders for various GAs were opened by the Board.
16. The Board Note of 23 July 2018 adopted the Census 2011 data on the total number of households
as the basis for computing the minimum and maximum limits for the purpose of determining
unreasonably low or unreasonably high quotes. The Board Note stipulated that 2 per cent of the
total households in terms of the Census 2011 data would be regarded as the minimum quote.
Anything below 2 per cent would be considered unreasonably low. Similarly, on the upper end of the
spectrum, the Board Note proposed that 100 per cent of the total households in terms of the Census
2011 data would be regarded as the maximum. A quotation beyond this upper limit would be
construed to be unreasonably high. Now, two features of the note of the Board Note dated 23 JulyAdani Gas Limited vs Petroleum And Natural Gas Regulatory ... on 17 February, 2020

2018 must be noted. First, the Board Note was generated after the last date for the submission of
bids. Second, the Board Note was an internal document of the Board which was not notified to the
bidders.
17. The Board commenced the process of opening the financial bids on 24 July 2018. On 2 August
2018, an agenda note was prepared for the Board. The agenda note outlined that three BECs were
nominated for evaluating the bids received. Technical bids submitted by the bidders were evaluated
by ICF, a consultant, based on the requirements of the Regulations and the Bid Documents. A
summary sheet of the technical bid evaluation was prepared and checked by the BEC. Thirty-eight
entities had submitted bids against 86 GAs. The financial bids of technically eligible bidders were
recommended for opening. The agenda note dated 2 August 2018 spelt out the stipulation contained
in paragraph 4.4.1 of the Bid Document, and of the previous decision of the Board, to adopt 2 per
cent of the total households as the minimum and 100 per cent as the maximum, both on the basis of
2011 Census data. The agenda note contained a tabulation of the bids of technically qualified
entities. The agenda note indicated that for four GAs: 35, 46, 48 and 49 where two bids had been
received for each, the highest bidder had quoted an unreasonably low number of projected PNG
connections at the end of eight contract years. Where the bid below 2 per cent was the sole bid for
the GA, the bid was accepted as the GA would have gone ‗dry‘ otherwise. The agenda note proposed
the adoption of three courses of action with respect to the remaining bids:
(i) Rejection of the bids received for the above four GAs as being unreasonably low;
(ii) Acceptance of the bids for the four GAs by extending to them the same logic that
was applied for single bid GAs; or
(iii) Inviting the concerned entities with the highest scores for each of the GAs for
negotiation to improve the quoted work programme.
18. The agenda note dated 2 August 2018 was presented before the Board for deliberation on 3
August 2018. In its meeting, the Board accepted the proposal for the issuance of LOIs to entities of
48 GAs mentioned in table 3 of the agenda note. The proposal to invite entities with the highest
scores which had submitted unreasonably low bids for each of the GAs for negotiations and to
improve the quoted work programme was approved. Accordingly, on 3 August 2018, the Board
issued a press release recording that it had approved the issuance of LOIs to 18 successful bidders
for 48 GAs. The press release indicated that the remaining GAs were being evaluated and the
outcome would be notified shortly.
19. On 9 August 2018, an agenda note was issued by the Board noting that in pursuance of the
decisions which were taken by the Board on 3 August 2018, letters have been addressed to the
entities which had obtained the highest composite score but had quoted unreasonably low PNG
connections, to confirm their acceptance of the minimum requirement of 2 per cent of households
as per the 2011 Census data. Table 5 to the agenda note contained a tabulation of bids which were
liable to be rejected due to unreasonably high or as the case may be, unreasonably low quotes.
Among these bids were the bids received from H1 bidders who had quoted unreasonably high PNGAdani Gas Limited vs Petroleum And Natural Gas Regulatory ... on 17 February, 2020

connections for the three GAs which form the subject matter of the present appeals. These were:
―Table -5 Sl No GA Name of GA Name of Quote Remarks No. bidding entities
11. GA 61 Kanchipuram Consortium of 114% of 7 other District AG&P LNG total HH
valid bids Marketing Pte remains Ltd. & Atlantic Gulf & Pacific Company of Manila
Inc.
12. GA 62 Chennai & Torrent Gas 157.00% of 9 other Tiruvallur Private Limited total
HH valid bids Districts remains
13. GA 63 Coimbatore IMC Limited 107.06% of 12 other District total HH valid bids
remains … From the above Table-5, it can be seen that in 3 GAs have unreasonably
High PNG Connections quoted have been received & also happens to be H1 bidder
and are liable for rejection.
20. At this stage it may also be necessary to note that table 4 contained a tabulation of bids among
them being those of bidders who were treated as not ―Not-Qualified. The agenda note
recommended that in three GAs, the bids of the highest bidders were liable to be rejected since they
had quoted an unreasonably high number of PNG connections to be achieved at the end of eight
contract years. Consequently, the names of the entities which were to be declared as successful
bidders were tabulated in table 6 of the agenda note. According to the agenda note, after the names
of the entities with the highest bids were removed, IMC Limited was recommended for being
declared as the successful bidder for GA 61 (Kanchipuram District). Similarly, for GA 62 (Chennai &
Tiruvallur Districts), Adani Gas Limited was recommended to be the successful bidder after the
highest bid was declared as ―Not Qualified. The agenda note was prepared by the Authorisation
Division and records that it was concurred with by the Member (I&T) and Member (C&M) and was
approved by the Chairperson ―for deliberations and approval of the Board.
21. On 10 August 2018, a meeting was held by the Board. The minutes of the Board meeting
recorded that out of four cases where the quotes for projected PNG domestic connections were
higher than 100 per cent of the households under the 2011 Census, one of the bidders for GA 63 was
not under consideration as its composite score was not the highest amongst the bids received for the
GA. The other three bidders who had quoted more than 100 per cent of the households for PNG
domestic connections were reflected in the following table:
― Sl GA GA name Bidding Entity Quoted for PNG No. No. Domestic connections as %
of households as per 2011 census
1. 61 Kanchipuram Consortium of 114% Distt. AG&P LNG marketing Pte Ltd. and
Atlantic Gulf & Pacific Company of Manila Inc.
2. 62 Chennai & Torrent Gas Pvt 157% Tiruvallur Ltd.Adani Gas Limited vs Petroleum And Natural Gas Regulatory ... on 17 February, 2020

Districts
3. 72 Medchal, Torrent Gas Pvt 220% Rangareddy Ltd.
& Vikarabad Districts  The minutes of the meeting went on to record that:
―During deliberations in the Board, the Board referred to clause 4.4.1 of ACBD which
reads, ―PNGRB reserves the right to reject any application cum bid comprising
quoted work program considered by it to be unreasonably high or low. In terms of
this clause vide note dated 23.07.2018 (i) lower and upper limits were decided for
PNG domestic connections (ii) lower limits was decided for CNG Stations and (iii) no
limit (higher or lower) was decided for Inch-KM of Steel pipeline. The Board
deliberated that though lower and upper households were decided, the same need not
be a mechanical exercise and an opportunity be given to affected entities to explain
reasonableness of their quotes.
22. The Board thus took a decision that the disqualification of bidders on the basis of the lower and
upper thresholds of 2 per cent and 100 per cent of the 2011 households which it had decided earlier
―need not be a mechanical exercise. Hence, a decision was taken to offer to the three affected
entities for GAs 61, 62 and 72, an opportunity to present their case on why their bids should not be
rejected for being unreasonably high. The Board appears to have done so on the basis that the
rejection of their bids, without an opportunity to present their case would not be ―legally correct.
This is reflected in the following decision which was taken by the Board on 10 August 2018:
―(a) To call the bidding entities for GA- 61, GA-62 and GA- 72 which quoted for PNG
domestic connections higher than fixed vide note that 23.07.2018 for discussion on
14.08.2018 to present their case as to why the bids submitted by them for PNG
domestic connections be not considered unreasonably high. The Board also decided
that under these circumstances, it would not be legally correct to reject their bids
without providing them a chance to present their case.
23. On 10 August 2018, a press release was issued by the Board. In pursuance of the decision which
was taken by the Board, on 14 August 2018 presentations were made before it by the three entities
for GAs 61, 62 and 72 which had quoted more than 100 per cent of the number of 2011 households.
Apart from the above three GAs, the financial bid for Puducherry (GA 51) was opened on 18 August
2018. The bidder with the highest composite score for GA 51 had also quoted more than 100 per
cent of the total 2011 households and was called on 23 August 2018 for a presentation before the
Board.
24. On 28 August 2018, an agenda note was prepared with respect to the Board‘s decision on four
GAs: 51, 61, 62 and 72. The agenda note contained a summation of the submissions made by each of
the four bidders who had been called upon to explain why their bids in excess of 100 per cent of the
total number of households as per 2011 Census data should not be considered unreasonably high.
The agenda note contained a tabulation of the percentage of PNG penetration in the projectedAdani Gas Limited vs Petroleum And Natural Gas Regulatory ... on 17 February, 2020

households in 2026 with respect to the number of households as per the 2011 Census. The
comparative table is extracted below:
Sl    GA           GA                 PNG        HH as per 2011      Projected        PNG           PNG
No.   ID                          connections   Census i.e. Upper   HH in 2026*   penetration   penetration
                                   quoted by      Limit of PNG                     in 2026 as    in 2026 as
                                   the bidder   Connections fixed                 per PNGRB        per H1
                                                   by PNGRB                       upper limit      bidder
A     B             C                 D                E                F          G=(E/F)       H=(D/F)
                                                                                     *100          *100
1     51       Puducherry          2,75,000         2,31,513         3,91,852        59%           70%
2     61      Kanchipuram          11,51,111        10,06,245        20,89,765       48%           55%
3     62         Chennai                            12,70,391        20,87,729
                Tiruvallur                          10,63,109        21,34,971
             Total (Chennai &      33,00,000        23,33,500        41,87,734       56%           79%
                Tiruvallur)
4     72   Ranga Reddy (except     10,05,300        4,56,557         10,17,097       45%           99%
             authorised area)
           Presently, Medhchal,
              Rangareddy &
            Vikarabad Districts
25. The Board held a meeting on 29 August 2018. During the meeting, the Board approved the
submission of the following three bidders who had made presentations before the Board with
respect to the reasonableness of their quotes:
―GA-51: Consortium of SKN Haryana City Gas Distribution Pvt. Ltd.
GA-61: Consortium of AG&P LNG Marketing Pte Ltd. & Atlantic Gulf & Pacific
Company of Manila Inc. GA-62: Torrent Gas Private Limited. The Board however
rejected the submission of Torrent Gas Private Limited in respect of the
reasonableness of its quote for GA 72 and decided to award the LOI to Megha
Engineering & Infrastructure Private Limited, the entity with the highest composite
score after Torrent Gas Private Limited was disqualified. The basis of the decision of
the Board is contained in the following extracts from the minutes of 29 August 2018
meeting:Adani Gas Limited vs Petroleum And Natural Gas Regulatory ... on 17 February, 2020

―2. The Board further deliberated as under:
(a) Following the earlier decisions, the three bidders i.e. Torrent Gas Private Limited,
Consortium of AG&P LNG and SKN Haryana City Gas Private Limited were called for
discussion on 14th and 23rd August 2018 to explain reasonableness of high PNG
connections quoted by them for the above GAs.
(b) The Board referred to table in Para 15 of the agenda note wherein quoted PNG
domestic connections for the above four GAs were compared with the upper limit
fixed vide noted dated 23.07.2018 and projected households in 2026 (considering the
number of households as per 2011 Census and the historical growth rate during 2001
to 2011 as per census data of 2001 to 2011). It was observed that penetration of PNG
domestic connections based upon upper limit fixed by PNGRB with reference to
projected number of households in 2026 varied from 45% to 59%. However,
penetration of PNG domestic connections based upon quoted PNG connections with
reference to projected number of households in 2026 varied from 55% to 99%. The
variation between two sets of numbers is 7% to 54%.
(c) The Board observed that the highest variation of 54% is in GA-72, which is based
on untenable assumptions made by the bidder as described in Para 14.3 of the agenda
note. Due to this, 10,05,300 PNG domestic connections quoted by the bidder are 99%
of the projected households by PNGRB in 2026, which is unreasonably high. It was
also observed that for the remaining 3 GAs, the variation between two sets of
numbers given in para 15 of the Agenda note is 7% to 23% of projected number of
households in 2026 and PNG penetration would be in the range of 55% to 79%.
(d) The Board also referred to regulation 16(2) of CGD Authorisation Regulations, which provides
for rates of pre-determined penalty for shortfall in achieving cumulative work program targets for
each contract year. The entities bidding aggressive number of PNG domestic connections would be
liable to pay pre-determined penalties under afore-mentioned regulation 16(2).
(e) In view of the above, it was decided to accept the quoted PNG domestic connections and award
the Chennai & Tiruvallur District GA (GA-62) to Torrent Gas Private Limited, Kanchipuram District
GA (GA-
61) to Consortium of AG&P LNG Marketing Pte. Ltd & Atlantic Gulf & Pacific Co. of Manila Inc. and
Puducherry District GA (GA-51) to Consortium of SKN Haryana City Gas Distribution Pvt. Ltd. and
Chopra Electricals to the bidders with highest composite score for respective GAs, where the
variation in two sets of numbers is in the range of 7 to 23%. Regarding Medchal, Rangareddy (except
area already authorised) & Vikarabad District GA (GA-72), where the variation is around 54% and
the bid by Torrent Gas Pvt. Ltd. is based on untenable assumptions and incorrect map, the bid of the
entity with highest composite score may be considered as unreasonably high and rejected in terms
of Clause 4.4.1 of ACBD. Accordingly, the GA may be awarded to the bidder with second highest
composite score and LOI may be issued to Megha Engineering & Infrastructure Pvt. Ltd.Adani Gas Limited vs Petroleum And Natural Gas Regulatory ... on 17 February, 2020

Subsequently, on receipt of PBG, authorisation letter (Schedule D) may be issued to the above
entities. The Board issued LOIs to SKN Haryana City Gas Distribution Private Limited and Chopra
Electricals11, AG & P LNG Marketing Private Limited and Atlantic Gulf & Pacific Company of
Manila12 and Torrent Gas Private Limited on 30 August 2018 as successful bidders for GAs 51, 61
and 62 respectively. On 6 September 2018 Adani Gas Limited wrote to the Board requesting a copy
of the decision with respect to the issuance of LOIs for the above three GAs. Subsequently, the Board
uploaded the details of the successful bidders under the ninth CGD round on its website on 14
September 2018.
26. On 19 September 2018, Appeal No 292 of 2018 was instituted before the APTEL by Adani Gas
Limited, aggrieved by:
(i) The decision to award LOIs, in respect of the three GAs – 51 (Puducherry District),
61 (Kanchipuram District), and 62 (Chennai & Tiruvallur Districts) on the ground
that the successful bids were beyond the unreasonably high limit adopted by the
Board; and
(ii) The action of the Board in issuing the LOIs without uploading the decision on the
website and without communicating it to Adani Gas Limited.
Following the institution of proceedings by Adani Gas Limited, IMC Limited also instituted
proceedings before the APTEL (Appeal No 323 of 2018) challenging the grant of authorisation by
the Board in respect of GA 61. The prayers in both appeals were identical and the Tribunal heard
both appeals together.
―SKN Haryana ―AG & P LNG
27. During the pendency of the appeal, by an order dated 11 October 2018 the APTEL directed the
Board to file an affidavit explaining its decision taken on 23 July 2018 and the reasons on the basis
of which bids were rejected, including on the ground of high and low quotes. In pursuance of the
above order, the Board filed an affidavit by which it disclosed the Board Note dated 23 July 2018
together with a compilation of documents containing board agenda notes, minutes of meetings and
press releases. On a perusal of the documents submitted by the Board, the competing standing of
the various bidders is summarised below for convenience:
      GA No            Area                   H1 Bidder             H2 Bidder
                                                                   Torrent Gas
       51           Puducherry               SKN Haryana
                                                                  Private Limited
       61          Kanchipuram               AG & P LNG             IMC Limited
                    Chennai –          Torrent Gas Private
       62                                                       Adani Gas LimitedAdani Gas Limited vs Petroleum And Natural Gas Regulatory ... on 17 February, 2020

                    Tiruvallur               Limited
In GA 51, Adani Gas Limited was the sixth highest bidder and in GA 61 Adani Gas Limited was the
third highest bidder. In Appeal No 292 of 2018 Adani Gas Limited challenged the grant of
authorisation in GAs 51, 61 and 62 and in Appeal No 323 of 2018 IMC Limited challenged the grant
of authorisation in GA 61.
28. On 28 February 2019, the APTEL pronounced a split decision. While the Chairperson allowed
the appeals filed by Adani Gas Limited and IMC Limited, the Member Technical (Petroleum and
Natural Gas) dismissed the appeals. In view of the divergence of opinion between the Chairperson
and Member Technical (Petroleum and Natural Gas), the appeals were referred to the Judicial
Member of the APTEL. The Judicial Member recused from hearing the appeal on 7 March 2019, as a
result of which proceedings were instituted before this Court. As noted earlier, the appeals pending
before the APTEL have been transferred to this Court.
Analysis
29. Having set out the facts, we now turn to the issues raised by the present dispute before this
Court. The first aspect which forms the subject matter of the controversy is the relevance of the 2011
Census data in the bidding process. The primary plank on which the appellants contend that the
2011 Census data was relevant to the bidding process was the reference to population/household
figures derived from 2011 Census data in the map annexed to the Bid Document.
30. Dr A M Singhvi, learned Senior Counsel appearing on behalf of Adani Gas Limited, submitted
that:
(i) The map which was attached to the Bid Document did not only describe the land
area but also the population and households comprised in it;
(ii) The rationale for this was that the authorisation is to lay the CGD network in a
defined land area and to service the defined households in that area;
(iii) The figures for population and number of households in the map attached to the
Bid Document were drawn from the 2011 Census;
(iv) In several areas out of the 86 GAs which were a part of the ninth round of
bidding, certain parts of the GAs were excluded from the zone of authorisation;
(v) Whenever certain parts of the GAs were excluded from the zone of authorisation,
the population/household number was proportionally reduced to reflect the
population/households as per the reduced area. Examples of the above are
Surendranagar (GA-8); and Medchal-Ranga Reddy (GA-72).
(vi) In GA 72, Medchal-Ranga Reddy:Adani Gas Limited vs Petroleum And Natural Gas Regulatory ... on 17 February, 2020

(a) The original map attached to the Bid Document showed the entire district with a
corresponding number of households of 13,47,118 according to the 2011 Census;
(b) The Bid Document was amended to exclude the area in which an existing entity
was already laying a CGD network as a result of which not only was the land area
reduced but even the number of households was reduced to 4,56,557;
(c) Torrent Gas Limited Private Limited, which was the highest bidder for the
reduced area had bid 10,05,300 PNG connections, which worked out to 74.6 per cent
of the original number of households (13,47,118) and 220 per cent of the reduced
number of households (4,56,557);
(d) The Board, at its meeting on 29 August 2018 rejected the H1 bidder for GA 72 on
the ground that the bid of 220 per cent of the households was unreasonably high; and
(e) The bid of the H1 bidder for GA 72 was in fact 99 per cent of the estimated
households for 2026 but was yet rejected as the ‗unreasonably high‘ norm was with
reference to the 2011 census and not 100 per cent of the 2026 estimate because if it
was the latter, the H1 bidder would have been declared to be successful.
(vii) The map annexed to the Bid Document depicted not only the land area but also
the population/number of households which were intrinsically intertwined in the bid
parameters;
(viii) Clause 1.1.3 of the Bid Document mandated bidders to look at the ―existing
population. Hence, it is incorrect to suggest that the bidders had to keep in mind the
population in the GAs in 2018. On the contrary, Clause 1.1.1 required bidders to bear
in mind the population/households as given in the map annexed to the Bid
Document; and
(ix) The reference to ‗charge areas‘ in Clause 1.1.2 of the Bid Document means
designated sub-areas which are part of the authorised GAs.
The designation of ‗charge areas‘ is only to facilitate the Board in determining whether the
authorised entity has created its network in all the GAs for which it is authorised.
31. Opposing the above submissions, Mr Paras Kuhad, learned Senior Counsel appearing on behalf
of the Board submitted a written note, explaining the amendments that were made to the CGD
Authorisation Regulations after they were notified initially on 19 March 2008:
(A) 2008 CGD Authorisation Regulations:
Regulation 7 of the 2008 CGD Authorisation Regulations prescribed a four- fold criterion for
bidding:Adani Gas Limited vs Petroleum And Natural Gas Regulatory ... on 17 February, 2020

(i) Criteria (a) was the lowness of the present value of the overall unit network tariff
with a weightage of 40 per cent;
(ii) Criteria (b) prescribed the lowness of the present value of the compression charge
for CNG for dispensing in the CNG stations with a weightage of 10 per cent;
(iii) Criteria (c) prescribed the highness of the present value of the inch-
kilometre of steel pipelines proposed to be laid in the CGD network during the period of exclusivity
with a weightage of 20 per cent; and
(iv) Criteria (d) prescribed the highness of the present value of the number of domestic customers
proposed to be connected by PNG with a weightage of 30 per cent.
Under the Regulations, no upper or lower ceiling was provided for bidding in respect of the Criteria
(a) to (d) of Regulation 7.
(B) 2013 Amendment to the CGD Authorisation Regulations13:
(i) The 2013 amendment amended criteria (a) and (b) and substituted bidding
criteria (c) and (d) with criteria (c);
21 June 2013
(ii) The successful bidder was required to achieve a Minimum Work Programme14 in respect of the
PNG domestic connections and inch- kilometres of steel pipeline;
(iii) The minimum number of PNG domestic connections to be achieved within the first five years of
authorisation was to be worked out by the Board. This was based on the total number of households
to be calculated as per the basic data sheet of the respective districts of the GA and the population
according to the latest census data;
(iv) The weightage of bidding was shifted to 70 per cent for criteria (a) and 30 per cent for criteria
(b). No weightage was given to PNG domestic connections and inch-kilometres of pipeline; and
(v) The successful bidder was to achieve a target of 15 per cent by the second year, 50 per cent by the
third year, seventy per cent by the fourth year and 100 per cent by the fifth year.
(C) 2014 Amendment to the CGD Authorisation Regulations15:
(i) The 2014 amendment substituted criteria (c) once again;
(ii) Under the 2014 amendment, the Board was to work out the target for
infrastructure for PNG domestic connections as 5 per cent of the households of theAdani Gas Limited vs Petroleum And Natural Gas Regulatory ... on 17 February, 2020

respective GAs to be achieved by the successful bidder during the first five years from
the grant of authorisation; and
(iii) No weightage was given to criteria (c) – PNG domestic connections and
inch-kilometres.
―MWP 7 April 2014 (D) On 16 August 2016, the Ministry of Petroleum and Natural Gas constituted
a committee to examine alternative models for the bidding criteria to grant authorisation for CGD
networks. The committee in its report recommended a MWP for PNG domestic connections at 7.5
per cent, within district headquarters/municipal limits. Prior to the ninth round, the MWP was fixed
at 5 per cent of the total households.
(E) 2018 Amendment to the CGD Authorisation Regulations16:
(i) The 2018 amendment substituted new criteria for bidding applicable to the ninth
round. The present batch of appeals deals with the ninth round of bidding; and
(ii) Under the new criteria applicable to the ninth round of CGD bidding, 50 per cent
weightage was given to PNG domestic connections.
Moreover, no minimum or maximum limits were set for PNG domestic connections in the 2018
amendment.
Responding to the appellant‘s submissions on the binding nature of the Board Note dated 23 July
2018 and the legality of the Board‘s decision to hear only the highest bidder, Mr Paras Kuhad urged
that:
(i) The agenda note dated 9 August 2018 is not binding on the Board as it clearly
states that the contents of the agenda note are subject to the deliberations and
approval of the Board;
(ii) Regulation 7 sets out five parameters on which the bids are to be evaluated. Once
a bidder fulfils the criteria set out in Regulations 5 6 April 2018 and 7 and emerges as
the highest bidder, they have a statutory right to be selected;
(iii) The CGD Authorisation Regulations do not set out criteria for determining ―unreasonably high
or low bids and no such criteria can be read into the Regulations and enforced on the Board;
(iv) Clause 4.4.1 read with Addendum 1 explicitly states that the Board‘s power to determine
―unreasonably high or low bids would be exercised on a ―case to case basis after considering the
relevant factors;
(v) The challenge made by the appellants is an adversarial challenge and not a Public Interest
Litigation. The appellants cannot try and advance their case by relying on decisions taken in relationAdani Gas Limited vs Petroleum And Natural Gas Regulatory ... on 17 February, 2020

to separate GAs which are not presently under challenge; and
(vi) The calculations made by the appellants with respect to the growth rate and projected number
of households are based on irrelevant factors.
32. Mr Gopal Subramanium, learned Senior Counsel appearing on behalf of Torrent Gas Private
Limited, supported the arguments urged by the Board and further submitted that:
(i) Torrent Gas Limited has attended the hearing before the Board, explained its
methodology in calculating its quoted number of PNG connections, and the quoted
figure has been accepted by the Board as reasonable;
(ii) The Board Note dated 23 July 2018 had been formulated subsequent to the
submission of bids. At the time of submitting its bid, the only criteria known to
Torrent Gas Private Limited were those specified in Regulation 7 and the Bid
Document, which did not prescribe a maximum number of PNG connections; and
(iii) There is no condition in either the CGD Authorisation Regulations or the Bid
Document which require the quoted number of PNG connections to be calculated on
the basis of 2011 Census data.
33. Mr Gopal Sankaranarayanan, learned Senior Counsel appearing on behalf of SKN Haryana,
urged that:
(i) Adani Gas Limited was neither the second nor third placed bidder in GA 51 on the
basis of the composite score, and therefore has no standing to challenge the LOI
granted to SKN Haryana for GA 51;
(ii) Clause 14.2 of the First Addendum makes it clear that there were no fixed
parameters on which an ―unreasonably high or low bid would be determined, and
specified that such determination would take place on a case to case basis; and
(iii) According to the calculation of composite scores in Schedule C(1), the bidder
with the highest number of PNG connections is at 100% and all other bidders are
reduced in proportion to the highest bidder‘s score. If 100% of the 2011 Census data
was a ‗hard upper limit‘ on the quoted number of PNG connections, the calculation
in Schedule C(1) would be rendered redundant.
34. Mr Kapil Sibal, learned Senior Counsel appearing on behalf of AG & P LNG, submitted as
follows:
(i) AG & P had quoted a figure of 11.51 lakh in its bid for GA 61.Adani Gas Limited vs Petroleum And Natural Gas Regulatory ... on 17 February, 2020

According to the 2011 Census figures, the number of households in GA 61 was only 10.06 lakhs.
However, the Tamil Nadu Generation & Distribution Corporation Limited (the state electricity
board) noted that as of 2018, there existed 15.91 lakh households in GA 61;
(ii) In GA 37, Indian Oil Corporation had quoted a number of PNG connections below the 2%
threshold and was the highest bidder. The Board awarded the GA to Bharat Gas Resource Limited,
which had quoted above the 2% threshold. However, Indian Oil Corporation has not challenged this
decision of the Board before the APTEL or any court, therefore the appellants cannot rely on the
case of GA 37; and
(iii) Each GA is a separate tender having its own unique geographical and socio-economic factors.
Therefore, one cannot compare cases of other GAs with the GA of Kanchipuram where AG & P LNG
has been awarded the authorisation.
35. The submission which has been urged on behalf of the appellants in regard to the relevance of
the 2011 census data must first and foremost be assessed in the context of the CGD Authorisation
Regulations as amended on 6 April 2018. The Regulations postulate that bidders must submit both
technical and financial bids. The procedure specified in Regulation 5 applies to an invitation by the
Board for laying, building, operating or expanding a CDG network. Regulation 5(6) requires the
fulfilment of minimum eligibility criteria. For a technical bid to pass muster, the minimum eligibility
criteria require the bidder to be qualified both with reference to technical and financial parameters.
This is evident from Regulation 5(6) under which the Board is to scrutinise the bids of only those
entities which fulfil the minimum eligibility criteria. The minimum eligibility criteria include the
technical capability of the bidding entity to (i) lay and build; and (ii) operate and maintain a CGD
network. Both of them are defined with reference to qualifying criteria. Besides the technical
criteria, the minimum eligibility requirements under Regulation 5(6)(e) incorporate the financial
ability to execute the project and to operate and maintain it in the authorised area. The financial
criteria are defined with reference to the minimum net-worth of the bidding entity. The net-worth
required is dependent on the population of the GA under the 2011 Census. The minimum net-worth
required is specifically defined with reference to the 2011 census figures of population for the GA.
The bidding entity is also required to submit a bid bond in the form of a performance bond
guarantee. The quantum of the guarantee is dependent on the population of the GA.
36. Regulation 7 requires the Board to tabulate all financial bids which meet the minimum eligibility
criteria, in accordance with the bidding criteria specified in the table. The Table incorporated in the
Regulation provides five-fold criteria for the tabulation and comparison of financial bids. The five
criteria are:
(i) ‗Lowness‘ of transportation rate for CGD;
(ii) ‗Lowness‘ for transportation rate for CNG;
(iii) ‗Highness‘ of the number of CNG stations to be installed in eight years from authorisation;Adani Gas Limited vs Petroleum And Natural Gas Regulatory ... on 17 February, 2020

(iv) ‗Highness‘ of the number of domestic PNG connections to be achieved within eight years of
authorisation; and
(v) ‗Highness‘ of inch-kilometre of steel pipeline to be laid within eight years of authorisation.
The third and fourth criteria together account for 70 per cent of the total composite score. Among
them, the fourth criterion – ‗highness‘ of the number of domestic PNG connections accounts for 50
per cent of the total composite score. Significantly, the bidding criteria in Regulation 7 are not linked
to the 2011 Census figures. There are two significant facets of Regulation 7:
(i) The absence of a linkage of the projected number of domestic PNG connections
with the 2011 Census data; and
(ii) The absence of a cap or ceiling on the ‗highness‘ norm both in relation to the
third and the fourth criteria (iii and iv above).
37. Regulation 7 (1)(b) requires the successful bidder to achieve the target in terms of an annual
work programme within eight contract years. The programme is distributed between the first and
eighth years for PNG connections‘, CNG stations‘ and Inch-kilometres of steel pipelines. For PNG
connections, the successful bidder must complete 10 per cent of the work programme at the end of
the second year, 20 per cent at the end of the third year, 30 per cent at the end of fourth year, 40 per
cent at the end of the fifth year, 60 per cent at the end of the sixth year, 80 per cent at the end of the
seventh year and 100 per cent at the end of the eighth year. Under Regulation 7(3), a bidding entity
with the highest composite score in terms of the criteria specified in sub-regulation (1) of Regulation
7 is to be declared as the successful bidder.
38. The provisions contained in the 2008 CGD Authorisation Regulations, as amended on 6 April
2018, indicate that where a specific linkage was sought with reference to the 2011 Census data, a
clear and categorical provision was made to that effect. Such provisions are found in regard to the
financial capability of a bidder as part of the minimum eligibility criteria in Regulation 5(6)(e) and
the extent of the performance bond in Regulation 5(6)(h).
39. Absent a condition in Regulation 7 linking the ‗highness‘ of the number of PNG connections to
be achieved within eight years from the date of authorisation with the 2011 Census data, it would be
contrary to basic principles of interpretation to read such a restriction into the CGD Authorisation
Regulations. A conditionality which has not been incorporated in Regulation 7 cannot be introduced
as a matter of construction. The court must first and foremost read the Regulation in accordance
with its plain and natural meaning. There is evidently a reason why Regulation 7 did not introduce a
ceiling or provide for a linkage with the Census data of 2011. Consumers or users, as the case may
be, in a CGD network broadly comprise of four categories namely:
      (i)     Domestic;
      (ii)    Commercial;Adani Gas Limited vs Petroleum And Natural Gas Regulatory ... on 17 February, 2020

      (iii)   Industrial; and
      (iv)    Vehicular.
40. The Board has submitted with justification that in a model of cross/subsidisation, the viability of
the project has to be perceived from a twenty- five-year perspective. Gains in one category of users
can offset the losses in another category. The CGD Authorisation Regulations are intended to
subserve the object of establishing the infrastructure necessary for setting up an operational CGD
network. In creating the infrastructure, the successful entity is contractually bound to set up a
project for the future. The infrastructure so created would be of service to consumers or, as the case
may be, users. Infrastructural projects cater to future needs and can legitimately be forward looking.
It is from this perspective that except for the tariff in the first two bidding criteria of Regulation 7
(the transportation rates for CGD and CNG), no ceiling was provided by the Board for the criteria set
out in Regulation 7. More particularly, Regulation 7(3) provided for a mandate to tabulate and
compare the bids of all entities which had met the minimum eligibility criteria upon their qualifying
in a competitive bidding process. The Regulations did not contemplate the disqualification of a
bidder with reference to a norm which would limit a bid to 100 per cent of the population figures
provided by the 2011 Census data. For the Board to stipulate an absolute norm to that effect, when it
has not been specifically incorporated in the Regulations would have rendered the decision making
process vulnerable to a challenge on the ground that it was not consistent with Regulation 7.
41. Now it is in this background, that it becomes necessary to evaluate the Bid Document. Clause
1.1.1 incorporates a reference to the GA as depicted in the map set out in Annexure-1, for which the
Board was inviting bids for the grant of an authorisation to develop a CGD network. The main plank
of the submissions of the appellants is that the map contained a reference to population and
household figures on the basis of the 2011 Census. Clause 1.1.3 places the responsibility on the
bidder to obtain information about the present gas supply availability, the pipeline connectivity and
the existing customers in the GA. Significantly, the scope of work in Clause 1.2 required bidding
entities ―to lay, build, operate or expand the CDG networks to meet the requirement of natural gas
―in domestic, commercial and industrial segments including natural gas in the vehicular segment in
the said Geographical Area to be authorised. Bidders are required under Clause 2.1.1 to examine
the contents of the Bid Document including instructions, terms and conditions and regulations of
the Board. The bidder was required to carefully study the GA and the charge area before submitting
the bid. In other words, bidders were on notice of the actions required to be taken to implement the
Regulations. The Bid Document necessarily had to be in conformity with the CGD Authorisation
Regulations. The map, at best was a compendium of the latest official record of the GA. The map did
not dictate how the number of domestic PNG connections was to be calculated. There is no such
indication particularly in Clause 1 of the Bid Document where the map is referenced. The mere
attachment of a map to the Bid Document would not result in the imposition of conditions of
eligibility or qualification. These have been provided in the Regulations which have a statutory
character. The depiction of the GA in a map attached to the bid document does not over-ride the
specific requirements of the bidding criteria as defined in Regulation 7.Adani Gas Limited vs Petroleum And Natural Gas Regulatory ... on 17 February, 2020

42. The next basis of the challenge by the appellants is that the decision which was taken in the form
of the Board Note dated 23 July 2018 had categorically stipulated a range of 2 per cent to 100 per
cent of the number of households as per the 2011 Census as the minimum/maximum thresholds to
judge the reasonableness of the bids. It has been urged that despite this, the decision of the Board
dated 10 August 2018 virtually reversed the earlier decision recorded in the Board Note of 23 July
2018, thereby tainting the decision-making process with arbitrariness. The nuances to this challenge
have been brought out in the submissions of Dr AM Singhvi, Mr Vikas Singh, learned Senior
Counsel on behalf of Adani Gas Limited and Mr KV Vishwanathan and Mr Buddy Ranganathan,
learned Senior Counsel on behalf of IMC Limited and can broadly be catalogued in the form of the
following points:
(i) The 2 - 100 per cent criterion based on the 2011 Census data is the basis on which
the bids for 79 out of 86 GAs were evaluated;
(ii) In respect of the bids for four GAs (out of the remaining seven GAs) where the
highest bidder had bid a number of PNG connections below 2 per cent of the number
provided by the 2011 Census, those four bidders were furnished with an opportunity
to improve their bids and match the 2 per cent threshold;
(iii) It is only for the three bidders with the highest composite scores in GAs 51, 61
and 62 that the bids were evaluated with reference to the projected number of
households in 2026;
(iv) For example, in GA-62 (Chennai-Tiruvallur), there were ten bidders of whom the
bids of nine were evaluated with reference to the 2011 Census data on the number of
households, whereas the bid of one bidder (Torrent Gas Private Limited) has been
evaluated with reference to the number of projected households in 2026;
(v) The agenda note dated 9 August 2018 which was approved by three out of the four
Board members recommended that Torrent Gas Private Limited was not qualified
and Adani Gas Limited be declared as the successful bidder. Yet on 10 August 2018,
the four Board members including the three who had approved the Board Note
concluded that, though the lower and upper thresholds were decided ―the same need
not be a mechanical exercise;
(vi) Neither the Bid Document nor the CGD Authorisation Regulations contain any
provision allowing the Board to call upon bidders to improve their bids;
(vii) The Board Note dated 23 July 2018 which defined the minimum and maximum
threshold (2-100 per cent of the number of households as per the 2011 Census)
without any caveat or provision for relaxation has been virtually reversed on 10
August 2018, thereby upsetting the level playing field between bidders;Adani Gas Limited vs Petroleum And Natural Gas Regulatory ... on 17 February, 2020

(viii) The only reason for the reversal of the decision, which is that the criterion need
not be a mechanical exercise is not supported by reasons and this volte face
introduced un-canalized subjectivity in the process which was earlier considered to
be objective and definite;
(ix) The Board decision dated 28 August 2018 wrongly adopts the 2011 Census
number as 23,33,500 whereas in the Board Note, the number of households as per
the 2011 census is 21,01,931;
(x) There has been a breach of the principles of natural justice for the following
reasons:
(a) In the Board decision dated 10 August 2018, it was decided to give a hearing to all
affected parties;
(b) The Board undertook the exercise of hearing only Torrent Gas Limited, AG & P
LNG and SKN Haryana; and
(c) The violation of natural justice lies in the fact that these ―not-
qualified bidders were heard on why their bids were reasonable despite being above 100 per cent of
the 2011 Census household data. Neither Adani Gas Limited nor any of the other unsuccessful
bidders were heard on why the bids of the ―not-qualified bidders were actually unreasonable.
(xi) This Court is justified in reviewing the process adopted by the Board in evaluating the bids for
the ninth round of CGD bidding. It is well settled that judicial review cannot be denied even in
contractual matters to prevent arbitrariness.
43. Our analysis of the CGD Authorisation Regulations, as amended on 6 April 2018, as explained
earlier, reveals that the Regulations did not contain any stipulation determining a range of 2 to 100
per cent of the number of households under the 2011 Census as the criterion to evaluate bids. The
Regulations in fact do not link the ‗highness‘ factor of domestic PNG connections to the 2011
Census data. In Clause 4.4.1 of the Bid Document, the Board reserved to itself the right to reject any
unreasonably high or low bid. In Addendum-1 to the Bid Document, the Board clarified to all
prospective bidders that the evaluation of whether a bid was unreasonably low or high would be
conducted on a case to case basis at the time of bid evaluation.
44. It is in the above background that the Board Note dated 23 July 2018 must be assessed. The
Board Note was formulated after the last date for the submission of bids. The criterion which the
Board Note proposed had not been notified to bidders. Bidders were not on notice that this would be
the basis on which their bid would be evaluated. The Board Note took notice of Clause 4.4.1 of the
Bid Document and stipulated that since technical bids for some GAs were about to be evaluated, it
was necessary to decide upon the reasonableness of the bidding parameters which constituted the
work programme. It was in this background that the Board Note proposed that; ―…2 per cent ofAdani Gas Limited vs Petroleum And Natural Gas Regulatory ... on 17 February, 2020

total households (as per the 2011 Census data) may be considered as minimum. As regards the
maximum, the Board note proposed that:
―beyond 100 per cent households may be treated as unreasonably quote (Emphasis
supplied) The terminology adopted by the Board Note indicates that the 2-100 per
cent range was not laid down as an absolute or inflexible basis for disqualifying bids
below the minimum or in excess of the maximum. On the contrary, the use of the
expression ―may be is one indicator that a bid which was below 2 per cent or in
excess of 100 per cent may trigger the exercise of the power which the Board had
reserved to itself in clause 4.4.1 of the Bid Document. On its plain terms, the Board
Note cannot be construed to have laid down an absolute norm by which bids quoting
below the minimum of 2 per cent or above the ceiling of 100 per cent of the number
of households under the 2011 Census data would automatically be rejected as
unreasonable.
45. If the Board Note of 23 July 2018 were to be construed in the manner in which the learned
Senior Counsel for the appellants urged, the automatic disqualification of bidders based on a
criterion introduced by the Board Note would raise serious doubts about its fairness and legality.
This is because the Board Note was not notified to bidders as a basis for the evaluation of bids before
the date for the submission of the bids had closed. To disqualify a bidder on the basis of a criterion
which was not notified and of which bidders had no knowledge would be arbitrary and would
constitute an infraction of Article 14. The Board was thus correct in determining that the automatic
disqualification of a bid on the basis of a criterion specified in the Board Note (which was never
notified to the bidders) would not be ―legally correct. Hence, it would be reasonable to interpret
the Board Note dated 23 July 2018 as being the formulation of a guideline for the Board. As a
guideline in the process of evaluation, the decision taken by the Board on 23 July 2018 was not to
the effect that every bid below 2 per cent or above 100 per cent would necessarily stand disqualified.
Consistently with the use of the word ‗may be‘, as already noticed, the decision of the Board meant
that the power which the Board reserved to itself in Clause 4.4.1 could be invoked if it came to the
conclusion that the bid had not been justified to be reasonable. In other words, the breaching of the
range of 2-100 per cent was a trigger for the Board to scrutinise the bid and determine whether the
power under Clause 4.4.1 should be invoked. Hence, the course of action which the Board followed
of calling upon the bidders with the highest composite scores in GAs 51, 61 and 62 to justify their
bids in terms of their reasonableness cannot be faulted. On the contrary, if the Board had rejected
these bids solely on the ground that they were above the limit of 100 per cent of households under
the 2011 Census data, the decision would have been seriously flawed for having applied a criterion
which was not a part of the Regulations, was not embodied in the Bid Document and in any event,
was not notified to bidders before they had submitted their bids.
46. Another limb of the submission is that, with respect to GA 62, three out of the four members of
the Board had in the Board agenda dated 9 August 2018 recommended that Torrent Gas Private
Limited was not qualified and that Adani Gas Limited be declared as the successful bidder. This, in
our view, is an incorrect reading of the agenda note. What this submission misses is the last
paragraph of the Board agenda note which states:Adani Gas Limited vs Petroleum And Natural Gas Regulatory ... on 17 February, 2020

―20. This Agenda note has been prepared by Authorization Division, concurred by
Member (I&T) & Member (C&M) and approved by Chairperson for deliberations and
approval of the Board. (Emphasis supplied) The agenda note dated 9 August 2018
was a recommendation which was prepared on the basis of the 2–100 per cent
criterion contained in the Board Note dated 23 July 2018. Obviously in the light of
that decision, a recommendation was made which was still to be deliberated upon by
the Board as a body. When the Board met on 10 August 2018, it correctly came to the
conclusion that the lower and upper thresholds were not to be applied mechanically
to disqualify bidders. This decision, as we have indicated earlier, was justified not
only by the terms of the Board Note dated 23 July 2018 but was intrinsic to a fair
exercise of power by the Board. The Board decided that it would call the bidders with
the highest composite score to explain the reasonableness of their bids. This was a
fair opportunity which was granted to the bidders who had the highest composite
score to justify the basis of their computation of projected households over the
eight-contract years.
47. There is no merit in the submission that there was a breach of the principles of natural justice in
calling only the bidders with the highest composite score to explain the reasonableness of their bids.
None of these bidders was being called upon to revise or improve their bids. In terms of the CGD
Authorisation Regulations, the bidder with the highest composite score has to be declared as the
successful bidder. If despite having the highest composite score, a bidder was being considered for
rejection by the Board, it was that bidder who was justifiably called to explain the reasonableness of
the bid. The other bidders had no locus to participate in the process. It is a settled principle of law
that the rules of natural justice are attracted where a decision affects a right of a party against whom
the decision has to be made. After the composite score of all bidders is calculated, the second highest
bidder has no rights vis-à-vis the highest bidder or the Board unless the method of calculating the
highest composite score itself is impugned. Calling upon the bidders with the highest composite
score to explain the reasonableness of their bid did not alter the composite score of the H1 bidders
or any other bidder for the same GA. The question of hearing any other bidder would have arisen
only if the H1 bidder stood disqualified, and the bidder with the next highest composite score also
breached the 2-100 per cent range, thereby warranting scrutiny from the Board. In the present
situation, when the Board decided to call the bidders with the highest composite score in order to
allow them an opportunity to explain reasonableness of their bid, the administrative decision taken
by the Board cannot be faulted as being in violation of the principles of natural justice.
48. At the 82nd meeting of the Board, which was held on 29 August 2018, the reasonableness of the
bids submitted for GAs 51, 61, 62 and 72 came up for consideration. In GA 62 (Chennai-Tiruvallur)
Torrent Gas Private Limited, relied on the current LPG domestic connections (41,73,073) according
to the statistics of the Tamil Nadu government. This was extrapolated until 2026 taking the growth
rate at 5 per cent per annum. On this basis, Torrent Gas Private Limited as the H1 bidder justified
before the Board its quoted figure of PNG connections of thirty-three lakhs. For GA 61
(Kanchipuram), AG & P LNG explained that its computation was based on:
(i) The urbanisation rates in the Kanchipuram district;Adani Gas Limited vs Petroleum And Natural Gas Regulatory ... on 17 February, 2020

(ii) Extrapolations of the number of households based on historical growth rates;
(iii) The twin city status of Chennai and Kanchipuram; and
(iv) The per capita income growth in Kanchipuram district.
On this basis, AG & P LNG justified its number for projected PNG connections. For GA-51
(Puducherry), SKN Haryana based its computation on the compound yearly growth of households in
the previous twenty years. Based on this growth rate, the bidder calculated the projected households
till 2026 and accordingly presented this computation to the Board when called upon.
49. In its minutes dated 29 August 2018, the Board noted that the four GAs:
51, 61, 62 and 72 were compared with the upper limit fixed by the agenda note dated
23 July 2018 and projected households in 2026. The penetration of PNG domestic
connections based on the upper limit fixed by the Board with reference to the
projected number of households in 2026 varied from 45 per cent to 59 per cent.
However, the penetration of PNG domestic connections based on quoted PNG
connections with reference to the projected number of households in 2026 varied
from 55 per cent to 99 per cent. The variation between the two sets of numbers was
between 7 per cent to 54 per cent. The Board noted that it was in GA 72 where the
highest variation of 54 per cent took place. The bid submitted by Torrent Gas Private
Limited for GA 72 was consequently rejected. The Board observed that the
computation for GA 72 by Torrent Gas Private Limited was based on untenable
assumptions as described in para 14.3 of the agenda note. According to these
assumptions, the PNG domestic connections quoted by the Torrent Gas Private
Limited was 99 per cent of the projected households by 2026 which was taken as an
unreasonably high penetration figure. However, for the remaining three GAs, the
variation was between 7 per cent to 23 per cent of the projected households in 2026,
and PNG penetration would be in the range of 55 per cent to 79 per cent. This
exercise was carried out by the Board to enable it to consider the reasonableness of
the bids. Torrent Gas Limited, whose bid was accepted for GA 62, was however not
considered for acceptance for GA 72 since its computation of the number of projected
households and penetration rate was deemed unreasonable. In our view, the Board
has certainly given a possible basis for coming to the conclusion that the bids
submitted by the bidders with the highest composite score for GAs 51, 61 and 62 were
reasonable and ought not to be rejected.
50. The agenda note dated 9 August 2018 merely tabled discussion on the disputed GAs. The highest
bidders for GAs 61 and 62 were heard by the Board on 14 August 2018. The highest bidder for GA 51
was heard by the Board on 23 August 2018. The final decision to award authorisation in GAs 51, 61
and 62 to AG & P LNG, Torrent Gas Private Limited and SKN Haryana (the highest bidders)
respectively was finally taken by the Board in its meeting on 29 August 2018. This decision was
taken after hearing the bidders on whether their bids were reasonable or not. The Board did notAdani Gas Limited vs Petroleum And Natural Gas Regulatory ... on 17 February, 2020

reject all other bidders or presumptively announce these entities as successful bidders before
making a determination as to the reasonableness of their bids. In light of this chronology of events,
at no point did the Board reverse its decision with respect to the GAs in question.
51. The appeals before APTEL pertained to GAs 51, 61 and 62. The present proceedings were not in
the nature of a public interest litigation instituted under Article 226 of the Constitution before a
High Court challenging the entirety of the tendering process. Both before this Court and APTEL, it
was contended that the Board had rejected bids in other GAs which were not-qualified on the
ground that they were either below 2 per cent or above 100 per cent of the number of households as
per the 2011 Census figures. The Member Technical (Petroleum and Natural Gas) at APTEL
examined the submission in paragraph 60 of the decision and held:
―60. Though the appeal pertains to only GAs, 51,61 & 62, the Appellant also submits
that the Board rejected 37 numbers of bids which were not qualified because their
bids were below 2% and higher than 100% of 2011 census figures as per the Board‘s
Press Release dated 10.08.2018 uploaded in its website. Though, the instant appeal
also strictly pertains to only highness of PNG domestic connections, still for the sake
of completeness, let me understand the status of these bids. On clarification, the
Board has stated that there were only 9 bids with H-1 bidders quoting below 2% and
above 100% limits of 2011 census. These 9 bids were accordingly highlighted to the
Board, and final decisions were taken on these 9 bids by the Board after proper
application of mind, hearing the parties and taking an objective decision. Out of 9
bids, 4 bids having lower than 2% connections were accepted after raising their bids
through discussions with the bidders, otherwise, these GAs would have gone dry. In
GA-37, IOC‘s bid was rejected because of lower than 2% quote, but this decision of
the Board has not been challenged by IOC. Out of the remaining 4 GAs where H-1
bidders quoted more than 100% of PNG connections of 2011 census household
numbers for 3 GAs (51, 61 & 62), H-1 bidders were declared successful bidders after
hearing them on their reasonableness of quotes. For the 4th GA (GA No. 72), the bid
of the H-1 bidder who is the R-2 in the instant case was rejected having found its bid
unreasonable and the GA was awarded to the next highest bidder and the H-1 bidder
has not challenged this decision. This clarification by the Board as well as the
findings which have been recorded by the Member Technical (Petroleum and Natural
Gas) commends itself for acceptance.
52. In addition to their submissions with respect to the binding nature of the 2 – 100 per cent range
set out in the Board Note dated 23 July 2018, the appellants also argued that the Compounded
Annual Growth Rate 17 considered by the Board for the period between 2001 and 2011 was higher
than the actual annual growth rate, leading the Board to project a higher number of households for
2026 than may actually exist. It was alleged that the Board used the figure of 23,33,500 as the
number of households existing in 2011 instead of 21,01,931 in calculating the growth rate, resulting
in an inflated growth rate. This high growth rate, according to the appellants, led the Board to accept
the submissions made by Torrent Gas Private Limited in justifying an ―unreasonably high quote
for the number of households for the year 2026.Adani Gas Limited vs Petroleum And Natural Gas Regulatory ... on 17 February, 2020

53. In his judgement, the Member Technical noted that the appellant had in fact calculated the
CAGR using overall population growth instead of using household growth. Evidently, for the
purpose of projecting the number of PNG connections within a GA, it is the number of households
and not the overall population that is relevant as each household is unlikely to have more than one
PNG connection. Moreover, as neither the CGD Regulations nor the Bid Document required the
number of projected households to be calculated on the basis of 2011 Census data, the decision of
the Board to accept the justification provided by the bidders cannot be attacked on the ground that
the figures provided did not strictly match the numbers extrapolated from the 2011 Census data.
Lastly, the Member Technical (Petroleum and Natural Gas) observed:
―51. … Moreover, the calculations have been done by an expert body (the Board)
which has been constituted as per Statutory Act. In addition, the estimates on future
PNG domestic connections made by the 3 bidders based on various parameters are
only estimates. These are not meant to be arrived at by any specified formula or
direct ―CAGR mathematical precision. The power to weed out unreasonably high or
low quote is only an enabling power and not a yardstick or parameter for evaluation.
(Emphasis supplied) The power granted to the Board under Clause 14.2 of the Bid
Document is an enabling clause that allows the Board to apply its mind to a quote
and determine its reasonableness. The quotes submitted by all bidders with respect
to the projected number of households in 2026 are admittedly estimates. Similarly,
the Board‘s own determination of a baseline for comparing the reasonableness of
various quotes is also an estimate. Therefore, the Board‘s use of the baseline figure
and its consequent acceptance of the reasonability of a quote cannot be faulted
because it did not strictly adhere to one particular methodology of arriving at a
number of projected households unless the methodology used is arbitrary, having no
correlation with the result sought to be achieved. We therefore approve of the finding
of the Member Technical with respect to the calculation of the number of households.
54. The present batch of appeals arises from two divergent opinions of the Chairperson and the
Member Technical (Petroleum and Natural Gas) of the APTEL. Several arguments urged by the
appellants before us find voice in the opinion of the Chairperson. Therefore, for the sake of
completeness it is necessary to briefly advert to the opinion of the Chairperson allowing the appeals.
The Chairperson observed as follows:
―136. … On 23.07.2018 certain criteria/parameters were indicated by this so called
Evaluation Committee in the Agenda Note. … This indicates that the exercise so far as
criteria/ parameters was uniform for all the bids. …. The report on Agenda Note
dated 09.08.2018, in fact, recommended that the highest bidders of GA 51, 61, and 62
were disqualified since their quote of PNG connections were beyond 100% of the total
households of 2011 census.
… However, the Minutes of the Board dated 10.08.2018 indicate that the four members of the Board
out of which three had approved Agenda Note, changed their opinion so far as disqualification of
highest bidder of these three GAs 51, 61 and 62. It‘s also noticed from the affidavit of the Board filedAdani Gas Limited vs Petroleum And Natural Gas Regulatory ... on 17 February, 2020

09.11.2018 that the Board has correctly applied the unreasonable low criteria to all the bidders
whose bid was below 2%, but surprisingly the bids which were beyond the limit of 100% of 2011
census, the Board thought it fit to relax the criteria by calling the high bidders for negotiation. If the
Board thought it fit to hear the affected parties, then it ought to have invited all the affected parties
of the said GA i.e., all the bidders who stand to lose the bid, since such procedure was exercised so
far as unreasonably low criteria to all bidders who quoted below 2% of 2011 census. Assessment of
reasonability of a bid cannot be equated with the concept of rejection of a bid as not qualified for a
particular criteria. Reasonability of a bid has reference to subjective assessment/satisfaction. The
assessment of a bid based on the available material would amount to objective assessment.
(Emphasis supplied) It is evident from the above extract that the Chairperson‘s findings are based
on three key assumptions:
(i) The Board Note dated 23 July 2018 was binding on the Board and the agenda note
dated 9 August 2018 was evidence of the Board Note‘s binding nature;
(ii) Because the Board disqualified certain other bidders by applying the 2 – 100 per
cent range, it was bound to do so against the successful bidders in GAs 51, 61 and 52;
and
(iii) Because the assessment of reasonability was a ―subjective assessment, the
Board was obligated to hear other bidders in the disputed GAs before declaring
successful bidders.
55. As noted previously, on a bare construction of the Board Note dated 23 July 2018 and the fact
that the Board Note was formulated after the last date for the submission of bids, the Board Note did
not set out absolute criteria for disqualification of bids. The agenda note dated 9 August merely
tabled a proposal to apply the criteria of 2-100 per cent range but the Board did not subsequently
adopt this course of action, a decision within its power and indeed necessary to preserve the
integrity of the bidding process. Having established that the Board Note was not an absolute binding
criteria, and the Tribunal was approached only with respect to GAs 51, 61 and 62, the Board‘s
treatment of other GAs cannot be decisive in determining the legality of the authorisations granted
in GAs 51, 61 and 62, especially where the Board‘s actions in respect of these other GAs have not
been independently challenged. Lastly, the Chairperson has construed the assessment of the
reasonability of the highest bidder‘s quote as a decision affecting the rights and liabilities of all other
bidders for the GAs, thus requiring them to be heard. As noted previously, the assessment of the
reasonability of the bid was a matter solely between the highest bidder and the Board. Such an
assessment would not alter the scores of the highest bidder vis-à-vis the scores of the other bidders.
The sole question was whether the highest bidder‘s quote was reasonable, and the power to
determine such reasonability resided solely with the Board by virtue of Clause 14.2 of the Bid
Document. Thus, the presence and hearing of other bidders was not necessary.
56. For the above reasons, we disagree with the opinion of the Chairperson and concur with the view
which was taken by the Member Technical (Petroleum and Natural Gas) to dismiss the appeals. The
Appeals are accordingly dismissed. Transferred Cases Nos 27 of 2019 and 26 of 2019 are disposedAdani Gas Limited vs Petroleum And Natural Gas Regulatory ... on 17 February, 2020

of. There shall no order as to costs.
57. Pending application(s), if any, shall stand disposed of.
…….………….…………………...........................J. [DR DHANANJAYA Y CHANDRACHUD]
……..…..…..…....…........……………….…........J. [HEMANT GUPTA] New Delhi;
February 17, 2020.Adani Gas Limited vs Petroleum And Natural Gas Regulatory ... on 17 February, 2020

