Andhra Pradesh Education Act, 1982
ANDHRA PRADESH
India
Andhra Pradesh Education Act, 1982
Act 1 of 1982
Published on 8 July 2013• 
Commenced on 8 July 2013• 
[This is the version of this document from 8 July 2013.]• 
[Note: The original publication document is not available and this content could not be
verified.]• 
Andhra Pradesh Education Act, 1982(Act No. 1 of 1982)Last Updated 12th August, 2019Statement
of Objects and Reasons - At present educational administration in the State is broadly governed by
executive rules and codes and a few enactments to meet some special requirements. The Andhra
Pradesh Primary Education Act, 1961 providing free and compulsory primary education for children
in the State has resulted in an unprecedented upward spiral of pupil enrolment and consequent
pressure for the spread of secondary education in which enrolments have nearly quadrupled over
the first three plan years. Secondary education has in its turn, given an equally powerful push for the
expansion of collegiate education. Experience in recent years has brought forth the expediency for
more comprehensive and legally valid measures in order to make the future of educational
administration more effective and fruitful.As a sequel of such significant developments, there has
also been large-scale change in the academic requirements which has made nearly obsolete the
existing text books, teaching methods, supervision, curricula, courses of study, system of
examination, teacher training, school organisation, grant-in-aid patterns and teacher welfare. This
situation naturally calls for a revised and continually rising standards in these key areas of
educational administration. Further, the existing rules have been called in question in Courts of law
as not having the necessary statutory backing. They are also not comprehensive enough to deal with
the aforesaid significant developments and have also proved ineffective in actual implementation. It
has, therefore, become necessary to confer by law adequate powers on the concerned authorities to
deal with the changed situation.The Commission on Education (Kothari Commission) set up by the
Government of India (1964-66), in its Chapter on "Educational Administration and Supervision"
discussed this problem at length and it came to the categorical conclusion that education should be
given a statutory basis everywhere and in all major and comprehensive education Acts should be
enacted in all the States and Union Territories. Pursuant to this recommendation, the State
Government embarked on the preparation of legislation in this behalf as long back as in 1969, but
due to various circumstances, the same could not be pushed through.A State-level Seminar on
Education consisting of representatives of a cross-section of the people including educationists,
educational administrators, university and school teachers, legislators and students and others
interested in education was held in March, 1974. The general consensus of this Seminar was that
there was an urgent need to undertake legislation which would not only answer the urgentAndhra Pradesh Education Act, 1982

administrative and academic problems confronting the educational system in the State but would
also be comprehensive enough to bring it in tune with the significant developments in educational
thinking.The State Government had set up a Committee, under the Chairmanship of Sri M.V.
Rajagopal, M.A., (Cantab), I.A.S., consisting of educationists, educational administrators, legislators
and student representatives and others. This Committee was entrusted with the task of making its
recommendations for the preparation of suitable legislation keeping in view the recommendations
of the Seminar on education and the latest educational thinking and also to suggest suitable
amendments to the University Acts and the Board of Intermediate Education Act. After extensive
deliberations, the Committee made its recommendation and embodied them in a draft
comprehensive Education Bill appended to its report. The proposals embodied in the said Bill have
been examined and approved with suitable modifications by the Consultative Committee of
Legislators for Education Department and also the Cabinet-Sub-Committee on Education.The
present Bill which gives effect to the above recommendations of the said Committee with some
modifications is mainly intended to provide in a small measure, a significant departure from the
conventional measures of education. Positive aspects such as, curriculum development and
textbooks, examinations, teacher training, teacher welfare, administration, and finance have been
incorporated, giving a high academic content. The other aspects of the Bill are to provide for
regulation of private managements of educational institutions, for taking over of managements
should it become necessary in the public interest, and for the requisitioning and acquisition of
properties for the purpose. The Bill besides giving effect to the above objects contains the following
salient features, namely. -(1) Provision has been made for the reform of the present examination
system so as to make it a valid and reliable indicator of student achievement (See Chapter V).(2) For
the first time, it is proposed to provide for the statutory registration of the tutorial educational
institutions keeping in view, the role of these institutions in the context of development of adequate
channels of non-formal education to students who have been left out of the educational system
altogether or dropped in the midstream and their freedom of action in pursuing their goal (vide
Clause 33).Incidentally, it is also proposed to provide statutory basis to various existing educational
bodies such as the Board of Secondary Education, State Board of Technical Education and Training,
the Andhra Pradesh Residential Educational Institutions Society and the Abhyudaya Pradhamika
Vidya Samstha, and to Grant-in-aid. The provisions of the Andhra Pradesh Recognised Private
Educational Institutions (Control) Act, 1975 and some of the existing Acts have been incorporated in
this Bill, in order to make the legislation fully comprehensive and unified.Statement of Objects and
Reasons - Act No. 27 of 1987 - The Government of India while conveying the pr6sidential assent to
A.P. Education Act made certain minor suggestions and comments in regard to the provisions
relating to minority educational institutions, non-formal education and pre-primary education in
the Bill, as passed by the State Legislature. It is proposed to amend the Act keeping in view the
suggestions of the Government of India. Apart from that, it is also proposed to regulate the
establishment and functioning of the schools which do not receive grant-in-aid from Government,
by classifying them as registered schools and requiring them to conform to separate rules and
regulations. It is also felt that penalties provided in the Act in respect of offences relating to
establishment of educational institutions are found to be not adequate to deter private
managements from violating those provisions. It is therefore proposed to enhance the punishments
in respect of the said offences to be more rigorous to act as sufficient deterrent. It is also proposed to
bring in certain types of institutions which are now regarded as tutorial institutions in the studentAndhra Pradesh Education Act, 1982

community.The Bill seeks to give affect to the above proposed (Bill No. 33 of 1987).Statement of
Objects and Reasons - Act No. 17 of 1993 - Consequent on taking up of the responsibility of paying
the salaries etc., to the members of the staff of the private aided colleges from out of the
Consolidated Fund of the State, orders were issued as early as in the year 1976 in G.O.Ms.No. 584,
Edn., dated 25-5-1976 and G.O.Ms.No. 647, Edn., dated 15-6-1977 fixing the age of superannuation
as 55 years and it was subsequently raised to 58 years on par with Government servants. In
G.O.Ms.No. 276, Edn., dated 21-3-1977 orders were issued stipulating a condition that no
grant-in-aid would be paid to any post against which any member either teaching or non-teaching is
continued beyond the age of superannuation as fixed in the said order. In respect of the members of
the teaching staff in the affiliated colleges, the age of superannuation was fixed on par with
Government employees by way of regulations under the relevant provisions of the respective
University Acts with effect from the year 1984, which were continued up to 1987. However, in the
year 1987, the said enabling provisions in the respective University Acts were taken away by Act No.
28 of 1987 and as such there is no other statutory provision governing the age of superannuation of
the teaching and non-teaching staff of the private aided colleges.2. Certain teaching and
non-teaching staff working in private, aided colleges have filed several writ petitions in the High
Court as well as in the Supreme Court challenging the executive orders fixing the age of
superannuation at 58 years on the ground that the Government have no right to reduce the age of
superannuation from 60 years to 58 years as they are employees of private managements. Their
claims for 60 years as age of retirement is on the ground that the age of retirement of teachers in
Universities to which their colleges are affiliated is 60 years. As on today this litigation is pending
before the Hon'ble Supreme Court for the reason that the age of superannuation of the said staff of
the private aided colleges is not governed by any Act of State Legislature.3. In the meantime the said
teaching and non-teaching staff have made representations to Government mainly on the grounds
that the ceiling of maximum pension of Rs. 1,000/- and gratuity of Rs. 36,000/- as admissible to
them under A.P. Liberalised Pension Rules, 1961 is too low hence it maybe removed and they may
also be allowed more beneficial Pension Rules. Unless the age of superannuation is equated on par
with the Government employees, their request for the said benefits cannot be acceded to. As
otherwise they will be in more advantageous position than the staff working in Government
colleges.4. After carefully examining the above issues, Government have decided to fix the age of
superannuation of the teaching and non-teaching staff of the aided, private educational institutions
at 58 years by amending the A.P. Education Act, 1982 and thereafter to allow them more beneficial
Pension Rules with effect from 1st November, 1992 (i.e., both the categories of employees, viz., those
who retired/retiring at 58 years of age, and those who are continued or continuing beyond 58 years
on the strength of Court orders) in accordance with separate rules as may be made in this behalf.5.
As the Legislative Assembly of the State was not then in session having been prorogued and as it was
decided to give effect to the above decisions immediately the Andhra Pradesh Education
(Amendment) Ordinance, 1993 (Andhra Pradesh Ordinance No. 2 of 1993) was promulgated by the
Governor on 12th July, 1993.6. The Bill seeks to replace the said ordinance.[27th January,
1982]Published in the Andhra Pradesh Gazette, Part IV-B (Extraordinary), dated 5-2-1982.Reserved
by the Governor on 3rd June, 1981 for the consideration and assent of the President. Received the
assent of the President on the 27th January, 1982.An Act to consolidate and amend the laws relating
to the educational system in the State of Andhra Pradesh for reforming, organising and developing
the said educational system and to provide for matters connected therewith or incidental, theretoAndhra Pradesh Education Act, 1982

:Whereas it is expedient that the educational system obtaining in the State of Andhra Pradesh
should be so developed as to -(i) be an instrument, for establishing and strengthening, consistent
with the National Policy, a Socialist, Secular and Democratic Society and also for promoting
National Integration ;(ii) firmly link it at all levels with science and technology ;(iii) inculcate moral,
social and human values and promote respect for manual labour and a sense of patriotism and
discipline in the children ; and(iv) achieve an integrated development of the pupil's personality.Be it
enacted by the Legislature of the State of Andhra Pradesh in the Thirty-third Year of the Republic of
India as follows: -
Chapter I
Preliminary
1. Short title, extent, application and commencement: -
(1)This Act may be called the Andhra Pradesh Education Act, 1982.(2)It extends to the whole of the
State of Andhra Pradesh.(3)It applies to all educational institutions and tutorial institutions in the
State except, -(i)institutions for scientific or technical education financed by the Central
Government and declared by Parliament by law to be institutions of National importance ;[***]
[Omitted '(ii) institutions established or maintained and administered by or affiliated to, or
recognised by the Andhra Pradesh Agricultural University and the Jawaharlal Nehru Technological
University' by Act No. 7 of 2013, dated 8.7.2013.](iii)colleges and institutions in so far as the matters
pertaining to them are dealt with in the enactments, relating to the establishment of Universities in
force in the State, including the University of Hyderabad Act, 1974 ;(iv)educational institutions
imparting intermediate education in so far as the matters pertaining to them are dealt with in the
Andhra Pradesh Intermediate Education Act, 1971.(4)It shall come into [force] [The Act came into
force from 18-7-1982, Vide G.O.Ms.No. 560 (Edn.) (R), dated 26-6-1982, Andhra Pradesh Gazette,
Part I, (Extraordinary), dated 13-7-1982.] on such date as the Government may, by notification,
appoint.
2. Definitions: -
In this Act, unless the context otherwise requires, -(1)"Abhyudaya Pradhamika Pathasala" means a
primary school under the management of the Abhyudaya Pradhamika Vidya
Samstha;(2)"Abhyudaya Pradhamika Vidya Samstha" means the registered society referred to in
sub-section (1) of Section 33 ;(3)"academic year" means a period of twelve months commencing on
the first day of June of the year or such other period of twelve months beginning on such date as the
Government may, by notification specify with respect to any educational institution or class of
educational institutions ;(4)"adult education (including non-formal)" means the education or
further education of a person of more than nine years of age who has not attended any educational
institution at any time before, or as the case may be, who is a drop-out from an educational
institution at any level of his studies therein ;(5)"Andhra Pradesh Residential Educational
Institutions Society" means the registered society referred to in sub-section (2) of Section 33
;(6)"approved school" means any school in any specified area within the jurisdiction of a localAndhra Pradesh Education Act, 1982

authority imparting [pre-primary or primary education] [Substituted by Act No. 27 of 1987, w.e.f.
1-6-1987.] which(i)is under the management of the Government or a local authority;(ii)being under
any other management, is recognised as such under this Act ;(7)"attendance" means the presence
for instruction at an approved school on such days in the academic year and at such time and for
such period or periods on each day of attendance as may be prescribed ;(8)"attendance authority"
means any person appointed to be an attendance authority under sub-section (1) of Section 10
;(9)"child" means a boy or a girl within such age group, not being less than six or more than fourteen
years, as the Government may, in each case, specify for the purposes of this Act, either generally or
with respect to any specified area ;(10)"Collector" means any officer in charge of a revenue district
and includes a Joint Collector, Deputy Collector, Sub-Collector and Assistant Collector ;(11)"College"
means a [college including a Medical College established or maintained] [Substituted by Act No. 27
of 1987, w.e.f. 1-6-1987.] and administered by, or affiliated to or associated with or recognised by,
any University in the State and includes a junior college recognised by or affiliated to the Andhra
Pradesh Board of Intermediate Education ;(12)"competent authority" means any person, officer or
authority authorised by the Government by notification to perform the functions of the competent
authority under this Act for such area or for such purposes as may be specified in the
notification;(13)"Director" means -(i)in relation to general education or any part thereof, the
Director in charge of primary education (including pre-primary), secondary education, adult
education (including non-formal), special education, intermediate education or higher education, as
the case may be ;(ii)in relation to technical education, the Director of Technical Education
;(14)"district" means a revenue district ;(15)"District Educational Officer" means the officer
appointed under sub-section (1) of Section 4 and includes a Joint Director, a Deputy Director or any
other officer authorised by the Government to exercise the powers and perform the functions of a
District Educational Officer ;(16)"education" means 1. Substituted by Act No. 27 of 1987, w.e.f.
1-6-1987.[general education, medical education], technical education, physical education, teacher
education, special education, oriental education, adult education (including non-formal) and any
other branch of education which the Government may, by notification, specify ;(17)"educational
agency" means in relation to -(a)any minority educational institution, [any body of persons]
[Substituted by Act No. 27 of 1987, w.e.f. 1-6-1987.] which has established and is administering or
proposes to establish and administer such minority educational institution, and(b)any other private
educational institution, [any body of persons] [Substituted by Act No. 27 of 1987, w.e.f. 1-6-1987.]
entrusted with the establishment, management and maintenance of such private educational
institution ;(18)"educational institution" means a recognised school, [colleges including Medical
Colleges] [Substituted by Act No. 27 of 1987, w.e.f. 1-6-1987.], special institution or other institution
(including an orphanage or boarding home or hostel attached to it) by whatever name called, the
management of which carries on (either exclusively or among other activities) the activity of
imparting education therein, and includes every premises attached thereto ; but does not include a
tutorial institution ;(19)[ "general education" means every branch of education including special
education, but does not include medical education or technical education ;] [Substituted by Act No.
27 of 1987, w.e.f. 1-6-1987.](20)"Government" means the State Government of Andhra
Pradesh;(21)"Gram Panchayat" means the body constituted for the local administration of a village
under the Andhra Pradesh Gram Panchayats Act, 1964 ;(22)"grant" or "grant-in-aid" means any
sum of money paid as aid out of State funds to any educational institution ;(23)"guardian" means
any person to whom the care nurture or custody of any child falls by law or by natural right orAndhra Pradesh Education Act, 1982

recognised usage or who has accepted or assumed the care, nurture or custody of any child or to
whom the care, nurture or custody of any child has been entrusted by lawful authority
;(24)"inspection" means the scrutiny of records, registers and checking of physical specifications as
determined by the competent authority in regard to buildings, libraries, laboratories, play grounds
and other allied matters and the overall appraisal of the educational institution and its functionaries
in the development of the institution ;(25)"listed backward classes" means the backward classes
declared as listed by the Government ;(26)"local authority" means in relation to the local area
comprised within the jurisdiction of a municipal corporation, the concerned municipal corporation
and in relation to any other local area in the State, the concerned Municipal Council, [Zilla Parishad,
Mandal Praja Parishad] [Substituted by Act No. 27 of 1987, w.e.f. 1-6-1987.] Gram Panchayat or
township having jurisdiction over such local area ;(27)"management" means the managing
committee or the governing body, by whatever name called, of a private institution to which the
affairs of the said institution are entrusted, but does not include a manager ;(28)"manager" means
-(i)in relation to a Government educational or special institution, the officer or authority to whom
the power of immediate control over the administration of the institution has been entrusted ;(ii)in
relation to a local authority educational or special institution, the authority or officer of the local
authority educational or special institution concerned In-charge of education ;(iii)in relation to a
private educational or special institution, the person nominated to manage the affairs of the
institution under sub-section (2) of Section 24 ;(29)"minority educational institution" means a
private educational institution of its choice established and administered by a minority, whether
based on religion or language, having the right to do so under Clause (1) of Article 30 of the
Constitution of India ;(30)"municipal corporation" or "municipal council" means a municipal
corporation constituted or deemed to have been constituted under any law relating to municipal
corporation for the time being in force, or as the case may be, a municipal council constituted under
the Andhra Pradesh Municipalities Act, 1965 ;(31)"notification" means a notification published in
the Andhra Pradesh Gazette and the word 'notified' shall be construed accordingly ;(32)"panchayat
samiti" means a panchayat samithi constituted or reconstituted under the Andhra Pradesh
Panchayat Samithis and Zilla Parishads Act, 1959 ;(32a)[ "pre-primary education" means any
education imparted prior to primary education and includes education imparted in nursery,
kindergarten, montessory, anganwadi, balwadi and the like ;] [Inserted by Act No. 27 of 1987, w.e.f.
1-6-1987.](33)"prescribed" means prescribed by rules made by the Government under this Act
;(34)"primary education" means education from Class I to Class VII ;(35)"private institution" means
an institution imparting education or training, established and administered or maintained by any
[xxx] [The words 'person or' omitted Act No. 27 of 1987, w.e.f. 1-6-1987.] body of persons, and
recognised as educational institution by the Government, and includes a college, a special institution
and a minority educational institution, but does not include an educational institution
-(a)established and administered or maintained by the Central Government or the State
Government or any local authority;(b)established and administered by any University established by
law ; or(c)giving, providing or imparting only religious instruction, but not any other instruction
;(36)"residential institution" means an educational institution where pupils are resident on the
premises of the institution and is affiliated to the Andhra Pradesh Residential Educational
Institutions Society;(37)[ "secondary education" means education from Class VIII to Class X ;]
[Substituted by Ibid.](38)"special education" means education imparted in a special
institution;(39)"special institution" means reformatory school, school for physically handicapped orAndhra Pradesh Education Act, 1982

mentally retarded or other defective pupils and includes any other type of special institution which
may be notified as such by the Government ;(40)"specified area" means any area within the
jurisdiction of a local authority in which primary education is declared by it to be compulsory under
sub-section (6) of Section 9 ;(41)"student" means a person who is admitted to a recognised
educational institution and whose name is lawfully borne on the attendance register thereof
;(42)"supervision" means the professional assessment of a teacher, the guidance given to him, and
the level of pupils' achievement as determined by an educational officer appointed for the purpose,
and includes overall academic appraisal of an educational institution;(43)"Teacher"means any
member of the teaching staff in an educational institution appointed to give instruction in that
institution ;(44)"Technical education" means any course of study in engineering, technology,
architecture, ceramics, industrial training, mining, fine arts or in any other subject which maybe
notified by the Government in this behalf ;(45)"to attend an approved school" means to be present
for instruction at an approved school in a year for such period or periods and at such time on each
day as may be fixed by the prescribed authority ;(46)"township" means any area declared as
township under the Andhra Pradesh Gram Panchayats Act, 1964 ;(47)"tutorial institution" means
any institution started by a person or body of persons for giving coaching or instruction to fifty or
more candidates or employing five or more teachers, to prepare them to appear for an examination
in any branch of education conducted by any body or authority or the Universities in the State under
this Act or any other law ; and includes an institution where instruction in typewriting or other
commercial subjects is given :Provided that in the case of any institution where instruction in
typewriting or other commercial subjects is given, the minimum number specified above in regard
to candidates or teachers shall not apply ;(48)"Zilla Praja Parishad" means a Zilla Parishad
constituted or reconstituted under the Andhra Pradesh and [Zilla Parishads Act, 1959.] [Now A.P.
Mandal Praja Parishads and Zilla Praja Parishads Act, 1986.]
Chapter II
Administrative Machinery, Board of Secondary Education and
State Board of Technical Education and Training
3. Director and other officers:
(1)The Government may appoint for the State one or more Directors for general education and a
Director of Technical Education, for the purpose of exercising the powers conferred on and
performing the functions entrusted to each of them by or under this Act.(2)The Government may
also appoint such number of Additional Directors, Joint Directors, Deputy Directors, Assistant
Directors and such other officers as they think fit to assist each such Director in the exercise of the
powers conferred on and the performance of the functions entrusted to him by or under this
Act.(3)Subject to the provisions of this Act, and the general or special orders of the Government
made in this behalf, -(a)the Director shall be the chief controlling authority in all matters connected
with the administration of such part of general education in the State as may be allotted to him by
the Government by an order made in this behalf ;(b)the Director of Technical Education shall be the
chief controlling authority in all matters connected with the administration of technical education in
the State.Andhra Pradesh Education Act, 1982

4. District Educational Officers and other subordinate officers and staff at the
district level: -
(1)The Government may appoint for each district one or more District Educational Officers, and
every such District Educational Officer shall exercise such powers and perform such functions as
may be entrusted to him by or under this Act.(2)The Government may sanction the appointment of
such number of officers and staff as may be necessary to assist the District Educational
Officer.(3)The appointment to the posts sanctioned under sub-section (2) shall be made by such
authority and in such manner as may be prescribed.(4)The powers and functions of the officers and
staff appointed under this section shall be such as may be prescribed.
5. Constitution of Boards: -
(1)The Government may, by notification, establish a board of secondary education to be called "the
Board of Secondary Education, Andhra Pradesh", the composition and powers of which shall be
such as may be prescribed. The functions of the Board shall be to advise the Government on the
co-ordinated development of secondary education in the State, including the conduct of
examinations, conforming to the minimum standards as may be prescribed and the award of
certificates.(2)The Government may, by notification, establish a board of teachers' education to be
called "the Board of Teachers' Education, Andhra Pradesh" the composition and powers of which
shall be such as may be prescribed. The functions of the Board shall be to advise the Government on
the courses of study, pre-service and in service training of teachers and other matters relating to
teachers' education.
6. State Board of Technical Education and Training: -
(1)The Government may, by notification, establish a board of technical education to be called "the
State Board of Technical Education and Training, Andhra Pradesh", the composition and powers of
which shall be such as may be prescribed.(2)The functions of the Board shall be, -(a)to advise the
Government on the co-ordinated development of technical education in the State at all levels below
under-graduate level ;(b)to work in liason with the Southern Regional Committee of the All India
Council for Technical Education in the formulation of schemes in the State ;(c)to affiliate or
recognise institutions conducting courses below undergraduate level and prescribe courses of study
for them;(d)to inspect institutions periodically and ensure that the standards of the courses and the
instructional facilities provided are satisfactory;(e)to conduct examinations and award diplomas and
certificates conforming to the minimum standards prescribed by the All India Council for Technical
Education ;(f)to establish and develop co-operative relationship with Industry and Commerce.
Chapter III
School EducationAndhra Pradesh Education Act, 1982

7. School Education: -
(1)(a)The Government shall endeavour to provide free and compulsory education for all children
until they complete the age of fourteen years and to promote school education in the State by
securing and maintaining the universal enrolment therefor of such children. The Government may
also progressively provide for medical inspection and care of children in the pre-primary and
primary schools.(b)The Government may, for reviewing the progress made in that direction and for
suggesting measures for the effective implementation thereof, appoint a committee immediately
after the expiry of five years from the commencement of this Act and thereafter at the expiry of every
fifth year.(2)(a)At the stage of pre-primary education, children completing the age of [three years]
[Substituted for the words 'two years' by Act No. 27 of 1987, w.e.f. 1-6-1987.] but not completing the
age of six years may be imparted education by the main method of informal learning effectively
linking it with the health and nutrition programmes.(b)The Government may, as part of
pre-primary education, provide for the attachment of pre-school centres to the existing primary
schools in the State.(3)At the stage of primary education, the children completing the age of six
years but not completing the age of fourteen years shall be imparted education and the curriculum
and instruction of education shall be such as may be specified by the competent authority so as to
achieve among others, the following specified objectives, namely :(a)irrelapsable literacy in the
mother tongue including skills of articulation;(b)basic numeracy skills and necessary knowledge of
child's physical and social environment;(c)proficiency in socially useful productive work;Provided
that a child who has completed the age of five years shall not be denied admission in the
schools.(4)(a)The main objective of secondary education shall be to impart such general education
as maybe prescribed to each pupil so as to make him fit either for higher academic studies or for
job-oriented vocational courses, by the time he completes his secondary education.(b)The general
education so imparted shall among others, include -(i)the development of linguistic skills and
literary appreciation in the mother tongue or regional language, as the case may be;(ii)the
attainment of prescribed standards of proficiency, in Hindi and English ;(iii)the acquisition of
requisite knowledge in mathematics and physical and biological sciences to pursue further courses
of study ;(iv)the study of social sciences with special reference to history, geography and civics so as
to achieve the minimum necessary knowledge by the pupil in regard to his State, Country and the
World ;(v)the introduction of [socially useful productive work] [Substituted for the words 'work
experience' by Act No. 27 of 1987, w.e.f. 1-6-1987.] as an integral part of the curriculum ;(vi)the
training in sports, games and other physical exercises and other arts ;(vii)the imparting of
knowledge in basic agricultural science and irrigation methods ;(viii)[ the introduction of
Intermediate courses ; [Clauses (viii) and (ix) inserted by Ibid.](ix)the teaching of morals;](c)The
Government may, -(i)accept and implement progressively at the secondary stage, the principle of
subject specialisation by the teacher ;(ii)take all steps necessary to secure the qualitative
strengthening of secondary education and for that purpose, make every effort to bring the physical
standards of existing schools to optimum levels.
8. [ Establishment, maintenance, etc., of schools by local authorities: - (1)
Every Municipal Corporation or Municipal Council shall make a provision for
education up to the end of the secondary education stage in the area withinAndhra Pradesh Education Act, 1982

its jurisdiction for all children in the prescribed age group ordinarily resident
therein and shall undertake the management of pre-primary, primary and
secondary education schools taken over by the Government and entrusted to
it.
(2)Every Zilla Parishad shall establish, maintain or expand secondary, vocational and industrial
schools in the area within its jurisdiction and shall undertake the management of such schools taken
over by the Government and entrusted to it and shall also be responsible to implement the
objectives of secondary education.(3)Every Mandal Praja Parishad shall be responsible to establish
and maintain pre-primary and primary schools in the area within its jurisdiction and shall
undertake the management of such Government and take over aided pre-primary and primary
schools as deemed necessary.(4)Every Municipal Corporation, Municipal Council, Zilla Praja
Parishad or Mandal Praja Parishad shall undertake to make provision for, and improvement of,
accommodation for schools with peoples' participation.] [Substituted for Section 8, by Ibid.]
Chapter IV
Primary Education and Its Implementation
9. Schemes for primary education: -
(1)Any local authority, if called upon by the Government so to do, shall within such time as may be
specified by the Government submit to them a scheme for compulsory primary education in such
area within its jurisdiction for children ordinarily resident therein, of such ages and up to such
standard as the Government may specify.(2)In the case of the Municipal Corporations and the
Municipalities, the Government may call on them to submit a scheme for compulsory primary
education in those areas for children ordinarily resident therein of such ages and up to such
standard as the Government may specify.(3)The scheme submitted under sub-section (1) or
sub-section (2) shall be in such form as the Government may specify and shall contain the following
particulars, namely, -(a)the area in which primary education will be compulsory ;(b)the
approximate number of children to whom the scheme will apply classified according to age and
mother-tongue ;(c)a list of existing approved schools and the schools, if any, proposed to be opened
for the purpose, classified by languages in which instruction is given or is proposed to be given
;(d)the number of teachers already employed and the additional staff proposed to be recruited
;(e)the recurring and non-recurring cost of the scheme ; and(f)such other particulars as may be
prescribed.(4)The Government may, after such inquiry as they may consider necessary, sanction
with or without modifications the scheme submitted by the local authority under sub-sections (1)
and (2). The implementation of the scheme so sanctioned, shall be subject to the general control of
and the directions issued from time to time, by the Government.(5)No sanction shall be accorded
under sub-section (4), in respect of any scheme unless the Government are satisfied that such steps,
as may be prescribed, have been taken to provide the necessary facilities for imparting compulsory
primary education to all children to whom the scheme will apply.(6)On receipt of sanction under
sub-section (4), the local authority shall give effect to the scheme so sanctioned, by means of aAndhra Pradesh Education Act, 1982

declaration that, with effect from the first day of the next academic year, primary education for
children of both sexes up to such class or standard and within such age-group as may be specified
therein shall be compulsory in any area which may be so specified.(7)Every declaration under
sub-section (6) shall be published before the first day of April of each year immediately preceding
the academic year, in the Andhra Pradesh Gazette and in such other manner as the local authority or
the Director, as the case may be, may decide:Provided that the Government may, for any good and
sufficient cause, condone any delay in the publication of such declaration in any year.(8)Where any
local authority fails to submit a scheme when called upon to do so under sub-section (1) or to give
effect to any sanctioned scheme under sub-section (6) to the satisfaction of the Government, the
Government may cause the scheme to be submitted or the sanctioned scheme to be implemented, as
the case may be, by such person or authority as they think fit. The Government may at any time
entrust the administration of the sanctioned scheme to the local authority concerned.
10. Attendance authorities and their powers and functions: -
(1)The local authority in the cases mentioned in sub-section (1) of Section 9, may appoint as many
persons as it thinks fit to be attendance authorities for the purpose of this Act, and may also appoint
as many persons as it considers necessary to assist the attendance authorities in the discharge of
their duties.(2)It shall be the duty of the local authority to cause to be prepared as early as possible
after the publication of a declaration under sub-section (6) of Section 9 and in such manner as may
be prescribed, a list of children in any specified area. Such lists shall also be prepared annually in
every specified area at such time and in such manner as may be prescribed.(3)The attendance
authority or any person appointed to assist the attendance authority may put such questions to any
guardian or require any guardian to furnish such information about his child, as it or he considers
necessary and every such guardian shall be bound to answer such questions or to furnish such
information as the case may be, to the best of his knowledge or belief.
11. Responsibility of guardian to cause his child to attend school: -
It shall be the duty of the guardian of every child to cause the child to attend an approved school
unless there is a reasonable cause for his non-attendance within the meaning of Section
12.[Explanation: - For purposes of this section and Section 14, the term "approved school' includes a
non-formal education centre.] [Inserted by Act No. 27 of 1987, w.e.f. 1-6-1987.]
12. Reasonable cause for non-attendance: -
(1)For the purposes of this Act, any of the following circumstances shall be deemed to be a
reasonable cause for the non-attendance of a child at an approved school, -(a)that there is no
approved school within the prescribed distance from his residence ;(b)that the only approved school
within the prescribed distance from the residence of the child to which the child can secure
admission is one in which religious instruction of a nature not approved by his guardian is
compulsory ;(c)that the child is receiving instruction in some other manner which is declared to be
satisfactory by the Government or by an officer authorised by them in this behalf;(d)that the child
has already completed primary education up to the class or standard specified in the declarationAndhra Pradesh Education Act, 1982

under sub-section (6) of Section 9;(e)that the child suffers from a physical or mental defect which
prevents him from attendance ;(f)that the child has been granted temporary leave of absence by the
prescribed authority, local authority or by any other person authorised by any such authority in this
behalf, for sickness or other prescribed reasons ;(g)that there is any other compelling circumstance
which prevents the child from attending school, provided the same is certified as such by the
attendance authority.(2)Notwithstanding anything in Clause (e) of sub-section (1), the attendance
authority may, if it is satisfied that, in relation to a child suffering from a physical or mental defect in
any specified area, there is a special school within the prescribed distance from the residence of the
child to which it could be sent, and that nothing in Clause (b) or Clause (c) applies in relation to such
child, it may, by order, require the child to attend the special school, and sub-section (1) shall have
effect in relation to such child as if Clauses (f) and (g) were the only provisions applicable.
13. Attendance orders: -
(1)Whenever the attendance authority has reason to believe that the guardian of a child has failed to
cause the child to attend an approved school and that there is no reasonable cause for the
non-attendance of the child within the meaning of Section 12, it shall hold an inquiry in the
prescribed manner.(2)If, as a result of the inquiry the attendance authority is satisfied that the child
is liable to attend an approved school under this Act and that there is no reasonable cause for his
non attendance within the meaning of Section 12 it shall pass an attendance order in the prescribed
form directing the guardian to cause the child to attend the approved school with effect from the
date specified in the order.(3)An attendance order passed against a guardian in respect of his child
under this section shall, subject to the provisions of sub-section (6), remain in force for so long as
this Act continues to apply to the child.(4)If any guardian against whom an attendance order has
been passed in respect of his child under sub-section (2) transfers the custody of the child to another
person during the period in which the attendance order is in force, such guardian shall be bound to
immediately inform the attendance authority in writing of such transfer.(5)Where an attendance
order has been passed against a guardian in respect of his child under this section, such order shall
have effect in relation to every other person to whom the custody of the child may be transferred
during the period in which the attendance order is in force as it has effect in relation to the person
against whom it was originally passed.(6)A guardian may, at any time apply to the attendance
authority for cancellation of an attendance order on the ground, -(i)that he is no longer the guardian
in respect of the child, or(ii)that circumstances have arisen which provide a reasonable cause for
non-attendance ; and thereupon the authority may, after holding an enquiry in the prescribed
manner, cancel or modify the attendance order.
14. Children not to be employed so as to prevent them from attending to
school: -
No person shall employ a child in a manner which shall prevent the child from attending an
approved school.Andhra Pradesh Education Act, 1982

15. Primary education to be free: -
(1)When a declaration under sub-section (6) of Section 9 has been made in respect of any area, no
fee shall be levied in respect of any child for attending an approved school which is under the
management of the Government or a local authority in that area.(2)Fees may be levied from any
such child at any other school situated within that area :Provided that where within one kilometre of
such school or such other distance therefrom as may be prescribed, there is no other approved
school, such number of the free places as may be fixed by the local authority shall be reserved in
such school or in any educational institution receiving aid out of State funds.
16. Age of child how to be computed: -
(1)The age of a child, for the purpose of this Act shall be computed in terms of years completed by
the child on or before the first day of the academic year.(2)Where the birthday of a child falls on a
day not later than the first day of the September each year, the birthday shall be deemed to fall on
the first day of the academic year for the purposes of computing the age of the child under
sub-section (1).
Chapter V
Examinations
17. Examinations: -
(1)The examination system, whether by internal assessment, external assessment or partly internal
and partly external assessment, shall be so regulated by the competent authority as to make it a
reliable and effective method of student evaluation.(2)The Government may make rules for all
matters connected with the implementation of examination system and the conduct of
examinations.
Chapter VI
Establishment of Educational Institutions, Their Administration
and Control
18. Government to provide facilities for imparting education:
- The Government may, for the purpose of implementing the provisions of this Act, provide
adequate facilities for imparting general education, technical education, special education and
teacher education in the State by -(a)establishing and maintaining educational institutions
;(b)permitting any local authority or a private body of persons to establish educational institutions
and maintain them according to such specifications as may be prescribed ; and(c)taking, from time
to time, such other steps as they may consider necessary or expedient.Andhra Pradesh Education Act, 1982

19. Classification of educational institutions: -
The educational institutions shall be classified as follows :(a)State institutions, that is to say,
educational institutions established or maintained and administered by the Government;(b)Local
authority institutions, that is to say educational institutions established or maintained and
administered by a local authority; and(c)Private institutions, that is to say, educational institutions
established or maintained and administered by any [xxx] [The words 'person or' omitted by Act 27
of 1987, w.e.f 1-6-1987.] body of persons registered in the manner prescribed.
20. [ Permission for establishment of educational institutions: - (1) The
competent authority shall, from time to time, conduct a survey as to identify
the educational needs of the locality under its jurisdiction, and notify in the
prescribed manner through the local newspapers calling for applications
from the educational agencies desirous of establishing educational
institutions.
(2)In pursuance of the notification under sub-section (1), any educational agency including local
authority or registered body of persons intending to -(a)establish an institution imparting education
;(b)open higher classes in an institution imparting primary education;(c)upgrade any such
institution into a high school ; or(d)open new courses (Certificate, Diploma, Degree, Post-Graduate
Degree Courses, etc.)may make an application, within such period in such manner and to such
authority as may be notified for the grant of permission therefor.(3)Any educational agency applying
for permission under sub-section (2) shall, -(a)before the permission is granted, satisfy the authority
concerned, -(i)that there is need for providing educational facilities to the people in the locality
;(ii)that there is adequate financial provision for continued and efficient maintenance of the
institution as prescribed by the competent authority ;(iii)that the institution is proposed to be
located in sanitary and healthy surroundings ;(b)enclose to the application, -(i)title deeds relating to
the site for building, playground and garden proposed to be provided ;(ii)plans approved by the
local authority concerned which shall conform to the rules prescribed therefor ; and(iii)documents
evidencing availability of the finances needed for constructing the proposed buildings ; and(c)within
the period specified by the authority concerned in the order granting permission, -(i)appoint
teaching staff qualified according to the rules made by the Government in this behalf ;(ii)satisfy the
other requirements laid down by this Act and the rules and orders made thereunder failing which it
shall be competent for the said authority to cancel the permission.(4)On and from the
commencement of the Andhra Pradesh Education (Amendment) Act, 1987, no educational
institution shall be established except in accordance with the provisions of this Act and any person
who contravenes the provisions of this section or who after the permission granted to him under this
section having been cancelled continues to run such institution shall be punished with simple
imprisonment which shall not be less than six months but which may extend to three years and with
fine which shall not be less than three thousand rupees but which may extend to fifty thousand
rupees :Provided further that the Court convicting a person under this section shall also order the
closure of the institution with respect to which the offence is committed.] [Substituted by Ibid.]Andhra Pradesh Education Act, 1982

20A. [ Prohibition of individual to establish institutions: - On and from the
commencement of the Andhra Pradesh Education (Amendment) Act, 1987 no
individual shall establish a private institution:
Provided that this section shall not have any effect on any private institution established by an
individual and recognised by the competent authority prior to such commencement] [Inserted by
Act. No. 27 of 1987, w.e.f. 1-6-1987.].
21. Grant or withdrawal of recognition of institutions imparting education: -
(1)The competent authority may, by order in writing grant, recognition in respect of any institution
imparting education or for a higher class in any such institution, permitted to be established under
Section 20 subject to such conditions as maybe prescribed in regard to accommodation equipment,
appointment of teaching staff, syllabi, text books and other matters relating thereto :Provided that
in case of existing institutions under all managements the deficiencies, if any, in respect of the above
conditions shall be made good within the time specified therefor in the order granting
recognition.(2)Where the manager of any local authority educational institution or private
educational institution, -(a)fails to fulfil all or any of the conditions of recognition, or fails to comply
with the orders of the competent authority in regard to accommodation, equipment, syllabi, text
books, appointment, punishment and dismissal of teachers ;(b)denies admission to any citizen on
grounds only of religion, race, caste, language or any of them ;(c)directly or indirectly, encourages in
the educational institution any propaganda or practice wounding the religious feelings of any class
of citizens of India or insulting the religion or the religious beliefs of that class ;(d)employs or
continues to employ any teacher whose certificate has been cancelled or suspended by the
competent authority after due enquiry or who has been considered, by the competent authority after
due enquiry to be unfit or undesirable to be a teacher ; or arbitrarily removes a teacher or fails to
comply with the orders of the competent authority in this regard ;(e)fails to remedy the defects in
the instructions or accommodation or the deficiencies in the management or discipline within such
time as may be specified therefor by the competent authority;(f)contravenes any of the provisions of
this Act and the rules and orders made thereunder ;the competent authority may, for reasons to be
recorded in writing withdraw the recognition of the institution or take such other action as is
deemed necessary after giving to the manager an opportunity of making representation against such
withdrawal or action.(3)Where the Government are of opinion that the recognition granted to any
local authority educational institution or private educational institution should, in the public
interest, be withdrawn, they may, after giving one month's notice to the manager of such institution
to make any representation, withdraw, by notification, the recognition granted to the said
institution.(4)Notwithstanding anything in any other law for the time being in force, no educational
institution which has not been recognised or the recognition of which has been withdrawn under
this Act shall be entitled, -(a)to receive any grant-in-aid from the State funds or other financial
assistance from the Government ;(b)to send up candidates for examinations in courses of study
conducted under this Act.Andhra Pradesh Education Act, 1982

21A. [ Prohibition of affiliation with Universities outside the State: - (1) No
institution imparting education and located in this State shall affiliate itself to
any University outside the State of Andhra Pradesh.
(2)Whoever contravenes the provisions of sub-section (1) shall be punished with simple
imprisonment for a term which shall not be less than six months but which may extend to three
years or with fine which shall not be less than three thousand rupees but which may extend to fifty
thousand rupees or with both.] [Inserted by Act No. 27 of 1987, w.e.f. 1-6-1987.]
22. Special provisions in respect of existing institutions: -
(1)All the institutions imparting education which were established and recognised in accordance
with rules in force immediately before the commencement of this Act and in existence at such
commencement shall be deemed to be educational institutions, established and recognised under
this Act, provided they comply with the provisions of this Act and the rules made thereunder within
such period and in accordance with such procedure as may be prescribed.(2)Any private institution
imparting education which is in existence at the commencement of this Act but which has not been
recognised in accordance with the rules in force immediately before such commencement, shall
discontinue to impart education from such commencement unless within thirty days of such
commencement, an application for recognition is made in accordance with the provisions of this Act
and the rules made thereunder and every such application shall be disposed of within sixty days of
its receipt by the competent authority. No person shall run any such institution after the application
for recognition is rejected.(3)[ Any person who in contravention of sub-section (2) runs any such
unrecognised institution shall be punished with simple imprisonment for a term which shall not be
less than six months but which may extend to three years or with fine which shall not be less than
three thousand rupees but which may extend to fifty thousand rupees or with both] [Substituted by
ibid.].
23. Duties of manager of local authority institution: -
(1)It shall be the responsibility of the manager of a local authority institution to comply with all the
provisions of this Act and the rules or orders made thereunder.(2)Without prejudice to the
generality of the foregoing provisions, it shall be the duty of the manager of the local authority
institution, -(a)to ensure that all monies collected by or granted or allotted to the local authority by
or under this Act are expended for educational purposes, and(b)to submit every year before such
date and to such authority as may be prescribed an annual report relating to the administration of
the local authority institution and an annual budget estimate relating thereto.
24. Appointment and removal of manager of private institution:
(1)The management of every private institution shall be constituted in such manner and shall
consist of such number of members as may be prescribed:Provided that the Board of Trustees, or
Governing Body or Wakf Board, by whatever name called, constituted or appointed under any otherAndhra Pradesh Education Act, 1982

law for the time being in force relating to the charitable and religious institutions and endowments
and wakfs, shall be deemed to be a management constituted under this sub-section.[Provided
further that the constitution of the management under this sub-section shall apply to a minority
educational institution, in so far as it is not repugnant to Clause (1) of Article 30 of the Constitution
of India] [Added by Act No. 27 of 1987, w.e.f. 1-6-1987.].(2)The management shall, for the purposes
of this Act, nominate a person to manage the affairs of the institution, whether called by the name of
secretary, correspondent or by any other name, and intimate such nomination within thirty days
thereof to the competent authority.(3)(a)Where the competent authority is satisfied that the
management is responsible for the lapses or irregularities of the institution, the competent authority
may, after giving to such management an opportunity to make representation and for reasons to be
recorded in writing suspend the management and appoint a special officer till the reconstitution of
the management :Provided that in relation to a private institution, under the management of a
charitable or religious institution, charitable or religious endowment and a wakf, the competent
authority shall be the Government or an authority or officer authorised by the Government in this
behalf.[Provided further that no management of minority educational institution shall be suspended
under this sub-section save for mis-management] [Added by Act No. 27 of 1987, w.e.f.
1-6-1987.].(b)Where the competent authority is satisfied that the manager alone is responsible for
the lapses or irregularities of the institution, action shall be taken against him by the management,
as recommended by the competent authority.(4)The competent authority may, for reasons to be
recorded in writing, declare a person to be unfit to be the manager of a private institution after
giving to such person an opportunity of making his representation against such declaration and
under intimation to the management and on such declaration, the person aforesaid shall cease to be
the manager of the private institution and the management of such institution shall nominate
another person as a manager in his place in accordance with the provisions of subsection
(2).[Provided that no manager of a minority educational institution shall be declared to be so unfit
under this sub-section save for mis-management] [Added by Act No. 27 of 1987, w.e.f.
1-6-1987.].(5)[x x x] [Omitted by Ibid.](6)For the removal of doubts it is hereby declared that any
failure or wilful negligence on the part of a management to take action against the manager as
required under Clause (b) of sub-section (3) or to nominate another person as manager under
sub-section (4) shall constitute an act of mismanagement and action shall be taken against the
private institution under this Act accordingly.
25. Duties of manager of private institution: -
(1)The manager nominated under Section 24 shall be responsible for managing and conducting the
affairs of the private institution in accordance with the provisions of this Act and rules or orders
made thereunder and for maintaining the properties thereof in proper and good condition.(2)It
shall be the duty of the manager to maintain such records and accounts of the institution and in
such manner as may be prescribed.(3)The manager shall afford all assistance and facilities as may
be necessary or reasonably required for the inspection of the institution and its records and
accounts by such officer as may be prescribed or authorised by the competent authority in this
behalf.(4)Before the end of April in each year, the manager of every private institution shall furnish
to the competent authority a statement containing a list of all movable and immovable properties of
the institution with such other particulars as may be prescribed.Andhra Pradesh Education Act, 1982

26. Private institution not to be closed down, etc., without sufficient notice: -
(1)Save as otherwise provided in this Act, no private institution shall be closed down or
discontinued, unless a notice of not less than one academic year expiring with the end of any
academic year and indicating the intention to do so, has been given by the manager to the officer
authorised by the competent authority in this behalf.(2)If any manager fails to give notice as
required under sub-section (1), he shall, on conviction, be punished with fine which may extend to
[five] [Substituted by Act No. 27 of 1987, w.e.f. 1-6-1987.] thousand rupees or with simple
imprisonment which may extend to [one year] [Substituted by Act No. 27 of 1987, w.e.f. 1-6-1987.]
or with both and with a fine of [rupees one hundred] [Substituted by Act No. 27 of 1987, w.e.f.
1-6-1987.] for every day of further default.
27. Manager to hand over properties, records etc., to competent authority on
closure, etc., of [private institution other than a registered school]
[Substituted by Act No. 27 of 1987, w.e.f. 1-6-1987.]: -
(1)In the event of the [private institution other than a registered school] [Substituted by Act No. 27
of 1987, w.e.f. 1-6-1987.] being closed down or discontinued or its recognition being withdrawn, the
manager shall hand over or cause to be handed over to the competent authority the custody of all
the properties, records and accounts of the institution in his possession.(2)(a)Where the competent
authority is resisted in, or prevented from, obtaining the custody of properties, records or accounts
of the institution by such manager, any judicial magistrate of the first class having jurisdiction shall,
on an application made by the competent authority, by order, after notice to the manager, direct the
handing over of the custody of such properties, records or accounts of the institution to the
competent authority within the time specified in such order.(b)Where the manager fails to hand
over the custody of the properties, records or accounts within the time specified in the order of the
Magistrate under Clause (a), he shall be punished with imprisonment which may extend to [one
year] [Substituted by Act No. 27 of 1987, w.e.f. 1-6-1987.] or with fine which may extend to [five
thousand rupees] [Substituted by Act No. 27 of 1987, w.e.f. 1-6-1987.] or with both, and the
Magistrate shall cause the custody of the properties, records or accounts to be handed over to the
competent authority taking such police assistance as may be necessary.(3)Nothing in this section
shall apply to a minority educational institution and to a private institution under the management
of a charitable or religious institution, charitable or religious endowment and a wakf.
28. Restriction on alienation of property of private institution: -
(1)Notwithstanding anything in any law for the time being in force, no sale, mortgage, lease, pledge,
charge or transfer of possession in respect of any property of a [private institution other than a
registered school] [Substituted by Act No. 27 of 1987, w.e.f 1-6-1987.] shall be made or created
except with the previous permission in writing of the competent authority on an application made in
this behalf.(2)(a)No permission applied for under sub-section (1) shall be refused by the competent
authority except where the grant of such permission will in its opinion, adversely affect the working
of the institution.(b)The competent authority shall pass an order, either granting or refusingAndhra Pradesh Education Act, 1982

permission applied for, within a period of sixty days from the date of receipt of the
application.(3)Any person aggrieved by an order refusing permission under sub-section (2) may, in
such manner and within such time as maybe prescribed, appeal to the prescribed authority.(4)Any
transaction made in contravention of sub-section (1) shall be null and void.
29. Liability of manager to repay debts incurred in certain cases: -
Where any manager incurs debts for the purpose of running an educational institution without
proper authorisation by the management of such institution and where it is found by the competent
authority after making an enquiry that the monies received through such debts have not been
utilised for running the institution it shall be the personal liability of such manager to discharge the
said debts.
30. Parent-teacher association: -
(1)There shall be parent-teacher association for every educational institution other than an adult
educational centre.(2)The composition and functions of the parent-teacher association shall be in
accordance with such rules as may be prescribed.
31. Inspection of educational institutions: -
(1)The Government or the competent authority may authorise any officer not below such rank as
may be prescribed to inspect any educational institution in the State.(2)The officer authorised under
sub-section (1) shall exercise general powers of inspection over the working of the educational
institution.(3)The manager and the employees of the educational institution shall at all reasonable
times be bound to afford to the aforesaid officer all such assistance and facilities as maybe required
for the purpose of such inspection.(4)The manager shall comply with such directions or suggestions
as may be given by the competent authority on the report of the aforesaid officer:Provided that the
manager aggrieved by any such direction or suggestion may appeal, within thirty days from the date
of receipt of such direction or suggestion to the prescribed authority whose decision on such appeal
shall be final.
32. Registration of tutorial institutions: -
(1)(a)On or after the commencement of this Act, no tutorial institution shall be started without prior
registration ; and an application for such registration shall be made in the prescribed manner and to
the prescribed officer.(b)In the case of a tutorial institution in existence at the commencement of
this Act, any person or body of persons managing such institution shall, within ninety days from
such commencement, make an application for registration to the prescribed officer and if no such
application is so made or if the prescribed officer communicates to him an order refusing to register
the institution under sub-section (2), the person or body of persons managing such institution shall
not run the institution from the date of expiration of the ninety days aforesaid or the date of
communication of such order of refusal, as the case may be.(2)On receipt of an application underAndhra Pradesh Education Act, 1982

sub-section (1), the prescribed officer may, after satisfying himself whether or not the application
contains all the prescribed particulars and that the tutorial institution complies with the minimum
requirements prescribed in regard to the sanitary conditions of the premises and the qualifications
of the teaching staff, either register the tutorial institution in a register to be maintained for the
purpose or refuse to register, and shall, where he so registers the institution, issue in the prescribed
form a registration certificate in the name of the tutorial institution.(3)The person or body of
persons managing every tutorial institution so registered, shall submit to the prescribed officer
within two months after the end of every academic year, an annual report regarding the coaching
facilities provided by it during the academic year.(4)The person or body of persons managing every
tutorial institution so registered shall give intimation to the prescribed officer and the District
Educational Officer, of any change in any of the particulars furnished under sub-section (1), or of
closure of the institution, in such form, in such manner and within such time as may be prescribed,
and the prescribed officer shall on receipt of such intimation, amend the register referred to in
sub-section (2) and the registration certificate wherever necessary, or as the case may be, cancel the
certificate, and notify the same.(5)Where the person or body of persons managing any tutorial
institution has, in the opinion of the prescribed officer, contravened any of the conditions subject to
which the registration certificate is issued to such person or body of persons managing such
institution, the prescribed officer may, after giving the person or body of persons an opportunity of
making his representation, cancel the registration certificate and remove the name of the institution
from the register referred to in sub-section (2) and notify the same.(6)Any person who runs a
tutorial institution in contravention of Clause (b) of sub-section (1) or who establishes and manages
a tutorial institution without obtaining a registration certificate under sub-section (2) or who after
the registration certificate issued to him, under that sub-section having been cancelled continues to
run such institution, shall be punished [with imprisonment for a term which shall not be less than
six months but which may extend to one year or with fine which may extend to one thousand rupees
or with both] [Substituted by Act No. 27 of 1987, w.e.f. 1-6-1987.] :Provided that for a second or any
subsequent offence under this section, he shall be punished with imprisonment for a term [which
shall not be less than one year but which may extend to two years or with fine which may extend to
five thousand rupees or with both] [Substituted by Act No. 27 of 1987, w.e.f. 1-6-1987.] ;[Provided
further that the Court convicting a person under this section shall also order the closure of the
tutorial institution with respect to which the offence is committed] [Added by Ibid.].
33. Abhyudaya Pradhamika Vidya Samstha and Residential Educational
Institutions Society: -
(1)There shall be a registered society to establish and maintain Abhyudaya Pradhamika Pathasalas
in the State for effecting qualitative improvement in primary education to be called the Abhyudaya
Pradhamika Vidya Samstha.(2)There shall be a registered society to establish and maintain
residential educational institutions in the State to be called the Andhra Pradesh Residential
Educational Institutions Society.(3)The compositions of the governing body of each of the said
societies and its powers and functions shall, notwithstanding in any law for the time being in force,
be such as may be prescribed.(4)Where the Government are of opinion that all or any of the
educational institutions established and maintained by the said society be taken over, they may,
after giving one month's notice to the society to make any representation; direct by notification thatAndhra Pradesh Education Act, 1982

the management of the said educational institution shall, with effect on and from the date specified
therein, vest in the Government without detriment to the interests of the employees of the said
institution.[Chapter VI-A] [Inserted by Act No. 27 of 1987, w.e.f. 1-6-1987.] Registered Schools
33A. Definition: -
For the purposes of this Chapter, the expression "registered school", shall mean a school recognised
under Section 21 but not receiving aid from the Government.
33B. Permission for establishment of registered schools: -
(1)The competent authority shall, from time to time, conduct a survey as to identify the need for
establishing registered schools under its jurisdiction and then notify in the prescribed manner
through the local news papers calling for applications from the educational agencies desirous of
establishing the school to be registered in the manner hereinafter provided.(2)In pursuance of the
notification under sub-section (1), any registered body of persons intending to, -(a)establish a
registered school ;(b)open higher classes in a registered school imparting pre-primary or primary
education ; or(c)upgrade any such school into a high school, may make an application, within such
period, in such manner and to such authority as may be notified for the grant of permission
therefor.(3)The authority empowered to grant permission under sub-section (2) may, after
satisfying that the conditions prescribed for the grant of permission are fulfilled, grant the
permission and register the school in such manner as may be prescribed or refuse such permission
after giving reasons therefor and where the school is so registered, a certificate to that effect may be
issued in the name of the school.
33C. Special provision in respect of existing schools: -
(1)The management of every private institution existing on the date of commencement of the
Andhra Pradesh Educational (Amendment) Act, 1987 desirous of registering the school in
accordance with the provisions of this Chapter may make an application for registration in
accordance with the provisions of Section 33B to the competent authority within sixty days from
such commencement and if no application is made within the said period or where the application is
rejected, the institution shall continue to be a private institution.
33D. Cancellation of registration of the registered schools: -
Where the competent authority is of the opinion that the management of a registered school has
failed to fulfil all or any of the conditions of registration under Section 33-B or the rules made
thereunder, it may after giving a notice not less than thirty days to the manager of such school
cancel the registration of the school and the certificate granted under Section 33B.Andhra Pradesh Education Act, 1982

33E. Conditions of service of staff: -
The teaching and non-teaching staff of the registered schools shall be entitled to receive such
salaries and allowances and shall be subject to such conditions of service as may be prescribed.
33F. Maintenance of registers and following of syllabus, etc.: -
The registered school shall follow the same syllabi, text books and hand books and maintain the
same records and registers as may be followed and maintained by the recognised schools.
33G. Advisory Body: -
The management of every registered school shall constitute an advisory body for the pre-primary,
primary and upper primary classes and for secondary school classes separately and the composition
and the constitution of such advisory body shall be such as maybe prescribed.
33H. Functions of the advisory body: -
The advisory body shall perform the following functions, namely: -(i)to advise the management in
evolving the fee structure ;(ii)to evolve the procedure for the admission of the students ;(iii)to evolve
the procedure for accounting and auditing the accounts of the registered school ;(iv)to suggest
guidelines for the administration of the school without interfering with the minority character of the
minority institutions;(v)to approve the annual report ;(vi)to evolve, subject to the provisions of
Section 33E, the procedure for the recruitment and conditions of service of the teaching and
non-teaching staff of the registered school.
33I. Grants: -
No registered school shall be entitled to receive grant-in-aid or any other financial assistance from
the Government for its management. The existing recognised schools which are receiving the
grant-in-aid shall continue to receive such aid only until they are registered under Section 33B.
33J. Properties of registered schools: -
The properties of any private institution registered as registered school, like building, furniture,
library, laboratory, equipment, playground, aids, endowments and bank balances, shall continue to
be the properties of such institution even after it is registered under Section 33B.
33K. Transfer certificate to be counter-signed: -
(1)The transfer certificate in respect of any student of a registered school shall be in such form and
issued in such manner as may be prescribed.(2)Students of any recognised school may seek
admission in or transfer from any such school to any registered school and vice-versa. The transferAndhra Pradesh Education Act, 1982

certificate issued by the registered school shall be countersigned by the competent authority in such
manner as may be prescribed.
33L. Examination for the students of registered school: -
Where the Government have prescribed any common examination or any public examination for
student evaluation, the students studying in the registered schools shall appear for those
examinations subject to satisfying the rules made in this behalf and the conditions prescribed by the
Commissioner for Government Examinations.
33M. Registered schools to make arrangements for conducting of
examination: -
Where the competent authority selects any registered school as a centre for the conduct of the VII
Class, District Common Examination, or the X Class Public Examination, the management of the
school shall extend all the facilities for the smooth conduct of the examination.
33N. Duties of the Management of the registered school: -
It shall be the responsibility of the management of a registered school to submit every year before
such date and to such authority as may be prescribed an annual report relating to the administration
of the school and such other information and statistical data as may be prescribed.
33O. Inspection: -
The Government shall have the right to visit or cause an inspection to be made by such person or
persons as they may direct for a specified purpose of the registered school and also to cause an
enquiry to be made into the matters connected therewith].
Chapter VII
Education Funds of Local Authorities
34. Definitions: -
In this Chapter, the expression "local authority" does not include a Gram Panchayat.
35. Education Fund of Local Authority: -
(1)There shall be constituted for each local authority an education fund, to which shall be credited,
-(a)an annual contribution from the general funds of such local authority not being less than a
minimum fixed by the Government in that behalf ;(b)all sums granted to such local authority by the
Government for the purpose of providing educational facilities within its jurisdiction ;(c)all finesAndhra Pradesh Education Act, 1982

and penalties levied within the jurisdiction of such local authority under the provisions of this Act
;(d)all income derived from any endowment or other property owned or managed by such local
authority for the benefit of education ;(e)all tuition fees, if any, collected in educational institutions
managed by, such local authority ;(f)all other sums of money which may be contributed to or
received by, such local authority for the purposes of this Act.(2)Notwithstanding anything in any
other law for the time being in force, the education fund constituted under this section shall be kept
separately and shall not be merged with the general revenues of the local authority concerned and it
shall be used exclusively for purposes of education.
36. Education fund where to be deposited and how to be drawn upon: -
(1)The education fund constituted under Section 35 shall be deposited in Government
treasury.(2)All expenses incurred on education by the local authority concerned shall be paid out of
the said fund.(3)All orders or cheques to be drawn upon the fund shall be signed by the chief
executive officer of the local authority or by such person as he may authorise in writing to sign on
his behalf.(4)So far as the funds to the credit of the local authority concerned permit, the treasury
shall pay -(a)all orders or cheques signed in accordance with sub-section (3);(b)all payments made
or expenses incurred by the Government on behalf of the local authority by or under the provisions
of this Act, provided that the local authority has given previous permission in writing to the treasury
to debit such expenses to the fund without the issue of any order or cheque.
37. Levy of taxes: -
(1)Any Municipal Council may, with the previous sanction of the Government and shall, if so
directed by them, levy within its jurisdiction, taxes for the purposes of this Act, at such rates as may
be considered necessary, as an addition to the taxation levied in the municipality under the Andhra
Pradesh Municipalities Act, 1965 under the head of property tax or profession tax or under both
these heads.Explanation: - In construing the expression "taxation levied" occurring in this
sub-section, exemptions granted under sub-section (2), sub-section (3), sub-section (4) or
sub-section (5) of Section 88 of the Andhra Pradesh Municipalities Act, 1965, shall not be taken into
account.(2)Any Gram Panchayat may, with the previous sanction of the Government and shall, if so
directed by them, levy within the area under its jurisdiction or part thereof, taxes for the purposes of
this Act, at such rates as maybe considered necessary, as an addition to the taxation levied in such
area or part under law for the time being in force governing Gram Panchayats under all or any of the
following heads, namely land cess or local cess, profession tax and house tax.
38. Rate of levy of taxes under Section 37: -
(1)The rates of levy of any tax under Section 37 shall be determined -(a)by the Municipal Council or
Gram Panchayat with the previous sanction of the Government, in case the tax is levied by it of its
own motion ; and(b)by the Government, in case the tax is levied at their direction:Provided that
rates of any such tax levied as addition to the taxation under the head of profession tax, shall be
subject to the limits specified in any law for the time being in force governing the Municipalities or
Gram Panchayats, as the case maybe, or prescribed by rules made under this Act:Provided furtherAndhra Pradesh Education Act, 1982

that the rates of any such tax levied by Municipal Council or Gram Panchayat as an addition to the
taxation under the head of property tax shall not exceed five per cent per annum in the case of
properties taxed on their annual rental value, one-fourth per centum per annum in the case of
properties taxed on their capital value and four rupees per annum for every three hundred square
meters or part thereof in the case of properties taxed on their extent :Provided also that the rates of
any such tax levied by a Gram Panchayat as an addition to the taxation under the head of land cess
or local cess shall not exceed thirty seven paise in the rupee of the annual rental value of the
land.(2)The Municipal Council or Gram Panchayat may, with the previous sanction of the
Government, and shall if so directed by them, alter the rates of levy of any such tax.
39. Assessment and realisation of taxes: -
(1)Every tax levied in any area under any head of taxation mentioned in Section 37 shall be deemed
to be an addition to a tax levied under the same head in such area under the law for the time being
in force governing the Municipalities or Gram Panchayats, as the case may be, and all the provisions
of such law relating to the incidence, assessment or realisation of such tax or in any manner
connected therewith shall be applicable accordingly :Provided that the Government may direct that
the said provisions shall apply subject to such modifications and restrictions, as may be
prescribed.(2)In particular, any such tax levied in any area within the jurisdiction of a Gram
Panchayat under any head of taxation, other than land cess or local cess shall be realised by such
authority as may be prescribed as an addition to a tax levied under the same head under the law for
the time being in force governing Gram Panchayats. Out of the proceeds of the tax so realised, such
percentage as may be prescribed shall be deducted towards the collection charges and the balance
shall be paid by such authority into the Government treasury.
40. Budget of Education Fund: -
(1)On or before the prescribed date, every local authority for which an education fund has been
constituted under Section 35 shall submit to the Government through the Director in such form as
may be prescribed a budget for the ensuing financial year showing the income and expenditure
relating to such fund.(2)The Government may pass such orders as they think fit in respect of the
budget and the local authority concerned shall carry out such orders.
41. Audit of accounts of Education Fund: -
The accounts of Education Fund of each local authority shall be examined and audited by such
officer as may be appointed by the Government and the local authority concerned shall carry out any
instructions which the Government may issue on the audit report.
Chapter VIII
Grant-in-AidAndhra Pradesh Education Act, 1982

42. Government to set apart sum for giving grant-in-aid to certain recognised
institutions: -
The Government shall, within the limits of its economic capacity, set apart a sum of money annually
for being given as grant-in-aid (hereinafter in this Act referred to as grant) to local authority
institutions and private institutions in the State, recognised for this purpose in accordance with
rules made in this behalf.
43. Authorities which may sanction grant:
(1)The Government may in such cases as they think fit, by order, sanction grant to any recognised
local authority educational institution or private educational institution subject to such conditions
as they may impose in the order relating to such grant.(2)Every grant sanctioned under sub-section
(1) shall be disbursed by the Director or such other officer subordinate to the Director as the
Government may, by a general or special order, authorise in this behalf, in such manner and subject
to such conditions as may be prescribed.(3)The manager of every recognised institution which is
receiving any grant out of State Funds shall be responsible for the fulfilment of all the conditions
subject to which such grant has been given,
44.
[x x x] [Omitted by A.P. Act No. 5 of 1983.]
45. Application for sanction of grant and the conditions to be fulfilled on
such sanction: -
(1)Every application for the sanction of grant shall be made to the Government, in such form as may
be prescribed and contain a declaration signed by the manager of the recognised institution to the
effect that the conditions of recognition and of grant are being and shall continue to be fully
observed, that all facilities for inspection of that institution, its accounts, registers and other records
relating to the grant shall be afforded to the inspecting staff deputed for the purpose and that all the
returns and reports prescribed in this behalf shall be submitted to the competent authority within
the time specified by it.(2)The Government may sanction such grant or for good and sufficient
reasons may refuse to sanction such grant.(3)Subject to the other provisions of this Act, any order
passed by the Government refusing to sanction the grant shall be final and shall not be questioned
in any Court of law.
46. Power of Government to withhold, reduce or withdraw grant: -
(1)Notwithstanding anything in this Chapter, the Government may, after such enquiry as they may
deem fit, withhold, reduce or withdraw any grant payable to an educational institution having
regard to the funds at the disposal of the Government or the conduct and efficiency and the financial
condition of such institution, after giving an opportunity to the manager of the institution concernedAndhra Pradesh Education Act, 1982

of making a representation against such withholding, reduction or withdrawal.(2)Without prejudice
to the generality of the provisions of sub-section (1) or any other provision of this Act, the
Government may, after such enquiry as they may deem fit, withhold, reduce or withdraw any grant
payable to any educational institution if the manager of the institution concerned, -(i)fails to fulfil all
or any of the conditions of grant ;(ii)denies admission to any citizen on grounds only of religion,
race, caste, language or any of them ;(iii)allows any employee of the institution to take part in any
agitation intended to bring or attempt to bring into hatred or contempt, or intended to excite or
attempt to excite disaffection towards, the Government established by law in India ;(iv)directly or
indirectly encourages any propaganda or practice of wounding the religious feelings of any class of
citizens of India or insulting the religion or the religious beliefs of that class ;(v)is guilty of
falsification of registers, of misuse of funds for purposes other than those for which they are
collected ;(vi)fails to remedy within such reasonable time as may be specified by the competent
authority, the defects in the maintenance of accounts pointed out by the auditors ; or(vii)fails to
restore, within the time specified by the competent authority, an employee whose services have been
wrongfully dispensed with or fails to pay him any arrears of salary or other benefits when directed to
do so by the competent authority.(3)Subject to the other provisions of this Act, every order passed
under this section shall be final and shall not be questioned in any Court of law.
47. Utilisation of funds and movable property of private institution: -
(1)All the monies collected, grants received and other movable property held by or on behalf of a
private institution shall be utilised for the purpose for which they are intended and shall be
accounted for by the manager in such manner as may be prescribed.(2)All the monies received or
held by or on behalf of every private institution shall be deposited in a bank.(3)The surplus fund of
every such institution shall be invested in such manner as may be prescribed and shall be utilised
towards educational development only.Explanation: - For the purpose of this section "surplus fund"
means all the monies that remain unused with the institution at the beginning o f each academic
year, after providing for all the objects, needs, requirements or improvements of the institution
during the previous three academic years.
Chapter IX
Accounts, Audit, Inspection and Returns
48. Accounts: -
Every educational institution receiving grants out of State Funds and other sources shall maintain
accounts in such manner and containing such particulars as may be prescribed.
49. Annual audit of accounts: -
(1)The accounts of every educational institution receiving grants out of the State Funds shall be
audited at the end of every academic year in such manner, after following such procedure and by
such authority, officer or person as may be prescribed and different authorities, officers or personsAndhra Pradesh Education Act, 1982

may be prescribed for different classes of educational institutions.(2)(a)The prescribed authority,
officer or person shall have full access to the account books and other documents required to be
maintained by the educational institution in respect of grants received by it out of State Funds and
shall send a copy of the report on the audit of the accounts under sub-section (1) to the competent
authority which shall forward the report to the educational agency.(b)The educational agency shall,
within such time as may be prescribed, submit that report together with the comments of that
agency to the competent authority.
50. Inspection or Inquiry: -
(1)The competent authority shall have the right to cause an inspection of, or inquiry in respect of,
any educational institution, its accounts, its buildings, laboratories, libraries, workshops and
equipment and also of the examinations, teaching and other work conducted or done by the
institution to be made by such person or persons as it may direct and to cause an enquiry to be made
in respect of any other matter connected with the institution and the educational agency shall be
entitled to be represented thereat.(2)The competent authority shall communicate to the educational
agency the views of that authority with reference to the result of such inspection or inquiry and may
after ascertaining the opinion of the educational agency thereon, advise that agency upon the action
to be taken.(3)The educational agency shall report to the competent authority the action, if any,
which is proposed to be taken or has been taken upon the results of such inspection or inquiry. Such
report shall be furnished within such time as the competent authority may direct.(4)Where the
educational agency does not, within a reasonable time, take action to the satisfaction of the
competent authority, that authority may, after considering any explanation furnished or
representation made by the educational agency, issue such directions as that authority deems fit ;
and the educational agency and the head of the institution shall comply with such directions and
shall be responsible for the implementation of every such direction.
51. Furnishing of returns, etc.: -
Every educational agency shall, within such time or within such extended time as may be fixed by
the competent authority in this behalf, furnish to the competent authority such returns, statistics
and other information as the competent authority may, from time to time, require.
Chapter X
Prohibition of Transfer of Properties by Aided Educational
Institutions
52. Definitions: -
In this Chapter, -(a)"manager" means the owner, trustee or other person who has power to transfer
any land or building belonging to an educational institution and includes a local authority
;(b)"transfer" includes sale, exchange, mortgage, charge, lease orAndhra Pradesh Education Act, 1982

53. Prohibition of transfer of lands and buildings by educational institutions
without the permission from Government in certain cases: -
(1)Where before or after the commencement of this Act, -(a)any land or building has been acquired,
constructed, improved or altered for the purpose of any educational institution, with the aid of any
grant made from the State funds ; or(b)any land or building has been transferred by the
Government for use for the purpose of any educational institution, then, notwithstanding anything
to the contrary in any other law for the time being in force or in any deed of transfer or other
document relating to the land or building, it shall not be transferred without permission of the
Government under sub-section (2) ; nor shall the land or building be used for any purpose other
than the purposes of the educational institution or purposes ancillary thereto, without the
permission of the Government.(2)The Government may, by order in writing, permit the transfer of
any such land or building subject to such conditions as they may impose, if -(i)the transfer is made
in furtherance of the purposes of the educational institution or of ancillary purposes approved by the
Government, and the proceeds of such transfer are to be wholly utilised in furtherance of the said
purposes ;(ii)the transfer is made only in part in furtherance of the purpose aforesaid, provided
repayment is made to the Government of such portion as the Government may direct in the
circumstances of the case, of the grant referred to in Clause (a) of sub-section (1) or of the current
market value of the land or building referred to in Clause (b) of sub-section (1) or of both, as the case
may be ;(iii)the transfer is made for any other valid reason, provided repayment is made to the
Government in full of the grant referred to in Clause (a) of sub-section (1), or of the current market
value of the land or building referred to in Clause (b) of sub-section (1) or of both, as the case may
be.(3)Any transfer of land or building made without obtaining the permission of the Government
under sub-section (2) shall be null and void.
54. Consequence of breach of provisions of Section 53: -
Where, in any case, the Government, after giving the manager of the educational institution
concerned an opportunity to make his representation in regard to the matter, are satisfied that the
provisions of sub-section (1) of Section 53 have been contravened in respect of any land or building
they may, by order, -(a)if the land or the land together with the budding standing thereon belonged
to the Government and was transferred by them for the purposes of the educational institution,
direct the Collectors to take possession of the land or land together with the building standing
thereon, as the case may be, or at their option, direct the manager to pay to them in full, the current
market value of the land or of the land together with that of the building where it was also
transferred by them and also the amount of the grant, if any, made by the Government for
improving the land or altering or constructing the building ;(b)if the land or the building, if any,
standing thereon does not belong to the Government, direct the manager to repay in full the grant
made by the Government.
55. Effect of orders under Sections 53(2) and 54: -
(1)Every order passed by the Government under sub-section (2) of Section 53 or Section 54 shallAndhra Pradesh Education Act, 1982

subject to the provisions of sub-section (2) and (3), be final.(2)The manager of the institution in
respect of which such an order is passed, not being a local authority, may on the ground that the
amount repayable or payable by or to him has been wrongly fixed in the order, apply within sixty
days from the date on which the order is received by him to the District Judge having jurisdiction
over the area in which the property in question is situated for fixing such amount correctly in
accordance with the provisions of sub-section (2) of Section 53 or Section 54, as the case may
be.(3)The District Judge shall determine the amount which is properly repayable or payable by or to
the manager in accordance with the provisions of sub-section (2) of Section 53 or Section 54, as the
case may be, and such determination shall be final.
56. Land or building to vest in Government absolutely on possession being
taken: -
(1)When, in pursuance of an order under Section 54, the Collector takes possession of any land or
building by himself or through another, it shall vest absolutely in the Government free from all
encumbrances.(2)If the Collector or any person authorised by him in this behalf is opposed or
impeded in taking possession of any land or building under this Chapter he shall, if he is a
Magistrate, enforce the surrender of such land or building to himself ; and if he is not a Magistrate,
he shall apply to a Magistrate and such Magistrate shall enforce the surrender of the land or
building to the Collector.(3)Whoever opposes or impedes the Collector or any person authorised by
him in taking possession of any land or building under this Chapter shall be punished with
imprisonment which may extend to [one year] [Substituted by Act No. 27 of 1987, w.e.f. 1-6-1987.]
or with fine which may extend to five thousand rupees or with both.
57. Recovery of sums due under this Chapter: -
Any sums required to be repaid or paid to the Government in pursuance of Section 53 or Section 54
or Section 55 may, without prejudice to any mode of recovery provided in any other law for the time
being in force, be recovered from the properties of the institution or from the manager thereof as if
it were an arrear of land revenue due from such educational institution or manager.
58. Court not to attach, sell, etc., in the absence of permission of the
Government: -
(1)No land or building referred to in sub-section (1) of Section 53 shall be liable to be attached, sold,
or made subject to a charge by any Court whether in execution of a decree or order or otherwise,
unless the person seeking such relief from the Court has obtained, the permission of the
Government to do so and files such permission in the Court.(2)When granting such permission, the
Government may impose such conditions as they deem fit.(3)If any such land or building is attached
or sold, or a charge is created thereon by any Court without the permission of the Government
having been obtained and filed as aforesaid or if any condition imposed by them when granting such
permission is contravened, then the attachment, sale or charge, as the case may be, shall be null and
void.Andhra Pradesh Education Act, 1982

Chapter XI
Taking Over of Management, Requisitioning and Acquisition of
Educational Institutions
59. Definitions: -
In this Chapter, -(a)"educational institution" means any school, college or other institution for
imparting education which is managed by an individual, body or local authority and is recognised by
the Government, but does not include a minority educational institution ;(b)"person interested"
includes all persons claiming or entitled to claim, an interest in the amount payable on account of
the taking over of the management of the educational institution or requisitioning or acquisition of
the property used for the purposes of an educational institution or of any other institution connected
therewith under this Act.
60. Taking over of management of educational institutions in public interest:
-
(1)Where the Government are of opinion that the management of any educational institution should
either in the public interest or in order to secure the proper management of the said educational
institution be taken over, they may, after giving one month's notice to the management of such
educational institution to make any representation, direct by notification, that the management of
the said educational institution, shall with effect on and from the date specified therein vest in the
Government until the said educational institution is acquired :Provided that no private institution
under the management of a religious institution, endowment or a wakf shall be taken over without
the prior consent of such management.(2)The educational institution referred to in sub-section (1)
shall be deemed to include all assets, rights and leaseholds, powers, authorities and privileges and
all property, movable and immovable including lands, buildings, stores, instruments and vehicles,
cash balances, reserve fund, investments and book debts and all other rights and interest arising out
of such property as were, immediately before the date of taking over of the management under
sub-section (1) (hereinafter in this Chapter referred to as the date aforesaid) in the ownership,
possession, power or control of the management of such educational institution and all books of
account, registers and all other documents of whatever nature relating thereto.(3)Any contract,
whether express or implied, or other arrangement (not being a contract, or agreement specified in
Section 62) in so far as it relates to the management of the educational institution, and in force
immediately before the taking over, shall be deemed to have terminated on the date aforesaid.(4)All
persons, in whom the management of the educational institution vested immediately before the
taking over shall, as from the date aforesaid, cease to be so vested and shall be deemed to have
vacated their offices as such on the date aforesaid.(5)Notwithstanding anything in any other law for
the time being in force, no person in respect of whom any contract of management or other
arrangement is terminated by reason of the provisions contained in sub-section (3) or who ceases to
hold any office by reason of the provisions contained in sub-section (4) shall be entitled to claim any
compensation for the premature termination of the contract of management or other arrangementAndhra Pradesh Education Act, 1982

or for the cessation of management or for the loss of office, as the case may be.(6)Notwithstanding
any judgment, decree or order of any Court, tribunal or other authority or anything contained in any
other law for the time being in force, every person in whose possession or custody or under whose
control the educational institution or any part thereof, or any properties attached thereto, may be
immediately before the taking over, shall on the date aforesaid, deliver possession of the educational
institution or part thereof or any properties attached thereto, as the case maybe, to the special
officer appointed by the Government for the purpose of carrying on the management of such
educational institution for and on behalf of the Government, or where no special officer is
appointed, to such other person as the Government may direct.(7)For the removal of any doubt, it is
hereby declared that any liability incurred by the private management in relation to the educational
institution before the taking over shall be enforceable against the said management and not against
the Government or the Special Officer.(8)The amount payable in respect of the vesting in the
Government of the management of an educational institution under sub-section (1) shall be an
amount equal to the average net annual surplus income of such educational institution during the
period of its existence, or the period of five consecutive accounting years immediately preceding the
date of such vesting, whichever is less :Provided that no such amount shall be payable if the trust or
management under which the educational institution is founded makes provision for the running of
such institution.Explanation: - In this sub-section, the expression "accounting year" means the
period beginning on the 1st day of July of any year and ending on the 30th day of June of the year
next following.(9)The amount payable under sub-section (8) shall, subject to rules made under this
Act, be paid by the competent authority to the person interested in the educational institution in
such manner and within such time as may be prescribed.
61. Power to terminate contracts of employment: -
If the Government or the special officer appointed under Section 60, is of opinion that any contract
of employment entered into by the management in relation to the educational institution at any time
before taking over is unduly onerous, they or he may, by giving to the employee one month's notice
in writing or salary or wages for one month in lieu thereof, terminate such contract of employment.
62. Contracts etc., made in bad faith may be cancelled or varied: -
(1)If the Government are satisfied, after such enquiry as they may think proper, that any contract or
agreement entered into at any time within a period of two years immediately preceding the date
aforesaid between the management in relation to the educational institution and any other person,
in relation to any service, sale or supply to, or by the educational institution and in force
immediately before the taking over, has been entered into in bad faith, or is found detrimental to the
interests of the educational institution, they may make, within one hundred and eighty days from
the date aforesaid an order cancelling or varying (either unconditionally or subject to such
conditions as they may think fit to impose) such contract or agreement and thereafter the contract
or agreement shall have effect accordingly :Provided that no contract or agreement shall be
cancelled or varied except after giving to the parties to the contract or agreement one month's notice
to make a representation in this regard.(2)Any person aggrieved by an order made under
sub-section (1) may, within thirty days from the date of communication of the order, make anAndhra Pradesh Education Act, 1982

application to the Principal Civil Court of original jurisdiction within the local limits of whose
jurisdiction the educational institution is situated, for the variation or reversal of such order and
thereupon such Court may confirm, modify or reverse such order.
63. Avoidance of voluntary transfers: -
Any transfer of property, movable or immovable, or any delivery of goods made by or on behalf of
the educational institution (not being a transfer or delivery made in the ordinary course of
transaction or in favour of a purchaser for valuable consideration and in good faith), if made within
a period of one year immediately preceding the date aforesaid, shall be void as against the
Government or the special officer, as the case may be.
64. Requisitioning of an educational institution: -
(1)Where recognition or permission granted to an educational institution is withdrawn by the
Government under sub-section (3) of Section 21 or otherwise, or where an educational institution is
closed before the last working day of an academic year and if the Government consider it necessary
to requisition any property movable or immovable, which before the withdrawal of the recognition
or permission or the closing of the institution was being used for the purposes of the institution or of
any other institution connected therewith, such as a hostel for students, quarters for the residence of
employees or a playground, then notwithstanding anything to the contrary in any other law for the
time being in force, the Government may, within three months from the withdrawal of the
recognition or permission or the closing of the educational institution, as the case may be,
requisition such property and make such further orders as appear to them to be necessary or
expedient in connection with the requisition.(2)Before requisitioning any property under
sub-section (1) the Government, -(a)shall call upon the manager or any other person who is in
possession of the property by notice in writing to show cause, within fifteen days of the date of the
service of such notice to him why the property should not be requisitioned and shall consider the
objections, if any, shown by the manager or other person ; and(b)may, by order, direct that the
manager or any person shall not, without permission of the competent authority, dispose of,
structurally alter, lease or in any manner deal with, the property until the expiry of such period, not
exceeding three months, as may be specified in the order.(3)Where any property is requisitioned
under sub-section (1) the Government may, -(a)use or deal with such property for any educational
purpose; or(b)by order, permit any person or body or local authority to use or deal with such
property for any such purpose, subject to the payment of such rent and other sums to the
Government and the observance of such conditions as may be specified in the order.
65. Summary power for taking possession of property: -
(1)Any person remaining in possession of any property in contravention of an order issued under
Section 64 may be summarily dispossessed of such property by an officer empowered by the
Government in this behalf, and in the case of building, if free access to it is not afforded to such
officer, he may after giving reasonable warning and facility of withdrawing to any woman not
appearing in public according to the customs of the country, remove or open any lock or bolt orAndhra Pradesh Education Act, 1982

break open any door or do any other act necessary for effecting such dispossession.(2)If any such
officer is resisted in the exercise of such power or discharge of such duty, the Magistrate having
jurisdiction shall, on a written requisition from such officer, direct any police officer not below the
rank of sub-inspector to render such help as may be necessary to enable the officer to exercise such
power or discharge such duty.
66. Release from requisitioning and discharge of liability of the Government:
-
(1)The Government may at any time, release any property requisitioned under this Chapter and in
such case, the possession of the property released from requisition shall be delivered to the manager
or other person from whom possession was taken at the time when the property was requisitioned,
or if there were no such manager or person, the person deemed by the Government to be the
manager or owner of such property, and such delivery of possession shall be full discharge of the
Government from all liabilities in respect of that property which any other person may be entitled by
the due process of law to enforce against the person to whom possession of the property is so
delivered.(2)Where the person to whom possession of any such property is to be delivered cannot be
found or has no agent or other person empowered to accept delivery on his behalf, the Government
shall cause to be published in the Andhra Pradesh Gazette a notice declaring that the property is
released from requisition ; and in the case of any immovable property, the Government shall also
cause a copy thereof to be affixed, on some conspicuous part of such property.(3)When the notice
referred to in sub-section (2) is published in the Andhra Pradesh Gazette, the property specified in
such notice shall cease to be subject to requisition on and from the date of such publication and shall
be deemed to have been delivered to the person entitled to possession thereof ; and the Government
shall not be liable for any amount, rent or other claim in respect of such property for any period
after the said date.
67. Acquisition of property: -
(1)Where any property is vested under sub-section (1) of Section 60 in connection with the
management of an educational institution or is subject to requisition under sub-section (1) of
Section 64, the Government may, if they consider it necessary to acquire the property for any public
purpose connected with education, acquire at any time such property for the said public purpose by
publishing in the Andhra Pradesh Gazette a notice to the effect that the Government have decided to
acquire the property in pursuance of this section :Provided that before issuing such notice, the
Government shall call upon the manager of, or any other person who in the opinion of the
Government, is the person interested in, such property to show cause why the property should not
be acquired ; and after considering the objections if any, shown by the manager or other person
interested in the property the Government may pass such order as they deem fit.(2)When notice as
aforesaid is published in the Andhra Pradesh Gazette, the requisitioned property shall on and from
the day on which the notice is so published, cease to be subject to requisition and vest absolutely in
the Government free from all encumbrances.Andhra Pradesh Education Act, 1982

68. Principles and methods of determining amount for property requisitioned
or acquired: -
(1)Where any property is requisitioned or acquired under this Act, the amount payable therefor shall
be determined and paid in the manner and in accordance with the principles hereinafter set out,
that is to say, -(a)where the amount is settled and fixed by agreement, it shall be paid accordingly
;(b)where there is no such agreement, the Government shall appoint as arbitrator a person who is
holding or has held a judicial office, not below the rank of a District Judge, for determining the
amount;(c)at the commencement of the proceedings before the arbitrator the Government and the
person to whom the amount is payable shall state what according to them is the fair amount ;(d)the
arbitrator shall after due enquiry determine the amount which appears to him to be just and specify
the person or persons to whom such amount shall be paid ; and in making the award determining
the amount, he shall have regard to the circumstances of each case and the provisions of
sub-sections (2), (3), (4) and (5) so far as they are applicable ;(e)where there is any dispute as to the
person or persons who are entitled to the amount, the arbitrator shall decide such dispute and if the
arbitrator finds that more persons than one are entitled to the amount, he shall apportion the
amount amongst such persons according to their rights ; and(f)nothing in the Arbitration Act, 1940,
shall apply to arbitrations under this section.(2)The amount payable for the requisitioning of any
property, movable or immovable, shall, in respect of the period of requisition, be a sum equal to the
rent which would have been payable for the use and occupation of the immovable property or for the
use of the movable property, if it had been taken on lease for that period.(3)The amount payable for
the acquisition of any immovable property under Section 67 shall be -(a)the price which the
requisitioned property would have fetched in the open market if it had remained in the same
conditions as it was at the time of requisitioning and been sold on the date of acquisition; or(b)twice
the price which the requisitioned property would have fetched in the open market if it had been sold
on the date of requisition, whichever is less.(4)The amount payable for the acquisition of any
movable property shall be the price which such property would have fetched in the open market if it
had been sold on the date of acquisition.(5)Where any property requisitioned or acquired under this
Act was acquired with the grant from the State funds, the amount of such grant shall be taken into
account in the prescribed manner in determining the amount payable.Explanation: - For purposes
of this sub-section, all the property acquired by the educational institution shall be deemed to have
been acquired with the aid of such grant, contribution, donation or collection unless the manager of
the Educational Institution proves to the satisfaction of the arbitrator that the property has been
acquired otherwise.
69. Payment of amount for property requisitioned or acquired:
- The amount payable under the award of arbitrator shall, subject to any rules made under this Act,
be paid by the competent authority to the person interested, in such manner and within such time as
may be specified in the award.Andhra Pradesh Education Act, 1982

70. Appeal from the award of the Arbitrator under Section 68 in respect of
amount: -
Any person aggrieved by the award of the arbitrator under Section 68 may, within sixty days from
the date of such award, prefer an appeal to the High Court :Provided that the High Court may
entertain an appeal after the expiry of the said period of sixty days, if it is satisfied that the appellant
was prevented by sufficient cause from filing the appeal in time.
71. Arbitrator to have certain powers of Civil Court: -
The arbitrator appointed under this Chapter, while holding arbitration proceedings under this Act,
shall have all the powers of a Civil Court while trying a suit under the Code of Civil Procedure, 1908,
in respect of the following matters, namely, -(a)summoning and enforcing the attendance of any
person and examining him on oath ;(b)requiring the discovery and production of any document
;(c)reception of evidence or affidavits ;(d)requisitioning any public record from any Court or office
;(e)issuing commissions for examination of witnesses.
72. Powers of entry and inspection and calling for information: -
The competent authority may, for the purpose of requisitioning or acquiring any property under this
Chapter, by order, -(a)empower any authority to enter and inspect any property specified in the
order liable to be requisitioned or acquired under this act;(b)require any person to furnish to such
authority such information in his possession relating to the property as may be specified in the
order.
73. Provisions for existing staff of Educational Institutions: -
Notwithstanding anything to the contrary in any contract or agreement or any law for the time being
in force, the following provisions shall apply in regard to the persons on the staff of the Educational
Institution immediately before the date on which the management of the Educational Institution is
vested in the Government, namely, -(a)the Government shall have power to terminate the services of
any such person after giving him three calendar months' notice in writing or paying him three
months' pay in lieu of such notice ;(b)a person whose services have been retained shall be governed
at his option either by the conditions of service as may from time to time be prescribed or by the
conditions of service applicable to him immediately before such vesting.
74. Posts of employees of educational institutions vested under this Chapter
to be treated as a unit for certain purposes: -
The posts in each category of employees of the educational institutions in a district which have
vested in the Government under this Chapter shall be a separate unit for purposes of seniority,
discharge, revision for want of vacancies, reappointment of probationers and approved probationers
and appointment of full members.Andhra Pradesh Education Act, 1982

Chapter XII
Transfer of Control and Management of Certain Schools
75. Powers of Government to take over control and management of schools,
belonging to local authority: -
(1)The Government may, by notification, and with the prior consent of a local authority, take over
the control and management of any or all primary schools or secondary schools established or
maintained and administered by the said local authority from such date as may be specified in the
notification; and from the date so notified it shall be open to the Government to control and manage
the said schools and all the properties and assets of the local authority pertaining to or intended to
be used for, every such school shall stand transferred to, and vest in the Government free from all
encumbrances.(2)Notwithstanding any contract or agreement or any law for the time being in force,
every teacher or other person employed in any of the said schools immediately before the date on
which the control and management thereof is taken over by the Government shall, as from the said
date, be deemed to be an employee of the Government and shall hold office on the same
remuneration and upon the same terms and conditions and with the same rights and privileges as to
pension, gratuity and other matters as he would have held under local authority until his
remuneration, terms and conditions of service are duly altered by the Government :Provided that
every such employee shall, within a period of three months or such other period beyond three
months as may be specified by the Government by a notification, from the date of taking over of the
control and management of the school, exercise his option either to be retrenched from the service
on receipt of such retrenchment benefits as maybe prescribed or to be absorbed in the service of the
Government with effect from the said date and shall be governed by the terms and conditions
governing the said service which shall not be less favourable than those applicable to such employee
prior to the said date.
76. Transfer of control and management of schools to Zilla Parishads: -
(1)Notwithstanding anything in the Andhra Pradesh Panchayat Samithis and Zilla Parishads Act,
1959 or the rules made thereunder, or any other law for the time being in force relating to control
and management of schools, the Government may, with effect on and from such date as may be
notified, transfer, with the prior consent of a Zilla Parishad, the control and management of all
primary schools or secondary schools in a district, established or maintained and administered by
the Government or any Panchayat Samithi to the Zilla Parishad concerned ; and from the date so
notified, it shall be open to the Zilla Parishad to control and manage the said schools in the district,
and all the properties and assets of the Government or the Panchayat Samithi as the case maybe,
pertaining to or intended to be used for, every such school shall stand transferred to and vest in, the
Zilla Parishad free from all encumbrances.(2)Notwithstanding any contract or agreement or any law
for the time being in force, every teacher or other person employed in any of the said schools
immediately before the date on which the control and management thereof is transferred to the Zilla
Parishad shall, as from the said date, be deemed to be an employee of the Zilla Parishad and shall
hold office on the same remuneration and upon the same terms and conditions and with the sameAndhra Pradesh Education Act, 1982

rights and privileges as to pension, gratuity and other matters as he would have held under the
Government, or Panchayat Samithi, as the case may be, until his remuneration and terms and
conditions of service are duly altered by the Zilla Parishad:Provided that every such employee shall,
within a period of three months or such other period beyond three months as may be specified by
the Zilla Parishad, from the date of transfer of the control and management of the school, exercise
his option either to be retrenched from the service on receipt of such retrenchment benefits as may
be prescribed or to be absorbed in the service of the Zilla Parishad with effect from the said date and
shall be governed by the said terms and conditions governing the said service which shall not be less
favourable than those applicable to such employee prior to the said date.
77. Transfer of control and management of schools to Abhyudaya
Pradhamika Vidya Samstha: -
(1)Notwithstanding anything in the Andhra Pradesh Panchayat Samithis and Zilla Parishads Act,
1959, the Andhra Pradesh Municipalities Act, 1965 or the rules made thereunder or any other law
for the time being in force relating to control and management of schools, the Government may,
with effect on and from such date as may be notified, transfer, with the prior consent of the local
authority concerned, the control and management of any primary school, established or maintained
and administered by the Government or any Panchayat Samithi or the Municipality, to the
Abhyudaya Pradhamika Vidya Samstha ; and from the date so notified, it shall be open to the
Abhyudaya Pradhamika Vidya Samstha to control and manage the said schools ; and all the
properties and assets of the local authority pertaining to and intended to be used for such school
shall stand transferred to, and vest in, the Abhyudaya Pradhamika Vidya Samstha free from all
encumbrances.(2)Notwithstanding any contract or agreement or any law for the time being in force,
every teacher or other person employed in the said school immediately before the date on which the
control and management thereof is transferred to the Abhyudaya Pradhamika Vidya Samstha shall,
as from the said date, be deemed to be an employee of the said Samstha and shall hold office on the
same remuneration and upon the same terms and conditions and with the same rights and
privileges as to pension, gratuity and other matters as he would have held under the said local
authority until his remuneration and terms and conditions of service are duly altered by the said
Samstha :Provided that every such employee shall, within a period of three months or such period
beyond three months as maybe specified by the said Samstha, from the date of transfer of the
control and management of the said school, exercise his option either to be retrenched from the
service on receipt of such retrenchment benefits as may be prescribed or to be absorbed in the
service of the said Samstha with effect from the said date and shall be governed by the terms and
conditions governing the said service which shall not be less favourable than those applicable to
such employee to the said date.
Chapter XIII
Constitution of Educational ServiceAndhra Pradesh Education Act, 1982

78. Constitution of Educational Service: -
(1)Notwithstanding anything in this Act or the rules made thereunder, the Government may, by
notification, constitute any officer or class of officers or any teacher or class of teachers appointed or
deemed to be appointed under this Act into an educational service for the State.(2)Upon issue of a
notification under sub-section (1), the Government shall have power to make rules to regulate the
classification, methods of recruitment, conditions of service, pay and allowances and discipline and
conduct of the members of the educational service thereby constituted and such rules may vest
jurisdiction in relation to such service in the Government or in such authority or authorities, as may
be prescribed.
78A. [ Age of superannuation of the staff in aided private educational
institutions: - (1) Every teacher or member of the non-teaching staff
employed in any aided, private educational institution, not belonging to last
grade service, shall retire from service on the afternoon of the last day of the
month in which he attains the age of fifty eight years :
Provided that a teacher or a member of the non-teaching staff aforesaid, who has already attained
the age of fifty-eight years and continuing in service on the date of commencement of the Andhra
Pradesh Education (Amendment) Act, 1993, shall retire on the afternoon of the last day of the
month of the commencement of the said Act.(2)Every member belonging to the last grade service
shall retire from service on the afternoon of the last day of the month in which he attains the age of
sixty years.Explanation: - For the removal of doubts, it is hereby declared that an employee whose
date of birth is the firSt day of a month shall retire from service on the afternoon of the last day of
the preceding month on attaining the age of fifty-eight or sixty years, as the case maybe.
78B. Pension to the employees of aided private, Junior and Degree Colleges:
-
(1)Notwithstanding anything contained in any orders issued by the Government for the payment of
pension to the employees of the aided, private, Junior and Degree Colleges before the
commencement of the Andhra Pradesh Education (Amendment) Act, 1993, such employees
including those in the last grade service who attained the age of superannuation as specified in
Section 78A shall be entitled to pension with effect from 1st November, 1992, in accordance with
such separate rules as may be made in that behalf.(2)A teacher or a member in any aided, private,
Junior and Degree Colleges who continues in service beyond the age of fifty eight years for any
reason shall be entitled to pension with effect from 1st November, 1992, in accordance with such
separate rules as may be made in that behalf.] [Inserted by Act No. 17 of 1993, w.e.f. 13-7-1993.]
78C. [ "Special representation in.appointment to the posts: The rule of
special representation (Reservation) in favour of Scheduled Castes,
Scheduled Tribes and Backward Classes shall be applicable forAndhra Pradesh Education Act, 1982

appointments to the posts in Private Educational Institutions:
Provided that the rule of special representation shall not be applicable to the Minority Educational
Institutions.
78D. Abatement of claims of appointments in Private Educational
Institutions: -
Notwithstanding any judgment, decree or order of any Court, no person shall claim approval of
appointment made in Private Educational Institutions except in accordance with Section 78C and
accordingly.(a)no suit or other proceedings shall be maintained or continued in any Court against
the Government or any person or authority whatsoever for approving the appointments otherwise
made and all such pending proceedings shall abate forthwith; and(b)no Court shall enforce any
decree or order directing for approval of such appointments"].
Chapter XIV
Payment of Salaries and allowances to and Disciplinary action
against Employees of Private Institutions
79. Dismissal, removal or reduction in rank or suspension, etc., of employees
of private institutions: -
(1)No teacher or member of the non-teaching staff employed in any private institution (hereinafter
in this Chapter referred to as the employee') shall be dismissed, removed or reduced in rank except
after an enquiry in which he has been informed of the charges against him and given a reasonable
opportunity of being heard in respect of those charges:[Provided that no order of dismissal, removal
or reduction in rank shall be passed under this sub-section against an employee other than an
employee of a minority educational institution without the prior approval of such authority or
Officer as may be prescribed for different classes of private institutions;Provided further that the
management may prefer an appeal against any order of the Officer or authority refusing approval
under this sub-section to such authority or officer and within such period as may be prescribed]
[Substituted by Act No. 27 of 1987, w.e.f. 1-6-1987.].(2)An inquiry under sub-section (1) shall be
completed within a period of two months from the date of communication of charges against the
employee.(3)(a)No employee shall be placed under suspension except when an inquiry into the
gross misconduct of such employee is contemplated.(b)No such suspension shall remain in force for
more than a period of two months from the date of suspension and if such inquiry is not started and
completed within that period, such employee shall, without prejudice to the inquiry, be deemed to
have been restored as employee:Provided that the competent authority may, for reasons to be
recorded in writing, extend the said period of two months for a further period not exceeding two
months, if in the opinion of such competent authority the inquiry could not be completed within the
said period of two months for reasons directly attributable to such employee.(4)Every such
employee as is placed under suspension under sub-section (3) shall be paid subsistence allowance atAndhra Pradesh Education Act, 1982

such rates as may be prescribed during the period of his suspension.(5)Before imposing any penalty,
other than the penalties specified in subsection (1), an employee shall be informed in writing of the
allegations on which action is proposed to be taken and be given an opportunity of making a
representation, but it shall not be necessary to hold an oral inquiry into such allegations.
80. Appeal against orders of punishment imposed on employees of private
institutions: -
(1)Any employee who is dismissed, removed or reduced in rank may prefer an appeal against the
order to the competent authority within thirty days of the receipt of order by him.(2)The competent
authority shall not interfere with the order appealed against unless the order is vitiated on any one
or more of the following grounds namely,-(a)that there is no material to substantiate the charge or
charges framed against the employee ; or(b)that the authority who passed the order acted with bias
or mala fides ; or(c)that the order is perverse or arbitrary ; or(d)that no reasonable opportunity has
been afforded to the employee to prove his innocence :Provided that the competent authority shall
not pass any order prejudicial to the management unless an opportunity of making a representation
is given.(3)The competent authority may, after giving notice to the management of the private
institution, pass such interim orders as it deems fit, pending disposal of the appeal under
sub-section (2), if it is satisfied that the employee has made out a prima facie case for
interference.(4)In respect of an order imposing any penalty as laid down in sub-section (5) of
Section 79 an appeal shall lie to the District Educational Officer having jurisdiction and in respect of
such appeals the order appealed against shall not be set aside except on the grounds specified in
sub-section (2).Explanation: - For the removal of doubts, it is hereby declared that , the provisions
of this section shall apply to any order imposing any penalty made on or after the date of the
commencement of this Act in any disciplinary proceeding which was pending on that date.
81. Appeal to Government: -
(1)Any employee or the management aggrieved by an order of the competent authority under
sub-section (2) of Section 80, may appeal to the Government within a period of thirty days from the
date of receipt of the order.(2)Where an appeal preferred under sub-section (1) of Section 80 has not
been disposed of by the competent authority within ninety days from the date the appeal was
preferred, it shall be competent for the Government either suo motu or on application, to withdraw
the appeal from the competent authority and dispose of the same.(3)The powers exercisable and the
procedure to be followed by the Government acting under this section shall be the same as that of
the competent authority under Section 80.
82. Special provisions regarding appeal in certain past disciplinary cases: -
(1)If, before the date of the commencement of this Act, any employee has been dismissed or
removed or reduced in rank of appointment has been otherwise terminated and any appeal
preferred before that date -(a)by him against such dismissal or removal or reduction in rank or
termination, or(b)by him or by the educational agency against any order made before that date inAndhra Pradesh Education Act, 1982

the appeal referred to in Clause (a) ;is pending on that date, such appeal shall stand transferred to
the competent authority under Section 80.(2)If any such appeal as is referred to in sub-section (1)
has been disposed of before the date of the commencement of this Act, the order made in any such
appeal shall be deemed to be an order made under this Act, and shall have effect accordingly.
83. Retrenchment of employees: -
Where retrenchment of any employee is rendered necessary by the management or competent
authority consequent on any change relating to education or course of instruction or to any other
matter, such retrenchment may be, effected with the prior approval of the competent authority or
the next higher authority, as the case may be.
84. Pay and allowances of employees of private institutions to be paid in the
prescribed manner: -
(1)The pay and allowances of any employee in a private institution shall be paid on or before such
day of every month in such manner and by or through such authority, officer or person as may be
prescribed.(2)The Government shall have power to direct the payment of salaries of all teachers and
members of the non-teaching staff in any private aided institution or class of private aided
institutions in such manner and through such agency as the Government may, by order, specify.
84A. [ Penalties for contravention of this Chapter: - If the management or
manager contravenes, or attempts to contravene, any of the provisions of
this Chapter or any rule or order made thereunder, it or he shall be punished
with imprisonment for a term which may extend to one year and with fine
which may extend to five thousand rupees and in the case of continuing
contravention, with imprisonment for a term which may extend to two years
and with fine which may extend to ten thousand rupees, in addition to
withdrawal of recognition of the institution] [Inserted by Act No. 27 of 1987,
w.e.f. 1-6-1987.].
Chapter XV
Welfare and code of Conduct and Rules of Conduct of the
Employees of Educational Institutions
85. Welfare of employees and their code of conduct: -
(1)The Government may appoint a joint consultative committee, consisting of the representatives of
the Government, managements and employees of educational institutions to deal with matters
pertaining to welfare of those employees.(2)The Government may [x x x] [Omitted by Ibid.]Andhra Pradesh Education Act, 1982

prescribe the code of conduct and duties of those employees.
86. Conduct rules: -
The rules of conduct applicable to the employees of educational institutions, other than the
employees of a private institution under the management of a charitable or religious institution,
charitable or religious endowment or a wakf, shall be such as may be prescribed.
Chapter XVI
Penalties and Procedure
87. Penalties for contravention: -
(1)If any person contravenes, or attempts to contravene, or abets the contravention of, any of the
provisions of this Act or any rule made thereunder, he shall be punished with fine, which may
extend to [one thousand] [Substituted by Act No. 27 of 1987, w.e.f. 1-6-1987.] rupees and in the case
of continuing contravention, with an additional fine which may extend to [two hundred]
[Substituted by Act No. 27 of 1987, w.e.f. 1-6-1987.] rupees for every day during which such
contravention continues after conviction for the first such contravention.(2)If any person obstructs
any authority, officer or person from entering any private educational institution in the exercise of
any power conferred on it or him by or under this Act, he shall be punished with fine which may
extend to [two thousand rupees] [Substituted by Act No. 27 of 1987, w.e.f. 1-6-1987.].
88. Offence by companies: -
(1)Where an offence against any of the provisions of this Act or any rule made thereunder has been
committed by a company, every person who at the time the offence was committed, was In-charge of
and was responsible to the company for the conduct of business of the company, as well as the
company, shall be deemed to be guilty of the offence and shall be liable to be proceeded against and
punished accordingly :Provided that nothing contained in this sub-section shall render any such
person liable to any punishment, if he proves that the offence was committed without his knowledge
or that he had exercised all due diligence to prevent the commission of such
offence.(2)Notwithstanding anything in sub-section (1), where any such offence has been committed
by a company and it is proved that the offence has been committed with the consent or connivance
of, or is attributable to any neglect on the part of any director, manager, secretary or other officer of
the company, such director, manager, secretary or other officer shall be deemed to be guilty of that
offence and shall be liable to be proceeded against and punished accordingly.Explanation: - For the
purpose of this section, -(a)"company" means any body corporate and includes a firm, a society or
other association of individuals, and(b)"director" in relation to(i)'a firm' means a partner in the
firm,(ii)'a society or other association of individuals' means the person who is entrusted, under the
rules of the society or other association, with management of the affairs of the society or other
association, as the case may be.Andhra Pradesh Education Act, 1982

Chapter XVII
Miscellaneous
89. Appeals: -
Save as otherwise provided in this Act, -(a)any person aggrieved by an order passed by an officer or
authority other than the Director under this Act may, within thirty days from the date of
communication of such order, appeal to the Director;(b)any person aggrieved by an order passed by
the Director under this Act other than an order passed by him under Clause (a) may, within sixty
days from the date of the communication of such order, appeal to the Government.Explanation: -
For purposes of this section and Section 92, the expression "Director" includes the Additional
Director or Joint Director when he exercises the powers of the Director under this Act.
90. Power of revision by the Government: -
(1)The Government may, either suo motu or on an application from any person interested, call for
and examine the record of an educational institution or of any authority, officer or person in respect
of any administrative or quasi-judicial decision or order, not being a proceeding in respect of which
a reference to an arbitrator or an appeal to the High Court is provided, to satisfy themselves as to the
regularity, correctness, legality or propriety of any decision or order passed therein ; and if, in any
case it appears to the Government that any such decision or order should be modified, annulled or
reversed or remitted for reconsideration, they may pass order accordingly :Provided that the
Government shall not pass any order adversely affecting any party unless such party has had an
opportunity of making a representation.(2)The Government may stay the execution of any such
decision or order pending the exercise of powers under sub-section (1) in respect thereof.(3)Every
application preferred under sub-section (1) shall be made within such time, and in such manner and
accompanied by such fees as may be prescribed.
91. Review: -
(1)The Government or the Director may suo motu at any time or on an application received from
any person interested within ninety days of the passing of any order under the provisions of this Act,
review any such order, if it was passed by them or him under any mistake, whether of fact or of law,
or in ignorance of any material fact.(2)The provisions contained in the proviso to sub-section (1) and
in sub-sections (2) and (3) of Section 90 shall, so far as may be, apply in respect of any proceeding
under this section as they apply to a proceeding under sub-section (1) of that section.
92. Powers of Government to give directions: -
(1)The Government may, subject to other provisions of this Act, by order, direct the Director or any
other officer not below the rank of a District Educational Officer, to make an enquiry or to take
appropriate proceeding under this Act in respect of any matter specified in the said order ; and theAndhra Pradesh Education Act, 1982

Director or the other officer, as the case may be, shall report to the Government in due course the
result of the enquiry made or the proceeding taken by him.(2)The Government may give directions
to any educational institution or tutorial institution as to the giving effect to any of the provisions
contained in this Act or of any rules or orders made thereunder and the manager or owner, as the
case maybe, of such institution shall comply with every such direction.
93. Delegation of powers of Government: -
The Government may, by notification, delegate all or any of their powers under this Act, except
those conferred upon them by this section and Sections 90, 91, 99 and 102 to any person or
authority subordinate to them subject to such conditions and to such control and revision by such
authority as may be specified in the notification ; and they may in the like manner withdraw any
powers so delegated.
94. Emergency powers of Director: -
(1)Where, at any time, it appears to the Director that the manager of a private institution or a local
authority institution has made default in performing any functions entrusted to him by or under this
Act relating to the maintenance and administration of the institution, he may, by order in writing,
fix a period for the performance of such function.(2)If the manager of a local authority institution or
of a private institution other than a minority educational institution fails to perform the function
within the period so fixed the Director may appoint any officer subordinate to him to perform such
function on behalf of the manager for the purpose of securing the proper maintenance and
administration of the institution for the purpose of avoiding hardship to the employees of the
institution and may direct that the expenses of performing such function shall be paid within such
time as he may fix, to the Government by the manager out of the funds of the institution and without
prejudice to any other method of recovery, the whole or any part of such expenses may be deducted
from any sum payable to the institution by way of grant-in-aid.
95. Power to enter and inspect: -
Every officer not below the rank of a deputy inspector in respect of an educational institution
imparting primary education and in respect of other institutions, any other officer not below such
rank as may be prescribed, shall, subject to such conditions as may be prescribed, be competent to
enter at any time during the normal working hours of an educational or tutorial institution, any
premises of any such institution, within his jurisdiction and to inspect any record, register or other
documents or any movable or immovable property relating to such institution for the purpose of
exercising his powers and performing his functions under this Act.
96. Penalty for obstructing officer or other person exercising powers under
this Act: -Andhra Pradesh Education Act, 1982

Any person who obstructs an officer of the Government in the exercise of any power conferred on
him, or in the performance of any function entrusted to him, by or under this Act or any other
person lawfully assisting such officer in the exercise of such power or in the performance of such
function or who fails to comply with any lawful direction made by such officer or person shall be
punished with fine which may extend to [one thousand rupees] [Substituted for the words 'two
hundred and fifty rupees' by Act No. 27 of 1987, w.e.f. 1-6-1987.].
97. Protection of acts done in good faith: -
No suit, prosecution or other legal proceeding shall be instituted against the Government or any
officer, authority or person empowered to exercise the powers or perform the functions by or under
this Act for anything which is in good faith done or intended to be done under this Act or under the
rules or orders made thereunder.
98. Managers, employees etc., to be public servants: -
Every manager of any educational institution and every employee of such institution shall be
deemed to be a public servant within the meaning of Section 21 of the Indian Penal Code when on
duty in connection with any examination conducted by the competent authority under this Act.
99. Power of Government to make rules: -
(1)(a)The Government may by notification [x x x] [The words 'and after previous publication'
omitted by Act No. 27 of 1987, w.e.f. 1-6-1987.] make rules to carry out all or any of the purposes of
this Act.(b)In particular and without prejudice to the generality of the foregoing power, such rules
may provide for, -(i)[x x x] [Omitted by Ibid.](ii)the steps to be taken for providing necessary
facilities for imparting compulsory primary education before notifying any area to be specified area
;(iii)the manner in which lists of children shall be prepared by the attendance authority in any
specified area ;(iv)the distance beyond which a child cannot be compelled to attend an approved
school ;(v)the manner in which in any enquiry under this Act shall be held;(vi)the form in which an
attendance order under this Act shall be passed ;(vii)the registers, statements, reports, returns,
budgets and other information to be maintained or furnished by approved schools for the purposes
of this Act ;(viii)the declaration as to what constitutes secondary or higher secondary education,
professional education, technical education, special education, school places, school-age and
attendance, in schools or other institutions ;(ix)the registers, statements, reports, returns, accounts
and budgets and other information to be maintained or furnished by the local authorities in respect
of education funds ;(x)the procedure for the assessment and realisation of the taxes leviable under
this Act ;(xi)the establishment or maintenance and administration of educational institutions
;(xii)the grant of recognition to educational institutions and the conditions therefor ;(xiii)regulating
the rates of fees, the levy and collection of fees in educational institutions ;(xiv)the manner in which
accounts, registers, records and other documents shall be maintained in the educational institutions
and the authority responsible for such maintenance ;(xv)the submission of returns, statements,
reports and accounts by managers or owners of properties of educational or tutorial institutions
;(xvi)the inspection of educational and tutorial institutions and the officers by whom inspectionAndhra Pradesh Education Act, 1982

shall be made ;(xvii)the mode of keeping and the auditing of accounts of such institutions ;(xviii)the
standards of education and courses of study in educational institutions ;(xix)the grant of sums by
the Government to educational institutions towards providing scholarships, bursaries, fee
concessions and the like ;(xx)the preparation and submission of development plans for educational
institutions in general and for technical education and the contents of such plans ;(xxi)the powers
and the functions of the officers and other subordinate staff of the Education Department ;(xxii)the
preparation and sanction of building plans and estimates of the educational institutions and the
requirements to be fulfilled by the buildings for the educational institutions maintained by the local
authorities and private institutions;(xxiii)the purposes for which the premises of the educational
institutions may be used and the restrictions and conditions subject to which such premises may be
used for any other purpose ;(xxiv)the regulation of the use of text books, maps, plans, instruments
and other laboratory and sports equipment in the institutions;(xxv)the regulation for admission into
educational institutions of pupils for the academic course, private study and other special courses
and the attendance thereat ;(xxvi)the qualifications necessary and other conditions to be fulfilled for
appearing at the examinations conducted by the authorities under this Act and the method of
valuation or revaluation of answer scripts ;(xxvii)the opening of special night schools and the
conditions for their working and of parallel sections or classes in the institutions for linguistic
minorities ;(xxviii)the manner of conducting the class and terminal examinations and promotion of
pupils to higher classes ;(xxix)the conditions subject to which donations or contributions from the
public maybe accepted by the educational institutions and the naming of institutions ;(xxx)the
conditions for co-education in the educational institutions and the regulation of the conduct and
discipline of the pupils and the penalty for misconduct or indiscipline ;(xxxi)the manner of service
of notices, orders and other proceedings, of presenting appeals or applications for revision or review
and the procedure for dealing with them and the fee in respect thereof ;(xxxii)the scale of fees or
charges or the manner of fixing fees or charges payable in respect of any certificate, permission,
marks list or other document for which such fees may be collected;(xxxiii)the constitution of
educational councils at the Panchayat Samithi and Zilla Parishad and the State level ; their
composition and function ;(xxxiv)all matters expressly required or allowed by this Act to be
prescribed or in respect of which this Act makes no provision or makes insufficient provision and a
provision is, in the opinion of the Government, necessary for the proper implementation of this
Act.(2)Any rule maybe made under this Act with retrospective effect and when such a rule is made
the reasons for making the rule shall be specified in a statement to be laid before both Houses of the
State Legislature.(3)Every notification issued and every rule made under this Act, shall immediately
after it is issued or made, be laid before each House of the State Legislature if it is in session and if it
is not in session in the session immediately following for a total period of fourteen days which may
be comprised in one session or in two successive sessions and if, before the expiration of the session
in which it is so laid or the session immediately following both Houses agree in making any
modification in the notification or in the rule, or in the annulment of the notification or the rule, the
notification or the rule shall, from the date on which the modification or annulment is notified, have
effect only in such modified form or shall stand annulled, as the case may be ; so however that any
such modification or annulment shall be without prejudice to the validity of anything previously
done under that notification or rule.Andhra Pradesh Education Act, 1982

100. Exemption: -
The Government may, by notification and for reasons to be specified therein, exempt any
educational institution from the operation of all or any of the provisions of this Act or the rules
made thereunder, subject to such conditions as they may deem fit to impose and may likewise vary
or cancel such exemption.
101. Repeals: -
(1)The following Acts are hereby repealed :(a)The Andhra Pradesh (Andhra Area) Elementary
Education Act, 1920 ;(b)The Andhra Pradesh (Andhra Area) Aided Institutions (Prohibition of
Transfer of Property) Act, 1948 in so far as it relates to the institutions which are intended for an
educational purpose ;(c)The Andhra Pradesh Educational Institutions (Requisitioning and
Acquisition) Act, 1956 ;(d)The Andhra Pradesh Primary Education Act, 1961 ;(e)The Andhra
Pradesh Recognised Private Educational Institutions (Control) Act, 1975.(2)Upon such repeal, the
provisions of Sections 8 and 18 of the Andhra Pradesh General Clauses Act, 1891, shall apply.
102. Power to remove difficulties: -
If any difficulty arises in giving effect to the provisions of this Act, the Government may by order
make such provisions not inconsistent with the purposes of this Act, as appears to them to be
necessary or expedient for removing the difficulty.[Inserted by Act No. 40 of 2008, w.e.f. 1-1-1994.]Andhra Pradesh Education Act, 1982

