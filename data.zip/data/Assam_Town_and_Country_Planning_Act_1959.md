Assam Town and Country Planning Act, 1959
ASSAM
India
Assam Town and Country Planning Act, 1959
Rule ASSAM-TOWN-AND-COUNTRY-PLANNING-ACT-1959 of
1959
Published on 1 January 1959• 
Commenced on 1 January 1959• 
[This is the version of this document from 1 January 1959.]• 
[Note: The original publication document is not available and this content could not be
verified.]• 
Assam Town and Country Planning Act, 1959Last Updated 13th February, 2020An Act to provide
for the development of the towns and country sides of the State of Assam.Preamble. - Whereas it is
expedient to provide for the development of the towns and the country sides of the State of Assam
on sound planning principles with the object of securing proper sanitary conditions, to conserve and
promote the public health, safety and general welfare of the people living therein;It is hereby
enacted in the Tenth Year of the Republic of India as follows: -
Chapter I
Preliminary
1. Short title, extent and commencement.
(1)This Act may be called the Assam Town and Country Planning Act, 1959.(2)It shall extend to
whole of Assam excluding the Autonomous Districts:Provided that if any District Council desires
that all or any of the provisions of this Act should apply to the Autonomous District concerned, a
notification may be issued to that effect and this Act shall then extent to that Autonomous District
subject to such exceptions or modifications as may be specified in the notification.
2. Definitions.
- In this Act, unless there is anything repugnant in the subject or context :-(1)"Authority" shall mean
the Local or Regional Authority appointed by the State Government for the purpose of
administering the Act. Unless otherwise appointed by the State Government, the Authority in the
case of Municipal Areas shall be taken to mean the Municipal Board for the area constituted under
the Assam Municipal Act, 1956 (Assam Act XV of 1957).(2)"Advisory Council" means the Town and
Country Planning Advisory Council constituted under section 3 of this Act.(3)"Betterment Fee"Assam Town and Country Planning Act, 1959

means the fee prescribed in respect of an increase in the value of land resulting from the execution
of a Development Scheme.(4)"Building" means any construction for whatsoever purpose and of
whatsoever materials constructed and every part thereof, whether used as human habitation or not
and includes plinth walls, chimney, drainage works, fixed platforms, verandah, balcony, cornice or
projection, or part of a building on anything affixed thereto or walls, earth bank, fence or other
construction enclosing or delimiting or intended to enclose or delimit any and or space.(5)"Building
Industrial" means a building which is wholly or predominantly used as a warehouse, factory,
distillery iron foundry and all other buildings put to or be put to any use permitted in the zone by an
authorised scheme applicable thereto.(6)"Director" means Director of Town and Country Planning
or any other officer appointed by the State Government.(7)"Development" means the carrying out of
buildings, engineering, mining or other operations in on or over the land, or making of any material
change in the use of any buildings or of land:Provided that the following operations or uses of land
shall not be deemed for the purposes of this Act to mean development of the land, that is to say
-(a)the carrying out of works for the maintenance, improvement or other alteration of any buildings
being works which affect only the interior of the building or which do not materially affect the use
and the external appearance of the building;(b)the carrying out by a local authority of any works
required for the maintenance or improvement of road being works carried out on land within the
boundaries of the road;(c)the carrying out by any local authority any works for the purposes of
inspecting, repairing or renewing any sewers, main pipes, cables or other apparatus, including the
breaking open of any street or other land for that purpose;(d)the use of any building or other land
within the curtilage of a dwelling house for any purpose incidental to the enjoyment of the dwelling
house as such.(8)"Factory" means a place to which the provisions of the Indian Factories Act of 1934
or any amendment thereof shall apply.(9)"Industrial Concern" means a commercial body e.g. a
factory, workshop and a mill or any concern of similar nature where materials are manufactured
repaired altered or processed.(10)"Master Plan" means a plan as defined under section 9 and shall
comprise of items (a) to (e) of section 11.(11)"Occupier" includes any person paying or liable to pay
the rent or any portion of the rent of the land or building in respect of which the work is due or
compensation or premium on account of the occupation of such land and building and also a rent
free tenant.(12)"Open space" means any land whether enclosed or not on which not more than
one-twentieth part is covered with buildings and whole of the remainder has been laid out as a
public garden or used for purposes of recreation or lies waste and unoccupied.(13)"Prescribed"
means prescribed by rules made under this Act.(14)"Reconstituted plot" means a plot which is in
any way altered by the making of a Development Scheme.(15)"Road" means and includes any
highway, street, lane, pathway, alley, passageway, carriageway, footway, square, bridge, whether
private or public, whether thoroughfare or not, whether existing or proposed in any scheme and
includes all bunds, channels, ditches, drains, culverts, side walks and traffic islands.(16)"Scheme"
means a development scheme and includes a plan or plans together with the descriptive matter if
any relating to such a scheme.
Chapter II
Constitution of the Advisory CouncilAssam Town and Country Planning Act, 1959

3. Constitution of the Town and Country Planning Advisory Council.
(1)The State Government may constitute, by a notification in the Official Gazette, the Council
consisting of the following members to advise the Government on matters referred to it: -
(i)Minister-in-charge of Town and Country Planning. ...Chairman
(ii) Director of the Town and Country PlanningDepartment. ...Secretary
(iii) Secretary, Town and Country PlanningDepartment. ...Member
(iv) Chief Engineer, Public Works Department.(R. and B.) or his nominee. ...Member
(v) Chief Engineer, Public Works Department.(Flood Control) or his nominee ...Member
(vi) Public Health Engineer or his nominee. ...Member
(vii) Secretary, Local Self-Government or hisnominee. ...Member
(viii) Secretary, Finance Department or hisnominee. ...Member
(ix) Secretary, Revenue Department or hisnominee. ...Member
(x) Six other non-official members half of whomshall be elected by the Assembly and
the rest shall be nominatedby the State Government....Member
(xi)Such member of representatives of Local Authorities falling within the area as may Be covered by
the Master Plan not exceeding two as may be co-opted by the Council by notification, Published in
the official Gazette.(2)Five of the members attending any meeting of the Council shall forms the
quorum for the purpose of transacting the business of that meeting of the Council.(3)All members of
the Council including the co-opted members shall have one vote each and the Chairman shall have a
casting vote in case of equality of division, in addition to his own vote.(4)Nothing done by the
Council in its meeting shall be held to be invalid because of any vacancy in the seats of the
nominated or elected members or the absence of any of the members for any reason
whatsoever.(5)The Chairman shall preside over the meetings of the Advisory Council and in his
absence the members present shall elect one among themselves to be the president for that
particular meeting.
4. Registration of non-official members.
- Any non-official member may at any time resign his office, provided that his resignation shall not
take effect until accepted by the State Government.
5. Term of office.
- The term of office of any non-official member shall ordinarily be three years:Provided that in case
of the members representing the Legislature or Local Authorities, their terms of office shall
terminate as soon as they cease to be member of such Legislature or Local Authority as the case may
be.Assam Town and Country Planning Act, 1959

6. Commencement of the term of office of non-official members.
(1)The term of office of non-official members shall commence on such date as may be notified in this
behalf by the State Government.(2)A person ceasing to be member by reason of the expiry of his
term of office as described in section 5, shall be eligible for re-nomination or re-election.
7. Removal of non-official members.
- The State Government may remove from the Council any member who: -(a)refuses to act, or
becomes incapable of acting or absents himself from three consecutive meetings of the Council and
is unable to explain such absence to the satisfaction of the Council; or(b)has to flagrantly abused in
any manner his position as a member of the Council as to render his continuance detrimental to the
public interest:Provided that when the State Government proposes to take action under the
foregoing provisions of this section, an opportunity of explanation shall be given to the member
concern and when such action is taken, the reason thereof shall be placed or recorded.
8. Filling of casual vacancies.
(1)When the place of a member nominated by the State Government becomes vacant by his
resignation, removal or death, the State Government shall appoint a person to fill the
vacancy.(2)When the place of a member elected or co-opted becomes vacant, he shall be elected or
co-opted by the Legislature or the Council as the case may be.(3)The term of office of a member
nominated or elected or co-opted, as the case may be, under sub-section (1) and (2) shall be the
remainder of the term of office of the member in whose place he has been nominated or elected or
co-opted.
Chapter IIA
Constitution of the Development Authority
8A. Constitution of the Authority.
(1)The State Government may, by notification in the Official Gazette, constitute for the purpose of
this Act, an Authority to be called "The as the Authority" with jurisdiction over such area as may be
specified in the said notification.(2)The Authority shall be a body corporate having perpetual
succession and a common seal with power to acquire, hold and dispose of properties both moveable
and immoveable and to enter into any agreement and shall by the said name sue and be sued.
8B. Composition of the Authority.
(1)The Authority shall consist of the following members, namely:-(a)A Chairman to be appointed by
the State Government;(b)Engineer- in- chief of the Authority to be appointed by the State
Government;(c)Town Planning Officer of the Authority to be appointed by the StateAssam Town and Country Planning Act, 1959

Government;(d)Finance Officer to be appointed by the State Government;(e)Deputy Commissioner
of the Sub divisional Officer, as the case may be;(f)Chairman or Chairmen of the local Authority or
authorities covered by the Master Plan;(g)One member representing Commerce and Industry
(Private Sector) to be nominated by the State Government;(h)One member representing the
Railways, to be nominated by the State Government;(i)One member representing Industry (Public
Sector) to be nominated by the State Government;(j)One person each from the local authorities
covered by the Master Plan to be elected by the members at a meeting from amongst
them.(2)Notification of members. - The name of the members elected and appointed shall be
published in the Official Gazette.(3)Disqualification for election or appointment as member. - A
person shall be disqualified for appointment, nomination or election as a member, if he -(a)has been
convicted of any offence involving moral turpitude;(b)is an applicant to be adjudicated as a
bankrupt or insolvent or is an un-certificated bankrupt or undischarged insolvent;(c)holds any
office of profit under the Authority except those mentioned in clause (a),(b),(c) and (d) of
sub-section (1);(d)has directly or indirectly, by himself or by any partner, any share or interest, in
any contract or employment with by, or on behalf of, the Authority; or(e)is a Director, or a Secretary,
Manager or other salaried Officer of any incorporated company which has any share or interest in
any contract or employment, with, by, or on behalf of the Authority.(4)Removal of members. - The
State Government may remove from the Authority any member including the Chairman who
-(a)refuses to act or becomes incapable of acting or absents himself from three consecutive meetings
of the Authority and is unable to explain such absence to the satisfaction of the Authority;(b)has so
flagrantly abused in any manner his position as a member of the Authority as to render his
continuance detrimental to the public interest;Provided that when the State Government proposes
to take any action under any of the above provisions, an opportunity shall be given to the member
concerned to show cause why action as proposed should not be taken against him;(c)ceases to be a
member of the local authority from which he was elected;(5)A member removed under clauses (a)
and (b) of sub-section (4) all not be eligible for re-appointment or re- election, as the case may be.
8C. Term of office and conditions of service of the Chairman and members of
the Authority.
(1)The term of office and conditions of service of the Chairman and members of the Authority shall
be such as may be prescribed and they shall be entitled to receive such salaries and allowances as
may be fixed by the State Government.(2)The Chairman or any member may resign his membership
of the Authority by giving notice in writing to the State Government and on the resignation being
accepted by the State Government, he shall cease to be a member of the Authority.(3)Any vacancy
created by resignation or removal shall be filled by fresh appointment or nomination by the State
Government, or by election, as the case may be.
8D. Functions and powers of the Authority.
- Subject to the provisions of this Act, rules and directions of the State Government, the function of
the Authority shall be to promote and secure the development of the area according to the Master
Plan and for that purpose it may carry out or cause to be carried out serveys of the area and to
prepare report or reports of such surveys, and to perform any other function which is supplementalAssam Town and Country Planning Act, 1959

incidental or consequential to any of the functions aforesaid or which may be prescribed.
8E. Meeting of the Authority.
(1)Each Authority shall meet once in a month at such time and place and shall subject to the
provisions of sub-sections (2) and (3) observe such procedure in regard to the transaction of
business at its meetings, as may be prescribed by bye-laws to be framed under section 74 of this
Act.(2)The Chairman or in his absence any member chosen by the members from amongst
themselves, shall preside at a particular meeting of the Authority.(3)All questions of the meeting of
the Authority shall be decided by a majority of the votes of the members present and voting and in
the case of an equality of votes, the person presiding shall have a second or casting vote.(4)Nothing
done by the Authority in its meeting shall be held to be invalid because of any vacancy in the seats of
the appointed, nominated or elected members or the absence of any of the members for any reason
whatsoever.(5)Minutes shall be kept of the names of the members present and of the proceedings at
each meeting in a book to be kept for this purpose, which shall be signed at the next ensuing
meeting by the person presiding at such meeting and shall be open to inspection by any member
during office hours.
8EE. Power of Chairman.
- The Chairman shall, for the transaction of the business connected with this Act, or for the purpose
of making any order authorised thereby, exercise all the powers vested by this Act in the
Authority:Provided that the Chairman shall not act in opposition to, or in contravention of any order
of the authority at a meeting, or exercise any power, which is directed to be exercised by the
authority at a meeting.
8F. Temporary association of persons with the Authority for particular
purposes.
(1)The Authority may associate with itself in such manner and for such purposes as may be
prescribed by rules any person whose assistance or advice it may desire in performing any of its
functions under this Act.(2)Any person associated with it by the Authority under sub-section (1) for
any purpose shall have a right to take part in the discussions of the Authority relevant to that
purpose but shall not have a right to vote at a meeting and shall not be a member for any other
purpose.
8G. Staff of the Authority.
(1)Subject to such control and restrictions as may be prescribed by rules, the Authority may appoint
such number of officers and employees as may be necessary for the efficient performance of its
functions and may determine their designations and grades.(2)The officers and employees of the
Authority shall be entitled to receive such salaries and allowances, if any, as may be fixed by the
Authority and shall be governed by such terms and conditions of service as may be determined byAssam Town and Country Planning Act, 1959

rules and regulations made in this behalf.
Chapter III
Master Plan
9. Preparation of Master Plan.
- A Master Plan hereinafter referred to as "Plan" in this Act for the development of any area within
the State which the State Government may consider necessary, shall be drawn up by the Director in
consultation with the local authority/authorities concerned and submitted to the State Government
for examination and approval.
10. Publication of the Master Plan.
(1)On receiving the Plan and the Zoning Regulation from the Director, the State Government shall
have them, as soon as may be, published in the Official Gazette, in some local newspaper and in the
locality in the manner prescribed and deemed to be required for wide and sufficient publicity in the
locality inviting public opinion and objection, if any, to be submitted within a period not more than
two months.(2)After considering all objections, suggestions and representations that may have been
received, and after getting the advice of the Council, the State Government shall have the plan finally
prepared by the Director and adopt the same.
11. Contents of Master Plan and Zoning Regulations.
- The Master Plan to be prepared as defined under Section 9, may include:-(a)A general land-use
plan for residential, commercial, industrial, recreational and public and semi-public
purposes;(b)Zoning plan;(c)Transportation plan including roads, railways, canals etc.;(d)Public
utilities plan;(e)A report giving relevant data and information in respect of the proposals in the Plan
and any other things which the State Government may deem necessary.
12. Implementation of the Plan.
- After adoption of the plan and zoning Regulation they shall be sent by the State Government for
implementation to the Authority constituted under section 8A.
13. Restrictions of use of land and buildings thereon after publication.
(1)The plan as adopted by the State Government shall be published as prescribed in Section 10, and
after such publication no person shall use any land, sub-divide any land or set up any new structure
on any land covered by the Plan or change the existing structure of any building or use of any
building or land within the area except with the permission of the Authority on a written application
submitted for that purpose.(2)Each such application shall be accompanied by a plan drawn to scaleAssam Town and Country Planning Act, 1959

showing the actual dimension of the parcel of the land and the building to be built upon it, the site
and the position of the building to be erected and in case of alteration in the use or structure of the
building or land, the nature and extent of such alteration.(3)The Authority may also call for such
other information as it may deem necessary to examine the application.(4)The Authority shall not
refuse the permission except on the ground of contravention of proposal contained in the Plan or the
Regulations and unless the permission has been refused within a period one month from receipt of
the application or such other information as may be called for by the Authority under sub-section
(3), it shall be presumed that the permission has been given.(5)[ Notwithstanding anything
contained in sub-sections (1) to (4) of this section, the subject matter covered under this section
shall not be applicable in respect of the residents inhabiting the areas notified as a Municipality or a
Town Committee under the provisions of the Assam Municipal Act, 1956 (Assam Act No. XV of
1957) All such matters relating to the said areas shall be dealt with under section 171 of the said Act.]
[Inserted by Section 2 of Assam Act No. 17 of 2012.]
13A. Prohibitions of registration in certain cases.
- Where any deed or document required to be registered under the Indian Registration Act,
1908(Act No. XVI of 1908), purports to subdivide any land covered by the Plan, no registering
officer shall register any such document unless the party presenting the deed or document for
registration produces a No Objection Certificate from the Authority to the effect that the Authority
has no objection to the registration of such deed or document.
14. Power of the State Government to modify the Plan and the Zoning
Regulation.
- The State Government may review the Plan and the Zoning Regulations, from time to time, in such
manner and in such procedure as followed for the preparation and approval of the original plan and
the Regulations.
Chapter IV
Development Scheme
15. Preparation of development Scheme.
(1)After the Commencement of this Act, the Authority may, by notification in the Official Gazette,
declare any area to be a scheme area and shall thereafter prepare a scheme. Where no Authority has
been constituted, the State Government may, by notification in the Official Gazette, declare any area
to be a scheme area and the Director shall thereafter prepare a scheme.(2)Notwithstanding anything
contained in sub-section (1), the State Government may, after making such enquiry as they may
deem necessary by notification in the Official Gazette, direct any local authority to prepare, publish
and submit for their sanction before an appointed date a scheme under this section for an area
specified in such notification.(3)While preparing the scheme, the Authority, the Director or the localAssam Town and Country Planning Act, 1959

authority, as the case may be, shall issue a notice inviting the names of all the claimants of any
interest on any land or building within the area under the scheme to be submitted within a period
not more than one month.(4)Save as provided in this Act, the Authority, Director or local authority
shall not undertake or carry out any development of land in any area which is not a scheme
area.(5)After the commencement of this Act, no development of land shall be undertaken or carried
out in the scheme area by any person or body of persons except in the manner prescribed under
section 13 of this Act.
16. Publication of the Development Scheme.
(1)The Authority, the Director or the local authority, as the case may be, shall have the scheme and
the report and the names of all the claimants published in the manner prescribed under
sub-section(l) of section 10 and have a copy of them served on all persons who preferred claims
under sub-section (3) of section 15, inviting objections to be filed within a period not more than two
months.(2)After the expiry of the aforesaid period, the Authority, the Director or the local authority,
as the case may be, shall examine the scheme in the light of such objection, giving sufficient
opportunity for hearing to all such interested persons who have filed objections and demanded a
hearing in the manner prescribed, and shall approve or refuse to approve or approve with such
modifications as it may deem necessary, for the implementation of the scheme and for imposing for
that purpose reasonable restrictions in the use of land and building within the area.(3)After the
Authority, the Director or the local authority, as the case may be, has adopted the scheme, it shall be
forwarded to the State Government for its approval and sanction, if so required under any rule
prescribed, otherwise the scheme will come into force from the date the scheme is adopted.
17. Implementation of the Development Scheme.
- No person shall within any area where a scheme has come into force erect or proceed with any
building or work or remove or alter or make additions or make any substantial repair to a building
or a part of it, a compound wall or any drainage work or remove any earth or change the use of any
land or building except on permission of the authority on application submitted for the purpose.
Unless the permission has been refused within one month from the date of receipt of the application
it shall be presumed that the permission has been given.
18. Scope of the Development Scheme.
(1)A scheme may be made in accordance with the provisions of the Act in respect of any land which
is -(a)in the course of development,(b)likely to be used for building purposes, or(c)already built
uponExplanation. - The expression "Land likely to be used for building purposes" shall include any
land likely to be used as, or for the purpose of providing open spaces, roads, streets, parks, pleasure
or recreational ground, parking spaces or for the purpose of executing any work upon or under the
land incidental to a scheme, whether in the nature of a building work or not.(2)Such scheme may
make provisions for any of the following matters: -(a)the laying out or re-laying out of land either
vacant or already built upon;(b)the filling up or reclamation of low-lying swamp or unhealthy areas
or levelling up of land;(c)lay out of new streets or roads, construction, diversion, extension,Assam Town and Country Planning Act, 1959

alteration, improvement and stopping up of streets, road and communications;(d)the construction
alteration and removal of buildings , bridges and other structure;(e)the allotment of reservation of
land for roads, open spaces, garlans, recreation, grounds, schools, markets, industrial and
commercial activities, green belts and dairies transport facilities and public purposes of 11
kinds;(f)drainage inclusive of sewarage, surface or sub-soil drainage and sewage
disposal;(g)lighting;(h)water supply;(i)the preservation of objects of historical importance or
natural beauty and of buildings actually used for religious purpose;(j)the imposition of conditions
and restrictions in regard to the open space to be maintained about buildings, the percentage of
building area for a plot, the number, height and character of buildings allowed in specified areas, the
purposes to which buildings or specified areas may be or may not be appropriate, the subdivision of
plots, the discontinuance of objectionable uses of land in any area of reasonable periods, parking
space and loading and unloading space for any building and the sizes of projections and
advertisement signs;(k)the suspension, so far as may be necessary for the proper carrying out of the
scheme, of any rule, bye-law, regulation, notification or order made or issued under any Act of the
State Legislature or any of the Acts which the State Legislature is competent to amend;(l)such other
matter not inconsistent with the objects of this Act.(3)The draft scheme shall contain the following
particulars: -(a)the area, ownership and tenure of each original plot;(b)the land allotted or reserved
under clause (e) of sub-section (2) of section 18 with a general indication of the uses to which such
land is to be put and the terms and conditions subjects to which such land is to be put to such
cases;(c)the extent to which it is proposed to alter the boundaries of original plots;(d)an estimate of
the net cost of the scheme;(e)a full description of all details of the scheme under such clause of
sub-section (2) of section 18, as may be applicable;(f)the laying out or re-laying out of land either
vacant or already built upon;(g)the filling up or reclamation of low-laying swamp or unhealthy areas
or levelling up of land; and(h)any other prescribed particulars.(4)In the scheme the size and shape
of every reconstituted plot shall be determined, so far as may be to render it suitable for building
purposes and where the plot is already built upon, to ensure that the building as far as possible,
complies with the provisions of the scheme as regards open spaces.(5)In order to render original
plots more suitable for building purposes the scheme may contain proposals: -(a)to form a
reconstituted plot by the alteration of the boundaries of an original plot;(b)to provide with the
consent of the owners that two or more original plots each of which is held in one ownership in
severalty or in joint ownership, shall hereafter, with or without alteration of boundaries be held in
ownership in common as a reconstituted plot.(6)The scheme shall include all such provisions as the
Authority may think necessary for carrying out, the objects of the Act including the following
matters :-(a)the laying out or re-laying out of land, either vacant or already built upon;(b)the filling
up or reclamation of low-lying swamp or unhealthy areas or levelling up of land;(c)lay out of new
streets or roads, construction, diversion, extension, alteration, improvement and stopping up of
streets, roads and communications;(d)the construction, alteration and removal of building, brides
and other structures;(e)the allotment of reservation of land for roads, open spaces, gardens,
recreation grounds, schools, markets, industrial and commercial activities, green belts and dairies,
transport facilities and public purposes of all other kinds;(f)drainage inclusive of sewerage, surface
or sub soil drainage and sewage disposal;(g)lighting;(h)water supply;(i)the preservation of objects of
historical importance or natural beauty and of buildings actually used for religious purposes.Assam Town and Country Planning Act, 1959

19. Amendments and alterations of the Development Scheme.
- (i) if after the final scheme has come into force, the Authority considers that the scheme is
defective on account of an error or irregularity or for any other reason, it shall refer to the State
Government to modify or withdraw the scheme and to publish the modified or withdrawn scheme in
the manner prescribed in sub¬section (1) of Section 10.(2)The modification of the scheme shall state
every amendment proposed to be made in the scheme and if any such amendment relates to matter
specified in any or all of the clauses (a) to (1) of sub-section (2) of Section 18, the modification shall
also contain such other particulars as may be found necessary by the Authority.(3)The variation
shall be open to inspection by the public at the office of the Local Body or Bodies as prescribed,
covering the area during office hours.(4)Within one month of the date of publication of the
modification, any person affected thereby may communicate in writing his objection to the
Authority.(5)After receiving the objection under sub-section (4) above, the Authority may, after
making such enquiry as it may think fit, approve the proposed modification with or without any
further modification thereof.(6)Such modification shall take effect as if it were incorporated in the
scheme from the date of its modification.(7)The Authority shall thereafter submit the modified
scheme to the State Government for sanction. The modified scheme shall be published after
sanction as prescribed in sub-section (1) of Section 10.
20. Power to revoke the Development Scheme.
(1)Notwithstanding anything contained in section 19, a scheme may at any time be modified or
revoked by a subsequent scheme made, published and sanctioned in accordance with this
Act.(2)The State Government, at its own initiative or on the application in the Official Gazette
revoke a scheme, if it is satisfied that under the special circumstances of the case the scheme shall be
so revoked :Provided that where revocation or modification is ordered by Government after people
partially or wholly implemented a scheme, compensation should be paid for the necessary
alterations in the manner prescribed.
21. Power of the Authority to impose restriction.
- For the purpose of the Master Plan, the land use and Zoning Regulation and the Scheme, the
Authority may impose reasonable restrictions on the use of the land and building including the
regulating of the open spaces to be maintained around the building or buildings, the percentage of
the plot area to be covered by building or buildings, the number of building or buildings on each
plot, height and character of building or buildings, allowed in specified areas, the purpose for which
building or buildings of the specified areas may or may not be used, the subdivision of plots, parking
space and loading and unloading space for any building and the sizes of projections and such other
matters not inconsistent with the objects of this Act.
Chapter V
Streets and Land SubdivisionsAssam Town and Country Planning Act, 1959

22. [ Power of the State Government to make rules prescribing die width etc.
of public streets. [Substituted by Section 3 of Assam Act No. 17 of 2012.]
(1)The State Government may from time to time, after making assessment as to the needs of the
localities situated within the areas of different development authorities of the State, make rules
prescribing the minimum width for different classes of public streets according to the nature of, the
traffic likely to be carried there, the localities in which they are situated, the heights up to which
buildings abutting thereon may be erected and other similar considerations including,-(i)land
sub-division and layout of public street;(ii)street lanes and setting back of buildings from the regular
line Of the street.(2)The power to make rules under this section shall be subject to the condition.of
previous publication.(3)The rules framed by the State Government under this section shall be
followed while preparing the Master plan by the Director under section 9.(4)Every rule made under
this section shall be laid as soon as may be after it is made, before the Assam Legislative Assembly
while it is in session for a total period of fourteen days which may be comprised in one session or in
two or more successive sessions and if, before the expiry of the session in which it is so laid or the
session immediately following, the Assam Legislative Assembly agrees in making any modification
in the rule or the Assam Legislative Assembly agrees that the rule should not be made, the rules
shall thereafter have effect only in such modified form or be of no effect as the case may be,
however, that any such modification or annulment shall be without prejudice to the validity of
anything previously done under that rule.]
23. Power to prescribe Street lines.
- The Authority may prescribe a line on one or both sides of any public street, provided a public
notice of the proposal has been issued by the Authority in the prescribed manner. No person shall
construct or reconstruct any portion of any building on land within the prescribed new street line.
24. Setting back buildings to the prescribed street line.
(1)If any building or any part of a building abutting on a public street is within such line of the
street, the Authority may require such building to be set back to the prescribed line, whenever it is
proposed -(a)to re-build such building or to take down such building,(b)to remove, reconstruct or
make any addition to or structural alteration in any portion of such building which is within the
regular line of the street.(2)When any building or any part thereof within the prescribed line of the
street falls down or is burnt down or is taken down, under the provisions of this Act or otherwise,
the Authority may at once take possession of the portion of land within the prescribed line of the
street previously occupied by the said building and if necessary, clear the same.(3)Land acquired
under the foregoing sub-sections shall, henceforward be deemed to be a part of the public street.
25. Acquisition of land within the line of street.
- If any private land whether open or enclosed lies, within the prescribed line of a public street and is
not occupied by a building or, if a platform , verandah, steps, compound wall, hedge, or fence orAssam Town and Country Planning Act, 1959

other structure, is within the line of such street the Authority may, after giving the owner of the land
or building a notice of the intention to do so, take possession of the said land with its enclosing wall,
hedge or fence, if any, or of the said platform, verandah, steps, or such other structure as aforesaid
or of the portion of the said platform, verandah, steps or other such structure as aforesaid which is
within the prescribed line of the street.
26. Acquisition of the remaining part of building and land after their portions
within a prescribed line of the street are acquired.
- If a building or land is partly within the prescribed line of a public street and if the Authority is
satisfied that the land remaining after the exclusion of the portion within the said line will not be
suitable or fit for construction of independent building, the Authority shall acquire the remaining
portion of the land if so desired by the owner.
27. Subdivision of private land.
(1)Every person who intends to sub-divide any plot of land within the Master Plan Area shall give
notice in writing to the Authority in his said intention and such notice shall be accompanied by the
plans and statements in triplicate.(2)All plan for subdivision of land shall be in accordance with the
standards prescribed by the State Government.
28. Plans accompanying notice.
- A layout plan drawn to a suitable scale and containing the following information shall accompany
the notice given under section 27 : -(a)The location of the land ,(b)The boundaries of the proposed
land shown on the map, and sufficient description to define the same,(c)Name and address of the
owner of the land,(d)Location, name and present widths of the adjacent roads and lanes,(e)The
major physical characteristics of the land proposed to be sub-divided, including topography, the
approximate location and width of any water course and location of any areas subject to inundation
or flood,(f)The complete layout of the proposed subdivision showing the location and widths of all
the proposed streets, dimensions and uses of all the plots,(g)The locations of all drains, sewers and
other utilities,(h)Building lines permissible.(i)Scale and north line,(j)Key plan.
29. Sanction with or without modification or refusal.
(1)The Authority may either grant or refuse the approval to the plans or may approve them with
such modifications as it may deem fit and thereupon shall communicate its decision to the person
giving the notice within three months from the date of the notice.(2)No person shall be allowed to
construct a building on any plot of land , the subdivision of which has not been previously approved
by the Authority.Assam Town and Country Planning Act, 1959

30. Layout not according to plan.
- Should the Authority determine at any stage that the layout or the construction is not proceeding
according to the sanctioned plan or is in violation of any provisions of this Act, it shall serve a notice
on the applicant requiring him to stay further execution until correction has been effected in
accordance with the approved plan.
31. Penalty for violation.
- The Authority will have power to impose fine not exceeding Rs. 250 on any person, firm or
corporation who violated , disobeys, refuses to comply with, or who resists the enforcement of any of
the provisions of this Act, Continuation of the violation shall constitute a separate offence for which
a fine of Rs. 50 per day may be imposed for the days after the first conviction. An appeal shall lie to
the Appellate Authority constituted under this Act.
Chapter VI
Acquisition of Land
32. Power of the State Government to acquire land.
- Where on the representation of the Authority it appears to the State Government that in order to
enable it to execute the scheme it is necessary that land within, adjoining or surrounded by any such
area should be acquired, the State Government may in consultation with the Council acquire the
land by publishing in the Official Gazette a notice to the effect that the State Government has
decided to acquired the land in pursuance of this section.
33. Proceeding for acquisition of land.
(1)The provisions of the Land Acquisition Act, 1894 (Central Act No. 1 of 1894) shall be applicable
for acquisition of Land under this Act and the compensation shall be computed under the provisions
of the same Act.(2)In computing compensation for land acquired, the value will be the market value
as prevailed on the 1st of January, 1957.(3)The owner of the lands will also be entitled to the
reasonable cost of development, if any, made during the period.(4)Twenty- five percent increase in
value on the date of acquisition of the land.
34. Disposing of land.
- Subject to the rules made under this Act [.....], the Authority may retain, lease, exchange or
otherwise, transfer any land acquired by it under this Act.Provided that in case of lease or transfer
the owner will get first priority, if due to acquisition he becomes landless.Assam Town and Country Planning Act, 1959

35. Provisions of private negotiation before compulsory acquisition.
(1)The Authority may, in the first instance, make reasonable efforts to purchase any land by private
negotiation.(2)In case of failure to purchase the land by private negotiation within a specified time,
the said land shall be compulsorily acquired.(3)Nothing in this section shall, however, debar the
State Government or a local authority from compulsorily acquiring any land without prior private
negotiation.
36. Payment to owner by adjustment.
- All payment due to be made to any person by the Authority under this Act shall so far as possible,
be made by an adjustment in respect of the plot concerned or of any other plot in which he has an
interest and failing such adjustment shall be paid in case or in such other way as may be agreed
upon by the parties.
Chapter VII
Compensation and Betterment
37. Right to compensation.
- Any person whose property is injuriously affected in value by the making of a scheme shall, if he
makes a claim for the purpose within a period of three months after the date of publication of a
notification sanctioning the scheme under section 16, be entitled to obtain compensation in respect
thereof from the Authority.
38. No right to compensation.
- A person shall not be entitled to obtain compensation under the foregoing section on account of
any building erected on or contract made or other thing done with respect to any land within the
area included in a scheme after the date of the notification of the scheme under section 15 :Provided
that this provisions shall not apply to any building erected, contract made or other thing done in
accordance with the permission granted under sections 13 and 17 of this Act.
39. Power of Government to exclude compensation in certain cases.
(1)No compensation shall be payable in respect of any property which may be injuriously affected by
putting into operation of any provision of the scheme which : -(a)prescribes the space about
buildings; or(b)limits the number of buildings; or(c)regulates the size, height, design or external
appearance of buildings; or(d)prohibits or restricts buildings operations permanently or temporarily
on the ground that erection of buildings thereon will be likely to be injurious to the health of the
occupants or the neighbours or likely to cause excessive expenditure of public money in making
provisions for roads, sewers, water supply or other public services; or(e)prohibits or restricts the useAssam Town and Country Planning Act, 1959

of land or a building for a purpose which may involve danger or injury to public hygiene or the
health of the occupants or their neighbours or for a purpose which is against the public policy or
public morals; or(f)in the interest of safety, regulates the height and position of proposed walls, and
building fences or hedges near the corners or bends of roads; or(g)in the case of the erection of any
building intended to be used for purposes of business or industry, requires the provisions of parking
the vehicles.(2)No compensation shall be payable for refusal of permission to make any alteration in
any building which is not in conformity with the use specified in the Plan or in the scheme.
40. Right of owner to require Authority to acquire or purchase land.
(1)The owner of any land which is to be acquired for purposes of a scheme may, at any time, after
the sanction of the scheme by the Government, by a written notice to the Authority in the prescribed
manner, call upon it to acquire or purchase the land and in so far as the land is to be acquired by the
State Government or the Authority.(2)If within six months of the service of the notice under
sub-section (1) the land is not purchased or acquisition proceedings are not started, the scheme, in
so far as that land is concerned, shall be deemed to have been withdrawn and all notices and orders
in that connection shall lapse.
41. Levy of betterment fee.
(1)Every property which has increased in value due to its inclusion within an area under a plan or a
scheme or due to the execution of such schemes shall be charged with a betterment fee :Provided
that no such fee shall be levied on such public and or building as are used for charitable, religious
and educational purposes or for places of non-professional entertainment and recreation.(2)The
betterment fee shall be an amount equal to twenty percent in case of residential holdings so long the
original owners use for their residence and equal to fifty percent in case of non-residential areas and
will be realised in five equal instalments.Explanation. - The increase in value for the purpose of this
Section shall be the increase in the market prices in between the date on which a notification under
sub-section (1) of section 15 has been issued and the date on which the execution of the scheme ahs
been substantially completed.
42. Appeal.
(1)Any person aggrieved by the decision of the Authority with respect to matters of compensation
and betterment fee, may appeal to the Appellate Authority within thirty days of the award.(2)If the
owner of any property objects to the amount of betterment fee determined by the Authority on any
ground he shall also state the amount which, he contents would be correct and may within thirty
days of the date on which the determination of his objection or appeal becomes final by written
notice, require the authority to acquire the property together with any building or other works that
may exist thereon.(3)The authority shall thereupon acquire the property.Assam Town and Country Planning Act, 1959

Chapter VIII
Appeals and the Appellate Authority
43. Appointment of Appellate Authority.
(1)Save as otherwise provided, the State Government shall appoint an Appellate Authority to hear all
appeals arising out of the provisions of this Act. The decision of Appellate Authority shall be
final.(2)The person or persons appointed by the State Government as Appellate Authority shall have
the qualification of a District Judge, [or of becoming a member of the Assam Board of Revenue
constituted under the Assam Board of Revenue Act 1962, (Assam Act XXI of 1962)]. The
appointment shall be on such terms and conditions as the State Government may decide.
44. Duties of the Appellate Authority.
(1)The duties and powers of the Appellate Authority shall be as follows -(a)to hear and decide
appeals against the orders of the Authority.(b)to decide and hear appeals in respect of such other
matters and exercise such other powers as may be entrusted to and conferred upon it by the State
Government in accordance with the provisions of this Act.(2)All appeals to the Appellate Authority
shall be filed within a month from the date of the order appealed against. The time required for
taking out copies of the order shall be excluded. The Appellate Authority may, however, in its
discretion condone such delay in filing appeal for sufficient reasons.
45. Procedure of working of the Appellate Authority.
- The Appellate Authority shall conduct its proceedings in the prescribed manner after giving the
opposite party or any one interested in the order appealed against and opportunity of being
heard.(2)The Appellate Authority may, at any time, call for any extract from any proceeding of the
State Government or Authority and call for any return or statement or report concerning or
connected with any matter with which the authority has been authorised to deal.(3)The Appellate
Authority shall have all the powers of a Civil court for the purposes of taking evidence on oath of
enforcing the attendance of witnesses including the parties interested or any of them and compelling
the production of documents and material objection if considered necessary.(4)The Appellate
Authority in its discretion may make any orders regarding the cost to be paid by any of the parties to
the proceedings and the Appellate Authority shall have full powers to determine by whom or out of
what property and to what extent such costs are to be paid and the authority shall be bound to
execute the orders of the Appellate Authority in accordance with the directions, if any, contained in
the order and such costs or amounts awarded by the Appellate Authority shall be realised as arrears
of land revenue.
46. Right to appear by recognised agent.
- Every party to any proceeding before the Appellate Authority shall be entitled to appear either inAssam Town and Country Planning Act, 1959

person or by his recognised agent.
47. Protection of action taken under this Act.
(1)No suit, prosecution or other legal proceedings shall lie against any person for anything which is
in good faith done or intended to be done in pursuance of this Act or any order made
thereunder.(2)Save as otherwise expressly provided in this Act, no suit or other legal proceeding
shall lie against the State Government for any damage caused or likely to be caused by anything in
good faith done or intended to be done in pursuance of this Act or any order made thereunder.
Chapter IX
Finance
48. Development Fund.
- The receipt of Authority under this Act shall form a separate development fund and all expenditure
under this Act or any development scheme thereunder, shall be defrayed out of such fund. No
portion of the fund shall, except with the sanction of Government, be expended for purposes not
provided by this Act.
49. Powers to borrow.
- Authority as defined in this Act shall be deemed to be a local authority as defined in the Local
Authorities Loans Act, 1914 (Central Act, IX of 1914) for the purpose of borrowing money under that
Act, and the making and execution of a plan and scheme shall be deemed to be a work which such
local authority is legally authorised to carry out.
50. Grants, advances and loans.
- The Government may make such grants, advances, and loans to the Authority as the Government
may deem necessary for the performance of functions of the Authority under this Act issued all
grants.
Chapter X
Legal Proceedings
51. Penalty for breach of the provisions of the Master Plan or scheme.
(1)When a Master Plan or a scheme has been sanctioned under this Act any person who commits or
knowingly permits a breach of any specified provisions of the Master Plan or of the scheme or who
neglects or fails to comply with any such provisions shall be punishable under this section.(2)In caseAssam Town and Country Planning Act, 1959

of any such breach or default the Authority shall send to any such person a notice calling on him to
him to discontinue the breach or cause it to be discontinued or to comply with such provision of the
Master Plan or the scheme within a time to be specified in the notice.(3)If after such time any such
person under sub-section (1) continues to neglect or causes a breach of any specified provision, such
persons shall be prosecuted and on conviction by a Magistrate be punishable by any or all or the
following:-(i)with fine which may extend to Rs.500 with or without simple imprisonment not
exceeding a period of 2 months;(ii)if the breach, neglect or failure continues after such conviction
with fine which may extend to Rs.30 for every day during which the breach, neglect or failure
continues after such conviction.
52. Power to execute works on failure to comply with notice.
- If a notice has been given under this Act to a person requiring him to execute a work in respect of
any property, movable or immovable, or to provide or do or refrain from doing anything within a
time specified in the notice and if such person fails to comply with such notice, then the authority
may cause such work to be executed or such thing to be provided or done, and may recover all
expenses incurred by it on such account from the said person as an arrear of land revenue.
53. Right of occupier to execute works in default of owner.
- When default is made by the owner of a building or land in the execution of any work required
under this Act to be executed by him, the occupier of such building or land may, with the prior
approval of the Authority cause such works to be executed, and the expenses thereof shall, in the
absence of any contract to the contrary, be paid to him by the owner, or the amount may be
deducted out of the rent from time to time becoming due from him to such owner.
54. Procedure upon opposition to execution by occupier.
(1)If after receiving information of the intention of the owner of any building or land to take any
action in respect thereof in compliance with a notice issued under this Act, the occupier refuses to
allow such owner to take action, the owner, may apply to a District Magistrate or Sub Divisional
Officer as the case may be.(2)The District Magistrate or Sub Divisional Officer upon proof of such
refusal may make an order in writing requiring the occupier to allow the owner to execute all such
works, with respect to such building or land, as may be necessary for compliance with the notice,
and may also, if he thinks fit, order the occupier to pay to the owner the costs relating to such
application or order.(3)If after the expiry of eight days from the date of the Magistrate's order, the
occupier continues to refuse to allow the owner to execute such work, the occupier shall be liable,
upon conviction, to a fine which may extend to Rs.30 for every day during which he has so
continued to refuse.(4)Every owner, during the continuance of such refusal shall be discharged from
any liability on account of such breach or default.Assam Town and Country Planning Act, 1959

55. Recovery of cost of work by the occupier.
- When the occupier of a building or land in compliance with a notice issued under this Act,
executed a work for which the owner of such building or land is responsible, either in pursuance of
the contract of tenancy or by law, he shall, in the absence of any contract to the contrary, be entitled
to recover from the owner by deduction from the rent payable by him or otherwise the reasonable
cost of such work.
56. Penalty for obstructing contractor or removing mark.
- If any person -(a)obstructs or assaults any person with whom the authority has entered into a
contract for the performance or execution by such person of his duty or of anything which he is
empowered or required to do under this Act; or(b)removes any mark set up for the purpose of
indicating any level or direction necessary to the execution of works authorised under this Act, shall
be punishable with fine which may extend to Rs.500 or with or without simple imprisonment for a
term which may extend to two months.
57. Officers under the Act to be public servants.
- Every officer and servants of authority and every other officer employed by the State Government
for the purposes of this Act, shall be deemed to be a public servant within the meaning of section 21
of the Indian Penal Code (Central Act.No. 15 of 1860).
58. Authority for prosecution.
- Unless otherwise expressly provided, no court shall take cognizance of any offence punishable
under this Act, except on the complaint of, or upon information received from, the Authority or
some person authorised by the Authority by orders in this behalf.
59. Power of Authority to institute proceedings, etc., and to take legal advice.
- The Authority shall subject to rules framed under this Act have powers to -(a)institute, defend or
withdraw from legal proceedings under this Act;(b)compound any offence against this Act, before
the matter is referred to the court ;(c)admit compromise, or withdraw any claim made under this
Act and(d)obtain such legal advice and assistance as it may from time to time think necessary or
expedient to obtain for any of the purposes, referred to in the foregoing clauses of this section for
securing the lawful exercise or discharge of any power or duty vested in or imposed upon the
Authority or any officer or servant or the Authority.
59A. Power to recover dues as an arrear of land revenue.
- Any sum recoverable by the Authority under this Act, if not paid on demand, shall be recoverable
as an arrear of land revenue.Assam Town and Country Planning Act, 1959

60. Bar to suits and prosecutions in certain cases.
(1)No suit, prosecution or other proceeding shall lie against an Authority or any officer or servant
thereof or any person acting under their direction or any Government Officer or servant employed
for the purposes of this Act for anything which is in good faith done in pursuance of this Act, or any
rules made thereunder.(2)No suit, prosecution or other proceedings shall lie against any officer or
servant of the authority or any Government Officer or servant employed for the purposes of this Act
for anything done under this Act,-(a)unless the previous sanction of the State Government has been
obtained; and(b)until the expiration of two months after notice in writing has been given to the
person to be used, clearly stating the cause of action, and the nature of relief sought, etc.
61. Punishment for malicious abuse of powers.
- Any officer or servant of the Authority or of the Government who wilfully or negligently abuses any
power conferred on him by or under this Act, shall be punishable with imprisonment which may
extend to six months or with fine which may extend to Rs.500 or with both:Provided that no
prosecution shall be instituted under this section -(a)unless the previous sanction of the State
Government has been obtained ;(b)until the expiry of two months notice in writing has been given
to the person concerned clearly stating the cause of action and the nature of relief sought, etc.
62. Registration of documents plans, or maps in connection with scheme.
(1)Nothing in the Indian Registration Act, 1908 (Central Act No. XVI of 1908) shall be deemed to
required the registration of any documents, plan or map prepared, made or sanctioned in
connection with a scheme which has come into force.(2)All such documents, plans and maps
relating to the sanctioned scheme shall, for the purposes of sections 48 and 49 of the Indian
Registration Act, 1908 (Central Act XVI of 1908) be deemed to have been and to be registered in
accordance with the provisions of that Act:Provided that documents, plans, and maps relating to the
scheme shall be accessible to the public, free of charge in the manner prescribed.
63. Orders under the Act not to be questioned in any Court.
- No order made in exercise of any power conferred by or under this Act shall be called in question
in any court except as provided in this Act.
64. Effect of orders inconsistent with other enactments.
- Any order made under this Act shall have effect notwithstanding anything inconsistent therewith
contained in any enactment other than this Act or any instrument having effect by virtue of any
enactment other than this Act.Assam Town and Country Planning Act, 1959

Chapter XI
Miscellaneous Provisions
65. Service of notice.
- Every notice issued under this Act shall be served as prescribed by rules.
66. Method of giving public notice.
- Subject to the provision of this Act, every public notice required under this Act shall be deemed to
have been given if it is published in some local newspaper (if any) or a paper of general circulation in
the area and posted upon a notice board to be exhibited for public information at the building in
which the meetings of the Local Authority are ordinarily held or by publishing it in official Gazette.
67. Formal defects in assessments and demands.
- No assessment list or other list, notice or other such document specifying, or purporting to specify
with reference to any charge, or fee, any person's property, thing or circumstances shall be invalid
only by reason of a clerical or technical mistake in the name, residence, place of business or
occupation of the person or in the description of property, thing or circumstances and it shall be
sufficient if the person, property, thing or circumstances is described sufficiently for the purpose of
identification, and it shall not be necessary to name the owner or occupier of any property liable in
respect of the charge.
68. Power and duties of police in respect of offences and assistance to
Authorities.
- Every police officer, mauzadar or officer of the Local Authority shall give immediate information to
the Authority or an offence to his knowledge which has been committed under this Act, or against
any rule, made under this Act and shall be bound to assist all members, officers and servants of the
Authority in the exercise of their lawful authority.
69. Decision of disputes between Authorities.
- Should dispute arise between the Authority and any other Local Authority on any matter in which
they are jointly interested, such dispute shall be referred to the State Government, whose decision
shall be final.
70. Powers to enter into land for inspection, etc.
- For the purpose of making or execution of any scheme, the Authority or persons appointed by the
State Government, their subordinates and contractors may enter into or upon any land in orderAssam Town and Country Planning Act, 1959

-(a)to make any inspection, survey, measure valuation or enquiry;(b)to take levels;(c)to dig or bore
into the sub-soil;(d)to set out boundaries and intended lines of works;(e)to mark levels, boundaries
and lines by marks and cutting trenches; or(f)to do any other thing, whenever it is necessary to do
so, for any of the purposes of this Act or any rule made or scheme sanctioned hereunder or any
scheme which the authority intends to frame hereunder :Provided as follows :-(a)except when it is
otherwise specially provided by a rule no such entry shall be made between sunset and
sunrise;(b)except when it is otherwise specially provided by the rules, no building which is used as a
human dwelling shall be so entered unless with the consent of the occupier thereof; without giving,
the said occupier at least 24 hours previous notice in writing of the intention to make such
entry;(c)due regard shall always be had, so far as may be compatible with the exigencies of the
purpose for which the entry is made, to the social and religious usages of the occupants of the
premises entered.
71. Mode of proof of the records of the Authority.
- A copy of receipt, application, plan, notice, order, entry in a register, or other document in the
possession of the Authority shall, if duly certified by then lawful keeper thereof or other person
authorised by the Authority in this behalf be received as prima facie evidence of the entry or
document and shall be admitted as evidence of the matters and transactions therein recorded in
every case where, and to the same extent as, the original entry or document would, if produced, have
been admissible to prove such matters.
72. Power of Authority to make agreements.
- The Authority shall be competent to make any agreement with any person in respect of any
matters, which is to be provided therein, such agreement shall take effect on and after the day on
which the scheme comes into force.
73. Powers of the State Government to make rules.
(1)The State Government may, after previous publication in the Official Gazette, make rules for
carrying out the purposes of this Act.(2)In particular and without prejudice to the generality of the
foregoing powers, the State Government [......] shall have power to make rules in respect of the
following matters(i)The manner of publication of the notification regarding scheme, their
modifications, variations, revocations, submission and sanction by the State government.(ii)Powers
that may be delegated to any Authority established under this Act or to any officer.(iii)Procedure to
be adopted for securing co¬operation of various Government Departments, the owners or other
persons or bodies interested in schemes.(iv)All matters pertaining to land acquisition including
procedure and making of award, compensation and the possession of land by Authority in ordinary
and emergent cases.(v)Calculation, assessment and payment of compensation in respect of property
which is injuriously affected within the meaning assigned to it in section 37 of this
Act.(vi)Calculation, assessment and collection of betterment contribution.(vii)Procedure of filling,
hearing and deciding objections and appeals under the Act and all matters connected
therewith.(viii)The delegation of powers to and the duties that shall be discharged by the DirectorAssam Town and Country Planning Act, 1959

and the matters on which and the manner in which he shall be consulted.(ix)Matters other than
those referred to in foregoing clauses which are expressly or by implication requires or allowed by
this Act to be prescribed by rules.(x)Creation and administration of fund for the purpose of
implementing the provisions of this Act.(3)All rules made under this section shall be laid for not less
than fourteen days before the Assam Legislative Assembly as soon as possible, after they are made
and shall be subject to such modification as the Legislative Assembly may make during the session
in which they are so laid or the session immediately following.
74. Power of the Authority to make bye-laws.
(1)The Authority shall have power to make bye-laws in respect of the matters enumerated under this
section and not inconsistent with the rules made by the State Government-(i)[ zoning regulations
prescribing the type or description of building which may or may not be, and the purpose for which
a building may or may not be created, in any prescribed area or areas, [Clauses (i), (ii) and (iii)
deleted and the remaining clauses (iv), (v), (vi) and (vii) are renumbered as (i), (ii), (iii), and (iv) by
section 4 of Assam Act No. 17 of 2012.](ii)regulation and display of advertisement in the interest of
amenity, aesthetic, or public safety.(iii)regulations in any manner not specifically provided for in
this Act, the erection of any enclosure, wall, fence, tent or other structure on any land within the
limits of the authority.(iv)time and place and transaction of business of the meetings of the
Authority.](2)The power to make bye-law under this Act shall be subject to the conditions of
previous publication.(3)No such bye-law shall come into force until it is approved by the State
Government.(4)The State Government may cancel their confirmation of any such bye-law and
thereupon the bye-law shall cease to have effect.Assam Town and Country Planning Act, 1959

