A.Velankanni vs The Secretary To The Government Of Tamil ...
on 26 September, 2023
Author: M.Sundar
Bench: M.Sundar
    2023:MHC:4484
                                                                                H.C.P.No.1166 of 2023
                                      IN THE HIGH COURT OF JUDICATURE AT MADRAS
                                                    DATED : 26.09.2023
                                                          CORAM
                                        THE HONOURABLE MR.JUSTICE M.SUNDAR
                                                       and
                                       THE HONOURABLE MR.JUSTICE R.SAKTHIVEL
                                                 H.C.P.No.1166 of 2023
                     A.Velankanni                                                   .. Petitioner
                                                            Vs
                     1.The Secretary to the Government of Tamil Nadu,
                       Home, Prohibition and Excise Department,
                       Secretariat, Chennai – 9.
                     2.The Commissioner of Police,
                       Tambaram City (Goondas Section),
                       Sholinganallur, Chennai.
                     3.The Superintendent of Prison,
                       O/o.Central Prison, Puzhal, Chennai.
                     4.The Inspector of Police,
                       O/o. The Inspector of Police,
                       T-18, Thazhambur Police Station,
                       Chennai.                                                  .. Respondents
                                  Petition filed under Article 226 of the Constitution of India
                     praying for issuance of a writ of habeas corpus to call for the records
                     in Memo No.BCDFGISSSV 16/2023 on the file of the second
                     respondent, quash the detention order dated 24.04.2023 and direct
                     the respondents           to produce detenu A.Balaji, son of Arumugam,A.Velankanni vs The Secretary To The Government Of Tamil ... on 26 September, 2023

                     detained at Central Prison, Puzhal, under the Tamil Nadu Act 14 of
                     Page Nos.1/8
https://www.mhc.tn.gov.in/judis
                                                                                       H.C.P.No.1166 of 2023
                     1982 before this Court and set him at liberty.
                                  For Petitioner           :     Mr.P.K.Ganesh
                                  For Respondents          :     Mr.E.Raj Thilak
                                                                 Additional Public Prosecutor
                                                                 assisted by Mr.C.Aravind
                                                           ORDER
[Order of the Court was made by M.SUNDAR, J.,] This order will now dispose of captioned 'Habeas
Corpus Petition' ['HCP' for the sake of brevity, convenience and clarity].
2. When the captioned HCP was listed for Admission on 06.07.2023, the following
proceedings/order was made:
M.SUNDAR, J.
and R.SAKTHIVEL, J.
(Order of the Court was made by M.SUNDAR, J.,) Captioned Habeas Corpus Petition
has been filed in this Court on 21.06.2023 inter alia assailing a 'detention order dated
24.04.2023 bearing reference BCDFGISSSV No.16/2023' (hereinafter 'impugned
preventive detention order' for the sake of convenience and clarity) made by 'second
respondent' [hereinafter 'Detaining Authority' for the sake of convenience and
clarity]. To be noted, fourth respondent is the Sponsoring
https://www.mhc.tn.gov.in/judis Authority.
2. To be noted, mother of the detenu is the petitioner.
3. Mr.P.K.Ganesh, learned counsel on record for habeas corpus petitioner is before
us. Learned counsel for petitioner submits that ground case qua the detenu is for
alleged offences under Sections 294(b), 341, 384, 392, 397 and 506(ii) of 'The Indian
Penal Code (45 of 1860)' [hereinafter 'IPC' for the sake of convenience and clarity] in
Crime No.76 of 2023 on the file of T18 Thazhambur Police Station.
4. The aforementioned impugned preventive detention order has been made on the
premise that the detenu is a 'Goonda' under Section 2(f) of 'The Tamil NaduA.Velankanni vs The Secretary To The Government Of Tamil ... on 26 September, 2023

Prevention of Dangerous Activities of Bootleggers, Cyber law offenders, Drug-
offenders, Forest-offenders, Goondas, Immoral traffic offenders, Sand-offenders, Sexual-offenders,
Slum-grabbers and Video Pirates Act, 1982 (Tamil Nadu Act No.14 of 1982)' [hereinafter 'Act 14 of
1982' for the sake of convenience and clarity].
5. The impugned preventive detention order has been assailed inter alia on the ground that the
similar case relied on by the Detaining Authority to arrive at subjective satisfaction qua imminent
possibility of detenu being enlarged on bail, is not really similar.
6. Prima facie case made out for admission. Admit. Issue Rule Nisi returnable by four weeks.
7. Mr.E.Raj Thilak, learned Additional Public Prosecutor, State of Tamil Nadu accepts notice for all
respondents. List the captioned Habeas Corpus Petition accordingly.'
3. The aforementioned proceedings/order dated 06.07.2023 captures all essentials i.e., essential
facts imperative for appreciating this final order and therefore we are not setting out the facts again.
Suffice to say that the aforementioned Admission Board order dated 06.07.2023 shall now be read
as an integral part and parcel of the https://www.mhc.tn.gov.in/judis instant final order. This also
means that the short forms, short references and abbreviations used in the aforementioned
Admission Board order will continue to be used in the instant final order also.
4. Mr.P.K.Ganesh, learned counsel on record for petitioner and Mr.E.Raj Thilak, learned State
Additional Public Prosecutor assisted by Mr.C.Aravind, learned counsel for all the respondents are
before us.
5. As would be evident from paragraph 5 of the Admission Board order at the time of admission, the
point that the similar case relied on by the detaining authority to arrive at subjective satisfaction is
not really similar was raised but today in the final hearing, Mr.P.K.Ganesh, learned counsel on
record for petitioner changed his line of attack against the impugned preventive detention order and
submitted that the similar case bail order has not been furnished to the detenu. Learned counsel for
petitioner drew our attention to a portion of paragraph 5 of the grounds of impugned preventive
detention order which reads as follows:
'5..... However, it is pertinent to note that in a similar case registered at T-1
Tambaram P.S. Cr.No.1/2021 u/s. 147, 148, 341, 294(b), 336, 307,
https://www.mhc.tn.gov.in/judis 506(ii) IPC, bail was granted to the accused
Nishanth, Kishore Kumar @ Kishore and Maniyarasu @ Manda Vishnu by the
Hon'ble Principal Sessions Judge of Kancheepuram District at Chengalpattu in
Crl.M.P.No.258/2021 on 05.02.2021. In the ground case also, no bail application has
been filed in his behalf.....'
6. The aforementioned similar case bail order relied on by the detaining authority has not been
furnished in the grounds booklet served on the detenu. In the Index of the grounds booklet at Sl.A.Velankanni vs The Secretary To The Government Of Tamil ... on 26 September, 2023

No.27 the description for pages 139 to 175 is 'Tambaram Police Station Crime No.01/2021' but pages
139 to 175 are missing in the grounds booklet. We had the benefit of perusing the grounds booklet.
We are convinced that it is a clear case of infraction of Article 22(5) of the Constitution of India as
the detenu's right to make an effective representation qua impugned preventive detention order has
been impaired.
7. As the matter turns heavily on records, learned Prosecutor really does not have much of a say.
https://www.mhc.tn.gov.in/judis
8. We have no hesitation in persuading ourselves to say that detenu's sacrosanct constitutional right
to make an effective representation against the impugned preventive detention order has been
impaired owing to non-furnishing of aforementioned similar case bail order relied on by the
detaining authority. This means that there is infraction of constitutional safeguard ingrained in
Article 22 (5) of the Constitution of India leading to the inevitable sequitur that impugned
preventive detention order deserves to be dislodged.
9. Ergo, the sequitur is, captioned HCP is allowed. Impugned preventive detention order dated
24.04.2023 bearing reference BCDFGISSSV No.16/2023 made by the second respondent is set aside
and the detenu Thiru.A.Balaji, aged 21 years, Son of Thiru.Arumugam, is directed to be set at liberty
forthwith, if not required in connection with any other case / cases. There shall be no order as to
costs.
                                                                         (M.S.,J.)        (R.S.V.,J.)
                                                                                26.09.2023
                     Index : Yes/No
                     Neutral Citation : Yes/No
                     mmi
P.S: Registry to forthwith communicate this order to Jail authorities in Central Prison, Puzhal,
Chennai - 66. https://www.mhc.tn.gov.in/judis To
1.The Secretary to the Government, Home, Prohibition and Excise Department, Secretariat, Chennai
– 9.
2.The Commissioner of Police, Tambaram City (Goondas Section), Sholinganallur, Chennai.
3.The Superintendent of Prison, O/o.Central Prison, Puzhal, Chennai.
4.The Inspector of Police, O/o. The Inspector of Police, T-18, Thazhambur Police Station, Chennai.
5.The Public Prosecutor, High Court, Madras.A.Velankanni vs The Secretary To The Government Of Tamil ... on 26 September, 2023

https://www.mhc.tn.gov.in/judis M.SUNDAR, J., and R.SAKTHIVEL, J., mmi 26.09.2023
https://www.mhc.tn.gov.in/judisA.Velankanni vs The Secretary To The Government Of Tamil ... on 26 September, 2023

