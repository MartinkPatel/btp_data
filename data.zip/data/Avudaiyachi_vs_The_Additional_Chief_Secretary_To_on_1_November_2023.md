Avudaiyachi vs The Additional Chief Secretary To ... on 1
November, 2023
Author: M.Sundar
Bench: M.Sundar
                                                                        H.C.P.(MD)No.1006 of 2023
                         BEFORE THE MADURAI BENCH OF MADRAS HIGH COURT
                                               DATED: 01.11.2023
                                                    CORAM:
                                   THE HONOURABLE MR.JUSTICE M.SUNDAR
                                                       and
                                  THE HONOURABLE MR.JUSTICE R.SAKTHIVEL
                                            H.C.P.(MD)No.1006 of 2023
                 Avudaiyachi                                                  : Petitioner
                                                     Vs.
                 1.The Additional Chief Secretary to Government,
                    Home, Prohibition and Excise Department,
                    For St. George,
                    Chennai.
                 2.The Commissioner of Police,
                    O/o. The Commissioner of Police,
                    Tirunelveli City.
                 3.The Superintendent of Prison,
                    Central Prison,
                    Palayamkottai,
                    Tirunelveli District.
                 4.The Inspector of Police,
                    Melapalayam Police Station,
                    Tirunelveli City.                                     : Respondents
                 PRAYER: Habeas Corpus Petition is filed under Article 226 of the
                 Constitution of India, calling for the entire records connected with the
https://www.mhc.tn.gov.in/judis
                 1/17
                                                                             H.C.P.(MD)No.1006 of 2023Avudaiyachi vs The Additional Chief Secretary To ... on 1 November, 2023

                 detention order in No.26/BCDFGISSSV/2023 dated 04.05.2023 on the file
                 of the second respondent and quash the same as illegal and direct the
                 respondents to produce the body or person of the petitioner's son namely
                 Anbu @ Anbukumar S/o. Muthaiah aged about 24 years now confined at
                 Central Prison, Palayankottai, Tirunelveli before this Court and set him at
                 liberty forthwith.
                                  For Petitioner   : Mr.S.M.A.Jinnah
                                  For Respondents : Mr.A.Thiruvadi Kumar
                                                    Additional Public Prosecutor
                                                       ORDER
*********** [Order of the Court was made by M.SUNDAR, J.] Captioned 'Habeas Corpus Petition'
['HCP' for the sake of brevity] was listed in the admission board on 11.08.2023 before a Hon'ble
Predecessor Coordinate Division Bench and the following order was made in the admission board:
https://www.mhc.tn.gov.in/judis
2.Therefore, this Court deems it appropriate to set out factual matrix in a nut shell. To be noted,
captioned HCP is now in the final hearing board, Mr.S.M.A.Jinnah, learned counsel on record for
petitioner and Mr.A.Thiruvadi Kumar, learned State Additional Public Prosecutor for all
respondents are before us.
3.Factual matrix in a nut shell is that HCP petitioner's son one Thiru.Anbu alias Anbukumar has
been detained vide a Preventive Detention Order dated 04.05.2023 bearing reference
No.26/BCDFGISSSV/2023 made by the second respondent [to be noted, this '04.05.2023
preventive detention order' shall be referred to as 'impugned preventive detention order' and the
'second respondent' shall be referred to as 'detaining authority', both for the sake of convenience
and clarity]; that impugned preventive detention order has been made under 'The Tamil Nadu
Prevention of Dangerous Activities of Bootleggers, Cyber law offenders, Drug-offenders,
Forest-offenders, Goondas, Immoral traffic offenders, Sand-offenders, Sexual-offenders,
Slum-grabbers and Video Pirates Act, 1982 (Tamil Nadu Act No.14 of 1982)' [hereinafter 'Act 14 of
1982' for the sake of brevity, convenience and clarity] branding the HCP petitioner's son ['HCP
petitioner's son' shall hereinafter be referred to as 'detenu' for the sake of convenience] as a 'Goonda'
within the meaning of Section 2(f) of Act 14 of 1982; that captioned HCP has been filed in this Court
on https://www.mhc.tn.gov.in/judis 07.08.2023 and admitted on 11.08.2023 vide aforementioned
admission board order [scanned and reproduced supra]; that captioned HCP is now in the final
hearing board as already alluded to supra.Avudaiyachi vs The Additional Chief Secretary To ... on 1 November, 2023

4.Mr.S.M.A.Jinnah, learned Counsel for HCP petitioner in his campaign against the impugned
preventive detention order submitted that the impugned preventive detention order has been made
on the basis of a solitary case. It was pointed out that the solitary case is Crime No.196/2023 on the
file of Melapalayam Police Station for alleged offences under Sections 341, 294(b), 324, 307, 506(ii)
of 'The Indian Penal Code (45 of 1860)' [hereinafter 'IPC' for the sake of convenience and clarity]
and Sections 3(1)(r), 3(1)(s), 3(2)(v) of 'the Scheduled Castes and the Scheduled Tribes (Prevention
of Atrocities) Act, 1989 (Act No.33 of 1989)' [hereinafter 'SC & ST (PoA) Act' for the sake of brevity
and convenience] altered into Sections 341, 294(b), 324, 307, 506(ii), 120(B), 212 of IPC and
Sections 3(1)(r), 3(1)(s) and 3(2)(v) of SC & ST (PoA) Act. It was submitted that as regards the
ground case, the same is now pending vide S.C.No.116/2023 on the file II Additional District Judge's
Court (Special Court for SC & ST cases), Tirunelveli, which means the regular law and order
mechanism has been set into motion and is operating. In this scenario learned Counsel submitted
that there is nothing to demonstrate that the detenu has acted in any manner prejudicial to
maintenance of public order. https://www.mhc.tn.gov.in/judis
5.In response to the aforementioned argument, learned State Prosecutor drew our attention to a
portion of paragraph No.2(i) of the impugned preventive detention order where the detaining
authority adverting to the solitary ground case has said “On seeing this incident those who were in
the temple ran outside with hue and cry out of fear”. This would demonstrate that detenue acted in a
manner prejudicial to maintenance of public order is learned Prosecutor's say.
6.This Court carefully considered the rival submissions.
7.As regards 'law and order' and 'public order' the Ram Manohar Lohia's case the locus classicus.
This celebrated judgment ie., Ram Manohar Lohia's case reported in AIR 1966 SC 740 [Ram
Manohar Lohia Vs. State of Bihar and another] is one where Hon'ble Supreme Court propounded
three concentric circles doctrine. Ram Manohar Lohia's case has stood the test of time, it continues
to be good law and to be noted, it has been followed in Mallada K Sri Ram Vs. The State of
Telengana in Crl.A.No.561 of 2022 dated 04.04.2022.
8.Three concentric circles doctrine propounded by Hon'ble supreme Court in Ram Manohar Lohia's
case has been elucidated by adopting a illustrative approach. The relevant paragraphs have been
extracted reproduced elsewhere in this order (as part of extract from Panjalai's
https://www.mhc.tn.gov.in/judis case). Be that as it may, this Ram Manohar Lohia principle is
instructive and we respectfully follow the same. When we apply the three concentric circles doctrine
and illustration of the Hon'ble Supreme Court to the case on hand we find that the matter has not
moved from the first larger concentric circle of 'law and order' to the next concentric circle of 'public
order' as there is nothing to demonstrate that the detenu has engaged or is making preparations for
engaging in any activities as a 'Goonda' which will adversely affect or is likely to affect adversely the
maintenance of public order. The reason is, as already alluded to the impugned preventive detention
order has been clamped by resorting to Act 14 of 1982 in which the term 'Goonda' has been defined
vide Section 2(f) and the expression 'acting in a manner prejudicial to the maintenance of public
order' has been defined vide 2(a) {2(a)(iii) is qua Goonda}, which read as follows:Avudaiyachi vs The Additional Chief Secretary To ... on 1 November, 2023

'Section 2. Definitions. - ...
2(f) “goonda” means a person, who either by himself or as a member of or leader of a
gang, commits, or attempts to commit or abets the commission of offence punishable
under Section 153 or Section 153-A under Chapter VIII or under Chapter XVI other
than Sections 354, 376, 376-A, 376-B, 376-0C, 376-D and 377 or Chapter XVII or
Chapter XXII of the Indian Penal Code, 1860 (Central Act 45 of 1860) or punishable
under Section 3 or Section 4 or Section 5 of the Tamil Nadu Property (Prevention of
Damage and Loss) Act, 1992 (Tamil Nadu Act 59 of 1992);
https://www.mhc.tn.gov.in/judis 2(a) “acting in any manner prejudicial to the maintenance of
public order” means:
2(a)(i). ...
2(a)(ii). ...
2(a)(iii) in the case of a goonda, when he is engaged, or is making preparations for
engaging, in any of his activities as a goonda, which affect adversely, or are likely to
affect adversely, the maintenance of public order;'
9.We are acutely conscious of the obtaining position that a preventive detention order can be
clamped on the basis of a solitary case but that it is clamped on the basis of a solitary case is not the
point. There is no material to demonstrate that the detenu has acted in a manner prejudicial to the
maintenance of public order is the point that enures to the benefit of detenu in the case on hand.
The further reason is, other than the lone sentence in paragraph No.2(i) of impugned preventive
detention order (pointed out by learned Prosecutor) which says that on the date of occurrence ie.,
14.04.2023 at the time of the incident, people who were in the temple ran outside with hue and cry
out of fear, there is no other material to demonstrate that detenu has acted in a manner prejudicial
to maintenance of public order much less within the meaning of Section 2(f) read with 2(a)(iii) of
Act 14 of 1982.
https://www.mhc.tn.gov.in/judis
10.As regards the Habeas Corpus legal drill the law is well settled that in a habeas legal drill a habeas
Court will address itself to the question as to whether the regular law and order machinery /
mechanism is good enough for taking care of the scenario or if it is imperative to resort to preventive
detention to contain the situation. If the answer is to the effect that regular law and order
mechanism / machinery is good enough, the habeas legal drill will gravitate towards dislodging the
preventive detention order. In this case, as already alluded to, the solitary ground case is now
S.C.No.116/2023 on the file II Additional District Judge's Court (Special Court for SC & ST cases),
Tirunelveli and there is nothing to demonstrate that this case is not good enough.Avudaiyachi vs The Additional Chief Secretary To ... on 1 November, 2023

11.Learned Prosecutor, on instructions [instructed by Mr.J.Suresh Kumar, Special Sub-Inspector,
Melapalayam Police Station] submits that in the trial Court charge sheet has been filed on
27.06.2023, within the mandatory prescribed period. If this be the position, the detenu will have to
only seek regular bail under Section 439 of 'the Criminal Procedure Code, 1973' [hereinafter 'Cr.P.C'
for the sake of brevity]. This also means that the position that regular law and order mechanism /
machinery is good enough to contain the situation stands buttressed. To be noted, the detenu
remains incarcerated and the detenu will be able to come out only if enlarged on bail by trial Court
in a regular bail plea which will be decided on its own merits and in accordance with law by the trial
Court untrammeled by this https://www.mhc.tn.gov.in/judis order which has been made for the
limited purpose of testing the impugned preventive detention order in habeas legal drill on hand.
This by itself buttresses the argument that the matter has not even gravitated towards the next
smaller concentric circle of Public Order and it continues to perambulate in the larger concentric
circle of Law and Order.
12.In Panjalai's case ie., order dated 20.06.2023 in HCP No.23 of 2023, this bench sitting in the
Principal Seat has set out the well settled principles in habeas jurisprudence including public order
point. Paragraph Nos.1, 9 to 12 are relevant and the same read as follows:
'The case on hand is a classic case for reminding ourselves about some of the well
settled principles in Habeas Corpus jurisprudence and they are :
(a) Preventive detention is not a punishment;
(b) Habeas Corpus is a high prerogative;
(c)The question which a Habeas Corpus Court will address itself to is whether normal
law and order mechanism is good enough to contain the situation; and if the answer
is in the affirmative preventive detention has to be interfered with;
(d)Whether public order is likely to be affected or has been affected is an adjunct
question qua aforementioned question (previous point);
......
9.In this regard, this Bench deems it appropriate to remind itself of the law laid down by Hon-ble
Supreme Court in the celebrated Ram Manohar Lohia case law [Ram Manohar Lohia
https://www.mhc.tn.gov.in/judis vs. State of Bihar and another reported in AIR 1966 SC 740].
Relevant paragraphs are paragraphs 51 and 52 which read as follows:
'51.We have here a case of detention under Rule 30 of the Defence of India Rules
which permits apprehension and detention of a person likely to act in a manner
prejudicial to the maintenance of public order. It follows that if such a person is not
detained public disorder is the apprehended result. Disorder is no doubt prevented
by the maintenance of law and order also but disorder is a broad spectrum whichAvudaiyachi vs The Additional Chief Secretary To ... on 1 November, 2023

includes at one end small disturbances and at the other the most serious and
cataclysmic happenings.
Does the expression “public order“ take in every kind of disorder or only some ? The answer to this
serves to distinguish “public order“ from “law and order“ because the latter undoubtedly takes in all
of them. Public order if disturbed, must lead to public disorder. Every breach of the peace does not
lead to public disorder. When two drunkards quarrel and fight there is disorder but not public
disorder, They can be dealt with under the powers to maintain law and order but cannot be detained
on the ground that they were disturbing public order. Suppose that the two fighters were of rival
communities and one of them tried to raise communal passions. The problem is still one of law and
order but it raises the apprehension of public disorder. Other example can be imagined. The
contravention of law always affects order but before it can be said to affect public order, it must
affect the community or the public at large. A mere disturbance https://www.mhc.tn.gov.in/judis of
law and order leading to disorder is thus not necessarily sufficient for action under the Defence of
India Act but disturbances which subvert the public order are. A District Magistrate is entitled to
take action under Rule 30(l)(b) to prevent subversion of public order but not in aid of maintenance
of law and order under ordinary circumstances.
52.It will thus appear that just as “public order“ in the rulings of this Court (earlier cited) was said to
comprehend disorders of less gravity than those affecting “security of State“, “law and order“ also
comprehends disorders of less gravity than those affecting “public order“. One has to imagine three
concentric circles. Law and order represents the largest circle within which is the next circle
representing public order and the smallest circle represents security of State. It is then easy to see
that an act may affect law and order but not public order just as an act may affect public order but
not security of the State. By using the expression “maintenance of law and order“ the District
Magistrate was widening his own field of action and was adding a clause to the Defence of India
Rules.'
10.The aforementioned two paragraphs in the celebrated Ram Manohar Lohia case law makes it
clear that Hon-ble Supreme Court has laid down three concentric circles doctrine and the three
concentric circles doctrine turns on law and order, public order and State security. By taking an
illustrative approach, Hon-ble Supreme Court elucidated the clear and certain distinction between
Law and Order & Public Order and as https://www.mhc.tn.gov.in/judis to when a particular matter
would move from Law and Order larger circle to the public order smaller concentric circle.
11.Be that as it may, before proceeding further, we deem it appropriate to say that the
aforementioned celebrated Ram Manohar Lohia judgment rendered half a century ago has stood the
test of time as the same has been followed as recently on 04.04.2022 in an order made in
Crl.A.No.561 of 2022 [Mallada K Sri Ram vs. The State of Telengana and others] authored by Hon-
ble Justice Dr.Dhananjaya Y Chandrachud. Relevant paragraph is paragraph 12 and the same reads
as follows:
'12.The distinction between a disturbance to law and order and a disturbance to
public order has been clearly settled by a Constitution Bench in Ram Manohar LohiaAvudaiyachi vs The Additional Chief Secretary To ... on 1 November, 2023

v. State of Bihar, AIR 1966 SC 740. The Court has held that every disorder does not
meet the threshold of a disturbance to public order, unless it affects the community at
large. The Constitution Bench held:
'51. We have here a case of detention under Rule 30 of the Defence of India Rules
which permits apprehension and detention of a person likely to act in a manner
prejudicial to the maintenance of public order. It follows that if such a person is not
detained public disorder is the apprehended result. Disorder is no doubt prevented
by the maintenance of law and order also but disorder is a broad spectrum which
includes at one end small disturbances and at the other the most serious and
cataclysmic happenings. Does the expression ?public order? take in every kind of
disorders or only some of them? The answer to this https://www.mhc.tn.gov.in/judis
serves to distinguish ?public order? from ?law and order? because the latter
undoubtedly takes in all of them. Public order if disturbed, must lead to public
disorder. Every breach of the peace does not lead to public disorder. When two
drunkards quarrel and fight there is disorder but not public disorder. They can be
dealt with under the powers to maintain law and order but cannot be detained on the
ground that they were disturbing public order. Suppose that the two fighters were of
rival communities and one of them tried to raise communal passions. The problem is
still one of law and order but it raises the apprehension of public disorder. Other
examples can be imagined. The contravention of law always affects order but before if
can be said to affect public order, it must affect the community or the public at large.
A mere disturbance of law and order leading to disorder is thus not necessarily
sufficient for action under the Defence of India Act but disturbances which subvert
the 7 public order are. A District Magistrate is entitled to take action under Rule
30(1)(b) to prevent subversion of public order but not in aid of maintenance of law
and order under ordinary circumstances.
52. It will thus appear that just as ?public order? in the rulings of this Court (earlier
cited) was said to comprehend disorders of less gravity than those affecting ?security
of State?, ?law and order? also comprehends disorders of less gravity than those
affecting ?public order?. One has to https://www.mhc.tn.gov.in/judis imagine three
concentric circles. Law and order represents the largest circle within which is the next
circle representing public order and the smallest circle represents security of State. It
is then easy to see that an act may affect law and order but not public order just as an
act may affect public order but not security of the State. By using the expression
?maintenance of law and order? the District Magistrate was widening his own field of
action and was adding a clause to the Defence of India Rules.- (emphasis supplied)'
12.Reverting to Ram Manohar Lohia principle and the three concentric circles
doctrine we find that it is a locus classicus in Habeas jurisprudence of matrimonial
discord and an aggression on the part of one spouse as against the other has resulted
in the unfortunate death of the victim. We are informed that the victim-s brother is
the defacto complainant.'Avudaiyachi vs The Additional Chief Secretary To ... on 1 November, 2023

13.The principle that liberty is the very quintessence of a civilised society and it can
be described as a grundnorm of a refined civilization has also been reiterated in
Panjalai's case. We are informed that Panjalai's case has attained finality.
14.There is another facet of Panjalai's case qua case on board. As would be evident
from the extract supra relevant paragraphs of Ram Manojar Lohia's case law dealing
with three concentric circles doctrine and the illustrative elucidation have been
extracted and set out therein.
https://www.mhc.tn.gov.in/judis
15.In the light of the narrative thus far, the inevitable sequitur is, captioned HCP and the impugned
preventive detention order are not matters which qualify as a case in which the detenu has acted in a
manner prejudicial to maintenance of public order within the meaning of Section 2(a)(iii) r/w.
Section 2(f) of Act 14 of 1982. The further sequitur is impugned preventive detention order becomes
vitiated and vulnerable for being dislodged in this habeas legal drill.
16.Ergo, the sum sequitur is, captioned HCP is allowed. Impugned preventive detention order dated
04.05.2023 bearing reference No.26/BCDFGISSSV/2023 made by the second respondent is set
aside and the detenu Thiru.Anbu alias Anbukumar, male, aged 24 years, son of Thiru.Muthaiah, is
directed to be set at liberty forthwith, if not required in connection with any other case / cases.
There shall be no order as to costs.
                                                               [M.S.,J.]   &     [R.S.V.,J.]
                                                                      01.11.2023
                 Index            : Yes
                 Internet         : Yes
                 Neutral Citation : Yes
                 MR
P.S: Registry to forthwith communicate this order to jail authorities in Central Prison,
Palayamkottai.
https://www.mhc.tn.gov.in/judis To
1.The Additional Chief Secretary to Government, Home, Prohibition and Excise Department, For St.
George, Chennai.
2.The Commissioner of Police, O/o. The Commissioner of Police, Tirunelveli City.
3.The Superintendent of Prison, Central Prison, Palayamkottai, Tirunelveli District.
4.The Inspector of Police, Melapalayam Police Station, Tirunelveli City.Avudaiyachi vs The Additional Chief Secretary To ... on 1 November, 2023

5.The Additional Public Prosecutor, Madurai Bench of Madras High Court, Madurai.
https://www.mhc.tn.gov.in/judis M.SUNDAR, J.
and R.SAKTHIVEL, J.
MR 01.11.2023 https://www.mhc.tn.gov.in/judisAvudaiyachi vs The Additional Chief Secretary To ... on 1 November, 2023

