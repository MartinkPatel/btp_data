Arvind Mohan Johari & Anr vs State Of U.P. & Anr on 3
November, 2004
Equivalent citations: AIRONLINE 2004 SC 618
Bench: N. Santosh Hegde, S.B. Sinha
           CASE NO.:
Appeal (crl.)  1265-66 of 2004
PETITIONER:
Arvind Mohan Johari & Anr.
RESPONDENT:
State of U.P. & Anr.
DATE OF JUDGMENT: 03/11/2004
BENCH:
N. Santosh Hegde & S.B. Sinha
JUDGMENT:
J U D G M E N T O R D E R (Arising out of SLP (Crl.) No.2057-2058 of 2004) Leave granted.
The Appellants who are two in number allegedly committed various offences of cheating, forgery,
etc. in respect whereof two First Information Reports were lodged being FIR No. R.C. No. 8(S)/2001
to R.C. No. 12(S) of 2001/CBI, Lucknow dated 6-7-2001 and R.C. No. 15(S)/2001 to R.C. No.
18(S)/2001/CBI, Lucknow dated 6.7.2001.
The Appellants floated various groups of companies, viz., M/s. Country Inform Tech. Pvt. Ltd., M/s
Kamal Infosys Ltd, M/s. Triputi Financial Services and M/s. Century Consultant Ltd.. Allegedly,
once Shri G.N. Srivastava, Secretary, City Cooperative Bank Ltd. in criminal conspiracy with the
appellants herein unauthorisedly and fraudulently permitted purchase of nine cheques of
aforementioned two groups, viz., Country Inform. Tech. and Kamal Infosys worth of Rs.
1,71,35,000/-. These cheques are said to have been signed by Shri A.K. Johri. Shri Johri allegedly,
furthermore, in conspiracy with Shri G.N. Srivastava got prepared a demand draft for Rs. 45.00 lacs
from Bombay Mercantile Bank out of the cheques purchased proceeds of Rs. 71,35,000/- on his oral
instruction. He also allegedly transferred Rs. 99.00 lacks from the account of Country Inform. Tech.
Services at State Bank of Hyderabad, Lucknow and remitted it to Century Consultant Ltd., Mumbai
although he was neither Director nor Authorised Signatory in respect thereof. The Appellants herein
are said to have got transferred Rs. 1.45 crores out of cheques purchased proceeds of Rs.
1,71,35,000/- to Mumbai and got a pay order prepared for Rs. 99,90,000/- in favour of Century
Consultant.Arvind Mohan Johari & Anr vs State Of U.P. & Anr on 3 November, 2004

The other case being Criminal Case No. 51 of 2001 relates to M/s. Century Consultants Ltd. in which
the Appellants are Directors. They allegedly with Shri A.K. Shah and Pradeep Narain started a
scheme known as 'Byaz Badla' in terms whereof they were supposed to deposit the amount received
from investors with the Bombay Stock Exchange but did not do it.
By reason of the alleged action on the part of the Appellants and other accused persons, allegedly a
large number of depositors who deposited the amount in 'Byaz Badla' Scheme as also the depositors
in City Cooperative Bank Ltd. were invested therein suffered a huge loss.
A petition for winding up of the Century Consultants Ltd. was filed. The said Company was directed
to be wound up by the learned Company Judge.
The Appellants applied for and were granted a short-term bail by an order dated 25.6.2003 on
certain conditions including that they would make payments to the investors who are parties to the
compromise with the Directors of Century Consultants in the pending Company Petition by
releasing first instalment of 20% amount within two months as first instalment and the second
instalment of 20% in the next two months. The Appellants were enlarged on bail for six months on
the following conditions:
"(i) Accused applicants shall furnish two sureties and a personal bond of the amount
of Rs. 1 lac each to the satisfaction of the Special Judicial Magistrate, CBI for a period
of six months.
(ii) Both the accused will file an undertaking on affidavit that they will not leave the
jurisdiction of the court without the permission of the court during trial.
(iii) They will not seek any adjournment during trial on the ground of their ailment or
otherwise and they will always either appear personally or they will be represented
through their counsel on the date fixed in the trial court.
(iv) Both the accused will not leave the country without permission of the CBI for
which they will furnish an undertaking on affidavit.
(v) They will surrender their passport and visa, if any, which shall remain in the
custody of the CBI. In case the accused do not have any passport and visa, they will
make it clear in their affidavits.
(vi) According to the own statement of the accused, they have assets more than fifty
crores of rupees, therefore they will honour the proposed compromise with the
depositors and irrespective of the order in the company petition, they will release first
instalment of 20% amount within two months by which they will give undertaking on
affidavit that they will comply with this condition by 25.8.2003.Arvind Mohan Johari & Anr vs State Of U.P. & Anr on 3 November, 2004

(vii) They will also make payment of second instalment of 20% to the depositors in
the next two months i.e. by 25.10.2003 and the third instalment of 20% by
25.12.2003.
(viii) The payment will be made to the depositors as contained in the list annexed to
the compromise."
The aforementioned directions were issued in view the assertion made by the Appellants to the
effect that the total amount involved by way of claim of the depositors of City Cooperative Bank Ltd.
would be to the extent of Rs. seven crores to Rs. eight crores and so far as depositors of M/s Century
Consultants are concerned, the same may be to the tune of Rs. nineteen crores; whereas they hold
and possess assets worth to Rs. twenty three to fifty crores.
It was further asserted that if they are enlarged on bail, they would be in a position to make the
payment due to the investors by disposing of their properties and assets. The City Cooperative Bank
Ltd. and Century Consultants Investors Welfare Association did not oppose the bail application of
the Appellants.
The said order was later on modified in the manner stated hereinafter.
Condition Nos. (ii), (vi) and (vii) were modified by an order dated 11.7.2003 in the following terms:
"(ii) Both the accused will file an undertaking on affidavit, that they will not leave the
jurisdiction of the Court without intimating the court concerned by giving address on
affidavit.
(vi) The accused  applicants will file an undertaking on an affidavit that they will
release first instalment of 20% amount within three months to liquidate their debts
of the depositors/ investors from the assets shown in para  6 of the supplementary
affidavit of Shri Mohit Lal dated 7.7.2003.
(vii) They will also undertake that they will make payment of second instalment of
the other 20% amount due to the depositors/ investors as per compromise with the
investors' association in the next three months i.e. by 25.12.2003."
On an application filed by the City Cooperative Bank Ltd. conditions No. (vi), (vii) and (viii) were
further modified by an order dated 9.10. 2003 in the following terms.
"(vi) The accused-applicants will file an undertaking on an affidavit that they will
release first instalment of 20% amount within the period prescribed earlier to
liquidate their debts of all the depositors/investors whether they are depositors of
Century Consultant Limited or they are account holders in City Cooperative Bank
from the assets shown in para of the supplementary affidavit of Shri Mohit Lal dated
7.7.2003.Arvind Mohan Johari & Anr vs State Of U.P. & Anr on 3 November, 2004

(vii) They will also undertake that they will make payment of second instalment of
other 20% amount due to all the depositors/ investors either of the Century
Consultant Limited or the City Cooperative Bank irrespective of the list annexed to
the compromise within a period prescribed earlier on 11.7.2003.
(viii) The payment will be made as indicated above to all individual
depositor/investor except the financial institutions notwithstanding their names find
place in the list of the investors association or not".
However, the prayer of the Bank for direction to make payment to its depositors only through it was
rejected.
A Special Leave Petition was filed thereagainst which was marked as Crl. MP NOs. 9881-9882/2003
wherein the Appellants herein were restrained from operating the Bank account and parting with
the assets and properties of the Society.
The period of six months for which the interim bail was granted in the meantime elapsed and the
Appellants filed applications for regular bail. The said bail applications having been rejected, the
Special Leave Petition filed by the City Cooperative Bank Limited became infructuous and it was
dismissed as such by this Court by an order dated 27.04.2004.
This appeal is directed against the order dated 23.04.2004 refusing regular bail to the Appellants.
Mr. Soli J. Sorabjee, learned senior counsel appearing on behalf of the Appellants in support of the
appeal would submit that from the records it would appear that despite directions by the Court in its
order dated 23.3.2004 to complete the trial within six months the same has not complied with as
dilatory tactics were adopted by the CBI. The learned counsel would contend that the Appellants
have no objection if from the assets held and possessed by them the depositors of Century
Consultants and the City Cooperative Bank Ltd. are paid their dues on a pro-rata basis. The
Appellants, furthermore would have no objection, Mr. Sorabjee would argue, if the depositors of the
City Cooperative Bank are paid through the Bank itself.
A supplementary affidavit has been filed on behalf of the Appellants herein wherein it is stated that
the value of the assets seized by CBI, as would appear from a report filed before the Registrar of
Companies in the winding up petition pending with the Allahabad High Court is Rs. 19.75 crores.
Furthermore, an amount of Rs. 17 crores and Rs. 13 crores are allegedly lying with the Bombay Stock
Exchange and National Stock Exchange respectively in the shape of bank guarantee money,
securities margin money, etc. A suit for injunction was filed by the Investors Forum of Century
Consultants Ltd. at Lucknow as Civil Suit No. 312 of 2002 praying for an order restraining the CBI
from releasing the said amount. In the said suit, National Stock Exchange and Bombay Stock
Exchange have filed their written statements admitting that the said monies are lying to the credit of
the company but the CBI has asked them not to release or disburse these amounts in view of a
pending Securities and Exchange Board of India (SEBI) inquiry into the transactions entered into by
the Appellants during the period January, February and March, 2001. The Appellants have alsoArvind Mohan Johari & Anr vs State Of U.P. & Anr on 3 November, 2004

liquid assets of Rs. 2.56 crores as stated at paragraphs (a) to (h) at pages 240-242 of the Paper Book,
Vol. I. Out of the said assets of Rs. 2.56 crores, a sum of Rs. 1.45 crores were realized by the
Appellants in the shape of release of demat accounts, fixed deposits, money from one debtor, release
back of money by the CBI. Out of it, they had disbursed Rs. 81.75 lakhs to 629 investors and a sum
of Rs. 65 lakhs are lying with them which could not be disbursed on account of the restraint order
passed by this Court.
Furthermore, a sum of Rs. 5.45 crores are owing to them from various debtors, the details whereof
are at pages 111-113 of the Paper Book, Vol. I. They have furthermore more than 100 bank accounts
which have been seized by the CBI, the details whereof are at pages 242-243 of the Paper Book, Vol.
I. Besides that, they are said to be in possession of the following personal assets, as contended in an
Additional Affidavit.
"(i) The residential house belonging to the Joint Hindu Family of G.N. Johri at 14,
Prem Nagar, Lucknow has also been seized by the CBI. The value of the said house is
approximately Rs. 50 lakhs. CBI has wrongfully attributed this residential house in
the names of the Petitioners.
Later on the CBI has released the house only for the purpose of its residential use and has restrained
the Petitioners from alienating the house.
(ii) The Petitioners hold at an average of nearly 5% equity each in Century Consultants Ltd. and in
other group companies in their individual status.
(iii) The Petitioners hold 12% equity share in lease-hold plot of Carlton Hotel, Lucknow and 12% in
equity partnership of Carton Hotel in their personal capacity.
(iv) The Petitioners have given unsecured loans to almost all the group companies and firms for
exigencies of business and the same are outstanding as on date.
(v) The Petitioners hold investments in secured bonds of Century Consultants Ltd. and in fixed
deposits of Cyber Space."
The details of the said assets and the bank accounts allegedly are not available to the Appellants as
the same have been seized by the CBI. The Appellants have furthermore inter alia contended that
they have no objection if payments are made to the investors of the Century Consultants Investors
Welfare Association and the depositors of City Cooperative Bank upon proof thereof. It has been
further urged :
"However, it is most respectfully submitted that in order to disburse these amounts
and satisfy these claims, it is essential that the properties which have been seized by
the CBI may be released and be placed at the disposal of the Company Court which
may issue appropriate directions for their protection and realization in order to meet
the established claims of the creditors. The Company Court may appoint a PresidingArvind Mohan Johari & Anr vs State Of U.P. & Anr on 3 November, 2004

Officer who may take requisite steps for this purpose.
The Petitioners submit that the Company Court may disburse the established claims
of the depositors of the City Cooperative Bank to the depositors directly or through
the City Cooperative Bank as this Hon'ble Court may be pleased to direct.
The Petitioners submit that they are willing to abide by all directions of this Hon'ble
Court in the abive matter as this Hon'ble Court may deem fit to issue."
Intervention applications have been filed by Century Consultants Investors Welfare Association,
Satya Prakash Choudhary and City Cooperative Bank Depositors Welfare Association through Ashok
Sur.
Having heard the learned counsel for the parties, we are of the opinion that no fruitful purpose
would be served by keeping the Appellants in continued detention.
We are further of the opinion that all endeavours should be made to realise as much amount as
possible from the personal and other assets of the Appellants by putting them on sale or otherwise.
For the aforementioned purpose, we direct :
1. All the amounts seized by CBI shall forthwith be placed at the disposal of the
learned Company Judge.
2. The Appellants herein shall also furnish details of their personal assets as also the
list of its creditors and the bank accounts. Bank accounts of the Appellants seized by
the CBI shall be released and the amount lying in the banks to the credit of the
Appellants shall also be deposited before the Company Judge.
3. The personal assets of the properties shall be sold in such a manner as the learned
Company Judge deems fit and proper but endeavours should be made to see that the
maximum price is fetched as for as possible by selling the said properties.
4. The National Stock Exchange and the Bombay Stock Exchange are directed to
deposit the money lying in the credit of the Company/Appellants as early as possible
subject to determination of the pending enquiry by SEBI.
If any enquiry is pending, SEBI shall dispose of the same as expeditiously as possible.
5. Steps be taken by the learned Company Judge to direct the banks in which the Appellants have
accounts to remit the money lying in their credit to the court.
6. In fine, all the assets whether movable or immovable including shares, debentures, promissory
notes, etc. lying with the Appellants themselves or with their creditors or any other persons or
authorities including CBI shall be placed at the disposal of the learned Company Judge.Arvind Mohan Johari & Anr vs State Of U.P. & Anr on 3 November, 2004

7. A bank account shall be opened in a nationalized bank by the learned Company Judge which may
be operated by such person or persons as may be authorized by it.
8. All the depositors including the depositors of the City Cooperative Bank shall file their claims
before the Company Judge and in case of any dispute, the claimants would be given opportunities to
establish such claims.
9. In order to disperse of claims of the creditors, the learned Company Judge may appoint such
number of Presiding Officer or Officers as may be necessary for effectuating realisation of the
amount by sale of the properties and disbursement thereof as well as disposal of the claims as may
be found to be necessary. For the said purpose requisite direction(s) shall be issued by the learned
Company Judge as regard realization and disposal of the assets including sale of the movable or
immovable properties, if any.
10. The City Cooperative Bank shall within a week from today shall file the statement of claims in
respect of the depositors before the learned Company Judge.
The claims of the City Cooperative Bank shall have preference over the claims of the others. The
depositors of City Cooperative Bank on establishing their claims, shall be paid through the City
Cooperative Bank.
11. In the event, the amounts and the assets lying at the disposal of the learned Company Judge are
found to be insufficient to satisfy all the claims, subject to the preference given to the City
Cooperative Bank, the claimants shall be paid on a pro-rata basis.
12. All claims which are pending before the learned Company Judge shall be deemed to have been
filed pursuant to this order.
13. The depositors in relation to City Cooperative Bank shall through the Bank or otherwise file their
claims within one month from the date of communication of this order for which the City
Cooperative Bank shall duly notify the depositors therefor.
14. It will be open to the City Cooperative Bank Depositors Welfare Association and Century
Consultants Investors Welfare Association to represent their respective members before the
Company Judge or such presiding officer(s) as may be appointed in this behalf.
15. All further proceedings pending before any Court in relation to the claim of the depositors both
in relation to the Company and City Cooperative Bank shall remain stayed.
16. The Company Judge is hereby requested to supervise the proceedings wherefor he would be
entitled to issue such direction or directions to the Presiding Officer, he may deem fit and proper. It
will also be open to the learned Company Judge to issue a general direction by way of guidelines.Arvind Mohan Johari & Anr vs State Of U.P. & Anr on 3 November, 2004

17. The Appellants herein, the CBI, the City Cooperative Bank and the official liquidator are hereby
directed to render all cooperation to the learned Company Judge for smooth conduct of the
proceedings.
18. The Appellants herein shall be entitled to scrutinize the Books of Accounts and other records and
documents which have been seized by the CBI for the purpose of assisting the learned Company
Judge in finding out their assets and debts in presence of the officer authorized in this behalf. They
are also permitted to take notes from the respective Books of Accounts and other records and
documents.
19. While disbursing the claims, the learned Company Judge or the Presiding Officer(s) shall take
into consideration the fact that some persons have already received some amount from the
Appellants herein in terms of the order of the High Court dated 25.6.2003 as modified on 11.7.2003
and 9.10.2003.
20. All Courts, Tribunals and Statutory Authority are hereby directed to produce all documents and
papers which are in their power and possession in accordance with law, as and when called for by
the learned Company Judge or the Presiding Officer(s) appointed in terms of this order.
The learned Chief Justice of the High Court is requested to place at the disposal of the learned
Company Judge services of such number of officers and other employees as may be asked for by the
learned Company Judge. The High Court shall also consider the desirability of placing services of
such number of judicial officers as may be found to be necessary for expeditious disposal of the
claim cases as also for other purpose, if any order in this behalf is passed by the learned Company
Judge.
It would be open to the learned Company Judge to avail the services of official liquidator as also
lawyers and their remuneration may be fixed by the learned Company Judge which would be
realized from the assets of the Appellants.
We are conscious of the fact that such directions could not have ordinarily been issued by this Court
while disposing of a bail application but keeping in view the fact that the Appellants herein had been
released on interim bail in terms of the order dated 25.6.2003 on conditions and steps had already
been taken to pay to the depositors their dues, we have issued the aforementioned directions in
exercise of our power under Article 142 of the Constitution of India to do complete justice to all the
parties.
The parties shall be at liberty to approach this Court for any clarification or direction or directions, if
any occasion arises therefor.
The Appellants herein shall be released on bail on furnishing personal bonds of Rs. 50,000/- with
one surety of the like amount to the satisfaction of the Special Judicial Magistrate, CBI subject to the
following conditions:Arvind Mohan Johari & Anr vs State Of U.P. & Anr on 3 November, 2004

(i) They would surrender their passports before the Special Judicial Magistrate, CBI.
(ii) They would also file an undertaking that they would not leave the jurisdiction of
the court without its prior permission.
(iii) They shall, save and except for cogent reasons, shall appear before the Court on
each and every date of hearing.
(iv) They shall not intimidate the witnesses nor interfere in any manner the trial.
(v) They shall not do any act or acts or things which may delay the disposal of the
criminal cases.
(vi) They shall render all cooperation to the learned Company Judge and the
Presiding Officer.
These Appeals are disposed of with the aforementioned directions. There shall be no order as to
costs.Arvind Mohan Johari & Anr vs State Of U.P. & Anr on 3 November, 2004

