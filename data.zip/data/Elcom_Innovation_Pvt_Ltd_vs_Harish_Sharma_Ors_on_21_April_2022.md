Elcom Innovation Pvt Ltd vs Harish Sharma & Ors. on 21 April,
2022
Author: Amit Bansal
Bench: Amit Bansal
                        *          IN THE HIGH COURT OF DELHI AT NEW DELHI
                        %                              Judgment Reserved on : 29th March, 2022
                                                       Judgment Delivered on : 21st April, 2022
                        +                                      CS(OS) 288/2021
                                   ELCOM INNOVATION PVT. LTD.             ..... Plaintiff
                                               Through: Mr. Manav Gupta with Mr. Sahil
                                                         Garg, Advocates.
                                                      versus
                                   HARISH SHARMA & ORS.                               ..... Defendants
                                               Through:             Mr. Samar Bansal with Ms. Anindita
                                                                    Mitra, Advocates for D-1.
                                   CORAM:
                                   HON'BLE MR. JUSTICE AMIT BANSAL
                                                            JUDGMENT
AMIT BANSAL, J.
I.A. No.7635/2021 (u/O-XIII R-1 of CPC)
1. Allowed, subject to just exceptions.
I.A. No.10786/2021 (of the defendant No.1 for exemption from attestation of supporting affidavits
and affidavit of service of counsel for the defendant no.1 through the oath commissioner), I.A.
No.10787/2021 (of the defendant No.1 for exemption from filing certified copies, legible, typed
copies of the annexures) & I.A. No.10788/2021 (of the defendant No.1 for exemption from filing
official translation and typed copy of annexures/documents)
2. For the reasons stated in the applications, the same are allowed.
Signing Date:22.04.2022 11:42:00 I.A. No.7634/2021 (u/O-XXXIX R-1 & 2 of CPC) & I.A.
No.12977/2021 (for directions)Elcom Innovation Pvt Ltd vs Harish Sharma & Ors. on 21 April, 2022

3. By the present order, I shall dispose of the applications filed on behalf of the plaintiff Company
namely, I.A. No.7634/2021 and I.A. No.12977/2021.
4. I.A. No.7634/2021 has been filed by the plaintiff Company under Order XXXIX Rules 1 and 2 of
the Code of Civil Procedure, 1908 (CPC), seeking an ad interim injunction, restraining the
defendants from using, disclosing, disseminating, divulging, circulating, selling or transferring etc.,
in any manner, the proprietary sensitive and highly confidential information/data, including the
intellectual property of the plaintiff Company. Though, prayer b in the aforesaid application was in
respect of restraining the defendant No.1 from competing with the plaintiff Company during the
subsistence of the Share Purchase and Shareholders Agreement dated 24th December, 2012 and
from disclosing, selling or transferring any confidential information, including intellectual property
of the plaintiff Company to the defendant No.2 or anyone else, including the competitors of the
plaintiff Company, however, submissions have been made only in respect of disclosing confidential
information.
5. The counsel for the defendant No.1 appeared on advance notice on 5th July, 2021, when the suit
along with I.A. No.7634/2021 was first listed. Though no formal notice was issued in the aforesaid
application, the counsel for the defendant No.1 has been heard at length on all subsequent dates
before this Court.
6. I.A. No.12977/2021 has been filed by the plaintiff Company under Section 151 of the CPC, seeking
a direction to the defendant No.1 to transfer Signing Date:22.04.2022 11:42:00 his 7,517 shares in
favour of the plaintiff Company for a consideration of Rs. 12,21,512.50/-.
7. Notice was issued in I.A. No.12977/2021 qua prayer (a) on 12th November, 2021. A reply has been
filed to I.A. No.12977/2021 by the defendant No.1 and a rejoinder, thereto, has been filed by the
plaintiff Company.
8. For the present applications to be decided, the necessary facts as pleaded by the plaintiff
Company in the plaint are as follows:
(i) The plaintiff, Elcom Innovation Pvt. Ltd., is in the business of aerospace,
communications, electronics, tactical communications, and homeland security, etc.
and is a leader in the field of defence.
(ii) The defendant No.1, Mr. Harish Sharma, is an erstwhile employee and
shareholder of the plaintiff Company. The defendant No.1 was appointed as a
Director - Product Engineering w.e.f. 1st December, 2012. The defendant No.1 was
also a party to the Share Purchase and Shareholders Agreement dated 24th
December, 2012 of the plaintiff Company (hereinafter, referred to as the „SPSA), in
pursuance whereto the defendant No.1 was allotted 5.4% shareholding in the plaintiff
Company.Elcom Innovation Pvt Ltd vs Harish Sharma & Ors. on 21 April, 2022

(iii) The defendant No.2, Vihaas Design Technologies, is an entity engaged in the
same business as the plaintiff Company and is managed by the defendants No.1 and
3.
(iv) Under the SPSA, the defendant No.1 had unequivocally undertaken to maintain
confidentiality and to not venture into anti-competitive practice to the detriment of
the plaintiff Company during the course of Signing Date:22.04.2022 11:42:00 his
employment and for a period of three years from the date of severance from the
plaintiff Company.
(v) The defendant No.1 resigned from the plaintiff Company w.e.f. 10th April, 2018,
pursuant whereto, full and final settlement of the dues of defendant No.1 was done by
the plaintiff Company.
(vi) In the month of January, 2020, the IT administrator of the plaintiff Company
observed unusual activity in the email accounts of the key employees of the plaintiff
Company. It was noticed that from the official email IDs of the Vice President of the
plaintiff Company, Mr. Sumeet Mallikarjun i.e., sumeet@elcominnovations.com and
the marketing coordinator of the plaintiff Company, Ms. Diksha Singh i.e.,
diksha@elcominnovations.com, emails were being forwarded to one email ID i.e.,
sumeetmalikarjun@outlook.com (hereinafter, referred to as the „fake email ID).
(vii) A criminal complaint was lodged by the plaintiff Company on 3rd February,
2020 with the Centre for Cyber Crime Investigation, Noida against unknown persons.
(viii) In the course of the investigation by the Cyber Cell, it came to light that the fake
email ID, where the confidential and sensitive information was being forwarded to,
was created by the defendant No.1.
(ix) The authorities registered an FIR against the defendant No.1 bearing FIR No.786
on 12th December, 2020 at P.S. Sector-39, Noida for commission of offences under
Section 420 of the Indian Penal Code, 1860 and Section 66 of the Information
Technology Act, 2000.
Signing Date:22.04.2022 11:42:00
(x) The defendant No.1 entered into a Consultancy Agreement dated 16 th April, 2018
with the defendant No.2, which is a competitor of the plaintiff Company.
(xi) Pursuant to the defendant No.1 routing confidential and sensitive information
from the plaintiff Company to the fake email ID, by misusing the confidential
information and data of the plaintiff Company, the defendants began to poach the
clients of the plaintiff Company.Elcom Innovation Pvt Ltd vs Harish Sharma & Ors. on 21 April, 2022

(xii) Since, the defendant No.1 continues to hold 5.4% shareholding in the plaintiff
Company and continues to be a shareholder of the plaintiff Company, by misusing
the confidential and sensitive information/data of the plaintiff Company for making
unlawful gains for the defendants and causing loss to the plaintiff Company, the
defendant No.1 has committed material breach of the SPSA.
9. Based on the aforesaid pleadings, the present suit has been filed by the plaintiff Company, seeking
a decree of permanent injunction against the defendants, restraining them from using, disclosing,
disseminating, divulging, circulating, selling or transferring, etc., in any manner, the proprietary,
sensitive and highly confidential information/data of the plaintiff Company and other ancillary
reliefs, including damages.
10. The counsel for the plaintiff Company, with respect to I.A.No.12977/2021, has made the
following submissions:
(i) As per the terms of the SPSA, the defendant No.1 was to transfer his 7,517 shares
in favour of the plaintiff Company for a consideration of Rs.12,21,512.50/-.
Signing Date:22.04.2022 11:42:00
(ii) In the reply to the I.A.No.12977/2021, the defendant No.1 has given his
willingness to sell his shares to the plaintiff Company upon the determination of
„Fair Market Value in terms of the SPSA.
11. The counsel for the plaintiff Company, with respect to I.A. No.7634/2021, has made the following
submissions:
(i) The suit has been filed based on two separate causes of action, (a) on account of
the revelation, pursuant to the investigation conducted by the Cyber Cell, that the
defendant No.1 had hacked into the server of the plaintiff Company in order to steal
confidential information/data;
and, (b) breach of the terms of the SPSA entered into between the plaintiff Company and the
defendant No.1.
(ii) After the filing of the present plaint, a chargesheet has been filed by the Cyber Cell on 16th April,
2021 in FIR No.786, wherein it has been noted that the phone number of the defendant No.1 was
used for accessing the fake email ID, whereto the emails from the plaintiff Companys key
employees were forwarded. He further submits that cognizance has been taken of the chargesheet by
the Sessions Court on 1st September, 2021 and bailable warrants have been issued against the
defendant No.1.
(iii) In support of the grant of an ad interim injunction, reliance is placed on the judgments in John
Richard Brady & Ors. Vs. Chemical Process Equipments P. Ltd. & Anr., AIR 1987 DELHI 372 andElcom Innovation Pvt Ltd vs Harish Sharma & Ors. on 21 April, 2022

Danieli Corus BV Vs. Steel Authority of India, 2018 (246) DLT 329, the judgment dated 10th
October, 2012 of the High Court of Karnataka in M.F.A. No.1682/2010 titled Homag India Private
Ltd. Vs. Ulfath Ali Khan & Ors., and the order dated 24th July, 2018 of this Court in Signing
Date:22.04.2022 11:42:00 CS(OS) 351/2018 titled Honeywell International India (Pvt) Ltd Vs. Kush
Kumar Bhateja.
12. The counsel for the defendant No.1, with regard to I.A.No.12977/2021, has made the following
submissions:
(i) The averments made in I.A.No.12977/2021 are at variance with the averments
made in the plaint.
(ii) The plaintiff Company has failed to make any amendments in the plaint as
originally filed.
(iii) In view of the fact that the plaintiff Company itself has defaulted in its
obligations to purchase the shareholding of the defendant No.1 in terms of the SPSA,
the defendant No.1 cannot be considered to be a shareholder of the plaintiff Company
and, therefore, the terms of the SPSA are not binding on the defendant No.1. In this
regard, reliance is placed on Articles 12.4, 14.2 and 14.3 a. ii) of the SPSA.
(iv) The aforesaid application has been filed at a very belated stage by the plaintiff
Company and only after a Default Notice in terms of the SPSA was issued by the
defendant No.1 to the plaintiff Company.
13. The counsel for the defendant No.1, with regard to I.A. No.7634/2021, has made the following
submissions:
(i) There is suppression of material facts by the plaintiff Company as noted by the
previous orders of this Court and, therefore, no ground is made out for the grant of
injunction. Attention in this regard has been drawn to the orders dated 5th July,
2021, 19th July, 2021, and 27th August, 2021.
(ii) No averments have been made with regard to the confidential information that
has been allegedly misused by the defendant No.1.
Signing Date:22.04.2022 11:42:00 In this regard, attention of the Court has been drawn to
paragraph 12 of the plaint, where only vague averments have been made in relation to the acts
committed by the defendant No.1. Reliance is placed on the judgment of this Court dated 17th
September, 2018 in CS(COMM) 735/2016 titled Navigators Logistics Ltd. Vs. Kashif Qureshi & Ors.,
to contend that no injunction order can be passed in the absence of details of confidential
information, breach of which has been alleged by the plaintiff Company.Elcom Innovation Pvt Ltd vs Harish Sharma & Ors. on 21 April, 2022

(iii) In the investigations conducted by the Cyber Cell, there is nothing to suggest that the fake email
ID was created by the defendant No.1 or that he committed any fraudulent act of usage of such fake
email ID. The chargesheet only states that this email ID was accessed by using the mobile internet
facility of the defendant No.1.
14. In rejoinder, it has been submitted on behalf of the plaintiff Company as follows:
(i) The chargesheet clearly records that the fake email ID was accessed on multiple
occasions using the mobile number of the defendant No.1.
(ii) The details of the confidential information, which has been misused by the
defendant No.1, have not been provided in the plaint as the nature of the contracts
entered into by the plaintiff Company with his clients are highly confidential and
sensitive. Therefore, details thereof cannot be provided by the plaintiff Company.
15. I have heard the counsels for the parties.
16. In order to decide I.A. No.12977/2021 and I.A. No.7634/2021, at this stage, it may be relevant to
reproduce some of the Articles of the SPSA that are relevant for deciding the said applications:
Signing Date:22.04.2022 11:42:00 ―ARTICLE 12:
TRANSFER OF SHARES xxx xxx xxx 12.4 Right of First Refusal
(a) In the event that, upon the expiry of the Lock-in Period, any of the Shareholders
(the ―Selling Shareholder) intends to Transfer all or any part thereof, of the Shares
held by it to a Person not being its Affiliate, the Selling Shareholder shall first offer
(the ―Offer) to sell the Shares by sending a notice of the Offer in writing (the
―Notice) to the other Shareholders (the ―Non-Selling Shareholders), irrevocably
offering to sell the Shares to the Non-
Selling Shareholders.
(b) The Notice shall clearly stipulate (i) the number of Shares the Selling Shareholder desires to sell
(the ―Offered Shares) (ii) the price at which the Selling Shareholder desires to sell the Offered
Shares (the ―Offer Price).
(c) Within 30 Business Days of the receipt of the Notice by the Non-Selling Shareholders (the "Offer
Period"), the Non-Selling Shareholders may at its option send a notice (a "Response Notice") in
writing to the Selling Shareholder and the Company making an irrevocable offer to buy the Offered
Shares at the Offer Price.
(d) If the Non-Selling Shareholders elect to send the Response Notice, the Selling Shareholder shall
transfer the Offered Shares to the Non-Selling Shareholders in proportion to their currentElcom Innovation Pvt Ltd vs Harish Sharma & Ors. on 21 April, 2022

Shareholding, free of all Liens and such 'Transfer Signing Date:22.04.2022 11:42:00 shall be
completed within thirty (30) Business Days from the date of the Response Notice.
(e) If the Non-Selling Shareholders do not elect to send the Response Notice within the Offer Period,
or if the Non-Selling Shareholders communicate a refusal to act upon the Notice, the Selling
Shareholder shall be free to sell the Offered Shares to any third Person (the "Proposed Buyer") on
terms no more favourable than those offered by the Selling Shareholder to the Non Selling
Shareholders, within 30 daysfrom the end of Offer Period or from the date of communication of its
refusal by the Non Selling Shareholders whichever is earlier and immediately upon finalization of
arrangement in respect of the Offered Shares with the Proposed Buyer, communicate the name and
the particulars of the Proposed Buyer to the Non-
Selling Party Provided such Proposed Buyer is not carrying on business competing with the
Company. If the Offered Shares are not sold within such period on such terms, the rights of the
Non-Selling Shareholder pursuant to this Article 12.4 and Article 12.5 shall again take effect with
respect to any Transfer of Shares in any other manner.
(f) The Proposed Buyer (as defined hereinabove) shall execute the Deed of Adherence in the form set
out in Schedule VIII of this Agreement.
                                                     xxx         xxx         xxx
ARTICLE 14:
                                               TERM AND TERMINATION
                                               xxx         xxx         xxx
Signing Date:22.04.2022 11:42:00
                                    14.2 Events of Default
Each of the following shall constitute an event of default (―Event of Default) for the purposes of
this Agreement:
a. In the event that either of the Parties (the "Defaulting Party") is in breach or fails to
observe or comply with the provisions and obligations contained in Articles 12
(Transfer of Shares), 17 (Non-Solicitation), 18 (Confidentiality) and 20
(Non-Compete) hereof, which breach or failure, if capable of cure or remedy, has not
been cured or remedied within thirty (30) Business Days of the receipt of written
notice of such breach or failure ("Default Notice") from the other Party (the "Non-Elcom Innovation Pvt Ltd vs Harish Sharma & Ors. on 21 April, 2022

                                        Defaulting Party"); or
                                                     xxx          xxx          xxx
                                   14.3 Consequences of Event of Default
a. Upon the occurrence of an Event of Default as specified in Article 14.2 (a) above,
the Agreement shall be liable to be terminated by the Non Defaulting Party and the
Defaulting Party shall, at the sole discretion of Non Defaulting Party, either
i) be obligated to sell all (but not some only) of its Shares to the Non-Defaulting Party
and/or its nominee at price equal to 75% of a Fair Market Value arrived at in
accordance with the process set out in Article 14.3 (d) below provided the Non-
Defaulting Party is willing to buy the Shares of the Defaulting Party, or
ii) be obligated to purchase all (but not some only) of the Shares held by the Non-Defaulting Party
and/or its Affiliates at a price equal to 125% of the Fair Market Value, provided the Non-Defaulting
Party is willing to sell its Shares to the Defaulting Party.
Signing Date:22.04.2022 11:42:00 xxx xxx xxx d. The "Fair Market Value" of the Shares for the
purpose of Article 14.3(a) shall be determined by an independent valuer of international repute (so
called "Big Four"
accounting firm), appointed by the Non-Defaulting Party. Such valuer shall be
appointed within thirty (30) Business Days of the date of the Default Notice and shall
determine the Fair Market Value within thirty (30) Business Days of its appointment.
The valuer shall base its valuation upon generally accepted international standards
for valuation, and shall consider such factors as historic performance, book value,
market comparables and discounted cash flow approach. Provided the market
comparables shall be drawn from companies having similar operations in the same
territory where the Company operates in.
e. The sale and purchase of Shares pursuant to the exercise by the Non-Defaulting
Party of its rights under Article 14.3(a) shall be completed within 30 Business Days of
the determination of the Fair Market Value in accordance with Article 14.3(d).
                                                        xxx         xxx          xxx
                                   14.4 Termination of this Agreement
                                                        xxx         xxx          xxxElcom Innovation Pvt Ltd vs Harish Sharma & Ors. on 21 April, 2022

c. The provisions of Article 14 (Term and Termination), Article 20 (Confidentiality),
Article 21 (Notices), Article 23(Governing Law and Dispute Resolution) as well as all
other miscellaneous provisions of Article 24 (Miscellaneous) as are applicable or
relevant thereto, shall survive termination of this Agreement.
                                                        xxx         xxx          xxx
Signing Date:22.04.2022 11:42:00
ARTICLE 20:
                                                      CONFIDENTIALITY
20.1 Each of the Parties shall at all times use their best endeavours to keep
confidential (and to ensure that its employees and agents shall keep confidential) any
confidential information which it may acquire in relation to the Company or in
relation to the clients, business or affairs of the other Party (or any of its subsidiary).
Each Party shall use all its respective powers to procure (to the extent that it can) that
the Company shall use all reasonable endeavours to ensure that the officers,
employees and agents of each of them shall observe a similar obligation of confidence
in favour of the Parties hereto. The term ―Confidential Information as used in this
Agreement includes all information and other materials acquired by a Party or its
representative or agent from the other Party or its representative or agent in relation
to the transactions contemplated by this Agreement and in relation to the Parties or
which, under the circumstances of disclosure ought to be treated as confidential,
whether written, oral or in any other form, and whether such information is
furnished before, on or after the date of this Agreement, and shall include
information and materials:
a. Relating to the terms and conditions of this Agreement and all documents in
furtherance of this Agreement;
b. Relating to the organization, business, technology, finance, transactions, affairs,
financial and accounting books and records, marketing or promotion of any product
or services, business policies or practices, customers, potential customers or
suppliers of information, trade secrets, source codes, documentation, formulae, and
technology of a Party or any other party;
Signing Date:22.04.2022 11:42:00 c. Received from the other Party that a Party is
obligated to treat as confidential; and d. Prepared by the Party or its respective
directors, officers, managers, partners, members, employees or legal, financial orElcom Innovation Pvt Ltd vs Harish Sharma & Ors. on 21 April, 2022

professional advisors or bankers that contain or otherwise reflect, or are generated
from, Confidential Information.
and shall not use or disclose such information except with the consent of the other
Party or in accordance with the order of a court of competent jurisdiction or, in the
case of information relating to the Company, for the advancement of the Business.
xxx xxx xxx 20.3 In the event that for any reason this Agreement shall lapse and the
transactions contemplated hereby shall not be implemented, each Party shall on
written demand of the other Party immediately return or destroy the Confidential
Information pertaining to the Party making such request.
17. First, I propose to take up I.A.12977/2021.
18. The relevant facts, which emerge from a reading of the pleadings and documents, in the context
of the SPSA and its provisions as stated aforesaid, may be consolidated as follows:
(i) Vide the Notice of Offer dated 12th November, 2018, the defendant No.1, the
Selling Shareholder, communicated his intention to sell 7,517 shares held by him,
constituting 5.4% of the total shareholding of the plaintiff Company, to the
Non-Selling Shareholders at an Offer Price of Rs.130/- per share. The aforesaid Offer
was made in terms of Article 12.4 of the SPSA bearing the title „Right of First
Refusal.
Signing Date:22.04.2022 11:42:00
(ii) The aforesaid Offer was accepted by the Non-Selling Shareholders of the plaintiff
Company vide the Response Notice dated 6 th December, 2018 as per Article 12.4(c)
of the SPSA, which was made note of by defendant No.1 vide the Communication
dated 14th December, 2018, whereby the Non-Selling Shareholders of the plaintiff
Company were asked to pay the sum of Rs.9,77,210/- as consideration value of the
shares.
(iii) The transfer of the shares from the defendant No.1 to the Non-Selling
Shareholders of the plaintiff Company was to be completed within thirty business
days from the date of the Response Notice.
(iv) However, the Non-Selling Shareholders of the plaintiff Company failed to
transmit the consideration in respect of the transfer and in this regard, a Default
Notice dated 25th January, 2019 was issued by the defendant No.1, being the
Non-Defaulting Party, to the Non-
Selling Shareholders of the plaintiff Company, being the Defaulting Parties, whereby the Defaulting
Parties were requested to cure the Event of Default within thirty business days from the receipt ofElcom Innovation Pvt Ltd vs Harish Sharma & Ors. on 21 April, 2022

the said Default Notice.
(v) The plaintiff Company, thereafter, sent a Legal Notice to the defendant No.1 dated 15th February,
2019, alleging commission of "serious offences, breach and theft" and which allegations were denied
by the defendant No.1 vide Reply dated 28th February, 2019. A Rejoinder dated 25th March, 2019
thereto on behalf of the plaintiff Company was sent to the defendant No.1.
(vi) Another Default Notice dated 7th March, 2019 was issued by defendant No.1 to the plaintiff
Company in terms of Article 14.3 a. of Signing Date:22.04.2022 11:42:00 the SPSA. It was stated
therein since the Non-Selling Shareholders of the plaintiff Company had failed to pay the
consideration for the transfer of the shares of the defendant No.1, and which Event of Default had
remained uncured, there was a default committed on behalf of the Non-Selling Shareholders of the
plaintiff Company. In view of the aforesaid, in terms of Article 14.3 a. ii) of the SPSA, the SPSA was
liable to be terminated and in such circumstance, under Article 14.3 a. ii) of the SPSA, the
Non-Selling Shareholders of the plaintiff Company were obligated to purchase all of the shares held
by the Non-Defaulting Party, the defendant No. 1, at a price equal to 125% of the „Fair Market
Value provided by the defendant No. 1, consequent to the process under Article 14.3 d. of the SPSA.
(vii) Accordingly, vide the aforesaid Notice the defendant No.1 terminated the SPSA and proceeded
to take steps for fixation of the „Fair Market Value of the shares in terms of Article 14.3 d. of the
SPSA.
(viii) Vide Reply dated 20th March, 2019 by the plaintiff No.1 Company, it was stated that the
Article 14.2, being „Events of Default and Article 14.3, being „Consequences of Event of Default
were very specific to the „Parties of the SPSA as defined in the SPSA and not to the individual
Members of the Tech Group. Therefore, Articles 14.2 and 14.3 were only applicable in case there is
an Event of Default committed by a Party and were not applicable for a default that may be
committed by a Member towards any other Member. Furthermore, it was stated that unless a
satisfactory resolution of the allegations against the defendant No.1 was done, the Non-Selling
Shareholders of Signing Date:22.04.2022 11:42:00 the plaintiff Company would not like to proceed
with the transfer of shares as agreed by vide Response Notice dated 6th December, 2018.
(ix) The defendant No.1 contacted the plaintiff Company vide Letter dated 5th April, 2019 to submit
the documents required for the determination of „Fair Market Value of the shares of the plaintiff
Company, however, the plaintiff Company refused to provide such information vide Letter dated
10th April, 2019, stating that the claim of the defendant No.1 of termination of the SPSA under
Article 14.3 of the SPSA was not sustainable.
19. It is to be noted that the aforesaid developments and documents do not find mention in the
plaint and have been brought on record as additional documents pursuant to the liberty granted by
this Court vide order dated 5th July, 2021. As noted in the order dated 12th November, 2021, though
the counsel for the plaintiff Company had submitted that the plaintiff Company would be moving an
application seeking to amend the plaint, however, the same has not been moved.Elcom Innovation Pvt Ltd vs Harish Sharma & Ors. on 21 April, 2022

20. The predecessor Bench of this Court in the order dated 27 th August, 2021 has already dealt with
the contention of the plaintiff Company that the Article 14.2, being „Events of Default and Article
14.3, being „Consequences of Event of Default were very specific to the „Parties of the SPSA as
defined in the SPSA and not to the individual Members of the Tech Group as follows:
―11. To a query from the Court as to how, in that case, Defendant No.1 could be said
to have breached Clause 20.1 or Clause 22.1 of the SPSA, when the obligations under
both these clauses attach only to ―parties to the SPSA and not to the individual
members of any of the parties, Mr. Gupta seeks to submit that, where the Signing
Date:22.04.2022 11:42:00 SPSA casts an obligation on any of the parties, that
obligation would -- to use the expression employed by Mr. Gupta - ―percolate down
to the individual members of the parties. As such, he submits, the obligations cast
under Clause 20.1 and 22.1 of the SPSA would percolate down to Defendant No. 1, as
a member of the Tech Group.
12. To my mind, these submissions are inherently contradictory in nature. Defendant
No. 1 is either a party to the SPSA or is not a party thereto. He cannot be treated as a
―party for the purposes of Clauses 20.1 and 22.1, and not a ―party for the purposes
of Clause 14.4. The SPSA does not contemplate multiple definitions of the word
―party. If the Tech Group is to be treated as a party to the SPSA, Defendant No.1
cannot, in my view, be individually bound by the covenants in Clause 20.1 and 22.1.
If, on the other hand, Defendant No.1 is to be treated as a party to the SPSA for the
purposes of Clause 20.1 and 22.1, he would equally be a party to the SPSA for the
purpose of Clause 14.4. No concept of ―percolating down of responsibilities and
obligations under the SPSA finds any place therein. The argument, therefore, though
ingenious, fails to impress.
21. I am in agreement with the aforesaid observations. It cannot be so that the defendant No.1 be
treated as a „Party for the purposes of the provisions of confidentiality in the SPSA and not be
treated as a „Party for the purposes of the provisions of term and termination in the SPSA.
22. In light of the aforesaid, it has rightly been contended on behalf of the defendant No.1 that the
Offer Price quoted by the defendant No.1 in his letter dated 12th November, 2018 was only relevant
for the purposes of Article 12.4 of the SPSA, being the „Right of First Refusal of the Non- Selling
Shareholders of the plaintiff Company. Since the Non-Selling Shareholders of the plaintiff Company
defaulted in making payment to the defendant No.1 in pursuance to the aforesaid Offer, the
aforesaid Offer price Signing Date:22.04.2022 11:42:00 of Rs.130/- ceased to apply. It is further to
be noted that the defendant No.1 gave an opportunity to the Non-Selling Shareholders of the
plaintiff Company to cure the Event of Default through the Default Notice dated 25th January, 2019.
However, the Non-Selling Shareholders of the plaintiff Company failed to cure the Event of Default.
Rather, vide Reply dated 20th March, 2019, the Non-Selling Shareholders of the plaintiff Company
stated that they would not like to proceed with the transfer of shares as agreed by vide Response
Notice dated 6th December, 2018. Thereafter, the defendant No.1 invoked Articles 14.3 a. ii) and
14.3 d. of the SPSA for determination of the „Fair Market Value of his shares in order for theElcom Innovation Pvt Ltd vs Harish Sharma & Ors. on 21 April, 2022

Non-Selling Shareholders of the plaintiff Company to purchase the said shares of the defendant
No.1. In this regard, the defendant No.1 has placed reliance on the email exchange with Ernst &
Young (hereinafter, referred to as „EY). Vide email dated 30th March, 2019, Com Legal Associates
LLP, on behalf of the defendant No.1, sent scanned documents for determination of the „Fair Market
Value of the shares held by defendant No.1. EY vide email dated 1st April, 2019 requested the
defendant No.1 to provide general information for conducting the valuation exercise. The defendant
No.1 in turn contacted the plaintiff Company vide letter dated 5th April, 2019 to submit the
documents required for the determination of „Fair Market Value of the shares of the plaintiff
Company, however, the plaintiff Company refused to provide such information vide Letter dated
10th April, 2019.
23. It is clear from the reading of the above said Articles of the SPSA that having failed to pay the
Offer Price within thirty business days from the date of the Response Notice, the Non-Selling
Shareholders of the plaintiff Company relinquished their right to purchase the shares at the said
Offer Signing Date:22.04.2022 11:42:00 Price. Thereafter, an Event of Default came into play and as
per Article 14.3 a. ii), and the shares could only be purchased by the Defaulting Parties of the
plaintiff Company at 125% of the „Fair Market Value of the shares, as determined by an
independent valuer of international repute, provided the defendant No.1 was willing to sell the
shares to the Defaulting Parties.
24. In light of such facts and circumstances, the defendant No.1 cannot be directed to transfer his
7,517 shares in favour of the plaintiff Company for a consideration of Rs. 12,21,512.50/-, being 125%
of the original Offer Price of the shares.
25. Consequently, I.A. No.12977/2021 is liable to be dismissed.
26. I now propose to take up I.A. No.7634/2021.
27. It is the case of the plaintiff Company that even after the cessation of his employment with the
plaintiff Company, the defendant No.1 has been accessing confidential and sensitive information of
the plaintiff Company by hacking into the email IDs of the key employees of the plaintiff Company,
routing confidential information to the fake email ID, and misusing the aforesaid confidential
information. The confidentiality provisions as contained in the SPSA have been reproduced above.
28. Though no reply has been filed on behalf of the defendant No.1 to the aforesaid application but
in the course of oral submissions, various grounds have been taken to oppose the grant of relief as
prayed in I.A. No.7634/2021.
29. One of the grounds taken by the defendant No.1 is that in view of the fact that the Non-Selling
Shareholders of the plaintiff Company themselves have defaulted in their obligation to purchase the
shareholding of the defendant No.1, the terms of the SPSA are not binding on the defendant Signing
Date:22.04.2022 11:42:00 No.1. However, this submission overlooks Articles 14.4 c. and 20.3 of the
SPSA as extracted above. Article 14.4 c. of the SPSA specifically provides that the provisions of
Article 20, being „Confidentiality shall survive the termination of the SPSA. Similarly, Article 20.3Elcom Innovation Pvt Ltd vs Harish Sharma & Ors. on 21 April, 2022

specifically provides that in the event the SPSA lapses, there is an obligation on each of the parties to
return or destroy the confidential information pertaining to other party. Therefore, even if the SPSA
had been terminated by the defendant No.1, the provisions of confidentiality shall continue to apply
and the defendant No.1 shall remain bound by the terms therein. Reference in this regard may be
made to the judgment of this Court in John Richard Brady Vs. Chemical Process Equipments Pvt.
Ltd., AIR 1987 Del. 372, wherein it has been held that even in the absence of a contract, information
received under a duty of confidence can be protected.
30. Next, it has been contended on behalf of the defendant No.1 that the plaintiff Company has
suppressed material facts from the Court.
31. This Court in the order dated 19th July, 2021 has noted that documents and facts pivotal to
maintaining the claim of the plaintiff Company, admittedly, do not find any reflection in the plaint.
Vide order dated 27th August, 2021, this Court has also noted that the submission of the plaintiff
Company on affidavit that the suppressed communications were not relevant for the case at hand,
could not prima facie be accepted. Thus, this raises the issue of whether, having failed to make any
reference to these communications, the plaintiff Company can seek to urge any rights, against the
defendant No.1.
32. While no interim relief has been granted in favour of the plaintiff Company till date and the
aforesaid documents have subsequently been Signing Date:22.04.2022 11:42:00 placed on record, it
cannot be denied that the suppressed documents and facts are crucial in determining the reliefs as
sought in the plaint and applications by the plaintiff Company. Though such suppression of material
facts itself is a ground for rejection of the plaint, I have proceeded to consider I.A. No.7634/2021 on
merits.
33. The submission made on behalf of the defendant No.1 is that only vague averments have been
made on behalf of the plaintiff Company with regard to the confidential information that has been
allegedly misused by defendant No.1. In this regard, the plaintiff Company has placed on record the
chargesheet filed, wherein it has been recorded that the fake email ID was accessed on multiple
occasions using the mobile number of the defendant No.1. In paragraphs 11 and 12 of the plaint, the
plaintiff Company has averred to the illegal acts being committed by the defendant No.1 by using the
confidential information as follows:
―11. That by violating the terms of the Shareholders Agreement and by gaining illegal
access to the sensitive information, the Defendants got hands on a US $ 7.6 Million
Purchase Order, which the Plaintiff had received from one of its international clients
and had routed the same to a competitor. The said competitor had created
misunderstandings between the Plaintiff Company and the concerned Norwegian
Company, who had in fact blamed the Plaintiff Company for breach of contract and
violation of confidentiality clause. The Plaintiff has reason to believe that the
Defendants have already/might misused/misuse the said classified information/data
with a palpable view of manipulating bidding processes in order to steal contracts out
of the hands of the Plaintiff Company.Elcom Innovation Pvt Ltd vs Harish Sharma & Ors. on 21 April, 2022

Signing Date:22.04.2022 11:42:00
12. By committing the illegal acts as aforesaid, the Defendants have and still
continuing to:
(a) Reveal Plaintiff Company's bidding prices for various government tenders to
competitors;
(b) Reveal the Plaintiff Company's Intellectual Property Rights to its competitors
leading to copying of its products;
(c) Divert contracts of the Plaintiff's Company to third party competing entities;
(d) Indulge in misleading the Plaintiff Company's international clients with
unsolicited and fallacious information causing loss to the Plaintiff Company;
(e) Instigating the Plaintiff's suppliers to significantly increase their prices by
divulging Plaintiffs profit margins.
Endanger the National Security of the Country.
34. Upon the enquiry of this Court as to the particulars of the confidential information as has been
misused by the defendant No.1, it has been repeatedly stated by the counsel for the plaintiff
Company that the information is such which cannot be disclosed.
35. At this stage, when the Court is required to take the prima facie view of the matter, it may be
noted that the said chargesheet is the only document which suggests a link between the defendant
No.1 and the fake email ID on which, the information was being forwarded from the email accounts
of the key employees of the plaintiff Company. However, the chargesheet by itself does not provide
any particulars of the confidential information as was routed to the fake email ID.
36. This Court in Navigators Logistics Ltd. (supra) has held as follows:
Signing Date:22.04.2022 11:42:00 ―22. What is thus for adjudication is, whether
there can be any copyright in a list of customers/clients with their contact
persons/numbers maintained by the service provider. Though the plaintiff has in the
plaint generally pleaded database pertaining to, running of business accounts
information, airway drawings, airway bills templates, plans, reports, taxes and other
financial information, process, financial/administrative and/or organizational
information as well as transactions based templates and internal notings and trade
secrets of the plaintiff company, but the said words/phrases, though high-sounding,
are vague and do not constitute a plea in law within the meaning of Order VI Rules 2,
4, 9 and Order VII Rules 1(e) and 7 of the Code of Civil Procedure, 1908 (CPC). In
this context, it may be also mentioned that using such high-sounding/phrases whichElcom Innovation Pvt Ltd vs Harish Sharma & Ors. on 21 April, 2022

in fact have no content or meaning, a large number of suits are filed in this Court
against the ex-employees and it has often been found that interim injunctions issued
restraining the ex-employees from divulging the same to any other person remain
unenforceable in the absence of particulars and with applications under Order
XXXIX Rule 2A of the CPC being filed with respect to all communications made by
such employees with others and with it being absolutely impossible for the Court to
determine whether the communication is in violation of the interim order. It is for
this reason only that Section 41(f) of the Specific Relief Act, 1963, and principles
whereof are applicable to temporary injunctions also, prohibits grant of injunction to
prevent, on the ground of nuisance, an act of which it is not reasonably clear that it
will be a nuisance. Similarly, without specifying the information, disclosure of which
is sought to be restrained, an injunction cannot be granted; rather I have wondered
the purport of the interim order dated 3rd June, 2016 in this suit, restraining the
defendants from utilizing, exploiting, copying, transmitting, publishing or releasing
any confidential information and trade secrets of the plaintiff to any entity Signing
Date:22.04.2022 11:42:00 for any purpose whatsoever, without specifying as to
which is that confidential information and trade secret. It is for this reason that I
have hereinabove observed that what is for adjudication is, whether list of
customers/clients with their contact numbers prepared/drawn up by a service
provider can be said to be a work in which such service provider can have copyright.
xxx xxx xxx
39. Confidentiality and secrecy is claimed in the same works in which copyright is
claimed viz. data, information and trade secrets residing in the electronic devices
without again specifying the particulars thereof or secrecy thereof. Mere mention of
research process, financial/administrative and/or organizational matter or
transaction or affairs of the company or invention or discovery or patent protection
does not satisfy the requirements of pleadings. The plaintiff as per its own admission
is engaged in the business of providing logistics and freight forwarding services and is
not engaged in any research work, it was incumbent for the plaintiff to, in the plaint,
plead how the data etc. in which confidentiality is claimed is different from data of
any other entity engaged in such business and what is secret about the same and what
steps besides the clause aforesaid in the letters of appointment of defendants no. 1 to
8 have been taken by the plaintiff to maintain secrecy/confidentiality thereof. The
plaint in this regard is vague and cannot be put to trial. The whole purpose of
pleadings in a civil suit is to let the opponent know the case to be met and which
crystallizes ultimately in issues on which the parties go to trial. If such rules of
pleadings are not to be adhered to, it will result in a fishing and roving enquiry and
enable a party to the suit to secure a victory by springing a surprise during the course
of trial.
Similarly, an injunction qua confidentiality as sought, even if granted would be vague and
unenforceable as aforesaid. This Court cannot pass such unenforceable Signing Date:22.04.2022Elcom Innovation Pvt Ltd vs Harish Sharma & Ors. on 21 April, 2022

11:42:00 order, the meaning whereof is not clear. It cannot be known, neither to the Court nor to the
defendant as to what the defendant is injuncted from doing.
37. In the present case as well, the plaintiff Company has in the plaint generally pleaded that the
defendant No.1 has access to the plaintiff Companys bidding prices for various government
tenders, its intellectual property rights and profit margins, upon the alleged misuse of which the
defendant No.1 is diverting contracts of the plaintiff Company to third party competing entities,
indulging in misleading the plaintiff Companys international clients with unsolicited and fallacious
information and instigating the plaintiff Companys suppliers to significantly increase their prices.
However, in light of the holding in Navigators Logistics Ltd. (supra), the said words/phrases are
vague. This Court cannot restrain the defendants from using, disclosing, disseminating, divulging,
circulating, selling or transferring, etc., in any manner, the proprietary, sensitive and highly
confidential information/data, including the intellectual property of the plaintiff Company, without
specifying as to which is that confidential information and data. If an injunction qua confidentiality
as sought is granted, the same would be vague and unenforceable. This Court cannot pass such an
unenforceable order, the meaning whereof is not clear at this stage, as it cannot be known to the
Court or to the defendants as to what the defendants are injuncted from doing.
38. In the case of Danieli Corus BV (supra), this Court has noted that the order of injunction as
sought could not be granted in general terms and in the said case, the injunction was restricted to
only those drawings and information that were relating to the proprietary items of the petitioner.
Signing Date:22.04.2022 11:42:00 Furthermore, in the case of Homag India Private Ltd. (supra), in
the facts and circumstances of the case, the High Court of Karnataka granted an order of temporary
injunction with reference to specific names stated in the product catalogue of the plaintiff therein for
a limited period to avoid a situation of grant of an order of temporary injunction on vague terms and
to avoid likelihood of the plaintiff therein misusing the order to curb the business activities of the
defendant therein. Even paragraph 11 of the order of this Court in Honeywell International Pvt. Ltd.
(supra), specifically notes that the large amount of confidential information, which had been
transferred by the defendant therein to an external media prior to returning of the laptop to the
plaintiff therein, had been contained in a tabular form from pages 39 to 62 of the documents and the
defendant therein was restrained from directly or indirectly disclosing, selling or transmitting the
confidential data, including the files mentioned at pages 39 to 62 of the documents to a third party.
Thus, in the said aforesaid case, the Court had been privy to the confidential information in respect
of which the injunction was sought. Consequently, none of the said judgments/orders come to the
aid of the plaintiff Company to warrant the grant of an interim injunction, restraining the
defendants from using, disclosing, disseminating, divulging, circulating, selling or transferring etc.,
in any manner, the proprietary sensitive and highly confidential information/data, including the
intellectual property of the plaintiff Company.
39. Therefore, in my view, the plaintiff Company has not made out a prima facie case in its favour
for the grant of an interim injunction.
40. Consequently, both, I.A. No.12977/2021 and I.A. No.7634/2021 are dismissed.Elcom Innovation Pvt Ltd vs Harish Sharma & Ors. on 21 April, 2022

Signing Date:22.04.2022 11:42:00 CS(OS) 288/2021
41. List on 8th September, 2022.
AMIT BANSAL, J.
APRIL 21, 2022 dk Signing Date:22.04.2022 11:42:00Elcom Innovation Pvt Ltd vs Harish Sharma & Ors. on 21 April, 2022

