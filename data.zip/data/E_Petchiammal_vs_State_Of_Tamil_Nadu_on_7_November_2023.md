E.Petchiammal vs State Of Tamil Nadu on 7 November, 2023
Author: M.Sundar
Bench: M.Sundar
    2023/MHC/5023
                                                                             HCP(MD)No.956 of 2023
                          BEFORE THE MADURAI BENCH OF MADRAS HIGH COURT
                                                 DATED: 07.11.2023
                                                       CORAM:
                                    THE HONOURABLE MR.JUSTICE M.SUNDAR
                                                         and
                                  THE HONOURABLE MR.JUSTICE R.SAKTHIVEL
                                             H.C.P.(MD)No.956 of 2023
                     E.Petchiammal                                             : Petitioner
                                                          Vs.
                     1.State of Tamil Nadu,
                       Rep. by the Additional Chief Secretary to Government,
                       Home, Prohibition and Excise Department,
                       Secretariat, Chennai – 600 009.
                     2.The District Collector and District Magistrate,
                       Thoothukudi District,
                       Thoothukudi.
                     3.The Superintendent of Prison,
                       Central Prison,
                       Palayamkottai, Tirunelveli.                               : Respondents
                     PRAYER: Petition filed under Article 226 of the Constitution of India to
                     issue a writ of Habeas Corpus, calling for the entire records connected with
                     the detention order passed in H.S.(M)Confdl No.95/2023 dated 27.07.2023
                     on the file of the 2nd respondent herein and quash the same and direct the
                     Page 1 of 10
https://www.mhc.tn.gov.in/judisE.Petchiammal vs State Of Tamil Nadu on 7 November, 2023

                                                                                 HCP(MD)No.956 of 2023
                     respondents to produce the detenu or body of the detenu namely the
                     petitioner's son ie., Subash, aged about 23 years, S/o.Subramanian, now
                     detained at the Central Prison, Palayamkottai before this Hon'ble Court and
                     set him at liberty forthwith.
                                             For Petitioner  : Mr.N.Pragalathan
                                             For Respondents : Mr.A.Thiruvadi Kumar
                                                                Additional Public Prosecutor
                                                           ORDER
[Order of the Court was made by M.SUNDAR, J.] When the captioned 'Habeas Corpus Petition'
[hereinafter 'HCP' for the sake of brevity] was listed in the Admission Board on 03.08.2023, a
Hon'ble Coordinate Division Bench made the following order in the Admission Board:
https://www.mhc.tn.gov.in/judis
2. It has now become necessary to set out a thumbnail sketch of factual matrix and we do so in the
paragraphs infra.
3. Today, the captioned matter is in the Final Hearing Board.
4. Mr.N.Pragalathan, learned counsel on record for HCP petitioner and Mr.A.Thiruvadi Kumar,
learned State Additional Public Prosecutor for all respondents are before us.
5. Captioned HCP has been filed by the mother of detenu assailing a 'preventive detention order
dated 27.07.2023 bearing H.S.(M)Confdl No. 95/2023' [hereinafter 'impugned preventive detention
order' for the sake of brevity and convenience]. To be noted, sponsoring authority has not been
arrayed as a respondent but we find that 'Station House Officer of Eral Police Station' is the
sponsoring authority [hereinafter 'Sponsoring Authority' for the sake of convenience and clarity]
and second respondent is the detaining authority as impugned preventive detention order has been
made by second respondent.
https://www.mhc.tn.gov.in/judis
6. Impugned preventive detention order has been made under 'The Tamil Nadu Prevention of
Dangerous Activities of Bootleggers, Cyber law offenders, Drug-offenders, Forest-offenders,
Goondas, Immoral traffic offenders, Sand-offenders, Sexual-offenders, Slum-grabbers and Video
Pirates Act, 1982 (Tamil Nadu Act No.14 of 1982)' [hereinafter 'Act 14 of 1982' for the sake of
convenience and clarity] on the premise that the detenu is a 'Sexual Offender' within the meaning of
Section 2(ggg) of Act 14 of 1982.
7. In the final hearing board today, though several points have been urged/ raised in the supportE.Petchiammal vs State Of Tamil Nadu on 7 November, 2023

affidavit qua captioned HCP, Mr.N.Pragalathan, learned counsel for HCP petitioner predicated his
campaign against the impugned preventive detention order on one point and that one point turns on
subjective satisfaction arrived at by the detaining authority with regard to imminent possibility of
being detenu enlarged on bail. Learned counsel submits that subjective satisfaction arrived at by the
detaining authority in this regard is impaired.
https://www.mhc.tn.gov.in/judis
8. Elaborating this point, learned counsel drew our attention to a portion of paragraph 6 of the
grounds of impugned Preventive Detention Order, which reads as follows:
'6.I am aware that the accused Subash was arrested in the ground case on 11.07.2023
and produced before the Court of Judicial Magistrate No.I, Srivaikundam on the
same day and forwarded to Judicial custody up to 24.07.2023 and lodged in Sub Jail
Srivaikundam. Further his remand was extended up to 07.08.2023. I am also aware
that accused Subash has tried to file a bail petition in the ground case registered in
Eral Police Station 71/2023 u/w. 376 (2) (g) IPC @ 376 (2) (g), 114 IPC before the
appropriate Court. In a similar case registered in Tiruchendur All Women Police
Station Cr.No.9/2017 u/s. 448, 376, 511 IPC bail was granted to the accused Gowthu
Mohaideen by the Principal Sessions Court Thoothukudi vide
Cr.M.P.(MD)No.3226/2017 dated 26.10.2017. I infer that it is very likely Subash is
coming out on bail in the above case by filing a bail petition before the appropriate
Courts, since bails are granted by Courts in such cases.......'
9. Adverting to the aforementioned portion of the impugned preventive detention order, learned
counsel submitted that the ground case on the file of Eral Police Station [Crime No.71 of 2023] is for
alleged https://www.mhc.tn.gov.in/judis offences under Sections 376(2) (g) of 'The Indian Penal
Code (45 of 1860)' [hereinafter 'IPC' for the sake of convenience and clarity], which was
subsequently altered into Sections 376(2) (g) and 114 IPC but for arriving at subjective satisfaction
as regards imminent possibility of the detenu being enlarged on bail, the detaining authority has
relied on Gowthu Mohaideen's case bail order dated 26.10.2017 on the file of Principal Sessions
Court, Thoothukudi. Adverting to Gowthu Mohaideen's case which has been furnished to the detenu
as part of the grounds booklet and the aforementioned portion of the grounds of impugned
preventive detention order, learned counsel submitted that Gowthu Mohaideen's csae is for 376 r/w
511 of IPC. Before we proceed further it is necessary to make it clear that in the aforementioned
extracted portion of the impugned grounds of detention, it is mentioned that a case was registered
under Sections 376, 511 IPC but a careful perusal of Gowthu Mohideen's bail order shows that it is
under Sections 448, 376 r/w 511 IPC.
10. Learned counsel submits that Section 511 IPC deals with attempt to commit offences which is
punishable with any imprisonment but it may not be necessary to go into that. Learned counsel
submits that as regards https://www.mhc.tn.gov.in/judis 376 IPC while the ground case is for
alleged offences under Sections 376(2)E.Petchiammal vs State Of Tamil Nadu on 7 November, 2023

(g) IPC @ 376(2) (g) and 114 IPC, Gowthu Mohideen's case is for Sections 376 r/w 511 IPC, the
comparison is a flawed exercise, is learned counsel's say. This flawed exercise has led to the
impairment qua subjective satisfaction is his further say.
11. In response to the aforementioned point raised by the learned counsel for HCP petitioner,
learned Additional Public Prosecutor submitted that Section 376 IPC is the nucleus of two cases ie.,
ground case as well as Gowthu Mohaideen's case.
12. We have carefully considered the rival points.
13. We find that though the nucleus of the offence is Section 376 IPC, an attempt to commit Section
376 offence cannot be compared with alleged Section 376 offence for arriving at subjective
satisfaction regarding discretionary relief of grant of bail. Therefore, we have no hesitation in
sustaining the argument of the learned counsel for the petitioner that the subjective satisfaction
exercise is flawed and therefore, the subjective https://www.mhc.tn.gov.in/judis satisfaction itself is
impaired which in turn means that the impugned preventive detention order is vitiated and it has
become liable for being dislodged in this habeas legal drill.
14. Before we write the operative portion of this order, we deem it appropriate to record the
submission of the learned Additional Public Prosecutor that as regards the ground case, charge
sheet has been filed on 15.09.2023 vide P.R.C.No.112 of 2023 on the file of Judicial Magistrate,
Srivaikundam. The learned Additional Public Prosecutor submits that the charge sheet has been
filed within the prescribed time and therefore, the detenu will have to seek regular bail under
Section 439 of 'The Code of Criminal Procedure, 1973 (2 of 1974)' [hereinafter 'Cr.PC' for the sake of
brevity and clarity] in the Court below. If the detenu seeks regular bail, we make it clear that the
Court below shall consider the bail plea under Section 439 Cr.PC on its own merits and in
accordance with law untrammelled by the instant order which has been made for the limited
purpose of testing the impugned preventive detention order in a habeas legal drill.
15. Ergo, the sequitur is, captioned HCP is allowed. Impugned https://www.mhc.tn.gov.in/judis
preventive detention order dated 27.07.2023 bearing reference H.S.(M) Confdl No.95/2023 made
by the second respondent is set aside and the detenu Thiru.Subash, male, aged 23 years, son of
Thiru.Subramanian, is directed to be set at liberty forthwith, if not required in connection with any
other case / cases. There shall be no order as to costs.
                                                                   [M.S.,J.] & [R.S.V.,J.]
                                                                         07.11.2023
                     Index          : Yes
                     Neutral Citation : YesE.Petchiammal vs State Of Tamil Nadu on 7 November, 2023

                     vsm
P.S: Registry to forthwith communicate this order to Jail authorities in Central Prison,
Palayamkottai.
M.SUNDAR, J.
https://www.mhc.tn.gov.in/judis and R.SAKTHIVEL, J.
vsm To
1.The Additional Chief Secretary to Government, Home, Prohibition and Excise Department,
Secretariat, Chennai – 600 009.
2.The District Collector and District Magistrate, Thoothukudi District, Thoothukudi.
3.The Superintendent of Prison, Central Prison, Palayamkottai, Tirunelveli.
4.Joint Secretary to Government, Public (Law and Order) Department, Secretariat, Chennai.
5.The Additional Public Prosecutor, Madurai Bench of Madras High Court, Madurai.
07.11.2023 https://www.mhc.tn.gov.in/judisE.Petchiammal vs State Of Tamil Nadu on 7 November, 2023

