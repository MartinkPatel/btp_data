Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum
on 5 July, 2019
Equivalent citations: AIRONLINE 2019 SC 396, 2019 (12) SCC 1, (2019) 3
BOMCR(CRI) 425, (2019) 3 MAD LJ(CRI) 764, (2019) 75 OCR 538, (2019) 8
SCALE 627
Author: Arun Mishra
Bench: Vineet Saran, Arun Mishra
                                                       1
                                                                            REPORTABLE
                                    IN THE SUPREME COURT OF INDIA
                            CRIMINAL APPELLATE/ ORIGINAL JURISDICTION
                                 CRIMINAL APPEAL NOS.140−151 OF 2012
         CENTRAL BUREAU OF INVESTIGATION & ANR. … APPELLANTS
                                                   VERSUS
         MOHD. PARVEZ ABDUL KAYUUM ETC.                                … RESPONDENTS
                                                    WITH
                                 CRIMINAL APPEAL NOS. 981−982 OF 2019
                         (Arising out of Special Leave Petition Nos.9028−9029 of 2016)
                                  CRIMINAL APPEAL NOS.83−94 OF 2012
                                    CRIMINAL APPEAL NO. 983 OF 2019
                            (Arising out of Special Leave Petition No.5530 of 2017)
                                                     AND
                                WRIT PETITION (CRIMINAL) NO.26 OF 2019
                                              JUDGMENT
ARUN MISHRA, J.Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

1. The facts, in short, envisage that initially two separate cases were registered by local Police
relating to the murder of Mr. Haren Pandya, ex−Home Minister for the State of Gujarat on
26.3.2003 and an attempt on the life of Mr. Jagdish Tiwari, a Viswa Hindu Parishad (VHP) leader of
Ahmedabad on 11.3.2003. The case of murder was initially registered on the basis of a complaint
brought by Mr. Janak Singh Parmar, vide FIR bearing I−C.R. No.272/2003 at Ellisbridge Police
Station, Ahmedabad, on 26.3.2003. After two days, the Government of Gujarat appointed the CBI to
investigate the matter on 28.3.2003. Later on the case of attempt to murder of Mr. Jagdish Tiwari
was also handed over to CBI and it was registered on 2.6.2003.
2. The evidence collected during the investigation in the cases revealed that both the incidents were
part of the same transaction and in pursuance of a well−designed common conspiracy, they were
committed. The motive was to spread terror amongst the Hindus. It was a part of an international
conspiracy. Mr. Haren Pandya was a BJP leader who earlier held the post of Home Minister. He had
played an active role in post−Godhra riots at Ahmedabad. It was alleged that he had led a mob
which demolished a Masjid at Paldi locality and resisted its reconstruction. One Mufti Sufiyan,
absconding accused, a preacher at Lal Masjid at Ahmedabad used his oratory skills, doctored video
CDs. depicting atrocities committed on Muslims and spread radical Islamic literature to instigate
and inculcate a strong feeling of hatred and retribution amongst the members of the Muslim
community against members of the Hindu community after post− Godhara riots. Said Mufti Sufiyan
in association with Rasul Khan Party, a defamed absconding accused of Ahmedabad allegedly, at
present residing at Karachi (Pakistan), and other close associates, Suhail Khan Pathan, also
absconding accused and Anas Machiswala (A−5) conspired to avenge the atrocities and
implemented the same in the form of a series of violent incidents. There was an incident of tiffin
bombs being planted in AMTS buses of Ahmedabad city on 29.5.2002 by a number of Muslim
youths which prompted Mufti Sufiyan, Sohail Khan Pathan and others. They planned for larger
conspiracy and contemplated incumbents to be sent for terrorist activities. In furtherance, thereof
several youths from Ahmedabad and Hyderabad had been sent to Pakistan in groups for arms
training with a view to indulge them in terrorist activities of larger magnitude on their return. Some
of them had passports and others allegedly crossed the Indo− Bangla Border illegally and went to
Pakistan where they obtained the training in the use of pistols, rifles, LMG, SLR, hand grenades,
explosive devices, recce, deceptions, etc. They were sent for the purpose of training and after
obtaining the same they returned to Ahmedabad in January 2003 and March 2003.
3. Rasul Khan @ Suleman before shifting to Karachi (Pakistan) resided at Hyderabad. He motivated
Mohmed Abdul Rauf (A−2), a local politician to participate in the conspiracy to avenge the alleged
atrocities committed on the Muslims in Gujarat and create terror in the minds of members of Hindu
community. On Suleman's instance, Mohmed Abdul Rauf selected, motivated and sent 14 boys from
Andhra Pradesh for arms training to Pakistan which included Asghar Ali (A1) a known criminal of
Hyderabad. They were trained in Pakistan and were motivated to work in Gujarat and create terror.
Asghar Ali wanted to commit big terror act and wanted to shift ultimately to Pakistan. He acted as
per the advice of Rasul Khan and Mufti Sufiyan and went to Udaipur from where he reached
Ahmedabad. Asghar Ali (A1) motivated his friend Mohmed Shafiuddin, a resident of Nalgonda,
Andhra Pradesh to join him at Ahmedabad. Conspirators decided to finish Mr. Jagdish Tiwari in the
first instance who allegedly played a leading role during the post−Godhra riots. It was decided thatCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

Asghar Ali and his friend Mohmed Shafiuddin with the necessary logistic support given by other
conspirators, shall attack Mr. Jagdish Tiwari on 11.3.2003.
4. A few days after the incident on 11.3.2003 a meeting was arranged which was attended by Mufti
Sufiyan and others to eliminate Mr. Haren Pandya and it was conveyed to other conspirators by
Sohail Khan on 17/18.3.2003 the minute aspects of the execution of the plan were finalised resulting
into execution of the same by Asghar Ali (A1) on 26.3.2003 with the support of other accused
persons at 7.30 a.m. opposite Law Garden. During the investigation as the conspiracy was revealed,
provisions of the Prevention of Terrorism Act, 2002 (in short ‘POTA') had been invoked and
accordingly, information was sent to the concerned Magistrate. The cases were made over to the
Special Court under the POTA. A joint charge sheet was filed in the matter on 8.9.2003.
5. Four accused persons were absconding that is A−13, A−14, A−18 and A−19 hence no charges could
be framed against them whereas other accused persons were charged for commission of offence
punishable under sections 120B, 302, 307, 201 read with section 120B of the Indian Penal Code,
1860 (for short, “the IPC”) and sections 25(1)(B)(a), 27(1) and section 5 of the Arms Act, 1959 (for
short, “the Arms Act”) and under sections 3(1), 3(2), 3(3), 3(4) and section 4 of POTA. The accused
persons abjured their guilt. The trial court proceeded with the trial of 12 accused persons. The
prosecution examined in all 122 witnesses. A plethora of documentary evidence has been filed.
Statements of accused persons under section 313 Cr.P.C. have been recorded. They denied the
charges and urged that the confessional statements have been recorded against each of them
forcibly and there is no element of voluntariness in the same. The case has been manufactured
against them to shield the real culprits. In defence 8 witnesses have been examined. The conviction
and sentence imposed by the trial court as modified by the High Court and the period have
undergone is as under:
Name of Conviction and sentence imposed Conviction and Sentence the by the Ld.
Trial Court sentence by the undergone Accused High Court Mohmed Convicted u/s
3(1) r/w 3(3), S.4 r/w Sentence awarded by 8 years Asgar Ali S.3(3) of POTA as well
as u/s 120−B of Trial Court u/s 307 [A−1] IPC and u/s.120−B r/w 302 IPC and r/w
120−B of IPC, u/s 120−B r/w 307 of IPC. u/s 4 r/w 3(2)(b) of Also convicted u/s
25(1−b)(a) and POTA and section 27(1) of Arms Act. 25[1−b](A) and The sentence for
the offence: section 27(1) upheld.
            u/s 120−B r/w 302, life imprisonment
            for twenty years.                          Acquitted for offence
            U/s 120−B r/w 307 – imprisonment of        u/s 120−B r/w 302
            10 years.                                  IPC and u/s 3(1)
            U/s 4 of POTA – Rigorous                   punishable u/s 3(2)
            imprisonment of seven years.               (a) of POTA.
            U/s 25 (1−b)(a) of Arms Act – five years
            u/s 27(1) of Arms Act – rigorous
            imprisonment for seven years
Mohmed     Convicted u/s 3(3) of POTA.                 Conviction confirmed 5 years
Abdul Rauf Sentence of rigorous imprisonment of        and maintained, fine
[A−2]      7 years.                                    upheld, rigorous
                                                       imprisonment ofCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

                                                       modifies and
                                                       reduced to the period
                                                       already undergone
                                                       by him in jail.
Mohmed     Convicted u/s 120−B r/w 307 of IPC.         Conviction u/s 120− Completed
Shafiuddin Sentence of rigorous imprisonment of        B r/w 307 of IPC    the
[A−3]      seven years.                                confirmed.          sentence
                                                                           period
Kalim       Convicted u/s 3(1) r/w 3(3) of POTA        Acquitted for           Undergoing
Ahmed @     as well as u/s 120−B of IPC and u/s        punishment u/s          life
KamiMulla   120−B r/w 302 IPC and u/s 120−B            120−B r/w 302 of        imprisonme
[A−4]       r/w 307 of IPC.                            IPC and u/s 3(1)        nt in
            Sentence of life imprisonment.             punishable u/s 3(2)     another
                                                       (a) of POTA.            case
                                                                               (Tiffinbox
                                                       Conviction u/s 3(3)     blast case)
                                                       of POTA confirmed
                                                       and maintained and
                                                       the imprisonment is
                                                       modified and
                                                       reduced to the period
                                                     undergone by him in
                                                     jail.
Anas       Convicted u/s 3(1) read with 3(3) of      Acquitted for
Machiswala POTA as well as u/s 120−B of IPC and      punishment u/s
[A−5]      u/s 120−B r/w 302 IPC and u/s 120−        120−B r/w 302 of
           B r/w 307 of IPC.                         IPC and u/s 3(1)
           Also convicted u/s 4 r/w s.3(3) of        punishable u/s 3(2)
           POTA and u/s 25(1−b)(a) of Arms Act.      (a) of POTA on the
           Sentence of life imprisonment.            same grounds that
           U/s 4 of POTA rigorous imprisonment       the same was not
           for five years.                           proved beyond a
           U/s 25(1−b)(a) of Arms Act five years.    reasonable doubt.
Mohmed     Convicted u/s 3(1) read with 3(2) of      Acquitted for            8 years
Yunus      POTA as well as u/s 120−B of IPC and      punishment u/s           without
Sareshwala u/s 120−B r/w 302 IPC and u/s 120−        120−B r/w 302 of         parole
           B r/w 307 of IPC.                         IPC and u/s 3(1)
           Also convicted u/s 4 r/w s.3(3) of        punishable u/s 3(2)
           POTA and u/s 25(1−b) (a) of Arms Act.     (a) of POTA.
           Sentence of life imprisonment.
           u.s 4 of POTA rigorous imprisonment       Conviction recorded
           for five years.                           by Trial Court for the
           U/s 25(1−b)(a) of Arms Act five years.    offences punishable
                                                     under section 4 of
                                                     the POTA and
section 25[1−b](a) of
                                                     the Arms Act and
                                                     sentence awarded to
                                                     him is confirmed and
                                                     maintained.Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

Rehan         Convicted u/s 3(1) read with 3(3) of   Acquitted for         8 years
Puthawala     POTA as well as u/s 120−B of IPC and   punishment u/s        without
[A−7]         u/s 120−B r/w 302 IPC and u/s 120−     120−B r/w 302 of      parole
              B r/w 307 of IPC.                      IPC and u/s 3(1)
              Sentence of Life imprisonment.         punishable.
                                                     Conviction u/s 3(3)
                                                     of POTA confirmed
                                                     and maintained and
                                                     the imprisonment is
                                                     modified and
                                                     reduced to the period
                                                     already undergone in
                                                     jail.
Mohmed        Convicted u/s 3(1) read with 3(3) of   Acquitted for            8 years
Riyaz [A−8]   POTA as well as u/s 120−B of IPC and   punishment u/s           without
              u/s 120−B r/w 302 IPC and u/s 120−     120−B r/w 302 of         parole
              B r/w 307 of IPC.                      IPC and u/s 3(1)
             Sentence of life imprisonment          punishable u/s 3(2)
                                                    (a) of POTA on the
                                                    grounds that the
                                                    same was not proved
                                                    beyond a reasonable
                                                    ground.
                                                    Conviction u/s 3(3)
                                                    of POTA confirmed
                                                    and maintained and
                                                    the imprisonment is
                                                    modified and
                                                    reduced to the period
                                                    already undergone in
                                                    jail.
Mohmed       Convicted u/s 3(1) read with 3(3) of   Acquitted for           8 years
Parvez       POTA as well as u/s 120−B of IPC and   punishment u/s          without
Shaikh [A−   u/s 120−B r/w 302 IPC and u/s 120−     120−B r/w 302 of        parole
9]           B r/w 307 of IPC.                      IPC and u/s 3(1)
             Sentence of life imprisonment          punishable u/s 3(2)
                                                    (a) of POTA.
                                                    Conviction u/s 3(3)
                                                    of POTA confirmed
                                                    and maintained and
                                                    the imprisonment is
                                                    modified and
                                                    reduced to the period
                                                    already undergone in
                                                    jail.
Parvez       Convicted u/s 3(1) read with 3(3) of   Acquitted for           8 years
Khan         POTA as well as u/s 120−B of IPC and   punishment u/s          without
Pathan [A−   u/s 120−B r/w 302 IPC and u/s 120−     120−B r/w 302 of        paroleCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

10]          B r/w 307 of IPC.                      IPC and u/s 3(1)
             Sentence of life imprisonment          punishable u/s 3(2)
                                                    (a) of POTA.
                                                    Conviction u/s 3(3)
                                                    of POTA confirmed
                                                    and maintained and
                                                    the imprisonment is
                                                    modified and
                                                    reduced to the period
                                                    already undergone in
                                                    jail.
Mohmed       Convicted u/s 3(1) read with 3(3) of   Acquitted for           8 years
Faruq [A−    POTA as well as u/s 120−B of IPC and   punishment u/s        without
11]          u/s 120−B r/w 302 IPC and u/s 120−     120−B r/w 302 of      parole
             B r/w 307 of IPC.                      IPC and u/s 3(1)
             Sentence of life imprisonment          punishable u/s 3(2)
                                                    (a) of POTA.
                                                    Conviction u/s 3(3)
                                                    of POTA confirmed
                                                    and maintained and
                                                    the imprisonment is
                                                    modified and
                                                    reduced to the period
                                                    already undergone in
                                                    jail.
Shahnavaz    Convicted u/s 3(1) 3(3) of POTA.       Conviction and         Completed
Gandhi [A−   Sentence of Rigorous imprisonment      sentence u/s 3(3) of   the
12]          for five years.                        POTA is confirmed      sentence
                                                    and maintained.        period.
6. The High Court on appeal has dismissed the appeal with respect to conviction
under section 307 read with section 120−B, IPC and section 4 read with section
3(2)(b), section 3(3) of POTA and section 25(1)(B)(a), section 27(1) of Arms Act.
However, it has allowed the appeals in part and set aside the judgment of conviction
with respect to the murder of Haren Pandya for the offence registered under section
302 read with section 120−B of IPC and section 3(1) of POTA against all the accused
persons. The CBI has come up in appeals with respect to the murder of Mr. Haren
Pandya.
7. It is pertinent to mention that as against accused A−2, Mohmed Abdul Rauf son of
Mohmed Abdul Kadar and A−12, Shah Navaz Gandhi son of Mohmed Gandhi, the
trial court held them guilty for offence under section 3(3) of POTA and has given the
benefit of doubt of all other offences under the POTA as well as under the IPC. A−3,Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

Mohmed Shafiuddin son of Late Yusuf Ali was held guilty for the offence punishable
under section 120B read with section 307 IPC, and was given the benefit of doubt for
all the offences he has been charged with under the POTA as well as under the IPC.
Against the acquittal of aforesaid 3 persons under various sections, admittedly, no
appeal was preferred by the CBI before the High Court. Against the conviction of A−
2−Mohmed Abdul Rauf son of Mohmed Abdul Kadar under section 3(3) of POTA, the
question for consideration before this Court is whether the sentence imposed by the
trial court under section 3(3) was proper or the sentence reduced by the High Court
on appeal by accused.
8. As per the prosecution case, as reflected in the common charge sheet, the two cases
are the outcome of deep−rooted criminal conspiracy to cause communal disharmony
and to create fear in the Hindu community. The prosecution has alleged as under:
(i) A meeting was held in April/ May 2002 at Lal Masjid which was attended by Mufti
Sufiyan (A−13 absconding accused), a Muslim Cleric (Kaleem Ahmed, A−4) and Anas
Machiswala (A−5).
During the said meeting, A−13 urged the persons present there to avenge the killing of Muslims
during the riots and strike terror in the minds of the Hindu community by committing violent acts.
It is to be noted that A−13 exploited the sentiments of Muslims by showing them doctored videos
and CDs. and literature showing dead bodies of victims of Naroda Patia, burnt houses, dead bodies,
plundered mosques, etc. and the said material has been duly recovered during the investigation.
(ii) In furtherance of criminal conspiracy on 29.5.2002, tiffin box bombs were planted in crowded
buses destined for Hindu localities by A−4, A−5 with the assistance of Mohd. Yunus, Abdul Rahim
Sarshewala (A−5), Rehan Abdul Maji Puthawala (A−7), Mohd. Riaz (A−8), Mohd. Parvel Abdul
Qayum Sheikh (A−9), Shahnawaj Gandhi (A−12) and others. Accordingly, POTA Case No.7 & 9 were
registered and pertinently, A−4 and A−5 have been convicted by the High Court in the aforesaid case
and they are undergoing life imprisonment in the aforesaid matter.
(iii) In September−October, 2002 accused Rasool Khan Party (A−18−absconding), a wanted
criminal of Ahmedabad while living in Hyderabad from 1994 till 2002 came in touch with Mohd.
Abdul Rauf (A−2) and instigated him to send Muslim boys to Pakistan for training in arms. A−2
accordingly selected 14 boys which include Asghar Ali (A−1), a notorious criminal in about 10 cases
in Hyderabad and they were sent to Pakistan for arms training.
(iv) In November 2002, A−5, A−14, and A−12 were sent to Pakistan via Mumbai and Dubai.
(v) After returning from Pakistan, A−1 reached Udaipur on 31.12.2002 and stayed at Muslim
Musafarkhana. After staying for some time, he returned to Hyderabad due to paucity of fund where
he again received a message from A−18 through emails directing him to reach Udaipur and contact
PW−29. He accordingly returned to Udaipur on 20.1.2003.Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

(vi) On 24.1.2003, PW−49, along with A−11 and A−13 went to Udaipur in a silver−colored Tata
Indica car of PW−38 and brought A−1 to Ahmedabad. Later, towards the end of January/beginning
of February, A−1 and A−3 were shifted to Flat No. 401, Royal Apartment, Rakhial by A−10 and A−11.
Sometime before 5/6.3.2003, a meeting was held at Lal Masjid and it was decided to kill Jagdish
Tiwari (PW−39). A−14 took A−1 and A−3 to the shop of A−4 where they were introduced with A−4
and A−5. A−4 handed over two pistols each to A−1 and A−3 with live cartridges. Around 9.3.2003,
A−10 pointed out Jagdish Tiwari at his shop to A−1, and on 9.3.2003, a meeting was held at Jaliwali
Masjid where A− 14 disclosed that Jagdish Tiwari would be their next target. A−1 and A−3 waited for
the arrival of Jagdish Tiwari to kill him, but he did not pass through the scheduled route.
(vii) Thereafter, on 11.3.2003, at around 9.15 PM, A−1 and A−3 went to the shop of PW−39 (Jagdish
Tiwari) and asked for a strip of the sorbitrate tablet. When PW−39 bent down to take out the said
strip, A−1 fired his pistol at him, which hit the metal buckle of his belt, and after ricocheting, entered
his body near his navel.
(viii) Sometime later, on 15/16.3.2003, A−13, in consultation with A−14 disclosed to A−5 that the
next target would be Haren Pandya, who used to come to Law Garden for a walk. On 17/18.3.2003,
at a meeting at Juni Jama Masjid, it was disclosed that Haren Pandya was the next target. On
22.3.2003, another meeting was held at Juni Masjid. On 23.3.2003, at around 7 a.m., A−9 and A−6
then visited the Law Garden where A−1 also joined them, but they could not see Haren Pandya.
(ix) On 24.3.2003, A−9 visited Law Garden in the morning on his motorcycle and saw Haren
Pandya. He noted down the number of the vehicle that Haren Pandya was in, as GJ−1AP−4606.
Later, a meeting was held near Juni Jama Masjid.
(x) An unsuccessful attempt was made to kill Haren Pandya on 25.3.2003. Again, the next day on
26.3.2003, Haren Pandya was killed.
9. On receiving information, an FIR was registered by PW−101 at Ellisbridge Police Station. Police
patrol jeep came around 10.40 a.m. followed by the arrival of PW−101 from Navrangpura Police
Station. The deceased Haren Pandya was immediately taken to the nearby V.S. Hospital.
Simultaneously, PW−1 lodged a complaint with PW−101 regarding the murder of Haren Pandya. At
11.30 a.m. the same was registered at Ellisbridge PS. The inquest was prepared by PW−101 followed
by post mortem of deceased by a panel of 4 doctors held between 2.15 p.m. and 4.50 p.m. on the
same day. Inquest of the crime scene was prepared by PW−101 and statement of eye−witness PW−
55 was also recorded the same day.
10. After transfer of investigation to the CBI on 28.3.2003, the accused persons were arrested and
their confessional statements were recorded under section 32 of POTA from which as per the
prosecution are the modus operandi and criminal conspiracy is amply proved.
11. On 2/3.9.2003, a letter was written to the Commissioner of Police, Ahmedabad for according
sanction under Section 39 of the Arms Act in respect of A−1 (Mohmed Asghar Ali), A−3 (Mohmed
Shafiuddin), A−5 (Anas Machiswala) and A−6 (Mohmed Yunus Sareshwala) (Exhibit 684). OnCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

5.9.2003, the sanction of the Commission of Police, Ahmedabad, under Section 39 of the Arms Act
was accorded (Exhibit 685). On 6.9.2003, Government of Gujarat accorded sanction under Section
50 of the POTA for prosecuting accused persons (Exhibit 697). On 8.9.2003, combined charge−
sheet was filed against A−1 to A−19 in the Court of Special Judge, POTA Cases, Ahmedabad. On
29.8.2005, A−15, A−16 and A−17 were exonerated by the Central POTA Review Committee and their
trial was separated. As many as 122 witnesses were examined by the prosecution in order to
substantiate the charges against the accused persons. On 25.6.2007, two court witnesses were
examined by the Court and defence had examined eight witnesses. The learned Special Judge
(POTA) vide judgment dated 29.8.2011 convicted all the 12 accused persons. Nine of them were
awarded life imprisonment and the remaining three were awarded sentences ranging from 5 to 7
years rigorous imprisonment. The High Court has acquitted all the accused persons from the charge
under Section 302 IPC.
SUBMISSIONS   ON     BEHALF        OF    CENTRAL      BUREAU      OF
INVESTIGATION (C.B.I.)
12. The prosecution submitted that confessional statements are corroborated in material particulars
by the other evidence. On behalf of the CBI, Mr. Tushar Mehta learned Solicitor General urged that
prosecution has proved the offences. The trial court had the advantage of looking at the demeanour
of the witnesses. He has urged arguments on the following aspects:
A: Larger Conspiracy:
(i) The prosecution by leading cogent evidence proved to hatch of larger criminal
conspiracy between all the accused persons along with the absconding accused
persons to kill Shri Haren Pandya (deceased) who was a Hindu leader in the
aftermath of Godhra riots to strike terror in a section of people viz. Hindus, thereby
committing an offence under section 3(1) of POTA and section 120−B of IPC.
(ii) Confessions of the accused persons recorded under section 32 of POTA amply
prove the role of every accused person in a criminal conspiracy.
(iii) Confessions of all the accused persons recorded under section 32 of POTA are voluntary and
thus the same can be relied upon.
(iv) All the safeguards as provided under section 32 of POTA have been duly complied with at the
time of recording of confessions and thus the same is admissible in evidence.
(v) Subsequent retraction of confessional statements by the accused persons is of no consequence.
(vi) Tiffin box blast in POTA Case Nos.7 & 9 of 2003 and the conviction of A−4 & A−5 in the said
POTA case, not only proves their criminal antecedents but it is also a material event in the chain of
events with respect to criminal conspiracy to create terror among Hindus by violent means.Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

(vii) Attack on Sh. Jagdish Tiwari (PW−39) by A−1 using a firearm along with A−3 in conspiracy
with the other accused persons, whose conviction under section 307 read with 120−B have also been
upheld by the High Court forms part of the same chain of criminal conspiracy to create terror in the
community of Hindus.
(viii) Call records of the accused persons during the entire period of conspiracy and the tower
location of the phones of the accused persons near the Law Garden on the day of the murder of the
deceased is a piece of strong circumstantial evidence against the accused persons.
(B) It was further urged that the prosecution by leading cogent evidence proved that in pursuance of
the said criminal conspiracy, A−1 (Asghar Ali) committed murder of the deceased on 26.3.2003 and
therefore all the accused persons committed offences under section 302 IPC to read with section
120B IPC and offences under section 3(1) and 3(3) of POTA. In this regard the following points have
been urged:
(a) PW−55 who is an eye witness stated to have seen A−1 shooting the deceased is a
reliable and truthful witness.
(b) Post mortem report which was conducted by a panel of 4 doctors, which was duly
proved by Dr. Pratik Patel (PW−8) proved 7 gunshot injuries on the body of deceased
caused by 5 bullets.
(c) The forensic and biological report proves the presence of blood of the deceased inside the car.
(d) The weapon used by A−1 in the murder of the deceased and the clothes worn by A−1 at the time
of the commission of the offence was duly recovered at the instance of A−1 from Kamar Flats.
(e) PW−75 ballistic expert duly proved that the bullets recovered from the body of the deceased were
fired from the same revolver which was recovered at the instance of A−1.
(f) The motorbike used by A−1 and A−6 at the time of the commission of murder of the deceased was
duly recovered.
(g) PW−55 who is an eye witness to the murder of the deceased and PW−39, who is an injured
witness of the attempt to murder of his own life, duly identified A−1 as the assailant in the test
identification parade before the Executive Magistrate (PW−14).
(h) The commission of the offence of attempt to murder on Jagdish Tiwari (PW−39) by A−1 along
with A−3 by using a firearm on 6.3.2003, which offence is duly proved and has attained finality,
proves the presence of A−1 and A−3 at Ahmedabad during the relevant period.
(i) PW−95 proves the presence of A−1 in Ahmedabad on 27.3.2003 as well as the fact that the phone
No. 9825491421 was being used by A−1 on 27.3.2003 i.e. next day of the murder of the deceased.Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

(C) It was submitted that the aforesaid witness Yusufbhai (PW−95) is an independent witness who
stayed in the same “Royal Apartments” as A−1. He in his testimony proved that A−1 was using the
mobile No.9825491421 on 27.3.2003 i.e. next day to the murder of the deceased as he made a phone
call from the aforesaid number to his brother on 27.3.2003, which has appeared in the call records
of the said number. This witness identified A−1 in his deposition before the court. The relevant
portion of his deposition is reproduced hereinbelow:
"3. On the next day of the murder of Mr. Haren Pandya, Vishwa Hindu Parishad has
called for band, I and my brother as per the direction of my parents were doing
scooter coloring work at Chandlodiya. I was going to call my brother that does not go
on work at that time Afdan met me on the stairs, he asked me that where are you
going? I told him reason at that time he has stated that you make calls from his
mobile. Therefore, I made a call from his mobile to Babubhai Dhobi who is staying
near my brother and we have a good relationship with him and informed him about
Salimbhai. Phone Number of Babubhai Dhobi is 7525518. I do not know the mobile
No. of Afdan. Due to so many time has been passed perhaps I cannot identify Afdan
and his friends. Although I will try. I can identify Afdan. At this stage, the witness has
identified the accused no. 1 Mr. Asgar Ali Afdan.” Learned Solicitor General
submitted that there is gross perversity in the impugned judgment of the High Court
which is against the evidence adduced as well as the settled principles of law.
SUBMISSIONS ON BEHALF OF ACCUSED
13. On behalf of the accused persons, it has been submitted by the galaxy of learned
senior counsel that the scene of murder does not inspire confidence. The murder of
Mr. Haren Pandya has not taken place in Maruti 800 car, no gunshot residue has
been found, neither any bullet has been recovered from the car. The post mortem
report does not tally with the ocular evidence. First information report has not been
lodged by the so−called witness PW−55 Anil Yadram Patel. He cannot be said to be a
reliable witness. His testimony stands discredited by the timing and conduct is
inconsistent with that of an eye−witness. There are contradictions on the position in
which Mr. Pandya’s body was lying in the car. Identification of A−1 and identifying
sketch of Ex. 620, inferences arrived at from the sketch clearly prove that it was
someone else and A−1 has not committed the offence. CBI site map dated 29.3.2003
has been manipulated. The adverse inference has to be drawn against the prosecution
for not producing the material witnesses.
14. The testimony of PW−55 is negatived by the forensic evidence.
The murder was not possible in the Maruti car with the window opening, as stated by
PW−55. The CBI has conjectured on lack of blood and GSR inside and on the car. The
count of bullets fired is not matching either with the ocular or medical evidence. The
ballistic evidence indicates that there was bullets mismatch. The scientific tests for
jacketed/unjacketed bullets were not done. There was deformation of bullets, and theCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

weapon of offence is doubtful. No convincing ballistic matching of the alleged
revolver with bullets was done. Recovery of revolver and pistol is doubtful. It was also
submitted on that reason the case under POTA is different from TADA. The learned
Magistrate while confirming the proceedings as to the confessional statement has
committed illegality. Recording of confessions is not as per legal requirement under
Section 32. There are other factors discrediting PW−21. There are several
contradictions within the confessional statement and there is no corroboration. As
such it would not be safe to act upon so−called confessions which were not voluntary
in nature and rendered inadmissible due to non− compliance with provisions of
section 32 of POTA. The arrest of A−1 is doubtful. No confession under POTA of any
other accused is admissible against A−1. Call records are not reliable. The prosecution
has withheld evidence. There is tampering with the same, and interpolation has been
made in spot map, rendering the prosecution case unreliable and improbable. The
vital flaws in the prosecution should lead to the benefit of the doubt to the accused.
There are irreconcilable inconsistencies in the prosecution case. Several vital objects
have not been produced by the CBI. The forensic evidence belies the ocular evidence.
The course followed by the High Court is legally sound and cannot be disturbed in the
case of acquittal. Even if two views are possible, the one adopted by the High Court
cannot be interfered with in an appeal against acquittal.
IN RE: FACTS AS TO INVESTIGATION AND LARGER CONSPIRACY TO CREATE
TERROR
15. The evidence has been adduced in the case as to the conspiracy which leads to the
attempt to murder of Mr. Jagdish Tiwari, PW−39 and thereafter fatal attack on
Haren Pandya, accused are associated with it up to the murder and finally to the
escape of the assailants after the murder. The evidence evinces training in Pakistan,
the various meetings at Masjids, etc. of various accused persons from time to time.
There is evidence of confessional statements of convicts, communication over e−mail,
seizure of documentary literature at the time of arrest, there is also evidence of
providing logistical support and other various types of facilitation, providing money
by cash or cheque in respect of accommodation, rent, transportation at Ahmedabad
as well as at other places. Evidence is also available with respect to providing mobile
phones, transportation, and providing of motorcycles, etc. On the basis of the
confessional statement, recoveries and seizures had been made as per the disclosure
statements including the seizure of computer hard discs from Cyber Cafes. There is
the recovery of documentary evidence also, passenger books proved by hotel caterers,
PC owners and opinion of handwriting experts. There is direct and circumstantial
evidence as to the involvement of other accused with A−1 in the commission of
attempt to murder of PW−39 and murder of the deceased Haren Pandya. There is
evidence of doing a recce of the Law Garden which used to be frequented by the
deceased for taking morning walks, mobile calls bear the time of the fatal attack by
the accused persons on the deceased. Besides the mobile tower location of the mobile
phone and data of telephone use even shortly before and after the attack on PW−39Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

as well as on deceased Haren Pandya. In the light of the aforesaid evidence which has
been referred to in detail, to be discussed hereinafter.
16. We first consider whether the criminal conspiracy in order to commit the murder
of Mr. Haren Pandya, to strike terror in a section of people has been proved, as such
the accused has committed the offence under section 3 of POTA.
17. It has been urged that section 3(1), 3(2), 3(3) and 3(4) and section 4 of POTA have
rightly been invoked in the present case.
Accused persons have been charged for criminal conspiracy under section 120B, IPC
and for conspiracy to commit acts of terrorism under section 3(1) and 3(3) and
section 4 of the POTA. It is urged that there is reasonable ground to believe that when
two or more persons have conspired together to commit any offence, anything said,
done or written by any one of them in reference to their common intention, is a
relevant fact as against each conspirator. It is submitted that the accused persons
with an intention to strike terror in a section of people, used fire−arms, caused
murder of Mr. Haren Pandya and attempted to murder Jagdish Tiwari, PW−39.
Thus, they committed offence under section 3(1) of POTA. The Central Pota Review
Committee has upheld the invocation of the provisions of POTA. The High Court has
also upheld the conviction of the accused persons under section 3(3) and section 4 of
POTA and has erred in acquitting the accused persons under section 3(1) and 3(2)(a)
of POTA. Mr. Tushar Mehta learned Solicitor General has submitted that section
120−B of IPC defines a criminal conspiracy as a distinct offence. He has relied on as
to criminal conspiracy by Dr. Sri Hari Singh Gour in his well−known ‘Commentary on
Penal Law of India’, (Vol. 2, 11 th Edn.
Page 1138) summed up the legal position in the following words:
“In order to constitute a single general conspiracy, there must be a common design.
Each conspirator plays his separate part in one integrated and united effort to
achieve the common purpose. Each one is aware that he has a part to play in a
general conspiracy though he may not know all its secrets or the means by which the
common purpose is to be accomplished. The evil scheme may be promoted by a few,
some may drop out and some may join at a later stage, but the conspiracy continues
until it is broken up. The conspiracy may develop in successive stages. There may be
a general plan to accomplish the common design by such means as may from time to
time be found expedient.
. In Yashpal Mittal vs. State of Punjab reported in [1977 (4) SCC 540], Goswami, J,
speaking for a three−judge Bench analysed the legal position relating to criminal
conspiracy. At pages 610−611, observed as under:Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

"the very agreement, the concert or league is the ingredient of the offence." and that
"it is not necessary that all the conspirators must know each and every detail of the
conspiracy." It was then observed that "there must be unity of object or purpose but
there may be a plurality of means sometimes even unknown to one another, amongst
the conspirators."
(emphasis supplied)
18. He has also referred to the case of State v. Nalini, 1999 (5) SCC 253, Hon. S.S.M. Quadri, J., after
a survey of case law, made the following pertinent observations:
"662….It is not necessary that all the conspirators should participate from the
inception to the end of the conspiracy; some may join the conspiracy after the time
when such intention was first entertained by any one of them and some others may
quit from the conspiracy. All of them cannot but be treated as conspirators. Where in
pursuance of the agreement the conspirators commit offences individually or adopt
illegal means to do a legal act which has a nexus to the object of conspiracy, all of
them will be liable for such offences even if some of them have not actively
participated in the commission of those offences."
19. In the matter of Yakub Abdul Razak Memon vs. State of Maharashtra reported in (2013) 13 SCC
1, where a large number of accused were involved in a criminal conspiracy having played a distinct
role, this Court held that where an accused allegedly transported weapons to the training centre,
carried trainees, the question arises; whether this amounted to overt acts contributing to common
object of the conspiracy. What is to be seen is that such an act formed a crucial part of the chain
leading to creating terror, engaging in violence, or waging a war against State. The knowledge of the
murder or attack on the victim in particular therefore was not a sine qua non. This Court in the
aforesaid matter further while upholding the order of the designated Court observed as under:
“2485. As the Respondent has been awarded sufficient punishment under different
heads of Sections 3(3) and 6 TADA, and the said offences themselves are a part of the
conspiracy, and the learned Designated Court has divided the conspiracy into various
components, considering the present case, where the accused were either involved in
participating in the various conspiratorial meetings, receiving training in the
handling of arms, their active participation in the throwing of bombs or parking of
vehicles fitted with explosives, or where the accused persons participated only in the
landing and transportation of contraband, but were not aware of the contents of the
said contraband, and further, another category, where the accused had knowledge of
the contents of the contraband, but did not participate either in the conspiratorial
meetings held, or in any actual incident of any terrorist activity, and has awarded
different punishments accordingly, we do not see any cogent reason to allow the said
appeal. The appeal is hence, dismissed.” (emphasis supplied) Relying upon the
aforesaid principles of law in the present case, it is submitted that all the accused
persons were in constant touch with each other, wherein different roles wereCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

designated to every accused person in providing support to A−1 for commission of
offence such as providing money, arranging weapons, arranging phones and fake SIM
cards, logistics and accommodation, the identification of targets, etc.
20. In September/October 2002, A−1 (Mohmed Asgar Ali) along with other 13 boys of Andhra
Pradesh was sent to Karachi, Pakistan by A−2 (Mohmed Abdul Rauf) for obtaining arms training on
the instigation of A−18. At Karachi, he was directed to reach Ahmedabad via Udaipur to take
revenge of the alleged atrocities committed on Muslims during riots by killing Hindu leaders. The
same had been proved by Exhibit 253 i.e., confessional statement of A−1 (Mohmed Asgar Ali) and
Exhibit 247 i.e., confessional statement of A−2 (Mohmed Abdul Rauf).
21. After return from Pakistan, A−1 (Mohmed Asgar Ali) stayed at Muslim Musafirkhana at Udaipur
from 31.12.2002 to 5.1.2003. It had been proved by Exhibit 298 i.e., the visitor register reflecting
entry no.5846 made in respect of his stay; Exhibit 297 i.e., deposition of Mohd. Jamil IS, Manager,
Muslim Musafirkhana, regarding his stay at Muslim Musafirkhana; positive opinion given by Dr.
Mohmed Aizaz Ali, CFSL, Delhi (PW−88) with respect to the handwriting of A−1 (Mohmed Asgar
Ali) at entry no.5846 Exhibit 298. Facts regarding stay of A−1 (Mohmed Asgar Ali) had also been
corroborated by Mohammed Jamil Nasir Mohammed (PW−30) and Dr. Mohmed Aizaz Ali (PW−88)
and Exhibit 253, which is the confessional statement of A−1 (Mohmed Asgar Ali). Thereafter, he
returned to Hyderabad from Udaipur and took Rs.2,000−3,000/− from A−2 (Mohmed Abdul Rauf).
He was directed by A−18 through email to reach Udaipur and to contact Usman Khan Nawab Khan
(PW−29).
22. A−1 (Mohmed Asgar Ali) reached Udaipur on 20.1.2003 and stayed at Muslim Musafirkhana for
a day. The same had been proved by Exhibit No.299 i.e., the visitor register showing entry No.8682;
Exhibit 297 i.e., deposition of Mohmed Jamil Nasir Mohammed (PW−
30), Manager of Muslim Musafirkhana regarding his stay at Muslim Musafirkhana; positive opinion
given by Dr. Mohmed Aizaz Ali, CFSL, Delhi (PW−88) with respect to handwriting of A−1 (Mohmed
Asgar Ali) at entry no.8682 Exhibit 299. Facts regarding stay of A−1 (Mohmed Asgar Ali) had also
been corroborated by Mohammed Jamil Nasir Mohammed (PW−30) and Dr. Mohmed Aizaz Ali
(PW−88) and Exhibit 253, which is the confessional statement of A−1 (Mohmed Asgar Ali).
23. For 2−3 days, he stayed at the residence of Usman Khan Nawab Khan (PW−29), which had been
corroborated by Usman Khan Nawab Khan (PW−29) in Court also. During the stay of A−1 (Mohmed
Asgar Ali) at Udaipur, he used to visit Netsavy Cyber Café situated at Chetak Circle, Udaipur for
operating emails. While in Udaipur, A−1 (Mohmed Asgar Ali) telephonically contacted A−3
(Mohmed Shafiuddin) and provided him the Landline Number of Usman Khan Nawab Khan (PW−
29) and mobile number 9426039937 of A−14 (Sohail Khan Pathan) and asked him to come to
Ahmedabad. The same had been proved by Exhibit 250 i.e., confessional statement of A−3
(Mohmed Shafiuddin).Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

24. On 23.1.2003, A−3 (Mohmed Shafiuddin) reached Udaipur and stayed at Muslim Musafirkhana
for a day. It had been proved by Exhibit 300 i.e., visitor register showing entry no.8699 made in
respect of stay of A−3 (Mohmed Shafiuddin); Exhibit 297 i.e., deposition of Mohammed Jamil Nasir
Mohammed (PW−30), Manager of Muslim Musafirkhana regarding stay of A−3 (Mohmed
Shafiuddin; and positive opinion of Dr. Mohmed Aizaz Ali, CFSL, Delhi, PW−88 regarding
handwriting of A−3 (Mohmed Shafiuddin) at entry no.8699 Exhibit 300. Mohammed Sharif Amir
Mohammed (PW−31), owner of PCO situated in the basement of Muslim Musafirkhana had also
proved stay of A−3 (Mohmed Shafiuddin) at Muslim Musafirkhana, Udaipur.
25. On 24.1.2003, Turk Salim Pasa Majarirule Islam (PW−49) along with A−11 (Mohmed Faruq)
and A−13 (Mufti Sufiyan) went to Udaipur in Tata Indica Car (silver color) of Mohmed Muslim
Mohmed Shabbir Ansari (PW−38) and brought A−1 (Mohmed Asgar Ali) to Ahmedabad. This fact
had been proved by Exhibit 365 i.e., the deposition of Turk Salim Pasa Majarirule Islam (PW−49)
who admitted that they had brought A−1 (Mohmed Asgar Ali) to Ahmedabad. At Ahmedabad, A−1
(Mohmed Asgar Ali) stayed in a room at Lokhandwalichali, Bapunagar owned by Mushtaq Ahmed
Munir Ahmed Ansari (PW−63). It had also been proved by Exhibit 652 though Mushtaq Ahmed
Munir Ahmed Ansari (PW−63) has turned hostile, who admitted that A−1 (Mohmed Asgar Ali) had
stayed at his house on the request of A−14 (Sohail Khan Pathan).
25(a). On 25.1.2003, A−3 (Mohmed Saifuddin) reached Ahmedabad from Udaipur and stayed at
Hotel Garden. Stay of A−3 (Mohmed Saifuddin) at Hotel Garden had been proved by Exhibit 220
i.e., the visitor register showing entry no.2137 made in respect of his stay at Hotel Garden, which
was signed by him and Rajendrasingh Vajesinh Rathod, Manager, Hotel Garden (PW−18) had also
proved the aforesaid entry in his deposition in Court. Exhibit 486 i.e., CFSL Report of Subhash
Mittal, Principal, Scientific Officer (PW−79) had also proved the handwriting of A−3 (Mohmed
Saifuddin) at entry no.2137. A−3 (Mohmed Shafiuddin) was then taken to Lokhandwalichali of
Mushtaq Ahmed Munir Ahmed Ansari (PW−63) by A−1 (Mohmed Asgar Ali) and A−10 (Parvez
Khan Pathan). This fact had been proved by Exhibits 250, 253 and 244 i.e., the confessional
statements of A−3 (Mohmed Shafiuddin), A−1 (Mohmed Asgar Ali) and A−10 (Parvez Khan Pathan)
respectively.
25(b). At the end of January 2003, A−1 (Mohmed Asgar Ali) and A−3 (Mohmed Shafiuddin) were
shifted to Flat No.902 in M.B. Complex by A−11 (Mohmed Faruq). The said flat was arranged by A−
10 (Parvez Khan Pathan) through Tawabhai Yusufbhai Shaikh (PW−66) and Mohmed Jalis Ahmed
Rajput (PW−68). This fact had been proved by Tawabhai Yusufbhai Shaikh (PW−66) and Mohmed
Jalis Ahmed Rajput (PW−68) in their deposition made in the Court.
25(c). Between January and February 2003, A−1 (Mohmed Asgar Ali) and A−3 (Mohmed
Shafiuddin) were moved to Flat No.401, Royal Apartment, Rakhial by A−10 (Parvez Khan Pathan)
and A−11 (Mohmed Farooq). The said flat was owned by Abdul Banki Abdul Bari Ansari (PW−44 −
hostile witness) and an advance of Rs.5,000/− was paid to him by A−10 (Parvez Khan Pathan).
When the said flat was vacated, Rs.3,500/− was refunded by Abdul Banki Abdul Bari Ansari (PW−
44) to A−10 (Parvez Khan Pathan) through cheque no.17296 drawn on Gujarat Industrial Coop.
Bank, which was encashed by A−10 (Parvez Khan Pathan). The stay of A−1 (Mohmed Asgar Ali) andCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

A−3 (Mohmed Shafiuddin) had been proved by Yusufbhai Idubhai Pathan, (PW−95 − occupant of
neighbouring flat). Exhibit 209 i.e., a notebook of the Royal Apartment had also proved that an
entry had been made by Mushtaq Yusufbhai Mansoori (PW−59) regarding the stay of A−1 (Mohmed
Asgar Ali) at Royal Apartment.
25(d). On 31.1.2003, a mobile no.9825491421 was procured by using Voter ID of Shivabhai Virabhai
Rathod (PW−53) and was provided to A−1 (Mohmed Asgar Ali) by A−14 (Sohail Khan Pathan). This
fact had been corroborated by Shivabhai Virabhai Rathod (PW−
53) and V. Srinivasan, Official of Hutch Company (PW−77) in their deposition and the print out of
mobile no. 9825491421 is also on record as Exhibit 467.
25(e). On 1.2.2003, a Suzuki Samurai Motorcycle (Black Colour) bearing registration no.GJ−1S−S−
5934 was purchased by A−10 (Parvez Khan Pathan) from Abdul Samad Abbasali (PW−54) and the
delivery note was signed by A−10 (Parvez Khan Pathan) while taking possession of the same. The
deposition of Abdul Samad Abbasali (PW−54) as well as the Exhibits 383 and 384 i.e., a delivery
note of the motorcycle had clearly proved that the motorcycle was purchased by A−10 (Parvez Khan
Pathan). On the instructions of A−14 (Sohail Khan Pathan), the motorcycle was provided to A−1
(Mohmed Asgar Ali) by A−10 (Parvez Khan Pathan). After the arrival of A−1 (Mohmed Asgar Ali)
and A−3 (Mohmed Shafiuddin) at Ahmedabad, A−4 (Kalim Ahmed) and A−5 (Anas Machiswala)
visited Surat on the instructions of A−13 (Mufti Sufiyan) and collected two pistols from one Maulana
Tahir. 25(f). Before 5/6.3.2003, a meeting was held at Lal Masjid, which was attended by A−4
(Kalim Ahmed), A−5 (Anas Machiswala), A− 13 (Mufti Sufiyan) and A−14 (Sohail Khan Pathan), in
which it was decided to kill Jagdish Tiwari.
25(g). On 5/6.3.2003, A−14 (Sohail Khan Pathan) introduced A−1 (Mohd. Asgar Ali) and A−3
(Mohmed Shafiuddin) to A−4 (Kalim Ahmed) and A−5 (Anas Machiswala). A−4 (Kalim Ahmed)
handed over two pistols each to A−1 (Mohd. Asgar Ali) and A−3 (Mohmed Shafiuddin) with live
cartridges. Before 9.3.2003, A−10 (Parvez Khan Pathan) pointed out Jagdish Tiwari (PW−39) at his
shop to A−1 (Mohd. Asgar Ali). On 9.3.2003, a meeting was held at Jaliwali Masjid, which was
attended by A−5 (Anas Machiswala), A−6 (Mohmed Yunus Sareshwala), A−7 (Rehan Puthawala),
A−8 (Mohmed Riyaz), A−9 (Mohmed Parvez Sheikh), A−12 (Shanavaz Gandhi) and A−14 (Sohail
Khan Pathan) and in the said meeting, it was disclosed by A−14 (Sohail Khan Pathan) that Jagdish
Tiwari would be their target. In the night of 9.3.2003, A− 1 (Mohmed Asgar Ali) and A−3 (Mohmed
Shafiuddin) waited for the arrival of Jagdish Tiwari (PW−39) in order to kill him, but on that night,
Jagdish Tiwari did not pass through the scheduled route. On 10.3.2003, A−1 (Mohmed Asgar Ali)
and A−3 (Mohmed Shafiuddin) followed Jagdish Tiwari (PW−39), who was on his motorcycle and
when he took U−turn for his flat, A−1 (Mohmed Asgar Ali) tried to fire a shot from his pistol, but the
bullet did not come out.
25(h). On the very next day i.e., 11.3.2003 at about 9.15 pm, A−1 (Mohmed Asgar Ali) and A−3
(Mohmed Shafiuddin) went to the shop of Jagdish Tiwari (PW−39) and A−3 (Mohd. Shafiuddin)
asked for a strip of the sorbitrate tablet. While he was taking out the medicine, A−1 (Mohmed Asgar
Ali) fired a shot from his pistol at Jagdish Tiwari (PW−Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

39), but the bullet hit on his metal buckle of belt and after ricocheting entered in his body near navel
portion. The weapon of A−1 (Mohmed Asgar Ali) got jammed and in the process of clearing the
blockage, two live cartridges fell at the shop. Two more bullets were fired on Jagdish Tiwari (PW−
39), but he hid behind a pillar and fridge. The identity of A−1 (Mohmed Asgar Ali) and A−3
(Mohmed Shafiuddin) had been proved by Exhibit 329 i.e., the deposition of Jagdish Tiwari (PW−
39) − injured eye−witness. At 9.16 pm, A−1 (Mohmed Asgar Ali) informed A− 10 (Parvez Khan
Pathan) on his mobile about the attack on Jagdish Tiwari (PW−39). At that moment his location was
under the tower of Jay Chemicals, Odhav, GIDC. At 9.20 pm, A−1 (Mohmed Asgar Ali) again called
A−10 (Parvez Khan Pathan) and at that point of time, his location was Vohra Marriage Hall, Char
Rasta, Rakhial. Jagdish Tiwari (PW−39) was rushed to Shardaben Hospital and was treated by Dr.
Hasuben Kalubhai Patel (PW−9) in casualty. Thereafter, he was shifted to the emergency of Surgery
Department. A wardi regarding the incident was received at PS Bapunagar on the basis of which,
Nagindas Kalidas Barot (PW−96) visited the shop of Jagdish Tiwari (PW−39) and from there he
went to Hospital. At the Hospital, Nagindas Kalidas Barot (PW−96) wrote down the complaint of
Jagdish Tiwari (PW−39) and sent the same to PS Bapunagar where I−CR No.101/03 was registered
at 11.35 pm. 25(i). On 12.3.2003, clothes of Jagdish Tiwari (PW−39) were taken into possession by
Nagindas Kalidas Barot (PW−96) vide Exhibit 491 (panchnama) in the presence of Sureshbhai
Chelwalya Patel (PW−
81). Panchnama of the crime scene was prepared by Nagindas Kalidas Barot (PW−96) in the
presence of Popatbhai Virchandbhai Padhiyar (PW−78). Two live cartridges, three cartridge cases,
and one fired bullet were recovered and taken into police possession vide Exhibit
474. Jagdish Tiwari (PW−39) was operated by Dr. Pranjal Desai and his senior and a bullet was
removed.
25(j). On 14.3.2003, Dr. Virendra Kanaiyalal Shah (PW−10) handed over the recovered bullet to
Himmatsinh Ratansinh Chauhan (Rathod) (PW−15), who produced the same before Nagindas
Kalidas Barot (PW−96) in the presence of Chandrakishan Bageshwar Tiwari (PW−80) (Panch).
Exhibit 489 is the memo of handing over of recovered bullet. On the same day, A−3 (Mohmed
Shafiuddin) was dropped at Gita Mandir Bus Stand by A−10 (Parvez Khan Pathan) and was
provided bus ticket for Jaipur. The ticket was sold by Maqsoodbhai Ismailbhai Mansoori (PW−22).
25(k). On 15/16.3.2003, A−13 (Mufti Sufiyan) in consultation with A−14 (Sohail Khan Pathan)
disclosed to A−5 (Anas Machiswala) that their next target would be Haren Pandya, who used to
come to Law Garden for a walk.
25(l). On 17/18.3.2003, a meeting was attended by A−4 (Kalim Ahmed), A−5 (Anas Machiswala), A−
7 (Rehan Puthawala), A−8 (Mohmed Riyaz), A−12 (Shahnavaz Gandhi) and A−14 (Sohail Khan
Pathan) at Juni Jama Masjid, where A−14 (Sohail Khan Pathan) disclosed their next target i.e.,
Haren Pandya. A−12 (Shahnavaz Gandhi) was directed by A−14 (Sohail Khan Pathan) to carry out a
recce of Law Garden in order to ascertain movements of Haren Pandya and his car number. 25(m).
In a meeting held on 22.3.2003 at Juni Jama Masjid attended by A−4 (Kalim Ahmed), A−5 (Anas
Machiswala), A−7 (Rehan Puthawala), A−8 (Mohmed Riyaz), A−12 (Shahnavaz Gandhi) and A−14Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

(Sohail Khan Pathan), A−9 (Mohmed Parvez Sheikh) was assigned the task to carry out the recce of
Law Garden as A−12 (Shahnavaz Gandhi) had failed to do so.
25(n). On 23.3.2003 at 7.00 am, A−9 (Mohmed Parvez Sheikh) called A−1 (Mohmed Asgar Ali) from
the mobile phone of A−7 (Rehan Puthawala) and asked him to come to Law Garden in order to
familiarize with the topography. It had been proved by Exhibit 467 i.e., CDR of mobile
no.9825491421 used by A−1 (Mohmed Asgar Ali) during the commission of the crime. A−6
(Mohmed Yunus Sareshwala) and A−9 (Mohmed Parvez Sheikh) visited the Law Garden where A−1
(Mohmed Asgar Ali) also came but they could not locate Haren Pandya.
25(o). On 24.3.2003, A−9 (Mohmed Parvez Sheikh) visited the Law Garden again in the morning on
the motorcycle and saw Haren Pandya. He noted down his car number as GJ−1AP−4606. In the
night of 24.3.2003, a meeting was again held in Juni Jama Masjid, which was attended by A−4
(Kalim Ahmed), A−5 (Anas Machiswala), A− 7 (Rehan Puthawala), A−8 (Mohmed Riyaz) and A−9
(Mohmed Parvez Sheikh), where A−9 (Mohmed Parvez Sheikh) was directed by A−4 (Kalim Ahmed)
to point out the spot at Law Garden to A−1 (Mohmed Asgar Ali). A−1 (Mohmed Asgar Ali) was
telephonically called there and taken to Law Garden by A−9 (Mohmed Parvez Sheikh), where the
spot was pointed out to him where Haren Pandya parked his car. Meticulous planning was done to
execute the murder of Haren Pandya on the next morning, where A−8 (Mohmed Riyaz) was
assigned the role of driver of A−1 (Mohmed Asgar Ali) and A−9 (Mohmed Parvez Sheikh) was
assigned the task to keep watch to safeguard A−1 (Mohmed Asgar Ali) and A−8 (Mohmed Riyaz). A−
7 (Rehan Puthawala) was given the task to escort A−1 (Mohmed Asgar Ali) and A−8 (Mohmed
Riyaz) to Shahpur Mill Compound, where A−4 (Kalim Ahmed) and A−5 (Anas Machiswala) were to
wait in an autorickshaw.
25(p). On 25.3.2003, an attempt was made to kill Haren Pandya at Law Garden, but A−1 (Mohmed
Asgar Ali) could not open fire due to the presence of many persons. In the afternoon, it was decided
to kill Haren Pandya next morning.
25(q). On 26.3.2003 at around 7.30 am, Haren Pandya was killed by A−1 (Mohmed Asgar Ali) by
firing from close range at Law Garden. Entire incident was witnessed by Anilram Yadram Patel
(PW−55), who identified A−1 (Mohmed Asgar Ali), whom he saw firing at Haren Pandya from
firearm and he had narrated the entire incident in his deposition and fully supported the version of
the prosecution vide Exhibit 175 i.e., identification memo of A−1 (Mohmed Asgar Ali). After the
incident, A−1 (Mohmed Asgar Ali) called A−14 (Sohail Khan Pathan) on mobile no.9426039937
from his mobile no.9825494421 at 7.33 am and 8.17 am. The location of these mobile numbers had
confirmed the presence of A−1 (Mohmed Asgar Ali) at Law Garden. These facts had been proved by
Exhibit 467 i.e., CDR of mobile no.9825494421. Hemantkumar Ratilal Patel, Assistant Divisional
Engineer, Vastrapur Telephone Exchange (PW−33) had also proved the location of mobile number
used by the accused persons on the basis of tower location chart. At 10.40 am, a message was sent to
PS Navrangpura and PS Ellis Bridge by City Control Room to reach Law Garden. Haren Pandya was
evacuated to B.S. Hospital by police officials of P.S. Navrangpura. A complaint was lodged by
Janaksingh Khusalsinh Parmar (PW−1) with Yusuf Miya Ahmed Miyan Shaikh, P.I., PS Ellis Bridge
(PW−101) regarding the murder of Haren Pandya. At 11.30 am, I−CR No.272/02 was registered atCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

PS Ellis Bridge regarding the killing of Haren Pandya. Inquest panchnama was prepared by Yusuf
Miya Ahmed Miyan Shaikh, P.I., P.S. Ellis Bridge (PW−101) between 1.00 pm to 2.00 pm. Post−
mortem examination of Haren Pandya was conducted between 2.15 pm to 4.50 pm. Panchnama of
the crime scene was prepared by Yusuf Miya Ahmed Miyan Shaikh, P.I., PS Ellis Bridge (PW−101)
between 2.30 pm to 3.30 pm. A notification was issued under Section 6 of the DSPE Act for
investigation by CBI in the murder of Haren Pandya. Statement of Anilram Yadram Patel (PW−55)
was recorded. On 28.3.2003, the investigation was taken up by CBI and records of FIR No.272/03
were seized from PS Ellis Bridge.
26. Further investigation also unearthed and supported the conspiracy. On 3.4.2003, A−6 (Mohmed
Yunus Sareshwala), A−7 (Rehan Puthawala), A−8 (Mohmed Riyaz) and A−9 (Mohmed Parvez
Sheikh) were arrested by Tarunkumar Amrutlal Barot, P.I. of DCB, Ahmedabad (PW−114) on
suspicion of obtaining arms training at Pakistan. I−CR No.6/03 was registered against the aforesaid
accused of waging war against the State and taken into police custody for remand. A mobile phone
was recovered from A−7 (Rehan Puthawala). 26(a). On 6/7.4.2003, when A−7 (Rehan Puthawala)
was confronted with the contact details of his mobile phone, in which numbers were stored against
the names of Mehman and Uncle, he disclosed that Mehman is killer of Haren Pandya and Uncle is
A−5 (Anas Machiswala), who played a key role in the murder of Haren Pandya. The same had been
proved vide Exhibit 728 i.e., the evidence of Sushilkumar S. Gupta (PW−120). The location of
phones was traced to be at Ahmedabad.
26(b). On 17.4.2003, A−1 (Mohmed Asgar Ali), A−2 (Mohmed Abdul Rauf), A−15 and A−16 were
arrested from Medchal Bus Stand, Hyderabad. On 18.4.2003, A−3 (Mohmed Shafiuddin) was
arrested from J.D. Math Bus Depot, RR District, Andra Pradesh by V. Prabhanjan Kumar (PW−118).
26(c). On 22.4.2003, bullets recovered from the body of Haren Pandya along with his clothes were
handed over to CFSL, New Delhi for opinion (Exhibit 441).
26(d). On 23.4.2003, A−1 (Mohmed Asgar Ali) had confessed about his stay at House No.206, Block
61, Gujarat Housing Board, Old Bapu Nagar, Ahmedabad in the presence of Harikishan Harpal
Meena (PW−23). He had also mentioned this fact in his confessional statement and it had also been
mentioned in the statement of Mustaq Ahmed Munir Ahmed Ansari (PW−63 – hostile witness). He
had also mentioned about M.B. Complex, Rakhial, in the presence of Harkishan Harpal Meena
(PW−23) and House No.522, Gujarat Housing Board, Babunagar owned by A−10/A−14. At the
pointing of A−1 (Mohmed Asgar Ali), Bajaj Boxer Motorcycle No.GJ−1BG−3849 was seized from the
house of A−10/A−14 along with registration papers. These facts had been proved by Exhibits 268,
269, 270 and 272.
26(e). On 25.4.2003, Suzuki Samurai Motorcycle No.GJ−1SS− 5934 and Hero Honda Motorcycle
No. GJ−1CD−8973 were seized from the parking of Kalupur Railway Station and PS Kagdapeeth
respectively. A−4 (Kalim Ahmed), A−5 (Anas Machiswala) and A−12 (Shahnavaz Gandhi) were
arrested from Sadashiv Pet Bus Stand, Sangareddy, Andhra Pradesh by Udham Sinh Ramkaran Sinh
Solanki (PW−108) and was remanded to transit custody till 29.4.2003 by the Judicial Magistrate.
These facts had been proved by Exhibits 274, 356, 645, 646, 647 and 648.Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

26(f). On 26.4.2003, a revolver No.B−40350 Webley & Scott and one pistol No. EE−0330 was
discovered at the instance of A−1 (Mohmed Asgar Ali) in the presence of Srinathsinh Shambhausinh
(PW−13) from Flat No.4−B, Kamar Flats, Shahapur, Ahmedabad. This fact had been proved by
Exhibit 196. RC Book of Suzuki Samurai Motorcycle No.GJ−1SS−5934 was recovered during a
search of the said flat. It had been proved by Exhibits 197 and 198.
26(g). On 28.4.2003, A−1 (Mohmed Asgar Ali) disclosed of having used various cyber cafes at
Ahmedabad and Udaipur. Two hard disks from Modern Cyber Café, Ahmedabad and one hard disk
each from Mittal Cyber Café and Net Savy Cyber Café, Udaipur were seized. The same had been
proved to vide Exhibits 601, 336, 410 and 576. On 29.4.2003, a hard disk of Cyber Space Café,
Ahmedabad was also seized (Exhibit 762).
26(h). On 30.4.2003, A−1 (Mohmed Asgar Ali) and A−2 (Mohmed Abdul Rauf) had disclosed about
their email IDs, passwords and print out of emails was taken in the presence of Prakashbhai Babulal
Modh (PW−16) (Exhibits 213 & 215).
26(i). On 5.5.2003, A−1 (Mohmed Asgar Ali) was identified by Anilram Yadram Patel (PW−55)
during a test identification parade. 26(j) On 8.5.2003, a pistol was discovered at the instance of A−5
(Anas Machiswala) from his house. It had been proved by Exhibit 423. 26(k). On 22.5.2003, A−7
(Rehan Puthawala) and A−8 (Mohmed Riyaz) made a disclosure about the shop of Star Number
from where they got prepared fake number plates bearing no.GJ−1CF−5189. Babarbhai Maljibhai
Rabari (PW−34) was the punch witness of the said disclosure and had fully supported the same
during his deposition. Shaikh Mohmed Riyaz Hussainmiyan Pirmiyan (PW−52) owner of Star
Number Plate had also deposed regarding the making of number plates. These facts had been
proved by Exhibits 312, 313, 314 and
315. 26(l). On 1.6.2003, POTA was invoked in FIR No. RC.2(S)/2003 SCUI and an intimation were
sent to Principal Sessions Judge, Ahmedabad, and Chief Metropolitan Magistrate, Ahmedabad
(Exhibit 744). 26(m). On 2.6.2003, I−CR No.101/03 of PS Bapunagar was registered in CBI as FIR
No.RC.5 (S) 2003 – SCU. I and investigation were taken up (Exhibit 746). Police custody remand of
A−6 (Mohmed Yunus Sareshwala), A−7 (Rehan Puthawala), A−8 (Mohmed Riyas) and A−9
(Mohmed Parvez Sheikh) was extended till 9.6.2003 (Exhibit 745). 26(n). On 3.6.2003, records of
I−CR No.101/03 were collected from DCB by CBI (Exhibit 747).
26(o). On 4.6.2003, A−10 (Parvez Khan Pathan) and A−11 (Mohmed Faruq) were arrested on the
basis of transfer warrant. Statement of Jagdish Tiwari (PW−39) was recorded, who claimed that he
can identify the assailants. A−6 (Mohmed Yunus Sareshwala), A−7 (Rehan Puthawala), A−8
(Mohmed Riyas) and A−9 (Mohmed Parvez Sheikh) expressed their desire to make a confessional
statement before Sushilkumar S. Gupta, Investigating Officer (PW−120), who produced them before
Vinayak Prabhakar Apte, Superintendent of Police (PW−21).
26(p). On 5.6.2003, A−10 (Parvez Khan Pathan) and A−11 (Mohmed Faruq) were produced before
Chief Metropolitan Magistrate, Ahmedabad and were remanded to police custody till 19.6.2003.
26(q). On 6.6.2003, Jagdish Tiwari (PW−39) identified A−1 (Mohmed Asgar Ali) and A−3 (MohmedCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

Shafiuddin) during a test identification parade. Statements of Jagdish Tiwari (PW−39), Javed Abdul
Rashidkhan Pathan (PW−45) and Faridkhan Majidkhan (PW−74) were recorded. A−7 (Rehan
Puthawala) also made a confessional statement, which was recorded by Vinayak Prabhakar Apte
(PW−21). The same had been proved by Exhibits 203, 366, 557, 558 and 229. 26(r). On 7.6.2003,
confessional statements of A−6 (Mohmed Yunus Sareshwala) and A−9 (Mohmed Parvez Sheikh)
were recorded by Vinayak Prabhakar Apte (PW−21). The same had been proved by Exhibits 232 and
235.
26(s). On 8.6.2003, Vinayak Prabhakar Apte (PW−21) recorded the confessional statement of A−8
(Mohmed Riyaz) (Exhibit 238). 26(t). On 11.6.2003, POTA was invoked in RC.5(S)/2003−SCU. I
i.e., case of Jagdish Tiwari and an intimation was sent to Principal Sessions Judge, Ahmedabad, and
Chief Metropolitan Magistrate, Ahmedabad (Exhibits 750 and 751).
26(u). On 12.6.2003, A−1 (Mohmed Asgar Ali), A−2 (Mohmed Abdul Rauf) and A−3 (Mohmed
Shafiuddin) were arrested on the basis of transfer warrant in case no. RC.5(S)/2003−SCU.I and
remanded to police custody till 21.6.2003. Hero Honda Motorcycle was seized from PS Koth. A−10
(Parvez Khan Pathan) made a disclosure statement regarding number plates and video CDs. The
number plate was discovered from roadside bushes of Tarapur Highway at the instance of A−10
(Parvez Khan Pathan) and six video CDs and other literature were discovered from the house of A−
10 (Parvez Khan Pathan). A−10 (Parvez Khan Pathan) and A−11 (Mohmed Faruq) also expressed a
desire to make a confessional statement before Sushilkumar S. Gupta (PW−120). These facts have
been proved by Exhibits 754, 755, 513, 514 and 515.
26(v). On 15.6.2003 and 16.6.2003, confessional statements of A−11 and A−10 respectively were
recorded by Vinayak Prabhakar Apte (PW−21). (Exhibits 241 and 244) 26(w). On 17.6.2003, A−4
(Kalim Ahmed), A−5 (Anas Machiswala) and A−12 (Shahnavaz Gandhi) were arrested on transfer
warrant and on 18.6.2003, they were remanded to police custody till 27.6.2003. A− 1 (Mohmed
Asgar Ali), A−2 (Mohmed Abdul Rauf) and A−3 (Mohmed Shafiuddin) expressed their desire to
make a confessional statement before Sushilkumar S. Gupta (PW−120). On 20.6.2003, confessional
statements of A−2 (Mohmed Abdul Rauf) and A−3 (Mohmed Shafiuddin) were recorded by Vinayak
Prabhakar Apte (PW−21). A−12 (Shahnavaz Gandhi) also expressed a desire to make confession to
Sushilkumar S. Gupta (PW−120). These facts had been proved by Exhibits 759, 595, 247 and 250.
26(x). On 21.6.2003, confessional statement of A−1 (Mohd. Asgar Ali) was recorded by Vinayak
Prabhakar Apte (PW−21) and on 22.6.2003, confessional statement of A−12 (Shahnavaz Gandhi)
was recorded by Vinayak Prabhakar Apte (PW−21). The same had been proved vide Exhibits 253
and 256. Thereafter, A−4 (Kalim Ahmed) and A−5 (Anas Machiswala) also expressed a desire to
make confession before Vinayak Prabhakar Apte (PW−21).
IN RE: ANIL YADRAM (PW−55)
27. It was urged on behalf of the prosecution that PW−55, Anil Yadram is a reliable eye−witness. His
presence at the scene of occurrence at 7.30 a.m. and that of deceased is natural and stands proved. It
was pointed out that the presence of the eye−witness on the crime spot was natural as he used toCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

keep his push handcart inside the compound of Chitty Bang in Thakorbhai Desai Hall, as the drive
was on to remove such carts by Municipal Corporation. He was present in early morning hours and
his presence has been corroborated and proved by PW−55, owner of Chitty Bang CW−1 who has
confirmed that PW−55 used to keep his hand cart in the Chitty Bang compound with his permission
and used to sleep there at night. The version of PW−55 has also been corroborated by medical
evidence and by other independent evidence. His disposition has been corroborated by medical as
well as ballistic expert, PWs.−8, 15, 55, 101 and 120 with respect to the position of the accused and
the bullet injury suffered by the deceased. The Post Mortem examination was conducted by 4
doctors. Dr. Pratik Patel (PW−8) has proved 7 gunshots caused by 5 bullets. Forensic and biological
reports prove the death of the deceased inside the car. The weapon used by A−1 at the time of the
commission of the offence was duly recovered from same flat. Ballistic expert PW−75 has deposed
that the bullets recovered from the body of the deceased were fired from the same revolver which
was recovered at the instance of A−1. Commission of offence vis−à−vis PW−39, Jagdish Tiwari has
attained finality as that has not been questioned by accused persons by filing appeals, which also
proves the presence of A−1 and A−3 at Ahmedabad during the relevant period. PW−95 proves that
A−1 was present in Ahmedabad on 27.3.2003 and used phone No.98254 91421 even up to the next
day of the murder of the deceased. The High Court has committed gross perversity in setting aside
the findings recorded by the trial court without coming to close quarters of the reasoning employed
by the trial court as well as marshalling of evidence in detail, as done by the trial court.
28. On the other hand, learned counsel appearing on behalf of the accused sought to discredit the
testimony and deposition of PW−55 Anil Yadram by raising various grounds to be dealt with in
extenso hereinafter. Anil Yadram, PW−55 has stated that he stationed his handcart near Law
Garden outside the gate of Chitty Bang, Thakorbhai Desai Hall, and Nanubhai is the owner of the
Chitty Bang. He used to leave his handcart in the compound of Chitty Bang of Nanubhai (CW−1)
during the night. If the handcart is kept outside, the corporation might tow away the cart. Therefore,
he used to keep the handcart in the said Chitty Bang during the night. He used to sleep in the Chitty
Bang, the place of Nanubhai. On 26.3.2003 he went to nature’s call, and after brushing he washed
his face and came near the front gate and then he saw that Kanhaiya Lal was standing nearby the
gate. He told him that the Corporation was towing the handcarts. Kanhayalal told him that he would
be there at 10’O clock. He was inside the gate of Chitty Bang when he saw a Maruti Fronti came from
Gajjar Hall Cross Roadside and stopped where he kept his larry. Haren Pandya was inside the car.
He parked the car and was rolling the window glass up. In the meantime, a boy came from the side
where the car had come and he fired 4 to 5 rounds. The feet of Haren Pandya was raised up and he
fell on the back side. Witness shouted what are you doing? The assaulter ran away. Thereafter
Ramesh, Sweeper came and asked what had happened. The boy was neither here nor there. He has
specified some features of the accused. He was scared and sat so for some time and then went
towards B Desai Hall and saw Shukla Chacha in a rickshaw. He informed Shukla Chacha that Haren
Pandya has been killed. Shukla Chacha and he both went in a rickshaw. Since goods were loaded
and as there was traffic police on Panchvati Circle, he dropped him off from rickshaw at Panchvati
Circle and again asked him to board the rickshaw at Ambawadi Circle. Then they reached
Nanubhai’s place. He informed Nanubhai that Haren Bhai Pandya has been killed by 4 to 5 rounds
of firing at the place where he used to keep his larry. Nanubhai told that after having tea he will
reach Law Garden. They went back to Law Garden, the police had arrived, Haren Pandya was takenCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

in a jeep to V.N. Hospital. The police officer came in civil dress and asked him features of the
assaulter. The witness explained him in the same manner as he has deposed in the court. The CBI
had prepared the map. He has affixed his thumb impression and Kanhaiya has signed it.
29. It was submitted on behalf of the accused persons that the case of gun firing set up by the
witness PW−55 is not correct as in Maruti 800 car, no gunshot residue (GSR) has been found and no
bullet has been recovered from the car. It is not in dispute that the bullets were recovered from the
body as such they were not found in the car. Learned counsel for A−1 submitted that from the seat
no blood was found though on Kurta and Pyjama and underwear there were blood stains. The High
Court has observed that there was profuse bleeding, as such from the driver’s seat cover blood ought
to have been found. On the other hand, it was pointed out on behalf of the CBI that blood has been
recovered from the Maruti car and it was of Group B of the deceased. Thus, merely on the cover of
the seat blood was not found, would not discredit the incident. As a matter of fact, it would depend
upon the nature of the wound and whether the bleeding is internal and the position of the body as to
how much blood would go down. Whether it will go to the seat cover or to the bottom of the car, it
cannot be said to be a universal formula that whenever an incident has happened in a car, blood
should be found on a particular place. Thus, an attempt to discredit the deposition of the witness on
the aforesaid ground that some blood has not been recovered from the seat cover of the car by itself,
cannot be said to be circumstances leading to doubting of the incident in the car. It was submitted
on behalf of the prosecution that PW−55 is an independent witness who is neither related to the
deceased nor having any enmity with A−1. He has duly identified A−1 in a test identification parade
on 5.5.1981 before PW−7 who has given Panchnama. The trial court has rightly found him to be a
reliable witness.
30. It was urged on behalf of the accused that there was no GSR inside or outside the vehicle which
according to the accused makes it highly doubtful that the car was the site of the shooting. The
prosecution submitted that since the bullets were found inside the body, GSR could not be found
inside or outside the vehicle. Thus, the incident cannot be said to be doubtful due to the fact that the
presence of GSR has not been found inside or outside the vehicle.
31. It was submitted by the learned counsel appearing on behalf of the accused that the car had dark
window glasses. Driver’s right side was slightly open. PW−55 has also stated that the car window
was open as shown in the photograph. Thus, it was submitted that by the opening of roughly 3
inches, gunshot injuries are rendered impossible, to be caused especially injury No.7, which renders
it doubtful that the car was the site of the shooting. PW−55 has stated that Haren Pandya after
stopping the car, drank water from the bottle and thereafter he was fired at when he was rolling up
the window glass.
32. In our opinion, precise rolling of the glass when he was fired at, cannot be stated by any person
with precision. It is too much to expect a person to state how much rolling of the glass of windows
had been done at the time of firing. Even if the witness had stated so, that would be merely his
guesswork. When a person is rolling the glass up, it is possible that he might have been fired the
shot when the window was quite wide open and when he was in the process of rolling it up. The
person in order to save himself from the firing would also try to roll up the glass with speed thenCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

also gunshot firing can be made in the process. Thus the argument raised that there was a tiny
opening of 3 inches when the shots were fired, is against the normal course of human conduct to
make such statement and the way in which the incident has taken place it cannot be said with
precision how much rolling of the glass of windows was done before firing took place and how much
rolling was done after suffering some shots or in the process of firing. It can only be said that he was
in the process of rolling the glass up when the firing took place.
33. PW−55 has demonstrated the position of the deceased inside the car in his deposition. With
respect to shooting from the driver’s side glass is corroborated medically by the direction of injuries
1 to 4 which are from upward to downward and right to left. PW−55 has further stated that the legs
of deceased came up and he fell on the co−driver’s seat which explains injury No. 7 also which is
from downward to upward and left to right. This is further corroborated by the entry hole in Pyjama
which is in the rear hole of Pyjama. The position of the deceased has been confirmed by PW−85, a
constable who took the body of the deceased out of the car. PW−85 has stated that legs were slightly
up from knee level. The right leg was slightly more on the upward direction.
34. To discredit version of PW−55, it was submitted that there were 7 injuries and 5 bullet injuries
were found. Total 5 fire−arms bullets were recovered from the body of the deceased during post
mortem as proved by PW−8. That falsifies the prosecution case. This aspect requires a close
examination of the evidence. It was submitted on behalf of A−1 that in the post mortem conducted
by 4 doctors, 5 bullets described as white metal bullets were found from the body as against 7
gunshot wounds. All of them had blackening around. Injury No.6 also had blackening as found by
PW−19, the treating doctor. The holes in the clothes corresponding to the blood wounds including
the right bone show blackening. The emergence of all 7 holes on the clothes including those on the
right GSR and later examined by CFSL. It was further submitted that autopsy surgeon PW−8 has
stated in answer to question Nos.64 to 66 that all the bullets inside the body are mentioned for 5
wounds namely injury Nos.1 to 4, 5 to 7. Injury Nos. 5 and 6 in the post mortem report is their
communicating injury. The track of injuries 5 and 6 is not noted. It was submitted that in case of
injury Nos.5 and 6, there should have been wrist fracture and the injury should have been on the
palm region. Thus the eye witness account of firing 5 shots is not reliable. For causing injury No.7
the weapon would have to be at the level of the scrotum and to its left and the autopsy surgeon has
stated that assailant to cause injury No.7 will have to be in front and beneath. Thus injury No.7
could not have been caused in Maruti car. So that is not the place of the incident. Due to this aspect,
the ocular evidence of PW 55 stands contradicted.
35. It was submitted on behalf of the prosecution that while countering that coherent and succinct
nature of the medical and forensic evidence with ballistics bolsters the case of the prosecution and
unambiguously establishes that murder was committed by A−1. Injury Nos.2 to 4 were direct shots
to the chest; injury Nos.1, 5 and 6 were caused by the same bullet, injury No.1 was on the neck,
injury No.5 on the right−hand metallic bone and injury No.6 at back of the hand, injury Nos.5 and 6
are communicating injuries and thereafter injury No.1 has been caused in the neck by the same
bullet. Statement of PW−8, Dr. Pratik Patel has been relied upon who has stated that the same bullet
has caused gunshot injuries 5 and 6. The doctor has opined that if the hand is reflexly kept in front
of face or neck region on the right side that back of hand if facing the opposite side of the victim, theCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

bullet may re−enter from external injury No.1.
36. Now we advert to whether medical evidence belies the version of PW−55. In the post mortem
report D−160 dated 26.3.2003 of Haren Pandya following injuries have been noted:
"1. About 0.8 cm diameter, punch red contused lacerated entry wound with inverted
edges is present on the lower part of front of neck on right side, about 1 cm above and
2 cm right to medial end of right clavicle. Blackening is seen on skin surrounding the
wound.
2. About 0.8 cm diameter, punch red contused lacerated entry wound with inverted
edges is present in front of right chest, about 1.2 cm right to midplane over right 2nd
intercostal space.
3. About 0.8 cm diameter, punch red contused lacerated entry wound with inverted
edges is present on front of right chest, 5 cm below and 1 cm left to right nipple.
4. About 0.8 cm diameter, punch red contused lacerated entry wound with inverted
edges is present front of right chest, 0.5 cm below and 3 cm right to abovementioned
external injury no. 3.
5. About 0.8 cm diameter, punch red contused lacerated entry wound with inverted
edges is present on back of right hand, 2 cm proximal to junction of index and middle
fingers. Blackening of skin is seen surrounding the wound.
6. Lacerated wound with everted margin is present on front of right forearm at
junction of upper 2/3 to lower 1/3rd, g___ obliquely downward to medially, 2 cm.
7. 0.5 cm diameter, circular punch lacerated wound with inverted margins present on
lower part of left scrotum 1 cm __ midplane (scrotal raphe) covered with clot.
8. 0.4 cm x 0.4 cm, red−colored, abrasion present on mid of lateral aspect of phalanx
of the right middle finger."
When we consider the aforesaid report, injury No.1 is on the lower part of the front of the neck on
the right side, that is on the right clavicle. The doctor has clearly expressed that injury Nos.5 and 6
are communicating ones. As a matter of fact, in communicating injuries it is not necessary that the
bullet to have entered the proximal to junction of the index and middle finger. It could have passed
touching the area and then caused injury on the right forearm in the process of reaching right up to
the front on a lower part of the front to cause injury No.1. The medical evidence clearly establishes
that injury No.5 was caused first, 6 thereafter and No.7 was ultimately caused by the same bullet and
doctor has clearly explained it. While replying to question No.14, the doctor said that if the hand is
reflexly kept in front of neck region on the right side and that back of the hand is facing the opposite
side of the victim, bullet injury No.1 may be caused after causing injury Nos.5 and 6.Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

37. The conclusion of the High Court is only right to the extent that injury Nos.5 and 6 could not be
said to be entry and exit wounds. They were rather communicating wounds caused in the process of
causing injury No.1. The conclusion to the contrary averred by the High Court as to independent
injuries is absolutely incorrect. Testimony of PW−55 cannot be said to be falsified on the basis of
aforesaid medical evidence. There is no inconsistency with respect to the aforesaid aspect in the
medical version and the ocular version of PW55.
38. PW−8, Dr. Pratik Patel, Autopsy Surgeon has further stated in answer to question No.73.
“Question no. 73: what would be the exception and what is the authority of considering the
exception?
Answer: If first entry and exit are through the small part of the body and soft tissue and side of the
re−entry are in the close proximity of the exit wound of the first entry wound then there may be
features of the entry wound on the re− entry wound. I can also show some statements in support of
my reply. There is a book on Medico legal statements in support of my reply. There is a book on
Medicolegal investigation of Gun Shot by Abdulla Fateh, J.B. Lipping Company."
It is apparent from the aforesaid answer that wound has been referred by doctor PW−8 as a small
part of the body and soft tissue. Thus, it is a communicating injury of soft tissue not piercing
through or entering the wrist. It is clear that injuries 5 and 6 are communicating injuries and injury
No.1 has been caused by the same bullet. The entry and exit wounds have been seen and explained
by the doctor in the aforesaid manner which has to be communicating one only caused by the same
bullet.
39. It was also urged that the account of a number of injuries of the bullet is not matching with the
number of injuries found. There were 7 gunshot wounds whereas 5 bullets were recovered from the
body of the deceased. As already explained 5 bullet injuries were caused as suggested by ocular
evidence of PW−55 and also by medical evidence that 5 bullets were found as injury Nos.5 and 6
were communicating injuries leading ultimately to injury No.1 as discussed above. Thus, there is no
inconsistency rather ocular evidence is fortified by the medical evidence.
40. The accused person has relied upon "Gray's Anatomy" and "A Colour Atlas of Human Anatomy"
to contend that there are 32 tightly packed bones in the palm. The tightest packed are wrist bones
and the carpal tunnel is just about 8.3 mm in depth (as per medical journals). A 0.32 caliber bullet
has a diameter of 7.65 mm. Therefore, in the absence of any credible competent forensic explanation
of the track of injuries 5 and 6, this theory set up by CBI at the stage of arguments, is liable to be
dismissed.
41. There is no dispute that the palm has tightly packed bones. In the instant case, as the bullet has
not entered inside and only touched the soft tissue in injury No.5, the injury was caused on the soft
tissue and then it has superficially touched the wrist.Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

42. The doctor has stated in para 8 that external injuries 5 and 6 were found communicating with
each other. Fracture of 2 nd right metacarpal bone was present. He has further stated that bullets
were made of white metal, they were sealed, labelled and handed over to the police officer on duty.
When the treating doctor was asked how there were 5 bullets and 6 entry wounds, he has opined
that one injury will be of the entry of the bullet and that was precisely the communicating injuries 5
and 6 leading to injury No.1 that was the re−entry wound. Whether injury No.1 was original or re−
entry, he has referred to post mortem report to opine that injury Nos.5 and 6 are communicating
injuries.
43. The High Court as well confused as to the number of injuries on the basis of 7 wounds and 5
number of bullets fired. In case of such communicating injuries, it is not necessary that the bullet
should enter any part of the body while reaching to the last injury, it may cause scratch or touched
the small part of the body or soft tissue as has been done in the instant case. It has happened in the
instant case. With respect to the significance of such a medical version, this Court in Rachhpal Singh
and Anr. vs. State of Punjab, AIR 2002 SC 2710, has observed thus:
“8. A perusal of the evidence of the doctor shows that there is some discrepancy in his
evidence in regard to the nature of the injury on the deceased as to whether the edges
of the wound were averted or inverted. But this, in our opinion, is not fatal to the case
of the prosecution. The doctor while admitting that there was some such confusion in
his evidence as well as the post mortem report, in our opinion, has clarified the said
position during the course of his examination, though belatedly. From the very
nature of the wounds found on the body of the deceased, it is clear that they died of
gunshot injuries which is not seriously disputed. What is being disputed by the
learned counsel is the points of entry and exit which on facts of this case, would make
a very little difference since the other evidence adduced by the prosecution clearly
shows that the deceased died out of gunshot injuries. Some discrepancy as to the
nature of entry and exit on facts of this case would not make the prosecution case any
weaker. It is more so because of the facts that the casings of the bullets which were
recovered by the Investigating Officer were positively proved by the ballistic expert as
of those bullets which were discharged from the weapons recovered from the
appellants and these casings having been found near the bodies of the deceased on
the roof of their house would establish that the deceased died of bullets discharged
from the weapons seized from the appellants. In such circumstances, the question of
entry or exit of the wounds would lose its significance if the presence of the accused
persons with these weapons at the place and time is otherwise established by the
prosecution.” (emphasis supplied)
44. Reference has also been made on Modi's jurisprudence. With respect to the path of the bullet
inside the body in which the following observations have been made:
“while searching for a bullet, it must be borne in mind that it could take a very erratic
and unusual course while passing through the body. With respect to the
determination of the direction from which the weapon was fired, it further states asCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

under :
"The question regarding the direction of fire, whether from right to left or from front
to back is of medico−legal importance. To ascertain this, it is necessary to know the
position of the victim at the time of the discharge of the bullet, when a straight line is
drawn between the entrance and exit wounds and prolonged in front generally
indicates the line of direction. In some cases, it is difficult to determine the direction
as the bullet is so often deflected by the tissues that its course is very irregular, also
when the bullet wobbles.” (emphasis supplied) Though it has been observed that in
some cases it is difficult to determine a direction but in the instant case considering
the fact that the injuries are only on the right side which is on driver's side, 3 wounds
were caused on the chest and injury Nos.1, 5 and 6 were caused by the same bullet
obviously fired from the driver's side window only as is apparent from the direction
of communicating injuries also. There is no inconsistency in ocular and medical
evidence in the instant case.
45. It was submitted on behalf of the learned counsel appearing for the accused that PW−55 has
contradicted himself on the position of Haren Pandya’s body inside the car. In his examination−in−
chief he makes an improvement “pug upar thayi gay ahata” and that he had fallen on his back “vasa
na taraf “. This is an improvement to counter PW−8’s forensic opinion that the weapon would have
to be below the scrotum. On this count of improvement alone, PW−55 should be discredited. He has
not said that in his CBI statement or to the police that "Pug upar thayi gay ahata".
46. This Court in Sukhdeep Singh v. State of Uttar Pradesh and Anr., 2010 (2) SCC 177, this Court
has observed thus:
“17. We find, therefore, that the very basis of the argument raised by the learned
counsel on the basis of the statement of Dr. C.P. Srivastava that the injuries could not
have been caused while the deceased was in a standing posture is not borne out from
the cross−examination. Even otherwise, we believe that it would be impossible for
any witness to give a categorical statement as to the posture that the deceased or the
assailants were holding at the time when the firing incident happened. The trial court
was not justified in coming to a contrary conclusion as it appears to be a case of
misreading of the evidence.” (emphasis supplied)
47. It was further submitted that in the police statement PW−55 has stated that Haren Pandya
collapsed on the front seat then speaks of Shri Pandya having fallen on the driver’s seat. Later
speaks about his falling on the adjacent seat. CW−1 has stated that “car mein ulte hoke pade hue
hain”. It was submitted that he first says on the question whether he could see knees below steering
in the car, PW−55 has replied that he could see a part of the chest and knee. It was submitted that
when injury No.7 has been caused, the weapon could be below the level of his scrotum to his left.
Weapon pointing upwards when PW−55 has stated that the shooting happened from outside from
the small opening, he stands discredited by the medical evidence. It was further urged on behalf of
the accused that the submission of CBI that left leg of the deceased came up the injury No.7 isCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

impossible version, cannot be believed.
48. In our opinion, from the statement of PW−55 it is clear that when Haren Pandya fell in the car,
his leg came up. Obviously, the left leg would come up towards the driver's side and where the injury
is caused to him, obviously it would be in the same direction and travel the same way it has
travelled. The same is the statement of witness PW−55 made in the examination−in−chief cannot be
said to be an improvement. He has stated what he has seen. It is not necessary to state every minute
details in the statement under section 161 Cr.P.C. It is not for the autopsy doctor to give a vivid
description as to how the deceased reacted at the time when gunshots were fired upon him as he was
not an eye witness. In view of the evidence on record, the statement made by PW−55, the direction
of causing of injury No. 7 is fully explained and an eye witness cannot be said to state all these
details with mathematical precision. Question is whether he is otherwise reliable and whether other
evidence corroborates him. Corroborating evidence is available in abundance.
49. As to the precise distance inch−wise position at the time of firing, there is no witness who can
give an exact description as suggested in a lengthy cross−examination. Lengthy cross−examination
on this line was wholly uncalled for and wholly unnecessary and witness is not supposed to furnish
all such details with precision. Though the witness has withstood the test of cross−examination also.
50. The deposition of PW−55 was sought to be further discredited on the ground that when feet
came up, he could not refer to the position of knees with reference to the steering. The witness is not
supposed to give all these minute details. It is not a case where medical evidence completely
improbabilises the ocular evidence only on that case the ocular evidence has to be discarded not
otherwise. Reliance has been placed on behalf of accused on Abdul Sayeed v. State of Madhya
Pradesh, 2010 (10) SCC 259 thus:
"39. Thus, the position of law in cases where there is a contradiction between medical
evidence and ocular evidence can be crystallised to the effect that though the ocular
testimony of a witness has greater evidentiary value vis−à−vis medical evidence,
when medical evidence makes the ocular testimony improbable, that becomes a
relevant factor in the process of the evaluation of evidence. However, where the
medical evidence goes so far that it completely rules out all possibility of the ocular
evidence being true, the ocular evidence may be disbelieved.” (emphasis supplied)
51. In Nallapati Sivaiah v. Sub−Divisional Officer, Guntur, A.P., 2007 (15) SCC 465 the court
observed:
“52. The dying declaration must inspire confidence so as to make it safe to act upon.
Whether it is safe to act upon a dying declaration depends upon not only the
testimony of the person recording the dying declaration—be it even a Magistrate but
also all the material available on record and the circumstances including the medical
evidence. The evidence and the material available on record must be properly
weighed in each case to arrive at a proper conclusion. The court must satisfy itself
that the person making the dying declaration was conscious and fit to makeCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

statement for which purposes not only the evidence of persons recording the dying
declaration but also cumulative effect of the other evidence including the medical
evidence and the circumstances must be taken into consideration.” (emphasis
supplied)
52. In State of Rajasthan v. Bhanwar Singh, 2004 (13) SCC 147 the Court observed:
“6. We find that the High Court has carefully analysed the factual position. Though,
individually some of the circumstances may not have affected veracity of the
prosecution version, the combined effect of the infirmities noticed by the High Court
is sufficient to show that the prosecution case has not been established. The presence
of PWs 3, 4 and 8 at the alleged spot of incident has been rightly considered doubtful
in view of the categorical statement of PW 5, the widow that she sent for these
persons to go and find the body of her husband. It is quite unnatural that PWs 3, 4
and 8 remained silent after witnessing the assaults. They have not given any
explanation as to what they did after witnessing the assault on the deceased.
Additionally, the unexplained delay of more than one day in lodging the FIR casts
serious doubt on the truthfulness of the prosecution version. The mere delay in
lodging the FIR may not prove fatal in all cases. But on the circumstances of the
present case, certainly, it is one of the factors which corrodes credibility of the
prosecution version. Finally, the medical evidence was at total variance with the
ocular evidence. Though ocular evidence has to be given importance over medical
evidence, where the medical evidence totally improbabilises the ocular version that
can be taken to be a factor to affect credibility of the prosecution version. The view
taken by the High Court is a possible view. The appeal being one against acquittal, we
do not consider this to be a fit case where any interference is called for. The appeal
fails and is dismissed.” (emphasis supplied)
53. In this case, it cannot be said that ocular evidence is belied by the medical evidence. It was also
submitted on behalf of the accused that when the eye witness made an improvement to suit medical
evidence which has come on record by itself, it is sufficient to discredit him. Reliance has been
placed on Shingara Singh v. State of Haryana & Anr., 2003 (12) SCC 758 in which this Court has
observed:
“22. In our view, the High Court has completely missed the significance of the finding
recorded by the trial court. The trial court found that in the FIR as also the
statements recorded under Section 161 CrPC the witnesses had clearly mentioned
that both the appellants had climbed on top of the wall and from there Shingara
Singh, A−2 fired at Surinder Singh. If this version were to be accepted, the injury
caused would not have been of the nature found by the Medical Officer who was
clearly of the opinion, having regard to the trajectory of injuries, that the person
firing the firearm was at a lower level than the victim. Therefore, with a view to bring
their case in consonance with the medical evidence on record, all the three witnesses
made significant changes while deposing in court and all of them thereafterCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

consistently stated that while A−1 had climbed on top of the wall A−2 stood on the
ladder in such a manner that only his face was visible from across the wall and while
standing in that position, keeping the barrel of the gun on the wall and without
resting the butt of the gun against his shoulder, he fired at the deceased. There was
no dispute that their deposition in court was consistent, but what was observed by
the trial court was that their version as to the manner of occurrence as deposed to by
them was at variance with what was stated in the first information report by PW 5,
and in the statements of PWs 6 and 7 recorded under Section 161 CrPC. When
confronted with their earlier statements, they could not give a satisfactory
explanation, with the result that their credibility was sufficiently impeached.
The change of version by each one of them, and to the same effect, was deliberate and not merely
accidental or on account of lapse of memory. It cannot be disputed that this was a very significant
change. It cannot also be disputed that the change was deliberately made by all the witnesses so that
the prosecution case became consistent with the medical evidence on record. We, therefore, do not
find any error committed by the trial court in coming to this conclusion.” (emphasis supplied)
54. Reliance has also been placed by learned counsel for the accused on Ram Narain Singh v. State
of Punjab, 1975 (4) SCC 497 in which this Court has observed:
“2. ……..We might also mention here that the definite case of the prosecution before
the Sessions Judge was that while the shot was fired at the deceased Teja Singh by
Ram Narain Singh he had kept the right hand flexed on his chest. It was thus stated
by the eyewitnesses that at the time of firing, the deceased had put his right hand on
his chest. These two additions or embellishments appear to us to have been
necessitated in order to bring the evidence of the eyewitnesses in consonance with
the evidence of the doctor as also that of the ballistic expert, and we shall deal with
this aspect of the matter a little later….
xxx xxx xxx
6. …….. This particular posture was undoubtedly a most conspicuous fact which could
not have been missed by the witness if it was really there. In these circumstances,
therefore, we should have expected this fact to be mentioned in the FIR but it is
conspicuously absent from the FIR, nor was this fact mentioned by either Surjit
Singh or his brother Joginder Singh in their statements before the police or before
the committing Magistrate. It seems to us that the theory of the deceased having
placed his arm on the right side of his chest has been introduced only after the doctor
who was examined as the second witness in the Sessions Court stated in his
examination−in−chief that if the elbow of right arm is flexed lying in front of the
chest, then injuries Nos. 1 to 4 could be caused with a single firearm discharge. It
would appear that this witness was examined before the Sessions Court on May 14,
1973, and PW Surjit Singh was examined on the same day after the evidence of the
doctor was recorded. PWs Surjit Singh and Joginder Singh had to introduce theCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

theory of the deceased having put his right arm on his chest to bring the occurrence
in tune and in consonance with the evidence of the doctor. This was undoubtedly a
belated idea because if it had been a fact there is no reason why the eyewitnesses
should not have deposed to it in their statements before the police or even before the
committing court. Till that time the witnesses were not aware of the injuries said to
have been caused to the deceased Ram Narain Singh by a single fire unless the
deceased was in a particular posture. This fact came to light for the first time when
the doctor was examined in the Sessions Court and the witnesses in order to
corroborate their testimony with the evidence of the doctor introduced this
embellishment in the story of the assault on the deceased.
Considered against this background, the argument of the learned counsel for the appellants that the
evidence of the eyewitnesses was inconsistent with the medical evidence appears to be well founded.
In other words, the position is that if we discard this part of the evidence of the eyewitnesses which
has come to light for the first time in the Sessions Court, then according to medical evidence, the
deceased would have got two gunshots whereas it was never the prosecution case that Ram Narain
Singh or any other accused fired a second shot at the deceased at any time. The medical evidence,
therefore, clearly falsifies the prosecution case regarding the manner in which the deceased was hit.”
(emphasis supplied)
55. Counsel for the accused further submitted that there is an inconsistency between the ocular and
medical evidence which will destroy the prosecution case, the benefit of which must go to defence.
Reliance has been placed on Ram Narain Singh (supra) in which this Court has observed:
“14. Where the evidence of the witnesses for the prosecution is totally inconsistent
with the medical evidence or the evidence of the ballistic expert, this is a most
fundamental defect in the prosecution case and unless reasonably explained it is
sufficient to discredit the entire case. In Mohinder Singh v. State, AIR 1953 SC 415,
this Court observed in similar circumstances as follows:
“In a case where death is due to injuries or wounds caused by a lethal weapon, it has
always been considered to be the duty of the prosecution to prove by expert evidence
that it was likely or at least possible for the injuries to have been caused with the
weapon with which and in the manner in which they are alleged to have been caused.
It is elementary that where the prosecution has a definite or positive case, it is
doubtful whether the injuries which are attributed to the appellant were caused by a
gun or by a rifle.” It is obvious that where the direct evidence is not supported by the
expert evidence, then the evidence is wanting in the most material part of the
prosecution case and it would be difficult to convict the accused on the basis of such
evidence. While appreciating the evidence of the witnesses, the High Court does not
appear to have considered this important aspect, but readily accepted the prosecution
case without noticing that the evidence of the eyewitnesses in the Court was a belated
attempt to improve their testimony and bring the same in line with the doctor’s
evidence with a view to support an incorrect case.”Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

56. Reliance has been placed as to inconsistency between medical and ocular evidence by Counsel
for accused on State of Haryana v. Ram Singh, 2002 (2) SCC 426 in which this Court has observed:
“1. While it is true that the post−mortem report by itself is not a substantive piece of
evidence, but the evidence of the doctor conducting the post−mortem can by no
means be ascribed to be insignificant. The significance of the evidence of the doctor
lies vis−à−vis the injuries appearing on the body of the deceased person and likely
use of the weapon therefor and it would then be the prosecutor’s duty and obligation
to have the corroborative evidence available on record from the other prosecution
witnesses.
xxx xxx xxx
8. The principal contention raised in support of the appeal filed on behalf of the
accused persons has been that medical evidence as is available on record, completely
demolished the prosecution case……”
57. In Ram Narain Singh (supra) the Court observed that the prosecution has to prove that injury
was caused by the weapon in the manner as alleged. There is no dispute with the aforesaid
proposition. However, the applicability of ratio has to be seen in the facts and circumstances of each
case. In the instant case, the ocular evidence of PW−55 is not discredited by the medical evidence.
58. Even otherwise as submitted on behalf of the prosecution that in case of any discrepancy
between the ocular or medical evidence, the ocular evidence shall prevail, as observed in Yogesh
Singh v. Mahabeer Singh & Ors., (2017) 11 SCC 195:
“43. The learned counsel appearing for the respondents has then tried to create a
dent in the prosecution story by pointing out inconsistencies between the ocular
evidence and the medical evidence. However, we are not persuaded with this
submission since both the courts below have categorically ruled that the medical
evidence was consistent with the ocular evidence and we can safely say that to that
extent, it corroborated the direct evidence proffered by the eyewitnesses. We hold
that there is no material discrepancy in the medical and ocular evidence and there is
no reason to interfere with the judgments of the courts below on this ground. In any
event, it has been consistently held by this Court that the evidentiary value of medical
evidence is only corroborative and not conclusive and, hence, in case of a conflict
between oral evidence and medical evidence, the former is to be preferred unless the
medical evidence completely rules out the oral evidence. [See Solanki Chimanbhai
Ukabhai v. State of Gujarat, (1983) 2 SCC 174, Mani Ram v. State of Rajasthan,
(1993) Supp. 3 SCC 18, State of U.P. v. Krishna Gopal, (1988) 4 SCC 302, State of
Haryana v. Bhagirath, (1999) 5 SCC 96, Dhirajbhai Gorakhbhai Nayak v. State of
Gujarat, (2003) 9 SCC 322, Thaman Kumar v. State (UT of Chandigarh), (2003) 6
SCC 380, Krishnan v. State, (2003) 7 SCC 56, Khambam Raja Reddy v. Public
Prosecutor, (2006) 11 SCC 239, State of U.P. v. Dinesh, (2009) 11 SCC 566, State ofCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

U.P. v. Hari Chand, (2009) 13 SCC 542, Abdul Sayeed v. State of M.P., (2010) 10 SCC
259 and Bhajan Singh v. State of Haryana, (2011) 7 SCC 421.]”
59. The ocular evidence to prevail has also been observed in Sunil Kundu & Anr. v. State of
Jharkhand, (2013) 4 SCC 422 thus:
“24. In Kapildeo Mandal v. State of Bihar, (2008) 16 SCC 99, all the eyewitnesses had
categorically stated that the deceased was injured by the use of firearm, whereas the
medical evidence specifically indicated that no firearm injury was found on the
deceased. This Court held that while appreciating variance between medical evidence
and ocular evidence, oral evidence of eyewitnesses has to get priority as medical
evidence is basically opinionative. But, when the evidence of the eyewitnesses is
totally inconsistent with the evidence given by the medical experts then evidence is
appreciated in a different perspective by the courts. It was observed that when
medical evidence specifically rules out the injury claimed to have been inflicted as per
the eyewitnesses' version, then the court can draw adverse inference that the
prosecution version is not trustworthy. This judgment is clearly attracted to the
present case.” (emphasis supplied)
60. Similarly, in Bastiram v. State of Rajasthan, (2014) 5 SCC 398, it was observed:
“33. The question before us, therefore, is whether the “medical evidence” should be
believed or whether the testimony of the eyewitnesses should be preferred? There is
no doubt that ocular evidence should be accepted unless it is completely negated by
the medical evidence. This principle has more recently been accepted in
Gangabhavani v. Rayapati Venkat Reddy, (2013) 15 SCC 298.
xxx xxx xxx
36. Similarly, a fact stated by a doctor in a post−mortem report could be rejected by a
court relying on eyewitness testimony, though this would be quite infrequent. In
Dayal Singh v. State of Uttaranchal, (2012) 8 SCC 263, the post−mortem report and
the oral testimony of the doctor who conducted that examination was that no internal
or external injuries were found on the body of the deceased. This Court rejected the
"medical evidence" and upheld the view of the trial court (and the High Court) that
the testimony of the eyewitnesses supported by other evidence would prevail over the
post−mortem report and testimony of the doctor.
It was held: (SCC p. 286, para 41) “41. … [T]he trial court has rightly ignored the deliberate lapses of
the investigating officer as well as the post−mortem report prepared by Dr. C.N. Tewari. The
consistent statement of the eyewitnesses which were fully supported and corroborated by other
witnesses, and the investigation of the crime, including recovery of lathis, inquest report, recovery of
the pagri of one of the accused from the place of occurrence, immediate lodging of FIR and the
deceased succumbing to his injuries within a very short time, establish the case of the prosecutionCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

beyond reasonable doubt. These lapses on the part of PW 3 [doctor] and PW 6 [investigating officer]
are a deliberate attempt on their part to prepare reports and documents in a designedly defective
manner which would have prejudiced the case of the prosecution and resulted in the acquittal of the
accused, but for the correct approach of the trial court to do justice and ensure that the guilty did not
go scot−free. The evidence of the eyewitness which was reliable and worthy of credence has
justifiably been relied upon by the court.”” (emphasis supplied)
61. With respect to track of bullet for injury No. 7 much was argued. As already stated in Modi’s
Jurisprudence, the track of bullet may take a different course once the injury has been caused. Bullet
may ricochet inside the body after causing the injury. In view of entry wound as explained in Modi’s
jurisprudence too much cannot be made out of the direction when the injury could have been caused
in the method and manner suggested by PW−55. The High Court while appreciating injury No.7 has
not considered the fact that Haren Pandya fell down inside on adjoining seat and his left leg came up
as stated by the witness. The High Court has simply proceeded on the basis that the victim was
sitting on the driver’s seat or was sliding on to the adjoining seat. The aforesaid material part of the
statement of witness makes it clear how the injury was caused.
62. It was also urged that the mobile phone of Mr. Pandya was not investigated. In our opinion, it
was not necessary at all in the facts of the case. It is not disputed that he had left the house in the
morning to walk.
63. It was urged that no fingerprints were lifted from the car or from the weapon recovered
afterward and shoes were not recovered. In our opinion, it was not a case of a cold−blooded murder
where there was no eye witness. Thus, when the accused has not touched the car, taking fingerprints
from the car was not at all necessary and the weapon of offence has also been recovered from the
accused. It was not necessary after quite some time when its recovery was made to lift the
fingerprints from it. Merely non−recovery of shoes of deceased from the hospital where a large
number of persons had gathered by itself is not enough to discredit prosecution case.
64. The High Court in para 16 has observed that negligible blood was found near the driver’s seat.
The clothes of the deceased bore tell− tale signs of profuse bleeding from injuries on his neck and
fore−arm and mobile phone and keys lying under the seat had stains of blood. Thus, it is apparent
that there was blood on the seat as well as on the mobile phone and keys which were lying on the
floor.
65. As eye witness has clearly stated the position where he was. He has been cross−examined at
length, blood on cloth was found, how much, where it was found is not going to discredit the ocular
version and an entire incident.
66. When questioned about the blood, PW−8 has answered, it would depend whether haemorrhage
was internal or external. If there is internal haemorrhage there would not be much blood outside.
The volume of the blood on the spot would depend upon the type of injuries. Out of 7 bullet injuries,
6 were internal wounds, and on the fore−arm where minimum or less blood is possible, it was
external. In answer to question No.111, the doctor has stated.Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

67. The High Court has mostly proceeded on the basis that there should have been more blood
found in the Maruti car. As already discussed, it would depend upon the injury whether it was
internal bleeding and how a person is lying, it can also spill on the clothes and fact remains blood
has also been recovered from the Maruti car. It is not necessary for how much quantity it should
have been recovered. It was found on mobile phone also and keys as observed by the High Court.
Following facts supports that the incident has taken place as suggested by PW−55.
(a) Ex. 160: Panchnama of the place of offence would show that blood was found.
(b) Ex. 774: report of the mobile FSL would show that blood was found on the spot.
(c) Ex. 547: opinion of serology goes to indicate that human blood was found.
(d) Ex. 458: CFSL−biological division report: biological report would show that cotton swabs had B
group blood which belonged to the deceased.
(e) Ex. 451: 5 cotton swabs all indicating B group blood.
(f) The evidence of Y.A. Shaikh (PW 101) who deposed that he has lifted the blood sample by a
cotton swab.
(g) The evidence of Satyam Patel, PW−4 (Panch Witness) who deposed that blood was seen on the
seat at the relevant time which was rubbed with a small pellet of cotton which was sent to the
laboratory.
(h) The PM report would indicate that there was a lot of blood in the thoracic cavity to the tune of
2.2 litres.
(i) Ex. 457, 458 and 169: Panchnama of the clothes would indicate that the clothes had B group
blood.
68. Besides PW−85, R Sharma, Constable has also stated that at the time when deceased was taken
to the hospital, there was no bleeding from his body.
69. The post mortem was conducted on 26.3.2003. Time, therefore, is stated to be 5 to 6 hours
before post mortem which comes around 8 a.m. and tallies with the version of PW−55.
70. It was submitted that the FIR was not lodged by PW−55. The police control room was informed
by IGP Mr. Suman. Thus, the conduct of PW−55 does not inspire confidence, he was not an eye
witness. In our opinion, Anil Yadram, PW−55 had gone to inform the factum of the incident to the
owner of Chitty Bang, Mr. Nanubhai S Wala (CW−1) at Desai Hall. It is not uncommon for a person
to react in the manner PW−55 has done. He first wanted to inform the owner of the place as to the
murder of Haren Pandya. He was not a literate person.Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

. CW−1 has also supported the version of PW−55, the narration of incident to CW−1 by PW−55 is
quite natural and inspire confidence and there is due corroboration of the version by CW−1
Nanubhai. In the circumstances, non−production of Shukla Chacha who had simply given the lift in
a rickshaw to Anil Yadram, PW−55 and has taken him to the house of CW−1, Nanubhai does not
cause any dent in the prosecution version. Merely on the ground of non−examination of the witness
Kanhaiya, the deposition of PW−55 cannot be discarded. By the time PW−55 came back to the spot
police had already arrived and the body of the deceased was taken in another vehicle to the hospital.
Anil Yadram has stated to Nanubhai CW−1 that Haren Pandya had been shot dead and “woh gadi
mein ulte hokar ke pade hain” and he had seen the accused taking to their heels. It could not be said
from the deposition of PW−55 that he had received the information of the incident, in fact, he has
given a vivid description as eye witness noted PW−55 or CW−1 had no ill−will or malice against the
accused. It does not make any difference whether Nanubhai CW−1 was examined as a court witness
or as a prosecution witness. Once a witness has been examined, his evidentiary value has to be
considered in accordance with the law. Once he has been examined no question to draw any adverse
inference against the prosecution arises.
72. It was submitted that CW−1 had attempted to shrink the timeline by stating that PW−55 came at
around 9.15 a.m. instead of 9.45 a.m. On a rough estimate of time, no adverse inference can be
drawn as to the correctness of the version by the aforesaid witness. Estimation of time may differ by
some margin when a statement is made in court after years together. Merely by the fact that CW−1
asked PW−55 twice whether he had seen the incident, he said ‘yes' he had seen the incident twice.
That does not cause any dent in the prosecution case and does not render the statement of PW−55
doubtful in any manner. We find no embellishment or material improvement in the court's
statement as compared to the one recorded under section 161 Cr.P.C. The question of whether CW−1
had asked PW−55 whether he was speaking the truth and omission of that in the statement under
section 161 cannot be said to be a material omission. Material facts have been stated in the
statement and there is no contradiction with respect to the material facts with the statement under
section 161 Cr.P.C. as to the approximation of time also nothing can be made out by the accused.
73. The argument was raised on behalf of A−1 that PW−55 did not mention in the examination−in−
chief the time of the incident at around 7.30 a.m. He admitted that he does not have a watch. No one
can tell the correct time. How by the aforesaid statement any benefit can be derived by the accused,
passes comprehension as it is not uncommon that various persons do not keep a watch and they go
by rough estimation of the time. It was not necessary to speak about the time of occurrence in the
examination−in−chief nonetheless it has been brought about in the cross−examination. There is
nothing to disbelieve the estimation of time made in the cross−examination. Time assessment may
differ in some duration. It was urged that as far as the time consumed by PW−55 is concerned, the
incident had not taken place at 7.30 a.m., the submission is futile. As urged, in which condition the
deceased was taken to the hospital, is not material whether sitting or lying. He was taken to the
hospital when he was already dead.
74. It was urged that the conduct of PW−55 is inconsistent with that of an eye witness. The witness
should have contacted to the regular walkers in the Law Garden. He did not go to the Law Garden. It
is not likely that he had witnessed the incident. He has stated that he was too scared to go to theCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

police and stated to Shukla Chacha that he wanted to tell the police. In our opinion, overall conduct
of the witness is not unnatural considering the person belongs to poor strata of the society and
decided to inform the owner of the Chitty Bang where his cart was parked, is not common and is
very usual conduct in the course of normal human conduct.
75. It was submitted that on the basis of the statement of PW 55 sketch Ex. 620 was prepared. There
is crucial variance with the description recorded under section 161 Cr.PC. The descriptive features
mentioned by him are not even reflected in the sketch. PW−55’s deposition cannot be discredited or
tainted in any manner by faulty preparation of sketch. Even otherwise the evidence of sketch is not
of much significance. Sometime the sketch may not tally with the version given by a witness.
76. The High Court is moved by sketch Ex. 620 which was drawn. PW−55 denied any knowledge of
such a sketch. The sketch was not put to PW−55 in the cross−examination and to obtain his
explanation whether it tallied with the assailant. In the absence of cross− examination of PW−55 on
this aspect, the defence cannot take any advantage of a discrepancy, if any. I.O. PW−120 has stated
that Ex. 620 was prepared in the absence of PW−55, Anil Yadram Patel. It was drawn only on the
basis of his statement recorded under section 161 Cr.PC the way in which sketch was drawn it cannot
be considered reliable and trustworthy sketch. In the circumstances, sketch in the reference of the
accused ought not to have weighed with the High Court because it was prepared in the absence of
PW−55. PW−101 has stated that he got the sketch map prepared on the basis of the description and
handed over it to Mr. A.A. Chauhan, Police Inspector, Crime Branch.
77. In view of the identification made by the witness in the test identification parade, no dent is
caused by the so−called sketch in the ocular evidence of PW−55. Considering the intricate nature of
the investigation, we find that there was no undue delay in holding the T.I.P. It was held on 5.5.2003
after 20 days of the arrest of the accused. The accused had been identified in the same. Jagdish
Tiwari (PW−39) also, later on, had rightly identified A−1 (Mohmed Asgar Ali) as the assailant. The
decision relied upon in Subash and Shiv Shankar v. State of U.P. 1987 (3) SCC 331 wherein the test
identification parade was done after 3 weeks. In the facts of the said case, the identification was
disbelieved. The decision is distinguishable and turns on its own facts and circumstances.
78. It is the duty of the High Court to examine the details of the intrinsic merit of the evidence of
eye−witnesses. As observed by this Court in State of U.P. v. Sahai & Ors., AIR 1981 SC 1442, PW−55
has been cross−examined repeatedly on the same question as to Maruti Fronti came from Gajjar
Hall Cross Road side which he withstood. The reason employed by the High Court that the presence
of PW−55 at the gate at 7.30 a.m. (sharp) is doubtful, is also wrong as he was there because he had
parked his hand cart in the Chitty Bang and the fact is corroborated by CW−1, Nanubhai who was
known to him for the last 15 years. The time−frame employed by the High Court with respect to the
witness travelling time that he should have come back at 10.30 a.m. and not at 11 a.m. is based on
estimation as if PW55 was not a witness but was an accused. The version of the witness is not
shaken by the aforesaid aspect. The timing stated by the witness is by estimation as he did not carry
the watch. The High Court has adopted hyper−technical approach in assessing the evidence and has
been moved by minor discrepancies which do not go to heart of the matter and shake the basic
version of the prosecution witness, as held in Vijay @ Chinee v. State of M.P. 2010 (8) SCC 191, andCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

Bhajan Singh @ Harbhajan Singh & Ors. v. State of Haryana (2011) 7 SCR 1.
79. The High Court is also moved by the fact that PW−55 claims to have seen the kurta of Mr.
Pandya and stated the colour of stripes of kurta as brown whereas stripes of kurta were red in
colour. There can be confusion in identification of the colour of the kurta and memory may also fade
after several years and there is not much difference between red and brown. It is a minor
discrepancy which has weighed with the High Court whereas it ought to have been ignored. IN RE:
WHETHER BULLETS ARE THE SAME AS RECOVERED IN POST MORTEM
80. It was also submitted on behalf of A−1 that bullet recovered was not sent for ballistic
examination and bullets produced in court differ in colour and the state of deformation recorded
during post mortem. However, it is clear that it was not put to the doctor that the bullets which were
produced in the court, were not the same which he has recovered.
81. It was further submitted on behalf of the accused that the colour depends on whether it is a pure
lead bullet or a bullet with a lead core covered by a jacket of zinc. A pure lead bullet is used in a
revolver, a jacketed bullet with a lead core is used in a pistol. A pure lead bullet will never look
white. Its colour will always be greyish black. If pure lead bullets caused the wounds on Haren
Pandya's body, they would have been greyish black even when removed at the time of post mortem.
The bullet sent to CFSL and later produced in court were pure lead bullets which could never have
looked white. Therefore, these bullets could not be the ones recovered from the body at post mortem
which were white metal bullets, seen by the four doctors conducting the post mortem. As a matter of
fact, the doctor has clearly opined that white bullets were seized and they were sent for ballistic
examination and they have been produced from the CFSL. In our opinion, it was necessary to put in
the cross−examination of PW−8 the fact that the bullets which were produced in court were not the
same which were recovered at the time of post mortem, which has not been done. Thus his
testimony cannot be discredited on this aspect.
82. PW−75, Forensic Expert, Mr. Ashok Raj Arora, Senior Scientific Officer (Ballistics), Asstt.
Chemical Examiner to Government of India has stated that 5 shots were fired from a single standard
weapon. He compared the seals. The bullets were fired from a .32 revolver. IN RE: FORENSIC
EVIDENCE
83. As per the doctor, the bullets were made of white metal. The Autopsy doctor (PW−8) Mr. Pratik
Ravjibhai Patel however, on seeing the bullets Exhs. 18/1, 18/2, 18/3, 18/4 and 18/5, has clearly
stated that the color of the bullets is grayish and they were slightly deformed. It is not the cross−
examination made that these bullets were not found in the body. It was the duty of the cross−
examiner to obtain explanation that whether these bullets which were shown and stated by the
doctor to have been recovered from the body of Haren Pandya were not the same. When the doctor
has seen the bullets and had identified them that they were recovered from the body, no dent is
caused by the statement of the doctor that they were made of white metal. It is the perception of the
doctor of which metal they were made. Proper identification of the bullets recovered was established
in the court by the witness.Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

84. The prosecution has successfully established the chain of seizure of five very bullets up to
production in court which were recovered from the body of the deceased. PW−8 has stated that
during autopsy five bullets were recovered from the body of Haren Pandya which was handed over
to the (PW−170) police constable in sealed condition. (PW−170) Bipin Bhai, a constable on duty has
stated that he received five bullets in the sealed condition and has handed over the sealed five
bullets to police inspector Y.A. Sheikh (PW−101) in the presence of panch−witness, Falgun Pandya
(PW−2). Further, evidence of (PW−101), Y.A. Sheikh indicates that he has handed over five bullets
recovered from the body of Haren Pandya to PW−107 who during the course of the investigation had
handed over the same to PW120 on 28.3.2003. The evidence further discloses that PW−120, Dy.
S.P., Mr. Gupta forwarded the said five bullets vide letter dated 4.4.2001 in the sealed condition to
V.S.G.H./EBAB/Forensic Medicine through Director, CFSL, New Delhi vide letter dated 25.4.2004.
Exh.442 is the document of receipts by which five bullets were sent to Central Forensic Science
Laboratory, New Delhi with seal intact and specimen. Exh.458 points out that blood found on the
five bullets, kurta pyjama and lifted from the car was of ‘B’ Group. Thus, it is apparent that the seals
have been found intact and there is positive evidence of the custody of the appellants. Thus, it is far−
fetched and intentional for the defence to contend that bullets have been changed. There is no room
to entertain the said submission.
85. PW−75, Mr. Ashok Raj Arora, Senior Scientific Officer, (Ballistics), Assistant Chemical
Examiner, Government of India in his deposition has clearly stated that all the bullets are received
in sealed condition from CFSL, New Delhi. He has also identified articles 18/1 to 18/5 in the seal
applied on the backside of Khakhi cover which is stated to be muddamal article 18/5 which is the
seal he had applied. He has stated that he has examined articles 18/1 to 18/5 of which he has given
the details. He has further stated in his examination that the bullets were of blackish grey colour but
the one with a jacket would have copper or aluminum colour. If the bullet is of white metal then the
metal would be made of steel or aluminium but he has not seen nor examined the white coloured
jacket bullet. Thus, it is clear that what has been produced in the court are the same articles which
were examined by the forensic expert – (PW−75).
86. On behalf of the accused, it was submitted that the chemical test on the clothes has not been
done to ascertain the nature of bullets used in the offence. The test, as well as breach face mark,
have to be performed which is prescribed in the CBI Forensic Manual. The test is must to eliminate
by proper evidence before concluding that un− jacketed bullets had been used and therefore the
revolver was used. Metal will be present in both unjacketed and jacketed bullets. No copper test was
done in the case, therefore, it is not known whether the actual weapon was a pistol or revolver. In
our opinion, even in the absence of the aforesaid test, the evidence conclusively establishes that the
revolver was used in the offence for firing the bullets in question and that has been proved to be a
weapon of the offence and recovered too.
87. The evidence discloses that during the course of police custody Mohmed Asgar Ali (A−1) on
26.1.2003 gave a disclosure statement and indicated the place for recovery of the weapon in the
presence of Additional S.P. Chikara and Police Inspector PW−3 Shri Rathi. Mohmed Asgar Ali (A−1)
has mentioned in his disclosure statement (Exh.656) information pursuant to which two weapons –
i.e. one revolver and one pistol and the cartridges were recovered vide inquest memo Exh.196 alongCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

with the clothes Exh.1 which A−1 worn at the time of occurrence. PW−13, Shrinathsingh, panch
witness and Mr. Chikara have proved the aforesaid aspects. The weapons were recovered hidden in
the tank of Battiwla Stove at Kamar Flat in Shahpur. The aforesaid articles seized vide memo Exhibit
196 were sealed on the same day i.e. on 27.4.2003 and sent to CFSL, New Delhi along with the
clothes of Mohmed Asgar Ali (A−1). PW−75 received a list of the material objects along with
forwarding letter (Exh.443) along with .32 bore revolver bearing serial No.B 40350, six .32 bore
‘Scot & Webley‘ cartridges and 7.65 mm pistol bearing serial No.EE 0330, seven 7.65 mm pistol
cartridges and one 7.65 mm empty magazine bearing serial no.3497 and clothes of the accused A−1.
88. On the basis of the examination carried out by forensic examiner, it was opined that five .32 bore
fired bullets received by him on 25.4.2003 had been fired from .32 bore revolver bearing serial No.B
40350 and not from any other firearm, even of the same make, caliber or bore on the ground that
every firearm has its own individual characteristics marks.
89. Mr. Gupta (PW−120) in his deposition has stated that Mohd. Yousuf Maniyari, accused, who has
been detained has made a statement that five empty cartridge cases were given to him by
absconding accused Mufti Sufiyan on 3.4.2003. They were recovered from his shop tied in a cloth
vide seizure memo (Exh.628 dated 10.7.2003). Information memo (Exh.639) was drawn pursuant
to disclosure dated 10.07.2003. Mr.Arora (PW−75) received the parcel on 16.7.2003. In all, they
recovered four .32 bore S & WL fired cartridge cases. As they were required to be compared with .32
bore revolver bearing Serial No.B 40350, the same had been received by him once again and he
opined that these four .32 bore fired cartridges contained in parcel No.22 had been fired from .32
bore revolver bearing Serial No.B 40350. He also found that though the revolver was in working
condition the firing pin of the revolver was found tampered.
90. The prosecution urged that it is not the requirement of law that pellets recovered from the body
be sent to the ballistic expert to determine whether they were fired from the given article or not. On
the contrary, the recovery of pellets from the body clearly establishes the prosecution’s case that the
deceased died of the gunshot injuries. PW−8, surgeon is unaware of the difference between white
metal bullets/ jacketed bullet, as white metal is a cupro−nickel or zinc but, lead bullet is grayish
black and thus, the cupro zinc or cupro−nickel jacketed bullet in relation to lead bullet is said to be
white coloured metal whereas, grayish would indicate lead bullet.
91. It was argued that PW−75 did not find the firing pin damaged when the weapon was first
examined by him on 05.05.2003. The witness was not able to explain the reason for examining the
weapon once again and for the examination of the damaged firing pin. The defence submitted that
in the circumstances the identification would not be possible. The prosecution has submitted that
the breach face mark, if available and sufficient, can lead to provide identification in case of
tampering of a pin. Reliance has been placed on behalf of the accused on the deposition of Dr.
Jitendra Kumar Sinha (DW−8). He has admitted not to have seen any of the exhibits pertaining to
the case in question namely the firearms, crime cartridges, test cartridges, empty cartridges, etc. nor
had any occasion to examine those exhibits under a stereomicroscope. (DW−8) in the cross−
examination was questioned whether striation marks of the land and grooves imprinted on the
surface of the bullet would be individual characteristics marks. It was stated that there may beCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

striation due to extraneous marks which cannot be called individual characteristic explaining the
same. It was the wrong non−committal reply. The trial court in the circumstances has referred to
individual characteristics on the point and relied on “An Introduction of Tool Marks”, Firearms
under the heading of “Individual Characteristics” by John E. Davis, the Author observed as to the
striation marks thus:
"The "Individual Characteristics" on a fired bullet are those features which
distinguish it from bullets fired through all other bores. Practically speaking, the term
applies to those minute striae along the land and groove impressions which are
produced by, and are characteristic of irregularities within a given bore. Bullets are
finally identified with a specific weapon on the basis of these striae."
92. It is apparent that every fired bullet has individual characteristics in the form of minute striae
along with the land and groove impression. The bullets are finally identified with the specific
weapons on the basis of these striae. DW−8 has also stated that in 95 % of the cases, filing in marks
alone permit identification of the firearm, but in the event of any tampering of firing pin, the expert
would examine breach face mark which shall have to be compared with test fired cartridges to
confirm the opinion that the cartridges are fired from the said firearm.
93. The act of disclosure of the weapon and its discovery at the instance of A−1 and the bullets found
in the body of Haren Pandya was sent to CFSL, New Delhi wherein it has been opined that they have
been fired with the standard weapon (revolver of .32 bore), which had been recovered.
94. It was submitted by the prosecution that the same very cartridges were seized and sent to
Forensic Science Laboratory as stated by Dr. Kuldeep Jayantilal Joshi (PW−20), CMO, V.S.
Hospital, Dr. Anil Sharma (PW−19) and Bipinchandra Mehta (PW−70), panch witness PW−10, Y.A.
Shaik (PW−101), etc. These were received by PW− 75, Mr. Arora after the Department of Biology
tested it. The weapon was seized on 27.04.2003 and sent on 2nd/ 3rd May 2003 to CFSL. It is a fact
that initially when the expert first examined the revolver he did not realise the fact that the firing pin
of the said weapon tampered. When once again after the cartridge cases discovered at the instance
of the accused (A−17) were sent for the laboratory testing, he realised that the firing pin had
tampered. Be that as it may, the tale−telling marks of striae makes the position clear.
95. A correspondence between major striae, general gross counter and a reasonable number of finer
striae will prove identity. No two bullets encounter precisely the same conditions in passing through
a bore, nor do the corresponding striae always appear at the same lengthwise position on “identical‘‘
specimen.
96. Dr. Arora emphasised that while giving his testimony before the court that degree of similarities
which are found was never perfect identity considering the striking area covered by the tampered
fire pin and comparison of the same with the untampered firing pin.
97. Thus, the evidence of DW−8 also makes it clear that breach face alone is sufficient to confirm the
opinion if they are found to be repetitive and also of repetitive character of the striations which areCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

due to an individual firearm can be related to a particular firearm. In this case, while ignoring the
difference caused by tampering of the firing pin found the second time, the basic striation marks
remain the same which is individual for every revolver and is not to be found in any other such
weapon. Thus, the evidence is conclusive to prove that the revolver in question was used in firing the
bullets recovered from the body of the deceased Haren Pandya. The medical evidence, thus,
supports the version of PW−55.
98. PW−8 who prepared the post mortem report has been discarded while relying upon the version
of defence witness DW−6 who stated injuries 5 and 6 as communicating injuries. This Court in
Tanviben Pankajkumar Divetia v. State of Gujarat, (1997) 7 SCC 156 has observed that the autopsy
doctor’s report cannot be discarded lightly as he had seen the injuries. In Tanviben Pankajkumar
Divetia (supra) at para 35, this Court held as:
“35…..We may also indicate here that the doctor who had held the post mortem
examination had occasion to see the injuries of the deceased quite closely. In the
absence of any convincing evidence that the doctor holding post mortem examination
had deliberately given a wrong report, his evidence is not liable to be discarded and in
our view, in the facts of the case, the opinion of the doctor holding post mortem
examination is to be preferred to the expert opinion of Dr. Shariff.” (emphasis
supplied)
99. In Eshwaraiah & Anr. v. State of Karnataka, (1994) 2 SCC 677, this Court has observed in this
regard thus:
“9…..In our view, the High Court has lightly held that the said doctor had no occasion
to see the dead body and the injuries on the person of the deceased and only from the
report of the post mortem the said doctor gave an expert opinion. On the contrary,
two doctors who had held the post mortem on the deceased had occasion to look and
examine the injuries on the person of the deceased and they had given a clear opinion
that the death was due to asphyxia and it was a case of homicidal death…..”
(emphasis supplied) INTERPOLATION OF SPOT MAP
100. The site map was sought to be discredited on the basis that PW− 120, I.O. of CBI gave a
contradictory reply. He said that the original spot map was drawn by pencil and later on drawn in
ink. It was clearly stated that at the time of re−drawing the same, later on, the name of accused
Asghar Ali was mentioned as it was known by that time. No dent is caused by the said mentioning of
the name of the accused and from the explanation given by PW−120, it is apparent that the name
has been added later on.
101. The High Court has also doubted by prosecution case with respect to interpolation and site map
with respect to the name of A−1. Dr. Gupta, I.O. of CBI, PW−120 has explained the said aspect in the
following manner:Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

"Question: You are being shown Exh−387. At the bottom, the word Asagarali is
written, and has it been checked in Note−3 thereafter?
Answer: Looking at it through the magnifying glass, I say that I am unable to say. The
witness states clarifying that the site plan of Exh− 387 was drawn at the time on
29/3/03 with pencil, and at each place, the noting was made with pencil. At the time
of attaching it to the charge sheet, it was very dim and therefore, it was made clearer
with the help of sketch pen and the drawing and the writing made with the pencil has
been stroked out and the note written at the bottom was written at the time of filing
the charge sheet. Therefore, there are some pencil marks on this paper. At the place
of ‘A', ‘D' and Law−Garden, NCC Ground and HP Car, etc. is written, it seems. The
writing done on the entire sketch is made by my colleague PI Mr. Vijayvirsinh in his
handwriting. The noting point – 3 and 4 written after erasing would have been falsely
written by Vijayvirsinh. So it was removed/erased, but I do not agree with the view
that Asagarali has written it.
Question: After writing the name of Asagarali in Note−3 and Exh− 387, you have
erased it?
Answer: I do not agree with that view.
It is not true and I do not agree with this view that on 29/3/03, we knew that we
would book Asagarali in this case. He is to be implicated, and his name was written
and later when it was realized that it was the document dated 29/3/03, his name was
spoken out.” The High Court ought to have taken note of the aforesaid statement in
what circumstances name came to be added later on. It was clearly a mistake as
admitted by the witness.
NON−EXAMINATION OF JAGRUTIBEN, W/O. HAREN PANDYA
102. It was submitted on behalf of the accused that Ms. Jagrutiben, wife of Haren Pandya should
have been examined so as to prove that the offence took place at about 7.30 a.m. as she has stated in
the statement under Section 161 Cr.P.C. that deceased left house at around 7.00 a.m. Some of the
friends of deceased and P.A. etc. later on reached the spot they have not been examined. In our
opinion, no dent is caused as Jagrutiben and other persons were not the eye− witnesses. In case of
any doubt, they could have been examined as defence witnesses. Jagrutiben, even if examined,
would have proved the fact that deceased left for Law Garden at around 7 a.m. and he would have
reached there around 7.10 a.m. No benefit can be drawn from the aforesaid aspect. No adverse
inference can be drawn against prosecution due to non−examination of Jagrutiben. As estimation of
time may differ and as per Jagrutiben, deceased left for Law Garden only where he used to go for a
morning walk.
IN RE: CALL RECORDSCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

103. Learned Addl. Solicitor General on behalf of the prosecution has submitted that all call records
of the accused persons during the entire period of conspiracy and the tower location of the phones of
the accused persons near the Law Garden on the day of the murder of Haren Pandya are the strong
circumstantial evidence against the accused persons. The accused persons were in possession of
mobile phones and were in constant touch with each other before, during and after the commission
of the crime through their mobile or landline phones, as depicted in the call details records, in order
to execute the conspiracy. As mobile phone No.9825491421 was used by A−1, his location at 7.33
a.m. on 26.3.2003 in the area near Law Garden and A−14 providing three new BSNL SIMs. to A−7,
A−8 and A−9 on 25.3.2003 and their location on 25.3.2003 and 26.3.2003 near Law Garden were
strong corroborative evidence of the presence of some of the accused in the Law Garden area. The
printouts of email sent by A− 1, A−2 and A−18 revealed that they were operating in furtherance of a
common object as also the presence of some of them in Udaipur and Ahmedabad, even as the text of
email messages did not reveal any specific plan of committing any particular crime. It is pertinent to
mention that the trial court has extensively dealt with the mobile phone, sim card details and the
evidence adduced to prove the usage of the said phone handsets and sim cards by the accused
persons. IN RE: MOTORBIKE USED BY A−1 AND A−6 :
104. The motorbike used by A−1 and A−6 at the time of the commission of the offence
was duly recovered. The entire gamut of facts relating to the motorbike is as under:
(i) A−10 purchased motorcycle No.GJ−ISS−5934 from PW−54 and gave it to A−1 in
the first week of February 2003 for his movements in Ahmedabad.
(ii) After the commission of a crime, the motorcycle was handed over by A−10 to
PW−45 while fleeing from Ahmedabad on 4.4.2003 and thereafter PW−45 parked the
same in the parking of Kalupur Railway Station from where the same was recovered
by CBI in presence of PW−24 on the night intervening 24/25.4.2003.
(iii) In December 2002, on the directions of A−13, PW−57 (hostile witness but statement under
section 164 Cr.PC arranged 3 stolen motor Hero Honda motorcycles and handed over the same to
A−4. Thereafter, A4 retained one with him and handed over one each to A−14 and A−5. Later on,
these motorcycles were used in the commission of a crime on 11.3.2003, 25.3.2003 and 26.3.2003.
(iv) One of the stolen motorcycles was handed over by A−10 to PW−45 on 3/4.4.2003 while fleeing
from Ahmedabad. PW−45 parked the same in Apsara Aradhna Theatre and later on brought by PS
Kagdapeeth from where it was seized by CBI on the pointing of PW−45 on 25.4.2003.
(v) A fake number plate bearing No.GJ−ICH−5189 was got prepared by A−7 and A−8 from PW−52.
This number plate was put on the second Hero Honda motorcycle after the commission of a crime.
(vi) The said motorcycle was abandoned by A−10 and A−11 while fleeing from Ahmedabad at
Tarapur Highway. The fake number plate was removed from the motorcycle and thrown into
roadside bushes which were recovered under section 27 Evidence Act at the pointing out of A−10 in
presence of PW−86 on 12.6.2003. the said motorcycle was taken into possession by PS Koth andCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

thereafter seized by CBI on 12.6.2003 from PS Koth. Presence of A−1 at Ahmedabad is proved by the
use of phone number and by PW−95.
105. With respect to the disappearance of the mobile phone of accused A−1, no such question was
put to I.O., PW−120 that mobile of A−1 had disappeared from Muddamal. Neither any mobile phone
nor any sim card was seized from A−1 on his arrest by one DIG Shri Behra. It is, in fact, Yusufbhai,
PW−95 who is an independent witness who stayed in the same Royal Apartments as A−1 has proved
that A−1 was using mobile No.9825491421 during the relevant time. PLACE OF EYE WITNESS NOT
DEPICTED IN SPOT MAP
106. With respect to not showing the presence at a particular spot of an eye−witness in the spot
map, reliance has been placed by the prosecution on a decision of this Court in Tori Singh & Anr. v.
State of U.P., AIR 1962 SC 399. With respect to the spot map, it has been observed that it would be
based on hearsay of witness. Spot map would be admissible so far as it indicates all that the
Inspector saw himself at the spot. Any mark put on the spot map on the basis of statements made by
the witness to the Inspector would be inadmissible in view of the clear provisions of section 162
Cr.P.C. This Court has observed thus:
“7. We are of opinion that neither of these arguments has any force. Let us first take
the contention that it was most unlikely that the deceased would be hit on that part of
the body where the injury was actually received by him if he was at the spot marked
in Ex. Ka−9. The validity of this argument depends mainly on the spot which has
been marked on the sketch−map Ex. Ka−9 as the place where the deceased received
his injuries. In the first place, the map itself is not to scale but is merely a rough
sketch and therefore one cannot postulate that the spot marked on the map is in
exact relation to the platform. In the second place, the mark on the sketch−map was
put by the Sub− Inspector who was obviously not an eyewitness to the incident. He
could only have put it there after taking the statements of the eyewitnesses. The
marking of the spot on the sketch−map is really bringing on record the conclusion of
the Sub−Inspector on the basis of the statements made by the witnesses to him. This
in our opinion would not be admissible in view of the provisions of Section 162 of the
Code of Criminal Procedure, for it is in effect nothing more than the statement of the
Sub−Inspector that the eyewitnesses told him that the deceased was at such and such
place at the time when he was hit. The sketch−map would be admissible so far as it
indicates all that the Sub− Inspector saw himself at the spot; but any mark put on the
sketch− map based on the statements made by the witnesses to the Sub− Inspector
would be inadmissible in view of the clear provisions of Section 162 of the Code of
Criminal Procedure as it will be no more than a statement made to the police during
investigation. We may in this connection refer to Bhagirathi Chowdhury v. King−
Emperor, AIR 1926 Cal. 550, where it was observed that placing of maps before the
jury containing statements of witnesses or of information received by the
investigating officer preparing the map from other persons was improper and that
the investigating officer who made a map in a criminal case ought not to put anything
more than what he had seen himself. The same view was expressed by the CalcuttaCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

High Court again in Ibra Akanda v. Emperor, AIR 1944 Cal. 339, where it was held
that any information derived from witnesses during police investigation, and
recorded in the index to a map, must be proved by the witnesses concerned and not
by the investigating officer, and that if such information is sought to be proved by the
evidence of the investigating officer, it would manifestly offend against Section 162 of
the Code of Criminal Procedure.”
107. In Pratap Singh & Anr. v. State of M.P., 2005 (13) SCC 624, it was held that even if the
witnesses are not reflected in the site plan, that does not bar the prosecution to produce such
witnesses during the trial. Since PW−55 has not been confronted with the site plan and no question
had been asked to the witness, thus his ocular evidence cannot be discredited on the basis of the
aforesaid omission. I.O. NOT ON SPOT
108. The High Court has also employed the reason that Police Inspector PW−101 was supposed to be
investigating at 2 p.m. on 26.3.2003 at the scene of the offence. He was shown present at post
mortem at 2.15 p.m. PW−101 in this regard he has explained that he handed over the papers to Head
Constable. Post Mortem might have been made at 2.15 p.m. but he was not present in the post
mortem room at that time. The statement of the witnesses ought to have prevailed as to his presence
on the spot.
RECOVERY OF REVOLVER AND PISTOL FROM A−1:
109. In spite of the tampering of the firing pin, the material striations are telling the
tale and overall evidence inspires confidence and no dent is caused in the prosecution
case. In our considered opinion the bullets and cartridges seized from A−1 match
with the revolver and bullet recovered from Haren Pandya's body. We reject the
submission raised by A−1. The recovery was from the rented flat of A−1 at
Ahmedabad. No one had access to the place and knowledge. Thus, the recovery at the
instance of A−1 is not doubtful.
110. Statement of PW−76, Akhtar is not at all with respect to the disclosure and
discovery attributed to A−1 on the intervening night of 26.4.2003 and 27.4.2003 of a
revolver, pistol, and cartridges. PW−76 has deposed as to the motorcycle. In our
opinion, it was not for the police to explain as to who had put two locks on the flat as
submitted by the accused. That no adverse inference can be drawn for failure to
explain putting of 2 locks. In no case, locks can be attributed to CBI.
111. The High Court has observed that in view of the concession granted by the
counsel for the appellants, voluminous records and number of controversies about
each piece of evidence, it was not necessary to be dealt with and each and every
argument of learned counsel for both the sides. It could not be said to be the proper
approach of the High Court. The High Court ought to have examined the entire
background as to what facts and circumstances prevailed and whether the chain was
complete to make out the case of conspiracy. It was absolutely necessary so as to findCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

out the conspiracy. The acquittal recorded by the High Court was wholly uncalled for
and is based on basically a wrong approach. It was incumbent upon the High Court to
come a close quarter of reasoning employed by the trial Court and assessment of the
evidence of the witnesses done by the trial court with great care, in an elaborate
manner. The High Court has failed to consider the reasons and has jumped to the
conclusion.
IN RE: SECTION 32 OF POTA:
112. We now take the question for consideration whether confessional statements
have been recorded after due compliance of provisions of section 32 of POTA. The
confession of the accused persons recorded under section 32 of POTA proves the
involvement of each and every accused person in the criminal conspiracy. The
question has been raised that whether the safeguards provided under section 32 have
not been observed.
113. Section 32 of the POTA contains a non−obstante clause like notwithstanding
anything in the Criminal Procedure Code or in the Indian Evidence Act and makes
admissible certain confessions made to the Police Officers. However, the same is
subject to the provisions of section 32 which is extracted hereunder:
“32. Certain confessions made to police officers to be taken into consideration.—(1)
Notwithstanding anything in the Code or in the Indian Evidence Act, 1872 (1 of 1872),
but subject to the provisions of this section, a confession made by a person before a
police officer not lower in rank than a Superintendent of Police and recorded by such
police officer either in writing or on any mechanical or electronic device like
cassettes, tapes or sound tracks from out of which sound or images can be
reproduced, shall be admissible in the trial of such person for an offence under this
Act or the rules made thereunder.
(2) A police officer shall, before recording any confession made by a person under
sub−section (1), explain to such person in writing that he is not bound to make a
confession and that if he does so, it may be used against him:
Provided that where such person prefers to remain silent, the police officer shall not
compel or induce him to make any confession.
(3) The confession shall be recorded in an atmosphere free from threat or
inducement and shall be in the same language in which the person makes it.
(4) The person from whom a confession has been recorded under sub−section (1),
shall be produced before the Court of a Chief Metropolitan Magistrate or the Court of
a Chief Judicial Magistrate along with the original statement of confession, written or
recorded on the mechanical or electronic device within forty−eight hours.Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

(5) The Chief Metropolitan Magistrate or the Chief Judicial Magistrate, shall, record
the statement, if any, made by the person so produced and get his signature or thumb
impression and if there is any complaint of torture, such person shall be directed to
be produced for medical examination before a Medical Officer not lower in rank than
an Assistant Civil Surgeon and thereafter, he shall be sent to judicial custody.”
114. Following safeguards are provided in the provisions contained in section 32 of
the Act :
(i). Confession to be made by the person before a Police Officer not lower in rank
than a Superintendent of Police.
(ii). It has to be recorded either in writing or on any mechanical or electronic device
like cassettes, tapes or soundtracks.
(iii). The Police Officer before recording confession has to appraise the accused in
writing that he is not bound to make a confession and in case he makes it, the same
may be used against him.
(iv). That accused shall not be compelled to make any confession.
(v). The confession shall be recorded in an atmosphere free from threat or
inducement.
(vi). Confession to recorded in the same language in which it is made.
(vii). The person who has confessed shall be produced before the court of Chief
Metropolitan Magistrate or CJM along with the recorded confession within 48 hours.
(viii). The CMM/CJM shall record the statement, if any, made by the person so
produced and get his signature or thumb impression on it.
If there is any complaint of torture by such a person, he shall be referred for medical examination to
an Assistant Civil Surgeon or any officer higher in rank.
(ix). The person shall be sent to judicial custody and not to police custody.
115. It was urged on behalf of the CBI that all the aforestated safeguards have been observed. The
submission has been refuted by Ms. Nitya Ramakrishnan and other learned counsel appearing on
behalf of the accused persons.
116. First, we examine whether the basic safeguards of section 32 have been observed or not. Dy. SP,
CBI on 18.6.2003 wrote a letter to the SP, ACB, Gandhi Nagar to the effect that accused Asghar Ali
has expressed his willingness to make confessional statement voluntarily. The Superintendent ofCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

Police was requested to record his statement under section 32 of POTA. After receiving the said
communication, the SP, ACB, CBI has recorded that he directed the Dy. S.P. to produce the accused
person before him on 18.6.2003 at 7 p.m. after handing over custody of the accused to some other
officer. Following proceedings had been recorded by the S.P. :
“Today on 18.6.2003, I received a requisition from Dr. S.K.Gupta, Dy. S.P., CBI, SIC
I, New Delhi, (Camp Gandhi Nagar), in CBI RC.5(S)/2003− SIU.I/SIC.I/CBI/New
Delhi requesting me to record the confessional statement of accused Asghar Ali under
Section 32 of the Prevention of Terrorism Act, 2002 (POTA). Accordingly, I directed
Dr. S.K. Gupta to produce accused before me on 18.6.2003 at 7.00 p.m. after handing
over the custody to some other officer.”
117. On the accused Asghar Ali being produced before the S.P., he has recorded the following
proceedings:
“ Proceedings under s. 32 of Prevention of Terrorism Act, 2002.
Accused Asghar Ali, S/o Mohd. Wazir Ali, aged 27 years, R/o House No.8/3/113,
Darusafa Colony, Nalgonda, Hyderabad, was today produced before me on 18th day
of June, 2003 at around 7.00 p.m. in the Chamber of S.P., CBI/ACB by ASI Shri
Ishwar Chand Sharma, for recording his statement under Section 32 of the
Prevention of Terrorism Act, 2002 (POTA) in connection with Case No. CBI
RC.5(S)/2003− SIU.I/SIC.I/CBI/New Delhi (Jagdish Tiwari case).”
118. After the ASI who produced him was asked to go out of the room when he went away, only the
S.P. and accused remained inside the room. The S.P. had again put certain questions and apprised
him all the details of the case and also ascertained from him whether he wanted to make a
confessional statement. Accused was told that he was not legally bound to make such a statement. In
case any such statement was made, the same may be used as evidence against him. He was also
asked whether he was under any fear, pressure or greed or was beaten, tortured physically and
mentally by anyone. He agreed to give a statement and denied to be under any fear, pressure or
greed or beaten up or tortured in any manner. He was told that he was not legally bound to give the
confessional statement. The S.P. had also recorded a finding that there was no physical injury, mark
of violence on his person. The S.P. ordered in writing for keeping the accused Mohd. Asghar Ali for
the purpose of his reflection in order to make up his mind whether he actually wanted to make a
confessional statement or not and no one is allowed to meet him during the period of reflection. On
18.6.2003 following questions were put :
“I asked ASI Ishwar Chand Sharma to go out of the room, and he went away.
Thereafter, only myself and the accused remained inside the room.
I asked the following questions from the accused and the answers to the questions
were given by the accused.Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

Q. Tell me your name, your father's name, your age, and address?
A. My name is Asghar Ali, s/o Mohd. Wazir Ali, aged 28 years, R/o House No.
8/3/113, Darusafa Colony, Nalgonda, Hyderabad. Q.What are your educational
qualifications? A. I am 10th fail.
Q. What is your occupation?
A. I was doing business of grocery and general stores. Q. When you were arrested and
for which crime? A. I was arrested by the CBI in connection with the Jagdish Tiwari
case on 12.6.2003.
Q. Do you know that I am a Superintendent of Police? A. Yes, I know that.
Q. Do you know why you have been produced before me? A. Yes I know I have been
produced before you for recording of my confessional statement.
Q. Do you wish to confess to your crime?
A. Yes Sir.
Q. Do you know that you are not legally bound to five the confessional statement, and
if you give any such statement, it would be used as evidence against you?
A. I do not know anything about this. But you have explained me and therefore I have
understood it now.
Q. Are you giving this confessional statement under any fear, pressure or greed?
A. No. I am giving this statement voluntarily on my own.
Q. Have you been beaten or tortured physically and mentally anyone?
A. No. . The answers to the above questions were given by accused on his own
volition and the questions and answers were read over and explained to accused and
he admitted them to be correct and signed the same.
Sd/− Illegible Mohd. Asghar Ali Sd/− Illegible Vinayak P. Apte Superintendent of
Police CBI/ACB, Gandhi Nagar”
119. On 21.6.2003 the accused was again told that he was not bound to give a confessional statement
as mentioned above. The proceedings recorded on 21.6.2003 by the S.P. are extracted hereunder :Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

“At this time, I warned the accused that he is not legally bound to give the
confessional statement and if he gives any such statement, it would be used as
evidence against him. I examined the person of accused and found no apparent or
visible injury on his person or any mark of violence. I ordered for keeping the accused
Mohd. Asghar Ali alone for the purpose of reflection in order to further make up his
mind whether he actually wants to make his confessional statement or not. I further
instructed that no one be allowed to meet him during the period of reflection.
Sd/− Illegible Mohd. Asghar Ali Sd/− Illegible Vinayak P. Apte Superintendent of
Police CBI/ACB, Gandhi Nagar”
120. After 65 hours lapsed, after the accused was given warning, he was directed to be produced
before the S.P. who has recorded that during his period of reflection, no person was allowed to meet
him. Once again warning was given. He was asked why he wanted to give a confessional statement.
He was told the consequence of confessional statement once again that it could be used against him
to which he answered that he knew it very well. Following is the note prepared by the S.P.:
“Now more than 65 hours have passed since accused was given warning and accused
was directed to produced in the Chamber of SP/CBI/ACB, Gandhinagar. During the
period of reflection, no person was allowed to meet or talk to him.
There is no other person in the Chamber of SP, CBI, ACB, Gandhi Nagar, except
myself and the accused Mohd. Asghar Ali. Following questions are again put to him.
Q. What is the decision you have taken for giving the confessional statement during
long duration of time since 18.6.2003? A. I have decided to give my confessional
statement. Q. Why are you willing to give confessional statement? A. Because I want
to lessen my burden and I want to confess my crime.
Q. I am once again warning you that you are not legally bound to give the
confessional statement and if you give any such statement, it would be used as
evidence against you?
A. Yes, I know very well.
Sd/−Illegible Mohd. Rauf.
Sd/− Illegible 21.6.2003”
121. Thereafter his confessional statement had been recorded by the S.P. After recording the
confessional statement, Asghar Ali has signed it. It has been mentioned that the confessional
statement has been read over and explained to the accused. He has admitted it to be correct. The
S.P. has appended a bottom note to the statement that he has informed the accused that he was not
bound to give his confessional statement. If he gives it, it could be used against him. He has given itCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

voluntarily, without any fear or pressure and it has been recorded by him, read over to the accused.
It has been heard, understood and admitted to be correct by the accused and confession has been
recorded whatever has been given by the accused. Following is the relevant portion of the aforesaid
proceedings:
“The above statement has been read over and explained to the accused which has
been admitted by him as correct. Sd/− Asgar Ali.
Sd/− Vinayak. P. Apte Supt. of Police CBI/ACB Gandhinagar At this stage I informed
the accused that he is not bound to give his confessional statement. I also informed
the accused that if he gives his confession statement the same would be used in
evidence against him. I have confidence that the accused gave his confession
statement voluntarily and without any pressure, fear and voracity. The confession
statement has been recorded by me personally and has been read over and over and
explained to the accused and the entire confession statement has been heard,
understood and admitted to be correct by the accused. The same confession
statement has been recorded whatever has been given by the accused.
Sd/− 21.6.03 Vinayak P. Apte Supt. Of Police CBI/ACB Gandhinagar Accused Asghar
Ali has been handed over to Dr. S.K. Gupta, Dy. S.P, SIC−I, CBI, New Delhi Camp
Gandhi Nagar today on 21.6.2003 at 3.00 PM.
Sd/− 21.6.03 Vinayak P. Apte Supt. Of Police CBI/ACB Gandhinagar” In view of the
aforesaid, it is apparent that the provisions of section 32(1), (2) and (3) of POTA have
been complied with.
122. On 21.6.2003 the accused was produced before the Special Magistrate for CBI, Ahmedabad. An
application was also filed under section 32(4) of the POTA for producing accused. It was mentioned
that the confessional statement has been made by the accused voluntarily without fear, threat or
inducement while recorded by the SP, CBI, ACP. The Magistrate has asked the accused whether he
was ill−treated or tortured by the CBI while in custody recording confessional statement to which he
replied in the negative. He further stated that he has voluntarily made the confessional statement.
On that, he was sent to judicial custody till 4.7.2003.
123. It is pertinent to mention here that a similar process has been followed while recording the
confessional statement of accused persons by PW−21 under section 32 of POTA.
124. It is submitted that on the strength of a decision of this Court in State (NCT of Delhi) v. Navjot
Sandhu etc., (2005) 11 SCC 600 (hereinafter referred to as ‘the Parliament attack case"), POTA has
absorbed into it the guidelines spelled out in Kartar Singh's case (1994) 3 SCC 569, and there is a
conscious improvement over the TADA Act. Therefore, TADA is no guide to understanding the same
with respect to confirmation proceedings before the Magistrate. Following is the relevant portion:Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

“156. As already noticed, POTA has absorbed into it the guidelines spelt out in Kartar
Singh v. State of Punjab, (1994) 3 SCC 569 and D.K. Basu v. State of W.B., (1997) 1
SCC 416, in order to impart an element of fairness and reasonableness into the
stringent provisions of POTA in tune with the philosophy of Article 21 and allied
constitutional provisions. These salutary safeguards are contained in Sections 32 and
52 of POTA. The peremptory prescriptions embodied in Section 32 of POTA are:
(a) The police officer shall warn the accused that he is not bound to make the
confession and if he does so, it may be used against him [vide sub−section (2)]. (b)
The confession shall be recorded in an atmosphere free from threat or inducement
and shall be in the same language in which the person makes it [vide sub−section
(3)]. (c) The person from whom a confession has been recorded under sub−section
(1) shall be produced before the Chief Metropolitan Magistrate or Chief Judicial
Magistrate along with the original statement of confession, within forty−eight hours
[vide sub− section (4)]. (d) The CMM/CJM shall record the statement if any, made by
the person so produced and get his signature and if there is any complaint of torture,
such person shall be directed to be produced for medical examination. After
recording the statement and after medical examination, if necessary, he shall be sent
to judicial custody [vide sub− section (5)].
The mandate of sub−sections (2) and (3) is not something new. Almost similar prescriptions were
there under TADA also. In fact, the fulfilment of such mandate is inherent in the process of
recording a confession by a statutory authority. What is necessarily implicit is, perhaps, made
explicit. But the notable safeguards which were lacking in TADA are to be found in sub− sections (4)
and (5).
157. The lofty purpose behind the mandate that the maker of the confession shall be sent to judicial
custody by the CJM before whom he is produced is to provide an atmosphere in which he would feel
free to make a complaint against the police if he so wishes. The feeling that he will be free from the
shackles of police custody after production in court will minimise, if not remove, the fear psychosis
by which he may be gripped. The various safeguards enshrined in Section 32 are meant to be strictly
observed as they relate to personal liberty of an individual. However, we add a caveat here. The
strict enforcement of the provision as to judicial remand and the invalidation of the confession
merely on the ground of its non−compliance may present some practical difficulties at times.
Situations may arise that even after the confession is made by a person in custody, police custody
may still be required for the purpose of further investigation. Sending a person to judicial custody at
that stage may retard the investigation. Sometimes, the further steps to be taken by the investigator
with the help of the accused may brook no delay. An attempt shall however be made to harmonise
this provision in Section 32(5) with the powers of investigation available to the police. At the same
time, it needs to be emphasised that the obligation to send the confession maker to judicial custody
cannot be lightly disregarded. Police custody cannot be given on the mere asking by the police. It
shall be remembered that sending a person who has made the confession to judicial custody after he
is produced before the CJM is the normal rule and this procedural safeguard should be given its due
primacy. The CJM should be satisfied that it is absolutely necessary that the confession maker shallCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

be restored to police custody for any special reason. Such a course of sending him back to police
custody could only be done in exceptional cases after due application of mind. Most often, sending
such person to judicial custody in compliance with Section 32(5) soon after the proceedings are
recorded by the CJM subject to the consideration of the application by the police after a few days
may not make material difference to the further investigation. The CJM has a duty to consider
whether the application is only a ruse to get back the person concerned to police custody in case he
disputes the confession or it is an application made bona fide in view of the need and urgency
involved. We are therefore of the view that the non−compliance with the judicial custody
requirement does not per se vitiate the confession, though its non−compliance should be one of the
important factors that must be borne in mind in testing the confession.”
125. This Court has observed that safeguards have been provided in various provisions made in
section 32. Exclusive provisions have been made in section 32. The notable safeguards which were
lacking in TADA are to be found in sub−sections (4) and (5). While interpreting the provisions of
section 32(5), this Court has observed that ordinarily the person should be sent to judicial custody.
In exceptional cases, police custody can be granted and not otherwise. Non−compliance with usual
custody requirement does not per se vitiate the confession. In the instant case, the accused persons
have been sent to judicial custody and the provisions of section 32 have been complied with in pith
and substance.
126. It was also submitted on behalf of accused persons the strength of the Parliament attack case
that the Magistrate should have read out the confession or at least gist of the same for compliance of
provisions of section 32(5). The magistrate should also assure the accused beforehand that he can be
sent to judicial custody and thereafter it is not enough that he ends up sending him to judicial
custody. The statement of the accused is read over by the S.P. and if the same is admitted to be
correct, thereafter he had put his signatures. Section 32(4) requires that the person whose
confession has been recorded to be produced before the Magistrate along with an ordinary
statement of confession within 48 hours. The Magistrate shall record the statement, if any, made by
the person so produced and get his signatures or thumb impression. If there is any complaint of
torture then medical examination has to be ordered and thereafter he shall be sent to judicial
custody.
127. When we read order sheets, it is apparent that the Magistrate has recorded the statement made
by the accused and has obtained the signatures. The Magistrate has clearly enquired whether he was
ill−treated or tortured by the CBI while in custody, for recording a confessional statement to which
he replied in the negative. The accused was asked what he wanted to say to which he responded that
he made a voluntary confessional statement. Then he was remanded to judicial custody. In view of
the fact that the officer of the rank of S.P. has duly recorded that he has read over the statement and
the accused has admitted it to be correct, as in due compliance with the provisions of section 32, so
it was not necessary for the Magistrate to read over the same again to the accused, in view of clear
language employed in section 32(4) and (5) the duties enjoined upon the Magistrate have been duly
observed.Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

128. Learned counsel on behalf of the accused submitted that the Magistrate did not care to open the
sealed envelope containing confessions and did not read it out to the accused. In State of
Maharashtra v. Bharat Chaganlal Raghani & Ors., (2001) 9 SCC 1, this Court has observed that there
is no requirement of the opening of the sealed envelope by the Magistrate containing the confession
and to read it out to the accused. Following observations have been made by this Court:
“36. Sub−rule (5) of Rule 15 of the TADA Rules provides that the confession recorded
under Section 15 of the TADA Act shall be sent forthwith to the Chief Metropolitan
Magistrate or the Chief Judicial Magistrate having jurisdiction over the area in which
such confession has been recorded and such Magistrate shall forward the record of
confession so received to the Designated Court which may take cognizance of the
offence. Rule 15 does not oblige such Magistrate either to open the envelope
containing the confessional statement recorded by the police officer or to satisfy
himself regarding the voluntary nature of the confession. The Magistrate, at the most,
can record the statement of the accused if made regarding alleged harassment,
torture or the like. If the Magistrate, referred to in sub−rule (5) of Rule 15 has to
ascertain the voluntary nature of the confessional statement, the purpose of Section
15 authorising a police officer to record the confessional statement shall stand
frustrated. It was, therefore, not correct on the part of the Designated Judge to hold,
“it was obligatory on the part of the Magistrate to question the accused as to whether
they had made the said statements voluntarily or otherwise and that ought to have
been formed as a part of the record of the confessional statements which were sent to
her”.
The Designated Judge has also erred in holding that the Magistrate had not discharged the duties
which were cast on her properly. The observations:
“Had she recorded a memorandum below the confessional statements that she had
questioned the accused about the averments in the said statements and she
considered the said confessional statements to be voluntary and correct, then in that
event, the confessional statements would have inspired the confidence of the court to
believe that they are free from any of the influences. The Magistrate is not expected to
take the position of a superior postman in the sense, receive the confessional
statements and forward the same to the TADA Court by putting them in another
envelope. The moment she receives the confessional statements, it should occur to
her as to why they are sent to her? What is she required to do with them? Had the
Magistrate been meticulous, it would have occurred to her that she is required to
question the accused as to whether they have really confessed in the manner recorded
in the statement and in that event, in normal course, she would not have forgotten to
make a memorandum below the confessional statements. Her writing to this effect
below the confessional statements would have been of great assistance to the cause of
justice” are, therefore, uncalled for."Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

129. The application which was filed by the prosecution before Magistrate was not for police remand
but for sending him to judicial custody. Thus, when the accused had been sent to judicial custody, it
cannot be said that he was not aware that he was to be sent to judicial custody. Since there was no
complaint of any torture and S.P. had also recorded the fact that there was no complaint of torture
or any mark of injury or violence on his body, he was sent to judicial custody.
130. The decision in Adambhai Sulemanbhai Ajmeri & Ors. v. State of Gujarat, (2014) 7 SCC 716 in
which confessional statement was made after 11 months and the accused was given only 15 minutes’
time to reflect− whether they wanted to make confessional statement and thereafter it was recorded,
and it appears that the record of the case also did not reflect that it was read over. It does not appear
that in the said case it was read over by the Superintendent of Police. Be that as it may. The
requirement has been fulfilled in the instant case as the S.P. has read over and is so recorded, that
he has read over and it was admitted to be correct and thereafter the accused has signed it. The
original statements were recorded in the Hindi language which was known to the accused persons in
their own words.
131. Relying upon Nathu v. State of Uttar Pradesh, AIR 1956 SC 56, learned counsel on behalf of
accused persons submitted that prolong police custody is sufficient to cast doubt out on the veracity
of the confession. In the instant case, the confessions have been recorded from 4.6.2003 to
22.6.2003. In the instant case the accused were arrested on different dates in May and June and
some were taken into custody from one case to another and then taken on police remand, and in the
facts and circumstances of the present case there was no such prolonged custody so as to render the
confessional statement doubtful in any manner only due to the fact of police custody. The impact of
police custody would depend upon the facts of each case. What is the impact of police custody on the
confessional statement has to be considered also in view of the fact whether the accused were given
sufficient time to think over which was given in the instant case. They had legal assistance also as
they had communicated with advocates also after they were arrested and then the S.P. explained in
writing to them the consequences of making such a statement. S.P. ensured that they were not under
any fear or greed etc. and that they were not tortured. Thereafter confessional statement had been
made. Sufficient time for reflection had also been given. Thus, no benefit can be derived from the
aforesaid decision.
132. Learned counsel appearing on behalf of A−1 has pointed out that he remained in police custody
from 17.4.2003 to 23.5.2003. Thereafter he was sent for judicial remand and again taken on police
remand on 12.6.2003. After his confession in another POTA case, A−1 was remanded back to police
custody from 16.5.2003 to 23.5.2003. Thus, A−1 had lost the confidence to speak out during his 10
minutes' production before the Magistrate and was not sure that he may be sent to police remand
again. In our opinion the submission is baseless. It cannot be said to be prolonged police custody.
When several accused persons are involved in various cases and an accused is found involved in a
series of cases, obviously, his police remand has to be taken in a particular case. That does not mean
that he has been sent to police remand in some other cases would adversely affect the confession.
What is envisaged is that with respect to the same crime, he should not normally be subjected to
police remand once he makes a statement in the court with respect to his confession as we see under
section 32(4) and (5), he has to be sent to judicial custody. That has been precisely followed. In theCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

case, it cannot be said that he was subjected to prolonged police custody or he had lost the
confidence that he would not be sent to judicial custody.
133. Learned counsel on behalf of accused further submitted that in view of the decision of this
Court in Shivappa v. State of Karnataka, (1995) 2 SCC 76, searching inquiry should be made by the
Magistrate before recording confessional statements. In the instant case, under section 32 of POTA,
since there is a departure and confession is made to a senior police officer has been made
admissible, the aforesaid decision based on section 164 Cr.P.C. is not attracted, even otherwise when
we apply the aforesaid test laid down with respect to section 164 Cr.P.C. as in Shivappa (supra), in
our opinion the S.P. under section 32(1), (2) and (3) and the concerned Magistrate under
subsections 4 and 5 of section 32 have performed their duties effectively as per the law laid down by
this Court in the aforesaid decision in which this Court observed:
“6. From the plain language of Section 164 CrPC and the rules and guidelines framed
by the High Court regarding the recording of confessional statements of an accused
under Section 164 CrPC, it is manifest that the said provisions emphasise an inquiry
by the Magistrate to ascertain the voluntary nature of the confession. This inquiry
appears to be the most significant and an important part of the duty of the Magistrate
recording the confessional statement of an accused under Section 164 CrPC. The
failure of the Magistrate to put such questions from which he could ascertain the
voluntary nature of the confession detracts so materially from the evidentiary value
of the confession of an accused that it would not be safe to act upon the same. Full
and adequate compliance not merely in form but in essence with the provisions of
Section 164 CrPC and the rules framed by the High Court is imperative and its non−
compliance goes to the root of the Magistrate's jurisdiction to record the confession
and renders the confession unworthy of credence. Before proceeding to record the
confessional statement, a searching enquiry must be made from the accused as to the
custody from which he was produced and the treatment he had been receiving in
such custody in order to ensure that there is no scope for doubt of any sort of
extraneous influence proceeding from a source interested in the prosecution still
lurking in the mind of an accused. In case the Magistrate discovers on such enquiry
that there is ground for such supposition he should give the accused sufficient time
for reflection before he is asked to make his statement and should assure himself that
during the time of reflection, he is completely out of police influence. An accused
should particularly be asked the reason why he wants to make a statement which
would surely go against his self−interest in course of the trial, even if he contrives
subsequently to retract the confession. Besides administering the caution, warning
specifically provided for in the first part of sub− section (2) of Section 164 namely,
that the accused is not bound to make a statement and that if he makes one it may be
used against him as evidence in relation to his complicity in the offence at the trial,
that is to follow, he should also, in plain language, be assured of protection from any
sort of apprehended torture or pressure from such extraneous agents as the police or
the like in case he declines to make a statement and be given the assurance that even
if he declined to make the confession, he shall not be remanded to police custody.”Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

134. The decision in Aloke Nath Dutta & Ors. v. State of West Bengal (2007) 12 SCC 230, relied on
behalf of the accused is based upon section 164 Cr.P.C. which is quite different in which the
confession is recorded by the Magistrate. Section 32 is a departure from the same. S.P. is authorised
to remand and he has observed all the safeguards. Thus, the decision for the aforesaid reasons has
no application.
135. On the strength of the Parliament attack case (supra), it was submitted that on the twin test of
confession and voluntariness of truth. The confession must be corroborated in material particulars.
It is inextricably linked with the truth of confession. This Court observed:
“36. Then we have the case of Shankaria v. State of Rajasthan, (1978) 3 SCC 435,
decided by a three−Judge Bench. Sarkaria, J., noted the twin tests to be applied to
evaluate a confession: (1) whether the confession was perfectly voluntary, and (2) if
so, whether it is true and trustworthy. The learned Judge pointed out that if the first
test is not satisfied the question of applying the second test does not arise. Then the
Court indicated one broad method by which a confession can be evaluated. It was
said: (SCC p. 443, para 23) “The Court should carefully examine the confession and
compare it with the rest of the evidence, in the light of the surrounding circumstances
and probabilities of the case. If on such examination and comparison, the confession
appears to be a probable catalogue of events and naturally fits in with the rest of the
evidence and the surrounding circumstances, it may be taken to have satisfied the
second test.”
37. In Parmananda Pegu v. State of Assam, (2004) 7 SCC 779, this Court while
adverting to the expression “corroboration of material particulars” used in Pyare Lal
Bhargava v. State of Rajasthan, 1963 Supp. (1) SCR 689, clarified the position thus:
(SCC p. 790, para 20) “By the use of the expression ‘corroboration of material
particulars’, the Court has not laid down any proposition contrary to what has been
clarified in Subramania Goundan v. State of Madras, 1958 SCR 428, as regards the
extent of corroboration required. The above expression does not imply that there
should be meticulous examination of the entire material particulars. It is enough that
there is broad corroboration in conformity with the general trend of the confession,
as pointed out in Subramania Goundan case.” The analysis of the legal position in
paras 18 and 19 is also worth noting: (SCC p. 788) “18. Having thus reached a finding
as to the voluntary nature of a confession, the truth of the confession should then be
tested by the court. The fact that the confession has been made voluntarily, free from
threat and inducement, can be regarded as presumptive evidence of its truth. Still,
there may be circumstances to indicate that the confession cannot be true wholly or
partly in which case it loses much of its evidentiary value.
19. In order to be assured of the truth of confession, this Court, in a series of
decisions, has evolved a rule of prudence that the court should look to corroboration
from other evidence. However, there need not be corroboration in respect of each andCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

every material particular. Broadly, there should be corroboration so that the
confession taken as a whole fits into the facts proved by other evidence. In substance,
the court should have assurance from all angles that the retracted confession was, in
fact, voluntary and it must have been true.””
136. There is no dispute with the aforesaid proposition. However, it would depend upon the nature
of the case and the facts and circumstances and evidence in each case whether the confessional
statement is truthful and is corroborated. That has to be seen in each case. In Parliament attack case
(supra) certain observations have been made with respect to section 52(2) of POTA Act which
specifically provided that the person arrested shall be informed of his right to consult a legal
practitioner as soon as he is brought to the Police Station. Section 52(3) provides that information of
his arrest shall be given immediately to a family member or a relative. Section 52(4) says that the
person arrested shall be permitted to meet the legal practitioner representing him during the course
of interrogation of the accused person. In this context the observations have been made by this
Court in Parliament attack case:
“182. Parliament advisedly introduced a Miranda v. Arizona, 384 US 436, ordained
safeguard which was substantially reiterated in Nandini Satpathy v. P.L. Dani, (1978)
2 SCC 424, by expressly enacting in sub−sections (2) and (4) of Section 52 the
obligation to inform the arrestee of his right to consult a lawyer and to permit him to
meet the lawyer. The avowed object of such prescription was to introduce an element
of a fair and humane approach to the prisoner in an otherwise stringent law with
drastic consequences to the accused. These provisions are not to be treated as empty
formalities. It cannot be said that the violation of these obligations under sub−
sections (2) and (4) have no relation and impact on the confession. It is too much to
expect that a person in custody in connection with the POTA offences is supposed to
know the fasciculus of the provisions of POTA regarding the confessions and the
procedural safeguards available to him. The presumption should be otherwise. The
lawyer's presence and advice, apart from providing psychological support to the
arrestee, would help him understand the implications of making a confessional
statement before the police officer and also enable him to become aware of other
rights such as the right to remain in judicial custody after being produced before the
Magistrate. The very fact that he will not be under the fetters of police custody after
he is produced before the CJM pursuant to Section 32(4) would make him feel free to
represent to the CJM about the police conduct or the treatment meted out to him.
The haunting fear of again landing himself into police custody soon after appearance
before the CJM would be an inhibiting factor against speaking anything adverse to
the police. That is the reason why the judicial custody provision has been introduced
in sub−section (5) of Section 32. The same objective seems to be at the back of sub−
section (3) of Section 164 CrPC, though the situation contemplated therein is
somewhat different.
183. The breach of the obligation of another provision, namely, sub−section (3) of
Section 52 which is modelled on D.K. Basu (supra) guidelines has compounded theCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

difficulty in acting on the confession. Section 52(3) enjoins that the information of
arrest shall be immediately communicated by the police officer to a family member or
in his absence, to a relative of such person by telegram, telephone or by any other
means and this fact shall be recorded by the police officer under the signature of the
person arrested. PW 80 the IO under POTA merely stated that “near relatives of the
accused were informed about their arrest as I learnt from the record”. He was not
aware whether any record was prepared by the police officer arresting the accused as
regards the information given to the relatives. It is the prosecution case that Afzal’s
relative by the name of Mohd.
Ghulam Bohra of Baramula was informed through phone. No witness had spoken to this effect. A
perusal of the arrest memo indicates that the name of Ghulam Bohra and his phone number are
noted as against the column “relatives to be informed”. Afzal’s arrest memo seems to have been
attested by Gilani’s brother who according to the prosecution, was present at the police cell. But,
that does not amount to compliance with sub−section (3) because he is neither family member nor
relation, nor even known to be a close friend. We are pointing out this lapse for the reason that if the
relations had been informed, there was every possibility of those persons arranging a meeting with
the lawyer or otherwise seeking legal advice.”
137. It is not the case of the accused that they were not given the right to consult legal practitioner
when they were interrogated after arrest by the police under section 52 of the Act. Section 52 of the
POTA Act is extracted hereunder:
“52. Arrest.—(1) Where a police officer arrests a person, he shall prepare a custody
memo of the person arrested. (2) The person arrested shall be informed of his right to
consult a legal practitioner as soon as he is brought to the police station.
(3) Whenever any person is arrested, information of his arrest shall be immediately
communicated by the police officer to a family member or in his absence to a relative
of such person by telegram, telephone or by any other means and this fact shall be
recorded by the police officer under the signature of the person arrested.
(4) The person arrested shall be permitted to meet the legal practitioner representing
him during the course of interrogation of the accused person:
Provided that nothing in this subsection shall entitle the legal practitioner to remain
present throughout the period of interrogation."
The observations made by this Court in Parliament attack case carry the case no
further as the accused were having the legal assistance after their arrest and they
were never deprived of the same, and it is not their case they had asked for lawyer’s
assistance during the period of reflection before confessing and they were denied the
same.Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

138. In the Parliament Attack case, the observation has been made by this Court in the light of the
submission that the confession cannot be truly judged from the standpoint of probabilities and
natural course of human conduct, though this Court has commented that they were plausible and
persuasive.
139. The learned counsel appearing on behalf of accused has submitted that confession of a co−
accused made under Section 32 of POTA is not admissible against anyone other than the maker.
Reliance has been placed on the Parliament Attack case, wherein this Court has observed thus:
“49. Now, let us examine the question whether Section 32(1) of POTA takes within its
sweep the confession of a co−accused.
Section 32(1) of POTA which makes the confession made to a high−ranking police
officer admissible in the trial does not say anything explicitly about the use of
confession made by a co− accused. The words in the concluding portion of Section
32(1) are:
“shall be admissible in the trial of such person for an offence under this Act or the
rules made thereunder.” It is, however, the contention of the learned Senior Counsel
Shri Gopal Subramanium that Section 32(1) can be so construed as to include the
admissibility of confessions of the co−accused as well. The omission of the words in
POTA "or co− accused, abettor or conspirator" following the expression "in the trial
of such person" which are the words contained in Section 15(1) of TADA does not
make a material difference, according to him. It is his submission that the words "co−
accused", etc. were included by the 1993 Amendment of TADA by way of abundant
caution and not because the unamended section of TADA did not cover the
confession of the co− accused. According to the learned Senior Counsel, the phrase
"shall be admissible in the trial of such person" does not restrict the admissibility
only against the maker of the confession. It extends to all those who are being tried
jointly along with the maker of the confession provided they are also affected by the
confession. The learned Senior Counsel highlights the crucial words "in the trial of
such person" and argues that the confession would not merely be admissible against
the maker but would be admissible in the trial of the maker which may be a trial
jointly with the other accused persons. Our attention has been drawn to the
provisions of CrPC and POTA providing for a joint trial in which the accused could be
tried not only for the offences under POTA but also for the offences under IPC. We
find no difficulty in accepting the proposition that there could be a joint trial and the
expression “the trial of such person” may encompass a trial in which the accused who
made the confession is tried jointly with the other accused. From that, does it follow
that the confession made by one accused is equally admissible against others, in the
absence of specific words? The answer, in our view, should be in the negative. On a
plain reading of Section 32(1), the confession made by an accused before a police
officer shall be admissible against the maker of the confession in the course of his
trial. It may be a joint trial along with some other accused; but, we cannot stretch theCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

language of the section so as to bring the confession of the co−accused within the fold
of admissibility. Such stretching of the language of law is not at all warranted
especially in the case of a law which visits a person with serious penal consequences
[vide the observations of Ahmadi, J. (as he then was) in Niranjan Singh Karam Singh
Punjabi v. Jitendra Bhimraj Bijjaya, (1990) 4 SCC 76, SCC at p. 86, which were cited
with approval in Kartar Singh case. We would expect a more explicit and transparent
wording to be employed in the section to rope in the confession of the co−accused
within the net of admissibility on a par with the confession of the maker. An
evidentiary rule of such importance and grave consequence to the accused could not
have been conveyed in a deficient language. It seems to us that a conscious departure
was made by the framers of POTA on a consideration of the pros and cons, by
dropping the words "co−accused", etc. These specific words consciously added to
Section 15(1) by the 1993 Amendment of TADA so as to cover the confessions of the
co− accused would not have escaped the notice of Parliament when POTA was
enacted. Apparently, Parliament in its wisdom would have thought that the law
relating to confession of the co−accused under the ordinary law of evidence, should
be allowed to have its sway, taking a cue from the observations in Kartar Singh case
at para 255. The confession recorded by the police officer was, therefore, allowed to
be used against the maker of the confession without going further and transposing
the legal position that was obtained under TADA. We cannot countenance the
contention that the words “co−accused”, etc. were added in Section 15(1) of TADA, ex
majore cautela.
50. We are, therefore, of the view that having regard to all these weighty
considerations, the confession of a co−accused ought not to be brought within the
sweep of Section 32(1). As a corollary, it follows that the confessions of the first and
second accused in this case recorded by the police officer under Section 32(1), are of
no avail against the co−accused or against each other. We also agree with the High
Court that such confessions cannot be taken into consideration by the Court under
Section 30 of the Evidence Act. The reason is that the confession made to a police
officer or the confession made while a person is in police custody, cannot be proved
against such person, not to speak of the co−accused, in view of the mandate of
Sections 25 and 26 of the Evidence Act. If there is a confession which qualifies for
proof in accordance with the provisions of the Evidence Act, then, of course, the said
confession could be considered against the co−accused facing trial under POTA. But,
that is not the case here.” This Court has merely laid down that confession of accused
is not admissible as against co−accused person and when TADA makes the
confession against co−accused admissible, it could not be said that the words co−
accused were added in Section 15(1) of TADA, ex majore cautela. Through the
expression, they were admissible against the accused has not been used in Section 32
of POTA. It is relevant and admissible against the maker of it.
140. On the other hand, learned Solicitor General has relied upon the decision in Kehar Singh v.
State (Delhi Administration), (1988) 3 SCC 609, wherein this Court observed as under:Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

"278. From an analysis of the section, it will be seen that Section 10 will come into
play only when the court is satisfied that there is reasonable ground to believe that
two or more persons have conspired together to commit an offence. There should be,
in other words, a prima facie evidence that the person was a party to the conspiracy
before his acts can be used against his co−conspirator. Once such prima facie
evidence exists, anything said, done or written by one of the conspirators in reference
to the common intention, after the said intention was first entertained, is relevant
against the others. It is relevant not only for the purpose of proving the existence of
conspiracy but also for proving that the other person was a party to it. It is true that
the observations of Subba Rao, J., in Sardar Sardul Singh Caveeshar v. State of
Maharashtra, (1964) 2 SCR 378 lend support to the contention that the admissibility
of evidence as between co−conspirators would be (sic more) liberal than in English
law. The learned Judge said: (SCR p. 390) “The evidentiary value of the said acts is
limited by two circumstances, namely, that the acts shall be in reference to their
common intention and in respect of a period after such intention was entertained by
any one of them. The expression ‘in reference to their common intention’ is very
comprehensive and it appears to have been designedly used to give it a wider scope
than the words ‘in furtherance of’ in the English law; with the result, anything said,
done or written by a co− conspirator, after the conspiracy was formed, will be
evidence against the other before he entered the field of conspiracy or after he left
it.””
141. In our opinion, there was no violation of safeguards provided under the provisions of section
32(5) vis a vis any accused person. The confessions cannot be said to be inadmissible. The
provisions of section 32 have been duly complied with.
142. It was also submitted on behalf of accused persons that recording of confessions was flawed.
The accused were placed in seclusion and they were not informed of the time at which they would be
summoned. PW−21 has admitted that none of them called him in− between. In our opinion, the
time of reflection was granted which was adequate in this case and after giving an opportunity to
accused whether they wanted to make a confession after being told that it may be used against them,
it was the case of observance of the aforesaid principle and it is not the case that the accused had
asked for legal assistance during that period and were deprived of it. The legal aspect of the effect of
confession had been duly informed to the accused persons beforehand in writing so many words,
and adequate time was given for reflection so as to consider the consequence of making a
confession. Nothing more could have been advised by a lawyer. Thus, by not volunteering to provide
aid of lawyer in view of the fact that the case, where it was not asked for during the time of
reflection, even on the assumption that it was necessary, no prejudice can be said to have been
caused to any of the accused persons as they were given enough time for reflection, whether they
wanted to make confession as it could be used against them. Thus, there was no breach of any of the
constitutional rights flowing from Articles 21, 22(3) and 20(3) of the Constitution of India. As
already mentioned that they were assisted by lawyers also in the main case when remand etc. was
sought. The submission that PW−21 has stated that police custody has no relevance upon the
voluntary nature of confession, which is as per counsel is against the settled jurisprudence, is alsoCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

untenable for the reason that section 32 makes a voluntary confession to a police officer admissible.
143. It was also submitted on behalf of accused persons that the use of words like “suraksha”,
“prabandh”, “poorva” ‘netritva’ ‘anusar’ ‘hatya’ “sampark", etc., which are highly Sanskritised words
would never occur spontaneously to a Muslim of A−1's background from the Deccan/Hyderabad
region. "Spontaneously to a Muslim like the background of A−1 who hails from Hyderabad", and to
other accused persons, the submission is not tenable. It would depend on several factors. Firstly, the
aforesaid words cannot be said to be Sanskritised. Secondly, it would depend upon the educational
background of a Muslim in which he has been brought up. Merely by the fact that A−1 happens to be
a Muslim, it cannot be said that he would not know these words, particularly when it would depend
upon his own education and the family background in which he has been brought up. There are
highly cultured and literary families found in Muslims also who know several languages not only
Urdu and are known for their Tehzeeb. Thus the criticism made of the confessional statement due to
use of the aforesaid words that they could not have been employed by A−1 or by other accused
persons is not only unwarranted but also unacceptable and the same is liable to be and is hereby
rejected.
144. In the confessional statement accused have referred to mobile numbers cannot be said to be
rendering it unreliable. It is not uncommon to remember mobile numbers and to narrate them.
145. It was also submitted to discredit recording of the confessions by PW−21 that it was not
humanly possible to record confessions continuously for 37 hours. Considering the chart which has
been indicated is not for 39 hours as submitted. It was submitted on behalf of the prosecution that
the time taken by PW−21 is not precise and the same has been calculated on the basis of the
reflection time given to the accused. PW−21 in this regard has stated thus:
“227. Exh. 228 and Ex. 229 had concluded just 4 hours before.
A. It is true on seeing a record that accused Rehan statement was completed at 11.25
PM on 6.6.2003 whereas what I can see from the record (E. 232) that more than 16
hours have passed and therefore it cannot be said that recording of the confessional
statement of accused Parvez had commenced exactly at 4 a.m.” The submission is
based upon incorrect calculation and stands explained by the deposition of PW−21.
The period of total recording is 20 to 22 hours and not 39 hours as attributed.
146. The argument was raised that when accused asked for a glass of water, this renders the
confessional statement unworthy of credence. A police officer is not supposed to remember all these
aspects and tell about them for several years and statements cannot be discredited on the ground
whether the accused had asked for water or not.
147. It was also urged that Mohmed Parvez was produced at the Civil Hospital at the time when the
statement was recorded, renders the confessional statement unreliable. No such question during his
cross− examination has been put to PW−21 as to the presence of Parvez Sheikh, A−9, in hospital at
10 a.m. A−9 was required produced before the Magistrate on 9.6.2003 i.e. within 48 hours asCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

required under section 32 of POTA. Neither he stated so in the written retraction of confessional
statement that he was at the time in the hospital when the confessional statement is said to have
been recorded. It was necessary to discredit the recording of confession by PW−21 to put it in the
cross−examination and to seek his explanation. Cross−examination is not a matter of procedure but
a matter of substance as held in Maroti Bansi Teli v. Badhabai w/o Tukaram Kunbi, AIR 1945
Nagpur 60, Karnidan Sarda v. Sailaja Kanta Mitra, AIR 1940 Patna 683, A.E.G. Carapiet v. A.Y.
Derderian, AIR 61 Cal. 359, and Jai Shankar Prasad vs. State of Bihar, AIR 1963 SC 1906.
148. With respect to retraction of the confessions by all the accused persons on the same day after a
month, it is apparent from the reasons recorded by the court that they have given different reasons
for retraction. The court has individually heard each and every accused. A−1 has stated that his
signatures had been obtained on the blank papers. A−2 has stated that was a fact that under fear of
encounter, he has given the statement. A−2 says that confession has been forcibly obtained. A−4
says that he was forced to make the confession. Similar is the statement of A−5. A−6 says that he has
not given any confessional statement, his signatures have been obtained. A−7 says that by hook or
crook, he was asked to make this confession and was forced to make it. A−8 says that he was forced
to make a confession. When he refused to sign, blinds were applied for 2 days. A− 9 says that
confession is forcible, he was compelled to sign. He signed the written confession. A−12 says that his
confession was forcible and was obtained under threat. A−13 also made a similar statement. Thus, it
is apparent that the accused persons have not retracted their confession at first opportunity when
they were produced. Reasons behind retraction also do not inspire confidence. The details with
which the confessional statements have been recorded after the observance of due safeguards and
other corroborative evidence on record are indicative of the fact that reasons for retraction, as
stated, are not correct. There is no allegation that they were tortured by the police. In the absence of
the same, it does not inspire confidence that they have signed on blank papers, etc. There was a
general statement that they were under fear made by some of the accused persons. The fact remains
that the statements have been recorded by the S.P., a high ranking officer as envisaged under section
32 which cannot be lightly discredited in the facts and circumstances of the case.
149. In Mohmed Amin & Anr. v. Central Bureau of Investigation, 2008 (15) SCC 49 this Court
observed:
“69. If the confessions of the appellants are scrutinised in the light of the above−
enumerated factors, it becomes clear that the allegations made by them regarding
coercion, threat, torture, etc. after more than one year of recording of confessions are
an afterthought and products of the ingenuity of their advocates. The statements
made by them under Section 313 CrPC were also the result of afterthought because
no tangible reason has been put forward by the defence as to why Appellants A−4 to
A−8 did not retract from their confessions when they were produced before the
Magistrate at Ahmedabad and thereafter despite the fact that they had access to legal
assistance in more than one way. Therefore, we hold that the trial court did not
commit any error by relying upon the confessions of Appellants A−4 to A−8 and A−10
and we do not find any valid ground to discard the confessions of Appellants A−4 to
A−8 and A−10."Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

Since there was no mal−treatment, no manifest complaint of torture, confession
appears to be voluntary and all the accused persons were sent to judicial custody.
Subsequent retraction of confession is of no consequence, the same is an
afterthought.
150. It was urged by learned Additional Solicitor General appearing on behalf of CBI that A−4 and
A−5 stand convicted in tiffin bomb case dated 29.5.2002 in which tiffin bombs were planted in
buses going towards Hindu localities and the trial court has also convicted A−1 along with A−3 in
conspiracy with other accused persons under section 307 read with section 120B IPC and section
3(3) of POTA Act. Same forms part of the chain of criminal conspiracy to create terror in the
community of Hindus which has led to the murder of Haren Pandya. The associated case also
provides a link and part of the conspiracy to finish the Hindu leaders and to take revenge of post−
Godhra incidents. PW−39 has also identified accused A−1 and A−3 in the TIP proceeding before the
Executive Magistrate, PW−14 on 6.6.2003. We have to examine the submissions in light of the
evidence that has been adduced with respect to the murder of Haren Pandya. CONFESSION AND
CORROBORATION
151. Since the decision was based on TADA, Section 120A of Indian Penal Code and Section 10 of
Evidence Act, it is the decision in Parliament Attack case which has to provide a guide as it was on
the provision of Section 32 of POTA. It is contended by C.B.I. that confession of all the accused
recorded under Section 32 of POTA are voluntary and thus can be relied upon. The confessions have
been proved by Vinayak Prabhakar Apte, SP CBI (PW−21). IN RE: CONFESSION OF A−1
(MOHMED ASGAR ALI)
152. It was confessed by A−1 (Mohmed Asgar Ali) that he was asked by co−accused Abdul Rauf to get
prepared for training at Pakistan with other boys. He was given Rs.20,000/− by Abdul Rauf and
they went to Calcutta from Hyderabad. One Parvez from Calcutta promised to take them to
Bangladesh. For about 1 ½ month, they were in Bangladesh and he was in constant touch with A−2
(Mohmed Abdul Raouf). He was given the name of Afdan during his stay at Dhaka, Bangladesh. In
the camp, they were trained in firearms like a pistol, gun, LMG, grenades, etc. for about a month. He
also confessed that he spoke to Suleman before proceeding to Karachi for training, who was
aggrieved by the atrocities committed on Muslim. He was asked to go to Udaipur by Rasul party
where he would be picked up for Ahmedabad to avenge atrocity and as being native of Hyderabad,
nobody would be able to recognize him at Ahmedabad and the terror could be created amongst the
Hindus.
153. It was further confessed that in December 2002, he reached Udaipur and stayed at
Musafirkhana in the name of Afdan Yusuf from 31.12.2002 to 5.1.2003. It was confessed by A−1
(Mohmed Asgar Ali) that he had received an email from Rasul Khan Party in which he was given the
address and phone number of Usman who lived in Udaipur. After his return from Udaipur to
Hyderabad, he took Rs.2,000 – Rs.3,000/− from A−2 (Mohmed Abdul Rauf). He also received one
message on his email that one Sohail Khan would come to Udaipur to take him to Ahmedabad. On
22.1.2003, Sohail Khan, Salim Pasha and Haji Faruk went to Udaipur in Tata Indica Car and they
left for Ahmedabad in the morning. He first went to the residence of Haji Faruk and thereafter toCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

Sohail Khan’s place from where he was taken to Lokhandwali Chawl, Bapunagar. He contacted A−3
(Mohmed Shafiuddin) and gave the address of Musafirkhana and also called him to Ahmedabad. He
was provided with the mobile number of Sohail Khan i.e., 9426034937 and also intimated Sohail
Khan about this friend. He went along with Sohail Khan and Parvez and brought Shafi to Hotel
Garden near Ahmedabad Railway Station. Thereafter, A−1 and Shafi were taken to M.B. Flats and
from there to Royal Apartment to Sundaramnagar. He was given a mobile phone with SIM card
no.9825498421 and also one Suzuki Samurai motorcycle. He was in touch with Suleman (Rasul
Party) through Modern Cyber Café. In March 2003, A−10 and A−11 went to meet him. Sohail Khan
name BJP Leader Jagdish Tiwari to be their first target as he led the mob during the riots. Parvez
showed him the shop of Jagdish Tiwari. 153(a). On 9.3.2003, A−1 (Mohmed Asgar Ali) and A−3
(Mohmed Shafiuddin) went to the place of Jagdish Tiwari to target him, but Jagdish Tiwari did not
pass through the said route. On 10.3.2003, they followed Jagdish Tiwari, but they could not kill
Jagdish Tiwari. They accordingly informed Sohail Khan and it was decided to kill Jagdish Tiwari at
his medical store. On 11.3.2003, Shafiuddin asked for medicine and while Jagdish Tiwari bent for
taking out the medicine, A−1 (Mohmed Asgar Ali) fired on him and the bullet went straight into his
stomach. He also fired a second shot, but the bullet could not come out. Jagdish Tiwari hides behind
the refrigerator. He immediately called up Sohail Khan on his mobile no.9426739927, but he could
not be contacted, so he informed Parvez on his mobile no.9426227349 about the incident and asked
him to inform Sohail Khan also. Thereafter, they changed their shirts at Sohail Khan's home and
were unhappy with the weapon and wanted to return him. A−11 and A−10 left them at Royal
Apartment.
153(b). On 17/18.3.2003, Sohail Khan named Haren Pandya as their next target. Mufti Sufiyan gave
the order for his killing. Sohail Khan told him that Haren Pandya used to go for a morning walk at
Law Garden and he could be killed there.
153(c). On 23.3.2003, Sohail Khan took him to Law Garden and Yunus and Parvez met them. On
that day, Haren Pandya did not come to Law Garden. On 24.3.2003, he went to Jumma Masjid and
where he met Anas, Rehan, and Goru. On 25.3.2003, he was given black colored loaded revolver
with six bullets by Anas in the toilet of Jaliwali Masjid. Goru took him to Law Garden. He walked
with Haren Pandya, but upon seeing a man in uniform, he decided not to kill Haren Pandya inside
the garden and dropped the plan of killing him and came back to Shahpur with Goru. The weapon
was returned to Anas Machiswala and Shahnavaz asked him to accomplish the task the next day.
153(d). Next day inside the Jaliwali Masjid, he was given loaded revolver by Anas Machinswala. It
was confessed that Haren Pandya came in Maruti Fronti car at the place and parked the car at his
regular place. He also confessed that he fired five bullets on Haren Pandya from the window of the
driver seat and fled away on Yunus’ motorbike. They went to Shahpur Mill Compound and he called
up Sohail Khan and informed him that work is accomplished. He was piloted by Rehan and Sohail
Khan and Anas Machiswala were waiting in the auto rickshaw. Five empty cartridges were handed
over to Anas Machiswala and kept the pistol of Yunus with him to guard himself. He then went to
the Royal Apartment and stayed there for three days. Due to safety purpose, Sohail Khan asked him
to vacate Royal Apartment. His task was appreciated by Anas Machiswala, Sohail Khan, and Mufti
Sufiyan. He was asked to stay at Sikandar's place at Kanodar village, but he refused to keep him andCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

he had stayed at Kanodar Masjid. Later, he was moved to Flat No.4−B, behind Shahpur Police
Station.
153(e). Next day Sohail Khan called A−1 (Mohmed Asgar Ali) near Juhapura, Afzal Masjid. He
received a call from Mohd. Ayub who was called at the hotel. His stay arrangement was made at
Silver Flat No.2, where Dr. Harun used to stay and A−1 (Mohmed Asgar Ali) also stayed there for
about a week. He continued to chat with his friends at Cyber Space Café at Afzal Mosque. It is stated
that he was extremely annoyed with the maltreatment meted out to him after killing Haren Pandya,
on writing to Rauf, he urged him that he should intimate Suleman at Pakistan that fact but the next
day he did not receive any message and therefore, the next day he chose to go to Hyderabad. On
7.4.2003 when Ayub brought food for him, he requested him to drop him at Railway Station, got the
ticket for himself for Mumbai. He himself was very perplexed and perspiring and told Ayub the true
story and Ayub was extremely scared. At Hyderabad, he went to Iftikhar's place and met Rauf there
and requested him to take him to Pakistan after talking to Suleman. They were asked to wait, but
since he was scared, he was planning to go to Bangladesh on his own. Rauf also told him that Haji
Faruk and Parvez had reached Hyderabad hiding from Police. On his way to Calcutta and
Bangladesh from Hyderabad, the police caught him. The confession was signed by him.
154. It was urged that confession of A−1 (Mohmed Asgar Ali) lacks corroboration in material
particulars. A−1 (Mohmed Asgar Ali) in his confession stated that he was standing at the spot from
before. Similar is the statement of PW−55. A−1's confession does not mention the presence of an
eye−witness. PW−55 claims to have shouted out at him. Confession of accused A−1 (Mohmed Asgar
Ali) does not refer to rolling up of the window but speaks of Haren Pandya drinking water at the
time of shooting. "Jaise use Gadi khadi karke pani peene ke liye botal ka dhakkan khola main gadi ki
taraf ghooma aur driver ki taraf se thoda khule sheeshe se Haren Pandya par panch fire kiye." In our
opinion, the non−recovery of a water bottle from the car is not at all material as it had nothing to do
with the offence in question. Every material found in the car was not required to be seized. The
witness PW−55 has also said that Haren Pandya drank water from the bottle. There is no
contradiction as sought to be made out on behalf of the learned counsel appearing for A−1.
155. Confession of A−1 (Mohmed Asgar Ali) has been supported by various other evidence on the
record like phone calls, recovery of the weapon, vehicle, hiring of rooms, etc. It was submitted that
conduct of A−1 (Mohmed Asgar Ali) as stated in the confession does not inspire confidence. There is
no conceivable reason for preserving cartridge case and weapons and spending time which must be
precious to a murderer for escaping from the spot. It was not reasonable for the accused to preserve
empty cartridges. There was the possibility of their recovery from the place of occurrence. In case he
had thrown them at the place of occurrence, as such, in our opinion, it was not unusual for accused
A−1 to carry them and he wanted to run away from the spot also as such he did not waste time in
throwing them on spot and leave the evidence.
156. On behalf of accused A−1 (Mohmed Asgar Ali), it was submitted that CBI case is that A−9 had
called A−7 at 7.18 a.m. on 26.3.2003 to say that A−1 has not arrived at Law Garden. At 7.33 a.m., A−
1 had called A−14 from some kilometers away from Law Garden after the murder. At 8.17 a.m., A−1
again called A−14 from some 15−17 km. away. It was further submitted that there is no evidence toCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

show that these were phones used by A−7 and A−9 or A−1 or to show the nature of the conversation
save the confessions. Even the cell location of one of those numbers is missing. It was also submitted
that taking this theory at face value it means that A−1 did not reach the spot before 7.19 a.m. Also, he
must necessarily have left the spot before 7.29 a.m. because it would take 4−5 minutes to reach the
spot from which the call at 7.33 a.m. was made. The time band for the murder is thus between 7.19
a.m. and 7.28 a.m. at the outer limit going by CBI case, it is even less if the confession is taken into
account for that says that A−1 wanted a few minutes before Mr. Pandya arrived.
157. After the incident, A−1 (Mohmed Asghar Ali) called A−14 Sohail's Mobile No.9426039937 from
His Mobile No.9825494421 at 7.33.27 a.m. and at 8.17 a.m., the location of these mobile phone
confirms the presence of A−1 Asghar Ali at Law Garden area. These facts have been proved by Exh.
467 (CDR of 9825494421) and also by Ex. 775. PW 33 Hemant Kumar Ratilal Patel, Asstt. Divisional
Engineer, Vastrapur Telephone Exchange, proved the location of mobile number used by the
accused persons on the basis of tower location. Trial Court has dealt with this aspect elaborately.
158. On 25.3.2003 there was an abandoned/aborted attempt to murder Haren Pandya. CDR and call
records indicate the presence of A−1 (Mohmed Asgar Ali) in the area of Law Garden on the said
date. On 26.3.2003 after the incident, the call was made to mobile of Sohail and it was said that the
work was done. CBI call records support the same.
159. In our opinion, it makes hardly any difference of one or two minutes when it is possible to
travel the distance from where the calls were made by A−1 to A−14 in a few minutes and from
distance of 15 to 17 km. calls in 45 minutes. Cell phone location also supports the ocular version and
lends credence to the fact that murder had taken at the place near Law Garden. In addition, for
tracking A−1 (Mohmed Asgar Ali), a landline at Nalgonda was used. It was proved that A−1 used
phone No.9825494251. In the confession also, the number has been stated. Even on the next date of
the incident, the phone was used by A−1, stands established by the prosecution.
160. There is corroborative evidence of confession with respect to A−1 (Mohmed Asgar Ali), Shooter.
He fired at Jagdish Tiwari and murdered Haren Pandya as stated in his confession in December
2002 after return from Pakistan. He reached Udaipur and stayed at Muslim Musafirkhana, which is
corroborated by the deposition of Mohammed Jamil Nasir Mohammed, Manager, Muslim
Musafirkhana (PW−30) (Exhibit 297) and has also produced guest register (Exhibit 298). Entry no.
5846 (Exhibit 298) was made in respect of stay of A−1 (Mohmed Asgar Ali) from 31.12.2002 to
5.1.2003, which was signed by A−1 (Mohmed Asgar Ali).
161. He also received a message from A−18 through email to reach Udaipur and contact Usman
Khan Nawab Khan (PW−29). The same had been corroborated by Usman Khan Nawab Khan (PW−
29) in his deposition. A−1 (Mohmed Asgar Ali) reached Udaipur on 20.1.2003 and stayed at Muslim
Musafirkhana for a day. Entry no.8682 (Exhibit
299) was made in the visitor register regarding his stay. Thereafter, he stayed with Usman Khan
Nawab Khan (PW−29) at his house for 2−3 days and went to Chetak Circle and used a computer in
the computer centre. It had been corroborated by Usman Khan Nawab Khan (PW−Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

29) in his deposition. He also procured a stolen bike of Hero Honda, this fact had been corroborated
by PW−57 (hostile witness) in this deposition. He met Salim Pasha and on 23.1.2003, A−3 (Mohmed
Shafiuddin) reached Udaipur and stayed at Muslim Musafirkhana for a day. This fact had been
corroborated by Dr. Mohmed Aizaz Ali, Principal Scientific Officer (Document) CFSL, New Delhi
vide report (Exhibit 524) and he had also given a positive opinion with respect to Entry No.8699
(Exhibit 300) made in the visitor register for a stay of A−3 (Mohmed Shafiuddin). After reaching
Ahmedabad, A−1 (Mohmed Asgar Ali) was accommodated in a room at Lokhandwalichali,
Bapunagar owned by Mushtaq Ahmad Munir (PW−63), which had been proved by Mushtaq Ahmad
Munir (PW−63) in his deposition (Exhibit
652). He had also confessed that after firing on Jagdish Tiwari (PW−
39), he called A−14 (Sohail Khan Pathan) on mobile no.9426039937. A−1 (Mohmed Asgar Ali)
further confessed that on 25.3.2003, there was an abandoned attempt to kill Haren Pandya. CDR
call record had indicated his presence in the area of Law Garden. He confessed that on 26.3.2003,
after the incident, he made a call to A−14 (Sohail Khan Pathan) and said: "work done". He further
confessed that he wrapped the pistol in a polythene bag and kept it in kerosene oil tanker of the
stove in Royal Apartment. The said weapon was recovered at the instance of A−1 (Mohmed Asgar
Ali) vide seizure memo Exhibit 196.
162. In view of overall evidence against him, we are of the view that his acquittal by High Court for
murder of Haren Pandya and POTA offence deserves to be set aside and conviction and sentence as
ordered by Trial Court is restored.
In Re: A−4 (Kalim Ahmad Karimi)
163. It was submitted by Shri Raju Ramachandran, learned senior counsel on behalf of A−4 (Kalim
Ahmad Karimi) that it is a case of conspiracy which is based entirely on confessions under POTA
which were obtained after an unduly long period of police custody. It is contended that colour of
conspiracy is sought to be given solely by the use of confessions. Reliance has been placed on Kehar
Singh (supra), which has already been considered. Further, reliance was placed on the decision of
K.R. Purushothaman v. State of Kerala, (2005) 12 SCC 631, wherein this Court observed as under:
“13. To constitute a conspiracy, meeting of minds of two or more persons for doing an
illegal act or an act by illegal means is the first and primary condition and it is not
necessary that all the conspirators must know each and every detail of the conspiracy.
Neither is it necessary that every one of the conspirators takes an active part in the
commission of each and every conspiratorial acts. The agreement amongst the
conspirators can be inferred by necessary implication. In most of the cases, the
conspiracies are proved by the circumstantial evidence, as the conspiracy is seldom
an open affair. The existence of conspiracy and its objects are usually deduced from
the circumstances of the case and the conduct of the accused involved in the
conspiracy. While appreciating the evidence of the conspiracy, it is incumbent on the
court to keep in mind the well−known rule governing circumstantial evidence viz.Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

each and every incriminating circumstance must be clearly established by reliable
evidence and the circumstances proved must form a chain of events from which the
only irresistible conclusion about the guilt of the accused can be safely drawn, and no
other hypothesis against the guilt is possible. Criminal conspiracy is an independent
offence in the Penal Code. The unlawful agreement is sine qua non for constituting an
offence under the Penal Code and not an accomplishment. Conspiracy consists of the
scheme or adjustment between two or more persons which may be express or implied
or partly express and partly implied. Mere knowledge, even discussion, of the plan
would not per se constitute conspiracy. The offence of conspiracy shall continue till
the termination of agreement.”
164. Learned Senior Counsel has further relied upon the decision of Central Bureau of Investigation,
Hyderabad v. K. Narayana Rao, (2012) 9 SCC 512, in which this Court opined thus:
“24. The ingredients of the offence of criminal conspiracy are that there should be an
agreement between the persons who are alleged to conspire and the said agreement
should be for doing of an illegal act or for doing, by illegal means, an act which by
itself may not be illegal. In other words, the essence of criminal conspiracy is an
agreement to do an illegal act and such an agreement can be proved either by direct
evidence or by circumstantial evidence or by both and in a matter of common
experience that direct evidence to prove conspiracy is rarely available. Accordingly,
the circumstances proved before and after the occurrence have to be considered to
decide about the complicity of the accused. Even if some acts are proved to have been
committed, it must be clear that they were so committed in pursuance of an
agreement made between the accused persons who were parties to the alleged
conspiracy. Inferences from such proved circumstances regarding the guilt may be
drawn only when such circumstances are incapable of any other reasonable
explanation. In other words, an offence of conspiracy cannot be deemed to have been
established on mere suspicion and surmises or inference which are not supported by
cogent and acceptable evidence.”
165. It is contended that CBI seeks to reverse the acquittal, where High Court has
rejected the confessions on the basis of law laid down by this Court. It is further
submitted that reversal of an acquittal should not be done when the view taken by the
High Court is a possible view and as such, no interference should be made as per the
parameter laid down in State of Rajasthan v. Islam & Ors., (2011) 6 SCC 343, in
which this Court observed:
“16. The principle to be followed by the appellate court considering an appeal against
an order of acquittal is to interfere only when there are compelling and substantial
reasons to do so. Thus, in such cases, this Court would usually not interfere unless:
(i) The finding is vitiated by some glaring infirmity in the appraisal of evidence. (State
of U.P. v. Sahai, (1982) 1 SCC 352 at SCC paras 20−22: AIR paras 19−21.)Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

(ii) The finding is perverse. (State of M.P. v. Bacchudas, (2007) 9 SCC 135 at SCC
para 10 and State of Punjab v.
Parveen Kumar, (2005) 9 SCC 769 at SCC para 9.)
(iii) The order suffers from substantial errors of law and fact. (Rajesh Kumar v. Dharamvir, (1997) 4
SCC 496 at SCC para 5.)
(iv) The order is based on misconception of law or erroneous appreciation of evidence. (State of U.P.
v. Abdul, (1997) 10 SCC 135; State of U.P. v. Premi, (2003) 9 SCC 12 at SCC para 15.)
(v) The High Court has adopted an erroneous approach resulting in miscarriage of justice. (State of
T.N. v.
Suresh, (1998) 2 SCC 372 at SCC paras 31 and 32;
State of M.P. v. Paltan Mallah, (2005) 3 SCC 169 at SCC para 8.)
(vi) Acquittal is based on irrelevant grounds.
(Arunachalam v. P.S.R. Sadhanantham, (1979) 2 SCC 297 at SCC para 4.)
(vii) The High Court has completely misdirected itself in reversing the order of conviction by the
trial court. (Gauri Shanker Sharma v. State of U.P., (1990) Supp. SCC 656)
(viii) The judgment is tainted with serious legal infirmities. (State of Maharashtra v. Narsingrao
Gangaram Pimple, (1984) 1 SCC 446 at SCC para 45: AIR para 45.)
17. In reversing an acquittal, this Court keeps in mind that presumption of innocence in favour of
the accused is fortified by an order of acquittal and if the view of the High Court is reasonable and
founded on materials on record, this Court should not interfere. However, if this Court is of the
opinion that the acquittal is not based on a reasonable view, then it may review the entire material
and there will be no limitation on this Court’s jurisdiction under Article 136 to come to a just
decision quashing the acquittal. [See State (Delhi Admn.) v. Laxman Kumar, (1985) 4 SCC 476 at
SCC para 45 and Dharma v. Nirmal Singh, (1996) 7 SCC 471 at SCC para 4.]” This Court has
cautioned that if the view of the High Court is not reasonable, this Court may review entire material
and there will be no limitation on the jurisdiction of this Court under Article 136 to render justice
quashing the acquittal.
166. A−4 (Kalim Ahmad Karimi) was part of the conspiracy to murder Haren Pandya. On 7.12.2002,
he went to Udaipur along with A−13 (Mufti Sufiyan) and two others and visited the house of Usman
Khan Nawab Khan (PW−29). He also spoke to A−18 from a PCO at Udaipur. He received three
stolen Hero Honda motorcycles from Hussainmiyan Amirmiyan Shaikh (PW−57) on the directions
of A−13 (Mufti Sufiyan). He kept one motorcycle with him and handed over the other two to A−5Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

(Anas Machiswala) and A−14 (Sohail Khan Pathan). On 24.4.2003, he called A−1 (Mohmed Asgar
Ali) to Juni Jama Masjid and handed over three weapons in the same night to A−5 (Anas
Machiswala). The weapon was recovered at the instance of A−5 (Anas Machiswala). A−4 (Kalim
Ahmad Karimi) and A−5 (Anas Machiswala) visited Surat and procured two weapons from one
Maulana Tahir. As per the prosecution, A−4 (Kalim Ahmad Karimi) had kept the weapons at his
shop and had given the same to A−5 (Anas Machiswala) on the night of 25.3.2003 for killing Haren
Pandya.
167. The prosecution has relied upon the confessional statement under Section 32 of POTA, though
the A−4 (Kalim Ahmad Karimi) was in police custody from 25.4.2003 till 5.6.2003. He was sent to
judicial custody up to 17.6.2003. Thereafter on 24.6.2003, he made the confession after he was
given time for reflection. He admitted his signature on his confessional statement on the day on
which he was produced before the Magistrate. Later on, he said that while retracting confession that
his signature had been obtained forcibly.
168. It was submitted on behalf of accused that mere knowledge of plan would not constitute
conspiracy as observed in K.R. Purushothaman v. State of Kerala (supra). As already observed, the
conspiracy shall not be deemed to have been established on mere suspicion and surmises or
inferences which are not supported by cogent and acceptable evidence.
169. Reliance has further been placed on CBI v. V.K. Naryana Rao, (2012) 9 SCC 512 and Kehar
Singh (supra). It was further submitted that Hussainmiyan Amirmiyan Shaikh (PW−57) on the
instructions of A−4 (Kalim Ahmad Karimi), has stolen three motorcycles and given them to A−4
(Kalim Ahmad Karimi). Hussainmiyan Amirmiyan Shaikh (PW−57) has turned hostile and has
stated that he had not made any statement on 11.4.2003 regarding stealing of motorcycles. He
further stated that he had not given any statement in the crime branch and only his signatures were
taken on written paper before the Magistrate. He has denied his statement under Section 164 Cr.PC
also. He has submitted that signatures were given under coercion. The statement under Section 164
Cr.PC is not a substantive piece of evidence and needs corroboration as held in the State of Delhi v.
Shri Ram Lohia, AIR 1960 SC 490.
170. It was also submitted on behalf of A−4 (Kalim Ahmad Karimi) that prosecution has relied on
the deposition of Javed Abdul Rashid Khan Pathan (PW−45) who had purportedly disposed of two
motorcycles after the incident. He had also stated that he was forced to give the statement. He has
denied that motorcycle recovered from Apsara Cinema was seized in his presence and he has also
denied that motorcycle was shown to him at PS Kagdapith. He has denied the recovery of Suzuki
Samurai motorcycle recovered from the railway station. In view of the witness not supporting the
same, the recovery of motorcycles become doubtful and cannot be believed. Further, it was
submitted that there is no evidence to show that the motorcycles were used in the commission of the
offence of murder of Haren Pandya. The date of alleged theft of motorcycles is 2002, long before the
conspiracy of murder of Haren Pandya, which was hatched in March 2003. The procurement could
not imply any conspiracy to murder Haren Pandya.Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

171. It was further submitted on behalf of A−4 (Kalim Ahmad Karimi) that regarding the allegation
of procuring the weapons from Surat is based on his confessional statement, which is vitiated in law
and hence inadmissible. The confession under Section 32 regarding this allegation cannot be used
against A−4 (Kalim Ahmad Karimi) as held by this Court in Parliament Attack case. No weapon was
found in his possession nor did he lead to any discovery. The confession is uncorroborated. A−4
(Kalim Ahmad Karimi) had been convicted and sentenced in POTA 12/2003 and in the present case
for the charge under Section 3(3) of POTA, for the generic charge of conspiracy as also the Arms Act,
these sentences he has already undergone. He has undergone the punishment for all the charges
that relate to the time period prior to an alleged conspiracy to murder Haren Pandya. The High
Court has rightly acquitted him from the commission of an offence under Section 120−B and 302
IPC.
172. It is apparent that though Hussainmiyan Amirmiyan Shaikh (PW−57) has turned hostile, his
statement had been recorded under Section 164, Cr.PC (Exhibit 546). The confessional statement of
A−14 (Sohail Khan Pathan) is supported by the recovery of motorcycles from PS Kagdapith in the
presence of Bhaveshbhai Nagindas Shah (PW−
103) vide seizure memo Exhibit 628. Bhaveshbhai Nagindas Shah (PW−103) corroborates the
recovery of the motorcycle from PS Kagdapith. Bhagwan Singh Samantsinh Rathod (PW−50) has
also corroborated the recovery of the motorcycle from PS Koth area vide seizure memo Exhibit 356.
The weapon was also recovered at the instance of A−5 (Anas Machiswala). Hence, there is
corroboration of confession of A−4 (Kalim Ahmad Karimi) by the recovery of the weapon which was
procured by him. It is apparent that A−4 (Kalim Ahmad Karimi) was a close associate of A−13 (Mufti
Sufiyan) and has worked as a link between A−13 (Mufti Sufiyan) and the rest of accomplices. He
received three motorcycles which were stolen in 2002 and kept on the directions of A−13 (Mufti
Sufiyan) one motorcycle with him and handed over the other two to A−5 (Anas Machiswala) and A−
14 (Sohail Khan Pathan). It is also apparent that he has procured two weapons from Surat in
February 2002. After shooting incident of Jagdish Tiwari on 11.3.2003, he had attended meetings
dated 17/18.3.2003, 22.3.2003, 24.3.2003 and 25.3.2003, where modalities to murder Haren
Pandya were chalked out. He kept the weapon received on 17/18.3.2003 from A−5 (Anas
Machiswala) and A−13 (Mufti Sufiyan) in his shop. On 24.3.2003, he handed over three weapons
which were kept at his shop to A−5 (Anas Machiswala). On 25.3.2003, he received back those
weapons from A−5 (Anas Machiswala) after a failed attempt on Haren Pandya. Later in the night, he
again handed over weapons to A−5 (Anas Machiswala) as Haren Pandya was to be killed on the next
day.
173. It is also apparent that he was instrumental in changing the number of plates of the stolen
motorcycles at the bungalow of Junaid on the night of 25.3.2003. It is also apparent that he received
empty cartridges of bullets from A−5 (Anas Machiswala), which were allegedly shot at Haren
Pandya and handed them over to A−13 (Mufti Sufiyan), which were ultimately recovered. Few days
after the incident, he took A−1 (Mohmed Asgar Ali) on the instructions of A−13 (Mufti Sufiyan) to
Sikander Bhai at Kanoder for providing shelter, who refused to keep A−1 (Mohmed Asgar Ali) and
then he dropped A−1 (Mohmed Asgar Ali) at Shahpur flat. Thus, the conspiracy is supported by the
confessional statement. A−4 (Kalim Ahmad Karimi) had conspired and he was clearly part of theCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

conspiracy of killing Haren Pandya. A−4 (Kalim Ahmad Karimi) was held guilty by the Trial Court
for the offences punishable under Section 3(2) read with Section 3(3) of POTA. For the offences
punishable under Section 120−B read with Section 302 of IPC, he was sentenced to life
imprisonment with a fine of Rs.5,000/− with default clause. However, the High Court has
maintained and confirmed the conviction for the offence punishable under Section 3(3) of POTA
and sentence has been reduced to the period already undergone by him in jail with fine of
Rs.5,000/− each, and in default of payment of fine, he shall undergo RI for 6 months. The High
Court has acquitted A−4 (Kalim Ahmad Karimi) of charges under Section 120−B read with Section
302 of IPC and the charge for the offence under Section 3(1) punishable under Section 3(2)(a) of
POTA. He procured vehicles and weapons and due to his active role in the conspiracy, he is liable to
be convicted for commission of offence under Section 3(1) read with Section 3(3) of POTA and
Section 120B read with 302 IPC as ordered by the Trial Court.
IN RE: A−5 (ANAS MACHISWALA)
174. It is urged on behalf of accused that emails allegedly recovered at the instance of A−5 (Anas
Machiswala) are fabricated. The relevant exhibits were not signed by the accused as is evident from
the testimony of Sanjay Rameshbhai Brahmane (PW−65) the panch witness. It is further contended
that call records of accused are inadmissible in view of Section 65B of Indian Evidence Act, 1872. It
proves nothing against accused as they knew each other and thus their presence in the same vicinity
or having talked with each other should not arouse any suspicion. The BSNL call records are clearly
not computer−generated owing to the random order of dates and missing pieces of information and
in terms of Section 65B of the Indian Evidence Act, 1872, the records cannot be said to be
reproduced from the original computer. Thus, the requirements under Sections 65A and 65B of the
Indian Evidence Act, 1872 are not met. 174(a). As far as the confessional statement of Anas
Maschiswala (A5) is concerned, the procedural safeguard of giving 24 hour reflection time was duly
adhered to. All cautions were given to him. Voluntariness was ascertained. No signs of any physical
injuries were found upon examination, neither was he threatened in any manner. 174(b). It comes
forth in A5's confession that it was Mufti Sufiyan (A13) who had instigated one and all to take
revenge of the 2002 riots. He (A5) describes his role of instigating other boys for the Tiffin Box
Bombs. A5 describes the arms training that he underwent in Pakistan. He also names others who
had also obtained training at Pakistan. After the training, he stayed at Karachi, where he was
constantly in touch with Sohail Khan (A14−−absconding), who in turn was very friendly with Rasool
Party (A18−−absconding). A5 further states that after his return to Ahmedabad, he was informed by
Kaleem (A4) that three Hero Honda Motorcycles were arranged at the instance of A13, through
Hussainbaba (PW−57). One of these motorcycles was given to Anas (A5), which bore Registration
No. GJ−1−BD−5739. 174(c). A5 also speaks about the weapons that were brought from Surat by A5
& A4. Three SIM Cards were given to A5 by A14, one each to be inserted in the phones of A5, A7
(Rehan), and A8 (Goru). The code words "P", "G" and "R" for the names Parvez, Goru, and Rehan
were also fed by A5 in his phone. This was done at A14's instance. In relation to the attack on
Jagdish Tiwari, A5 states that while he was sitting one day with A13, A14, and A4, it was A14 who
had said that Tiwari of Medical store had played a major role in Communal Riots. Tiwari should be
done away by "Mehman". Jagdish Tiwari was shot on 11.03.2003. A5 states that he came to know of
this the next day. After this incident, A4 took back both the firearms.Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

174(d). It is further stated that on 15 th and 16th of March, A13 told him (A5) that Haren Pandya
would be killed next. A5 was in attendance at the meetings that took place on 17 th and 18th of
March, 2003 at Juni Jama Masjid. A14, A8, A7, and A4 also attended those meetings. A14 named
Haren Pandya as the next target because, according to A14, Haren Pandya had perpetrated atrocities
on Muslims during the communal riots apart from taking a major lead in the demolition of Paldi
Masjid. A5 describes as to how the task of doing a recce of Law Garden was first assigned to A12 and,
upon A12's failure, the same came to be entrusted to Parvez. The events of 23.03.03 and of 24.03.03
are also described. On 23.03.03 Haren Pandya had not turned up at Law Garden. On 24.03.03,
registration No. of the Maruti Fronti Car used by Haren Pandya came to be noted at Law Garden. It
is stated that after the first attempt to kill Haren Pandya was aborted, on the night of 25.03.03,
number plates of the motorcycles were changed by A4 and A14.
174(e). On the morning of 26.03.2003, A5 handed over a loaded pistol to A6 and a loaded revolver
to A1. After A1 undertook the task assigned to him of killing Haren Pandya, A1 along with A6 and
Rehman came to Shahpur Mill Compound, where A5 was present at the autorickshaw. A6 kept the
pistol and helmet in the autorickshaw, but A1 refused to give either of the firearms but handed over
five empty cartridges.
175. Evidence of PW−21, PW−120, PW−122, and PW−91 show due compliance of all procedures,
including confirmation proceedings. PW− 108 arrested A5 from Andhra Pradesh. He was arrested
along with A4 and A12. Disclosure, discovery, and seizure of both the pistol and the e−mail printouts
are supported by PW−65 (panch witness). The pistol was discovered at the instance of A5 in the
presence of this witness. Email−id and password were given by A5. Printouts of the emails were
taken out in the presence of this witness. This witness supported all documentary evidence in
relation to the above. Exhibit 685 is the sanction accorded by PW−115 to prosecute several accused
including A5 under the Arms Act. Other accused are A1, A3, and A6. This sanction under Section 39,
Arms Act was accorded by PW−115, being the In−Charge Police Commissioner of Ahmedabad City at
the relevant time. Vide notification dated 28.02.02, State of Gujarat had been declared to be a
notified area under the POTA. Mere possession of a firearm in a notified area is an offence as per
Section 4 of the POTA.
176. PW−87 opined as to matters connected with weapon discovered at the instance of A5. This
witness was a Senior Scientific Officer at CFSL, New Delhi. PW−87 opined that bullet recovered
from the body was Jadish Tiwari was fired from the 7.65 mm pistol discovered at A5's instance.
Three empty cartridges recovered from the shop of Jagdish Tiwari had also been fired from the same
weapon, which is a firearm as per the Arms Act, 1959. The evidence of PWs 87, 65, 108 and 120 has
no inter se anomalies.
177. For inter se cellular mobile communication of accused persons, testimonies of PW−11, PW−17,
PW−33 PW−36, and PW−46 are specifically relevant. Besides them, PWs 25, 26, 35, 40 also provide
corroborative evidence. In the face of this evidence, non−recovery of the mobile handset from A5
would, in fact, be an incriminating circumstance against him.Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

178. It is thus apparent that A−5 played a vital role at all stages of conspiracy, right from the very
inception, extending to the murder of Haren Pandya and the subsequent abscondment of various
accused, including himself. He was present in several meetings at various Masjids where different
aspects of the conspiracy were hatched and put into operation. He played a crucial role in the
procurement, handling, and storage of the illegally procured arms. 7.65 mm pistol was in fact
discovered and recovered at his instance. No great significance can be attached to PW−69 not
supporting the prosecution. First of all, this witness was A5's first cousin. Secondly, his Section 164
CrPC statement is on record. No complaint to any authority was ever made that this statement was
forcibly extracted.
179. He was, thus, rightly convicted and sentenced by the Trial Court for commission of offence
under section 3(1) r/w 3(3) of POTA as well as 120B and 120B read with 302 IPC for commission of
offence of murder of Haren Pandya. The same is restored.
IN RE: A−6 (MOHMED YUNUS SARESHWALA)
180. It was submitted by Shri Raju Ramachandran, learned Senior Counsel on behalf of A−6
(Mohmed Yunus Sareshwala) that his presence at the Law Garden area at the time of the incident
has not been established. It was submitted on behalf of A−6 (Mohmed Yunus Sareshwala) that as
per prosecution he was present in the meeting dated 25.3.2003 in the Masjid. A−5 (Anas
Machiswala) told him that A−6 (Mohmed Yunus Sareshwala) would take A−1 (Mohmed Asgar Ali)
to Law Garden on a motorcycle for killing Haren Pandya. A−5 (Anas Machiswala) also provided him
black coloured Hero Honda motorcycle for the purpose and mobile instrument of A−8 (Mohmed
Riyaz) having SIM card. Discovery has been made on the basis of disclosure memo under Section 27
of the Evidence Act furnished by A−1 (Mohmed Asgar Ali) regarding pistol and it is recovered in the
presence of SrinathSinh ShambhauSinh (PW−13). CDR call records of mobile no.9426325774 has
been placed on record.
181. Disclosure memo Exhibit 196 of the pistol and its seizure vide Exhibit 195 have been proved on
record. The confessional statement of A−6 (Mohmed Yunus Sareshwala) disclosed that he was given
72 hours to reflect upon the aspect of his confession. He stated of his having taken the training at
Pakistan with Parvez and Goru. After giving details of his role in AMTS blasts on 29.5.2002, they
also purchased country−made revolver from money given by A−5 (Anas Machiswala). Masak told
them to create terror amongst the people by killing the leaders. He was informed that 15−20 guests
were to come to Ahmedabad and A−4 (Kalim Ahmad Karimi) had to make arrangement for all of
them. On 9.3.2003, A−5 (Anas Machiswala) called up on mobile of A−7 (Rehan Puthawala) and told
that they were required to meet at Sidi Saiyed Jaliwali Masjid. They also met A−5 (Anas
Machiswala) and A−14 (Sohail Khan Pathan) asked them to create terror since extensive training
was imparted to them. The first target was Jagdish Tiwari (PW−39). On 18.3.2003, A−7 (Rehan
Puthawala) called upon his residence and said that it was Haren Pandya who is enlisted next for
killing and with his killing, a terror shall be created in Gujarat. A−10 (Parvez Khan Pathan) was
doing a recce to kill Haren Pandya. On 25.3.2003, A−7 (Rehan Puthawala) called up A−10 (Parvez
Khan Pathan) and asked him to come at Pan Galla near Al Fazal Masjid. On 25.3.2003, an
unsuccessful attempt was made to kill Haren Pandya. On 26.3.2003, he was required to takeCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

accused A−1 (Mohmed Asgar Ali) on a motorcycle at Law Garden so as to kill Haren Pandya. A−5
(Anas Machiswala) told him that he would be given Hero Honda motorcycle at Law Garden. A−4
(Kalim Ahmad Karimi) also told him that he would be given a pistol and if anybody is following
them, he could do firing in the air. A−5 (Anas Machiswala) got a new SIM card for A−6 (Mohmed
Yunus Sareshwala) which was used in the mobile phone of A−8 (Mohmed Riyaz @ Goru). At 7
O'clock in the morning, he was required to take Mehman to Law Garden. In Sunrise Bungalow
Society, A−5 (Anas Machiswala) and A−4 (Kalim Ahmad Karimi) changed the number plates of both
the Hero Honda motorcycles and A−5 (Anas Machiswala) gave him the motorcycle bearing
registration no.1110. He went on that motorcycle at 6.30 am to Lucky Restaurant. He purchased
Sandesh newspaper at Juhapura and at 6.56 am reached to Lucky restaurant and by that time A−5
(Anas Machiswala) reached there and called him at Jaliwali Masjid and in the bathroom, he was
given pistol by A−5 (Anas Machiswala) and said that it was locked and loaded. Thereafter, he went
along with A−1 (Mohmed Asgar Ali) to Nehru Bridge. He had worn a helmet and near the gate of
Thakardas Hall, he pretended to read a newspaper. He saw A−10 (Parvez Khan Pathan) passing
from the opposite side and nodded at him. He heard firing of 4 to 5 bullets. He started the
motorcycle and wore the helmet. After about 1 to 1½ minutes, Mehman approached him and set as a
pillion rider. He went towards Gujarat College to Gandhidham Railway Station to Nehru Bridge.
From there they went to Shahabuddin Dargah to Shahpur Mill Compound, where they met A−14
(Sohail Khan Pathan) and A−7 (Rehan Puthawala), who was waiting in an autorickshaw. A−6
(Mohmed Yunus Sareshwala) went with A−7 (Rehan Puthawala) on his motorcycle after changing
two autorickshaws. He went to his residence at Juhapura. He was very happy to know about the
death of Haren Pandya.
182. His confessional statement has been corroborated by Alpesh Ranchhodbhai Patel (PW−11),
SrinathSinh ShambhauSinh (PW−13), Manojkumar Baldevbhai (PW−17), Hemantkumar Ratilal
Patel (PW−33) and Rajendra Singh S. Chhikara (PW−110). They are the witnesses to the recoveries
of SIM cards. Alpesh Ranchhodbhai Patel (PW−11) and Manojkumar Baldevbhai (PW−17) are the
witnesses relating to BSNL SIM cards, which were used by the accused persons during the
conspiracy of murder of Haren Pandya, to remain in touch with each other. At the instance of A−1
(Mohmed Asgar Ali) 7.5 mm pistol bearing no.EE330 was discovered from Flat No.4/B, Kamar Flats
from Batiwala Stove and Srinathsinh Shambhausinh (PW−13) was the witness to the said discovery.
Jayantibhai Vitthaldas Suthar (PW−27) has proved the landline of the house of Mohmed Yunus
Sareshwala (A−6) at A/12, Sunrise Apartment, Juhapura, Ahmedabad and the same has been
admitted by A−6 (Mohmed Yunus Sareshwala) in his further statement recorded under Section 313,
Cr.PC. The incriminating circumstances are proved by the said evidence. Rajendra Singh S.
Chhikara (PW−110) was present at the time of discovery at Kamar Flat. The motorbike used during
the commission of an offence was driven by A−6 (Mohmed Yunus Sareshwala) and was handed over
to Javed Abdul Rashid Khan Pathan (PW−45). It is apparent that A−6 (Mohmed Yunus Sareshwala)
has also provided logistic support throughout the conspiracy and on the date of the killing of Haren
Pandya. He had not only driven A−1 (Mohmed Asgar Ali) to Law Garden but also waited near
Thakarbhai Desai Hall under the pretext of reading a newspaper till A−1 (Mohmed Asgar Ali)
accomplished the task assigned to him and drove him back to Shahpur Mill Compound. He was also
provided one pistol bearing no.EE330 by A−5 (Anas Machiswala) for his own protection and also for
the protection of A−1 (Mohmed Asgar Ali). Proximity of A−6 (Mohmed Yunus Sareshwala) with restCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

of the group, his explicit act in taking A−1 (Mohmed Asgar Ali) to Law Garden and waiting till killing
of Haren Pandya under the pretext of reading newspaper and thereafter, taking A−1 (Mohmed Asgar
Ali) to Shahpur Mill Compound and handing over the weapon and vehicle and completing
everything with meticulous detail are all reflected in the confessional statements.
183. It is submitted on behalf of accused that sole eyewitness Anilram Yadavram Patel (PW−55) has
not made any reference with regard to A− 6 (Mohmed Yunus Sareshwala) presence at the place of
incident. It is further alleged that prosecution has relied on the evidence of Hemantkumar Ratilal
Patel, BSNL Officer (PW−33) to ascertain the location of A−6 (Mohmed Yunus Sareshwala) based
on the call details record of mobile no.9426325774. It is alleged that A−5 (Anas Machiswala) had
given three SIM cards to A−7 (Rehan Puthawala) of mobile no.9426325765, A−8 (Mohmed Riyaz)
having mobile no.9426325774 and A−9 (Mohmed Parvez Sheikh) of mobile no.9426325768. It is
submitted that Hemantkumar Raitlal Patel, BSNL Officer (PW−33) has given the call details and
location based on it of aforesaid three mobile numbers on the morning of 26.3.2003 in his
deposition. As per him, the following calls were made on 26.3.2003:
i. A−9 (Mohmed Parvez Sheikh) contacted A−7 (Rehan Puthawala) twice at 7:18:35
and 7:18:43. As per him, the location of A−9 was Law Garden and that of A−7 was
Nehru Bridge.
ii. At 7:34:43 another call was made by A−9 (Mohmed Parvez Sheikh) to A−7 (Rehan
Puthawala), but their location could not be traced due to technical lag.
It is further submitted that there was no call either made or received by A−6
(Mohmed Yunus Sareswala) on that date between 7.00 am to 8.30 am. Hence, A−6
(Mohmed Yunus Sareswala) presence has not been conclusively established at the
place of incident.
184. It is also submitted that the CDR produced by Hemantkumar Raitlal Patel,
BSNL Officer (PW−33) is in typed format and in any case, it is inadmissible under
Section 65B of the Evidence Act. It is further submitted that there is no evidence to
show that A−6 (Mohmed Yunus Sareswala) had taken A−1 (Mohmed Asgar Ali) to
Shahpur Mill Compound after the murder of Haren Pandya. With regard to recovery
of pistol carried by A−6 (Mohmed Yunus Sareswala), it is contended that it was not
recovered at the instance of A−6 (Mohmed Yunus Sareswala), but from the purported
disclosure made by A−1 (Mohmed Asgar Ali), which only binds the maker of the
statement and cannot be used against A−6 (Mohmed Yunus Sareswala). It is
inadmissible under Section 27 of the Evidence Act against A−6 (Mohmed Yunus
Sareswala) as it only binds the maker of the disclosure. Thus, there is no evidence to
hold him guilty for the involvement in the conspiracy of murder of Haren Pandya.
185. In our view, the submissions on behalf of the accused are baseless. Alpesh
Ranchhodbhai Patel (PW−11), SrinathSinh ShambhauSinh (PW−13), Manojkumar
Baldevbhai (PW−17), Hemantkumar Ratilal Patel (PW−33) and Rajendra Singh S.Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

Chhikara (PW−110) are the witnesses to corroborate the confessional statement.
They are also witnesses to the recoveries of SIM cards. Alpesh Ranchhodbhai Patel (PW−11) and
Manojkumar Baldevbhai (PW−17) are the witnesses of BSNL SIM cards, which were used during an
incident to remain in contact with each other. Discovery of 7.5 mm pistol bearing no.EE330 at the
instance of A−1 (Mohmed Asgar Ali) from Flat No.4/B, Kamar Flats was from Batiwala stove and
Srinathsinh Shambhausinh (PW−13) was the witness of that discovery. In his testimony, he had
discussed at length A−1 (Mohmed Asgar Ali) had hidden two weapons given to him by the accused.
Jayantibhai Vitthaldas Suthar (PW−27) had proved the landline number at the house of A−6
(Mohmed Yunus Sareshwala) at A/12, Sunrise Apartment, Juhapura, and the said fact had also been
admitted by A− 6 (Mohmed Yunus Sareswala). Record of mobile phone location also revealed the
incriminating circumstances as proved by the evidence. Rajendra Singh S. Chhikara (PW−110) was
present at Kamar Flat when the discovery was effected. Motorbike used during the commission of
the offence was handed over to Javed Abdul Rashid Khan Pathan (PW−45), who turned hostile to
the case of the prosecution. He had taken A−1 (Mohmed Asgar Ali) to spot and brought him back
also and carried a weapon too. Keeping in view his proximity with rest of the group and his
involvement in the conspiracy to kill Haren Pandya, the conviction and sentence awarded to A−6
(Mohmed Yunus Sareswala) by the Trial Court under Section 120B read with Section 302 IPC and
under section 3(1) and 3(3) of the POTA, is found to be appropriate.
IN RE: A−7 (REHAN PUTHAWALA)
186. Evidence against A−7 (Rehan Puthawala) is that on 9.3.2003 he was present at Jaliwali Masjid
along with A−5 (Anas Machiswala), A−8 (Mohmed Riyaz), A−9 (Mohmed Parvez Sheikh), A−12
(Shahnawaz Gandhi) and A−14 (Sohail Khan Pathan), where A−14 (Sohail Khan Pathan) disclosed
that Jagdish Tiwari (PW−39) would be their target due to his role in riots and task will be
accomplished by Mehman (A−1 – Mohmed Asgar Ali) who has come from Hyderabad. On
17/18.3.2003, he attended meeting at Juni Jama Masjid where A−14 (Sohail Khan Pathan) disclosed
that Haren Pandya would be their next target and A−1 (Mohmed Asgar Ali) would execute the
killing. He also attended the meeting held on 22.3.2003 at Juni Jama Masjid where A− 14 (Sohail
Khan Pathan) assigned the task of a recce of Haren Pandya at Law Garden to A−12 (Shahnawaz
Gandhi). On 23.3.2003 at about 7.00 am, A−9 (Mohmed Parvez Sheikh) called A−1 (Mohmed Asgar
Ali) using his mobile in which A−5 (Anas Machiswala) had stored the numbers of A−1 (Mohmed
Asgar Ali) and A−5 (Anas Machiswala) as Mama and Uncle respectively. On 24.3.2003, he was
present in the meeting at Juni Jama Masjid where A−1 (Mohmed Asgar Ali) was called by A−4
(Kalim Ahmed) by making a phone call. On the directions of A−14 (Sohail Khan Pathan), A−9
(Mohmed Parvez Sheikh) took A−1 (Mohmed Asgar Ali) to Law Garden for familiarisation with
topography. In the said meeting, he was assigned the task to remain present at Nehru Bridge in
order to escort A−1 (Mohmed Asgar Ali) and A−8 (Mohmed Riyaz) after killing Haren Pandya. A−5
(Anas Machiswala) handed over to him one SIM Card of BSNL for using next morning. The CDR of
mobile no.9825398516 and print out of mobile no.9426325775 vide Exhibits 469 and 310
respectively have been cited.Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

187. It is apparent from the record that he could not go for training to Pakistan as during the month
of Ramzan his parents were to come from the USA and he decided to opt out. However, he has
provided complete logistic support to all those who went for training. He was also contacted by Anas
Machiswala (A−5) from Dubai and the others from Calcutta. He was in regular touch with A−4
(Kalim Ahmad Karimi) and has helped his friends who were in difficulty in Calcutta. On his asking,
he was informed by A−14 (Sohail Khan Pathan) that A−1 (Mohmed Asgar Ali) @ Mehman, who is
coming from Hyderabad, would perform the task of killing Haren Pandya and rest of the members
have to provide logistic support only. He has also attended the meeting on 22.3.2003 called by
Sohail Khan Pathan (A−14) and Anas Machiswala (A−5) at Old Jumma Masjid, where A−9
(Mohmed Parvez Sheikh) was directed by A−14 (Sohail Khan Pathan) to carry out recce of Law
Garden as A−12 (Shahnavaz Gandhi) could not do so. He had his own mobile no.9825398516, where
he fed mobile no.9825498241 of A−1 (Mohmed Asgar Ali) and mobile no.9825311510 of A−5 (Anas
Machiswala) as Mehman and Uncle respectively. It is also apparent that he had waited at the corner
of Nehru Bridge for A−1 (Mohmed Asgar Ali) and A−6 (Mohmed Yunus Sareshwala) to come. He
escorted them to Shahpur Mills Compound where A−5 (Anas Machiswala) and A−14 (Sohail Khan
Pathan) were waiting for them in an autorickshaw. He also accompanied A−6 (Mohmed Yunus
Sareshwala) for handing over the helmet and weapons to A−5 (Anas Machiswala) and A−6
(Mohmed Yunus Sareshwala) gave him brief detail about the killing of Haren Pandya. He also
accompanied A−8 (Mohmed Riyaz @ Goru) for getting the fake number plate. His mobile phone
directory gave a major lead in the investigation and his active role at every stage and overt act are
visible from the evidence adduced by the prosecution.
188. It is also apparent that A−7 (Rehan Puthawala) is a close friend of A−10 (Parvez Khan Pathan),
A−12 (Shahnavaz Gandhi) and A−8 (Mohmed Riyaz). He has given his confessional statement to
Vinayak Prabhakar Apte (PW−21) and the same had been confirmed by Dahyabhai Mathurbhai
Patel (PW−91). Though Hussainmiyan Amirmiyan Shaikh (PW−57) has not supported his own
statement, yet he has stated that he was known to A−4 (Kalim Ahmed Karimi) through A−13 (Mufti
Sufiyan) and also knowing all the accused including A−7 (Rehan Puthawala). Shaikh Mohmed Riyaz
Hussainmiyan Pirmiyan (PW−52) the owner of “Star Number Plate” shop has categorically stated
about A−8 (Mohmed Riyaz @ Goru) and A−7 (Rehan Puthawala) having approached for number
plate and also taken the delivery and at the end of May 2003, they had shown his shop to CBI
Officer from where the number plate was got prepared. The motorcycle having fake registration
no.GJ−1−CH−5189 originally belonged to Gaurang Gandhi. This motorcycle was stolen and the
original owner Gaurang Gandhi had made a request not to transfer the stolen vehicle in the name of
any other person. As stated earlier, the fake number plate was discovered from the bushes near
Tarapur Highway and it was A−10 (Parvez Khan Pathan) who left the motorcycle at Tarapur
Highway while he and A−11 (Mohmed Faruq) were running away to Bharuch to Surat to Pune and to
Hyderabad and this motorcycle was found by PS Koth. The discovery of motorcycle is duly proved
by Bhagwan Singh Samantsinh Rathod (PW−50), PSI posted at PS Koth. After killing Haren Pandya,
the fake number plate was put by the accused so as to save themselves from the clutches of law.
Sirajbhai Mustufabhai (PW−60) has stated about the visit of A−7 (Rehan Puthawala) along with
other accused to his Pan Parlour.Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

189. The sanction granted by Kuldeep Chand Kapoor (PW−117) to A−7 (Rehan Puthawala) under
Section 50 of POTA; the deposition of Dr. Sushilkumar S. Gupta (PW−120), Investigating Officer
relating to pointing out of Star Number Plate shop; and the deposition of Babarbhai Maljibhai
Rabari (PW−34), a panch witness to the disclosure of making of fake number plate and pointing out
and seizure of rough bill book of Star Number Book are strong corroborative evidence to corroborate
the confession of A−7 (Rehan Puthawala) recorded by Vinayak Prabhakar Apte (PW−21).
190. It is apparent that he was provided with BSNL SIM card mobile no.9426325765. and he was
present at Nehru Bridge in the morning of 25.3.2003 and escorted A−1 (Mohmed Asgar Ali) and A−
8 (Mohmed Riyaz) to Shahpur Mills Compound where A−5 (Anas Machiswala) and A−14 (Sohail
Khan Pathan), were waiting for them with an autorickshaw. On 26.3.2003, he reached Nehru Bridge
corner at about 7.15 am and he received a phone call from A−9 (Mohmed Parvez Sheikh) while he
was on his way. On seeing A−1 (Mohmed Asgar Ali) and A−6 (Mohmed Yunus Sareshwala) on a
motorcycle, he escorted them to Shahpur Mill Compound where A−5 (Anas Machiswala) and A− 14
(Sohail Khan Pathan) were waiting with an autorickshaw and returned the SIM card to A−5 (Anas
Machiswala). He parked the motorcycle used by A−6 (Mohmed Yunus Sareshwala) in the parking of
Anam Flats, Daryapur on 28.3.2003. After 2−3 days of the murder of Haren Pandya, on the
direction of A−5 (Anas Machiswala), he along with A−8 (Mohmed Riyaz) went to Shaikh Mohmed
Riyaz Hussainmiyan Pirmiyan (PW−52) and got prepared false number plates bearing no.5189. This
fact has been proved by Shaikh Mohmed Riyaz Hussainmiyan Pirmiyan (PW−52) by his deposition
vide document Exhibit 379 and Babarbhai Maljibhai Rabari (PW−34) vide document Exhibit 311.
191. It was submitted on behalf of accused by Shri Raju Ramachandran, learned Senior Counsel that
there was no necessity to escort A−6 (Mohmed Yunus Sareshwala), who is a local resident of
Ahmedabad. The CDR (Exhibit 310) has failed to show the location of the number which was being
used by A−7 (Rehan Puthawala) on 26.3.2003 and the CDR was inadmissible in evidence. The
allegation against the accused was far from the truth and also baseless. The evidence of Shaikh
Mohmed Riyaz Hussainmiyan Pirmiyan (PW−52) is fraught with infirmities. There is a doubt as to
whether A−7 (Rehan Puthawala) approached him for a false number plate of the motorcycle. The
receipt produced contains no name and he has erased Splendor and written Yamaha against the
entry of number 5189, whereas it is his original case that he was asked to prepare a number plate for
Yamaha which was later changed to Splendor. The job book is recovered on 22.5.2003 whereas he
has not stated that CBI has come to his shop before 23.5.2003. The statement is typed on a
computer, but there is no computer at the shop of Shaikh Mohmed Riyaz Hussainmiyan Pirmiyan
(PW−52) and he has not been confronted with number plate in the court as a material object to
identify as the one made at the behest of A−7 (Rehan Puthawala).
192. In our opinion submissions are baseless. There is no reason for Shaikh Mohmed Riyaz
Hussainmiyan Pirmiyan (PW−52) to speak lie and it is apparent that he is a reliable witness and that
the fake number plate of motorcycles had been got prepared by the accused was recovered and it
was used at the time of the commission of the offence. Shaikh Mohmed Riyaz Hussainmiyan
Pirmiyan (PW−52) is categorical about A−7 (Rehan Puthawala) and A−8 (Mohmed Riyaz) having
approached him for a number plate. It was at the instance of A−7 (Rehan Puthawala) and A−8
(Mohmed Riyaz) CBI officers came to know of the place where number plates have been prepared.Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

The motorcycle was stolen one and fake number plates have been discovered from the bushes near
Tarapur Highway. It was A−10 (Parvez Khan Pathan) who left the motorcycle at Tarapur Highway in
the bush. The recovery of the motorcycle is proved by Bhagwan Singh Rathod (PW−50)
corroborated by Alpesh Ranchhodbhai Rathod (PW−86 − the panch witness) and by deposition of
Investigating Officer, CBI and Dr. Sushilkumar S. Gupta (PW−120). The vehicle was used in killing
Haren Pandya and the fake number plate was put by the accused so as to save themselves from the
clutches of law and prevent identification. The guilt stand proved against the A−7 (Rehan
Puthawala) as found established by the Trial Court.
193. The conviction and sentence imposed by the Trial Court on Rehan Puthawala is found to be
proper under section 3(1) and 3(3) of POTA as well as section 120B r/w section 302 IPC for
commission of murder of Haren Pandya.
IN RE: A−8 (MOHMED RIYAZ @ GORU)
194. It is the contention of the learned counsel that there is no record or written evidence against A−
8 (Mohmed Riyaz) that he has given the order for the number plate. It is also averred that
alterations were made in the job workbook of Star Number Plate. There is no independent evidence
linking the number plate to the offence. It is further submitted that prosecution has picked up
abandoned bikes already in the local police custody and foisted the same on the accused. Each
motorcycle recovered is the planted recovery and has been falsely connected to this case. It is further
submitted that there is no independent evidence to establish the connection of motorcycle recovered
by PS Koth, which CBI claimed to be connected with number plate 5189, with the offence. The
discrepancies as to the presence or absence of a number plate on the motorcycle in the panchnama
and in the testimony of Sushilkumar S. Gupta (PW−120) creates suspicion. It is further urged that
on account of broadcast in May 2003, the CBI came to know about the motorcycle being at PS Koth.
This broadcast indicates that CBI was aware of the motorcycle in the month of May itself and the
recovery of the motorcycle from PS Koth on 12.6.2003 was choreographed to suit the case of the
prosecution. Despite Court’s directions, no broadcast documents have been produced. It is stated
that motorcycle having number plate 8973 was recovered from the parking of Apsara Cinema by
Kagdapeeth PS on 9/10.4.2003 and it was seized by CBI on 25.4.2003. However, Javed Abdul
Rashidkhan Pathan (PW−45) denies being shown the motorcycle at Kagdapeeth PS and also states
that CBI did not seize it in his presence. It is also contended that original owner Ashokbhai Ambalal
Shah (PW−36) of the above motorcycle has deposed that from 24.12.2002 i.e., the day he filed a
complaint of theft of motorcycle till 4.5.2003, he regularly visited (every 15−30 days) the
Kagdapeeth PS to inquire about his stolen motorcycle. It is, thus, completely incomprehensible as to
why Amduji Pabji Chavda (PW−46) did not inform him immediately when the bike was recovered.
195. It is further alleged that Bhagwan Singh Samantsinh Rathod (PW−50) has categorically stated
that broadcast made in May 2003 about the recovered motorcycle indicates that CBI was aware of
the motorcycle at the time of recovery of the number plate and fabricated a connection between the
two later.Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

196. A−8 was given 78 hours of reflection time. All necessary cautions and explanations were given
to him. His confessional statement was recorded on 08.06.03. Custody was handed over to PW120
at 4.00 am on 08.06.03. He had not complained of anything when produced before PW91 at 10.40
am. His oral retraction was made on 29.07.03; written retraction on 11.08.03.
197. A−8 stated that he undertook arms training in Pakistan. He went there via Dhaka, along with
Yunus (A6), Parvez (A9), and another person named Munaver Beg @ Captain. Fake passports were
used for this, where A8’s name was Abdul Karim. Besides this, he also spoke of his close association
with other persons, namely, Kaleem (A4), Anas (A5), Yunus (A6), Parvez (A9) Shahnawaz (A12), and
Rasul Khan Party (A18−−absconding). One specific instance of his association with Rehan (A7)
came after the murder of Haren Pandya. This was in relation to changing the number plate of Hero
Honda Motorcycle, which was done at the Shop of Star Number Plate. A8 had gone with A7 for this
purpose. Number plate registration No. GJ−1−CA−5189 was suggested for this task by Anas (A5).
Prior to changing the number plate, he was instrumental in taking Asgar Ali (A1) to Law Garden on
25.03.03. Black coloured Hero Honda motorcycle was used for this; it was provided by Anas (A5).
The plan to murder Haren Pandya was aborted on that day (i.e. on 25.03.03) as the place was found
to be very crowded. Next day, i.e. on 26.03.03, it was Yunus (A6) to whom the task of taking A1 to
Law Garden for the murder of Haren Pandya came to be handed over.
198. By and large, A8’s confessional statement is on the same lines as that of A6. Although he had
complained of forcible extraction of his confessional statement by making him sign on blank papers,
trial court did not attach much importance to this in view of his late retraction which was held to be
on legal advice, with no prior complaint having been made to any judicial officer and all safeguards
of Section 32, POTA had been duly observed by the S.P.
199. PW−21, PW−120, and PW−91 prove contemporaneous record of the requisition, the
preliminary questioning, the caution which was administered and the confirmation procedure under
Section 32 (4) of the POTA, in regard to the confessional statement of A−8. Additionally, all
witnesses examined to prove A−7’s guilt are examined to prove A−9’s complicity as well.
Corroborative evidence also comes forth from PW− 11, PW−17, PW−21, PW−45, PW−52, PW−60,
PW−77, PW−91, PW−114, PW−117, and PW−120. Depositions of PW−119 and PW−33 (working as
Sub−Divisional Engineer and Divisional Engineer, respectively at BSNL, Ahmedabad) are in relation
to cell phone records.
200. On 25.03.03 A8 drove A1 to Law Garden. Haren Pandya was to be murdered on that day as per
the conspired planning. This mission had to be aborted on 25.03.03. For 26.03.03 (i.e. the day
Haren Pandya was actually murdered) A−8’s task of taking A−1 to Law Garden was assigned to A−6.
This was done at A−14’s instance, lest repeated visits should blow away A−8's cover. Further, after
Haren Pandya was murdered, a fake number plate was obtained for the stolen Hero Honda
motorbike. Fake number plate bore registration No. GJ−1−CH− 5189, whereas the motorbike earlier
had a plate bearing registration No. GJ−2164. The fake number plate was changed at Star Number
Place, shop of PW−52. A−8 had prior acquaintance with PW−52. The stolen motorbike had been
procured through PW−57 at the instance of A−13 (absconding accused). The number plate was
discovered at the instance of A−10, who had left the motorcycle at Tarapur Highway.Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

201. A−8 was arrested on 03.04.03 from Parimal Garden. Depositions of PW−114 and DW−3 bear
on this aspect. DW−3 lived in A−8’s neighborhood. This witness stated that A8 was taken away by
police at night; time around 2.30; the date was 2 nd or 3rd of April, 2003. DW−3 deposed nearly
three years after the happening. There are no supporting documents. It is very incredulous that
prior to receiving of Court summons, this witness had no knowledge of what it was that occurred,
neither did he make any inquiries in relation to A−8 (the son of DW3’s neighbour). Equally, he is
himself unsure of the exact date. Therefore, even if, arguendo, his version was to be believed, it
would still not dent the prosecution. Thus, there is nothing to suspect arrest of A−8.
202. As for the discrepancies alleged in the format of the call records, these would not go to the
falsify the prosecution’s case. At the time of his arrest, SIM Card was found from his pocket. Mobile
Nos. 9426007240 and 9825384241 (Hutch) belonged to A8, along with mobile phone bearing IMEI
No. 448478527477630). In view of the evidence on record, A−8 (Mohmed Riyaz @ Goru) had
rightly been convicted and sentenced by the Trial Court for commission of offence under section 3(1)
read with section 3(3) of POTA as well as under
section 120B and 120B read with section 302 IPC for commission of murder of Haren
Pandya. The same is restored.
IN RE: A−9 (MOHMED PARVEZ SHEIKH)
203. In a nutshell, details of his training at Pakistan and return from there, together with his
knowledge and role in AMTS Blasts, attack on Jagdish Tiwari (PW−39), and murder of Haren
Pandya are all mentioned in the statement. A9 also provides details of the role played by others in
the entire sequence of conspiracy. 60 hours of reflection time was given to him. The requisition was
given on 04.06.03. The statement was recorded on 07.06.03. Willingness was again verified after
recording the statement. A9 put his signatures to it. His custody was handed over to PW−120 at 4.50
pm. The next day being Sunday, he was produced before PW−91 at 10.35 am on 09.06.03. No
grievance was raised against police. No complaint was made of any physical or mental ill−treatment
at the hands of police. His subsequent warrant of judicial remand is Ex. 324.
204. He went for training at Pakistan via Indo−Bangla Border. A4 had told him that even those who
did not have passports were also to go there. A9 states that although Rehan (A−7) could not make it,
for his (A−7's) parents were visiting from the USA, Anas (A−5), Shahnawaz (A−
12), Sohail Khan (A−14), and Yunus (A−6) had all gone for training at Pakistan. Two coded messages
are also mentioned to have been sent, one each on behalf of A−18 and A−18’s wife; the former was
sent for A4, the latter in the form of a letter for A−8 and A6.
205. A−9 was present in the meeting at Jaliwalli Masjid on 09.03.03. He states that attendees
included A−4 and A−14. There, A14 disclosed two things. Firstly, that Jagdish Tiwari would be their
target and secondly that two ‘guests’ from Hyderabad had also been called; both of whom trained at
Pakistan. It is stated that firing upon Jagdish Tiwari came to A−9's knowledge via a newspaper.
Next, he met A−7 and A−12. Along with them, A−9 met A−4, A−5, A−12, and A−14 at Juni JamaCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

Masjid. This time, Haren Pandya came to be named as their target. Haren Pandya was stated to have
worked very actively during the riots, as also in the demolition of the Paldi Masjid. A−14 disclosed
that a sharpshooter had come from outside for accomplishing this.
206. A−9 states that the first task assigned to him was for undertaking the recce of Law Garden. This
fell to him since earlier A− 12 had failed to undertake the same task. Therefore, in the meeting at
Juni Jama Masjid on 22.03.03, it was to A9 that this task came to be assigned by A−14. A−14 is so
stated to have disclosed certain aspects of Haren Pandya's movements in/around Law Garden: that
Haren Pandya would go for a morning walk at Law Garden every day, and entering from towards the
Thakarbhai Desai Hall, Haren Pandya would park his White Maruti Fronti Car near Children's Park.
Upon not sighting their target on the morning following the meeting dated 22.03.03, A9 once again
went to Law Garden on 24.03.03 on his motorbike. On this occasion, he found Haren Pandya. He
also found his Maruti Fronti Car bearing registration No. GJ−1−AP−4606. What thereafter followed
on 25.03.03 and on 26.03.03 is also mentioned by A9, including as to why it was that on 25.03.03
the plan to murder Haren Pandya came to be aborted. On both these days, A−9 was present in the
vicinity of Law Garden, opposite H.A. College. Finally, he saw Haren Pandya being killed by A−1. A−
9 saw to it that nobody followed A−1. Besides the aforesaid, A−9 also provides details of the mobile
numbers used by various co−conspirators. A−7’s number was 9825398156, that of A−1 was
9825498421 and A−5 had 9825311510. It was through A−7’s mobile phone that A1 was asked to
reach Law Garden at 7 am on 23.03.03.
207. Defence mounted an attack on the entire procedure of recording confessions. Specifically,
voluntary recording of A−9's confession was stated to be improbable. To this end, certain aspects of
PW21's deposition were pressed into service. Accused had been sent for a medical check−up as part
of compliance of the guidelines in D.K. Basu’s Case. PW−21 had mentioned that about 12 hours and
50 minutes were taken to record A−9’s confessional statement. There was no interruption of any
kind while recording the confession. Recording started at around 4 am; ended at 4.30 pm. A−9 was
produced at the Civil Hospital for medical check−up on 07.06.03. Medical papers (Ex.
773) show his presence along with other accused. Mr. I.C. Sharma of CBI had taken A−7, A−8, A−9,
A−10, and A−11 for medical examination around 10 am. With aforesaid as the position, defence
contention was that there could have been no uninterrupted recording of the statement. Thus, PW−
21 perjured himself. A confessional statement is hence rendered, suspect.
208. There is no substance in the aforesaid defence arguments. The defence did not ask for a recall
of PW−21 to cross−examine him as to aforesaid aspects. Even if medical papers were produced late,
nothing prevented the defence from asking for his recall. It cannot thus be concluded that PW−21
perjured himself. In fact, PW−21 was duty− bound to refer the accused persons for medical check−
up every 48 hours. The outer time−limit for medical examination is provided for under D.K. Basu
Guidelines. Bonafide compliance of this mandate cannot be held to be against prosecution’s case. It
is to be also kept in mind that during the reflection time of 60 hours given to A−9, he was not sent
for medical examination. A perusal of Ex. 772 shows that A−9 was last sent to Civil Hospital on
03.06.03 at 9.35 am. This aspect also throws light on the necessity for sending A−9 for medical
check− up on 07.06.03.Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

209. Lastly, the defence contention of forcible extraction of confession is also to be noted, if only to
be rejected. There is no proof of the alleged torture. There is no medical evidence substantiating the
same. On the other, sufficient corroboration is available for A−9’s confession. Considering the
overall evidence, the Trial Court convicted and sentenced him rightly under section 3(1) read with
section 3(3) of POTA as well as 120B IPC and 120B read with 302 IPC also for commission of
murder of Haren Pandya. The same is restored. IN RE: A−10 (PARVEZ KHAN PATHAN)
210. On behalf of A−10 (Parvez Khan Pathan) and A−11 (Mohmed Faruq), it was contended that they
were not part of the conspiracy of killing Haren Pandya. A−10 (Parvez Khan Pathan) got the
knowledge of killing after a few hours. Their participation with the other accused will not amount to
conspiracy. They have been punished for a general conspiracy to take revenge for atrocities against
Muslims. They have been tried and punished not once but twice and spent over 8 years in custody.
They were accused in the case of Jagdish Tiwari (PW−39) also. The confession attributing ex post
facto knowledge of the murder of Haren Pandya is inadmissible in evidence. Their statements are
not admissible under Section 32 of POTA safeguards were not observed, which aspect we have
already discussed and negated.
211. On behalf of A−10 (Parvez Khan Pathan), it was submitted that he has no specific role in the
murder of Haren Pandya. He made a disclosure under Section 27 of Evidence Act which lead to the
recovery of some literature from his house and that he has disclosed that a motorbike was left by
him on Tarapur Highway after removing number plates and rendering the bike unfit by taking out
air on 4/5.4.2003. The Investigating Officer, CBI (PW−120) recovered number plate bearing
no.5189 from the bushes, though, he discovered no bike, he went into nearby Koth Police Station,
whereupon he learned that in May 2003, the Koth Police Station had found an abandoned bike on
the Tarapur Highway.
212. On behalf of the accused, it was submitted that the bike could not have been driven by Bhagwan
Singh Samantsinh Rathod (PW−50), PSI Koth Police Station stated that on 5.4.2003. It was further
submitted that tires were deflated and flung down. It could not have been brought to the police
station. The Koth Police Station had broadcast this news in May 2003 and that is how CBI came to
know about it. The statement of Bhagwan Singh Samantsinh Rathod (PW−
50) has also been adversely commented upon that looking at the front of the motorcycle there was
one white color number plate, but no number was written on it. On 3.5.2003, when the motorcycle
was seized, it was in standing position, hence he brought it to the police station and broadcast as to
the motorcycle in every police station as it was found unclaimed. The disclosure statement refers to
the number of the plate being removed and thrown away.
213. As per prosecution case, A−10 (Parvez Khan Pathan) is the real brother of A−14 (Sohail Khan
Pathan) and during the entire period of the conspiracy, he had the main role of providing lodging,
arms, ammunition, mobile phones, and SIM cards. In January 2003, A−14 (Sohail Khan Pathan)
disclosed to him that as per directions of A−13 (Mufti Sufiyan), one Mehman (A−1 Mohmed Asgar
Ali) is to be brought from Udaipur for taking revenge in Ahmedabad. A−14 (Sohail Khan Pathan)
along with A−11 (Mohmed Faruq) and Turk Salim Pasa Majarirule Islam (PW−49) went to UdaipurCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

in Tata Indica car and brought Mehman (A−1 Mohmed Asgar Ali) to Ahmedabad and was
introduced to him. He also went to Railway Station, Ahmedabad and brought A−3 (Mohmed
Shafiuddin) to Lokhandwali Chali. He and A−11 (Mohmed Faruq) had made arrangement for stay of
A−1 (Mohmed Asgar Ali) and A−3 (Mohmed Shafiuddin) at M.B. Complex and later on at Flat
No.401, Royal Apartment. He also made an advance payment of Rs.5,000/− for the flat to Abdul
Banki Abdul Bari Ansari (PW−44). This fact had been corroborated by Abdul Banki Abdul Bari
Ansari (PW−44 – hostile witness) in his deposition. He also purchased Suzuki Samurai motorcycle
bearing no. GJ−1SS−5934 from Abdul Samad Abbasali (PW−54) from the money provided by A−14
(Sohail Khan Pathan) in February 2003 for A−1 (Mohmed Asgar Ali), the shooter. This fact had been
corroborated by Abdul Samad Abbasali (PW−54) in his deposition. He acted as an intermediary
between A−1 (Mohmed Asgar Ali) and A−13 (Mufti Sufiyan). About 5−6 days before the attack on
Jagdish Tiwari, he was called by A−14 (Sohail Khan Pathan) at the shop of A−4 (Kalim Ahmed)
where A−14 (Sohail Khan Pathan) disclosed that as per the directions of A−13 (Mufti Sufiyan),
Jagdish Tiwari was their target. He pointed out Jagdish Tiwari (PW−39) and his shop to A− 1
(Mohmed Asgar Ali) on the directions of A−14 (Sohail Khan Pathan). On 7.3.2003, he collected two
weapons from A−1 (Mohmed Asgar Ali) and gave them to A−14 (Sohail Khan Pathan).
214. It is further the stand of prosecution that on 9.3.2003, A−1 (Mohmed Asgar Ali) and A−3
(Mohmed Shafiuddin) made an abortive attempt on Jagdish Tiwari (PW−39) where he along with
A−11 (Mohmed Faruq) waited for them at Afzal Cold Drink in order to exchange the motorcycles
with A−1 (Mohmed Asgar Ali) and A−3 (Mohd. Shafiuddin). After the attack on 11.3.2003 on
Jagdish Tiwari (PW−39), A−1 (Mohmed Asgar Ali) called him twice on his mobile. After attacking
Jagdish Tiwari (PW−39), they visited his house and changed clothes. He along with A−11 (Mohmed
Faruq) dropped them at Royal Apartments.
215. It is further the case of the prosecution against A−10 (Parvez Khan Pathan) that after 3−4 days
of the attack on Jagdish Tiwari (PW−
39), on the directions of A−14 (Sohail Khan Pathan), he dropped A−3 (Mohmed Shafiuddin) at ST
Bus Stand for going to Jaipur. On 1.4.2003, he was informed by A−14 (Sohail Khan Pathan) that Flat
No.401 at Royal Apartment has been vacated. On 3.4.2003, he went to Abdul Banki Abdul Bari
Ansari (PW−44) and collected a cheque for Rs.3,500/− out of the advance amount paid. Thereafter,
on the instructions of A−14 (Sohail Khan Pathan), he handed over Suzuki Samurai and Hero Honda
motorcycles to Javed Abdul Rashidkhan Pathan (PW−45) and asked him to keep them in some
parking place. This fact had been corroborated by Javed Abdul Rashidkhan Pathan (PW−45) in his
deposition (Exhibit 558). After 4.4.2003, he along with A−11 (Mohmed Faruq) fled from
Ahmedabad on Hero Honda motorcycle which they abandoned at Tarapore highway after removing
its number plate. Thereafter, he went to Bharuch and stayed in false names of Akhtar Ali and Usman
Ali. On 5.4.2003, he went to Surat and stayed in Bismillah Hotel in a false name and from Surat he
went to Hyderabad via Pune and stayed in Hotel Bluestar. The confession about his stay at Bharuch
and Hyderabad had been corroborated proved by Exhibits 757 and 527 i.e., the visitor registers of
both the Hotels. He met A−4 (Kalim Ahmed), A−5 (Anas Machiswala), A−12 (Shahnawaz Gandhi),
A−13 (Mufti Sufiyan) and A−14 (Sohail Khan Pathan) in Hyderabad. Upon seeing the news in a
newspaper on 26.4.2003 about the arrest of other accused persons, he along with A− 11 (MohmedCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

Faruq) decided to return to Ahmedabad. The allegations against A−10 (Parvez Khan Pathan) had
been proved by Harikishan Harpal Meena (PW−23) as panch witness. Rajendra Singh S. Chhikara
(PW−110) had called Harikishan Harpal Meena (PW−23) working in Central Excise and Customs
Department posted at Gandhinagar as Superintendent to be panch witness in pointing out memo
prepared at the instance of A−1 (Mohmed Asgar Ali). A−10 (Parvez Khan Pathan) has closely worked
in association with absconding brother A−14 (Sohail Khan Pathan). He has provided all the logistic
supports for executing the conspiracy and made arrangement for stay of those who came from
outside and provided for their transportation, motorcycles, arms, and ammunition.
216. There is evidence that he has provided all the logistic support from the beginning in executing
the conspiracy and had been supported by A−11 (Mohmed Faruq). On 23.4.2003, they went in TATA
Sumo jeep from CBI Office, Gandhinagar and A−1 (Mohmed Asgar Ali) led them to House No.206,
Block No.61, Old Bapunagar, Ahmedabad at Gujarat Housing Board flats where he stayed for three
days and from there to Flat No.902, A−3 Block near Dhobi ki Chawl, Rakhial where also stayed for
three days and then to House No.522, Block No.105, Bapunagar near Momin Masjid, which is a
house of A− 14 (Sohail Khan Pathan) and A−10 (Parvez Khan Pathan) and from there one Bajaj
Kawasaki Boxer Motorcycle bearing registration no.GJ1BG3849 had been seized along with its RC
book, for which memo Exhibit 270 was prepared and was signed by Harikishan Harpal Meena (PW−
23) as well as by A−1 (Mohmed Asgar Ali).
217. Abdul Banki Abdul Bari Ansari (PW−44) had corroborated that he had rented the flat at Royal
Apartment on a fixed rent of Rs.1,400/− and Rs.5,000/− had been deposited. In April 2003 it was
vacated and after deducting the amount of rent, he had refunded Rs.3,400/− to A− 10 (Parvez Khan
Pathan) through cheque issued favouring A−10 (Parvez Khan Pathan) drawn on Gujarat Industrial
Cooperative Bank from Saving Bank Account No.2244 and the same had been encashed by A−10
(Parvez Khan Pathan). This fact had been proved by Satyendra Sriramayan Pandey (PW−105), Sub−
Inspector, CBI who had seized the said cheque book and also obtained the bank details of aforesaid
account no.2244 from the Shantikumar Narmadashankar Pandya (PW−37), Branch Manager of
Gujarat Industrial Cooperative Bank, was also categorical about A−10 (Parvez Khan Pathan) having
withdrawn the amount giving the details of denomination of the currency notes given to him on
3.4.2003. The handwriting on the cheque was also proved to be that of A−10 (Parvez Khan Pathan).
Suzuki Samurai black coloured motorcycle bearing no.GJ−1−SS−5934 was found at the instance of
Javed Abdul Rasidkhan Pathan (PW−45). Abdul Samad Abbasali (PW−54), owner of Silver Auto
Consultant, dealing in sale and purchase of second−hand two−wheelers, on 28.1.2003 purchased
the aforementioned motorcycle from Sanjab Akhtar Maheboob Akhtar (PW−76) of India Auto
Consultant and signed the delivery notebook and he subsequently sold the same to A−10 (Parvez
Khan Pathan). An entry was accordingly made in the delivery notebook. The original owner of the
aforesaid motorcycle was Anil Mehta, who sold it to Sanjab Akhtar Maheboob Akhtar (PW−76).
After killing Haren Pandya, the aforesaid motorcycle was handed over to Javed Abdul Rashidkhan
Pathan (PW−45) by A−10 (Parvez Khan Pathan) on 3.4.2003 and this fact had been proved by Javed
Abdul Rashidkhan Pathan (PW−45). The aforesaid motorcycle was found from Magnet System Car
Parking, Kalupur Railway Station on 17.4.2003 in an abandoned condition.Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

218. Another motorcycle bearing fake registration no.GJ−1CD−8973 was found at Apsara−Aradhana
Theatre. The original registration number of this motorcycle was GJ−1CH−6692 and it was owned
by Rutul Ashok Shah and his father Ashokbhai Ambalal Shah (PW−36) had stated that this
motorcycle was stolen from New Cloth Market. On intimation by Kamlesh Bamanrao Marathe (PW−
40), Manager of Apsara−Aradhana Cinema, the aforesaid motorcycle was fetched by the officers of
Kagdapith Police Station. It is also apparent that Janakrai Ravishankar Pandya (PW−25) in
response to a letter of CBI had produced registration papers in respect of Hero Honda Splendor
bearing registration no.GJ−1CJ−6692 and Suzuki Samurai owned by Anil Mehta as well as Bajaj
Kawasaki Boxer having registration no.GJ− 1BG−3849 vide exhibits 278, 279 and 282. Another
Hero Honda motorcycle having registration no.GJ7Q2164 was found at Tarapur Highway which
originally belonged to Gaurang Kirit Gandhi and the fake number plate was got prepared from Star
Number Plate as GJ− 1CF−5189. The aforesaid motorcycle was found without any number near
Tarapur−Bagodara Highway at the instance of A−10 (Parvez Khan Pathan) in the presence of Sushil
Kumar S. Gupta (PW−120) and Arpesh Ranchhodbhai Rathod (PW−86). It was seized by Bhagwan
Singh Samantsinh Rathod (PW−50), In−charge, PSI, Koth Police Station. Thereafter, the six CDs
and written material were also discovered from the residential place of A−10 (Parvez Khan Pathan)
which depicted the plight of Muslims after the Godhra incident in Gujarat.
The aforesaid evidence clearly proves the role of A−10 (Parvez Khan Pathan) in the conspiracy to
murder Haren Pandya and he has been rightly convicted by the Trial Court under POTA and for
murder of Haren Pandya.
IN RE: A−11 (MOHMED FARUQ)
219. It is contended by Shri Shadan Farasat, learned counsel on behalf of A−11 (Mohmed Faruq)
that there is no evidence against A−11 (Mohmed Faruq) other than confession. It is alleged that he
has accompanied A−10 (Parvez Khan Pathan) when the bike was abandoned at Tarapur Highway.
There is no evidence to support it. The other allegation against him is that he accompanied a group
of people who drove A−1 (Mohmed Asgar Ali) to Ahmedabad from Udaipur in February 2003 and
that by itself is not an offence as it is the prosecution case that the plan to murder Haren Pandya was
hatched only on 18.5.2003. He has undergone the sentence for general conspiracy including the
conspiracy of the attack on Jagdish Tiwari (PW−39). It is contended that there is no evidence to link
him to the murder of Haren Pandya and hence, his acquittal must be upheld.
220. It is the case of prosecution and evidence discloses that A−11 (Mohmed Faruq) was a close
associate of A−14 (Sohail Khan Pathan) and a friend of A−10 (Parvez Khan Pathan). He was under
the influence of Mutfi Sufiyan and through him, he came in contact with A−14 (Sohail Khan Pathan).
On their instructions, A−11 (Mohmed Faruq) agreed to accompany A−14 (Sohail Khan Pathan) to
fetch A−1 (Mohmed Asgar Ali) from Udaipur. He was also accompanied by Turk Salim Pasa
Majarirule Islam (PW−49) and he drove the Tata Indica car. A−1 (Mohmed Asgar Ali) was brought
to Ahmedabad on 23.1.2003. On the very first day, A−1 (Mohmed Asgar Ali) stayed at the place of
A−11 (Mohmed Faruq) and thereafter, he made arrangement of his stay at M.B. Complex for being
in touch in Mohmed Jalis Ahmed Rajput (PW−Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

68) through Tawabhai Yusufbhai Shaikh (PW−66). Thereafter, they stayed at the Royal Apartment.
It is proved by Sajid Ibrahim Patel (PW−47) that SIM card no.9825677207 was sold from his shop
which was used while fleeing away to Hyderabad after killing Haren Pandya. Turk Salim Pasa
Majarirule Islam (PW−49) had also confirmed the same by naming A−11 (Mohmed Faruq). Sajid
Ibrahim Patel (PW−47) also corroborated that Turk Salim Pasa Majarirule Islam (PW−49) had
requested for SIM card, but later he agreed that by way of proof of residence with the application of
A−11 (Mohmed Faruq), he had sent the driving license, which was forwarded to the company. He
stated that sometimes company, in order to achieve the targets, request the dealers to activate the
SIM in the name of any his employees and it was done in name of Sarvarmiyan Anvarmiyan Saiyed,
however before 4.4.2003, not even a single call was made from the aforesaid SIM card and the same
was sold to A−11 (Mohmed Faruq). He further maintained that if the company requests for
activation of SIM card for achieving its target, the proof sent with the application suffice the need of
the company. Mubinuddin Pirsaabmiya Shaikh (PW−116), Manager, Bismillah Hotel has deposed
that two persons in the name of Akhtarali Sabirali and Fazalbhai Ganibhai had stayed at Surat in
fake names. As per the prosecution, they were A−10 (Parvez Khan Pathan) and A−11 (Mohmed
Faruq). After purchasing the SIM card, A−10 (Parvez Khan Pathan) and A−11 (Mohmed Faruq) left
the motorcycle at Tarapur Highway and fled away to Bharuch to Surat to Pune to Hyderabad. Their
stay at Hotel Bluestar at Hyderabad was also duly proved by the prosecution. A−11 (Mohmed Faruq)
has provided all sorts of logistic support in executing the conspiracy and he has played a very crucial
role in the conspiracy and prosecution has also proved his alleged involvement in the crime.
221. There is supporting evidence of Usman Khan Nawab Khan (PW−
29) (Exhibit 295), Turk Salim Pasa Majarirule Islam (PW−49) (Exhibit
365), Tawabhai Yusufbhai Shaikh (PW−66) (Exhibit 429) and Mohmed Jalis Ahmed Rajput (PW−
68) (Exhibit 431).
222. It was urged on behalf of accused persons that FIR of such incident registered belatedly is
doubtful. The submissions though attractive have no legs to stand. It is apparent that car was parked
at Chitty Bang near Law Garden and the glasses of the car of Haren Pandya were dark and rolled up
considerably and in the process of firing he fell down on the side seat. Obviously, in order to save
himself, he tried to lie down and bullets were fired at him constantly one after the other by A−1
(Mohmed Asgar Ali). In the process, his legs came up. As the glasses were dark, obviously it was not
possible for others to take note of the fact that Haren Pandya was lying killed in the vehicle. The eye
witness − Anil Yadram Patel (PW−55) has gone to inform the owner of Chitty Bang and by the time
he could come back, police had arrived at the spot and were taking Haren Pandya to Hospital. This
explains the so−called delay and explains the situation of the spot and due to dark glasses, it may
not have been possible for the passer−by immediately to take note of the fact that as to what had
happened inside the car, which was parked on the side of Chitty Bang. Thus, the submission on
behalf of accused persons cannot be accepted and the evidence discloses that family members of
Haren Pandya, his P.A., and other political leaders had also arrived in the meantime at the spot on
coming to know of the incident.Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

223. In view of overall evidence available against the accused he was rightly held guilty by Trial
Court for offence under section 3(1) and section 3(3) of POTA as well as under section 120B and
section 120B read with section 302 IPC for murder of Haren Pandya. The conviction and sentence
imposed by Trial Court is restored.
IN RE: ACCUSED NO.2 (MOHMED ABDUL RAOUF)
224. Mohmed Abdul Raouf, son of Mohmed Abdul Kadar was held guilty by the Trial Court for the
offence punishable under Section 3(3) of POTA and was given benefit of doubt of all the other
offences under the POTA as well as under the IPC. There is no appeal preferred against his acquittal
by the State/CBI in the High Court. Now, the question remains that of the sentence to be imposed
under Section 3(3) of POTA. The Trial Court has convicted A−2 (Mohmed Raouf) under Section 3(3)
of POTA and sentenced him to 7 years rigorous imprisonment and the High Court has also
confirmed and maintained the conviction as well as the amount of fine i.e., Rs.10,000/−. The
sentence of rigorous imprisonment has been modified to the period already undergone in jail i.e., 5
years. Against the decision of the High Court, the CBI is in appeal. The minimum sentence is 5 years
under Section 3(3) of POTA and by now 8 years have passed and the accused has already undergone
little more than 5 years. No case for further interference is called for as CBI did not prefer an appeal
against the judgment and order of the Trial Court. The decision of the High Court as to conviction
and sentence under POTA is affirmed. IN RE: A−3 (MOHMED SHAFIUDDIN)
225. With respect to A−3 (Mohmed Shafiudding), the Trial Court has recorded conviction under
Section 120B read with Section 307 of IPC and has sentenced him to undergo 7 years rigorous
imprisonment with fine of Rs.3,000. He was also given benefit of doubt for all the other offences he
had been charged with under the POTA as well as under the IPC. The High Court has also
maintained and upheld conviction and sentence awarded to him by the Trial Court. As no appeal
was preferred by CBI against the decision of the Trial Court against A−3 (Mohmed Shafiuddin), no
case for further interference is made out.
IN RE: A−12 (SHAHNAVAZ GANDHI)
226. With respect to A−12 (Shahnavaz Gandhi), he was convicted only under Section 3(3) of POTA
and was sentenced by the Trial Court to undergo 5 years rigorous imprisonment. The High Court
has confirmed and maintained the conviction and sentence awarded under Section 3(3) of POTA.
227. No appeal was preferred by CBI against the acquittal A−2 (Mohmed Abdul Raouf), A−3
(Mohmed Shafiuddin) and A−12 (Shahnavaz Gandhi) and since they have completed the sentence
fully awarded to them by the Trial Court as modified by the High Court in the case of A−2 (Mohmed
Abdul Raouf), no further interference is required to be made as against them in the judgment of
conviction and sentence imposed and it need not be discussed elaborately as no appeal was
preferred against the decision of the Trial Court by CBI. IN RE: CRIMINAL APPEAL NO……./2019
@ SPECIAL LEAVE PETITION (CRL.) NO.5530 OF 2017 AND CRIMINAL APPEAL NO……./2019
@SPECIAL LEAVE PETITION (CRL.) NOS.9028−9029 OF 2016Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

228. Leave granted.
229. As accused absconded, separate trial was held with respect to Mohd. Junaid Sheikh.
230. In addition to the aforesaid charges for the murder of Haren Pandya and attempt to kill
Jagdish Tiwari under POTA the accused – Mohd. Junaid Sheikh was also prosecuted under Section
174 A of Indian Penal Code (for short, “the IPC”) as he had absconded. A separate trial was held
wherein he had been acquitted by the trial court for commission of the offence with respect to the
attempt of murder of Jagdish Tiwari and murder of Haren Pandya but has been convicted for
commission of the offence under section 174A of the IPC. The trial court has convicted the accused
for the said offence under section 174A IPC in Case No.10 of 2003 vide separate judgment and order
dated 28.02.2008.
231. On appeal filed by the accused, the High Court acquitted the accused and modified the sentence
by imposing fine of Rs. 21 lakhs and in breach of default of payment of fine the sentence imposed by
the trial court shall stand. The amount of fine has been deposited. On being aggrieved, the CBI has
filed the appeals.
232. Though, in the instant case, the trial court has found that attempt on the life of Jagdish Tiwari
and the murder of Haren Pandya has been committed in the method and manner as per prosecution
case. However, with regard to present accused M.J. Sheikh, it has been held that the prosecution has
not been able to prove his guilt beyond the periphery of doubt.
233. As per prosecution case, he is stated to have stayed in Mumbai in the place of Mufti Sufian, the
trial court has found that though his visit to Mumbai with Mufti Sufian stands proved, any
conspiracy was formed at Mumbai had not been established. His statement under section 164 (1)
Cr.P.C. initially was recorded as a witness that has not been taken into consideration. The polygraph
test conducted on the accused was not as per the laid down safeguards to be observed by the
National Human Rights Commission and was without any permission of the court. Even the
statement had been held to be not good enough to fasten the guilt to enter into the conspiracy for
either an attempt of murder of Mr. Jagdish Tiwari or killing of Haren Pandya. He was not with the
main accused – Mohmed Asgar Ali on the date of the incident and while he was running from place
to place after committing murder of Haren Pandya, he is said to have stayed for three days in the
accommodation which was taken from the accused M.J. Sheikh at the instance of the Mufti Sufian.
No role has been shown of the accused in the conspiracy leading to the attempt of murder of Mr.
Jagdish Tiwari and killing of Haren Pandya. Maybe subsequent stay at the house that too when the
house has been obtained by Mufti Sufian and since the accused M.J. Sheikh was close to Mufti
Sufian he has taken his car to bring the A−1 to the accommodation cannot make him conspirator in
the murder of Haren Pandya since it was a subsequent event. The phone calls made to Mufti Sufian
by the accused are not significant since the witness was known to Mufti Sufian and he handed him
Rs.15,000 to Rs.20,000 for visit to Haj which amount was paid back, as such it has been inferred by
the trial court that the same is not the case for funding for creating terror. Apart from that, after
tiffin bomb accident the conspiracy was hatched to kill Jagdish Tiwari and Haren Pandya to which
the accused was not a part. The High Court had not disturbed the aforesaid finding.Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

234. We have gone through the judgment of the trial court and the evidence on record adduced in
this case. We are satisfied that the benefit of the doubt has been rightly extended by the Trial Court.
In the peculiar facts and circumstances of the case, as the petitioner has already served the sentence
of 17 months and has also paid the fine of Rs.21 lakhs, thus, no case for interference is made out vis−
à−vis to him. The appeals are accordingly, disposed of.
WRIT PETITION (CRL.) NO.26 OF 2019
235. The petition has been filed by the Centre for Public Interest Litigation to direct further
investigation into the murder of Shri Haren Pandya which took place on 26.3.2013. Other ancillary
reliefs have also been sought.
236. The writ petition had been filed on 21.1.2019 on the ground that the High Court has acquitted
the accused persons and has doubted the correctness of investigation while passing the judgment
dated 29.8.2011. It was submitted that earlier a criminal miscellaneous application No.15506/2007
was filed by father of the deceased, Vithalbhai Pandya v. CBI and two others for further investigation
in the case. However, the petition was dismissed by the High Court of Gujarat on 16.6.2008.
Thereafter, wife of deceased Haren Pandya filed a petition, being Special Crl. Application
No.2327/2011, in the High Court of Gujarat at Ahmedabad, which was dismissed. Vide judgment
and order dated 6.2.2012 passed by the High Court of Gujarat at Ahmedabad on the ground that
petition filed by Mr. Vithalbhai D. Pandya, father of the deceased, had been dismissed and due to
the pendency of the criminal appeals in this Court, the High Court observed that it would not be
proper to reappreciate and re−evaluate the material on record. Judicial propriety and discipline oust
the court from entering into the merits of the case. Since this Court was in seisin of the subject−
matter to settle the issue authoritatively under plenary jurisdiction under Chapter IV of the
Constitution of India.
237. The present writ petition has been filed when criminal appeals filed in this Court were already
being heard for the last two months. It was not mentioned that criminal appeals were already being
heard w.e.f. 1.11.2018 by this Court in which hearing was concluded on 31.1.2019. The present writ
petition was listed before a Bench consisting of Hon. Sikri and Abdul Nazeer, JJ. on 8.2.2019. The
Bench directed the listing of the case before the same Bench which had heard the criminal appeals
on merits, after obtaining orders from Hon. the Chief Justice of India. Thereafter, this matter had
been listed before this Court and has been heard and is being decided with the criminal appeal.
238. The writ petition has been filed on the ground that the High Court has held that investigation
done is botched up and misdirected. Statement of Mohd. Azam Khan had been recorded on
3.11.2018 in a criminal trial who was produced as a prosecution witness in the trial of fake encounter
of Sohrabuddin Sheikh, his wife Kausarbi and his associate Tulsiram Prajapati. In the case, accused
persons were acquitted. Azam Khan has stated that Sohrabudin had told him that the contract to kill
Haren Pandya had been given to him by IPS Officer G.D. Vanzara and that Sohrabuddin’s associate
Tulsiram Prajapati along with one Naeem Khan and Shahid Rampuri murdered Haren Pandya.
Azam Khan’s statement has been placed on record as Annexure P−1 on the basis whereof a news
report had been carried out by the Indian Express on 5.11.2018 filed as Annexure P−2. Ajam KhanCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

has revealed that he had given the information to the CBI in 2010. The CBI did not pay any heed to
this information.
239. It is submitted that a book called ‘Gujarat Files – Anatomy of a cover−up" was published by a
journalist Ms. Rana Ayyub wherein she had given certain details of operation conducted by her on
the investigating officer from Gujarat Police, Y.A. Shaikh who had started the investigation in the
case of murder of Haren Pandya before the same was handed over to the CBI, the shooter accused
Mohmed Asgar Ali was already in the police custody and the site map dated 29.3.2003 had the name
of Asghar Ali, main article published on the website on 7.11.2018, has also been relied upon. D.G.
Vanzara’s statement was published in the Times of India who told the CBI that Sohrabuddin was
involved in Haren Pandya’s murder. The news was published in Times of India dated 21.9.2013. A
photo sketch which was drawn did not match with the appearance of Mohmed Asghar Ali, A−1 but
with Tulsiram Prajapati. The newspaper report dated 5.11.2007 published in countercurrents.org
regarding Mr. Vithalbhai Pandya and Ms. Jagrutiben Pandya’s allegations has been filed as
Annexure P−8. Mr. Pandya had given an interview published in the Outlook dated 7.11.2007 saying
that he was likely to be murdered.
240. The prosecution case has been doubted by the petitioners on the various counts which have
been raised in the criminal appeals. Such as he was rolling up the glass of the window of his car,
there were 5 bullets found with 7 injuries. PW−55 is not a reliable witness. Family of Mufti Sufiyan
was permitted to move to Pakistan despite being under the surveillance of the Gujarat Police and
relocated there. The High Court has made observations that ballistic evidence does not support the
ocular version. There was a difference in the bullets recovered and examined. The direction of the
wound has also been adversely commented upon so as to cast doubt on ocular version. The offence
has not taken place in the car. Confessions of the accused were not reliable. The investigation was
tainted. Thus, prayer has been made to direct further investigation in the matter. Reliance has been
placed on Vinay Tyagi v. Irshad Ali (2013) 5 SCC 762 in which this Court observed that a fair and
proper investigation has two imperatives, the investigation must be unbiased, honest, and just
which is in accordance with law and secondly, the entire emphasis has to be to bring out the truth of
the case before the competent jurisdiction. In Manohar Lal Sharma v. Principal Secretary & Ors.,
(2014) 2 SCC 532, the Court observed that the aim of the investigation is ultimately to search for the
truth and bring the offender to book. The CBI has not acted as per the provisions contained in the
Manual at para 6.11.5, Chapter VI. The CBI is required to take into consideration as per para 8.22 of
Chapter VIII of the Manual the press reports regarding allegations relating to the significant matter
in the media. In spite of acquittal by the High Court, the CBI has not taken the steps as envisaged in
para 23.20 of CBI Manual. It is likely that G.D. Vanzara was involved in the conspiracy to kill Haren
Pandya and there is the possibility of the complicity of political figures. Azam Khan’s testimony
reveals that he had provided information 8 years before to the CBI. The CBI has not acted upon it.
Haren Pandya’s father and wife were not having the benefit of the information available now. The
conduct of the investigating agency in the instant case forms a fit ground for ordering a re−
investigation as observed in Zahira Habibullah Sheikh & Anr. v. State of Gujarat & Ors. (2004) 4
SCCCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

158. If deficiency in the investigation or the prosecution is visible or can be perceived by lifting the
veil trying to hide the realities of covering the obvious deficiencies, courts have to deal with the same
with an iron hand appropriately within the framework of the law. In Pooja Pal v. Union of India
(2016) 3 SCC 135, this Court has again relied upon the observations made in Zahira Habibullah
Sheikh (supra).
241. Mr. Shanti Bhushan, learned senior counsel and Mr. Prashant Bhushan, learned counsel have
urged that in view of the aforesaid facts and circumstances and the statement of Azam Khan and
other materials placed on record, it is a fit case where the further investigation should be ordered.
They have relied upon the statement of the father of deceased and the wife of the deceased Haren
Pandya. As is reflected in the newspaper reports, the orders passed in their cases have also been
placed on record.
242. Mr. Tushar Mehta, Solicitor General has submitted that the petition filed by the father of the
deceased seeking investigation had been dismissed by the Gujarat High Court way back in 2008, the
special leave petition against the same was also dismissed. Thereafter wife of deceased also filed a
petition in the year 2012 in the Gujarat High Court which was also dismissed inter alia on the
aforesaid grounds that judicial propriety and discipline oust the High Court from entering into
merits as this Court has to reassess the evidence and the findings recorded by the Gujarat High
Court in the criminal appeals. Which have been heard finally by this Court and hearing concluded
on 31.1.2019. The petition is not maintainable and has been filed with an oblique motive. The
statement of Azam Khan is an afterthought and did not relate to the matter in question in the case in
which he has deposed. The Forum of PIL is being misused. It cannot be based on newspaper reports
or reports in the magazines. For this purpose, he has relied upon Kusum Lata v. Union of India,
(2006) 6 SCC 180, Rohit Pandey v. Union of India (2005) 13 SCC 702; and Holicow Pictures
(Private) Ltd. v. Prem Chandra Mishra, 2007 (14) SCC 281.
243. Mr. Mehta, with respect to the evidentiary value of the report, has further submitted that the
facts contained in the newspaper reports are merely hearsay and therefore not admissible in
evidence. He has relied upon Laxmi Raj Shetty v. State of Tamil Nadu (1988) 3 SCC 319. He has
further relied upon Rajiv Ranjan Singh ‘Lalan’ (VIII) v. Union of India (2006) 6 SCC 613 to contend
that such PILs. would hamper the course of justice in a criminal case and are not maintainable. A
PIL cannot be filed for personal gains or private profit or political motives or any oblique
consideration. A person must act bona fide and should have sufficient interest in the proceeding
alone has locus standi to file a PIL. Unnecessary interference given in a case may sometime damage
the prosecution case and at times may cause prejudice to the accused also. Reliance has been placed
on Gulzar Ahmed Azmi v. Union of India (2012) 10 SCC 731, and Ashok Kumar Pandey v. State of
West Bengal, (2004) 3 SCC 349. Mr. Mehta has also relied upon a recent decision of this Court in
Tehseen Poonawasla v. Union of India, (2018) 6 SCC 72, to submit that the instant case is nothing
but misuse of PIL by the petitioners.
244. As the writ petition has been filed on 22.1.2014 when this Court was finally hearing the
criminal appeals with effect from December 2018 and most of documents and grounds taken are
similar as such, during the course of hearing we asked Mr. Prashant Bhushan, learned counselCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

appearing on behalf of the petitioner that when criminal appeals were being heard by this Court at
that time on the basis of almost the same grounds why PIL has been filed. In case it was felt
necessary that further investigation is required, why an application was not filed seeking further
investigation or re−investigation in the matter by the concerned persons or by CPIL and how the
very same documents have been obtained and filed in the petition which forms part of the criminal
appeal. Mr. Prashant Bhushan admitted that certain documents have been supplied by learned
counsel who is appearing on behalf of the accused persons/ respondents in criminal appeals. He had
consultations with said counsel to file the petition. It was considered appropriate to file a separate
petition.
245. We are not happy the way in which the writ petition has been filed. It has been filed acting
obviously in conjunction with the accused persons in the case as the counsel for accused has
admittedly supplied the documents to the petitioner and had consultations. It was also pointed out
by Mr. Tushar Mehta that presence of the counsel appearing on behalf of CPIL and one of them
appearing for the accused, has also been recorded in the writ petition in the order dated 8.2.2019. A
perusal of the order dated 8.2.2019 indicates that the presence of the counsel for an accused in
criminal appeals has been recorded on behalf of the petitioner CPIL along with Mr. Prashant
Bhushan and Mr. Rohit K Singh, advocates. Mr. Prashant Bhushan tried to explain the aforesaid
position on the ground that his clerk has wrongly given the appearance of said learned counsel who
is appearing on behalf of an accused person in criminal appeals. However, as admitted by Mr.
Prashant Bhushan, the said counsel was associated with him in furnishing the information,
documents, etc. Be that as it may. The fact is apparent that accused persons were instrumental in
getting filed this writ petition for further investigation in the case. If the accused so wanted then
they ought to have approached this Court by way of filing an appropriate application in the criminal
appeals only and not by way of filing a PIL, that too through the CPIL. It cannot be said to be an
appropriate way of filing a writ petition for further investigation, the motive is oblique, improper
and against discipline, especially when the criminal appeals were being heard finally and this Court
was in seisin of the matter and judgment has been reserved ultimately on 31.1.2019. At the relevant
time when the petition was filed, obviously the petitioner CPIL was well aware of the hearing of
criminal appeals and that fact has not been stated in the writ petition that criminal appeals were
being heard on merits for the last several months w.e.f. 1.11.2018. It is shocking and surprising that
the accused have resorted to the aforesaid method of getting filed the petition in guise of the PIL by
supplying the documents to CPIL in their self−interest and virtually attacking the case of the
prosecution on the same grounds and whatever new material has been filed, we will discuss the
value of the same hereafter.
246. Statement of Mohd. Azam Khan who was examined as a witness in Sessions Case No.177/2013
etc. has been relied on, it was stated by him that Sohrabuddin told him that Shahid Rampuri, Naeem
Khan and he got a contract to kill Haren Pandya and they had killed him. He felt sad and told
Sohrabuddin that they have killed a good person. Thereafter Sohrabuddin told him that this
contract of killing was given by Mr. Vanzara. In our opinion, the aforesaid statement made by Azam
Khan was totally out of the context of a criminal case in which he had deposed. It was clearly an
attempt as an afterthought to make the statement as to some other matter irrelevant to controversy.
In the cross−examination of the witness in para 3, he has made the following statement:Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

“3. The CBI officer recorded my statement twice in the year 2010. I told before the
CBI officer the entire story of my leaving Udaipur for Pratapgarh and from there to
come back to Udaipur and then to visit Hyderabad to meet Shahid Rampuri in jail
and Naeem Khan at Hyderabad and to assured Naeem Khan to supply AK 56
weapons to him and then come to Indore and again Udaipur and to stay with
Sohrabuddin at Udaipur as said by me in my examination in chief. The reason for the
omission of this story by CBI might be when I told before them the story of the killing
of the Home Minister Hariyan Pandya. I told before the CBI officer about my
discussion with Sohrabuddin at his house at Udaipur and the killing of the Home
Minister Shri Hariyan Pandya by Tulsiram and one boy at the instance of
Sohrabuddin and killing of Hamid Lala by Tulsiram and Mudassar at the instance of
Sohrabuddin. There is no reason for this omission in my statement recorded by CBI. I
told before the CBI officer that in order to recover the money of Rajasthan Tools
Company Jodhpur from Mariam Marble, I was falsely booked in an extortion case.
There is no reason for the above omission in my statement before CBI……."
(emphasis supplied)
247. Azam Khan has stated that CBI recorded his statement twice in the year 2010, but he was
unable to give any reason for omission in his statement recorded by the CBI. Even otherwise the
statement made after more than 15 years is wholly unreliable and an afterthought and was not
connected with the matter in question in which it was made. Thus, it appears to be clearly a
motivated one and bundle of falsehood as he could not give any reason for omission in the previous
statement in which also this issue was not involved.
248. A book by Ms. Rana Ayyub has also been relied upon in which it has been observed that Haren
Pandya’s case is like a volcano. “Once the truth is out, (xxx) will go home. He will be jailed.” The
counsel has further relied upon an article in the Outlook based upon the statement of Mr. Vithal
Pandya, father of Haren Pandya. It appears from that he entertained a doubt as to the actual killer,
but with no material against anybody. The Book by Rana Ayyub is of no utility. It is based upon
surmises, conjectures, and suppositions and has no evidentiary value. The opinion of a person is not
in the realm of the evidence. There is a likelihood of the same being politically motivated, cannot be
ruled out. The way in which the things have moved in Gujarat post− Godhra incident, such
allegations and counter−allegations are not uncommon and had been raised a number of times and
have been found to be untenable and afterthought.
249. Coming to the allegations made by the family of the deceased, by father of Haren Pandya, Mr.
Vithal Pandya and Ms. Jagruti Ben, wife of the deceased, the matter has been dealt with on merits
by Gujarat High Court in the petition which was filed on behalf of Mr. Vithal Bhai Pandya. A
Division Bench of the High Court of Gujarat has considered the matter in extensive details. It was
urged that Ms. Jagrutiben Pandya, wife of deceased Haren Pandya was cited as a witness in the
charge sheet. On 16.11.2006, the prosecution submitted closing pursis and pursis for dropping of the
witnesses including Jagrutiben Pandya. It was taken note of the fact that the applicant did not
challenge the order passed declining further investigation. A similar application was submitted onCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

18.12.2006 on the basis of newspaper reports which was also dismissed on 25.6.2007 by the POTA
Judge. A copy of the order was also supplied to the applicant, wife of the deceased. Thereafter,
father of deceased has filed a petition in the High Court assailing the order which was decided vide
judgment and order dated 20.6.2008. A Division Bench of the High Court of Gujarat has observed
thus:
“24. At the outset, it is required to be noted that in the respective appeals, the
applicant who is neither a witness nor a complainant, has challenged three different
orders namely [1] order dtd.18/12/2006 passed below application Ex.855 [2] order
dtd.26/3/2007 passed below application Ex.898 [3] final judgement and order of
conviction dtd.25/6/2007 passed by the learned Special Court in Special Case
[POTA] No.10 of 2003. Vide order dtd.18/12/2006 passed below application Ex.855
and order dtd.26/3/2007 passed below application Ex.898, the learned Special Court
[POTA] has dismissed the said applications submitted by the applicant for
reinvestigation/further investigation of the case related to the murder of the son of
the applicant namely Mr. Haren Pandya. It is also required to be noted at this stage
that at the time when the first application Ex.855 was submitted by the applicant for
further investigation/reinvestigation, the same was after 122 prosecution witnesses
and 7 defence witnesses were already examined by the Special Court [POTA] and
further statements of the accused running into 202 pages had already been recorded
and the trial was at the fag end. Even when the application Ex.898 came to be
dismissed by the learned Special Court [POTA] on 26/3/2007 it was specifically
observed by the learned trial court that the applicant be supplied copy of the said
order urgently to enable him to approach the higher forum if he so chooses, as there
is still some time before the Court shall deliver the judgment after completing the
submissions of both the sides on 28/3/2007 and 4/4/2007. It is borne out from the
record that the order passed below application Ex.855 dtd.18/12/2006 was sent to
the applicant on 22/12/2006 and the copy of the order passed blow application
Ex.898 dtd.26/3/2007 was received by the applicant on the very day i.e. on
26/3/2007. In the order dtd.26/3/2007, it was specifically observed by the learned
Special Jude that the applicant shall also be provided legal aid service to approach
the Hon'ble High Court if he so desires. Still, the applicant did not challenge the
aforesaid two orders immediately. It appears that the submissions/arguments of both
the sides were heard on 28/3/2007 and 4/4/2007. Thereafter, final judgment and
order of conviction convicting the accused persons is passed by the learned Special
Court [POTA] on 25/6/2007 and all the aforesaid orders came to be challenged by
the applicant in the month of November 2007. Thus, it appears that the applicant has
either not taken the matter very seriously in challenging the aforesaid orders passed
below application Ex.855 and 898 immediately and/or within a reasonable time and
allowed the trial to be proceeded and concluded. It is also required to be noted at this
stage that the applicant has specifically averred in the Appeal Memo challenging the
final judgment and order dtd.25/6/2007 that he is not challenging the final judgment
and order of conviction dtd.25/6/2007 convicting the accused persons. If that is so,
in that case, as such, the appeal against the final judgment and order dtd.25/6/2007Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

under Section 34 of the POTA would not be maintainable, an order of conviction is
not challenged.
26. In support of his prayer for further investigation and/or reinvestigation of the
murder of Mr. Haren Pandya it is alleged that the same was a political murder. It is
submitted by the applicant that the applicant was not cited as a witness in the charge
sheet and that the Jagrutiben widow of deceased Haren Pandya though was cited as a
witness, but was dropped. As stated above, the charge sheet was filed on 8/9/2003
and the applicant was not cited as a witness. Still, the applicant did not do anything.
Closing pursis and the pursis for dropping of the witness was submitted by the
learned Special Public Prosecutor on 16/11/2006 and the certified copy of the said
pursis was applied by the applicant on 16/4/2007 which was actually delivered to the
applicant on 25/4/2007. Still, the applicant did not challenge the orders passed
below applications Ex.855 and 898 and allowed the trial to be concluded. It also
appears that even the averments made in the applications explaining the delay are
too vague and/or general in nature. Even the applicant has not stated correct facts
with respect to the receipt of copies of the orders passed below applications Ex.855
and 898 and the certified copy of the closing pursis for dropping of the witnesses.
27. Still construing the ‘sufficient cause’ liberally, so as to advance substantial justice
and with a view to see that the meritorious case is not defeated on the technical
ground of delay, we have considered prima facie case on merits also.
The learned senior advocate appearing on behalf of the applicant as well as learned Special Public
Prosecutor appearing on behalf of the CBI have addressed the court on merits also and we have
heard the learned advocates appearing on behalf of the respective parties on merits at length to
appreciate the prima facie case on merits with a view to advance substantial justice and to see that
the meritorious case is not defeated on the technical ground of delay.
29. It is further submitted that Jagrutiben widow of Haren Pandya was already cited as a witness in
the charge sheet, still, she was not examined as a witness and she was dropped as a witness. It is
submitted that if she would have been examined as a witness, the truth might have come out. It is
submitted that even Jagrutiben in her interview published in ‘Tahelka’ on 19/8/2006 apprehended
that she would not be examined as a witness and it has come true.”
250. The High Court has further observed that non−examination of Jagrutiben is no ground for
further investigation. The High Court has also observed that in the interview published in ‘Tehelka’
on 19.8.2006, it is clearly admitted by Ms. Jagrutiben that she has no proof/material with respect to
political rivalry. Only on allegation of political rivalry, further investigation or re−investigation
cannot be ordered. The I.O. has stated that during the investigation he did not get any material with
respect to political rivalry on the basis of the vague statement of Mr. Vithalbhai Pandya, father of
deceased, further investigation was not possible to be ordered against political figures. The applicant
has no material to substantiate the material of political rivalry. In the absence of material, there
cannot be an order for further investigation or re−investigation. On merit, the applicant has failed toCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

make out a case for further investigation or re−investigation.
251. Coming back to Jagrutiben, she was not an eye−witness, admittedly, and has no personal
knowledge and it is apparent from the report she has stated that the deceased left the house for a
morning walk at around 0645 hours/0700 hours. Thus, the doubt raised in the newspaper report
was that it would not have taken half an hour to reach the Law Garden. It would have taken 10
minutes to reach Law Garden. The submission of dropping of Jagrutiben is too tenuous to be
accepted. She has not unfolded any story regarding the real assailants to be someone else and in
case she would have been examined, her statement would have supported the case of the
prosecution that deceased had left the house in the morning only for a walk. The assessment of the
time may differ by 15 to 20 minutes also or even half an hour. On the basis of approximation of the
time by Jagrutiben in the newspaper reports and on the basis whereof the happening at Law Garden
at 7.30 a.m. cannot be doubted at all. Deceased Haren Pandya had as per her version left for Law
Garden. She was not an eye−witness to be examined in the case. Thus, it cannot be said that the
prosecution has withheld her and she would have unfolded any part story which was material to the
case.
252. The SLP against the aforesaid decision in the case of Vithal Bhai of the Gujarat High Court has
been dismissed by this Court on 15.7.2009. This Court condoned the delay and dismissed the SLP.
Thus, the order passed by the High Court that no investigation was warranted, has attained finality.
253. Thereafter, yet another attempt had been made by the wife of the deceased though she was not
entitled to file any petition after it was filed by the father of the deceased in view of prayer made
before the Trial Court as father had questioned the orders passed on applications filed by her before
Trial Court. Nonetheless, she filed Special Crl. Application No.2327/2011 which was decided vide
order dated 6.2.2012. The High Court of Gujarat has dismissed the petition filed by the wife and
observed:
“4. Mr. J.M. Panchal, learned Special Public Prosecutor appearing for the State of
Gujarat has, relying upon the affidavit dated 4.2.2012 filed on behalf of the State of
Gujarat, virtually reiterated, apart from reappreciation of evidence, the factum about
pendency of SLPs arising out of the judgment and order dated 29.8.2011 rendered by
this Hon’ble Court in Crl. Appeal No.975 of 2007 and allied appeals. It is further
submitted that similar petition and prayer made earlier by the father−in−law of the
petitioner for further investigation/re−investigation below Exh.855 and Exh.898 in
Special Case [POTA] No.10 of 2003 came to be rejected by the Designated Trial Court
and further Criminal Appeal Nos.17 of 2008, 18 of 2008 and 1324 of 2007 preferred
along with delay condonation application before this Court also came to be rejected
by a Division Bench after condoning the delay as per C.A.V. Judgment dated
16.6.2008 and, therefore, in such a scenario, when the subject matter is pending
before the Apex Court in Petition(s) for Special Leave to Appeal (Crl) No(s) 9785−
9796/2011 and Petition(s) for Special Leave to Appeal (Crl) No(s) 9797−9808/2011,
in all propriety and judicial discipline, it is desirable that this Court may not exercise
extraordinary power under Article 226 of the Constitution of India read with SectionCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

482 of the Code of Criminal Procedure, 1973.
5. Admittedly, the above factual aspects remain uncontroverted as submitted by the
State Counsel.
6. Prima−facie, the subject matter, and prayer of this petition are emanating from the
proceedings pending before the Apex Court in Petition(s) for Special Leave to Appeal
(Crl) No(s) 9785−9796/2011 [filed by the State of Gujarat] and Petition(s) for Special
Leave to Appeal (Crl) No(s) 9797− 9708/2011 [filed by the CBI]. Under the
circumstances, at this stage, entertaining this petition for seeking a direction to re−
investigate/for further investigation of the offences would be in the arena of re−
appreciating and re−evaluating the evidence and material on record and, therefore,
the propriety and judicial discipline dissuades this Court from entering into the
merits of the case in exercise of powers under Article 226 of the Constitution of India
as well as under Section 482 of the Code of Criminal Procedure, 1973, since the Apex
Court is in seisin of the subject matter to settle the issue authoritatively in its plenary
jurisdiction under Chapter IV of the Constitution of India.” (emphasis supplied)
254. Thus, it is apparent that the matter has attained finality. Again, in criminal
appeals, we have examined the case on merits as the case relates to Haren Pandya,
former Home Minister of Gujarat. In our opinion on merits in view of the material
that has been placed on record including that of Azam Khan’s statement and Book by
Rana Ayyub, no case is made out on the basis of material placed on record so as to
direct further investigation or re−investigation. There is absolutely no material for
that purpose. The matter has already attained finality due to the dismissal of SLP.
Even otherwise the petition has been based upon reports in the
newspapers/magazines. It has been observed by this Court in Kusum Lata v. Union of
India, (2006) 6 SCC 180 that newspaper reports do not constitute evidence.
This Court also observed that the writ petition should be dismissed with costs so that the message
goes in the right direction that a petition filed by the oblique motive does not have the approval of
courts.
255. As we are deciding the criminal appeals along with the order, we have dealt with veracity of
prosecution case and fairness of investigation in our opinion the observations made by the High
Court were not only uncalled for but based on incorrect appreciation of medical/forensic evidence
and ignoring material evidence on record.
256. In Rohit Pandey v. Union of India, (2005) 13 SCC 702, the writ petition was filed on the basis of
newspaper reports by a young lawyer. The petition was filed on 12.2.2004. This Court observed that
ordinarily we would have dismissed such a misconceived petition with exemplary costs but
considering that the petitioner is a young advocate, costs of Rs.1,000 was imposed.Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

257. In Holicow Pictures (Pvt.) Ltd. v. Prem Chandra Mishra, (2007) 14 SCC 281, it was noticed that
the petitions are based on newspaper reports without any attempt to verify their authenticity.
258. In Laxmi Raj Shetty v. State of Tamil Nadu, (1988) 3 SCC 319, this Court has observed that it is
well settled that a statement of fact contained in a newspaper is merely hearsay and therefore
inadmissible in evidence in absence of the maker of the statement appearing in court and deposing
to have perceived the fact reported.
259. In Rajiv Ranjan Singh ‘Lalan’ (viii) v. Union of India, (2006) 6 SCC 613, this Court has
observed that public interest litigation cannot be filed for personal gain or political motive or any
oblique consideration. Unnecessary reference in the criminal case made against the prosecution case
at times may cause serious prejudice to the accused also.
260. In Gulzar Ahmed Azmi v. Union of India, (2012) 10 SCC 731, it was observed that it is for the
affected party to seek redress.
261. Reliance has also been placed on Simranjit Singh Mann v. Union of India & Anr., (1992) 4 SCC
653 in which this Court observed:
“7. Ordinarily, the aggrieved party which is affected by any order has the right to seek
redress by questioning the legality, validity or correctness of the order, unless such
party is a minor, an insane person or is suffering from any other disability which the
law recognises as sufficient to permit another person, e.g. next friend, to move the
Court on his behalf. If a guardian or a next friend initiates proceedings for and on
behalf of such a disabled aggrieved party, it is in effect proceedings initiated by the
party aggrieved and not by a total stranger who has no direct personal stake in the
outcome thereof. In the present case no fundamental right of the petitioner before us
is violated; if at all the case sought to be made out is that the fundamental rights of
the two convicts have been violated. The two convicts could, if so minded, have raised
the contention in the earlier proceedings but a third party, a total stranger to the trial
commenced against the two convicts, cannot be permitted to question the correctness
of the conviction recorded against them. If that were permitted any and every person
could challenge convictions recorded day in and day out by courts even if the persons
convicted do not desire to do so and are inclined to acquiesce in the decision. If the
aggrieved party invokes the jurisdiction of this Court under Article 32 of the
Constitution, that may stand on a different footing as in the case of A.R. Antulay v.
R.S. Nayak, (1988) 2 SCC 602. However, we should not be understood to say that in
all such cases the aggrieved party has a remedy under Article 32 of the Constitution.
Unless an aggrieved party is under some disability recognised by law, it would be
unsafe and hazardous to allow any third party to question the decision against him.
Take for example a case where a person accused under Section 302, IPC is convicted
for a lesser offence under Section 324, IPC. The accused is quite satisfied with the
decision but a third party questions it under Article 32 and succeeds. The conviction
is set aside and a fresh trial commenced ends up in the conviction of the accusedCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

under Section 302, IPC. The person to suffer for the unilateral act of the third party
would be the accused! Many such situations can be pointed out to emphasise the
hazard involved if such third party's unsolicited action is entertained. Cases which
have ended in conviction by the apex court after a full gamut of litigation are not
comparable with preventive detention cases where a friend or next of kin is permitted
to seek a writ of habeas corpus. We are, therefore, satisfied that neither under the
provisions of the Code nor under any other statute is a third party stranger permitted
to question the correctness of the conviction and sentence imposed by the Court after
a regular trial. On first principles, we find it difficult to accept Mr. Sodhi's contention
that such a public interest litigation commenced by a leader of a recognised political
party who has a genuine interest in the future of the convicts should be entertained.
In S.P. Gupta v. Union of India, (1981) Supp. SCC 87 Bhagwati, J. observed :
(SCC p. 219, para 24) “But we must be careful to see that the member of the public,
who approaches the court in cases of this kind, is acting bona fide and not for
personal gain or private profit or political motivation or other oblique consideration.
The court must not allow its process to be abused by politicians and others ….” These
observations were made while discussing the question of ‘locus standi’ in public
interest litigation. These words of caution were uttered while expanding the scope of
the ‘locus standi’ rule. These words should deter us from entertaining this petition.
This accords with the view expressed by this Court in Krishna Swami v. Union of
India, (1992) 4 SCC 605.
8. More apposite is the view expressed by a Division Bench of this Court in Janata
Dal v. H.S. Chowdhary, (1992) 4 SCC 305. That was a public interest litigation for
quashing an FIR lodged by the CBI on January 22, 1990 based on the core allegation
that certain named and unnamed persons had entered into a criminal conspiracy in
pursuance whereof they had secured illegal gratification of crores of rupees from
Bofors, a Swiss Company, through their agents as a motive or reward. The CBI had
moved an application before the learned Judge, Delhi, for the issuance of a letter
rogatory to the Swiss authorities for assistance in conducting an investigation, which
request was conceded. An advocate, Shri Harinder Singh Chowdhary, filed a criminal
revision application before the High Court of Delhi for quashing the FIR and the
letter rogatory on certain grounds. Several questions of law and fact were raised in
support of the challenge.
The High Court came to the conclusion that the said third party litigant had no ‘locus standi’ to
maintain the action and so also the interveners had no right to seek impleadment/intervention in
the said proceeding. However, the learned Judge took suo motu cognizance of the matter and for
reasons stated in his order directed issue of show cause notice to the CBI and the State why the FIR
should not be quashed. On appeal, this Court came to the conclusion that the learned Judge in the
High Court was right in holding that the advocate litigant, as well as the interveners, had no ‘locus
standi'. The relevant observations found in paragraph 45 of the judgment read as under: (SCC p.
329, para 45) “Even if there are million questions of law to be deeply gone into and examined in aCentral Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

criminal case of this nature registered against specified accused persons, it is for them and them
alone to raise all such questions and challenge the proceedings initiated against them at the
appropriate time before the proper forum and not for third parties under the garb of public interest
litigants.” (emphasis supplied) In that case, besides the advocate litigant, certain political parties
like the Janata Dal, the CPI (Marxist), the Indian Congress (Socialist) and one Dr. P. Nalla Thampy
Thera also approached this Court questioning the High Court’s rejection of their request for
impleadment/intervention. It was in this context that this Court was required to examine the
question whether third parties had any ‘locus standi' in criminal proceedings and answered the
same as stated above. This decision clearly negatives the submission made by Mr. Sodhi in support
of the maintainability of this petition. We are, however, in respectful agreement with the view
expressed in the observations extracted hereinbefore.”
262. Reliance has been placed on Ashok Kumar Pandey v. State of W.B., (2004) 3 SCC 349, in which
it has been observed that an aggrieved party which is affected by any order, has the right to seek
redress by questioning the legality, validity or correctness of the order, unless aggrieved party is a
minor or insane person or is suffering from any other disability, etc. to question the decision again.
263. On behalf of the petitioner, reliance has been placed on A. R. Antulay v. Ramdas Sriniwas
Nayak & Anr., (1984) 2 SCC 500 in which private complaint lodged by Shri R.S. Nayak was held to
be maintainable against A.R. Antulay, the then Chief Minister. It was urged that any person can
bring to the notice of the court the fact which constitutes the offence and a Special Judge can take
cognizance on such complaint or even on information received from any person other than a police
officer or upon his own knowledge of the fact that the offence has been committed. The decision has
no application in the instant case as Forum of PIL has been misused, we have examined the case and
found the same to be meritless. Apart from that, it is not a case where a private complaint has been
lodged with respect to an offence. The CBI has investigated the case thoroughly and minutely and
the conspiracy between accused persons has been found established. There is voluminous evidence
discussed in criminal appeals decided today vide separate judgment with respect to the complicity of
the accused persons in the offence. It cannot be said that investigation was unfair, lopsided, botched
up or misdirected in any manner whatsoever, as had been observed by the High Court in the
judgment which we have set aside. It is surprising that the observations of the High Court have been
heavily relied upon in spite of mentioning the fact that the appeal was pending. In all fairness, such
petition ought not to have been filed by CPIL at the instance of accused, it is clearly misused of
Forum of PIL. Only an application could have been preferred by the accused persons or by the
petitioner or any other interested person in the criminal appeals. Even otherwise, we have not found
on merits any material or ground worthy to direct further investigation or re−investigation in the
case. The observations made by the High Court in the judgment which we have set aside were based
on lopsided approach without consideration of the entire evidence on record and on the wholly
incorrect appreciation of the evidence which was clearly perverse.
264. Reliance has also been placed on Bandhua Mukti Morcha v. Union of India & Ors., AIR 1984
SC 802 wherein this Court has observed that where a person or class of persons whose fundamental
right is violated but who cannot approach the Court on account of poverty or disability or socially or
economically disadvantaged position, and in such a case, any member of the public acting bona fide,Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

can move the court for relief under Article 32 and a fortiorari, also under Article 226 so that the
fundamental rights may become meaningful not only for the rich and the well to do but also for the
large masses of people who are living a life of want and destitution and who are by reason of lack of
awareness, assertiveness, and resources unable to seek judicial redress. Court can and must allow
any member of the public acting bona fide to espouse the cause of such person or class of persons
for judicial enforcement of the fundamental rights. This Court has further observed that the
provisions of Article 32 do not specifically indicate who can move the court. In the absence of such a
provision in that respect, it is plain that the petitioner may be anyone in whom the law has conferred
power to maintain an action of such nature. It is open to anybody who is interested in the petition
under Article 32 of the Constitution for relief. The aforesaid proposition cannot be doubted. In the
instant case, the petition cannot be said to have been filed bona fide as in the facts and
circumstances as narrated above. In case it is at the instance of family members, their rights have
been adjudicated by the High Court and concluded up to this Court. Accused persons are
represented by able lawyers throughout and in criminal appeals. But unfortunate part is that they
had a hand in filing of the petition by supplying the materials to the petitioner CPIL and CPIL in all
fairness, ought not to have filed the petition in the form of PIL but an application should have been
filed on behalf of the accused persons or any other person interested in criminal appeals. When all
concerned were aware that appeal was being heard in this Court for the last 2 months before the
filing of the petition, publications being made in reports when the appeal has been taken up for
hearing is also not a proper scenario and may tantamount to undue interference in course of justice.
265. We have dealt with on merits the various submissions raised by the petitioner as to the falsity
of the case of the prosecution and investigation in criminal appeals and have found that on merits
the submissions raised to cast doubt on prosecution case by CPIL are baseless vide detailed
discussion which we have made while dealing with the criminal appeals decided today by separate
judgment in which we have reiterated the judgment of conviction recorded by the Trial Court.
266. During the course of arguments, we had put a query to Mr. Prashant Bhushan, learned counsel
appearing on behalf of CPIL, how he can appear as counsel in the case filed by CPIL as he
admittedly is a member of the executive committee of CPIL. In view of the rule of professional ethics
framed by the Bar Council of India contained in section I of Chapter II of Part VI, Rule 8 is extracted
hereunder:
"8. An advocate shall not appear in or before any court or tribunal or any other
authority for or against an organisation or an institution, society or corporation if he
is a member of the Executive Committee of such organisation or institution or society
or corporation. "Executive Committee", by whatever name it may be called, shall
include any Committee or body of persons which, for the time being, is vested with
the general management of the affairs of the organisation or institution, society or
corporation:
Provided that this rule shall not apply to such a member appearing as amicus curiae
or without a fee on behalf of a Bar Council, Incorporated Law Society or a Bar
Association.”Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

267. Rule 8 makes an exception only if such a member is appearing as an amicus curiae or without a
fee on behalf of a Bar Council, Incorporated Law Society or a Bar Association. There is no exception
to a body like CPIL. Mr. Prashant Bhushan learned counsel has stated that he had questioned the
vires of Rule 8 by way of filing a writ petition in the High Court. In order to save vires of aforesaid
Rule 8, the statement was made in the Court by the Bar Council that they are going to amend the
rules, however, he submitted that the Bar Council has not amended the rules in spite of making the
statement. The rule is arbitrary and ultra vires as such he can appear.
268. We are not happy with the entire scenario. There cannot be any justification to appear in
violation of Rule 8, on the ground that the rule is arbitrary or ultra vires. The rule is not so far
declared to be illegal or ultra vires by the Court. The Rule 8 is binding on the members of the Bar
unless and until the rule in question is amended or declared to be arbitrary or ultra vires for any
reason, it is to be observed scrupulously by members of the Bar. Rules of professional ethics are
meant to be observed by all concerned. In case their observance is done in a breach that too before
this Court and that too knowing its implication on the aforesaid canvassed untenable ground, no one
can prevent breach of rules of ethics. If the Bar Council after making a statement has not amended
the rule, the rule ought to have been questioned afresh in an appropriate petition. The appearance
on behalf of the CPIL by a lawyer who is in the Executive Committee of the said Centre, cannot be
said to be proper as it is defined misconduct under the rules. This is in breach of Rule 8 of the
aforesaid Rules. We need not say any further on this. However, until it is declared ultra vires, we
hold that the advocates are bound to observe the same.
269. Resultantly, we find that the petition cannot be said to have been filed bona fide. Even
otherwise, the petition is bereft of merit. It raises the mainly same questions which have been dealt
with in the appeal. There is no such further material so as to direct further investigation or re−
investigation in the case. The matter should have rested finally as the petition filed by the family
members also stands dismissed by this Court raking up of the matter, again and again, is not
permissible and was wholly unwarranted in the facts and circumstances of the case. The same
amounts to political vendetta.
The petition is thus liable to be dismissed.
CONCLUSION CRIMINAL APPEAL NOS.140, 142−146 AND 149−151 OF 2012
270. In view of the aforesaid discussion, we restore the conviction and sentence imposed by the Trial
Court on A−1 (Mohmed Asgar Ali) (Criminal Appeal No.149 of 2012), A−4 (Kalim Ahmed) (Criminal
Appeal No.142 of 2012), A−5 (Anas Machiswala) (Criminal Appeal No.145 of 2012), A−6 (Mohmed
Yunus Sareshwala) (Criminal Appeal No.146 of 2012), A−7 (Rehan Puthawala) (Criminal Appeal
No.143 of 2012), A−8 (Mohmed Riyaz @ Goru) (Criminal Appeal No.144 of 2012), A−9 (Mohmed
Parvez Sheikh) (Criminal Appeal No. 140 of 2012), A−10 (Parvez Khan Pathan) (Criminal Appeal
No.150 of 2012) and A−11 (Mohmed Faruq) (Criminal Appeal No.151 of 2012) under Section 3(1)
and 3(3) of POTA and 120−B and Section 302 read with Section 120−B IPC as ordered by the Trial
Court. The appeals are accordingly disposed of.Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

CRIMINAL APPEAL NOS.141, 147 AND 148 OF 2012
271. However, with respect to A−2 (Mohmed Abdul Raouf) (Criminal Appeal No.147 of 2012), A−3
(Mohd. Shafiuddin) (Criminal Appeal No.148 of 2012) and A−12 (Shahnawaz Gandhi) (Criminal
Appeal No.141 of 2012), the CBI did not prefer any appeal in the High Court against them and since
A−3 (Mohd. Shafiuddin) and A−12 (Shahnawaz Gandhi) have completed the sentence fully awarded
to them by the Trial Court and in the case of A−2 (Mohd. Abdul Raouf) as modified by the High
Court, no further interference is made and the appeal against them is dismissed. (The names of
accused have been used as per the Trial Court judgment).
CRIMINAL APPEAL NOS.83−94 OF 2012
272. The appeals filed by State of Gujarat stand disposed of in terms of decision rendered in
Criminal Appeal Nos.140−151 of 2012. CRIMINAL APPEAL NO……./2019 @ SPECIAL LEAVE
PETITION (CRL.) NO.5530 OF 2017 AND CRIMINAL APPEAL NO……./2019 @ SPECIAL LEAVE
PETITION (CRL.) NOS.9028−9029 OF 2016
273. With respect to accused Mohd. Sheikh, a separate trial was held. In his conviction and sentence
under section 174A IPC as ordered by the High Court, no interference is made. He has been
acquitted except under section 174A IPC by the trial court as well as by the High Court. The appeal
against him filed by the CBI is dismissed. Appeal by the accused is also dismissed.
WRIT PETITION (CRIMINAL) NO.26 OF 2019
274. No ground for further re−investigation or investigation is made out in the matter. The writ
petition is dismissed with cost of Rs.50,000/− to be deposited by petitioner with Supreme Court Bar
Association Advocates Welfare Fund within a month.
                                                   ……………………..J.
                                                   (Arun Mishra)
New Delhi;                                         …………………….J.
July 05, 2019.                                     (Vineet Saran)Central Bureau Of Investigation vs Mohd.Parvez Abdul Kayuum on 5 July, 2019

