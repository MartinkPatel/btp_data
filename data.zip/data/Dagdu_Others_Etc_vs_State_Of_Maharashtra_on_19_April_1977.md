Dagdu & Others Etc vs State Of Maharashtra on 19 April, 1977
Equivalent citations: 1977 AIR 1579, 1977 SCR (3) 636, AIR 1977 SUPREME
COURT 1579, (1977) 3 SCC 68, (1977) 2 SCJ 241, 1977 SC CRI R 285, 1977 CRI
APP R (SC) 241, 1977 SCC(CRI) 421, 1977 3 SCR 636, 1977 MADLJ(CRI) 462
Author: Y.V. Chandrachud
Bench: Y.V. Chandrachud, P.K. Goswami, P.N. Shingal
           PETITIONER:
DAGDU & OTHERS ETC.
        Vs.
RESPONDENT:
STATE OF MAHARASHTRA
DATE OF JUDGMENT19/04/1977
BENCH:
CHANDRACHUD, Y.V.
BENCH:
CHANDRACHUD, Y.V.
GOSWAMI, P.K.
SHINGAL, P.N.
CITATION:
 1977 AIR 1579            1977 SCR  (3) 636
 1977 SCC  (3)  68
 CITATOR INFO :
 RF         1977 SC1936  (39)
 D          1988 SC1831  (119)
 RF         1992 SC1689  (7)
ACT:
Evidence  Act 1972--Sections 114 illustration  (b)   and
        133--Accomplice     evidence,    whether     a     competent
        witness--Whether  conviction can be based on  uncorroborated
        evidence of an accomplice--Appreciation--Rule of  corrobora-
        tion---Presumption by courts.
Criminal  Procedure Code 1989--Sections 163, 164,  367(5)
        and  554--Confessional statements--Criminal Manual  1960  of
        Bombay  High  Court--Para 18 --Failure to comply  with  Sec.
        164(3)  and  High  Court circulars  if  renders  confessions
        inadmissible in evidence-- Evidence Act, Section 29.
Criminal Procedure Code 1973-- Sections 235,  354--Hear-
        ing  accused on the question of  sentence--If  mandatory--If
        appellate  court  can give hearing on failure by  the  trialDagdu & Others Etc vs State Of Maharashtra on 19 April, 1977

        court.
HEADNOTE:
            Accused,  No.  1 though in her thirties  had  entered  a
        period  of  premature menopause.  She was anxious to  get  a
        child  which  could only happen if her menstrual  cycle  was
        restored.  She used to consult quacks and Mantriks in  order
        to  help.get a child. Accused No.1's mother  was  accredited
        with  sixth  sense in the matter of  discovery  of  treasure
        trove.   She had oracled that a treasure trove lay buried  I
        in  accused No. 1's house underneath the Pimpal  tree.   The
        Pimpal  tree is believed to be the haunt of Munjaba, who  is
        supposed  to  be  the spirit of an  unmarried  Brahmin  boy.
        Accused  NOs. 1 and 2 consulted quacks who  prescribed  that
        virgins  should  be offered as sacrifice to Munjaba  and  to
        propitiato  the  deity, blood from their  private  parts  be
        sprinkled  on the food offered by way of  'Naivedya'.   Five
        small girls about 10 years of age, a year old infant and.  4
        women in their  mid-thirties  were found  murdered   between
        14-11-1972  and 4-1-1974 in a village called  Manawat.  The.
        murders of these 10 females showed significant  similarities
        in  pattern  and conception. The time and place  chosen  for
        crime,  preference  for females as victims,  the  nature  of
        injuries  caused to them, the strange possibility  that  the
        private   parts of some of the victims were cut in order  to
        extract blood, the total absence of motive for killing these
        very girls and women, the clever attempt to dodge the police
        and  then to put them on a false scent and the extreme  bru-
        tality  surroundings  the crimes gone to the case  an  eerie
        appearance.
            Eighteen  persons were put up for trial before the  Ses-
        sion  Judge  for the 10 murders.  Two out of  these  persons
        were  tendered pardon and were examined in the case  as  ap-
        provers.  Accused No. 6 died during the trial. The  Sessions
        Judge  acquitted accused 4, 5, 7, 8 and 13 to  16.   Accused
        No.  1 and 2 were convicted under s. 302 read with s.  120-B
        and  section  34 of the Penal Code. Accused No. 1, 2  and  3
        were  sentenced  to  death while accused No. 9  to  12  were
        sentenced to life imprisonment.  The matter went to the High
        Court  in the form of various proceedings.  The  High  Court
        acquitted  accused No. 1 and 2 holding that the  offence  of
        conspiracy  which formed the gravamen of the charge  against
        them was not proved.  Since the charge of conspiracy  failed
        and  since it was a common ground that accused No. 1  and  2
        had  not  taken  any direct part in the  commission  of  the
        murders,  the  High Court held that they  were  entitled  to
        acquittal on all the charges.  The High Court dismissed  the
        appeal filed by accused No. 3 holding that he was  responsi-
        ble  for  the first 4 murders and confirmed  his  conviction
        under  s. 302 read with  s. 34 as also the sentence of  death
        imposed  upon  him.  The High Court  dismissed  the  State'sDagdu & Others Etc vs State Of Maharashtra on 19 April, 1977

        appeal against acquittal of accused No. 4 and 5 but  allowed
        the State's appeal and enhanced the sentence of accused  No.
        9 to 12 to death.
            Criminal  Appeal  No. 437 of 1976 was filed  by  accused
        Nos.  9 to 12. Criminal Appeal No. 438 of 1976 was filed  by
        accused No. 3 and Criminal Appeal No. 441 of 1976 was  filed
        by  the  State of Maharashtra against acquittal  of  accused
        1%s. 1 and 2.  The Court acquitted accused No. 12 by  giving
        him  the  benefit of doubt and while  dismissing  the  three
        appeals.
        637
            HELD:  (1)  There is no antithesis between   s.  133  and
        illustration (b) to section-114 'of the Evidence Act because
        the  illustration  only says that-the-Gourt  may  presume  a
        certain  state of affairs under  s. 114 of the  Evidence  Act
        The  Court  may presume the existence of any fact  which  it
        thinks  likely  to have happened regard' being  had  to  the
        common  course of natural events, human conduct  and  public
        and  private  business in their  relation-to  the  facts-of-
        theparticular casee.  Under  s. 133 -of the Evidence-Act,  an
        accomplice  shall be acompetent wireess against  an  accused
        person  and a conviction is  not  illegal merely because  it
        proceeds upon-the uncorroborated testimony of an accomplice:
        [643 B-C]
          (2)   Though  an  accomplice is,a  competent  witness  and
        though a conviction may lawfully rest upon his uncorroborat-
        ed testimony yet the court is entitled to presume and may be
        justified  in presuming in the generality of cases  that  no
        reliance  can  be placed on the evidence  of  an  accomplice
        unless  that evidence is corroborated in  material  particu-
        lars, by which is meant that there has to be some  independ-
        ent  evidence tending to incriminate the particular  accused
        in the commission of the crime.  1643 C-D]
          (3) It is hazardous as a matter of prudence to proceed  on
        the  evidence a self-confessed criminal.  The risk  involved
        in  convicting  accused on the testimony  of  an  accomplice
        unless it is corroborated in material particulars is so real
        and potent that what during the early development of law was
        felt  to be a matter of prudence has been elevated by  judi-
        cial  experience into a requirement or rule of  lave.   What
        has  hardened into a rule of law is not that the  conviction
        is illegal if it proceeds upon the uncorroborated  testimony
        of an accomplice but that the rule of corroboration must  be
        present to the mind an the Judge and that corroboration  may
        be dispensed with only if the peculiar circumstances of  the
        case make it safe to dispense with it. [643 ,E-F]
            King  v.  Baskerville [19161 2 K.B.  653;  Rameshwar  v.
        State  of Rajasthan [1952] S.C.R. 377, Bhuboni Saku  v.  The
        King 76 I.A. 147; The State of Bihar v. Basawan Singh [1959]
        SCR  195  and Ravinder Singh v. State of  Haryana  [1975]  3
        S.C.R. 453. relied on.
            (4)  It is true that an approver has real  incentive  to
        speak  out his mind after tender of pardon but where  it  isDagdu & Others Etc vs State Of Maharashtra on 19 April, 1977

        impossible  to  reconcile his earlier  statements  with  his
        later assertions his evidence has to be left out of  consid-
        eration.  It is one thing to say that an approvers statement
        cannot  be  discarded for the mere reason that  he  did  not
        disclose the entire story in his police statement and  quite
        another  to  accept an approver in spite  of  contradictions
        which  cast a veil of doubt over his involvement of  others.
        [646 B-C]
               Madan  Mohan Lal v. State of Punjab [1970]  2  S.C.C.
        733 relied on.
             Tahsildar's  case  [1959] Supp. 2 S.C.R.  875,  distin-
        guished.
        (5) The failure to comply with section 164(3) Cr. P.C.  with
        the  High  Court circulars will not render  the  confessions
        inadmissible  in evidence.  Relevancy and  admissibility  of
        evidence have to be determined in accordance with the provi-
        sions of the Evidence Act.  [651 E]
        (6) Under section 29 of the Evidence Act, if a confession-is
        otherwise  relevant,  it does not become  irrelevant  merely
        because, inter alia, the accused was not warned that he  was
        not  bound to make it and the evidence of it might be  given
        against  him.  If, therefore a confession does  not  violate
        any  one of the conditions operative under  ss. 24 to  28  of
        the Evidence Act, it will be admissible in evidence.  But as
        in respect of any other admissible evidence oral or documen-
        tary,  so in the case of confessional statements  which  are
        otherwise admissible. the Court has still to consider wheth-
        er  they can be accepted as true. If the facts  and  circum-
        stances  surrounding  the making of a confession  appear  to
        cast a doubt on the veracity or voluntariness of the confes-
        sion,   the Court may refuse to act upon the confession even
        if it is admissible in evidence.
                                          [651 E-G]
            (7) A strict and faithful compliance with  s. 164 of  the
        Code  and  with the instructions issued by  the  High  Court
        affords in a large measure the guarantee
        638
        that  the confession is voluntary.  The failure  to  observe
        the safeguards prescribed therein are in practice calculated
        to  impair the evidentiary value of the confessional  state-
        ments.
            In the instant case no reliance can be placed on any  of
        the  contesstons. Apart from the cofessions of the  two  ap-
        provers,  all others were retracted, which further  cripples
        their evidentiary value.  [657 H]
            (8) The imperative language of sub-section (2) leaves no
        room for doubt that after recording the finding of guilt and
        the  order of conviction, the. Court is under an  obligation
        to  hear the accused on the question of sentence  unless  it
        releases  him on probation of good conduct or after  admoni-
        tion  under s. 360. The social compulsions, the pressure  of
        poverty,  the retributive  instinct  to seek an  extra-legal
        remedy to a sense of being wronged, the lack of means to  beDagdu & Others Etc vs State Of Maharashtra on 19 April, 1977

        educated  in the difficult art of an honest firing the  par-
        entage, the heredity-all these and similar  other  consider-
        ations  can, hopefully and legitimately, tilt the scales  on
        the  property of sentence.  The mandate of s. 235 (2)  must,
        therefore, be obeyed in its letter and spirit.  [657 F-H]
            (9) The failure on the part of the Court, which convicts
        an accused, to hear him on the question of sentence does not
        necessarily entail a remand to that Court in order to afford
        to the accused an opportunity to be heard on the question of
        sentence.  [658 A-B]
        Santa  Singh  v. State of Punjab [1976] 4  S.C.C.  190,  ex-
        plained.
            (10)  The Court, on convicting an accused, must  unques-
        tionably hear him on the question of sentence.  But if,  for
        any reason, it omits to do so and the accused makes a griev-
        ance  of  it in the higher court, it would be open  to  that
        Court  to remedy the breach by giving a hearing to  the  ac-
        cused on the question of sentence.  That opportunity has  to
        be real and effective, which means that the accused must  be
        permitted  to adduce before the Court all the data which  he
        desires to adduce on the question of sentence.  The  accused
        may exercise that right either by instructing his counsel to
        make  oral submissions to the Court or he may, on  affidavit
        or otherwise, place in writing before the Court whatever  he
        desires to place before it on the question of sentence.  The
        Court may, in appropriate cases, have to adjourn the  matter
        order to give to the accused sufficient time to produce  the
        necessary data and to make his contention on the question of
        sentence.  For a proper and effective implementation of  the
        provision contained in s. 235(2) it is not always  necessary
        to  remand  the matter to the Court which has  recorded  the
        conviction.   Remand  is  an exception, not  the  rule,  and
        ought,  therefore,  be  avoided as far as  possible  in  the
        interests   of expeditious, though fair disposal  of  cases.
        [658 B-D, F]
             Santa  Singh  v. State of Punjab [1976] 4  S.C.C.  190,
        distinguished.
             GOSWAMI, I. (Concurring) :--
             Whenever  an  appeal court finds that  the  mandate  of
        section  235(2) Cr. P.C. for a hearing on sentence  has  not
        been complied with it becomes the duty of the Court to offer
        to the accused an adequate opportunity to produce before  it
        whatever  material  he chooses in  whatever  reasonable  way
        possible.  Courts  should as far us possible  avoid  remands
        when the accused can secure a full benefit of s. 235 (2) Cr.
        P.C. in the appeal court.  [661 C-D]
JUDGMENT:
CRIMINAL APPELLATE JURISDICTION: Crl. A. Nos. 437 & 438 of 1976.Dagdu & Others Etc vs State Of Maharashtra on 19 April, 1977

(Appeals by Special Leave from the Judgment and Order dated the 8/9/10-3-1976 of the Bombay
High Court in Crl. Appeals Nos. 17 and 18 of 1976 and confirmation Case No. 3 of 1976) and Crl. A.
No. 441 of 1976.
(Appeal by Special Leave from the Judgment and Order dated the 8/9/10-3-1976 of the Bombay
High Court in Criminal Appeal No. 18 of 1976).
P. Narayan, B.G. Kolse Patil, B.S. Bhonde and V.N. Ganpule, for the appellants in Crl. A. Nos.
437-438 and for respondent in Crl. A. 441/76.
V. S. Desai, P.P. Hudlekar and M.N. Shroff for respond- ents in Crl. Appeal Nos. 437-438 and for the
appellant in Crl. A. No. 441/76.
The Judgment of Y.V. Chandrachud and P.N. Sitinghal, JJ. was delivered by Chandrachud, J. P.K.
Goswami, J. gave a separate opinion.
CHANDRACHUD, J. Five small girls about ten years of age, a year, old infant and four women in
their mid-thirties were found murdered between November 14, 1972 and January 4, 1974 in a village
called Manwar in Maharashtra. The murders of these ten females show significant SimilaritieS in
pat- tern and conception. The time and place chosen for the crimes, the preference for females as
victims, the nature of injuries caused to them, the strange possibility that the private parts' of some
of the victims were cut in order to extract blood, the total absence of motive for killing these very
girls and women, the clever attempt to dodge the police and then to put them on a false scent and
the extreme bru- tality surrounding the crimes give to the case an eerie appearance. Such harrowing
happenings make the task of discovering truth difficult and it is just as well to begin with Justice
Vivian Bose's reminder that the shocking nature of the crime ought not to induce an instinctive
reaction against a dispassionate scrutiny of facts and law. We have three appeals before us,. all by
special leave granted by this Court. Criminal Appeal No. 437 of 1976 is flied by accused Nos. 9 to 12,
Criminal Appeal No. 438 of 1976 by accused No. 3 while Criminal Appeal No. 441 of 1976 is flied by
the State of Maharashtra against the acquittal of accused Nos. 1 and 2.
Eighteen persons were put up for trial before the learned Sessions judge, Parbhani for the ten
murders. Two out of these, Ganpat Bhagoji Salve and Shankar Gyanoba Kate were tendered pardon
by the learned Judge and were examined in the case as approvers. Accused Nos. 6 died during the
trial leaving 15 persons for consideration of the question whether they had conspired to commit the
murders and whether the murders were committed in pursuance of that conspiracy. The learned
Sessions Judge acquitted accused Nos. 4, 5, 7, 8 and 13 to 16. Accused Nos. 1 and 2 were convicted
under sec. 302 read with sec. 120-B and sec. 109 of the Penal Code. Accused Nos. 3 and 9 to 12 were
convicted under sec. 302 read with sec. 120-B and sec. 34 of the Penal Code. Accused Nos. 1, 2 and 3
were sentenced to death while ac- cused Nos. 9 to 12 were sentenced to life imprisonment. The
matter went to the Bombay High Court in various forms. The seven accused who were convicted by
the Trial Court filed an appeal challenging the order of conviction and sentence. The Sessions Court
made a reference to the High Court for confirmation of. the death. sentence imposed on-accused
Nos. 1, 2 and 3. The State Government flied an appeal against the acquittal of accused Nos. 4 and 5.Dagdu & Others Etc vs State Of Maharashtra on 19 April, 1977

It also filed an appeal under s..377 of the Criminal Procedure Code, 1973 asking that the sentence of
life imprisonment imposed on accused Nos. 9 to I2 be enhanced to death. The State not having
challenged the order of acquittal passed by the Sessions Court in regard to accused Nos,7, 8 and 13
to 16, that order has become final and was not in any form assailed before Us as erroneous.
The High court acquitted. Nos.1 and 2 holding friar the offence of conspiracy which formed the
gravamen of the charge against them was not proved. The charge of conspira- cy having failed and it
being common ground that accused Nos. 1 and 2 had not taken any direct part in the commis- sion
of the murders, the High Court held that they Were entitled to acquittal on all the charges. The High
Court dismissed the appeal file flied by accused No. 3 holding that he was responsible for the first
four murders and.con- firmed his conviction under s. 302 read with s. 34 as also the sentence of
death imposed upon him. The conviction ,and sentence-of accused No. 3 under s. 302 read with
s.120B was set aside by the' High Court in view of its finding, that the prosecution had failed to
establish the charge,of con- spiracy. High court dismissed the State's appeal against the acquittal of
accused Nos.4 and 5 but it allowed the appeal flied.by the State for enhancement of the sentence of
life imprisonment imposed on accused Nos. 9 to 12. The. High Court enhanced their sentence to
death under s. 302 read with 8. 34 but consistently, with its finding on the charge of conspiracy it set
aside their conviction and sentence under s. 302 read with s. 120B. There were delay on the"
part of the State Government in filing the appeal for en- hancement of the sentence of
accused Nos. 9 to 12 but the High Court condoned that delay.
We are thus called upon to consider the correctness of:
(1)the order of the High Court acquitting accused Nos. 1 and 2; (2) the-order of
conviction of accused No. 3 under s. 302 read with s. 34 and the sentence of death
imposed upon him by the Sessions Court and the High Court; and (3) the order of
conviction of accused Nos. 9 to 12 under s. 302 read with s. 34. Thus, we are
concerned in these appeals with accused Nos. 1 to 3 and 9 to 12 only.
The hamlet of Manwat has a population of 15 thousand and is situated in. Taluka Pathri, District
Parbhani, Maharash- tra. Accused No. 1, Rukhmini, was about 32. years of age at the relevant time
and despite the pledge-to secularism, it has to be mentioned that she is Pardhi by caste. She was in
the keeping of accused No. 2, Uttamrao Barshate, a non pardhi, who is a man of means and was at
one time the Presi- dent of the Manwat Municipality. He purchased a house for accused No. 1 in
which the two lived together and it is this house or wada.which became 'the focal point of the
conspira- cy. Accused No. 2 purchased the house really in order to ensure the exclusiveness of
mistress but it happened to blaze an altogether new trial.
In the house was a Pimpal tree which is believed to be the emblem of God Vishnu, the Preserver. The
Pimpal is also believed to be the haunt of Munjaba, who is supposed to be the spirit of an unmarried
Brahmin boy. The Parbhani Dis- trict Gazetteer says at page 115 that "some childless per- sons who
trace their misfortune to the influence of some evil spirit cause the Brahminic thread ceremony
performed for a pimpal tree and a masonry platform built round its trunk."Dagdu & Others Etc vs State Of Maharashtra on 19 April, 1977

The Man want village-folk commonly believe that treasure troves are lying buried in the town ever
since the sixteenth century when its inhabitants fled away after the troops of Murtazahad invaded
the town, which was then under the Ni- zamshahi of Ahmednagar. Quite some quacks in the
periphery of 'Manwat make their living by diagnosing where the treas- ure trove lies and what
means to adopt for diScovering it. Accused No. 1, though in her thiries, had entered a period of
premature menopause. She was anxious to get a child which could only happen if her menstrual
cycle was restored. She used to consult quacks and mantriks who, she 'believed, could help her get a
child. Accused No. 2's mother was ,credited with a sixth sense in the matter of- discovering treasure
troves. 'She had oracled that a' treasure trove lay buried in accused No. 1's house under- neath the
Pimpal tree. The stage was thus set for the visits of mountebanks to the house of accused No. 1 for
the display of their supernatural. attainments.
The case of the prosecution is that accused Nos land 2 consulted quacks who prescribed that virgins
should be offered as sacrifice to munjaba. and blood from the irpri- vate arts be sprinkled on the
food offered by way of Naive- dya to the God. One of such quacks was Ganpat Salve, the approver,
who was examined as: P.W. 1. Accepting Ganpat's advice, accused Nos. 1,, 2, 3,4 and 6 conspired to
commit the murders of virgin girls. Ganpat himself joined the conspiracy and so did Shankar
Gyanoba Kate who was a servant of accused No. 2. Shankar, also an approver, was examined in the
case as P.W.2. Accused Nos. 5 and 7 to 16 are alleged to have joined the conspiracy at a later point of
time. In pursuance of the conspiracy, ten murders were committed between November 14, 1972 and
January 4, 1974.
The first four murders are alleged to have been commit- ted by the approver Shankar and accused
No. 3, Sopan, who was also in the employment of accused No. 2. Gayabai, a girl of 11 was murdered
on November-14, 1972; Shakila, a girl of 10, was murdered on December 9, 1972;. Sugandhabai, a
woman Of 35 was murdered on February 21, 1973 and Nasima a girl of lO was murdered on April 13,
1973.
It is said that the-blood from the private parts of these victims was offered to Munjaba and yet there
was no clue as to where the treasure trove lay. Gayabai, Shakila and Sugandhabai had evidently died
in vain and therefore Nasima, the fourth victim, was beheaded so that the severed head could be
offered. to propitiate the deity. Even Nasima's head failed to move Munjaba's heart. The treasure
trove remained undisclosed.
The next two murders are alleged to have been committed by accused Nos. 5 and 6. Kalavati, a
woman of 30, was murdered on June 29, 1973 and Halires, a girl of 11, on July 12, 1973. Accused No.
5 has been acquitted and the order of acquittal has become final. Accused No. 6 died during the
pendency of the trial in the Sessions Court. The seventh murder is alleged to have been committed
by accused Nos. 7 and 8 when Parvatibai, aged about 35, was murdered on October 8, 1973. These
two accused were ac- quired by the Sessions Court and the acquittal was not challenged by the State.
The three last murders are alleged to have been commit- ted by accused Nos. 9 to 12, all at the same
time. Haribai, aged 35, was going along with her daughter Taravati aged 9 and was carrying in her
arms an infant daughter, Kamal, aged a year and half. All of them were murdered on the afternoonDagdu & Others Etc vs State Of Maharashtra on 19 April, 1977

of January 4, 1974.
Accused Nos. 1, 2, and 14 were arrested on June 18, 1973 in connection with the first four murders
which had taken place between November 14, 1972 and April 13, 1973. It is alleged that, while in
custody, accused No. 2 sent a message to accused No. 5 to commit a few more murders so that no
suspicion may fall on those who were arrested. That is why accused Nos. 5 and 6, accused No. 6
being a servant of accused No. 1, are said to have committed the murders of Kalavati and Halires in
June and July, 1973. On July 30, 1973 accused Nos. 1, 2, 9 and 14 were released on bail on condition
that they shall not enter the limits of Manwat. This condition was relaxed on October 4, 1973 for
investiga- tional purposes. Accused Nos. 1 and 2 were in Manwat from October 4 to October 21, 1973
during which period they are alleged to have procured the service. of accused Nos. 7 and 8 for the
commission of Parvatibai's murder on October 8. On December 18, 1973, an application was moved
for cancella- tion of the bail granted to accused Nos. 1 and 2. That application was allowed and they
were rearrested on January 4, 1974 when the murders of Haribai, Taramati and Kamal were
committed. Accused No. 3 was arrested on December 28, 1973, accused Nos. 9 to 11 on January 8,
1974 and accused No. 12 on January 11, 1974.
Accused Nos. 1 and 2 are the linch-pin of the case and therefore, it would be appropriate to deal with
their cases first. Accused No. 1 is the mistress of accused No. 2 and whereas the former was anxious
to get a child, they both were anxious to discover the treasure trove lying buried in their house. The
charge against them is that for the purpose of achieving these objects they consulted quacks who
advised that the Munjaba should be propitiated by offering the blood of virgin girls. Accepting that
advice, accused Nos. 1 and 2 are alleged to have entered into a conspiracy with the other accused to
commit the various murders. The prosecution relied inter alia on the evidence of the two approvers,
Ganpat, P.W. 1, and Shanku, P.W. 2, in order to prove the charge of conspiracy against accused Nos.
1 and 2 as also for proving that various murders were com- mitted in pursuance of that conspiracy.
The learned Sessions Judge accepted the evi- dence, of both the approvers as against accused Nos. 1
and 2 but the High Court rejected the evidence of Ganpat and accepted that of Shankar only.
Before considering that evidence, it would be necessary to state the legal position in regard to the
evidence of accomplices and approvers. Section 133 of the Evidence Act lays down that an
accomplice shall be a competent witness against an accused person; and a conviction is not illegal
merely because it proceeds upon the uncorroborated testimony of an accomplice. Section 114 of the
Evidence Act provides that the Court may presume the existence of any fact which it thinks likely to
have happened, regard being had to the common course of natural events, human conduct and
public and private business, in their relation to the facts of the particular case. Illustration (b) to s.
114 says that the Court may presume that an accomplice is unworthy of credit unless he is
corroborated in material particulars. There is no. antithesis between s. 133 and illustration
(b) to s.114 of the Evidence Act, because the illustration only says that the Court 'may' presume a
certain state of affairs. It does not seek to raise a conclusive and irre- butable presumption. Reading
the two together the position which emerges is that though an accomplice is a competent witness
and though a conviction may lawfully rest upon his uncorroborated testimony, yet the Court is
entitled to presume and may indeed be justified in presuming in the generality of cases that noDagdu & Others Etc vs State Of Maharashtra on 19 April, 1977

reliance can be placed on the evidence of an accomplice unless that evidence is corrobo- rated in
material particulars, by which is meant that there has to be some independent evidence tending to
incriminate, the particular accused in the commission of the crime. It is hazardous, as a matter of
prudence, to proceed. upon the evidence of a self confessed criminal, who, in so far as an approver is
concerned, has to testify in terms of the pardon tendered to him. The risk involved in convicting an
accused on the testimony of an accomplice, unless it is corroborated in material particulars, is so
real and potent that what during the early development of law was felt to be a matter of prudence
has been elevated by judicial experience into a requirement or rule of law. All the same, it is
necessary to understand that what has hardened into a rule of law is not that the conviction is illegal
if it proceeds upon the uncorroborated testimony of an accomplice but that the rule of corroboration
must be present to the mind of the Judge and that corroboration may be dispensed with only it the
peculiar circumstances of a case make it safe to dispense with it.
In King v. Baskerville(1) the accused was convicted for committing gross acts of indecency with two
boys who were treated as accomplices since they were freely consenting parties. Dealing with their
evidence Lord Reading, the Lord Chief Justice of England, observed that though there was no doubt
that the uncorroborated evidence of an accomplice was admissible in law it was for a long time a role
of practice at common law for the Judge to warn the Jury of the danger of convicting a person on the
uncorroborated testimo- ny of an accomplice. Therefore, though the Judge was enti- tled, to point
out (1) [1916] 2 K.B. 658.
2--7078CI/77 to the Jury that it was within their legal province to convict upon the unconfirmed
evidence of an accomplice, the rule of practice had become virtually equivalent to a rule of law and
therefore in the absence of a proper warning by the Judge the conviction could not be permitted to
stand. If after being properly cautioned by the Judge the Jury never- theless convicted the prisoner,
the Court would not quash the conviction merely upon the ground that the accomplice's testimony
was uncorroborated.
In Rameshwar v. State of Rajasthan(1) this Court ob- served that the branch of law relating to
accomplice evi- dence was the same in India as in England and that it was difficult to better the lucid
exposition of it given in Baskerville's (supra) case by the Lord Chief Justice of England. The only
clarification made by this Court was that in cases tried by a Judge without the aid of a Jury it was
necessary that the Judge should give some indication in his judgment that he had this rule of
caution in mind and should proceed to give reasons for considering it unnecessary to require
corroboration on the facts of the particular case before him and show why he considered it safe to
convict without corroboration in the particular case. In Bhuboni Sahu v. The King(a) the Privy
Council after noticing s. 133 and illustration (b) to s. 114 of the Evi- dence Act observed that whilst it
is not illegal to act on the uncorroborated evidence of an accomplice, it is a rule of prudence so
universally followed as to amount almost to a rule of law that it is unsafe to act on the evidence of an
accomplice unless it is corroborated in material respects so as to implicate the accused; and further
that the evi- dence of one accomplice cannot be used to corroborate the evidence of another
accomplice. The rule of prudence was based on the interpretation of the phrase "corroborated in
material particulars" in illustration (b). Delivering the judgment of the Judicial Committee, Sir John
Beaumont ob- served that the danger of acting on accomplice evidence is not merely that theDagdu & Others Etc vs State Of Maharashtra on 19 April, 1977

accomplice is on his own admission a man of bad character who took part in the offence and
afterwards to save himself betrayed his former associates, and who has placed himself in a position
in which he can hardly fail to have a strong bias in favour of the prosecution the real danger is that
he is telling a story which in its general outline is true, and it is easy for him to work into the story
matter which is untrue. He may implicate ten people in an offence and the story may be true in all
its details as to eight of them but untrue as to the other two whose names may have been introduced
because they are enemies of the approver. The only real safeguard therefore against the risk of
condemning the innocent with the guilty lies in insisting on independent evidence which in some
measure implicates each accused.
This Court has in a series of cases expressed the same view as regards accomplice evidence. (see The
State of Bihar v. Basawan (1) [1952] S.C.R. 377.
(2) 76 I.A. 147.
Singh(1); Hari Charan Kurmi v. State of Bihar;(2) Haroon Haji Abdulla v. State of Maharashtra;(a)
and Ravinder Singh v. State of Haryana(4). In Hari Charan(2) Gajendragadkar, C.J., speaking for a
five-Judge Bench observed that the testimony of an accomplice is evidence under s. 3 of the
Evidence Act and has to be dealt with as such. The evidence is of a tainted character and as such is
very weak; but, nevertheless, it is evidence and may be acted upon, subject to the requirement which
has now become virtually a part of the law that it is corroborated in material particulars. We will
assess the evidence of the two approvers Ganpat and Shankar in the light of these principles. Ganpat
Bhagoji Salve, P.W. 1, fails to cross the initial hurdle of reliability and no amount of corroboration
cure the infirmi- ties which beset his evidence. He is not a quack but a charlatan who traded on the
credulous optimism of the ster- ile village women. He admits that he possessed no cure but made a
pretence of it by carrying the confidence of lay, uninformed women. He was sent for to prescribe a
cure to enable accused No. 1 to bear a child but accused Nos. 1 and 2, taking advantage of his expert
presence, consulted him on where the treasure trove lay. Ganpat prescribed the facade of a
procedure which was in the nature of a confidence trick. Practising it deftly on his credulous
audience, he passed on the errand of God that Munjaba has to be appeased by offering the blood of
virgin girls. That work was as- signed by accused No. 2 to his servants, accused No. 3 and the other
approver Shankar.
Accused No.3 and Shankar committed the murders of Gaya- bai and Shakila and handed over the
bowlful of blood from the private parts of the victims to accused Nos. 1 and 2 who performed the
puja of Munjaba. But the treasure trove did not come up. Then Sugandhabai was murdered and her
menstur- al blood was offered to the God, again without a purpose. The fourth to die was Nasima
whose head and small finger were offered as sacrifice. But even that heavy price yield- ed no clue to
the treasure trove Ganpat was paid a fee of Rs. 100 whereupon he made himself scarce and left for a
place called Baramati from where he was traced by the po- lice. That is what Ganpat's evidence
comes to. Ganpat is an utterly worthless witness whose evidence has been rightly discarded by the.
High Court. His entire story is incredible and abounds in contradictions of the gravest kind. Accused
No. 2 is a man of some means and was for some time the President of the Manwat Municipality. It is
hardly likely that a person in his position would readily gulp the fantastic process prescribed byDagdu & Others Etc vs State Of Maharashtra on 19 April, 1977

Ganpat for discov- ering the treasure trove Ganpat was interrogated by the police for nearly a month
and a half after his arrest at Baramati and it was only at the end of that trying period that he trotted
out some story (1) [1959] SCR 195 (2) [1964] 6 SCR 623 (3) [1968] 2 SCR 641 (4) [1975] 3 SCR 453
to save his skin. It is common ground, and we see much more in that episode, that Ganpat struck his
head against a wall while in police custody and sustained a head injury for which he was
charge-sheeted for attempting to commit sui- cide. He admits in his evidence that he was driven to
break his head as a result of the torture inflicted upon him by the police. Though he implicated both
accused Nos. 1 and 2 in the search for treasure trove, he admitted later that. accused No.1 had never
talked to him. in that behalf. He made several significant statements for the first time in the Court
and though we agree that an approver has real incentive to speak out his mind after tender of
pardon, it is impossible to reconcile his earlier statements with his later assertions. It is one thing to
say as was said in Madan Mohan Lal v. State of Punjab(1) that an approver's statement cannot be
discarded for the mere reason that he did not disclose the entire story in his police statement and
quite another to accept an approver in spite of contra- dictions which cast a veil of doubt over his
involvement of others. Conceding the ratio. of Tahsildar's(2) case, on. which Mr. Desai for the State
Government relies, the conclu- sion seems to us inescapable that Ganpat has mixed a ton of
falsehood with an ounce of truth. His evidence has there- fore to be left out of consideration.
The other approver Shankar Gyanoba Kate, P.W. 2, has greater credibility than Ganpat. Shankar
was working with accused No. 2 as an agricultural servant along with accused No. 3. He speaks of
Ganpat's visits, the performance of the 'shakun' and of being commanded by accused Nos. 1 and 2 to
commit murders of virgin girls. He has unreservedly admitted having committed the murders of
Gayabai, Shakila, Sngandha- bai and Nasima with accused No. 3's assistance. He impli- cates
accused Nos. 1 and 2 by deposing that after each o[ the murders was committed, he and accused No.
3 used to go to accused No.1's house for delivering the blood and that the accused used to perform
the Puja thereafter. Not only has Shankar tarred himself with the same brush as accused Nos. 1, 2
and 3 but he has confessed to having played the leading role in the commission of the first four
murders. Impressed by that circumstance, the Sessions Court and the High Court concluded that he
is a reliable witness, but they took the view that the conviction of accused Nos. 1 and 2 cannot be
permitted to rest on his uncorroborated testimony. We unhesitatingly share that view. Having
played the role of the master killer in four ghastly murders, he is bound to know every little detail as
to the manner of kill- ing. The vivid description given by him of the luring, the gagging and the
throwing away of the dead bodies may there- fore be true. But it is easy enough for him to introduce
nice falsities here and there by involving some others in the broadly true framework of his story. It is
therefore necessary to see whether the evidence of Shankar in regard to the implication of accused
Nos. I and 2 is corroborated by some independent evidence..
(1) [1970] 2 S.C.C. 733.
(2) [1959] Supp. 2 S.C.R. 875.
Before looking out for corroboration., we must point out that Shankar used to be interrogated by the
police every night for about 9 or 10 days and it was at the end of that gruelling interrogation that his
statement came to be re- corded. Though Shankar claims that he had seen the 'shakun' beingDagdu & Others Etc vs State Of Maharashtra on 19 April, 1977

performed by Ganpat, he had not stated so before the police nor had he then described the elaborate
ritual ob- served during the performance of that ceremony. He also did not say to the police that
accused No. 1 had asked him to commit the murders. Neither to the police nor in his state- ment
recorded under s. 164 of the Code of Criminal Procedure did he say that he had gone to accused
No.1's house on the morning following the first murder and that She had told him that since the
treasure trove was not found another murder should be committed. The statement attributed by
Shankar to accused No. 1 that menstrual blood was required for sacri- fice is also conspicuous by its
absence in his police state- ment. These significant omissions are in the nature of contradictions
because not only do they pertain to a very vital aspect of the case against accused Nos. 1 and 2, but
they are of such a nature that the story told by Shankar to the police and under s. 164- of the Code of
Criminal Proce- dure, cannot sensibly stand along with what he told the Court in regard to the part
played by accused Nos. 1 and 2. It is true that Shanker was under a higher obligation while deposing
in the Court because as a condition of the pardon tendered to him he had to disclose the whole truth
to the Court. But while assessing the value of Shankar's. evidence in so far as he implicates accused
Nos. 1 and 2 we find it impossible to overlook the studied improvements which he made to involve
them. Such gross departure from the earliest versions makes the story of conspiracy suspect and
uninspir- ing. All the same, we may examine the argument advanced before us by the learned
counsel for the State that Shan- kar's evidence against accused Nos. 1 and 2 is corroborated in
material particulars and should therefore be accepted. For affording corroboration to Shankar's
evidence reli- ance is placed on the evidence of four witnesses--Laxman (P.W. 19), Sakharam (P.W.
29), Ramchandra (P.W. 30) and Kachru (P.W. 34)..
We see nothing in the evidence of these witnesses which can lend corroboration to the approver's
story, that accused Nos. 1 and 2 conspired to commit the murders or that they asked Shankar and
accused No. 3 to do so or that the blood of victims was handed over to either of them, or that any
Puja was performed after the commission of murders. Laxman says nothing about the treasure
trove, Sakharam merely carried the errand to Ganpat, Ramchandra was mauled by the police who
pulled out Iris pig-tail and the quack called Kachru only prescribed a medicine for accused, No.1's
meno- pause.
Nor indeed is the evidence of P.Ws. 20, 21 and 51 of any assistance in the matter of corroboration.
They merely say that Ganpat was eking his livelihood by prescribing Mantras and medicines, which
takes one nowhere near corroborative factors for implicating accused Nos. 1 and 2.
The recovery of Ganpat's satchel. containing charms and herbs, trader the Panchnama Ex. 130A,
also proves nothing beyond showing that Ganpat was equipped with a quack's repertoire.
One of the strongest arguments made by Mr. Desai on behalf of the State was that accused Nos. 1
and 2 stood to gain by the commission of the murders and that would afford corroboration to their
participation in the conspiracy. Motive may conceivably furnish the necessary corroboration, but we
are unable to see any independent evidence on the record regarding the treasure trove theory.
Scrapings were taken from Munjaba's image and samples of earth were also taken from the place
where Munjaba is alleged to have been propitiated with the blood of the victims. If Puja was really
performed in the manner described by Shankar, it is strange that no blood stains should have beenDagdu & Others Etc vs State Of Maharashtra on 19 April, 1977

found anywhere near the Pimpal tree. There is also no evidence at all to show that any attempt was
made by accused Nos. 1 and 2 to discover the treasure, as for example, by digging. These
circumstances cast a serious doubt on the theory that ac- cused Nos. 1 and 2 were trying to locate the
treasure trove. The fact that accused No. 3 is a servant of accused No. 2 cannot by itself be sufficient
to connect accused No. 2 with the crime charged.
The last circumstance on which prosecution relies to. connect accused Nos. 1 and 2 with the crime is
the confes- sion, Ex. 108, made by accused No. 1 Rukhmam. That confes- sion was recorded by a
Sub-Divisional Magistrate, Devidas Sakharam Pawar, P.W. 23. Later, we will have a great deal to say
about the various confessions recorded by this learned Magistrate but in so far as the confession of
ac- cused No. 1 is concerned it is enough to point out that it is entirely exculpatory and can,
therefore, serve no useful purpose. Besides, the confession was retracted by accused No. 1.
Along with these considerations is the circumstance that the High Court has acquitted accused Nos.
1 and 2 after a fair examination of the material relied upon by the prosecu- tion as against them. The
various reasons given by us would so that there is no justification for interfering with the conclusion
to which the High Court has come. The acquittal of accused Nos. 1 and 2 has, therefore, to be
confirmed. It would now be convenient to take up the ease of ac- cused No. 3, Sopan Rambhau
Salve. The allegation against him is that he and the approver Shankar committed the murder of
Gayabai on November 14, 1972, of Shakila on December 9, 1972, of Sugandhabai on February 21,
1973 and of Nasima on April 13, 1973. There is no eyewitness to any of these four murders but for
establishing the charge against accused No. 3, the prosecution relies on the evidence of the two
approv- ers Ganpat (P.W. 1) and Shankar (P.W.2), the discovery of article 17 by accused No. 3, the
discovery of articles 18 and 19 by approver Shankar, the seizure of articles 20 and 21 from the house
of accused No. 1 and lastly the retracted confession of accused No. 3 himself. We have already dealt
with the evidence of the approvers while considering the case against accused Nos. 1 and 2 and we
have given our reasons for discarding Ganpat's evidence outright. In regard to Shankar's evidence
we have taken the view that though he is a reliable witness, his evidence cannot be acted upon unless
it is corroborated in material particulars. Shankar and accused No. 3 were in the employment of
accused No. 2. After describing the 'Shakun' ceremony which was performed for ascertaining the
desire of the deity, Shankar deposes that he and accused No. 3 were commissioned to commit the
murders of virgin girls. Shankar, after some hesitation, agreed to do so on the promise that accused
Nos. 1 and 2 will,give to him and accused No.3 a share in the treasure trove.
Accused No. 3, according to Shankar, lured Gayabai, Shakila and Nasima to secluded spots., where
upon Shankar gagged and throttled them. Accused No. 3 facilitated the murders by holding the legs
of victims which also helped Shankar to collect blood from their private parts after causing cuts
thereon. Accused No. 3 played a more signifi- cant role in the murder of Sugandabhai by axing her
to death.
Shankar's evidence is amply corroborated as regards the broad outlines of the story narrated by him.
But that is not enough. We must see whether his evidence receives corrobo- ration from an
independent source and in material particu- lars, so as to fasten the guilt on accused No. 3. The first
circumstance which is said to corroborate the evidence of the approver is the discovery of 27 piecesDagdu & Others Etc vs State Of Maharashtra on 19 April, 1977

of shirt, which are collectively marked as article 17. The panchanama of discovery (Ex. 127) is dated
January 2, 1974 and is proved by the Pancha Vithalrai Takankhar (P.W.
27). The report of the serologist which is at Ex. 312 shows that there were several blood stains on the
shirt pieces ranging from 0.1 cm. to 0.5 cm. in diameter, all of 'A' group. Gayabai's blood also
belonged to 'A' group. Mr. Bhonde who appears for accused No. 3 has, subjected the evidence of
discovery to a searching criticism which at first blush seems plausible but which does not bear close
scrutiny. The argument that the panchanama of discovery does not attribute to accused No,. 3 the
authorship of concealment has the simple answer that the English transla- tion of the Marathi
panchanama is incorrect. The original document expressly states that accused No. 3 agreed to point
out the place where. he had kept the shirt pieces. The evidence of the Panch (P.W. 27) and of Dy.
S.P. Waghmare (P. W. 96) is. to. the same effect. In the absence of any effective cross-examination
of these witnesses, we see no substance in the contention that accused NO. 3's father, who was
standing near the hut, should have been examined as a witness.
It is urged that it is highly unlikely that accused No. 3 will preserve the tell-tale evidence of the
crimes in the manner alleged by the prosecution. Why the accused chose to do this is difficult to
know but we are not examining the evidence in the case as a Court of first instance.. The evidence in
regard to the discovery is accepted as unexcep- tionable by the Sessions Court as well as the High
Court and we are unable to characterise that view of the matter as preverse or against the weight of
evidence. The recovery of art. 17 thus afford material corroboration to the part played by accused
No. 3, at least in Gayabal, s murder. The discovery of the blade (art. 18) and the undervest (art. 19)
at the instance of the approver affords no cor- roboration as against accused No. 3. Nor indeed can
the recovery of the bowl (art. 20) and the bottle (art. 21) from the house of accused No. 1 connect
accused No.. 3 with the crime. These are articles of common use and no blood was detected thereon.
What remains to be considered is the retracted con- fession accused No. 3, which is Ex. 106. While
on this question, we would like to deal with all the confessional statements recorded in the case so
that it will not be necessary to revert to. the question time and again. As many as eight confessions
were recorded in the case, the confessing accused, apart from the two approvers, being accused Nos.
1, 3, 4, 5, 6, and 12. The approvers, Ganpat and Shankar, stuck to their confessions while all others
retracted theirs.
Section 24 of the Evidence Act makes a confessional statement irrelevant in a criminal proceeding if
the making thereof appears to have been caused by any inducement, threat or promise, having
reference to the charge against the accused, proceeding from a person in authority and sufficient to
give the accused grounds which would appear to him reasonable for supposing that by making the
confes- sion he would gain any advantage or avoid any evil of a temporal nature in reference to the
proceedings against him. Section 163 of the Criminal Procedure Code bars a Police Officer or any
person in authority from offering or causing to be offered any inducement, threat or promise as is
referred to in s. 24 of the Indian Evidence Act. Section 164 of the Code prescribes the mode of
recording confession- al statements. Acting under s. 554 of the Criminal Proce- dure Code, 1898, the
High Court of Bombay had framed in- structions for the guidance of Magistrates while recording
confessional statements. Those instructions are contained in Chapter I, Paragraph 18, of theDagdu & Others Etc vs State Of Maharashtra on 19 April, 1977

Criminal Manual 1960, of the Bombay High Court. The instructions require the Magistrate
recording a confession to ascertain from the accused whether the accused is making the confessional
statement voluntarily and to find whether what the accused desires to state appears to be true. The
instructions prescribe a form in. which the. confessional statement has to be recorded. Similar
circulars or instructions have been issued by the various High Courts in India and their impor- tance
has been recognised by this Court in Sarwan Singh v. State of Punjab(1) in which it was said that the
instruc- tions issued by the High Courts must be followed by the Magistrates while recording
confessional statements. [1957] S.C.R. 953 All of the eight confessions were recorded in this case by
a Sub Divisional Magistrate, Devidas Sakharam Pawar (P. W. 23), whose evidence leaves no room
for doubt that he was blissfully unaware of the stringent responsibilities east by law on Magistrates.
who. are called upon to record confes- sions. He made no effort to ascertain from any of the accused
whether he or she was making the confession volun- tarily. He did not ask any of the accused
whether the police had offered or promised any incentive for making the confessional statement nor
did he ascertain for how long the confessing accused was in police custody prior to. his production
for recording the confession nor indeed did he maintain any record to show where the accused were
sent after they were given time for reflection. One of the glaring infirmities from which the
confessional statements of the various accused suffer is that none of those state- ments contain a
memorandum as required by s. 164 of the Code that the Magistrate believed that the "confession
was volun- tarily made". It is also clear that when the various ac- cused were produced before the
Magistrate after the time for reflection was over, he asked no further questions and recorded the
confessions. mechanically for the mere reason that the accused expressed their willingness to
confess. The Magistrate was either overcome by the sensation which the case had aroused in
Maharashtra or perhaps he blindly trusted the high police officers who were frantically look- ing out
for a clue to these mysterious murders. They pro- duced the accused for recording the confessions
and the Magistrate thought that the mere production of the accused was guarantee enough of their
willingness to confess. Learned counsel appearing for the State is right that the failure to comply
with s. 164(3), Criminal Procedure Code, or with the High Court Circulars will not render the
confessions inadmissible in evidence. Relevancy and admis- sibility of evidence have to be
determined in accordance with the provisions of the Evidence Act. Section 29 of that Act lays down
that if a confession is otherwise. relevant it does not become irrelevant merely because, inter alia,
the accused was not warned that he was not bound to make it and the evidence of it might be given
against him. If, there- fore, a confession does not violate any one of the condi- tions operative under
ss. 24 to 28 of the Evidence Act, it will be admissible in evidence. But as in respect of any other
admissible evidence, oral or documentary, so in the case of confessional statements which are
otherwise admissi- ble, the Court has still to consider whether they can be accepted as true.. If the
facts and circumstances surround- ing the making of a confession appear to. cast a doubt on the
veracity or voluntariness of the confession, the Court may refuse to act upon the confess;on even if it
is admissible in evidence. That shows how important it is for the Magistrate who. records the
confession to satisfy him- self by appropriate questioning of the confessing accused, that the
confession is true and voluntary. A strict and faithful compliance with s. 164 of the Code and with
the instructions issued by the High Court affords in a Large measure the guarantee that the
confession is voluntary. The failure to observe the safeguards prescribed therein are in practice
calculated to impair the evidentiary value of the confessional statements.Dagdu & Others Etc vs State Of Maharashtra on 19 April, 1977

Considering the circumstances leading to the procession- al recording of the eight confessions and
the abject disre- gard, by the Magistrate, of the provisions contained in s. 164 of the Code and of the
instructions issued by the High Court, we are of the opinion that no reliance can be placed on any of
the confessions. Apart from the confessions of the two approvers, all others were retracted, which
further cripples their evidentiary value.
Since the evidence of the approver Shankar is corrobo- rated in material particulars by the discovery
of article 17, there is no valid reason for departing from the concur- rent view of the High Court and
the Sessions Court that the complicity of accused No. 3. in the four murders is proved beyond a
reasonable doubt. As the charge of conspir- acy fails, the High Court was right in convicting accused
No. 3 under s. 302 read with s. 34 of the Penal Code only. That leaves the case of accused Nos. 9 to
12 for consid- eration,. being the subject-matter of Criminal Appeal No. 437 of 1976 filed by them.
The charge against these accused is that in furtherance of conspiracy and in pursuance of their
common intention they, on January 4, 1974, committed the murders of Haribai, aged 35 years, her
daughter Taramati aged 9 years, and her infant child Kamal aged 1-1/2 years. The Sessions Court
convicted these accused under s. 302 read with ss. 120B and 34 of the Penal Code and sentenced
them to life imprisonment. The charge of conspiracy having failed before the High Court and the
main co-conspirators, accused Nos. 1 and 2, having been acquitted, the High Court convict- ed these
accused under s. 302 read with s. 34 only. But, accepting the appeal flied by the State, the High
Court enhanced their sentence from life imprisonment to death. The evidence against accused Nos.
9 to 12 consists of :
(1) The: eye-witness account of Umaji Limbaji, Pitale (P.W.
31); (2) Discoveries effected in pursuance of statements made by the accused; (3)
Injuries on accused No. 10; (4) The evidence in regard to the movements of the
accused at or about the time when the murders were committed and (5) the
confession of accused N6. 12.
Umaji was working as. an agricultural servant with one Balabhau Lad on a daily wage of Rs. 3/-. On
January 4, 1974 while he was on his way to one of the lands of his master, he first met accused No.
10 and then accused Nos. 9 and 11, and had some conversation with accused No. 10. At about the
same time, he saw Haribai carrying her infant child in her arms, and a basket of food on her head.
Her other daughter Taramati was walking behind her. Umaji climbed the Mala, which is a raised
platform from which crops are generally watched, and soon thereafter he heard the shrieks of a
child. Turning in the direction from which the shrieks came, he saw accused No. 10 holding Haribai
from behind by her waist and accused No.9 giving an axe blow on her head. Almost simultaneously,
Umaji saw accused No. 12 holding Taramati from behind and accused No. 11 giving an axe blow on
her head. Feeling nervous and fearful, jumped down from the Maid, tethered his horse in his
master's land, went by a bus to the Manwat Road Railway Station, took a train to Ranjani and from
there proceeded to the village of Iregaon where his maternal uncle Mathaji lived. After staying at
Iregaon for about four days, Umaji went back to his master's house at Manwar when a police
constable took him to. the Police Station, where a Police Officer recorded his state- ment.Dagdu & Others Etc vs State Of Maharashtra on 19 April, 1977

Umaji's evidence having been concurrently accepted by the Sessions Court and the High Court, we
do. not propose to undertake a fresh reappraisal of that evidence except to the extent to which the
view of the Courts below is contrary to the weight of the record or is otherwise such as is impossi-
ble in the context to sustain. On a careful consideration of Mr. Narayan's closely reasoned
submissions, we have formed the conclusion, which does not materially differ from that of the two
Courts, that Umaji's evidence cannot be accepted without adequate corroboration. Our reasons for
taking this view are briefly these: Fear and pame may account for the fact that the witness did not
raise an alarm. But there is no reasonable explanation why, having had the presence mind to tether
back the horse, he did not see his master. Then again, he sojourned from the scene of offence to
Iregaon but spoke to none. At Iregaon, which was far removed from the scene of Manwat murders,
he holidayed with his uncle for four days but even on being questioned as to the purpose of his visit,
he made no an- swer. After returning to Manwat he saw his master but told him nothing. His
statement was recorded by the police after two days of close interrogation.
In regard to accused No. 9, there are two circumstances which afford reliable corroboration to
Umaji's evidence. On January 11, 1974 accused No. 9 made a statement leading to the discovery of
an axe blade, article 160, from his house. The panchnama of recovery is Ex. 91-A which is proved by
the Panch Sheikh Imam (P.W. 11 ). It shows that accused No. 9 took out an axe blade from below a
piece of wood lying behind a cupboard in his house. The report of the Serolo- gist, Ex. 267, shows
that the axe blade was stained with human blood of 'A' group. The blood of the deceased Haribai
belonged to the same group. Accused No. 9 admitted in his examination that he had produced the
axe blade and that it was stained with blood but he sought to explain the blood stains by saying that
his wife had sustained an injury while hewing wood with the axe. That is a flimsy explanation
because were it true, it is difficult to understand why such great care was taken to conceal the axe
blade. On January 21.1974- a burnt shirt piece, article 170, was recovered in consequence of
information given by accused No. 9. The Panchnama, Ex. 87-A, and the evidence of the Panch
Munjaba (P.W. 25) show that the accused dug out the shirt piece from under a heap of earth lying
inside his house. Article 170 was found by the Sessions Judge to fit squarely with the shirt sleeve,
article 112, which was found at the place of occurrence near Haribai's dead body. The report of the
Chemical Analyser at Ex.271 shows that arti- cles 112 and 170 bore' identical textile and
physiochemical characteristics.
In our opinion, the courts below were justified in relying upon these corroborative circumstances to
connect accused No. 9 with the murder of Haribai.
Turning to accused No. 10, an axe handle, article 169, was recovered at his instance on January 17,
1974. The Panchanama, Ex. 86-A, and the evidence of the Panch Mohd. Yusuf Bade Khan (P.W. 10)
show that the axe handle was. recovered from below a thorny fence in the Pardhi Wada locality. The
report of the serologist, Ex.267, shows that there was human blood on the axe but the group of, the
blood could not be determined. It is not possible to accept the submission of Mr. Narayan that the
axe handle was recov- ered from a place which was easily accessible to the public because the handle
was taken out after making quite some efforts to locate it. Accused No. 10 was the author of its
concealment.Dagdu & Others Etc vs State Of Maharashtra on 19 April, 1977

On January 8, 1974 when accused No. 10 was arrested a turban, bush-shirt and dhoti (articles 150 to
1.52) were seized from his person. The serologist's report, Ex.267, shows that human blood was
detected on the bush-shirt and the dhoti. The blood-stain. on the shirt was 0.5 cm in diameter and
the blood detected on the bush-shirt and the dhoti belonged to 'A' group. Accused No. 10 admitted
in his examination that the shirt and the dhoti were blood-stained but he offered an unconvincing
explanation that a child of his had bled from the nose, The evidence of Dr. Salunke (P.W. 48) who
examined accused No. 10 on the date of his arrest shows that he had four injuries on his person, the
certificate in regard to, which is Ex. 174. Injuries Nos. 1 and 2 were interrupted abrasions which in
the opinion of Dr. Salunke could be caused by teeth-bite. That fits in with 'the part played by
accused No. 10, who according to Umaji's evidence, had held Haribai from behind by her waist.
Evidently, Haribai strug- gled to release herself in a frantic attempt to save her life she caused the
injuries to accused No. 10. We agree with the view taken by both the Courts that the discovery of the
blood-stained axe-handle, the seizure of clothes stained with 'A' group blood and the teeth-bite
injuries afford adequate corroboration to Umaji's evidence regarding the part played by accused No.
10, in the murder of Haribai.
As regards accused No. 11, an axe-blade (article. 167) was recovered in consequence of information
supplied by him. The Panchanama, Ex. 84-A, and the evidence of the Panch Mohd. Yusuf Bade
Khan. (P.W. 10) show that accused No.11 led the police party and the panchas to a water tap in the
Pardhi Wada locality and dug out the axe blade which was lying buried under a stone. The report of
the Serologist, Ex. 269, shows that human blood of 'A' group' was detected on the axe blade.
Taramati, according to Umaji's evidence, was assaulted with an axe by accused No. 11. Her clothes,
articles 142 and 143, were found to be stained with human blood of 'A' group.. We see no infirmity in
the Pancha's evidence and no substance in the counsel's contention that the discovery of the
axe-blade was foisted on the accused.
The discovery of the axe blade stained with human blood of 'A' group sufficiently corroborates the
evidence of Umaji as regards the part played by accused No. 11 in Taramati's murder.
Before considering the case of accused No. 12, we would like to point out that there is satisfactory
evidence to show the presence of accused Nos. 9 to 11 at or near the scene of offence some time
before the incident. Dagdu (P.W.
5), Bhanudas (P.W. 14), Sitaram (P.W. 16), Narayan (P.W.
17), Baliram (P.W. 18) and Santram (P.W. 24) have deposed about the same either in regard to all of
these accused or some of them. Their evidence has been examined with gear care by the learned
Sessions Judge and we agree with his assessment that except for Sant Ram, the other witnesses can
be relied up.on for affording corroboration to Umaji's evidence.
That leaves the case of accused No. 12 for considera- tion. It is alleged that he held Taramati from
behind whereupon accused No. 11 gave axe-blows on her head. Tara- mati was just a girl of 9 and the
allegation that accused No. 12 had to hold her from behind to enable accused No. 11 to assault her
with an axe sounds inherently incredible. 1t is significant that some time before the occurrence,Dagdu & Others Etc vs State Of Maharashtra on 19 April, 1977

Umaji met accused Nos. 9,10 and 11 near the scene of offence but not accused No. 12. The
importance of this circumstance is twofold: Firstly that accused No. 12 was not in the company of
the other three at or about the time of the incident and secondly that Umaji's identification of the
person who held Taramati, namely accused No. 12, becomes somewhat infirm. There was standing
crop about five feet high between the Mala where Umaji was standing and the place where Taramati
was held. Besides, the spot where Taramati was done to death was in a depression, which would
further affect the witness's ability to. identify the person who. had held Taramati. After all, Umaji
had but a fleeting glimpse of the incident and the chance of an error in identifying accused No. 12,
who w.as not seen earlier in the company of accused Nos. 9 to 11, cannot fairly be excluded. All the
same, since Umaji has no particular reason to implicate accused No. 12 falsely and since the Courts
below have concurrently accepted his evidence in regard to accused No. 12 also, we must examine
carefully the strenuous submission made by Mr. Desai for the State that even as regards accused No.
12, Umaji's evidence is sufficiently corroborated.
That corroboration consists of the discovery of. an axe-handle, article 168, from the house of
accused No. 12 on January 17 1974. The Panchanama of recovery is Ex. 85-A which is proved by the
Panch Mohd. Yusuf Bade Khan, P.W.
10. It is alleged that the axe-handle was produced by accused No. 12 from below the tin-sheet roof of
his house in Pardhi Wada. The report of the serologist, Ex. 269, says that there was human blood of
'A' group on the axehandle. We find it impossible to place any. reliance on the discovery of the
axe-handle for the following reasons:
Though accused No. 12 was arrested on January 11, 1974 his house was searched on
January 7, 1974 in connection with the murders of Haribai and her daughters which
had taken place on January 4, 1974. That search is borne out by the Panchanama, Ex.
221. On January 6, 1974 accused No. 12 figured in an identifica- tion parade which
was arranged in order to ascertain if the Dog squad could afford assistance in fixing
the identity of the culprits. The evidence of the Senior Dog Master, Ram- chandra
(P.W. 52), shows that a female dog called Mala sniffed her suspicion at accused No.
12. With the clue provided by the Dog Squad on the 6th, the house of accused No. 12
was searched on the 7th. That house consists of one room only. The Panchanama
shows that the axe-handle was not in any manner concealed under the tin-sheet. It
was lying openly, visible to the naked eye, so that he who cared could easily see it. It
is then strange that it was not found on the 7th itself. There is also a serious dis-
crepancy in the evidence of the two Panehas, Mohd. Yusuf, P.W. 10, and Sheikh
Imam, P.W. 11, regarding the discovery. Whereas according to the former, accused
No. 12 said that he had concealed the axe,handle below the tin-sheet of the roof,
according to the latter the information which accused No. 12 gave was that he had
kept the handle below a stone inside his house. Coupled with the circumstance which
emerges from the evidence of Panch Sheikh Imam that there is no door to the room
from which the axe-handle was pro- duced, the evidence in regard to. the recovery of
the axe- handle becomes manifestly suspect. These infirmities in the recovery of the
axe-handle failed to evoke the attention of the High Court. The Sessions Court tooDagdu & Others Etc vs State Of Maharashtra on 19 April, 1977

missed their impact on the point at issue.
The seizure of a blood-stained' Dhoti from the person of accused No. 12 at the time of
h,is arrest, even if the blood belonged to 'A' group, is not of a kind which, in the
context of the various circumstances referred to above, can be accepted as safely of
sufficiently corroborative of Umaji's evidence. This is particularly so because, at the
very threshold, it is doubtful if Umaji could identify accused No. 12.
The evidence regarding the presence of accused No. 12 in the fields roundabout the
scene of offence on the after- noon of the day of incident cannot connect him with the
crime. And the retracted confession of the accused, like its counterparts, has to be
excluded from consideration altogether because of the cavalier fashion in which the
Sub-Divisional Magistrate recorded the various confessions. Accused No. 12 is thus
entitled to an acquittal for the reason that the prosecution has failed to prove its case
against him beyond a reasonable doubt.
Learned counsel for accused Nos. 3, 9, 10 and 11 whose conviction under s. 302 read
with s. 34 has been affirmed by us and who stand sentenced to death, contend that
the ac- cused were not heard on the question of sentence and there- fore the sentence
is not according to law. It is urged that we should remand the appeal of accused Nos.
9, 10 and 11 to the High Court which sentenced them to death, and accused No. 3's
appeal to the Sessions Court which sentenced him to death, in order to enable these
accused to make their contentions as to why they should not be sen- tenced to death
even though they have been convicted under s. 302 of the Penal Code. In support of
this argument reliance is placed on a decision of this Court in Santa Singh v. State of
Punjab(1).
In Santa Singh(1), the Sessions Judge, after pronouncing the judgment convicting the
appellant for a double murder, did not give him opportunity to be heard on the
question of sentence. He pronounced the appellant guilty of murder and, as a part of
a single judgment, imposed the sentence of death. The High Court confirmed the
conviction and the sentence of death. In appeal, it was held by this Court (Bhagwati
and Fazal Ali, JJ) that the provisions of s. 235 of the Code of Criminal Procedure,
1973, which are clear and explicit, require that the Court must in the first instance
deliver a judgment of acquitting the accused and if the accused be convicted, he must
be given an opportunity to be heard in regard to the sentence. Holding that the provi-
sions of s. 235 are mandatory in character, the Court set aside the sentence of death
and remanded the case to. the Sessions Court with the direction that it should pass an
appropriate sentence after giving to the appellant an oppor- tunity to be heard on the
question of sentence.
Section 235 of the Criminal Procedure Code, 1973 reads thus:Dagdu & Others Etc vs State Of Maharashtra on 19 April, 1977

"235(1) After heating arguments and points of law (if any), the Judge shall give a
judgment in the case.
(2). If the accused is convicted, the Judge shall, unless he proceeds in accordance
with the provisions of Section 360, hear the accused on the question of sentence, and
then pass sentence on him according to law."
The imperative language of sub-section (2) leaves no. room for doubt that after recording the
finding of guilt and the order of conviction, the Court is under an obligation to hear the accused on
the question of sentence unless it releases him on probation of good conduct or after admo- nition
under s. 360. The right to be heard on the question of sentence has a beneficial purpose, for a variety
of facts and considerations bearing on the sentence can, in the exercise of that right, be placed
before the Court which the accused, prior to the enactment of the Code of 1973, had no. opportunity
to do. The social compulsions, the pressure of poverty, the retributive instinct to seek an extra-legal
remedy to a sense of being wronged, the lack of means to be educated in the difficult art of an honest
living, the parentage, the heredity--all these and similar other con- siderations can, hopefully and
legitimately, tilt the scales on the propriety of sentence. The mandate of s. 235(2) must, therefore, be
obeyed in its letter and spirit. (1) [1976] 4 S.C.C. 190.
But we are unable to read the judgment in Santa Singh (supra) as laying down that the failure on the
part of the Court, which convicts an accused, to 'hear him on the ques- tion of sentence must
necessarily entail a remand to that Court in order to afford to the accused an opportunity to. be
heard on the question of sentence. The Court, on con- victing an accused, must unquestionably hear
him on the question of sentence. But if, for any reason, it omits to do so and the accused makes a
grievance of it in the higher court, it would be open to that Court to remedy the breach by giving a
hearing to the accused on the question of sen- tence. That opportunity has to be real and effective,
which means that the accused must be permitted to adduce before the Court all the data which he
desires to adduce on the question of sentence. The accused may exercise that right either by
instructing his counsel to make oral submissions to the Court or he may, on affidavit or otherwise,
place in writing before the Court whatever he desires to place before it on the question of sentence.
The Court may, in appropri- ate cases, have to adjourn the matter in order to give to the accused
sufficient time to produce the necessary data and to make his contentions on the question of
sentence. That, perhaps, must inevitably happen where the conviction is recorded for the first time
by a higher court. Bhagwati J. has observed in his judgment that care ought to be taken to ensure
that the opportunity of a hearing on the question of sentence is not abused and turned into an
instrument for unduly protracting the proceedings. The material on which the accused proposes to
rely may there- fore, according to the learned Judge, be placed before the Court by means of an
affidavit. Fazal Ali, J., also ob- serves that the courts must be vigilant to exercise proper control over
their proceedings, that the accused must not be permitted to adopt dilatory tactics under the cover
of the new right and that what s. 235(2) contemplates is a short and simple opportunity to place the
necessary material before the Court. These observations show that for a proper and effective
implementation of the provision contained in s. 235(2), it is not always necessary to remand the
matter to the court which has recorded the conviction. The fact that in Santa Singh (supra) this
Court remanded the matter to the Sessions Court does not spell out ratio of the judgment to be thatDagdu & Others Etc vs State Of Maharashtra on 19 April, 1977

in every such case there has to be a remand. Remand is an exception, not the rule, and ought
therefore to be avoided as far as possible in the interests of expeditious, though fair disposal of
cases. After counsel for accused Nos. 3, 9, 10 and 11 raised an objection before us that the sentence
of death was imposed upon the accused without hearing them as required by s. 235(2) of the code,
we granted to them liberty to produce before us such material as they desired and to make such
contentions as they thought necessary on the question of sentence. Accordingly, counsel made their
oral submissions before us on the question of sentence and they also flied the relevant material
before us showing why we should not uphold the death sentence imposed on the accused.
That takes us to the question of sentence. For the offence under s. 302, it is no longer obligatory to
impose the sentence of death. Prior to the amendment of s. 367(5) of the Code of Criminal
Procedure, 1898 by Act 26 of 1955, the normal sentence for murder was death and the Court had to
record its reasons for imposing the lesser sentence of life imprisonment. The obligation to record
reasons for imposing the lesser penalty was deleted by Act 26 of 1955, so that Courts became free to
award either the sentence of life imprisonment or the sentence of death, depending on the
circumstances of each individual case. Section 354(3) of the Code of 1973 provides that when the
conviction is for an offence punishable with death or, in the alternative, with imprisonment for life
or imprisonment for a term of years, the judgment shall state the reasons for the sentence award-
ed, and in the case of sentence of death, the special rea- sons for awarding that sentence. The
legislative history of the sentencing provisions and the explicit language of s. 354(3) show that
capital punishment can be awarded for the offence of murder, only if there are special reasons for
doing so. All murders are inhuman, some only more so than others.
Having considered the matter in all its aspects--penal, juristic and sociological--and having given
our most anxious consideration to the problem, we are of the opinion that accused Nos. 3, 9, 10 and
11 deserve the extreme penalty of law and that there is no justification for interfering with the
sentence of death imposed upon them.
Accused No. 3 put an end to four innocent lives, three small girls ten years of age and a woman in
her thirties. Accused Nos. 10 and 11 committed the murders of Haribai, her nine- year old daughter
and her infant child. The victims had given no cause for the' atrocities perpetrated on them. They
were killed as a child kills flies. And the brutality accompanying the manner of killing defies an
adequate description. The luring of small girls, the gagging, the cutting of their private parts, the
ruthless defiling in order to prevent identification of the victims and the mysterious motive for the
murders call for but one sentence. Nothing short of the death sentence can atone for such callous
and calculated transgression of law. Morbid pity can have no place in the assessment of murders
which, in many respects. will remain unparalleled in the annals of crime. Accordingly, we confirm
the death sentence imposed on accused Nos. 3, 9, 10 and 11.
The overall result is as follows:
(1 ) We uphold the acquittal of accused Nos. 1 and 2 and dismiss Criminal Appeal No.
441 of 1976 filed by the State of Maharashtra.Dagdu & Others Etc vs State Of Maharashtra on 19 April, 1977

Both the two Accused who are in jail shall be released.
(2) We uphold the conviction of ac-
cused No. 3 under s.. 302 read with S. 34 of the Penal Code and the sentence Of death imposed upon
him. Criminal Appeal No. 1438 of 1976 filed by him is accordingly dismissed (3) We uphold the
conviction of accused Nos. 9, 10 and 11 under s. 302 read with s. 34 of the Penal Code and
3--707SCI/77 the sentence of death imposed upon them. We acquit accused No 12 by giving him the
benefit of doubt and direct that he shall be released. Criminal Appeal No.437 of 1976 filed by ac-
cused Nos. 9 to 12 thus succeeds partly in so far as accused No. 12 is concerned and fails in so far as
accused Nos. 9, 10 and 11 are concerned.
Before concluding, we would like to make a few observa- tions concerning the detection and
investigation of these crimes. It is a matter of grave concern that the police were not able to obtain
any clue whatsoever to the numerous murders which were committed so systematically in the small
village of Manwat. The spate of those atrocities commenced with the murder of Gayabai on
November 14, 1972 and ended with the murders of Haribai and her two daughters on January 4,,
1974. All along, a strong patrol of policemen was keep- ing vigil in the very locality in which most of
the murders were committed. The evidence of Dy. S.P. Waghmare shows that apart from the mobile
police, fixed post patrols were deputed to keep a close watch on the activities of all and sundry in the
area which was chosen by the murderers for their criminal activities. Haribai and her daughters
were murdered under the very nose of the policemen. Quite a few of them were on duty a few
hundred yards away from the scene of occurrence and yet the culprits could escape with impuni- ty.
And it is astonishing that when the three dead bodies were lying in close proximity, the police with
their trained hawk-sight could see only one. All this hardly does any credit to the efficiency and
watchfulness of a system which in Maharashtra has won many encomiums. Eventually Provi- dence,
and perhaps the police, persuaded Samindrabhai Pawar, accused No. 4, to make a confessional
statement on December 28, 1973 and the wheels of a baffled machine started moving fast.
It would perhaps have been more conducive to greater efficiency if an unduly large number of senior
police offi- cers were not commissioned for the investigational work..No one seems to have assumed
an overall responsibility for investigation and so many of them working together spoiled the broth
like so many cooks.
It is plain common-sense that suspects are seldom will- ing to furnish a quick and correct clue to the
crimes for which they are arrested. A certain amount of coaxing and promising has inevitably to be
done in order to persuade the accused to disclose at least the outlines of the crime. But the use of
strong methods of investigation, apart from raising problems concerning the observance of decency
in public affairs and of human dignity, is fraught with the danger that the very process by which
evidence is collected may become suspect and fail to inspire confidence. Ganpat, the approver, was
driven to admit that he was tortured while in the lock-up and we have serious doubts whether the
injury caused on his head was, as alleged by the police, self- inflicted. A witness called Ramchandra
also admitted that while under interrotation the police pulled out his pig-tail We have resisted theDagdu & Others Etc vs State Of Maharashtra on 19 April, 1977

failing which tempts even judicially trained minds to revolt against such methods and throw the
entire case out of hand. But we must with hopes for the future, utter a word of warning that just as
crime does not pay so shall it not pay to resort to torture of suspects and witnesses during the course
of investigation. History shows that misuse of authority is a common human failing and, therefore,
Courts must guard against all excesses. The police, with their wide powers, are apt to overstep their
zeal to detect crimes and are tempted to use the strong arm against those who happen to fall under
their secluded juris- diction. That tendency and that temptation must, in the larger interests of
justice, be nipped in the bud. GOSWAMI, J.--I am in agreement with the judgment proposed by my
brother Chandrachud which is a piece of conspicuous clarity after marshalling and compressing a
mass of evi- dence. I also agree with the views expressed therein on the legal questions raised in
these appeals. Even so I feel obliged to add a few lines.
I would particularly emphasise that there is no mandatory direction for remanding any case in Santa
Singh v. The State of Punjab(1) nor is remand the inevitable recipe of section 235(2) Code of
Criminal Procedure, 1973. Whenever an appeal court finds that the mandate of section 235(2) Cr.
P.C. for a heating on sentence had not been complied with, it, at once, becomes the duty of the
appeal court to offer to the accused an adequate opportunity to produce before it whatev- er
materials he chooses in whatever reasonable way possible. Courts should avoid laws' delay and
necessarily inconsequen- tial remands when the accused can secure full benefit of section 235(2) Cr.
P.C. even in the appeal court, in the High Court or even in this Court. We have unanimously adopted
this very course in these appeals.
Treasure-trove legend survives generations. There had been many casualties in honest exploits to
the peaks of gold bars. Gold was not found So was treasure-trove not located in spite of the
notorious Manwat murders.
The gruesome story revealed in these cases beggars description of the limit of human credulity,
horrid avarice and unconcerned and heartless execution of evil ends. I am not on that. The final
curtain, so far as legal process goes is drawn.
Conviction in these cases does no credit to the police, nor to the hoodwinking demonstration of
flashy 'dog-squad'. Murders committed. one 'after the other in series, under the very nose of a
publicised ring of a camping platoon of police personnel widely cordoning the entire scene of occur-
rence for months with check-posts, for recording names of passers-by, may secure banner in
newspapers, but no laurels for the police.
But for the blazing lust for life of the confessing approvers supplying the infrastructure for the
prosecution case which, we find, is corroborated in material particulars by independent testimony
so far as some of the appellants are concerned, there is much more to be. desired in an investigation
of such awe-inspiring cases. The archaic attempt to. secure confessions by hook or by crook seems to
be the be all and end all of the (1) [1976] (4) SCC 190.
police investigation. The investigation does not reflect any imaginative drive on the part of the police
in a crime of this magnitude.Dagdu & Others Etc vs State Of Maharashtra on 19 April, 1977

To mention one item only, even Balabhau Lad, a close neighbouring relative of the deceased Haribai
and master of Umaji, the star witness against accused 9 to 12, has not been produced in this case to
corroborate the sudden and instant disappearance of Umaji for four days from the very scene of
murder, being his master's field, by leaving his horse tethered therein. Next having got blood stains
in the articles produced by the accused there was no attempt to ascertain the blood group of the
accused's family members. In fact accused No. 9 did tell the court that the blood stains in the exhibit
were from his wife's injury from the axe. Again, accused No. 10 said that the blood stains on the
exhibited clothes were from his child's bleeding nose. We have disbelieved the pleas of the accused
but that does not redound to the credit of the quality of the investiga- tion of these dastardly crimes.
It is distressing that when three murders took place on the 4th of January, 1974, and all the dead
bodies were lying at the same field, only one dead body was located and the other two. were not
traced until next morning. If the murderers could escape from the barricaded area in broad day light
by throwing dust in the eyes of the police, what would have happened if the other two dead bodies
were removed during the night beyond trace; ? Is this investigation with a 'dog-squad' at command ?
A dog is its master's voice. Did the police play the true master ?
The police. should remember that confession may not always be a short-cut to solution. Instead of
trying to "start" from a confession they should strive to "arrive" at it. Else, when they are busy on
this short route to suc- cess, good evidence may disappear due to inattention to the real clues. Once
a confession is obtained, there is often flagging of zeal for a full and thorough investigation with a
view to establish the case de hors the confession. It is often a sad experience to find that on the
confession, later, being inadmissible for one reason or other the case founders in court.
It is an irony that a Sub-Divisional Magistrate holding executive charge of a Sub-Division was
completely ignorant of the duties imposed on him under section 164, Code of Criminal Procedure
and we had to reject the confessions. Under the new Code such powers are exercised by a Metropoli-
tan or Judicial Magistrate. The pitfalls in recording confession may be so. disastrous that it may be
of immense value for the Magistrates to have some practical guidance from superior officers for
properly discharging their func- tion under section 164, Cr. P.C. Even after conclusion of the trial in
a heinous case of this magnitude, the police should be well-advised to pursue clues and for missing
links to unearth 'the yet undiscovered guilty ones and should not rest satisfied with 'the result of
these cases. There is yet room for a wider probe into men and matters in connection with these
ghastly crimes.
Counsel drew our attention to a very disquieting fea- ture in the attempt of the police to see that the
accused did not get the assistance of the local Bar. The suggestion has of course been denied by the
police officer. If there is any truth in this unholy move for denying proper defence to the accused, no
matter how heinous the offence, it is highly obnoxious to the notions of fair play and all that justice
stands for. Such ideas should be banished. I hasten to add that the accused before us could not have
been better defended as has been done by the three conscientious young counsel who impressed us
with their industry and ability.
P.H.P.Dagdu & Others Etc vs State Of Maharashtra on 19 April, 1977

