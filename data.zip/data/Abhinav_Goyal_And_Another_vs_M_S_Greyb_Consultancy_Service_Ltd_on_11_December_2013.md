Abhinav Goyal And Another vs M/S Greyb Consultancy Service
Ltd on 11 December, 2013
                     CRM-M-36473 of 2011 (O&M)                                   -1-
                      IN THE HIGH COURT OF PUNJAB AND HARYANA AT CHANDIGARH
                                                          CRM-M-36473 of 2011 (O&M)
                                                          Date of Decision : 11.12.2013
                     Abhinav Goyal and another                             ........Petitioners
                                                      Versus
                     M/s Greyb Consultancy Service Ltd.                   ...... Respondent
                     CORAM: HON'BLE MR. JUSTICE R.P. NAGRATH
                     1.        Whether Reporters of local papers may be allowed to see the
                               judgment?
                     2.        To be referred to the Reporters or not?
                     3.        Whether the judgment should be reported in the Digest?
                     Present:       Mr. Rohan Mittal, Advocate
                                    for Mr. Amit Aggarwal, Advocate
                                    for the petitioners.
                                    Mr. J.S. Bhatia, Advocate
                                    for the respondent.
                     R.P. NAGRATH, J.
Prayer in this petition is under Section 482 Cr.P.C. for quashing of complaint No. 107 dated
30.07.2010 (Annexure P-1) filed under Section 379, 406 read with Section 120-B of Indian Penal
Code (IPC) as well as Section 72 of Information Technology Act, 2000 and summoning order dated
16.10.2010 (Annexure P-3) and all the consequential proceedings.
2. Petitioner No. 2 was appointed as Senior Research Analyst and petitioner No. 1 the Research
Analyst on 08.09.2008 and 06.02.2008 respectively, by respondent-company.
                      CRM-M-36473 of 2011 (O&M)                                  -2-
                     3.          In   the   complaint   (Annexure   P-1)   filed      by   theAbhinav Goyal And Another vs M/S Greyb Consultancy Service Ltd on 11 December, 2013

respondent-company it was stated that the petitioners were involved in technical research on
various inventions of clients of the company and to get it patented. This process was highly
confidential. The petitioners were working for various other foreign clients of the company in the
area of research work on trademark, copyright as well as patent drafting and registration of new
inventions/products. Both the petitioners closely worked on various products including the project
plants and understanding clients requirements.
4. The respondent-company installed a data base costing about ` 1,75,000/- which was required for
research work. This was meant to be used exclusively by the employees of the company and research
work of the clients of respondent-company. Each employee had been given the user name and
password in order to operate the said data base. Similarly, petitioners were provided with secret
personal password so as to have access to said data base. Petitioners had signed a confidentiality
and invention agreement and as per clause 2.3 it was specifically agreed that petitioners will not
directly or indirectly use, make available, disclose, any invention discovery, copyright registration or
patent applications and other confidential information of the company which may be highly
prejudicial to the company and said improper disclosure of such trade secrets amounts to invasion
of privacy and cause loss to the company.
CRM-M-36473 of 2011 (O&M) -3-
5. After having access to the data base both the petitioners agreed to do an illegal act by illegal
means by hatching a criminal conspiracy and started downloading copies of extract of data,
computer data base information illegally and unauthorizedly in pen-drives and by transferring the
stolen data by e-mails for their own illegal use. They started theft of data base provided for their own
personal use and gain. While in service of the company they also floated their own company on
13.11.2009 in the name and style of "Stellarix Consultancy Services Pvt. Ltd." with registered office
at 275, Industrial Area, Phase-II, Chandigarh and thus committed breach of trust punishable under
Section 406 IPC. Said company was floated by them on the same pattern by committing theft of the
data base. Even the website of the company of petitioners was also showing similar services, what
the respondent-company was rendering.
6. When the above illegal act came to the notice of the respondent-company the petitioners
submitted resignations on 11.05.2010 and 14.01.2010 respectively. Since the respondent- company
was checking the theft and cheating committed by them, the resignation of petitioner No. 1 was kept
in abeyance. Respondent-company allegedly suffered a loss to the tune of ` 10 lacs as vital
information was leaked out and they illegally floated a rival competitor company by having access to
the electronic record, information and documentation of the company without its consent which is
also punishable under Section 72 of the Information CRM-M-36473 of 2011 (O&M) -4- Technology
Act, 2000.
7. After recording the statement of Deepak Sayal, Director of respondent-company who proved
certain documents on the file, learned Magistrate passed the impugned order of summoning under
Sections 378, 406 and 120-B of Indian Penal Code (IPC) as well as Section 72 of the Information
Technology Act, 2000.Abhinav Goyal And Another vs M/S Greyb Consultancy Service Ltd on 11 December, 2013

8. The impugned summoning order has been mainly challenged inter alia on the grounds; (i) that
petitioners are residing beyond the jurisdiction of learned Magistrate at Panchkula and therefore,
the order could not be passed without holding enquiry in terms of Section 202 (1) Cr.P.C.; (ii) that
there is non-compliance of provisions of Section 210 Cr.P.C. as on a complaint filed by the
respondent-company, the matter was investigated by the police and nothing was found against
them. It was further contended that the allegations in the complaint and the evidence led in support
thereof at the preliminary stage do not make out prima facie offence for which the petitioners have
been summoned, especially in the absence of any documentary evidence and infringement of the
provisions of the Act and misappropriation. It was also stated that there are so many sites available
on the internet wherein such study material is freely accessible and available and nothing has been
specified as to what kind of theft of material was committed by the petitioners. The study material
and other materials are available in the market through internet. The websites from which
information about patents can be retrieved freely have been CRM-M-36473 of 2011 (O&M) -5-
detailed.
9. The petitioners have also purchased patent data base from the market for their own company for
` 2,25,000/-. The petitioners tried to refer to the bill (Annexure P-5) in support of this argument.
10. I have heard learned counsel for both the parties and after thoughtful consideration on the
subject I find substance in the contention on behalf of the petitioners.
11. The bone of contention of petitioners was non- compliance of provisions of Section 202 Cr.P.C. It
is contended that both the petitioners are residents of Rajasthan which is beyond territorial
jurisdiction of the Courts at Panchkula and without compliance of Section 202 Cr.P.C. the
Magistrate could not have issued the process against the petitioners.
12. In the complaint (Annexure P-1) before the Magistrate address of petitioner No. 2 is mentioned
as House No. 89, Sector 17, Panchkula and that of petitioner No. 1 as resident of a property situated
near New Sanganer Road, Jaipur, Rajasthan, though presently described as resident of Flat No. 91,
Kendriya Vihar, Sector 25, Panchkula. In the instant petition both the petitioners had described
their addresses as residents of Jaipur in Rajasthan State. The certificate of incorporation of the
company of Stellarix Consultancy Services Pvt. Ltd., 275, Industrial Area, Phase-II, Chandigarh has
been attached as Annexure C-3 with the complaint (Annexure P-1). Annexure C-5 is the
memorandum and articles of CRM-M-36473 of 2011 (O&M) -6- association of the said company and
the address of petitioner No. 1 in the said certificate of incorporation is of Jaipur. This is a document
which the respondent-company itself attached with the complaint. Petitioner No. 2, however,
described her address as resident of House No. 89, Sector 17, Panchkula.
13. There is a categorical assertion in the instant petition in paragraph No. 11 that both the
petitioners are residing at Jaipur which is beyond the jurisdiction of the Courts at Panchkula. The
respondent-company in the reply has not denied the assertion that both the petitioners are residents
of Rajasthan. It is rather stated that trial Court has complied with the provisions of Section 202(1)
Cr.P.C. According to the learned counsel, examination of the complainant who is the only witness
cited in the complaint in support of assertion of the complaint is sufficient compliance of theAbhinav Goyal And Another vs M/S Greyb Consultancy Service Ltd on 11 December, 2013

provisions of Section 202(1) Cr.P.C.
14. I am of the view that examination of complainant in this case as CW-1 by the trial Court was
basically an act of taking cognizance of the complaint. Learned counsel for respondent- company
has not referred to any order passed by the trial Court which would indicate that the trial Court was
alive to the requirement of Section 202 (1) Cr.P.C. before passing the summoning order. In
paragraph No. 2 of the impugned order (Annexure P-3) it is recorded that the
complainant-company examined Deepak Sayal, Director as CW-1 in the preliminary evidence and
thereafter, the complainant counsel closed CRM-M-36473 of 2011 (O&M) -7- preliminary evidence
on 30.07.2010. Learned Magistrate after hearing the complainant counsel passed the impugned
order on 16.10.2010.
15. In National Bank of Oman vs. Barakara Abdul Aziz and another, (2013) 2 SCC 488, Hon'ble
Supreme Court held as under:-
"9. The duty of a Magistrate receiving a complaint is set out in Section 202 of the
Code of Criminal Procedure and there is an obligation on the Magistrate to find out if
there is any matter which calls for investigation by a criminal court. The scope of
enquiry under this Section is restricted only to find out the truth or otherwise of the
allegations made in the complaint in order to determine whether process has to be
issued or not. Investigation under Section 202 of the Code of Criminal Procedure is
different from the investigation contemplated in Section 156 as it is only for holding
the Magistrate to decide whether or not there is sufficient grounds for him to proceed
further. The scope of enquiry under Section 202 of the Code of Criminal Procedure is,
therefore, limited to the ascertainment of truth or falsehood of the allegations made
in the complaint: -
(i) on the materials placed by the complainant before the Court;
(ii) for the limited purpose of finding out whether a prima facie case for issue of
process has been made our; and
(iii) for deciding the question purely from the CRM-M-36473 of 2011 (O&M) -8-
point of view of the complainant without at all adverting to any defence that the accused may have.
10. 202 of the Code of Criminal Procedure was amended by the Code of Criminal Procedure
(Amendment Act 2005) and the following words were inserted:
"and shall, in a case where the accused is residing at a place beyond the area in which
he exercises jurisdiction,"
The notes on clauses for the above-mentioned amendment read as follow:Abhinav Goyal And Another vs M/S Greyb Consultancy Service Ltd on 11 December, 2013

"False complaints are filed against persons residing at far off places simply to harass
them. In order to see that the innocent persons are not harassed by unscrupulous
persons, this clause seeks to amend Sub- section (1) of Section 202 to make it
obligatory upon the Magistrate that before summoning the accused residing beyond
his jurisdiction he shall enquire into the case himself or direct investigation to be
made by a police officer or by such other person as he thinks fit, for finding out
whether or not there was sufficient ground for proceeding against the accused."
The amendment has come into force w.e.f. 23.6.2006 vide notification No. S.O. 923(E) dt.
21.6.2006.
11. We are of the view that the High Court has correctly held that the above-mentioned amendment
was not noticed by the C.J.M. Ahmednagar. The C.J.M. had failed to carry out any enquiry or
ordered investigation as CRM-M-36473 of 2011 (O&M) -9- contemplated under the amended
Section 202 of the Code of Criminal Procedure. Since it is an admitted fact that the accused is
residing outside the jurisdiction of the C.J.M. Ahmednagar, we find no error in the view taken by the
High Court."
16. In view of the above case law, the impugned order cannot be sustained.
17. Learned counsel for the respondent referred to certain judgments which cannot be helpful to the
complainant. Meena Degala vs. State of A.P., 2005 (1) RCR (Criminal) 434 was a case in which the
Magistrate directed an FIR to be registered on a complaint made to it under Section 156 (3) Cr.P.C.
(Dr.) Shiva Jatan Thakur vs. Union of India, represented by the Ministry of Information and
Technology and others, 2011 (108) AIC 748 was a case in which quashing of the FIR, which was
registered under Sections 500, 506, 507, 509 IPC and Sections 66, 66-A, 66- E and 67-A of the
Information Technology Act, 2000, was prayed.
18. The other contention of the petitioners was that a complaint was made to the police and on
enquiry the police found that the complaint was false. Learned counsel for the respondent- company
rightly submits that the Magistrate was not bound to seek report of the police in terms of Section
210 Cr.P.C. as no matter was pending with the police.
19. The complainant has basically relied upon documents in support of the complaint that there is
breach of confidentiality stating that the complainant has been cheated by using the secret
CRM-M-36473 of 2011 (O&M) -10- data made available to both the petitioners in the course of
employment. How these documents Ex. CW-1/E and CW-1/F would justify the view that there are
sufficient grounds for proceeding against the accused unless the matter is considered, after holding
enquiry in terms of Section 202 (1) Cr.P.C.
20. From the above discussion, the impugned order of summoning dated 16.10.2010 (Annexure P-3)
is set aside and the matter is remitted to the Magistrate with a direction to proceed further in the
matter in accordance with law.
                     December 11, 2013                               ( R.P. NAGRATH )Abhinav Goyal And Another vs M/S Greyb Consultancy Service Ltd on 11 December, 2013

                     jk                                                   JUDGEAbhinav Goyal And Another vs M/S Greyb Consultancy Service Ltd on 11 December, 2013

