Abinaya Ramu vs The Additional Chief Secretary To ... on 27
November, 2023
Author: M.Sundar
Bench: M.Sundar
                                                                         H.C.P(MD)No.522 of 2023
                      BEFORE THE MADURAI BENCH OF MADRAS HIGH COURT
                                            DATED: 27.11.2023
                                                    Coram
                                    THE HON'BLE MR.JUSTICE M.SUNDAR
                                                   and
                                  THE HON'BLE MR. JUSTICE R.SAKTHIVEL
                                         H.C.P(MD)No.522 of 2023
                  Abinaya Ramu                       .. Petitioner/sister of the detenu
                                                     vs
                  1.The Additional Chief Secretary to Government of Tamil Nadu,
                    Home, Prohibition and Excise Department,
                    Fort St. George,
                    Chennai – 600 009.
                  2.The District Collector cum District Magistrate,
                    Madurai,
                    Madurai District.
                  3.The Superintendent of Prison,
                    Central Prison,
                    Madurai.
                  4.The Inspector of Police,
                    Melur Circle,
                    Madurai District.                                  .. Respondents
https://www.mhc.tn.gov.in/judis
                  1/10
                                                                             H.C.P(MD)No.522 of 2023Abinaya Ramu vs The Additional Chief Secretary To ... on 27 November, 2023

                  Prayer:- Petition filed under Article 226 of the Constitution of India
                  praying for issuance of a writ of Habeas Corpus calling for the records
                  pertaining        to   the   detention      order   in    Detention       Order
                  No.B.C.D.F.G.I.S.S.S.V.No.04/2023, dated 13.02.2023 under sub-
                  Sections (2) and 3 of Section 3 of the Tamil Nadu Act 14 of 1982 passed
                  by the second respondent and set aside the same by setting the detenu by
                  name Ajithbalan, S/o.Ramu, aged about 26 years and set him at liberty
                  now detained at Central Prison, Madurai.
                            For Petitioner         :       Mr.R.Vignesh
                            For Respondents        :       Mr.A.Thiruvadi Kumar
                                                           Additional Public Prosecutor
                                                       ORDER
[Order of the Court was made by M.SUNDAR, J.] When the captioned 'Habeas Corpus Petition'
[hereinafter 'HCP' for the sake of brevity] was listed in the Admission Board on 28.04.2023, a
Hon'ble Predecessor Coordinate Division Bench made the following order and a scanned
reproduction of the same is as follows:
https://www.mhc.tn.gov.in/judis
2.It has now become necessary to set out a thumbnail sketch of factual matrix and we
do so in the paragraphs infra.
3.Today, captioned matter is in the Final Hearing Board.
4.Mr.R.Vignesh, learned counsel for petitioner and Mr.A.Thiruvadi Kumar, learned
State Additional Public Prosecutor for all respondents are before us.
https://www.mhc.tn.gov.in/judis
5.Captioned HCP has been filed by the sister of the detenu assailing a 'preventive detention order
dated 13.02.2023 bearing reference No.B.C.D.F.G.I.S.S.S.V.No.04/2023' [hereinafter 'impugned
preventive detention order' for the sake of brevity and convenience] made by 'second respondent'
[hereinafter 'Detaining Authority' for the sake of clarity]. To be noted, fourth respondent is the
Sponsoring Authority.
6.Impugned preventive detention order has been made under 'The Tamil Nadu Prevention of
Dangerous Activities of Bootleggers, Cyber law offenders, Drug-offenders, Forest-offenders,
Goondas, Immoral traffic offenders, Sand-offenders, Sexual-offenders, Slum- grabbers and Video
Pirates Act, 1982 (Tamil Nadu Act No.14 of 1982)' [hereinafter 'Act 14 of 1982' for the sake ofAbinaya Ramu vs The Additional Chief Secretary To ... on 27 November, 2023

convenience and clarity] on the premise that the detenu is a 'Goonda' within the meaning of Section
2(f) of Act 14 of 1982.
7.There is one adverse case and one ground case. The ground case which constitutes substantial part
of substratum of the https://www.mhc.tn.gov.in/judis impugned preventive detention order is
Crime No.202 of 2022 on the file of Melavalavu Police Station for alleged offences under Sections
147, 148, 341, 302 and 506(ii) of 'The Indian Penal Code (45 of 1860)' [hereinafter 'IPC' for the sake
of convenience and clarity] and subsequently altered into Sections 147, 148, 341, 302, 506(ii),
294(b), 355, 120-B and 212 of IPC. Considering the nature of the challenge to the impugned
detention order, it is not necessary to delve into the factual matrix of the case.
8.In the support affidavit qua captioned HCP several grounds have been raised but learned counsel
for petitioner predicated his campaign against the impugned preventive detention order on the
point that the detenu was arrested on 04.01.2023 but the impugned preventive detention order has
been made only on 13.02.2023 resulting in 'live and proximate link' between grounds of detention
and purpose of detention getting snapped.
9.Mr.A.Thiruvadi Kumar, learned State Additional Public Prosecutor, submits to the contrary by
saying that materials had to be https://www.mhc.tn.gov.in/judis collected and time was consumed
in this exercise. Considering the facts / circumstances of the case on hand and nature of ground
case, we find that this explanation of learned Prosecutor is unacceptable.
10.We remind ourselves of Sushanta Kumar Banik's case [Sushanta Kumar Banik Vs. State of
Tripura & others reported in 2022 LiveLaw (SC) 813 : 2022 SCC OnLine SC 1333]. To be noted,
Banik case arose under 'Prevention of Illicit Traffic in Narcotic Drugs and Psychotropic Substances
Act, 1988' [hereinafter 'PIT NDPS Act' for the sake of brevity] in Tirupura, wherein after considering
a proposal by a Sponsoring Authority and after noticing the trajectory the matter took, Hon'ble
Supreme Court held that the 'live and proximate link between grounds of detention and purpose of
detention snapping' point should be examined on a case to case basis. Hon'ble Supreme Court has
held in Banik case law that this point has two facets. One facet is 'unreasonable delay' and the other
facet is 'unexplained delay'. We find that the captioned matter falls under latter facet i.e.,
unexplained delay. https://www.mhc.tn.gov.in/judis
11.To be noted, Banik case has been respectfully followed by this Court in Gomathi Vs.The Principal
Secretary to Government and others reported vide Neutral Citation of Madras High Court being
2023/MHC/334, Sadik Basha Yusuf Vs. The State of Tamil Nadu and others reported vide Neutral
Citation of Madras High Court being 2023/MHC/733, Sangeetha Vs. The Secretary to the
Government and others reported vide Neutral Citation of Madras High Court being
2023:MHC:1110, N.Anitha Vs. The Secretary to Government and others reported vide Neutral
Citation of Madras High Court being 2023:MHC:1159 and a series of similar orders in HCP cases.
12.To be noted, the adverse case is in Crime No.39 of 2020 on the file of Melavalavu Police Station
(occurrence was on 24.02.2020) and therefore time consumed remains unexplained.Abinaya Ramu vs The Additional Chief Secretary To ... on 27 November, 2023

13.Before concluding, we also remind ourselves that impugned preventive detention is not a
punishment and HCP is a high prerogative writ.
https://www.mhc.tn.gov.in/judis
14.Ergo, the sequitur is, captioned HCP is allowed. Impugned preventive detention order dated
13.02.2023 bearing reference No.B.C.D.F.G.I.S.S.S.V.No.04/2023 made by the second respondent is
set aside and the detenu Thiru.Ajithbalan, aged 26 years, son of Thiru.Ramu, is directed to be set at
liberty forthwith, if not required in connection with any other case / cases. There shall be no order
as to costs.
(M.S.,J.) (R.S.V.,J.) 27.11.2023 (1/3) Index : Yes/No Neutral Citation : Yes/No ps Post Script: (i)
Registry to forthwith communicate this order to Jail authorities in Central Prison, Madurai.
(ii) All concerned to act on this order being uploaded in official website of this Court without
insisting on certified copies. To be noted, this order when uploaded in official website of this Court
will be watermarked and will also have a QR code. https://www.mhc.tn.gov.in/judis To
1.The Additional Chief Secretary to Government of Tamil Nadu, Home, Prohibition and Excise
Department, Fort St. George, Chennai – 600 009.
2.The District Collector cum District Magistrate, Madurai, Madurai District.
3.The Superintendent of Prison, Central Prison, Madurai.
4.The Inspector of Police, Melur Circle, Madurai District.
5.The Joint Secretary to Government, Public (Law and Order) Department, Secretariat, Chennai.
6.The Additional Public Prosecutor, Madurai Bench of Madras High Court, Madurai.
https://www.mhc.tn.gov.in/judis M.SUNDAR, J., and R.SAKTHIVEL, J., ps 27.11.2023 (1/3)
https://www.mhc.tn.gov.in/judisAbinaya Ramu vs The Additional Chief Secretary To ... on 27 November, 2023

