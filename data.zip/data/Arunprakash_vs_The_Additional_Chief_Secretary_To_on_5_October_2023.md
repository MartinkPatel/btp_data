Arunprakash vs The Additional Chief Secretary To ... on 5
October, 2023
Author: M.Sundar
Bench: M.Sundar
                                                                           HCP(MD)No.1075 of 2023
                         BEFORE THE MADURAI BENCH OF MADRAS HIGH COURT
                                               DATED: 05.10.2023
                                                      CORAM:
                                    THE HONOURABLE MR.JUSTICE M.SUNDAR
                                                        and
                                  THE HONOURABLE MRS.JUSTICE R.KALAIMATHI
                                            H.C.P.(MD)No.1075 of 2023
                     Arunprakash                                             : Petitioner
                                                          Vs.
                     1.The Additional Chief Secretary to Government,
                        State of Tamil Nadu,
                        Home Prohibition and Excise Department,
                        Secretariat, Chennai – 600 009.
                     2.The District Collector and District Magistrate,
                        Office of the District Collector and District Magistrate,
                        Madurai District, Madurai.
                     3.The Superintendent of Prison,
                        Madurai Central Prison,
                        Madurai District.                                      : Respondents
                     PRAYER: Petition filed under Article 226 of the Constitution of India
                     to issue a writ of Habeas Corpus, calling for the entire recordsArunprakash vs The Additional Chief Secretary To ... on 5 October, 2023

                     Page 1 of 8
https://www.mhc.tn.gov.in/judis
                                                                                  HCP(MD)No.1075 of 2023
                     connected with the detention order of the second respondent in
                     Detention Order B.C.D.F.G.I.S.S.S.V.No.13/2023 dated 12.04.2023 and
                     quash the same and to direct the respondents to produce the body or
                     person of the detenue by name Arunprakash son of Vairavan, aged
                     about 34 years, now confining as “Sexual Offender” at Madurai
                     Central Prison before this Court and set him at liberty forthwith.
                                             For Petitioner      : Mr.R.Prakash
                                             For Respondents : Mr.A.Thiruvadi Kumar
                                                                  Additional Public Prosecutor
                                                         ORDER
*********** [Order of the Court was made by M.SUNDAR, J.] This 'Habeas Corpus Petition' ['HCP'
for the sake of brevity] has been filed by the detenu assailing a 'preventive detention order dated
12.04.2023 bearing reference B.C.D.F.G.I.S.S.S.V.No. 13/2023' [hereinafter 'impugned preventive
detention order' for the sake of brevity and convenience]. To be noted, sponsoring authority has not
been arrayed as a respondent but we find that Station House Officer of M.Chathirapatti Police
Station is the sponsoring authority [hereinafter 'Sponsoring Authority' for the sake of convenience
and clarity].
https://www.mhc.tn.gov.in/judis
2.Impugned detention order has been made under 'The Tamil Nadu Prevention of Dangerous
Activities of Bootleggers, Cyber law offenders, Drug-offenders, Forest-offenders, Goondas, Immoral
traffic offenders, Sand-offenders, Sexual-offenders, Slum-grabbers and Video Pirates Act, 1982
(Tamil Nadu Act No.14 of 1982)' [hereinafter 'Act 14 of 1982' for the sake of convenience and clarity]
on the premise that the detenu is a 'Sexual Offender' within the meaning of Section 2(ggg) of Act 14
of 1982.
3.There is one adverse case and one ground case. The ground case which constitutes substantial part
of substratum of the impugned preventive detention order is Crime No.107 of 2022 on the file of
M.Chathirapatti Police Station for the alleged offences under Sections 294(b), 341, 323, 365, 376,
392, 109, 506(ii) of 'The Indian Penal Code (45 of 1860)' [hereinafter 'IPC' for the sake of
convenience and clarity] and was subsequently altered into Sections 294(b), 341, 323, 365, 376, 392Arunprakash vs The Additional Chief Secretary To ... on 5 October, 2023

and 506(ii) IPC. Considering the nature of the challenge to the impugned detention order, it is not
necessary to delve into the factual matrix of the case.
https://www.mhc.tn.gov.in/judis
4.Mr.R.PRakash, learned counsel on record for petitioner and Mr.A.Thiruvadi Kumar, learned State
Additional Public Prosecutor for all respondents are before us.
5.In the support affidavit qua captioned HCP several grounds have been raised, but learned Counsel
for petitioner predicated his campaign against the impugned Preventive Detention Order on the
point that the detenu surrendered before the Judicial Magistrate, Iluppur and remanded to judicial
custody in the ground case on 02.02.2023 but the impugned preventive detention order has been
made only on 12.04.2023 resulting in live and proximate link between grounds and purpose of
detention getting snapped.
6.Mr.Thiruvadi Kumar, learned State Additional Public Prosecutor, submits to the contrary by
saying that materials had to be collected and time was consumed in this exercise. Considering the
facts / circumstances of the case on hand and nature of ground case, we find that this explanation of
learned Prosecutor is unacceptable.
7.We remind ourselves of Sushanta Kumar Banik's case [Sushanta Kumar Banik Vs. State of Tripura
& others reported https://www.mhc.tn.gov.in/judis in 2022 LiveLaw (SC) 813 : 2022 SCC OnLine
SC 1333]. To be noted, Banik case arose under 'Prevention of Illicit Traffic in Narcotic Drugs and
Psychotropic Substances Act, 1988' [hereinafter 'PIT NDPS Act' for the sake of brevity] in Tirupura,
wherein after considering a proposal by a Sponsoring Authority and after noticing the trajectory the
matter took, Hon'ble Supreme Court held that the 'live and proximate link between grounds of
detention and purpose of detention snapping' point should be examined on a case to case basis.
Hon'ble Supreme Court has held in Banik case that this point has two facets. One facet is
'unreasonable delay' and the other facet is 'unexplained delay'. We find that the captioned matter
falls under latter facet i.e., unexplained delay.
8.To be noted, Banik case has been respectfully followed by this Court in Gomathi Vs.The Principal
Secretary to Government and others reported vide Neutral Citation of Madras High Court being
2023/MHC/334, Sadik Basha Yusuf Vs. The State of Tamil Nadu and others reported vide Neutral
Citation of Madras High Court being 2023/MHC/733, Sangeetha Vs. The Secretary to the
Government and others reported vide Neutral Citation of Madras High Court being
2023:MHC:1110, N.Anitha Vs. The Secretary https://www.mhc.tn.gov.in/judis to Government and
others reported vide Neutral Citation of Madras High Court being 2023:MHC:1159 and a series of
similar orders in HCP cases.
9.To be noted, the adverse case is in Crime No.79 of 2022 on the file of M.Chathirapatti Police
Station for alleged offence under Section 392 of IPC [occurrence was on 27.08.2022] and therefore
time consumed remains unexplained.Arunprakash vs The Additional Chief Secretary To ... on 5 October, 2023

10.Before concluding, we also remind ourselves that preventive detention is not a punishment and
HCP is a high prerogative writ.
11.Ergo, the sequitur is, captioned HCP is allowed. Impugned preventive detention order dated
12.04.2023 bearing reference B.C.D.F.G.I.S.S.S.V.No.13/2023 made by the second respondent is set
aside and the detenu Thiru.Arunprakash, male, aged 34 years, son of Thiru.Vairavan, is directed to
be set at liberty forthwith, if not required in connection with any other case / cases. There shall be
no order as to costs.
                                                                   [M.S.,J.]  &   [R.K.M.,J.]
                                                                          05.10.2023
                     Index      : Yes/No
                     Internet   : Yes/No
                     Neutral Citation : Yes/No
                     MR
P.S: Registry to forthwith communicate this order to Jail https://www.mhc.tn.gov.in/judis
authorities in Central Prison, Madurai.
To
1.The Additional Chief Secretary to Government, State of Tamil Nadu, Home Prohibition and Excise
Department, Secretariat, Chennai – 600 009.
2.The District Collector and District Magistrate, Office of the District Collector and District
Magistrate, Madurai District, Madurai.
3.The Superintendent of Prison, Madurai Central Prison, Madurai District.
4.The Additional Public Prosecutor, Madurai Bench of Madras High Court, Madurai.
https://www.mhc.tn.gov.in/judis M.SUNDAR, J.
and R.KALAIMATHI, J.
MR ORDER MADE IN 05.10.2023 https://www.mhc.tn.gov.in/judisArunprakash vs The Additional Chief Secretary To ... on 5 October, 2023

