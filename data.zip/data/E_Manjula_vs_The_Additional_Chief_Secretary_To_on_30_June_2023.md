E.Manjula vs The Additional Chief Secretary To ... on 30 June,
2023
Author: M.Sundar
Bench: M.Sundar
                                                                                           H.C.P.No.83 of 2023
                                     IN THE HIGH COURT OF JUDICATURE AT MADRAS
                                                        DATED : 30.06.2023
                                                              CORAM
                                       THE HONOURABLE MR.JUSTICE M.SUNDAR
                                                      and
                                     THE HONOURABLE MR.JUSTICE R.SAKTHIVEL
                                                        H.C.P.No.83 of 2023
                     E.Manjula                                           .. Petitioner/
                                                                           Aunt of the detenu
                                                                Vs.
                     1.           The Additional Chief Secretary to Government
                                  Home, Prohibition and Excise Department
                                  Secretariat, Chennai – 600 009
                     2.           The Commissioner of Police
                                  Greater Chennai
                                  Chennai
                     3.           The Superintendent of Police
                                  Central Prison
                                  Puzhal, Chenani – 600 066
                     4.           The Inspector of Police (L & O)
                                  K-3, Aminjikarai Police Station
                                  Chennai                                          ..Respondents
                                  Petition filed under Article 226 of the Constitution of India praying for
                     issuance of a writ order or direction in the nature of WRIT OF HABEAS
                     Page Nos.1/10
https://www.mhc.tn.gov.in/judis
                                                                                          H.C.P.No.83 of 2023E.Manjula vs The Additional Chief Secretary To ... on 30 June, 2023

                     CORPUS, calling for records in connection with the order of detention
                     passed           by     the    second       respondent    dated    02.12.2022        in
                     No.450/BCDFGISSSV/2022 against the petitioner's brother's son Deena @
                     Dinakaran, male, aged 24 years, son of Udhayakumar, who is confined at
                     Central Prison, Puzhal, Chennai and to set aside the same and consequently
                     direct the respondents to produce the detenu before this Court and set him at
                     liberty.
                                  For Petitioner             :      Mr.M.Mohamed Saifulla
                                                                    for Mr.M.Anand
                                  For Respondents            :      Mr.E.Raj Thilak
                                                                    Additional Public Prosecutor
                                                             ORDER
[Order of the Court was made by M.SUNDAR, J.,] When the captioned 'Habeas Corpus Petition'
[hereinafter 'HCP' for the sake of convenience and clarity] was listed in the Admission Board on
23.01.2023, this Court made the following order:
'Captioned Habeas Corpus Petition has been filed in this Court on 09.01.2023 inter
alia assailing a detention order dated 02.12.2022 bearing reference
No.450/BCDFGISSSV/2022 made by 'second respondent' [hereinafter 'Detaining
Authority' for the https://www.mhc.tn.gov.in/judis sake of convenience and clarity].
To be noted, fourth respondent is the Sponsoring Authority.
2. The aunt of the detenu is the petitioner.
3. Mr.M.Anand, learned counsel on record for habeas corpus petitioner is before us.
Learned counsel expresses regret for not representing the matter in the previous
listing on 20.01.2023. Learned counsel for petitioner submits that ground case qua
the detenu is for alleged offences under Sections 448, 341, 294(b), 323, 392 read with
397, 336, 427 and 506(ii) of IPC in Crime No.444 of 2022 on the file of K-3
Aminjikarai Police Station.
4. The aforementioned detention order has been made on the premise that the
detenu is a 'Goonda' under Section 2(f) of 'The Tamil Nadu Prevention of Dangerous
Activities of Bootleggers, Cyber law offenders, Drug-offenders, Forest-
offenders, Goondas, Immoral traffic offenders, Sandoffenders, Sexual-offenders, Slum-grabbers and
Video Pirates Act, 1982 (Tamil Nadu Act No.14 of 1982)' [hereinafter 'Act 14 of 1982' for the sake of
convenience and clarity].
5. The detention order has been assailed inter alia on the ground that the similar case bail order
relied on has not been properly translated.E.Manjula vs The Additional Chief Secretary To ... on 30 June, 2023

6. Prima facie case made out for admission. Admit. Issue Rule nisi returnable by four weeks.
7. Mr.R.Muniyapparaj, learned Additional Public https://www.mhc.tn.gov.in/judis Prosecutor,
State of Tamil Nadu accepts notice for all respondents.
List the captioned Habeas Corpus Petition accordingly '
2. The aforementioned order made in the 23.01.2023 Admission listing shall be read as an integral
part and parcel of this order which means that the short forms, short references and abbreviations
used in the order in the Admission listing shall be used in the instant order also.
3. There are four adverse cases and one ground case. The ground case which constitutes substantial
part of substratum of the impugned preventive detention order is Crime No.444 of 2022 on the file
of K-3, Aminjikarai Police Station for alleged offences under Sections 448, 341, 294(b), 323, 392
read with Sections 397, 336, 427 and 506(ii) of IPC. Owing to the nature of the challenge to the
impugned preventive detention order, it is not necessary to delve into the factual matrix or be
detained further by facts.
4. Mr.M.Mohamed Saifulla, learned counsel representing the counsel on record for petitioner and
Mr.E.Raj Thilak, learned State Additional Public Prosecutor for all respondents are before us.
https://www.mhc.tn.gov.in/judis https://www.mhc.tn.gov.in/judis
5. To be noted, as would be evident from the Admission Board order even in the admission board
the point that similar case bail order has not been properly translated has been raised. Elaborating
on the same, Mr.M.Mohamed Saifulla, learned counsel representing the counsel on record for
petitioner drew our attention to two portions of grounds of impugned preventive detention order,
which read as follows:
'........jpU/ guj; Mfpnahiu 10/11/2022 md;W brd;id:?6. vGk;g{h;. 5?tJ bgUefu
Fw;wtpay; eLth; ePjpkd;wk; Kd;ghf M$h;gLj;jpaij mLj;J vjphpfs;. 24/11/2022 tiu
brd;id. g[Hy;. kj;jpa rpiwapy; tprhuizf; ifjpahf milf;fg;gl;ldh;......' '..... jpU/ guj;
vd;gtUf;F $hkPd;
                                  tH';fg;gl;Ls;sjhYk;.               ,Jnghd;w           tHf;fpy;         rpwpJ
                                  fhyk;               fHpj;J               ePjpkd;;wfj;jpy;              $hkPd;
tH';fg;gl;Ls;sjhYk;. mth; nf3 mike;jfiu fhty; epiua Fw;w vz;fs; 359-2022 kw;Wk; 444
– 2022 Mfpa tHf;FfSf;fhf $hkPd; nfhUk; kDit chpa ePjpkd;wj;jpy; jhf;fy; bra;J
$hkPdpy; btspna tu cz;ikahd rhj;jpaf;Tw cs;sJ vd;Wk; ehd;
fUJfpnwd;......'
6. Learned counsel pointed out that the subjective satisfaction qua imminent possibility of detenu
being enlarged on bail has been arrived at by https://www.mhc.tn.gov.in/judis the Detaining
Authority by relying on bail granted to co-accused Thiru.Barath but copy of Barath's bail order hasE.Manjula vs The Additional Chief Secretary To ... on 30 June, 2023

not been furnished as part of the grounds booklet is his say.
7. Responding to this argument, learned Prosecutor drew our attention to page 168 of the grounds
booklet and submitted that Barath's case bail order has been furnished but the problem presents
itself in a different form. A perusal of Pages 168 and 169 show that Barath's case bail order has been
made by the learned Sessions Judge in English. The literacy level of the detenu is 10th Standard, he
is a school drop out and he is conversant only with Tamil. Therefore, it has become necessary to look
at the Tamil translation of the same, but what has been furnished to detenu as Tamil translation of
Barath's case bail order is at pages 170 and 171 and that shows the petitioner as one Narasimhan.
The detenu being conversant only with Tamil would obviously look at the bail order in Tamil. Tamil
bail order talks about bail for one Narasimhan and therefore, as far as the detenu is concerned, he
will not have the benefit of seeing the Barath's case bail order. This means that the detenu's sanctus
right to make an effective https://www.mhc.tn.gov.in/judis representation which is a constitutional
safeguard ingrained in sub-clause (5) of Article 22 is impaired. The sequitur is, impugned preventive
detention order deserves to be dislodged.
8. Ergo, the sequitur is, captioned HCP is allowed. Impugned detention order dated 02.12.2022
bearing reference 450/BCDFGISSSV/2022 made by the second respondent is set aside and the
detenu Thiru.Deena @ Dinakaran, aged 24, son of Thiru.Udhayakumar, is directed to be set at
liberty forthwith, if not required in connection with any other case / cases. There shall be no order
as to costs.
                                                                    (M.S.,J.)         (R.S.V.,J.)
                                                                           30.06.2023
                     Index : Yes
                     Speaking order
                     Neutral Citation : Yes
                     gpa
P.S. Registry to forthwith communicate this order to Jail authorities in Central Prison, Puzhal
https://www.mhc.tn.gov.in/judis To
1. The Additional Chief Secretary to Government Home, Prohibition and Excise Department
Secretariat, Chennai – 600 009
2. The Commissioner of Police Greater Chennai Chennai
3. The Superintendent of Police Central Prison Puzhal, Chenani – 600 066
4. The Inspector of Police (L & O) K-3, Aminjikarai Police Station Chennai
5. The Public Prosecutor High Court, Madras.
https://www.mhc.tn.gov.in/judis M.SUNDAR, J., and R.SAKTHIVEL, J., gpa 30.06.2023E.Manjula vs The Additional Chief Secretary To ... on 30 June, 2023

https://www.mhc.tn.gov.in/judisE.Manjula vs The Additional Chief Secretary To ... on 30 June, 2023

