Bihar Minor Mineral Concession Rules, 1972
BIHAR
India
Bihar Minor Mineral Concession Rules, 1972
Rule BIHAR-MINOR-MINERAL-CONCESSION-RULES-1972 of
1972
Published on 22 June 1972• 
Commenced on 22 June 1972• 
[This is the version of this document from 22 June 1972.]• 
[Note: The original publication document is not available and this content could not be
verified.]• 
Bihar Minor Mineral Concession Rules, 1972Published vide Notification No. B/N/109/72-4275 M,
dated 22nd June, 1972, Bihar Gazette (extraordinary) dated 31 July, 1972[Notification No.
B/N/109/72-4275 M, the 22nd June, 1972. - In exercise of the powers conferred by Section 15 of the
Mines and Minerals (Regulation and Development) Act, 1957 (67 of 1957), the Governor of Bihar is
pleased to make the following Rules, namely:-
Chapter I
Preliminary
1. Short title, extent and commencement.
- (i) These Rules may be called the Bihar Minor Mineral Concession Rules, 1972.(ii)They shall
extend to the whole of the State of Bihar.(iii)They shall come into force with effect from the date of
publication in the Bihar Gazette.
2. Definitions.
- In these Rules, the context otherwise requires. -(i)"Collector" means the Chief Officer incharge of
the revenue administration of a district or any officer specially empowered by the State Government
to perform the duties of a Collector under these Rules;(ii)"Commissioner" means the Commissioner
of Mines and Geology, Bihar, or any other Officer authorised in this behalf by the State Government
to perform the duties of Commissioner under these Rules;(iii)"Competent Officer" means (a) in the
case of grant of quarrying permits in land notified as Reserved and Protected Forest under the
Indian Forest Act, 1927 (Central Act XVI of 1927), where the actual mining operation involved is
merely removal from the surface or from a depth not exceeding five feet and to a limit of 10.000
cubic feet only, Divisional Forest Officer of the reserved and protected areas concerned, and(b)in allBihar Minor Mineral Concession Rules, 1972

other cases in respect of all lands, and sub-soil including any right in mines and minerals whether
discovered and whether being worked or not, the Assistant [Director or Mineral Development
Officer of the district or circle or Mines Inspector of the district or circle where Assistant Director or
Mineral Development Officer has not been posted.] [Substituted vide Section 2 of Amendment
Rules, 2008.] [x x x] [Omitted by S.O. 305 dated 26.3.1985.];(iv)"Divisional Commissioner" means
the Commissioner of a Division appointed as such by the State Government;(v)"Director of Mines"
means the Director of Mines appointed as such by the State Government;(va)[ "Additional Director
of Mines" means Additional Director of Mines appointed as such by the State Government;]
[Inserted by S.O. 861 dated 11.7.1983.](vi)"Deputy Director of Mines" means the Deputy Director of
Mines appointed as such by the State Government;(vii)"Form" means a form set out in Schedule III
appended to these Rules;(viii)"Government" means the State Government of Bihar;(ix)"Local
authority" shall mean a Municipal Committee, District Board or other authority legally entitled to,
or entrusted, by the Government with, the control or management of a municipal or local
fund;(x)"Minerals" means minor minerals as defined in clause (e) of Section 3 of the Mines and
Minerals (Regulation and Development) Act, 1957;(xi)"Person" means an individual, a firm, a
company, an association or body of individuals, an institution or department of the State
Government or Central Government;(xii)"Quarrying Permit" means a permit granted under Chapter
IV of these Rules to extract and remove any minor minerals in specified quantities from the
specified areas;(xiii)"Schedule" means a Schedule appended to these Rules; and(xiv)Words and
expression used but not defined in these Rules shall have the same meanings as are respectively
assigned to them in the Mines and Minerals (Regulation and Development) Act, 1957.
3. Limitation of application of Rules.
- Nothing in these Rules shall affect, the provisions of any Central Act or Regulations or Rules made
thereunder for the purpose of regulation and development of mines and minerals and of the safety
of the persons working in the mines, and anything done or any action taken under the provisions of
the Bihar Minor Minerals Concession Rules, 1964.Rules 3(A-E) Omitted vide S. O. No. 1063 dated
16.10.1989.]
Chapter II
General restriction on undertaking Mining Operation
4. Prohibition of mining operation without permit or mining lease.
(1)No person shall undertake any mining operation in any area, except under and in accordance
with the terms and conditions of a quarrying permit or, as the case may be, a mining lease, granted
under these Rules:Provided that nothing in this sub-rule shall affect any mining or quarrying
operations undertaken in any area in accordance with the terms and conditions of a mining lease or
quarrying permit granted before the commencement of these Rules which is in force at the time of
such commencement.(2)No quarrying permit or mining lease shall be granted otherwise than in
accordance with the provisions of these Rules.Bihar Minor Mineral Concession Rules, 1972

5. Restriction on the grant of quarrying permit or mining lease.
(1)No quarrying permit or mining lease shall be granted to a person who is not an Indian national
except with the previous approval of the Government.(2)No quarrying permit or mining lease shall
be granted in respect of land notified by Government as reserved for the use of the Government,
Local Authorities or for any other public or for special purposes except with the previous approval of
the Government.(3)No mining lease shall be granted in Reserved and Protected Forest area without
consulting the Divisional Forest Officer concerned. The Competent Officer shall consult the
Divisional Forest Officer before making his own recommendation for the grant of the mining
lease:Provided that if any referency by the Competent Officer to the Divisional Forest Officer
concerned fails to elicit any reply within 60 days from the date of reference, the concurrence of the
Divisional Forest Officer shall be presumed:Provided further that if there be any difference of
opinion between the Competent Officer and the Division Forest Officer, the Collector of the District
shall decide point or points of difference and his decision thereon shall be final.
6. Maximum area for which mining lease be granted or renewed.
- No person shall acquire in the State in respect of any minor minerals one or more mining leases
covering a total area of more than [100 Hectares] [Substituted by S. O. 305 dated
26.3.1985.]:Provided that if the State Government is of the opinion that in the interest of mineral
development it is necessary so to do, it may, for reasons to be recorded, permit any person to
acquire one or more mining leases covering an area in excess of the aforesaid maximum.
7. Period for which mining lease be granted or renewed.
- The period for which a mining lease may be granted or renewed shall not ordinarily be more than
[Ten years] [Substituted by S. O. 1063 dated 16.10.1989.] [x x x x] [Omitted by S. O. 1063 dated
16.10.1989.]
8. Length and breadth of leased area.
(1)The length of an area held under a mining lease shall not exceed four times its breadth:Provided
that the Collector may, in any particular case, relax the provision of this Rule [for reasons to be
recorded in writing] [Inserted by S. O. 305 dated 26.3.1985.].(2)The area under any mining lease
shall be in a compact block and for every compact block separate application for grant of mining
leases shall have to be filed.
Chapter III
Grant of Mining LeaseBihar Minor Mineral Concession Rules, 1972

9. Application for grant of mining leases.
- [(1) Except of Granite] [Substituted by S. O. 5572 dated 18.10.95.](a)[ A mining lease except of
granite shall be granted by the Collector,] [Inserted by S. O. 5572 dated 18.10.95.](b)Mining lease or
prospecting licence of granite shall be granted by the State Govt.(2)Every application for a mining
lease in respect of any land shall be made in Form "A" to the [Competent-Officer] [Substituted for
'Collector' by S. O. 867 dated 21.8.1972.] or any other officer authorised by the Collector.(3)Every
application for mining lease shall be accompanied by a fee of [Rs. 2000,] [Substituted by S. O. 1063
dated 16.10.1989.] and details of the land in respect of which the mining lease is applied for, and,
where so required, certified copy or copies of the relevant extracts of the record of rights.(4)[ Every
application for mining lease shall be accompanied by a valid clearance certificate of payment of
mining dues such as royalty or dead rent, surface rent and cess upto the end of last financial year [in
respect of all mineral concessions held in the State of Bihar.] [Substituted by S.O. 1133 dated
19.8.1978.]][ x x x x] [Omitted by S. O. 1063 dated 16.10.1989.](6)[ Every application shall be
accompanied by an affidavit stating that the applicant has-(i)filed Income-Tax returns
up-to:date;(ii)paid the Income-Tax assessed on him; and(iii)paid the Income-Tax on the basis of self
assessment as provided in the Income-Tax Act, 1961.(7)Every application shall be accompanied by
an affidavit showing particulars of areas mineral wise in such State, which the applicant or any
person jointly with him-(i)already holds under a mining lease;(ii)has applied for but has not been
granted; and(iii)being applied for simultaneously."(8)Every application shall be accompanied by a
statement in writing that the applicant, has, where the land is not owned by him, obtained surface
right over the are or has obtained the consent of the owners for starting prospecting operation;
provided that no such statement shall be necessary where the land is owned by the Government.]
[Inserted by S. O. 1063 dated 16.10.1989.][Provided that consent of the raiyats/owners of the land
for starting prospecting/ mining operations in the area or part thereof shall be furnished after
execution of the lease deed but before entry into said area:Provided further that no consent shall be
required in the case of renewal where consent has already been obtained during the lease.] [Inserted
by S.O. 5572 dated 18.10.95.](9)[ When an application for a mining lease is not accompanied by the
papers specified in sub-rules (2), (3), (4) and [6, 7, & 8] [Sub-rule 3 re-numbered as (9) and inserted
by S. O. 1063 dated 16.10.1989.] it shall be rejected straightway by the Competent Officer within a
period of 15 days from the date of its receipt.]
9A. [ [Inserted by S.O. 29 dated 24.3.2001.]
- Notwithstanding anything contained in. these rules the Government may by notification in Official
Gazette direct that any mineral may be leased out or settled by Public auction/tender in the manner
prescribed in Rule-52].
10. Acknowledgement of application.
- On receipt of the application for a mining lease, the Collector [or Competent Officer or any other
officer authorised by the Collector] [Inserted by S. O. 305 dated 26.3.1985.] shall initial the
application along with date of its receipt and shall give to the applicant an acknowledgement stating
the date of receipt in Form 'B'.Bihar Minor Mineral Concession Rules, 1972

11. Disposal of application for mining lease.
(1)An application for the grant of mining lease shall be disposed of within [120] [90 days have been
replaced by 120 days vide by S. O. 305 dated 26.3.1985.] days from the date of its receipt.(2)If any
application is not disposed of within the period specified in sub-rule (1) it shall be deemed to have
been refused.[x x x x] [Proviso omitted by S. O. 305 dated 26.3.1985.](3)[ In case an applicant does
not hold mining lease in certain districts of the State, he shall, with an application for the grant or
renewal of the lease, file an affidavit to that effect.] [Inserted by S. O. 305 dated 26.3.1985.]
11A. [ [Inserted by S.O. 1133 dated 19.8.1978 and Substituted by S.O.33 dated
14.1.1985.]
Notwithstanding anything contained in these Rules the settlement of sand as minor mineral will be
done by public auction by the Collector to the highest bidder on annual basis.][Before the auction,
the bidders shall produce royalty clearance certificate required under Rule 9 (4) or an affidavit to the
effect that he is/was not a lessee or permit-holder and that he does not owe any mining dues.]
[Inserted by S.O. 199 dated 3.3.1988.]Explanation. - Existing leases shall not be renewed nor fresh
lease/permits for sand shall be granted:[Provided that in isolated and far flung areas of sand
deposits which reasonably and conveniently cannot be settled by auction shall be identified by the
Collector and on their being approved as such by the Commissioner the Competent Officer may
issue permits for removal of sand from such areas for such period not exceeding one year in respect
of any one individual permit holder.Provided further that such isolated and far flung areas can also
be settled through public auction as and when so declared by the Commissioner.] [Inserted by S.O.
199 dated 3.3.1988.][Provided further that anything contained herein before in this Rule shall not
prevent the Collector from exercising his power u/R 9 in cases covered by Rule 12 (i) hereinafter.]
[Inserted by S.O. 1063 dated 16.10.1989.]
11B. [ [Inserted by S.O. 398 dated 17.8.1991.]
(1)Every settlee of sand as minor mineral shall deposit the amount equivalent to ten percentum of
auctioned amount as security for due observance of terms and conditions of settlement which shall
be refunded after the expiry of the period of settlement by the Competent Officer unless the same
will be withheld in part or in full by the Competent Officer for reasons to be recorded in writing
including non-payment of mining dues.(2)Where the settlement is made by public auction, a deed
shall ordinarily be executed in Form 'O' or in a Form as near thereto as circumstances of each case
may require, of this Rule within 60 days of the order of the settlement and if no such deed is
executed due to the failure on the part of the settlee the settlement order shall be deemed to have
been revoked and security deposit and other amounts paid may be forfeited.]
11C. [ [Inserted by S. O. 5572 M dated 18.10.1995.]
- However the Collector may give preference to Co-operative Society, duly registered under Bihar
and Orissa Co-operative Societies Act, 1935, having its members among those personsBihar Minor Mineral Concession Rules, 1972

who;(i)Usually work as labourers in the Panchayat or Panchayats in which such sand deposits
occur;(ii)are residents of the Panchayat or Panchayats for which the Society is formed;(iii)do not
own more than five acres of agricultural or homestead land:Provided that the society undertakes in
writing to deposit an amount which is 20% higher than the amount realised as royalty from the
same area in the calender year immediately preceding.
11D.
Every such settlement shall be valid only for the calendar year in which it is so made irrespective of
the date on which such settlee comes in its possession and in no case shall such settlement or
possession continue in the succeeding calendar year.
11E.
After such settlement and making deposit of 25% of the settlement amount within seven days
thereafter, the settlee may be put in possession of the area by the Collector.
11F.
Every such settlee shall make payment of the settlement amount after possession in following
instalments in the local treasury :-
(i) within 30 days of coming into possession -30%
(ii) within 120 days of coming into possession -20%
(iii) within 180 days of coming into possession remaining amount -50%
Any default in payment of such amount shall at once result in cancellation of the settlement and the
Collector shall be free to settle the area denovo in accordance with the Rules 11-A, 11-C and 11-D.]
12. Preferential right for obtaining mining lease.
(1)In granting the mining lease, the Collector shall give preference to Government Departments,
Public Sector Undertakings of the State or Central Governments, Local body, [and Co-operative
Society] [Inserted by S.O. 1063 dated 16.10.1989.] where the lease is required for work directly
concerned with the Department, undertaking or body, if they fulfil the conditions required for the
grant of mining lease.[However, the Collector may give preference to such Co-operative Society all
the members/share-holders of which belong to [Scheduled Tribe or Scheduled Caste] [Inserted by
S.O. 1063 dated 16.10.1989.] and which has duly been registered under Bihar and Orissa
Co-operative Societies Act, 1935.](2)Subject to the provisions of Rule 12(1), where two or more
persons have applied for mining lease in respect of the same land, the applicant whose application
was received earlier shall have a preferential right for the grant of the lease over the applicant whose
application was received later:Provided that where any such applications are received on the same
day, the Collector, after taking into consideration the matters specified in sub-rule (3), may grant
mining lease to such one of the applicants as he may deem fit.(3)The matters referred to in theBihar Minor Mineral Concession Rules, 1972

proviso above shall be the following namely:-(a)The experience of the applicants in quarrying
business;(b)Financial soundness and stability of the applicant;(c)The end use of the mineral by the
applicant;(d)Any other matter which the Government may prescribe.(4)No applicant shall claim any
priority by reason only of the fact that he had previously worked in the area to which the application
relates.(5)In the case of application for mining lease filed prior to the commencement of these Rules
and pending after such commencement priority will remain unaltered provided the applicant
complies with the requirement of these Rules within 30 days from the date of the receipt of a
requisition on this behalf by the [Competent Officer] [Substituted for 'Collector' by S.O. 867 dated
21.8.1972.],(6)Notwithstanding anything contained in sub-rule (2), the Collector may, for any
special reasons to be recorded and with the previous approval of the Government, grant a mining
lease to an applicant whose application was received later in preference to an applicant whose
application was received earlier.
13. Deposit of preliminary expenses.
- When the lease is granted or renewed, the applicant shall deposit for meeting the preliminary
expenses a sum of Rs. 200 only before the document is executed.
14. Security deposit.
- The applicant shall, before execution of the lease deed, deposit as security for the due observance
of the terms and conditions of the lease, a sum equal to the annual dead rent [at the maximum rate]
[Inserted by S.O. 305 dated 26.3.1985.] fixed for the lease or a sum of Rs. 1,000 whichever is [more]
[Substituted by S.O. 305 dated 26.3.1985.], which shall be refundable to him after the expiry of the
period of the lease, by the Competent Officer unless and until the same is withheld in part or in full
by the Competent Officer for any cogent reason including non-payment of mining dues.
15. Survey of the area leased.
- When the mining lease is granted, arrangement shall be made for the survey and demarcation of
the area granted under the lease by the Competent Officer.
16. Register of applications.
- A register of applications for mining leases shall be maintained by each Competent Officer
specifying therein the following particulars:(a)Name of the applicant;(b)Address of the
applicant(c)Particulars of the challan with which application fee is paid;(d)Particulars of the lands
applied for and its area;(e)Mineral or Minerals which the applicant desires to extract;(f)Period for
which the lease is required;(g)Action taken on the application and the date of orders.Bihar Minor Mineral Concession Rules, 1972

17. Register of Mining Lease.
- A register of mining leases shall be maintained by each Competent Officer in Form "C".
18. Inspection of Registers.
- The registers maintained by the Competent-Officer under Rules 16 and 17 shall be open to
inspection by any person, on payment of a fee of [Rs. 10] [Inserted vide S. 0.305 dated 26.3.1985.]
only for each register.
19. Refund of application fee.
(1)Where an application for the grant or renewal of a mining lease is refused or is deemed to have
been refused, the fee paid by the applicant shall be refunded to him.(2)Where the whole or any part
of the amount deposited under Rule 13 has not been expended for the purposes specified in that
Rule, it shall be refunded to the applicant.(3)The boundaries of the areas covered by a mining lease
shall run vertically downwards below the surface towards the centre of the earth.
20. Refusal of application for grant and renewal of mining lease.
- The Collector may, for reasons to be recorded in writing and communicated to the applicant, refuse
to grant or renew a mining lease over the whole or part of the area applied for.
21. Conditions.
(1)Every mining lease shall be in Form "D" or in a Form as near thereto as circumstances of each
case may require.(2)The conditions embodied in Form "D" shall be deemed to be conditions
imposed under this Rule.(3)The Collector may impose such other conditions as he deems necessary
in regard to the following, namely:-(a)The time limit, mode and place of payment of rents and
royalties;(b)[ The lessee shall pay to the occupier of the surface of the land such compensation as
may become payable under these Rules.] [Substituted by S.O. 1063 dated 16.10.1989.](c)[ The lessee
shall take such measures for planing in the same area or any other area selected by the Central or
State Government not less than twice the number of trees destroyed by reason of any mining
operation or to the extent possible, the restoration of flora and other vegetation destroyed by such
operation.] [Substituted by S.O. 1063 dated 16.10.1989.](d)The restriction of surface operations in
any area prohibited by any authority;(e)The notice by lessee for surface occupation;(f)The provision
of proper weighing machines;(g)The facilities to be given by the lessee for working other minerals in
the leased area or adjacent area;(h)The earning and working in a reserved or protected forest;(i)The
reporting of accidents;(j)The securing of pits and shafts;(k)The indemnity to Government against
claims of third party;(l)The delivery of possession of lands and mines on the surrender, expiration
or determination of the lease;(m)The forfeiture of property left after determination of the
lease;(n)The power to take possession of plant, machinery, premises and mines in the event of war
or emergency.(o)[ The lessee shall not pay a wage lesser than the minimum wage prescribed by theBihar Minor Mineral Concession Rules, 1972

Central or State Government from time to time under the Minimum Wages Act, 1948.] [Inserted by
S.O. 1063 dated 16.10.1989.](4)The Collector, if he is of the opinion that in the interest of mineral
development it is necessary so to do, may, in any case with the previous approval of the
Government, impose such further conditions as he thinks fit.(5)[ If the lessee makes default in
payment of rent/royalty as required by Rule 26 or commits breach of any of the conditions referred
to in this Rule or embodied in the mining lease Form "D" the Competent Officer shall give notice to
the lessee requiring him to pay the rent/royalty or remedy the breach as the case may be within 30
days from the date of the receipt of the notice and if the rent/royalty is not paid or the breach is not
remedied within such period, the Collector may without prejudice to any proceeding that may be
taken against the lessee, determine the lease and forfeit the whole or part of the security deposit.]
[Inserted by S. O. 199 dated 3.3.1988.]
22. Renewal of mining lease.
(1)Application for renewal of mining lease shall be made in Form "AA" at least [90 days but not
earlier than 180 days] [Substituted by S. O. 305 dated 26.3.1985.] before the expiry of the
lease.(2)Every application for the renewal of mining lease shall be accompanied by:-(a)A fee of Rs.
[2000/-] [Substituted for Rs. 500/- vide S. O. 1063 dated 16.10.1989.](b)[ A valid clearance
certificate of payment of royalty, dead rent, surface rent and cess upto the end of last financial year
[in respect of all the mineral concessions held in the State of Bihar] [Substituted by S.O. 1133 dated
19.8.1978.], to which the application for renewal of a mining lease relates.](c)If an application for
the renewal of a mining lease made within the time referred to in sub-rule (1) is not disposed of by
Collector before the date of expiry of the lease, the period of that lease shall be deemed to have been
extended by a further period of 90 days or ending with the date of receipt of the orders of the
Collector thereon, whichever is shorter.(d)If any application is not disposed of even within the
extended period specified in sub-rule (2) (c) it shall be deemed to have been refused.(e)[ Where an
application for renewal of a mining lease is not accompanied by the papers specified in sub-rules (1)
and (2), it shall be rejected straightway by the Competent Officer within 15 days from the date of its
receipts.] [Existing sub-rule 2 (f) made 2 (e) and new sub-rule 2(f) & 2(g) Inserted by S. O. 1063
dated 16.10.1989.](f)[ Every application for the grant or renewal of mining lease shall be
accompanied by an affidavit showing that he has- [Existing sub-rule 2 (f) made 2 (e) and new
sub-rule 2(f) & 2(g) Inserted by S. O. 1063 dated 16.10.1989.](i)filed uptodate Income-Tax
returns;(ii)paid the Income-Tax assessed on him; and(iii)paid the Income-Tax on the basis of self
assessment as provided in the Income-tax Act, 1961.(g)Every application for grant or renewal of
mining lease shall be accompanied by an affidavit showing-Particulars of area Mineral-wise in the
State which the applicant or any person jointly with him,-(i)already holds under a mining
lease;(ii)has applied for but has not been granted a mining lease; and(iii)being applied for
simultaneously.]
22A. [ [Inserted by S.O. 29 dated 24.3.2001.]
(1)[x x x](2)[x x x] [Rule 22A(1) (2) and (3) deleted vide Section 3 of Amendment Rules, 2008.](3)[x
x x] [Rule 22A(1) (2) and (3) deleted vide Section 3 of Amendment Rules, 2008.](4)The existing
quarrying leases shall not be renewed but it would be allowed to subsist for the remaining period forBihar Minor Mineral Concession Rules, 1972

which they have already been granted on the same terms and condition:Provided that at the end of
the period for which they had been granted the area settled for quarrying will be governed by Rule
52.Explanation I. - The relevant Rules of Bihar Mineral Concession Rules 1972 shall "Mutatis
Mutandis" apply to quarry lease granted under Rule 52.Explanation II. - Existing leases shall not be
renewed nor fresh lease permits shall be granted.]
23. Transfer of lease.
(1)The lessee shall not, without the previous consent in writing of the Collector:-(a)assign, sub-let,
mortgage, or in any manner, transfer the mining lease, or any right, title, or interest therein
including raising rights, or(b)enter into or make any arrangement, contract or understanding
including giving of raising contract whereby the lessee will or may be directly or indirectly financed
to substantial extent by, or under which the lessee's operations or undertakings, will or may be
substantially controlled by, any person or body of persons other than the lessee.(2)Without
prejudice to the provisions of sub-rule (1), the lessee may subject to the condition specified in Rule
6, transfer his lease or any right, title or interests therein, to any person on payment of a fee of [Rs.
100] [Substituted by S. O. 1133 dated 19.8.1978.] [and production of royalty clearance certificate by
lessee and transferee] [Inserted by S.O. 305 dated 26.3.1985.]:Provided that the lessee shall make
available to transferee the original or certified copies of all plants of abandoned workings in the area
and in a belt 3[60 metres] wide surrounding it.(3)The Collector may, by an order in writing
determine any lease at any time if the lessee has, in the opinion of the Collector committed a breach
of any of the provisions of sub-rule (1) or has transferred any lease or any right, title or interest
therein otherwise than in accordance with sub-rule (2) :Provided that 'no such order shall be made
without giving the lessee a reasonable opportunity of being heard.(4)An application for transfer of
mining lease shall be disposed of by the Collector within 90 days from the date of its receipt; and, if
it is disposed of within that period, it shall be deemed to have been refused.
23A. [ Application for the transfer of mining lease. [Substituted by S.O. 305
dated 26.3.1985.]
- The transferor and transferee interested in the transfer shall produce valid clearance certificate of
payment of mining dues such as royalty, dead rent, surface rent and/or cess etc.]
23B. [ [Inserted by S.O. 29 dated 24.3.2001.]
(1)The lessee shall not assign, sub-let, mortgage or in any other manner transfer the quarrying lease
or any right, title or interest vested therein unless prior order of State Government has been
obtained, to any other person.(2)Every lessee seeking prior order under sub-rule (1) shall make an
application to the Competent Officer which shall be accompanied by a letter of consent of the owner
or occupant of the land to the effect that he has no objection for quarrying minor minerals by the
transferee.]Bihar Minor Mineral Concession Rules, 1972

24. Right to [surrender] [Substituted for 'determine' by S.O. 867 dated
21.8.1972.] lease.
(1)The lessee may [surrender] [Substituted for 'determine' by S.O. 867 dated 21.8.1972.] the lease at
any time by giving not less than 6 month's notice in writing to the Competent Officer.(2)The State
Government may determine the lease if it considers desirable in public interest or in case the
property is found damaged by the lessee subject to the condition that three calendar months notice
in writing is given by the Government to the lessee but such a notice will not be required in the event
of war or such other emergency.Explanation. - The determination of the lease in public interest shall
be considered desirable only when the lease is to be determined in the interest of any industry which
has been or will in future be established by Government or which the Government may establish
through a Company, public or private, or through any person or when the Government decide to
conduct mining or quarrying operations of its own [or when the Government is satisfied that the
continuance of mining or quarrying operation is likely to cause grave injury to health or the property
and injury is of such nature and magnitude that it cannot be reasonably compensated and that the
risk of injury is so imminent that the lessee cannot be allowed to run its course until it expires
naturally.] [Inserted by S.O. 305 dated 26.3.1985.](3)The Collector may determine the lease if the
lessee commits any breach of the terms and conditions of the mining lease after the applicant is
given reasonable opportunity of being heard.(4)At the expiry of the lease or on determination of the
lease, the lessee shall deliver up the leased area and all quarries if any, dug therein a proper and
workable state save in respect of any working regarding which the Collector may have sanctioned
abandonment.(5)If the lessee fails to deliver possession after expiry or determination of the lease,
the Collector shall serve an order in writing on the lessee requiring him to deliver possession thereof
to the Collector to show cause, if any, against the order within a time specified therein and if the
lessee fails to deliver possession or show cause or if the Collector reject any cause shown after giving
him reasonable opportunity of being heard, the Collector shall take or cause to be taken such steps
or use or cause to be used such force, as in his opinion, may be necessary for securing compliance of
the order.
25. Execution of lease.
(1)Where a mining lease is granted under Rule 9 (1), [or mining lease renewed under Rule 22]
[Inserted by S.O. 305 dated 26.3.1985.] the formal lease shall be executed within 90 days of the
order sanctioning the lease and if no such lease is executed within the aforesaid period, the order
sanctioning the lease shall be deemed to have been revoked, and in that event the application fee
and the security deposit shall be forfeited:Provided that where the Collector is satisfied that the
applicant for lease is not responsible for the delay in execution of the formal lease, he may permit
the execution of the formal lease even after the expiry of the aforesaid period of 90 days.(2)The date
of the commencement of the period for which a mining lease is granted shall be the date on which
the mining lease deed is executed under sub-rule (1) [in case mining lease is granted under Rule 9
(1)] [Inserted by S.O. 305 dated 26.3.1985.] and the lessee shall be liable to pay rent/royalty from
the date of the execution of the mining lease.(3)[ In the case of renewal of lease the date of
commencement of the mining lease shall be the date on which the previous lease is expired and the
lessee shall be liable to pay rent/royalty/cess from that date.] [Inserted by S.O. 305 datedBihar Minor Mineral Concession Rules, 1972

26.3.1985.]
25A. [ [Inserted by S. O. 29 dated 24.3.2001]
- Lease granted under Rule 52 shall be executed in Form 'D' as contained under Rule 21 of the
rules."]
26. [ Rent/royalty and assessment. [Substituted by S.O. 1133 dated
19.8.1978.]
(1)When a lease is granted or renewed:-](a)[ Dead rent shall be charged at the rates specified in
Schedule I; [Substituted by S.o. 867 dated 21.8.1972.](b)Royalty shall be charged at the rates
specified in Schedule II; and(c)Surface rent shall be charged at the rate specified by the Collector
from time to time for the area occupied or used by the lessee.](2)On and from the date of
commencement of these rules, the provisions of sub-rule (1) shall also apply to the leases granted or
renewed prior to the date of such commencement and subsisting on such date.(3)If the lease
permits the working of more than one mineral in the same area, the Collector may charge separate
dead rent in respect of each mineral:Provided that the lessee shall be liable to pay the dead rent or
royalty in respect of each mineral, whichever be higher in amount.[(4] Notwithstanding any thing
contained in any instrument of lease the lessee shall pay rent/royalty in respect of any minor
mineral own, extracted and removed at the rate specified from time to time in Schedules I and II.]
[Sub-rule (4) omitted and sub-rules (5) to (7) re-numbered as (4) to (6) by S.O. 1133 dated
19.8.1978.](5)The State Government may, by notification in the Official Gazette, amend the first and
second Schedules so as to enhance or reduce the rate at which rents/ royalties shall be payable in
respect of any minor mineral with effect from the date of publication of the notification in the
Official Gazette.(6)The [Competent Officer] [Substituted for 'Collector' by S.O. 867 dated
21.8.1972.], after such enquiry and verification as he may deem necessary of the monthly returns
furnished by the lessee in Form "H" shall assess the amount of rent/royalty payable by the lessee at
the end of the prescribed period.
26A. [ Consolidation of royalty on brick earth. [Substituted by S.O. 259 dated
26.3.1987.]
- Notwithstanding anything contained in these Rules, the State Government shall by notification in
the Official Gazette determine a consolidated amount of royalty which may be revised once in three
years, to be paid by the brick kiln owner/brick earth remover per kiln per annum to the State
Government in a manner prescribed therein on a fixed number of bricks for every classified
area:Provided that the State Government may for the purposes of determining the consolidated
amount of royalty to be so paid classify the places into different categories taking such facts into
account which the State Government think proper: Provided further that if the brick earth
remover/brick kiln owner fails to make payment of the consolidated amount of royalty in the
manner so prescribed, he shall not be allowed to carry on the business and the Competent Officer or
any other officer duly authorised in this behalf by the State Government, shall be competent to stopBihar Minor Mineral Concession Rules, 1972

such business.Explanation. - For the purpose of this Rule-(i)Business means and includes laying,
burning or selling of bricks by brick earth remover/brick kiln owner and such other activities as are
associated with manufacturing of bricks.(ii)For the purpose of this Rule brick, earth remover means
and includes person or persons by whom or on whose behalf the brick earth is removed for
manufacturing bricks.(iii)For the purpose of this Rule brick kiln owner means a person who owns
the brick kiln or on whose behalf bricks are manufactured in that kiln and includes manager, agent
and lessee of such person.]
Chapter IV
27. Grant of quarrying permits in areas other than those in reserved or
protected forests.
(1)On an application made to him, the Competent Officer may grant a quarrying permit in Form "E"
to any person to extract and remove from any specified land within the limits of his jurisdiction any
mineral not exceeding [three thousand cubic metres] [Substituted for '1 lac cubic feet' by S. O. 867
dated 21.8.1972.] in quantity under any one permit, on pre-payment of royalty at the rates specified
in Schedule II. Before granting such permit, the Competent Officer shall satisfy himself that the
requirement of the permit is genuine and that it does not obviate the necessity of obtaining a mining
lease in the area in respect of which the permit for extraction of the mineral has been applied
for.(2)The Competent Officer may refuse the issue of such permits for reasons to be recorded by him
in writing.(3)[ [x x x x] [Omitted by G.S.R. 1085 dated 25.3.1992.]
28. Application for quarrying permit.
(1)An application for quarrying permit shall be submitted to the Competent Officer in Form
'1'(2)Every application for quarrying permit shall be accompanied by a fee of [Rs. 2000/]
[Substituted for Rs. 200/- by G.S.R. 1085 dated 25.3.1992.]. (but for Bangla Brick kiln the fee for
quarrying permit shall remain Rs. 200/-) only(3)Every application for quarrying permit shall be
accompanied by a valid and up-to-date clearance certificate of payment of mining dues, if any.(3A)[x
x x x x] [Omitted by S.O. 1133 dated 19.8.1978.](4)Every application of a quarrying permit shall, if
the lands from which the minor mineral is to be extracted are raiyati lands, be accompanied by a
written consent letter from the occupant of such lands to the effect that he has no objection to the
extraction of the mineral by the applicant.(5)The application fee and royalty shall not be refunded if
the raiyat subsequently refuses permission to the permit holder to work in the raiyati area.(6)[ Every
application for the extension of the period of the permit shall be accompanied by a fee Rs. 200.]
[Inserted by S. O. 52. dated 5.1.1976 effective from 1.1.1975.](7)[ The area applied for grant of
quarrying permit shall be in a compact block covering not more than 10 acres (4 hectares).]
[Inserted by S.O. 1133 dated 19.8.1978.]Bihar Minor Mineral Concession Rules, 1972

28A. [ Disposal of application for quarrying permit. [Inserted by S. O. 52.
dated 5.1.1976 effective from 1.1.1975.]
- An application for the grant of quarrying permit shall be disposed of by the Competent Officer
within 30 days from the date of its receipt.](2)If any application is not disposed of within the period
specified in sub-rule (1), it shall be deemed to have been rejected [x x x] [Omitted by S. O. 305 dated
26.3.1985.] and disposed of after the said period of 30 days but not exceeding 60 days from the date
of the receipt of the application.[x x x] [Proviso omitted by S. O. 305 dated 26.3.1985.]
29. Conditions on which the quarrying permit shall be granted.
(1)Every quarrying permit granted under Rule 27 (1), shall contain a condition that the depth of the
pit below the surface shall not ordinarily exceed [3 metres] [Substituted for '10 feet' by S.O. 867
dated 21.8.1972.] and that for digging pits beyond [3 meters] [Substituted for '10 feet' by S.O. 867
dated 21.8.1972.] the permit holder shall obtain the permission of the Competent Officer.(2)Any
quarrying permit granted under Rule 27 (1) may contain such other conditions as the Competent
Officer may deem necessary in regard to the following matters, namely:-(a)Time limit, mode and
place of payment of rents and royalties;(b)Compensation for damage to the land covered by
permit;(c)Felling of trees in consultation with Divisional Forest Officers in case of forest areas and
in consultation with the Additional Collector in other areas;(d)Restriction on surface operation in
any area prohibited by any authority;(e)Reporting of accidents;(f)Indemnity to Government against
claims of third parties;(g)Period within which the minor mineral shall be extracted and removed
and delivery of possession over lands on the expiry of such period or on the removal of the quantity
of the minor mineral for which the permit is valid;(h)Forfeiture of property left after cancellation of
the permit; and(i)[ Disposal of minerals in stock at site after expiry of the permit.] [Added by S.O.
1133 dated 19.8.1978.](3)In case of breach of any of the conditions subject to which the permit is
granted, the Competent Officer may cancel the permit issued by him. On cancellation of the permit,
the quarried material lying on the land from which they are extracted shall become the absolute
property of the Government and may be sold by public auction by the Competent Officer.(4)[ The
Competent Officer after such enquiry and verification, as they may deem necessary, shall assess
amount of royalty and penalty for the excess quantity at the end of the prescribed period]
[Substituted by S. O. 305 dated 26.3.1985.]
30. Grant of quarrying permits in Reserved and Protected Forest areas.
(1)In Reserved Forest areas where the actual mining operation involved is merely removal from the
surface or from a depth not exceeding, [1.5 meters and to a limit of 250 cubic metres] [Substituted
for '5 feet and to a limit of 10,000 cubic feet' by S.O. 867 dated 21.8.1978.] quarrying permit in Form
'E' shall be granted by Divisional Forest Officer of area concerned. While granting the quarrying
permit, the Divisional Forest Officer of the area concerned will ensure that the quarrying permit is
not taken out by intending applicant with a view to obviating the necessity of obtaining a mining
lease. In order to ensure this, the Divisional Forest Officer shall not grant quarrying permit more
than once to the same person from the same area during any one calendar year without priorBihar Minor Mineral Concession Rules, 1972

permission of Government. For this purpose besides occasional inspection of the concerned areas,
the Divisional Forest Officer will act as an officer of Mines Department of the State Government and
will obtain from and comply with the instructions of the said Department through the Chief
Conservator of Forest or the Collector of the District.(2)An application in Form T for the grant of
quarrying permit within Reserved or Protected Forest areas shall be accompanied by a fee [Rs.200.]
[Substituted for Rs. 20/- by S.O. 52 dated 5.1.1976 effective from 1.1.1975.](3)The applicant shall
also file an up-to-date clearance certificate in respect of mining dues.(3a)[ Every application for
quarrying permit in Reserved and Protected Forest areas shall be accompanied by a certificate of
approval in Form 'K' or if the certificate of approval has expired a copy of the application made to
the Competent Authority, for its renewal.] [Inserted by S.O. 52 dated 5.1.1976.](4)The terms and
conditions shall be the same as indicated in Rule 29 of these Rules but subject always to the
condition indicated in sub-rule (1).(3)[ Every application for the extension of the period of the
permit shall be accompanied by a fee Rs. 200.] [Inserted by S.O. 52 dated 5.1.1976.]
Chapter V
31. Power to rectify apparent mistakes.
- Any clerical or arithmetical mistake in any order passed by the Government or any other authority
or Officer under these Rules and any error arising therein from accidental slip or omissions, may
within two years from the date of the order, be corrected by the Government authority or the Officer,
as the case may be:Provided that no order prejudicial to any person shall be passed unless he has
been given a reasonable opportunity for stating his case.
32. Submission of copy of lease.
- Every person holding a mining lease or sub-lease from a private person or before the
commencement of these Rules, shall submit to the Competent Officer in whose jurisdiction the area
or areas covered by such lease or sub-lease is or are situated a certified or true copy of the lease or
sublease.
32A. [ Availability of the areas for re-grant to be signified by an entry in
register for mining lease. [Inserted by S.O. 1133 dated 19.8.1978.]
- No area which was previously held under a mining lease or in respect of which an order had been
made for the grant thereof but the applicant has died before the execution of a lease or in respect of
which the order granting lease has been revoked under sub-rule (1) of Rule 25, shall be available for
re-grant unless an entry to the effect has been made in the register referred to in Rule 17. The date
from which the area shall be available for re-grant shall be notified in the District Gazette at least 60
days in advance [specifying a date not earlier than 30 days from the date of such notification in the
Gazette from which areas shall be available for re-grant.]Bihar Minor Mineral Concession Rules, 1972

32B. [ [Inserted by S.O. 1133 dated 19.8.1978.]
Premature applications-Application for the grant of a mining lease in respect of the area in
which-(a)no notification has been issued under Rule 32.A, or(b)if any such notification has been
issued the period specified in the notification has not expired:shall be deemed to be premature and
shall not be entertained and the fee if any paid in respect of any such application shall be refunded.]
33. [Challans, Registers, Returns and Signboard. [Substituted by S.O. 305
dated 26.2.1985.]
- Every lease or permit holder who intends to despatch minerals, by rail, road or river shall issue
challan in Form 'F' to the Carriers who shall produce the same on demand by any Competent Officer
[or Collector or Deputy Director (Mines) or Additional Director (Mines) or Director of Mines or any
other officer authorised by them.](2)Every lease or permit holder shall maintain Register in Form
'G' in which day to day transaction shall be entered. 1[He shall also have to display a signboard
exhibiting following information (i) Name of kiln-owner, (ii) mauza and plot no. of the land on
which kiln, is situated (iii) volume of Brick earth excavated so far (iv) date of starting brick-laying (v)
date of firing the kiln (vi) no. of rounds already completed by kiln (vii) stock of bricks on site on the
day.](3)Every lessee or permit holder shall submit every month to the Competent Officer a true and
correct return for minerals in Form 'H' by the fifteenth of the following month to which it
relates.(4)Every lessee or permit holder shall give all reasonable facilities to the Competent Officer
[or Director of Mines or Additional Director of Mines or Deputy Director of Mines] [Substituted by
S.O. 305 dated 26.2.1985.] or any other Officer authorised by the Collector in this behalf to inspect,
verify and check the accounts of the minerals.(5)[ If the accounts, returns and other evidence
produced by the lessee; permit-holder or any other person who has removed minerals, are in the
opinion of any of the officers authorised under Rule 33 (1) incorrect, incomplete or unreliable either
wholly, or partly, the officer concerned, shall report to the Competent Officer who shall proceed to
assess to the best of his judgement, the amount of royalty due from the assessee:Provided that if the
Competent Officer himself has formed the opinion he shall proceed forthwith to assess to the best of
his judgement, the amount of royalty due from the assessee:Provided further that the purchaser of
minor mineral who intends to obtains royalty/cess clearance certificate from the Competent Officer
shall retain the challan in Form 'F' issued to the carrier. The Competent Officer on production of
Challan in Form 'F' shall issue royalty/cess clearance certificate of the quantity shown as despatched
in challan.] [Inserted by S.O. 305 dated 26.2.1985]
34. Application of these Rules to all Renewals.
- Where a mining lease granted before the commencement of these Rules is renewed after such
commencement, these Rules shall apply in relation to such renewal as they apply in relation to the
renewal of a mining lease granted after such commencement.Bihar Minor Mineral Concession Rules, 1972

35. Interpretation of mining lease.
- Every lease shall provide for submission by the lessee of any question of dispute regarding the
lease or any other matter or thing, construction of a term or condition in the lease or anything
connected with the mining of minor minerals specified in the lease, or the working or non-working
of the mine or the quarry, and the amount of royalty or dead rent or its mode of payment to the
Competent Officer, for the decision of the Collector, which shall be final and binding on the lessee.
36. Relaxation of Rules in special cases.
- In any case in which the Government is of the opinion that public interest so requires, it may grant
a mining lease or authorise the grant of a quarrying permit on terms and conditions other than
those prescribed in these Rules.
37. Mode of realisation of rents, royalties and penalty.
- The amounts of rent, royalty or penalty payable under these Rules, shall be recoverable as a public
demand under the Bihar Public Demands Recovery Act, 1914.
38. Penalty for failure to furnish documents.
- Should any lessee or his transferee or assignee fail to furnish the documents required to be
maintained under these Rules or refuse entry or inspection by the Competent Officer or [Director of
Mines or Additional Director of Mines or Deputy Director of Mines] [Substituted by S. O. 861 dated
11.7.1983.] or Collector or Commissioner or any Officer authorised by the Government, he shall be
punishable with simple imprisonment for a term which may extend to three months or with fine
which may extend to one thousand rupees or with both.
39. Penalty for filing wrong returns or maintaining-incorrect accounts or for
failure to issue challan.
(1)If any lessee or permit-holder files wrong returns or maintains incorrect accounts, [or fails to
issue challans] [Inserted by S.O. 867 dated 21.8.1972.] he shall be liable to a penalty of a sum up to
[Rs. 2000/-.] [Substituted by S.O. 305 dated 26.3.1985.] and shall also be liable to have his mining
lease terminated or quarry permits cancelled:Provided that before final orders are passed by the
[Collector or Competent Officer] [Substituted for 'Collector' by S.O. 847 dated 21.8.1985], he shall be
given a reasonable opportunity of showing cause against the same.(2)If any lessee or permit holder
fails to file the return as specified in Rule 33 (3) within the prescribed period he shall be liable to pay
as penalty a sum of [Rs. 20] [Substituted by S.O. 305 dated 26.3.1985.] [subject to maximum of
rupees two thousand and five hundred] [Substituted by S.O. 199 dated 2.3.1988.] after expiry of the
prescribed date during the period the lessee or permit holder fails to furnish the required return.[ x
x x x] [Omitted by S.O. 305 dated 26.3.1985.](3)[ If any lessee/permit-holder fails to display
signboard as prescribed in Rule 33 (5) he shall be liable to penalty of a sum of Rs. 1000/-.]Bihar Minor Mineral Concession Rules, 1972

[Substituted by S.O. 305 dated 26.3.1985.]
40. Penalty for unauthorised extraction and removal of minor minerals.
- [(1) Whoever is found to be extracting or removing minor minerals or on whose behalf such
extraction or removal is being made he be an agent, a manager, an employee or a contractor or a
sub-lessee, otherwise than in accordance with these Rules, shall be presumed to be party to the
illegal removal of the minor mineral and every such person shall be punishable with simple
imprisonment which may extend to six months or with fine, which may extend to rupees five
thousand or with both.] [Substituted by S.O. 305 dated 26.3.1985.](2)Whenever any person is found
extracting or removing or transporting minor minerals in contravention of the provisions of these
Rules, the [Competent Officer or Deputy Director (Mines) or Additional Director (Mines) or
Director of Mines] [Substituted by S.O. 305 dated 26.3.1985.] may seize the minor minerals together
with all tools and equipments used in committing such offence.(3)The [Competent Officer or Deputy
Director (Mines or Additional Director (Mines) or Director of Mines] [Substituted by S.O. 305 dated
26.3.1985.] who has seized the minor minerals or the tools and equipments under sub-rule (2), may
release the same on the execution by the claimant thereof of a bond for the production of the
property so released, if and when so required before the Court having jurisdiction to try the offence
on account of which the seizure has been made.(4)The [Competent Officer or Deputy Director
(Mines) or Additional Director (Mines) or Director of Mines] [Substituted by S.O. 305 dated
26.3.1985.] may, without orders from a Magistrate, and without a warrant, arrest any person who is
found extracting or removing or transporting minor minerals in contravention of these Rules.(5)The
[Competent Officer or Deputy Director (Mines) or Additional Director (Mines) or Director of Mines]
[Substituted by S.O. 305 dated 26.3.1985.] making an arrest under sub-rule (4) of these Rules shall
within 24 hours of the arrest, take or send the person arrested before the Magistrate having
jurisdiction in the case along with a complaint in writing regarding the offence committed by the
person.(6)The [Competent Officer or Deputy Director (Mines) or Additional Director (Mines) or
Director of Mines] [Substituted by S.O. 305 dated 26.3.1985.] may release the person arrested on his
executing a bond to appear before the Magistrate having jurisdiction in the case if and when so
required.(7)If any driver of any carrier while carrying minor minerals fails to furnish the Challan in
Form "F" or refuses inspection of such Challan by the Competent Officer or [Director of Mines or
Additional Director of Mines or Deputy Director of Mines] [Substituted by S.O. 305 dated
26.3.1985.] or Director (Mines) or Collector or Commissioner or any officer authorised by the
Collector, he shall be punishable with simple imprisonment which may extend to six months or with
fine which may extend to one thousand rupees or with both.(8)[Whoever removes minor mineral
without valid lease/permit or on whose behalf such removal is made otherwise than in accordance
with these Rules he be an agent, Manager, contractor or a sub-lessee, shall be presumed to be a
party to the illegal removal of the minor mineral and shall be liable to pay [the price thereof and the
Government may also recover from such person rent, royalty or taxes as the case may be, for the
period during which the land was occupied by such person without any lawful authority] [Inserted
by S. 0.1133 dated 19.8.1978 and Omitted by S.O. 262 dated, 5.3.1983 and again Inserted by S.O.
305 dated 26.3.1985.] without prejudice to other action being taken against him under these Rules
or any other law for the time being in Force.](9)[ Notwithstanding anything contained in Rule 40
(8) hereinbefore whosoever, under the terms of an agreement other than an agreement under theseBihar Minor Mineral Concession Rules, 1972

Rules at any time has received or receives cost of minor mineral/material including royalty under
the terms of the said agreement shall deposit that royalty which is included in such cost of
mineral/material in the manner prescribed in Rule 43 hereinafter, within seven days from the date
of receipt of such cost of mineral/material.Any royalty received as such by such person before the
commencement of this Rule shall be deposited by him within fifteen days from the date of
commencement of this Rule :Provided that if a sum equal to the royalty included in the cost of
mineral/ material so received has already been paid or deposited prior to receipt of cost of the
mineral/material including royalty by him he shall not be required to deposit the royalty said
above:Provided further that any royalty payable under this Rule, if not paid when due be recovered
with interest @ 15 percent per annum as an arrear sum of public demand"] [Inserted by S.O. 1063
dated 16.10.1989.](10)[ To prevent evasion of royalty it is provided that works contractor shall
purchase the minerals from lessee/permit holder and authorised dealers only and no Works
Department shall receive the bill which the works contractors submit to recover cost etc. of mineral
used by them in completion of the works of the Works Department under any agreement from the
works contractor if the said bill is not accompanied by an affidavit in Form 'M' with particulars in
Form 'N' of these Rules alongwith a photo copy of the said affidavit and particulars. It shall be the
duty of the officer who receives or on whose behalf the said bill is received to send the photo copy of
the Affidavit and particulars to the District Mining Officer/Assistant Mining Officer within whose
jurisdiction the mineral was allegedly purchased, for verification.If contents of the said affidavit on
verification by the concerned District Mining Officer/Assistant Mining Officer is found to be false
either wholly or partly it shall be presumed that the concerned mineral was obtained by illegal
mining and in that event the said District Mining Officer/Assistant Mining Officer shall take action
as prescribed in these Rules against the maker of the said affidavit:Provided that if the Works
Contractor deposits or pays the royalty in respect of the mineral so consumed/supplied by him as
shown in the aforesaid affidavit and particulars the said District Mining Officer/Assistant Mining
Officer in his discretion may not take action as prescribed in this Rule".Explanation. - For the
purposes of this Rule-(i)"Works Department" means departments of the Central or State
Government including Company, Corporation, Undertakings, Autonomous body of the Government
engaging Works Contractors for any kind of construction on its behalf.(ii)"Works Contractor" means
an individual, a firm, a company, an association or body of individuals who under an agreement,
with the Works Department work for the said Department.]
41. Offence cognizable upon written complaints.
- No Court inferior to that of a Magistrate of the First Class shall try any offence punishable under
these rules and no Court shall take cognizance of any offence under these rules, except upon a
complaint made in writing by the [Competent Officer or Deputy Director of Mines or [Additional
Director of Mines or Director of Mines] [Substituted by S.O. 1133 dated. 19.8.1978.] or any other
Officer empowered by the Government] [Inserted by S.O. 1063 dated 16.10.1989.],
42. Compounding of offence.
- The Competent Officer may, with the approval of the [Collector] [Substituted for 'Commissioner'
vide S.O. 867 dated 21.8.1972.], compound a case instituted against any person.[Where a case hasBihar Minor Mineral Concession Rules, 1972

been instituted by the [Deputy Director of Mines] [Substituted by S.O. 1133 dated. 19.8.1978.] or
[Additional Director of Mines or Director of Mines] [Inserted by S. O. 305 dated 26.3.1986.] or any
other officer empowered by the Government] may, with the approval of the Commissioner,
compound a case instituted against any person.]
43. How the fees and deposit to be made.
- Any amount payable under these Rules shall be paid into Treasury by means of a Challan under the
head "XXXII-C-Miscellaneous Social and Development Organisation- Miscellaneous-(i) Fees for
grant and renewal of Mineral Concession (ii)-Rent and royalties from Mining lessees and licensees".
43A. [ [Inserted by S.O. 1063 dated 16.10.1989.]
The Government may, without prejudice to the provisions contained in the Act or any other rule in
these Rules; charge simple interest at the rate [24 per cent] per annum on any rent, royalty or fee
(other than the fee payable under Rule 47 (A) or other sum due of the Government.]
44. Savings and repeal.
(1)On the commencement of these Rules, the Bihar Minor Mineral Concession Rules, 1964, shall
cease to be in force, except as regards things done or omitted to be done before such
commencement.(2)The provisions of Rule 24 (2) of the Bihar Minor Mineral Concession Rules, 1964
which have been incorporated in these rules and numbered as rule 26(2), and which were validated
by the Bihar Land Reforms Laws (Regulating Mines and Minerals) Validation Act, 1969 (Central
Act. No. 42 of 1969), shall continue to be in force under these Rules.
Chapter VI
Appeal and Revision
45. [ Application for revision. [Substituted by S.O. 861 dated 11.7.1983.]
(1)(a)The Commissioner, at any time for reasons to be recorded in writing, may on his own motion,
and where any person aggrieved by any order passed by the Collector under these rules files an
application within 60 days from the date of communication of the order, and within 75 days from
the date on which an application is deemed to have been refused by the Collector, if no
communication is made of such refusal, shall start a proceeding for revision of the order:Provided
that an application for revision may be entertained even after the time specified as above if the
applicant satisfies the Commissioner that he had sufficient cause for not making the application
within time.](b)[xxxx] [Sub-rule (b) omitted and its proviso made proviso to sub-rule (a) by S.O.
305 dated 26.3.1985.](2)In every '[proceeding] under sub-rule (1) against the order of Collector
refusing to grant or renew a mining lease, any person to whom a mining lease was granted or whose
lease was renewed in respect of the same area or for a part thereto, shall be impleaded as aBihar Minor Mineral Concession Rules, 1972

party.(3)Alongwith the application under sub-rule (1) the applicant shall submit as many copies
thereof as there are parties impleaded under sub-rule (2).(4)[ On receipt of the application and
copies thereof under sub-rule (2), the Commissioner shall send a copy of the application, and where
proceeding is started by him on his own motion, under sub-rule (1) he shall send notices of starting
the proceeding and reasons thereof to each of the parties impleaded specifying a date on or before
which he may make representation, if any, against the revision application.] [Inserted by S.O. 305
dated 26.3.1985.]Explanation. - For the purposes of this rule, where the Collector has failed to
dispose of an application for the grant or renewal of a mining lease within the period specified in
respect thereof in these rules, the Collector shall be deemed to have made an order refusing the
grant or renewals of such leases on the date on which such period expires.
46. Orders on revision application.
(1)On receipt of an application for revision under Rule 45 copies thereof [and where proceeding is
started by the Commissioner on his own motion] [Substituted by S.O. 861 dated 11.7.1983.], notices
thereof shall be sent to the Collector and to all the impleaded parties calling upon them to make
such comments as they may like to make within a specified period, and if no comments are received
by the Commissioner within that period, it shall be presumed that the party or the Collector, as the
case may be, which has omitted to make such comments, has no comments to make and the case
may be decided by the Commissioner.(2)The Commissioner may call from the Collector the record
of the case in respect of which a revision application has been filed before him, [or in respect of
which a proceeding has been started by him] [Substituted by S.O. 861 dated 11.7.1983.],(3)After
considering the records referred to in [sub-rule (2) the Commissioner may confirm] [Substituted for
sub-rules (2) & (3) by S.O. 867 dated 21.8.1972.], modify or set aside the order or pass such other
order in relation thereto as the Commissioner may deem just and proper and his order shall be
final.(4)Pending the final disposal of an application for revision, the Commissioner may, for
sufficient cause, stay the execution of the order against which any revision application has been
made.
46A. [ [Inserted by S.O. 305 dated 26.3.1985.]
- The Commissioner, may at any time but before the expiry of six years from the date of the order
either on his own motion or on an application filed before him, call for and examine the record of
any proceeding in which any order has been passed by any Competent Officer appointed under Rule
(2) (iii) or a Deputy Director of Mines, appointed under Rule (2) (vi), for the purpose of satisfying as
to the legality or propriety of such order and may after examining the records and making or causing
to be made such enquiry as he may deem to be necessary, pass any order which he thinks
proper.The Commissioner may, delegate this power to any subordinate officer whom he thinks
fit:Provided that no order under this Rule shall be passed without giving the applicant as also the
authority whose order is sought to be revised or their representative, a reasonable opportunity of
being heard:Provided further that where an application is filed seeking revision of any order, such
an application shall be entertained only if it is made within ninety days of the date of
communication of the order sought to be revised.The application should be accompanied by a
treasury receipt showing that a fee of Rs. 50/- has been paid into the Govt. Treasury or any branchBihar Minor Mineral Concession Rules, 1972

of the State Bank of India doing treasury business to the credit of the State Govt, under the head of
Account "XXXII-C Miscellaneous-Social and Development Organisation-Miscellaneous (i) Fees for
grant and renewal of mineral concession (ii) Rent and Royalties from mining leases and licences.]
47. Appeal.
- [(1) Any person aggrieved by an order passed by the Competent Officer in exercise of the powers
conferred on him by these Rules, may within a period of 30 days from the date of such order, prefer
an appeal to the Deputy Director of Mines of the area concerned:Provided that the Deputy Director
of Mines may condone delay, not exceeding 60 days, in filing the appeal on reasonable
grounds:Provided further that the Deputy Director of Mines may, with the previous approval of the
Director of Mines, condone any delay exceeding 60 days but not exceeding 180 days in filing the
appeal.] [Substituted by S.O. 1133 dated 19.8.1978.](2)A fee of Rs. 25 shall be paid in respect of each
appeal.The memo of appeal shall be accompanied by Treasury receipt showing that the appeal fee
has been paid into Government Treasury or in any branch of the State Bank of India doing treasury
business to the credit of the State Government under the head of account
"XXXII-C-Miscellaneous-Social and Development Organisations-Miscellaneous-(i) Fees for grant
and renewal of Mineral Concessions (ii) Rent and royalties from Mining leases and licenses".(3)No
appeal against the orders of the Competent Officer passed under Rule [26 (6)] [Substituted by S.O.
1133 dated 19.8.1978.], shall be admitted unless the applicant has paid 50 per cent of the amount
assessed by the Competent Officer.(4)The Appellate Authority may confirm, modify or set aside the
order under appeal after giving the applicant an opportunity of being heard and, if necessary, after
considering the report of the Competent Officer concerned.(5)[ If the Appellate Authority modifies
an order passed by the Competent Officer which has the effect of giving relief in the matter of
Rent/Royalties, he shall forthwith forward one certified copy and three true copies of the order to
the Mines Commissioner.] [Inserted by S.O. 305 dated 26.3.1985.]
48. [ Modality for fixation of price of minerals. [Inserted by S.O. 1563 dated
8.10.1976.]
(1)On a report from Competent Officer, the Collector of the district may fix the price of any minerals
in the public interest keeping in view the following factors:-(a)The cost of production;(b)Handling
charges;(c)Transport cost,(d)Royalty, Sales Tax and other taxes and cesses;(e)Margin of
profit;(f)Any other local condition.(2)The Collector of the district shall obtain the approval of the
Government to the price fixed by him before enforcing the same in his district.(3)The State
Government may issue, instructions to Collector from time to time regarding the factors to be taken
into consideration for fixation of prices.]
49. [ [Inserted by S.O. 305 dated 26.3.1985.]
(1)Every person who carried business of minor minerals beyond any lease hold area shall obtain a
licence from the [Competent Officer in Form 'L]" which shall be displayed at a conspicuous place of
business] and shall maintain proper accounts of purchase and sale of all such minerals in a registerBihar Minor Mineral Concession Rules, 1972

in Form 'G' which shall be produced before the Commissioner, Director of Mines and Additional
Director of Mines or Deputy Director of Mines or Competent Officer or any other Officers
authorised by the Government, for inspection. [Every application for obtaining licence in Form "L"]
[Inserted by S.O. 1063 dated 16.10.1989.] shall be accompanied with a fee of [Rs. 500 (Five
Thousand Rupees)] [Substituted by S.O. 29 dated 24.3.2001.](a)[ Every such licence shall be valid
for one calender year; [Inserted by S.O. 305 dated 26.3.1985.](b)Every such licence may, be renewed
on application which shall be accompanied by a fee of [Rs. 1000 (One thousand Rupees)](2)Every
such person as mentioned in (1) shall issue a transport challan in Form 'F' to every carrier, truck,
tractor or bullock cart while despatching minerals for his stock.(3)If any person as mentioned in (1)
fails to maintain a register in Form 'G' or [obtain Form 'L' or"] [Substituted by S.O. 29 dated
24.3.2001.] issue a challan in Form 'F', shall be punishable with a simple imprisonment which may
extend to one year or with fine which may extend upto Rs. 1000/- (One thousand) or with
both.][Chapter VII] [Inserted by S.O. 1063 dated 16.10.1989.]
50. [ Payment of compensation to owner of surface rights etc. [Inserted by
S.O. 1063 dated 16.10.1989.]
(1)The holder of a prospecting licence or a mining lease shall be liable to pay to the occupier of the
surface of the land over which he holds the prospecting licence or as the case may be the mining
lease, such annual compensation as may be determined by an officer appointed by the State
Government by Notification in this behalf in the manner provided in sub-rules (2) to (4).(2)In case
of agricultural land other than the land referred to in sub-rule (4) the amount of annual
compensation shall be worked out on the basis of the average annual net income for the cultivation
of similar land for the previous 3 years.(3)In case of non-agricultural land, the amount of annual
compensation shall be worked out on the basis of average annual letting value of similar land for the
previous three years;(4)The annual compensation referred to in sub-rule (1) shall be payable on or
before such date as may be specified by the State Government in this behalf.]
51. [ Assessment of compensation for damage. [Inserted by S.O. 1063 dated
16.10.1989.]
(1)After termination of prospecting licence or mining lease, the State Government shall assess the
damage, if any, done to the land by the prospecting or mining operations and shall determine the
amount of compensation payable by the licensee or as the case may be the lessee to the occupier of
the surface land.(2)Every such assessment shall be made within a period of one year from the date
of termination of the prospecting licence or mining lease and shall be carried out by an officer
appointed by the State Government by Notification in this behalf.]
52. [ [Added by S.O. 29 dated 24.3.2001.]
(1)(i)For the purpose of grant of quarrying lease by auction in respect of the mineral notified under
Rule 9A, the Collector shall notify the following particulars of the area, namely:-(a)Toposheet No.
extent of the area and boundaries.(b)Name of village, Circle, Plot No. Khata No. etc.(c)The period ofBihar Minor Mineral Concession Rules, 1972

quarrying lease.Provided that the period of quarrying lease shall not be less than five years and
extent of the quarrying lease area shall not be more than 2 (two) acres.(ii)Date of auction shall be
notified before period of one month from the date of auction.(2)Every bidder of mining lease shall
file the following documents five days before the auction:-(i)Clearance Certificate in respect of
mining dues, such as royalty or dead rent and surface rent as obtained from Competent
Officer.(ii)Every application shall be accompanied by an affidavit stating that the applicant
has:-(a)Filed up-to date Income Tax return.(b)Paid the Income Tax assessed on his total
income.(iii)Deposited the amount equivalent to [10 (Ten) percent] of auction amount as security,
which shall be adjusted with the last instalment of auction amount if the mining lease holder is not
otherwise defaulter in payment. In case of unsuccessful bidder the security deposit shall be refunded
by the Collector within two months after the grant of quarry lease.(3)Withdrawal from bidding-Any
bidder, who once has submitted documents as mentioned in sub-rule (2) shall not be withdrawn till
the grant of quarry lease is made in respect of the said area.(4)Payment of bid amount-The bid
amount shall be deposited in yearly basis in equal instalments and each instalment shall be
deposited before 31st January:[Provided that notwithstanding anything repugnant in these Rules or
otherwise the settlee shall pay extra royalty for the quantity of stone extracted and dispatched in
excess of the quantity equivalent to bid amount.] [Added by Section 5 of Amendment Rules,
2008](5)Default in payment-If any instalment shall not be deposited before prescribed period, 24
percent simple interest shall be charged upto two months and after that action for cancellation shall
be taken.(6)Preference in auction-The Collector shall give preference to Public Sector Undertaking
of the State or Central Government, Local Bodies and Co-operative Societies duly registered under
Bihar & Orissa Cooperative Societies Act, 1935 for grant of quarry lease by public auction in the
following manner:-(a)When they have not participated in any Public auction.(b)In case of
Co-operative Societies, if they give written offer for more than 5 percent higher amount or minimum
auction amount whichever is higher within 48 hours after Public auction.(c)In case of Public
Undertaking of State or Central Government and local bodies, if they give written offer for more
than 5 percent higher amount than the Co-operative Societies within 48 hours after Public auction,
where Co-operative Societies do not give any written offer, in that case of Public Sector Undertaking
of State or Central Govt, and local bodies give written offer for more than 10 percent higher amount
than the highest bid amount or minimum auction whichever is higher within 48 hours after Public
auction.Explanation. - Preference shall be given to only those Co-operative Societies whose
members/share-holders usually work as labourers in Panchayat/Panchayats where such mineral
deposit occur residing in the Panchayats for which the Societies has been formed and do not own
more than five acres of agricultural or homestead land.]
53. [ Notwithstanding anything contained in the Bihar Minor Mineral
Concession Rules, 1972 to the contrary. [Inserted vide Notification No. 230/M
dated. 4.2.2010.]
(1)No mining lease for stone shall be granted.(2)Existing leases for stone granted under Rule 9 and
Rules 52 would be allowed to subsist for the remaining period for which they have already been
granted but they shall not be renewed thereafter:Provided where period of lease has expired before
coming into force of these Rules but requisite statutory approval from Govt, of India has been
received before enforcement of these Rules, lessee may be entitled to renewal subject to fulfillmentBihar Minor Mineral Concession Rules, 1972

of other statutory obligation:Provided further that in public interest, if the State Government is
satisfied that quarrying or mining of stone may not adversely affect ecology and environment and
further there is requirement of stone for public use, it may relax the above restriction in any area for
such period as it may deem fit necessary.Explanation. - "Stone" means building stones and includes
boulders, gravel, shingle, lime shell, kanker and limestone used in kilns for manufacturing of lime
used as building material and lime shell used for manufacture of bottoms, chalcedony pebbles used
for ball mill purpose only, Quartzite and sandstone when used for purposes of building or for
making road metal and household utensils, slate and shell when used for building material, stone
used for making household utensils including grinding stone, stone sets and stone bricks, granite (In
case of use for decorating stone) and marble.][Schedule I] [Substituted for Rs. 9,000 by Act 7, 2006
w.e.f. 19.4.2006.][See Rule 26(1) (a)]Dead Rent
Period Rate of dead Rent
(1) (2)
Rate per year for entire period of
leaseRs.[18,000] [Substituted for Rs. 9,000 by Act 7, 2006 w.e.f.
19.4.2006.]per acre per year
[Schedule II] [Schedule II Substituted by Act 7, 2006 w.e.f. 19.4.2006.][See Rule 26 (1) (b)]Royalty
Sl. No. Name of MineralsRate per
cubic
metre(in
Rupees)
1 2 3
1. (a) Boulder, Gravel, shingle 63.30
 (b) Store settled by auctionAuction
amount in
case of
auction
2.(a) Boulder, Gravel, Shingle
which is used for making chips125.00
 (b) Stone settled by auctionAuction
amount in
case of
auction.
[Provided that notwithstanding anything repugnant
in theseRules or otherwise the settlee shall pay extra
royalty for thequantity of stone extracted and
dispatched in excess of thequantity equivalent to bid
amount.] [Added proviso by Section 6 of Amendment
Rule, 2008. It shall come into force with effect from
29th November, 2004.]
3.(a) Ordinary sand used for
construction purpose32.00Bihar Minor Mineral Concession Rules, 1972

 (b) Ordinary sand of settled ghat
by auctionAuction
amount in
case of
auction
4.Brick earth (equivalent to 400
standard bricks)8.00
5.Ordinary clay/earth used for
manufacturing of Ranigaj
tilescommercial use or for filling
or levelling purposes
inconstruction of embankments,
road, railways and buildings.15.00
6.Ordinary clay which is used for
commercial works.2.00
7.Lime shell, kanker and limestone
used in kilns formanufacturing of
lime used as building material
and lime shellused for
manufacture of bottoms.75.00
8. Murram 38.00
9.Chalcedoney pebbles used for ball
mill purpose only.50.00
10.Quartzite and sandstone when
used for purposes of building
orfor making road metal and
household utensils.50.00
11. Reh matti 18.00
12. Saltpetre 20.00
13.Slate and shell when used for
building material.50.00
14. Fullers earth 65.00
15.Stone used for making household
utensils including grindingstone.25.00
16. Stone sets and stone bricks. 50.00
17. Stone dust10 percent
of sale
price
18.Granite (In case of use for
decorating stone per hundred) 
 (i) Block more than 60 c.m. 375.00
 (ii) Block less than 60 c.m. 188.00Bihar Minor Mineral Concession Rules, 1972

19. All other minerals25
(Twenty
five) per
centum of
sale price.
Note:- In respect of minerals mentioned in SI. No. 1 and 2 the rate of royalty shell be applicable for
the area notified by the Department.
III
Form A[See Rule 9 (2)]Form of application for Mining Lease for Minor MineralsDated.......day
of.......19ToThe Collector,...................Sir,I/We have the honour to apply for the grant of Mining
Lease under the Bihar Minor Minerals Rules,
1972.Received.......................on.................................(dated)......................................(Initial)A sum of
Rs.............being the fee in respect of this application payable under Rule 9 (3) of the said rules has
been deposited in............... (name of Treasury or Branch of the State Bank of India doing the
Treasury Business) and the relevant challan is attached herewith.The required particulars are given
below:Particulars
1. Name of individuals, firm or company applying.
2. Nationality of individuals or place of registration of incorporation of firm or
company.
3. Profession of individuals or nature of business of firm or company and
place of business.
4. Address of the individuals, firm or company.
5. Mineral or minerals which the applicant intends to mine.
6. Period for which the mining lease is required-
7. Details of area in respect of which lease is required-
(i)District, (ii) Revenue thana, (iii) Village/Mouza, (iv) J.L. no., (v) Plot nos., (vi) Total area.
8. Particulars of map or plan on 16" = 1 kilometre scale, covering the area
mentioned at 7 above, attached. It shall give sufficient information to enable
identification of the area in respect of which the lease is required.Bihar Minor Mineral Concession Rules, 1972

9. Brief description of the area.
10. Area and minerals within the jurisdiction of the State Government for
which the applicant or any person joint in the interest with him-
 : Mineral ...Area
 : Taluk ...District
(a)already holds a lease (s);(b)has already applied for but not been granted a lease; or(c)has applied
simultaneously.
11. Nature of joint interest, if any under 10 above.
12. Approximate quantity of minerals expected to be raised during the first
year.
13. Means by which the minerals are to be raised, i.e., by hand labour or
mechanical or electrical power and the degree of mechanisation if any
contemplated.
14. The amount of money proposed to be invested.
15. Past experience of the applicant in the profession of mining.
16. Manner in which the mineral raised is to be utilised, expected consumers
and places of consumption of the mineral.
17. Any other particulars which the applicant wishes to furnish or which the
Collector may ask for.
18. Manner and details of payment of the application fee prescribed in these
rules.
(Note. - The fee to be paid to the credit of the State Government under the head)I/We do hereby
declare that the particulars furnished above are correct and am/are ready to furnish any other
details, including accurate plan and security deposit, etc. as required by you before the grant of the
lease.Yours faithfully.Signature and designation of the ApplicantPlace-Date-Note-In case of an
application for mining lease for a period not exceeding one year, information under 13,14,15 and 16
need not be given.Form AA[See Rule 22 (1)]Form of application for renewal of Mining Lease for
Minor MineralsDated day of 20The Collector,...............Received on InitialSir,I/We have the honour
to apply for the grant or renewal of Mining Leases under the Bihar Minor Minerals Rules, 1972.ABihar Minor Mineral Concession Rules, 1972

sum of Rs .........................................being the fee in respect of this application payable under Rule
22(a) of the said Rules has been deposited............................................. (name of treasury or branch
of the State Bank of India doing the treasury business) and the relevant challan is attached
herewith.The required particulars are given below:-(1)Name of the applicant.(2)Nationality of the
applicant.(3)Place of registration of incorporation of firm or Company.(4)Profession of applicant,
nature of business or firm or Company and place of business.(5)Address of applicant firm or
Company.(6)Mineral or minerals which the applicant intends to mine.(7)Period for which the
renewal is required.(8)Details of the area in respect of which renewal is
required-(i)District.(ii)Thana(iii)Village(iv)Plot nos.(v)Total area.(9)Whether renewal is applied for
the whole or part of the leasehold area.(10)Particulars of the map of the lease-hold with area applied
for renewal clearly marked on it (attached).(11)Means by which minerals are to be raised, i.e., by
hand labour or mechanical or electrical power.(12)Manner in which the mineral raised is to be
utilised.(13)Manner and details of payment of the application fee prescribed in these rules.(14)Any
other particulars which applicant wishes to furnish.I/We do hereby declare that the particulars
furnished above are correct and am/are ready to furnish any other details including accurate plan
and security deposit, etc., as required by you before the grant of the lease.Yours faithfully.Signature
and designation of the Applicant.Place-Date-Form B[See Rule 10]Form of acknowledgement of
application for Mining Lease for Minor MineralsOffice ofNo..........................................
Dated..................................................Received the application of mining lease for a minor mineral
from Shri/Shrimati...................on...................for.........................about....................acres/hectares of
land located in village ................of district................for lease of...................minor mineral.Signature
and designation of Receiving OfficerPlace-Date-Form C[See Rule 17]Register of Mining
Lease(a)(i)Serial number(ii)Name of the lessee and his address.(iii)Particulars and area of the land
in respect of which the lease had been granted and the period of the lease.(iv)Date on which the
lease is granted.(v)Date on which formal lease is executed.(vi)Rates of royalty, surface rent and dead
rent and any other rents payable.(vii)Mineral or minerals for which the lease is valid.(viii)Amount of
security deposit paid with challan no. and date.(ix)Date of assignment of transfer of the lease, if any,
fee paid thereof and the names of the parties thereto.(x)Date of assignment of transfer of the lease, if
any, fee paid thereof and the names of the parties thereto.(x)Date of expiry or
relinquishment.(xi)Date from which the area is available for re-grant.(xii)Details of challan and date
showing payment of preliminary expenses.(b)(i)Date of renewal.(ii)Period of renewal.(iii)Total area
under renewal.(iv)Rate of surface rent.(v)Rate of royalty.(vi)Mineral or minerals for which renewed
lease is valid.(vii)Rate of dead rent.(viii)Amount of security deposit paid.(ix)Date of assignment of
transfer of the lease, if any, fee paid therefor and the names of the parties thereto.(c)(i)Date of
expiry or relinquishment or cancellation, whether all dues have been paid.(ii)In case of expiry or
relinquishment of cancellation, whether all dues have been paid.(iii)The date from which the area is
available for regrant.Form D(See Rule 21)Model Form of mining lease for minor mineralsThis
Indenture made this..........................day of..........................................20 Between The Governor of
Bihar (hereinafter referred to as the Governor which expression shall where the context so admits be
deemed to include his successors in office and assigns of the one Part and
(1)When the
lessee is an
individual(1)................................... (name of person): sonof address and occupation)
hereinafter referred to as "thelessee, (which expression shall, where the context
so admits, bedeemed to include his heirs, executors,Bihar Minor Mineral Concession Rules, 1972

administrators,representatives and permitted assigns (1) and
(2)When the
lessees are
more than one
individual.(2)......................... (name of person)of.....................of.................
occupation............(name of person) of........ (address and occupation)
hereinafterreferred to as the "Lessees" (which expression shall,where the
context so admits, be deemed to include theirrespective heirs, executors,
administrators, representatives andtheir permitted assigns (2) and
(3)When the
lessee is a
registered firm
or syndicate.(3)........................ (name of persons) of..............(address) and ................ (name
of persons) of............(address) all carrying on business in
co-partnershipat................... address of the firm or syndicate) under thename,
and style of or syndicate, name of the firm registeredunder the Partnership Act
hereinafter referred to as the"lessees" (which expression shall, when the context
soadmits be deemed to include all the partners, or the said firm,their
representatives, heirs, executors, administrators, andpermitted assigns), and
(3) and
(3)When the
lessee is
registered
company.(4).................. (name of company) a company REGISTEREDunder..................
(Act under which incorporated) and havingits registered office at..............
(address (hereinafterreferred to as the "Lessees" which expression shall,where
the context so admits be deemed to include its successorsand permitted
assigns) (4) of, the other Part.
WHEREAS the lessee/lessees has/have applied to the Government of Bihar, (hereinafter referred to
as the 'State Government)' for a mining lease for................ (name of minerals) in accordance with
the [Bihar Minor Mineral Concession Rules, 1964] [Now it should be 1972.] [hereinafter referred to
as the said Rules) in respect of lands described in Part I of the Schedule hereunder written
(hereinafter referred to as the said Schedule) and has/have deposited with the State Government the
sum of Rs. ........... as security and the sum of Rs. ......... for meeting the preliminary expenses for a
mining lease.NOW THIS INDENTURE WITNESSETH that in consideration of the rents and
royalties, and agreements by and in these presents and the said schedule reserved and contained
and on the part of the lessee/lessees to be paid, observed and performed the Governor doth hereby
grant and demise unto the lessee/lessees, all those the mines beds/veins seams of.................. [here
state the "Minerals"] hereinafter and in the said Schedule referred to as the said "Minerals"]
situated, lying and being in or under the land mentioned and described in Part I of the said
Schedule, together with the land, liberties, powers and privileges to be exercised on or enjoyed in
connection therewith which are mentioned in Part II of the said Schedule subject to the restrictions
and conditions as to the exercise and enjoyment of such liberties, powers, and privileges which are
mentioned in Part III of the said Schedule Except all reserving out of this demise unto the State
Government the liberties, powers and privilege mentioned in Part IV of the said Schedule To Hold
the premises hereby granted and demised unto the lessees-from the day............ 20......... for
the............. term of............... years thence next ensuing Yielding and paying unto the State
Government the several rents and royalties mentioned in Part V of the said schedule at the
respective times therein specified subject to the provisions contained in Part VI of the said schedule
And the lessee/lessees hereby covenants/covenant with the State Government as in Part VII of the
said Schedule is expressed AND the State Government hereby covenants with the lessee/lessees as
in Part VII of the said Schedule is expressed And it is hereby mutually agreed between the partiesBihar Minor Mineral Concession Rules, 1972

hereto as in Part IX of the' said Schedule is expressed.In Witness Whereof these presents have been
executed in manner hereunder appearing the day and year first above written.The Schedule above
referred to:
Part I – The Area of This Lease
All the tract of lands situated at.............. (description of area or areas)............. (paragraph)
in.................. the Registration District .................. Sub-District ................ and Thana ................
bearing Cadestral Survey nos. ................... containing an area of or thereabouts delineated on the
plan hereto annexed and thereon marked with lines/ coloured.................... and bounded as
follows:-On the North byOn the South byOn the East by andOn the West by(hereinafter referred to
as "the said lands")
Part II – Liberties, Powers And Privileges to be Exercised and
Enjoyed by the Lessee/ Lessees Subject to the Restrictions and
Conditions In part III
1. To enter upon land and search for win, work, etc. - Liberty and power at all
times during the term hereby demised to enter upon the said lands and to
search for, mine, bore, dig, win, carry away and dispose of the said
mineral/minerals.
2. To bring and use machinery equipments, etc. - Liberty and power for or in
connection with any of the purposes mentioned in this part to erect,
construct, maintain and use on or under the said lands any machinery, plant
brick kilns, godowns, sheds and other buildings.
3. To make road and ways, and use existing roads and ways. - Liberty and
power for or in connection with any of the purposes mentioned in this part to
make any roads and other ways in or over the said lands.
4. To use water from streams, etc. - Liberty and power for or in connection
with any of the purposes mentioned in this part but subject to the Collector
of.................(name of district) to appropriate and use water from any streams,
watercourse, spring or other source in or upon the said land and to divert,
step up or dam any such streams or watercourse and collect or impound any
such water and to make, construct and maintain any water course, culverts,
drains or buildings or watering places for livestock of a reasonable supply of
water as before accustomed nor in any way to foul or pollute any streams orBihar Minor Mineral Concession Rules, 1972

springs.
6. To use and for stacking, heaping or depositing purpose. - Liberty and
power to enter upon and use a sufficient part of the surface of stacking,
heaping, storing or depositing thereon any produce of the mines or works
carried and on any tools, equipment, earth and materials and substance dug
or raised under the liberties and power's mentioned in this part.
7. To clear brushwood and to fell and utilise trees, etc. - Liberty and power
for or in connection with any of the purposes mentioned in this part and
subject to existing rights of others and saves 6s brushwood and to fell and
utilise any tree or timber standing or found on the said lands provided that
Collector may ask the lessee/lessees to pay for any trees or timber standing
or found on the said lands felled and utilised by him/them at the rates
specified by the Collector,
Part III – Restrictions and Conditions as to the Exercise of the
Liberties, Powers and Privileges in Part II
1. No building, etc. upon certain places. - No building or thing shall be
erected, set up or placed and no surface operations shall be carried on in or
upon any public pleasure grounds, burning or burial ground or place held
sacred by any class of persons or any house or village site, public road or
other place which the Collector may determine as public ground nor in such
a manner as to injure or prejudicially affect any buildings, works, property or
rights of other persons and no land shall be used for surface operation which
is already occupied by persons other than the State Government for works or
purposes not included in this lease. The lessee/ lessees shall not also
interfere with any right of way, well or tank.
2. To cut trees on reserved Lands. - The lessee/lessees shall not without the
express sanction of the Collector cut down or injure or allow any person to
cut down or injure any timber or trees on the said lands, but may without
such sanction clear away any brushwood or under growth which interferes
with any operations/authorised by these presents. The Collector or the State
Government may require the lessee/ lessees to pay for any trees or timber
felled and utilised by him/them/it with the sanction of the Collector at theBihar Minor Mineral Concession Rules, 1972

rates specified by the Collector. In case the lessee/ lessees cuts/cut down or
injure or allow any person to cut down and injure any timber or tree without
the sanction of the Collector in writing the lessee/lessees shall be bound to
pay on demand made by the said Collector additional compensation at a rate
not exceeding rupees fifty (Rs. 50) per tree of timber as specified by the
Collector or the State Government. The lessee/lessees shall observe all
conditions as to the area within which the quantity up to which and the terms
on which the said Collector or the State Government may like to exercise that
authority.
3. Working in a condition of Reserved Forests. - Notwithstanding anything in
this schedule contained the lessee/lessees shall not work in any Reserved
Forests included in the said lands otherwise than in accordance with the
conditions mentioned herein. In this respect the lessee/lessees, the
employees of the lessee/lessees shall be subject to the directions of the
Forest Officer concerned. In case of any dispute the matter shall be referred
to the State Government whose decision in the matter shall be final. (Mention
the conditions imposed by the Forest Officer drawn up in consultation with
the State Government or lease granting authority).
4. No mining operations within [50 metres of public works etc.] [Substituted
by S.O. 305 dated 26.3.1985.] - The lessee/lessees shall not work or carry or
allow to be worked or carried on any mining operations at or to any point
within a distance of [50] [Substituted by S.O. 305 dated 26.3.1985.] metres (55
yards) from any railway line except with the previous written permission of
the Railway Administration concerned or from any reservoir, public road,
canal or other public work or buildings or inhabited site or within [10] meters
(11 yards) of any village roads except with the previous permission of the
Collector or any other officer authorised by the Collector in this behalf and
otherwise than in accordance with such instructions, resurrections and
conditions either general or special which may be attached to such
permission.
Explanation. - For the purposes of this clause the expression "Railway Administration" shall have
the same meaning as it is defined to have in the Indian Railways Act, 1890, by Section 3, sub-section
(4) of that Act, "Public Road" shall mean a road which has been constructed by artificially surfaced
as distinct from a track resulting from repeated use. The village road shall mean a road other than
"Public road" and which has been shown as road in Revenue Settlement maps.Bihar Minor Mineral Concession Rules, 1972

5. The lessee. - shall take adequate steps to ensure that-
(a)heights and widths of trenches in quarries are properly maintained to facilitate easy removal of
the minerals and the work;(b)the working faces are always kept clear and(c)the minor minerals won
are stacked in suitable dimensions and each stack is numbered.
6. Facilities for adjoining Government licences and leases. - The lessee/
lessees shall allow existing and future holders of Government licenses or
leases over any land which is comprised in or adjoins or is reached by the
land held by the lessee/lessees reasonable facilities of access thereto.
7. The lessee shall arrange for the proper sanitation of the area leased to
him:
8. Forest fire. - Nothing shall be done by the lessee/lessees or his/their/its
employees which may cause a forest fire. Proper precautions shall be taken
at all times to prevent such fires.
9. The lessee shall abide by such instructions and directions as may be
issued by Government from time to time regarding the observation and
development of minor minerals.
Note. - This clause should be omitted if there is no forest reserved or otherwise.
Part IV – Liberties, Powers and Privileges Reserved to the State
Government
1. To work other minerals. - Liberty, and power for the Collector or any
persons authorised by it in that behalf to enter into and upon the said lands
and to search for win, work, dig, get raised dress, process, convert and carry
away minerals other than the said mineral and any other substance and for
those purposes to sink, drive, make, erect, construct, maintain and use such
pits shafts, inclines, drifts, levels and other lines, waterways, watercourses,
drains reservoirs; engines, machinery plant, building, canals, railways,
roadways and other works and conveniences as may be deemed necessary
or convenient:
Provided that in the exercise of such liberty and power no substantial hindrance shall be caused to
or with the liberties, power and privileges of the lessee/ lessees under these presents and that fairBihar Minor Mineral Concession Rules, 1972

compensation shall be made to the lessee/lessees for all loss or damage sustained by the
lessee/lessees by reason or consequence of the exercise of such liberty and power.
2. To make railway lines and roads. - Liberty and power for the State
Government or any lessee or person authorised by it in that behalf to enter
into and upon the said lands and to make upon, over or through the same
any railways, tramways, roadways, canals or pipelines, or to carry any
electric or telephone or such lines over the lands under lease for any
purpose other than gravel, earth and other materials for making, maintaining
and repairing such railways, tramways and roads or and existing railways,
tramways and roads and to go and repass at all times with or without horses,
cattle or other animals, carts, wagons, carriages, trucks, cars, locomotives or
the vehicles over or along any such railways, roads, line and other ways for
all purposes and as occasions may require:
Provided that in the exercise of such liberty and power by such other lessee or person no substantial
hindrance or interference shall be caused to or with the liberties, powers and privileges of the
lessee/lessees for all loss or damage sustained by the lessee/lessees by reason or in consequence of
the exercise by such lessee or person of such liberty and power, subject to the proviso that no
compensation shall be deemed to be payable where only electric lines or telephone or similar lines
are carried in or over the lands under lease.
3. Lease by mistake. - The lessee/lessees shall have no claim against the
State Government for compensation or damage in respect of land having
been included in this lease which has already been included in some
previous lease but that the lessee/lessees shall be entitled to proportionate
reduction of the assessment in respect of any land covered by the lease
which may subsequently be discovered not to have been available for lease.
4. Action in case of occurrence of valuable mineral. - In case there are
reasons to believe at any time that valuable mineral or minerals exist along
with the mineral for which this lease is being granted the Collector may issue
such order for the compliance of the lessee/lessees as the Collector may
think proper for dumping of the tailings or screened rejects of the mineral
treated or treatment of the mineral to which this lease is being granted. The
granting of this lease to the lessee/lessees will always be without prejudice
to the right of the Collector to terminate the lease if the mineral leased is
found any time to contain any valuable mineral separation of which is not, in
the opinion of the Collector, easily possible or within the means of theBihar Minor Mineral Concession Rules, 1972

lessee/lessees.
Part V – Rent and Royalties Reserved by this Lease
1. To pay dead rent or royalty whichever is greater. - The lessee/lessees shall
pay in respect of any quarterly period or half yearly period as may be fixed by
the Collector either the dead rent reserved by clause 2 of this part or the sum
of the royalties reserved by clause 3 of this part whichever is greater. If the
lease permits the working of more than one mineral in the same area, the
Collector may fix separate dead rent in respect of each mineral:
Provided the lessee shall be liable to pay the dead rent or royalty in respect of each mineral
whichever be higher in amount, but not later.
2. Rate and mode of payment of dead rent. - Subject to the provision of
clause I of this part as from the day of [xxxxx] [Words 'one year after the date
of this lease' deleted by S.O. 1760 dated 29.12.75.]........20 during the
subsistence of this lease the lessee/lessees shall pay to the Collector (in four
equal quarterly instalments on the........day of the months of.........or in four
equal half yearly instalments on the........day of the months of.........or in four
equal half yearly instalment on the day of.................and the......day of........in
each year) certain annual dead rent at the following rates per acre of the
lands, described in Part-I of this Schedule subject to revision at any time by
the State Government by notification of Schedule-1 of this Rule (here insert
the amount payable)
3. Rate and mode of payment of royalty. - Subject to the provision of this
part, the lessee/lessees shall during the subsistence of this lease pay to the
State Government in four equal instalments on the day of the each of the
month of in each year royalty in respect of any mineral/minerals removed by
him/them from the leased area at the rate for the time being specified in the
Second Schedule to the Bihar Minor Mineral Concession Rules, 1972.
4. Payment of surface rent. - The lessee/lessees shall pay rent to the State
Government in respect of all parts of the surface of the said lands which
shall from time to time be occupied or used by the lessee under the authority
of these present at the rate of Rs per annum per acre of the area or at the
rates as may be fixed by the Collector from time to time so occupied or usedBihar Minor Mineral Concession Rules, 1972

and so in proportion for any area less than acre during the period from the
commencement of such occupation or use until the area shall cease to be so
occupied or used and shall as far as possible be restored to its original
condition (which rent shall be paid upon each of the quarterly or half-yearly
dates hereinbefore appointed for the payment of instalments of the certain
annual dead rent):
Provided that no Such rent shall be payable in respect of the occupation and use of the area
comprised in any roads or ways to which the Public have full right to access.
5. The lessee/lessees shall duly and regularly pay to the appropriate
authority all cess, taxes and local dues in respect of the leased area, the said
minerals or the working of the mines in addition to the rent and royalty so
payable as aforesaid.
Part VI – Provisions Relating to the Rents and Royalties
1. Rent and royalties to be free deductions, etc. - The rent and royalties
mentioned in Part V of this Schedule shall be paid free from any deductions
to the State Government at and in such manner as the State Government may
direct.
2. Mode of computation of royalty. - For the purposes of computing the said
royalties the lessee/lessees shall keep a correct account of the
mineral/minerals in stock or in the process of despatch may be checked by
any officer authorised by. the Collector.
3. Monthly account to be sent to State Government. - The accounts for each
month in respect of raising, sale, despatch, local consumption, royalty, and
rent dues and paid shall be [submitted] [Substituted for 'Completed' by S.O.
867 dated 21.8.1972.] within 15 days of the month following and a true copy
signed by the lessees or his/her/its authorised agent shall be sent in
triplicate to the Competent Officer [xxxx] [Works '7 days' omitted by S.O. 867
dated 21.8.1972.] thereafter in a form that may be prescribed from time to
time by the State Government.Bihar Minor Mineral Concession Rules, 1972

4. Interest on arrear payments. - The lessee/lessees shall be liable to pay
interest at the rate of [15] [Substituted by S.O. 199 dated 3.3.1988.] percent
per annum on any amount remaining payable to the State Government.
5. Course of action if rent and royalties are not paid in time. - Should the
royalty and/or rent reserved and made payable by the lessee be not paid
within one month next after the date fixed in the lease for the payment of the
same, the Collector may enter upon the premises and distrain all or any of
the mineral or beneficiated products thereof or moveable property therein or
of so much of them as will suffice for the satisfaction of the rent and/or
royalties due and all costs and expenses occasioned by the non-payments
thereof. If any royalty or rent remains at any time unpaid for 3 calender
months after the date on which it is due, the Collector may determine the
lease and take possession of the premises comprised thereon. These rights
shall be without prejudice to the right of the Collector to realise the dues
under the Bihar Public Demands Recovery Act or any Statutory Act or Rules
thereof for the time being in force.
Part VII – The Covenants of the Lessee/Lessees
1. Lessee to pay rents, royalties', taxes, etc. - The lessee/lessees shall pay
the rents and royalties reserved by this lease at such time and in the manner
provided in Parts V and VI of these presents and shall also pay and
discharge all taxes, rates, assessments and impositions whatsoever being in
the nature of public demands which shall from time to time be charged,
assessed or imposed by the authority of the State Government upon or in
respect of the premises and works of. the premises and works of the
Lessee/Lessees in common with other premises and works of a like nature
except demands for land revenue.
2. To maintain and keep boundary marks in good order. - The lessee/lessees
shall at his/their/its own expense erect and at all times maintain and keep in
repair boundary marks and pillars [according to the specification prescribed]
[Inserted by S.O. 205 dated 26.3.1985.] the demarcation shown in the plan
annexed to this lease. Such Marks and pillars shall be sufficiently clear of
shrubs and other obstruction as to allow easy identification.Bihar Minor Mineral Concession Rules, 1972

2A. [ To maintain and keep boundary marks and sign boards in good order.
[Inserted by S.O. 305.dated 26.3.1985.] - The lessee/lessees shall at
his/their/own expense arrange for sign boards within the lease hold area
showing the name of the lessee/name of the minerals/details of the area and
period of the lease and shall always maintain and keep them in good order.]
3. To commence operations within three months and work in a workman-like
manner. - Unless the Collector for good cause permits otherwise, the lessee/
lessees shall commence operation within three months from the date of
execution of the lease and shall thereafter at all times during the continuance
of this lease for, win, work and develop the said minerals without voluntary
intermission in a skillful and workmanlike manner and in accordance with
any Centra! or State Act and Rules and Regulations made thereunder for the
purpose and for the time being in force without doing or permitting to be
done any unnecessary or avoidable damage to the surface of the said lands
or the crops, buildings, structures or other property thereon. The Collector
shall be fully competent in whatever manner and by whatever agency it likes
to determine, whether the work is carried on properly and skillfully and in
accordance with any Central or State Act and Rules and Regulations made
thereunder for the purpose and for the time being in force or whether the
work was commenced within three months from the date of execution of the
lease.
4. To indemnify government against all claims. - The lessees shall make and
pay such reasonable satisfaction and compensation as may be assessed by
lawful authority in accordance with the law in force on the subject for all
damage, injury or disturbance which may be done by him/them/it in exercise
of the powers granted by this lease and shall indemnify and keep indemnified
fully and completely the State Government against all claims which may be
made by any person or persons in respect of any such damage, injury or
disturbance and all cost and expenses in connection therewith.
5. To fill up all pits, shaft, etc. - The lessee/lessees shall, during the
subsistance, of this lease, throw the refuse from the excavations at places
approved by the Collector.Bihar Minor Mineral Concession Rules, 1972

6. To strengthen and support the mines to necessary extent. - The lessee/
lessees shall strengthen and support to the satisfaction of the Railway
Administration concerned or the Collector, as the case may be any part of
the mine which in its opinion requires such strengthening or support for the
safety of any railway, canal road and other public works or structures.
(Note:-Modify according to existing circumstances.)
7. To allow inspection of working. - The lessee/lessees shall allow the
Collector or the Competent Officer or any officer authorised by the Collector
in that behalf to enter upon the said premises including any buildings
excavation or land comprised in the lease for the purpose of for the purpose
of inspecting, examining, measuring, surveying and making plans thereof,
sampling and collecting any data and the lessees shall with proper person
employed by the lessee/lessees, and acquainted with the mines and works,
effectually assist such officers, agents, servants and workmen in conducting
every such inspection and shall afford them all facilities, information
connected with the working of the mines which they may reasonably require
and also shall and will conform to and observe all orders which the Collector
or Competent officer as the result of such inspection or otherwise may from
time to time see fit to impose.
8. To report accidents. - The lessee/lessees shall report within 24 hours to
the Collector/Competent Officer a report of any accident causing death or
serious bodily injury or serious injury to property or seriously affecting or
endangering life or property which may occur in the course of the operations
under this lease.
9. To report discovery of other mineral. - (a) Whenever the lessee/lessees
shall find in the said lands any mineral other than the said mineral/minerals
the lessee/lessees shall report within 15 days such discovery in writing to the
Collector with full particulars of the nature and position of each such land.
He/they/it or any of his/their/its employees shall not win and dispose of the
newly discovered mineral or minerals without first obtaining a lease in
respect of those minerals.
(b)If the lessee/lessees intends/intend to work such newly discovered mineral or minerals
he/they/it shall within three months of making such report as is mentioned in sub-clause (a) of thisBihar Minor Mineral Concession Rules, 1972

clause intimate his/their/its intention to the Collector and apply for mining lease in respect thereto
in accordance with the Rules regulating the grant of mining concessions for that mineral. But such
mining lease shall not be claimed as a matter of right.(c)If the lessee/lessees intimates his/their/its
intention not to work the newly discovered mineral or fails to intimate intention to work it within a
period of three months then it shall be open to the Collector to grant a licence of lease for the
working of the same to any other person.
10. To keep record and accounts regarding production and employees, etc. -
The lessee/lessees shall at all times during the said term keep or cause to be
kept at an office to be situated upon or near the said lands correct and
intelligible books (bound and paged) of account which shall contain account
accurate entries showing from time to time. -
(1)Quantity and quality of the said mineral/minerals reaslised from the said lands.(2)Quantity of the
various qualities of minerals benefits or converted for example limestone converted in to
lime.(3)Quantities of the various qualities of the said mineral/minerals sold.(4)Quantities of the
various qualities of the said mineral/minerals otherwise disposed of and the manner and purpose of
such disposal.(5)the prices and all other particulars of all sales of said mineral/minerals.(6)The
number of persons employed each day in the mines or works or upon the said lands specifying
qualifications and pay of the technical personnel.(7)The stock of mineral/minerals
undisposed.(8)The full particulars together with addresses of the party or parties to whom the
mineral/minerals has/have been sold, the date of sale, the number of railway wagon together with
the station from which despatched and in the case of despatches by trucks the names, address of
owners of the trucks.(9)Such other facts, particulars and circumstances as the Collector may from
time to time require and shall also furnish free of charge to such officers and at such time as the
Collector may appoint true and correct abstracts of all or any such books of accounts and such
information and returns to all or any of the matters aforesaid as the Collector shall in that behalf
appoint to enter into and have free access to the said office for the purpose of examining and
inspecting the said books of accounts and to make copies thereof and make extracts therefrom.
11. [ The lessee/lessees shall at all times during the said terms maintain at
the mine office correct, intelligible up-todate and complete plans of the mine
in the said lands on a scale of not less than 10-1 mile, being the copy of the
Cadestral Survey map with details of plot nos. and other present features,
showing therein the extent of the workings and the situation of various
quarries along with such roads as might have been constructed by the
lessees connecting the main public roads in and around the lease hold
premises. Lessee/lessees shall also allow any officer authorised by the
Collector to inspect the same at all reasonable times.Bihar Minor Mineral Concession Rules, 1972

11.
(A). The lessee shall pay a wage not lesser than the.minimum wages prescribed by the Central or
State Government from time to time.
11.
(B). The lessee shall comply with provisions of the Mines Act, 1952.
11.
(C). The lessee shall take measures, at his own expense for the protection of the environment like
planting of trees, reclamation of mine land, use of pollution control device and such other measures
as may be prescribed by the Central or State Government from time to time.
11.
(D). The lessee shall pay compensation to the occupier of the land on the date and in the manner
laid down in these Rules.] [Inserted by S.O. 1063 dated 16.10.1989.]
12. Notice to the Chief Inspector of mines in India. - If at any time any
underground excavation is made or the number of persons employed in the
mine exceeds 50 or the depth of the quarry exceeds [6 metres] [Substituted
for '20 feet' by S.O. 817 dated 26.8.1972.] at any place or if any explosive is
used in the mine at any time a notice specifying the details about the number
of persons employed maximum depth of any quarry, explosives used and the
location and ownership of the mine together with the address of the owner
shall be sent to the [Director General of Mines "Safety"] [Substituted for
'Chief Inspector of Mines' by S.O. 817 dated 26.8.1972.] in India, P.O.
Dhanbad, Bihar.
13. Liberty to assign or transfer his rights. - The lessee/lessees may assign
this lease or transfer any right title or interest hereunder by outright sale to a
person approved by the Collector with the previous written sanction of the
Collector on payment of a fee of [Rs. 1,000] [Subtituted by S.O. 199 dated
3.3.1988.]. The lessee/lessees shall not allow this lease or any right, title or
interest hereunder to be attached or sold in compliance with any decree or
order of a court or Revenue officer:Bihar Minor Mineral Concession Rules, 1972

Provided that the assignment or transfer as aforesaid the instrument thereof shall be registered
within three calender months from the date of its completion.The lessee shall not however or sub-let
any right, title or interest in this lease.
14. Not to be financed or controlled by a Trust, Corporation, firm or person. -
the lease shall not be controlled and lessee/lessees shall nopt allow
themselves/ itself to be any Trust, Corporation, firm or person except with
the written consent of the Collector. The lessee/lessees shall not enter into or
make any arrangement, compact or understanding whereby lessee/lessees
will or may be directly financed by or under which the lessee/lessees
operations or understandings will or may be carried on directly or indirectly
by or for the benefit of or subject to the control of any Trust, or person
unless with the written sanction of the Collector given prior to such
arrangement compact, or understanding being entered into or made and any
or every sue arrangement compact or understanding as aforesaid (entered
into or made with such sanction as aforesaid) shall only be entered into or
make and shall always be subject to an express condition binding upon the
other parties thereto that on the occasion of a State of Emergency of which
the President of India in his discretion shall be the sole judge it shall be
terminable if so required in writing by the Collector and shall in the event of
any such requisition being made be forthwith thereafter determined by the
lessee/lessees accordingly.
15. Lessee shall deposit any additional amount necessary other than security
deposits. - Whenever the security deposit of Rs or any part thereof or any
further sum hereafter deposited with the Collector in replenishment thereof
shall be forfeited or applied by the Collector pursuant to the power
hereinafter declared in that behalf the lessee/lessees shall deposit with the
Collector such further sum as may be sufficient with the unappropriated part
thereof to bring the amount in deposit with the Collector upto the sum of
Rs.........(Rupees...........) only.
16. Delivery of working in good order to State Government after
determination of lease. - The lessee/lessees shall at the expiration or sooner
determination to the said term of lease or any renewal there of deliver unto
the Collector all mines, pits, shafts, inclines, drifts, levels, waterways,
airways and other works now existing or hereinafter to be sunk or made on
or under the said lands except such as have been abandoned with theBihar Minor Mineral Concession Rules, 1972

sanction of the Collector and in an ordinary and fair course of working all
engines, machinery, plant buildings structures, other works and
conveniences which, at the commencement of the said term were upon or
under the said lands and all such machinery set up by the lessee/lessees
below ground which cannot be removed without causing injury to the mines
or work under the said lands except such of the same as may with the
sanction of the Collector have become disused and all buildings and
structures of bricks or stone erected by the lessee/ lessees above ground
level in good repair and condition and fit in all respects for further working of
the said mines and the said minerals.
17. Right of preemption. - (a) The Collector and any person authorised by the
Collector for the purpose shall from time to time and at all times during the
said term of the lease have the right (to be exercised by notice in writing to
the lessee/lessees) of preemption of the said mineral (and all products
thereof) lying in or upon the said land hereby demised or elsewhere under
the control of the lessee/lessees and the lessee/lessees shall with all
possible expedition deliver all minerals or products of minerals required by
the Collector or any such authority under power conferred by this provision
in the quantities, at the times, in the manner and at the place specified in the
notice by the Collector or such authority. The lessee/lessees shall indemnify
the Collector against claim of any third party in respect of such minerals.
(b)The price to be paid for all minerals or products of minerals taken in preemption by the Collector
or the authority authorised by the Collector in this behalf in exercise of the right hereby conferred
shall be the fair market price prevailing at the time of preemption :Provided in order to assist in
arriving at the said fair market price the lessee/ lessees shall if so required furnish to the Collector
for the confidential information of the Collector particulars of the quantities, descriptions and prices
of the said minerals and the products thereof sold to other customers and of characters entered into
for frieght for carriage of the same and shall produce to such officer or officers as may be directed by
the Collector original or authenticated copies of contracts and charter parties entered into for the
sale or freightage of such minerals or products. In case of difference of opinion between the lessee
and the Collector about the fair market price, the matter may be referred to the Commissioner of the
Division, whose orders shall be final.(c)The lessee/lessees agrees/agree notwithstanding anything to
the contrary in the clause to supply such quantity of the mineral as may be required by any
Government Department or local authorities to work within this district at a rate 5 per cent less than
that of the local prevailing market rate.Bihar Minor Mineral Concession Rules, 1972

18. Action in case of war or national emergency. - In the event of the
existence of a state of war or emergency (of which existence the President of
India shall be the sole judge and a notification to this effect in proof) the
State Government shall from time to time and at all times during the said
term have the right (to be exercised by a notice in writing to the
lessee/lessees) forthwith to take possession and control of the works, plant,
machinery and premises of the lessee/lessees on or in connection with the
said lands, or operations under this lease and during such possession or
control of the lessee/lessees shall conform and obey all directions given by
or on behalf of the State Government regarding the use of employment of
such works, plants, premises and minerals:
Provided that fair compensation which shall be determined in default of agreement by the State
Government shall be paid to the lessee/lessees for all loss or damage sustained by him/them/it by
reason or in consequence of the exercise of the powers conferred by this clause and provided also
that the exercise of such powers shall not determine the said term hereby granted or affect the terms
and provisions of these presents further than may be necessary to give effect to the provisions of this
clause.
19. Notwithstanding anything contained in this lease, the lessee/lessees on
receipt of a notice in writing from the Collector or Competent Officer or an
Officer appointed by the Collector for the purpose stating that it or he
considers the lessee/ lessee's operations on the land delineated in the plan
involve danger of a serious landslip and requiring him to desist from such
operations, the lessee/lessees shall not claim any compensation for
stoppage of work in respect of the delineated area.
20. Storage and use of explosive. - The storage and use of any explosive
shall only be in accordance with the provisions of Indian Explosives Act, the
Metalliferous Mines Regulations for the time being in force and any lawful
directions of the Inspector of Mines. The lessee/lessees shall be responsible
for and ensure that no explosive intended for the mine is pilferred or misused
or used for purposes, within or outside the lease area, other than mining
within the lease area.
21. Boundary dispute. - If any boundary dispute or disputes regarding the
right of way or any other dispute, whatsoever regarding the construction of
any term or condition in the lease arises between the lessee/lessees and theBihar Minor Mineral Concession Rules, 1972

lessee of any adjoining block already leased under similar terms or which
may subsequently be leased, the lessee/lessees shall be bound to submit
such dispute to the decision of the Collector or to an officer appointed by the
State Government for the purpose. An appeal shall lie to the Commissioner
of the Division from the decision of the said officer and the order of the
Commissioner of the Division thereon shall be final and binding on the
lessee/lessees.
22. Employment of foreign nationals. - The lessee/lessees shall not without
the previous sanction in writing of the Collector employ any person for work
within the lease area or in connection therewith, who is not an Indian
national.
23. To abide by Rules and Regulations. - The lessee/lessees shall abide by all
existing laws and rules and Regulations enforced by the Government of India
or the State Government and all such other Laws, Rules and Regulations as
may be enforced from time to time in respect of working of mines and
minerals and other matters affecting the safety, health and convenience of
the employees of the lessee/lessees or of the public. On receipt of a notice
from the State Government or from an officer authorised by the State
Government in this behalf regarding any unlawful or irregular work in
connection with the working of the mine, the lessee/ lessees shall also be
bound to pay compensation to the State Government for all losses due to
any illegal or unlawful work done by the lessee/lessees or his/their/its
employees.
24. The lease shall be liable to cancellation if the lessee ceases to work the
mine or the quarry, for a continuous period of one year without obtaining the
previous permission of the Competent Officer or Collector:
Provided that the lease shall not be cancelled if the lessee is prevented from working the mine or
quarry owing to circumstances beyond his control.
25. If the lessee does not work in any part of the area leased out to him
continuously for a period of six months, of which the Collector shall be the
sole judge, the Collector shall have the power to determine the lease and
re-enter the area, provided that the lessee shall be given a reasonable
opportunity to show cause against the same.Bihar Minor Mineral Concession Rules, 1972

26. If the lessee does not work on more than 10 per cent of the area leased
out to him continuously for more than 6 months, of which the Collector shall
be the sole judge, the Collector shall have the power to re-enter on 75
percent of the area comprised in the lease, provided that the lessee shall be
given a reasonable opportunity to show cause against the same and the area
left with the lessee shall be a compact block including the portion of the area
worked by him and the terms of the original lease shall be considered as
modified from the date of re-entry by the Collector after his final order.
Part VIII – The covenants of the State Government
1. Lessee may hold an enjoy rights quietly. - The lessee/lessees paying the
rents and royalties hereby served and observing and performing all the
covenants and agreement herein contained and on the lessee/lessees to be
observed and performed shall and may quietly hold and enjoy the rights and
premises hereby demised for and during the term hereby granted without
any unlawful interruption from the Collector, or any person rightfully
claiming under it.
2. If in accordance with the provision of clause 4 of Part VII of this Schedule
the lessee/lessees shall offer to pay to an occupier of the surface of any part
of the said lands compensation for any damage or injury which may arise
from the proposed operations of the right and powers reserved to the
Collector and demised to the lessee/lessees by these presents and the said
occupier shall refuse his consent to the exercise of the right and powers
reserved to the Collector and demised to the lessee/lessees by these
presents and the lessee/lessees shall report the matter to the Collector and
shall deposit with it the amount offered as compensation and if the Collector
is satisfied that the amount of compensation offered is fair and reasonable or
if it is not so satisfied and the lessee/lessees shall have deposited with it
such further amount as the State/as the Collector shall order the occupier to
allow the lessee/lessees to enter the land to carry out such operations as
may be necessary for the purpose of this lease. In assessing the amount of
compensation the Collector shall be guided by the principles of the Land
Acquisition Act, 1894 (1 of 1894).Bihar Minor Mineral Concession Rules, 1972

3. To renew. - If the lessee/lessees be desirous of taking a renewed lease of
the premises hereby demised or of any part or parts of the same for a further
term of (exceeding the period of original lease) years from the expiration of
the term hereby granted and of such desire shall prior to the expiration of the
last mentioned term give to the Collector six calendar months' previous
notice in writing and shall pay the rents and royalties hereby reserved and
shall observe and perform the several covenants and agreements herein
contained and on the part of the lessee/lessees to be observed and
performed then up to the expiration of the term hereby granted the Collector
if satisfied with the work of the lessee/lessees may upon the request and at
the expense of the lessee/lessees and upon his/their/its executing and
delivering to the Collector if required a counterpart thereof execute and
deliver to the lessee/lessees a renewed lease of the said premises for the
further term of (not exceeding the period of original lease) years at such
rates and royalties and on such terms and subject to such covenants and
agreements, including this present covenant to renew as it may consider
proper at that time.
4. Liberty to determine, surrender or relinquish any part of the leased area. -
The lessee/lessees may at any time determine this lease by giving not less
than six calendar months notice in writing to the Collector and upon the
expiration of such notice provided that the lessee/lessees shall pay all rents,
royalties, compensation for damages and other moneys which may then be
due and payable under these presents to the Collector or any other person or
persons and shall deliver up these presents to the Collector then this present
lease and the said term and the liberties, powers and privileges hereby
granted shall absolutely cease and determine by without prejudice to any
right or remedy of any breach of any of the covenants or agreements
contained in these presents.
5. Refund of security deposit. - On such date as the Collector may elect
within 12 calendar months' after the determination of this lease or of any
renewal thereof, the amount of the security deposit paid in respect of this
lease and then remain in deposit with the Collector and not required to be
applied to any of the purposes mentioned in this lease shall be refunded to
the lessee/lessees. No interest shall run on the security deposit.Bihar Minor Mineral Concession Rules, 1972

Part IX – General provisions
1. Breach of any condition. - In case of breach of any of the conditions of the
lease other than mentioned in clauses 2 and 3 of this Part the Collector may
require the lessee/lessees or his/their its transferees or assignees to pay
penalty not exceeding an amount equivalent to four times the amount of
annual dead rent specified under clause 2, Part V.
2. Obstruction to inspection. - In case the lessee/lessees or his/their/its
transferees or assignees obstructs/obstruct or does/do not allow entry or
inspection any of the conditions of the lease mentioned in clause 1 of Part
111 and clauses 13, 14 and 2 of Part VII, the Collector may cancel the lease
and forfeit the whole or part of the security deposit.
3. Breach of any other condition. - In case of lessee/lessees or his/their/its
transferee or assignee commit any breach of any of the conditions specified
in (clause 3 of Part III) and clauses 2,3,6,10,23 of Part VII then and in any such
case the Collector shall give notice in writing to the lessee/lessees or
his/their/its transferees or assignees as the case may be asking him/them to
remedy the breach within 30 days from the date of the notice and if the
breach is not remedied within such period the Collector may determine the
lease:
Provided that nothing herein contained shall debar the Collector from enforcing any other right or
remedy that the Collector may have against the lessee/lessees or his/their/its transferees or
assignees under any other provisions herein contained.Note. - The portion within brackets to be
omitted if this clause has been omitted in Part III.
4. In case of breaches of the covenants and agreements by the lessee/
lessees on which the aforesaid notice has been given, the Collector in lieu of
giving notice may impose such penalty not exceeding four times the amount
of annual dead rent specified in clause 2 of Part V.
5. Failure to fulfil the terms of lease due to "Force Majeure". - Failure on the
part of the lessee/lessees to fulfil any of the terms and conditions of this
lease shall not give the Collector any claim against the lessee/lessees or be
deemed a breach of this lease, in so far as such failure is considered by the
said Collector to arise from force majeure, and if through force majeure theBihar Minor Mineral Concession Rules, 1972

fulfilment by the lessee/lessees of any of the terms and conditions of this
lease be delayed, the period of such delay shall be added to the period fixed
by this lease. In this clause the expression "Force Majeurd' means act of
God, war, insurrection, riot, civil commotion, strike, earthquake, tide, storm,
tidal wave flood, lightening, explosion, fire, earthquake and other happenings
which the lessee/lessees could not reasonably prevent or control.
6. Lessee to remove his properties on the expiry of lease. - The lessee/
lessees having first paid and discharged the rents and royalties payable by
virtue of these presents may at the expiration or sooner determination of the
said term or within six calendar months thereafter take down and remove for
his/their/its own benefit all or any machinery, plant, building, and other
works, erections and conveniences which may have been erected, set up or
placed by the lessee/lessees in or upon the said lands and which the
lessee/lessees is/are not bound to deliver to the Collector under clause 18 of
Part VII of this Schedule and which the Collector shall not desire to purchase.
7. Forfeiture of property left more than six months after determination of
lease. - If at the end of three calendar months after the expiration or sooner
determination of the said term or after the date from which any, surrender by
the lessee/lessees of the said lands under the provision contained in clause
4 of Part VIII of this Schedule become effective there shall remain in or upon
the said land, any machinery, plant, buildings, structures and other work,
erections and conveniences or other property, the same may be sold or
disposed of in such manner as the Collector shall deem fit without liability to
pay any compensation or account to the lessee/lessees in respect thereof.
8. Recovery under the Public Demand Act. - Without prejudice to any other
mode of recovery authorised by any provision of this lease or by any law all
amount falling due hereunder against the lessee/lessees may be recovered
as a public demand under the Bihar Public Demands Recovery Act or any
Statutory Act or Rules thereof for the time being in force.
9. Anticipated royalty for the purpose of stamp duty. - For the purpose of
stamp duty, the anticipated royalty is Rs.........Bihar Minor Mineral Concession Rules, 1972

10. Responsibility of Managing Agents. - The Managing Agent of the lessee/
lessees shall be equally responsible as the Lessee/Lessees.
11. Service of notice. - Every notice by these presents required to be given to
the lessee/lessees shall be given in writing to such person resident on the
said lands as the lessee/lessees may appoint for the purpose of receiving
such notices and if these shall be sent to the lessee/lessees by registered
post addressed to the lessee/lessees at the address recorded in this lease or
at such other address in India as the lessee/lessees may from time to time in
writing to the Collector or the Competent Officer authorised by the Collector
in this behalf designate for the receipt or notices and every such service
shall be deemed to be proper and valid service upon the lessee/lessees and
shall be deemed to be proper and valid service upon the lessee/lessees and
shall not be questioned or challenged by him.
IN WITNESS WHERE OF These presents have been executed in the manner hereunder appearing
the day, month and year first above written.Signed by.........for and on behalf ofthe Governor of the
State of Biharin the presence offor and on behalf ofLessee/Lesseesin the presence of.........Form
E(See Rule 27)Form of Permit for Minor Minerals to be Issued under The Bihar Minor Minerals
Concession Rules, [1972] [Substituted for '1964' by S.O. 867 dated 21.2.1972.].Permit no. of 20Name
and address of the permit-holder-
Name of locality
village, plot
number, etc.Date of
expiry of
permit.Name and
description of
minor minerals.Purpose for
which it will
be used.Number of
quantity of
materialsRate of
royalty.Total
amount
paid
1 2 3 4 5 6 7
       
Seal Competent Officer
The permit is issued subject to the terms and conditions noted below. -Conditions.
1. Materials shall have to be removed within the prescribed time-limit.
2. Quarrying is not allowed beyond the depth of 10' from the surface.
Permit-holder shall have to obtain the approval of the Competent Officer for
digging pits below 10' from the surface.
3. Compensation, if any, shall have to be paid for damage to the land covered
by permit.Bihar Minor Mineral Concession Rules, 1972

4. Felling of trees is not allowed without prior permission of Competent
Authorities within whose jurisdiction the area lies.
5. Surface operation shall not be done on any public prohibited and
restricted place.
6. Every type of accident shall be reported to the Competent Officer
immediately.
7. The party shall be liable to indemnify the claims of third parties. State
Government shall not be responsible for such claims in any way.
8. The materials left after the cancellation of the permit shall be forefited to
Government and the same shall be deemed to be Government property.
9. No excess quantity of materials beyond this permit shall be removed
without obtaining prior permit, otherwise the permit-holder shall be liable for
action under Rule 40 of the Bihar Minor Mineral Concession Rules, 1972.
10. Proper accounts for the extraction and removal shall be maintained in the
prescribed form and a monthly return shall be submitted within the month
following the month to which extraction relates.
11. Pucca challans in the prescribed form shall have to be issued for the
materials to be despatched or sold from the area.
N.B. Breach of any of the conditions noted above is liable for cancellation of the permit, forfeiture of
materials extracted and such other action as may be deemed necessary.Form F[See Rule 33(1)]Form
of Challan for Transport of Minor Mineral.No........................Date........
1. Name and address of the lessee/permit-holder.
2. Details of the quarry lease permits..........
3. Name of minor mineral.
4. Name and address of the persons/contractors to whom material has been
sold and supplied.Bihar Minor Mineral Concession Rules, 1972

5. Quantity ..........
6. Truck No./RR No/Carrier No.
7. Name and Address of the Driver in case the minor mineral is to be
transported by road/river.
8. Place of delivery of materials...........
9. Date and time of despatch................
Signature of the lessee/permit-holder.Seal of Competent Officer.Form G.[See Rule 33 (2)]Register
to be Maintained by the Lessee/Permit Holder.
1. Name and address of lessee/permit-holder.
2. Datails of quarry lease/permit.
3. Area...........
4. Mineral........
5. Location of quarry site........
DateOpening
balance.Quantity
extractedTotalName of
persons to
whom sold /
despatchedNumber
of
challan
issuedTotal
quantity sold
or
despatchedQuantity
in stock at
the close
of the dayAmount
of
royaltyRemarks
1 2 3 4 5 6 7 8 9 10
          
Form H[See Rule 33 (3)Form of Monthly Return for minor Minerals for the Month of 20(i)Name
and address of the lesseee/permit-holder.(ii)Details of quarry lease/permit.(iii)Area.......(iv)Mineral
Stock of mineral at
the beginning of the
monthQuantity extracted or
manufactured during
themonth.Total Quantity
Sold locally Despatched by railDespatched
by truck.Despatched by
other means.Total
despatched.
1 2 3 4 5 678
        
Rate of Amount of Number of challan issued during the month Balance at the RemarksBihar Minor Mineral Concession Rules, 1972

royalty. royalty. copiesof which are to be attached with the
return.end of the month
9 10 11 12 13
     
Signature of lessee/permit-holder.Form I[See Rules 28 (1) and 30 (2)]Form of Application for
Quarrying PermitNo..........Date .............ToThe Competent Officer,.......................Sir,I/We request
that a quarrying permit under the Bihar Minor Mineral Concession Rules be granted to me/us.A
sum of Rs. 20 being the fee in respect of this application is deposited (copy of challan enclosed)The
following particulars are enclosed:-(i)Clearance certificate for payment of mining dues to be
attached.(ii)Written consent of the raiyats from which mineral is to be extracted if the land from
which minor mineral is to be extracted are raiyati lands.(iii)Mineral which the applicant intends to
quarry.(iv)The details of the lands from which the minerals is to be quarried.(v)Quantity of minor
mineral to be extracted.(vi)Period during which the minor mineral will be quarried.I/We do hereby
declare that the particulars furnished above are correct and am/are ready to furnish any other
details as may be required by you. I/We do hereby further declare that I/We shall adhere to the
terms and conditions as indicated in these Rules and any other conditions imposed by the
Competent Authority.Yours faithfully.Signature and designation of the ApplicantPlace-Date-[Form
J] [Inserted by S.O. 62 dated 5.1.1976.]Received To be submitted in
duplicate.Receivedat............................(Place)on....................(Date)........................Initial ofReceiving
Officer.............Government of BiharApplication for Certificate of Approval[See Rule 3 (A)
(2)]DatedDay of 20ToThroughSir,I/We request that a Certificate of Approval under the Bihar Minor
Mineral Concession Rules, 1972 be granted to enable me/us to acquire leases/and permit under the
said Rules.
2. The fee of Rs. 250 payable for the grant of Certificate of Approval has been
paid in the manner prescribed by the State Government in their Notification
No............Dated........treasury Receipt No..............Dated............is enclosed in
original.
3. The required particulars are given below:-
(i)Name of the applicant with complete address.(ii)Is the applicant a private individual private
company/public company/firm or association.(iii)In case the applicant is :(a)an individual, his
nationality,(b)a private company, the nationality of all members of the Company along with place of
registration.(c)a public company, the nationality of directors, the percentage of share capital held by
Indian Nationals alongwith place of incorporation.(d)a firm or association, the nationality of all the
partners of the firm or members of the association.(iv)Does the applicant hold a certificate of
approval or has even held a certificate of approval for the State or any other State? If so, give full
particulars of such certificate(s).(v)Does the applicant hold any quarry or permit in the State or any
other State? If so, give 'their particulars.(vi)Any other details which the applicant wishes to
furnish.I/We hereby declare that the particulars furnished above are correct and am/ are ready to
furnish any other details as may be required by you.Yours FaithfullySignature and designation of the
applicant,Dated............Place........................[Form J-1] [Inserted by S. O. 52 dated 5.1.1955.]To beBihar Minor Mineral Concession Rules, 1972

submitted in duplicateReceived at.................(Place)on..................Date .......................Initial
of..................Receiving Officer............Government of BiharApplication For Renewal of Certificate of
Approval[See Rule 3 (A) (3)]Dated.........day of...........20ToThroughSir,I/We request for renewal of
my/our Certificate of Approval under the Bihar Minor Mineral Concession Rules, 1972.
2. The fee of Rs. 250/- payable for the renewal of Certificate of Approval has
been paid in the manner prescribed by the State Government in their
Notification No. .................dated Treasury Receipt
No.............................dated.......is attached in original.
3. The required particulars are given below:
(i)Name of the applicant with complete address.(ii)Is the applicant a private individual/private
company/public company/Firm or association?(iii)In case applicant is :-(a)an individual, his
nationality(b)a private company alongwith place of registration.(c)a public company, the nationality
of directors, the percentage of share capital held by Indian National alongwith place of
incorporation.(d)a firm or association, the nationality of all the partners of the firm or members of
the association.(iv)Particulars of the Certificate of Approval of which renewal is desired.(v)Reasons
in detail for asking for renewal of Certificate of Approval.(vi)Any other details which the application
wishes to furnish.I/We do hereby declare that the particulars furnished above are correct and
am/are ready to furnish any other details as may be required by you.Yours faithfullySignature and
designation of the applicantPlace.........Date..........Form K[x x x x x] [Omittedby S. O. 1063 dated
16.10.1989.][Licence in Form 'L'] [Inserted by S.O. 305 dated 26.3.1985.][See Rule 33 (5)]Shri/Sri is
approved to be a person to stock minor minerals at.........................(name of
place)................P.S.................................District..............................and he will abide by the provisions
of B.M.M.C. Rules, 1972.Seal and Signature of Competent Officer.[Form - M] [Inserted by S.O. 1063
dated 16.10.1989.][See Rule 40 (10]AffidavitIn the court of Executive Magistrate
1. Son of..................resident of Moh P. O.P. S........District... do hereby
solemnly affirm and declare as follows:-
2. That I am a registered Contractor of the Department of Government of
Bihar/Union of India and have taken works of construction of.........
3. That in the course of aforesaid work I have supplied/consumed the
following quantity of minerals-
(a).......sand on...................(dates) which was purchased by me from (Full) address of a
lessee/permit holder/other person).(b)............Stone on (dates) which was purchased by me
from........(full address of lessee/permit holder/other person)!(c)..........mineral on which was
purchased by me from... (full address of lessee/permit holder/other person_.Bihar Minor Mineral Concession Rules, 1972

4. That the materials described in the paragraph 3 above were purchased by
me in good faith and after due inquiry that the seller thereof was authorised
to deal with that and the details of which is given below:-
(i)Name and address of the seller, if the seller is a lessee/permit holder the details of the mine from
which the minerals so sold was extracted If the seller is not a permit holder/lessee then the name
and address of other person from whom the seller has purchased............(ii)The quantity of the
purchased mineral with dates.........
5. That the certificate issued by the seller from whom the minerals
consumed/ supplied by me was purchased is attached herewith which I
believe to be true.
6. That the contents of this affidavit are true to the best of my knowledge and
belief.
This paragraph will not apply if the Contractor submits a certificate in the prescribed form issued by
the seller of the mineral.[Form-'N'] [Inserted by S.O. 1069 dated 16.10.1989.][See Rule 40
(10)]Specimen of the certificate which the Works Contractor will obtain from the sellers which he
will enclose with the bill alongwith the affidavit.(1)Name and address of the seller, if the seller is a
lessee/permit holder the details of the mine from which the concerned mineral was extracted.(2)If
the seller is not a lessee/permit holder then the name and address of that person from whom the
said seller had purchased the minor mineral which was subsequently purchased by works contractor
with the date of such purchase by the seller.(3)Name and address of the
purchaser/contractor.(4)Quantity of mineral purchased by the Contractor with date.Certified that
the aforesaid parties are true to my knowledge and belief.Signature of Seller,DateModel Form
'O'[See Rule 11-B (2)]AgreementThis agreement made this
day...........................of.............................................20..............................between the Governor of
Bihar (hereinafter referred to as the Governor which expression shall where the context so admits be
deemed to include his successor in office and assignee) of the one part
and........................................S/o...............................of village ......................P.O. and
P.S.........................Dist........................ State of................................................. (hereinafter referred to
as settlee of the other part).Whereas by a auction dated.........................and finalised
on.................................................with the person/persons being the highest bidder/bidders
(hereinafter referred as settlee or settlees as the case may be) for mining of sand (as Minor Mineral)
in accordance with Rule "11 A', of Bihar Minor Mineral Concession Rules, 1972 (hereinafter referred
to as the said Rules) in respect of lands described in Part 1 of this agreement hereunder written
(hereinafter referred to as the agreement and has/have deposited with the State Government of
Bihar (hereinafter referred to as Government), the sum of Rs vide Treasury challan no.
................................................dated...........................................as security money and the sum of Rs
vide Treasury challan No....................dated..........................as per 100%, 50% of the bid money of
Rs....................................................as per the conditions laid down in bid offer notice for the period
of one year or upto 31st December 20............................as the case may be.Bihar Minor Mineral Concession Rules, 1972

Part I – All the tract of land
situated.......................................................in the
river...................................................under the Revenue P.
S...............................P.
S............................District...........................Bihar.
Part II – Liberties, power and privileges to be exercised and
enjoyed by the settlee/ settlees.
The settlee/settlees will win, extract, remove sand under the provisions of Bihar Minor Mineral
Concession Rules, 1972 and from the....................river bed as mentioned in Part I.
Part III – Restriction and condition as to the exercise of the
liberties, power and privileges in Part II.
(i)No working, winning, mining or removal of and shall be done from the Raiyati land without
consent of the raiyats. The settlee/settlees shall pay compensation to the raiyats as fixed or directed
by the Collector appointed under these Rules.(ii)The settlee/settlees will allow other settlee/settlees
to transport the Minerals through his auction area.(iii)The settlee/settlees shall have no claim
against the State Government for compensation or damages due to non-availability of Minerals or
any hinderance caused in transportation.
Part IV – Mode of Payment
The settlee/settlees shall pay bid money in the following manner:(i)The settlee/settlees whose bid
money does not exceed Rs. ten thousand will pay in full the total amount before the agreement is
made.(ii)The settlee/settlees whose bid money exceeds Rs. ten thousand but does not exceed Rs.
fifty thousand will have to pay in two instalments-(a)The settlee/settlees shall have to deposit fifty
percentum of the bid money by next working day of the auction;(b)The rest amount of bid money
shall have to be deposited within six months from the date of auction by the settlee/settlees.(iii)In
case of settlee/settlees whose bid money exceeds Rs. fifty thousand shall have to deposit in the
following manner:-(a)Fifty per centum of the bid money shall be deposited by the next working day
of auction held for the said area;(b)The rest amount shall be deposited in two equal instalments, the
first instalment shall be deposited by 15th of April 20 and second by 15th July 20...........(iv)In case of
failure in payments of instalments the settlee/settlees shall be liable to pay 15 per cent on the
balance amount with effect from the date the instalment has become due.(v)Failure in payment of
any instalments or breach of any of the clause may lead to cancellation of the auction without any
notice and forfeiture of full or part of security money deposited by the settlee or settlees as the case
may be.Bihar Minor Mineral Concession Rules, 1972

Part V – Obligations of settlee/settlees
A settlee or the settlees shall observe the following :-(1)To allow inspection of working auction
area;(2)To report accidents;(3)To keep record and accounts regarding production and despatch in
prescribed proforma under the provisions of Bihar Minor Minerals Concession Rules, 1972;(4)To
issue a transport challan in Form F under the provision laid down in Bihar Minor Minerals
Concession Rules, 1972 to the carriers of Minerals by Trucks, Tractors, Boats and other mode of
transportation;(5)To deposit any additional amount as desired by Collector;(6)To secure licence in
Form L if the settlee or settlees stores sand elsewhere;(7)To allow the Competent Officer to take the
possession of the auction area, the day the period of auction expires; failing which a penalty equal to
the double the amount of the bid money on pro rata basis for the excess period shall be charged.
Part VI – Refund of security money
In case of refund of security money, deposited by the settlee or settlees, as the case may be, at the
time of auction, the Collector shall, within ninety days from the date of expiration of settlement
period, which is not required to be expended for any of the purposes mentioned in the auction, shall
be refunded to the settlee or the settlees, as the case may be, but no interest thereof shall be payable.
Part VII
Anticipated royalty for the purpose of stamp duty..............................................................is Rs.
..............................................................................................
Part VIII
1. Other conditions not included in this agreement shall be the same as in the
Bihar Minor Minerals Concession Rules, 1972.
2. All Central and State laws may be enforced on the settlee/settlees in
respect of working of mines and minerals. These laws may also be enforced
in respect of other matters affecting the safety, health and convenience of
the employees of the settlee/settlees or of the public in general. On receipt of
the notice from the State Government or from Competent Officer regarding
any unlawful work or irregular work in connection with the working of the
said mine the settlee or settlees, as the case may be, shall also be bound to
pay compensation to State Government for all losses due to any illegal or
unlawful work done or allowed to be done by the settlee/settlees.
Service of NoticeEvery notice will be served in writing by registered post on the address recorded inBihar Minor Mineral Concession Rules, 1972

the agreement. Every such service shall be deemed to be proper and valid service upon the
settlee/settlees and shall not be questioned or challenged by him.In witness whereof these present
have been executed in the manner hereunder appearing the day month year first above
written.Signed by the Governor of State of Bihar......................In the presence of for and on behalf of
settlee/settlees....................NotificationsS.O.262, dated 5th March, 1983, published in Bihar Gazette,
Extraordinary No. 311, dated March 5,1983. - In exercise of the powers conferred by Section 15 of
the Mines and Minerals (Regulation and Development) Act, 1957 (Act 67 of 1957), the Governor of
Bihar is pleased to make the following amendments in the Bihar Minor Mineral Concession Rules,
1972 published with Notification No. B/N-109/72-4275/M of the 22nd June,
1972:-Amendment(i)After Rule 2 (v) the following shall be inserted:-(v)(a)"Additional Director of
Mines" means "Additional Director of Mines appointed as such by the State Government."(ii)In Rule
33 (4), the words between "the Competent Officer" and "or any other officer authorised by the
Collector" shall be omitted and in their place the following words shall be substituted:-"or Director
of Mines or Additional Director of Mines or Deputy Director of Mines."(iii)In Rules 38 and 40 (7),
the words between "The Competent Officer" and "or Collector" shall be omitted and in their place
the following words shall be substituted:-"or Director of Mines or Additional Director of Mines or
Deputy Director of Mines."(iv)Clauses (1) and (8) of Rule 40 shall be omitted and the following
provision shall be substituted as clause (1):-"(1) No minor mineral shall be removed from the lease
hold area without payment of royalty and in case of removal of minor mineral from the lease hold
area without payment of royalty, the holder of mining lease, his agent, manager, employee,
contractor or sub-lessee shall be presumed to be parties to the illegal removal of the minor mineral
and every such person shall be liable to pay royalty due and shall be punished with simple
imprisonment for a term, which may extend to six months or with fine, which shall be less than
three times of the royalty due, or with both."(v)Sub-rule (1) of Rule 45 shall be substituted by the
following:-"(1) (a) The Commissioner, at any time for reasons to be recorded in writing, may on his
own motion, and where any person aggrieved by any order passed by the Collector under these
Rules files an application, within 60 days from the date of communication of the order, and within
75 days from the date on which an application is deemed to have been refused by the Collector, if no
communication is made of such refusal, shall start a proceeding for revision of the order.(b)The
application for revision as aforesaid shall be accompanied by a treasury receipt showing that a fee
for Rupees 50 has been paid into the Government Treasury or in any branch of the State Bank of
India doing treasury business to the credit of the State Government, under the head of account
"XXXII-C Miscellaneous Social and Developmental Organisation-Miscellaneous" (i) fee for grant
and renewal of Mineral Concession (ii) Rent royalties from mining leases and licenses:Provided that
an application for revision may be entertained even after the time specified as above if the applicant
satisfies the Commissioner that he had sufficient cause for not making the application within
time."(vi)In sub-rule (2) of Rule 45 the word "application" shall be substituted by the word
"proceeding".(vii)Sub-rule (4) of Rule 45 shall be substituted by the following:-"4. On receipt of the
application and copies thereof under sub-rule (2), the Commissioner shall send a copy of the
application, and where proceeding is started by him on his own motion, under sub-rule (1) he shall
send notices of starting the proceeding and reasons thereof to each of the parties impleaded
specifying a date on or before which he may make representation if any, against the revision
application."(viii)In sub-rule (1) of Rule 46 after the words "copies thereof" and before the words
"shall be sent" the words "and where proceeding is started by the Commissioner on his own motionBihar Minor Mineral Concession Rules, 1972

notices thereof" shall be inserted.(ix)In sub-rule (2) of Rule 46 the following words shall be added at
its end:-"or in respect of which proceeding has been started by him."
2. This notification shall come into force with effect from the date of
publication of the notification in the Bihar Gazette.
S.O. 861, dated 11th July, 1983, published in Bihar Gazette, Part 2, dated July 13,1983 at pages
548-550. - In exercise of the powers conferred by Section 15 of the Mines and Minerals (Regulation
and Development) Act, 1957 (Act 67 of 1957), the Governor of Bihar is pleased to make the following
amendments in the Bihar Minor Mineral Concession Rules, 1972 published with Notification No.
B/M-109/72-4275-M., of the 22nd June 1972.Amendment(i)After Rule 2(v) the following shall be
inserted:-(v) (a)"Additional Director of Mines" means "Additional Director of Mines appointed as
such by the State Government."(ii)In Rule 33 (4), the words between "the Competent Officer" and
"or any other officer authorised by the Collector" shall be omitted and in their place the following
words shall be substituted:-"or Director of Mines, or Additional Director of Mines or Deputy
Director of Mines"(iii)In Rules 38 and 40(7), the words between "the Competent Officer" and "or
Collector" shall be omitted and in their place the following words shall be substituted:-"or Director
of Mines or Additional Director of Mines or Deputy Director of Mines"(iv)Clauses (1) and (8) of Rule
40 shall be omitted and the following provision shall be substituted as clause (1):-"(1) No minor
mineral shall be removed from the lease hold area without payment of royalty and in case of
removal of minor mineral from the lease hold area without payment of royalty, the holder of mining
lease, his agent, manager, employee, contractor or sub-lessee shall be presumed to be parties to the
illegal removal of the minor mineral and every such person shall be liable to pay royalty due and
shall be punished with simple imprisonment for a term which may extend to six months or with
fine, which shall not be less than three times of the royalty due, or with both".(v)Sub-rule (1) of Rule
45 shall be substituted by the following:-"(1) (a) The Commissioner at any time for reasons to be
recorded in writing may on his own motion, and where any person aggrieved by any order passed by
the Collector under these Rules files an application, within 60 days from the date of communication
of the order, and within 75 days from the date on which an application is deemed to have been
refused by the Collector if no communication is made of such refusal, shall start a proceeding for
revision of the order.(b)The application for revision as aforesaid shall be accompanied by a treasury
receipt showing that a fee of Rs. 50 has been paid into the Government treasury or in any branch of
the State Bank of India doing treasury business, to the credit of the State Government, under the
head of account "XXXII-C-Miscellaneous Social and Developmental Organisation-Miscellaneous" (i)
fee for grant and renewal of Mineral Concession (ii) Rent and royalties from mining leases and
licences: Provided that an application for revision may be entertained even after the time specified
as above if the applicant satisfies the Commissioner that he had sufficient cause for not making the
application within time".(vi)In sub-rule (2) of Rule 45 the word "application" shall be substituted by
the word "proceeding".(vii)Sub-rule (4) of Rule 45 shall be substituted by the following:-"(4) On
receipt of the application and copies thereof under sub-rule (2), the Commissioner shall send a copy
of the application and where proceeding is started by him on his own motion, under sub-rule (1) he
shall send notices of starting the proceeding and reasons thereof to each of the parties impleaded
specifying a date on or before which he may make representation, if any, against the
revision".(viii)In sub-rule (1) of Rule 46 after the word "copies thereof" and before the words "shallBihar Minor Mineral Concession Rules, 1972

be sent" the words "and where proceeding is started by the Commissioner on his own motion notices
thereof" shall be inserted.(ix)In sub-rule (2) of Rule 46 the following words be added at its end:- "or
in respect of which a proceeding has been started by him".(2)This notification shall come into force
with effect from the date of publication of the notification in the Bihar Gazette.Department of Mines
and Geology Notification No. S. O. 33, dated 14th January, 1985-Published in Bihar Gazette
Extraordinary No. 26, dated January 14, 1985. - In exercise of the powers conferred by Section 15 of
the Mines and Minerals (Regulation and Development) Act, 1957 (Act 67 of of 1957), the Governor
of Bihar is pleased to make the following amendments in the Bihar Minor Mineral Concession
Rules, 1972:-AmendmentsFor Rule 11-A. the following Rule, shall be substituted namely-"(11 -A)
Notwithstanding anything contained in these Rules the settlement of sand as minor mineral will be
done by public auction by the Collector to the highest bidder on annual basis.Explanation. - Existing
leases shall not be renewed nor fresh lease/ permits for sand shall be granted."After Rule 26 the
following new Rule shall be inserted:-"26. Compounding of royalty on brick-earth - Notwithstanding
anything contained in these Rules, (i) the Competent Officer shall assess a compounded amount of
royalty on brick-earth used in a brick-kiln after adding 15 per cent on the maximum mining revenue
(inclusive of royalty and cess) in the last three years, or mining revenue calculated on the basis of
quantity of production on three rounds of the kiln in a year on its full capacity, whichever is higher,
(ii) as far a new brick-Kilns, which are working for less than three years, the compounding shall be
done on the mining revenue (inclusive of royalty and cess) on the production of bricks in three
rounds in a year at full capacity: Provided that the compounding of royalty shall be optional for the
brick-kiln owner, not compulsory."S.O. 305, dated 26th March, 1985-Published in Bihar Gazette
Extraordinary No. 206, dated 26.3.1985. - In exercise of the powers conferred by Section 15, of the
Mines and Minerals (Regulation and Development) Act, 1957 (Act 67 of 1957), the Governor of Bihar
is pleased to make the following amendments in the Bihar Minor Mineral Concession Rules, 1972,
published with Notification No. P/M-109/72-4275/M of the 22nd June, 1972:-Amendment
1. In Rule 2 (iii) (b) the words after the words "Assistant Mining Officer of the
District or Circle" shall be omitted.
2. In Rule 3-A wherever word "authority" occurs it shall be substituted by the
word "officer".
3. In Rule 3-B wherever word "authority" occurs it shall be substituted by the
word "officer".
4. In Rule 3D wherever word "authority" occurs it shall be substituted by the
word "officer".
5. In Rule 6 in place of word and figure "250 acres" the word and figure "100
Hectares" shall be substituted.Bihar Minor Mineral Concession Rules, 1972

6. In the proviso to sub-rule (1) of Rule 8 after the words "the provision of this
Rule" the words "for reasons to be recorded in writing" shall be added.
7.
(1)In sub-rule (4) of Rule 9 the words after the words "last financial year" shall be omitted and in
their place "in respect of all mineral concessions held in the State of Bihar" shall be
substituted.(2)Sub-rule (5) of Rule 9 shall be numbered as sub-rule (6) and sub-rule (6) of Rule 9
shall be numbered as sub-rule (5).(3)In sub-rule (5) numbered as sub-rule (6) after the bracket and
number "(4)" and before the bracket and number "(5)" the bracket and number "(5)'' shall be
inserted.
8. In Rule 10 after the words "the Collector" and before the words "shall
initial" the words "Competent Officer or any other Officer authorised by the
Collector" shall be inserted.
9.
(1)In Rule 11 in place of figure "90" the figure "120" shall be substituted.(2)Proviso to Rule 2 shall be
omitted.(3)After sub-rule (2) the following sub-rule shall be added:-"(3) In case an applicant does
not hold mining lease in certain districts of the State, he shall, with an application for the grant or
renewal of the lease, file an affidavit to that effect".
10.
(1)In Rule 14 after the words "to the annual dead rent" and before the words "fixed for the lease" the
words "at the maximum rate" shall be inserted.(2)The word "less" in the Rule shall be substituted by
the word "more".
11. In Rule 18 the figure "2" shall be substituted by the figure "10".
12. Sub-rule (5) of Rule 21 shall be omitted.
13.
(1)In sub-rule (1) of Rule 22 the word "90 days" shall be substituted by the words "90 days but not
earlier than 180 days".(2)In sub-rule (2-B) the words "after last financial year" shall be substituted
by the words "in respect of all the mineral concessions held in the State of Bihar",Bihar Minor Mineral Concession Rules, 1972

14.
(1)In sub-rule (2) of Rule 23 after the words and figure "of Rs. 1,000" the words "and production of
royalty clearance certificate by lessee and transferee", shall be added.(2)In proviso 2 to sub-rule (2)
of Rule 23 the figure and word "200 feet" shall be substituted by the figure si id word "60 meters".
15. After Rule 23 the following Rule shall be inserted:-
"23-A. Application for the transfer of mining lease. - The transferor and transferee interested in the
transfer shall produce valid clearance certificate of payment of mining dues such as royalty, dead
rent, surface rent and/or cess etc".
16. After the words "of its own" in explanation to sub-rule (2) of Rule 24, the
following shall be added:-
"In Rule 24 "or when the Government is satisfied that the continuance of mining or quarrying
operation is likely to cause grave injury to health or the property and injury is of such nature and
magnitude that it cannot be reasonably compensated and that the risk of injury is so imminent that
the leassee cannot be allowed to run its course until it expires naturally".
17.
(1)Rule 25 after the word, figure and bracket "Rule 9(1)" and before the words "the formal lease" the
words "or mining lease renewed under 22" shall be inserted.(2)In sub-rule (2) after the words "lease
deed is executed" and before the words" "the lessee shall be liable" the words 'in case mining lease is
granted under Rule 9(1)".(3)After sub-rule (2) the following shall be added;-"(3) In the case of
renewal of lease the date of commencement of the mining lease shall be the date on which the
previous lease is expired, and the lessee shall be liable to pay rent/royalty/cess from that date".
18.
(1)In sub-rule (5) of Rule 28A the words after "have been rejected" and before "may be considered"
shall be omitted.(2)The proviso to sub-rule (2) shall be omitted.
19. After sub-rule (3) of Rule 29 the following shall be added:-
"(4) The Competent Officer after such enquiry and verification, as they may deem necessary, shall
assess amount of royalty and penalty for the excess quantity at the end of the prescribed period".
20. In Rule 32A the words after the words "at least 60 days in advance" shall
be omitted and in their place "specifying a date not earlier than 30 days from
the date of such notification in the Gazette from which areas shall beBihar Minor Mineral Concession Rules, 1972

available for re-grant" shall be substituted.
21.
(1)The heading of Rule 33 shall be amended as under:-"Challans, Registers, Returns and
Signboard".(2)In sub-rule (1) at the end, the following words shall be added:-"Or Collector or
Deputy Director (Mines) or Additional Director (Mines) or Director of Mines or any other officer
authorised by them".(3)In sub-rule (2) he shall also have to display a signboard exhibiting following
information (i) name of kiln-owner, (ii) mauza and plot no. of the land on which kiln is situated, (iii)
volume of Brick earth excavated so far (iv) Date of starting bricklaying, (v) Date of firing the kiln (vi)
No of rounds already completed by kiln, (vii) stock of bricks on site on the day.(4)In sub-rule (4)
after the words and bracket "Deputy Director (Mines)" and before "or Director (Mines)" "Additional
Director (Mines)" shall be inserted.After sub-rule 4 the following shall be added. -"(5) If the
accounts, returns and other evidence produced by the lessee, permit holder or any other person who
has removed minerals, are in the opinion of any of the officers authorised under Rule 33(1)
incorrect, incomplete or unreliable either wholly or partly, the officer concerned, shall report to the
Competent Officer who shall proceed to assess to the best of his judgement, the amount of royalty
due from the assessee:Provided that if the Competent Officer himself has formed the opinion he
shall proceed forthwith to assess to the best of his judgement, the amount of royalty due from the
assessee:Provided further that the purchaser of minor mineral who intends to obtain royalty/cess
clearance certificate from the Competent Officer shall retain the challan in Form 'F' issued to the
carrier. The Competent Officer on production of challan in Form 'F' shall issue royalty/cess
clearance certificate of the quantity shown as despatched in challan".
22.
(1)In Sub-rule (1) of Rule 39 of the words after "penalty of a sum upto" and before the words "and
shall also be liable" shall be omitted and in their place "Rs. 2,000" shall be substituted.(2)In
sub-rule (2) in place of figure "10" figure "20" shall be substituted.(3)Proviso to sub-rule (2) shall be
deleted.(4)After sub-rule (2) the following shall be added:-"(3) If any lessee/permit-holder fails to
display signboard as prescribed in Rule 33 (5) he shall be liable to penalty of a sum of Rs. 1,000".
23.
(1)Sub-rule (1) of Rule 40 shall be substituted by the following:-"(1) Whoever is found to be
extracting or removing minor minerals or on whose behalf such extraction or removal is being made
he be an agent, a Manager an employee or a contractor or a sub-lessee, otherwise than in accordance
with these Rules, shall be presumed to be party to the illegal removal of the minor mineral and every
such person shall be punishable with simple imprisonment, which may extend to six months or with
fine, which may extend to rupees five thousand or with both".(2)After sub-rule (7) the sub-rule 8
shall be substituted by the following:- "(8) Whoever removes minor mineral without valid
lease/permit or on whose behalf such removal is made otherwise than in accordance with these
Rules he be an agent, Manager, contractor or a sub-lessee, shall be presumed to be a party to theBihar Minor Mineral Concession Rules, 1972

illegal removal of the minor mineral and shall be liable to pay royalty or penalty which may extend
upto four times the rate of royalty specified for the minor mineral in Schedule II without prejudice
to other action being taken against him under these Rules or any other law for the time being in
force".(3)In sub-rules (2), (3), (4), (5) and (6) in place of "Competent Officer" the following shall be
inserted:-"Competent Officer, or Deputy Director (Mines) or Additional Director (Mines) or
Director of Mines".
24. In Rule 41 after the words "Deputy Director of Mines" and before the
words "or any other officer", the words "Additional Director of Mines" shall
be inserted.
25. In Rule 42 after the words "Deputy Director of Mines" and before the word
"may" the word "he" shall be omitted and in its place the words 'of Additional
Director of Mines or Director of Mines or any other officer empowered by the
Government" shall be inserted.
26. Rule 45(i) (b) shall be omitted. For proviso to sub-rule (i) (b) of Rule 45,
proviso to sub-rule (i) (a) of Rule 45 shall be substituted.
27. After Rule 46 and before Rule 47 the following Rule shall be inserted:-
"46-A. The Commissioner, may at any time but before the expiry of six years from the date of the
order either on his own motion or on an application filed before him, call for and examine the record
of any proceeding in which any order has been passed by any Competent Officer appointed under
Rule 2(iii) or a Deputy Director of Mines, appointed under Rule 2(vi), for the purpose of satisfying
as to the legality or propriety of such order and may, after examining the records and making or
causing to be made such enquiry as he may deem to be necessary, pass any order which he thinks
proper. The Commissioner may delegate this power to any subordinate officer whom he thinks
fit:Provided that no order under this Rule shall be passed without giving the applicant as also the
authority whose order is sought to be revised or their representative, a reasonable opportunity of
being heard:Provided further that where an application is filed seeking revision of any order, such
an application shall be entertained only if it is made within ninety days of the date of
communication of the order sought to be revised. The application should be accompanied by a
treasury receipt showing that a fee of Rs. 50 has been paid into the Government Treasury or in any
branch of the State Bank of India doing treasury business to the credit of the State Government
under the head of Account "XXXII-C. - Miscellaneous-Social and Development
Organisation-Miscellaneous (i) Fees for grant and renewal of mineral concession (ii) Rent and
Royalties from mining leases and licences."Bihar Minor Mineral Concession Rules, 1972

28. (a) In Rule 47 (3) in place of figure and bracket "26(7)" figure and bracket
"26(6)" shall be substituted.
(b)After sub-rule (4) the following shall be added:-(5)If the Appellate Authority modifies an order
passed by the Competent Officer which has the effect of giving relief in the matter of Rent Royalties,
he shall forthwith forward one certificate copy and three true copies of the order to the Mines
Commissioner.
29. After Rule 48 the following shall be added:-
"49. (1) Every person who carried business of minor minerals beyond any lease hold area shall
obtain a licence from the Competent Officer in Form 'L' and shall maintain proper accounts of
purchase and sale of all such minerals in a register in Form 'G' which shall be produced before the
Commissioner, Director of Mines and Additional Director of Mines or Deputy Director of Mines or
Competent Officer or any other officers authorised by the Government, for inspection.(2)Every such
person as mentioned in (1) shall issue a transport challan in Form 'F' to every carrier, truck, tractor
or bullock cart while despatcing minerals for his stock.(3)If any person as mentioned in (i) fail to
maintain a register in Form 'G' or fail to issue a challan in Form 'F' shall be punishable with a simple
imprisonment which may extend to one year or with fine which may extend upto Rs. 1,000 (one
thousand) or with both".
30. (a) In clause 4 of Part III, Form D, of Schedule III in place of figure "45.7"
the figure "50" and in place of figure "9.14" the figure "10" shall be
substituted.
(b)In clause 2 of Part VII, Form D of Schedule III after the words "and pillars according to" and
before the words "the demarcation shown in the plan" the words "the specification prescribed" shall
be inserted.(c)In clause 2 LVII Form D of LIII shall be renumbered as "2(i)".(d)After clause 2 of Part
LVII, Form D, of Schedule III and before clause 3 the following shall be inserted:-"2-A. To maintain
and keep boundary marks and signboards in good order. - The lessee/lessees shall at his/their/own
expense display signboards within the lease hold area showing the name of the lessee/ name of the
minerals/details of the area and period of the lease and shall always maintain and keep them in
good order".
31. After Form 'K' of Schedule III the following forms shall be added:-
Form-'L'Form-'G'Form-'F'Licence In Form 'L'[See Rule 33(5)]Sri/S. Sri...............is approved to be a
person to stock minor minerals at..................(name of place) P.S...........District...............and he will
abide by the provisions of B.M.M.C. Rule, 1972.Seal and signature of Competent Officer.Form
'G'[See Rule 33(5)]Register to be maintained by StockistBihar Minor Mineral Concession Rules, 1972

1. Name of stockist Form-'L
2. Location of stock Form-'L
Mauza.............Thana No.........Mohalla Police Station............... District ......
3. Mineral-
4. Month-
Date Opening balance Quantity received Total Name of lessee/ permit-holder from whom received
1 2 3 4 5
     
Details of Challan under
which receivedTotal quantity sold,
depositedChallan under which sold/
despatchedClosing
balanceRemarks
6 7 8 9 10
     
Form F[See Rule 23(5)]No.......................Date
1. Name and address of stockist
2. Site of stock
3. Name of Minor Mineral
4. Name and address of persons to whom material has been applied/ sold.
5. Quantity
6. Truck/Tractor/Carrier no.
7. Name and address of Driver
8. Place of delivery of material
9. Date and time of despatch
Signature of StockistSeal of Competent OfficerRegarding Brick KilnsS.O. 279, dated 2nd April, 1987.
- In exercise of the powers conferred by Rule 26-A of the Bihar Minor Mineral Concession Rules,
1972, and having regard to location, population, state of civil construction, state of industrialBihar Minor Mineral Concession Rules, 1972

construction, state of urbanisation and place of industrial growth in different areas of the State, the
Governor of Bihar is pleased to classify such different areas in different categories and to determine
the number of bricks (equivalent brick earth) and a consolidated amount of royalty to be paid
thereon by the Brick kiln owner/Bricks earth remover per annum to the State Government for
different categories of areas as shown in the table below:-Table
Serial
No.Categories
of areaAreas Included in shown
categories in column (2)Fixed No. of Bricks
(equivalent Brickearth)
perkiln situated in area
shown in column 3Consolidated amount of
royalty payable per
kilnper annum on number
of Bricks shown in column
3
1 2 3 4 5
1. IUrban area of Patna,
Phulwari Sharif, Danapur,
Khagual andFatwah.12 Laks 7,500
2. IIUrban area of Jamshedpur,
Ranchi, Dhanbad,
Bokaro,Muzaffarpur,
Dharbhangaand Bhagalpur.10 Lakhs 6,250
3. III Other urban area 1 Lakh 5,000
4. IV Rural areas 6 Lakhs 3,750.
* This S.O. and the contents herein have been modified by S.O. 400M dated 17.8.1991 and again it is
revised by S.O. 27 dated 24.3.2001.Every brick kiln owner/brick earth remover shall pay 40 per cent
of consolidated amount of royalty as shown in the table herein before in one instalment before
starting the business to the State Government and the balance amount of 60 percent shall be paid in
one instalment within 90 days from the date of the start of the business.Note I. - "Urban area"
means the area within the local limits of Corporation or Municipal Corporation or Municipality or
Notified Area Committee and also includes the areas falling within 4 (four) Kms. from the boundary
of such Corporation or Municipal Corporation or Municipality as the case may be and in case of
Notified Area 'Committee the area so notified except that in respect of Fatwah Notified Area
Committee" Urban area" shall also include the area falling within 4 (four) Kms. from the boundary
of the Notified Area.Note II. - For the purpose of determining the consolidated amount of royalty on
Bangala Bhatha used for Commercial purpose the number of bricks shall be fixed at one lakh per
Bangala Bhatha per annum equivalent to Rs. 625 as consolidated amount of royalty. No royalty shall
be payable on brick/brick earth manufactured in Bangala Bhatta for non-commercial personal
consumption.S.O.281 dated 2nd April, 1987. - In exercise of the powers conferred by Rule 26-A of
the Bihar Minor Mineral Concession Rules, 1972, the Governor of Bihar is pleased to authorise the
Sub-divisional Officers and the Circle Officers to function in manner provided by rule 26-A,
aforesaid, within their respective jurisdiction.S.O.199, dated the 3rd March, 1988. - In exercise of
the powers conferred by Section 15 of the Mines and Minerals (Regulation and Development) Act,
1957 (Act 67 of 1957), the Governor of Bihar is pleased to make the following amendments in the
Bihar Minor Mineral Concession Rules, 1972:-Bihar Minor Mineral Concession Rules, 1972

1. In Rule 11-A after the words "the highest bidder on annual basis" the
following provision shall be added:
"Before the auction, the bidders shall produce royalty clearance certificate required under Rule 9(4)
or an affidavit to the effect that he is/was not a lessee or permit-holder and that he does not owe any
mining dues."After explanation of Rule 11-A following proviso shall be added. - "Provided that in
isolated and far flung areas of sand deposits which reasonably and conveniently cannot be settled by
auction shall be identified by the Collector and on their being approved as such by the
Commissioner the Competent Officer may issue permits for removal of sand from such areas for
such period not exceeding one year in respect of any one individual permit-holder:Provided further
that such isolated and far flung areas can also be settled through public auction as and when so
declared by the Commissioner."
2. After sub-rule (4) of Rule 21 following new sub-rule shall be inserted;
namely:-
"If the lessee makes default in payment of rent/royalty as required by Rule 26 or commits breach of
any of the conditions referred to in this Rule or embodied in the mining lease "From D", the
Competent Officer shall give notice to the lessee requiring him to pay the rent/royalty or remedy the
breach as the case may be within 30 days from the date of the receipt of the notice and if the
rent/royalty is not paid or the breach is not remedied within such period, the Collector may without
prejudice to any proceeding that may be taken against the lessee, determine the lease and forfeit the
whole or part of the security deposit."
3. In sub-rule (e) of Rule 39 after the words and figure "for every day" the
words and figure "subject to maximum of rupees two thousand and five
hundred" shall be inserted.
4. In sub-rule (8) of Rule 40 "for the words" royalty or penalty which may
extend upto four times the rate of royalty specified for the Minor Minerals in
Schedule II "the words" the price thereof and the Government may also
recover from such person, rent royalty or taxes as the case may be, for the
period during which the land was occupied by such person without any
lawful authority" shall be substituted.
5. In Clause 4 of Part VI of Form "D" of Schedule III for the figure "6" the
figure "15" shall be substituted.Bihar Minor Mineral Concession Rules, 1972

6. In Clause 13 of Part VII of Form 'D' of Schedule III for the figure "Rs.50" the
figure "Rs. 1000" shall be substituted.
The 16 September, 1989S.O. 1063 dated the 16th October, 1989. - In exercise of the powers
conferred by Section 15 of the Mines and Minerals (Regulation and Development) Act, 1957 (Act 67
of 1957), the Governor of Bihar is pleased to make the following amendments in the Bihar Minor
Mineral Concession Rules, 1972. -(1)Rule 3A. - Rule 3A shall be omitted.(2)Rule 3B. - Rule 3B shall
be omitted.(3)Rule 3C. - Rule 3C shall be omitted.(4)Rule 3D. - Rule 3D shall be omitted.(5)Rule 3E.
- Rule 3E shall be omitted.(6)Rule 7. - In Rule 7 in place of the words "five years", the words "ten
years" shall be substituted. After that the words "but if the Collector a periods exceeding ten years
with the prior approval of Government" shall be deleted.(7)Rule 9. - In sub-rule (3) of Rule 9 in
place of the word and figure "Rs. 500", "Rs. 200' shall be substituted. The sub-rule (5) of Rule 9
shall be omitted. After sub-rule (5) of Rule 9, the following clauses as sub-rules (6), (7), (8) shall be
inserted and existing sub-rule (6) shall be renumbered as sub-rule (9) of Rule 9 and in the existing
sub-rule (6) of Rule 9, after the figure (4) in place of figure (5), the figures (6), (7) and (8) shall be
added. -"(6) Every application shall be accompanied by an affidavit stating that the applicant
has-(i)filed income-tax return up-to-date,(ii)paid the income tax assessed on him; and(iii)paid the
income tax on the basis of self assessment as provided in the Income-tax Act, 1961.""(7) Every
application shall be accompanied by an affidavit showing particulars of areas mineral wise in such
State which the applicant or any person jointly with him-(i)already holds under a mining
lease;(ii)has applied for but has not been granted; and (iii) being applied for simultaneously.""(8)
Every application shall be accompanied by statement in writing that the applicant has, where the
land is not owned by him, obtained surface rights over the area or has obtained the consent of the
owners for starting prospecting operation:Provided that no such statement shall be necessary where
the land is owned by the Government."(8)Rule 11A. - In Rule 11, after the second proviso the
following proviso shall be inserted:-"Provided further that anything contained herein before in this
Rule shall not prevent the Collector from exercising his power u/r9 in cases covered by Rule 12 (i)
hereinafter."(9)Rule 12. - (1) In sub-rule (1) of Rule 12 in place of word "and" used after the word
"Central Government", "(comma)" shall be substituted and after the word "local body" the words,
"and Co-operative Society" shall be inserted.(2)In the end of sub-rule (1) of Rule 2, the following
shall be appended:-"However, the Collector may give preference to such Co-operative Society all the
members/share-holders of which belong to Scheduled Tribe and which has duly been registered
under Bihar and Orissa Cooperative Societies Act, 1935."(10)Rule 21. - (1) In place of the clause (b)
of sub-rule (3) of Rule 21, following clause shall be substituted as clause "(b) The leassee shall pay to
the occupier of the surface of the land such compensation as may become payable under these
Rules".(2)In place of the clause (c) of sub-rule (3) of Rule 21 the following shall be substituted:-"(c)
The lessee shall take such measures for planting in the same area or any other area selected by the
Central or State Government not less than twice the number of trees destroyed by reason of any
mining operation or to the extent possible, the restoration of flora and other vegetation destroyed by
such operations".(3)After clause (n) of sub-rule (3) of Rule 21, a new sub-clause (o) shall be
added-"(o) The lessee shall not pay a wage lesser than the minimum wage prescribed by the Central
or State Government from time to time under the Minimum Wages Act, 1948".(11)Rule 22. - The sub
Rule (2) (e) of Rule 22 shall be omitted and sub-rule (2) (f) shall be re-numbered as sub-rule (2) (e).
In sub-rule (2) (a) of Rules 22 in place of "Rs. 500" "Rupees 2,000" shall be substituted, AfterBihar Minor Mineral Concession Rules, 1972

re-numbered sub-rule (2) (e) of Rule 22, the following clauses shall be inserted as sub-rules (f) and
(g):-"(f) Every application for the grant of renewal of mining lease shall be accompanied by an
affidavit showing that he has-(i)filed uptodate income-tax returns(ii)paid the income-tax assessed
on him; and(iii)paid the income tax on the basis of self assessment as provided in the Income-Tax
Act, 1961"."(g) Every application for grant of renewal of mining lease shall be accompanied by an
affidavit showing-Particulars of area Mineral-wise in the State which the applicant or any person
jointly with him,-(i)already holds under a mining lease;(ii)has applied for but has not been granted a
mining lease; and(iii)being applied for simultaneously."(12)Rule 40 (9). - After Rule 40 sub-rule (8),
the following new sub-rules 40(9) and 40 (10) shall be added, namely:-
40.
(9)Notwithstanding anything contained in Rule 40 (8) hereinbefore, whosoever, under the terms of
an agreement other than an agreement under these Rules at any time has received or receives cost of
minor mineral/material including royalty under the terms of the said agreement shall deposit that
royalty which is included in such cost of mineral/ material in the manner prescribed in Rule 43
hereinafter, within seven days from the date of receipt of such cost of mineral/material.Any royalty
received as such by such person before the commencement of this Rule shall be deposited by him
within fifteen days from the date of commencement of this Rule:Provided that if a sum equal to the
royalty included in the cost of mineral/material so received has already been paid or deposited prior
to receipt of cost of the mineral/material including royalty by him he shall not be required to deposit
the royalty said above:Provided further that any royalty payable under this Rule, if not paid when
due be recovered with interest @ 15 per cent per annum as an arrear sum of public
demand".(13)Rule 40 (10) To prevent evasion of royalty it is provided that works contractor shall
purchase the minerals from lessee/permit holder and authorised dealers only and no Works
Department shall receive the bill which the works contractors submit to recover cost etc. of mineral
used by them in completion of the works of the Works Department under any agreement from the
works contractor if the said bill is not accompanied by an affidavit in Form 'M' with particulars in
Form 'N' of these Rules alongwith a photo copy of the said affidavit and particulars. It shall be the
duty of the officer who receives or on whose behalf the said bill is received to send the photo copy of
the Affidavit and particulars to the District Mining Officer/Assistant Mining Officer within whose
jurisdiction the mineral was allegedly purchased, for verification.If contents of the said affidavit on
verification by the concerned District Mining Officer/Assistant Mining Officer is found to be false
either wholly or partly it shall be presumed that the concerned mineral was obtained by illegal
mining and in that event the said District Mining Officer/Assistant Mining Officer shall take action
as prescribed in the Rules against the maker of the said affidavit:Provided that if the works
contractor deposits or pays the royalty in respect of the mineral so consumed/supplied by him as
shown in the aforesaid affidavit and particulars the said District Mining Officer/ Assistant Mining
Officer in his discretion may not take action as prescribed in this Rule".Explanation. - For the
purposes of this Rule-(i)"Works Department" means departments of the Central or State
Government including Company, Corporation Undertaking, Autonomous body of the Government
engaging works contractors for any kind of construction on its behalf.(ii)"Works Contractor" means
an individual, a firm, a company, an association or body of individuals who under an agreement
with Works Department work for the said Department".(14)Rule 43 A. - After Rule 43 a new Rule asBihar Minor Mineral Concession Rules, 1972

Rule 43-A shall be added:-"43(A). The Government may, without prejudice to the provisions
contained in the Act or any other Rule in these Rules charge simple interest at the rate of 15 per cent
per annum on any rent royalty or fee (other than the fee payable under Rule 46 (A) or other sum due
of the Government."(15)Rule 49 (1)-At the end of Rule 49 (1) the following shall be added:-Every
application for obtaining licence in Form "L" shall be accompanied with a fee of Rs. 100." After the
words "in Form L" in Rule 49 (1) the words "which shall be displayed at a conspicuous place of
business" shall be inserted.In sub-rule 49 (3) after the words "fails to" the words "obtain Form 'L'
or" shall be inserted.(16)After Rule 49 a new chapter VII consisting of new Rules be added:-
Chapter VII
"Rule 50. - Payment of compensation to owner of surface rights, etc. - (1) The holder of a
prospecting licence or a mining lease shall be liable to pay to the occupier of the surface of the land
over which he holds the prospecting licence or as the case may be the mining lease, such annual
compensation as may be determined by an officer appointed by the State Government by
Notification in this behalf in the manner provided in sub-rules (2) to (4);(2)In case of agricultural
land other than the land referred to in sub-rule (4) the amount of annual compensation shall be
worked out on the basis of the average annual net income for the cultivation of similar land for the
previous 3 years;(3)In case of non-agricultural land, the amount of annual compensation shall be
worked out on the basis of average annual letting value of similar land for the previous three
years;(4)The annual compensation referred to in sub-rule (1) shall be payable on or before such date
as may be specified by the State Government in this behalf.(17)"Rule 51. - Assessment of
compensation for damage. - (1) After termination of prospecting licence or mining lease, the State
Government shall assess the damage, if any, done to the land by the prospecting or mining
operations and -shall determine the amount of compensation payable by the licensee or as the case
may be the lessee to the occupier of the surface land.(2)Every such assessment shall be made within
a period of one year from the date of termination of the prospecting licence or mining lease and shall
be carried out by an officer appointed by the State Government by Notification in this
behalf."(18)Schedule I under Rule 26 (i) (a). - The schedule I under Rule 26 (i)(a) shall be
substituted by the following new Schedule I."Schedule I[See Rule 26 (i) (a)]Dead Rent
Period of the mining leas  Rate of dead rent per acre
  Rupees
1. 1st Year ...250.00
2. 2nd year and onwards ...1,000.00
(19)In Form D, Part VII, Clause 11 A. - In Form D in part VII after clause 11 the following clauses
shall be inserted, namely:-"11 (A). The lessee shall pay a wage not lesser than the minimum wages
prescribed by the Central or State Government from time to time.
11.
(B). The lessee shall comply with provisions of the Mines Act, 1952.Bihar Minor Mineral Concession Rules, 1972

11.
(C). The lessee shall take measures, at his own expense for the protection of the environment like
planting of trees, reclamation of mined land, use of pollution control device and such other
measures as may be prescribed by the Central or State Government from time to time.
11.
(D). The lessee shall pay compensation to the occupier of the land on the date and in the manner
laid down in these Rules."(20)Schedule III, Form K under Rule 3 (B) (3). - Form 'K' shall be
omitted.(21)Schedule III, Form M under Rule 40 (10). -Form-M[See Rule 40 (10)]AffidavitIn the
court of Executive MagistrateI,..............Son of..........resident of Moh............,P.O...........,
PS............District.......do hereby solemnly affirm and declare as follows:-
2. That I am a registered Contractor of the Department of Government of
Bihar/Union of India and have taken works of Construction of.............
3. That in the course of aforesaid work I have supplied/consumed the
following quantity of minerals-
(a)sand on.(dates) which was purchased by me from........(full address of a lessee/permit
holder/other person).(b)Stone on (dates) which was purchased by me from (full address of a
lessee/permit holder/other person).(c)............mineral on........which was purchased by me from (full
address of lessee/permit holder/other person).*4. That the materials described in the paragraph 3
above were purchased by me in good faith and after due inquiry that the sell thereof was authorised
to deal with that and the details of which is given below:-(i)Name and address of the seller, if the
seller is a lessee/permit holder the details of the mine from which the mineral so sold was
extracted......If the seller is not a permit holder/lessee then the name and address of other person
from whom the seller has purchased............(ii)The quantity of the purchased mineral with dates.......
5. That the certificate issued by the seller from whom the minerals
consumed/ supplied by me was purchased is attached herewith which I
believe to be true.
6. That the contents of this affidavit are true to the best of my knowledge and
belief.
Signature of Deponent.*This paragraph will not apply if the Contractor submits a certificate in the
prescribed form issued by the seller of the mineral.Form-'N'[See (Rule 40 (19)]Form N under Rule
40(10). - Specimen of the certificate which the works Contractor will obtain from the sellers which
he will enclose with the bill alongwith the affidavit.(1)Name and address of the seller, if the seller is a
lessee/permit holder the details of the mine from which the concerned mineral was extracted.(2)IfBihar Minor Mineral Concession Rules, 1972

the seller is not a lessee/permit holder then the name and address of that person from whom the
said seller had purchased the minor mineral which was subsequently purchased by works contractor
with the date of such purchase by the seller.(3)Name and address of the
purchaser/contractor.(4)Quantity of mineral purchase by the Contractor with date.Certified that the
aforesaid particulars are true to my knowledge and belief.Signature of Seller.DateRegarding Brick
KilnsS.O.400-M, the 17th August, 1991-In exercise of the powers conferred by Rule 26-A of the
Bihar Minor Mineral Concession Rules, and having regard to location, population state of Civil
Construction, state of Industrial Construction, state of urbanisation and place of industrial growth
in different areas of the State, the Governor of Bihar is pleased to amend the previous notification
no. S.O. 279, dated the 22nd April, 1987 and to re-classify such different areas in different categories
and to determine again the number of bricks (equivalent to brick earth) and a consolidated amount
of royalty to be paid thereon by bricks Kiln owner/Brick-earth remover per kiln per annum to the
State Government for different categories of areas as shown in the table below-Table
Sl.
No.Categories
of areaAreas included in categories
as shown in column(2)Fixed no. of (equivalent
Brickearth) per
kilnsituated in areas
shown in column (3).Consolidated amount of
royalty payable per kilnper
annum on the no. of brick
shown in column (4).
1 2 3 4 5
1. IBrick manufactured by
Mechanised kiln set-up25 lakhs 62,500
2. IIUrban areas of Patna,
Phulwari Sharif, Danapur,
Khagaul andFatwah.12 lakhs 30,000
3. IIIUrban areas of Jamshedpur
Ranchi, Dhanbad,
Bokaro,Muzaffarpur,
Darbhanga and Bhagalpur.10 lakhs 25,000
4. IV Other urban areas, 8 lakhs 20,000
5. V Rural area, 6 lakhs 15,000
6. VISingle Bricks kiln
(excluding serial no. 1) is
being run inthe areas of any
categories.Half number of bricks
out of fixed quantity
forthe category.Half amount of
consolidated royalty for
area.
7. VIIBangla Bhatta (For
Commercial use.)1 lakh 2,500
Every brick kiln owner/brick earth remover shall pay 40 percent of the consolidated amount of
royalty as shown in the table herein before in one instalment before starting the business, to the
State Government and the balance amount of 60 percent shall be paid in one instalment within 90
days from the date of start of the business.Note I. - "Urban area" means the areas within the local
limits of Corporation or Municipal Corporation or Municipality or Notified Area Committee and also
includes the areas falling within 4 (four) Kms. from the boundary of such Corporation or Municipal
Corporation or Municipality as the case may be, and in case of Notified Area Committee, the area isBihar Minor Mineral Concession Rules, 1972

so notified except that in respect of Fatwah Notified Area Committee, "Urban area" shall also
include the areas falling within 4 (four) Kms. from the boundary of the Notified Area.Note. II. - For
the purpose of determining the consolidated amount of royalty on the "Bangla Bhatta" used for
Commercial purpose, the number of bricks shall be fixed at one lakh per Bangala Bhatta per annum
equivalent to Rs. 2500 as consolidated amount of royalty. No royalty shall be payable on
brick/brick-earth manufactured in Bangla Bhatta for non-commercial personal
consumption.Notification. No. 1126 dated 27.3.92-In exercise of the powers conferred by Rule 26-A
of the Bihar Minor Mineral Concession Rules, 1972, and having regard to location, population, state
of construction, state of industrial construction, state of urbanisation and place of industrial growth
in different areas of the State, the Governor of Bihar is pleased to amend the previous notification
No. S.O. 400/M, dated 17 August, 1991, and substitute to re-classify such different areas in different
categories and to determine again the number of bricks equivalent to brick-earth and consolidated
amount of royalty to be paid thereon by bricks kiln owner/brick earth remover per kiln per annum
to the State Government for different categories of the areas as shown below. -
Sl.
No.Categories
of areaAreas included in categories
as shown in column(2)Fixed no. of (equivalent
Brickearth) per
kilnsituated in areas
shown in column (3).Consolidated amount of
royalty payable per kilnper
annum on the no. of brick
shown in column (4).
1 2 3 4 5
1. IBrick manufactured by
Mechanised kiln set-up25 lakhs 62,500
2. IIUrban areas of Patna,
Phulwari Sharif.12 lakhs 30,000
3. IIIUrban areas of Jamshedpur
Ranchi, Dhanbad,
Bokaro,Muzaffarpur,
Darbhanga and Bhagalpur.10 lakhs 25,000
4. IV Other urban areas, 8 lakhs 20,000
5. V Rural area, 6 lakhs 15,000
6. VISingle Bricks kiln
(excluding serial no. 1) is
being run inthe areas of any
categories.Half number of bricks
out of fixed quantity
forthe category.Half amount of
consolidated royalty for
area.
7. VIIBangla Bhatta (For
Commercial use.)1 lakh 2,500
Every brick kiln owner/brick earthremover shall pay all amount of consolidated royalty in one
instalment as shown in the table here in before issue of the permit.Note I. "Urban area" means the
areas within local limits of Corporation or Municipal Corporation or Municipality or Notified Area
Committee and also includes the area falling within 4 (four) kilometres from boundary of such
Corporation of Municipal Corporation or Municipality as the case may be, and in case of Notified
Area Committee, the area is so notified except that in respect of Fatwah Notified Area Committee,
"Urban area" shall also include the areas falling within 4 (four) kms. from the boundary of the
Notified area.Note II. For the purpose of determining the consolidated amount of royalty on theBihar Minor Mineral Concession Rules, 1972

"Bangla Bhatta" used for commercial purpose the number of bricks shall be fixed at one lakh per
Bangla Bhatta per annum equivalent to Rs. 2,500 as consolidated amount of royalty. No royalty
shall be payable on brick/brick-earth manufactured in Bangla Bhatta for non-commercial personal
consumption.S.O.27, dated 24 March, 2001. - In exercise of the power conferred by Rule 26(A) of
the Bihar Minor Mineral Concession Rules, 1972 and having regard to state of civil construction,
state of industrial construction, state of situated population, state of urbanisation and place of
industrial growth in different areas of the State, the Governor of Bihar is pleased to amend the
previous notification S.O. No. 0367, dated 6th October, 1994 and reclassify such areas to deter, fine
the number of bricks per fixed kiln and Bangala Bhatta and the consolidated amount of royalty to be
paid thereon by brick-kiln owner/brick earth remover per kiln per annum to the State Government
for different areas as shown in the table below:-Table
Sl.
No.Categories
of areaName of districts and
areasCapacity Fixed no. for the
manufactured bricksper fixed
kiln and Bangla Bhatta situated
in areas shown incolumn 3Royalty Amount of royalty
payable per kiln
perannum on number of
bricks fixed in column 4
(In Rupees)
1 2 3 4 5
1. IUrban areas of Patna,
Muzaffarpur, Gaya,
Darbhanga district.45 lakh bricks Rs. 90,000/-
2. II Other Urban area 35 lakh bricks Rs. 70,000/-
3. III Rural area 25 lakh bricks Rs. 50,000/-
4. IV Bangla Bhatta 1 (One) lakh bricks Rs. 3,000/-
2. This order will come into force from 1.4.2001.
Note. I-Consolidated royalty shall be paid in two instalments, namely:-(i)First instalment-50% of
the total payable royalty amount before commencement, of kiln and(ii)Second instalment-Rest 50%
of the total amount before the month of March.If the payment of total amount of payable royalty is
made in one lump sum by a kiln owner then 5% rebate shall be given on the total payable
royalty.Note II. - "Urban Area" means the areas within the local limits of Municipality or Municipal
Corporation or Notified Area Committee and also includes the area falling within 4 kms. outside the
boundary limits of such Municipal Corporation or Municipality or Notified Area Committee, as the
case may be;Note III. - No royalty shall be payable on bricks/brick earth manufactured in Bangla
Bhatta for non-commercial, personal consumption.Number of bricks per fixed kiln &
Royalty[S.O.27, dated 24 March, 2001. - In exercise of the power conferred by Rule 26(A) of the
Bihar Minor Mineral Concession Rules, 1972 and having regard to state of civil construction, state of
industrial construction, state of situated population, state of urbanisation and place of industrial
growth in different areas of the State, the Governor of Bihar is pleased to amend the previous
notification S. O. No. 0367, dated 1. Substituted by S.O. 259 dated 26.3.1987. 6th October, 1994 and
reclassify such areas to determine the number of bricks per fixed kiln and Bangala Bhatta and the
consolidated amount of royalty to be paid thereon by brick-kiln owner/brick earth remover per kiln
per annum to the State Government for different areas as shown in the table below:-Bihar Minor Mineral Concession Rules, 1972

Sl.
No.Categories
of areaName of districts and
areasCapacity Fixed no. for the
manufactured bricksper fixed
kiln andBangla Bhattasituated
in areas shownin column 3Royalty Amount of royalty
payable per kiln
perannum on number of
bricks fixed in column 4
(In Rupees)
1 2 3 4 5
1. IUrban areas of Patna,
Muzaffarpur, Gaya,
Darbhanga district.45 lakh bricks Rs. 90,000/-
2. II Other Urban area 35 lakh bricks Rs. 70,000/-
3. III Rural area 25 lakh bricks Rs. 50,000/-
4. IV Bangla Bhatta 1 (One) lakh bricks Rs. 3,000/-
2. This order will come into force from 1.4.2001.
Note I-Consolidated royalty shall be paid in two instalments, namely(i)First instalment-50% of the
total payable royalty amount before commencement, of kiln and(ii)Second instalment-Rest 50% of
the total amount before the month of March.If the payment of total amount of payable royalty is
made in one lump sum by a kiln owner then 5% rebate shall be given on the total payable
royalty.Note II-"Urban Area" means the areas within the local limits of a Municipality or Municipal
Corporation or Notified Area Committee and also includes the area falling within 4 kms. outside the
boundary limits of such Municipal Corporation or Municipality or Notified Area Committee, as the
case may be;Note III-No royalty shall be payable on bricks/brick earth manufactured in Bangla
Bhatta for non-commercial, personal consumption.Bihar Minor Mineral Concession Rules, 1972

