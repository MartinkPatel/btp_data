Cubastion Consulting Pvt Ltd vs Shubham Saxena on 28 March,
2023
     IN THE COURT OF MS. SHRIYA AGRAWAL,
   JSCC cum ASCJ cum GJ, SOUTH-EAST DISTRICT,
              SAKET COURTS, DELHI
CS SCJ 254/20
CNR No. DLSE03-000539-2020
CUBASTION CONSULTING PVT LTD
701, TOWER-2, VATIKA BUSINESS PARK
SECTOR-49, SOHNA ROAD
GURGAON-HARYANA-122009.           ... PLAINTIFF
                                  VERSUS
SHUBHAM SAXENA
S/O SH. RAJ KUMAR SAXENA
R/O 117, BLOCK-E, 2ND FLOOR
KALKAJI, NEW DELHI-110019.
ALSO AT
BHARTI AIRTEL LIMITED
PLOT NO.16, UDYOG VIHAR, PHASE-IV
SECTOR -18, GURUGRAM
HARYANA-122015.                 ... DEFENDANT
   SUIT FOR PERMANENT INJUNCTION FOR
    PASSING OFF THE LITERARY WORK &
   TRADE SECRETS OF THE PLAINTIFF AND
                DAMAGES
                                      Date of Institution : 13.02.2020
                             Date of reserving Judgment : 23.03.2023
                                       Date of Judgment : 28.03.2023
CS SCJ 254/20   Cubastion Consulting Pvt Ltd Vs Shubham Saxena   Page no.1 of 27
                                JUDGMENT
1. The present suit has been instituted by the Plaintiff against the Defendant for the following reliefs:
a) A Decree of Perpetual Injunction restraining the Defendant, either by himself orCubastion Consulting Pvt Ltd vs Shubham Saxena on 28 March, 2023

through any of his agents, associates, employees, servants, and / or assigns from
passing off the Plaintiff's Confidential information to M/s Bharti Airtel Ltd;
b) A Decree of Perpetual Injunction restraining the Defendant, either by himself or
through any of his agents, associates, employees, servants, and / or assigns from
passing off the Plaintiff's Confidential information to any / all third parties;
c) A Decree for Perpetual Injunction restraining the Defendant, to work for or
provide service to M/s Bharti Airtel in relation of CRM Tools;
       d)       Cost;
       e)       Any other relief.
CASE OF PLAINTIFF AS PER PLAINT
2. Briefly, the Plaintiff is a Company and described as one of the specialized service
providers and consultants of Customer Relationship Management software solutions
(hereinafter for short 'CRM Tools') The Plaintiff is a specialized CRM consultant and
also a Siebel specialized Oracle Gold Partner in India since the year 2010. The
Defendant is an ex-employee of the Plaintiff who had joined the Company on
03.09.2018, as an Associate Consultant pursuant to the offer letter issued by the
Plaintiff to him. The Defendant had further agreed to abide by the general terms and
CS SCJ 254/20 Cubastion Consulting Pvt Ltd Vs Shubham Saxena Page no.2 of 27
conditions as set out in the appointment letter dated 31.08.2018.
Upon the Defendant joining the Plaintiff as an Associate Consultant, he was imparted technical and
business knowledge concerning methods, processes, formulae, compositions, systems, techniques,
computer programs and customer lists, pricing data, source of supply etc. during various training
sessions held by the Plaintiff Company for its employees. It is averred that the said knowledge which
was imparted to the Defendant by the Plaintiff, is not available in the public domain. The same is
critical and vital for conducting the business of the Plaintiff in the ordinary course.
3. It is the claim of the Plaintiff that it was made clear to the Defendant that the knowledge imparted
to him during the training sessions is strictly proprietary, confidential and also forms a part of their
trade secrets. The Defendant had assured that the said knowledge would be held in trust and
confidence, knowing the same to be confidential and proprietary to the Plaintiff. He had also
undertaken that the same shall not be misused or disclosed to any third party even after
discontinuation of his employment with the Plaintiff. During the course of his employment with the
Plaintiff, the Defendant was also sent on deputation/ on-site visit to customers of the Plaintiff. On
03.09.2019, the Defendant No.1 had tendered his formal resignation from the post of 'Associate
Consultant' through an Email.
CS SCJ 254/20 Cubastion Consulting Pvt Ltd Vs Shubham Saxena Page no.3 of 27Cubastion Consulting Pvt Ltd vs Shubham Saxena on 28 March, 2023

4. It is claimed further that at the time of his resignation, the Defendant had expressly represented,
assured and promised the Plaintiff that his next employment would not be with any of Plaintiff
Company's customers/ clients either directly or indirectly and the business secrets and confidential
information/ data of their client acquired/ learnt by him during his employment tenure, shall be
kept confidential and not be divulged to any person/ organization. Accordingly, on the aforesaid
assurance, his resignation was accepted by the Plaintiff and the Defendant was relieved from his
services on 02.12.2019. It is stated that upon background verification by one of the Plaintiff's
customers i.e. Bharti Airtel on 12.12.2019, the Company learnt that after the Defendant had left the
Plaintiff on 02.12.2019, pursuant to his resignation on 03.09.2019 he had joined Bharti Airtel Ltd,
despite knowing that it is one of the existing customers of the Plaintiff. Defendant therefore violated
the terms and conditions stipulated in his appointment letter/ agreement and also committed
breach of the Non-Disclosure Agreement dated 02.12.2019. The fact that the Defendant had joined
one of its customers, Bharti Airtel, was also confirmed by one of the deputed on-site employees.
5. It is further averred that the Plaintiff Company had developed and maintained confidential data
and information regarding internal processes, specific client profile, client details, business strategy,
methods, finances, client budget, CS SCJ 254/20 Cubastion Consulting Pvt Ltd Vs Shubham Saxena
Page no.4 of 27 pricing structure, upcoming projects, vendors business profiles etc. The aforesaid
confidential data had been developed over a period of several years by putting in extensive efforts.
The Defendant, being the former employee of the Plaintiff, had access to some of its secret and
confidential data during the course of the employment and the Defendant after resigning from the
service of the Plaintiff Company also took over some important and confidential files, documents
and records of the Plaintiff, illegally using them for his own advantage. In this background, the
present suit has been filed against the Defendant for the aforesaid reliefs.
WRITTEN STATEMENT
6. Per Contra, it is stated that the suit ought to be dismissed as it is barred by Section 27 of the
Indian Contract Act, 1872 and the reliefs claimed are violative of the fundamental rights of the
Defendant under Articles 19 (1) (g) and 21 of the Constitution of India. It is stated that the Plaintiff
has failed to plead or disclose the author of the alleged literary work or disclose any particulars
thereof, over which the Plaintiff can assert any protection under any law. It is averred that the
pleadings in the plaint are highly vague and lack material in particulars as no details of any alleged
literary work have been disclosed, access to which has been misused by the Defendant. No trade
secrets or confidential information have been disclosed either, which are alleged to have been
misused by the Defendant. It is specifically stated that the Defendant was not CS SCJ 254/20
Cubastion Consulting Pvt Ltd Vs Shubham Saxena Page no.5 of 27 privy to nor was provided any
confidential information during the course of his employment with the Plaintiff. The Defendant was
not given any business knowledge, formulae, compositions, customers lists, pricing data, source of
supply etc. as alleged by the Plaintiff.
7. It is further claimed that the CRM tool, concerning which the Defendant was imparted training is
not a software owned exclusively by the Plaintiff. The same is a proprietary acquisition of the Oracle
systems. The use of such tools owned by Oracle is a standard training given by several companies toCubastion Consulting Pvt Ltd vs Shubham Saxena on 28 March, 2023

its employees and cannot be considered to be a trade secret, on which any propriety rights can be
claimed by the Plaintiff. The Defendant was only provided with the requisite training to use the
CRM tools. He was not provided with any information in relation to business strategies, methods
and finances, client budget etc. The plaint is lacking in disclosure of such details as well.
8. It is averred that Clause 8.5 of the 'General Service Conditions' has no application in the facts and
circumstances of the present case as the same stipulates restrictions on taking up employment
opportunities with its competitors or customers only when the services of an employee are
terminated. In the present case, the Defendant has willfully resigned from the Plaintiff Company
and had also served his notice period as mandated under Clause 8.2. The Defendant was associated
with CS SCJ 254/20 Cubastion Consulting Pvt Ltd Vs Shubham Saxena Page no.6 of 27 the Plaintiff
Company for a period of over one year in the position of an Associate Consultant which is mild-level
employment position in the business chain of the Plaintiff Company. The present suit has been filed
on false and baseless allegations, without considering the scope of work and associated
responsibilities assigned to the Defendant during his tenure with the Plaintiff Company. It is stated
that after getting a confirmation of an unconditional/unequivocal release from employment under
the Plaintiff Company, the Defendant joined the employment of M/s Bharti Airtel. He was given a
respectful exit. The Plaintiff has solely based its claim on Clause 8.5 of the Appointment Letter,
which per se is void ab-initio.
9. Defendant was mandatorily required to sign the said Non-Disclosure Agreement failing which he
would not have been provided with a relieving letter. It is highlighted in defence that even the said
Agreement was vague, failing to disclose any information allegedly given to the Defendant during
his employment and meant to be kept confidential. It is further stated that the Clause 8.5 of the
'General Service Conditions', on which the Plaintiff has based its case for injunction against the
Defendant from providing services to Bharti Airtel, is itself void under Section 27 of the Indian
Contract Act. It is averred that the Defendant joined M/s Bharti Airtel on 03.12.2019 after being
duly relieved from his employment with the Plaintiff Company.
CS SCJ 254/20 Cubastion Consulting Pvt Ltd Vs Shubham Saxena Page no.7 of 27 ISSUES
10. The Ld. Predecessor vide Order dated 27.09.2021 had framed the following issues:
1. Whether the suit of plaintiff is barred by Section 27 of Indian Contract Act? OPD
2. Whether the defendant is having any confidential information of the business of
plaintiff? OPP
3. Whether the defendant has ever tried to hand order /transfer such confidential
information pertaining to business of plaintiff to M/s Bharti Airtel Ltd or any other
third party? OPP
4. Whether the plaintiff is entitled to decree of permanent injunction as prayed for?
OPPCubastion Consulting Pvt Ltd vs Shubham Saxena on 28 March, 2023

5. Relief.
PLAINTIFF EVIDENCE
11. The Plaintiff examined its Authorised Representative Mr. Manish Bhakhoo as PW1, who deposed
on the strength of his affidavit Ex. PW1/A tendering in evidence, inter-alia, copy of offer letter dated
31.08.2018 [Mark B (colly)], e-mails dated 10.10.2019 and 03.09.2019 [Ex.PW1/2 (colly)], Non-
Disclosure Agreement (Ex.PW1/3), Email Dated acourt2903.01.2020 (Ex.PW1/4), Office Copy of
Legal Notice Dated 06.01.2020 (Mark C) and Affidavit cum Certificate under Section 65(B) of the
Indian Evidence Act (Ex. PW1/6).
12. In his cross examination by the Ld. Counsel for the Defendant, the witness stated that he did not
have any personal knowledge about the Defendant's engagement with the Plaintiff Company and
what was done during his tenure. He stated that the Defendant had been imparted training by the
senior consultant of the Plaintiff Company whose name he did not CS SCJ 254/20 Cubastion
Consulting Pvt Ltd Vs Shubham Saxena Page no.8 of 27 know. He acknowledged that there was no
document on record as could confirm the claim that the Defendant was imparted knowledge on
various forms of techniques and business, including but not limited to methods, processes,
formulae, compositions, systems and computer programmes or that he had access to customer list,
pricing data, source of supply of the Plaintiff Company. When asked if all the information
concerning the alleged training imparted to the Defendant, was in already in the public domain,
available on portals such as Google, leaving no need for the Defendant to specifically approach the
Plaintiff for the same, the witness stated that he was not aware, as this was not his area of expertise.
He could also not say if the same was available in the public domain as suggested. As regards the
claim of the Plaintiff that the knowledge imparted to the Defendant during training being
proprietary and confidential, was duly informed to the Defendant, the witness drew attention to the
Non-Disclosure Agreement in support in response, which was mentioned to have been signed on
02.12.2019.
13. He further explained that the details of the information had not been filed on record, since the
same were confidential. The Defendant gave his resignation on 03.09.2019 and his last day was
02.12.2019. After a few days, he claimed that the Plaintiff came to know from one of its deputed on
site employees that the Defendant had joined another Company. They had also received a
background verification call CS SCJ 254/20 Cubastion Consulting Pvt Ltd Vs Shubham Saxena Page
no.9 of 27 concerning the same. He further admitted that the Defendant had not collaborated /
worked with any client of the Plaintiff, other than Bharti Airtel and also that one year period of
employment under the contract inter-se the Plaintiff and the Defendant had also expired. The
witness was asked to state as to during the period from December 2019 till 2022, what information
of the Plaintiff Company according to him had been divulged by the Defendant. The witness stated
that the information so divulged included (but was not limited to) that pertaining to pricing,
upcoming projects, Plaintiff's clients and customers list, technical strategies /knowledge provided by
the Plaintiff's team. He could not refer to any specific document on record as could show the
information as claimed by him to have been divulged by the Defendant or that the Plaintiff had
suffered losses due to such divulging of information illegally. The witness could not confirm if theCubastion Consulting Pvt Ltd vs Shubham Saxena on 28 March, 2023

tools/ software design for the customers of the Plaintiff Company were specific only to that
customer or could have been generally used.
14. He could not say if the CRM Tool had been developed by the Plaintiff itself for record keeping.
When asked about any action taken by the Plaintiff against the Defendant after it learnt that the
Defendant had joined the Bharti Airtel, the witness stated that their HR team had confronted him,
inter-alia, through telephonic calls asking him to quit and join the Plaintiff back. A violation letter
was also issued in December 2019. The witness admitted that the Defendant had been given an CS
SCJ 254/20 Cubastion Consulting Pvt Ltd Vs Shubham Saxena Page no.10 of 27 honorable
discharge at the time he quit his employment with the Plaintiff. At the time of acceptance of the
relieving letter from the Defendant, no allegations had been made against him by the Plaintiff. The
witness was specifically asked as to what was the basis for him to claim that the Defendant had
illegally used the alleged information passed on to him to his advantage. He stated that ever since he
had joined the Bharti Airtel, the resources required to be provided by Plaintiff for their project had
reduced, affecting their billing, which had also gone down and they suffered losses. He stated that
no complaint was filed on record pertaining to the alleged illegal retention of important and
confidential files, documents and records by the Defendant, in breach of the terms and conditions of
his appointment letter. The witness was asked to state as to what was the basis of the claim of the
Plaintiff that the Defendant had acted negligently and in irresponsible manner prejudicing the
security of confidential data of the Plaintiff Company. He deposed that the Defendant had joined
Bharti Airtel and had divulged crucial information to their prejudice. Despite being confronted
about the same, he continued to remain associated with Bharti Airtel and acted negligently, as even
at the time of exit formalities, their HR Team had apprised the Defendant of the restrictions against
divulging the information to third parties.
DEFENDANT EVIDENCE
15. The Defendant deposed as DW1 on the basis of his evidence affidavit, tendering in evidence his
Conduct CS SCJ 254/20 Cubastion Consulting Pvt Ltd Vs Shubham Saxena Page no.11 of 27
Certificate dated 27.12.2019 (Ex.DW1/1), and relieving letter dated 27.12.2019 (Ex.DW1/2). The
witness was cross examined by the Ld. Counsel for Defendant. He stated that he had joined the
Plaintiff on 03.09.2018. He affirmed that training sessions were held at the Plaintiff Company at the
time of his joining as Associate Consultant.
16. When asked about CRM tools, the witness stated that it is a customer relationship management
software which helps process the customer-based data as per business requirements. He stated that
during his tenure under the Plaintiff, he was only deputed in Bharti Airtel and that when deputed
there he was using Siebel CRM tools. He denied the suggestion that while using the CRM tools, he
had been given access to customer data. The witness further stated the usage of CRM tools was in
line with the business requirements shared by the Airtel team. He stated that Bharti Airtel team had
given him individual access to the CRM tools through separate user ID and password and after
logging in through the said particulars, he would operate on the same on the basis of business
requirements shared. The witness was asked as to whether at the time of signing the NDA, the HR
manager of the Plaintiff briefed him on what information was confidential and what was not. TheCubastion Consulting Pvt Ltd vs Shubham Saxena on 28 March, 2023

witness responded in the negative. He stated that he was not aware if the Plaintiff Company had a
license of a CRM Software of the Oracle System.
CS SCJ 254/20 Cubastion Consulting Pvt Ltd Vs Shubham Saxena Page no.12 of 27 APPRAISAL &
FINDINGS
17. Final arguments were heard threadbare. The record has been carefully perused.
18. The Plaintiff has instituted the instant suit against the Defendant, its ex-employee, for the
afore-mentioned reliefs, on the claim of the latter having, upon exiting from employment with the
Plaintiff, violated the terms and conditions regulating his association with the latter (Mark B colly),
particularly Clause 8.5 thereof, as well as the conditions under the Employee Confidentiality and
Non Disclosure Agreement dated 2.12.2019 (Ex PW1/3), duly executed and signed by the Defendant
at the time of completion of his exit formalities with the Plaintiff. The cause of action is stated to
have arisen in the above light in favour of the Plaintiff, when the Defendant in breach of the Clause
8.5 of the Terms of Employment, having tendered his resignation with the Plaintiff on 3.9.2019,
proceeded to join one of the customers of the Plaintiff i.e. M/s Bharti Airtel Ltd., a fact learnt on
12.12.2019, prior to completion of one year as per the requirements of the aforesaid Clause and on
account of he having failed to comply with the mandate of the Non-Disclosure Agreement and
having misused confidential information and data, to which he attained access during his tenure
with the Plaintiff, by passing it off, to utmost loss for and prejudice to the Plaintiff.
19. The Defendant has, on the other hand, questioned the very maintainability of the suit and the
veracity of the claims on CS SCJ 254/20 Cubastion Consulting Pvt Ltd Vs Shubham Saxena Page
no.13 of 27 multifarious grounds. The Defendant claims he had joined the Plaintiff Company as an
Associate Consultant on 3.9.2018, with no fixed period of engagement agreed upon. He further
states that no confidential information or data was either passed onto him, nor was any piece of
information shared by him further in breach of employment terms, refuting the allegations of the
Plaintiff. The Defendant has raised objections over the aforesaid allegations highlighting that they
are not only baseless, but also noticeably couched in absolutely vague terms in the plaint. It is
further asserted in defence that the Clause 8.5 of the General Terms and Conditions and the reliefs
sought on the basis of it, are even otherwise in the teeth of Section 27 of the Indian Contract Act,
1872, rendering them void and non-est as seeking virtually to infringe upon the fundamental rights
of the Defendant.
20. For the sake of ready reference and in order to understand the import of the specific terms of
employment under the 'Cubastion General Service Conditions', made a part and parcel of the
Appointment Letter dated 31.8.2018 issued by the Plaintiff to the Defendant (Mark B Colly) and
under the Employee Confidentiality and Non-Disclosure Agreement (Ex PW1/3), the relevant
service conditions are reproduced hereunder:
CS SCJ 254/20 Cubastion Consulting Pvt Ltd Vs Shubham Saxena Page no.14 of 27
CUBASTION GENERAL SERVICE CONDITIONSCubastion Consulting Pvt Ltd vs Shubham Saxena on 28 March, 2023

7. Confidentiality 7.1 You shall maintain utmost secrecy with regard to confidential
and proprietary information relating to the Company. This information includes and
is not limited to trade secrets technical processes, finances, dealings with information
relating to suppliers, employees, agents, distributors and customers. 7.2 You shall
not, during your employment and at all times thereafter directly or indirectly use or
disclose confidential information except for the sole benefit of the Company. This
restriction shall cease to apply when it may come into the public domain otherwise
than through unauthorized disclosure by you or such information which you shall be
obliged to disclose by law.
7.3 You shall not take copies of confidential documents or information for your own
purposes and forthwith upon termination, you shall return to the Company all
documents records, and accounts in any from (including electronic, mechanical,
photographic, and optic recording) relating to matter concerning the business or
dealings or affairs of the Company. 7.4 You shall not during your employment and at
all times thereafter do or say anything that may injure or directly damage the
business of the Company.
CS SCJ 254/20 Cubastion Consulting Pvt Ltd Vs Shubham Saxena Page no.15 of 27
7.5 You shall maintain utmost confidentiality with regard to your compensation and
benefits. You shall not discuss your compensation and benefits with anyone, but with
the Manager you report to. 7.6 You shall sign a. The proprietary Rights and
Non-Disclosure Agreement.
b. The Code of Business Conduct and Ethics.
c. Prohibition on Disclosure or Use of Inside Information.
d. Default User Rights on Cubastion Network.
8.Separation from the Company 8.1 In the normal course, you will retire from the Company at the
age of 58 years.
8.2 At the time of formally resign from the service of the Company you shall serve the 90 days"
notice period.
8.3 When you formally resign from the service of the Company, the Company may at its discretion,
permit you to. Adjust the vacation accumulated toward part of the notice period pay up for the
notice period in lieu thereof.
8.4 Your service are liable to be terminated immediately without any notice if in the opinion of
company, you are found guilty of breach of any of the above clause, insubordination, insolence,
gross CS SCJ 254/20 Cubastion Consulting Pvt Ltd Vs Shubham Saxena Page no.16 of 27 negligence
of duty, dishonesty or embezzlement or accepting gratification or contravention of integrity policy ofCubastion Consulting Pvt Ltd vs Shubham Saxena on 28 March, 2023

the Company.
8.5 For a period of one year following the termination of your employment, for whatever reason, you
will not directly or indirectly, solicit business from, offer to provide service to, or do business with,
any customer to whom Cubastion has provided services (or made a written proposal to provide
services to).
8.6 On the date of termination of your employment or at any time during the immediately preceding
six- month period you shall not attempt, either directly or indirectly, to induce or influence any
other employee of Cubastion to leave Cubastion employment.
(emphasis supplied) EMPLOYEE CONFIDENTIALITY AND NON-
DISCLOSURE AGREEMENT Confidentiality That during the course of my employment there may
be disclosed to me certain trade secrets of the Company and its clients; said trade secrets consisting
but not necessarily limited to:
I. Technical information: Methods, processes, formulae, compositions, systems,
techniques, inventions, machines, computer programs and research projects.
CS SCJ 254/20 Cubastion Consulting Pvt Ltd Vs Shubham Saxena Page no.17 of 27
II. Business information: Customer lists, pricing data, sources of supply, financial
data and marketing, production, or merchandising systems or plans. That I will hold
this confidential or proprietary information or trade secrets in trust and confidence
and agree that I shall not misuse it for any other purpose, or disclose to any third
party even after discontinuation of my employment with Cubastion. That I shall not
at any time after the discontinuation of my employment with Cubastion, use for
myself of others, or disclose or divulge to others including future employees, any
trade secrets, confidential information, or any other proprietary data of the Company
in violation of this agreement.
Return of Company Material and Intellectual Property That upon the discontinuation
of my employment from the Company:
i. I shall return to the Company all documents and property of the Company,
including but not necessarily limited to: documents, drawing, blueprints, reports,
manuals, correspondence, customer lists, computer programs, and all other materials
and all copies thereof relating in any way to the Company's business, or in any way
obtained by me during the course of employment. I further CS SCJ 254/20 Cubastion
Consulting Pvt Ltd Vs Shubham Saxena Page no.18 of 27 agree that I shall not retain
copies, notes or abstracts of the foregoing.
ii. The Company may notify any future or prospective employer or third party of the
existence of this agreement, and shall be entitled to full injunctive relief for anyCubastion Consulting Pvt Ltd vs Shubham Saxena on 28 March, 2023

breach.
21. The main thrust of the case of the Plaintiff for the reliefs sought is that the
Defendant, after securing a relieving from the Company, opted to join one of its
customers, in breach of the contractual terms of service and confidentiality, indulging
in mal-practices, such as, offering the CRM Tools (developed by the Plaintiff) to
others at lower pricing, misusing access to confidential data, wrongfully retaining
important and confidential files, documents, records of the Plaintiff illegally. Despite
being served with an intimation through email dated 3.1.2020 (Ex PW1/4) and a legal
notice dated 6.1.2020 (Mark C), the Defendant has continued to commit breach of
the terms as aforesaid, occasioning losses to the Plaintiff. The Plaintiff to substantiate
its case against the Defendant has relied upon the Appointment Letter dated
31.8.2018 along with General Service Conditions (Mark B Colly), Email dated
3.9.2019 whereby the Defendant tendered his resignation to the Plaintiff (Ex PW1/2
colly), Email dated 10.10.2019 whereby resignation of the Defendant stood accepted
by the Plaintiff, with 2.12.2019 being conveyed to be the last working day (Ex PW1/12
colly), the Non-Disclosure Agreement dated 2.12.2019 (Ex PW1/3) CS SCJ 254/20
Cubastion Consulting Pvt Ltd Vs Shubham Saxena Page no.19 of 27 executed at the
time of completion of exit/relieving formalities and Notices Ex PW1/4 and Mark C as
aforementioned. The Defendant on the other hand, claiming to have received an
honorable discharge from the employment of the Plaintiff has tendered in evidence
his relieving Certificate (Ex DW1/1) and Letter dated 27.12.2019 (Ex DW1/2),
denying the claims of the Plaintiff.
22. The law on pleadings under the Code of Civil Procedure, 1908, under Order VI Rule 2, 4 CPC
and Order VII Rule 1(e ) CPC, requires the Plaintiff to clearly set out/ make complete disclosure of
all the necessary facts and material particulars, as clearly constituting an identifiable cause of action
for the lis. The purpose of such specific disclosure at the outset was discussed by Hon'ble High Court
of Delhi in Navigators Logistics Ltd. v Kashif Qureshi and Ors. [ CS (COMM). 735/2016 decided on
17.9.2018] wherein it was observed that "the whole purpose of pleadings in a civil suit is to let the
opponent know the case to be met and which crystallizes ultimately in issues on which the parties go
to trial". The Hon'ble High Court went further to discuss that if the said rules were not adhered in
pleadings, it would result in a 'fishing and roving enquiry'. The onus in the present suit, rightly cast
on the Plaintiff, in view of Section 103 of the Indian Evidence Act, to prove the allegations levelled
against the Defendant of committing violation of the restraint clause (i.e. Clause 8.5) and of the
confidentiality terms, by wrongful retention of CS SCJ 254/20 Cubastion Consulting Pvt Ltd Vs
Shubham Saxena Page no.20 of 27 information/ data/ records and passing it off to its customer and
others, required the Plaintiff to clearly spell out the information/ confidential data or trade secrets
that the Plaintiff had developed over time, to which the Defendant had become privy during the
course of his employment. This special knowledge/ access to a specialized technical know-how
concerning CRM Tool, processes, formulae, systems, techniques or protocol or programs was
required to be disclosed and established first, before the Plaintiff could have asserted its case of any
leak/ passing off as alleged.Cubastion Consulting Pvt Ltd vs Shubham Saxena on 28 March, 2023

23. The Plaintiff through the averments in the plaint has claimed that during the tenure of the
Defendant with the Company, he was imparted 'various technical and business knowledge including
but not limited to methods, processes, formulae etc'. during various training sessions held by the
Plaintiff for its employees and that the knowledge so acquired by the Defendant was strictly
proprietary, confidential and a trade secret for the Plaintiff, which he had undertaken not to divulge.
It has been further averred that the Defendant had 'illegally retained' important and confidential
files, documents and records of the Plaintiff Company' and had been offering the development and
management of CRM tools at the same or even lower pricing. The Plaintiff has also pleaded that it
has over time developed and maintained confidential information, data, internal processes,
methods, finances, client budget, pricing structure, etc. claiming exclusivity of access thereto, to CS
SCJ 254/20 Cubastion Consulting Pvt Ltd Vs Shubham Saxena Page no.21 of 27 some of which
data/ knowledge, even the Defendant, as an ex- employee had gained access during his employment.
These averments as in paragraph numbers 4, 5 ,11 and 12 of the plaint, when read conjointly, reveal
that the pleadings are ex-facie vaguely worded, bereft of any specific details of processes, methods,
or knowledge of expertise, which the Defendant was made privy to, during his association and
training under the Plaintiff, which he ought not to have passed on. The pleadings are couched in
absolute vague terms, with there being, conspicuously, no specific averments with respect to any
specific data/ knowledge/ tehnical know-how having been unauthorizedly shared with the customer
of the Plaintiff/ successive employer of the Defendant i.e. M/s Bharti Airtel Pvt. Ltd. or Ors.
24. Even during cross examination of the witness for the Plaintiff (PW1), the deponent could come
up with no specific details of either the training claimed to have been imparted to the Defendant or
the special knowledge derived, as furthered unlawfully, occasioning prejudice to the financial and
commercial interests of the Plaintiff. There is an evasive reference to the Non-Disclosure
Agreement, with no other document shown as filed, to support the claim that the Defendant was
having access to proprietary information such as customer lists, pricing data, source of supply,
compositions, formulae, systems, techniques etc. It is noteworthy, that the witness also failed to
specifically deny the suggestion to the CS SCJ 254/20 Cubastion Consulting Pvt Ltd Vs Shubham
Saxena Page no.22 of 27 effect that the training imparted to the Defendant by the Plaintiff Company
concerned information, which was already available in the public domain.
25. The witness PW1 was specifically asked during his cross examination by the Ld. Counsel for
Defendant as to what information was divulged by the Defendant in the period of December 2019
till 2022, to which the witness responded referring to information concerning pricing, upcoming
projects, Plaintiff's clients and customer lists. He vaguely referred to technical strategies and
technical coding for software development, et al in response. The Plaintiff has failed to discharge its
onus by establishing as to what were the confidential processes/protocols which were shared with
the Defendant concerning software development etc. which were illegally passed on by him to rival
entities/ customer as alleged. The data referred to vaguely in response as noted above does not
qualify to be a 'trade secret' even otherwise. Due to lack of specifics, despite being asked to disclose
the details of the alleged confidential information/ data during cross examination, it is clear, that
the Plaintiff has set out a case, deficient in stipulation of material facts, constituting a valid cause of
action in its favour. In Star India Pvt. Ltd. v Laxmiraj Seetharam Nayak [ 2003 SCC OnLine Bom 27]
, the Hon'ble High Court observed that 'everyone in any employment for some period would knowCubastion Consulting Pvt Ltd vs Shubham Saxena on 28 March, 2023

certain facts and would get to know some information without any special effort; all such persons
cannot CS SCJ 254/20 Cubastion Consulting Pvt Ltd Vs Shubham Saxena Page no.23 of 27 be said
to know trade secrets or confidential information and that every opinion or general knowledge of
facts cannot be labelled as trade secrets or confidential information'. It has been held that 'if such
items are called as trade secrets, or secret, the term would lose its meaning and significance'. The
data alleged to have been illegally withheld and misused herein, also does not qualify to be a
'trade-secret' in the above terms, on which customers/ entities in competition could have encashed/
capitalized upon.
26. As regards the restraining covenant under Clause 8.5 of the Employment terms and the
prohibition thereunder for a period of one year "following the termination" of employment, from
indulging in direct or indirect solicitation of business with any customer of Cubastion, the said term,
although not applicable in the present situation as stemming from a voluntary resignation (duly
accepted), as opposed to termination, is even otherwise violative of Section 27 of the Indian Contract
Act, 1872. A joint reading of the legal precedents in Superintendence Company of India (P) Ltd. v
Krishan Murgai [ MANU / SC/ 0457/1980] and Percept D' Mark (India) P. Ltd. v. Zaheer Khan [
MANU / SC 1412/2006] , reveals the well settled law on the subject, as per which, a restrictive
clause in an employment contract can at best apply in a case where the employment is a for a fixed
period and the same (or the notice period) has not been undergone, as opposed to a situation, where
there has been a proper relieving from CS SCJ 254/20 Cubastion Consulting Pvt Ltd Vs Shubham
Saxena Page no.24 of 27 employment, and the notice period too has expired, as in the present case.
In the present facts and circumstances, the Defendant had never contracted for a fixed tenure
employment with the Plaintiff, and therefore the restriction beyond the notice period, for a year post
relieving from employment, is in direct conflict of the mandate of Section 27 of the Indian Contract
Act, 1872 [reference : Navigators Logistics Ltd. (Supra)]. Needless to say, the Clause 8.5, even
otherwise, on its bare reading, could not have been invoked in the very first place, as restraining the
Defendant's subsequent employment prospects, given the fact, that if read in the ejusdem generis
spirit, in continuation with the previous recital i.e. Clause 8.4 also touching upon 'the eventuality of
termination', the aforesaid Clause 8.5 could at best apply to a case of 'termination' and not
'resignation', notwithstanding it being void as in teeth of Section 27 of the Indian Contract Act, as
above discussed.
27. The Plaintiff has also claimed that the Defendant had illegally retained certain records/
documents/ files concerning software/ tools etc., prone to misuse. There are no specific details
disclosed to substantiate the said allegation in the plaint or the evidence led either. The Certificate
and the Relieving Letter (Ex DW1/1 and Ex DW1/2 respectively) on the other hand suggest, as also
confirmed by PW1, that the Defendant had been given an honorable discharge from employment.
Such certification of effective contribution to the employer, with no CS SCJ 254/20 Cubastion
Consulting Pvt Ltd Vs Shubham Saxena Page no.25 of 27 complaint lodged as brought on record to
suggest illegal retention of records, negates the said claim as well.
28. It is further imperative to note that the Non-Disclosure Agreement (Ex PW1/3) makes a mention
of a possibility of disclosure of trade secrets to an employee, as it makes the use of a word 'may' as
opposed to something that would indicate it to be a norm in practice. The Plaintiff has failed to spellCubastion Consulting Pvt Ltd vs Shubham Saxena on 28 March, 2023

out as to what trade secrets were shared with the Defendant and as to how the Agreement stood
violated by him. The allegations have clearly, for the aforesaid reasons, gone unexplained,
uncorroborated and unsubstantiated. Therefore, no merit is found in the case put forth by the
Plaintiff.
ISSUE-WISE FINDINGS :
29. Accordingly, for the above discussed reasons, following are the issue-wise findings in the lis:
1. Whether the suit of plaintiff is barred by Section 27 of Indian Contract Act? OPD
Finding : This issue for above discussed reasons is decided in favour of the
Defendant, against the Plaintiff.
2. Whether the defendant is having any confidential information of the business of
plaintiff? OPP Finding : This issue for above discussed reasons is decided in favour of
the Defendant, against the Plaintiff as the latter has failed to disclose any such
'confidential information' of the business of the Plaintiff as in possession or
knowledge of the Defendant.
CS SCJ 254/20 Cubastion Consulting Pvt Ltd Vs Shubham Saxena Page no.26 of 27
3. Whether the defendant has ever tried to hand order / transfer such confidential
information pertaining to business of plaintiff to M/s Bharti Airtel Ltd or any other
third party? OPP Finding : This issue is decided against the Plaintiff, in favour of the
Defendant, as the Plaintiff has failed to substantiate and prove the said allegation, for
reasons, as discussed hereinabove.
4. Whether the plaintiff is entitled to decree of permanent injunction as prayed for?
OPP Finding : This issue for aforesaid reasons is decided against the Plaintiff, in
favour of the Defendant.
RELIEF
30. Accordingly, for the above discussed reasons in the facts and circumstances of the case, the suit
of the Plaintiff stands hereby dismissed.
31. Decree sheet be prepared and file be consigned to Record Room as per Rules.
(Pronounced in the open court on 28.03.2023) (Shriya Agrawal) JSCC cum ASCJ cum GJ South
East District/Saket Courts CS SCJ 254/20 Cubastion Consulting Pvt Ltd Vs Shubham Saxena Page
no.27 of 27Cubastion Consulting Pvt Ltd vs Shubham Saxena on 28 March, 2023

