Bombay Industrial Relations Act, 1946
BOMBAY PRESIDENCY
India
Bombay Industrial Relations Act, 1946
Act 11 of 1947
Published on 15 April 1947• 
Not commenced• 
[This is the version of this document from 15 April 1947.]• 
[Note: The original publication document is not available and this content could not be
verified.]• 
Section 6 of Bombay 49 of 1955, reads as follows:"6. Amendment made by sections 3 and 4 to come
into force from the date on which the principal Act came into force. - Notwithstanding anything
contained in any judgement, decree or order of a Court, the amendments made by sections 3 and 4
of this Act shall be deemed to have come into force with effect from the date on which the Bombay
Industrial Relations Act, came into force:Provided that nothing in this section shall render any
person liable to conviction of an offence in respect of any act committed by him before the date of
the coming into force of this Act, if such act was not an offence under the said Act at aforesaid date,
but for the provisions of this section" (Bombay XI of 1947).For Statement of Objects and Reasons,
see Bombay Government Gazette, 1946, Part V. p.209; and for Proceedings in Assembly see Bombay
Legislative Assembly Debates, 1946, Vol. IX; and for Proceedings in Council, see Bombay Legislative
Council Debates, 1946 Vol. XI.Section 6 of Bombay 49 of 1955, reads as follows:"6. Amendment
made by sections 3 and 4 to come into force from the date on which the principal Act came into
force. - Notwithstanding anything contained in any judgement, decree or order of a Court, the
amendments made by sections 3 and 4 of this Act shall be deemed to have come into force with
effect from the date on which the Bombay Industrial Relations Act, came into force:Provided that
nothing in this section shall render any person liable to conviction of an offence in respect of any act
committed by him before the date of the coming into force of this Act, if such act was not an offence
under the said Act at aforesaid date, but for the provisions of this section" (Bombay XI of 1947).The
Bombay Industrial Relations Act, 1946 has been extended to the Saurashtra and Kufch areas of the
State of. Gujarat by Bombay Industrial Relations (Gujarat Extenstion and Amendment) Act, 1961
(Gujarat XX of 1961), s.2. Section 2 of Gujarat XX of 1961 reads as follows, namely:-Extension of
Bombay XI of 1947 to Saurashtra and Kutch areas of State of Gujarat.The Bombay Industrial
Relations Act 1946 (Bombay XI of 1947) as in force in the Bombay area of the State of Gujarat
immediately before the commencement of this Act, is hereby extended to the Saurashtra and Kutch
areas of the State of Gujarat.".Section 3 of Gujarat 18 of 1968, reads as under:"6. Repeal of Gujarat
Ordinance No. 2 of 1968. - The Bombay Industrial Relations (Gujarat Amendment) Ordinance,
1968, is hereby repealed and the provisions of section 7 and 25 of the Bombay General Clauses Act,
1904 (Gujarat Ordinance No. 2 of 1968). Bombay I of 1904) shall apply to such repeals as if the
Ordinance were an enactment.An Act to regulate the relation of employers and employees, to makeBombay Industrial Relations Act, 1946

provision for settlement of industrial disputes and to provide for certain other purposes.Whereas it
is expedient to provide for the regulation of the relations of employers and employees in certain
matters, to consolidate and amend the law relating to the settlement of industrial disputes and to
provide for certain other purposes. It is hereby enacted as follows:-
Chapter I
Preliminary
1. Short title. - This Act may be called the Bombay Industrial Relations Act,
1946.
2. Extent, Commencement and Application. - [(1) This Act extends to the
whole of the State of Gujarat.]
[(2) (a) It shall come into force on such date as the [State] Government may by notification in the
Official Gazette, specify.[(b) in those [areas of the State of Gujarat to which it is extended by the
Bombay Industrial Relations (Gujarat Extension and Amendment) Act, 1961, (Gujarat XX of 1961.)]
it shall come into force on such other date as the State Government may by notification in the
Official Gazette, specify.](3)In the areas in which the Bombay Industrial Disputes Act, 1938,
(Bombay XXX of 1938) was in force immediately before the commencement of this Act, this Act
shall apply to the industries to which the said Act applied :[Provided that this Act shall cease to
apply with effect from the date on which the Bombay Industrial Relations (Amendment) Act, 1949
(Bombay LV of 1949. X of 1949) comes into force to the Imperial Bank of India and any banking
company as defined in section 5 of the Banking Companies Act, 1949 having branches or other
establishments in more than one [State].(4)The [State] Government may by notification in the
Official Gazette apply all or any of the provisions of this Act to all or any other industries, whether
generally or any local area as may be specified in such notification.[(5) The Provisions of this Act
shall not apply to the industry, unit or establishment set up in the special economic zone declared as
such by the Government of India][(6) The State Government may, by notification in the Official
Gazette, direct that the provisions of this Act shall cease to apply to such industry, in such area, and
from such date, as may be specified in the said notification and thereupon the provision of section-7
of the Bombay General Clauses Act, 1940 (Bombay 1 of 1940) Shall apply to such cessor as if this Act
had then been repealed in relation to the said industry in such area by the Gujarat Act]
3. Definitions. - In this Act unless there is anything repugnant in the subject
or context-
(1)"approved list" means the list of approved unions maintained by the Registrar under section
12;(2)"approved union" means a union on the approved list;(3)"arbitration proceeding"
means-(i)any proceeding under this Act before an arbitrator,(ii)any proceeding before a Labour
Court, [a Wage Board] or the Industrial Court in arbitration;(4)"arbitrator" means an arbitrator to
whom a dispute is referred for arbitration under the provisions of this Act and includes anBombay Industrial Relations Act, 1946

umpire;(5)"association of employer" means any combination of employers recognised by the [State]
Government under section 27;(6)"award" means any [interim, final or supplementary]
determination in an arbitration proceeding of any industrial dispute or of any question relating
thereto;(7)"board" means a Board of Conciliation appointed under section 7;(8)"change" means an
alteration in an industrial matter,[(8A) "closure" means the closing of any place or part of a place of
employment or the total or partial suspension of work by an employer or the total or partial refusal
by an employer to continue to employ persons employed by him, whether such closing, suspension
or refusal is or is not in consequence of an industrial dispute;](9)"Commissioner of Labour" means
an officer appointed by the [State] Government for the time being to be the Commissioner of
Labour; and in respect of any of the powers and duties of the Commissioner of Labour that may be
conferred and imposed on any person, includes such person;(10)"conciliation proceeding" means
any proceeding held by a Conciliation or a Board under this Act;(11)"Conciliator" means any
Conciliator appointed under this Act and includes the Chief Conciliator or a Special
Conciliator;[(11A) "Council" means a Joint Management Council for any undertaking constituted
under section 53A];(12)"Court of Enquiry" means a Court constituted under section 100;[(13)
"employee" means any person (including an apprentice) employed in any industry to do any skilled
or unskilled manual, supervisory, technical or clerical work for hire or reward whether the terms of
employment be express or implied, and includes-(a)a person employed in the execution of any work
in respect of which the owner of an undertaking is an employer within the meaning of sub-clause (e)
of clause (14),(b)a person who has been [dismissed, discharged or retrenched from employment or
whose services have been terminated] on account of any dispute relating to a change in respect of
which a notice is given or an application made under section 42 whether before or after [dismissal,
discharge, retrenchment or, as the case may be, termination from employment,]but does not
include-(i)a person who is employed in the police service or as an officer or other employee of a
prison,(ii)a person who being employed primarily in a managerial, administrative or supervisory
capacity draws basic pay (excluding allowances) exceeding [one thousand] rupees per month,
and(iii)irrespective of the pay drawn, any other person or class of persons employed in any capacity
specified in clause (ii) or in a technical capacity which the State Government may, by notification in
the Official Gazette, specify in this behalf;](14)"employer" includes-(a)an association or a group of
employers;(b)any agent of an employer;(c)where an industry is conducted or carried on by a
department of the [State] Government the authority prescribed in that behalf, and where no such
authority has been prescribed, the head of the department;(d)where an industry is conducted or
carried on by or on behalf of a local authority, the chief executive officer of the authority;[(e) where
the owner of any undertaking in the course of or for the purpose of conducting the undertaking
entrusts the execution of the whole or any part of any work which is ordinarily a part of the
undertaking, to any person otherwise than as the servant or agent of the owner, the owner of the
undertaking;](15)"illegal change" means an illegal change within the meaning of sub-section (4) or
(5) of section 46;(16)"Industrial Court" means the Court of Industrial Arbitration constituted under
section 10;(17)"Industrial Dispute" means any dispute or difference between an employer and
employer or between employers and employees or between employees and employees and which is
connected with any industrial matter;(18)"Industrial matter" means any matter relating to
employment, work, wages, hours of work, privileges, rights or duties of employers or employees or
the mode, terms and conditions of employment, and includes-(a)all matters pertaining to the
relationship between employers and employees, or to the dismissal or non-employment of anyBombay Industrial Relations Act, 1946

person.(b)all matters pertaining to the demarcation of function of any employees or classes of
employees;(c)all matters pertaining to any right or claim under or in respect of or concerning a
registered agreement or a submission, settlement or award made under this Act;(d)all questions of
what is fair and right in relation to any industrial matter having regard to the interest of the person
immediately concerned and or the community as a whole;(19)"industry" means-(a)any business,
trade, manufacture or undertaking or calling of employers;(b)any calling service, employment,
handicraft, or industrial occupation or avocation of employees;and includes-(i)agriculture and
agricultural operations;(ii)any branch of an industry or group of industries which the [State]
Government may by notification in the Official Gazette, declare to be an industry for the purpose of
this Act;(20)"Joint Committee" means a Joint Committee constituted under section 48;(21)"Labour
Court" means a Labour Court constituted under section 9;(22)"Labour Officer" means an officer
appointed to perform the duties of a Labour Officer under this Act; and includes in respect of such
powers and duties of the Labour Officer as may be conferred and imposed on him, an Assistant
Labour Officer;(23)"Local Area" means any area [(including the entire State)] notified as a local area
for the purposes of this Act [or for different industries];(24)"lock-out" means the closing of a place
or part of a place of employment or the total or partial suspension of work by an employer or the
total or partial refusal by an employer to continue to employ persons employed by him, where such
closing, suspension, or refusal occurs in consequence of an industrial dispute and is intended for the
purpose of-(a)compelling any of the employees directly affected by such closing, suspension or
refusal or any other employees of his, or(b)aiding any other employer in compelling persons
employed by him, to accept any term or condition of or affecting employment;(25)"member" means
a person who is an ordinary member of a union and who has paid a subscription of not less than
[twenty-five paise] [per calendar month]:Provided that no person shall at any time be deemed to be
member if his subscription is in arrears for a period of three [calendar months] or more next
preceding such time;][Explanation - A subscription for a particular calendar month shall, for the
purposes of this clause, be deemed to be in arrears if such, subscription is not paid by the end of the
calendar month in respect of which it is due;](26)"occupation" means such section of an
undertaking as is recognised under section 11 to be an occupation;(27)"prescribed" means by rules
under this Act;(28)"Primary Union" means a union for the time being registered as a Primary Union
under this Act;(29)"Qualified Union" means a union for the time being registered as a Qualified
Union under this Act;(30)"registered union" means union registered under this Act,(31)"Registrar"
means person for the time being appointed to be the Registrar of Unions under this Act; and
includes [an Additional Registrar, and] in respect of such powers and duties of the Registrar as may
be conferred and imposed on him, an Assistant Registrar of Unions;(32)"representative of
employees" means a representative of employees entitled [to appear or act] as such under section
30;(33)"representative Union" means a union for the time being registered as a representative
Union under this Act;(34)"Schedule" means a schedule appended to this Act;(35)"settlement"
means a settlement arrived at during the course of a conciliation proceeding; [and for the purposes
of section 44B includes a settlement arrived at within two months from the date of the completion
or any conciliation proceeding which has failed;][(35A) "stoppage" means a total or partial cessation
of work by the employee in an industry acting in combination or a concerted refusal or a refusal
under a common undertaking of employees to continue to work or to accept work, where such
cessation or refusal is or not in consequence of an industrial dispute;](36)"strike" means a total or
partial cessation of work by the employees in an industry acting in combination or concerted refusalBombay Industrial Relations Act, 1946

or a refusal under a common undertaking of employees to continue to work or to accept work, where
such cessation or refusal is in consequence of an industrial dispute;(37)"undertaking" means such
concern in any industry as is recognised by the Registrar under section 11;(38)"Union" means a
trade Union of employees which is registered under the Indian Trade Unions Act, 1926; (XVI of
1926.)[(38A) "Wage Board" means a Wage Board constituted under section [86AA];(39)"wages"
means remuneration of all kinds capable of being expressed in terms of money and payable to an
employee in respect of his employment or work done in such employment and includes-(i)any
bonus, allowance (including dearness allowance), reward or additional remuneration;(ii)the value of
any house accommodation, light, water, medical attendance or other amenity or service;(iii)any
contribution by the employer to any pension or provident fund;(iv)any travelling allowance or the
value of any travelling concession;(v)any sum paid or payable to or on behalf of an employee to
defray special expenses entailed on him by the nature of his employment;[(vi) gratuity payable, if
any.]
Chapter II
Authorities to Be Constituted or Appointed Under This Act
4. Commissioner of Labour. - (1) The [State] Government shall, by
notification in the Official Gazette, appoint a person to be Commissioner of
Labour.
(2)The [State] Government may, by general or special order notified' in the Official Gazette, confer
and impose all or any of the powers and duties of the Commissioner of Labour on any person
whether generally or for any local area.
5. Registrar and Assistant Registrar. - (1) The [State] Government shall, by
notification in the Official Gazette appoint a person to be the Registrar of
Unions for the whole [State of Gujarat].
(2)The [State] Government may, by similar notification, appoint a person to be the Assistant
Registrar of Unions for any local area and may, by general or special order, confer on such person all
or any of the powers of the Registrar of Unions under this Act.
6. Conciliators. - (1) The [State] Government shall, appoint a person to be the
Chief Conciliator. His jurisdiction shall extend throughout the [State of
Gujarat],
(2)The [State] Government may, by notification in the Official Gazette, appoint any person to be a
Conciliator for any industry in a local area specified in the notification.(3)The [State] Government
may, by notification in the Official Gazette, appoint any person to be a Special Conciliator for such
local area or for such industrial dispute or class of disputes as may be specified in the notification.Bombay Industrial Relations Act, 1946

7. Board of Conciliation. - (1) When an industrial dispute arises the [State]
Government may, by notification in the Official Gazette constitute a Board of
Conciliation for promoting the settlement of such dispute.
(2)The Board shall consist of a Chairman who shall be an independent person and an even number
of members. Every member shall be either an independent person or a person chosen by the [State]
Government from a panel representing the interests of the employers employees, provided that the
number of persons chosen from panels representing employers and the number chosen from panels
representing employees shall be equal. Such panels shall be constituted in the manner
prescribed.(3)If any vacancy occurs in the office of the Chairman or a member of the Board before
the Board has completed its work, such vacancy shall be filled in the manner prescribed and the
proceedings shall be continued before the Board as so reconstituted from the stage at which they
were when the vacancy occured.Explanation - For the purposes of this section a person shall be
deemed to be an independent person if he is unconnected with the dispute for the settlement of
which the Board is constituted and the industry directly affected by the dispute.
8. Labour Officers and Assistant Labour Officer. - (1) The [State] Government
may, by notification in the Official Gazette, appoint, Labour Officers for any
local area or areas.
(2)The [State] Government may, by similar notification, appoint Assistant Labour Officers, for any
local area or areas, and may by general or special order confer on them all or any of the powers of
the Labour Officer under this Act.
9. Labour Courts. - [(1) The [State] Government shall, by notification in the
Official Gazette constitute one or more Labour Courts having jurisdiction in
such local areas as may be specified in such notification and shall appoint
persons having [the qualifications specified in sub-section (2) to preside over
such Courts]].
[(2) A person shall not be qualified for appointment as the Presiding Officer of a Labour Court
unless, -(a)he has practised as an advocate or a pleader for not less than three years in the High
Court or any court subordinate thereto, or in any Labour Court, Industrial Court or Tribunal
established in the State under this Act or the Industrial Disputes Act, 1947 (XIV of 1947.) or any law
corresponding to any such Act, for the time being in force in the State; or(b)he has regularly
appeared as a member of a trade union for not less than seven years in proceeding before any such
Labour Court, Industrial Court or Tribunal and law in any part of India, or(c)he holds a degree in
law of a University established by law in any part of India and has held an office not lower in rank
than that of a Registrar of a Labour Court or an Industrial Court or of an Assistant Commissioner of
Labour under the State Government, for not less than five years.]Bombay Industrial Relations Act, 1946

10. Industrial Court. - (1) The [State] Government shall constitute a Court of
Industrial Arbitration.
(2)The Industrial Court shall consist of three or more members, one of whom shall be its
President.(3)Every member of the Industrial Court shall be a person [who is not connected with the
Industrial dispute referred to such court or with any industry directly affected by such
dispute:Provided that no person shall be deemed to be connected with the industrial dispute or with
the industry by reason only of the fact that he is share-holder of an incorporated company which is
connected with, or likely to be affected by such industrial dispute; but in such a case, he shall
disclose to the State Government the nature and extent of the shares held by him in such
company].(4)Every member of the Industrial Court shall be a person who is or has been a judge of a
High Court or is eligible for being appointed a judge of such Court [or has Presided over a Labour
Court for not less than ten years]:Provided that one member may be a person not so eligible if in the
opinion of the [State] Government he possesses expert knowledge of industrial matters:[Provided
further that a member, who before his appointment as such member has presided over a Labour
Court for not less than ten years shall notwithstanding anything contained in section 92, be eligible
for appointment on a Bench of the Industrial Court consisting only of one member and section 92
shall have effect accordingly],
Chapter III
.
Registration of Union section
11. Recognition of undertakings and occupations. - The Registrar may after
making such inquiry as he deems fit, recognise for the purposes of this Act-
(1)any concern in an industry to be an undertaking;(2)any section of an undertaking to be an
occupation.
12. Maintenance of registers and approved list. - It shall be duty of the
Registrar to maintain in such forms as may be prescribe
(a)registers of unions registered by him under the provisions of this Act, and(b)a list of approved
unions.
13. Application for registration. - (1) Any union which has for the whole of the
period of [three calendar months immediately preceding the calendar month
in which it so applies] under this section a membership of [not less than
twenty-five percent] of the total number of employees employed in any
industry in any local area may apply in the prescribed form to the RegistrarBombay Industrial Relations Act, 1946

for registration as a Representative Union for such industry in such local
area.
(2)If in any local area no Representative Union has been registered in respect of an industry a Union
which has for the whole of the period of [three calender months immediately preceding the calender
month in which it so applies] under this section a membership of not less than five percent of the
total number of employees employed in such industry in the said area may apply in the prescribed
form to the Registrar for registration as a Qualified Union for such industry in such local area.(3)If
in any local area, neither a Representative Union nor a Qualified Union has been registered in
respect of an industry a union having a membership of not less than fifteen percent, of the total
number of employees employed in any undertaking in such industry in the said area and complying
with the conditions specified in section 23 as necessary for its being placed on the approval list may
apply in the prescribed form to the Registrar for registration as a Primary Union for such industry in
such local area.[(4) Notwithstanding anything contained in this section, if a union makes a fresh
application for registration as a Representative Union, Qualified Union, or as the case may be,
Primary Union, the Registrar shall not entertain such application unless a period of one year has
elapsed since the date of disposal by the registrar of the previous application of that union for such
registration.]
14. Registration of union. - On receipt of an application from a union for
registration under section 13 and on payment of the fee prescribed, the
Registrar, shall, if after holding such inquiry as he deems fit he comes to the
conclusion that the conditions requisite for registration specified in the said
section are satisfied and that the union is not otherwise disqualified for
registration, enter the name of the union in the appropriate register
maintained under section 12 and issue a certificate of registration in such
form as may be prescribed:
Provided -Firstly, that in any local area there shall not at any time be more than one registered
union in respect of the same industry:Secondly, that in any local area the Registrar shall in respect
of an industry register a union fulfilling the conditions necessary for registration as a representative
Union in preference to one not fulfilling the said conditions and failing such a union, a union
fulfilling the conditions necessary for registration as a Qualified Union in preference to one not
fulfilling such conditions:[Thirdly, that -(i)where two or more unions fulfilling the conditions
necessary for registration apply in the same calendar month for registration in respect of the same
industry, in any local area, subject to the provisions of the second proviso, the union having the
largest membership of employees employed in the industry during the whole of the period of three
calendar months immediately preceding that in which the applications were made shall be
registered, and any application made in any subsequent calendar months shall not be considered by
the Registrar until the applications made in the earlier calendar month are dispose of by
him;(ii)where a union fulfulling the conditions necessary for registration makes an application
during any calendar month for registration in respect of an industry in any local area anyBombay Industrial Relations Act, 1946

application in any subsequent calendar month by any other union for registration in respect of the
same industry shall not be considered by the Registrar until the former application is disposed of by
him];Fourthly, that the Registrar shall not register any union if he is satisfied that the application
for its registration is not made bona-fide in the interest of the employees but is made in the interest
of the employers to the prejudice of the interest of the employees;[Fifthly, that the Registrar shall
not register any union if at any time, within six months immediately preceding the date of the
application for registration or thereafter the union has instigated, aided or assisted the
commencement or continuation of a strike or stoppage which has been held or declared to be
illegal;Sixthly, that the Registrar shall not register any union, if the rules of the union relating to its
members contain any provision debarring an employee in the industry concerned from being a
member of such union on the ground that he is or is not an employee in any particular undertaking
in the said industry.]
15. Cancellation of registration. - The Registrar shall cancel the registration
of a union-
(a)if the Industrial Court directs that the registration of such union shall be cancelled;(b)if [after
giving notice to such union to show cause why its registration should not be cancelled and] after
holding such inquiry, if any, as he deems fit, he is satisfied.(i)that it was registered under mistake,
misrepresentation or fraud; or(ii)that the membership, of the union has for a continuous period of
three [calendar months] fallen below the minimum required under section 13 of its
registration:Provided that where a strike or a closure not being an illegal strike or closure under this
Act in an industry involving more than a third of the employees in the industry in the area has
extended to a period to a period exceeding fourteen days in any calendar month, such month shall
be excluded in computing the said period of three months:Provided further that the registration of a
union shall not be cancelled under the provisions of this sub-clause unless its membership [for the
calendar month in which show cause notice under this section was issued was] less than such
minimum; or(iii)that the registered union being a Primary Union has after registration failed to
observe any of the conditions specified in section 23; or(iv)that the registered union is not being
conducted bona-fide in the interests of employees but in the interests of employers to the prejudice
of the interest of employers; or(v)that has instigated, aided or assisted the commencement or
continuation of [a strike or a stoppage which has been held or declared to be illegal];(c)if its
registration under the Indian Trade Union Act 1926, (XVI of 1926.) is cancelled.
16. Registration of another union in place of existing registered union. - (1) If
at any time any union (hereinafter in this section referred to as "application
union") makes an application to the Registrar for being registered in place of
the union already registered (hereinafter in this section referred to as
"registered union") for an industry, in a local area, on the ground that it has a
larger membership of employees employed in such industry the Registered
shall [if a period of two years has elapsed since the date of registration of the
Registered union,] call upon the registered union by a notice in writing toBombay Industrial Relations Act, 1946

show cause within [thirty days] of the receipt of such notice why the
applicant union should not be registered in its place. An application made
under this sub-section shall be accompanied by such fee as may be
prescribed:
[Provided that the Registrar shall not entertain any application for registration of a union, unless a
period of one year has elapsed since the date of disposal of the previous application of the
union](2)The Registrar shall forward to the Labour Officer a copy of the said application and
notice.(3)if, on the expiry of the period of notice under sub-section (1), after holding such inquiry as
he deems fit, the Registrar, comes to the conclusion that the applicant union complies with the
conditions necessary for the registration specified in section 13, and that its membership was during
the whole of the period of [three calendar months immediately preceding the calendar month in
which it made the application] under this section larger than the membership of the registered
union, he shall, subject to the provisions of section 14 register the applicant union in place of the
registered union [and issue certificate of registration in such form as may be prescribed].(4)Every
application made under this section shall be published in the prescribed manner not less than 14
days before the expiry of the period of notice under sub-section (1).
17. Application for registration. -(1) Any union the registration of which has
been cancelled on the ground that it was registered under a mistake or on
the ground specified in sub-clause (ii) of clause (b) of section 15 may, at any
time after three months from the date of such cancellation and on payment of
such fees as may be prescribed, apply for reregistration. The provisions of
sections 13 and 14 shall apply in respect of such application.
(2)A union the registration of which has been cancelled on any other ground shall not, save with the
permission of the [State] Government, be entitled to apply for reregistration.
18. Liability of union or members not relieved by Cancellation. -
Notwithstanding anything contained in any law for the time being in force,
the cancellation of the registration of a union shall not relieve the union or
any member thereof from any penalty or liability' incurred under this Act
prior to such cancellation.
19. Periodical returns to be submitted to registrar. - Every registered union
shall submit to the Registrar on such dates and in such manner as may be
prescribed, periodical returns of its membership.Bombay Industrial Relations Act, 1946

20. Appeal to Industrial Court from order of Registration. - [****] (1) any party
to a proceeding before the Registrar may, within 30 days from the date of an
order passed by the Registrar under this Chapter, appeal against such order
to the Industrial Court :
Provided that the Industrial Court may for sufficient reason admit any appeal made after the expiry
of such period.(2)The Industrial Court may admit an appeal under sub-section (1) if on a perusal of
the memorandum of appeal and the decision appealed against it finds that the decision is contrary
to law or otherwise erroneous.(3)The Industrial Court in appeal may confirm, modify or rescind any
other passed by the Registrar and may pass such consequential orders as it may deem fit. A copy of
the orders passed by the Industrial Court shall be sent to the Registrar.
21. Publication of order. - Every order passed under section 14, 15 or 16 and
every order passed in appeal under section 20 shall be published in the
prescribed manner
22. Registration of union for more than one local area. - Subject to the
foregoing provisions of this Chapter, a union may in the prescribed manner
be registered for an industry for more local areas than one.
Chapter IV
.
Approved Union section
23. Approved list Maintenance of conditions for being entered in. -(1) On an
application being made in the prescribed form, by a union for being entered
in the approved list, the Registrar may after holding such inquiry as he
deems fit enter the union in such list if he is satisfied that the union has
made rules that the provisions of the said rules are being duly observed by
the unions, and that the rules provide, tha. -
(i)its membership subscription shall be not less than [fifty paise] per month;(ii)its executive
committee shall meet at intervals of not more than three months;(iii)all resolutions passed, whether
by the executive committee or the general body of the union, shall be recorded in a minute book kept
for the purpose;(iv)an auditor appointed by Government may audit its accounts at least once in each
financial year;[(v) every industrial dispute in which an agreement or settlement is not reached shall
be offered to be submitted to arbitration or for decision to a wage Board as may be mutually agreed
upon and that if any time an employer agrees to refer all disputes, as then existing and to which the
union is a party to arbitration of the Industrial Court under Chapter XI, such arbitration shall not beBombay Industrial Relations Act, 1946

refused by it;](vi)no strike shall be sanctioned or resorted to by it unless all the methods provided by
or under this Act for the settlement of an industrial dispute have been exhausted and the majority of
its members vote by ballot in favour of such strike;[***]Provided that the Registrar shall not enter a
union in the approved list if he is satisfied that it is not being conducted bona-fide in the interest of
its members, but to their prejudice.Explanation - "Member" for the purposes of clause (vi) means a
member of the union for the purpose of the Indian Trade Unions Act, 1926. (XVI of 1926.)(2)The
[State] Government may by notification in the Official Gazette direct that in the case of any union or
class of unions specified in the notification the membership subscription may, subject to a minimum
of [twenty-five paise] per month, be less than [fifty-paise],(3)Notwithstanding anything contained in
sub-section (1) there shall not at any time be more than one approved union in respect of any
industry in a local area:[Provided that, where two or more unions satisfying the conditions
necessary for being entered in the approved list under sub-section (1) apply in the same calendar
month for being so entered in respect of the same industry in any local area, union having the
largest membership of employees employed in the industry during the calendar month immediately
preceding that in which the applications were made shall be entered in the approved list and any
applications were made in subsequent calendar months shall not be considered by the Registrar
until the applications made in the earlier calendar months are disposed of by him:Provided further
that where a union satisfying the condition necessary for being entered in the approved list applies
in any calendar month for being so entered in respect of an industry in any local area, any
application in any subsequent calendar month by any other union for being so entered in respect of
the same industry shall not be considered by the Registrar until the former application is disposed of
by him.](4)Any union complying with the conditions specified in sub-section (1) and having a larger
membership in an industry in a local area than an approved union for such industry [in that local
area] shall on application in that behalf be entered in the approved list in place of such approved
union [by the Registrar after holding such inquiry as he deems fit] [if he is satisfied that the
membership of the applicant union had in the calendar month in which the application was made as
also in the calendar month immediately preceding it was respectively larger than the membership of
the approved unions is those months. The provisions of sub-section (3) shall mutatis mutandis
apply to such application]:[Provided that the Registrar shall not entertain-(a)any such application
unless a period of two years has elapsed since the approved union was entered in the approved
list;(b)any fresh application by the same union, unless a period of one year has elapsed from the
date of disposal of its previous application by the Registrar.][23A. Approved union to continue to be
so for altered local area for some time. - Notwithstanding anything contained in section 23, if there
is any alteration in the local area or areas,-(a)an approved union in an industry in the altered local
area or areas, or(b)where two or more approved unions exist in an industry in the altered local area
or areas the union having the largest membership, whether by agreement of the other approved
union or as determined by the Registrar after such inquiry as he deems fit,[shall continue to have all
the rights and privileges of an approved union in respect of its members] for the altered local area or
areas, as the case may be for a period of twelve months from the date on which such alteration is
effected, or where such approved union or any other union in the altered local area or areas makes
an application under section 23 within such period until the disposal of such application by the
Registrar.]Bombay Industrial Relations Act, 1946

24. Removal from approved list. - The Registrar shall remove a union from
the approved list if its registration under the Indian Trade Union Act, 1926, is
cancelled, and may also so remove a union if after holding such inquiry if
any as he deems fit, he is satisfied that it
(i)was entered in the list under mistake, misrepresentation or fraud, or (XVI of 1926.)(ii)has, since
being included in the approved list, failed to observe the conditions specified in section 23, [or][(ii)
as instigated, added or assisted the commencement or continuance of a strike or a stoppage which
has been held or declared to be illegal],
24A. Appeal to Industrial Court from order of Registrar. - [(1) Any party to a
proceeding before the Registrar, may, within 30 days from the date of an
order passed by the Registrar under this Chapter, appeal against such order
to the Industrial Court:
Provided that, the Industrial Court may for sufficient reason admit any appeal made after the expiry
of such period.(2)The provisions of sub-sections (2) and (3) of section 20 shall apply mutatis
mutandis to an appeal under this section.]
25. Rights of Officers of approved union. - [Such officers, [members of the
office staff] and members of a an approved union as may be authorised by or
under rules made in this behalf by the [State] Government shall, in such
manner and subject to such conditions as may be prescribed, have a right,
and shall be permitted by the employer concerned-
(a)to collect sums payable by members to the union on the premises where wages are paid to
them;(b)to put up or cause to be put up a notice board on the premises of the undertaking in which
its members are employed and affix or cause to be affixed notices thereon;(c)for the purpose of the
prevention or settlement of an industrial dispute-(i)to hold discussions of the premises on the
undertaking with the employees concerned who are the members of the union;(ii)to meet and
discuss with an employer or any person appointed by him for the purpose the grievances of its
members employed in his undertaking;(iii)to inspect, if necessary, in any undertaking any place
where any member of the union is employed;[(d) to remain present during a departmental enquiry
against an employee who is a member of that union.]
26. Legal aid to approved unions at Government expenses in important
proceedings. - (1) An approved union entitled to appear-
(a)before a Labour Court in a proceeding for determining whether a strike, lockout [closure,
stoppage] or change is illegal, or(b)before the industrial Court in a proceeding involving in the
opinion of the Court an important question of law or fact, may apply to the Court for the grant ofBombay Industrial Relations Act, 1946

legal aid at the expense of the [State] Government.(2)A copy of every application made under
sub-section (1) shall be sent to the Registrar with the least practicable delay.(3)The Court to which
an application is made under sub-section (1) may fix for the hearing of the application a day of
which at least three day's clear notice shall be given to the Registrar.(4)On the day fixed, or as soon,
thereafter as may be convenient, the Court shall examine the witnesses, if any, produced by the
union and the Registrar, and may also examine the officers of the union, and shall make a
memorandum of the substance of such evidence.(5)The Court may after considering the evidence
adduced under sub-section (4) either grant or refuse the application.(6)The [State] Government
may in consultation with Industrial Court prescribe the fees for legal advice to, and appear on behalf
of a union before a Court.(7)For the purpose of this section, legal aid includes advice to the union
and the appearance before a Court of a legal practitioner on behalf of the union.
Chapter V
Representative of Employers and Employees, and Appearance on Their Behalf
27. Recognition of combination of employers as association of employers. -
(1) The [State] Government may from time to time by notification in the
Official Gazette-
(a)recognise any combination of employers in an industry [in any local area] whether incorporated
or not as an association of employers for the purposes of this Act, provided that one of the objects of
such combination is the regulation of conditions of employment in the industry [in that local
area];(b)withdraw any recognition granted under clause(a) :Provided that no recognition shall be
withdrawn unless an opportunity has been given to such association of employers to be heard.(2)In
any proceeding under this Act an association of employers shall be entitled to represent-(a)any
employer who is a member of the association;(b)any employer connected with the same industry not
being a member of the association, who has intimated in writing to the prescribed authority that he
has agreed to be represented by the association in such proceeding;and any notice or intimation
given by or to such association shall be deemed to have been given by or to everyone it is entitled to
represent.(3)Where more employers than one are affected or under any of the provisions of this Act
deemed to be affected and no association of employers is under sub-section (2) entitled to represent
all of them, the representative determined in the prescribed manner shall be entitled to act as their
representative.[(4) Where in any proceeding under this Act, an employer is represented by an
association of employers, a registered agreement, settlement, submission or award to which such
association is a party, shall be binding on such employer.(5)Where in pursuance of the provisions of
sub-section (2) an association of employers represents any employers in any proceeding under this
Act, it shall, at the earliest stage of the proceedings, furnish to the authority before whom it is held a
list containing the names of the employers whom it represents.]Bombay Industrial Relations Act, 1946

27A. Appearance on behalf of employees. - [Save as provided in [sections 32,
33 and 33A] no employee shall be allowed to appear or act in any proceeding
under this Act except through the representative of employees.]
27B. Continuance of recognition of association of employers for altered local
area. - [Notwithstanding anything contained in this Act, on any alteration in
any local area or areas any association of employers, recognised under
sub-section (1) of section 27 for the local area or areas immediately before
such alteration, shall be entitled to represent the employers in accordance
with the provisions of sub-section (2) of that section in the altered local area
or areas, as the case may be, for a period of twelve months from the date on
which such alteration is effected.]
28. Election of representatives of employees. - (1) Where there is no
Representative Union is respect of any industry in any local area, the
employees in each undertaking in the industry and in each occupation
therein, in the prescribed manner, elect five persons from among themselves
to represent them for the purposes of this Act:
Provided that no such persons shall be elected for any occupation the number of employees in which
does not exceed ten.(2)The persons, if any, elected under sub-section (1) shall function in such
manner as may be prescribed.(3)Within [two years] from the date on which an election under
sub-section (1) is held, and within each succeeding [two years] thereafter, a fresh election shall be
held:Provided that any person may be re-elected at any such election.(4)The employees may in the
prescribed manner recall any or all of the persons elected under sub-section (1) or (3).(5)Vacancies
in the number of the persons elected under sub-section (1) or (3) shall be filled by election in the
prescribed manner.
29. Act or decision of majority to be deemed to be act or decision of all. - Any
act or decision of the majority of the persons elected under section 28 by any
employees shall be deemed to be the act or decisions of all the persons so
elected by them.
30. Representative of employees. - [Subject to the provisions of section 33A,
the following shall be entitled to appear or act] in the order of preference
specified as the representative of employees in an industry in any local area-
(i)a Representative Union for such industry;(ii)Qualified or Primary Union of which the majority of
employees directly affecting the change concerned are members;(iii)any Qualified or Primary Union
in respect of such industry authorised in the prescribed manner in that behalf by the employeesBombay Industrial Relations Act, 1946

concerned;(iv)the Labour Officer if authorised by the employees concerned;(v)the persons elected
by the employees in accordance with provisions of section 28 or where the proviso to sub-section (1)
thereof applies, the employees themselves;(vi)the Labour Officer:Provided -Firstly, that persons
entitled [to appear or act] under clause (v) may authorise any Qualified or Primary Union in respect
of such industry [to appear or act] instead of them;Secondly, that were the Labour officer is the
representative of the employees, he shall not enter into any agreement under section 44 or
settlement under section 58 unless the terms of such agreement or settlement, as the case may be,
are accepted by them in the prescribed manner;Thirdly, that in any proceeding the person entitled
[to appear or act] under clause (v) are more than five, the prescribed number elected from amongst
them in the prescribed manner shall be entitled [to appear or act] instead.
31. Registered or representative union to continue to be so for altered local
area for some time. - [Notwithstanding anything contained in this Act, if there
is any alteration in any local area or areas notified for the purposes of this
Act,-
(a)a registered or representative union entitled under this Act to appear or act as a representative of
employees in an industry immediately before the alteration in the local area or areas concerned,
or(b)where more than one registered or representative union are entitled to appear or act as
representative of employees in an industry under this section the union having the largest
membership of employees employed in the industry, whether by agreement of the other registered
or representative unions or as determined by the Registrar after such inquiry as he thinks fit, shall
be entitled to appear or act for the altered local area or area as the case may be, for a period of twelve
months from the date on which such alteration is effected, or if an application under section 13 is
made within such period by such union or any other union in the altered local area or areas until the
disposal of such application by the Registrar.]
32. Persons who may appear in Proceedings. - [A Conciliator, a Board, an
Arbitrator, a Wage Board, a Labour Court and the Industrial Court may, if he
or it considers it expedient for the ends of justice, permit an individual,
whether an employee or not, to appear in any proceeding before him or it:
[Provided that subject to the provisions of section 33A] no such individual shall be permitted to
appear in any proceeding [(not being a proceeding before a Labour Court or the Industrial Court in
which the legality or propriety of an order of dismissal, discharge, removal)], retrenchment,
termination of service or suspension of an employee is under consideration in which a
Representative Union has appeared as the representative of employees.]
33. Appearance for employees. - Notwithstanding anything contained in any
other provision of this Act, an employee [or a representative union] shall be
entitled to appear through any person,Bombay Industrial Relations Act, 1946

(a)in all proceeding before the Industrial Court;[(aa) in all proceeding before a Wage Board;](b)in
proceedings before a Labour Court for deciding whether a strike, lockout, [closure or stoppage] or
change or an order passed by an employer under the standing orders is illegal] [* ****];(c)in such
other proceedings as the Industrial Court may, on application made in that behalf, permit:Provided
that a legal practitioner shall not be permitted under clause (c) to appear in any proceeding under
this Act, except before a Labour Court [as provided in section 83A] or the Industrial
Court:[[Provided further that, subject to the provisions of section 33A] no employee shall be entitled
to appear through any person in any proceeding under this Act [(not being a proceeding before a
Labour Court or the Industrial Court in which the legality or propriety of an order of dismissal,
discharge, removal, retrenchment, termination of service or suspension of an employee is under
consideration] under this Act in which a Representative Union has appeared as the representative of
employee].
33A. Persons who may appear in proceeding in which there is dispute
between employees and employees. - [(1) In any dispute between the
employees and employees referred to arbitration of a Labour Court or the
Industrial Court under section 72, all persons, who are parties to the dispute,
shall be entitled to appear and act in the proceedings before such Court :
Provided that where the number of employees on either side exceeds five, then such employees shall
elect in the manner prescribed, two persons from amongst themselves to appear and act for
them.(2)If a Representative Union desires to be heard in respect of such dispute it may, on
application made to the Court also be heard by such Court.]
Chapter VI
Powers and Duties of Labour Officers
34. Powers and duties of Labour Officer. - (1) A Labour Officer shall exercise
the powers conferred, and perform the duties imposed on him by or under
this Act.
(2)For the purpose of exercising such power and performing such duties a Labour Officer may,
subject to such conditions as may be prescribed, at any time during the working hours and outside
working hours after reasonable notice enter and inspect-(a)any place used for the purpose of any
industry;(b)any place used as the office of any union;(c)any premises provided an employer for the
residence of his employees, and shall be entitled to call for and inspect all relevant documents which
he may deem necessary for the due discharge of his duties and powers under this Act.(3)All
particulars contained in or information obtained from any document inspected or called for under
sub-section (2) shall, if the person in whose possession the document was so required, be treated as
confidential.(4)A Labour Officer may, after giving reasonable notice, convene a meeting of
employees for any of the purposes of this Act, on the premises where they are employed and mayBombay Industrial Relations Act, 1946

require the employer to affix a written notice of the meeting at such conspicuous place in such
premises as he may order and may also himself affix or cause to be affixed such notice. The notice
shall specify the date, time and place of the meeting, the employees or class of employees affected
and the purpose for which the meeting is convened:Provided that during the continuance of a
lock-out which is not illegal, no meeting of employees affected thereby shall be convened on such
premises without the employer's consent.(5)A Labour Officer shall be entitled to appear in any
proceeding under this Act,(6)It shall be the duty of the Labour Officer to-(a)watch the interests of
employees and promote harmonious relations between employers and employees;(b)investigate the
grievances of employees and represent to employers such grievances and make recommendations to
them in consultation with the employees concerned for their redress;(c)report to the [State]
Government the existence of any industrial dispute of which no notice of change has been given,
together with the names of the parties thereto:Provided that the Labour Officer shall not-(a)appear
in any proceeding in which the employees who are parties thereto are represented by a
Representative Union,(b)where there in [an approved union] for an industry in a local area, [except
after consultation with such union], act under clause (b) of subsection (6) in respect of the
employees.
Chapter VII
Standing Orders
35. Settlement of Standing Orders by Commissioner of Labour. - (1) Within
six weeks from the date of the application of this Act to an industry every
employer therein shall submit for approval to the Commissioner of Labour in
the prescribed manner draft standing orders regulating relations between
him and his employees with regard to the industrial matters mentioned in
Schedule I:
Provided that where an undertaking in an industry is started after the application of this Act to such
industry, the draft standing orders shall be submitted within six months of the starting of the
undertaking.(2)On receipt of the draft standing orders the Commissioner of Labour, shall, after
consulting in the prescribed manner the representative of employees and employers and such other
interests concerned in the industry and making such inquiry as he deems fit, settle the said standing
orders.(3)The Commissioner of Labour shall forward a copy of the standing orders so settled to the
registrar, who shall within fifteen days of their receipt record them in the register kept for the
purpose.(4)Standing orders so settled shall come into operation from the date of their record in the
register under sub-section (3).(5)Until standing orders in respect of an undertaking come into
operation under the provisions of sub-section (4), model standing orders, if any, notified in the
Official Gazette by the [State] Government in respect of the industry shall apply to such
undertaking.Bombay Industrial Relations Act, 1946

36. Appeal to Industrial Court. - (1) Any person aggrieved by any standing
Orders settled by the Commissioner of Labour under sub-section (2) of
section 35 may within thirty days from the date of their coming into operation
appeal to the Industrial Court.
Provided that the Industrial Court may for sufficient cause, admit any appeal after the expiry of the
period of thirty days.(2)On an appeal being filed, the Industrial Court may on the application of any
party to such appeal and on such conditions as it may think fit stay the operation of all or any of
such standing orders until the appeal is decided.(3)The Industrial Court in appeal may confirm,
modify, add to or rescind all or any of such standing orders.(4)The Industrial Court shall fix the date
on which all or any of the standing orders settled by it under sub-section (3) shall come into
operation.(5)A Copy of the orders passed by the Industrial Court under sub-section (3) shall be sent
to the Registrar who shall record them in the register referred to in sub-section (3) of section 35.
37. Review. - (1) Any person aggrieved by a decision of the Industrial Court
under section 36 may within thirty days from the date of the decision apply to
the Industrial Court for a view of the said decision.
[Provided that the Industrial Court may for sufficient cause admit any such application after the
expiry of the said period of thirty days.](2)The Industrial Court shall not grant such application
unless it is satisfied that there has been a discovery of new and important matter or evidence which
after the exercise of due diligence was not within the knowledge of the party making the application
or could not be produced by him at the time when decision was made, or that there has been some
mistake or error apparent on the face of the record or that there is any other sufficient reason for
granting such application.(3)The provisions of sub-sections (2), (3), (4) and (5) of section 36 shall,
so far as may be, apply to proceedings under sub-section (1) in the same manner as they apply to an
appeal against standing orders settled by the Commissioner of Labour under sub-section (2) of
section 35.
38. No alteration in Standing Orders for one year. - (1) No alteration shall be
made for a period of one year from the date of its coming into operation in
any standing order settled under any of the foregoing provisions of its
Chapter except by the Industrial Court in appeal or review, where such
appeal or review lies.
(2)Any employer or employee may apply to the Commissioner of Labour for a change in-(a)any
standing order settled under sub-section (2) of section 35, which has not been appealed against,
or(b)any standing order settled in appeal under sub-section (3) of section 36, in respect of which no
application for review has been made, or(c)any standing order settled in review under section
37,after the expiry of one year from the date of such standing order coming into operation.Bombay Industrial Relations Act, 1946

39. Alteration in Standing Orders. - (1) On receipt of an application under
subsection (2) of section 38 the Commissioner of Labour shall, after giving
the other party an opportunity of being heard and after consulting such other
interests in the industry as his opinion are affected, pass such order as he
deems fit, and, if the order effects an alteration in any standing order,
forward a copy of the standing order as so altered an alteration in any
standing order, forward a copy of the standing order as so altered to the
Registrar who shall, within fifteen days of its receipt record it in the register
referred to in sub-section (3) of section 35. The standing order as so altered
shall come into operation from the date of its record in the register.
(2)The provisions of sections 36, 37 and 38 shall, so far as may be, apply to an order passed by the
Commissioner of Labour under sub-section (1) in the same manner as they apply to standing orders
settled under sub-section (2) of section 35.
40. Standing Orders to be determinative. - (1) Standing orders in respect of
an employer and his employees settled under this Chapter and in operation,
or where there are no such standing orders, modal standing orders, if any,
applicable under the provisions of sub-section (5) of section 35 shall be
determinative of the relations between the employer and his employees in
regard to all industrial matters specified in Schedule I.
(2)Notwithstanding anything contained in sub-section (1) the [State], Government may refer, or an
employee [or a representative union] may apply in respect of any dispute of the nature referred to in
clause (a) of paragraph A of section 78, to a Labour Court.
41. Act XX of 1946 not to apply to certain industries. - The provisions of the
Industrial Employment (Standing Orders) Act, 1946, (XX of 1946.) shall not
apply to any industry to which the provisions of this Chapter are applied.
Chapter VIII
Changes
42. Notice of change. - (1) Any employer intending to effect any change in
respect of a industrial matter specified in Schedule II shall give notice of
such intention in the prescribed form to the representative of employees. He
shall send a copy of such notice to the Chief Conciliator, the Conciliator for
the industry concerned for the local area, the registrar, the Labour OfficerBombay Industrial Relations Act, 1946

and such other person as may be prescribed. He shall also affix a copy of
such notice at a conspicuous place on the premises where the employees
affected by the change are employed for work and at such other place as
may be directed by the Chief Conciliator in any particular case.
(2)An employee desiring a change in respect of an industrial matter not specified in Schedule I or III
shall give notice in the prescribed form to the employer through the representative of employees,
who shall forward a copy of the notice to the Chief Conciliator, the Conciliator for the industry
concerned for the local area, the Registrar, the Labour Officer and such other person as may be
prescribed.(3)When no settlement is arrived at in any conciliation proceeding in regard to any
industrial dispute which has arisen in consequence of a notice relating to any change given under
sub-section (1) or sub-section (2), no fresh notice with regard to the same change or a change similar
in all material particulars shall be given before the expiry of two months from the date of the
completion of the proceeding within the meaning of section 63. If at any time after the expiry of the
said period of two months, any employer or employee again desires the same change or a change
similar in all material particulars, he shall give fresh notice in the manner provided in sub-section
(1) or (2) as the case may be.(4)Any employee [or a representative union] desiring a change in
respect of (i) any order passed by [the] employer under standing orders, or (ii) any industrial matter
arising out of the application or interpretation of standing orders, or (iii) an industrial matter
specified in Schedule III, shall make an application to the Labour Court:Provided that no such
application shall lie unless the employee [or a representative union] has in the prescribed manner
approached [the] employer with a request for the change and no agreement has been arrived in
respect of the change within the prescribed period.
43. Notice of change when to be deemed general notice. - [(1) Where an
employer gives notice of a proposed change under sub-section (1) of section
42 affecting some of the employees in an industry in a local area, any other
employer or an association of employers or the representative of any
employees engaged in the industry in the local area may, within seven days
from the date of service of such notice, intimate in writing to such employer
that other employers, or as the case may be, other employees, engaged in
the industry in the area and mentioned in such intimation are affected by the
change. The employer or employees concerned shall affix a copy of such
intimation at a conspicuous place on every premises where the employees
concerned are employed for work.
(2)Where an employee gives notice of a proposed change under sub-section (2) of section 42
affecting one or some or the employers in an industry in a local area the representative of employees
or any employer or an association of employers engaged in the industry in the local area may, within
seven days from the date of service of such notice, give a special notice in writing to the employee
and his employer, or as the case may be, the representative of employees, that other employees or asBombay Industrial Relations Act, 1946

the case may be, other employers, engaged in the industry in the area and mentioned in such special
notice, are affected by the change. The employer or employees concerned shall affix a copy of such
special notice at a conspicuous place on every premises where the employees concerned are
employed for work],(3)A copy of every intimation under sub-section (1) and special notice under
subsection (2) shall be sent to the Commissioner of labour, the Chief Conciliator, the Conciliator for
the industry concerned for the local area, the Registrar, the Labour Officer and such other person as
may be prescribed.(4)On an intimation being given under sub-section (1) or special notice being
given under sub-section (2) and the provisions of sub-section (3) being complied with, the
employees mentioned in the intimation or employers mentioned in the special notice, as the case
may be, shall also, for the purposes of this Act, be deemed to be affected by such change, and to have
been given notice under sub-section (1) or (2), as the case may be, of section 42.(5)Where an
employer or an employee gives a notice of a proposed change under sub-section (1) or sub-section
(2), as the case may be, of section 42, and such change, in the opinion of the [State] Government
affects the majority of employers or employees engaged in an industry or occupation in the local
area, the [State] Government may by notification in the Official Gazette declare that the whole of
such industry or occupation, as the case may be, is affected by such change and thereupon it shall be
deemed to be so affected.
44. Agreement regarding change. - (1) If within seven days from the date of
service of a notice under section 42 or an intimation or special notice under
section 43, or the date of publication of a notification under sub-section (5) of
section 43 or within such further period as may be mutually fixed by the
employers affected and the representative of the employees affected an
agreement is arrived at in regard to the proposed change, a memorandum of
such agreement signed by the employer or employers as well as by the
representative of employees shall be forwarded in the prescribed manner to
the Chief Conciliator, the Registrar and the Labour Officer:
Provided that where the employees deemed to be affected under sub section (4) of section 43 are in
the opinion of the [State] Government the majority of the employees in the industry, or the whole
industry is deemed to be affected under sub-section (5) thereof, the Labour Officer shall not enter
into any agreement under this sub-section.(2)On receipt of such memorandum of agreement the
Registrar shall enter the same in a register maintained for the purpose unless on inquiry he is
satisfied that the agreement was in contravention of any of the provisions of this Act or was the
result of mistake, misrepresentation, fraud, undue influence, coercion or threat.(3)An appeal shall
lie to the Industrial Court against an order of the Registrar refusing to register an agreement under
sub-section (2). The provisions of section 20 shall apply to such appeal.
44A. Registration of agreements under section 42(4). - [Where an agreement
referred to in the proviso to sub-section (4) of section 42 is arrived at, a
memorandum of such agreement may be forwarded by either party to the
Registrar by registered post. The provisions of sub-section (2) and (3) ofBombay Industrial Relations Act, 1946

section 44 shall then apply for registration of such agreement.
44B. Certain settlements deemed to be agreements. - Where a settlement is
arrived at within two months from the date of the completion of any
conciliation proceedings, such settlement shall be deemed to be an
agreement for the purposes of section 44 and the provisions of the said
section 44 shall apply for registration of such agreement.]
45. Agreement to come into force. - An agreement registered under section
44 shall come into operation on the date specified therein or if no date is so
specified on its being recorded by the Registrar.
46. Illegal change. - (1) No employer shall make any change in any standing
order settled under Chapter VII without following the procedure prescribed
thereof in this Act.
(2)No employer shall make any change in any industrial matter mentioned in Schedule II-[(ai)
before giving notice of the change as required by the provisions of sub-section (1) of section
42;](i)within the period provided for in sub-section (1) of section 44 unless an agreement is arrived
at;[(ii) where no agreement is arrived at before the completion of the conciliation proceedings and
during the period of ten days thereafter];(iii)where no settlement is arrived at, after two months
from the date of the completion of the proceeding before the Conciliator;(iv)in case where there is a
registered submission or in which the dispute has been referred to arbitration, before the date on
which the award comes into operation;[(v) in cases where such matter or a dispute regarding such
matter has been referred to a Wage Board for decision, before the date on which the decision comes
into operation.](3)No employer shall make any such change in contravention of the terms of a
settlement, [effective award, registered agreement or effective order or decision of a Wage
Board].(5)Failure to carry out the terms of any settlement, award, [registered agreement or effective
order or decision of a Wage Board], [a Labour Court or the Industrial Court affecting Industrial
matter] shall be deemed to be an illegal change.
47. Employer to make change etc., within certain time. - An employer
required under the terms of any [effective decision or order of a Wage
Board,] Labour Court or the Industrial Court to carry out a change or
withdraw an illegal change, shall comply with such requirement within such
time as the [Wage Board or] Court giving or making the decision or order
prescribes and where no time is prescribed by it within fortyeight hours of
the giving or making of the decision or the order [or as the case may be, of
the declaration referred to in section 76A or 86F].Bombay Industrial Relations Act, 1946

Chapter IX
Joint Committees
48. Constitution of Joint Committees. - (1) A Joint Committee may be
constituted for an undertaking or occupation with the consent of the
employer and the registered union for the industry for the local area [and
shall be constituted irrespective of such consent, if the [State] Government
on an application made to it in this behalf by the registered union so directs]:
Provided that no Joint Committee shall be so constituted in respect of an undertaking or occupation
where there is no representative union, unless not less than fifteen per cent of the employees are
members of a registered union.(2)On application made in this behalf by the employer or the Union
to the registrar, a Joint Committee shall be entered in a list of Joint Committees maintained by him,
and thereupon all the provisions of this Act shall apply to the Joint Committee.[(3) Every Joint
Committee shall stand dissolved whenever the condition specified in the proviso to sub-section (1)
ceases to be complied with; and a Joint Committee constituted with the consent of the employer and
the registered union shall also stand dissolved on the expiry of the period of a three month's notice
in that behalf being given by the employer to the union, or by the union to the employer.]
49. Composition of Joint Committee. - (1) A Joint Committee shall consist of
such number of members as may be prescribed; half the number shall in the
prescribed manner be nominated by the union [from among employees in the
undertaking or occupation concerned], and the other half appointed by the
employer concerned.
[Where the Joint Committee is to be constituted in pursuance of a direction of the [State]
Government on an application made by the registered union, the union and the employer shall
nominate and appoint the members within such period as the [State] Government may by order
specify. A copy of such order shall, as soon as may be, be given to the union and the employer in the
manner prescribed.](2)A Chairman shall be appointed in accordance with rules made in this behalf.
He shall perform his duties in the prescribed manner.
50. Proceedings of Joint Committee. - (1) A representative of the registered
union may attend any meeting of the Joint Committee, to advise the
members representing the employees.
(2)The proceeding of the Joint Committee shall be conducted in the manner prescribed.(3)The
proceedings shall be recorded in a minute book [in a language understood by majority of the
employees].Bombay Industrial Relations Act, 1946

51. Proposal for change. - (1) Any member of a Joint Committee may move a
proposal regarding any change other than a change in any standing order or
regarding any other matter affecting the relations between the employer and
the employees in the undertaking or occupation, as the case may be, for
which the Committee is constituted :
Provided that no such proposal shall be moved for a change in respect of any industrial matter if
such change could not for the time being be made under this Act.(2)The decision of the Joint
Committee regarding every change proposed under the provisions of sub-section (1) together with
all necessary particulars regarding such change shall within forty-eight hours be communicated to
the registered union and the employer, as well as Labour Officer and the Commissioner of Labour.
52. Special intimation for change and special application to Labour Court. -
(1) Where an agreement is arrived at between the employer and the union
regarding any change proposed in the Joint Committee under sub-section (1)
of section 51, a memorandum of such agreement signed by them shall be
forwarded by the employer in the prescribed manner to the Registrar and the
Labour Officer and all the provisions, of this Act shall apply to such
agreement as they would apply in respect of an agreement under sub-section
(1) of section 44.
(2)If within seven days from the receipt of a decision under sub-section (2) of section 51, the
employer or the union sends an intimation (hereinafter called special intimation) in the prescribed
form to the Conciliator for the industry for the local area stating that the change proposed in the
Joint Committee, being a change in respect of a matter not specified in Schedule I or III, or such
change with specified alterations, should be made, and that no agreement in respect thereof has
been arrived at between the union and the employer, the Conciliator shall forthwith enter the case as
an industrial dispute in the register kept under section 55, and the provisions of this Act, shall apply
to it as if a statement were submitted under section 54.(3)If within seven days from the receipt of a
decision under sub-section (2) of section 51 regarding a matter specified in clause (a) of paragraph A
of sub-section (1) of section 78 the employer or union sends a special application in respect of such
matter to the Labour Court having jurisdiction, the Labour Court shall forthwith proceed to decide
the dispute under the provisions of Chapter XII.(4)A copy of every special intimation sent under
sub-section (2) shall be forwarded to the Chief Conciliator, the Conciliator for the industry for the
local area concerned, the Registrar, the Labour Officer and such other person as may be prescribed.
53. Decision of respective representatives binding on union and employer. -
(1) The union may authorise such proportion (hereinafter called the
authorised proportion), not being less then three-fourths of the member
representing the employees on the Joint Committee, to accept or reject on its
behalf any proposal or class of proposals moved in the Committee.Bombay Industrial Relations Act, 1946

(2)The employer may authorise a proportion of the members representing him on the Committee to
accept or reject on his behalf any proposal or class of proposals moved in the Committee.(3)For a
period of two months after a decision of the Committee, no notice of change under section 42, or
special intimation or application under section 52 shall be given or made-(a)where the union acts
under sub-section (1), by the employees concerned or the union, contrary to the decision of the
authorised proportion accepting a proposal in respect of which it is authorised; and(b)where the
employer acts under sub-section (2), by the employer, contrary to the decision of the authorised
proposition of his representatives.(4)The union whenever it acts under sub-section (1), and the
employer whenever he acts under sub-section (2), shall communicate the fact to the Chief
Conciliator, the Conciliator for the industry for the local area concerned and the Registrar.[Chapter
IXA]Joint Management Councils
53A. Constitution of Joint Management Councils. - (1) If in respect of any
industry, the State Government is of opinion that it is desirable in public
interest to take action under this section, it may, in the case of all
undertakings or any class of undertakings in such industry, in which five
hundred or more employees are employed or have been employed on any
day in the preceding twelve months, by general or special order, require the
employer to constitute in the prescribed manner and within the prescribed
time limit a Joint Management Council, consisting of such number of
members as may be prescribed, comprised of representatives of employers
and employees engaged in the undertaking, so however, that the number of
representatives of employees on the Council shall not be less than the
number of representatives of the employers.
Notwithstanding anything contained in this Act, the representative of the employees on the Council
shall be elected in the prescribed manner by the employees engaged in the undertaking from
amongst themselvesProvided that a list of industries in respect of which no order is issued under
this sub-section shall be laid by the State Government before the State Legislature within thirty days
from the commencement of its first Session of each year.(2)One of the members of the Council shall
be appointed as Chairman in accordance with rules made in this behalf.
53B. Function of Council. - (1) The council shall be charged with the general
duty to promote and assist in the management of the undertaking in a more
efficient, orderly and economical manner, and for that purpose and without
prejudice to the generality of the foregoing provision, it shall be the duty of
the Council-
(a)to promote cordial relations between the employer and employees;(b)to build up understanding
and trust between them;(c)to promote measures which lead to substantial increase in
productivity;(d)to secure better administration of welfare measures and adequate safetyBombay Industrial Relations Act, 1946

measures;(e)to train the employees in understanding the responsibilities of management of the
undertaking and in sharing such responsibilities to the extent considered feasible; and(f)to do such
other things as may be prescribed.(2)The Council shall be consulted by the employer on all matter
relating to the management of the undertaking specified in sub-section (1) and it shall be the duty of
the Council to advice the employer on any matter so referred to it.(3)The Council shall be entrusted
by the employer with such administrative functions, appearing to be connected with, or relevant to,
the discharge by the Council of its duties under this section, as may be prescribed.(4)It shall be the
duty of the employer to furnish to the Council necessary information relating to such matters as may
be prescribed for the purpose to enable it to discharge its duties under this Act.(5)The Council shall
follow such procedure in the discharge of its duties as may be prescribed.]
Chapter X
Conciliation Proceedings
54. Report of dispute to be sent to Registrar, Chief Conciliator and
Conciliator. - (1) If any proposed change in respect of which notice is given
under section 42, or an intimation or special notice is given under section 43
is objected to by the employer or the employee, as the case may be, the party
who gave such notice, intimation or special notice shall, if he still desires
that the change should be effected, forward to the Registrar, the Chief
Conciliator and the Conciliator for the local area for the industry concerned a
full statement of the case in the prescribed form within fifteen days from the
date of service of such notice, intimation or special notice on the other party
or within one week of the expiry of the period fixed by both parties under
sub-section (1) of section 44 for arriving at an agreement.
Explanation - For the purposes of this sub-section a change shall be deemed to be objected to by the
employer or employee, as the case may be, if within seven days from the date of service of such
notice, intimation or special notice or within the period fixed by both the parties under sub-section
(1) of section 44 for arriving at an agreement a memorandum of agreement has not been forwarded
to the Registrar under the said subsection.(2)When a notification is issued under sub-section (5) of
section 43 in respect of such change, any employer or employee in the industry may within seven
days from the date of publication of such notification forward such statement to the said officers.
55. Commencement of conciliation proceeding. - On receipt of the statement
of the case under section 54 the Conciliator shall, except in a case in which
by reason of the provisions of section 64 a conciliation proceeding cannot be
commenced, [within a week] enter the industrial dispute in the register kept
for the purpose and thereupon the conciliation proceeding shall be deemedBombay Industrial Relations Act, 1946

to have commenced from [the date of such entry in the register, which date
shall be communicated by him to the parties concerned].
56. Conciliation proceeding. - (1) The Conciliator shall hold the conciliation
proceeding in the prescribed manner.
(2)It shall be the duty of the Conciliator to endeavour to bring about the settlement of the industrial
dispute and for this purpose the Conciliator shall enquire into the dispute and all matters affecting
the merits thereof and may do all such things as he thinks fit for the purpose of including the parties
to come to a fair and amicable settlement of the dispute and may adjourn the conciliation
proceeding for any period sufficient in his opinion to allow the parties to arrive at a settlement or for
any other reason.
57. Power of Chief Conciliator to intervenue. - (1) It shall be lawful for the
Chief Conciliator to intervenue or to direct any Conciliator to intervene at any
stage in any conciliation proceeding held by another conciliator, and
thereafter the Chief Conciliator or the Conciliator so directed shall hold the
conciliation proceeding with or without the assistance of the Conciliator.
(2)The Chief Conciliator may from time to time issue such directions as he deems fit to any
Conciliator at any stage of a conciliation proceeding.
58. Settlement and report. - (1) If a settlement of an industrial dispute is
arrived at in a conciliation proceeding, a memorandum of such settlement
shall be drawn up in the prescribed form by the Conciliator and signed by the
employer and the representatives of employees. The Conciliator shall send a
report of the proceeding along with a copy of the memorandum of settlement
to the Registrar and the Chief Conciliator. The Registrar shall record such
settlement in the register of agreements and shall then publish it in the
prescribed manner. The change, if any, agreed to by such settlement shall
come into operation from the date agreed upon in such settlement and where
no such date is agreed upon from the date on which it is recorded in the
register.
(2)If no such settlement is arrived at, the Conciliator shall, as soon as possible after the close of the
proceeding before him, send, a full report to the Chief Conciliator stating the steps taker by him for
ascertaining the facts and circumstances relating to the dispute and the reasons on account of
which, in his opinion, settlement could not be arrived at :Provided that where such Conciliator is the
Chief Conciliator such report shall be forwarded by him to the [State] Government.(3)The Chief
Conciliator shall forward the report submitted to him under sub-section (2) to the [State]Bombay Industrial Relations Act, 1946

Government with such remarks as he deems fit.(4)The [State] Government shall publish the report
of the Conciliator or Chief Conciliator forwarded to it under the proviso to sub-section (2) or under
sub-section (3) except in cases in which the dispute is referred to a Board, or the parties to the
dispute enter into a submission in respect of it.[(4A) Notwithstanding anything contained in this
section where an industrial dispute is settled in regard to some of the industrial matters included
therein and has not been settled in regard to others and the parties agree in writing that the
settlement shall take place in regard to the industrial matters so settled, the settlement of the said
Industrial matter shall be registered and a report of the industrial matters not settled shall be sent in
accordance with the provisions of this section.](5)Before the close of the proceeding before him the
Conciliator shall ascertain from the parties whether they are willing to submit the dispute to
arbitration.(6)(a)Notwithstanding anything contained in the foregoing sub-sections, if at any stage
of a conciliation proceeding the parties agree in writing to submit the dispute to arbitration, the
agreement shall be deemed to be a submission within the meaning of section 66.(b)Where the
agreement provides for arbitration either by a Labour Court or by the Industrial Court, the
Conciliator shall forthwith refer the dispute to the Labour Court or the Industrial Court, as the case
may be.
59. Reference to Board. - (1) The [State] Government may at any time, and
where either prior to the commencement of a proceeding before the
Conciliator or after his failure to bring about a settlement, the parties agree,
shall refer dispute to a Board and thereupon conciliation proceedings before
the Board shall be deemed to have commenced from the date of such
reference.
(2)On such reference being made, the Board shall give notice in the prescribed manner to the parties
to the dispute to appear before it at such time and place as may be specified in the notice. A Copy of
such notice shall be sent to the Labour Officer.(3)On the date specified in the notice or on such other
date as may be fixed by the Board, the Board shall hold the conciliation proceeding. It shall be the
duty of the Board to endeavour to bring about settlement of the industrial dispute and the
provisions of sections 55, 56 and 58 shall, so far as may be, apply to the proceeding before the
Board.
60. Procedure and powers of Conciliator and Board. - (1) A Conciliator or a
Board, as the case may be, shall subject to the provisions of this Act, follow
in a conciliation proceeding such procedure as may be prescribed.
(2)The proceedings before a Conciliator shall be held in camera and any proceedings before a Board
may be held in public or in camera as the Board may decide.(3)If a party to an industrial dispute or a
witness or any other person giving any information or producing any document in a conciliation
proceeding makes a request in writing to the Conciliator or the Board, as the case may be, that such
information or the contents of such document be treated as confidential, the Conciliator or the
Board shall direct that such information or document be treated as Confidential:Provided that theBombay Industrial Relations Act, 1946

Conciliator or Board may permit the information or the contents of the document to be disclosed to
the other party.(4)Save as provided in sub-section (3), a Conciliator or any member of a Board or
any person present at or concerned in the conciliation proceeding shall not disclose any information
or the contents of any document in respect of which a request has been made under sub-section (3)
without the consent in writing of the party making the request under the said
sub-section.(5)Nothing in this section shall apply to the disclosure of any information or the
contents of any document for the purpose of a prosecution under this Act or under any other law for
the time being in force.
61. Reference to Industrial Court by Conciliator or Board. - A Conciliator or a
Board may refer any question of law arising before him or it in any
conciliation proceeding, to the Industrial Court for decision. Any order
passed by the Conciliator or the Board in such proceeding shall be in
accordance with such decision.
62. Time limit for stages of conciliation proceeding. - (1) The [State]
Government shall by general or special order notified in the Official Gazette
fix a time limit for the completion of each stage of the conciliation
proceedings provided for under this Chapter :
Provided that the total period fixed for the completion of all stages of conciliation proceeding shall
not exceed one month from the date on which the dispute is entered by the Conciliator in the
register under section 55 or is referred to a Board under section 59:Provided further that the [State]
Government may extend the said period of one month by a further period of a fortnight at a time but
not exceeding in any case two months in the aggregate.(2)Notwithstanding anything contained in
sub-section (1), the parties to any industrial dispute may in any case agree to extend the period fixed
for the completion of any stage of a conciliation proceeding by any further period and such further
period shall be excluded in computing the period of time limit referred to in the said sub-section:[
Provided that the total period fixed for the completion of conciliation proceeding including the
period of extension mutually agreed to by the parties shall not exceed one year:Provided further that
the State Government may extend the said period of one year by a further period of a month at a
time but not exceeding in any case two months in the aggregate.][(3) Where a Conciliator or a Board
refers under section 61a question of law to the Industrial Court for its decision, the period
commencing from the date of such reference to the date of communication of the decision of the
Industrial Court to the Conciliator or the Board, as the case may be, shall be excluded in computing
the time limit referred to in sub-section (1)].
63. Completion of conciliation proceeding. - A conciliation proceeding shall
be deemed to have been complete-
(i)when a memorandum of the settlement arrived at in such proceeding is signed by the parties
under sub-section (1) of section 58, or-(ii)when the parties agree in writing to submit the dispute toBombay Industrial Relations Act, 1946

arbitration, or(iii)If no settlement is arrived at, when the report of the Conciliator or the Board is
published by the [State] Government, or(iv)when the time-limit fixed for the completion of such
proceeding under section 62 has expired.[Explanation - When an industrial dispute is settlement in
regard to some of the industrial matters included therein, the conciliaton proceeding in regard to
those matters only shall be deemed to have been completed within the meaning of this section.]
64. Conciliation proceedings not to be commenced or continued in certain
cases. - No conciliation proceeding in respect of an industrial dispute shall
(a)be commenced if-(i)the representative of employees directly affected by the dispute is a
registered union which is a party to a submission relating to such dispute or a dispute relating to an
industrial matter similar to that regarding which the dispute has arisen;(ii)it has been referred to
arbitration under the provisions of section 72 [or 73] [or referred for decision under section
86C];(iii)by reason of a direction issued under sub-section (2) of section 114 [or by reason of any of
the other provisions of this Act] the employers and employees concerned are in respect of the
dispute bound by a registered agreement, settlement, submission or award;(b)be continued after the
date on which-(i)a submission relating to such dispute is entered into by the employer and
employees concerned under section 58 or 66;(ii)the dispute is a referred to arbitration under section
72, [73 or 73A] [or referred for decision under section 86C or 86CC] or;(iii)the direction referred to
in sub-clause (iii) of clause (a) is issued.
65. Conciliation proceedings discontinued deemed to be completed. - A
conciliation proceeding which is discontinued under clause (b) of section 64
shall be deemed to have been completed on the date referred to in the said
clause, and the provisions of section 58 with regard to the submission,
forwarding and publication of reports shall apply to such conciliation
preceding.
Chapter XI
Arbitration
66. Submission. - (1) Any employer and a Representative Union or any other
registered union which is a representative of employers may, by a written
agreement, agree to submit any present or future industrial dispute or class
of such disputes to the arbitration of any person whether such arbitrator is
named in such agreement or not. Such agreement shall be called a
submission.
(2)Such submission may provide that the dispute shall be referred to the arbitration of a Labour
Court or the Industrial Court:[Provided that no such submission shall provide for reference of anyBombay Industrial Relations Act, 1946

such dispute to the arbitration of the Industrial Court when under any provision of this Act it is
required to be referred to the Labour Court for its decision.](3)A copy of every such submission shall
be sent to the Registrar who shall register it in the register to be maintained for the purpose and
shall publish it in such manner as may be prescribed.
67. Submission when revocable. - Every submission shall in the absence of
any provision to the contrary contained therein be irrevocable:
Provided that a submission to refer future disputes to arbitration may at any time be revoked by any
of the parties to such submission by giving the other party six month's notice in writing:Provided
further that before the expiry of the said period of six months the parties may agree to continue the
submission for such further period as may be agreed upon between them.
68. Non-application of Arbitration Act, 1940. - [Nothing in the Arbitration Act,
1940 (X of 1940.) shall apply to arbitration under this Chapter.]
69. Special case to be stated to Industrial Court. - The arbitrator may refer
any question of law arising before him in any proceeding under this Act to
the Industrial Court for its decision. Any award made by the arbitrator shall
be in accordance with such decision.
70. Award by arbitrator. - The arbitrator shall after hearing the parties
concerned, make an award of which shall be signed by him.
71. Dispute to be referred to Labour Court and Industrial Court if no arbitrator
appointed. - Notwithstanding anything contained in this Chapter, if no
provision has been made in any submission for the appointment of an
arbitrator or where by reason of any circumstance no arbitrator is appointed,
such dispute shall be referred to the arbitration of a Labour Court or the
Industrial Court, as the [State] Government may determine.
72. Disputes between employees and employees may be referred by [State]
Government to arbitration of Labour Court or Industrial Court. - (1)
Notwithstanding anything hereinbefore contained the [State] Government
may, at any time on the report of the Labour Officer or on its own motion,
refer any industrial dispute between employees and employees to the
arbitration of a Labour Court or the Industrial Court.
(2)The provisions of this Chapter with such modifications as may be prescribed shall apply to such
arbitration.(3)The employers of such employees shall in the prescribed manner be made parties toBombay Industrial Relations Act, 1946

such arbitration.
73. [State] Government may refer Industrial dispute to Industrial Court for
arbitration. - Notwithstanding anything contained in this Act, the [State]
Government may, at any time, refer an industrial dispute to the arbitration of
the Industrial Court, if on a report made by the Labour Officer or otherwise it
is satisfied that-
(1)by reason of the continuance of the dispute-(a)a serious outbreak of disorder or a breach of the
public peace is likely to occur; or(b)serious or prolonged hardship to a large section of the
community is likely to be caused; or(c)the industry concerned is likely to be seriously affected or the
prospects and scope for employment therein curtailed; or(2)the dispute is not likely to be settled by
other means; or(3)it is necessary in the public interest to do so.
73AA. Power of State Government to include other undertakings in
references to Labour or Industrial Court. - [Where an industrial dispute
concerning any undertaking in an industry or section thereof has been or is
to be referred to a Labour Court or Industrial Court under section 72 or 73,
and the State Government is of opinion, whether on application made to it in
this behalf or otherwise, that the dispute is of such a nature that any other
undertaking, group or class of undertakings of a similar nature in that
industry or any section thereof is likely to be interested in or affected by
such dispute, the State Government may, at the time of making such
reference or at any time thereafter, but before the submission of the award,
include in that reference such undertaking, group or class of undertaking or
any section thereof, whether or not at the time of such inclusion any dispute
exists or is apprehended in that establishment, group or class of
undertakings or section thereof.]
73A. Reference to arbitration by unions. - [Notwithstanding anything
contained in this Act, a registered union which is a representative of
employees and which is also an approved union may refer any industrial
dispute for arbitration to the Industrial Court:
Provided that no such dispute shall be referred to the Industrial Court,-(i)after two months from the
date of the completion of the proceedings before the Conciliator;(ii)where the employer has offered
in writing before the Conciliator to submit the dispute to arbitration under this Act, and the union
has not agreed to do so;(iii)unless the dispute is first submitted to the Conciliator and the
conciliation proceedings are completed or the Conciliator certifies that the dispute is not capable of
being settled by conciliation:Provided that no such dispute shall be referred to the Industrial CourtBombay Industrial Relations Act, 1946

where under any provision of this Act it is required to be referred to the Labour Court for its
decision.]
74. Notice of award to parties. - (1) The arbitrator, Labour Court or Industrial
Court, as the case may be, shall forward copies of the award made by him or
it to the parties, the Commissioner of Labour and the Registrar.
(2)On receipt of such award, the Registrar shall enter it in the register kept for the purpose and shall
publish it in such manner as may be prescribed.
75. Date on which awards shall come into operation. - [Except as provided in
section 118B, the award shall] come into operation on the date specified in
the award or where no such date is specified therein on the date on which it
is published under section 74.
76. Completion of arbitration proceeding. - The arbitration proceeding shall
be deemed to have been completed when the award is published under
section 74.
76A. Procedure to give effect to awards affections [State] Government. - [(1)
Notwithstanding anything contained in sections 74 to 76 (both inclusive)
where the award affects an industry conducted or carried on by a department
of the [State] Government, the award shall not be effective except in
accordance with the procedure set out in subsections (2) and (3).
(2)The arbitrator, Labour Court or Industrial Court shall, as soon as practicable, on the conclusion
of its proceedings, submit its award to the [State] Government, and the [State] Government shall, by
order in writing, declare the [award] to be binding:Provided that where in the opinion of the [State]
Government it would be inexpedient on public grounds to give effect to the whole or any part of the
award the [State] Government, shall on the first available opportunity, lay the [award] together with
the statement of its reasons for not making a declaration as aforesaid before the Legislative
assembly of the [State] and shall, as soon as may be, cause to be moved therein a resolution for the
considerations of the [award]; and the Legislative Assembly may by its resolution confirm, modify
or reject the award.(3)On the passing of a resolution under the proviso to sub-section (2) unless the
award is rejected thereby, the [State] Government shall, by order in writing declare the award as
confirmed or modified by the resolution, as the case may be, to be binding.]
Chapter XII
Labour CourtsBombay Industrial Relations Act, 1946

77. Territorial jurisdiction. - The territorial jurisdiction of Labour Courts shall
extend to the local areas for which they are constituted.
78. Powers of Labour Court. - (1) Labour Court shall have power to-
A. decide-(a)dispute regarding-[[i) the propriety or legality of an order passed by an employer acting
or purporting to act under the standing orders;](ii)the application and interpretation of standing
orders;(iii)any change made by an employer or desired by an employee in respect of an industrial
matter specified in Schedule III and matters arising out of such change;(b)industrial
disputes-(i)referred to it under section 71 or 72;(ii)in respect of which it is appointed as the
arbitrator by a submission;(c)whether a strike, lock-out, [closure, stoppage] or any change is illegal
under this Act;B. try offences punishable under this Act and where the payment of compensation on
conviction for an offence is provided for, determine the compensation and order its payment;C.
require any employer to-(a)withdraw any change which is held by it to be illegal, or(b)carry out any
change provided such change is a matter in issue in any proceeding before it under this Act.(2)Every
offence publishable under this Act shall be tried by the Labour Court within the local limits of whose
jurisdiction it was committed.Explanation - A dispute falling under clause (a) of paragraph A of
sub-section (1) shall be deemed to have arisen if within the period prescribed under the proviso to
subsection (4) of section 42, no agreement is arrived at in respect of an order, matter or change
referred to in the said proviso.
79. Commencement of proceedings. - (1) Proceedings before a Labour Court
in respect of disputes falling under clause (a) of paragraph A of sub-section
(1) of section 78 shall be commenced on an application made by any of the
parties to the dispute, a special application under sub-section (3) of section
52 or an application by the Labour Officer [or a representative union] and
proceeding in respect of a matter falling under clause (c) of the said
paragraph A on an application made by any employer or employee directly
affected or the Labour Court [or a representative Union],
(2)Every application under sub-section (1) shall be made in the prescribed form and manner.(3)An
application in respect of a dispute falling under clause (a) of paragraph A of sub-section (1) of
section 78 shall be made,-(a)If it is a dispute falling under sub-clause (i) or (ii) of the said clause,
within three months of the arising of the dispute;(b)If it is a dispute falling under sub-clause (iiii) of
the said clause, within three months of the employee concerned having last approached the
employer under the proviso to sub-section (4). of section 42.(4)An application in respect of a matter
falling under clause (c) of paragraph A of sub-section 78 shall be made within [six months] of the
commencement of the strike, [lock-out, closure or stoppage] or of the making of the illegal change,
as the case may be:[Provided that the Labour Court may, for sufficient reasons, admit any
application for a declaration that a change is illegal under this act, after the expiry of [six months]
from the date on which change was made:Provided further that when an application is admitted
after the expiry of [six months] under the preceding proviso the employer who made the changeBombay Industrial Relations Act, 1946

shall not be liable to the penalty provided under section 100.]
80. Labour Court to give notice to parties affected and permit appearance of
parties. - [On receipt of an application under section 79 the Labour Court
shall issue a notice to all parties affected by the dispute in the manner
provided by rules under section 85. Subject to the provisions of Chapter V,
the Labour Court may permit the parties so affected to appear in the manner
provided by the provisions of sections 80A to 80C. The Labour Court shall
then hold an inquiry.
80A. Procedure to be followed in an application under section 79 by an
employer when employees affected are numerous. - (1) Where an application
is filed, under section 79 by an employer or the Labour Officer for the
decision of the Labour Court, and the employees affected are numerous
persons having the same interest, the Court may permit one more of such
employers to appear and to defend the application on behalf of all the
employees so interested.
(2)In such case the Labour Court shall also direct notice of the filing of the application to be given to
all such employees at the applicant's expense either by personal service or where from the number
of employees or any other cause such service is not reasonably practicable, by public advertisement
and by causing the notice which is translation in a regional language to be affixed by the applicant at
the entrance through which the majority of the employees enter the premises for their work. The
person affixing the notice and publishing the advertisement shall file an affidavit in the Court of his
having done so.
80B. When an employee, who is not permitted to appear may be allowed to
join as party. - Any employee, who is not permitted to appear under section
80A but on whose behalf the application is defended may apply to the Court
to make him a party to such application. The Court may grant such
application, if it is satisfied that the interest of the employee will be severally
and materially affected to his prejudice if he is not joined as a party to the
application.
80C. Procedure to be followed in an application under section 79 by
employees when employees affected are numerous. - (1) Where there are
numerous employees having the same interest, one or more of such
employees, or the Labour Officer, may, with the permission of the Court, file
an application under section 79. Such application may be made on behalf ofBombay Industrial Relations Act, 1946

and for the benefit of all the employees. The court, in such cases direct the
notice of the filing of the application to be given to such employees at the
applicant's expense, either by personal service or where from the number of
employees or any other cause, such service is not practicable, by public
advertisement. The person publishing the advertisement shall file an affidavit
in the Court of his having done so.
(2)An employee on whose behalf an application is filed under sub-section (1) may apply to the Court
to make him a party to such application. The Court may grant such application if it is satisfied that
his interest will be severally and materially affected to his prejudice if he is not joined as a party to
the application.
80D. Judge of Labour Court to record minutes of proceedings, etc. - In an
inquiry under sections 80 and 80A to 80C, the Judge presiding over the
Labour Court shall himself, as such inquiry proceeds, record a minute of the
proceedings in his own hand, embracing the material averments made by the
parties affected and the material parts of the evidence. The decision shall be
signed by him and shall set forth the grounds on which it is based.]
81. Reference to Industrial Court by Labour Court - A Labour Court may refer
any question of law arising in any proceeding before it to the Industrial Court
for decision. Any order passed by the Labour Court in such proceeding shall
be in accordance with such decision.
82. Cognizance of offence. - No Labour Court shall take cognizance of any
offence except on a complaint [of facts constituting such offence made by
the person affected thereby] [or by a representative union which is also an
approved union], or on a report in writing by the Labour Officer.
83. Powers and procedure of Labour Court in trials. - In respect of offences
punishable under this Act, a Labour Court shall have all the powers under
the Code of Criminal Procedure, 1898, (V of 1898.) [of a Magistrate of First
Class], and in the trial of every such offence shall follow the procedure laid
down in Chapter XXII of the said Code for a summary trial in which an appeal
lies; and the rest of the provisions of the said Code shall, so far as may be,
apply to such trial.Bombay Industrial Relations Act, 1946

83A. Legal Practitioners excluded from appearance in certain proceedings in
Labour Courts. - [Except in a proceeding in connection with an offence under
this Act, a legal practitioner shall not be entitled to appear before a Labour
Court on behalf of any party in any other proceeding under this Act, save
with the permission of such Court.]
84. Appeals. - (1) Notwithstanding anything contained in section 83 an appeal
shall lie to the Industrial Court-
(a)against a decision of a Labour Court in respect of a matter falling under clauses (a) or (c) of
paragraph A of sub-section (1) of section 78 except to the extent to which it determines whether a
strike, [lock-out, closure or stoppage] was illegal or not, or a decision of such Court under paragraph
C of sub-section (1) of the said section;(b)against a conviction by a Labour Court by the person
convicted;(c)against acquittal by a Labour Court in its special jurisdiction, by the [State]
Government;(d)for enhancement of a sentence awarded by a Labour Court in its special jurisdiction
by the [State] Government.(2)Every appeal shall be made within thirty days from the date of the
decision, conviction, acquittal or sentence, as the case may be:Provided that the industrial Court
may for sufficient reasons allow an appeal
85. Industrial Court to exercise superintendence over Labour Courts. - [(1)
The industrial Court shall have superintendence over all Labour Courts and
may-
(a)call for returns;(b)make and issue general rules and prescribed forms for regulating the practice
and procedure of such Courts in matters not expressly provided for by this Act and, in particular, for
securing the expeditious disposal of cases;(c)prescribe forms in which books, entries and accounts
shall be kept by the officers of any such Courts;(d)settle a table of fees payable for process issued by
a Labour Court or theIndustrial Court.[(2) The Industrial Court may, by order in writing and for
reasons to be stated therein withdraw any proceeding under this Act pending before a Labour Court
and transfer it for disposal to another Labour Court which may, subject to any special directions in
the order of transfer, proceed in the matter either de novo or from the stage at which it is so
transferred.]
86. Decision etc. of Labour Court not to be called in question. - Except as
otherwise provided by this Act, no decision, award or order of a Labour
Court shall be called in question in any proceeding in any Civil Criminal
Court.Bombay Industrial Relations Act, 1946

86A. [Power to award costs. - (1) A Labour Court shall have the power to
direct by whom the whole or any part of the costs of any proceeding before it
shall be paid:
Provided that no such costs shall be directed to be paid for the services of any legal adviser engaged
by any party.(2)The provisions of section 93 shall apply to an order under this section in the same
manner as they apply to an order of the Industrial Court.][Chapter XIIA]Wage Boards
86AA. Wage Board. - [The [State] Government may, by notification in the
Official Gazette constitute for one or more industries a Wage Board for the
[State of Gujarat].
86B. Constitution of Wage Board. - The Wage Board shall consist of an equal
number of persons nominated by the [State] Government to represent
employers and employees and such member of independent persons as the
[State] Government nominates. The Chairman shall be appointed by the
[State] Government.
Explanation. - For the purposes of this section a person shall be deemed to be an independent
person if he is unconnected with the industrial matter which may be referred to it under section 86C
[or 86CC] and the industry directly affected by the industrial matter.
86C. Reference to Wage Boards. - (1) Notwithstanding anything contained in
any other provision of this Act, the [State] Government may, by an order
notified in the Official Gazette refer to a Wage Board for decision any
industrial matter or industrial dispute regarding items numbered 1, 2, 4, 9 and
10 in Schedule 11, and such other industrial matters or disputes as may be
prescribed.
(2)The order of reference under sub-section (1) shall specify, which employers and employees
(including representative of employees, if any, and association of employers, if any) shall be parties
to the proceedings before the Wage Board.
86CC. Reference to Wage Board certain registered unions. - [Notwithstanding
anything contained in any other provision of this Act, a registered union
which is a representative of employees and which is also an approved union
may refer any industrial dispute of the nature, mentioned in sub-section (1) of
section 86C other than a dispute in respect of bonus, to a Wage Board for
decision :Bombay Industrial Relations Act, 1946

Provided that no such dispute shall be referred to the Wage Board by the union,-(i)after two months
from the date of the completion of the proceedings before the Conciliator;(ii)where the employer has
offered in writing before the Conciliator to submit the dispute to arbitration under this Act and the
union has not agreed to do so;(iii)unless the dispute is first submitted to the Conciliator and the
conciliation proceedings are completed or the Conciliator certifies that the dispute is not capable of
being settled by conciliation.]
86D. Proceedings not to be commenced or continued before Conciliator,
Boards, etc. - Notwithstanding anything contained in any other provision of
this Act, where an industrial matter or industrial dispute is referred for
decision to a Wage Board under section 86C [or 86CC] no proceedings
regarding the same shall be commenced before a Conciliator, Board, Labour
Court or the Industrial Court or a Court of Enquiry; and any such
proceedings already commenced shall be forthwith stayed on the making of
the reference.
86E. Procedure before Boards. - A Wage Board shall, in respect of an
industrial matter or industrial dispute referred to it for decision, subject to
any rules or procedure which may be prescribed, follow the same procedure
as the Industrial Court in respect of arbitration proceedings before it.
In particular the rules of procedure which may be prescribed in this behalf may provide for the
formation of committees for local areas from amongs members of the Wage Board with co-option of
such other persons from the local areas as the Wage Board would for the purpose of any reference
think fit to appoint to the committees and the exercise by each such committee of the jurisdiction
and powers vested in the Wage Board in respect of such industrial matters or industrial disputes as
are referred by the Wage Board to the Committee.
86EE. Coming into operation of decision of Wage Board. - [Save as provided
in section 86F, a decision of the Wage Board shall come into operation on
the date specified in the decision and where no such date is specified therein
on the date on which it is published in the prescribed manner.]
86F. Procedure to give effect to decision of Wage Board affecting [State]
Government. - (1) Where the decision of a Wage Board affects an industry
conducted or carried on by a department of the [State] Government, the
decision shall not be effective except in accordance with the procedure set
out in sub-sections (2) and (3).Bombay Industrial Relations Act, 1946

(2)The Wage Board shall, as soon as practicable on the conclusion of its proceedings, submit its
decision to the [State] Government, and the [State] Government shall by order in writing declare the
decision to be binding:Provided that where in the opinion of the [State] Government it would be
inexpedient on public grounds to give effect to the whole or any part of the decision, the [State]
Government shall on the first available opportunity lay the decision together with the statement of
its reasons for not making a declaration as aforesaid before the Legislative Assembly of the [State]
and shall, as soon as may be, cause to be moved therein a resolution for the consideration of the
decision; and the Legislative Assembly may by its resolution confirm, modify or reject the
decision.(3)On the passing of resolution under the proviso to sub-section (2), unless the decision is
rejected thereby, the [State] Government shall, by order in writing, declare the decision as
confirmed or modified by the resolution, as the case may be, to be binding.[(4) A decision declared
to be binding under sub-section (2) or (3) shall come into operation on such date as may be
specified in the order of declaration made by the [State] Government.]
86G. Appeals. - (1) An appeal shall lie to the Industrial Court against an order
or decision of a Wage Board (including reviewed order or decision), save in
case referred to in section 86 F.
(2)Such appeal shall be made within six weeks from the date of the order of decision.
86H. Parties on whom order or decision of Wage Board is binding. - Subject
to the provisions of sections 86 F and 86G, an order or decision of a Wage
Board shall be binding on-
(a)all parties to any proceeding before it who appeared or were represented therein;(b)all parties
who were summoned to appear as parties to the proceeding, whether they appeared or not;(c)all the
employers and employees in the concern or occupation or industry in the local area according as the
order of reference under sub-section (1) of section 86-C directs irrespective of whether they were
such employers or employees at the time of the making or giving of such order or decision, or
whether they became such afterwards.
86I. Review of order or decision by Wage Board. - (1) An employer or an
employees or an association or a group of employers or a registered union
or body of employees may apply to a Wage Board for review of an order or
decision of the Wage Board and the Wage Board may for any sufficient
reason and upon hearing all the parties review the order or decision:
Provided that no such application shall lie until a period of one year has elapsed from the date of the
making or giving of the order or decision or the last review thereof, as the case may be:Provided
further that no such application by an employer or an association or a group of employers shall lie
unless the employer, association or group, as the case may be, employees not less than fifteen per
cent, of the employees whom the order or decision binds:Provided also that no such application byBombay Industrial Relations Act, 1946

an employer or a body of employees shall lie unless the employee or body of employees represents
not less than fifteen per cent, of the employees whom the order or decision binds.(2)Where the
[State] Government makes an application in this behalf, the Wage Board may at any time review its
order or decision for any sufficient reason and upon hearing all the parties.
86J. Superintendence by Industrial Court. - The Industrial Court shall have
superintendence over all Wage Boards and may-
(a)call for returns from such Boards;(b)make and issue general rules, and lay down forms for
regulating the practice and procedure of such Boards in matters not expressly provided for by or
under this Act, and in particular, for securing expeditious disposal of cases;(c)lay down the forms in
which books, entries and accounts shall be kept by officers of Wage Board;(d)settle fees for
processes issued by Wage Boards.
86K. Order or decision of Wage Boards not to be called in question. - (1) Save
as otherwise provided by this Act, no order or decision of a Wage Board
shall be called in question in any proceeding in any civil or criminal court.
(2)The appellate order or decision of the Industrial court under section 86G shall have the same
force as the original order or decision of the wage Board which it replaces except that there shall be
no further appeal against it.
86KK. Transfer of certain disputes to Wage Board. - [The [State] Government
may, on the recommendation of the Industrial Court, by an order notified in
the Official Gazette, direct that any industrial matter, or industrial dispute of
the nature mentioned in section 86C which has been referred to the Industrial
Court under [sub-section (6) of section 58 sections 66, 72, 73 or 73A] and is
pending before it at any time shall be transferred to a Wage Board for
disposal or for further disposal from the stage reached before the Industrial
Court and thereupon all the provisions of this Act shall apply to that dispute
as if it were referred to the Wage Board for decision under section 86C].
Chapter XII
B
[State] Wage BoardBombay Industrial Relations Act, 1946

86L. [State] Wage Board. - (1) The [State] Government may by notification in
the Official Gazette, constitute for all the industries together to which this Act
applies a [State] Wage Board for the [State of Gujarat].
(2)In relation to the [State] Wage Board the provisions of sections 33, 46, 47, 86B to 86K (both
inclusive), 87, 90, 97, 98, 115, 118, 119, 119A and 123 shall be read as if the reference therein to a
Wage Board were referred to the [State] Wage Board.]
Chapter XIII
Court of Industrial Arbitration.
87. Duties of Industrial Court. - It shall be the duty of the Industrial Court-
(a)(i)to decide appeals under section [20, 24A or 44] from orders passed by the registrar;(ii)to
decide appeals from the decision of the Commissioner of Labour under section 36 or 39 and revision
applications under section 37 regarding standing orders;(iii)to decide disputes referred to it under
sub-section (6) of section 58;(iv)to decide all matters which may be referred to it by a Conciliator or
a Board under section 61 or by an arbitrator under section 69;(v)to decide industrial disputes
referred to it in accordance with submissions registered under section 66 which provide for such
reference to the Industrial Court;(vi)to decide industrial disputes referred to it under sections 71, 72,
[73 or 73A];(vii)to decide matters referred to it under section 90;(viii)to decide questions relating to
the interpretation of this Act or rules made thereunder and standing orders referred to it under
section 91;[(viiia) to decide applications made to it under section 115B;](ix)to decide references
made to it under section 99;[ixa] to modify an award under section 116A;](x)to decide such other
matters as may be referred to it under this Act or the rules made thereunder;(b)to decide appeals
made under section 84 from a decision of a Labour Court;[(c) to decide appeals made under section
86G from an order or decision of a Wage Board].
88. Powers of Industrial Court. - (1) The Industrial Court in appeal may
confirm, modify, add to or rescind any decision or order appealed against
and may pass such orders therein as it may deem fit.
(2)In respect of offences punishable under this Act, the Industrial Court shall have all the powers of
the [High Court of Gujarat] under the Code of Criminal Procedure, 1898. (v of 1898.)(3)A copy of
the orders passed by the Industrial Court shall be sent to the Labour Court.
89. Cancellation of registration of union. - If in any proceeding the Industrial
Court finds that any union was registered by reason of a mistake,
misrepresentation or fraud, or that a registered union has contravened any of
the provisions of this Act, the Industrial Court may direct that the registrationBombay Industrial Relations Act, 1946

of such union shall be cancelled.
90. Reference on point of law. - [(1) A Wage Board may refer to the Industrial
Court any point of law arising in any proceedings before it under this Act.
Any order or decision made or given by the Wage Board in such proceedings
shall be in accordance with the decision of the Industrial Court.]
[(2) A Civil or Criminal Court may refer any matter or any issue in any suit, criminal prosecution or
other legal proceeding before it relating to an industrial dispute to the Industrial Court for its
decision. Any order passed by such Court in such suit, prosecution or legal proceedings shall be in
accordance with such decision.][(3) The [State] Government may refer to the Industrial Court any
point of law arising in any proceeding held under this Act. The Industrial Court shall not decide any
such reference save in open Court and with the concurrence of a majority of the members of the
Court present at the hearing of the reference.]
91. Reference regarding interpretation of Act and Rules. - The Commissioner
of Labour may refer any question relating to the interpretation of this Act or
the rules made under this Act to the Industrial Court for its decision.
92. Procedure before Industrial Court. - (1) The Industrial Court shall make
regulations consistent with the provisions of this Act and rules made
thereunder regulating its procedure.
(2)In particular, and without prejudice to the generality of the foregoing power, such regulations
may provide for the formation of Benches consisting of one or more of its members and the exercise
by each such Bench of the Jurisdiction and powers vested in it:Provided that no Bench shall consist
only of a member who has not been and at the time of his appointment was not eligible for
appointment as, a Judge of a High Court.(3)Every regulation made under sub-section (1) or (2) shall
be published in the Official Gazette.(4)Every proceeding before the Industrial Court shall be deemed
to be a judicial proceeding within the meaning of sections, 192, 193 and 228 of Indian Penal Code.
(XIV of 1860.)(5)The Industrial Court shall have power to direct by whom the whole or any part of
the costs of any proceeding before it shall be paid :Provided that no such costs shall be directed to be
paid for the services of any legal advisor engaged by any party.
93. Execution or order as to costs. - An order made by the Industrial Court
regarding the costs of a proceeding may be produced before the Court of the
Civil Judge within the local limits of whose jurisdiction any person directed
by such order to pay any sum of money has a place of residence or business
[or where such place is within the City of Ahmedabad before the Court of
Small Causes of Ahmedabad] [***], and such court shall execute such order
in the same manner and by the same procedure as if it were a decree for theBombay Industrial Relations Act, 1946

payment of money made by itself in a suit.
94. Parties on whom order of Industrial Court binding. - An order, decision or
award of the Industrial Court shall be binding on-
[(a) all parties to the industrial dispute;](b)all parties who were summoned to appear as parties to
the dispute whether they appeared or not unless the Industrial Court is of opinion that they were
improperly made parties;(c)in the case of an employer who is a party to the proceeding before such
Court in respect of the undertaking to which the dispute relates, his successors, heirs or assigns in
respect of the undertaking to which the dispute relates; and(d)in the case of a registered union
which is a party to the proceeding before such Court, all persons represented by the union at the
date of the award, as well as thereafter.
95. [Order of Industrial Court to be final except on review.] - [(1) An employer
or an association or a group of employees or a registered union [or a
representative of employees] may at any time apply to the Industrial Court for
review of a decision or award of the Industrial court and the Industrial Court
may, for any sufficient reason and upon hearing the parties, review the
decision or award.]
[(2) No order, decision or award of the Industrial Court shall be called in question in any civil or
criminal Court.]
95A. Law declared by Industrial Court to be binding. - [The determination of
any question of law in any order, decision, award, declaration passed or
made, by the Full Bench of the Industrial Court constituted under the
regulations made under section 92 shall be recognised as binding and shall
be followed in all proceedings under this Act.]
96. Officer to appear in proceeding before Industrial Court. - The [State]
Government may direct any officer to appear in any proceeding before the
Industrial Court by giving notice to such Court and on such notice being
given such officer shall be entitled to appear in such proceeding.
Chapter XIV
Illegal Strikes and Lock-OutsBombay Industrial Relations Act, 1946

97. Illegal strike. - (1) A strike shall be illegal if it is commenced or continue-
(a)in cases where it relates to an industrial matter specified in Schedule III or regulated by any
standing order for the time being in force;(b)without giving notice in accordance with the provisions
of section 42;(c)only for the reason that the employer has not carried out the provisions of any
standing order or has made an illegal change;(d)in cases where notice of the change is given in
accordance with the provisions of section 42 and where no agreement in regard to such change is
arrived at before the statement of the case referred to in section 54 is received by the conciliator for
the industry concerned for the local areas;(e)in cases where conciliation proceeding in regard to the
industrial dispute to which the strike relates have commenced, before the completion of such
proceedings [and during the period of ten days thereafter];(f)in cases where special intimation has
been sent under sub-section (2) of section 52 to the Conciliator, before the receipt of the intimation
by the person to whom it is to be given;(g)in cases where a submission relating to such dispute or
such type of disputes registered under section 66, before such submission is lawfully revoked;(h)in
cases where an industrial dispute has been referred to the arbitration ofa Labour Court or the
Industrial Court under sub-section (6) of section 58 or under section 71, or of the Industrial Court
under section 72, [73 or 73A] before the date on which the arbitration proceedings arc completed, or
the date on which the awards of the Labour or Industrial Court, as the case may be, comes into
operation, whichever is later;(i)in contravention of the terms of a registered agreement or a
settlement or [effective awards];[(j) where an industrial matter or industrial dispute is referred to a
Wage Board for decision, before the date on which the decision comes into operation;(k)in
contravention of the terms of an effective decision of a Wage Board.][(1A) Notwithstanding anything
contained in sub-section (1) a strike which is commenced or continued only for the reason that the
employer has not paid the basic pay or dearness allowance due to the employees within the period
fixed under any law for the time being in force or under a registered agreement or settlement or an
effective award or an effective decision of a Wage Board shall not be deemed to be illegal:Provided
that such strike shall be deemed to be illegal if-(i)it is commenced without seven clear days' notice
being given to the employer by the representative of employees, or(ii)it is commenced or continued
after the employer has paid basic pay or dearness allowance due to the employees.](2)In cases where
a conciliation proceeding in regard to any industrial dispute has been completed, a strike relating to
such dispute shall be illegal if it is commenced at any time after the expiry of two months after the
completion of such proceedings.(3)Notwithstanding anything contained in sub-sections (1) and (2),
if fourteen clear days' notice of a strike not falling under clause (a), (g), (h) or (i) of sub-section (1)
was given to the employer and the labour Officer, and the strike was not commenced either before
the expiry of the period of notice or after six weeks from the date of its expiry, the employees who
resume work within forty-eight hours of a Labour Court or the Industrial Court declaring such strike
to be illegal shall incur no penalty under this Act in respect of such strike:Provided that nothing in
sub-section (3) shall apply to any strike which has within the period of notice been declared under
section 99 to be illegal.
97A. Stoppage of work by employees in certain circumstances illegal. - [A
Stoppage shall be illegal if it is commenced or continued-Bombay Industrial Relations Act, 1946

(a)with the object of compelling the [Central or [State] government] or any public servant to take or
abstain from taking any particular course of action in regard to an industrial matter, where the
[Central or [State] Government] is not an employer in the industry concerned, or(b)if such stoppage
is in support of, or in sympathy with, a strike which is illegal under this Act or the Industrial
Disputes Act, 1947, (XIV of 1947.) or any other law for the time being in force, whether or not in the
same industry, occupation or undertaking.]
98. Illegal lock-outs. - (1) A lock-out shall be illegal if it is commenced or
continued-
(a)in cases where it relates to any industrial matter specified in Schedule III or regulated by any
standing order for the time being in force;(b)without giving notice in accordance with the provisions
of section 42;(c)in cases where notice of the change is given an accordance with the provisions of
section 42 and where no agreement in regard to such change is arrived at, before the statement of
the case referred to in section 54 is received by the conciliator for the industry concerned for the
local areas;(d)in cases where conciliation proceedings in respect of an industrial dispute to which a
lock-out relates have commenced before the completion of such proceedings [and during the period
of ten days thereafter];(e)in cases where a special intimation has been sent under sib-section (2) of
section 52 to the Conciliator, before the receipt of the intimation by the person to whom it is to be
given;(f)in cases where a submission relating to such dispute or such type of disputes is registered
under section 66, before such submission is lawfully revoked;(g)in cases where an industrial dispute
has been referred to the arbitration of a Labour Court or the Industrial Court under sub-section (6)
of section 58 or under section 71, or of the Industrial Court under section 72, [73 or 73A] before the
date on which the arbitration proceeding is completed or the date on which the award of the
Industrial Court comes into operation whichever is later;(h)in contravention of the terms of a
registered agreement or a settlement or [effective awards];[(i) where an industrial matter or
industrial dispute is referred to a Wage Board for decision, before the date on which the decision
comes into operation;(j)in contravention of the terms of an effective decision of a Wage Board.](2)In
cases where a conciliation proceeding in regard to any industrial dispute has been completed, a
lock-out relating to such dispute shall be illegal if it is commenced at any time after the expiry of two
months from the completion of such proceeding.(3)Notwithstanding anything contained in
sub-sections (1) and (2), if fourteen clear days' notice of a lock-out not falling under clause (a), (g),
(h) or (i) of sub-section (1) was given to the employees and the Labour Officer, and the lock-out was
not commenced either before the expiry of the period of notice or after six weeks from the date of its
expiry and the employer discontinues the lock-out to be illegal, the employer shall incur no penalty
under this Act in respect of such lock-out:Provided that nothing in this sub-section shall apply to
any lock-out which has within the period of notice been declared under section 99 to be illegal.
98A. Closure of work by employer in certain circumstances illegal. - [A
closure shall be illegal, if it is commenced or continued with the object of
compelling the [Central or [State] Government] or any public servant to take
or abstain from taking any particular course of action in regard to any
industrial matter.]Bombay Industrial Relations Act, 1946

99. Reference to Industrial Court for declaration whether strike, [lock-out,
closure of stoppage] is illegal. - (1) The [State] Government may make a
reference to the Industrial Court for a declaration whether any proposed
[strike, lock-out, closure or stoppage will be illegal],
(2)No declaration shall be made under this section save in open Court.[(3) The declaration made
under sub-section (1) shall be recognised as binding and shall be followed in all proceedings under
this Act.]
Chapter XV
Court Of Enquiry
100. Court of Enquiry; constitution, duties and powers of. - (1) The [State]
Government may constitute one or more Courts of Enquiry consisting of
such number of persons as the [State] government may think fit.
(2)A Court of Enquiry shall inquire into such industrial matters, as may be referred to it by the
[State] Government, including any matter pertaining to conditions of work or relations between
employers and employees in any industry, and any aspect of any industrial dispute.(3)Even
proceeding before a Court of Enquiry shall be deemed to be a judicial proceeding within the
meaning of sections 192, 193 and 228 of the Indian Penal Code. (XIV of 1860.)[(4) A copy of
Enquiry may refer to the Industrial Court any point of law arising in any proceeding before it under
this Act. Any finding of the Court of Enquiry in such proceeding shall be in accordance with the
decision of the Industrial Court on such point.]
Chapter XVI
Penalties
101. Employer not to dismiss, reduce or punish an employee. - (1) No
employer shall dismiss, discharge or reduce any employer or punish him in
any other manner by reason of the circumstance that the employee
(a)is an officer or member of a registered union or a union which has applied for being registered
under this Act; or(b)is entitled to the benefit of a registered agreement or a settlement, submission
or award; or(c)has appeared or intends to appear as a witness in, or has given any evidence or
intends to give evidence in [a proceeding under this Act or any other law for the time being in force]
[or takes part in any capacity in, or in connection with] a proceeding under this Act; or(d)is an
officer or member of an organisation the object of which is to secure better industrial conditions;
or(e)is an officer or member of an organisation which is not declared unlawful; or(f)is representativeBombay Industrial Relations Act, 1946

of employers; or(g)has gone on or joined a strike which has not been held by a Labour Court or the
Industrial Court to be illegal under the provisions of this Act.(2)No employer shall prevent any
employee from returning to work after a strike, arising out of an industrial dispute [***] which has
not been held by a Labour Court or the Industrial Court to be illegal unless-(i)the employer has
offered to refer the issue on which the employee has struck work to arbitration under this Act, and
the employee has refused arbitration; or(ii)the employee not having refused arbitration, has failed to
offer to resume work within one month of a declaration by the [State] Government that the strike
has ended.(3)Whoever contravenes the provisions of sub-section (1) or (2) shall, on conviction, be
punishable with fine which may extend to Rs. 5,000.(4)The Court trying an offence under this
section may direct that out of the fine recovered, such amount as it deems fit shall be paid to the
employee concerned as compensation.(5)In any prosecution under this section the burden of
proving that the dismissal, discharge, reduction or punishment of an employee by an employer was
not in contravention of the provisions of this section shall lie on the employer.
102. Penalty for declaring illegal lock-out [or illegal closure]. - Any employer
who has commenced a lock-out [or a closure] which a Labour Court holds or
the Industrial Court has declared to be illegal shall, on conviction be
punishable with fine which may extend to Rs. 2,500 and, in the case of the
lock-out [or the closure, as the case may be,] being continued after the lapse
of forty-eight hours after it has been held or declared to be illegal, with an
additional fine which may extend to Rs. 5,000 for every day during which
such lock-out [or closure] continues after such conviction.
103. Penalty for declaring or commencing illegal strike [or illegal stoppage.] -
Subject to the provisions of sub-section (3) section 97, any employee who
has gone on strike [or stoppage] or who joins a strike [or a stoppage] which
a Labour Court holds or the Industrial Court has declared to be illegal shall,
on conviction, be punishable with fine which may extend to Rs. 10 and, in the
case of his continuing on strike [or stoppage, as the case may be], after the
lapse of forty-eight hours after it is held or declared to be illegal, with an
additional fine which may extend to Rs.1 per day for every day during which
[such strike or stoppage continues after such conviction] subject to a
maximum of Rs. 50.
104. Penalty for instigating etc. illegal strikes [lock-outs, closures and
stoppages]. - Any person who instigates or incites others to take part in, or
otherwise acts in furtherance of a lock-out [or a closure], for which an
employer is punishable under section 102 or a strike [or a stoppage] for
which any employee is punishable under section 103, shall, on conviction, beBombay Industrial Relations Act, 1946

punishable with imprisonment of either description for a term which may
extend to three months, or with fine or with both:
Provided that no person shall be punished under this section where the Court trying the offence is of
opinion that in the circumstances of the case a reasonable doubt existed at the time of the
commission of the offence about the legality of the [strike, lock-out, closure or stoppage], as the case
may be.Explanation I - For the purposes of this section, a person who contributes, collects or solicits
funds for the purposes of any such [strike, lock-out, closure or stoppage] shall be deemed to act in
furtherance thereof.Explanation II - A person shall be deemed to have committed an offence under
this section if before an illegal [strike, lock-out, closure or stoppage] has commenced, he has
instigated or incited others to take part in, or otherwise acted in furtherance of such [strike,
lock-out, closure or stoppage].
105. Penalty for disclosing confidential information. - If a Conciliator, a
member of a Board or a Labour Officer or any person present at or
concerned in any conciliation proceeding wilfully discloses any information
or the contents of any document in contravention of the provisions of this
Act, he shall, on conviction, on a complaint made by the party who gave the
information or produced the document in such proceeding be punishable,
with fine which may extend to Rs. 1,000.
106. Penalty for illegal change. - (1) Any employer who makes an illegal
change shall, on conviction, be punishable with fine which may extend to Rs.
5,000.
(2)Any employer who contravenes the provisions of section 47 shall on conviction, be punishable
with imprisonment which may extend to three months, or for every day on which the contravention
continues with fine which may extend to Rs. 5,000, or with both.(3)The Court convicting any person
under sub-section (1) or (2i may direct such person to pay such compensation as it may determine to
any employee directly and adversely affected by the change in issue.
106A. Penalty for failure to appoint members on Joint Committee. - [Any
employer who fails to appoint members of a Joint Committee to be
constituted on an application made by the union within the period specified
in the order made under subsection (1) of section 49 shall, on conviction, be
punishable with fine which may extend to fifty rupees and in the case of a
continuing failure with an additional fine which may extend to fifty rupees for
every day during which such failure continues.]Bombay Industrial Relations Act, 1946

106B. Penalty for failure to nominate members on Council by employer. -
[Any employer who fails to nominate his representatives to be appointed as
members of the Council within the time limit specified for the constitution of
the Council under subsection (1) of section 53A shall, on conviction, be
punishable with fine which may extend to fifty rupees and in the case of a
continuing failure, with an additional fine which may extend to fifty rupees for
every day during which such failure continues.]
107. Penalty for contravention of a standing order. - Any employer who acts
in contravention [a model standing order notified and in operation under
subsection (5) of section 35 of] a standing order settled under Chapter VII
shall, on conviction, be punishable with fine which may extend to Rs. 500
and in the case of a continuing contravention of such standing order, with an
additional fine which may extend to Rs. 125 per day for every day during
which such contravention continues.
108. Penalty for obstructing person from carrying out duties. - Any person
who wilfully refuses entry to a Labour Officer or such Officer of an approved
union as is authorised under section 25 to any place which he is entitled to
enter, or fails to produce any document which he is required to produce or
fails to comply with any requisition or order issued to him by or under the
provisions of this Act or the rules made thereunder shall, on conviction, be
punishable with fine which may extend to Rs.500.
109. Penalties for offences not provided for elsewhere. - Whoever
contravenes any of the provisions of this Act or of any rule made thereunder
shall on conviction, if no other penalty is elsewhere provided by or under this
Act for such contravention be punishable with fine which may extend to Rs.
200.
110. Recovery of fines and compensation. - The amount of any fine imposed
and any compensation directed by any Court to be paid under this Act shall
be recoverable as arrears of land revenue.
Chapter XVII
Record Industrial ConditionsBombay Industrial Relations Act, 1946

111. Record of industrial matters, etc. - The [State] Government may in
respect of any industry-
(a)maintain in the prescribed manner a record of industrial matters covered by the
Schedules;(b)require any employer or employers generally to maintain and submit copies of a
record in such form as may be prescribed of-(i)data relating to plant, premises and
manufacture,(ii)other industrial transactions and dealings, which in the opinion of the [State]
Government are likely to affect the matters specified in clause (a).
112. Inquiry for verification of records. - (1) For the purpose of verifying the
accuracy of any records maintained by an employer under the provisions of
section 111, an officer authorised by the [State] Government may, subject to
the prescribed conditions hold an inquiry and may require any person to, and
such person thereupon shall, produce any relevant record or document in
his possession and may after reasonable notice, at any reasonable time enter
any premises wherein he believes such record or document to be, and may
ask any question necessary for verifying such records:
Provided that where such premises are not the usual business premises of person, such officer shall
not without the previous permission of the [State] Government enter them under this
sub-section.(2)Any proceedings held by him for the purpose of obtaining information for such
record shall be deemed to be a judicial proceeding within the meaning of section 192 of the Indian
Penal Code. (XIV of 1860.)
Chapter XVIII
Miscellaneous
113. Modification in Schedules. The [State] Government may, by notification
in the Official Gazette at any time, make any additions to or alterations in the
industrial matters specified in Schedule I, II or III or may delete therefrom any
such matter:
Provided that before making any such addition, alteration or deletion a draft of such addition,
alteration or deletion shall be published for the information of all persons likely to be affected
thereby and the [State] Government shall consider any objection or suggestion that may be received
by it from any person with respect thereto.Bombay Industrial Relations Act, 1946

113A. Dismissal of certain applications for want of prosecution. - [The
Registrar may, after giving fifteen days' notice, dismiss any application made
under section 13, 16, 17 or 23 if he is satisfied that the applicant union has
failed to purpose or prosecute the application, without any sufficient cause.]
114. Agreement, etc. on whom binding. - (1) A registered agreement, or a
settlement, submission or award shall be binding upon all persons who are
parties thereto:
Provided that-(a)in the case of an employer, who is a party to such agreement, settlement,
submission or award, his successors in interest, heirs or assigns in respect of the undertaking as
regards which the agreement, settlement, submission or award is made, and(b)in the case of a
registered union which is a party to such agreement, settlement, submission or award [all employees
in the industry in the local area whose representative, the said union is],shall be bound by such
agreement, settlement, submission or award.(2)In case in which a Representative Union is a party
to a registered agreement or settlement, submission or award, the [State] Government may, after
giving the parties affected an opportunity of being heard, by notification in the Official Gazette,
direct that such agreement, settlement, submission or award shall be binding upon such other
employers and employees in such industry or occupation in that local area [and with effect from
such date,] as may be specified in the notification:Provided that before giving a direction under this
section the [State] Government may, in such cases as it deems fit, make a reference to the Industrial
Court for its opinion.(3)A registered agreement entered into by the representatives of the majority of
the employees affected or deemed to be affected under section 43 by a change shall bind all the
employees so affected or deemed to be affected.
115. Order or decision [Wage Board or Labour Court] on whom binding. - An
order or decision of a [Wage Board or Labour Court] against an employer
shall bind his successors in interest, heirs and assigns in respect of the
undertaking as regards which it is made or given and such order or decision
against a registered union shall bind [all employees in the industry in the
local areas whose representative, the said union is].
115A. Order, decision or award to be in terms of agreement between
employer and Representative Union. - [If any agreement is arrived at between
an employer and a Representative Union who are parties to any industrial
dispute pending before an Arbitrator, Wage Board, Labour Court or Industrial
Court, the order, decision or award in such proceeding shall be made in
terms of such agreement, unless the Arbitrator, Wage Board, Labour Court or
Industrial Court, is satisfied that the agreement was in contravention of any
of the provisions of this Act or the consent of either party to it was caused byBombay Industrial Relations Act, 1946

mistake, misrepresentation, fraud, undue influence, coercion or threat.]
115B. Construction and interpretation of awards. - [Where any question
arises regarding the construction or interpretation of any award, any
employer or employee on whom such award is binding may-
(a)if the award was made by a Labour Court, Wage Board or Industrial Court, apply to the Court or
Board which made the award, and(b)if the award was made by any other arbitrator, apply to the
Industrial Court,for deciding the question. The Court or Board to which the application is made
may, after giving the parties concerned an opportunity of being heard, decide the question and such
decision shall be binding on the parties on whom the award is binding.]
116. Agreement etc., when to cease to have effect. - (1) A registered
agreement or a settlement or award shall cease to have effect on the date
specified therein or if no such date is specified therein, on the expiry of the
period of two months from the date on which notice in writing to terminate
such agreement, settlement or award as the case may be, is given in the
prescribed manner by any of the parties thereto the other party :
Provided that no such notice shall be given till the expiry of three months after the agreement,
settlement or award comes into operation.(2)Nothing in this section shall prevent the terms of a
registered agreement or a settlement [or an award in terms of an agreement] being changed or
modified by mutual consent of the parties affected thereby [and the registered agreement,
settlement or award shall be deemed to be changed or modified accordingly].(3)Notwithstanding
anything contained in sub-section (1) or (2), If a registered agreement or a settlement or award
provides that it shall remain in force for a period exceeding one year, it may after the expiry of one
year from the date of its commencement be terminated by either party thereto giving two months'
notice in the prescribed manner to the other party.(4)The party giving notice under sub-section (1)
or (3) shall send a copy of it to the Registrar and the Labour Officer of the Local area
concerned.[(4A) A notice given by a party under sub-section (1) or (3) may be withdrawn by it by a
subsequent notice given in writing in the prescribed manner before the expiry of two calendar
months from the date on which the previous notice was given. The party giving such subsequent
notice shall send a copy thereof to the Registrar and the Labour Officer of the Local area
concerned.](5)If a registered agreement, or a settlement or award is terminated under subsection (1)
or (3) or if the terms of a registered agreement, or a settlement [or an award] are changed or
modified by mutual consent, notice of such termination, change or modification shall be given by
the parties concerned to the Registrar and the Labour Officer. The Registrar shall enter the notice of
such termination, change or modification in a register kept for the purpose.Explanation. - For the
purposes of this section, parties who shall be competent to terminate a registered agreement or a
settlement or award, or to change or to modify the terms of a registered agreement or a settlement
[or an award] and who shall give notice of such termination, change or modification under
sub-section (5) shall be the employer who has signed the agreement or settlement or who is a partyBombay Industrial Relations Act, 1946

to the award or the heirs, successors or assigns of such employer in respect of the undertaking
concerned and the representative of the employees affected by the agreement, settlement or award.
116A. Modification of award. - [(1) Any party who under the provisions of
section 116 is entitled to, give notice of the termination of an award may
instead of giving such notice apply after the expiry of the period specified in
sub-section (2), to the Industrial Court, the Labour Court or the Wage Board
making the award, for its modification.
(2)Such application in the case of an award-(a)which does not specify a date on which it shall cease
to have effect shall be made until the expiry of the period of two months from the date on which
notice can be given to terminate the award under section 116;(b)which provides that it shall remain
in force for a period exceeding one year, shall not be made until the expiry of one year from the date
of its commencement.(3)On such application being made, the Industrial Court, the Labour Court
the Wage Board, as the case may be, may, after hearing the parties and taking such evidence as it
thinks fit, modify the award [with effect from such date as it may specify].(4)Where an application
for the Modification of an award under sub-section (1) is made, such application shall not in any way
affect the binding effect of such award in regard to the matters determined therein until it is
modified.(5)Nothing in this section shall affect the right of any part to terminate such award in
accordance with the provisions of section 116.]
117. Liability of the executive of a union. - Where anything is required to be
done by any union under this Act, the person authorised in this behalf by the
executive of the union, and where no person is so authorised every member
of the executive of the union, shall be bound to do the same and shall be
personally liable if default is made in the doing of any such thing.
Explanation. - For the purposes of this section, the executive of a union means the body by whatever
name called to which the management of the affairs of the union is entrusted.
118. Powers of certain authorities to summon witnesses etc. - (1) For the
purpose of holding an inquiry or proceeding under this Act, the Registrar, a
Conciliator, [a Wage Board], Board, Labour Court in its ordinary jurisdiction,
a Court of Enquiry and the Industrial Court shall have the same powers as
are vested in Courts in respect of-
(a)proof of facts by affidavits;(b)summoning and enforcing the attendance of any persons and
examining him on oath;(c)compelling the production of documents; and(d)issuing commissions for
the examination of witnesses.(2)The Registrar, a Conciliator, [a Wage Board] or Board shall also
have such further powers as may be prescribed.(3)For the purpose of obtaining the information
necessary for compiling and maintaining the record under Chapter XVII the officer authorisedBombay Industrial Relations Act, 1946

under section 112 shall have the powers specified in clauses (b) and (c) of sub-section (1) and in
sub-section (2).[(4) A Wage Board, a Labour Court and the Industrial Court shall also have powers
to call upon any of the parties to proceedings before it to furnish in writing and in such form as it
may think proper any information which it considers relevant for the purpose of any proceedings
before it and the party so called upon shall thereupon furnish the information to the best of his
knowledge and belief, and if so required by the Board or the Court to do so, verify the same in such
manner as may be prescribed.]
118A. Offences under section 104 cognizable. - [The offence under section
104 shall be cognizable.]
118B. Consequences of non-appearance of parties. - [(1) Where in any
proceeding before the Industrial Court or a Labour Court, if either party in
spite of notice of hearing having been duly served on it, does not appear
when the matter is called on for hearing, the Court may either adjourn the
hearing of the matter to a subsequent date or proceed ex-parte and make
such award, (2) Where any award, order or decision is made ex-parte under
sub-section (1) the aggrieved party may, within thirty days of the receipt of a
copy thereof, make an application to the Court, to set aside such award,
order or decision. If the Industrial Court or Labour Court is satisfied that
there was sufficient cause for non-appearance of the aggrieved party, it may
set aside the award, order or decision so made and shall appoint a date for
proceeding with the matter:
Provided that no award, order or decision shall be set aside on any such application as aforesaid,
unless notice thereof has been served on the opposite party.]
119. Certain officer to be public servants. - The Registrar, an Assistant
Registrar, a Conciliator, a Labour Officer, an Assistant Labour Officer, an
arbitrator [a member of a Wage Board], a member of a Board, an officer
authorised under section 112, a Judge of a Labour Court, a member of the
Industrial Court or a Court of Enquiry and a member of the staff of any of the
said Courts shall be deemed to be public servants within the meaning of
section 21 of the Indian Penal Code. (XLV of 1860.)
119A. Contempt of Industrial Court, Labour Courts and Wage Boards relating
to commission to produce documents, etc. - [(1) If any personal when
ordered by the Industrial Court or a Labour Court or a Wage Board to
produce or deliver up any document, [or to furnish any information], beingBombay Industrial Relations Act, 1946

legally bound intentionally omits to do so; or
(b)when required by the Industrial Court or a Labour Court or a Wage Board to bind himself by an
oath or affirmation to state the truth refuses to do so;(c)being legally bound to state the truth on any
subject to the Industrial Court or a Labour Court or a Wage Board refuses to answer any question
demanded of him touching such subject by such Court or Board; or(d)intentionally offers any insult
or causes any interruption to the Industrial Court or a Labour Court or a Wage Board at any stage of
its judicial proceeding, he shall, on conviction, be punishable with imprisonment for a term which
may extend to six months or with fine which may extend to one thousand rupees or with both.(2)If
any person refuses to sign any statement made by him when required to do so by the Industrial
Court or a Labour Court or a Wage Board, he shall, on conviction, be punishable with imprisonment
for a term which may extend to three months or with fine which may extend to five hundred rupees
or with both.(3)If any offence under sub-section (1) or (2) is committed in the view or presence of
the Industrial Court or a Labour Court or a Wage Board, as the case may be, such Court or Wage
Board, may after recording the facts constituting the offence and the statement of the accused as
provided in the Code of Criminal Procedure, 1898, (V of 1898.) forward the case to a magistrate
having jurisdiction to try the same and may require security to be given for the appearance of the
accused person before such magistrate or, if sufficient security is not given, shall forward such
person in custody to such magistrate. The magistrate to whom any case is so forwarded shall
proceed to hear the complaint against the accused person in the manner provided in the said Code
of Criminal Procedure.
119B. Other kinds of contempts of Industrial Court, Labour Courts and Wage
Boards. - (1) If any person commits any act or publishes any writing which is
calculated to improperly influence the Industrial Court, or a Labour Court or a
Wage Board or to bring such Court, Board, or a member or a Judge, thereof
into disrepute or contempt or to lower its or his authority, or to interfere with
the lawful process of any such Court or Board, such person shall be deemed
to be guilty of contempt of such Court or Board, as the case may be.
(2)In the case of contempt of itself the Industrial Court shall record the fact constituting such
contempt and make a report in that behalf to the High Court.(3)In the case of contempt of a Wage
Board or a Labour Court, such Board or Court shall record the facts constituting such contempt and
make a report in that behalf to the Industrial Court; and thereupon the Industrial Court may, if it
considers it expedient to do so, forward the report to the High Court.(4)When any intimation or
report in respect of any contempt is received by the High Court under sub-section (2) or (3) the High
Court shall deal with such contempt as if it were contempt of itself and shall have and exercise in
respect of it the same jurisdiction, powers and authority in accordance with the same procedure and
practice as it has and exercises in respect of contempt of itself.]Bombay Industrial Relations Act, 1946

119C. Power of Industrial Court, etc., to decide all connected matters. -
[Notwithstanding anything contained in this Act, the Industrial Court, a
Labour Court or a Wage Board, as the case may be, shall have the power to
decide all matters arising out of the industrial matter or dispute referred to it
for decision under any of the provisions of this Act.
119D. Power of Industrial Court, etc., to pass interim orders. - In any
proceeding before it under this Act, the Industrial Court, a Labour Court or a
Wage Board may pass such interim orders as it may consider just and
proper.
119E. Protection of action taken under this Act. - No suit, prosecution or
other legal proceeding shall lie against any person for anything which is in
good faith done or purported to be done under this Act.j
120. Provisions of Act VII of 1929 not to be affected. - Nothing in this Act
shall affect any of the provisions of the Trade Disputes Act, 1929 (VII of
1929.) and no conciliation or arbitration proceeding shall be held under this
Act relating to any matter or trade dispute which has been referred to and is
pending before a Court of Enquiry or Board of Conciliation under the said
Act.
120A. Provisions of Act XIV of 1947 not to be affected. - [Nothing in this Act
shall affect any of the provisions of the Industrial Disputes Act, 1947, (XIV of
1947.) and no proceeding shall be held under this Act relating to any matter
or dispute which has been referred to and is pending before a Board, a Court
for inquiry, a Labour Court or a Tribunal under the said Act.]]
121. Repeal of Bombay IX of 1934. -[The Bombay Trade Dispute Conciliation
Act, 1934 (Bombay IX of 1934.) is hereby repealed.]
122. Repeal of Bombay XXV of 1938. - The Bombay Industrial Disputes Act,
1938, (Bombay XXV of 1938.) is hereby repealed :
Provided that-(a)every appointment, order, rule, regulation, notification or notice made, issued or
given under the provisions of the Act so repealed shall, in so far as it is not inconsistent with the
provisions of this Act, be deemed, to have been made or issued under the provisions of this Act,
unless and until superseded by any appointment, order, rule, regulation, notification, or notice
made, issued or given under this Act;(b)any standing order settled, agreement registered, changesBombay Industrial Relations Act, 1946

which have come into operation, settlements recorded or registered, submissions registered, awards
made or orders passed by the Industrial Court, under the provisions of the Act so repealed shall be
deemed to have been settled, registered, to have come into operation, to have been recorded, made
or passed by the appropriate authority under the corresponding provisions of this Act;(c)any right,
privilege, obligation or liability acquired, accrued or incurred under the Act so repealed shall not be
affected and any investigation, legal proceeding or remedy in respect of any such right, privilege,
obligation or liability shall, so far as it is not inconsistent with the provisions of this Act, be made,
instituted and availed of as if the said Act had not been repealed and continues in operation;(d)any
proceedings pending before the Industrial Court, conciliation proceedings, or any proceedings
relating to the rail or offences punishable under the provisions of the Act so repealed shall be
continued and completed as if the said Act had not been repealed and continued in operation; and
any penalty imposed in such proceedings shall be recorded under the Act so repealed;(e)Registered
Union or Representative Union or a Qualified Union or other representatives elected, entitled to
appear or act as the representatives of employees under the Act so repealed shall, notwithstanding
the repeal of the said Act, continue to act as the representatives of employees in any proceeding
under this Act for a period of three months from the date on which this Act comes into force.
123. Rules. - (1) The [State] Government may by notification in the Official
Gazette make rules to carry out the purposes of this Act.
(2)In particular and without prejudice to the generality of the foregoing provision such rules may be
made for all or any of the following matters, namely:-(a)the authority to be prescribed under
sub-clause (c) of clause (14) of section 3;(b)the manner in which the panels representing the
interests of employers and employees shall be constituted and the manner in which vacancies in the
Board of Conciliation shall be filled up under section 7;(c)the qualifications for being eligible to be
appointed to preside over Labour Courts under section 9;(d)the form in which the registers of
unions and the approved list shall be maintained under section 12;(e)the form of application under
sub-sections (1), (2) and (3) of section 13;(f)the fee to be paid, and the form of certificate of
registration to be issued under section 14;(g)the fee to be paid under sub-section (1), [the form of
certificate of registration under sub-section (3)] and the manner of publication under sub-section
(4), of section 16;(h)the fee to be paid under sub-section (1) of section 17;(i)the dates on which and
the manner in which returns shall be submitted under section 19;(j)the manner of publication of
orders under section 21;(k)the manner of registration of a union for more local areas than one under
section 22;(l)the form of application under section 23;(m)the officers, [members of the office staff]
[and members of approved unions] to be authorised under section 25 and the manner in which and
the conditions subject to which the rights under that section shall be exercised;(n)the fees to be
prescribed under sub-section (6) of section 26;[(na) the procedure to be followed by the Registrar
for ascertaining membership of unions for the purposes of Chapter [III, IV and V];(nb)the manner
of submitting objections to such membership and the amount of deposit which the Registrar may
require to be made before entering upon the inquiry;(nc)the fine which may be imposed by the
Registrar for any frivolous or vexatious objections to membership;](o)the authority to be prescribed
under clause (b) of sub-section (2), and the manner of determining the representative of employers
under sub-section (3) of section 27;(p)the manner in which the person shall be elected under
sub-section (1) recalled under sub-section (4), the period for which and the manner in which theyBombay Industrial Relations Act, 1946

shall function and the manner in which vacancies shall be filled under sub-section (5), of section
28;(q)the manner of authorising a Qualified or Primary Union under clause (iii) of, the manner of
accepting the terms of an agreement for settlement under proviso. Secondly and the number of
representatives and the manner of their election under proviso. Thirdly to, section 30;(r)the
conditions subject to which the powers of entry and inspection shall be exercised under sub-section
(2) of section 34;(s)the manner of submission of draft standing orders under sub-section (1), and the
manner of consulting the representative of employees and other interests under sub-section (2) of
section 35;(t)the form of notice and the other persons to be prescribed under subsections (1) and (2)
and the manner of approach and the period to be prescribed under the proviso to sub-section (4) of
section 42;(u)the other persons to be prescribed under sub-section (3) of section 43;(v)the manner
of forwarding the memorandum of agreement under subsection (1) of section 44;(w)[the number of
members of a Joint Committee, the manner of nomination of members by the union and the
manner of giving copies of orders under sub-section (1), and] the appointment of the chairman and
the manner in which he shall perform his duties under sub-section (2) of section 49;(X)the manner
of conducting the proceedings of a Joint Committee under sub-section (2) of section 50;(y)the
manner in which the memorandum of agreement shall be forwarded under sub-section (1), the form
in which a special intimation shall be forwarded under sub-section (2), and the other persons to be
prescribed under sub-section (4) of section 52;[(y-a) the manner of constituting a Council and filling
of vacancies therein, the number of members of such Council, and the manner of electing the
representatives of employees under sub-section (1) of section 53A;(y-b) the other things which a
Council may do under clause (f) of sub-section (1) of section 53B;(y-c) the administrative functions
with which a Council shall be entrusted under sub-section (3) of section 53B;(y-d) matters relating
to which information shall be furnished to the Council by the employers under sub-section (4) of
section 53B;(y-e) the procedure to be followed by the Council in the discharge of its duties, under
sub-section (5) of section 53B;](z)the form in which the statement shall be forwarded under
sub-section (1) of section 54;(aa)the manner of holding conciliation proceedings under sub-section
(1) of section 56;(ab)the form in which the memorandum of settlement shall be drawn up and the
manner of its publication under sub-section (1) of section 58;(ac)the manner of giving notice under
sub-section (2) of section 59;(ad)the procedure to be followed by a Conciliator or Board under
sub-section (1) of section 60;(ae)the manner of publication of a submission under sub-section (3) of
section 66;(af)the modifications to be prescribed under sub-section (2) and manner of making the
employers parties to arbitration under sub-section (3) of section 72;(ag)the manner of publication
under sub-section (2) of section 74;(ah)the form and manner in which an application shall be made
under sub-section (2) of section 79;[(aha) the other industrial matters and disputes under
sub-section (1) of section 86C;(ahb)the rules of procedure to be followed by a Wage Board under
section 86E;](ai)the manner in which the record shall be maintained under section 111;(aj)the
conditions to be prescribed under sub-section (1) of section 112;(ak)the manner of giving notice
under section 116;(al)the further power of the Registrar, a Conciliator, [Wage Board] or Board under
sub-section (2), [and the manner of verifying information under sub-section (4) of section
118];(am)any other matter which is required to be or may be prescribed.(3)The rules made under
this section shall be subject to the condition of previous publication in the Official Gazette.[(4) All
rules made under this section shall be laid for not less than thirty days before the State Legislature
as soon as may be after they are made and shall be subject to such modifications as the State
Legislature may make during the session in which they are so laid or the session immediatelyBombay Industrial Relations Act, 1946

following.]
124. Delegation of powers. - [The State Government may by notification in the
Official Gazette direct that any power exercisable by it under this Act or rules
made thereunder shall in relation to such matters and subject to such
conditions if any, as may be specified in the direction be exercisable also by
such officer or authority [***] as may be specified in the notification.]
I
(Section 35)
1. Classification of employees, e.g. permanent, temporary, apprentices,
probationers, badlis, etc.
1A. [Employee's tickets, cards, registers and service certificates.]
2. Manner of notification to employees of periods and hours of work,
holidays, pay days and wage rates.
3. [Shift working including notice] to be given to employees of starting
alteration or discontinuance of two or more shifts in a department or
departments.
4. Closure or reopening of a department or a section of a department or the
whole of the undertaking.
5. Attendance and late coming.
[6. Procedure and authority to grant leave.
7. Procedure and authority to grant holidays.]
8. Liability to search and entry into premises by certain gates.
9. Temporary [closures] of work including playing off, and rights and
liabilities of employers and employees arising therefrom.Bombay Industrial Relations Act, 1946

10. Termination of [employment. including notice] to be given by employer
and employee.
11. [Punishment including warning censure, fine, suspension or] dismissal
for misconduct, suspension pending inquiry into alleged misconduct and the
acts or omissions which constitute misconduct.
12. Means of redress for employees against unfair treatment or wrongful
exaction on the part of the employer or his agent or servant.
[13. Age for retirement or superannuation.]
II.
(Section 42)
1. Reduction intended to be of permanent or semi-permanent character in the
number of [posts or persons] employed or to be employed in any occupation
or process or department or departments or in a shift not due to force
majeure.
2. Permanent or semi-permanent increase in the number of persons
employed or to be employed in any occupation or process or department or
departments.
3. Dismissal of any employee except as provided for in the standing orders
applicable under this Act.
4. Rationalisation or other efficiency systems of work whether by way of
experiment or otherwise]
[4A. Permanent or Semi-permanent increase in the work load of a person or person employed or to
be employed in any operation or occupation or process or department.][5. All matters pertaining to
shift working which are not covered by the standing orders applicable under this Act.]
6. Withdrawal of recognition to unions of employees.
7. Withdrawal of any customary concession or privilege or change in usage.Bombay Industrial Relations Act, 1946

8. Introduction of new rules of discipline or alteration of existing rules and
their interpretation, except in so far as they are provided for in the standing
orders applicable under this Act.
9. Wages including the period and mode of payment.
10. Hours of work and rest intervals.
[11. All matters pertaining to leave and holidays other than those specified in items 6 and 7 in
Schedule I].
III.
(Section 42)(1)Adequacy and quality of materials and equipment supplied to the
workers.(2)Assignment of work and transfer of workers within the establishment.(3)Health, safety
and welfare of employees (including water, dining sheds, rest sheds, latrines, urinals, creches,
restaurants and such other amenities).(4)Matters relating to trade union organisation, membership
and levies.(5)Construction and interpretation of [***] agreements and settlements.(6)Employment
including-(i)reinstatement and recruitment;(ii)unemployment of persons previously employed in
the industry concerned.[(7) Payment of compensation for-(i)closures,(ii)loss of earnings due to
inadequate or bad quality of materials and equipment supplied to the workers.]Bombay Industrial Relations Act, 1946

