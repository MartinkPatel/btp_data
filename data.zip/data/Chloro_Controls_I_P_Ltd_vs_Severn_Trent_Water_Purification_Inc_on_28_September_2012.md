Chloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc
... on 28 September, 2012
Author: Swatanter Kumar
Bench: Swatanter Kumar, A.K.Patnaik, S.H.Kapadia
                                                                             REPORTABLE
                        IN THE SUPREME COURT OF INDIA
                        CIVIL APPELLATE JURISDICTION
                   CIVIL APPEAL NO.   7134         OF 2012
                  (Arising out of SLP (C) No.8950 of 2010)
      Chloro Controls (I) P. Ltd.                      … Appellant
                                   Versus
      Severn Trent Water Purification Inc. & Ors.      … Respondents
                                    WITH
         CIVIL APPEAL NOS.      7135-7136                    OF 2012
               (Arising out of SLP (C) No.26514-26515 of 2011)
                              J U D G M E N  T
      Swatanter Kumar, J.Chloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      1.    Leave granted.
      2.    The expanding need for international arbitration  and  divergent
      schools of thought, have provided new dimensions  to  the  arbitration
      jurisprudence in the international field.   The  present  case  is  an
      ideal example of invocation of arbitral reference in multiple,  multi-
      party agreements with intrinsically interlinked causes of action, more
      so,  where  performance  of  ancillary  agreements  is   substantially
      dependent upon effective execution of the  principal  agreement.   The
      distinguished learned counsel appearing for the  parties  have  raised
      critical questions of law relatable to the facts of the  present  case
      which in the opinion of the Court are as follows :
      (1)   What is the ambit and scope of Section 45 of the Arbitration and
           Conciliation Act, 1996 (for short ‘the 1996 Act’)?
      (2)   Whether  the  principles  enunciated  in  the  case  of  Sukanya
           Holdings Pvt. Ltd. v. Jayesh H. Pandya [(2003) 5  SCC  531],  is
           the correct exposition of law?
      (3)   Whether in a case where multiple agreements are  signed  between
           different parties and where some contain an  arbitration  clause
           and others don’t and further the  parties  are  not  identically
           common in proceedings before the  Court  (in  a  suit)  and  the
           arbitration agreement, a reference of disputes as a whole or  in
           part can be made to the arbitral  tribunal,  more  particularly,
           where the parties to an action are claiming under or  through  a
           party to the arbitration agreement?
      (4)   Whether bifurcation or splitting of parties or causes of  action
           would be permissible, in absence of any specific  provision  for
           the same, in the 1996 Act?
      3.    Chloro Controls (India)  Private  Ltd.,  the  appellant  herein,
      filed a suit on the original side of the High Court  of  Bombay  being
      Suit No.233 of 2004, for declaration that the joint venture agreements
      and supplementary collaboration agreement entered into between some of
      the parties are valid, subsisting  and  binding.   It  also  sought  a
      direction that the scope of business of  the  joint  venture  company,
      Respondent No. 5, set  up  under  the  said  agreements  includes  the
      manufacture, sale, distribution and service of  the  entire  range  of
      chlorination equipments including the  electro-chlorination  equipment
      and claimed certain other reliefs as well, against the  defendants  in
      that suit. The said parties took out  two  notices  of  motion,  being
      Notice of Motion No.553 of 2004 prior to and Notice of Motion  No.2382
      of 2004 subsequent to the amendment of the plaint.  In  these  notices
      of motion, the principal question that fell for consideration  of  the
      learned Single Judge of the High Court was whether the  joint  venture
      agreements between  the  parties  related  only  to  gas  chlorinationChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      equipment or whether they included electro-chlorination  equipment  as
      well.  The applicant had prayed for an order of restraint,  preventing
      Respondent Nos. 1 and 2, the foreign collaborators, from  acting  upon
      their notice dated 23rd January, 2004, indicating termination  of  the
      joint  venture  agreements   and   the   supplementary   collaboration
      agreement.  A further prayer was made for grant of injunction  against
      committing breach of contract by directly or indirectly  dealing  with
      any person other than the Respondent No.5, in any  manner  whatsoever,
      for  the  manufacture,  sale,  distribution   or   services   of   the
      chlorination  equipment,  machinery  parts,  accessories  and  related
      equipments including  electro-chlorination  equipment,  in  India  and
      other countries covered by the agreement.  The defendants in that suit
      had taken out another Notice of Motion No.778 of 2004, under Section 8
      read with Section 5 of the1996 claiming that  arbitration  clauses  in
      some of the agreements governed all the joint venture agreements  and,
      therefore, the suit should be  referred  to  an  appropriate  arbitral
      tribunal for final disposal and until a final award  was  made  by  an
      arbitral tribunal, the proceedings in the suit should be stayed.   The
      learned Single Judge, vide order dated 28th  December,  2004,  allowed
      Notice of Motion No.553 of 2004 and consequently disposed of Notice of
      Motion No.2382 of 2004 as not surviving. Against this order, an appeal
      was preferred, which came to be registered as Appeal No.24 of 2005 and
      vide a detailed judgment dated 28th July, 2011, a  Division  Bench  of
      the High Court of Bombay set aside the order  of  the  learned  Single
      Judge and dismissed both the  notices  of  motion  taken  out  by  the
      plaintiff in the suit.
      4.    Notice of Motion No.778 of 2004 was dismissed by another learned
      Single Judge of the High Court of Bombay, declining the  reference  of
      the suit to an arbitral tribunal vide order  dated  8th  April,  2004.
      This order was again assailed in appeal by the defendants in the  suit
      and another Division Bench of the Bombay High Court, vide its judgment
      dated 4th March, 2010, allowed the Notice of Motion No.778 of 2004 and
      made reference to arbitration under Section 45 of the 1996 Act.
      5.    The judgments of the Division Benches, dated 4th March, 2010 and
      28th July, 2011, respectively, have been assailed  by  the  respective
      parties before this Court in  the  present  Special  Leave  Petitions,
      being SLP(C) No.8950/2010 and SLP(C)  No.26514-15/2011,  respectively.
      Thus, both these appeals shall be disposed of by this common judgment.
      6.    Before we notice in detail the factual matrix giving rise to the
      present appeals and the contentions raised, it would be appropriate to
      illustrate the corporate structure of the companies and the  scope  of
      the agreements  that  were  executed  between  the  parties  to  these
      proceedings.
      Corporate Structure of the Companies who are parties to lis
      7.    In order to describe the corporate structure with  precision  we
      will explain it diagrammatically as follows:
                           SEVERN TRENT (DEL) INC.Chloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

     Formerly known as SEVEREN TRENT U.S. INC.; Name Changed in May 1992
                      SEVERN TRENT SERVICES (DEL) INC.
R-1 – CAPITAL CONTROL CO. INC.
Acquired 80% on 15.05.1990 and 20% on 31.03.1994.
NAME CHANGED ON 1.4.2002 TO
SEVERN TRENT WATER PURIFICATION INC.
(GAS CHLO. & HYPOGEN Product Lines)
R-2 - CAPITAL CONTROL
(DELAWARE) CO. INC.
Formed on 21.09.94
EXCEL TECHNOLOGIES
INT’L CORP.
Acquired in 1998
Original OMNIPURE and
SANILEC Manufacturer
Appellant
CHLORO CONTROL
INDIA PVT. LTD.
               MERGED INTO
                                     ON 31.03.2003
            Shareholders Agreement   JV
CAPITAL CONTROL (INDIA) PVT LTD.
(ON 14.11.1995 a new Joint Venture)
R-5 - GAS CHLORINATORS & HYPOGEN
      Distributorship
and Knowhow
Agreement
ODN,Chloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

B.V.
   DENORA NORTH AMERICA, INC.
GROUPO DE NORA
Original Seaclor and Seaclor Mac Manufacturer
                                JV
SERVEN TRENT DE NORA LLC – SEPT, 2001
PRODUCTS CURRENTLY OFFERED ARE OMNIPURE,
SANILE 7 SEACLOR
R-3 – TITANOR
COMPONENTS LTD.
Distributes SEACLOR MAC
Product Line
R-4 – HI POINT SERVICES PVT LTD
OMNIPURE, SANILEC
Before 1998
Independent Distributor of EXCEL TECHNOLOGIES since prior to Severn Trent’s
Acquisition of EXCEL TECHNOLOGIES
Currently, Independent Distributor for SEVERN TRENT DENORA
Distributes Omnipure and Sanilec Products in India
      8.    Severn Trent, U.S., Inc. was a company existing under  the  laws
      of the State of Pennsylvania, United States  of  America  (for  short,
      ‘U.S.A.’).   This name came to be changed, in 1992,  to  Severn  Trent
      (Delaware) Inc., which is the principal parent company.   This company
      owned a 100 per cent  subsidiary,  Severn  Trent  Services  (Delaware)
      Inc., U.S.A.   Severn Trent Services  (Delaware)  Inc.  owned  Capital
      Control (Delaware) Co. Inc. which was formed on 21st September,  1994.
       On or about 14th May, 1990,  Severn  Trent  Services  PLC,  U.K.,  an
      erstwhile state-owned water authority, privatized  in  1989,  expanded
      its business into the U.S.A.  by  acquiring  80  per  cent  shares  in
      Capital Control Co. Inc. on 15th May 1990  and a further 20  per  cent
      on 31st March 1994. It is  in  this  period  that  the  joint  venture
      agreements with the appellant were negotiated, with the consent of the
      Severn Trent group, which was, by that time, a majority shareholder in
      Capital Control Co. Inc.  Subsequently, the name  of  Capital  Control
      Co. Inc.,  was  changed  to  Severn  Trent  Water  Purification,  Inc.
      (Respondent No.1), with effect from 1st April, 2002. The Severn  TrentChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      Water Purification Inc./Capital Control  Co.  Inc.  then  came  to  be
      merged with Capital Control (Delaware) Co. Inc. (Respondent No. 2), on
      31st March, 2003.   As a result thereof,  Capital  Control  (Delaware)
      Co. Inc. ceased to exist.   As  per  the  pleadings  of  the  parties,
      reference to Capital Control Co. Inc. includes  reference  to  Capital
      Control Co. Inc. as well as Capital Control (Delaware) Co. Inc.
      9.     The appellant is a company carrying on business under that name
      and  style  for  the  manufacture  of  chlorination   equipments   and
      incorporated under the Indian laws  by  Madhusudan  Kocha  (Respondent
      No.9 herein) and his group  (for  short,  the  “Kocha  Group”).   This
      company had been negotiating with Respondent No. 1 for entering into a
      joint venture agreement, to deal with  the  manufacture,  distribution
      and  sale  of  gas  chlorination  equipment  and  “Hypogen”   electro-
      chlorination equipment Series 3300, etc.   This led to  the  execution
      of joint venture agreements between the appellant and  Respondent  No.
      1.   The joint venture agreements were signed between these  companies
      for constituting a joint venture company under the name and  style  of
      Capital Control (India) Pvt. Ltd., with 1,50,000 equity shares of  Rs.
      10 each and 50 per cent shareholding with each party. These agreements
      being prior to the merger of Capital Control (Delaware) Co. Inc.  with
      Capital Control Co. Inc. and also prior  to  the  change  of  name  of
      Capital Control Co. Inc. to Severn Trent Water Purification  Inc.,  50
      per cent of the shares allotted to the foreign collaborators  were  to
      be equally divided between Capital Control  (Delaware)  Co.  Inc.  and
      Capital Control Co. Inc.  These joint venture agreements were executed
      between the parties  on  16th  November,  1995,  as  already  noticed.
      However, the joint venture  company  had  been  incorporated  on  14th
      November, 1995 itself.
      10.   In the year 1998, Excel Technologies  International  Corporation
      came to be acquired by Severn Trent Services (Delaware)  Inc.     This
      company was dealing in the manufacture of  “Omnipure”  and  “Sanilec”,
      distinct brands of chlorination products.   Later, Excel  Technologies
      entered into a joint venture agreement with De Nora North America Inc.
      and floated another joint venture company, Severn Trent De Nora LLC in
      September, 2001 for dealing in the products “Omnipure”, “Sanilec”  and
      “Seaclor Mac”.  It may be noticed that “Seaclor  Mac”  was  a  product
      dealt with and distributed  by  Titanor  Components  Ltd.,  Respondent
      no.3, and whose original manufacturer was Groupo De Nora;  the  latter
      is  the  parent  company  of  the  De  nora  North  America  Inc.  The
      distribution rights in respect of all these three products were  given
      by the joint venture company Severn Trent De  Nora  LLC  to  Hi  Point
      Services Pvt. Ltd., Respondent No. 4, for independent distribution  of
      the products for Severn Trent De nora LLC, in India.
      11.   This corporate structure clearly  indicates  that  Severn  Trent
      Services (Del.) Inc. is the holding company  of  the  companies  which
      have entered into the joint venture agreements, for floating both  the
      companies Capital Controls (India) Pvt. Ltd., as well as “Severn Trent
      De Nora  LLC”.  The  disputes  have  actually  arisen  between  Chloro
      Controls (India) Pvt. Ltd. and the Kocha Group on the  one  hand,  and
      Severn Trent Water Purification Inc., the  erstwhile  Capital  ControlChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      (Delaware) Co. Inc. and Capital Control Co. Inc. on the other.
                            Details of Agreements
|S.  |Date of    |Details of    |Parties to the Agreement  |Whether   |
|No  |Agreement  |Agreement     |                          |contains  |
|    |           |              |                          |arbitratio|
|    |           |              |                          |n clause  |
|1.  |16.11.1995 |Shareholders  |1.  Capital Controls      |Yes       |
|    |           |Agreement     |(Delware) Company, Inc.   |          |
|    |           |              |(Respondent No.2)         |          |
|    |           |              |2.  Chloro Controls India |          |
|    |           |              |Pvt. Ltd. (Appellant)     |          |
|    |           |              |3.  Mr. M.B. Kocha        |          |
|    |           |              |(Respondent No.9)         |          |
|2.  |16.11.1995 |International |1.  Capital Controls      |No        |
|    |           |Distributor   |Company Inc., (Colmar) now|          |
|    |           |Agreement     |Severn Trent Water        |          |
|    |           |              |Purification Inc.         |          |
|    |           |              |(Respondent No.1)         |          |
|    |           |              |2. Capital Controls       |          |
|    |           |              |(India) Private Ltd.      |          |
|    |           |              |(Respondent No.5)         |          |
|3.  |16.11.1995 |Managing      |1. Capital Controls       |No        |
|    |           |Directors’    |(India) Private Ltd.      |          |
|    |           |Agreement     |(Respondent No.5)         |          |
|    |           |              |2.  Mr. M.B. Kocha        |          |
|    |           |              |(Respondent No.9)         |          |
|4.  |16.11.1995 |Financial &   |1.  Capital Controls      |Yes       |
|    |           |Technical     |Company Inc., (Colmar) now|          |
|    |           |Know-how      |Severn Trent Water        |          |
|    |           |License       |Purification Inc.         |          |
|    |           |Agreement     |(Respondent No.1)         |          |
|    |           |              |2. Capital Controls       |          |
|    |           |              |(India) Private Ltd.      |          |
|    |           |              |(Respondent No.5)         |          |
|5.  |16.11.1995 |Export Sales  |1.  Capital Controls      |Yes       |
|    |           |Agreement     |Company Inc., (Colmar) now|          |
|    |           |              |Severn Trent Water        |          |
|    |           |              |Purification Inc.         |          |
|    |           |              |(Respondent No.1)         |          |
|    |           |              |2. Capital Controls       |          |
|    |           |              |(India) Private Ltd.      |          |
|    |           |              |(Respondent No.5)         |          |
|6.  |16.11.1995 |Trademark     |1.  Capital Controls      |No        |
|    |           |Registered    |Company Inc., (Colmar) now|          |
|    |           |User License  |Severn Trent Water        |          |
|    |           |Agreement     |Purification Inc.         |          |
|    |           |              |(Respondent No.1)         |          |
|    |           |              |2. Capital Controls       |          |
|    |           |              |(India) Private Ltd.      |          |
|    |           |              |(Respondent No.5)         |          |Chloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

|7.  |August 1997|Suppleme-ntary|1.  Capital Controls      |          |
|    |           |Collaboration |Company Inc., (Colmar) now|          |
|    |           |Agreement     |Severn Trent Water        |          |
|    |           |              |Purification Inc.         |          |
|    |           |              |(Respondent No.1)         |          |
|    |           |              |2. Capital Controls       |          |
|    |           |              |(India) Private Ltd.      |          |
|    |           |              |(Respondent No.5)         |          |
      Facts
      12.   Prior to the formation of the joint venture company, the  Chloro
      Controls Group carried on the business of manufacture and sale of  gas
      chlorination equipments  and  from  1980  onwards,  it  developed  and
      commenced the manufacturing of  electro-chlorination  equipment  also.
      The business was done in  the  name  of  “Chloro  Controls  Equipments
      Company”, a sole proprietary concern  of  Respondent  No.9,  Mr.  M.B.
      Kocha and it was the distributor in India  for  the  products  of  the
      Capital Controls group for more than a decade prior to  the  formation
      of the joint venture.  On 1st December, 1988, a letter of intent and a
      letter of understanding were executed between Capital Controls Company
      Inc., Colmar, Pennsylvania, U.S.A (which name was subsequently changed
      in the year 2002 to ‘Severn Trent Water Purification Inc.,  respondent
      No.1) and respondent no.9 to form  a  new,  jointly-owned  company  in
      India,  to  be  called  “Capital  Controls  (India)  Pvt.  Ltd.”,  the
      respondent  No.5  in  the  present  appeals,  for  the   purposes   of
      manufacture, sale and export of chlorination equipments on  the  terms
      and conditions as agreed between the parties.  The  formation  of  the
      joint venture company got delayed for some  time,  because  Respondent
      No.1 informed the appellant that Severn Trent, U.K. and  the  officers
      of the Capital Controls Company Inc., Colmar, Pennsylvania, U.S.A. had
      acquired all the shares of the Capital Controls Company Inc. and  this
      share acquisition permitted them to support their representatives  and
      distributers with continuity.   On  14th  November,  1995,  the  joint
      venture company, Capital Controls (India) Private Ltd., Respondent No.
      5, was incorporated and registered under the Companies Act, 1956  (for
      short, the ‘Companies Act’).
      13.   To examine the  factual  matrix  of  the  case  in  its  correct
      perspective,  reference  to  pleadings  of  the   parties   would   be
      appropriate.
      14.   The petitioner is a Private Limited Company and its  shares  are
      entirely  held  by  Respondent/Defendant  Nos.9  to  11  (Kocha/Chloro
      Control Group).  Respondent No.1–Company was earlier known as “Capital
      Control Company Inc.” and in  or  about  the  year  1990  the  Capital
      Controls Group came to be acquired by Severn Trent Services PLC  (UK),
      originally a State owned water authority and  following  privatization
      from the UK Government in 1989, it proceeded to build  a  product  and
      services business from the US beginning with the  acquisition  of  the
      Capital Controls Group.  The name of the first respondent was  changed
      to Severn Trent Water Purification Inc. with effect  from  1st  April,Chloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      2002.  Thus, Respondent Nos.1 and 2 became  the  group  companies  and
      were  earlier  part  of  “the  Capital  Controls  Group”  (hereinafter
      referred to as the Capital Controls/Severn Trent Group).  Till January
      1999,  the  respondent  Nos.1  and  2  developed  and  sold   electro-
      chlorination equipment under the brand name “Hypogen” and from January
      1999 onwards, the said brand was replaced by the brands “Sanilec”  and
      “Omnipure”.  Respondent  Nos.1  and  2  carried  on  the  business  of
      manufacture, supply, sale and distribution of chlorination equipments,
      including gas and electro-chlorination equipments.  Respondent No.3 is
      a company incorporated under the Companies  Act  and  engaged  in  the
      business  of  manufacture  and   marketing   of   electro-chlorination
      equipment.  In or about the year 1989-90, the said Respondent no.3 was
      floated as a joint venture in technical  and  financial  collaboration
      with the De Nora group of Italy which held 51%  of  the  equity  share
      capital of the said respondent.  Respondent No.4 is a Private  Limited
      Company incorporated under the Companies Act and carried  on  business
      in electro-chlorination equipments.  It had a tie-up with an  American
      Company called  “Excel  Technologies  International  Inc.”  which  was
      engaged in the business of electrolytic disinfection equipment.
      15.   Respondent No.5, i.e., Capital Controls (India) Private Ltd.  is
      a Company incorporated under the Companies Act pursuant to  the  joint
      venture agreements dated 16th  November,  1995  executed  between  the
      appellant and respondent no.9 on the one hand and the respondent nos.1
      and 2 on the other. 50 per cent of the  share  capital  of  Respondent
      No.5 is held by the appellant and balance of 50 per cent  is  held  by
      Respondent No.2.  Thus, the appellant  and  Respondent  No.2  are  the
      joint venture partners who have together incorporated  the  Respondent
      No.5 – company.
      16.   Respondent Nos.6 and 8 are the Directors of the Respondent  No.5
      Company, appointed as such by the Capital Controls  Group.  Respondent
      No.7 is the Chairman also appointed by the Capital Controls Group, but
      has no casting vote.  Respondent Nos.9 to 11 are the Directors of  the
      Respondent no.5 company, nominated by the Kocha Group/Chloro  Controls
      Group and Respondent No.9 is the Managing Director of the  said  joint
      venture.
      17.   It appears that the joint venture company, Respondent no.5,  was
      incorporated on 14th November, 1995. As  discussed  above,  the  joint
      venture agreements were primarily a project between Respondent Nos.  1
      and 2 on the one  hand  and  the  appellant  company  along  with  its
      proprietor, Respondent No. 9, on the other.    The  purpose  of  these
      joint venture agreements as indicated in the Memorandum of Association
      of this joint venture company  was  to  design,  manufacture,  import,
      export, act as agent, marketing etc. of gas  and  electro-chlorination
      equipments.   In order to achieve this object, the parties had decided
      to execute various agreements.   It needs to  be  emphasized  at  this
      stage itself that, as is clear from  the  above  narrated  chart,  the
      agreements had been signed between different parties,  each  agreement
      containing somewhat different clauses. Therefore, there is a  need  to
      examine the content and effect of each of the  seven  agreements  that
      are stated to have been signed between different parties.Chloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      Content, scope and purpose of the agreements  subject  matter  of  the
      present appeals
      18.   The parties to the proceedings, except respondent Nos. 3 and  4,
      were parties to one or more  of  the  seven  agreements  entered  into
      between the parties.  This includes the Principal Agreement, i.e., the
      Shareholders Agreement, the Financial and Technical  Know-how  License
      Agreement, the  International  Distributor  Agreement,  Exports  Sales
      Agreement, Trademark Registered User License  Agreement  and  Managing
      Director’s Agreement, all dated  16th  November,  1995.   Lastly,  the
      parties also entered into and executed a  Supplementary  Collaboration
      Agreement in August,  1997.   We  have  already  noticed  that  except
      respondent Nos.3 and 4 who were not signatory to  any  agreement,  all
      other parties were not parties to all the agreements  but  had  signed
      one or more agreement(s) keeping in mind the content  and  purpose  of
      that agreement.
      19.   Now we shall proceed to discuss each of these agreements.
      Share Holders Agreement
      20.   The Shareholders Agreement dated 16th November, 1995 was entered
      into and executed between the Capital  Control  (Delaware)  Co.  Inc.,
      respondent No. 2, on the one hand and Chloro Controls (India)  Private
      Ltd., the appellant company run by the Kocha/ Capital  Controls  group
      and Mr. M.B. Kocha, respondent No. 9, on the other.   As  is  apparent
      from the pleadings on record, these  two  groups  had  negotiated  for
      starting a joint venture company in India and for  this  purpose  they
      had entered into the Shareholders Agreement.  The main object of  this
      agreement was  to  float  a  joint  venture  company  which  would  be
      responsible for manufacture, sale and  services  of  the  products  as
      defined in the Financial & Technical Know-How  License  Agreement,  in
      terms of clause 1 of the Agreement.   The  Agreement  was  subject  to
      obtaining all necessary approvals, licenses and authorization from the
      Government of India, as the joint venture company under the  name  and
      style of Capital Control India Pvt. Ltd. was to  be  registered  as  a
      company with its office located in India at Bombay and to carry on its
      business in India.  The plant was to be taken on  lease.   As  already
      noticed, the authorized capital  of  the  company  was  Rs.5  million,
      consisting of equity shares of Rs.10 each.   In  terms  of  clause  7,
      Capital Controls,  which  was  the  short  form  for  Capital  Control
      (Delaware)  Co.  Inc.,  appointed  the  joint  venture  company  as  a
      distributor in India of the products manufactured by  it,  subject  to
      the terms and conditions of the  International  Distributor  Agreement
      attached to that Agreement as Appendix II.   Directors  to  the  joint
      venture company were to be nominated for a period of  three  years  in
      accordance with  clause  8  of  the  Agreement.   Clause  14  made  it
      obligatory for the parties to ensure that the  joint  venture  companyChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      entered into the Financial and Technical  Know-How  License  Agreement
      with Capital Controls, subject to which, as mentioned above, the joint
      venture company was to have the right and license to  manufacture  the
      specified products in India.  The  Financial  and  Technical  Know-How
      License Agreement, which was annexed to  the  Principal  Agreement  as
      Appendix IV, was to be executed  relating  to  sale  and  purchase  of
      chlorination equipment assets.  This Agreement had to be construed and
      interpreted in accordance with the laws of the Union of India in terms
      of clause 29.  Further  clause  21  related  to  termination  of  this
      Principal Agreement.   In terms of this clause, it was agreed that the
      Agreement was to continue in force and effect  for  so  long  as  each
      party held not less than twenty-six per cent (26%) of the total  paid-
      up equity shares of the company or  in  the  event  that  the  company
      failed to achieve a cumulative sales volume  of  Rs.120  million  over
      three years and cumulative profit of fifteen per cent (15%) over three
      years from signing of the Agreement.  Either party had the  option  to
      terminate the agreement and dispose of the shares as provided  in  the
      terms thereof.   Material  breach  of  the  Agreement  or  a  deadlock
      regarding  the  management  of  the  Company  were,  inter  alia,  the
      contemplated grounds for termination of  the  Agreement,  whereby  the
      party not in default could terminate the Agreement by giving notice in
      writing to the other party. The period of notice in  the  event  of  a
      material breach was 90 days from the date of such notice.  Clause 21.3
      provided that in the event of the termination of  the  Agreement,  the
      joint venture company would be wound up and all obligations undertaken
      by  Chloro  Controls  under  different  agreements  would  cease  with
      immediate effect.  In such an eventuality, even the name of the  joint
      venture company was required to be changed  and  the  word  ‘Capital’,
      either individually or in combination with  other  words,  was  to  be
      removed.
      21.   Two other very material clauses of this Agreement, which require
      the attention of this Court, are clauses 4 and 30.  In terms of clause
      4.5, the Kocha Group and their company Chloro Controls were bound  not
      to engage themselves, directly or indirectly, or even  have  financial
      interest in the manufacture,  sale  or  distribution  of  chlorination
      equipment which were  similar  to  those  manufactured  by  the  joint
      venture company during the term of the Agreement.  In terms of  clause
      30, all or any disputes or differences arising under or in  connection
      with the Agreement between the parties were liable to  be  settled  by
      arbitration,  in  accordance  with  the  Rules  of  Conciliation   and
      Arbitration of the International Chamber of Commerce (for  short,  the
      ‘ICC’), by three  arbitrators  designated  in  conformity  with  those
      Rules. The arbitration proceedings were to be held in London,  England
      and were to be governed by and subject to English laws.
      22.   As is  clear  from  the  above  terms  and  conditions  of  this
      Agreement, it was treated as a principal  agreement  executed  between
      the parties and other agreements, like the Financial & Technical Know-
      How License Agreement, Trademark Registered  User  License  Agreement,
      International Distributor Agreement, Managing Directors’ Agreement andChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      Export Sales Agreements were not the only  anticipated  agreements  to
      be executed between  the  parties,  but  their  drafts  and  necessary
      details had been annexed as Appendix  I  to  VII  of  the  shareholder
      agreement.  The other Agreements were only required to  be  signed  by
      the parties who, as per the Shareholders Agreement, were  required  to
      sign such agreement.   The  Arbitration  Clause  of  the  Shareholders
      Agreement reads as under:
                 “Any dispute or difference arising under or  in  connection
                 with this Agreement, or any breach thereof, which cannot be
                 settled by friendly negotiation and agreement  between  the
                 parties, shall be finally settled by arbitration  conducted
                 in  accordance  with  the   Rules   of   Conciliation   and
                 Arbitration of the International  Chamber  of  Commerce  by
                 three  arbitrators  designated  in  conformity  with  those
                 Rules.   The  arbitration  proceedings  shall  be  held  in
                 London, England and shall be governed  by  and  subject  to
                 English law.  Judgment  upon  the  award  rendered  may  be
                 entered in any court of competent jurisdiction.”
      International Distributor Agreement
      23.   The International Distributor Agreement has  been  mentioned  as
      Appendix  II  to  the  Shareholders  Agreement.    The   International
      Distributor Agreement was executed on the same day  and  entered  into
      between Capital Controls Company Inc., respondent No.1 and  the  joint
      venture company Capital Controls India  Pvt.  Ltd.,  respondent  no.5.
      Under this Agreement, the joint venture company was appointed  as  the
      exclusive distributor of products in the “territory” and for the  term
      provided under clause 10 of that Agreement.  The  specified  territory
      was India, Afghanistan, Nepal and Bhutan but the agreement also stated
      that exports to other countries were not permissible except  with  the
      specific authorization by respondent  No.1.    Besides  providing  the
      rights and duties of the Distributors, this  Agreement also stated the
      schedule  for  delivery  of  products/orders,  the   prices   payable,
      commissions and  inspection.   It  also  provided  for  the  terms  of
      payment.  Distributor’s orders of products were subject to  acceptance
      by the seller at its offices and the seller reserved his right, at any
      time, to cease manufacture as well as offering for  sale  any  product
      and to change the design of product.
      24.    This  distributorship  right   was   non-assignable   and   was
      exclusively  between  the   distributor   and   the   seller.      The
      relationship between the parties was agreed to be that of a seller and
      purchaser.   Clause 11 of the Agreement then clearly  postulated  that
      the distributor was an independent contractor and not joint venture or
      partner with an agent or employee of the seller.   Clause 13  providedChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      that the Agreement contained  the  entire  understanding  between  the
      parties with  respect  to  that  subject  matter  and  superseded  all
      negotiations,  discussions,  promises  or  agreements,  prior  to   or
      contemporaneous with this Agreement.
      25.   Further, this Agreement contained the confidentiality clause  as
      well  as  the  non-competition  clause  being  clauses  16   and   18,
      respectively.  The latter specified that the  distributor  shall  not,
      directly or indirectly, sell, manufacture or supply  products  similar
      to any of the products or  engage,  directly  or  indirectly,  in  any
      business the same as or similar to that of seller, except  subject  to
      the conditions of the Agreement.
      26.   In terms of clause 20, the agreement between the parties was  to
      remain confidential and not to be discussed, shown to  or  filed  with
      any Government agencies without the prior consent  of  the  seller  in
      writing. This Agreement did not contain any arbitration clause, but it
      did provide a jurisdiction clause i.e. clause 21, which read as under:
                 “The construction, interpretation and performance  of  this
                 Agreement and all transactions under it shall  be  governed
                 by  and  interpreted  under  the  laws  of  the  State   of
                 Pennsylvania, U.S.A., and the  parties  hereto  agree  that
                 each shall be subject  to  the  jurisdiction  of,  and  any
                 litigation hereunder shall be brought in,  any  federal  or
                 state  court  located  in  the  Eastern  District  of   the
                 Commonwealth of Pennsylvania, and that  the  resolution  of
                 such litigation by such court shall  be  binding  upon  the
                 parties.”
      27.   We may notice here that the International Distributor  Agreement
      was not only executed in furtherance to Clause 7 of  the  Shareholders
      Agreement but in that clause itself it was also stated to  be  annexed
      thereto as Appendix II.  The Distributor Agreement was  liable  to  be
      renewed as long as the Distributor  i.e.  Capital  Controls,  held  at
      least twenty-six per cent (26%) of the shares  in  the  joint  venture
      company.
      Managing Directors Agreement
      28.   Clause 8.6  of  the  Shareholders  Agreement  had  provided  for
      appointment or reappointment of the Managing Director  or  whole  timeChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      Director  by  mutual  consent.   Subject  to  the  provisions  of  the
Companies Act, it was agreed that Mr. Kocha would be appointed as  the
      first Managing Director of the Company for  an  initial  period  of  3
      years and on such terms and conditions as were specified  in  Appendix
      III, i.e., the Managing Directors Agreement  of  the  same  date.   In
      other words,  the  Managing  Directors  Agreement  had  been  executed
      between joint venture company, Capital Control India Pvt. Ltd. and Mr.
      M.B. Kocha, on terms already agreed to  between  the  parties  to  the
      Shareholders’ Agreement.
      29.   The  joint  venture  company,  which  is  stated  to  have  been
      incorporated on 14th  November,  1995,  held  Board  Meeting  on  16th
      November,  1995  and  as  contemplated  under  Clause   8.6   of   the
      Shareholders Agreement, appointed Mr. Kocha as the  Managing  Director
      of the Company for three years commencing from 1st April, 1996.   This
      Managing Directors Agreement spelt out the powers which  the  Managing
      Director could exercise and more specifically,  under  Clause  3,  the
      powers which the Managing Director could exercise only with the  prior
      approval of the Board of Directors  of the Joint Venture Company.  For
      instance, under Clause 3 (k), the Managing Director was  not  entitled
      to undertake any new business or  substantially  expand  the  business
      contemplated thereunder except with  the  approval  of  the  Board  of
      Directors.  Further, clause 6 contained a non-compete clause requiring
      Mr. Kocha not to run any similar business for two years after the date
      of termination of the Agreement.
      30.   This Agreement also did not contain  any  arbitration  agreement
      and provided no terms which  were  not  within  the  contemplation  of
      clause 8.7 of the Shareholders Agreement.
      Export Sales Agreement
      31.   Export Sales Agreement  was  again  singed  between  the  Chloro
      Control India Pvt. Ltd. and Capital  Control  Co.  Inc.,  the  foreign
      partner to the joint venture.  This Agreement, on  its  bare  reading,
      presupposes the existence and working of the  joint  venture  company.
      The products required to be manufactured by the joint venture  company
      under the Shareholders Agreement as well as those stated in Exhibit  1
      of this Agreement were  to  be  exported  to  different  countries  by
      Capital Control Company Inc. which was required to export those  goods
      and execute such orders as  per  the  terms  and  conditions  of  this
      Agreement,  except  in  countries  specified  in  Exhibit  2  to   the
      Agreement.   It is noteworthy that the export could be effected to all
      countries  covered  under  the  ‘Territory’  excluding  the  countries
      specified  in  Ext.  2  of  the  agreement  which  was  completely  in
      consonance with the execution and performance of Shareholder Agreement
      and the  International  Distributor  Agreement  executed  between  the
      parties.  This Agreement  stipulated  distinct  terms  and  conditions
      which had to be adhered to by the parties while  the  Capital  ControlChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      Company Inc. was to act as sole and exclusive agent for  sale  of  the
      products.  The products under  the  Agreement  meant  design,  supply,
      installation commissioning and  after-sale  services  of  chlorination
      systems and equipment  related  products  manufactured  by  the  Joint
      Venture Company.  The services under the Agreement could be  performed
      by  Capital  control  Co.  Inc.  itself  or  through  its   affiliated
      corporation or duly appointed sales agents and distributors.  In terms
      of Clause 17 of the Agreement, it was to be construed and  interpreted
      in accordance with the laws in the State of  Pennsylvania,  U.S.A.  It
      specifically contained an arbitration clause (clause 18) that read  as
      under:
                 “Any dispute of difference arising under or  in  connection
                 with this Agreement, or any breach thereof, which cannot be
                 settled by friendly negotiation and agreement  between  the
                 parties shall be finally settled by  arbitration  conducted
                 in  accordance  with  the  Rules  of  American  Arbitration
                 Association.  The arbitration proceedings shall be held  in
                 Pennsylvania, U.S.A. Judgment upon the award  rendered  may
                 be rendered may  be  entered  in  any  court  of  competent
                 jurisdiction.”
      Financial and  Technical  Know-how  License  Agreement  and  Trademark
      Registered User Agreement
      32.   Now, we shall deal with both these agreements together  as  both
      these agreements are inter-dependent and one finds elaborate reference
      to one in the other.  Furthermore, both  these  agreements  have  been
      entered into and executed between Capital Control Co. Inc. on the  one
      hand and the joint venture company on the other.
      33.   Under clause 14 of the Shareholders Agreement, it  was  required
      of the parties to cause the joint venture company to  enter  into  the
      Financial and Technical Know-How License Agreement  with  the  Capital
      Controls under which the latter was to grant the joint venture company
      the right  and  license  to  manufacture  the  products  in  India  in
      accordance with the Technical Know-How and other technical information
      possessed by Capital Controls. Clause 18 of  the  Principal  Agreement
      also referred to this agreement and postulated that if the  Government
      of  India  did  not  grant  permission  for  the  terms   of   foreign
      collaboration  contained  in  this  agreement,  even   the   Principal
      Agreement, i.e. the Shareholder’s Agreement  would  be  liable  to  be
      terminated without giving rise to any claim for damages.   Both  these
      clauses provided that this Agreement was  attached  to  the  Principal
      Agreement itself and had been referred to as the ‘License  Agreement’,Chloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      for short.
      34.   We may refer to certain terms  of  this  agreement  which  would
      indicate that the terms and conditions of the Principal Agreement were
      to be implemented  through  this  Agreement.   Besides  providing  the
      obligations  of  the  Capital  Controls  (respondent  no.5),  it  also
      stipulated that the licensee, i.e. the joint venture company would  be
      free to manufacture the products under the said patent even after  the
      expiry of the Agreement.  Under clauses 9 and  10  of  the  Agreement,
      obligations of the licensee were stated and it required  the  licensee
      to maintain quality  comparable  to  corresponding  products  made  by
      Capital Controls in USA and to allow free access  and  information  to
      Capital Controls.  The products manufactured  by  the  licensee  whose
      quality was approved by Capital Controls  could  be  marked  with  the
      legend, ‘Manufactured in India under  license  from  Capitals  Control
      Company Inc. Colmar, Pennsylvania, USA”.  However,  if  the  agreement
      was terminated, the licensee was not to use the trademark and legend.
      35.   As stated, the purpose of this Agreement was that  the  licensee
      desired to obtain the right and license to manufacture the products in
      accordance with the Technical Know-How owned or  acquired  by  Capital
      Controls and for which that company was willing to  grant  license  on
      the terms and conditions stated in  that  Agreement.   The  first  and
      foremost restriction was that the rights under the agreement were non-
      transferable and  the  right  was  restricted  to  sell  the  products
      exclusively in India and the countries listed in the Appendix  to  the
      Agreement.   The  Agreement  also  contained  a  non-competing  clause
      providing that the licensee must not manufacture or have  manufactured
      for it, sell or offer for sale or be financially interested in similar
      products  without  prior  written  permission  of  Capital   Controls.
      Respondent no.1 had also agreed that its  affiliated  companies  would
      sell the product in India only through the  licensee.   The  Agreement
      provided for payment of royalties under clause 11.
      36.   Another very significant clause of this Agreement was  the  Term
      and Termination clause.  The agreement was to continue  in  force  for
      ten years from the date it was filed with the Reserve Bank  of  India,
      subject to earlier termination in terms of clause 15.2.   Clause  14.2
      provided  practically  for  the  conditions  of  termination  of  this
      Agreement  similar  to  those  contemplated  for  the  Share   Holders
      Agreement. Neither any modification/amendment of  this  Agreement  nor
      any waiver of its terms and conditions was  to  be  binding  upon  the
      parties unless made in writing and duly executed by both the  parties.
      Appendix I to this agreement recorded the  products  which  the  joint
      venture company was to manufacture.   In the  event  of  dispute,  the
      parties were expected to settle it by friendly  negotiations,  failing
      which it  was  to  be  referred  to  the  ICC,  by  three  Arbitrators
      designated in conformity with the  relevant  Rules.   Clause  26,  the
      Arbitration clause, read as under:-
                 “Any dispute or difference arising under or  in  connection
                 with this Agreement, or any breach thereof, which cannot be
                 settled by friendly negotiation and agreement  between  theChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

                 parties shall be finally settled by  arbitration  conducted
                 in  accordance  with  the   Rules   of   Conciliation   and
                 Arbitration of the International  Chamber  of  Commerce  by
                 three  arbitrators  designated  in  conformity  with  those
                 Rules.   The  Arbitration  proceedings  shall  be  held  in
                 London, England and shall be governed  by  and  subject  to
                 English Law.   Judgment upon  the  award  rendered  may  be
                 entered in any court of competent jurisdiction.”
      37.   Clauses 15.1 and 15.2 of the Principal Agreement referred to the
      Trademark Registered User License Agreement.  Firstly, it is  provided
      that respondent no.9, Mr. Kocha and Chloro Controls acknowledged  that
      Capital Controls was the sole owner of certain trademarks  and  trade-
      names used by Capital Controls in connection  with  the  sale  of  the
      products.  Besides agreeing that they would not adopt, use or register
      as a trademark or tradename any word or symbol, which in  the  opinion
      of Capital Controls is confusingly similar to their trademarks,  there
      the joint venture company was  required  to  enter  into  a  Trademark
      Registered User License Agreement  for  obtaining  the  right  to  use
      certain trademarks and tradenames  and  it  was  further  specifically
      provided that the said agreement formed  part  of  the  Financial  and
      Technical Know-How License Agreement.
      38.   The Trademark Registered User Agreement, as already noticed, was
      executed between the respondent no.1 and respondent  no.5,  the  joint
      venture company.  The relationship  between  the  parties  under  this
      agreement was contractual and respondent no.1 had agreed to grant user
      permission to use the trademarks, subject to the terms and  conditions
      specified in the agreement.  The agreement was executed with the clear
      intention that the license owner (respondent No. 1) would provide  its
      secret drawings, plans, specifications, test data, formulae and  other
      manufacturing  procedures  and  as  well  as  technical  know-how  for
      assembly, manufacture, quality control and testing  of  goods  to  the
      licensee, the joint venture company.  The agreement dealt with various
      aspects including grant of non-exclusive right to use  the  trademarks
      in relation to the goods in the territory as the  registered  user  of
      the trademarks.  In terms of clause 10 of  the  agreement,  the  joint
      venture company was not to  acquire  any  ownership  interest  in  the
      trademarks or registrations thereof by virtue of use of trademark  and
      it was specifically agreed that every permitted use of  trademarks  by
      the user would enure to the benefit of  the  licensor  company.   This
      Agreement was to terminate automatically  in  the  event  the  License
      Agreement i.e. the Financial and Technical Know-How License Agreement,
      was terminated for any reason.   Clause  13  also  provided  that  the
      permitted use of the trademarks did not involve  the  payment  of  any
      royalty or other consideration, other than the royalties payable under
      the Financial  and  Technical  Know-How  License  Agreement  by  joint
      venture  company  to  the  licensor  company.   This   agreement   was
      terminable on the conditions stipulated in clause 16, which again were
      similar to the termination clause provided in other agreements.   ThisChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      Agreement did not contain an arbitration clause.
      Supplementary Collaboration Agreement
      39.   The last of the documents in this series which  requires  to  be
      mentioned by the Court is the Supplementary  Collaboration  Agreement.
      Any joint venture agreement in India which is in collaboration with  a
      foreign partner can be commenced only after obtaining  the  permission
      of the Government of India.  The parties herein had already executed a
      joint venture  agreement  dated  16th  November,  1995.   The  company
      obtained the permission of the Government of India vide its letter No.
      FC-II 830(96)245(96) dated 11th October, 1996 amended on  21st  April,
      1997.   The company then commenced the operation and business  of  the
      joint venture company with effect from 1st April, 1997.
      40.   In the letter by the Government of  India  dated  11th  October,
      1996, besides noticing the items of manufacture  activity  covered  by
      the foreign  collaboration  agreement,  foreign  equity  participation
      being 50% and other conditions which had been specifically postulated,
      under clause 7 of the letter it was specified that the approval letter
      was made a  part  of  the  foreign  collaboration  agreement  executed
      between the parties and only those provisions of the  agreement  which
      were covered by the said letter or which were not at variance with the
      said letter would be binding on the Government of India or the Reserve
      Bank of India.  Thus, the parties were directed to proceed to finalize
      the agreement.
      41.   Vide its letter dated 21st December,  1996,  the  joint  venture
      company had  written  to  the  Ministry  of  Industry,  Department  of
      Industrial Policy and Promotion, Government of  India,  requesting  to
      amend point No. 2 of the above-mentioned approval letter.  The request
      was to widen the scope of the manufacture activities  covered  by  the
      foreign collaboration  agreement.   The  company  wished  to  add  the
      manufacture of gas and electro-chlorination equipments, amongst  other
      stated items.  The other amendment that was sought for was increase in
      the authorized share capital from Rs.25 lakhs to paid-up capital of 50
      lakhs in the joint venture company.  Both these requests of the  joint
      venture company were accepted by the Government of  India  vide  their
      letter dated 21st April, 1997 and clauses (2),  (3)  and  (4)  of  the
      earlier approval letter dated 11th October, 1996 were  modified.   All
      other terms and conditions of the approval letter remained  the  same.
      The Government of India had asked  for  acknowledgement  of  the  said
      letter.
      42.   In furtherance to this letter of the Government  of  India,  the
      joint  venture  company  and  the  respondent   no.2   executed   this
      Supplementary Collaboration Agreement.  The important part of this one-
      page agreement is ‘we hereby conform that we shall adhere to the terms
      and conditions as stipulated by the Government of India.   Letter  No.
      FC.II: 830(96) 295(96) dated 11.10.1996, amended 21.04.1997.’  It alsoChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      stated that the companies had entered into the joint venture agreement
      dated 16th November, 1995  and  had  commenced  their  operation  with
      effect from 1st  April,  1997.   In  other  words,  the  Supplementary
      Collaboration Agreement was a mere confirmation of the previous  joint
      venture agreement.  By this time i.e., somewhere in August  1997,  all
      other agreements had been executed, the joint venture company had come
      into existence  and,  in  furtherance  to  those  agreements,  it  had
      commenced its business.
      43.   As we have already noticed under the head ‘Corporate Structure’,
      the name of Respondent No. 1, Capital Control Co. Inc. was changed  to
      Severn Trent Water Purification Inc. with effect from 1st April, 2002.
       Later on, respondent no.2, Capital Control (Delaware)  Co.  Inc.  was
      merged with the respondent no.1 on 31st March, 2003.   Thus,  for  all
      purposes and intents, in fact and in law, interest of respondent  no.1
      and 2 was controlled and given effect to by Severn Trent.
      44.   On this issue, version of the respondents had been  disputed  in
      the earlier round of litigation between the parties  where  respondent
      No. 1, Severn Trent Water Purification Co.  Inc.,  USA,  had  filed  a
      petition for winding up respondent No. 5-Chloro  Controls  India  Pvt.
      Ltd., the joint venture company, on just and  equitable  ground  under
Section 433(j) of the Companies Act.  In this petition, specific issue
      was raised that merger of Capital Controls (Delaware) Co. with  Severn
      Trent was not intimated to the respondent No. 5 company prior  to  the
      filing of the arbitration petition by Severn Trent under Section 9  of
      the 1996 Act as well as that Severn Trent was not a  share  holder  of
      the joint venture company and thus had no locus  standi  to  file  the
      petition.  This Court vide its judgment dated 18th February,  2008  in
      Civil Appeal No. 1351 of 2008 titled Severn Trent  Water  Purification
      Inc.  v.  Chloro Control (India) Pvt. Ltd.  and  Anr.  held  that  the
      winding up petition by Severn Trent Water Purification  Inc.  was  not
      maintainable as it was not a contributory.  But the  question  whether
      that company was a creditor of the  joint  venture  company  was  left
      open.
      45.   At this very stage, we may make it clear that we do not  propose
      to deal with any of the contentions raised in  that  petition  whether
      decided or left open, as the judgment has already  attained  finality.
      In terms of the settled position of law, the said judgment  cannot  be
      brought in challenge  in  the  present  proceedings,  collaterally  or
      otherwise.
      46.   Certain disputes had already arisen  between  the  parties  that
      resulted in termination of the joint venture agreements.  Vide  letter
      dated 21st July, 2004, Severn Trent Services informed respondent no.9,
      respondent no.5 and Chloro  Controls  India  Pvt.  Ltd.,  the  present
      appellant, that they had failed to remedy the  issues  and  grievances
      communicated to them in their previous  correspondences  and  meetings
      and also failed to  engage  in  any  productive  negotiation  in  this
      connection and therefore, they were terminating from  that  very  day,
      the joint venture agreements executed between them and  the  appellant
      company, which included agreements stated  in  that  letter  i.e.  theChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      Shareholders Agreement, the International Distributor  Agreement,  the
      Financial and Technical Know-How License Agreement, the  Export  Sales
      Agreement and the Trademark Registered User Agreement, all dated  16th
      November,  1995  and  requested  them  to  commence  the  winding   up
      proceedings of the joint venture company, respondent No. 5.  They were
      also called upon to act in accordance with the terms of the  agreement
      in the event of such termination.  It may be noticed here itself  that
      prior to the serving of the notice of termination,  a  suit  had  been
      instituted by the appellant in which application under Section 8/45 of
      the 1996 Act was filed.
      Contentions of the learned Counsel appearing for the  parties  in  the
      backdrop of above detailed facts
      47.   The appellant had filed a derivative suit being Suit No. 233  of
      2004 praying, inter alia, for a decree of declaration that  the  joint
      venture agreements and the supplementary collaboration  agreement  are
      valid, subsisting and binding and that the scope of  business  of  the
      joint venture company included the manufacture, sale, distribution and
      service of entire range of chlorination equipments including  electro-
      chlorination equipment.  An order  of  injunction  was  also  obtained
      restraining respondent Nos. 1 and 2 from interfering in any way and/or
      preventing respondent No.5 from conducting its  business  of  sale  of
      chlorination equipments including electro-chlorination  equipment  and
      that they be not permitted to sell their products in  India  save  and
      except through the joint venture company, in compliance of clause  2.5
      of the Financial and Technical Know-How License  Agreement  read  with
      the Supplementary  Collaboration  Agreement.   Besides  this,  certain
      other reliefs have also been prayed for.
      48.   After the institution of  the  suit,  as  already  noticed,  the
      respondent Nos.1 and 2 had  terminated  the  joint-venture  agreements
      vide  notices  dated  23rd  January,  2004  and   21st   July,   2004.
      Resultantly, in the amended plaint, specific prayer was made that both
      these notices were wrong, illegal and invalid; in breach of the  joint
      venture agreements and of no effect; and the joint venture  agreements
      were binding and subsisting.  To be precise, the appellant had claimed
      damages, declaration and injunction in the suit primarily relying upon
      the agreements entered  into  between  the  parties.   In  this  suit,
      earlier  interim  injunction  had  been  granted  in  favour  of   the
      appellant, which was subsequently vacated at the appellate stage.  The
      respondent Nos.1 and 2 filed an application under  Section  8  of  the
      Act, praying for reference of the suit to  the  arbitral  tribunal  in
      accordance with the agreement between the parties.   This  application
      was contested and finally decided by  the  High  Court  in  favour  of
      respondent Nos.1 and 2, vide order dated  4th  March,  2010  making  a
      reference of the suit to arbitration.Chloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      49.   It is this Order of the Division Bench  of  the  High  Court  of
      Bombay that has given rise to the present appeals before  this  Court.
      While raising a challenge, both on facts and in law, to  the  judgment
      of the Division Bench of the Bombay High Court making a  reference  of
      the entire suit to arbitration, Mr. Fali S.  Nariman,  learned  senior
      counsel  appearing  for  the  appellant,  has  raised  the   following
      contentions :
     1. There is inherent right conferred on every person by Section  9  of
        the Code of Civil Procedure, 1908, (for short  ‘CPC’)  to  bring  a
        suit of a civil nature unless it is barred by a  statute  or  there
        was no agreement restricting the exercise of such  right.  Even  if
        such clause was there (is  invoked),  the  same  would  be  hit  by
Section 27 of the Indian Contract Act, 1872 and under  Indian  law,
        arbitration is only an exception to a suit and not  an  alternative
        to it.  The appellant, in exercise of such right, had instituted  a
        suit before the Court of  competent  jurisdiction,  at  Bombay  and
        there being no bar under any statute to such suit.  The Court could
        not have sent the suit for arbitration under the provisions of  the
        1996 Act.
      2.    The appellant, being dominus litus to  the  suit,  had  included
           respondent  Nos.3  and  4,  who  were  necessary  parties.   The
           appellant had claimed different  and  distinct  reliefs.   These
           respondents had not been added as parties to the suit merely  to
           avoid the arbitration clause but there were substantive  reliefs
           prayed for against these  respondents.   Unless  the  Court,  in
           exercise of its power under Order I,  Rule  10(2)  of  the  CPC,
           struck out the name of these parties as being improperly joined,
           the decision of the High Court would be vitiated in law as these
           parties  admittedly  were  not  parties   to   the   arbitration
           agreement.
      3.    On its plain terms, Section 45 of the 1996 Act provides  that  a
           judicial authority, when seized of an  action  in  a  matter  in
           respect of which the parties have made an agreement referred  to
           in Section 44, shall, at the request of one of  the  parties  or
           any person claiming through or under him, refer the  parties  to
           arbitration.  The expression ‘party’ refers to  parties  to  the
           action or suit.  The request for arbitration, thus, has to  come
           from one of the parties to the suit  or  action  or  any  person
           claiming through or under him.  The Court then can  refer  those
           parties to arbitration.  The  expression  ‘parties’  used  under
Section 45 would necessarily mean all the parties and  not  some
           or any  one  of  them.   If  the  expression  ‘parties’  is  not
           construed to mean all parties to the action and  the  agreement,
           it will result in multiplicity of  proceedings,  frustration  of
           the intended one-stop remedy and may cause further mischief.Chloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

                  Judgment of the High Court in referring the  entire  suit,
           including the parties who were not parties  to  the  arbitration
           agreement as well as against whom the cause of  action  did  not
           arise from arbitration agreement, suffers from error of law.
      4.    The 1996 Act is an  amending  and  consolidating  Act  being  an
           enactment setting  out  in  one  statute  the  law  relating  to
           arbitration,   international    commercial    arbitration    and
           enforcement of foreign arbitral awards.  Further, the  1996  Act
           has no provision like Section 34 of the  Arbitration  Act,  1940
           (for short “1940 Act”).  In Section  3  of  the  Foreign  Awards
           (Recognition and Enforcement) Act, 1961 (for short ‘1961  Act’),
           there existed a mandate only to stay the proceedings and not  to
           actually refer the parties to arbitration.  Thus,  the  position
           before 1996 in India, as in England, permitted a partial stay of
           the suit, both as regards matters and parties.  But after coming
           into force of the 1996 Act, it is no longer possible to  contend
           that some parties and/or some matters in a suit can be  referred
           to arbitration leaving the rest to be decided by another forum.
      5.    Bifurcation of  matters/cause  of  action  and  parties  is  not
           permissible under the provisions of the 1996 Act. Such procedure
           is unknown to the law of arbitration in India.  The judgment  of
           this Court in the case of Sukanya Holdings Pvt. Ltd. (supra)  is
           a judgment in support of this contention.  This judgment of  the
           Court is holding the field even now.  In the alternative, it  is
           submitted  that  bifurcation,  if  permitted,  would   lead   to
           conflicting decisions by two  different  forums  and  under  two
           different systems of law.  In such situations,  reference  would
           not be permissible.
      6.    In the  alternative,  reference  to  arbitral  tribunal  is  not
           possible in the facts and circumstances  of  the  present  case.
           Where three major agreements, i.e., Managing Director Agreement,
           Trademark   Registered   User   Agreement   and    Supplementary
           Collaboration Agreement do  not  have  any  arbitration  clause,
           there  the  International  Distributor   Agreement   exclusively
           provides the jurisdiction  for  resolution  of  dispute  to  the
           federal  or  state  courts  in  the  Eastern  District  of   the
           Commonwealth of Pennsylvania, USA.  This latter agreement, thus,
           provided for resolution of disputes under a specific law and  by
           a specific forum.  Thus, for uncertainty and indefiniteness, the
           alleged arbitration clause is unenforceable.
            Thus, in the present case, out  of  all  the  agreements  signed
           between  different  parties,  four  agreements,  i.e.,  Managing
           Director   Agreement,   International   Distributor   Agreement,
           Trademark  Registered  User  Agreement  and  the   Supplementary
           Collaboration   Agreement,   have   no    arbitration    clause.Chloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

           Furthermore, different agreements have been signed by  different
           parties and respondent No.9 is  not  a  party  to  some  of  the
           agreements containing/not containing an arbitration clause.   In
           any case, respondent Nos.3 and 4 are not party  to  any  of  the
           Agreements and the cause of action of the appellant against them
           is limited to the scope of International  Distributor  Agreement
           vis-à-vis  the  products   covered   under   the   joint-venture
           agreement.
                 On these contentions, it is submitted that the judgment  of
           the High Court is liable to be set aside  and  no  reference  to
           arbitral tribunal is possible.    Also, the submission is  that,
           within the ambit and scope  of  Section  45  of  the  1996  Act,
           multiple agreements, where some contain  an  arbitration  clause
           and others don’t, a composite reference to  arbitration  is  not
           permissible.  There has to be clear intention of the parties  to
           refer the dispute to arbitration.
      50.   Mr. Harish Salve, learned senior counsel, while  supporting  the
      judgment of the High Court for the reasons stated therein,  argued  in
      addition that the submissions made by Mr. F.S. Nariman, learned senior
      counsel, cannot be accepted in law and on the facts of the  case.   He
      contended that :
        i) Under the provisions of the 1996 Act, particularly in  Part  II,
           the Right  of  Reference  to  Arbitration  is  indefeasible  and
           therefore, an interpretation in favour of such reference  should
           be given primacy over any other interpretation.
       ii) In substance, the suit and the reliefs claimed therein relate to
           the dispute with regard to the agreed scope of business  of  the
           joint venture company  as  regards  gas  based  chlorination  or
           electro based chlorination.   This major dispute in the  present
           suit being  relatable  to  joint  venture  agreement  therefore,
           execution of multiple agreements would not make any  difference.
           The reference of the suit to arbitral Tribunal by the High Court
           is correct on facts and in law.
      iii) The filing of the suit as  a  derivative  action  and  even  the
           joinder of respondent Nos.3 and 4 to  the  suit  were  primarily
           attempts to escape the impact of the arbitration clause  in  the
           joint venture agreements.  Respondent Nos. 3 and 4 were  neither
           necessary nor appropriate parties to the suit.  In the facts  of
           the case the party should be held to the bargain of  arbitration
           and even the plaint should yield in favour  of  the  arbitration
           clause.
       iv) All agreements executed between the parties are  in  furtherance
           to the Shareholders Agreement and were intended to achieve  only
           one object, i.e., constitution and carrying on  of  business  of
           chlorination products by the joint venture company in India  and
           the specified countries.  The parties having signed the  variousChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

           agreements, some containing an  arbitration  clause  and  others
           not,  performance  of  the  latter  being  dependent  upon   the
           Principal Agreement and in face of clause 21.3 of the  Principal
           Agreement, no relief could be granted on the bare reading of the
           plaint and reference to arbitration of the complete stated cause
           of action was inevitable.
        v) The judgment of this Court in the case of Sukanya  (supra)  does
           not enunciate the correct law.  Severability of cause of  action
           and parties  is  permissible  in  law,  particularly,  when  the
           legislative intent is that arbitration has  to  receive  primacy
           over the other remedies.  Sukanya being a judgment relatable  to
           Part 1 (Section 8) of the 1996 Act, would not be  applicable  to
           the facts of the present case which exclusively is covered under
           Part II of the 1996 Act.
       vi) The 1996 Act does not contain any restriction or  limitation  on
           reference to arbitration as contained under Section  34  of  the
           1940 Act and therefore, the Court would be competent to pass any
           orders as it may deem fit and proper, in the circumstances of  a
           given case particularly with the aid of Section 151 of the CPC.
      vii) A bare reading of the provisions of Section 3 of the 1961 Act on
           the one hand and Section 45 of the 1996 Act on the other clearly
           suggests that change has been brought in the structure  and  not
           in the substance of the provisions.  Section 3 of the 1961  Act,
           of  course,  primarily  relates  to  stay  of  proceedings   but
           demonstrates that the plaintiff claiming through  or  under  any
           other person who is a party to the arbitration  agreement  would
           be subject to the applications under the arbitration  agreement.
           Thus, the absence of equivalent words in Section 45 of 1996  Act
           would not make much difference.  Under Section 45, the applicant
           seeking reference can either  be  a  party  to  the  arbitration
           agreement or a person claiming through or under such party.   It
           is also the contention that a defendant who is neither of these,
           if cannot be referred to arbitration, then such  person  equally
           cannot  seek  reference  of  others  to  arbitration.   Such  an
           approach would be consistent with the development of arbitration
           law.
      51.   The contention raised before us is that Part I and  Part  II  of
      the 1996 Act  operate  in  different  fields  and  no  interchange  or
      interplay is permissible.  To  the  contra,  the  submission  is  that
      provisions of Part I have to be construed with Part II.  On behalf  of
      the appellant, reliance has been placed  upon  the  judgment  of  this
      Court in the case Bhatia International v. Bulk Trading S.A.  and  Anr.
      [(2002) 4 SCC 105].  The propositions stated in  the  case  of  Bhatia
      International (supra) do not directly arise for consideration of  this
      Court in the facts of the present case.  Thus, we are not dealing with
      the dictum of the Court in Bhatia International’s case and application
      of its principles in this judgment.Chloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

            It is appropriate for us to deal with the interpretation,  scope
      and ambit of Section 45 of the 1996 Act particularly  relating  to  an
      international arbitration covered under the Convention on  Recognition
      and Enforcement of Foreign Arbitral Awards (for short, ‘the  New  York
      Convention’).
      52.   Now, we shall proceed to discuss the width of Section 45 of  the
      1996 Act.
      Interpretation of Section 45 of the 1996 Act
      53.   In order to invoke jurisdiction of the Court under  Section  45,
      the applicant should satisfy the pre-requisites stated in  Section  44
      of the 1996 Act.
      54.   Chapter I, Part II deals with  enforcement  of  certain  foreign
      awards in accordance with the New York Convention, annexed as Schedule
      I to the 1996 Act.   As per Section 44, there has to be an arbitration
      agreement in writing.   To such arbitration agreement  the  conditions
      stated in Schedule I would apply.   In other words,  it  must  satisfy
      the requirements of Article II of Schedule I.   Each contracting State
      shall recognize an  agreement  in  writing  under  which  the  parties
      undertake to submit to arbitration their  disputes  in  respect  of  a
      defined legal relationship, whether contractual or not,  concerning  a
      subject matter capable of settlement by arbitration.   The arbitration
      agreement shall include an arbitration clause  in  a  contract  or  an
      arbitration agreement signed by the parties or entered in any  of  the
      specified modes.   Subject  to  the  exceptions  stated  therein,  the
      reference shall be made.
      55.   The language of Section 45 read with Schedule I of the 1996  Act
      is worded in favour of making a reference to arbitration when a  party
      or any person claiming through or under him approaches the  Court  and
      the Court is satisfied that the agreement is  valid,  enforceable  and
      operative.    Because of  the  legislative  intent,  the  mandate  and
      purpose  of  the  provisions  of  Section  45  being  in   favour   of
      arbitration, the  relevant  provisions  would  have  to  be  construed
      liberally to achieve  that  object.   The  question  that  immediately
      follows is as to what are the aspects which the Court should  consider
      while dealing with an application for reference to  arbitration  under
      this provision.
      56.   The 1996 Act makes it abundantly clear that Part I  of  the  Act
      has been amended to bring these provisions completely in line with the
      UNCITRAL Model Law on International Commercial Arbitration (for short,
      the ‘UNCITRAL Mode Law’), while Chapter I  of  Part  II  is  meant  to
      encourage international commercial  arbitration  by  incorporating  in
      India, the provisions  of  the  New  York  Convention.   Further,  theChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      protocol on Arbitration Clauses (for short  ‘Geneva  Convention’)  was
      also incorporated as part of Chapter II of Part II.
      57.   For proper interpretation and application of Chapter I  of  Part
      II, it is necessary that those provisions are read in conjunction with
Schedule I of the Act.   To  examine  the  provisions  of  Section  45
      without the aid of Schedule I would not be appropriate as that is  the
      very foundation of Section 45 of the Act.  The  International  Council
      for Commercial Arbitration prepared a Guide to the  Interpretation  of
      1958 New York Convention, which lays/contains the Road Map to  Article
      II.  Section 45 is enacted materially on the lines of  Article  II  of
      this Convention.  When the Court is seized with  a  challenge  to  the
      validity of an arbitration agreement, it would be desirable to examine
      the following aspects :
                 “1.   Does the arbitration agreement fall under  the  scope
                 of the Convention?
                 2.    Is the arbitration agreement evidenced in writing?
                 3.    Does  the  arbitration  agreement  exist  and  is  it
                 substantively valid?
                 4.    Is there a dispute, does it arise out  of  a  defined
                 legal relationship, whether contractual or not, and did the
                 parties intend to have this particular dispute  settled  by
                 arbitration?
                 5.    Is the arbitration agreement binding on  the  parties
                 to the dispute that is before the Court?
                 6.    Is this dispute arbitrable?”
      58.   According to this Guide, if these questions are answered in  the
      affirmative, then the parties must be  referred  to  arbitration.   Of
      course, in addition to the above, the Court will  have  to  adjudicate
      any plea, if taken by a non-applicant that the  arbitration  agreement
      is null and void, inoperative or  incapable  of  being  performed.  In
      these three situations, if the Court answers such plea  in  favour  of
      the non-applicant, the question of making a reference  to  arbitration
      would not arise and that would put the matter at rest.
      59.   If the parties are referred to arbitration  and  award  is  made
      under these provisions of the Convention, then it shall be binding and
      enforceable in accordance with the provisions of Sections 46 to 49  of
      the 1996 Act.  The procedure prescribed under Chapter I of Part II  is
      to take precedence  and  would  not  be  affected  by  the  provisions
      contained under Part I and/or Chapter  II  of  Part  II  in  terms  of
Section 52. This is the extent of priority that  the  Legislature  had
      intended to accord to this Chapter 1 of Part II.Chloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      60.   Amongst the initial steps, the  Court  is  required  to  enquire
      whether the dispute at issue is covered by the arbitration  agreement.
      Stress  has  normally  been  placed  upon  three  characteristics   of
      arbitrations which are as follows –
      (1)    arbitration  is  consensual.   It  is  based  on  the  parties’
           agreement;
      (2)   arbitration leads to a  final  and  binding  resolution  of  the
           dispute; and
      (3)   arbitration is regarded as substitute for the  court  litigation
           and results in the passing of an binding award.
      61.   Mr. Nariman, learned senior counsel appearing on behalf  of  the
      appellant, contended that in terms of Section  45  of  the  1996  Act,
      parties to the agreement shall essentially be the parties to the suit.
       A stranger or a third party cannot ask for arbitration.  They have to
      be essentially the same.  Further, the parties  should  have  a  clear
      intention, at the time of the contract,  to  submit  any  disputes  or
      differences as may arise, to arbitration and then alone the  reference
      contemplated under Section 45 can be enforced.
      62.   To the contra, Mr. Salve, the learned senior  counsel  appearing
      for respondent No. 1, submitted that the phrase “at the request of one
      of the parties or any person claiming through or under him” is capable
      of liberal construction primarily for the reason that under  the  1996
      Act,  there  is  a  greater  obligation  to  refer  the   matters   to
      arbitration.   In  fact,  the  1996  Act  is  the  recognition  of  an
      indefeasible Right to Arbitration.   Even  a  party  which  is  not  a
      signatory to the arbitration agreement  can  claim  through  the  main
      party.  Particularly, in cases of composite transactions, the approach
      of the Courts should  be  to  hold  the  parties  to  the  bargain  of
      arbitration rather than permitting them to  escape  the  reference  on
      such pleas.
      63.   At this stage itself,  we  would  make  it  clear  that  we  are
      primarily discussing these submissions purely on a legal basis and not
      with regard to the merits of the case, which we shall  shortly  revert
      to.
      64.   We have already noticed that the language of Section 45 is at  a
      substantial variance to the language of Section 8 in this regard.   In
Section  45,  the  expression  ‘any  person’  clearly  refers  to  the
      legislative intent of enlarging the scope of  the  words  beyond  ‘the
      parties’ who are signatory to the arbitration agreement.   Of  course,
      such applicant should claim through  or  under  the  signatory  party.
      Once this link is established, then the  Court  shall  refer  them  to
      arbitration.  The use of the word ‘shall’ would have to be  given  its
      proper meaning and cannot be equated with the word ‘may’, as liberally
      understood in its common parlance.   The  expression  ‘shall’  in  the
      language of the Section  45  is  intended  to  require  the  Court  to
      necessarily make a reference to arbitration, if the conditions of this
      provision are satisfied.   To  that  extent,  we  find  merit  in  the
      submission that there  is  a  greater  obligation  upon  the  judicialChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      authority to make such reference, than it was  in  comparison  to  the
      1940 Act.   However,  the  right  to  reference  cannot  be  construed
      strictly as an indefeasible right.  One can claim the  reference  only
      upon satisfaction of the pre-requisites stated under Sections  44  and
45 read with Schedule I of the 1996 Act.  Thus, it is  a  legal  right
      which has its own contours and is not an absolute right, free  of  any
      obligations/limitations.
      65.   Normally, arbitration takes place between the persons who  have,
      from the outset, been parties to both  the  arbitration  agreement  as
      well as the substantive contract underlining that agreement.  But,  it
      does occasionally happen that the claim is made against or by  someone
      who is not originally  named  as  a  party.   These  may  create  some
      difficult  situations,  but   certainly,   they   are   not   absolute
      obstructions to law/the  arbitration  agreement.   Arbitration,  thus,
      could be possible between a signatory to an arbitration agreement  and
      a third party.  Of course, heavy onus lies on that party to show that,
      in fact and in law, it is claiming ‘through’ or ‘under’ the  signatory
      party as contemplated under Section 45 of the 1996 Act.  Just to  deal
      with such situations illustratively, reference  can  be  made  to  the
      following examples in Law and Practice of  Commercial  Arbitration  in
      England (Second Edn.) by Sir Michael J. Mustill:
                 “1.   The claimant was in reality always  a  party  to  the
                       contract, although not named in it.
                 2.    The claimant has succeeded by operation of law to the
                       rights of the named party.
                 3.    The claimant has become a part  to  the  contract  in
                       substitution for the  named  party  by  virtue  of  a
                       statutory or consensual novation.
                 4.    The original  party  has  assigned  to  the  claimant
                       either the underlying  contract,  together  with  the
                       agreement to arbitrate which it incorporates, or  the
                       benefit of  a  claim  which  has  already  come  into
                       existence.”
      66.   Though the scope of an arbitration agreement is limited  to  the
      parties who entered into it and those claiming under or through  them,
      the Courts under the English Law have, in certain cases, also  applied
      the “Group of Companies Doctrine”.  This doctrine has developed in the
      international context, whereby an arbitration agreement  entered  into
      by a company, being one within a group of companies, can bind its non-
      signatory  affiliates  or  sister   or   parent   concerns,   if   the
      circumstances demonstrate that the mutual intention of all the parties
      was to bind both the signatories  and  the  non-signatory  affiliates.
      This theory has been applied in a number  of  arbitrations  so  as  to
      justify a tribunal taking jurisdiction over  a  party  who  is  not  a
      signatory  to  the  contract  containing  the  arbitration  agreement.Chloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      [‘Russell on Arbitration’ (Twenty Third Edition)].
      67.   This evolves the principle that a non-signatory party  could  be
      subjected to arbitration provided these transactions were  with  group
      of companies and there was a clear intention of the  parties  to  bind
      both, the signatory as well as the non-signatory  parties.   In  other
      words, ‘intention of the parties’ is a very significant feature  which
      must be established before the scope of arbitration  can  be  said  to
      include the signatory as well as the non-signatory parties.
      68.   A non-signatory or third party could be subjected to arbitration
      without their prior consent, but this would  only  be  in  exceptional
      cases.  The Court will examine these exceptions from the touchstone of
      direct  relationship  to  the  party  signatory  to  the   arbitration
      agreement, direct commonality of the subject matter and the  agreement
      between the parties being a composite  transaction.   The  transaction
      should be of a composite nature where performance of mother  agreement
      may not be feasible without aid,  execution  and  performance  of  the
      supplementary or ancillary agreements, for achieving the common object
      and collectively having bearing on the dispute.  Besides all this, the
      Court would have to examine whether  a  composite  reference  of  such
      parties would serve the  ends  of  justice.   Once  this  exercise  is
      completed and the Court answers  the  same  in  the  affirmative,  the
      reference  of  even  non-signatory  parties  would  fall  within   the
      exception afore-discussed.
      69.   In a case like the present one, where origin and end of  all  is
      with the Mother or the Principal Agreement, the fact that a party  was
      non-signatory  to  one  or  other  agreement  may  not  be   of   much
      significance.  The performance of any one of such  agreements  may  be
      quite irrelevant  without  the  performance  and  fulfillment  of  the
      Principal or the Mother Agreement.  Besides  designing  the  corporate
      management to successfully complete  the  joint  ventures,  where  the
      parties execute different agreements but all with one  primary  object
      in mind, the Court would normally hold the parties to the  bargain  of
      arbitration and not  encourage  its  avoidance.   In  cases  involving
      execution of such multiple agreements, two essential  features  exist;
      firstly,  all  ancillary  agreements  are  relatable  to  the   mother
      agreement and secondly, performance of one is so intrinsically  inter-
      linked with the other agreements that  they  are  incapable  of  being
      beneficially performed without performance of the  others  or  severed
      from the rest.  The intention of the parties to refer all the disputes
      between all the parties  to  the  arbitral  tribunal  is  one  of  the
      determinative factor.
      70.   We may  notice  that  this  doctrine  does  not  have  universal
      acceptance.   Some  jurisdictions,  for  example,  Switzerland,   have
      refused to recognize the doctrine, while others have  been  equivocal.
      The doctrine has found favourable consideration in the  United  States
      and French jurisdictions.  The  US  Supreme  Court  in  Ruhrgos  AG  v
      Marathon Oil Co. [526 US 574 (1999)] discussed this doctrine  at  someChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      length and relied on more traditional principles, such  as,  the  non-
      signatory being  an  alter  ego,  estoppel,  agency  and  third  party
      beneficiaries to find jurisdiction over the non-signatories.
      71.   The Court will have to examine such pleas with  greater  caution
      and by  definite  reference  to  the  language  of  the  contract  and
      intention of the parties.  In the case of composite  transactions  and
      multiple agreements, it may again be possible to invoke such principle
      in accepting the pleas  of  non-signatory  parties  for  reference  to
      arbitration.  Where the agreements are consequential and in the nature
      of a follow-up to  the  principal  or  mother  agreement,  the  latter
      containing the arbitration agreement  and  such  agreements  being  so
      intrinsically  inter-mingled  or  inter-dependent  that  it  is  their
      composite performance which  shall  discharge  the  parties  of  their
      respective mutual  obligations  and  performances,  this  would  be  a
      sufficient indicator of intent of the parties to  refer  signatory  as
      well as  non-signatory  parties  to  arbitration.   The  principle  of
      ‘composite performance’ would have to be gathered  from  the  conjoint
      reading of the principal and supplementary agreements on the one  hand
      and  the  explicit  intention  of  the  parties  and   the   attendant
      circumstances on the other.
      72.   As already noticed, an arbitration agreement, under  Section  45
      of the 1996 Act, should be  evidenced  in  writing  and  in  terms  of
      Article II of Schedule 1, an agreement in  writing  shall  include  an
      arbitral clause in a contract or an arbitration  agreement  signed  by
      the parties or contained in  an  exchange  of  letters  or  telegrams.
      Thus, the requirement that an arbitration agreement be in  writing  is
      an expression incapable of strict  construction  and  requires  to  be
      construed liberally, as the words of this Article provide.  Even in  a
      given circumstance, it may be possible and permissible to construe the
      arbitration agreement with the aid and principle of ‘incorporation  by
      reference’.  Though the New York Convention is silent on this  matter,
      in common  practice,  the  main  contractual  document  may  refer  to
      standard terms and conditions or other standard  forms  and  documents
      which may contain an arbitration clause and,  therefore,  these  terms
      would become part of the contract between the  parties  by  reference.
      The solution to such issue  should  be  case-specific.   The  relevant
      considerations to determine  incorporation  would  be  the  status  of
      parties, usages within the specific industry,  etc.  Cases  where  the
      main documents explicitly refer  to  arbitration  clause  included  in
      standard terms and conditions would be more easily found in compliance
      with the formal requirements set out in the Article II of the New York
      Convention than those cases in which the main contract  simply  refers
      to the application of standard forms without any express reference  to
      the arbitration clause.  For instance, under the American  Law,  where
      standard terms and conditions referred to in a purchase order provided
      that the standard terms would have been attached to or  form  part  of
      the purchase order, this was considered to be an incorporation of  the
      arbitration agreement by reference.   Even  in  other  countries,  the
      recommended criterion for incorporation is whether the parties were or
      should have been aware of the arbitration agreement.  If the  Bill  of
      Lading, for example, specifically mentions the arbitration  clause  inChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      the Charter Party Agreement, it is generally considered sufficient for
      incorporation.  Two different approaches in  its  interpretation  have
      been adopted, namely, (a) interpretation of  documents  approach;  and
      (b) conflict of laws approach.  Under  the  latter,  the  Court  could
      apply  either  its  own  national  law  or  the  law   governing   the
      arbitration.
      73.   In India, the law has been  construed  more  liberally,  towards
      accepting incorporation by reference.   In  the  case  of  Owners  and
      Parties Interested in the Vessel M.V. “Baltic Confidence”  &  Anr.  v.
      State  Trading Corporation of India Ltd. & Anr. [(2001)  7  SCC  473],
      the Court was considering the question as to whether  the  arbitration
      clause in a Charter Party Agreement was incorporated by  reference  in
      the Bill of Lading and what the intention of the parties to  the  Bill
      of Lading was.   The primary document was the Bill of  Lading,  which,
      if read in the manner provided in the  incorporation  clause  thereof,
      would include the arbitration clause of the Charter  Party  Agreement.
      The Court observed  that  while  ascertaining  the  intention  of  the
      parties, attempt should be made to give  meaning  and  effect  to  the
      incorporation clause and not to invalidate or frustrate it  by  giving
      it a literal, pedantic  and  technical  reading.   This  Court,  after
      considering the judgments of the courts in  various  other  countries,
      held as under :
                 “19. From the conspectus of the views expressed  by  courts
                 in  England  and  also  in  India,  it  is  clear  that  in
                 considering the question, whether the arbitration clause in
                 a Charter Party Agreement was incorporated by reference  in
                 the Bill of Lading, the principal question is, what was the
                 intention of the parties to the Bill of  Lading?  For  this
                 purpose the primary document is the  Bill  of  Lading  into
                 which the arbitration clause in the Charter Party Agreement
                 is to be read in the manner provided in  the  incorporation
                 clause of  the  Bill  of  Lading.  While  ascertaining  the
                 intention of the parties, attempt should be  made  to  give
                 meaning to the incorporation clause and to give  effect  to
                 the same and not to invalidate or  frustrate  it  giving  a
                 literal, pedantic and technical reading of the  clause.  If
                 on a construction of the arbitration clause of the  Charter
                 Party Agreement as incorporated in the Bill  of  Lading  it
                 does  not  lead  to  inconsistency  or   insensibility   or
                 absurdity then effect should be given to the  intention  of
                 the parties and the arbitration clause as agreed should  be
                 made binding on parties to  the  Bill  of  Lading.  If  the
                 parties  to  the  Bill  of  Lading  being  aware   of   the
                 arbitration clause in  the  Charter  Party  Agreement  have
                 specifically incorporated the same in the conditions of the
                 Bill of Lading then the intention of the parties  to  abide
                 by the arbitration clause is clear.  Whether  a  particular
                 dispute  arising  between  the  parties  comes  within  the
                 purview of the arbitration clause as  incorporated  in  the
                 Bill of Lading is a matter to be decided by the  arbitratorChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

                 or  the  court.  But  that  does  not  mean  that   despite
                 incorporation of the arbitration  clause  in  the  Bill  of
                 Lading by specific reference the parties had  not  intended
                 that the disputes arising on the Bill of Lading  should  be
                 resolved by an arbitrator.”
      74.   Reference can also be made to the judgment of this Court in  the
      case of Olympus Superstructure Pvt. Ltd. v. Meena Vijay Khetan &  Ors.
      [(1999) 5 SCC 651], where the parties  had  entered  into  a  purchase
      agreement for the purchase of flats.  The main agreement contained the
      arbitration clause (clause 39).  The parties also entered  into  three
      different Interior Design Agreements, which also contained arbitration
      clauses.  The main agreement was  terminated  due  to  disputes  about
      payment and non-grant of possession.  These disputes were referred  to
      arbitration.  A sole arbitrator was appointed to make awards  in  this
      respect.  Inter alia, the  question  was  raised  as  to  whether  the
      disputes under the Interior Design Agreements were  subject  to  their
      independent arbitration clauses or whether one and the same  reference
      was permissible under the main agreement.   It  was  argued  that  the
      reference under clause 39 of the main agreement could not  permit  the
      arbitrator to deal with  the  disputes  relating  to  Interior  Design
      Agreements and the award was void.  The Court, however, took the  view
      that parties had entered into multiple agreements for a common  object
      and the expression ‘other matters…connected with’ appearing in  clause
      39 would permit such a reference. The Court held as under :
           “30. If there is  a  situation  where  there  are  disputes  and
           differences in connection  with  the  main  agreement  and  also
           disputes in regard  to  “other  matters”  “connected”  with  the
           subject-matter of the main agreement then in such  a  situation,
           in our view, we are governed by the general  arbitration  clause
           39 of the main agreement under which  disputes  under  the  main
           agreement and disputes connected therewith can  be  referred  to
           the same arbitral tribunal. This clause 39  no  doubt  does  not
           refer to any named arbitrators.  So  far  as  clause  5  of  the
           Interior Design Agreement is concerned, it  refers  to  disputes
           and  differences  arising  from  that  agreement  which  can  be
           referred to named arbitrators and the  said  clause  5,  in  our
           opinion, comes into play only in a situation where there are  no
           disputes and differences in relation to the main  agreement  and
           the disputes and differences are solely confined to the Interior
           Design Agreement. That, in our view, is the  true  intention  of
           the parties and that is  the  only  way  by  which  the  general
           arbitration provision in clause 39 of the main agreement and the
           arbitration provision for a named arbitrator contained in clause
           5  of  the  Interior  Design  Agreement  can  be  harmonised  or
           reconciled. Therefore, in a case  like  the  present  where  the
           disputes and differences cover the main agreement as well as the
           Interior Design Agreement, — (that there  are  disputes  arising
           under the main agreement and the Interior  Design  Agreement  is
           not in dispute) — it is the general arbitration clause 39 in theChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

           main agreement that governs because the questions arise also  in
           regard to disputes relating to  the  overlapping  items  in  the
           schedule  to  the  main  agreement  and  the   Interior   Design
           Agreement, as detailed  earlier.  There  cannot  be  conflicting
           awards in regard to items which overlap in the  two  agreements.
           Such a situation was never  contemplated  by  the  parties.  The
           intention of the parties when they incorporated clause 39 in the
           main agreement and clause 5 in the Interior Design Agreement was
           that the former clause was to apply  to  situations  when  there
           were disputes arising under both agreements and the  latter  was
           to apply  to  a  situation  where  there  were  no  disputes  or
           differences arising under the main contract but the disputes and
           differences were confined only to the Interior Design Agreement.
           A case containing two agreements with arbitration clauses  arose
           before this Court in Agarwal Engg. Co. v. Technoimpex  Hungarian
           Machine Industries Foreign  Trade  Co.  There  were  arbitration
           clauses in two contracts, one for sale of two  machines  to  the
           appellant and  the  other  appointing  the  appellant  as  sales
           representative. On the facts of the case, it was held that  both
           the clauses operated separately and this conclusion was based on
           the specific clause in the sale contract that it was  the  “sole
           repository” of the sale transaction of the two machines. Krishna
           Iyer,  J.  held  that  if  that  were  so,  then  there  was  no
           jurisdiction  for  travelling  beyond  the  sale  contract.  The
           language of the other  agreement  appointing  the  appellant  as
           sales representative was prospective  and  related  to  a  sales
           agency and “later purchases”, other than the purchases of  these
           two machines. There  was  therefore  no  overlapping.  The  case
           before us and the above case exemplify contrary  situations.  In
           one case the disputes are connected and in the  other  they  are
           distinct and not connected. Thus, in the present case, clause 39
           of the main agreement  applies.  Points  1  and  2  are  decided
           accordingly in favour of the respondents.”
      75.   The Court also took the view that a dispute relating to specific
      performance of a contract in relation to immoveable property could  be
      referred to arbitration and Section 34(2)(b)(i) of the  1996  Act  was
      not attracted.  This finding of the Court clearly  supports  the  view
      that where the law does not prohibit  the  exercise  of  a  particular
      power, either the Arbitral Tribunal or the Court could  exercise  such
      power.  The Court, while taking this view, has obviously rejected  the
      contention that a contract for specific performance was not capable of
      settlement by  arbitration  under  the  Indian  law  in  view  of  the
      statutory provisions.  Such contention having been rejected,  supports
      the view that we have taken.
      THRESHOLD REVIEW
      76.   Where the Court which, on its judicial side,  is  seized  of  an
      action in a matter in respect  of  which  the  parties  have  made  anChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      arbitration agreement, once the required ingredients are satisfied, it
      would refer the parties to arbitration but for the situation where  it
      comes  to  the  conclusion  that  the  agreement  is  null  and  void,
      inoperative or incapable of being performed.  These  expressions  have
      to be construed somewhat strictly so  as  to  ensure  that  the  Court
      returns a finding with certainty and on the correct premise of law and
      fact as it has the effect of depriving  the  party  of  its  right  of
      reference to arbitration.  But once the Court finds that the agreement
      is valid then it must make the reference, without any further exercise
      of discretion {refer General  Electric  Co.  v.  Renusagar  Power  Co.
      [(1987) 4 SCC 137]}.  These are the issues which go to the root of the
      matter  and  their  determination  at  the  threshold  would   prevent
      multiplicity of litigation and would even prevent futile  exercise  of
      proceedings before the arbitral tribunal.
      77.   The issue of whether the courts  are  empowered  to  review  the
      existence and validity of the arbitration agreement prior to reference
      is more controversial.   A majority of  the  countries  admit  to  the
      positive effect of kompetenz kompetenz principle, which requires  that
      the arbitral tribunal must  exercise  jurisdiction  over  the  dispute
      under the arbitration agreement.  Thus, challenge to the existence  or
      validity of the arbitration agreement will not  prevent  the  arbitral
      tribunal  from  proceeding  with   hearing   and   ruling   upon   its
      jurisdiction.  If it retains jurisdiction, making of an award  on  the
      substance of the dispute would be permissible without waiting for  the
      outcome of any court  action  aimed  at  deciding  the  issue  of  the
      jurisdiction.   The  negative  effect  of  the   kompetenz   kompetenz
      principle is  that  arbitrators  are  entitled  to  be  the  first  to
      determine their jurisdiction which is later reviewable by  the  court,
      when there is action to enforce  or  set  aside  the  arbitral  award.
      Where the dispute is not before an arbitral tribunal, the  Court  must
      also decline jurisdiction unless the arbitration agreement is patently
      void, inoperative or incapable of being performed.
      78.   This is the  position  of  law  in  France  and  in  some  other
      countries, but as far as the Indian Law is concerned, Section 45 is  a
      legislative mandate and does not admit of any ambiguity.  We must take
      note of the aspect of Indian law that Chapter I of Part II of the 1996
      Act does not contain any provision analogous  to  Section  8(3)  under
Part I of the Act.  In other words,  under  the  Indian  Law,  greater
      obligation is cast upon the Courts to determine whether the  agreement
      is valid, operative and capable of being performed  at  the  threshold
      itself.   Such  challenge  has  to  be  a  serious  challenge  to  the
      substantive contract or to the agreement, as in the  absence  of  such
      challenge, it has to be found that the agreement was valid,  operative
      and capable of being performed;  the  dispute  would  be  referred  to
      arbitration.  [State of Orissa  v. Klockner and Company  &  Ors.  (AIR
      1996 SC 2140)].
      79.    Alan  Redfern  and  Martin  Hunter  in  Law  and  Practice   of
      International Commercial Arbitration,  (Fourth  Edition)  have  opined
      that when several parties are involved in a  dispute,  it  is  usually
      considered desirable that the dispute should be dealt with in the sameChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      proceedings rather than in  a  series  of  separate  proceedings.   In
      general terms, this saves time, money, multiplicity of litigation  and
      more importantly, avoids the possibility of conflicting  decisions  on
      the same issues of fact and law since all issues are determined by the
      same arbitral tribunal  at  the  same  time.   In  proceedings  before
      national courts, it is generally possible to join  additional  parties
      or to consolidate  separate  sets  of  proceedings.   In  arbitration,
      however, this is difficult,  sometimes  impossible,  to  achieve  this
      because the arbitral process  is  based  upon  the  agreement  of  the
      parties.
      80.   Where there is multi-party arbitration, it may be because  there
      are several parties to one contract or it may  be  because  there  are
      several contracts with different parties that have a  bearing  on  the
      matter in dispute.  It is helpful  to  distinguish  between  the  two.
      Where there are several parties to one contract, like a joint  venture
      or some other legal relationship of  similar  kind  and  the  contract
      contains an arbitration clause, when a dispute arises, the members  of
      the consortium or the joint venture may decide that  they  would  each
      like to appoint an  arbitrator.   In  distinction  thereto,  in  cases
      involving  several  contracts  with  different  parties,  a  different
      problem arises.  They may have different issues in dispute.  Each  one
      of them  will  be  operating  under  different  contracts  often  with
      different choice of law and arbitration clauses and yet,  any  dispute
      between say the employer and the main contractor is likely to  involve
      or affect one or more of the suppliers or sub-contractors, even  under
      other contracts.  What happens when the dispute  between  an  employer
      and the main contractor is  referred  to  arbitration,  and  the  main
      contractor wishes to join the sub-contractor in  the  proceedings,  on
      the basis that  if  there  is  any  liability  established,  the  main
      contractor  is  entitled  to  pass  on  such  liability  to  the  sub-
      contractor?  This was the issue raised in the Adgas  case  {Abu  Dhabi
      Gas Liquefaction Co. Ltd.  v.  Eastern Bechtel Corp. [1982] 2  Lloyd’s
      Rep. 425, CA}.  Adgas was the owner of a plant that produced liquefied
      natural gas in the Arabian Gulf.  The company started  arbitration  in
      England  against  the  main   contractors   under   an   international
      construction contract, alleging that one of the huge  tanks  that  had
      been constructed to store the gas was defective.  The main  contractor
      denied liability but added that, if the tank was defective, it was the
      fault  of  the  Japanese  sub-contractor.   Adgas   brought   ad   hoc
      arbitration proceedings against the  main  contractor  before  a  sole
      arbitrator in London.   The  main  contractor  then  brought  separate
      arbitration proceedings, also in London,  against  the  Japanese  sub-
      contractor.
      81.   There is little doubt that if the matter had been  litigated  in
      an English court, the Japanese company would have  been  joined  as  a
      party to the action.  However, Adgas did not agree that  the  Japanese
      sub-contractor should be brought into its arbitration  with  the  main
      contractor, since this  would  have  lengthened  and  complicated  the
      proceedings.  The Japanese sub-contractor also did  not  agree  to  be
      joined.  It preferred to await the outcome of the main arbitration, to
      see whether or not there was a case to answer.Chloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      82.   Lord Denning, giving judgment in the English
      Court  of  Appeal,  plainly  wished  that  an  order  could  be   made
      consolidating the two sets of arbitral proceedings so as to save  time
      and money and to avoid the risk of inconsistent awards:
                 “As we have often pointed out, there is a danger in  having
                 two separate arbitrations in a case like this.   You  might
                 get  inconsistent  findings  if  there  were  two  separate
                 arbitrators.  This has been said in many cases…it  is  most
                 undesirable that there should be inconsistent  findings  by
                 two  separate  arbitrators  on  virtually   the   self-same
                 question, such as causation.  It  is  very  desirable  that
                 everything should be done to avoid such a circumstance [Abu
                 Dhabi Gas, op.cit.at 427]”
      83.   We have already referred  to  the  contention  of  Mr.  Fali  S.
      Nariman, the learned senior counsel appearing for the appellant,  that
      the provisions of Section 45 of the 1996 Act are somewhat  similar  to
      Article II(3) of the New York Convention and the expression  ‘parties’
      in that Section would mean that ‘all parties to the action’ before the
      Court have to be the parties to the arbitration agreement.  If some of
      them are parties to the agreement, while the others are  not,  Section
      45 does not contemplate the applicable procedure and the status of the
      non-signatories.  The consequences of all parties not being common  to
      the action and arbitration  proceedings  are,  as  illustrated  above,
      multiplicity of proceedings and frustration of the intended ‘one  stop
      action’.  The Rule of  Mischief  would  support  such  interpretation.
      Even if some unnecessary parties are added to the  action,  the  Court
      can always strike out such parties and even the  cause  of  action  in
      terms of the provisions of the CPC. However, where such parties cannot
      be struck off, there the proceedings must  continue  only  before  the
      Court.
      84.   Thus, the provisions of Section 45 cannot be effectively applied
      or even invoked.  Unlike Section 24 of the 1940 Act,  under  the  1996
      Act the Court has not been given the power  to  refer  to  arbitration
      some of the parties from amongst the parties to the suit.  Section  24
      of 1940 Act vested the Court with the discretion that where the  Court
      thought fit, it could refer such matters and  parties  to  arbitration
      provided the same could be separated from  the  rest  of  the  subject
      matter of the suit.  Absence of such provision in the 1996 Act clearly
      suggests that the Legislature intended not  to  permit  bifurcated  or
      partial references of dispute  or  parties  to  arbitration.   Without
      prejudice to this contention, it was also the argument that  it  would
      not  be  appropriate  and  even  permissible  to  make  reference   to
      arbitration when the issues and parties in action are not  covered  by
      the arbitration agreement.   Referring  to  the  consequences  of  all
      parties  not  being  common  to  the  action  before  the  Court   and
      arbitration, the disadvantages are:Chloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      a)    There would be multiplicity of litigation;
      b)    Application of  principle  of  one  stop  action  would  not  be
           possible; and
      c)    It will frustrate the application of the Rule of Mischief.   The
           Court can prevent  the  mischief  by  striking  out  unnecessary
           parties or causes of action.
      85.   It would, thus, imply that a stranger or a  third  party  cannot
      ask for arbitration.  The expression ‘claiming through or under’  will
      have to be construed strictly and restricted to  the  parties  to  the
      arbitration agreement.
      86.    Another  issue  raised  before  the  Court  is  that  there  is
      possibility of the arbitration  proceedings  going  on  simultaneously
      with the suit, which would result in rendering passing of  conflicting
      orders possible.  This would be contrary to the public policy of India
      that Indian courts can give effect to the foreign awards which are  in
      conflict with judgment of the Indian courts.
      87.   To the contra, Mr. Salve, learned senior counsel  appearing  for
      respondent  No.1,  contended  that   the   expressions   ‘parties   to
      arbitration’, ‘any person claiming through or under him’ and  ‘at  the
      request of one of the party’ appearing in Section 45 are  wide  enough
      to include some or all the parties and even non-signatory parties  for
      the purposes of making a reference to arbitration.   It  is  also  the
      contention that on the true construction of Sections 44, 45 and 46  of
      the 1996 Act, it is not possible  to  accept  the  contention  of  the
      appellant that all the parties to an action have to be parties to  the
      arbitration agreement as well as the Court proceedings.  This would be
      opposed to the principle that parties should be held to their  bargain
      of arbitration.  The Court always has the choice to  make  appropriate
      orders in exercise of inherent powers to bifurcate  the  reference  or
      even stay the proceedings  in  a  suit  pending  before  it  till  the
      conclusion of the arbitration proceedings or otherwise.  According  to
      Mr. Salve, if the interpretation advanced by Mr. Nariman is  accepted,
      then mischief will be encouraged which would frustrate the arbitration
      agreement because a party not desirous of going to  arbitration  would
      initiate  civil  proceedings  and  add  non-signatory   as   well   as
      unnecessary parties to the suit with  a  view  to  avoid  arbitration.
      This would completely frustrate the legislative object underlining the
      1996 Act.  Non-signatory parties can even be deemed to be  parties  to
      the arbitration agreement and may successfully pray  for  referral  to
      arbitration.
      88.   As noticed above, the legislative intent and essence of the 1996
      Act  was  to  bring  domestic  as  well  as  international  commercial
      arbitration in consonance with the UNCITRAL Model Rules, the New  York
      Convention and the Geneva Convention.  The  New  York  Convention  was
      physically before the Legislature and available for its  consideration
      when it enacted the 1996 Act.  Article II of the  Convention  providesChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      that each contracting State shall recognise an agreement and submit to
      arbitration all or any differences which  have  arisen  or  which  may
      arise between them in respect of a defined legal relationship, whether
      contractual or not concerning a subject matter capable  of  settlement
      by arbitration.   Once the agreement is there and the Court is  seized
      of an action in relation to such subject matter, then on  the  request
      of one of the parties, it  would  refer  the  parties  to  arbitration
      unless the agreement is null and void,  inoperative  or  incapable  of
      performance.
      89.   Still,  the  legislature  opted  to  word  Section  45  somewhat
      dissimilarly.   Section 8 of the 1996 Act  also  uses  the  expression
      ‘parties’ simpliciter without any extension.    In significant contra-
      distinction, Section 45 uses the expression ‘one of the parties or any
      person claiming through or  under  him’  and  ‘refer  the  parties  to
      arbitration’, whereas the rest  of  the  language  of  Section  45  is
      similar to that of Article II(3) of the  New  York  Contention.    The
      Court cannot ignore this aspect and has to give due weightage  to  the
      legislative intent.    It is a settled  rule  of  interpretation  that
      every word used by the Legislature in a provision should be given  its
      due meaning. To us, it appears that the Legislature intended to give a
      liberal meaning to this expression.
      90.   The language of Section 45 has wider import.  It refers  to  the
      request of a party and then refers  to  an  arbitral  tribunal,  while
      under Section 8(3) it is upon the application of one  of  the  parties
      that the court may refer the parties to arbitration.   There  is  some
      element of similarity in the language of Section 8 and Section 45 read
      with Article II(3).  The language and expressions used in Section  45,
      ‘any  person  claiming  through  or  under  him’  including  in  legal
      proceedings may seek reference of all parties  to  arbitration.   Once
      the words used by the Legislature are of wider connotation or the very
      language of section is structured with liberal  protection  then  such
      provision should normally be construed liberally.
      91.   Examined from the point of view of the  legislative  object  and
      the intent of the framers of  the  statute,  i.e.,  the  necessity  to
      encourage  arbitration,  the  Court  is  required  to   exercise   its
      jurisdiction  in  a  pending  action,  to  hold  the  parties  to  the
      arbitration clause and not to permit them to avoid  their  bargain  of
      arbitration by bringing civil action involving multifarious  cause  of
      action, parties and prayers.
      Legal Relationship
      92.    Now,  we  should  examine  the  scope  of  concept  of   ‘legal
      relationship’ as  incorporated  in  Article  II(1)  of  the  New  York
      Convention vis-à-vis the expression ‘any person  claiming  through  or
      under him’ appearing in Section 45 of the 1996  Act.    Article  II(1)
      and (3) have to be read in conjunction with Section  45  of  the  Act.
      Both these expressions have to be read in  harmony  with  each  other.
      Once they are so read, it will be evident that the  expression  “legal
      relationship” connotes the relationship of the party with  the  personChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      claiming through or under him.   A person may not be signatory  to  an
      arbitration agreement,  but  his  cause  of  action  may  be  directly
      relatable to that contract and thus, he may  be  claiming  through  or
      under one of those parties.  It is also stated in the Law and Practice
      of International  Commercial  Arbitration,  Alan  Redfern  and  Martin
      Hunter  (supra), that for the purposes of both the New York Convention
      and the UNCITRAL Model Law, it is sufficient that there  should  be  a
      defined “legal relationship” between the parties, whether  contractual
      or not. Plainly there has to be some contractual relationship  between
      the parties, since there must be some arbitration  agreement  to  form
      the basis of the arbitral proceedings.   Given the existence  of  such
      an agreement, the dispute submitted to arbitration may be governed  by
      the principles of delictual or tortuous liability rather than  by  the
      law of contract.
      93.   In the case of Roussel - Uclaf v. G.D. Searle  &  Co.  Ltd.  And
      G.D. Searle & Co. [1978 Vol. 1 LLR 225], the Court held:
                 “The argument does not admit of much elaboration, but I see
                 no reason why these words in the Act should be construed so
                 narrowly as to exclude a  wholly-owned  subsidiary  company
                 claiming, as here, a right to sell patented articles  which
                 it has obtained from  and  been  ordered  to  sell  by  its
                 parent.  Of  course,  if  the  arbitration  proceedings  so
                 decide, it may eventually turn out that the parent  company
                 is at fault and  not  entitled  to  sell  the  articles  in
                 question at all; and, if so, the subsidiary will be equally
                 at fault.   But, if the parent is blameless, it seems  only
                 common  sense  that  the  subsidiary  should   be   equally
                 blameless.   The two parties and their actions are,  in  my
                 judgment, so closely related on the facts in this case that
                 it would be right to hold that the subsidiary can establish
                 that it is within the purview of the arbitration clause, on
                 the basis that it is “claiming through or under” the parent
                 to do what it is in fact doing whether ultimately  held  to
                 be wrongful or not.”
      94.   However, the view expressed by the Court in the above case  does
      not find approval in the decision of the Court of Appeal in  the  case
      of City of London v. Sancheti [(2009) 1 Lloyds Law Reports  116].   In
      paragraph 34, it was held that the view in the case of  Roussel  Uclaf
      need not be followed and stay could not be obtained against a party to
      an arbitration agreement or a person claiming through or under such  a
      party, as mere local or commercial connection is not sufficient.   But
      the Court of Appeal hastened to add that, in cases such as the one  of
      Mr.  Sancheti,  the  Corporation  of  London  was  not  party  to  the
      arbitration agreement, but the relevant party is  the  United  Kingdom
      Government.  The fact that in certain circumstances, the State may  be
      responsible under international law for the acts of one of  its  localChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      authorities, or may have to take steps to redress wrongs committed  by
      one of the local authorities, does not  make  the  local  authority  a
      party to the arbitration agreement.
      95.   Having examined both the  above-stated  views,  we  are  of  the
      considered opinion that it will be the facts  of  a  given  case  that
      would act as precept to the jurisdictional forum as to whether any  of
      the stated principles should be adopted or not.  If in the facts of  a
      given case, it is not possible to construe that the person approaching
      the forum is a party to the arbitration agreement or a person claiming
      through or under such party, then the case would not fall  within  the
      ambit and scope of the provisions of the section and  it  may  not  be
      possible for the Court to  permit  reference  to  arbitration  at  the
      behest of or against such party.
      96.   We have already referred to the  judgments  of  various  courts,
      that state that arbitration could be possible between a  signatory  to
      an agreement and a third party.   Of course, heavy onus lies  on  that
      party to show that in fact and in law, it is claiming under or through
      a signatory party, as contemplated under Section 45 of the 1996 Act.
      97.   Michael J. Mustill and Stewart C. Boyd in The Law  and  Practice
      of Commercial Arbitration in England have observed that the  applicant
      must show that the person whose claim he seeks to  stay  is  either  a
      party to the arbitration agreement or a  person  claiming  through  or
      under such a party.   It  is  further  noticed  that  it  occasionally
      happens that the plaintiff is not himself a party to  the  arbitration
      agreement on which the application is founded.   This may arise in the
      following situations :
        i) The plaintiff has acquired  the  rights,  which  the  action  is
           brought  to  enforce,  from  someone  who  is  a  party  to   an
           arbitration agreement with the defendant;
       ii) The plaintiff is bringing the action on behalf of someone  else,
           who is a party to an arbitration agreement with  the  defendant.
      iii) When the expression used in the provision, the  words  ‘claiming
           under plaintiff’ relate to  substantive  right  which  is  being
           asserted.
      98.   The requirements can scarcely be interpreted  in  their  literal
      sense, this would mean that a person could claim a  stay  even  though
      not a party to the arbitration  agreement.    However,  the  applicant
      must be party to the agreement against  whom  legal  proceedings  have
      been initiated rather than a party as intervenor.
      99.   Joinder of non signatory parties to arbitration is  not  unknown
      to the arbitration jurisprudence.    Even  the  ICCA’s  Guide  to  the
      Interpretation of the 1958 New York Convention also provides for  such
      situation, stating that when the question arises as to whether bindingChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      a non-signatory to an arbitration agreement could be read as being  in
      conflict with the requirement of written agreement under Article I  of
      the Convention, the most compelling answer is “no”  and  the  same  is
      supported by a number of reasons.
      100.  Various legal basis may be applied to bind a non-signatory to an
      arbitration agreement.   The first theory is that of implied  consent,
      third party beneficiaries, guarantors, assignment and  other  transfer
      mechanisms  of  contractual  rights.   This  theory  relies   on   the
      discernible intentions of the parties and, to a large extent, on  good
      faith principle.   They apply to  private  as  well  as  public  legal
      entities.   The second theory includes the legal doctrines  of  agent-
      principal relations, apparent authority, piercing of veil (also called
      the “alter ego”), joint venture relations,  succession  and  estoppel.
      They do not rely on the parties’ intention but rather on the force  of
      the applicable law.
      101.  We may also notice the Canadian  case  of  The  City  of  Prince
      George v. A.L. Sims & Sons Ltd. [YCA XXIII (1998), 223]   wherein  the
      Court  took  the  view  that  an  arbitration  agreement  is   neither
      inoperative nor incapable of being performed if a multi-party  dispute
      arises and not all parties are bound by the arbitration agreement: the
      parties bound by the arbitration  agreement  are  to  be  referred  to
      arbitration and court proceedings may continue  with  respect  to  the
      other parties, even if this creates a risk of conflicting decisions.
      102.  We have already discussed that  under  the  Group  of  Companies
      Doctrine, an arbitration agreement entered into by a company within  a
      group of companies can  bind  its  non-signatory  affiliates,  if  the
      circumstances demonstrate that the mutual intention of the parties was
      to bind both the signatory as well as the non-signatory parties.
      103.  The question of formal validity of the arbitration agreement  is
      independent of the nature of parties to  the  agreement,  which  is  a
      matter that belongs to the merits and is not  subject  to  substantive
      assessment.   Once it is determined that a valid arbitration agreement
      exists, it is a different step to establish which parties are bound by
      it.    Third  parties,  who  are  not  explicitly  mentioned   in   an
      arbitration agreement made in writing,  may  enter  into  its  ratione
      personae scope.   Furthermore, the Convention does not prevent consent
      to arbitrate from being provided by a person on behalf of  another,  a
      notion which is at the root of the theory of implied consent.
      104.  If one analyses the above  cases  and  the  authors’  views,  it
      becomes abundantly clear that reference of even non-signatory  parties
      to arbitration agreement can be made.     It  may  be  the  result  of
      implied or specific consent or judicial determination.   Normally, the
      parties to the arbitration agreement calling  for  arbitral  reference
      should be the same as those  to  the  an  action.   But  this  general
      concept is subject to exceptions which are that when  a  third  party,
      i.e. non-signatory party, is claiming or is  sued  as  being  directly
      affected through a party to the arbitration agreement  and  there  are
      principal and subsidiary agreements, and such third party is signatoryChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      to a subsidiary agreement and not to the mother or principal agreement
      which contains the arbitration clause, then depending upon  the  facts
      and circumstances of the given case, it may be possible  to  say  that
      even such third party can be referred to arbitration.
      105.  In the present case, the corporate structure of  the  respondent
      companies  as  well  as  that  of  the  appellant  companies   clearly
      demonstrates a  legal  relationship  which  not  only  is  inter-legal
      relationship but also intra-legal relationship between the parties  to
      the lis  or  persons  claiming  under  them.   They  have  contractual
      relationship which arises out of the various contracts that spell  out
      the terms, obligations and roles of the respective parties which  they
      were expected to  perform  for  attaining  the  object  of  successful
      completion of the  joint  venture  agreement.     This  joint  venture
      project was not dependant on any single agreement but was  capable  of
      being achieved only upon fulfillment of all  these  agreements.     If
      one floats a joint venture company, one must essentially  know-how  to
      manage  it  and  what  shall  be  the  methodology  adopted  for   its
      management.   If one manages it well, one must  know  what  goods  the
      said company is to produce and with what technical knowhow.   Even  if
      these requisites are satisfied, then also one is required to know, how
      to create market, distribute and export such goods.  It is nothing but
      one single chain consisting of different components.  The parties  may
      choose to sign different agreements to effectively  implement  various
      aforementioned facets right from managing to making profits in a joint
      venture company.  A party may not be signatory to an agreement but its
      execution may directly be relatable to the main contract  even  though
      he claims through or under one of the main party to the agreement.  In
      such situations, the parties would aim  at  achieving  the  object  of
      making their bargain successful, by execution of  various  agreements,
      like in the present case.
      106.  The New York Convention clearly postulates that there should  be
      a defined legal relationship between the parties, whether  contractual
      or not, in relation to the differences that may have arisen concerning
      the subject matter capable of settlement  of  arbitration.    We  have
      referred to a number of judgments of the various courts  to  emphasize
      that in given circumstances, if  the  ingredients  above-noted  exist,
      reference to arbitration of a signatory and  even  a  third  party  is
      possible.    Though  heavy  onus  lies  on  the  person  seeking  such
      reference, multiple and multi-party agreements between the parties  to
      the arbitration agreement or persons claiming through  or  under  such
      parties is neither impracticable nor impermissible.
      107.  Next, we are to examine the issue whether the cause of action in
      a suit can be bifurcated and a partial reference may be  made  by  the
      Court.  Whatever be the answer to this question, a necessary corollaryChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      is as to whether the Court should or should not stay  the  proceedings
      in  the  suit?   Further,  this  may  give  rise  to  three  different
      situations.  Firstly, while making reference of the subject matter  to
      arbitration,  whether  the  suit  may  still  survive,  partially   or
      otherwise; secondly, whether the suit, still pending before the Court,
      should be stayed completely; and lastly, whether both the  arbitration
      and the suit proceedings could be permitted to proceed  simultaneously
      in accordance with law.
      108.  Mr. Nariman, the learned senior counsel, while relying upon  the
      judgments in the cases of Turnock  v.  Sartoris  [1888  (43)  Chancery
      Division, 1955 SCR 862], Taunton-Collins v. Cromie & Anr., [1964 Vol.1
      Weekly Law Reports 633] and  Sumitomo  Corporation  v.  CDS  Financial
      Services  (Mauritius)  Ltd.  and  Others  [(2008)  4  SCC  91]   again
      emphasized that the parties to the agreement have to be parties to the
      suit and also that the cause of action  cannot  be  bifurcated  unless
      there was a specific provision in the 1996 Act itself permitting  such
      bifurcation or splitting of cause of action.  He also  contended  that
      there is no provision like Sections 21 and 24 of the 1940 Act  in  the
      1996 Act and thus, it supports the view that bifurcation of  cause  of
      action is impermissible and  such  reference  to  arbitration  is  not
      permissible.
      109.  In the case of Turnock (supra), the Court had stated that it was
      not right to cut up that litigation into two actions, one to be  tried
      before the arbitrator and the other to be tried elsewhere, as in  that
      case matters in respect of which  the  damages  were  claimed  by  the
      plaintiff could not  be  referred  to  arbitration  because  questions
      arising as to the construction of the agreement and provisions in  the
      lease deed were involved and they did not fall within the power of the
      arbitrator in face of the  arbitration  agreement.   In  the  case  of
      Taunton-Collins (supra), the Court again expressed the  view  that  it
      was undesirable that  there  should  be  two  proceedings  before  two
      different tribunals, i.e., the official referee and an Arbitrator,  as
      they may reach inconsistent findings.
      110.  This Court dealt with the provisions of the  1940  Act,  in  the
      case of Anderson Wright Ltd. v. Moran & Company [1955  SCR  862],  and
      described the conditions to be satisfied before a stay can be  granted
      in terms of Section 34 of the 1940 Act.  The Court also held  that  it
      was within the jurisdiction of  the  Court  to  determine  a  question
      whether the plaintiff was a  party  to  the  contract  containing  the
      arbitration clause or not.  Still in the case of Sumitomo  Corporation
      (supra), this Court primarily declined the  reference  to  arbitration
      for the reason that the disputes stated in the petition did  not  fall
      within the ambit of the arbitration clause contained in the  agreement
      between the parties and also that the Joint Venture Agreement did  not
      itself contain a specific arbitration clause.  An observation was also
      made in paragraph 20 of the judgment that the ‘party’ would mean  ‘the
      party to the judicial proceeding should be a party to the  arbitration
      agreement.
      111.  It will be appropriate to refer to the contentions of Mr. Salve,Chloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      the learned senior counsel.  According to him, reference, even of  the
      non-signatory party, could  be  made  to  arbitration  and  upon  such
      reference the proceedings in an action  before  the  Court  should  be
      stayed.   The  principle  of  bifurcation  of  cause  of  action,   as
      contemplated under the CPC, cannot stricto sensu apply to  Section  45
      of the 1996 Act in view of the non-obstante language of  the  Section.
      He also contended that parties or issues, even if outside the scope of
      the arbitration agreement, would not per  se  render  the  arbitration
      clause inoperative.  Even  if  there  is  no  specific  provision  for
      staying the proceedings in the suit  under  the  1996  Act,  still  in
      exercise of its inherent powers, the Court can direct stay of the suit
      proceedings or pass such other appropriate orders  as  the  court  may
      deem fit.
      112.  We would prefer to first deal with the precedents of this  Court
      cited before us.  As far as Sumitomo Corporation (supra) is concerned,
      it was a case dealing with the  matter  where  the  proceedings  under
Section 397-398 of the  Companies  Act  had  been  initiated  and  the
      Company Law Board had passed an order.   Whether  the  appeal  against
      such order would lie to the High  Court  was  the  principal  question
      involved in that  case.   The  denial  of  arbitration  reference,  as
      already noticed, was based upon the reasoning that disputes related to
      the joint venture agreement to which the parties  were  not  signatory
      and the said agreement did not even contain  the  arbitration  clause.
      On the other  hand,  it  was  the  other  agreement  entered  into  by
      different parties which contained the arbitration clause.  As  already
      noticed, in paragraph 20, the Court had observed that a  party  to  an
      arbitration agreement has to be a party to  the  judicial  proceedings
      and then alone it will fall within the ambit of Section  2(h)  of  the
      1996 Act.  As far as the first issue is concerned,  we  shall  shortly
      proceed to discuss it when we discuss the  merits  of  this  case,  in
      light of  the  principles  stated  in  this  judgment.   However,  the
      observations made by  the  learned  Bench  in  the  case  of  Sumitomo
      Corporation (supra) do not appear to be  correct.  Section  2(h)  only
      says that ‘party’ means a party to  an  arbitration  agreement.   This
      expression falls in the Chapter dealing  with  definitions  and  would
      have to be construed along with the other relevant provisions  of  the
      Act.   When  we  read  Section  45  in  light  of  Section  2(h),  the
      interpretation given by the Court in the case of Sumitomo  Corporation
      (supra) does not stand to  the  test  of  reasoning.   Section  45  in
      explicit language permits the parties  who  are  claiming  through  or
      under a main party to the arbitration agreement to seek  reference  to
      arbitration.  This is so, by  fiction  of  law,  contemplated  in  the
      provision of Section 45 of the 1996 Act.
      113.  We have already discussed above that the language of Section  45
      is incapable of being construed narrowly and must  be  given  expanded
      meaning to achieve the twin objects of arbitration, i.e., firstly, the
      parties should be held to their bargain of arbitration  and  secondly,
      the legislative intent behind incorporating the New York Convention as
      part of Section 44 of the Act must be protected.  Moreover,  paragraph
      20 of the judgment of Sumitomo Corporation (supra) does not state  any
      principle of law and in any event it records no reasons  for  arrivingChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      at such a conclusion.  In fact, that was not even directly  the  issue
      before the Court so as to operate as a binding  precedent.  For  these
      reasons, respectfully but without hesitation, we  are  constrained  to
      hold that the conclusion or the statement made in paragraph 20 of this
      judgment does not enunciate the correct law.
      Scope of jurisdiction while referring the parties to arbitration
      114.  An  application  for  appointment  of  arbitral  tribunal  under
Section 45 of the 1996 Act would also be governed by the provisions of
Section 11(6) of the Act.  This question is no more  res  integra  and
      has been settled by decision of a Constitution Bench of  seven  Judges
      of this Court in the case of SBP and Co. v. Patel Engineering Ltd. and
      Anr. [(2005) 8 SCC 618], wherein this Court held that power  exercised
      by the Chief Justice is not an administrative power.  It is a judicial
      power.  It is a settled  principle  that  the  Chief  Justice  or  his
      designate Judge will decide preliminary  aspects  which  would  attain
      finality unless otherwise directed  to  be  decided  by  the  arbitral
      tribunal.  In para 39 of the judgment, the Court held as under :
                 “39. It is necessary  to  define  what  exactly  the  Chief
                 Justice, approached with an application under Section 11 of
                 the Act, is to decide at that stage. Obviously, he  has  to
                 decide his own jurisdiction in the sense whether the  party
                 making the motion has approached the right High  Court.  He
                 has to decide whether there is an arbitration agreement, as
                 defined in the Act and whether the person who has made  the
                 request before him, is a party to such an agreement. It  is
                 necessary to indicate that he can also decide the  question
                 whether the claim was a dead one; or  a  long-barred  claim
                 that was sought to be resurrected and whether  the  parties
                 have concluded the transaction by recording satisfaction of
                 their mutual rights and obligations  or  by  receiving  the
                 final payment without objection. It may not be possible  at
                 that stage, to decide whether a live  claim  made,  is  one
                 which comes within the purview of the  arbitration  clause.
                 It will be appropriate to leave that question to be decided
                 by the Arbitral Tribunal on taking evidence, along with the
                 merits of the claims involved in the arbitration. The Chief
                 Justice has to decide whether the applicant  has  satisfied
                 the conditions for appointing an arbitrator  under  Section
                 11(6) of the Act. For the purpose of taking a  decision  on
                 these aspects, the Chief Justice can either proceed on  the
                 basis of affidavits and the documents produced or take such
                 evidence  or  get  such  evidence  recorded,  as   may   be
                 necessary. We think that adoption of this procedure in  the
                 context of the Act would best serve the purpose  sought  to
                 be achieved  by  the  Act  of  expediting  the  process  of
                 arbitration, without too many approaches to  the  court  atChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

                 various stages  of  the  proceedings  before  the  Arbitral
                 Tribunal.”
      115.  This aspect of the arbitration law was explained by a two  Judge
      Bench of this Court in the case of Shree Ram  Mills  Ltd.  v.  Utility
      Premises (P) Ltd. [(2007) 4 SCC 599] wherein, while referring  to  the
      judgment in SBP & Co. (supra) particularly the above  paragraph,  this
      Court held that the scope of order under Section 11 of  the  1996  Act
      would take in its ambit the issue regarding  territorial  jurisdiction
      and the existence of the arbitration  agreement.   The  Court  noticed
      that if these issues are not decided  by  the  Chief  Justice  or  his
      designate,  there  would  be  no  question  of  proceeding  with   the
      arbitration.  It held as under:
                 “27…Thus,  the  Chief  Justice  has  to  decide  about  the
                 territorial jurisdiction and also whether there  exists  an
                 arbitration agreement between the parties and whether  such
                 party has approached  the  court  for  appointment  of  the
                 arbitrator. The Chief Justice has to examine as to  whether
                 the claim is a dead one or in the sense whether the parties
                 have already concluded the transaction  and  have  recorded
                 satisfaction of their  mutual  rights  and  obligations  or
                 whether  the  parties   concerned   have   recorded   their
                 satisfaction regarding the financial claims.  In  examining
                 this  if  the  parties  have  recorded  their  satisfaction
                 regarding the financial claims, there will be  no  question
                 of any issue remaining. It is in this sense that the  Chief
                 Justice has to examine as to whether there remains anything
                 to be  decided  between  the  parties  in  respect  of  the
                 agreement and whether the parties are still at issue on any
                 such matter. If the Chief Justice does not, in  the  strict
                 sense, decide the issue, in that event it  is  for  him  to
                 locate such issue and record  his  satisfaction  that  such
                 issue exists between the parties. It is only in that  sense
                 that the finding on a live issue is given. Even at the cost
                 of repetition we must state that it is only for the purpose
                 of finding out whether the arbitral  procedure  has  to  be
                 started that the Chief Justice has to  record  satisfaction
                 that there remains a live issue in between the parties. The
                 same thing is about the limitation which is always a  mixed
                 question of law and fact. The Chief  Justice  only  has  to
                 record his satisfaction that prima facie the issue has  not
                 become dead by the lapse of time or that any party  to  the
                 agreement has not slept over its  rights  beyond  the  time
                 permitted by law to agitate those  issues  covered  by  the
                 agreement. It is for this reason that it was pointed out in
                 the above para that it would be  appropriate  sometimes  to
                 leave the question regarding the live claim to  be  decided
                 by the Arbitral Tribunal. All that  he  has  to  do  is  to
                 record his satisfaction that the parties  have  not  closed
                 their  rights  and  the  matter  has  not  been  barred  byChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

                 limitation. Thus,  where  the  Chief  Justice  comes  to  a
                 finding that there exists a live issue, then naturally this
                 finding would include a finding that the respective  claims
                 of the parties have not become barred by limitation.
                                                        (emphasis supplied)”
      116.  Thus, the Bench while explaining the judgment of this  Court  in
      SBP & Co. (supra) has stated that the Chief  Justice  may  not  decide
      certain issues finally and  upon  recording  satisfaction  that  prima
      facie the issue has not become dead even leave  it  for  the  arbitral
      tribunal to decide.
      117.  In National Insurance Co.  Ltd.  v.  Boghara  Polyfab  (P)  Ltd.
      [(2009) 1 SCC 267], another equi-bench of this Court after  discussing
      various judgments of this  Court,  explained  SBP  &  Co.  (supra)  in
      relation to scope of powers of the Chief Justice and/or his  designate
      while exercising jurisdiction under Section 11(6), held as follows :
                 “22. Where the intervention of  the  court  is  sought  for
                 appointment of an Arbitral Tribunal under Section  11,  the
                 duty of the Chief Justice or his designate  is  defined  in
                 SBP  &  Co.  This  Court  identified  and  segregated   the
                 preliminary issues that may arise for consideration  in  an
                 application  under  Section  11  of  the  Act  into   three
                 categories, that is, (i) issues which the Chief Justice  or
                 his designate is bound to decide; (ii) issues which he  can
                 also decide, that is, issues which he may choose to decide;
                 and (iii) issues which  should  be  left  to  the  Arbitral
                 Tribunal to decide.
                 22.1.  The  issues  (first  category)   which   the   Chief
                 Justice/his designate will have to decide are:
                 (a)    Whether  the  party  making  the   application   has
                       approached the appropriate High Court.
                 (b)   Whether there is an arbitration agreement and whether
                       the party who has applied under  Section  11  of  the
                       Act, is a party to such an agreement.
                 22.2.  The  issues  (second  category)  which   the   Chief
                 Justice/his designate may choose to decide (or  leave  them
                 to the decision of the Arbitral Tribunal) are:Chloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

                 (a)   Whether the claim is a dead (long-barred) claim or  a
                       live claim.
                 (b)     Whether   the   parties    have    concluded    the
                       contract/transaction  by  recording  satisfaction  of
                       their mutual rights and obligation  or  by  receiving
                       the final payment without objection.
                 22.3.  The  issues  (third  category)   which   the   Chief
                 Justice/his  designate  should  leave  exclusively  to  the
                 Arbitral Tribunal are:
                 (i)   Whether a claim made  falls  within  the  arbitration
                       clause (as for example, a matter  which  is  reserved
                       for final decision of a  departmental  authority  and
                       excepted or excluded from arbitration).
                 (ii)  Merits or any claim involved in the arbitration.”
      118.  We may notice that at first blush, the judgment in the  case  of
      Shree Ram Mills (supra) is at some variance with the judgment  in  the
      case of National Insurance Co.  Ltd.  (supra)  but  when  examined  in
      depth, keeping in view the judgment in the case of SBP &  Co.  (supra)
      and provisions of Section 11(6) of the 1996 Act, both these  judgments
      are found to be free from contradiction and capable of being  read  in
      harmony in order to bring them in line with the statutory law declared
      by the larger Bench in SBP &  Co.  (supra).   The  expressions  “Chief
      Justice does not in strict sense decide the issue” or “is prima  facie
      satisfied”, will have to be construed in the facts  and  circumstances
      of a given case.  Where the Chief Justice or  his  designate  actually
      decides the issue, then it can no longer be prima facie, but would  be
      a decision binding in law.  On such an issue,  the  Arbitral  Tribunal
      will have no jurisdiction to re-determine the issue.  In the  case  of
      Shree Ram Mills (supra), the Court held that the Chief  Justice  could
      record a finding where the issue between the parties was  still  alive
      or was dead by lapse of time.  Where it prima facie found the issue to
      be alive, the Court could leave the question of  limitation  and  also
      open to be decided by the arbitral tribunal.
      119.   The above expressions are mere observations of the Court and do
      not fit into the contours of the principle of ratio decidendi  of  the
      judgment.  The issues in  regard  to  validity  or  existence  of  the
      arbitration agreement, the application not satisfying the  ingredients
      of Section 11(6) of the 1996 Act and claims being barred by time  etc.Chloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      are the matters which can be adjudicated by the Chief Justice  or  his
      designate.  Once the parties are heard on such issues and  the  matter
      is determined in accordance with law, then such a finding can only  be
      disturbed by  the  Court  of  competent  jurisdiction  and  cannot  be
      reopened before the arbitral tribunal.  In  SBP  &  Co.  (supra),  the
      Seven Judge Bench clearly stated, “the finality given to the order  of
      the Chief Justice on the matters within his competence  under  Section
      11 of the Act are incapable of  being  reopened  before  the  arbitral
      tribunal”.  Certainly the Bench dealing with the  case  of  Shree  Ram
      Mills (supra) did not intend to lay down any law  in  direct  conflict
      with the Seven Judge Bench judgment in SBP  &  Co.  (supra).   In  the
      reasoning given in Shree Ram Mills’ case, the Court has clearly stated
      that matters of existence and binding nature of arbitration  agreement
      and other matters mentioned therein are to be  decided  by  the  Chief
      Justice or his designate and the same is in line with the judgment  of
      this Court in the case of SBP &  Co.  (supra).   It  will  neither  be
      permissible nor in consonance with  the  doctrine  of  precedent  that
      passing observations by the Bench should be construed as the law while
      completely ignoring the ratio decidendi of that very judgment. We  may
      also notice that the judgment in  Shree  Ram  Mills  (supra)  was  not
      brought to the notice of the Bench which pronounced  the  judgment  in
      the case of National Insurance Co. Ltd. (supra).
      120.  As far as the classification carved out by the Court in the case
      of National Insurance Co. Ltd. (supra) are  concerned,  it  draws  its
      origin from paragraph 39 of the judgment in the  case  of  SBP  &  Co.
      (supra) wherein the Constitution Bench of the Court had observed  that
      “it may not be possible at that stage to decide whether a  live  claim
      made is one which comes within the purview of the arbitration  clause.
      It will be more appropriate to leave the seriously disputed  questions
      to be decided by the Arbitral Tribunal on taking evidence  along  with
      the merits of the claim, subject matter of the arbitration.”
      121.  The foundation for category (2)  in  para  22  of  the  National
      Insurance Company Ltd. (supra) is directly relatable to para 39 of the
      judgment of this court in SBP & Co. (supra)  and  matters  falling  in
      that  category  are  those  which,  depending   on   the   facts   and
      circumstances of a given case, could be decided by the  Chief  Justice
      or his designate  or  even  may  be  left  for  the  decision  of  the
      arbitrator, provided there  exists  a  binding  arbitration  agreement
      between the parties.  Similar is the approach of the Bench in the case
      of Shree Ram Mills (supra) and that is why in  paragraph  27  thereof,
      the Court has recorded that it would be appropriate sometimes to leave
      the question regarding the claim being alive  to  be  decided  by  the
      arbitral tribunal and the Chief Justice may  record  his  satisfaction
      that parties have not closed their rights and the matter has not  been
      barred by limitation.
      122.  As already noticed, the observations made by the Court  have  to
      be construed and read to support the ratio decidendi of the  judgment.
      Observations in a judgment which are stared upon by the judgment of  a
      larger bench would not constitute valid precedent as it will be hit by
      the doctrine of staire decisis.  In the case of  the  Shri  Ram  MillsChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      (supra) surely the Bench did not intend to lay down the law or state a
      proposition which is directly in conflict with  the  judgment  of  the
      Constitution Bench of this Court in the case of SBP & Co. (supra).
      123.  We have no reason to differ with the classification  carved  out
      in the case of National Insurance Co. (supra) as it is  very  much  in
      conformity with the judgment of the Constitution Bench in the case  of
      SBP (supra).  The question that follows from the above  discussion  is
      as to whether  the  views  recorded  by  the  judicial  forum  at  the
      threshold would be final and binding on  the  parties  or  would  they
      constitute the prima facie view.  This again has been a matter of some
      debate before this Court.  A three Judge Bench of this  Court  in  the
      case of Shin-Etsu Chemical Co. Ltd. v. M/s. Aksh Optifibre Ltd. & Anr.
      [(2005) 7 SCC 234] was dealing with an application for reference under
Section 45 of the 1996 Act and consequently, determination of validity
      of  arbitration  agreement  which  contained  the  arbitration  clause
      governed by the ICC Rules in Tokyo, Japan.  The appellant before  this
      Court had terminated the agreement in that case.  The respondent filed
      a suit claiming a decree of declaration  and  injunction  against  the
      appellant for  cancellation  of  the  agreement  which  contained  the
      arbitration clause.  In that very suit, the appellant also prayed that
      this long  term  sale  and  purchase  agreement,  which  included  the
      arbitration  clause  be  declared  void  ab  initio,  inoperative  and
      incapable of being performed on the ground  that  the  said  agreement
      contained unconscionable, unfair and unreasonable terms;  was  against
      public policy  and  was  entered  into  under  undue  influence.   The
      appellant had also filed an application under Section 8  of  the  1996
      Act for reference to arbitration.  Some controversy arose  before  the
      Trial Court as well as  before  the  High  Court  as  to  whether  the
      application was one under Section 8 or Section 45 but when the  matter
      came up before this Court, the counsel appearing for both the  parties
      rightly took the stand that only Section 45 was applicable and Section
      8 had no application.  In this case, the Court was primarily concerned
      and dwelled upon the question whether an order refusing  reference  to
      arbitration was appealable under Section 50 of the 1996 Act  and  what
      would be its effect.
      124.  We are not really concerned with the merits  of  that  case  but
      certainly are required to deal with the limited question  whether  the
      findings recorded by the referring Court are of final nature,  or  are
      merely prima facie and thus, capable of being  re-adjudicated  by  the
      arbitral tribunal.   Where  the  Court  records  a  finding  that  the
      agreement containing the arbitration clause or the arbitration  clause
      itself is null and void, inoperative or incapable of  being  performed
      on merits of the case, it  would  decline  the  reference.   Then  the
      channel of legal remedy  available  to  the  party  against  whom  the
      reference has been declined would be to take  recourse  to  an  appeal
      under Section 50(1)(a) of the 1996 Act.  The Arbitral Tribunal in such
      situations does not deliver any determination on  the  issues  in  the
      case. However, in the event that the referring Court deals  with  such
      an issue and returns a finding that objections to reference  were  not
      tenable, thus rejecting, the plea on merits, then the issue arises  as
      to whether the arbitral tribunal can re-examine the  question  of  theChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      agreement  being  null  and  void,   inoperative   or   incapable   of
      performance, all over again.  Sabharwal, J., after  deliberating  upon
      the approaches of different courts under the English and the  American
      legal  systems,  stated  that  both  the  approaches  have  their  own
      advantages and disadvantages.  The approach whereby the courts finally
      decide on merits in relation to the issue of existence and validity of
      the arbitration agreement would result to a large extent  in  avoiding
      delay and increased cost.  It would not be for the parties to wait for
      months or years before knowing  the  final  outcome  of  the  disputes
      regarding jurisdiction alone.  Then, he held as follows :
                 “56. I am of the  view  that  the  Indian  Legislature  has
                 consciously adopted a conventional approach so as  to  save
                 the  huge  expense  involved  in  international  commercial
                 arbitration as compared to domestic arbitration.
                 57. In view of the aforesaid discussion, I am of  the  view
                 that under Section 45 of the Act, the determination has  to
                 be on merits, final and binding and not prima facie.”
      125.  However, Srikrishna, J.  took  a  somewhat  different  view  and
      noticing the truth that there is nothing in Section 45 to suggest that
      a finding as to the nature of the arbitration agreement has to  be  ex
      facie or prima facie, observed that if it were to  be  held  that  the
      finding of the court under Section 45 should be a final, determinative
      conclusion, then it is obvious that  until  such  a  pronouncement  is
      made, the arbitral proceedings would have to be in limbo. So, he  held
      as follows :
                 “105. I fully agree with my learned Brother's view that the
                 object of dispute resolution through arbitration, including
                 international commercial  arbitration,  is  expedition  and
                 that the object of the Act would be defeated if proceedings
                 remain pending in the court even after  commencing  of  the
                 arbitration. It is precisely for  this  reason  that  I  am
                 inclined to  the  view  that  at  the  pre-reference  stage
                 contemplated by Section 45, the court is required  to  take
                 only a prima facie view for making the  reference,  leaving
                 the parties to a full  trial  either  before  the  Arbitral
                 Tribunal or before the court at the post-award stage.”
      126.  Dharmadhikari, J., the third member of the Bench, while agreeing
      with the view of  Srikrishna,  J.  and  noticing,  “Where  a  judicial
      authority or the court refuses to make  a  reference  on  the  grounds
      available under Section 45  of  the  Act,  it  is  necessary  for  the
      judicial authority or the court which is seized of the matter to  pass
      a reasoned order as the same is subject to  appeal  to  the  appellateChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      court under Section 50(1)(a) of the Act and  further  appeal  to  this
      Court under sub-section (2) of the said section.” expressed no view on
      the issue of prima facie or finality of the finding  recorded  on  the
      pre-reference stage, he  left  the  question  open  in  the  following
      paragraph :
                 “112. Whether such a decision of the judicial authority  or
                 the court, of  refusal  to  make  a  reference  on  grounds
                 permissible under Section 45 of the Act would be  subjected
                 to further re-examination before the Arbitral  Tribunal  or
                 the court in  which  eventually  the  award  comes  up  for
                 enforcement in accordance with Section 48(1)(a) of the Act,
                 is a legal question of  sufficient  complexity  and  in  my
                 considered opinion since that question  does  not  directly
                 arise on the facts of the present case, it should  be  left
                 open for consideration in an appropriate case where such  a
                 question is directly raised and decided by the court.”
      127.  The judgment of  this  Court  in  Shin-Etsu  Chemical  Co.  Ltd.
      (supra) preceded the judgment of this Court in the case of SBP  &  Co.
      (supra).  Though the Constitution Bench in the latter case referred to
      this judgment in paragraph 89 of the judgment but did not discuss  the
      merits or  otherwise  of  the  case  presumably  for  absence  of  any
      conflict. However, as already noticed, the Court clearly took the view
      that the findings returned by the Chief Justice while  exercising  his
      judicial powers under Section 11 relatable to Section 8 are final  and
      not open to be questioned by the arbitral tribunal. Sections 8 and  45
      of the 1996 Act are provisions independent of each other.  But for the
      purposes of reference to arbitration, in both cases, the applicant has
      to pray for a reference before the Chief Justice or his  designate  in
      terms of Section 11 of the 1996  Act.   We  may  refer  to  the  exact
      terminology used by the larger Bench in SBP & Co. (supra) in  relation
      to the finality of such matters,  as  reflected  in  para  12  of  the
      judgment which reads as under :
                 “12. Section 16 of the Act only makes explicit what is even
                 otherwise implicit,  namely,  that  the  Arbitral  Tribunal
                 constituted under the Act has the jurisdiction to  rule  on
                 its own jurisdiction, including ruling on  objections  with
                 respect to the existence or  validity  of  the  arbitration
                 agreement. Sub-section (1) also directs that an arbitration
                 clause which forms part of a contract shall be  treated  as
                 an  agreement  independent  of  the  other  terms  of   the
                 contract. It also clarifies that a decision by the Arbitral
                 Tribunal that the contract  is  null  and  void  shall  not
                 entail ipso jure the invalidity of the arbitration  clause.
                 Sub-section (2) of Section 16 enjoins that a party  wanting
                 to raise a plea that the Arbitral Tribunal  does  not  have
                 jurisdiction, has to raise that objection  not  later  than
                 the submission of the statement of defence,  and  that  the
                 party shall not be  precluded  from  raising  the  plea  ofChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

                 jurisdiction   merely   because   he   has   appointed   or
                 participated in the  appointment  of  an  arbitrator.  Sub-
                 section (3)  lays  down  that  a  plea  that  the  Arbitral
                 Tribunal is exceeding the scope of its authority, shall  be
                 raised as soon as the matter alleged to be beyond the scope
                 of its authority is raised during the arbitral proceedings.
                 When the Tribunal decides these two questions, namely,  the
                 question of jurisdiction and the question of exceeding  the
                 scope of authority or either of them, the same is  open  to
                 immediate challenge in an appeal,  when  the  objection  is
                 upheld and only in an appeal against the final award,  when
                 the objection is overruled. Sub-section (5) enjoins that if
                 the Arbitral Tribunal overrules the objections  under  sub-
                 section (2) or (3), it should continue  with  the  arbitral
                 proceedings and make an  arbitral  award.  Sub-section  (6)
                 provides that a party aggrieved by such an  arbitral  award
                 overruling  the  plea  on  lack  of  jurisdiction  and  the
                 exceeding  of  the  scope  of  authority,   may   make   an
                 application on these grounds for setting aside the award in
                 accordance with Section 34 of the Act. The question, in the
                 context of sub-section (7) of Section 11 is,  what  is  the
                 scope of the right conferred on the  Arbitral  Tribunal  to
                 rule upon its own jurisdiction and  the  existence  of  the
                 arbitration clause, envisaged by Section  16(1),  once  the
                 Chief Justice or the person designated by him had appointed
                 an arbitrator after satisfying himself that the  conditions
                 for the exercise of power  to  appoint  an  arbitrator  are
                 present in the case. Prima facie, it would be difficult  to
                 say that in spite of the finality conferred by  sub-section
                 (7) of Section 11 of the Act, to such  a  decision  of  the
                 Chief Justice, the Arbitral Tribunal can  still  go  behind
                 that decision and rule on its own jurisdiction  or  on  the
                 existence of an arbitration clause. It also appears  to  us
                 to be incongruous to say that after the Chief  Justice  had
                 appointed an Arbitral Tribunal, the Arbitral  Tribunal  can
                 turn  round  and  say  that  the  Chief  Justice   had   no
                 jurisdiction or authority to appoint the Tribunal, the very
                 creature brought into existence by the exercise of power by
                 its creator, the Chief Justice. The argument of the learned
                 Senior Counsel, Mr K.K. Venugopal that Section 16 has  full
                 play only when an Arbitral Tribunal is constituted  without
                 intervention under Section 11(6) of the Act, is one way  of
                 reconciling that provision with  Section  11  of  the  Act,
                 especially in the context of sub-section  (7)  thereof.  We
                 are inclined to the view that the  decision  of  the  Chief
                 Justice on the issue of jurisdiction and the existence of a
                 valid arbitration agreement would be binding on the parties
                 when the matter  goes  to  the  Arbitral  Tribunal  and  at
                 subsequent stages of the proceeding except in an appeal  in
                 the Supreme Court in the case of the decision being by  the
                 Chief Justice of the High Court or by a Judge of  the  High
                 Court designated by him.”
                                                         (Emphasis supplied)Chloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      128.  We are conscious of the fact that the above dictum of the  Court
      is in relation to the scope and application of Section 11 of the  1996
      Act.   It has been held in various judgments of this  Court  but  more
      particularly in the case of SBP (supra) which is binding  on  us  that
      before making a reference, the Court has to dispose of the  objections
      as contemplated under Section 8 or Section 45, as the case may be, and
      wherever needed upon filing of affidavits.   Thus, to an  extent,  the
      law laid down by this Court on Section 11 shall  be  attracted  to  an
      international arbitration which  takes  place  in  India  as  well  as
      domestic arbitration.   This, of course, would be applicable  at  pre-
      award stage.  Thus, there exists a direct legal link, limited to  that
      extent.
      129.  We are not oblivious of the principle ‘Kompetenz kompetenz’.  It
      requires the arbitral tribunal to rule on its own jurisdiction and  at
      the first instance.  One school of thought propagates that it has duly
      the positive effect as it enables the arbitrator to rule  on  its  own
      jurisdiction  as  it  widely  recognized  international   arbitration.
      However, the negative effect is equally important, that the Courts are
      deprived of their jurisdiction.  The arbitrators are  to  be  not  the
      sole judge but first judge, of their jurisdiction.  In other words, it
      is to allow them to come to a decision on their own jurisdiction prior
      to any court  or  other  judicial  authority  and  thereby  limit  the
      jurisdiction  of  the  national  courts  to  review  the  award.   The
      kompetenz kompetenz rule, thus, concerned not only is the positive but
      also the  negative  effect  of  the  arbitration  agreement.    [refer
      Fouchard Gaillard Goldman on International Commercial Arbitration]
      130.  This policy has found a favourable mention with reference to the
      New York Convention in some of the countries.   This  is  one  aspect.
      The more important aspect as far as Chapter I of Part II of  the  1996
      Act is concerned, is the absence of  any  provision  like  Section  16
      appearing in Part I of the same Act.  Section 16 contemplates that the
      arbitrator may determine its own  jurisdiction.   Absence  of  such  a
      provision in Part II, Chapter I is suggestive of the  requirement  for
      the Court to determine the ingredients of Section 45, at the threshold
      itself.  It is expected  of  the  Court  to  answer  the  question  of
      validity of the arbitration agreement, if a plea is  raised  that  the
      agreement containing the arbitration clause or the arbitration  clause
      itself is null and void, inoperative or incapable of being  performed.
      Such determination by the Court in accordance with law would certainly
      attain finality and would not be open  to  question  by  the  arbitral
      tribunal, even as per the principle  of  prudence.   It  will  prevent
      multiplicity to litigation and re-agitating of same  issues  over  and
      over again.  The underlining principle of finality  in  Section  11(7)
      would  be  applicable  with  equal  force  while  dealing   with   the
      interpretation of Sections 8 and 45.  Further, it may  be  noted  that
      even the judgment of this Court in SBP & Co. (supra) takes a  view  in
      favour of finality of determination by the Court despite the  language
      of Section 16 in Part I of the 1996 Act.  Thus, there could hardly  beChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      any possibility  for the Court to take any other view in  relation  to
      an  application  under  Section  45  of  the  1996  Act.   Since,  the
      categorization referred to by this  Court  in  the  case  of  National
      Insurance Company Ltd. (supra) is  founded  on  the  decision  by  the
      larger Bench of the Court in the case of SBP & Co. (supra), we see  no
      reason to express any  different  view.   The  categorization  falling
      under para 22.1 of the National Insurance Company case  (supra)  would
      certainly be answered by the Court before it makes a  reference  while
      under para 22.2 of that case, the Court may  exercise  its  discretion
      and decide the dispute itself or refer the  dispute  to  the  arbitral
      tribunal.  Still, under the cases falling under para 22.3,  the  Court
      is expected to leave  the  determination  of  such  dispute  upon  the
      arbitral tribunal itself.  But wherever the Court decides in terms  of
      categories mentioned in paras 22.1 and 22.2, the decision of the Court
      is unreviewable by the arbitral tribunal.
      131.  Another very significant  aspect  of  adjudicating  the  matters
      initiated with reference to  Section  45  of  the  1996  Act,  at  the
      threshold of  judicial  proceedings,  is  that  the  finality  of  the
      decision in regard to the fundamental issues stated under  Section  45
      would further the cause of justice and  interest  of  the  parties  as
      well.  To illustratively demonstrate  it,  we  may  give  an  example.
      Where party ‘A’ is seeking reference  to  arbitration  and  party  ‘B’
      raises objections going to the  very  root  of  the  matter  that  the
      arbitration agreement is null and void, inoperative and  incapable  of
      being performed, such  objections,   if  left  open  and  not  decided
      finally at the threshold itself may result in not only  parties  being
      compelled to pursue arbitration proceedings by  spending  time,  money
      and efforts but  even  the  arbitral  tribunal  would  have  to  spend
      valuable time in adjudicating  the  complex  issues  relating  to  the
      dispute between the parties, that may finally prove to be in vain  and
      futile.  Such adjudication by the arbitral tribunal  may  be  rendered
      ineffective or even a nullity in the event the courts upon  filing  of
      an award and at  execution  stage  held  that  agreement  between  the
      parties  was  null  and  void  inoperative  and  incapable  of   being
      performed.  The Court may also hold that the arbitral tribunal had  no
      jurisdiction to entertain and decide the issues between  the  parties.
      The issue of jurisdiction normally is a  mixed  question  of  law  and
      facts.  Occasionally, it may also be a question of law alone.  It will
      be appropriate to decide  such  questions  at  the  beginning  of  the
      proceedings itself and they  should  have  finality.   Even  when  the
      arbitration law in India contained the provision like  Section  34  of
      the 1940 Act which was somewhat similar to Section 4  of  the  English
      Arbitration Act, 1889, this Court in the case of Anderson Wright  Ltd.
      (supra) took the view that while dealing with the question of grant or
      refusal of stay as contemplated under Section 34 of the 1940  Act,  it
      would be incumbent upon the Court to decide first of all whether there
      is a binding agreement for arbitration between the parties to the suit
      or not.  Applying the analogy  thereof  will  fortify  the  view  that
      determination of fundamental issues as contemplated under  Section  45
      of the 1996 Act at the very first instance by the  judicial  forum  is
      not only appropriate but is also the legislative  intent.   Even,  the
      language of Section 45 of the 1996 Act suggests that unless the  CourtChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      finds that an agreement is null and void, inoperative and incapable of
      being performed, it shall refer the parties to arbitration.
      Correctness of Law stated in Sukanya
      132.  Though rival contentions have  been  raised  before  us  on  the
      correctness of the judgment of this Court  in  Sukanya  Holdings  Pvt.
      Ltd. (supra), Mr. Salve vehemently tried to persuade us to  hold  that
      this judgment does not state the correct exposition of law and to that
      effect it needs to be clarified by this Court in the present case.  On
      the contrary, Mr. Nariman argued that this judgment states the correct
      law and, in fact, the principles  stated  should  be  applied  to  the
      present case.
      133.  The ambit and scope of Section 45 of the 1996 Act, we  shall  be
      discussing shortly but at this stage itself, we would  make  it  clear
      that it is  not  necessary  for  us  to  examine  the  correctness  or
      otherwise of the judgment in the case of Sukanya (supra).  This we say
      for varied reasons.  Firstly, Sukanya was a judgment of this Court  in
      a case arising under Section 8 Part  I  of  the  1996  Act  while  the
      present case relates to Section 45 Part II of the Act.  As  such  that
      case may have no application to the present case.  Secondly,  in  that
      case the Court was  concerned  with  the  disputes  of  a  partnership
      concern.  A suit had been filed for dissolution  of  partnership  firm
      and accounts also challenging the  conveyance  deed  executed  by  the
      partnership firm in favour of one of the parties  to  the  suit.   The
      Court noticing the facts of the case emphasized that where the subject
      matter of the suit includes subject matter for  arbitration  agreement
      as well as other disputes, the Court  did  not  refer  the  matter  to
      arbitration in terms of Section 8 of the Act.  In the  case  in  hand,
      there is a mother agreement and there are other  ancillary  agreements
      to the mother agreement.   It  is  a  case  of  composite  transaction
      between the same parties or the parties claiming through or under them
      falling under Section 45 of the Act.  Thus, the dictum stated in  para
      13 of the judgment of Sukanya would not apply  to  the  present  case.
      Thirdly, on facts, the judgment in Sukanya’s case, has no  application
      to the case in hand.
      134.  Thus, we decline to examine  the  merit  or  otherwise  of  this
      contention.
      On Merits
      135.  The Corporate structure of the companies in the present case has
      already been stated by us in paragraph 7 which we need not refer  here
      again in detail.  Suffice it to note that Kocha group  had  floated  a
      company and incorporated the same under the  Indian  laws,  which  was
      carrying on the business  of  manufacture  of  chlorination  equipment
      under the name and style ‘Chloro Control India Private Limited’.  They
      were negotiating with Severn Trent  Water  Purification  Inc.  for  anChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      international joint venture agreement to deal  with  the  manufacture,
      distribution and sale  of  gas  chlorination  equipment  and  electro-
      chlorination equipment, “Hypogen Series 3300”  etc.   On  this  basis,
      they had entered into a  joint  venture  agreement  which  was  signed
      between them.  The  joint  venture  agreement  contemplated  that  the
      business shall be carried on under  the  name  and  style  of  Capital
      Controls India Ltd. Private Limited.  The agreements gave 50 per  cent
      shareholding to the foreign collaborators which  were  to  be  equally
      divided between Capital Control (Del) Company Inc. and Capital Control
      Company Inc.  These joint venture agreements were executed between the
      parties on 16th November, 1995 but the joint venture company had  been
      incorporated on 14th November, 1995  itself.   Severn  Trent  Services
      (Del) Inc. is the holding company of the companies which have  entered
      into the joint  venture  agreement  for  floating  both,  the  Capital
      Control India Ltd. as well as Severn Trent  De Nora LLC.  The disputes
      had arisen actually between the Kocha Group on the one hand and Severn
      Trent Water Purification Inc. on the  other,  and  the  disputes  were
      mainly with regard to Capital Control (India) Pvt. Ltd. Inc.  Now,  we
      must note, even at the cost of repetition, the  parties  signatory  to
      each of these  agreements  and  we  must  also  note  which  of  these
      agreements did not contain arbitration clause.  Shareholders Agreement
      dated 16th November, 1995 was executed  between  the  Capital  Control
      (Delaware) Company Inc. and Chloro Control India Private Ltd.  Capital
      Control Delaware  Company  Inc.  was  a  subsidiary  of  Severn  Trent
      Services (Delaware) Inc. and  was  formed  on  21st  September,  1994.
      Capital Control Company Inc. came to be merged  with  Capital  Control
      (Delaware) Company Inc. in  March  1994.   As  a  result  the  Capital
      Control  Delaware  Company  was  no  more  in  existence.   Thus,  the
      reference to  Capital  Control  Company  Inc.  includes  reference  to
      Capital Control Company Inc. as well  as  Capital  Control  (Delaware)
      Company Inc.
      136.  The corporate structure of the Companies involved in the present
      litigation clearly shows that name of Capital  Control  Company  Inc.,
      incorporated in the year 1994,  was  changed  to  Severn  Trent  Water
      Purification Inc. with effect from  April,  2002.   Thus,  both  these
      companies together were subsidiaries of  the  holding  company  Severn
      Trent Services  (Delaware)  Inc.   The  joint  venture  agreement  was
      executed between Chloro Control (India) Pvt. Ltd.  and  the  erstwhile
      Capital Control Company Inc. resulting  into  creation  of  the  joint
      venture company, Capital Control (India) Pvt. Ltd.  This is the  basic
      structure which one has to make clear before examining the  agreements
      and their impact.  The negotiations  between  the  appellant  and  the
      respondent nos.1 and 2 or their holding companies were going on  since
      1990 and ultimately culminated into execution  of  the  joint  venture
      agreement.  In terms of the  Shareholders  Agreement,  the  authorized
      share capital of the company was five  million  rupees  consisting  of
      equity shares of Rs.10/- each.  Initially the parties had  decided  to
      issue equity capital of 1,50,000 equity shares of  Rs.10/-  each  with
      50% of the initial equity to Capital Controls and the remaining 50% to
      Chloro Controls.  It is necessary to refer in some detail the relevant
      clauses of this Agreement as this agreement is the ‘Principal  or  the
      Mother Agreement’.  All other agreements were executed in  furtheranceChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      to and for achieving the purpose of  this  Agreement.  This  agreement
      notices that Capital Control was engaged in the  design,  manufacture,
      import,  marketing,  export  etc.  of  gas  and   electro-chlorination
      equipments.  The company was to be registered and as  is  evident,  in
      furtherance to the negotiations, steps for registration  of  the  said
      company had been taken and finally it came to be incorporated on  14th
      November, 1995.  The main object of the joint venture company was  the
      manufacture, service and sale  of  the  products.   In  terms  of  the
      Principal Agreement, establishment  of  a  plant,  management  of  the
      company, appointment of Directors, implementation of decisions of  the
      Board of Directors, appointment  or  re-appointment  of  the  Managing
      Director, dividend policy, loans, financial  information,  trademarks,
      transfer of shares, sale-purchase of chlorination  equipment,  assets,
      government  approvals,  performance  of  Chloro  Controls,  trademark,
      service  of  notices,  modifications,  severability  and  arbitration,
      settlement  of  disputes  by  arbitration  etc.   were   the   matters
      specifically provided for under this agreement.   A  very  significant
      feature of this contract was that the Kocha Group  was  put  under  an
      injunction to not engage directly  or  indirectly  or  be  financially
      interested in the manufacture, sale or  distribution  of  chlorination
      equipment and related products, which is similar to those manufactured
      or sold by the company during the term of the agreement.  Similarly, a
      restriction was also placed upon Capital Controls and even its holding
      companies to not directly or indirectly engage in or to be financially
      interested in the  manufacture,  sale  or  distribution  in  India  of
      products manufactured or sold by the company, during the term  of  the
      agreement.
      137.   The  Principal  Agreement  specifically  referred  to   various
      agreements or even terms and conditions  thereof.   Clause  7  of  the
      agreement provided for  execution  of  the  International  Distributor
      Agreement which was Appendix II to this Agreement.  The Financial  and
      Technical Know-how Licence Agreement was executed  in  furtherance  to
      clause 14 thereof.  Similarly, the Trademark Registered  User  License
      Agreement was required to be executed between the parties in terms  of
      clause 15 of this  Agreement.   Other  terms  and  conditions  of  the
      Principal  Agreement  referred  to  management  of  the   company   by
      appointment  or  reappointment  of  Directors  or  Managing  Directors
      inasmuch as Clause 8.6 contemplated execution of the  agreement  which
      was appended as Appendix III.  Still, certain  other  clauses  of  the
      Principal  Agreement  specifically  dealt  with  the  sale  of   goods
      manufactured  by   the   joint   venture   company,   nationally   and
      internationally.   This  resulted  in  signing  of  the  International
      Distribution and Export Sales Agreement between the parties.
      138.  All the five agreements signed by the parties were primarily  to
      fulfill their obligations and ensure  performance  of  this  Principal
      Agreement.  The  Supplementary  Collaboration  Agreement  executed  in
      August 1997 was only to comply with the conditions of  the  Government
      Approval which were granted vide letter dated 11th October,  1996,  as
      amended by  letter  dated  21st  April,  1997.   The  companies  which
      executed the various agreements were the companies  signatory  to  the
      Principal Agreement  or  their  holding  companies  or  the  companiesChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      belonging to the respondent group in which they had got merged for the
      purposes of  attaining  effective  designing,  manufacturing,  import,
      export and marketing of the agreed chlorinated products.
      139.  All the subsequent  agreements  were,  therefore,  ancillary  or
      incidental agreements to the Principal  Agreement.   Thus,  the  joint
      venture  entered  between  the  parties  had  different  facets.   Its
      foundation was provided under the  Principal  Agreement  but  all  the
      agreed terms could only be fulfilled by performance of  the  ancillary
      agreements.  If one segregates the Principal Agreement from the  rest,
      the subsequent agreements  would  be  rendered  ineffective.   If  the
      agreed goods were not manufactured in India with the  technical  know-
      how of the respondent No. 1 company and the joint venture company  was
      not incorporated, the question of the Distribution Agreement, Managing
      Director Agreement, Financial and Technical Know-How License Agreement
      or the Export Sales Agreement would  not  have  even  arisen,  in  any
      event.  Conversely, if the ancillary agreements were not performed  in
      a  collective  manner,  the  Principal  Agreement  would  be   of   no
      consequence.  In other words, it was  one  composite  transaction  for
      attaining the purpose of business of the joint venture  company.   All
      these agreements are so intrinsically connected to each other that  it
      is  neither  possible  nor  probable  to  imagine  the  execution  and
      implementation of one without the collective performance  of  all  the
      other agreements.  The intention of the parties  was  clear  that  all
      these agreements were being executed as integral parts of a  composite
      transaction.   It  can  safely  be  covered  under  the  principle  of
      ‘agreements within an agreement’.  For  instance,  the  Financial  and
      Technical Know-How License Agreement not only finds a specific mention
      in the Principal Agreement but its contents also are referable to  the
      clauses of the Principal Agreement.  The Financial and Technical Know-
      How License Agreement was Appendix III to the Principal Agreement  and
      the details of the goods which were contemplated to  be  manufactured,
      distributed and sold under the Principal Agreement had been  specified
      in Appendix I of the Financial and Technical Know-How  Agreement.   If
      the latter agreement was not there, the  Principal  Agreement  between
      the parties would have remained incomplete and the parties would  have
      been  at  a  disadvantage  to  know  as  to  what  goods  were  to  be
      manufactured and what goods could not  have  been  manufactured.   The
      Principal Agreement  referred  either  specifically  or  by  necessary
      implication to all other agreements.  They  were  inter-dependent  for
      their performance and one could not be read and understood  completely
      without the aid of the other.
      140.  Having held that all these  other  agreements  as  well  as  the
      mother/ principal agreement were part of a  composite  transaction  to
      facilitate implementation of the principal agreement and that  was  in
      reality the intention of the parties,  now,  we  will  deal  with  the
      question of parties to  the  principal  agreement.   When  the  mother
      agreement dated 16th November, 1995 was executed between the  parties,
      presumably the Certificate of Incorporation of Capital  Control  India
      Private Ltd. had not been issued to the parties  though  it  had  been
      incorporated on 14th November, 1995.  If the  company  had  been  duly
      incorporated and the Certificate of Incorporation was available to theChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      parties, then there could be no reason for the parties to  propose  in
      the Principal Agreement that the joint venture company would be in the
      name of Capital Controls India Private Ltd. or any  other  name  which
      would be mutually agreed between the parties.  The reference to  joint
      venture company, thus, was not by a specific name.  Both  the  parties
      have signed this agreement with the clear intention that the  company,
      Capital Control India Pvt. Ltd., will be the  joint  venture  company.
      Thus, non-mentioning of the name of the joint venture company  in  the
      principal agreement, though it had been incorporated on 14th November,
      1995, is immaterial and inconsequential in face of  intention  of  the
      parties appearing from the written  documents  on  record.   Once  the
      Principal Agreement  was  signed,  all  other  agreements  had  to  be
      executed   by or in favour of the joint venture company.   That is how
      to all these other agreements the joint venture company  i.e.  Capital
      Control India Pvt. Ltd. is a party.   It further  completely  supports
      the view that non-mentioning of the name of Capital Control India Pvt.
      Ltd. can hardly affect the findings of the Court.   With regard to the
      management of the joint venture  company  and  implementation  of  the
      Principal  Agreement,  the  parties  had  entered  into  the  Managing
      Director Agreement dated 16th November,  1995.    This  agreement  was
      signed by each of the concerned partners i.e. by Capital Control India
      Pvt. Ltd., respondent No. 5 and the Kocha  Group,  respondent  No.  9.
      This agreement provided as to how the Managing Directors  were  to  be
      appointed or reappointed and how the meeting of the Board of Directors
      of the company were to be conducted in accordance  with  law  and  the
      terms of the Mother Agreement.   This  agreement  came  to  be  signed
      between the joint venture company and the Kocha Group.
      141. Other aspect of performance of the Principal  Agreement  was  the
      Financial and Technical Know-How License Agreement.    This  agreement
      had been signed between the Capital Control Company Inc., subsequently
      known as Severn Trent Water Purification, respondent No.  1,  one  the
      one hand and the joint venture company, respondent  No.  5.     Severn
      Trent Water Purification Inc. is the  holding  company  of  the  joint
      venture to the extent of its share holding and  is  the  company  into
      which Capital Control (Del.) Co.  Inc.  had  merged.     Severn  Trent
      Water Purification Inc. is thus,  the  resultant  product  of  Capital
      Control (Del.) Company Inc. being merged into Capital Control  Company
      Inc. and its name was changed with effect from 1st April, 2002.    All
      these three companies had at the relevant time been or when came  into
      existence were and are subsidiaries of Severn Trent (Del.) Inc.    The
      requisite technical know-how was possessed by these companies and  was
      agreed to be imparted in favour  of  the  joint  venture  company,  in
      furtherance to and as per the terms and conditions  contained  in  the
      Principal Agreement.
      142.  Similarly, Severn Trent Water Purification Inc. had entered into
      an International Distributor Agreement and an Export  Sales  Agreement
      with the joint venture to facilitate the sale, marketing and export of
      goods, under these two different agreements.    Thus,  it  is  crystal
      clear that all the six material agreements had  been  signed  by  some
      parties or their holding companies or the  companies  into  which  the
      signatory company had merged.   None  of  these  companies  is  eitherChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      stranger to the transaction or not an appropriate party.   The parties
      who have signed the agreements could alone give rights or benefits  to
      the joint venture company  and  they,  in  turn,  were  the  companies
      descendants in interest or the subsidiaries of Severn  Trent  Services
      Del. Inc.
      143.  May be all the parties to the lis are not signatory to  all  the
      agreements in question, but still they  would  be  covered  under  the
      expression ‘claiming through or under’ the parties to  the  agreement.
      The interests of these companies are not adverse to  the  interest  of
      the principal company  and/or  the  joint  venture  company.   On  the
      contrary, they derive their basic interest and enforceability from the
      Mother Agreement and  performance  of  all  the  other  agreements  by
      respective parties had to fall  in  line  with  the  contents  of  the
      Principal Agreement.   In view of the settled position of law that  we
      have indicated above, we will have no hesitation in holding that these
      companies claim their interest and invoke the terms of  the  agreement
      or defend the action in the capacity of a ‘party claiming  through  or
      under’ the parties to the agreement.
      ARBITRATION
      144.  When we refer to all the six relevant agreements in relation  to
      the arbitration clause, the Shareholders Agreement, the Financial  and
      Technical Know-How License Agreement and the  Export  Sales  Agreement
      contained the arbitration clause while  the  other  three  agreements,
      i.e., International Distributor  Agreement,  the  Managing  Director’s
      Agreement and the Trademark Registered User License Agreement did  not
      contain any such arbitration clause.  The arbitration clause contained
      in the Principal Agreement in clause 30 has been reproduced above.  It
      requires that any dispute or difference arising under or in connection
      with that agreement which could not be settled by friendly negotiation
      and agreement  between  the  parties,  would  be  finally  settled  by
      arbitration conducted in accordance  with  the  Rules  of  ICC.   This
      clause is widely worded.  It is comprehensive enough  to  include  the
      disputes arising ‘under and in connection with’  the  agreement.   The
      word ‘connection’ has been added by the parties to expand the scope of
      the disputes under the agreements.  The  intention  to  make  it  more
      comprehensive is writ large from the language  of  the  agreement  and
      particularly clause 30 of the Mother Agreement. It is useful to notice
      that the agreement has to be construed and interpreted  in  accordance
      with laws of the Union of India, as consented by the parties.
      145.  The expression ‘connection’ means a link or relationship between
      people or things or the people with  whom  one  has  contact  (Concise
      Oxford  Dictionary  (Indian  Edition).   ‘Connection’  means  act   of
      uniting; state of being united; a relative;  relation  between  things
      one of which is bound up with (Law Lexicon 2nd Edn. 1997).
      146.   Thus,  even  the  dictionary  meaning  of  this  expression  is
      liberally worded.  It implies expansion in its  operation  and  effect
      both.  Connection can be  direct  or  remote  but  it  should  not  beChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      fanciful or marginal.   In  other  words,  there  should  be  relevant
      connection between the dispute and the agreement by specific words  or
      by necessary implication like reference to all other agreements in one
      (principal) agreement.  The expression appearing in clause 30  has  to
      be given a meaningful interpretation particularly when  the  Principal
      Agreement itself, by  specific  words  or  by  necessary  implication,
      refers to all other agreements.   This  would  imply  that  the  other
      agreements originate from the Principal Agreement and hence, its terms
      and conditions would be applicable to  those  agreements.   There  are
      three agreements,  as  already  noticed,  which  do  not  contain  any
      specific arbitration clause.  Both the Managing Director Agreement and
      the  International  Distributor  Agreement  directly  relate  to   the
      Principal Agreement stating the manner in which the affairs  would  be
      managed and the Managing Directors be appointed.  At  the  same  time,
      the International Distributor Agreement is executed between the Severn
      Trent Water Purification Inc. the erstwhile  Capital  Control  Company
      Inc. and the Capital Control India Private  Ltd.,  the  joint  venture
      company.  Firstly, the chances of dispute between the  same  group  of
      companies were remote and secondly these were the companies which were
      held by the same management.  The parties  had  also  agreed  to  have
      relationship as that of seller  and  distributor  to  make  the  joint
      venture company a success.  The interest of Capital  Controls  Company
      Inc. and that of the Capital Control India Private Ltd., to the extent
      of the former’s  share,  were  common.   Furthermore,  this  being  an
      integral part of the Principal Agreement would,  in  our  opinion,  be
      squarely  covered  by  the  arbitration  clause   contained   in   the
      Mother/Shareholders Agreement.  This agreement has  been  specifically
      referred in clause 7 of the Mother/Shareholders Agreement.   Not  only
      that there is incorporation by reference of International Distribution
      Agreement in the Mother/Shareholders Agreement but, in fact, it is  an
      integral part thereof.
      147.  Another aspect of the case is that  all  these  agreements  were
      executed simultaneously  on  16th  November,  1995  which  fact  fully
      supports the  view  that  the  parties  intended  to  have  all  these
      agreements as a composite transaction.  Furthermore, when the  parties
      signed the Supplementary Collaboration Agreement in  August  1997,  by
      that time all these agreements had not only been signed and understood
      by the parties but, in fact, had also been acted upon.
      148.  In the Supplementary Collaboration Agreement,  the  parties  re-
      confirmed the existence of the  joint  venture  agreement  dated  16th
      November, 1995 and made a specific stipulation that both  the  parties
      confirmed to adhere by the terms  and  conditions  stipulated  by  the
      Government of India in its letters dated 11th October,  1996,  amended
      on 21st April, 1997.   This was signed by Madhusudan B. Kocha,  member
      of the Kocha group on behalf of the joint venture company and  Capital
      Controls (Delaware) Inc.   The necessity for executing this  agreement
      was in face of the condition of Government approval  as  well  as  the
      subsequent amendment of clause 2, 3 and 4 of the approval letter dated
      11th October, 1996 i.e. items of manufacture,  proposed  location  and
      foreign equity.Chloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      149.  The conduct of the parties and even the subsequent events  leave
      no doubt in the mind of the  Court  that  the  parties  had  executed,
      intended and actually implemented the composite transaction  contained
      in the Principal Agreement.    The Courts have also applied the  Group
      of Companies Doctrine in such  cases.      As  already  noticed,  this
      Court  in  the  case  of  Olympus  Superstructure  Pvt.  Ltd.  (supra)
      permitted reference to arbitration where there were multiple contracts
      between the parties, interpreting the words ‘in connection  with’  and
      ‘disputes relating to connected matters’.
      150.  Besides making the reference, the Court also held that making of
      two awards which may be conflicting in relation to the items which are
      likely to overlap in two agreements could  not  be  permitted.     The
      courts have also accepted and more so in group company cases that  the
      fact that a party being non-signatory to one or  other  agreement  may
      not be of much significance, the  performance  of  one  may  be  quite
      irrelevant with the performance and fulfillment of  the  principal  or
      the mother agreement.   That, in fact, is the situation in the present
      case.
      151.  One  of  the  arguments  advanced  was  that  the  International
      Distributor Agreement  had  specifically  provided  for  construction,
      interpretation  and  performance  of  the  agreement   and   for   the
      transaction under that agreement to be governed by and interpreted  by
      the laws of State of Pennysylvania, USA  and  parties  thereto  agreed
      that any litigation thereunder shall be  brought  in  any  federal  or
      state  court  in  the  Eastern  District  of   the   Commonwealth   of
      Pennysylvania which fact would oust the possibility  of  reference  to
      arbitration in terms of clause 30 of the Principal Agreement,  as  the
      parties had chosen a specific forum of the court system.    Discussion
      on this argument may not be greatly relevant  in  view  of  the  above
      discussion in this judgment.   This being a composite transaction, the
      parties could opt for any remedy.
      152.  In  the  present  case,  we  have  already  noticed,  that  some
      agreements contain the arbitration clause, while  others  don’t.   The
      Shareholders  Agreement,  Financial  and  Technical  Knowhow   Licence
      Agreement and Export Sales Agreement contain the  arbitration  clause,
      while the  International  Distributor  Agreement,  Managing  Directors
      Agreement and Trade Mark Registered User Agreement do not contain  the
      arbitration clause.  The arbitration clause contained under clause  30
      of the  Shareholders  Agreement  and  that  under  clause  26  of  the
      Financial and Technical Knowhow Licence Agreement are identical.  They
      both require the disputes to be referred to arbitration in  London  as
      per the ICC Rules.   However,  the  arbitration  clause  contained  in
      clause 18 of the Export Sales Agreement provides for reference of  the
      disputes to arbitration at Pennsylvania, USA, in accordance with rules
      of American Arbitration  Association.    It  also  provides  that  the
      judgment upon the Award rendered could be  entered  in  any  court  of
      competent  jurisdiction.    Still,  clause  21  of  the  International
      Distributor Agreement required the  construction,  interpretation  and
      performance of the agreement to be governed by and  interpreted  under
      the  laws  of  the  State  of  Pennsylvania,  USA.    Any   litigationChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      thereunder was to be brought in any federal or State Court located  in
      the Eastern District of the Commonwealth of Pennsylvania, which was to
      be binding upon the parties.
      153.  As already noticed, two of the agreements did  not  contain  any
      arbitration clause, but they also did not subject the parties even for
      litigative jurisdiction.    They are the Managing Directors  Agreement
      and the Trademark Registered User Agreement.    These  two  agreements
      had been executed in furtherance to and for compliance  of  the  terms
      and conditions of the mother agreement which contained the arbitration
      clause.  They  were,  thus,  intrinsically  inter-connected  with  the
      mother agreement.
      154.     All these agreements were signed  on  the  same  day  and  in
      furtherance to the mother agreement.  None of the parties have invoked
      the jurisdiction of the Court at Pennsylvania, USA.  Thus, it  was  an
      alternative remedy that too restricted to the disputes, if any arising
      from that agreement.  Where different agreements between  the  parties
      provide for alternative remedies, it does not  necessarily  mean  that
      the other remedy or jurisdiction stands ousted.  Where the parties  to
      such composite transaction provide for different  alternative  forums,
      including arbitration, it has to be taken that real intention  of  the
      parties was to give effect to the purpose of agreement and  refer  the
      entire subject matter to arbitration and not to frustrate  the  remedy
      in law.  It was for the parties to chose either to  institute  a  suit
      qua the International Distributor  Agreement  at  Pennsylvania  or  to
      invoke the arbitration agreement in terms of clause 30 of  the  mother
      agreement.  They  have  chosen  the  latter  remedy.    The  question,
      therefore, does not arise as to which law would apply since  the  only
      litigation taken out by the parties is  the  suit  instituted  by  the
      appellant before the original side of the Bombay High  Court  and  the
      subsequent application for  reference  to  arbitration  filed  by  the
      Respondent No. 1 under Section 45 of the 1996 Act.
      155.   The  effect  of  execution  of  multiple  agreements  has  been
      discussed by us in some elaboration above.    The  real  intention  of
      the parties was not only to refer all their disputes arising under the
      agreement which could not be settled despite friendly negotiations  to
      arbitration, but even the disputes which arose in connection with  the
      shareholder/mother agreement to arbitration.
      156.   Thus, a composite reference was well within  the  comprehension
      of the parties to various agreements which were executed on  the  same
      day and for the same purpose.   There  cannot  be  any  doubt  to  the
      contention that in terms of Section 9 of the CPC, the courts in  India
      shall have jurisdiction to try all suits of civil  nature.    Further,
      this section gives a right to a person to institute a suit before  the
      court of competent jurisdiction.   However, the language of Section  9
      itself makes it clear that the civil courts have jurisdiction  to  try
      all suits of civil nature except the suits of which taking  cognizance
      is either  expressly  or  impliedly  barred.    In  other  words,  the
      jurisdiction of the court and the  right  to  a  party  emerging  from
Section 9 of the CPC is not an absolute right,  but  contains  inbuiltChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      restrictions.    It is an accepted principle that jurisdiction of  the
      court can be excluded.   In the case of Dhulabhai v. State of M.P. and
      Anr.  [AIR 1969 SC 78], this Court  has  settled  the  principle  that
      jurisdiction of the Civil Court is all embracing, except to the extent
      it is excluded by law or by clear intendment arising  from  such  law.
      In Nahar Industrial Enterprises Ltd. v. Hong Kong &  Shanghai  Banking
      Corporation [(2009) 8  SCC  646],  this  Court  has  even  stated  the
      conditions for exclusion of jurisdiction. They are,  (a)  whether  the
      legislative intent to exclude is expressed explicitly or by  necessary
      implication, and (b) whether the statute in question provides  for  an
      adequate and satisfactory alternative remedy to a party  aggrieved  by
      an order made under it.
      157.  The provisions of Section 45 of the 1996 Act are to prevail over
      the provisions of the CPC and when the  Court  is  satisfied  that  an
      agreement is enforceable, operative and is not null and  void,  it  is
      obligatory upon the court to make a reference to arbitration and  pass
      appropriate orders in relation to the  legal  proceedings  before  the
      court, in exercise of its inherent powers.
      158. In the  present  case,  the  court  can  safely  gather  definite
      intention on behalf of the parties to have their disputes collectively
      resolved by the process of arbitration.   Even if different forums are
      provided, recourse to one of them which is capable  of  resolving  all
      their issues should be  preferred  over  a  refusal  of  reference  to
      arbitration.    There appears to be no uncertainty in the minds of the
      parties in that  regard,  rather  the  intention  of  the  parties  is
      fortified and clearly referable to the mother agreement.
      159.  It is not the case of any of the parties before us that  any  of
      the parties to the present litigation  had  taken  steps  before  that
      Court or had invoked the jurisdiction of that court under that system.
        There  is  no  apparent  conflict  of  interest  as  of  now.    The
      arbitration clause would stand  incorporated  into  the  International
      Distributor Agreement as this agreement itself was Appendix II to  the
      Principal Agreement.   This Court in the case of  M.R.  Engineers  and
      Contractors Pvt. Ltd. v. Som Datt Builders Ltd. [(2009) 7 SCC 696] has
      stated that firstly the subject of  reference  be  enacted  by  mutual
      intention, secondly  a  mere  reference  to  a  document  may  not  be
      sufficient and the reference should be sufficient  to  bring  out  the
      terms and conditions of  the  referred  document  and  also  that  the
      arbitration clause should be capable of application in  respect  of  a
      dispute under the contract and not  repugnant  to  any  term  thereof.
      All these three conditions are satisfied in the present case.
      160.  The terms  and  conditions  of  the  International  Distribution
      Agreement were an integral part of the Principal Agreement as Appendix
      II and the Principal Agreement had an  arbitration  clause  which  was
      wide enough to cover disputes in all the ancillary agreements.  It  is
      not necessary  for  us  to  examine  the  choice  of  forum  or  legal
      enforceability of legal system in the present  case,  as  we  find  no
      repugnancy even where the main contract is governed  by  law  of  some
      other country and the arbitration clause by Indian law.     They  bothChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      could be invoked, neither party having invoked the former will  be  no
      bar for invocation of the latter in view of arbitration clause  30  of
      the mother agreement.
      161.  Reliance was also placed on the judgment of this  Court  in  the
      case of Deutsche Post Bank Home Finance Ltd. v.  Taduri  Sridhar  [AIR
      2011 SC 1899] where the Court had declined reference of  multiple  and
      multi party agreement.    That case is of no  help  to  the  appellant
      before us.    In that case, there were four parties, the seller of the
      land, the builder, purchaser of the flat and the bank.   The bank  had
      signed an agreement with the purchaser of  the  flat  to  finance  the
      flat, but it referred to other agreement stating that it would provide
      funds directly to the builder.    There was an agreement  between  the
      builder and the owner of the land and the purchaser  of  the  land  to
      sell the undivided share and that  contained  an  arbitration  clause.
      The question before the Court was whether while referring the disputes
      to the arbitration, the disputes between the bank on the one hand, and
      the  purchaser  of  the  flat  on  the  other  could  be  referred  to
      arbitration.    The Court, in reference to Section 8 of the 1996  Act,
      held that the bank was  a  non-party  to  the  arbitration  agreement,
      therefore, neither the reference was permissible  nor  they  could  be
      impleaded at a subsequent stage.    This  judgment  on  facts  has  no
      application.   The distinction between Section 8 and  Section  45  has
      elaborately been dealt with by us above and in view of that,  we  have
      no hesitation in holding that this judgment, on facts and law, is  not
      applicable to the present case.
      162.  Thus, in view of the above, we hold that the  disputes  referred
      to and arising from the multi-party agreements are  capable  of  being
      referred to arbitral tribunal in accordance with the agreement between
      the parties.
      163.  Another argument advanced with some vehemence on behalf  of  the
      appellant was that respondent Nos.3 and 4 were not party to any of the
      agreements entered into between the parties and their cause of  action
      is totally different and distinct, and their rights were controlled by
      the agreement of distribution executed by respondent Nos.1  and  2  in
      their  favour  for  distribution  of  products  of  gas  and  electro-
      chlorination.   It was contended that there  cannot  be  splitting  of
      parties, splitting of cause of action and remedy by the Court.
      164.  On the other hand, it was contended on behalf of the  respondent
      No.1 that it is permissible to split  cause  of  action,  parties  and
      disputes.   The mater referable to  arbitration  could  be  segregated
      from the civil  action.   The  court  could  pass  appropriate  orders
      referring the disputes covered under the arbitration agreement between
      the signatory party to arbitration  and  proceed  with  the  claim  of
      respondent Nos. 3 and 4 in accordance with law.
      165.  As far as this question of law is  concerned,  we  have  already
      answered the same.    On  facts,  there  is  no  occasion  for  us  to
      deliberate on this issue, because respondent Nos. 3 and 4 had  already
      consented for arbitration.   In light of that fact, we do not wish  toChloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

      decide this question on the facts of the present case.
      166.  Having dealt with all the relevant issues in law, now  we  would
      provide answer to the questions framed by us in the beginning  of  the
      judgment as follows :
      Answer
      167.  Section 45 is a provision falling under Chapter I of Part II  of
      the 1996 Act which is a self-contained Code.  The  expression  ‘person
      claiming through or under’  would  mean  and  take  within  its  ambit
      multiple and multi-party agreements, though in exceptional case.  Even
      non-signatory parties to some  of  the  agreements  can  pray  and  be
      referred to arbitration provided they satisfy the pre-requisites under
Sections 44 and 45 read with Schedule I.  Reference  of  non-signatory
      parties is neither unknown to  arbitration  jurisprudence  nor  is  it
      impermissible.
      168.  In the facts of a given case, the Court is  always  vested  with
      the power to delete the name of the parties who are neither  necessary
      nor proper to the proceedings before the Court.  In the cases of group
      companies  or  where  various  agreements   constitute   a   composite
      transaction like mother  agreement  and  all  other  agreements  being
      ancillary to and for effective  and  complete  implementation  of  the
      Mother Agreement, the court may have to make reference to  arbitration
      even of the disputes existing between signatory or even  non-signatory
      parties.  However, the discretion of the Court has to be exercised  in
      exceptional, limiting, befitting  and  cases  of  necessity  and  very
      cautiously.
      169.  Having answered these questions, we do not  see  any  reason  to
      interfere with the judgment of the Division Bench of the  Bombay  High
      Court under appeal.   We direct all the disputes arise in the suit and
      from the agreement between the parties  to  be  referred  to  arbitral
      tribunal and be decided in accordance with the Rules of ICC.
      170.   The  appeals  are  dismissed.   However,  in  the   facts   and
      circumstances of the present case, we do not award costs.
                                             ….………….....................CJI.
                                                              (S.H. Kapadia)
                                              …….………….....................J.
                                                              (A.K. Patnaik)Chloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

                                            ...….………….....................J.
                                                           (Swatanter Kumar)
New Delhi;
September 28, 2012
                       IN THE SUPREME COURT OF INDIA
                       CIVIL APPELLATE JURISDICTION
                       CIVIL APPEAL NO. 7134 OF 2012
                 (arising out of SLP(C)No. 8950 of 2010)
      Chloro Controls (I) P.Ltd.             ... Appellant
                             Versus
      Severn Trent Water Purification Inc. & Ors. ...Respondents
                                    WITH
                    CIVIL APPEAL NOS. 7135-7136  OF  2012
         (Arising out of SLP(C)Nos. 26514-26515 of 2011)
                               O R D E R
Upon pronouncement of the judgment Mr. F.S. Nariman, learned senior counsel appearing for the
petitioner, mentioned that the petitioner had filed an application for injunction in the suit before the
High Court. The same was dismissed. Appeal against the order dismissing the application had been
filed before this Court and was ordered to be listed along with SLP (C) No. 8950 of 2010 (which is an
appeal against the order of the High Court making reference to arbitral tribunal). However, the
Court had not heard arguments on that appeal.
Learned senior counsel appearing for the respondents, Mr. K.V. Vishwanathan, submitted that the
special leave petitions were listed but they were not admitted.
In view of the common stand taken by the counsel for the parties, we permit the petitioner to move
an independent application praying for hearing for those special leave petitions i.e.
SLP(C)Nos.26514-26515 of 2011 (listed along with SLP(C)No. 8950/2010) pending for admission.
..............CJI (S.H.Kapadia) ................J. (A.K.Patnaik) ................J. (Swatanter Kumar) New Delhi;
September 28, 2012.Chloro Controls(I) P.Ltd vs Severn Trent Water Purification Inc ... on 28 September, 2012

