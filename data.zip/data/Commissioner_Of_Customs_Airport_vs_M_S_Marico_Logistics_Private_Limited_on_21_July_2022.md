Commissioner Of Customs (Airport & ... vs M/S. Marico
Logistics Private Limited on 21 July, 2022
Author: T.S.Sivagnanam
Bench: T.S. Sivagnanam
                                                      CUSTA NO. 16 OF 2020
        IN THE HIGH COURT OF JUDICATURE AT CALCUTTA
                 SPECIAL JURISDICTION (CUSTOMS)
                           ORIGINAL SIDE
                    RESERVED ON: 07.07.2022
                    DELIVERED ON: 21.07.2022
                              CORAM:
            THE HON'BLE MR. JUSTICE T.S. SIVAGNANAM
                                 AND
          THE HON'BLE MR. JUSTICE BIVAS PATTANAYAK
                       CUSTA NO. 16 OF 2020
                        (GA NO. 01 OF 2020)
    COMMISSIONER OF CUSTOMS (AIRPORT & ADMINISTRATION)
                              VERSUS
             M/S. MARICO LOGISTICS PRIVATE LIMITED
Appearance:-
Ms. Manasi Mukherjee, Learned Standing Counsel.
                                                  .....For the Appellant.Commissioner Of Customs (Airport & ... vs M/S. Marico Logistics Private Limited on 21 July, 2022

Mr. Arnab Chakraborty, Adv., Bar-at-Law
Mr. Aniket Chaudhury, Adv.
                                              .....For the Respondent.
                              Page 1 of 19
                                                                  CUSTA NO. 16 OF 2020
                                   JUDGMENT
(Judgment of the Court was delivered by T.S.SIVAGNANAM, J.)
1. This appeal filed by the revenue is directed against the order dated 26.11.2019 passed by the
Customs, Excise and Service Tax Appellate Tribunal, East Regional Bench, Kolkata (tribunal) in
Appeal No. 77086/2017. The revenue has raised the following substantial questions of law for
consideration:-
(b) Whether the respondent is not liable as per Regulation 17(9) of the Customs
Broker Licensing Regulation 2013 which stipulates that 'a customs broker shall
exercise such supervision as may be necessary to ensure the proper conduct of his
employees in the transaction of business and he shall be held responsible for all acts
or omissions of his employees during their employment.'
(c) Whether the payment of differential amount duty of Rs.
65.40 Lakhs by the respondent to the appellant does not prove admission of liability and
involvement of the respondent functioning as importer itself.
(e) Whether statements made by the director of the respondent admitting the offence and the
involvement thereto binds the respondent company?
2. We have heard Ms. Manasi Mukherjee, learned standing counsel for the appellant and Mr. Arnab
Chakraborty, learned advocate, Bar-At-Law assisted by Mr. Aniket Chaudhury, learned advocate for
the respondent.
3. The respondent is a Customs Broker having been granted the licence under the provisions of the
Customs Broker Licensing Regulations, 2013 (CBLR). The respondent came to adverse notice of the
department with CUSTA NO. 16 OF 2020 regard to the certain import consignments where the
combined net weight of the goods imported were manipulated. In this regard, an offence report was
drawn by the Directorate of Revenue Intelligence (DRI) and communicated to the appellant
department. The respondent's licence was initially suspended and thereafter by order dated
21.09.2017, the licensing was revoked and the security deposit ordered to be forfeited. Challenging
the same, the respondent preferred appeal before the tribunal which has been allowed and aggrievedCommissioner Of Customs (Airport & ... vs M/S. Marico Logistics Private Limited on 21 July, 2022

by such order, the revenue is before us by way of this appeal.
4. On perusal of the order passed by the tribunal, we find that relief has been granted to the
respondent on the purported ground that the statements recorded from various persons are
inconsistent with each other. On reading of the impugned order, we get a feeling that the tribunal
assumed the role of a criminal court examining the case of an accused, who has been charged of a
criminal offence such as an offence under the Indian Penal Code. The tribunal lost sight of an
important fact that what is called in question before it is the correctness of an order passed by the
Commissioner of Customs revoking a licence granted to the respondent under the provisions of the
CBLR 2013. The other legal principle which has been ignored by the tribunal is that, in cases like
that of the case on hand requirement is not proof beyond reasonable doubt and action can be
initiated by applying the principles of preponderance of probability. The statement recorded from
the Director of the respondent under Section 108 of the Customs Act clearly shows that there is
admission of guilt. The Weigh Bridge Operator of the Container Corporation Limited has been a
party to CUSTA NO. 16 OF 2020 the entire manipulation. The tribunal faults the appellant
department for not taking action against the employee of the Container Corporation Limited. The
said person has not committed any offence under the CBLR, 2013 for the Commissioner to take
action. The tribunal also ignored certain vital provisions of the CBLR. It failed to note that under
Regulation 8 of the CBLR, the respondent has executed a bond and furnished security before the
grant of licence binding himself to due observance of the provisions of CBLR, 2013. The obligations
on the Customs Broker/respondent have been clearly and elaborately enumerated in Regulation 11.
The respondent cannot "wash his hands" by stating that notices issued by the department to the
importer could not be served and in order to mitigate the liability, the respondent had paid Rs.
65,00,000/-. The appellant on examining the conduct of the respondent held him to be the de facto
importer. In terms of the CBLR 2013, the KYC norms have to be fulfilled before the Customs Broker
accepts to handle the cargo of any one of the parties. If the KYC norms had been complied with, the
respondent cannot be heard to say that the whereabouts of the importer are not known. Nothing
prevented the respondent to bring the importer to the scene by the making him appear before the
authorities to give a statement. The fact that the respondent did not do so but on the contrary paid
the sum of Rs. 65,00,000/- towards the part of the duty liability clearly shows that the respondent
was the de facto importer and the appellant was fully justified in coming to such a conclusion. The
respondent cannot be heard to say that he cannot identify the importer. If the respondent is
protecting the so-called importer or if the importer is a non-existent person, then it is the
respondent who has to be CUSTA NO. 16 OF 2020 held to be the principal offender and rightly
action was initiated against the respondent. On going through the relevant portion of the statement
of the concerned persons, as has been recorded in the order of revocation dated 21.09.2017, we find
there is no such inconsistency as having microscopically examined by the tribunal. Even before us,
Mr. Chakraborty seeks to point out such discrepancies. In fact, we have faulted the tribunal for
doing such a exercise and we cannot be called upon to commit the same mistake. It is relevant to
take note of the decision of the Hon'ble Supreme Court in Shri Kamakshi Agency wherein the role of
the Customs House Agent has been explained in the following terms:-
The very purpose of granting a license to a person to act as Custom House Agent is
for transacting any business relating to the entry or departure of conveyance or theCommissioner Of Customs (Airport & ... vs M/S. Marico Logistics Private Limited on 21 July, 2022

import or export of goods at any customs station. For that purpose, under Regulation
9 necessary examination is conducted to test the capability of the person in the
matter of preparation of various documents, determination of value procedures for
assessment and payment of duty, the extent to which he is conversant with the
provisions of certain enactments etc. Therefore, the grant of licence to act as a
Custom House Agent has got a definite purpose and intent. On a reading of the
Regulations relating to the grant of licence to act as Custom House Agent, it is seen
that while Custom House Agent should be in a position to act as agent for the
transaction of any business relating to the entry or departure of conveyance or the
import or export of goods at any customs station, he should also ensure that he does
not act as an Agent for carrying on certain illegal activities of any of the persons who
avail his services as Custom House Agent. In such circumstances, the CUSTA NO. 16
OF 2020 person playing the role of Custom House Agent has got greater
responsibility. The very prescription that one should be conversant with the various
procedures including the offences under the Customs Act to act as a Custom House
Agent would show that while acting as Custom House Agent, he should not be a cause
for violation of those provisions. A CHA cannot be permitted to misuse his position as
a CHA by taking advantage of his access to the Department. The grant of licence to a
person to act as Custom House Agent is to some extent to assist the Department with
the various procedures such as scrutinizing the various documents to be presented in
the course of transaction of business for entry and exit conveyance or the import or
export of the goods. In such circumstances, great confidence is reposed in a Custom
House Agent. Any misuse of such position by the Custom House Agent will have far
reading consequences in the transaction of business by the Custom House officials.
5. The conduct of the respondent does not meet the standards as pointed out by the
Hon'ble Supreme Court. In terms of clause (d) of Regulation 11, the respondent was
bound to advise his client to comply with the provisions of the Act and in case of
non-compliance, the respondent should bring the matter to the notice of the Customs
Authorities. In terms of clause (n) of Regulation 11, the respondent has to verify the
antecedents, the correctness of the importer, exporter code no. identity of his client
and functioning of his client at the declared address by using reliable, independent,
authenticate document, data or information. Admittedly, the conduct of the
respondent clearly shows that he has breached the said provision. Therefore, we are
of the view that the tribunal was not justified in reversing the order passed by the
licensing authorities in revoking the respondent licence.
CUSTA NO. 16 OF 2020
6. Lastly, the tribunal has proceeded to invoke the doctrine of proportionality and held to the
punishment of revocation of licence to be very harsh. In our view, such observation and order
passed by the tribunal is based on misplaced sympathy. It is to be noted that there is no vested right
in the respondent to handle cargo in a Customs area and such right is conferred pursuant to a
licence granted under the CBLR 2013 which licence comes with conditions and the respondent hasCommissioner Of Customs (Airport & ... vs M/S. Marico Logistics Private Limited on 21 July, 2022

bound himself to comply with the conditions and the relevant laws by executing a bond and
furnishing a security deposit. The trust and confidence reposed on the respondent as a Customs
House Agent is in a higher pedestal and he serves as a link between the client and the department
and is bound to be neutral and righteous. The doctrine of proportionality was considered in the case
of Welcome Air Express Private Limited Versus Commissioner of Customs (Airport and
Administration) wherein after taking note of the various decisions it was held as follows:
7. In Union of India and Another Versus G. Ganayutham 1, the Hon'ble Supreme Court considered
the position of proportionality in administrative law in England and India and held as follows:
The current position of proportionality in administrative law in England and India
can be summarized as follows:-
(1) To judge the validity of any administrative order or statutory discretion, normally
the Wednesbury test is to be applied to find out if the decision was illegal or suffered
from procedural improprieties or was one which no sensible decision-maker (1997) 7
SCC 463 CUSTA NO. 16 OF 2020 could on the material before him and within the
framework of the law, have arrived at. The Court would consider whether relevant
matters had not been taken into account or whether irrelevant matters had been
taken into account or whether the action was not bona fide. The Court would also
consider whether the decision was absurd or perverse. The Court would not however
go into the correctness of the choice made by the administrator amongst the various
alternatives open to him. Nor could the Court substitute its decision to that of the
administrator. This is the Wednesbury test.
(2) The Court would not interfere with the administrator's decision unless it was
illegal or suffered from procedural impropriety or was irrational in the sense that it
was in outrageous defiance of logic or moral standards. The possibility of other tests,
including proportionality being brought into English Administrative Law in future is
not ruled out. These are the CCSU principles. (3) (a) As per Bugdaycay, Brind and
Smith, as long as the Convention is not incorporated into English Law, the English
Courts merely exercise a secondary judgment to find out if the decision maker could
have, on the material before him arrived at the primary judgment in the matter he
had done.
(b) If the Convention is incorporated in England making available the principle of
proportionality, then the English Courts will render primary judgment on the validity
of the administrative action and find out if the restriction is disproportionate or
excessive or is not based upon a fair balancing of the fundamental freedom and the
need for the restriction thereupon.
(4)(a) The position in our country, in administrative law, where no fundamental
freedoms as aforesaid are involved, is that the Courts/Tribunals will only play a
secondary role while the primary judgment as to reasonableness will remain with theCommissioner Of Customs (Airport & ... vs M/S. Marico Logistics Private Limited on 21 July, 2022

executive or administrative authority. The secondary judgment CUSTA NO. 16 OF
2020 of the Court is to be based on Wednesbury and CCSU principles as stated by
Lord Greene and Lord Diplock respectively to find if the executive or administrative
authority has reasonably arrived at his decision as the primary authority.
(4) (b) Whether in the case of administrative or executive action affecting
fundamental freedoms, the Courts in our country will apply the principles of
'proportionality' and assume a primary role, is left open, to be decided in an
appropriate case where such action is alleged to offend fundamental freedoms. It will
be then necessary to decide whether the Courts will have a primary role only if the
freedoms under Article 19, 21 etc. are involve and not for Article 14.
Punishment in disciplinary matters:
Wednesbury & CCSU tests:
(1) Finally, we come to the present case. It is not contended before us that any
fundamental freedom is affected. We need not therefore go into the question of
'proportionality'. There is no contention that the punishment imposed is illegal or
vitiated by procedural impropriety. As to 'irrationality' there is no finding by the
Tribunal that the decision is one which no sensible person who weighed the pros and
cons could have arrived at nor is there a finding, based on material, that the
punishment is in 'outrageous' defiance of logic. Neither Wednesbury nor CCSU tests
are satisfied. We have still to explain 'Ranjit Thakur'. (2) In Ranjit Thakur, this Court
interfered with the punishment only after coming to the conclusion that the
punishment was in outrageous defiance of logic and was shocking. It was also
described as perverse and irrational. In other words, this Court felt that, on facts,
Wednesbury and CCSu tests are satisfied. In another case, in B.C Chaturvedi Versus
Union of India [1995] (6) CUSTA NO. 16 OF 2020 SCC 749] a three Judge Bench said
the same thing as follows (SCC P. 762 para 18) "The High Court/Tribunal while
exercising the power of judicial review, cannot normally substitute its own
conclusions on penalty and impose some other penalty. If the punishment imposed
by the disciplinary authority or the appellate authority shocks the conscience of the
High Court/Tribunal it would appropriately would the relief, either by directing the
disciplinary authority/appellate authority to reconsider the penalty imposed or to
shorten the litigation, it may itself, in exceptional and rare case, impose appropriate
punishment with cogent reasons in support thereof"
Similar view was taken in Indian Oil Corporation Versus Ashok Kumar Arora [1997 (3) SCC 72] that
the Court will not intervene unless the punishment is wholly disproportionate.
8. In Coimbatore District Central Cooperative Bank while considering the doctrine of
proportionality it was held as follows:Commissioner Of Customs (Airport & ... vs M/S. Marico Logistics Private Limited on 21 July, 2022

"Proportionality is a principle where the Court is concerned with the process, method
or manner in which the decision- maker has ordered his priorities, reached a
conclusion or arrived at a decision. The very essence of decision-making consists in
the attribution of relative importance to the factors and considerations in the case.
The doctrine of proportionality thus steps in focus true nature of exercise the
elaboration of a rule of permissible priorities De Smith states that 'proportionality'
involves 'balancing test' and 'necessity test'. Whereas the former ("balancing test")
permits scrutiny of excessive onerous penalties or infringement of rights or interests
and a manifest imbalance of relevant consideration, the latter ('necessity CUSTA NO.
16 OF 2020 test') requires infringement of human rights to the least restrictive
alternative ['Judicial Review of Administrative Action' (1995); pp 601-605; para
13.085; see also Wade and Forsyth; 'Administrative Law'; (2005); p. 366]
9. In Chairman Cum Managing Director Coal India Limited and Another Versus Mukul Kumar
Chowdhury and Others 2, the doctrine of proportionality was explained in the following terms:
The doctrine of proportionality is, thus, well recognized concept of judicial in our
jurisprudence. What is otherwise within the discretionary domain and sole power of
the decision maker to quantity punishment once the charge of misconduct stands
proved, such discretionary power is exposed to judicial intervention if exercised in a
manner which is out of proportion to the fault.
10. The above decisions were taken note of in OTA Kandla Private Limited and it was held as
follows:
In view of the above principles laid down by the Hon'ble Supreme Court in various
judgments it clearly transpires that the judicial review of administrative action or of
proportionality of punishment is permissible only if the decision of the decision
maker is found to be illegal, unreasonable, irrational or suffering from any procedural
impropriety, and that the High Court in exercise of jurisdiction under Article 226 or
227 should not interfere with the legal orders of Administrative Authorities, So far as
the facts of the present case are concerned, as stated hereinabove, respondent No. 3-
the CEGAT has upheld the Mumbai AIR 2010 SC 75 CUSTA NO. 16 OF 2020 order of
respondent No. 2 revoking the licence of the petitioner as CHA on the ground of
petitioner having committed breach of statutory regulations and the misconduct by
misusing its licence. In the opinion, of this Court, once the decision of the respondent
Authorities that the petitioner committed violation of statutory regulations and the
misconduct if found to be within the legal parameters, all the legal consequences as a
result of such violation and the breach have to follow. The case of the petitioner being
the case of contravention of said regulations and misuse of licence as CHA, the
respondent Authorities have rightly revoked the licence of the petitioner. The said
decision having been arrived at by the respondents, after taking into consideration all
relevant material and the said Regulation, and after following the due process of law,
it could not be said that the said decision was illegal, unreasonable, perverse orCommissioner Of Customs (Airport & ... vs M/S. Marico Logistics Private Limited on 21 July, 2022

irrational. Under the circumstances, it could also be not said that the punishment of
revocation of licence was a harsh punishment or the punishment dehors the doctrine
of proportionality. The petitioner having failed to point out any perversity or
unreasonableness on the part of respondent authorities warranting judicial
intervention, this Court does not find any merits in the present petition.
11. Mr. Chakraborty elaborately referred to the order passed by the tribunal more particularly
paragraphs 7 to 12 wherein the learned tribunal has referred to the submissions made on behalf of
the respondent. The learned advocate has referred to paragraph 17 of the impugned order to
demonstrate that the tribunal had taken note of the contradictory statement of Shri Ratan Baidya
regarding suppression of weight of the CUSTA NO. 16 OF 2020 imported consignments and had
mentioned in his statement that 63 weighment slips were tendered however, only 5 weighment slips
were relied upon by the DRI for the purpose of investigation. It is pointed out that the learned
tribunal rightly held that there is no explanation in the order of revocation regarding
mis-declaration of the net weight. Further it is submitted that the learned tribunal rightly held that
the statement dated 05.09.2016 of Shri Ratan Baidya is further contradictory when he stated that
from March 2016, he had manipulated weight of more than 100 containers of old and used garment
handled by the respondent company. However, in his statement dated 07.09.2016, he stated that
the weight was manipulated since last 3 to 4 months. Therefore, the tribunal noted a plethora of
contradictions in the statement of Shri Ratan Baidya and rightly granted relief in favour of the
respondent company. In the earlier part of this judgment we had mentioned above the scope of the
interference by the learned tribunal over order passed by the licensing authority under CBLR, 2013.
We also noted the legal principle of Preponderance of Probabilities which is required to be applied
and not proof beyond reasonable doubt. Bearing this in mind, when we examine the order passed by
the licensing authority dated 21.09.2017 by which the license was revoked, the statement of Shri
Subhasish Bhattachariya, Director of the respondent company recorded under Section 108 of the
Act on 03.09.2016, 05.09.2016 and 11.11.2016 were taken note of. There is a clear admission that
there was a mis-declaration in the weight of the imported consignment, and that the weigh bridge
operator of CONCOR-CFS Kolkata used to ask staff of the respondent about the declared weight in
the Bill of CUSTA NO. 16 OF 2020 Lading or IGM and used to issue weighment slip matching with
the declared weight. Further he had stated that the customs authorities never checked the weight of
the packing materials of the bills of the old and used clothing but relied on the declaration in the
imported documents. Further he had stated that after examination by the customs, the weighment
slips were destroyed by the respondent company. Shri Marinmoy Das, another Director of the
respondent in his statement under Section 108 of the Act recorded on 15.09.2016 stated that no
weighment slips were found from their office by the DRI as they were destroyed as per the
instructions of the importer because the weight of the consignment were not as per declaration.
Further he had stated that Shri Subhasish Bhattachariya had taken care of the entire operations and
three G card holders of the respondent had physically cleared the consignment through the customs.
Further the difference in declared weight and actual weight was admitted to have revealed huge
evasion of customs duty. Shri Ratan Baidya, weigh bridge operator in his statement recorded under
Section 108 on 05.09.2016 and 07.09.2016 admitted that for two years he worked as weigh bridge
operator and during March 2016, two representatives of the respondent company approached him
to manipulate the weight of containers by entering cargo weight as given by them manually duringCommissioner Of Customs (Airport & ... vs M/S. Marico Logistics Private Limited on 21 July, 2022

weighments and promised to pay Rs. 100 per container for such manipulation and he being poor
agreed to the proposal. Further he had stated that he had manipulated weighments of more than
100 containers handled by the respondent. The manipulated weighment slips were not only handed
over to the representatives of the respondent and the actual CUSTA NO. 16 OF 2020 weight and 6
containers were available in the computer installed in the Weigh Bridge. The weigh bridge operator
has specifically implicated the Director of the respondent and the G Card holder who dealt with the
cargo on behalf of the respondent. The statement recorded from the transporter shows that the
declared weight of the container is much less than the actual weight. As noted earlier, the importers
did not respond to the summons issued under Section 108 of the Act and the same were returned
undelivered with remark "not found/ not existed". Therefore, the licensing authority concluded that
the said importers are paper firms and the respondent has kept the department in the dark about
the identity of his client and thus allowing them to evade customs duties. Furthermore, the
respondent company had deposited a sum of Rs. 65.40 lakhs by 26 demand drafts stated to be on
behalf of the importers. The statements which were recorded under Section 108 remained intact and
were not retracted except as stated by the Director of the company that there was an attempted
retraction in the statement recorded on 11.11.2016. Nevertheless, such alleged retraction was also
taken note of by the authority while passing the order. Before the Commissioner, the respondent
company took a stand that they dealt with the documents produced by the importers in good faith
without apprehending any manipulation in weight. If such is the submission, nothing prevented the
respondent from producing the importers before the authority which they fail to do. On the
contrary, part of the differential duty to the tune of Rs. 65.40 lakhs was remitted by the appellant, to
be treated as voluntary payment as there is no allegation that the respondent was compelled to pay
CUSTA NO. 16 OF 2020 due amount. This argument/admission before the Commissioner clearly
shows that the respondent has failed to fulfill the obligation which has been fixed on them. Thus, it
is clear that the tribunal has picked holes in the evidence brought on record by the licensing
authority which not only probabilises but also establishes the violation committed by the respondent
thereby giving no room for interference.
12. While on this issue it is educative to refer to the decision of the Hon'ble Supreme Court in M.
Siddiq (Ram Janmabhumi Temple-5, J.) Versus Suresh Das 3 whereunder the law on the standard
of preponderance of probabilities was explained:-
720. In Miller v. Minister of Pensions, Lord Denning, J. (as the Master of Rolls then
was) defined the doctrine of the balance or preponderance of probabilities in the
following terms: (All ER p. 373 H) "(1).....It need not reach certainty, but it must carry
a high degree of probability. Proof beyond reasonable doubt does not mean proof
beyond the shadow of doubt. The law would fail to protect the community if it
admitted fanciful possibilities to deflect the course of justice. If the evidence is so
strong against a man as to leave only a remote possibility in his favour which can be
dismissed with the sentence, "of course it is possible, but not in the least probable"
the case is proved beyond reasonable doubt, but nothing short of that will suffice."
(emphasis supplied)Commissioner Of Customs (Airport & ... vs M/S. Marico Logistics Private Limited on 21 July, 2022

721. The law recognises that within the standard of preponderance of probabilities, there could be
different degrees (2020) 1 SCC 1 CUSTA NO. 16 OF 2020 of probability. This was succinctly
summarised by Denning, L.J. in Bater v. Bater 4, where he formulated the principle thus: )p.37)
"....So also in civil cases, the case must be proved by a preponderance of probability, but there may
be degrees of probability within that standard. The degree depends on the subject-matter".
723. Proof of a fact depends upon the probability of its existence. The finding of the court must be
based on:
723.1. The test of a prudent person, who acts under the supposition that a fact exists.
723.2. In the context and circumstances of a particular case.
724. Analysing this, Y.V. Chandrachud, J. (as the learned Chief Justice then was) in
N.G. Dastane v. S. Dastane 5 held: (SCC pp.
335, para 24) "The belief regarding the existence of a fact may thus be founded on a balance of
probabilities. A prudent man faced with conflicting probabilities concerning a fact situation will act
on the supposition that the fact exists, if on weighing the various probabilities he find that the
preponderance is in favour of the existence of the particular fact. As a prudent man, so the court
applies this test for finding whether a fact in issue can be said to be proved. The first step in this
process is to fix the probabilities, the second proved. The first step in this process is to fix the
probabilities, the second to weigh them, though the two may often intermingle. The impossible is
weeded out at the first stage, the improbable at the second. Within the wide range of probabilities
the court has often a difficult choice to make but it is this choice which ultimately determines where
the 1951 P 35 (CA) (1975) 2 SCC 326 CUSTA NO. 16 OF 2020 preponderance of probabilities lies,
Important issues like those which affect the status of parties demand a closer scrutiny than those
like the loan on a promissory note: 'the nature and gravity of an issue necessarily determines the
manner of attaining reasonable satisfaction of the truth of the issue 6, CLR at p. 210; or as said by
Lord Denning, 'the degree of probability depends on the subject-matter'. In proportion as the
offence is grave, so ought the proof to be clear7. All ER at p. 536'. But whether the issue is one of
cruelty or of a loan on a pronote, the test to apply is whether on a preponderance of probabilities the
relevant fact is proved. In civil cases this, normally is the standard of proof to apply for finding
whether the burden of proof is discharged." (emphasis supplied)
13. Applying the test laid down as above, we have no hesitation to hold that there exists more than
sufficient probabilities to pin down the respondent on the charge of violation of CBLR, 2013.
14. Mr. Chakraborty placed reliance on the decision of the Hon'ble Supreme Court in H.B. Cargo
Services Versus Commissioner of Customs 8 it was submitted that in the said case the period of
license expired and when the challenge to the revocation travelled up to the Hon'ble Supreme Court,
taking note of the fact that the said appellant had submitted an application for grant of fresh CHA
License, the application was directed to be considered by the competent authority on its own merits
uninfluenced by the revocation order concerning the previous CHA licence. Per Dixon, J. in WrightCommissioner Of Customs (Airport & ... vs M/S. Marico Logistics Private Limited on 21 July, 2022

v. Wright, (1948) 77 CLR 191 (Aust). Blyth v. Blyth, 1966 AC 643: (1966) 2 WLR 634: (1966) 1 All ER
524 (HL) 2021 (376) E.L.T. 241 (SC) CUSTA NO. 16 OF 2020
15. It is pointed out that licence granted to the respondent is to expire on 22.07.2022 and in the
event this Court does not agree with his submissions, the relief as granted by the Hon'ble Supreme
Court can be considered in the case of the respondent.
16. The decision in HB Cargo Services is in the nature of a concession granted by the department
before the Hon'ble Supreme Court which led to issuance of such direction. Ms. Manasi Mukherjee,
learned standing counsel for the appellant submitted that the appellant department is entitled to
take note of the conduct of the appellant even if an application for renewal was held to be
maintainable. We agree with such submissions. Thus, we are of the view that the decision in HB
Cargo Services does not render assistance to the case of the respondent.
17. In the result, we find that the order passed by the tribunal suffers from errors of law and
perversity calling for interference.
18. In the result, the appeal filed by the revenue is allowed and the substantial questions of law are
answered in favour of the revenue.
(T.S. SIVAGNANAM, J.) I agree.
(BIVAS PATTANAYAK, J.) (P.A - SACHIN)Commissioner Of Customs (Airport & ... vs M/S. Marico Logistics Private Limited on 21 July, 2022

