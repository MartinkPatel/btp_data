Alembic Pharmaceuticals Ltd. vs Rohit Prajapati . on 1 April,
2020
Equivalent citations: AIRONLINE 2020 SC 445
Author: D.Y. Chandrachud
Bench: Ajay Rastogi, Dhananjaya Y Chandrachud
                                                                          REPORTABLE
                              IN THE SUPREME COURT OF INDIA
                               CIVIL APPELLATE JURISDICTION
                                   Civil Appeal No. 1526 of 2016
          Alembic Pharmaceuticals Ltd.                             ...Appellant
                                              Versus
          Rohit Prajapati & Ors.                                   ...Respondents
With Civil Appeal No 3175 of 2016 With Civil Appeal Nos 6604-6605 of 2016 And With Civil Appeal
No 1555 of 2017 JUDGMENT Dr Dhananjaya Y Chandrachud, J
1. By a judgment dated 8 January 2016, the Bench of the National Green Tribunal1 for the Western
Zone held that a circular issued by the Union Ministry of Environment and Forests2 on 14 May
2002 is contrary to law. The circular envisaged the grant of ex post facto environmental clearances.
The NGT issued a slew of directions including the revocation of environmental clearances and for
closing down industrial units operating without valid consents. On 17 May 2016, the NGT dismissed
an application for review filed by one of the affected industrial units. The industrial units and MoEF
are in appeal 3.
2. The Environmental Impact Assessment4 notification of 27 January 1994 mandated prior
Environmental Clearances5 for setting up and expansion of industrial projects falling within thirty
categories. The deadline for obtaining an EC under the EIA notification of 1994 was extended by
various circulars to 31 March 1999 and thereafter to 30 June 2001. By the circular of 14 May 2002,Alembic Pharmaceuticals Ltd. vs Rohit Prajapati . on 1 April, 2020

which was quashed by the NGT, MoEF extended the period till 31 March 2003 for those industrial
units which had gone into production without obtaining an EC under the EIA notification of 1994 to
apply for and obtain an ex post facto EC. The circular indicated that it had been decided:
1 “NGT” 2 “MoEF” 3 Civil Appeal no 1526 of 2016 (Alembic Pharmaceuticals
Limited); Civil Appeal no 3175 of 2016 (United Phosphorus Limited); Civil Appeal
nos 6604-6605 of 2016 (Unique Chemicals); and Civil Appeal no 42756 of 2016
(Union of India) 4 “EIA” 5 “EC” “... to extend the deadline upto 31 March 2003 so
that defaulting units could avail of this last and final opportunity to obtain
ex-post-facto environmental clearance...”
3. The circular of 14 May 2002, allowed for ex post facto ECs, subject to a graded contribution into
an earmarked fund based on the investment cost of the project. The first and the second
respondents challenged the circular of 14 May 2002 before the High Court of Gujarat. The
proceedings were subsequently transferred to the NGT. The NGT by its decision dated 8 January
2016 held that the law did not permit the grant of an ex post facto clearances and that the circular of
14 May 2002 was an internal communication and did not override the provisions of the EIA
notification dated 27 January 1994 which had been issued in exercise of statutory powers conferred
by Section 3 of the Environment (Protection) Act 19866.
4. Having held that the concept of an “ex post facto environmental clearance” was not sustainable
with reference to any provision of law, the NGT issued the following directions:
(i) The authorities of the Union of India, including the MoEF, State of Gujarat,
Gujarat Pollution Control Board7 and District Collectors shall not grant consent for
an industrial activity covered by the EIA notification of 1994 without the steps
mandated by the notification such as screening, scoping, public hearing and decision
being fulfilled;
(ii) The ECs granted to the industrial units of the sixth to ninth respondents shall be
revoked;
(iii) All the industrial activities which were being operated without a valid EC and
consent to operate shall be closed down within one month;
6 “Environment Protection Act 1986” 7 “GPCB”
(iv) Each of the units shall deposit a compensation of  10 lakhs for having caused environmental
degradation; and
(v) The amount deposited shall be used for the restoration of the environment in and around the
industrial area of Ankleshwar in the State of Gujarat.
5. The private respondents before the NGT who were affected by the above directions are:Alembic Pharmaceuticals Ltd. vs Rohit Prajapati . on 1 April, 2020

(i) United Phosphorous Ltd - the sixth respondent;
(ii)           Unique Chemicals - the seventh respondent;
(iii)          Darshak Private Limited - the eight respondent; and
(iv)           Nirayu Private Limited - the ninth respondent.
The private respondents are engaged in the manufacture of pharmaceuticals and bulk
drugs at the industrial area of Ankleshwar in the State of Gujarat. Alembic
Pharmaceuticals Limited is the appellant in the lead appeal before this Court.
Darshak Private Limited merged with the appellant in 2002 pursuant to a scheme of amalgamation
sanctioned by the High Court of Gujarat. Nirayu Private Limited was acquired by the appellant
under a slump sale on 1 January 2008. Following this exercise, the manufacturing units of erstwhile
Darshak Private Limited and Nirayu Private Limited have come to be known as API – I and API – II,
respectively.
EIA Notification of 1994
6. The EIA notification was issued by the MoEF on 27 January 1994, in exercise of its powers under
Section 3(1) and clause (v) of Section 3(2) of the Environment Protection Act 1986 read with Rule
5(3)(d) of the Environment (Protection) Rules 19868. The EIA notification stipulated that:
“…on and form the date of publication of this notification in the Official Gazette,
expansion or modernization of any activity (if pollution load is to exceed the existing
one) or new project listed in Schedule I to this notification, shall not be undertaken in
any part of India unless it has been accorded environmental clearance by the Central
Government in accordance with the procedure hereinafter specified in this
notification.”
7. The EIA notification stipulated that any person who desired to undertake a new project, or the
expansion or modernisation of an existing industry, listed in Schedule-I shall submit an application
to the Secretary, MoEF. Entry 8 of Schedule - I includes industries engaged in manufacturing bulk
drugs and pharmaceuticals. The application had to be accompanied by a project report including,
inter alia, an EIA report and an environmental management plan prepared in accordance with the
guidelines issued by the Union Government through the MoEF from time to time. The notification
spelt out the procedure to be followed upon the submission of the application including an
evaluation and assessment by a stipulated agency. Clause 3(a)9 provided that:
“...no construction work primarily or otherwise relating to the setting up of the
project may be undertaken till the environmental and site clearances is obtained.”Alembic Pharmaceuticals Ltd. vs Rohit Prajapati . on 1 April, 2020

8. On 10 April 1997, the EIA notification of 1994 was amended by making a public hearing
mandatory for thirty categories of activities which required an EC. On 5 November 1998, the MoEF
issued a circular recording that though the EIA 8 “Environment Protection Rules” 9 Which was
(substituted on 4 May 1994) notification of 1994 was in effect since 27 January 1994, units covered
by the notification had been set up without obtaining prior ECs. The GPCB had despite the advice of
the MoEF allowed units to operate without valid ECs. In this backdrop, the circular of 5 November
1998 provided that:
“Since number of such proposals are large in number and many of the units have not
applied for environmental clearance genuinely out of ignorance it has been decided to
consider their case for environmental clearance on merits. This will apply only to
those proposals which are received in the Ministry till 31st March 1999.
Simultaneously State Pollution Control Boards have also been advised to issue
requisite notices to the units to apply for environmental clearance. In case of those
units which have already started production, we may consider the proposals on
merits and if necessary suggest additional mitigative measures. A formal
environmental clearance will be issued in these cases after approval by the competent
authority.”
9. By a circular dated 27 December 2000, the MoEF directed all state pollution
control boards to issue fresh notices to all defaulting units and extended the deadline
to obtain ECs from 31 March 1999 to 30 June 2001. Inspite of this, there were
delinquent units which had either failed to apply for an EC or had failed to complete
the requirement of a public hearing before the extended date.
By the circular of 14 May 2002, the deadline was extended to 31 March 2003. The circular stated
that:
“Keeping the foregoing in view, it has been decided to extend the deadline upto 31
March 2003 so that defaulting units could avail of this last and final opportunity to
obtain ex-post- facto environmental clearance. This would apply to all such units,
which had commenced construction activities/operations without obtaining prior
environmental clearance in violation of the EIA Notification of 27 January 1994.”
10. In terms of the circular, those defaulting units seeking an expansion were to earmark a separate
fund for “eco-development measures including community development measures in Indian
projects areas” on a graded scale linked to the investment in the project. This was indicated in a
tabulated form which read thus:
A Projects with investment upto  100 crores 1 % of the project cost with a minimum
of  50,000 B Projects with investment beyond  100 crores and upto 0.5% of the
project cost  1,000 crores subject to a minimum of  1 crore and a maximum of  2.5
crores C Projects with investment exceeding  1000 crores 0.25 % of the project cost
subject to a maximum of  5 crores Units which failed to comply with the extendedAlembic Pharmaceuticals Ltd. vs Rohit Prajapati . on 1 April, 2020

deadline were to be proceeded against.
The challenge to the ex post facto circular dated 14 May 2002
11. A petition was instituted under Article 226 of the Constitution by the first and second
respondents in the present lead appeal before the High Court of Gujarat challenging the circular
dated 14 May 2002 and seeking the revocation of the clearances which were granted to the
industrial units in question. The case was transferred to the Western Zonal Bench of the NGT by the
High Court of Gujarat on 21 April 2015. The NGT by its judgment dated 8 January 2016 set aside the
circular dated 14 May 2002 and issued consequential directions which have been noted in the
earlier part of this judgment. Unique Chemicals Limited, the seventh respondent before the NGT,
preferred a review petition against the judgment of the NGT which was dismissed. The affected
industrial units and the MoEF are in appeal before this Court.
12. The issue to be adjudicated is whether in view of the requirement of a prior EC under the EIA
notification of 1994, a provision for an ex post facto EC to industrial units could be validly made by
means of the circular dated 14 May 2002.
13. During the course of the submissions, Mr Kapil Sibal, learned Senior Counsel appearing on
behalf of Alembic Pharmaceuticals Limited has urged the following submissions:
(i) The issue is academic as both the units of the appellant have been granted an EC
for subsequent expansion to a much higher capacity after conducting a public hearing
and upon consideration of all material factors.
The relevant details in support of the submission are thus:
Darshak Private Limited (API - I)
(a) An EC was granted on 14 May 2003 for a capacity of 15 MT per month;
(b) An EC was granted on 16 April 2008 for expansion of capacity from 15 MT per
month to 25 MT per month; and
(c) An EC was granted on 31 January 2017 for a further expansion of capacity from 25
to 75 MT per month.
Nirayu Private Limited (API – II)
(a) An EC was granted on 14 May 2003 for a capacity of 47 MT per month; and
(b) An EC was granted on 20 December 2016 for an expanded capacity of 300 MT per month.Alembic Pharmaceuticals Ltd. vs Rohit Prajapati . on 1 April, 2020

(ii) The EIA notification of 1994 omits the expression “prior”. This is contrasted with the EIA
notification dated 14 September 2006 which stipulates the requirement of a “prior” EC. While a
prior EC is mandatory under the notification dated 14 September 2006, it was not under the earlier
notification dated 27 January 1994;
(iii) Once an EC has been granted for a much larger capacity after conducting a prior public hearing,
the question as to whether the first EC for a lesser capacity was valid, is of no significance. Since
both the units have an EC for a larger capacity, the satisfaction for granting an EC for a lesser
capacity would be subsumed;
(iv) The EIA notification of 1994 did not apply to the two units of the appellant (API – I and API –
II). Clause 8 of the explanatory note to the EIA notification of 1994 provides that where a no
objection certificate 10 from GPCB has been obtained before 27 January 1994, an EC is not required.
In this context it has been submitted that:
(a) On 17 July 1992, GPCB granted an NOC to establish and manufacture to the
manufacturing unit of API - I;
(b) On 29 May 1997 and 27 July 1998, GPCB granted an authorisation to operate
under the Air (Prevention and Control of Pollution) Act 1981 11to API - I;
(c) On 11 October 1999, GPCB granted API – I an authorisation to operate under the
Water (Prevention & Control of Pollution) Act 1974 12;
(d) On 24 May 1985,GPCB granted API - II a consent order under the Water Act;
10 “NOC” 11 “Air Act” 12 “Water Act”
(e) On 9 October 1991, GPCB granted a site clearance certificate to API – II;
(f) On 12 May 1993,GPCB granted an NOC to API - II to establish and for the manufacture drugs;
(g) On 23 September 1993 and 13 November 1999, GPCB granted a consent under the Water Act to
API - II;
(h) On 14 December 2001, GPCB granted an authorisation to API - II to operate under the
Hazardous Waste (Management and Handling) Rules 198913; and
(i) On 1 September 1999, 14 December 2001 and 7 March 2008, GPCB granted a consolidated
consent and authorisation to API - II.
(v) A public hearing was not mandatory under the EIA notification of 1994.Alembic Pharmaceuticals Ltd. vs Rohit Prajapati . on 1 April, 2020

Clause 4 of the explanatory note confers a discretion to call for a hearing in case of projects that may
cause large scale displacement or with severe environmental ramifications;
(vi) If the order of the NGT prevails, the appellant would be prejudiced and suffer an irreparable
loss. The appellant has made an investment of over  293 crores and employed a labour force of
over 1000 workers; and
(vii) The first respondent who was the petitioner before the NGT chose to target only the appellant
and two others out of over ninety different entities which were granted similar clearances. This
cherry picking of certain select units demonstrates the mala fide nature of the proceedings.
14. During the course of his submissions, Mr C U Singh, learned Senior Counsel appearing on behalf
of United Phosphorus Limited has urged the following submissions:
(i) The circular dated 5 November 1998, by which the deadline for obtaining ECs
under the EIA notification of 1994 was extended to 30 June 2001 was 13 “Hazardous
Waste Rules” not challenged. The circular dated 5 November 1998 specifically noted
that the State Pollution Control Board had despite the advice of the MoEF allowed
units to operate without valid ECs;
(ii) United Phosphorus Limited had all requisite ECs that were granted by GPCB for the existing and
expanded capacity. In this context it has been submitted:
(a) An EC was granted on 17 July 2003 for manufacturing Phorate and Terbuphose
(300 MT per month combined) and Acephate (80 MT per month);
(b) An EC was granted on 15 April 2008 for the expansion of capacity for
manufacturing pesticides and intermediate products. Production of Phorate and
Terbuphose was increased from 300 MT per month to 500 MT per month, and
production of Acephate was increased to 1000 MT per month;
(c) An EC was granted on 10 January 2020 for an enhanced capacity of 9546 MT per
month;
(iii) The complainant, the first respondent in the lead appeal, attended the public
hearing held on 16 January 2002 prior to the grant of an EC on 17 July 2003 and
raised no objections;
(iv) If the order of the NGT prevails, the appellant would be prejudiced and suffer an
irreparable loss. The appellant has employed approximately 400 permanent and
contract workers at its manufacturing unit; and
(v) The challenge by the first and second respondents was to the EIA notification
1994 which did not apply to the manufacturing unit of the appellant. At the relevantAlembic Pharmaceuticals Ltd. vs Rohit Prajapati . on 1 April, 2020

time, the appellant was exempted from obtaining an EC since it had all requisite
permissions. In this context it has been submitted:
(a) On 3 October 1992, GPCB granted an NOC to the appellant for setting up a
manufacturing unit;
(b) On 17 November 1995 and 2 April 1996, GPCB granted NOCs for expansion and
manufacturing additional products;
(c) On 27 August 2009, GPCB granted a consolidated consent and authorisation to
the appellant’s manufacturing unit;
(d) On 25 July 2012, GPCB issued an NOC for the expansion of the appellant’s
manufacturing unit; and
(e) On 11 May 2015 and 27 May 2017,GPCB granted a consolidated consent and
authorisation for expanded operations.
15. Appearing for Unique Chemicals Limited, Dr Abhishek Singhvi, learned Senior Counsel urged
the following submissions:
(i) The NGT did not have the jurisdiction to entertain the petition filed by the first
and second respondents in view of the decision of this Court in Techi Tagi Tara v
Rajendra Singh Bhandari & Ors14;
(ii) The EC granted in 2007 superseded the earlier EC granted in 2002.
Therefore, the question of validity of the earlier EC does not arise. In this context it has been
submitted:
(a) An EC was granted on 23 December 2002 for a capacity of 78.02 MT per month
for manufacturing bulk drugs and intermediates;
(b) An EC was granted on 8 August 2007 for an increase in manufacturing capacity
from 78.02 MT per month to 116.12 MT per month; and
(c) An EC was granted on 30 June 2018 for an increase in the manufacturing capacity
to 290 MT per month. On 10 April 2019, the 14 2018 (11) SCC 734 above EC was
amended allowing an increase in the number of products permitted to be
manufactured by the appellant.
(iii) The ex post facto clearance granted to the appellant cannot be set aside by the order of the NGT
in terms of the decision of this Court in Goa Foundation v Union of India15, where 95 industrial
projects were accorded ex post facto clearances in terms of the circular dated 14 May 2002.Alembic Pharmaceuticals Ltd. vs Rohit Prajapati . on 1 April, 2020

Accordingly, no question of closing down the manufacturing units of the appellants can arise;
(iv) The requirement of an ex post facto public hearing was introduced by an amendment in 1997 to
the EIA notification of 1994. The legality of an ex post facto public hearing has been upheld by this
Court in Lafarge Umiam Mining Pvt Ltd v Union of India16;
(v) In various cases where there has been a violation of law, this court has not ordered the closure
considering the significant investment and expansion undertaken by the industry. In Electrotherm
Ltd v Patel17, this Court did not order closure of the plant since a significant expansion had already
taken place and the industry was functioning;
(vi) If the order of the NGT prevails, the appellant would be prejudiced and suffer an irreparable
loss. The appellant has employed approximately 400 employees at its manufacturing unit;
15 (2005) 11 SCC 559 16 (2011) 7 SCC 338 17 (2016) 9 SCC 300
(vii) The EIA notification 1994 did not apply to the manufacturing unit of the appellant. The
manufacturing unit of the appellant was exempt from obtaining an EC as it had all the requisite
permissions. In this context it has been submitted:
(a) On 30 September 1995, GPCB issued an ‘air consent order’ under the Air Act;
(b) On 9 January 1996 GPCB issued an authorisation under the Hazardous Waste
Rules;
(c) On 16 April 1996 GPCB issued a ‘water consent order’ under the Water Act;
(d) On 15 April 2009 GPCB granted a consolidated consent and authorisation to the
manufacturing unit of the appellant;
(e) On 11 June 2010 and 26 June 2012, GPCB amended the consolidated consent and
authorisation granted to the appellant on 13 April 2009;
(f) On 30 May 2011, GPCB granted consent to set up a gas-based power generation
plant having a capacity of 400 KW at the manufacturing unit of the appellant;
(g) On 2 November 2013, GPCB granted a fresh consolidated consent and
authorisation to the manufacturing unit of the appellant; and
(h) On 25 January 2019 and 25 October 2019, GPCB granted a fresh and revised
consolidated consent and authorisation, respectively for an increase in the number of
products permitted to be manufactured at the manufacturing unit of the appellant.Alembic Pharmaceuticals Ltd. vs Rohit Prajapati . on 1 April, 2020

16. Appearing for the first and second respondents, Mr Siddharth Seem, learned counsel has urged
the following submissions before this Court:
(i) The circular dated 14 May 2002 is illegal because environmental jurisprudence
does not recognise any concept of ex post facto clearances.
Any ex post facto approval is void and the benefit of the circular cannot be given to such an industry.
In this regard, reliance was placed upon the decision of this Court in Common Cause v Union of
India18;
(ii) The circular dated 14 May 2002 does not mention its source or authority of law. The source of
the circular is not traceable to Section 3 of the Environment Protection Act 1986 because the circular
does not protect or improve the quality of the environment. The circular allows defaulters to get ex
post facto clearances and does not encourage compliance with the law;
(iii) The Comprehensive Environmental Pollution Index report by the Central Pollution Control
Board indicates that the air, water and soil parameters in and around the industrial area of
Ankleshwar in the State of Gujarat, where the three industrial units are located, are among the most
critical in India:
and
(iv) Even if this court were to hold that the closure of the industries should not be
ordered, compensation should be directed to be paid by them for restoration of the
environment. These industries have brazenly operated for years without
environmental clearances.
17. The rival submissions fall for our consideration.
18. We first address the challenge to the jurisdiction of the NGT to strike down rules or regulations
made under the Environment Protection Act 1986. In Tamil Nadu Pollution Control Board v Sterlite
Industries (I) Ltd 19 (“Sterlite”) this Court analysed the adjudicatory functions which have been
entrusted to the NGT under the National Green Tribunal Act 2010 20. Justice R F Nariman,
speaking for a two judge Bench held that while exercising its jurisdiction under Section 16, the NGT
cannot strike down rules or regulations made under the Environment 18 (2017) 9 SCC 499 19 2019
SCC Online SC 221 / Civil Appeal nos 4763-4764 of 2013 20 “NGT Act” Protection Act 1986. In
coming to this conclusion, the Court relied on the decision in Bharat Sanchar Nigam Limited v
Telecom Regulatory Authority of India 21, where the appellate power contained in Section 14 of the
Telecom Regulatory Authority of India Act22 1997 was interpreted. After adverting to this decision,
Justice R F Nariman concluded that:
“53…the NGT has no general power of judicial review akin to that vested under
Article 226 of the Constitution of India possessed by the High Courts of this country.”Alembic Pharmaceuticals Ltd. vs Rohit Prajapati . on 1 April, 2020

19. While placing reliance on the above decision, Mr ANS Nadkarni, learned
Additional Solicitor General made an attempt to demonstrate that the power to issue
the circular dated 14 May 2002 that extended the deadline for defaulting units to
avail of an ex post facto clearance until 30 March 2003 could well be traceable to
Section 3 of the Environment Protection Act 1986. Section 3, to the extent relevant,
provides thus:
“Section 3. Power of central government to take measures to protect and improve
environment.- (1) Subject to the provisions of this Act, the Central Government, shall
have the power to take all such measures as it deems necessary or expedient for the
purpose of protecting and improving the quality of the environment and preventing
controlling and abating environmental pollution.”
20. Section 3(1) is an enabling provision for the Central Government to undertake all
such measures as it deems necessary or expedient for the purpose of protecting and
improving the quality of the environment and preventing, controlling and abating
environmental pollution. This limb of the submission of the 21 (2014) 3 SCC 222 22
“TRAI Act” Additional Solicitor General is crucial to the issue as to whether the NGT
has exceeded its jurisdiction since the decision in Sterlite holds that the NGT, while
exercising its appellate jurisdiction, “cannot strike down rules or regulations made
under this Act”. In the present case, to demonstrate that the NGT did not have the
jurisdiction to strike down the circular dated 14 May 2002, it was urged that the
circular was issued by the MoEF pursuant to its powers under Section 3 of the
Environment Protection Act 1986. There is an inherent difficulty in accepting the
submission. Before this Court, the Union of India has not pleaded the case that the
circular dated 14 May 2002 is a measure which is traceable to the provisions of
Section 3. On the contrary, in its pleadings the Union of India construed it as a
“purely administrative decision”. Ground (iii) in paragraph 3 of the memo of appeal
states the position of the Union government:
“Because the Hon’ble Tribunal failed to appreciate that after the EIA, Notification
1994 the opportunity to seek ex-post facto environmental clearance was given to
industries in background of far reaching impact in terms of direct loss of livelihood in
the employees working in the units which also supply inputs to other units and their
indirect employment. It was submitted to the Hon’ble High Court of Gujarat that
issuance of circular dated 14/05/2002, based on which environmental clearance was
given, was purely an administrative decision before taking stringent action.”
(Emphasis supplied)
21. The omission in the appeal to make any attempt to sustain the circular dated 14 May 2002 with
reference to the provisions of Section 3 of the Environment Protection Act 1986 is significant. For an
action of the Central government to be treated as a measure referable to Section 3 it must satisfy the
statutory requirement of being necessary or expedient “for the purpose of protecting and improving
the quality of the environment and preventing, controlling and abating environment pollution”. TheAlembic Pharmaceuticals Ltd. vs Rohit Prajapati . on 1 April, 2020

circular dated 14 May 2002 in fact does quite the contrary. It purported to allow an extension of
time for industrial units to comply with the requirement of an EC. The EIA notification dated 27
January 1994 mandated that an EC has to be obtained before embarking on a new project or
expanding or modernising an existing one. The EIA notification of 1994 has been issued under the
provisions of the Environment Protection Act 1986 and the Environment Protection Rules 1986,
with the object of imposing restrictions and prohibitions on setting up of new projects or expansion
or modernisation of existing project. The measures are based on the precautionary principle and
aim to protect the interests of the environment. The circular dated 14 May 2002 allowed defaulting
industrial units who had commenced activities without an EC to cure the default by an ex post facto
clearance. Being an administrative decision, it is beyond the scope of Section 3 and cannot be said to
be a measure for the purpose of protecting and improving the quality of the environment. The
circular notes that there were defaulting units which had failed to comply with the requirement of
obtaining an EC as mandated. The circular provided for an extension of time and inexplicably
introduced the notion of an ex post facto clearance. In effect, it impacted the obligation of the
industrial units to be in compliance with the law. The concept of ex post facto clearance is
fundamentally at odds with the EIA notification dated 27 January 1994. The EIA notification of 1994
contained a stipulation that any expansion or modernisation of an activity or setting up of a new
project listed in Schedule – I “shall not be undertaken in any part of India unless it has been
accorded environmental clearance”. The language of the notification is as clear as it can be to
indicate that the requirement is of a prior EC. A mandatory provision requires complete compliance.
The words “shall not be undertaken” read in conjunction with the expression “unless” can only have
one meaning : before undertaking a new project or expanding or modernising an existing one, an EC
must be obtained. When the EIA notification of 1994 mandates a prior EC, it proscribes a post
activity approval or an ex post facto permission. What is sought to be achieved by the administrative
circular dated 14 May 2002 is contrary to the statutory notification dated 27 January 1994. The
circular dated 14 May 2002 does not stipulate how the detrimental effects on the environment
would be taken care of if the project proponent is granted an ex post facto EC. The EIA notification
of 1994 mandates a prior environmental clearance. The circular substantially amends or alters the
application of the EIA notification of 1994. The mandate of not commencing a new project or
expanding or modernising an existing one unless an environmental clearance has been obtained
stands diluted and is rendered ineffective by the issuance of the administrative circular dated 14
May 2002. This discussion leads us to the conclusion that the administrative circular is not a
measure protected by Section 3. Hence there was no jurisdictional bar on the NGT to enquire into its
legitimacy or vires. Moreover, the administrative circular is contrary to the EIA Notification 1994
which has a statutory character. The circular is unsustainable in law.
22. Mr Kapil Sibal, learned Senior Counsel appearing on behalf of Alembic Pharmaceuticals Limited
sought to urge that the EIA notification dated 27 January 1994 contains an omission of the
expression “prior” and contrasted this with the EIA notification dated 14 September 2006 which
stipulates the requirement of a “prior” EC. This, in his submission is an indicator that a prior EC is
mandatory under the notification dated 14 September 2006 but was not so under the earlier
notification dated 27 January 1994. This interpretation was not supported by Mr ANS Nadkarni,
learned Additional Solicitor General who categorically submitted that the requirement under the
notification dated 27 January 1994 was of a prior EC. We are unable to accept the submission of MrAlembic Pharmaceuticals Ltd. vs Rohit Prajapati . on 1 April, 2020

Kapil Sibal. The terms of the EIA notification dated 27 January 1994 leave no manner of doubt that
a prior EC was mandated before a new project was commenced or before undertaking any expansion
or modernisation of an existing project. The absence of the expression “prior” in the EIA notification
dated 27 January 1994 makes no difference since the words “shall not be undertaken…unless”
postulate the requirement of a prior EC. Speaking for a two judge Bench of this Court in Common
Cause v Union of India23 (“Common Cause”), Justice Madan B Lokur rejected the submission
which was urged on behalf of mining leaseholders that:
“108… the possibility of getting an ex post facto EC was a signal to the mining
leaseholders that obtaining an EC was not mandatory or that it if was not obtained,
the default was retrospectively condonable.” Disagreeing with the submission, the
Court held:
“125. We are not in agreement with the learned counsel for the mining leaseholders.
There is no doubt that the grant of an EC cannot be taken as a mechanical exercise. It
can only be granted after due diligence and reasonable care since damage to the
environment can have a long-term impact. EIA 1994 is therefore very clear that if
expansion or modernisation of any mining activity exceeds the existing pollution
load, a prior EC is necessary and as already held by this Court in M.C. Mehta [M.C.
Mehta v. Union of India, (2004) 12 SCC 118] even for the
23 (2017) 9 SCC 499 renewal of a mining lease where there is no expansion or modernisation of any
activity, a prior EC is necessary. Such importance having been given to an EC, the grant of an ex post
facto environmental clearance would be detrimental to the environment and could lead to
irreparable degradation of the environment. The concept of an ex post facto or a retrospective EC is
completely alien to environmental jurisprudence including EIA 1994 and EIA 2006. We make it
clear that an EC will come into force not earlier than the date of its grant.” (Emphasis supplied)
23. The concept of an ex post facto EC is in derogation of the fundamental principles of
environmental jurisprudence and is an anathema to the EIA notification dated 27 January 1994. It
is, as the judgment in Common Cause holds, detrimental to the environment and could lead to
irreparable degradation. The reason why a retrospective EC or an ex post facto clearance is alien to
environmental jurisprudence is that before the issuance of an EC, the statutory notification warrants
a careful application of mind, besides a study into the likely consequences of a proposed activity on
the environment. An EC can be issued only after various stages of the decision-making process have
been completed. Requirements such as conducting a public hearing, screening, scoping and
appraisal are components of the decision-making process which ensure that the likely impacts of the
industrial activity or the expansion of an existing industrial activity are considered in the
decision-making calculus. Allowing for an ex post facto clearance would essentially condone the
operation of industrial activities without the grant of an EC. In the absence of an EC, there would be
no conditions that would safeguard the environment. Moreover, if the EC was to be ultimately
refused, irreparable harm would have been caused to the environment. In either view of the matter,
environment law cannot countenance the notion of an ex post facto clearance. This would be
contrary to both the precautionary principle as well as the need for sustainable development.Alembic Pharmaceuticals Ltd. vs Rohit Prajapati . on 1 April, 2020

24. In order to enable the Court to assess the status of compliance, the material which has been
produced on the record by (i) Alembic Pharmaceuticals Limited; (ii) United Phosphorous Limited;
and (iii) Unique Chemicals Limited has been compiled in a tabulated form for each of the three
industries. For Alembic Pharmaceuticals Limited, the data for its two industrial units - Darshak
Private Limited (API – I) and Nirayu Private Limited (API – II) - has been analysed separately. For
each of the three industries, Table A below consists of the list of permissions, consents and
authorisations obtained by the industry from various authorities. Table B contains a list of ECs
which were granted from time to time to each industrial unit. The position as tabulated below is
based on the material which has been disclosed on the record of these proceedings :
Table A: List of permissions, consents and authorisations granted to Alembic
Pharmaceuticals Limited Darshak (API–I) Date Permission/Consent/Authorisation
Granted 17 July 1992 GPCB issued a no objection certificate to establish an industrial
unit for the manufacture of the following items at API –I: (i) Ciprofloxacin (1.25 MT
pm); and (ii) Norfloxacin (2.5 MT pm) 11June 1997 GPCB granted no objection
certificate for manufacturing additional items at API–I 29 May 1997 GPCB issued air
consent order authorising to operate API –I 11 July 1997, GPCB granted no objection
certificate for manufacturing of additional 12 July 1997 items at API–I and 27 July 31
March 1999 GPCB issued air consent order authorising to operate API –I 11 October
GPCB issued water consent order authorising to operate AP –I Between 27 GPCB
issued various consents under the Air Act, Water Act and September Hazardous
Waste Rules.
2002 – 23 December Nirayu Private Limited (API –II) Date Permission/Consent/Authorisation
Granted 12 July 1984 Factory license was issued in favour of Nirayu Private Limited 24 May 1985
GPCB issued water consent order authorising to operate API –II 9 October 1991 GPCB issued a site
clearance certificate to establish an industrial unit and manufacture the following items at API –II:
(i) CIMC chloride (2000 kgs pm); and (ii) Cloxacillin sodium (500 kgs pm) 12 May 1993 GPCB
granted a no objection certificate to establish an industrial unit and manufacture the following
items: (i) Acetone thiosemicarbazone (2 MT pm); (ii) 2 Mercapta (5 MT pm); (iii) Methoxy
orthoxymethyl chloride (0.3 MT pm); and (iv) Solvent ether (7 MT pm) 1 September GPCB issued
authorisation to operate API –II under the Hazardous 1993 Waste Rules 23 September GPCB issued
water consent order authorising to operate API –II 4 December GPCB granted no objection
certificate for manufacturing additional 1995 items at API–II 4 October 1996 GPCB issued air
consent order to operate API–II and 17 April 1 September GPCB granted consolidated consent and
authorisation to operate 1999 API–II 12 November GPCB issued water consent order to operate API
–II 14 December GPCB issued authorisation to operate API –II under the Hazardous 2001 Waste
Rules Between 27 GPCB issued various consents under the Air Act, Water Act and September
Hazardous Waste Rules.
2002     –    6
January 2015Alembic Pharmaceuticals Ltd. vs Rohit Prajapati . on 1 April, 2020

Table B: List of environmental clearances granted to Alembic Pharmaceuticals Limited Darshak
(API–I) Date of Date of Public EC for Expansion (Quantity) Date EC Granted Application Hearing
21 July 30 January 2002 Manufacturing of various bulk 14 May 2003 as per 2001 drugs and
intermediate the 1994 EIA products with a total capacity of notification 15 MT pm 8 December 9
October 2007 Expansion of total capacity of 16 April 2008 as per 2006 bulk drugs from 15 to 25 MT
the 2006 EIA pm notification 16 12 June 2015 Expansion of total capacity of 31 January 2017 as
September active pharmaceutical per the 2006 EIA 2015 ingredients from 25 to 75 MT notification
pm Nirayu Private Limited (API–II) Date of Date of Public EC for Expansion (Quantity) Date EC
Granted Application Hearing 20 July 30 January 2002 Manufacturing of various bulk 14 May 2003
as per 2001 drugs and intermediate the 1994 EIA products with a total capacity of notification 47
MT pm 28 March 12 June 2015 Expansion of total capacity of 20 December 2016 2016 active
pharmaceutical as per the 2006 EIA ingredients and intermediates notification from 47 to 300 MT
pm Table A: List of permissions, consents and authorisations granted to United Phosphorus Limited
Unit no 2 - Plot no 3405 and 3406 Date Permission/Consent/Authorisation Granted 31 January
Gujarat Industrial Development Corporation granted land to the 1992 appellant to establish and run
unit no 2 9 March 1992 GPCB issued no objection certificate for operation of unit no 2 in relation to
manufacturing of various products 3 October 1992 GPCB issued no objection certificate to set up a
unit to manufacture the following items at unit no 2: (i) Carbendazim; (ii) Quinalphos; and
(iii) Paraquat 1993 Unit no 2 commenced manufacturing activities 17 November GPCB granted no
objection certificate for expansion of unit no 2 for 1995 manufacturing of two additional products –
Phorate and Terbuphose (300 MT pm combined) 2 April 1996 GPCB granted no objection certificate
for expansion of unit no 2 for the manufacture of Acephate (80 MT per month) 27 August 2009
GPCB granted a consolidated consent and authorisation to unit no 2 25 July 2012 GPCB issued
consent to establish (NOC) for expansion of unit no 2 11 May 2015 GPCB granted a consolidated
consent and authorisation for the and 27 April expanded operations Table B: List of environmental
clearances granted to United Phosphorus Limited Unit no 2 - Plot no 3405 and 3406 Date of Date of
Public EC for Expansion (Quantity) Date EC Granted Application Hearing 21 August 16 January
2002 Manufacturing of Phorate and 17 July 2003 as per 2002 Terbuphose (300 MT pm EIA
notification of combined) and Acephate (80 1994 MT per month) 20 October Expansion of
pesticides and April 15 2008 as per 2007 - intermediate products. EIA notification of
- Production of Phorate and 2006 Terbuphose to be increased to 500 MT pm combined
- Production of Acephate to be increased to 1000 MT pm
- - Enhanced capacity of 9546 10 January 2020 as MT per month (as per written per EIA
notification submissions) of 2006 Table A: List of permissions, consents and authorisations granted
to Unique Chemicals Limited Unit at plot no 5 Date Permission/Consent/Authorisation Granted 14
August 1995 GPCB issued a no objection certificate to establish and run a unit (site clearance) at plot
no 5 30 September GPCB issued air consent order authorising to operate unit at plot no 5 25
December GPCB issued a no objection certificate to set up and manufacture the 1995 followingAlembic Pharmaceuticals Ltd. vs Rohit Prajapati . on 1 April, 2020

items at the unit at plot no 5: (i) Dichlotofenance sodium (6 MT pm); (ii) Nifedipine (2 MT pm); (iii)
Indolinone (6.9 MT pm); and (iv) Pefloxacin (3 MT pm) 9 January 1996 GPCB issued authorisation
under the Hazardous Waste Rules 16 April 1996 GPCB issued water consent order authorising to
operate unit at plot no 5 24 April 1996 Unit at plot no 5 commenced manufacturing activities 15
April 2009 GPCB granted a consolidated consent and authorisation to the unit at plot no 5 11 June
2010 GPCB amended the consolidated consent and authorisation to the and 26 June unit at plot no
5 granted on 15 April 2009 30 May 2011 GPCB granted no objection certificate to set up a gas-based
power generation plant of a capacity of 400 KW at the unit at plot no 5 2 November GPCB granted a
fresh consolidated consent and authorisation to the 2013 unit at plot no 5 for manufacturing of bulk
drugs and intermediates 1 July 2016 The appellant was certified as a zero liquid discharge unit 25
January GPCB granted a new consolidated consent and authorisation to the 2019 unit at plot no 5
25 October GPCB issued a revised consolidated consent and authorisation for 2019 increase in the
number of products that were permitted to be manufactured at the unit at plot no 5 Table B: List of
environmental clearances granted to Unique Chemicals Limited Unit at plot no 5 Date of Date of
Public EC for Expansion (Quantity) Date EC Application Hearing Granted 30 June 25 January Total
capacity 78.02 MT pm of bulk 23 December 2001 2002 drugs and intermediates. 2002 as per EIA
Manufacturing of (i) Diclofenac notification 1994 sodium intermediates and derivates (40 MT pm);
(ii) Nifedipine and its intermediates (2 MT pm); (iii) Indelinone (7 MT pm); (iv) Pefloxacin and its
intermediates (3 MT pm); (v) 2 methyl imldazole (15 MT pm); (vi) Phentolamine HCL (10 MT pm);
(vii) Diltazem HCL (1 MT pm); and (viii) other co-products 12 January Exempt – For an increase in
manufacturing of 8 August 2007 2007 proposed bulk drugs and intermediates from a as per EIA
project located total capacity from 78.02 MT pm to notification 2006 in notified 116.12 MT pm
industrial area For an increase in manufacturing of co-products from a total capacity of 103 MT pm
to 297 MT pm For setting up a captive power plant with 1.3 MW capacity 16 March Exempt – For an
increase in manufacturing of 30 June 2018 2018 proposed bulk drugs and intermediates from a as
per EIA project located total capacity from 78.02 MT pm to notification 2006 in notified 290 MT
pm by setting up of synthetic industrial area organic chemicals manufacturing plant Amendment to
the EC dated 30 10 April 2019 June 2018 increasing the number of as per the 2006 products
permitted to be EIA notification manufactured by the appellant at the unit at plot no 5
25. The position that emerges from the record is that in the case of all the three industries, ECs were
applied for nearly a decade after the introduction of the EIA notification 1994. In the meantime, the
industries had been set up and had commenced production. GPCB issued a notice to United
Phosphorus Limited on 30 April 2001 directing them to apply for an EC. On 9 December 2000,
GPCB issued a notice to Darshak Private Limited (API – I) and Nirayu Private Limited (API – II)
directing them to apply for and obtain an EC in accordance with the EIA notification of 1994.
Darshak Private Limited (API – I) of Alembic Pharmaceuticals Limited, applied for an EC on 21 July
2001 which it was granted on 14 May 2003. Subsequent applications for expansion of capacity were
submitted on 8 December 2006 and 16 September 2015 for which ECs were granted on 16 April
2008 and 31 January 2017, respectively. Nirayu Private Limited (API – II), initially applied for an
EC on 20 July 2001 and the EC was granted on 14 May 2003. The application for the grant of an EC
for an extended capacity was submitted on 28 March 2016 and the EC was granted on 20 December
2016. In the case of United Phosphorous Limited, the initial EC was sought on 21 August 2002 and
it was granted on 17 July 2003. An application for expansion of capacity was submitted on 20Alembic Pharmaceuticals Ltd. vs Rohit Prajapati . on 1 April, 2020

October 2007 and it was granted on 15 April 2008. An EC for the further expansion of capacity was
granted on 10 January 2020. In the case of Unique Chemicals Limited, the initial application for an
EC was submitted on 30 June 2001 and it was granted on 23 December 2002. Subsequent
applications for expansion in capacity were submitted on 12 January 2007 and 16 March 2018 for
which ECs were granted on 8 August 2017 and 30 June 2018, respectively. An amendment to the EC
dated 30 June 2018 was granted on 10 April 2019. The documents disclosed by the three industries
demonstrate that no ECs as mandated by the EIA notification of 1994 were sought before the
commencement or expansion of operations. The terms of the EIA notification of 1994 envisage that
expansion or modernisation of any activity (if the pollution load is to exceed the existing one) or a
new project listed in Schedule – I shall not be undertaken unless it has been granted an EC. In the
present case, all the three industries continued to operate in the teeth of the EIA notification 1994.
26. Learned counsel appearing for the three industries have relied on a range of additional measures
adopted, such as the installation of latest pollution capturing technologies, recent consents from
GPCB and certification of “zero discharge” units. These measures adopted subsequently will not cure
the failure to obtain ECs before the projects commenced operation. These measures are simply to
ensure compliance with the pollution standards and requirements of law that exist as of date. These
submissions have no bearing on determining whether the industrial units were in the past operating
in compliance with the requisite environmental standards. These measures cannot act as correctives
for historical wrongs and cannot compensate for the damage already caused to the environment as a
result of manufacturing activities which were carried on without ECs.
27. Learned counsel for the three industries urged that the EIA notification of 1994 did not apply to
their manufacturing units as they were covered by the exemption in terms of Clause 8 of the
explanatory note. The issue which needs to be considered is whether the industries were covered by
the exemption and were not required to obtain ECs. Clause 8 to the explanatory note to the EIA
notification of 1994 states thus:
“8. Exemption for projects already initiated For projects listed in Schedule – I to the
notification in respect of which the required land has been acquired and all relevant
clearances of the State Government including NOC from the respective State
Pollution Control Board have been obtained before 27th January 1994, a project
proponent will not be required to seek environmental clearance from the IAA.
However, those units who have not as yet commenced production will inform the
IAA”
28. Before the exemption contained in Clause 8 applies, it was necessary for projects listed in
Schedule - I to obtain all relevant clearances from the State government including an NOC from the
State Pollution Control Board. It was in other words not sufficient to merely obtain an NOC from the
State Pollution Control Board. The exemption which was carved out in the explanatory note was to
ensure that activities which had received all required clearances at the state level, following the
acquisition of land should be protected. In fact, many of them would also involve the
commencement of production prior to 27 January 1994. The explanatory note stated that where
production had not yet commenced, the IAA would have to be intimated. In order to be coveredAlembic Pharmaceuticals Ltd. vs Rohit Prajapati . on 1 April, 2020

within the scope of the exemption, the burden is on the industry to demonstrate before this Court
that they fulfilled conditions spelt out in Clause 8 of the explanatory note. The EIA notification 1994
is a significant instrument in effectuating the implementation of the precautionary principle. The
burden lies on the project proponent who seeks to alter the state of the environment or to impact on
the environment to demonstrate that the terms on which an exemption has been granted have been
fulfilled. An exemption must be construed in its strict sense according to its plain terms. None of the
three industries before the Court have furnished an exhaustive catalogue of what were the “relevant
clearances from the State government” that had to be obtained under the provisions of the law as it
then stood.
29. With this background, we will now assess individually whether the industries in question
qualified for the exemption provided by Clause 8 to the explanatory note.
30. Alembic Pharmaceuticals Limited
(i) Darshak Private Limited (API - I) The material produced on the record indicates that on 17 July
1992, GPCB had issued an NOC to establish an industrial unit and manufacture two
pharmaceuticals products. However, the NOC for manufacturing additional items was issued only
on 11 June 1997 subsequent to the EIA notification dated 27 January 1994. The NOC dated 17 July
1992 issued by GPCB clearly states:
“We would like to inform you that the proposed location for this industrial plant is
acceptable to us provided that you will implement the following measure for the
prevention and control of environmental pollution:-
(A) (B) (C) (D) Adequate arrangement for the management and handling of
hazardous waste shall be made:
IMPORTANT NOTE (3) The applicant/entrepreneur shall be required to obtain the
following from the Board prior to commencement of production:
(a) Consent under the Water (Prevention and Control of Pollution) Act 1974.
(b) Consent under the Air (Prevention and Control of Pollution) Act 1981.
(c) Authorisation under the Hazardous Waste (Management and Handling) Rules
1989 under the Environment (Protection) Act 1986.” (Emphasis supplied) GPCB
while granting the NOC to establish an industrial unit required the project proponent
to undertake certain measures for the prevention and control of environmental
pollution including installation of treatment plants, discharge of effluents within
prescribed limits and the creation of a green belt around the industrial unit. One of
the points under the “Important Note” states that the project proponent “shall be
required to obtain” from the board “prior to commencement of production” requisite
consents and authorisations under the Air Act, Water Act and Hazardous WasteAlembic Pharmaceuticals Ltd. vs Rohit Prajapati . on 1 April, 2020

Rules. The language used in the NOC makes it clear that obtaining consents and
authorisations under various environment related legislations was a mandatory
pre-condition and not merely directory. In the present case, the authorisation under
the Air Act was issued only on 29 May 1997 and 31 March 1999. The authorisation
under the Water Act was issued on 11 October 1999. Clause 8 of the explanatory note
states that for the exemption to apply, it was necessary for projects listed in Schedule
- I to have obtained all relevant clearances from the State government including an
NOC from the State Pollution Control Board. The evidence produced on the record by
Darshak Private Limited indicates that it did not have the requisite consents and
authorisations under the Air Act, Water Act and Hazardous Waste Rules prior to the
EIA notification 1994. Many of the consents and permissions were obtained
subsequently and not prior to the EIA notification of 1994. Accordingly, the
manufacturing unit of Darshak Private Limited (API – I) is not covered under the
exemption under Clause 8 to the explanatory note of the EIA notification of 1994.
(ii) Nirayu Private Limited (API – II) A factory license was issued on 12 July 1984 to
API – II. On 24 May 1985, GPCB issued a water consent order under the Water Act.
This was valid only for the manufacture of anaesthetic Ether. GPCB issued a site
clearance certificate on 9 October 1991 for the manufacture of CIMC Chloride and
Cloxacillin Sodium. An NOC to establish an industrial unit and to manufacture
products was issued on 12 May 1993 and one for expansion on 4 December 1995. It is
relevant to note that the NOC dated 12 May 1993 issued by GPCB to Nirayu Private
Limited (API – II) is worded in exactly the same manner as the NOC dated 17 July
1992 issued to Darshak Private Limited (API – I). The NOC dated 12 May 1993 issued
to Nirayu Private Limited (API – II) also mandates that the project proponent “shall
be required to obtain” from the board “prior to commencement of production”
requisite consents and authorisations under the Air Act, Water Act and Hazardous
Waste Rules from GPCB. In the case of Nirayu Private Limited (API – II),
authorisation under the Hazardous Waste Rules was issued on 1 September 1993.
Consent to operate API – II under the Water Act was issued on 12 November 1999.
GPCB issued consolidate consent and authorisation to operate API – II on 14
December 2010. From the above narration which is based on the disclosures made by
Nirayu Private Limited, it is evident that all consents and permissions had not been
obtained prior to the EIA notification of 1994.
Accordingly, the manufacturing unit of Nirayu Private Limited (API – II) is not covered under the
exemption under Clause 8 to the explanatory note of the EIA notification of 1994.
31. United Phosphorous Limited On 31 January 1992, Gujarat Industrial Development Corporation
granted land to the appellant to establish and run its unit. On 9 March 1992 and 3 October 1992,
GPCB issued an NOC for the operation of the unit. The unit commenced manufacturing in 1993. It is
relevant to note that the NOC dated 3 October 1993 also mandates that the project proponent “shall
be required to obtain” from the GPCB “prior to commencement of production” requisite consents
and authorisations under the Air Act, Water Act and Hazardous Waste Rules. United PhosphorousAlembic Pharmaceuticals Ltd. vs Rohit Prajapati . on 1 April, 2020

Limited has not disclosed the dates on which it received authorisations under the relevant
environmental legislation. It has placed on record a consolidated consent and authorisation that was
issued much later on 27 August 2009 under the Air Act, Water Act and Hazardous Waste
(Management, Handling and Trans boundary Movement) Rules 2008. The disclosures which have
been made are patently incomplete. No material has been produced to indicate that all relevant
clearances from the State government including the NOC from GPCB had been obtained prior to the
EIA notification 1994. Accordingly, they cannot be granted the benefit of the exemption under
Clause 8 to the explanatory note of the EIA notification of 1994.
32. Unique Chemicals Limited The material produced on the record indicates that GPCB issued an
NOC to establish and run the manufacturing unit on 14 August 1995. It is evident from the table
enlisting the list of relevant permissions, consents and authorisations that all permissions were
received after the EIA notification 1994 was issued. Clearly, Unique Chemicals Limited is not
entitled to the benefit of the exemption contained in Clause 8 of the explanatory note to the EIA
notification 1994.
33. From the material placed on the record by the industries, it becomes evident that there has been
a gross abdication of responsibility by all the three industries in terms of obtaining timely consents
and authorisations from the GPCB. There exists a distinction between obtaining relevant clearances
and consents from the State Pollution Control Board and obtaining an environmental clearance in
accordance with the procedure laid down under the EIA notification of 1994. A consent order issued
by the State Pollution Control Board allows an industry to operate within the prescribed emission
norms. However, the consent orders do not account for the social cost and impact of undertaking an
industrial activity on the environment and its surroundings. A holistic analysis of the environmental
impact of an industrial activity is only accounted for once all the steps listed out in EIA notification
of 1994 are followed. The purpose of setting in place specific requirements such as public hearing,
screening, scoping and appraisal is to foster deliberative decisions and protect environmental
concerns. The detailed process listed out in the EIA notification of 1994 for obtaining an EC allows
for minimising the adverse environmental impact of any industrial activity and improving the
quality of the environment. One must adopt an ecologically rational outlook towards development.
Given the social and environmental impacts of an industrial activity, environment compliance must
not be seen as an obstacle to development but as a measure towards achieving sustainable
development and inter-generational equity.
34. We have therefore come to the conclusion that none of the three industries were entitled to the
benefit of the exemption contained in Clause 8 of the explanatory note to the EIA notification of
1994.
35. The issue which must now concern the Court is the consequence which will emanate from the
failure of the three industries to obtain their ECs until 14 May 2003 in the case of Alembic
Pharmaceuticals Limited, 17 July 2003 in the case of United Phosphorous Limited, and 23
December 2002 in the case of Unique Chemicals Limited. The functioning of the factories of all
three industries without a valid EC would have had an adverse impact on the environment, ecology
and biodiversity in the area where they are located. The Comprehensive Environmental PollutionAlembic Pharmaceuticals Ltd. vs Rohit Prajapati . on 1 April, 2020

Index24 report issued by the Central Pollution Control Board for 2009-2010 describes the
environmental quality at 88 locations across the country. Ankleshwar in the State of Gujarat, where
the three industries are located showed critical levels of pollution 25. In the Interim Assessment of
CEPI for 2011, the report indicates similar critical figures 26 of pollution in the Ankleshwar 24
“CEPI” 25 CEPI score - 88.50 26 CEPI score - 85.75 area. The CEPI scores for 201327 and 201828
were also significantly high. This is an indication that industrial units have been operating in an
unregulated manner and in defiance of the law. Some of the environmental damage caused by the
operation of the industrial units would be irreversible. However, to the extent possible some of the
damage can be corrected by undertaking measures to protect and conserve the environment.
36. Even though it is not possible to individually determine the exact extent of the damage caused to
the environment by the three industries, several circumstances must weigh with the Court in
determining the appropriate measure of restitution. First, it is not in dispute that all the three
industries did obtain ECs, though this was several years after the EIA notification of 1994 and the
commencement of production. Second, subsequent to the grant of the ECs, the manufacturing units
of all the three industries have also obtained ECs for an expansion of capacity from time to time.
Third, the MoEF had issued a circular on 5 November 1998 permitting applications for ECs to be
filed by 31 March 1999, which was extended subsequently to 30 June 2001. On 14 May 2002, the
deadline was extended until 31 March 2003 subject to a deposit commensurate to the investment
made. The circulars issued by the MoEF extending time for obtaining ECs came to the notice of this
Court in Goa Foundation (I) v Union of India29. Fourth, though in the context of the facts of the
case, this Court in Lafarge Umiam Mining Private Limited v Union of India30 (“Lafarge”) has
upheld the decision to grant ex post facto clearances with respect to limestone 27 CEPI score - 80.93
28 CEPI score - 80.21 29 (2005) 11 SCC 559 30 (2011) 7 SCC 338 mining projects in the State of
Meghalaya. In Lafarge, the Court dealt with the question of whether ex post facto clearances stood
vitiated by alleged suppression of the nature of the land by the project proponent and whether there
was non-application of mind by the MoEF while granting the clearances. While upholding the ex
post facto clearances, the Court held that the native tribals were involved in the decision-making
process and that the MoEF had adopted a due diligence approach in reassuring itself through
reports regarding the environmental impact of the project. Chief Justice SH Kapadia speaking for
the three judge Bench observed:
“119. The time has come for us to apply the constitutional “doctrine of
proportionality” to the matters concerning environment as a part of the process of
judicial review in contradistinction to merit review. It cannot be gainsaid that
utilization of the environment and its natural resources has to be in a way that is
consistent with principles of sustainable development and intergenerational equity,
but balancing of these equities may entail policy choices. In the circumstances,
barring exceptions, decisions relating to utilization of natural resources have to be
tested on the anvil of the well- recognized principles of judicial review. Have all the
relevant factors been taken into account? Have any extraneous factors influenced the
decision? Is the decision strictly in accordance with the legislative policy underlying
the law (if any) that governs the field? Is the decision consistent with the principles of
sustainable development in the sense that has the decision-maker taken into accountAlembic Pharmaceuticals Ltd. vs Rohit Prajapati . on 1 April, 2020

the said principle and, on the basis of relevant considerations, arrived at a balanced
decision? Thus, the Court should review the decision-making process to ensure that
the decision of MoEF is fair and fully informed, based on the correct principles, and
free from any bias or restraint. Once this is ensured, then the doctrine of “margin of
appreciation” in favour of the decision-maker would come into play.” (Emphasis
supplied)
37. After adverting to the decision in Lafarge, another Bench of three learned judges
of this Court in Electrotherm (India) Limited v Patel Vipulkumar Ramjibhai31, dealt
with the issue of whether an EC granted for expansion to the appellant without
holding a public hearing was valid in law. Justice Uday Umesh Lalit speaking for the
Bench held thus:
“19…the decision-making process in doing away with or in granting exemption from
public consultation/public hearing, was not based on correct principles and as such
the decision was invalid and improper.” The Court while deciding the consequence of
granting an EC without public hearing did not direct closure of the appellant’s unit
and instead held thus:
“20. At the same time, we cannot lose sight of the fact that in pursuance of
environmental clearance dated 27-1-2010, the expansion of the project has been
undertaken and as reported by CPCB in its affidavit filed on 7-7-2014, most of the
recommendations made by CPCB are complied with. In our considered view, the
interest of justice would be subserved if that part of the decision exempting public
consultation/public hearing is set aside and the matter is relegated back to the
authorities concerned to effectuate public consultation/public hearing. However,
since the expansion has been undertaken and the industry has been functioning, we
do not deem it appropriate to order closure of the entire plant as directed by the High
Court. If the public consultation/public hearing results in a negative mandate against
the expansion of the project, the authorities would do well to direct and ensure
scaling down of the activities to the level that was permitted by environmental
clearance dated 20-2-2008. If public consultation/public hearing reflects in favour of
the expansion of the project, environmental clearance dated 27-1-2010 would hold
good and be fully operative. In other words, at this length of time when the expansion
has already been undertaken, in the peculiar facts of this case and in order to meet
ends of justice, we deem it appropriate to change the nature of requirement of public
consultation/public hearing from pre-decisional to post-decisional. The public
31 (2016) 9 SCC 300 consultation/public hearing shall be organised by the authorities concerned in
three months from today.” (Emphasis supplied)
38. Guided by the precepts that emerge from the above decisions, this Court has taken note of the
fact that though the three industries operated without an EC for several years after the EIA
notification of 1994, each of them had subsequently received ECs including amended ECs forAlembic Pharmaceuticals Ltd. vs Rohit Prajapati . on 1 April, 2020

expansion of existing capacities. These ECs have been operational since 14 May 2003 (in the case of
Alembic Pharmaceuticals Limited), 17 July 2003 (in the case of United Phosphorous Limited), and
23 December 2002 (in the case of Unique Chemicals Limited). In addition, all the three units have
made infrastructural investments and employed significant numbers of workers in their industrial
units.
39. In this backdrop, this Court must take a balanced approach which holds the industries to
account for having operated without environmental clearances in the past without ordering a
closure of operations. The directions of the NGT for the revocation of the ECs and for closure of the
units do not accord with the principle of proportionality. At the same time, the Court cannot be
oblivious to the environmental degradation caused by all three industries units that operated
without valid ECs. The three industries have evaded the legally binding regime of obtaining ECs.
They cannot escape the liability incurred on account of such non- compliance. Penalties must be
imposed for the disobedience with a binding legal regime. The breach by the industries cannot be
left unattended by legal consequences. The amount should be used for the purpose of restitution and
restoration of the environment. Instead and in place of the directions issued by the NGT, we are of
the view that it would be in the interests of justice to direct the three industries to deposit
compensation quantified at  10 crores each. The amount shall be deposited with GPCB and it shall
be duly utilised for restoration and remedial measures to improve the quality of the environment in
the industrial area in which the industries operate. Though we have come to the conclusion, for the
reasons indicated, that the direction for the revocation of the ECs and the closure of the industries
was not warranted, we have issued the order for payment of compensation as a facet of preserving
the environment in accordance with the precautionary principle. These directions are issued under
Article 142 of the Constitution. Alembic Pharmaceuticals Limited, United Phosphorous Limited and
Unique Chemicals Limited shall deposit the amount of compensation with GPCB within a period of
four months from the date of receipt of the certified copy of this judgment. This deposit shall be in
addition to the amount directed by the NGT. Subject to the deposit of the aforesaid amount and for
the reasons indicated, we allow the appeals and set aside the impugned judgment of the NGT dated
8 January 2016 in so far as it directed the revocation of the ECs and closure of the industries as well
as the order in review dated 17 May 2016. Pending application(s), if any, shall stand disposed of.
…………...…...….......………………........J. [Dr Dhananjaya Y Chandrachud]
…..…..…....…........……………….…........J. [Ajay Rastogi] New Delhi;
April 01, 2020.Alembic Pharmaceuticals Ltd. vs Rohit Prajapati . on 1 April, 2020

