Arunachal Pradesh Municipal Act, 2007
ARUNACHAL PRADESH
India
Arunachal Pradesh Municipal Act, 2007
Act 4 of 2008
Published on 28 October 2010• 
Commenced on 28 October 2010• 
[This is the version of this document from 28 October 2010.]• 
[Note: The original publication document is not available and this content could not be
verified.]• 
Arunachal Pradesh Municipal Act, 2007(Act No. 4 of 2008)Last Updated 8th February, 2020To
introduce and consolidate the laws relating to the municipal Government in the State of Arunachal
Pradesh in conformity with the provisions of the Constitution of India (Seventy-fourth Amendment)
Act, 1992, based on the principles of Government at various levels and to introduce reforms in
financial management and accounting systems, internal resource generation capacity and
organizational design of Municipalities, to ensure professionalization of the municipal personnel
and to provide for matters connected therewith or incidental thereto.Be it enacted by the Legislature
of the State of Arunachal Pradesh in the Fifty- eighth Year of the Republic of India as follows
:-Chapter - I Preliminary
1. Short title, extent and commencement.
(1)This Act may be called the Arunachal Pradesh Municipal Act, 2007.(2)It shall extend to the whole
of the State of Arunachal Pradesh or part thereof as may be notified by the State Government from
time to time excluding defence areas therein.(3)It shall come into force on such date as the State
Government may, by notification, appoint in this behalf, and different dates may be appointed for
different municipal areas.
2. Definitions.
- In this Act, unless the context otherwise requires,-(1)"Adhoc Committee" means an Ad-hoc
Committee appointed under section 33;(2)"Auditor" means an Auditor appointed under section 93,
and includes any officer authorized by him to perform all or any of the functions of an Auditor under
this Act;(3)"Balance sheet" means the balance sheet prepared under section 91;(4)"Bio-medical
waste" means waste generated during diagnosis, treatment or immunization of human beings or
animals or in research activities pertaining thereto or in the production or testing of
biologicals;(5)"Bridge" includes a culvert;(6)"Budget Estimate" means the budget estimate prepared
under section 84;(7)"Budget Grant" means the total sum entered on the expenditure side of aArunachal Pradesh Municipal Act, 2007

budget estimate under a major head and adopted by the Municipality, and includes any sum by
which such budget grant is increased or reduced by transfer from or to other heads in accordance
with the provisions of this Act and the rules and the regulations there under ;(8)"Building" means a
structure constructed for whatever purpose and of whatever materials, and includes the foundation,
plinth, walls, floors, roofs, chimneys, fixed platforms, verandas balconies, cornices or projections or
part of a building or anything affixed thereto or any wall (other than a boundary wall of less than
three meters in height) enclosing or intended to enclose, any land, sign or outdoor display-structure
but does not include a tent, shamiana or tarpaulin shelter ;(9)"Cadres" of common municipal
services" means the cadres of common municipal services constituted under sub-section (1) of
section 43;(10)"Carriage" means any wheeled vehicle, with springs or other appliances acting as
springs, which is ordinarily used for the conveyance of human beings, and includes a auto-rickshaw,
cycle-rickshaw, bicycle or tricycle, but does not include a perambulator or other form of vehicle
designed for the conveyance of children or elderly, infirm or handicapped persons ;(11)"Cart" means
any hackney or wheeled vehicle with or without springs, which is not a carriage, and includes a
handcart, a cycle van and a push van but does not include any wheeled vehicle which is propelled by
mechanical power or its trailer ;(12)"Category 'A' post" means a category 'A' post classified as such
under section 37 ;(13)"Category 'B' post" means a category 'B' post classified as such under section
37;(14)"category 'C' post" means a category 'C' post classified as such under section 37;(15)"category
'D' post" means a category 'D' post classified as such under section 37;(16)"Chief Councillor"
means,-(i)in relation to a Municipal Corporation, the Mayor,(ii)in relation to a Municipal Council,
the Municipal Chairperson, and(iii)in relation to Nagar Panchayat, the Municipal president
;(17)"Chief Municipal Executive Officer" means,-(i)in relation to a Municipal Council in Capital
Region and " Municipal Executive Officer" means,-(ii)in relation to a Municipal Council or Nagar
Panchayat, in districts.(18)"City" means a larger urban area declared to be a city under section 3
;(19)"Class 'A' smaller urban area" means a smaller urban area classified as such under section 7
;(20)"Class 'B' smaller urban area" means a smaller urban area classified as such under section 7
;(21)"Class 'C' smaller urban area" means a smaller urban area classified as such under section 7
;(22)"Councillor" , in relation to a Municipality, means a person chosen by direct election from a
ward of that Municipality ;(23)"Cubical extent," with reference to the measurement of a building,
means the space contained within the external surface of its walls and roof and the upper surface of
the floor of its lowest or only storey ;(24)"dangerous disease" means-(a)Cholera, plague, small-pox,
cerebrospinal meningitis, diphtheria, Tuberculosis, leprosy, influenza, encephalitis, poliomyelitis, or
syphilis; or(b)any other epidemic, endemic, infectious disease which the State Government may, by
notification, declare to be a dangerous disease for the purposes of this Act ;(25)"Deputy Chief
Councilor" means,-(a)in relation to a Municipal Corporation, the Deputy Mayor,(b)in relation to a
Municipal Council, the Municipal Vice- Chairperson, and(c)in relation to a Nagar Panchayat, the
Municipal Vice president ;(26)"Director of Urban Local Bodies" means an officer appointed as such
by the State 'Government' and includes an Additional Director, a Joint Director, a Deputy Director,
or any other officer of nodal department of the State Government authorized by it to perform the
functions of the Director of Urban Local Bodies under this Act,(27)"Domestic purpose" in relation to
the supply of water, means the purpose other than those referred to in sub-section ( 3) of section 172
;(28)"Drain" includes a sewer, a house-drain, a drain of any other description, a tunnel, a culvert, a
ditch, a channel or any other device for carrying off sullage, sewage, offensive matter, polluted
water, rain-water or sub-soil water ;(29)"Drug" means any substance used as medicine or in theArunachal Pradesh Municipal Act, 2007

composition or preparation of medicine, whether for internal or external use, but does not include a
drug within the meaning of clause ( b) of section 3 of the Drugs and Cosmetics Act, 23 of
1940;(30)"Dwelling- house" means a masonry building constructed, used, or adapted to be used,
wholly or principally for human habitation ;(31)"Empowered Standing Committee" means the
Empowered Standing Committee referred to in section 21 ;(32)"Establishment Schedule" means the
Establishment Schedule prepared under section 37 ;(33)"Financial statement" means the financial
statement prepared under section 90 ;(34)" Food" includes every article used for food or drink by
man, other than drugs or water, and any article which ordinarily enters into, or is used in the
composition or preparation of, human food, and also includes confectionery, flavouring and
colouring matters, spices and condiments ;(35)" Footpath" means a pavement for use by pedestrians
which abuts a category I or category II or category III or category IV road ;(36)" Habitable room"
means a room constructed or adapted for human habitation;(37)"Hazardous process" means the
hazardous process defined in Clause (cb) of section 2 of the Factories Act, 1948,(63 of 1948.)
;(38)"Hazardous wastes" means the categories of wastes specified as such in the Environment (
Protection ) Act, 1986,(29 of 1986.) ;(39)"House- drain" means any drain of one or more premises
used for the drainage of such premises ;(40)"House-gully" means a passage or a strip of land
constructed, set apart or utilized for the purpose of serving as a drain or affording access to a privy,
urinal, cesspool or other receptacle for filthy or polluted matter for municipal employee ;(41)"Hut"
means any building, no substantial part of which, excluding the walls up to a height of fifty
centimeters above the floor or floor level, is constructed of masonry, reinforced concrete, steel, iron
or other metal ;(42)"Industrial township" means such urban area or part thereof as the Governor
may, having regard to the size of the area and the municipal services being provided or proposed to
be provided by an industrial establishment in that area and such other factors as he may deem fit, by
notification, specify to be an industrial township ;(43)"Infectious disease" or "communicable
disease" means any disease which may be transmitted from one person to another and declared as
such by the State Government by notification;(44)"Joint Committee" means a Joint Committee
constituted under section 34;(45)"Larger urban area" means a municipal area classified as a larger
urban area under section 7 ;(46)"Land or building" includes a slum ;(47)"Market" includes any
place, by whatever name called, where persons assemble for the sale of meat, fish, fruit, vegetables,
live stock, or any other article of food of a perishable nature, or any other article for which there is a
collection of shops or warehouses or stalls, declared and licensed by the Municipality as a
market.(48)"Masonry building" means any building, other than a hut, and includes any structure, a
substantial part of which is made of masonry, reinforced concrete, steel, iron or other metal
;(49)"Milk" includes cream, separated milk, and condensed, sterilized, desiccated or toned milk
;(50)"Municipal Accounts Committee" means a Municipal Accounts Committee constituted under
section 100 ;(51)"Municipal Accounting Manual" means the Municipal Accounting Manual prepared
and maintained under section 89 ;(52)"Municipal area" means an area constituted as a municipal
area under section 6 ;(53)"Municipal drain" means a drain vested in the Municipality
;(54)"Municipal Fund" means the Municipal Fund referred to in section 75 ;(55)"Municipal
Magistrate" means the Municipal Magistrate appointed under section 425 ;(56)"Municipal Market"
means a market belonging to, or maintained by, the Municipality;(57)"Municipal Service
Commission" means the Municipal Service Commission constituted under section 44
;(58)"Municipal slaughterhouse" means a slaughterhouse belonging to, or maintained by, the
Municipality ;(59)"Municipality" means an institution of self-government constituted under sectionArunachal Pradesh Municipal Act, 2007

12, read with article 243 Q of the Constitution of India, and includes a Municipal Corporation, a
Municipal Council, and Nagar Panchayat, referred to in section 13;(60)"Notification" means a
notification published in the Official Gazette ;(61)"Nuisance" includes any act, omission, place or
thing which causes, or is likely to cause, injury, danger, annoyance or injurious to health or property
;(62)"Occupier" includes any person for the time being paying or liable to pay, to the owner rent or
any portion of the rent of the land or the building in respect of which the word is used or for
damages on account of the occupation of such land or building, and also includes a rent-free tenant
:Provided that an owner living in, of otherwise using, his own land or building shall be deemed to be
the occupier thereof ;(63)"Offensive matter" means kitchen or stable refuse, dung, dirt, putrid or
putrefying substance, or filth of any kind which is not included in sewage ;(64)"Other agency"
means a company firm, society, or body corporate in the private sector, or any institution, or
government agency, or any joint sector agency, or any agency under any other law for the time being
in force ;(65)"Owner" includes the person for the time being receiving the rent of any land or
building or of any part of any land or building, whether on his own account or as an agent or
charitable purpose or as a receiver who would receive such rent if the land or the building or of any
part of the land or the building were let to a tenant ;(66)"Population" means the population as
ascertained at the last preceding census of which the relevant figures have been published
;(67)"Premises" means any land or building or part of a building or any hut or part of a hut, and
includes -(a)the garden, ground and outhouses, if any, appertaining thereto, and(b)any fittings or
fixtures affixed to a building or part of a building or hut or part of a hut for the more beneficial
enjoyment thereof;(68)"Prescribed" means prescribed by rules made under this Act;(69)"Presiding
officer" means,-(a)in the case of a Municipal Council, the Municipal Chairperson,(b)in the case of a
Nagar Panchayat, the Municipal President;(70)"Private drain" means any drain which is not a
municipal drain;(71)"Private street" means any street, road, lane, gully, alley, passage or square
which is not a public street, and includes any passage securing access to four or more premises
belonging to the same or different owners, but does not include a passage provided in effecting a
partition of any masonry building amongst joint owners where such passage is less than two meters
and fifty centimeters wide ;(72)"Public building" means a masonry building constructed, used, or
adapted to be used,-(a)as a place of public worship or as a school, college or other place of
instruction (not being a dwelling-house so used) or as a hospital, workhouse, public theatre, public
cinema, public hall, public concert-room, public ballroom, public lecture-room, public library or
public exhibition room or as a public place of assembly, or(b)for any other public purpose, or(c)as a
hotel, lodging-house, refuge or shelter, where the building, in cubical extent, exceeds seven
thousand cubic meters or has sleeping accommodation for more than one hundred
person;(73)"Public street" means any street, road, lane, gully, alley, passage, pathway, square or
courtyard, whether a thoroughfare or not, over which the public have a right of way, and includes
:-(a)the access or approach to a public ferry,(b)the roadway over any public bridge or
causeway,(c)the footpath attached to any such street, public bridge or causeway,(d)the passage
connecting two public streets, and(e)the drains attached to any such street, public bridge or
causeway, and, where there is no drain attached to any such street, shall be deemed to include also,
unless the contrary is shown, all land up to the boundary wall, hedge or pillar of the premises, if any,
abutting on the street, or, where a street alignment has been fixed, up to such alignment
;(74)"Regulations" means the regulations made by a Municipality under this Act ;(75)"Rules" means
the Rules made by the State Government under this Act ;(76)"Sewage" means nigh-soil and otherArunachal Pradesh Municipal Act, 2007

contents of privies, urinals, cesspools or drains, and includes trade effluents and discharges from
manufactories of all kinds ;(77)"Smaller urban area" means a municipal area classified as a smaller
urban area under section 7 ;(78)"State Municipal Service Commission" means the State Municipal
Service Commission constituted under section 45 ;(79)"State Municipal Vigilance Authority" means
the State Municipal Vigilance Authority appointed under section 46 ;(80)"Street" means a public
street or a private street ;(81)"Street alignment" means the line dividing the land comprised in, and
forming part of, a street from the adjoining land ;(82)"Subject Committee" means a Subject
Committee constituted under section 32 ;(83)"Ward Committee" means a ward Committee referred
to in section 31;(84)"Wards Committee" means a wards Committee constituted under section 30
;(85)"Water-course" includes a ricer, stream or channel, whether natural or artificial ;(86)"Year"
means a financial year beginning on the first day of April.Chapter- II Constitution of Municipal
Areas and Classification of Municipalities
3. Declaration of Intention to Constitute a Municipal area.
(1)The Governor may, after making such inquiry as he may deem fit, and having regard to the
population of any urban area, the density of population therein, the revenue generated for the local
administration of such area, the percentage of employment in non- agricultural activities in such
area, the economic importance of such area, and such other factors as may be prescribed, by
notification, declare his intention to specify such area to be a larger urban area, or smaller urban
area, or a transitional area :Provided that no such declaration shall be made unless the population
:-(a)in the case of a larger urban area is 75 thousands or more,(b)in the case of a smaller urban area,
is twenty-five thousand or more but is less than 75 thousand, and(c)in the case of a transitional area,
is less than twenty-five thousand :Provided further that the non-agricultural population in all cases
shall be eighty five per cent or more.Explanation. - "revenue generated for the local administration"
shall not include -(a)taxes, if any, distributed to the Municipality by the State Government,(b)loans
and grants from the State Government, and(c)loans and grants from the Central Government or any
institution or other source.(2)The Governor shall, by notification, declare an area specified as-(i)a
larger urban area to be a city,(ii)a smaller area to be a town, and(iii)a transitional area to be a Nagar
Panchayat.(3)Notwithstanding anything contained in sub-section (1), the Governor may, by
notification, determine separate conditions to constitute any hill area, pilgrim centre, tourist centre
of mandi town as a municipal area.
4. Publication of declaration.
(1)The notification about the constitution of a municipal area shall be published in the Official
Gazette and in at least two leading newspapers, at least one of which shall be in vernacular
intelligible to the inhabitants of the local area concerned.(2)A copy of the notification shall also be
pasted in a conspicuous place in the office of the Collector of the district and, where there is a
Municipality, also in the office of the Municipality, and in such other public places as the State
Government may direct.(3)A public proclamation about the constitution of a municipal area shall be
made either by beating of drum throughout the local area concerned or through any other publicity
media.Arunachal Pradesh Municipal Act, 2007

5. Consideration of objection.
- Any inhabitant of the city, town or Nagar Panchayat in respect of which a notification has been
published under section 4 may, if he objects to anything contained in the notification, submit his
objection in writing to the State Government within one month from the date of its publication, and
the State Government shall take such objection into consideration.
6. Constitution of Municipal area.
- On the expiry of one month from the date of publication of the notification and after consideration
of all or any of the objection which may be submitted, the Governor may, by notification, constitute
such city transitional area or any specified part thereof as a municipal area under this Act.
7. Classification of Municipal areas.
- The Governor may, for the purpose of application of the provisions of this Act, classify any
municipal area on the basis of the population as ascertained at the last preceding census of which
the relevant figures have been published, as-(a)a urban area of -Class 'A' municipal area having
population above 75,000 orClass 'B' municipal area having population above 30,000 but not
exceeding 75,000 orClass 'C' municipal area having population above 20,000, but not exceeding
30,000 , and(b)Nagar Panchayat having population not exceeding 20,000 :Provided that for the
purpose of classification of municipal area in any hill area, pilgrim centre, tourist centre of mandi
town, the Governor may, by notification, determine separate size of population for each class of such
municipal areas.
8. Power to abolish or alter limits of Municipal area.
- The Governor may, by notification,-(a)withdraw any municipal area or part thereof from the
operation of this Act, or(b)exclude from a municipal area any local area comprised therein and
defined in the notification,(c)include within a municipal area any local area contiguous to such
municipal area and defined in the notification, or(d)divide any municipal area into two or more
municipal areas, or(e)unite two or more contiguous municipal area so as to constitute one municipal
area, or(f)revise the boundary of two or more contiguous municipal areas:Provide that the
procedure laid down for the constitution of a municipal area under this Act shall be followed
mutates mutants in each such case:Provided further that the views of the Municipality affected by
any such notification shall be invited by the State Government within such time as may be specified
in the notification, and the State Government shall consider the views of the Municipality as
aforesaid before a final declaration is made:Provided also that no such notification shall be issued
where any part of the municipal area or any neighbouring area is a cantonment or part of a
cantonment, as defined in the Cantonments Act, 1924.Arunachal Pradesh Municipal Act, 2007

9. Power to include certain dwelling house, manufactory, etc. within a
particular Municipal area.
- Where a dwelling house, manufactory, warehouse, or place of industry or business is situated
within the limits of two or more adjacent municipal areas, the State Government may,
notwithstanding anything contained elsewhere in this Act, by notification, declare the municipal
within which such dwelling house, manufactory, ware, or place of industry or business be deemed to
be include for the purpose of this Act.
10. Power to exempt Municipal area from operation of any provisions of the
Act unsuited thereto.
(1)The State Government may, by notification, and for reasons to be recorded in writing, except
Class 'C' municipal areas or Nagar Panchayats from the operation of any of the provisions of this Act
considers unsuited thereto, and, thereupon, the said provisions shall not apply to such class 'C'
municipal areas or Nagar Panchayats, as the case may be until such provisions are applied thereto
by notification.(2)While a notification under sub-section (1) remains in force, the State Government
may make rules consistent with the provisions of this Act in respect of any matter within the
purview of such provisions from the operation of which the municipal areas or Nagar Panchayats as
aforesaid are exempted.Chapter-III Municipality and Municipal Councillors
11. The Municipality.
(1)The municipality shall consist of such number of elected Councillors as there are wards within the
municipal area as determined in accordance with the provisions of any law relating to municipal
election in the State.(2)The Municipality shall be a body corporate with perpetual succession and a
common seal, and may, by the name of the Municipality of the city / town or the Nagar Panchayats,
as the case may be, by reference to which the Municipality is known, sue and be sued.(3)All
executive actions of the Empowered Standing Committee shall be expressed to be taken in the name
of the Municipality.(4)Subject to the provisions of this Act, the Municipality shall have the power to
acquire, hold and dispose of properties.
12. Constitution of Municipality.
(1)The Councillors elected in a general election or a by- election of a municipality in accordance with
the provisions of any law relating to municipal elections in the State, shall constitute the
Municipality.(2)The Municipality shall, unless dissolved earlier, continue for a period of five years
from the date of its first meeting after the general election, and(3)No longer an election to constitute
a Municipality shall be completed, as the case may be;(a)before the expiry of the period specified in
sub- section (2), or(b)before the expiry of a period of six months from the date of its
dissolution:Provided that where the remainder of the period for which the dissolved Municipality
would have continued is less than six months, it shall not be necessary to hold an election for
constituting the Municipality for such period.(4)The Municipality constituted upon its dissolutionArunachal Pradesh Municipal Act, 2007

before the expiry of the period specified in sub- section ( 2 ) shall continue only for the remainder of
the period for which the dissolved Municipality would have continued under sub- section (2) had it
not been so dissolved.(5)In a municipal area newly constituted, the local authority having
jurisdiction over such area immediately before such area was constituted a municipal area, shall
continue to have jurisdiction and to perform its functions till such time , not exceeding six months
from the date of the notification under section 6, as may be necessary for holding elections.(6)If, for
any reason, it is not possible to hold the general election of a Municipality before the expiry of the
period of five years specified in sub- section(2), the Municipality shall stand dissolved on the expiry
of the said period, and all the powers and functions vested in the municipal authorities under this
Act or under any other law for the time being in force shall be exercised or performed, as the case
may be, by such person or persons to be designated as Administrator or Board of Administrators as
the State Government may, by notification, appoint.
13. Constitution of Municipality.
- Each Municipality shall consist of such number of Councillors as are specified in the Table
below:-The TableNumber of Councillors
Population Range Minimum Incremental Number Maximum
  Municipal Councils  
Class 'A' Municipal
Councils15One additional Councilor for Municipal Councilevery
5,000 above 75,00025
Class ' B'Municipal
Council10One additional Councilor for every 3,000
above50,00020
Class 'C'Municipal
Council8One additional Councilor for every 2,500
above30,00016
  Nagar Panchayat  
Nagar Panchayat 6  10
14. Election of Councillors.
- Notwithstanding anything contained in this Act, the superintendence, Direction and control of the
preparation of electoral rolls for , and the Conduct of , all elections of Councillors shall be vested in
the State Election Commission constituted under the State Election Commission Act or the State
Municipal Election Act, as the case may be.
15. Oath of allegiance to be taken by Councillors.
(1)Notwithstanding anything contained in the Indian Oaths Act,1873, every person who is elected as
a Councillor shall, before taking his seat, make and subscribe an oath or affirmation of his allegiance
to the Constitution of India before the District Magistrate or the magistrate in-charge of the
sub-division in which the municipal area is situated or an officer of the State Government
authorized in this behalf by the District magistrate.(2)The oath shall be in the following form :-"I, A.Arunachal Pradesh Municipal Act, 2007

B. , having been elected a Councillor of the municipal area of ........., do swear in the name of God/
solemnly affirm that I will bear true faith and allegiance to the Constitution of India as by law
established, and that I will faithfully discharge the duties upon which I am about to enter".(3)Any
person who, having been elected a Councillor, fails to make and subscribe, within three months of
the date on which his term of office commences, the oath or affirmation under sub-section (1), shall
cease to hold his office and his seat shall be deemed to be vacant :Provided that the State
Government may, for reasons to be recorded in writing, extend each case or class of cases the period
of three Period as it thinks fit.
16. Term of office of Councillors of Municipality.
- Subject to the provisions of sub-section (3) or sub-section (4), as the case may be, of section 12, a
Councillor shall hold office for a period of five years from the date of the first meeting of the
Municipality under section 35 or, in the case of a Councillor chosen to fill a casual vacancy, for the
remainder of the term of office of his predecessor, unless -(a)the Municipality is dissolved earlier,
or(b)he resigns his office by notice, in writing, under his hand addressed to Chief Councillor, and,
thereupon, his office shall become vacant from the date of the notice, or(c)his election is void, or is
declared to be void, under the provisions of any law relating to municipal elections in the State,
or(d)the entire area of the ward from which he has been elected is withdrawn from the operation of
this Act under clause(a) of sub-section (1) of section 8.
17. Recall of Concillors.
(1)Every Councillor shall be deemed to have vacated his office forthwith if he is recalled by means of
secret ballot by a majority of the total number of voters of the concerned ward of the municipal area
casting the vote in accordance with such procedure as may be prescribed :Provided that no process
of recalled shall be initiated unless a proposal in this behalf is signed by not less than three-fourth of
the total number of Councillors and presented to the Collector or Chief Municipal Executive Officer/
the Municipal Executive Officer:Provided further that no such process of recall shall be
initiated-(i)within a period of two years from the date on which a Councillor is elected and enters
upon his office, or(ii)if half of the term of office of a Councillor elected in a bye-election has not
expired:Provided also that the process of recall of a Councillor shall be initiated once only during the
term of his office.(2)when a proposal for recall of a Councillor is presented to the Collector under the
first provision to sub-section (1), the Collector/Chief Municipal Executive Officer/the Municipal
Executive Officer shall, after satisfying himself and verifying that not less than three-fourth of the
Councillors have signed the proposal, send the proposal to the State Government shall make a
reference to the State Election Commission.(3)On receipt of the reference under sub-section (2), the
State Election Commission shall arrange for voting on the proposal of recall in such manner as may
be prescribed.
18. Disqualification for being a Councillor if employed in a Municipality.
- No employee of any Municipality shall be eligible to contest an election to become a Councillor of
any Municipality.Arunachal Pradesh Municipal Act, 2007

19. Remuneration and allowances of Councillors.
- The Chief Councillor, the other members of the Empowered Standing Committee, and the other
Councillors may receive such remuneration and allowances as may be prescribed :Provided that
different rates may be prescribed for different classes of Municipalities.Chapter -IV Municipal
Authorities
20. Municipal authorities.
(1)The Municipal Authorities for the purposes of giving effect to the Provisions of this Act shall
be,-(a)in the case of a Class 'A' or Class 'B' or Class 'C' smaller urban area,-(i)The Municipal
Council,(ii)The Empowered Standing Committee,(iii)The Municipal Chairperson, and(iv)The
Municipal Executive Officer;(b)In the case of a Nagar Panchayat,-(i)The Nagar Panchayat,(ii)The
Empowered Standing Committee,(iii)The Municipal President, and(iv)The Municipal Executive
Officer.(2)The presiding officer of the Municipality shall be, in the case of-(a)The Municipal Council,
the Municipal Chairperson, and,(b)The Nagar Panchayat, the Municipal President.
21. Constitution of Empowered Standing Committee of Municipality.
(1)In every Municipality there shall be an Empowered Standing Committee.(2)The Empowered
Standing Committee shall consist of-(a)in the case of a Class 'A' or Class 'B' Municipal Council, the
Municipal Chairperson, the Municipal Vice-Chairperson, and five other Councillors;(b)in the case of
a Class 'C' Municipal Council, the Municipal Vice-Chairperson, and three other Councillors; and(c)in
the case of a Nagar panchayat, the Municipal President, the Municipal Vicepresident, and three
other Councillors.(3)The Municipal Vice Chairman or the Municipal Vice President, as the case may
be, of a Municipal Council or a Nagar Panchayat, shall be elected by the Councilors from among the
Councilors.(4)The other members of the Empowered Standing Committee shall be nominated by the
Chief Councilor from among the Councilors within a period of seven days of his entering
office.(5)The members of the Empowered Standing Committee shall assume charge after taking the
oath of secrecy under section 24.(6)The Chief Councilor shall be the presiding officer of the
Empowered Standing Committee.(7)The manner of transaction of business of the Empowered
Standing Committee shall be such as may be prescribed.(8)The Empowered Standing Committee
shall be collectively responsible to the Municipal Council or the Nagar Panchayat, as the case may
be.
22. Executive power of Municipality to be exercised by Empowered Standing
Committee.
- Subject to the Provisions of this Act and the rules and the regulations made there under, the
executive power of a Municipality shall be exercised by Empowered Standing Committee.Arunachal Pradesh Municipal Act, 2007

23. Election of Chief Councillor.
(1)The Councillors shall, in the first meeting under section 35, elect in accordance with such
procedure as may be prescribed one of the Councillors to be the Chief Councillor, who shall assume
office forthwith after taking the oath of secrecy under section 24.(2)If the Councillors fail to elect a
Chief Councillor under sub-section (1), the State Government shall appoint by name one of the
Councillors to be the Chief Councillor.(3)In the case of any casual vacancy in the office of the Chief
Councillor caused by death, resignation, removal or otherwise, and to fill up the vacancy, the
councilors may elect one of the councillors to be chief councillor as may be prescribed.
24. Oath of secrecy to be taken by Chief Councillor and members of
Empowered Standing Committee.
(1)The Councillor and the members of the Empowered Standing Committee of a Municipality shall
assume office after taking the oath of secrecy in the following form :-"I, A. B. do swear in the name
of God/solemnly affirm that I will not directly or indirectly communicate or reveal to any persons or
persons any matter which shall be brought under my consideration or shall become known to me as
the presiding officer or as member of the Empowered Standing Committee except as may be
required for the due discharge of my duties".(2)The oath of secrecy shall be administered by:-In the
case of a Municipal Council or a Nagar Panchayat, the District Magistrate or the Magistrate
in-charge of the Sub- division in which the municipal area is situated or an officer of the State
Government authorized in this behalf by the District Magistrate.
25. Chief Councillor.
(1)The Chief Councillor shall cease to hold office as such if he ceases to be a Councilor.(2)The Chief
Councillor may, at anytime, by giving a notice, in writing to the Municipality, resign his office, and
the procedure for acceptance or otherwise of the resignation shall be such as may be
prescribed.(3)The Chief Councillor may be removed from office by a resolution carried out by a
majority of the total number of councilors holding office for the time being at a special meeting to be
called for this purpose in the manner as prescribed, upon a requisition made in writing by not less
than one- third of the total number of Councillors, and the procedure for the conduct of business in
the special meeting shall be such as may be prescribed.Provided that no such resolution shall be
moved before the expiry of six months from the date of entering office by the Chief Councillor, and if
such resolution is not carried by a majority of the total number of councillors, no further resolution
for such purpose shall be moved before the expiry of a period of six months from the date on which
the former resolution was moved.
26. Deputy Chief Councillor.
(1)The Deputy Chief Councillor shall, in the absence of the Chief Councillor, preside over the
meetings of the Municipality.(2)When-(a)The office of the Chief Councillor falls vacant by reason of
death, resignation, removal or otherwise, or(b)The Chief Councillor is, by reason of reason of leave,Arunachal Pradesh Municipal Act, 2007

illness or other cause, temporarily unable to exercise the powers, perform the functions, or
discharge the duties, of his office,The Deputy Chief Councillor shall exercise the powers, perform the
functions, and discharge the duties, of the Chief Councillor until a Chief Councillor is elected under
sub- section (3) of section 23 and enters office or until the Chief Councillor resumes his
duties.(3)The Deputy Chief Councillor shall, at any time, exercise such other powers, perform such
other functions, and discharge such other duties, as may be delegated to him under the provisions of
this Act.
27. Term of office of Chief Councillor and members of Empowered Standing
Committee.
- The term of office of the Chief Councillor and the members of the Empowered Standing Committee
shall be conterminous with the duration of the Municipality.
28. Delegation of powers and functions.
(1)The Municipality may, by resolution, delegate, subject to such conditions as may be specified in
the resolution, any of its powers or functions to the Empowered Standing Committee.(2)The
Empowered Standing Committee may, by order in writing delegate, subject to such conditions as
may be specified in the order, any of its powers or functions to the Chief Councillor or to the Chief
Municipal Executive Officer/ Municipal Executive Officer.(3)Subject to such standing orders as may
be made by the Empowered Standing Committee in this behalf,-(a)the Chief Councillor may, by
order, delegate, subject to such conditions as may be specified in the order, any of his powers or
functions to the Deputy Chief Councillor or the Chief Municipal Executive Officer/ Municipal
Executive Officer.(b)the Chief Municipal Executive Officer/ Municipal Executive Officer, may, by
order, subject to such conditions as may be specified in the order, any of his powers or functions,
excluding the powers or functions under sub- section (2) of section 354 or section 365, to any officer
or other employee of the Municipality; and(c)any officer of the Municipality, other than the Chief
Municipal Executive Officer/ Municipal Executive Officer, may, by order, delegate, subject to such
conditions as may be specified in the order, any of his powers or functions to any other officer
subordinate to him.(4)Notwithstanding anything contained in this section, the Empowered
Standing Committee, the Councillor, the Municipal Officer, or the other officer referred to in clause
(c) of sub-section (3), shall not delegate-(a)any of its or his powers or functions delegated to it or
him under this section, or(b)such of its or his powers or functions as may be specified by
regulations.
29. Reservation of Office of Chief Councillor.
- The office of the Chief Councillor in the Municipality shall be reserved for Scheduled Tribes, and
women to such extent, and in such manner, as may be prescribed.Arunachal Pradesh Municipal Act, 2007

30. Wards Committee.
(1)Every Municipal Council, at its first meeting after the election of Councillors thereto or as soon as
may be thereafter, group the wards of the Council in such manner that each group consists of not
less than three contiguous wards, and constitute a wards committee for each such group.(2)Each
wards committee shall consist of the councillors elected from the wards constituting the group.(3)A
councillor of the wards committee representing a constituent ward shall hold office till he ceases to
be the councillor representing such ward.(4)The councillors of each wards committee shall elect
from amongst themselves one councillor, who shall not be a member of the empowered standing
committee, to be its Chairperson.(5)The Chairperson of a wards committee may, at any time, resign
his office by giving notice in writing to the Chairman and the resignation shall take effect from the
date of acceptance by the Chairman.(6)A wards committee shall, subject to the general supervision
and control of the Empowered Standing Committee, discharge, within the local limits of the group
of wards, the functions of the Municipality relating to the provision of supply-pipes and drainage
and sewerage connections to premises, removal of accumulated water on the streets or public places
due to rain or otherwise, collection and removal of solid wastes, disinfection, provision of health
immunization services and slum services, provision of lighting, repair of category IV and category V
roads, maintenance of parks, drains and gullies, issue of license under sub-section (1) of section 369,
and such other functions as the Municipality may, from time to time, determine by
regulations.(7)The Empowered Standing Committee shall assign to a wards committee such number
of officers and other employees as it deems fit and shall designate one of such officers as the wards
officer of such wards committee.(8)The manner of transaction of business of the wards committee
shall be such as may be determined by regulations.(9)Subject to such conditions, if any, as may be
specified by regulations, a wards committee may conduct public hearing on any major issue of
public interest.
31. Ward Committee.
(1)Each ward of a Municipality shall have a ward committee.(2)The Councillor elected from a ward
shall be the chairperson of the ward committee for that ward.(3)The ward committee may include
not more than ten persons representing the civil society from the ward, nominated by the
Municipality.Provided that if the population of the ward is not more than ten thousand, the number
of other members shall be four, and, thereafter, there shall be one additional member for every four
thousand population or part thereof.Provided further that in reckoning the number of additional
members of the ward committee exceeding four, any part of less than two thousand population may
be ignored.Explanation. - For the purposes of this section, "civil society" shall mean any non
government organization or association or person, established, constituted or registered under any
law for the time being in force and working for social welfare, and shall include
any-community-based organization, professional institution and civic, health, educational, social or
cultural body, and such other association or body as the Municipality may decide.(4)The ward
committee shall perform such functions, and in such manner, as may be specified by
regulations.Note. - The provision of the section -30 &31 shall be subject to approval of the State
Government .Arunachal Pradesh Municipal Act, 2007

32. Subject Committee.
(1)A Class 'A' Municipal council may, from time to time, constitute Subject Committees consisting of
Councillors to deal with the following matters, namely:-(a)water- supply, drainage and sewerage,
and solid waste management;(b)urban environment management and land use control; and(c)slum
services.(2)The members of the Empowered Standing Committee and Chairperson, Municipal
council, as Nagar Panchayat as the case may be, shall not be members of any subject
Committee.(3)Each Subject Committee shall consist of -(a)five members in the case of a subject
Committee of a Class 'A' Municipal Council.(b)3 members in case of Nagar Panchayat.(4)The
manner of the constitution and the transaction of business of a subject Committee shall be such as
may be specified by regulations,(5)The term of a Subject Committee shall be not less than two
years,(6)The Chairperson of a Subject Committee shall be elected by its members from amongst
themselves in the manner specified by regulations:Provided that a member shall not be eligible for
election as Chairperson for more than two terms.(7)Each Subject Committee shall exercise such
powers, and perform such functions, as may be specified by regulations.(8)The recommendations of
a Subject Committee shall be submitted to the Empowered Standing Committee for its
consideration.
33. Ad hoc Committee.
(1)The Empowered Standing Committee may, from time to time, appoint an Ad hoc Committee to
perform such functions, or conduct such enquiries, or undertake such studies including reports
thereon, as may be specified by a resolution in this behalf.(2)Any person, who is not a Councillor but
possesses special qualifications useful for the purpose of an Ad hoc Committee, may be associated
therewith as its member.(3)The manner of transaction of business in an Ad hoc Committee shall be
such as may be laid down by the Empowered Standing Committee.
34. Joint Committee.
(1)The State government may, if it considers it necessary so to do, constitute a Joint committee for
more than one Municipality, or for one or more Municipalities with other local authority or local
authorities, for any purpose in which they are jointly interested or for delegating to it any power or
function which calls for joint action.(2)The Joint Committee shall consist of the following
members:-(i)two elected members of each constituent Municipality or local authority,(ii)one
nominee of each of the concerned departments of the state Government or of the concerned
statutory authorities under the State government,(iii)such expert or experts as the State government
may nominate, and(iv)the Director of Local Bodies or his representative who shall act as the
convener of the Joint Committee.(3)The procedure of transaction of business by a Joint committee
shall be such as may be prescribed.
35. First meeting of Municipality.
(1)The first meeting of a Municipality after the general election of Councillors to the MunicipalityArunachal Pradesh Municipal Act, 2007

shall be convened within thirty days from the date of publication of the names of elected Councillors
in the Official gazette under the provisions of any law relating to municipal elections in the
State.(2)seven days' notice shall be given for the meeting.(3)In the case of a Municipal Council or a
Nagar Panchayat, the meeting shall be convened by the District Magistrate or any other Executive
Magistrate authorized by the District Magistrate in this behalf.Chapter-V Organizational Structure
of MunicipalityA. Statutory Officers of Municipality
36. Officers of Municipality.
(1)Subject to the provisions of section-41, and having regard to the need for ensuring maximum
possible economy in Municipal administration, the Municipality may, besides appointing a
Municipal Executive Officer in the case of a Municipal Council or a Nagar Panchayat, appoint
officers to deal with all or any of the functions relating to finance, engineering, health, secretariat,
law and internal audit, as the Empowered Standing Committee may, from time to time,
determine.Note. - In order to ensure minimum financial involvement in recruiting Municipal Officer
initially, the under mentioned officers / officials shall be entrusted / deputed with the functions as
under namely: -(i)[ The Deputy Commissioner, Capital Complex shall function as Chief Municipal
Executive Officer of Municipal in Capital Region and in Districts the Deputy Commissioner or his
representative of respective towns where Municipalities is constituted shall be the Executive Officer
of that Municipality;] [Substituted by Arunachal Pradesh Act No. 15 of 2010, dated
28.10.2010.](ii)The relevant technical manpower such as Architects, Civil engineers and Town
planners and non-technical manpower from the Department of Urban development & Housing and
Town Planning shall be posted to the Municipalities on deputation basis, till the Municipalities
generates enough resources to create and sustain its own establishment and
manpower.(2)Appointments of officers mentioned in sub-section (1) may be made either on a
regular basis or on a contract basis for such term as the Empowered Standing Committee may
consider necessary.(3)At the requests of the Empowered Standing Committees of more than one
Municipality, the state Government may, by order, provide for sharing of services of officers referred
to in sub-section(1) by such Municipalities, and on such terms and conditions, as may be specified in
the order.(4)Subject to the provisions of sub-section (2), appointments of officers referred to in
sub-section (1) for different posts as may be specified by regulations shall be made-(a)by the State
Government in consultation Chief Municipal Executive Officer with the Empowered Standing
Committee and Chief Municipal Executive Officer/ Municipal Executive Officer by notification from
amongst the persons who are or have been in the service of that Government, or(b)by the
Empowered Standing Committee with the prior approval of the State Government and in
consultation with the State Public Service Commission:Provided that the appointments to the posts
as aforesaid shall be on such terms and conditions, and for such period not exceeding five years in
the first instance, as the State Government may determine:Provided further that the State
Government may , in consultation with the Empowered Standing Committee, extend the period of
appointment of posts as aforesaid from time to time, so ,however the total period of extension shall
not exceed five years.(5)Until cadres of common municipal services for the State are constituted
under subsection (1) of section 43, the Empowered Standing Committee may determine which of the
posts of officers referred to in sub-section (1) of this section are necessary for a Municipal Council or
a Nagar Panchayat, and, with the prior approval of the State Government, create posts or, andArunachal Pradesh Municipal Act, 2007

appoint, such officers and fix the salaries and allowances to be paid to such officers.(6)The method
of, and the qualifications required for, recruitment, and the terms and conditions of service
including conduct, discipline and control, of officers appointed by the Empowered Standing
Committee shall be such as may be prescribed.(7)Notwithstanding anything contained in the
foregoing provisions of this section, the State Government may, at any time, in the case of any
person appointed to any post referred to in sub-section (1), terminate his appointment:Provided
that if, in the case of any such officer, the Empowered Standing Committee so decides, the State
Government shall terminate the appointment of such officer.(8)Notwithstanding anything
contained in sub-section (2) or sub-section (3), prior approval of the State Government shall be
necessary in the case of appointment of a person not recommended by the State Public Service
Commission.(9)No person above the age of sixty years shall be appointed to any post in a
municipality.B. Municipal Establishment and Schedule of Posts.
37. Establishment of Municipal and Schedule of posts.
(1)The posts of officers and other employees of the Municipality, other than those referred to in
sub-section (1) of section 36, shall constitute the municipal establishment.(2)The Municipality shall,
by regulation , classify the posts of officers and other employees constituting the establishment of
the Municipality into four categories, namely, category 'A' post, category 'B' post, category 'C' post,
and category 'D' post, on the basis of the scales of pay of such posts.(3)The Municipality shall
prepare, and maintain, a Schedule of posts of officers and other employees constituting the
establishment of the Municipality, to be called Establishment Schedule, and such Establishment
Schedule shall include the designation, and the number of posts under each designation, and shall
be in three parts of which part I shall include category 'A' posts, Part II shall include category 'B'
Posts, and Part III shall include category 'C' posts and category 'D' posts.(4)Every year the Chief
Municipal Executive Officer/ Municipal Executive Officer shall place before the Empowered
Standing Committee for its consideration the Establishment Schedule along with the proposals for
such changes therein as he may consider necessary:Provided that no upward revision of the sizes of
the establishment of the Municipality shall be made without the prior sanction of the State
Government.(5)The Empowered Standing Committee shall, after consideration of the
Establishment Schedule along with the proposals, if any, for changes therein, place the same along
with its recommendations, if any, before the Municipality for approval prior to the presentation of
the budget estimates to the Municipality by the Chief Councillor.(6)The Chief Municipal Executive
Officer/ Municipal Executive Officer shall revise the Establishment Schedule as approved by the
Municipality.(7)The Empowered Standing Committee may sanction any category 'C' post or category
'D' post for a period not exceeding six months:Provided that no such post shall be sanctioned unless
there is a provision in this behalf in the budget estimates of the Municipality.(8)Subject to such
norms regulating to the size of a municipal establishment as may be fixed by the State Government
from time to time, no post of an officer or other employees of the Municipality shall be created by
the Municipality without the prior sanction of the State Government, if the number of posts to be so
created in a year for a Municipality is more than one per cent of the total number of sanctioned
posts of officers and other employees in existence in the year immediately preceding.Provided that
the number of posts as may be admissible for creation in a year without the prior sanction of the
State Government after the commencement of this Act, if not created in that year, may be carriedArunachal Pradesh Municipal Act, 2007

forward to the next year, subject to a maximum of ten.(9)The recruitment to the posts of officers and
other employees of the Municipality not required to be made through the Municipal Service
Commission shall be made through the local employment exchange or through such other method
as the State Government may determine from time to time.(10)Notwithstanding anything contained
in the foregoing provisions of this section or elsewhere in this Act, the Empowered Standing
Committee may decide to engage on contract basis, officers and other employees of the Municipality
against such posts of officers and other employees referred to in sub-section (1) of section 37.
38. Appointing Authorities.
- Subject to the other provisions of this Act, the appointing authority in respect of the posts of
officers and other employees constituting the establishment of the Municipality shall be, -(a)the
Chief Municipal Executive Officer in Municipality of Capital Region and Municipal Executive
Officers in other Municipalities.Provided that-
1. Except Group -'C' and 'D' Posts, no other posts shall be recruited directly
within first Five years of commencing of Municipality.
2. Except Group -'C' 'D' & 'B' Posts, no Group-'A' posts shall be recruited
directly within first ten years of commencing of Municipality .
Explanations. - In the initial years of introduction of Municipality ,recruitment of all the posts
directly will create huge financial involvement to the state exchequer. Therefore, in order to
minimize the financial involvement and to ensure experienced hand in the administration of
Municipality, the officers and staff of relevant department such as Deptt. of UD & Housing, Town
Planning, Health Department, Law Department etc. shall be utilized, till such time the
Municipalities generates enough resources to sustain its own establishment.
39. Salaries and Allowances of officers and other employees.
(1)All officers and other employees of a Municipality including the officers referred to in section -36
shall receive salaries and allowances out of the Municipal Fund:Provided that the State Government
may make such contribution toward the salaries and allowances as aforesaid as it may, from time to
time, determine.(2)The Municipality may also provide for pension, gratuity, provident fund,
incentive, bonus, reward or penalty for its officers and other employees in accordance with such
rules, norms, scales and conditions as may be prescribed.
40. Leave and other Conditions of service.
- All officers and other employees of the Municipality shall be subject to such conditions of service
including leave and other benefits or obligations, not specifically provided for in this Act, as may be
prescribed.Arunachal Pradesh Municipal Act, 2007

41. Appointment of Officers of State Government for Municipalities.
- Notwithstanding anything contained elsewhere in this Act, the State Government may appoint
officers from Department of Urban development and Housing, Department of Health Services and
Directorate of Accounts, Govt. of Arunachal Pradesh, possessing such qualifications as may be
determined by it for a Municipal Council or class of Municipal Councils or a Nagar Panchayat as
Municipal Executive Officer, Municipal Finance Officer, Municipal Architect / Engineer/ Town
Planner or Municipal Health Officer referred to in sub-section (1) of section -36 or with such
designation as the State Government may consider necessary, and in such manner, and on such
terms and conditions of service, as may be determined by the State Government in this behalf. The
expenditure on account of salaries and allowances of any such officer shall be borne by the State
Government:Provided that the officer so appointed shall be under the administrative control of the
Empowered Standing Committee and matters to that effect may be passed by the Councillors at a
meeting called for this purpose by a majority of the total number of Councillors holding office for the
time being.C. Municipal Establishment Audit Commission
42. Municipal Establishment Audit Commission.
- For the purpose of review of the existing establishment of the Municipalities in the State, and for
fixing norms and standards of manpower for different tasks performed at various levels of
Municipalities, and for performance of similar other functions, the State Government may
constitute a Municipal Establishment Audit Commission in such manner and consisting of a
chairperson and such other members, and on such terms and conditions, as may be prescribed.D.
Municipal Services Cadres
43. Cadres of Common Municipal Services, Appointments, etc.
(1)The State Government may constitute cadres of common municipal services for the State in
respect of such officers of the Municipality referred to in sub-section (1) of section-36 as may be
determined by that Government from time to time.(2)The Director of Local Bodies shall be the
appointing authority of all officers borne in the cadres of common municipal services and shall be
the authority to transfer such officers from one Municipality to another.E. Municipal Service
Commission
44. Municipal Service Commission for Municipality.
- Every Municipality may, and, if so directed by the State Government, shall, for the purpose of
selection of its officers and other employees, constitute a Municipal service Commission in such
manner, and consisting of a Chairperson and such other members, and on such terms and
conditions, as may be prescribed.Arunachal Pradesh Municipal Act, 2007

45. State Municipal Service Commission.
- The State Government may, for selection of such officers and other employees of a Municipality as
may be prescribed, constitute-(a)a State Municipal Service Commission, and in such manner,
consisting of a Chairperson and such other members, and on such terms and conditions, as may be
prescribed.F. State Municipal Vigilance Authority
46. State Municipal Vigilance Authority.
(1)The State Government may, by notification, appoint a State Municipal Vigilance Authority in such
manner, consisting of a Chairperson and such other members, and on such terms and conditions, as
may be prescribed, for inquiring into any complaint of corruption, misconduct, lack of integrity or
any other kind of malpractice or misdemeanor on the part of any officer or other employee of a
Municipality and for making recommendation to the Empowered Standing Committee.(2)No
Councilor and no officer or other employee of any Municipality shall be the State Municipal
Vigilance Authority.Chapter-VI Functional Domain of Municipalities
47. Core Municipal Functions.
- Every Municipality shall-(1)(a)provide on its own or arrange to provide through any agency the
following core municipal services:-(i)water-supply for domestic, industrial, and commercial
purposes,(ii)drainage and sewerage,(iii)solid waste management,(iv)preparation of plans for
economic development and social justice,(v)communication systems including construction and
maintenance of roads, footpaths, pedestrian pathways, transportation terminals, both for
passengers and goods, bridges, over-bridges, subways, ferries, and inland water transport
system,(vi)transport system accessories including traffic engineering schemes, street lighting,
parking areas, and bus stops,(vii)community health and protection of environment including
planting and caring of trees on road sides and elsewhere,(viii)markets and
slaughterhouses,(ix)promotion of educational, sports and cultural activities, and(x)aesthetic
environment, and(b)perform such other statutory or regulatory functions as may be provided by or
under this Act or under any other law for the time being in force.(2)The Municipality may, having,
regard to its managerial, technical, financial and organizational capacity, and the actual conditions
obtaining in the municipal area, decide not to take up, or postpone, the performance of , any of the
functions as aforesaid.(3)The State Government may direct a Municipality to perform any of the
functions as aforesaid, if such function is not taken up, or is postponed, by the Municipality.(4)The
Municipality may plan, build, operate, maintain or manage the infrastructure required for the
discharge of any of the functions, as aforesaid, either by itself or by any agency under any concession
agreement referred to in section 167.
48. Functions Assigned by Government.
- The Municipality may, subject to the underwriting of the costs by, and approval of, the Central
Government or the State Government, as the case may be, undertake any function belonging to theArunachal Pradesh Municipal Act, 2007

functional domain, and such functions may include primary education, curative health, transport,
and supply of energy, arrangements for fire prevention and fire safety, and urban poverty
alleviation.
49. Other Functions.
- The Municipality may, having regard to the satisfactory performance of its core functions which
shall constitute the first charge on the Municipal Fund, and subject to its managerial, technical and
financial capabilities, undertake or perform, or promote the performance of, any of the following
functions:-(1)in the sphere of town planning, urban development and development of commercial
infrastructure,-(a)planned development of new areas for human settlement,(b)measures for
beautification of the municipal area by setting up parks and fountains, providing recreational areas,
improving river banks, and landscaping,(c)collection of statistics and data, significant to the
community, and(d)integration of the development plans and schemes of the municipal area with the
district or regional development plan, if any;(2)in the sphere of protection of
environment,-(a)reclamation of waste lands, promotion of social forestry and maintenance of open
spaces.(b)establishment and maintenance of nurseries for plants, vegetables and tress and
promotion of greenery through mass participation,(c)organization of flower-shows and promotion
of flower-growing as a civic culture, and(d)promotion of measures for abatement of all forms of
pollution;(3)in the sphere of public health and sanitation,-(a)mass inoculation campaigns for
eradication of infectious diseases,(b)construction and maintenance of municipal markets and
slaughterhouses and regulation of all markets and slaughterhouses,(c)reclamation of unhealthy
localities, removal of noxious vegetation and abatement of all nuisances,(d)maintenance of all public
tanks and regulating the re-excavation, repair and upkeep of all private tanks, wells and other
sources of water- supply on such terms and conditions as the Municipality may deem
proper,(e)construction and maintenance of cattle pounds,(f)provision for unfiltered water-supply
for non- domestic uses,(g)advancement of civic consciousness of public health and general welfare
by organizing discourses, seminars and conferences, and(h)measures for eradication of addiction of
all kinds including addiction to drugs and liquor;(4)in the sphere of education and
culture,-(a)promotion of civic education, adult education, social education and non-formal
education,(b)promotion of cultural activities including music, physical education, sports and
theatres and infrastructure there for,(c)advancement of science and technology in urban
life,(d)publication of municipal journals, periodicals and souvenirs, purchase of books and
subscription to journals, magazines and newspapers,(e)installation of statues, portraits and pictures
in appropriate manner,(f)organization, establishment and maintenance of art galleries and
botanical or zoological collections ,and(g)maintenance of monuments and places of historical,
artistic and other importance;(5)in the sphere of public welfare,-(a)establishment and maintenance
of shelters, in times of drought, flood, earthquake, or other natural or technological disasters, and
relief works, for, destitute persons within the limits of the municipal area,(b)construction or
maintenance of, or provision of aids to , hospitals, dispensaries, asylums, rescue homes, maternity
houses, and child welfare centers,(c)provision of shelter for the homeless,(d)implementation
programmes for liberation and rehabilitation of scavengers and their families,(e)organization of
voluntary labour and co-ordination of activities of voluntary agencies for community welfare,
and(f)campaigns for dissemination of such information as is vital for public welfare; and(6)in theArunachal Pradesh Municipal Act, 2007

sphere of community relations,-(a)civic receptions to persons of distinction and paying homage on
death to persons of repute,(b)organization and management of fairs and exhibitions,
and(c)dissemination of information of public interest.Chapter-VII Conduct of BusinessA.
transaction of Business of Municipality
50. Meetings.
(1)The Municipality shall meet not less than once in every month for the transaction of its
business.(2)The Chief Councillor may, whenever he thinks fit, and shall, upon a requisition in
writing by not less than one- fifth of the Councillor, convene a meeting of the Municipality.
51. Notice of Meeting and List of business.
- A list of business to be transacted at every meeting of the Municipality, except at an adjourned
meeting, shall be sent to the registered address of each councillor at least seventy-two hours before
the time fixed for such meeting, and no business shall be brought before, or transacted at, any
meeting other than the business of which notice has been so given:Provided that any emergent
business may be brought before, and transacted in, the meeting with the permission of the Chief
Councillor:Provided further that any Councillor may send or deliver to the Municipal Secretary
notice of any resolution so as to reach him at least forty-eight hours before the time fixed for the
meeting, and the Municipal Secretary shall, with all possible dispatch, take steps to circulate such
resolution to every Councillor in such manner as he may thinks fit:Provided also that no business,
which has no relevance to the business of the Municipality, shall be brought before the
Municipality.Explanation. - For the purposes of this section, " registered address" shall be the
address for the time being entered in the register of addresses of Councillors to be maintained by the
Municipal Secretary.
52. Quorum for Transaction of Business at a Meeting of Municipality and
methods of deciding questions.
(1)The quorum necessary for the transaction of business at a meeting of the Municipality shall be
one-fifth of the total number of Councillors.(2)If at any during a meeting of the Municipality there is
no quorum, it shall be the duty of the person presiding over such meeting either to adjourn the
meeting or to suspend the meeting until there is a quorum.(3)Where a meeting has been adjourned
under sub-section (2), the business which would have been brought before such meeting shall be
brought before, and may be transacted at, the adjourned meeting.(4)All matters required to be
decided at a meeting of the Municipality shall, save as otherwise provided in this Act, be determined
by a majority of votes of the Councillors present and voting.(5)The voting shall be by show of hands,
provided that the Municipality may, subject to such regulations as may be made by it, resolve that
any question, or class of questions, shall be decided by secret ballot.(6)At any meeting of the
Municipality, where a poll is taken on a resolution before it, the votes of all the Councillors present
who officer of such meeting, who shall declare such resolution to have been carried or lost, as the
case may be, in accordance with the result of such poll.(7)At any meeting of the Municipality, unlessArunachal Pradesh Municipal Act, 2007

a poll is demanded by at least one-tenth of the councillors present, a declaration by the presiding
officer of such meeting that a resolution has been carried or lost in such meeting, and an entry to
that effect in the minutes of the proceeding of such meeting shall, for the purposes of this Act, be
conclusive evidence of the fact that such resolution has been carried or lost, as the case may be.
53. Presiding Officer of a meeting of Municipality.
(1)The Chief Councillor shall preside at every meeting of the Municipality:Provided that when a
meeting is held to consider a motion for the removal of the Chief Councillor, the Chief Councillor
shall not preside at such meeting.(2)The Chief Councillor, or the person presiding over a meeting of
the Municipality, shall also have, and may exercise, a casting vote in all cases of equality of votes.
54. Maintenance of order at a meeting of Municipality and withdrawal and
suspension of Councillors.
(1)The presiding officer of a meeting of the Municipality shall preserve order there at and shall have
all the powers necessary for the purpose of preserving such order.(2)The presiding officer of a
meeting may direct any Councillor, whose conduct is, in his opinion, grossly disorderly, to withdraw
immediately from the meeting, and every councillor so directed shall do so forthwith and shall
absent himself during the remainder of the meeting.(3)If any councillor is ordered to withdraw for a
second time, the presiding officer may warn such Councillor of the action that may be taken under
this sub-section and may thereafter, if necessary, suspend such Councillor from attending the
meetings of the Municipality for any period not exceeding sixty days, and the Councillor so
suspended shall absent himself accordingly:Provided that the Chief Councillor may at any time
decide that such suspension be terminated:Provided further that a Councillor shall not, so long as he
is debarred from attending any meeting of the Municipality, attend any meeting of any committee of
Municipality.(4)In the case of grave disorder arising in a meeting, the presiding officer may, if he
thinks necessary so to do, adjourn the meeting to a date specified by him.
55. Councillor having pecuniary Interest in any contract etc. with
Municipality.
(1)If a Councillor has any pecuniary interest, direct or indirect, in any contract or proposed contract
with or without employment under, or other matter concerning the Municipality and is present at a
such contract or of a committee thereof at which consideration, he shall, as soon as practicable after
the contract or employment or other matter, and shall not take part in the consideration or
discussion of, or vote on, any question with respect to such contract or employment or other
matter:Provided that the provisions of this section shall not apply to a Councillor having interest as
a tax-payer or inhabitant of the municipal area or consumer of water or having an interest any
matter relating to any civic service to the public.(2)For the purposes of this section, a Councillor
shall be deemed to have an indirect pecuniary interest in a contract or employment or other matter,
if he or his nominee is a member of any company or other body with which the contract is made or is
proposed to be made or which has a direct pecuniary interest in the employment or other matterArunachal Pradesh Municipal Act, 2007

under consideration, or if he is a partner in a firm with which , or is in employment under a person
with whom, the contract is made or is proposed to be made, or if such firm or person has a direct
pecuniary interest in the employment or other matter under consideration:Provided that:(i)the
provisions of this sub-section shall not apply to a councillor who is a member of , or is in
employment under, any public institution or organization under any law for the time being in force,
and(ii)a Councillor shall not, by reason of his membership of a company or other body, be treated as
having any pecuniary interest in such company or other body if he has no beneficial interest in any
share or stock of such company or other body.(3)In the case of a Councillor who is married and lives
with his spouse, the interest of one shall be deemed, for the purposes of this section, to be the
interest of the other.Explanation. -For the purposes of this section and section -56, " company" shall
mean any body corporate, and shall include a firm or other association of individuals.
56. Disclosure of Pecuniary Interest.
(1)A Councillor may give to the Municipal secretary a notice to the effect that he or his spouse is a
member of a company or is a partner in a firm or is in the employment under a person, and if any
contract is made or is proposed to be made with such company or firm or person, such notice shall,
unless and until it is withdrawn, be deemed to be a sufficient disclosure of his interest in such
contract or proposed contract which may be the subject of consideration at a meeting of the
Municipality after the date of the notice.(2)The Municipal Secretary shall record in a book, to be
kept for the purpose, particulars of any disclosure made under sub-section (1) of section-55 and of
any notice given under sub- section (1) of this section, and the book shall be open at all reasonable
hours for the inspection of any Councillor.
57. Meeting to be ordinarily open to public.
(1)Every meeting of the Municipality shall be open to the public, unless a majority of the Councillors
present at the meeting decides by a resolution, which shall be put by the presiding officer either on
his own motion or at the request of any such Councillor, that any enquiry or deliberation pending
before the Municipality shall be held in private.(2)The Municipality may make regulations providing
for the admission of strangers to its meeting and for the removal by force, if necessary, of any
stranger for interrupting or disturbing the proceedings of the meeting.
58. Right of the Chief Municipal Executive Officer and Municipal Executive
Officer and other officers to attend meeting of Municipality and committees
etc.
- The Chief Municipal Executive Officer/ Municipal Executive Officer, or any other officer of the
Municipality authorized by him in writing in this behalf, may attend any meeting of the Municipality
or of any of its committees.Arunachal Pradesh Municipal Act, 2007

59. Right of Councillor to ask questions.
(1)A Councillor may, subject to provisions of sub-section (2), ask the Empowered Standing
Committee questions on any matter relating to the administration of the Municipality or municipal
governance, and all such questions shall be addressed to the Empowered standing Committee and
shall be answered either by the Chief Councillor or by any other member of the Empowered
Standing Committee.(2)The right to ask a question shall be governed by the following conditions,
namely:-(a)not less than seven working days' notice, in writing, specifying the question shall be
given to the Municipal Secretary;(b)no question shall-(i)bring in any name or statement not strictly
necessary to make the question intelligible,(ii)contain arguments, ironical expressions, imputations,
epithets or defamatory statements,(iii)ask for an expression of opinion or the solution of a
hypothetical proposition,(iv)ask as to the character or conduct of any person except in his official or
public capacity,(v)relate to a matter which is not primarily the concern of the Municipality,(vi)make
or imply a charge of a personal character,(vii)raise questions of policy too large to be dealt with
within the limits of an answer to a question,(viii)repeat in substance questions already answered or
to which an answer has been refused,(ix)ask for information on trivial matters,(x)ask for
information on matters of past history,(xi)ask for information set forth in accessible documents or
in ordinary works of reference,(xii)raise matters under the control of bodies or persons not
primarily responsible to the Municipality, or(xiii)ask for any information on any matter which is
under adjudication by a court of law.(3)The presiding officer shall disallow any question, which is, in
his opinion, in contravention of the provisions of sub-section (2).(4)If any doubt arises whether any
question is or is not in contravention of the provisions of sub-section (2), the matter shall be decided
by the presiding officer, whose decision shall be final.(5)The Chief Councillor or any member of the
Empowered Standing Committee shall not be bound to answer a question seeking information
which has been communicated to him or to the Empowered Standing Committee in confidence or if,
in his opinion, it cannot be answered without prejudice to the public interest.(6)Unless otherwise
directed by the presiding officer of the meeting every question shall be answered at a meeting of the
Municipality.
60. Discussion on Urgent public Matters.
(1)Any Councillor may give notice of raising discussion on a matter of urgent public importance to
the Municipal secretary, stating clearly the matter to be raised.(2)Such notice, supported by the
signatures of at least two other Councillors, shall reach the Municipal Secretary at least forty-eight
hours before the date on which such discussion is sought, and the Municipal secretary shall
immediately place it before the Chief Councillor and circulate the notice among the Councillors in
such manner as he may thinks fit.(3)the Chief Councillor may admit for discussion such notice as
may appear to him to be of sufficient public importance and allow such time for discussion as he
may consider appropriate.(4)There shall be no formal resolution or voting on such discussion .
61. Asking for Statement from Empowered Standing Committee.
(1)Any Councillor may ask for a statement from the Empowered Standing Committee on an urgent
matter relating to the administration of the Municipality by giving notice to the Municipal SecretaryArunachal Pradesh Municipal Act, 2007

at least one hour before the commencement of the meeting of the Municipality on any day.(2)The
Chief Councillor or a member of the Empowered Standing committee may either make a brief
statement on the same day or fix a date for making such statement.(3)Not more than two such
matters shall be raised at the same meeting and, in the event of more than two matters being raised,
priority shall be given to the maters which are, in the opinion of the Chief Councillor, more urgent
and important.(4)There shall be no debate on such statement at the time it is made.B. Minutes and
Proceedings.
62. Keeping of Minutes and Proceedings.
- Minutes of each meeting of the Municipality and of a committee of the Municipality recording
therein the names of the Councillors present at such meeting and the proceedings of each such
meeting shall be laid before the next meeting of the Municipality or such committee, as the case may
be, and signed at such meeting by the presiding officer thereof.
63. Circulation and Inspection of Minutes.
- Minutes of the proceedings of each meeting of the Municipality shall be circulated to all the
Councillors and shall, at all reasonable times, be available at the office of the Municipality for
inspection by any councillor, free of cost, and by any other person on payment of such fee as the
Municipality may determine.
64. Forwarding of Minutes to State Government.
(1)The Municipal Secretary shall forward to the State Government a copy of the minutes of the
proceedings of each meeting of the Municipality or a committee of the Municipality as early as
possible.(2)The State Government may, in any case, call for a copy or copies of all or any of the
papers laid before the Municipality or any committee of the Municipality and, thereupon, the
municipal Secretary shall forward to the State Government a copy or copies of such paper or papers.
65. Rules relating to conduct of business of Municipality.
- The State Government may, by rules, provide for such matters, not provided in this Act, relating to
the conduct of business of the Municipality or of its committees, as it may deem necessary.C.
Validation
66. Validation of acts and proceedings.
(1)No act or proceeding of the Municipality or of any committee of the Municipality shall be called in
question merely on the ground of-(a)the existence of any vacancy in, or any defect, initial or
subsequent, in the constitution of , the Municipality or any committee of the Municipality, or(b)any
councillor having voted or taken part in any proceeding in contravention of the provisions of section
55, or(c)any defect or irregularity not affecting the merit of any case to which such defect orArunachal Pradesh Municipal Act, 2007

irregularity relates,(2)Every meeting of the Municipality or any committee of the Municipality, the
minutes of the proceeding of which have been duly signed under section -62, shall be deemed to
have been duly convened and be free from any defect or irregularity.
Chapter VIII
Direction and control
67. Power of State Government to call for records etc.
- The State Government may, at any time, require any Municipal Authority-(a)to produce any
record, correspondence, or other documents,(b)to furnish any return, plan, estimate, statement,
accounts, or statistics, and(c)to furnish or obtain any report, and thereupon such municipal
authority shall comply with such requirement.
68. Power of State Government to Depute officers to make inspection or
examination and report.
- The State Government may depute any of its officers to inspect or examine any department, office,
service, work or property of the Municipality and to report thereon, and such officer may, for the
purpose of such inspection or examination, exercise all the powers of the State Government under
section 67:Provided that such officer shall be not below the rank of -(a)a Deputy Secretary to the
State Government in the case of a Class 'A' Municipal Council or Class 'B' Municipal Council,
and(b)a Sub-divisional Officer in the case of a Class 'C' Municipal council or Nagar Panchayat, as the
case may be.
69. Power of State Government to require Municipal Authorities to take
action.
- If, after considering the records required under section 67, or the report under section 68, or any
information received otherwise by the State Government, the State Government is of opinion that
-(a)any action taken by a municipal authority is unlawful or irregular or any duty imposed on such
authority by or under this Act has not been performed or has been performed in an imperfect,
insufficient or unsuitable manner, or(b)adequate financial provision has not been made for the
performance of any under this Act, the State Government may, by order, require such municipal
authority to regularize such unlawful or irregular action or perform such duty or restrain such
authority from taking such unlawful or irregular action or direct such authority to make, to the
satisfaction of the State Government, within such period as may be specified in the order,
arrangement, or financial provision, as the case may be, for the proper performance of such
duty:Provided that the State Government shall, unless in its opinion the immediate execution of
such order is necessary before making an order under this section, give such municipal authority, in
writing, an opportunity of show cause, within such period as may be specified by the State
Government, why such order should not be made.Arunachal Pradesh Municipal Act, 2007

70. Power of State Government to provide for enforcement of order under
section 69.
(1)If no action has been taken in accordance with the order under section 69 within the period
specified therein or if no cause has been shown under the provision to that section or if the cause
shown is not to the satisfaction of the State Government, the State Government may make
arrangements for the taking of such action and may direct that all expenses connected therewith
shall be defrayed from the Municipal Fund.(2)For the purposes of sub-section (1), it shall be lawful
for the State Government to appoint, for such period as the State Government may thinks fit, any
person considered suitable by it, who shall exercise and perform, subject to such directions as the
State Government may issue from time to time, all or any of the powers and functions of the
municipal authorities necessary to implement the order under section 69.
71. Power of State Government to dissolve Municipality.
(1)If no action has been taken in accordance with the order under section 69 within the period
specified therein or if no cause has been shown under the provision to that section or if the cause
shown is not to the satisfaction of the State Government, the State Government may make
arrangements for the taking of such action and may direct that all expenses connected therewith
shall be defrayed from the Municipal Fund.(2)For the purposes of sub-section (1), it shall be lawful
for the State Government to appoint, for such period as the State Government may thinks fit, any
person considered suitable by it, who shall exercise and perform, subject to such directions as the
State Government may issue from time to time, all or any of the powers and functions of the
municipal authorities necessary to implement the order under section 69.(1) If, in the opinion of the
State Government, the Municipality has shown its incompetence, or has persistently made default,
in the performance of the duties, or in the exercise of the functions, imposed on it by or under this
Act or any other law for the time being in force, or has exceeded or abused its powers, or is unable to
function under the provisions of this Act, the State Government may, subject to the provisions of
sub-section (2), by an order published in the Official Gazette, and stating the reasons therefore,
declare the Municipality to be incompetent or in default or to have exceeded or abused its powers, as
the case may be, and with effect from such date, as may be specified in the order.(2)(a)before
making any order under sub-section (1), a notice shall be given by the State Government to the
Municipality calling upon it to submit representation, if any, against the proposed order within such
period as may be specified in the notice.(b)on receipt of such representation, if any, the State
Government shall constitute a committee consisting of five persons, nominated by the State
Government, of whom-(i)one shall be a member of the State Higher Judicial Service who shall be
the Chairperson of the committee,(ii)one shall be the Chief Councillor of any other Municipality of
the same class,(iii)one shall be a Chartered Accountant or a person having experience in financial
matters,(iv)one shall be an Engineer or Architect, and(v)one shall be an officer of the State
Government, not below the rank of a Sub divisional Officer, and shall forward the representation to
the committee for its consideration and report within such time as the State Government may
specify.(c)the State Government shall, on receipt of the report from the committee, consider the
representation :Provided that notwithstanding anything contained in sub-section (1), no order of
dissolution of the Municipality shall be made without giving the Municipality an opportunity ofArunachal Pradesh Municipal Act, 2007

being heard.
72. Consequences of dissolution.
(1)Notwithstanding anything contained in this Act or in any other law for the time being in force,
with effect from the date of the order of dissolution under sub-section (1) of section-71.(a)all the
councillors including the members of the Empowered Standing Committee and of any committee of
the Municipality constituted under this Act, and the Chief Councillor and the Deputy Chief
Councillor shall vacate their respective offices, and(b)all the powers and duties which, under the
provisions of this Act or the rules or the regulations made thereunder or any other law of the time
being in force, may be exercised or performed Standing by the members of the Empowered Standing
Committee or of any committee of the Municipality or the Chief Councillor, shall be exercised or
performed, subjects to such directions as the State Government may give from time to time, by such
person or persons as the State Government may appoint in this behalf :Provided that when the State
Government appoints more than one person to exercise any powers or perform any duties, it may,
by order, and in such manner as it thinks fit, allocate such powers and duties among the persons so
appointed :Provided further that the State Government shall fix the remuneration of such person or
persons, and may direct that such remuneration shall, in each case, be paid out of the Municipal
Fund.(2)For the avoidance of doubts, it is hereby declared that an order of dissolution under
sub-section (1) of section -71 shall not effect or imply in any way the dissolution of the Municipality
as a body corporate.Chapter-IX Municipal finance and Municipal Fund
73. Implementation of recommendations of State Finance Commission.
- After taking into consideration the recommendations of the State Finance Commission constituted
under article 243-Y, read with article 243-I, of the Constitution of India, the State Government shall
determine-(a)the devolution of net proceeds of the taxes, tolls and fees to the Municipalities,(b)the
assignment of taxes, duties, tolls and fees to the Municipalities,(c)the sanction of grants-in-aid to
the Municipalities from the Consolidated fund of the State, and(d)the other measures required to
improve the financial position of the Municipalities.
74. Financial Assistance from State Government.
(1)The State Government may, from time to time, give grants or financial assistance to the
Municipality with or without direction as to the manner in which such grants or financial assistance
shall be applied.(2)The State Government may, for giving such grants or assistance, lay down a
scheme which may include the conditions of release of Municipalities into different classes for that
purpose.(3)The State Government may, give grants to the Municipality for implementation, in full
or in part, of any scheme included in the annual development plan of the Municipality.
75. Municipal Fund.
(1)There shall be a fund to be called the Municipal Fund which shall be held by the Municipality inArunachal Pradesh Municipal Act, 2007

trust for the purposes of this Act, and all moneys realized or realizable under this Act and all moneys
otherwise received by the Municipality shall be credited thereto.(2)Subject to such directions as the
State Government may issue in this behalf, and keeping in view the classification of municipal areas
under section -7,the receipts and expenditures of the Municipality shall be kept under such heads of
accounts, including those for water-supply, drainage and sewerage, solid waste management, road
development and maintenance, slum services, commercial projects and other account heads as may
be specified and the general account head, in such manner, and in such form, as may be prescribed,
so as to facilitate the imposition of user charges and preparation of any subsidy report under this
Act.Explanation. - For the purposes of this section, "commercial projects" shall include municipal
markers, development projects, property development projects, and such other projects of a
commercial nature as may be specified by the Municipality from time to time.(3)Every head of
account specified under sub-section (1) shall be split up into a revenue account and a capital account
and all items of receipts and expenditures shall be kept appropriately under such revenue account or
capital account, as the case may be.Chapter-X Application of Municipal fund
76. Application of Municipal Fund.
- The moneys credited to the Municipal fund from time to time shall be applied for payment of all
sums, charges and costs necessary for carrying out the purposes of this Act and the rules and the
regulations made thereunder and for payment out of the Municipal Fund under any other law for
the time being in force.
77. Payments not to be made out of Municipal Fund unless Covered by
Budget grant.
- No payment of any sum out of the Municipal fund shall be made unless such expenditure is
covered by a current budget grant and a sufficient balance of such budget grant is available,
notwithstanding any reduction or transfer thereof under the provision or transfer under the
provisions of this Act :Provided that this section shall not apply to any payment in the following
cases:-(a)refund of taxes and other moneys which are authorized by this Act,(b)repayment of
moneys belonging to contractors or other persons and held in deposit and all moneys collected by
the Municipality or credited to the Municipal Fund by mistake,(c)temporary payment for works
urgently required by the State Government in the public interest,(d)expenses incurred by the
Municipality on special measures on the outbreak of dangerous diseases, natural or technological
hazards or in any other emergent case,(e)sums payable as compensation under this Act or the rules
or the regulations made thereunder,(f)sums payable-(i)under orders of the State Government on
failure of the Municipality to take any action required by the State Government under any provision
of this Act, Or(ii)under any other law for the time being in force, or(iii)under the decree or order of a
civil or criminal court against the Municipality, or(iv)under a compromise of any claim, suit or other
legal proceeding, or(v)on account of the cost incurred in taking immediate action by any of the
municipal authorities to avert a sudden threat or danger to the property of Municipality or of human
life, and(g)such other cases as may be determined by regulations.Arunachal Pradesh Municipal Act, 2007

78. Procedure when money not covered by budget grant.
- Whenever any sum is paid in any of the cases referred to in the provision to section- 77, the Chief
Municipal Executive Officer/ Municipal Executive Officer shall forthwith communicate the
circumstances of such payment to the Empowered Standing Committee, and, thereupon, the
Empowered Standing Committee may take, or recommend to the Municipality to take, such action
under the provisions of this Act as may appear to it to be feasible and expedient for covering the
amount of such payment.
79. Temporary payment from Municipal Fund for works urgently required in
public interest.
(1)On a requisition, in writing, by the State Government, the Empowered Standing committee may,
at any time, required the Chief Municipal Executive Officer/ Municipal Executive Officer to
undertake the execution of any work certified by the State Government to be urgently required in
the public interest and, for this purpose, to make payment for such work from the Municipal Fund
in so far as such payment be made without unduly interfering with the regular work of the
Municipality.(2)The cost of all work so executed, and the proportionate establishment charges for
executing such work, shall be paid by the State Government and credited to the Municipal
Fund.(3)On receipt of a requisition under sub-section (1), the Empowered Standing Committee shall
forthwith forward a copy thereof to the Municipality together with a report of the steps taken in
pursuance of the said requisition.
80. Power to incur expenditure beyond the limits of Municipality.
- Notwithstanding anything contained elsewhere in this chapter, the Municipality may, with the
approval of the State Government, authorize expenditure to be incurred beyond the limits of the
municipal area for creation of physical assets relating to the core functions of the Municipality
outside the limits of such municipal area and for maintenance thereof for carrying out the purposes
of this Act.
81. Exclusive use of Fund for particular purpose.
(1)Notwithstanding anything contained elsewhere in this chapter, the State Government may, by
order, require the Municipality to earmark a particular portion of the Municipal Fund or a particular
grant or a part thereof, or any item of receipt under any head of account, or any percentage thereof,
or any share of tax receivable by the Municipality other than taxes, duties and fines assigned to the
Municipality under this Act or any part thereof, to be utilized exclusively for such purpose related to
municipal functions as may by specified by the State Government, and it shall be the duty of the
Municipality to act accordingly.(2)The State Government may, for carrying out the purposes of
sub-section (1), make rules for different classes of Municipalities.Arunachal Pradesh Municipal Act, 2007

82. Operation of accounts.
- Subject to the other provisions of this Act, payment from the Municipal Fund shall be made in such
manner as may be determined by regulations, and the heads of accounts referred to in section-75
shall be operated by such officers of the Municipality as may be authorized by the Municipality by
regulations.
83. Investment of surplus moneys.
(1)Surplus moneys standing at the credit of any of the heads of account of the Municipal Fund which
are not required, either immediately or at any early date, to be applied for the purposes of this Act
by the Municipality, may, in accordance with such regulations as may be made by the Municipality
in this behalf, be transferred by the Municipality, either in whole or in part, to any other head of
account of the Municipal Fund:Provided that no such money shall be transferred permanently from
any of the heads of accounts to any other head of account without the previous approval of the
Municipality:Provided further that such surplus moneys standing at the credit of the
CommercialProjects Account of the Municipal Fund shall not be transferred to the General Account
of the Municipal Fund.(2)Surplus moneys which are not transferred under sub-section (1), may be
invested in public securities or small savings schemes, approved by the State Government, or
deposited at interest with such scheduled bank as may be determined by the Empowered Standing
Committee.(3)Profit or loss, if any, arising from the investment as aforesaid shall be credited or
debited, as the case may be, to the account to which such profit or loss relates.Chapter-XI Budget
Estimates
84. Preparation of budget Estimate of Municipality.
(1)The Chief Municipal Executive Officer/ Municipal Executive Officer shall prepare in each year a
budget estimate along with an establishment schedule of the Municipality for the ensuing year, and
such budget estimate shall be an estimate of the income and expenditure of the
Municipality.(2)Subject to the provisions of section 10 and sub-section (2) of section 75, the budget
estimate shall separately state the income and the expenditure of the Municipality to be received
and incurred in terms of the various heads of accounts.(3)The budget estimate shall state the rates
at which various taxes, surcharges, cesses and fees shall be levied by the Municipality in the year
next following.(4)The budget estimate shall state the amount of money to be raised as loan during
the year next following.(5)The Chief Councillor shall present the budget estimate to the Municipality
on the 15th day of February in each year or as soon thereafter as possible.(6)The budget estimate
shall be prepared, presented and adopted in such Form and in such manner, and shall provide for
such matters, as may be prescribed.(7)The annual statements prepared under sub-section (2) of
section 107 and sub-section *(1) of section 119 together with the reports prepared under sub-section
(1) of section 85 and under sub-section (2) of section 278 shall be enclosed with the budget estimate.Arunachal Pradesh Municipal Act, 2007

85. Report on Services Provided at Subsidized Rate.
(1)The Chief Municipal Executive Officers/ Municipal Executive Officer shall, while preparing the
budget estimate, append thereto a report indicating whether the following services are being
provided at a subsidized rate and, if so, the extent of the subsidy, the reasons therefore, the source
from which the subsidy is being met, and the sections or categories of the local population who are
the beneficiaries of such subsidy, namely:-(a)water-supply and disposal of sewage,
and(b)scavenging, transporting and disposal of solid wastes.Explanation. - A service shall be
construed as being provided at a subsidized rate if its total cost, comprising the expenditure on
operation and for debt serving, exceeds the income relating to the rendering of that service.(2)The
Empowered Standing Committee shall examine the report referred to in sub-section (1) and place
the same before the Municipality with its recommendations, if any.
86. Sanction of budget Estimate of Municipality.
(1)The Municipality shall consider the budget estimate and the recommendations, if any of
Empowered Standing Committee thereon, and shall, by the fifteenth day of March in each year,
adopt the budget estimate for the ensuing year with such changes as it may consider necessary, and
submit the budget estimate so adopted to the Director of Local Bodies.(2)The budget estimate
received by the Director of Local Bodies, as the case may be, under sub-section (1) shall be returned
with or without modifications of the provisions relating to subventions by the State Government.
87. Power to alter Budget grant.
- A Municipality may, from time to time, during a year-(a)increase the amount of any budget grant
under any head,(b)make an additional budget grant for the purpose of meeting any special or
unforeseen requirement arising during the said year,(c)transfer the amount of any budget grant or
portion thereof under one head to the amount of budget grant under any other head, or(d)reduce
the amount of the budget grant under any head:Provided that nothing shall be done under clause (a)
or clause (b) or clause (c) or clause (d) without the recommendation of the Empowered Standing
committee.Chapter-XII Accounts and Audit
88. Maintenance of Accounts.
- The Chief Municipal Executive Officer/ Municipal Executive Officer shall prepare and maintain
accounts of receipts and expenditures of the Municipality in such Form, and in such manner, as may
be prescribed.
89. Preparation of Municipal Accounting Manual.
- The State Government shall prepare and maintain a Manual to be called the MunicipalAccounting
Manual containing details of all financial matters and procedures relating thereto in respect of the
Municipality.Arunachal Pradesh Municipal Act, 2007

90. Financial Statement.
(1)The Chief Municipal Executive Officer/ Municipal Executive Officer shall, within four months of
the close of a year, cause to be prepared a financial statement containing an income and expenditure
account and a receipts and payments account for the preceding year in respect of the accounts of the
Municipality.(2)The Form of the financial statement, and the manner in which the financial
statement shall be prepared, shall be such, as may be prescribed.
91. Balance sheet.
(1)The Chief Municipal Executive Officer/ Municipal Executive Officer shall, within four months of
the close of a year, cause to be prepared a balance sheet of the assets and the liabilities of the
Municipality for the preceding year.(2)The Form of the balance sheet, and the manner in which the
balance sheet be prepared, shall be such as may be prescribed.
92. Submission of financial Statement and balance sheet to Auditor.
- The financial statement prepared under section 90 and the balance sheet of the assets and the
liabilities prepared under section 91 shall be placed by the Chief Municipal Executive Officer/
Municipal Executive Officer before the Empowered Standing Committee which, after examination of
the same, shall adopt and remit them to the Auditor as may be appointed in this behalf by the State
Government.
93. Power of Auditor.
(1)The municipal accounts as contained in the financial statement, including the accounts of special
funds, if any, and the balance sheet shall be examined and audited by an Auditor appointed by the
State Government from the panel of professional chartered accountants prepared in that behalf by
the State Government.(2)The Chief Municipal Executive Officer/ Municipal Executive Officer shall
submit such further accounts to the Auditor as may be required by him.(3)The Auditor so appointed
may-(a)require, by a notice, in writing, the production before him, or before any officer subordinate
to him, of any document which he considers necessary for the proper conduct of the
audit,(b)require, by notice, in writing, any person accountable for, or having the custody or control
of, any document, cash or article, to appear in person before him or before any officer subordinate to
him.(c)require any person so appearing before him, or before any officer subordinate to him, to
make or sign a declaration with respect to such document, cash or article or to answer any question
or prepare and submit any statement, and(d)cause physical verification of any stock of articles in
course of examination of accounts.(4)The Auditor, or the officer subordinate to him, may report any
item of accounts contrary to the provisions of this Act to the Empowered Standing
Committee.(5)The Empowered Standing Committee shall consider the report of the Auditor as early
as possible and shall, if necessary, take prompt action thereon, and shall also, if necessary,
surcharge the amount of any illegal any person responsible therefore the amount of any deficiency
or loss incurred by the negligence or misconduct of such person or any amount which ought to haveArunachal Pradesh Municipal Act, 2007

been, but is not, brought into account by such person, and shall, in every such case, certify the
amount due from such person:Provided that any person aggrieved by an order of payment of
certified sums any appeal to the State Government whose decision on such appeal shall be
final.(6)Any person who willfully neglects, or refuses to comply with, the requisition made by an
Auditor, or the officer subordinate to him, shall, on conviction by a Court, be punishable with fine in
respect of item included in the requisition. The fine may be fixed by the Government from time to
time.
94. Audit report.
(1)As soon as practicable after the completion of audit of the accounts of the Municipality, but not
later than the thirtieth day of September each year, the Auditor shall prepare a report of the
accounts audited and examined and shall send such report to the Chief Municipal Executive Officer/
Municipal Executive Officer.(2)The Auditor shall include in such report a statement
showing.(a)every payment which appears to the Auditor to be contrary to law,(b)the account of any
deficiency or loss, which appears to have been caused by gross negligence or misconduct of any
person,(c)the account of any sum received which ought to have been, but has not been, brought into
account by any person, and(d)any other material impropriety or irregularity in the accounts.
95. Placing of Audited Accounts before Municipality.
(1)The Chief Municipal Executive Officer/ Municipal Executive Officer shall place the audited
financial statement, the balance sheet and the report of the Auditor and his comments thereon
before the Empowered Standing Committee which, after the examination thereof, shall place them
before the Municipality with its comments, if any,(2)The Chief Municipal Executive Officer/
Municipal Executive Officer shall remedy any defect that has been pointed out by the Auditor in his
report.
96. Submission Of audited Accounts.
(1)The Chief Municipal Executive Officer/ Municipal Executive Officer shall, after adoption of the
financial statement and the balance sheet and the report of the Auditor by the municipality, forward
the same to the State Government together with a report of the action taken thereon by the
Municipality and shall also send copies thereof to the Auditor.(2)If there is any difference of opinion
between the Auditor and the Municipality or if the Municipal does not remedy the defects or the
irregularities mentioned in the report of the Auditor within a reasonable period, the Auditor shall
refer the matter to the State Government whose decision here on shall be final and binding.
97. Power of State Government to enforce order upon audit report.
- If any order made by the State Government under this chapter is not complied with, it shall be
lawful for the State Government to take such steps as it thinks fit to secure the compliance of the
order and to direct that all expenses therefore shall be defrayed from the Municipal Fund.Arunachal Pradesh Municipal Act, 2007

98. Special audit.
- In addition to the audit of annual accounts, the State Government or the Municipality may, if it
thinks fit, appoint an Auditor to conduct special audit pertaining to a specified item or series of
items requiring thorough examination, and the procedure relation to audit shall apply mutatis
mutandis to such special audit,
99. Internal audit.
- The State Government or Municipality may provide for internal audit of the day to day accounts of
the Municipality by the auditor appointed in this behalf by the State Government in the manner as
may be prescribed.
100. Municipal Accounts Committee.
(1)The Municipality shall, at its first meeting in each year or as soon as may be at any meeting
subsequent thereto, constitute a Municipal Accounts Committee.(2)The Municipal Accounts
Committee shall consist of-(a)such number of members, not being less than 3 and not more than 5
as the Municipality may determine, to be elected by the Councillors, not being the members of the
empowered Standing Committee, from amongst themselves, and(b)such number of persons, not
being Councillors, or officers or other employees of the Municipality and not exceeding two in
numbers, having knowledge in financial matters, as may be nominated by the Municipality.(3)The
members of the Municipal Accounts Committee shall elect from amongst themselves one member to
be its Chairperson.(4)Subject to the other provisions of this Act, the members of the Municipal
Accounts Committee shall hold office until a new Municipal Accounts Committee is
constituted.(5)The manner of submission of resignation by the Chairperson or any other member,
and the manner of filling up of a casual vacancy in the office of a member, of the Municipal accounts
Committee shall be such as may be prescribed.(6)Subject to the provisions of this Act and the rules
and the regulations made thereunder, it shall be the duty of the Municipal Accounts
Committee-(a)to examine the accounts of the Municipality showing the appropriation of sums
granted by the Municipality for its expenditure and the annual financial accounts of the
Municipality,(b)to examine and scrutinize the report on the accounts of the Municipality by the
Auditor appointed under section 92 and to satisfy itself that the moneys shown in the accounts as
having been disbursed were available for, and applicable to, the services or purposes to which they
were applied or charged and that the expenditure was incurred in accordance with the authority
governing such expenditure,(c)to submit report to the Municipality every year and from time to time
on such examination and scrutiny,(d)to consider the report of the Auditor appointed under section
98 in cases where the State Government or the Municipality requires him to conduct a special audit
of any receipt or expenditure of the Municipality or to examine the accounts of stores and stocks or
the Municipality or to check the inventory of the properties of the Municipality including its land
holdings and buildings ; and(e)to discharge such other functions as may be prescribed.(7)The
Municipal Accounts Committee may call for any book or document if, in its opinion, such book or
document is necessary for its work and may send for such officers of the Municipality as it may
consider necessary for explaining any matter in connection with its work.(8)The manner ofArunachal Pradesh Municipal Act, 2007

transaction of business to the Municipal Accounts Committee shall be such as may be determined by
regulations :Provided that the persons nominated under clause (b) of sub-section (2) shall not have
the right to vote at the meeting of the Municipal Accounts Committee.Chapter-XIII Municipal
Property
101. Power to acquire and hold property.
- The Municipality shall, for the purposes of this Act, have the power to acquire, by gift, purchase or
otherwise, and hold, movable and immovable properties or any interest therein, whether within or
outside the limits of the municipal area.
102. Vesting of property.
- Notwithstanding anything contained in any other law for the time being in force, the movable and
the immovable properties of the following categories within the limits of a municipal area, not
belonging to any Government department or statutory body or corporation, shall vest in the
Municipality, unless the State Government directs otherwise by notification, namely:-(a)all vested
public lands not belonging to any Government department or statutory body or corporation,(b)all
public tanks, streams, reservoirs, and wells,(c)all public markets and slaughterhouses,(d)all public
sewers and drains, channels, tunnels, culverts and watercourses, alongside, or under, any
street,(e)all public streets and pavements, and stones and other materials thereon, and also trees on
such public streets or pavements not belonging to any private individual,(f)all public parks and
gardens, including squares and public open spaces,(g)all public ghats on rivers or streams or
tanks,(h)all public lamps, lamp-posts and apparatus connected therewith, or appertaining
thereto,(i)all public places for disposal of the dead, excluding those governed by any specific law in
this behalf,(j)all solid wastes collected on a public street or public place, including dead animals and
birds, and(k)all stray animals not belonging to any private person.
103. Acquisition of property by Municipality by agreement, exchange, lease,
grant, etc.
(1)The Municipality may, on such terms and conditions as may be approved by it, acquire by
agreement-(a)any immovable property, and(b)any easement affecting immovable property.(2)The
Municipality may also acquire any property by exchange on such terms and conditions as may be
approved by it.(3)The Municipality may also hire or take on lease immovable property on such
terms and conditions as may be approved by it from time to time.(4)The Municipality may receive
any grant or dedication by donor, whether in the form of any income or any movable or immovable
property, by which the Municipality may be benefited in the discharge of any of its functions.(5)It
shall be for the Municipality to be the beneficiary of any trust created under the Charitable and
religious Trusts Act, 1920, or the Indian Trusts Act, 1882.Arunachal Pradesh Municipal Act, 2007

104. Compulsory Acquisition of land.
(1)When any land, whether within or outside the limits of the municipal area, or any easement
affecting any immovable property vested in the Municipality, is required for any public purpose
under this Act, the State Government may, at the request of the Municipality, proceed to acquire
such land or easement under the Land of Acquisition Act, 1894.(2)The Municipality shall be bound
to pay to the State Government the cost including all charges in connection with the acquisition of
the land under the Land Acquisition Act, 1894.(3)The Municipality may resort to other methods of
land assembly including the use of transferable development rights.
105. Special provisions for acquisition of lands adjoining streets.
- Whenever the Municipality makes a request to the State Government for acquisition of land for the
purpose of widening or improving an existing street, it shall be lawful for the Municipality to apply
to the State Government for the acquisition of such additional land immediately adjoining the land
to be occupied by such new street or existing street as is required for the sites of buildings to be
erected on either side of the street, and such additional land shall be deemed to be required for the
purposes of this Act.
106. Disposal of property.
- Any property belonging to the Municipality may be disposed of in the manner hereinafter
provided, namely:-(a)the Empowered Standing Committee may sell, or grant lease or, otherwise
dispose of, by public auction, any movable property, and may grant lease of, or let out on hire, any
immovable property, belonging to the Municipality,(b)the Municipality may, with the prior approval
of the State Government, for valuable consideration, sell or otherwise transfer, any immovable
property belonging to the Municipality which is not required for carrying out the purposes of this
Act, and(c)the Municipality shall not transfer any immovable property vested in it by virtue of this
Act, but shall cause the same to be maintained, controlled and regulated in accordance with the
provisions of this Act and the rules and the regulations made thereunder:Provided that the State
Government may authorize, in the public interest, the disposal of such immovable property by the
Municipality, if the Municipality so requires, for reasons to be recorded in writing.Explanation. - "
valuable consideration" shall, in relation to any immovable property, mean anything of considerable
value in terms of money or property given in lieu of transfer, by way of sale or otherwise, of such
immovable property.
107. Inventory of properties of Municipality.
(1)The Empowered Standing Committee shall maintain a register and a map of all the immovable
properties of which the Municipality is the owner or which vest in it, or which the Municipality holds
in trust with the Government, and a register of all movable properties belonging to the
Municipality.(2)The Empowered Standing Committee shall, in the case of the inventory of an
immovable property, prepare an annual statement indicating the changes, if any, in the saidArunachal Pradesh Municipal Act, 2007

inventory and shall place the same before the Municipality along with the budget
estimate.Chapter-XIV Borrowings
108. Comprehensive debt limitation policy.
- The State Government shall frame a comprehensive debt limitation policy applicable in the case of
loans, including short- term loans, to be raised by the Municipalities, laying down, inter alia, the
general principles governing the raising of loans by the Municipalities, the limit of the loans which
any Municipality may raise having regard to its financial capacity, the rate of interest to be paid for
such loans, and the terms and conditions, including the period of repayment thereof.
109. Power of Municipality to raise loan.
(1)The Municipality may, from time to time, raise, by a in resolution in this behalf passed at a
meeting of the Municipality, a loan within the limits set by the comprehensive debt limitation policy
framed under section 108, by the issue of debentures or other wise, on the security of the property
tax or of all or any of the other taxes, surcharges, cesses and fees and dues under this Act or of both
the property tax and all or any of the other taxes, surcharges, cesses and fees and dues under this
Act, or on the guarantee by the State Government, of any sum of money which may be required for
the purpose of this Act namely:-(a)construction of works(b)acquisition of lands and
buildings(c)paying off any debt due to the State Government,(d)repayment of a loan
raised(e)acquisition of a public utility concern which renders such services as the Municipality is
authorized to render(f)purchase of vehicles, locomotive engines, boilers and machinery necessary
for carrying out the purposes of this Act, or(g)any other purpose for which the Municipality is, by or
under this Act or any other law for the time being in force, authorized to borrow:Provided that any
loan proposed to be raised which goes beyond the limits set by the comprehensive debt limitation
policy as aforesaid shall require the previous sanction of the State Government in regard to its
purpose, the quantum, the rate of interest and the period for repayment, and the other terms and
conditions, if any:Provided further that in addition to the loans as aforesaid, the Municipality may
also take loan from the State Government or any statutory body or public sector
corporation.(2)When any loan has been raised under sub-section (1),-(a)no portion thereof shall,
without the previous sanction of the State Government, be applied to any purpose other than that
for which it has been raised, and(b)no portion of any loan raised for any of the purposes referred to
in that subsection shall be applied to the payment of salaries or allowances to any officer or other
employee of the Municipality, other than those who are exclusively employed for the purpose for
which the loan has been raised.Explanation. - The expression " dues under this Act" in sub-section
(1) shall, for the purpose of clause (e) of that sub-section, be deemed to include the income derivable
from the public utility concern referred to in that clause.
110. Power of Municipality to open credit account with bank.
- Notwithstanding anything contained in section 109, the Municipality may, where the raising of a
loan is sanctioned by the State Government under that section, instead of raising such loan or any
part thereof, take credit, on such terms as may be approved by the State Government, from anyArunachal Pradesh Municipal Act, 2007

scheduled bank, to be kept in a cash account bearing the name of the Municipality to the extent of
such loan or any part thereof and, with the sanction of the State Government, may grant mortgage of
all or any of the properties vested into the Municipality by way of securing the repayment of the
amount of such credit or of the sums advanced from time to time on such cash account with interest.
111. Power of Municipality to raise short term loan.
- Notwithstanding anything contained in this chapter, the Municipality may, within the limits set by
the comprehensive debt limitation policy framed under section 108, from time to time, take a
short-term loan repayable within such period, not exceeding twelve months, from any other
scheduled bank, for such purpose, not being a purpose referred to in sub-section (1) of section 109,
on such terms, and on furnishing such security for the repayment of such loan, as may be approved
by the State Government.
112. Establishment of Sinking Fund.
- The Municipality shall establish a Sinking Fund in respect of each loan raised under section 109 for
the repayment of moneys borrowed, or debentures issued, and shall in every year, pay into such
Sinking Fund such sum as shall, be sufficient for the repayment, within the period fixed for the loan,
of the moneys borrowed or the debentures issued.
113. Application of Sinking Fund.
- A Sinking Fund or any part thereof shall be applied to discharge of the loan or a part of the loan for
which such Fund was created and, until such loan or part thereof is wholly discharged, such Fund
shall not be applied to any other purpose.
114. Power to discontinue payment towards Sinking Fund.
- If, at any time, the sum standing at the credit of a Sinking Fund established under section 112 for
the repayment of any loan is of such amount that is allowed to accumulate at the rate of interest
sanctioned under the first proviso to sub-section (1) of section 109, it will be sufficient to pay off the
loan within the period approved by the State Government under the said proviso, further payments
towards such fund may be discontinued.
115. Investment of amount at the credit of Sinking Fund.
(1)All moneys paid into a Sinking Fund shall, as soon as possible, be invested by the Empowered
Standing Committee in-(a)Government securities, or(b)securities guaranteed by the Central
Government or any State Government, or(c)debentures issued by the Municipality, or(d)such other
public securities as may be approved by the State Government,(e)and such other securities as may
be held by the Municipality for the purpose of repayment of loans from time to time raised by it by
issue of debentures or otherwise.(2)All dividends and other sums received in respect of anyArunachal Pradesh Municipal Act, 2007

investment under sub-section (1) shall, as soon as possible after their receipt, be paid into the
Sinking Fund and shall be invested in the manner laid down in that sub-section.(3)Moneys standing
at the credit of two or more Sinking Funds may, at the discretion of the Empowered Standing
Committee, be invested together as a common fund, and it shall not be necessary for the
Empowered Standing Committee to allocate the securities held in such investments to the several
Sinking funds.(4)Subject to the provision of sub-section (1), any investment made under this section
may, from time to time, be varied or transposed.
116. Power of Municipality to reserve a portion of debentures, issued for
raising loan, for investment.
(1)For the purpose of investment of any portion of the Municipal Fund, including Sinking Fund, in
the debentures issued by the Municipality for raising a loan, the Municipality may, within the limits
set by the comprehensive debt limitation policy framed under section 108, reserve and set apart any
portion of such debentures for issue at par thereto in the name of the Municipality provided that the
intention so to reserve and set apart such debentures shall have been notified as a condition of
raising the loan.(2)The issue of any debentures by the Municipality under sub-section (1) shall not
operate to extinguish or cancels such debentures, but issued to, and in the name of, any other
person.(3)The purchase by, or the transfer, assignment or endorsement to, the Municipality of any
debenture issued by it shall not operate to extinguish or cancel such debenture and every such
debenture shall be valid and negotiable in the same manner and to the same extent as if it were held
by or transferred, assigned or endorsed to, any other person.
117. Manner of Repayment of loans.
- Every loan raised by the Municipality under section 109 shall be repaid within the time approved
under that section and such repayment shall be made either from a Sinking Fund established under
section 112 in respect of such loan or partly from such Sinking Fund and, to the extent or which such
Sinking Fund falls short of the sum required for the repayment of such loan, partly from the loan
raised for the purpose under section 109, as may be approved by the State Government.
118. Form and effect of debentures.
- All debentures issued under this chapter shall be in such Form, and shall be transferable in such
manner, as the Municipality may, by regulations, determine, and the right to sue in respect of the
moneys secured by any of such debentures shall vest in the holders thereof from the time, being
without any preference by reason of some such debentures being prior in date to others.
119. Annual statement.
(1)The Chief Municipal Executive Officer/ Municipal Executive Officer shall, at the end of every
year, prepare, and submit to the Municipality, an annual statement showing -(a)the amount which
has been paid into the Sinking fund or Sinking Funds during the year under section 112,(b)the dateArunachal Pradesh Municipal Act, 2007

of the last investment made during the year,(c)the aggregate amount of the securities in the hand of
the Municipality at the end of the year, and(d)the aggregate amount which has been applied for the
purpose of repayment of the loan under section 115.(2)A copy of every such annual statement shall
be submitted to the State Government by the Chief Municipal Executive Officer/ Municipal
Executive Officer.
120. Annual examination of Sinking Funds.
(1)All Sinking Funds established under this Act shall be subject to annual examination by the
Auditor appointed under section 92 who shall ascertain whither the cash and the value of securities
belonging to such Sinking funds are equal to the amount which should be at the credit of such
Sinking Funds, had the investment under section 115 been regularly made and had the interest
accruing from such investments been regularly obtained.(2)The amount which should be at the
credit of a Sinking Fund shall be calculated on the basis of the sums paid into such Sinking Fund
under section 112.(3)The value of securities belonging to a Sinking Fund shall be the current value of
such securities, unless such securities become due for redemption at par with, or above, their face
value before maturity in which case their current value shall be taken as their redemption value,
except in the case of the debentures issued by the Municipality which shall always be valued at par
with their face value, provided the Municipality shall make good immediately may loss owing to the
sale of such debentures for repayment of the loan raised under sub-section (1) of section 109.(4)The
Municipality shall forthwith pay into a Sinking Fund such amount as the Auditor appointed under
section 92 may certify to be deficit in respect of such Sinking Fund, unless the State Government
specially sanctions a gradual readjustment of such deficit.(5)If the cash and the value of the
securities at the credit of a Sinking Fund are in excess of the amount which should be at the credit of
such Sinking Fund, the Auditor appointed under section 92 shall certify the amount of such excess
sum, and the Municipality shall, thereupon, transfer the excess sum into the Municipal Fund
General Account.(6)If any dispute arises as to the accuracy of any deficit or excess referred to in the
certificate under sub-section (4) or sub-section (5), the Municipality may, after payment of such
deficit or after transfer of such excess, as the case may be, refer the matter to the State Government
whose decision thereon shall be final.
121. Power of Municipality to borrow money from State Government and
attachment of Municipal fund for recovery of such money.
(1)The Municipality may borrow money from the State Government for carrying out the purposes of
this Act on such terms and conditions as the State Government may determine.(2)If any money
borrowed by the Municipality from the State Government before the commencement of this Act or
under sub-section (1) is not repaid, or any interest due in respect thereof is not paid, according to
the terms and conditions of such borrowing, the State Government may attach the Municipal Fund
or any portion thereof.(3)After such attachment, an officer as may be appointed in this behalf by the
State Government shall deal with the Municipal Fund, or any portion thereof, so attached, in such
manner as he thinks fit and may do all acts in respect thereof which any municipal authority or an
officer or other employee of the Municipality might have done under this Act, if such attachment
had not taken place, and may apply such Municipal Fund or the portion thereof, as the case may be,Arunachal Pradesh Municipal Act, 2007

for payment of the arrear of the principal amount and the interest incurred on account of the
attachment and subsequent proceeding :Provided that no such attachment shall defeat or prejudice
any debt for the recovery of which the Municipal fund was previously charged under any law for the
time being in force, and all such prior debt shall be paid out of the Municipal Fund before any part
thereof is applied for repayment of the money borrowed from the State Government.
122. Issue of Municipal Bonds for development of urban infrastructure.
- Subject to such guidelines and procedure as the Central Government may lay down from time to
time and with the previous approval of the State Government, the Municipality may issue tax-free
Municipal Bonds for financing of projects for development of urban infrastructure.
123. Credit rating of Municipal Bonds.
(1)A Municipality shall, if and when required for the purpose of raising funds through a Municipal
Bond, arrange to have a credit rating of the municipal Bonds by a Credit Rating Agency, duly
approved by the Central Government or the State Government, as the case may be, in this
regard.(2)The Municipality shall provide to the Credit Rating Agency such information as it may
require.
124. Pledging of Municipal assets as security for Municipal Bonds.
- The Municipality may pledge its movable and immovable assets including lands, buildings and
revenues from tax in special escrow accounts as security for the Municipal Bonds issued for
development of urban infrastructure.
125. Debt Service Reserve Fund.
- The Municipality may set up a Debt Service Reserve Fund by providing special grants from its
surplus revenue or through capitalization of proceeds from Municipal Bonds to service
bond-holders in case of default in payment of principal and interest for a period not exceeding two
years.
126. Limit to encumbrances through future debt.
- If and when required, the Municipality may, for the purpose of issuing Municipal Bond, limit its
future debt encumbrances by adoption of suitable debt service coverage ratio as a minimum ratio in
relation to its future cash flow projections.
127. Use of proceeds from Municipal Bonds.
- The fund to be raised from the Municipal Bonds shall be used for capital investment for
development of urban infrastructure in the spheres of water-supply, sewerage, solid wasteArunachal Pradesh Municipal Act, 2007

management, markets, roads, bridges, and urban transport, and for reforming and improving the
efficiency of existing systems of municipal administration and for repayment of loans for the
aforesaid purposes raised through earlier issues of municipal bonds or otherwise.Municipal
RevenueChapter-XV Sources of Internal Revenues
128. Internal revenues of Municipality.
- The internal revenues of the Municipality shall consist of its receipts from the following
sources:-(a)taxes levied by the Municipality,(b)user charges levied for provision of civic services,
and(c)fees and fines levied for performance of regulatory and other statutory functions.
129. Power to levy taxes.
(1)Subject to the provisions of section 10, the Municipality shall have, for the purposes of this Act,
the power to levy the following taxes:-(a)property tax on lands and buildings,(b)surcharges on
transfer of lands and buildings,(c)tax on deficit in parking spaces in any non residential
building,(d)water tax,(e)fire tax,(f)tax on advertisements, other than advertisements published in
newspapers,(g)surcharge on entertainment tax,(h)surcharge on electricity consumption within the
municipal area,(i)tax on congregations,(j)tax on pilgrims and tourists, and(k)toll-(i)on roads,
bridges and ferries, and(ii)on heavy trucks which shall be heavy goods vehicles, and buses, which
shall be heavy passenger motor vehicles, within the meaning of the Motor Vehicles Act, 1988, plying
on a public street.(2)Subject to the prior approval of the State Government, the Municipality may,
for raising revenue for discharging its duties, and performing its functions, under this Act, levy any
other tax which the State Legislature has the power to levy under the Constitution of India.(3)The
levy, assessment and collection of taxes under this Act shall be in accordance with the provisions of
this Act and the rules and the regulations made there under.
130. Power to levy user charges.
- The Municipality shall levy user charges for-(i)provision of water-supply, drainage and
sewerage,(ii)solid waste management,(iii)parking of different types of vehicles in different areas and
for different periods,(iv)stacking of materials or rubbish on public streets for construction,
alteration, repair or demolition work of any type, and(v)other specific services rendered in
pursuance of the provisions of this Act, at such rates as may be determined from time to time by
regulations :Provided that a Municipality may, having regard to the conditions containing in the
municipal area, decide not to levy, or postpone the levying of, any of the user charges as aforesaid
:Provided further that the State Government may direct the Municipality to levy any of the user
charges as aforesaid, not levied, or postponed, by the Municipality.
131. Power to levy fees and fines.
- The Municipality shall have the power to levy fees and fines in exercise of the regulatory powers
vested in it by or under this Act or the rules or the regulations made there under for-(a)sanction ofArunachal Pradesh Municipal Act, 2007

building plans and issue of completion certificates,(b)issue of municipal licenses for various
non-residential uses of lands and buildings,(c)licensing of -(i)various categories of professionals
such as plumbers and surveyors,(ii)various activities such as sinking of tube-wells, sale of meat, fish
or poultry, or hawking of articles,(iii)animals,(iv)carts or carriages, and(v)such other activities as
require a licence or permission under the provisions of this Act, and(d)issue of birth and death
certificates.
132. Levy of surcharge on tax or fee.
- The Municipality may levy a surcharge on a tax, or user charge, or fee on a premises used for
non-residential purposes at such rate, being not less than twenty five per cent and not more than
seventy five per cent, of such tax, user charge or, fee, as the case may be, as may be determined by
regulations.
133. Power to levy development charge.
- The Municipality may levy such development charge as may be determined by regulations, from
time to time, on any residential building with a height of more than fourteen meters, or any
non-residential building, having regard to its location along a particular category of street, its use
characteristics, and sanctioned built up area.
134. Realization of tax, fees, cess, etc. under any other law.
- The Municipality may, if so authorized by any other law for the time being in force, realize any tax,
development charge, cess, or fee, imposed under that law, or any dues payable under that law, in
accordance with the provisions thereof.Chapter-XVI Tax on Lands and Buildings and Related Taxes
Other Than Property Tax
135. Levy of surcharge on transfer of land and buildings.
(1)The Municipality may levy a surcharge on the transfer of lands and buildings situated within the
municipal area as a percentage of stamp duty levied on such transfer under the Indian Stamp Act,
1899.(2)The rate of surcharge, and the manner of-(a)collection of surcharge,(b)payment of
surcharge to the Municipality, and(c)deduction of the expenses, if any, incurred by the State
Government in course of collection of surcharge, shall be such as may be prescribed.
136. Tax on deficits of parking spaces in nonresidential buildings.
(1)The Municipality may, by regulations, levy a tax on the deficits in the provision for parking spaces
require for different types of vehicles in any non-residential building.(2)The amount of tax shall be
determined by multiplying the quantum of such deficit in the area of parking spaces by the unit area
value of land in the case of open parking spaces or by the unit area value of covered space of a
building in the case of covered parking spaces, as the case may be, as determined for the levy ofArunachal Pradesh Municipal Act, 2007

property tax under this Act.
137. Water tax.
- The Municipality may levy a water tax on any land or non-residential building as a percentage of
property tax as may be specified by regulations.
138. Fire tax.
- The Municipality may levy a fire tax on any building as a percentage of property tax as may be
specified by regulations :Provided that a surcharge may be levied on such fire tax at such rate as may
be specified by regulations for any non-residential building.Chapter-XVII Tax on Advertisements
other Than Advertisements in Newspapers and Licence Fees for Advertisement Spaces
139. Prohibition of Advertisements without written permission of the Chief
Municipal Executive Officer/ Municipal Executive Officer.
(1)No person shall erect, exhibit, fix or retain upon or over any land, building, wall, hoarding, frame,
post, kiosk, structure, vehicle, neon sign or sky-sign any advertisement, or display any
advertisement to public view in any manner whatsoever (including any advertisement exhibited by
means of cinematograph), visible from a public street or public place, in any place within the
municipal area without the permission, in writing, of the Chief Municipal Executive Officer/
Municipal Executive Officer.(2)The Chief Municipal Executive Officer/Municipal Executive Officer
shall not grant such permission, if-(a)a licence for the use of the particular site for the purpose of
advertisement has not been taken, or(b)the advertisement contravenes any provisions of this Act or
the rules or the regulations made thereunder, or(c)the tax, if any, due in respect of the
advertisement has not been paid.(3)No person shall broadcast any advertisement, on radio or
television, without the permission, in writing, of the Chief Municipal Executive Officer/ Municipal
Executive Officer.
140. Licence for use of site for purpose of advertisement.
(1)Except under, and in conformity with, such terms and conditions of a license as the Municipality
may, by regulations, provide, no person being the owner, lessee, any site in any land, building or
wall, or erect, or allow to be erected, on any site any hoarding, frame, post, kiosk, structure, vehicle,
neon-sign or sky-sign for the purpose of display of any advertisement.(2)For the purpose of
advertisement, every person-(a)using any site before the commencement of this Act, within ninety
days from the date of such commencement, or(b)intending to use any site, or(c)whose licence for
use of any site is about to expire, shall apply for a licence or renewal of licence, as the case may be, to
the Chief Municipal Executive Officer/ Municipal Executive Officer in such Form as may be
specified by the Municipality.(3)The Chief Municipal Executive Officer/ Municipal Executive Officer
shall, after making such inspection as may be necessary and within thirty days of the receipt of the
application, grant or renew a licence, as the case may be, on payment of such fee as may beArunachal Pradesh Municipal Act, 2007

determined by regulations, or refuse or cancel a licence, as the case may be.(4)The Chief Municipal
Executive Officer/Municipal Executive Officer may, if, in his opinion, the proposed site for any
advertisement is unsuitable from the considerations of public safety, traffic hazards or aesthetic
design, refuse to grant a licence, or renew any existing licence, within thirty days of the receipt of the
application.(5)Every licence shall be for a period of one year except in the case of sites used for any
temporary congregation of whatever nature including fairs, festivals, circus, yatra, exhibitions,
sports events, or cultural or social programmes.(6)The Chief Municipal Executive Officer/
Municipal Executive Officer shall cause to be maintained a register wherein the licence issued under
this section shall be separately recorded in respect of advertisement sites-(a)on telephone,
telegraph, tram, electric or other posts or poles erected on or along public or private streets or public
places,(b)in lands or buildings, and(c)in cinema-halls, theaters or other places of public resort.
141. Tax on advertisement.
(1)Every person, who erects, exhibits, fixes or retains upon or over any land, building, wall,
hoarding, frame, post, kiosk, structure, vehicle, neon-sign or sky-sign any advertisement, or displays
any advertisement to public view in any manner whatsoever (including any advertisement exhibited
by means of cinematograph ), visible from a public street or public place in any location in a
municipal area including an airport or a port or a railway station, shall for every advertisement,
which is so erected, exhibited, fixed or retained or so displayed to public view, a tax calculated at
such rate as may be determined by regulations:Provided that a surcharge, not exceeding fifty per
cent of the rate of tax as aforesaid, may be imposed on any advertisement on display in any
temporary congregation of whatever nature including fairs, festivals, circus, yatra, exhibitions,
sports events, or cultural or social programmes.(2)Notwithstanding anything contained in
sub-section (1), no tax shall be levied under this section on any advertisement which-(a)relates to a
public meeting or to an election to Parliament or the State Legislature or the Municipality or any
other local authority or to candidature in respect of such election, or(b)is exhibited within the
window of any building, if the advertisement relates to any trade, profession or business carried on
in the building, or(c)relates to any trade, profession or business carried on within the land or the
building upon or over which such advertisement is exhibited or to any sale or letting of such land or
building or any effects therein or to any sale, entertainment or meeting to be held on, upon or in
such land or building, or(d)relates to the name of the land or the building upon or over which the
advertisement is exhibited or the name of the owner or the occupier of such land or building,
or(e)relates to the business of any airport or port or railway administration, and is exhibited within
such airport or port or railway station or upon any wall or other property of an airport, port or
railway station, or(f)relates to any activity of the Central Government or the State Government or
any local authority.(3)The tax on any advertisement leviable under this section shall be payable in
advance in such instalments, and in such manner, as may be determined by regulations:Provided
that the Municipality may, under such terms and conditions of licence as may be determined by
regulations under section 140, require the licensee to collect, and to pay to the Municipality, subject
to a deduction of five per cent of the tax, to be kept by him as collection charges, the amount of tax
in respect of such advertisements as are displayed on any site for which the licence has been
granted.Arunachal Pradesh Municipal Act, 2007

142. Permission of the Chief Municipal Executive Officer/ Municipal Executive
Officer to be void in certain cases.
- Any permission under section 139 shall be void,-(a)if the advertisement contravenes the provisions
of any regulations made under this Act, or(b)if any material change is made in the advertisement or
any part thereof without the previous permission of the Chief Municipal Executive Officer/
Municipal Executive Officer, or(c)if the advertisement or any part thereof falls otherwise than by
accident, or(d)if, due to any work by the Central Government, the State Government, or the
Municipality, or by any statutory authority, the advertisement is required to be displaced.
143. Licence for use of site for purpose of advertisement to be void in certain
cases.
- Any licence granted under section 140 shall be void,-(a)if the licensee contravenes any of the terms
and conditions of licence, or(b)if any addition or alteration is made to, or in, the land, building, wall,
hoarding, frame, post, kiosk, structure, vehicle, neon-sign or sky-sigh, upon or over which the
advertisement is erected, exhibited, fixed or retained, or(c)if the land, building, wall, hoarding,
frame, post, kiosk, structure, vehicle, neon-sign or sky-sign over which the advertisement is erected,
exhibited, fixed or retained or demolished or destroyed.
144. Presumption in case of contravention.
- Where any advertisement has been erected, exhibited, fixed or retained upon or over any land,
building, wall, hoarding, frame, post, kiosk, structure, vehicle, neon-sign or sky-sign or displayed to
public street or public place in contravention of the provisions of this Act or the regulations made
thereunder, it shall be presumed, unless the contrary is proved, that the contravention has been
made by the person or persons on whose behalf the advertisement purports to be or the agents of
such person or persons.
145. Power of the Chief Municipal Executive Officer/ Municipal Executive
Officer in case of contravention.
- If any advertisement is erected, exhibited, fixed or retained in contravention of the provisions of
this Act or the regulations made thereunder, the Chief Municipal Executive Officer/ Municipal
Executive Officer may require the owner or the occupier of the land, building, wall, hoarding, frame,
post, kiosk, structure, vehicle, neon-sign or sky-sign, fixed or retained to take down or remove such
advertisement or may enter any land, building or other property and cause the advertisement to be
dismantled, taken down, removed, spoiled, defaced or screened.Explanation I. - The word "
structure" in this chapter shall include any movable board on wheels used as on advertisement or
advertisement medium.Explanation II. - The word "advertisement", in relation to a tax on
advertisement under this Act, shall mean any word, letter, model, sign, neon-sign, sky-sign, placard,
notice, device or representation, whether illuminated or not, in the nature of, and employed wholly
or in part for the purposes of, advertisement, announcement or direction.Arunachal Pradesh Municipal Act, 2007

146. Removal of poster, hoarding, etc.
- Notwithstanding any other action that may be taken against the owner or the occupier of any land
or building, upon or over which there is any hoarding, frame, post, kiosk, structure, vehicle, neon-
sigh or sky-sign for erecting any advertisement in contravention of the provisions of this Act or the
regulations made thereunder, or the person who owns such hoarding, frame, post, kiosk, structure,
vehicle, neon-sign or sky-sign, the Chief Municipal Executive Officer/ Municipal Executive Officer
may, for removal and storage of such hoarding, frame, post, kiosk, structure, vehicle, neon-sign or
sky-sign, realize from such person such charges as may be fixed by the Empowered Standing
Committee from time to time.Chapter-XVIII Other Taxes and Tolls
147. Surcharge on tax on entertainment.
(1)Subject to the approval of the State Government, the Municipality may levy a surcharge on any
tax levied by the State Government on any entertainment or amusement within the municipal
area.(2)The rate of surcharge and the manner of-(a)collection of the surcharge,(b)payment of the
surcharge to the Municipality, and(c)deduction of the expenses, if any, incurred by the State
Government in course of collection of the surcharge, shall be as may be prescribed.
148. Surcharge on electricity consumption.
- Subject to the approval of the State Government, the Municipality may levy a surcharge on
consumption of electricity within the municipal area at such rates as may be prescribed.
149. Tax on tourists and congregations.
(1)The Municipality may levy a tax per head or per vehicle for providing municipal services to
persons or vehicles visiting the municipal area for the purpose of tourism or in connection with any
congregation of whatever nature, including pilgrimage, fair, festival, circus or yatra, within a
municipal area for persons or vehicles assembling within the municipal area for the purpose
:Provided that such tax shall not be levied for persons or vehicles passing through the municipal
area.(2)The tax for the purposes of sub-section (1) shall be as may be determined by the
Municipality from time to time and shall not exceed the levy on passengers therein.(3)The
Municipality may made regulations specifying the occasions on which such levy may be imposed
and the rate of levy, the mode of collection, and the other matters incidental thereto.
150. Toll on roads.
- The Municipality may, with the sanction of the State Government, establish a toll-bar on any
public street in the municipal area and levy a toll at such toll-bar on vehicles at such rate as may be
determined by the State Government from time to time.Arunachal Pradesh Municipal Act, 2007

151. Toll on bridges.
(1)The Municipality may, with the sanction or the State Government, establish a toll-bar, and levy
tolls, on any bridge at which tolls may be levied on vehicles, carriages and carts passing over such
bridge:Provided that no such toll-bar be established, or tolls levied, otherwise than for the purpose
of recovering the expenses incurred in construction of such bridge together with interest on such
expenses and in maintaining such bridge in good repair.(2)The State Government may, with the
consent of a Municipality, make over to that Municipality any existing toll-bar on a bridge within the
municipal area to be administered by the Municipality and, thereupon, the Municipality shall
administer such toll-bar until the State Government directs otherwise. Every such toll-bar, while so
administered, shall be deemed to be a municipal toll-bar, and the profits derivable there from or
such parts thereof as shall be agreed upon between the State Government and the Municipality,
shall be credited to the Municipal Fund.
152. Toll on heavy truck and bus.
(1)The Municipality may levy toll on heavy trucks and buses referred to in sub-clause (ii) of clause
(1) of sub-section (1) of section 129, plying on a public street.(2)The rate of toll for the purposes of
sub-section (1) shall be such as may be determined by the Municipality by regulations from time to
time.(3)The Municipality may make regulations providing for the mode of collection of toll and
other matters incidental thereto.
153. Declaration of ferries as municipal ferries.
(1)Where a ferry plies between two points on a water-course and either one or both the points are
situated within a municipal area, the Sate Government may, after considering the views of the
concerned Municipality, declare such ferry to be a municipal ferry, and, thereupon, the profits
derivable from the plying of such shall be credited to the Municipal Fund.(2)Due compensation shall
be given by the concerned Municipality to any person for the loss which he may have sustained as a
result of a ferry being declared to be a municipal ferry.
154. Administration of municipal ferries.
- Subject to the provisions of any Central or State law relating to the administration of public ferries,
the Municipality shall specify by regulations-(a)the terms and conditions for granting of lease of
municipal ferries in favour of private parties,(b)the rates of tolls to be established and published for
such municipal ferries,(c)the grounds for cancellation of ferry leases,(d)the administration of a
municipal ferry involving another Municipality or local authority,(e)provisions for safety and
convenience of passengers and goods, and(f)Provisions for exemptions from payment of toll for
municipal ferries in the case of authorized representatives and properties of the Central Government
or the State Government or the Municipality.Arunachal Pradesh Municipal Act, 2007

155. Municipality to collect tolls in navigable channel.
(1)If, the State Government, at any time, declares that the provisions of any law relating to canals or
any other law for the time being in force are applicable to any navigable channel which passes
through the limits of a municipal area, that Government may with the consent of the concerned
Municipality, appoint such Municipality to collect tolls in accordance with the provisions of such law
until the State Government otherwise directs, and the profits derivable there from, or such part
thereof as may be agreed upon between the State Government and the Municipality, shall be
credited to the Municipal Fund.(2)In every such case, the Municipality shall exercise all the powers
vested in the Collector under the law as aforesaid.Chapter-XIX Payment and Recovery of TaxesA.
Recovery of Taxes by Municipality
156. Manner of recovery taxes under the Act.
- Save as otherwise provided in this act, any tax levied under this Act may be recovered in
accordance with the following procedure and in such manner as may be determined by regulations
:-(a)by presenting a bill, or(b)by serving a notice of demand, or(c)by distraint and sale of a
defaulter's movable property, or(d)by attachment and sale of a defaulter's immovable property,
or(e)in the case of property tax on any land or building, by attachment of rent due in respect of such
land or building, or(f)by a certificate under any law for the time being in force regulating the
recovery of any dues as public demand.
157. Time and manner of payment of taxes.
(1)Save as otherwise provided in this Act, any tax levied under this Act shall be payable on such date,
in such number of instalments, and in such manner, as may be determined by regulations.(2)If any
amount due is paid on or before the date referred to in sub-section (1), a rebate of five per cent of
such amount shall be allowed.
158. Presentation of bill.
(1)When any tax has become due, the Chief Municipal Executive Officer/ Municipal Executive
Officer shall cause to be presented to the person liable for the payment thereof a bill for the amount
due :provided that no such bill shall be necessary in the case of-(a)a tax on advertisements,(b)a tax
on tourists and congregations, and(c)a toll :Provided further that for the purpose of recovery of any
tax by the preparation and presentation of a bill or notice of demand and the collection of tax in
pursuance thereof, the Empowered Standing Committee may, with the approval of the Municipality,
entrust the work to any agency under any law for the time being in force, or to any other agency, on
such terms and conditions as may be specified by regulations.Explanation I. - A bill shall be deemed
to be presented under this section if it is sent by post under certificate of posting or by courier
agency or be electronics mail to the person liable for payment of the amount included in the bill,
and, in such case, the date of certificate of posting, or the date on which it is delivered by date of
certificate or by electronic mail shall be deemed to be the date of presentation of the bill to suchArunachal Pradesh Municipal Act, 2007

person.Explanation II. - " courier agency" shall mean any agency engaged in door delivery of
time-sensitive documents, utilizing the services of a person, either directly or indirectly, to carry
such documents.Explanation III. - "electronic mail" shall include e-mail or facsimile
transmission.(2)Every such bill shall specify the particulars of the tax and the period to which the
bill relates.
159. Regulations regarding payment and recovery of tax.
- To ensure payment and recovery of its tax dues, the Municipality shall, by regulations, provide
for-(a)issue of notice of demand, charging of notice fee, levy of interest of delayed payment at a rate
as may be specified, and the amount of penalty there for,(b)issue of warrant for attachment,
distress, and sale of movable property for recovery of tax dues,(c)attachment and sale of immovable
property for recovery of tax dues, and(d)recovery of dues from a person about to leave the municipal
area.
160. Requirement of payment of rent by occupier towards tax due on land or
building.
(1)For the purpose of recovery of property tax on any land or building from any occupier, the Chief
Municipal Executive Officer/ Municipal Executive Officer shall, notwithstanding anything contained
in any State law relating to premises tenancy or any other law for the time being in force, cause to be
served on such occupier a notice requiring him to pay to the Municipality any rent due, or falling
due, from him in respect of the land or the building to the extent necessary to satisfy the portion of
the sum due for which he is liable under the said section.(2)Such notice shall operate as an
attachment of such rent unless the portion of the sum due shall have paid and satisfied, and the
occupier shall be entitled to credit in account with the person to whom such rent is due, any sum
paid by him to the Municipality in pursuance of such notice:Provided that if the person to whom
such rent is due is not the person primarily liable for payment of the tax on land or building, he shall
be entitled to recover from the person primarily liable for payment of such tax any amount for which
credit is claimed.(3)If any occupier fails to pay to the Municipality any rent due or falling due which
he has been required to pay in pursuance of a notice served upon him as aforesaid, the amount of
such rent may be recovered from him by the Municipality as an arrear of tax under this Act.
161. Recovery of property tax on land and building or any other tax or charge
when owner of land or building is unknown or ownership is disputed.
(1)If any money is due under this Act from the owner of any land or building on account of tax on
such land or building or any other tax, expense or charge recoverable under this Act, and if the
owner of such land or building is unknown or the ownership thereof is disputed, the Municipal
Executive Officer may publish twice, at an interval of not less than two months, a notification of
such dues interval of not less than two months, a notification of such dues and of sale of such land or
building for realization thereof, and may, after the expiry of not less than one month from the date
of last publication of such notification, unless the amount recoverable last publication of suchArunachal Pradesh Municipal Act, 2007

notification, unless the amount recoverable is paid, sale such land or building by public auction to
the highest bidder, who shall deposit, at the time of sale, twenty-five per cent of the purchase
money, and the balance thereof within thirty days of the date of sale. Such notification shall be
published in the Official Gazette and in local newspapers and by displaying on the land or the
building concerned.(2)After deducting the amount due to the Municipality as aforesaid, the surplus
sale proceeds, if any, shall be credited to the Municipal Fund and may be paid, on demand, to any
person who establishes his right thereto to the satisfaction of the Chief Municipal Executive Officer/
Municipal Executive Officer or a court of competent jurisdiction.(3)Any person may pay the amount
due at any time before the completion for the sale, whereupon the sale be abandoned. Such person
may recover such amount by a suit in a court of competent jurisdiction from any person beneficially
interested in such land or building.
162. Power of Chief Municipal Executive Officer/ Municipal Executive Officer
to prosecute or serve notice of demand.
(1)When any sum is due from any person on account of -(a)tax on advertisements other than the
advertisements published in newspapers, or(b)any other tax, fee or charge leviable under this Act,
the Chief Municipal Executive Officer/ Municipal Executive Officer may either prosecute such
person, if prosecution lies under the provisions of this Act, or cause to be served on such person a
notice of demand in such Form as may be specified by regulations or in such other Form as the Chief
Municipal Executive Officer/ Municipal Executive Officer may deem fit.(2)The provisions of section
159 shall apply mutantes mutandis, to every such recovery of sum due.
163. Cancellation of irrecoverable dues.
- The Municipality may, by order, strike off the books of the Municipality at any sum due on account
of the property tax or any other tax or on any other account which may appear to it to be
irrecoverable.B. Recovery of Tax on Lands or Buildings by person Primarily Liable to Pay to the
Municipality
164. Apportionment of property tax on lands and buildings by person
primarily liable to pay.
(1)Save as otherwise provided in this Act, the person primarily liable to pay the property tax in
respect of any land or building may recover,-(a)if there be but one occupier of the land or the
building, from such occupier half of the tax so paid, and, if there be more than one occupier, from
each occupier half of such sum as bears to the entire amount of tax so paid by the owner the same
proportion as the value of the portion of the land or the building in the occupation of such occupier
bears to the entire value of such land or building :Provided that if there be more than one occupier,
such half of the amount may be apportioned and recovered from each such occupier in such
proportion as the annual value of the portion occupied by him bears to the total annual value of such
land or building; and(b)the entire amount of the surcharge on the property tax on any land or
building from the occupier of such land or building who uses it for commercial or non-residentialArunachal Pradesh Municipal Act, 2007

purposes :Provided that if there is more than one occupier, the amount of surcharge on the property
tax may be apportioned and recovered from each such occupier in such proportion as the annual
value of the portion occupied by him bears to the total annual value of such land or
building.(2)Notwithstanding anything contained in sub-section (1), if, as a result of the
determination of the annual value of any land or building and the imposition of the property tax
thereon under this Act for the first time, there is an increase in the amount of tax payable in respect
of such land or building from the amount of tax previously payable under this chapter, the person
primarily liable to pay the property tax may recover the difference in the amount due to such
increase from the occupier of such land or building.
165. Mode of recovery.
- If any person primarily liable to pay any property tax on any land or building or surcharge thereon
is entitled to recover part of such property tax or surcharge thereon from an occupier of such land or
building, he shall have for recovery thereof the same rights and remedies as if such part of the
property tax or the surcharge thereon were rent payable to him by such occupier.Chapter-XX
Commercial Projects
166. Commercial projects and receipts there from.
- The Municipality may, either on its own or through public or private sector agencies, undertake the
planning, construction, operation, maintenance or management of commercial infrastructure
projects, including district centers, bus or truck terminals and tourist lodges with commercial
complexes and any other type of commercial projects on commercial basis.Urban Environmental
Infrastructure and ServicesChapter-XXI Private Sector Participation Agreement and Assignment to
other Agencies
167. Undertaking of project by Municipality or by other agency.
- Notwithstanding anything contained elsewhere in this Act, but subject to the provisions of any
State law relating to planning, development, operation, maintenance and management of municipal
infrastructure and services, a Municipality may, in the discharge of its functions specified in section
47, section 48, and section 49,-(a)promote the undertaking of any project for supply of urban
environmental infrastructure or services by participation of a company, firm, society, trust or any
body corporate or any institution, or Government agency or any agency under any other law for the
time being in force, in financing, construction, maintenance and operation of such project of a
Municipality irrespective of its cost,(b)consider and approve the undertaking of any project relating
to urban environmental infrastructure or services by a company, or firm, or society, or body
corporate in terms of a private sector participation agreement or jointly with any such agency,
and(c)consider and approve the undertaking of any project relating to urban environmental
infrastructure or services by any institution, or Government agency under any other law for the time
being in force, or jointly with any such agency.Arunachal Pradesh Municipal Act, 2007

168. Types of private sector participation Agreements.
(1)Private sector participation agreements shall be such as may be prescribed.(2)Without prejudice
to the generality of the foregoing provisions of this section, such agreements include the
following:(a)Build-Own-Operate-Transfer Agreement,(b)Build-Own-Operate-Maintain
Agreement,(c)Build and Transfer Agreement,(d)Build-Lease-Transfer
Agreement,(e)Build-Transfer-Operate Agreement,(f)Lease and Management
Agreement,(g)Management Agreement,(h)Rehabilitate-Operate-Transfer
Agreement,(i)Rehabilitate-Own-Operate-Maintain Agreement,(j)Service Contract Agreement,
and(k)Supply-Operate-Transfer agreement.
169. Functions assigned to Municipality or other agencies.
- In the discharge of its obligations for providing urban environmental infrastructure and services in
relation to water- supply, drainage and sewerage, solid waste management, communication systems
and commercial infrastructure, the Municipality may, wherever considered appropriate in the public
interest,-(a)discharge any of its obligations on its own, or(b)enter into any private sector
participation agreement.Chapter -XXII Water-SupplyA. General
170. Definitions.
- In this chapter, unless the context otherwise requires -(1)"communication pipe" means-(a)where
the premises supplied with water abutts on the part of the street in which the main is laid, and the
service pipe enters those premises otherwise than through the outer wall of a building, abutting on
the street and has a stopcock placed in those premises and as near to the boundary of that street as
is reasonably practicable, so much of the service pipe as lies between the main and such stopcock,
and(b)in any other case, so much of the service pipe as lies between the main and the boundary of
the street in which the main is laid, and includes the ferrule at the junction of the service pipe with
the main, and also includes, -(i)where the communication pipe ends at a stopcock, such stopcock,
and(ii)any stopcock fitted on the communication pipe between the end thereof and the
main;(2)"main" means a pipe laid by the Municipality for the purpose of giving a general supply of
water as distinct from a supply to individual consumers, and includes any apparatus used in the
connection with such pipe;(3)"service-pipe" means so much of any pipe for supplying water from a
main to any premises as is subject to water-pressure from that main, or would be so subject but for
the closing of any tap;(4)"supply-pipe" means so much of any service pipe as is not a communication
pipe;(5)"trunk-main" means a main constructed for the purpose of conveying water from a source of
supply to a filter or reservoir or from one filter or reservoir to another filter or reservoir, or for the
purpose of conveying water in bulk from one part of the limits of supply to another part of such
limits, or for the purpose of giving, or taking, a supply of water in bulk;(6)"water-fittings" includes
pipes (other than mains), taps cocks, valves, ferrules, meters, cisterns, baths and other similar
apparatus used in connection with the supply and use of water.B. Functions in Relation to
Water-supplyArunachal Pradesh Municipal Act, 2007

171. Duty of Municipality to supply water.
(1)It shall be the duty of the Municipality to take steps, from time to time, either on its own or
through any other agency,-(a)to ascertain the sufficiency and wholesomeness of water supplied
within the municipal area,(b)to provide, or to arrange to provide, a supply of wholesome water in
pipes to every part of the municipal area in which there are houses, for domestic purposes of the
occupants thereof, and for taking the pipes affording that supply to such point or points as will
enable the houses to be connected thereto at a reasonable cost, so, however, that the Municipality
shall not be required to do anything which is not practicable at a reasonable cost or to provide such
supply to any part of the municipal area where supply is already available at such point or points,
and(c)to provide, as far as possible, supply of wholesome water otherwise than in pipes to every part
of the municipal area in which there are houses, for domestic purposes of the occupants thereof, and
to which it is not practicable to provide supply in pipes at a reasonable cost, and in which danger to
health may arise from the insufficiency or unwholesomeness of the existing supply and a public
supply is required and may be provided at a reasonable cost, and to secure that such supply is
available within a reasonable distance of every house in that part.(2)If any question arises under
clause (b) of sub-section (1) as to whether anything is or is not practicable at a reasonable cost or as
to the point or points to which pipes must be taken in order to enable houses to be connected to
such point or points at a reasonable cost, or, if any question arises under clause (c) of that
sub-section as to whether a public supply may be provided at a reasonable cost, such question shall
be decided by the Municipality.
172. Supply of water to connected premises.
(1)The Chief Municipal Executive Officer/ Municipal Executive Officer may, on an application by the
owner, lessee or occupier or any building, either on his own or through any other agency, arrange for
supply of water from the nearest main to such building for domestic purposes in such quantity as
may be deemed to be reasonable and may, at any time., limit the quantity of water to be supplied
whenever considered necessary:Provided that the Chief Municipal Executive Officer/ Municipal
Executive Officer may, by order in writing, delegate the responsibility of receiving the application to
any other agency.(2)For the water supplied under sub-section (1), payment shall be made at such
rate as may be fixed by the Municipal from time to time:Provided that such rate shall, as far as
practicable, cover the costs on account of management, operation, maintenance, depreciation, debt
servicing, and other charges related to waterworks and distribution costs, including
distribution-losses, if any.(3)A supply of water for domestic purposes shall be deemed not to include
a supply-(a)to any institutional building, assembly building, business building, mercantile building,
industrial building, storage building, or hazardous building, referred to in clause (2) of section 339,
or any part of such building, other than that used as a residential building, or educational building,
within the meaning of sub-clause (a), or sub-clause (b), of clause (2) of that section,(b)for building
purposes,(c)for watering roads and paths,(d)for purposes of irrigation,(e)for gardens, fountains,
swimming pools, or for any ornamental or mechanical purpose, or(f)for animals or for washing
vehicles where such animals or vehicles are kept for sale or hire.Arunachal Pradesh Municipal Act, 2007

173. Supply of water for non-domestic purposes.
(1)The Chief Municipal Executive Officer/ Municipal Executive Officer or the other agency, as the
case may be, may, on receiving an application, in writing, specifying the purpose for which the
supply of water is required and the quantity which is likely to be consumed, supply water for any
purpose other than domestic purpose, on such terms and conditions, including the condition of
withdrawal of water, as may be determined by regulations.(2)For the water supplied under
sub-section (1), payment shall be made at such rate as may be fixed by the Municipality from to
time.(3)The Chief Municipal Executive Officer/ Municipal Executive Officer may withdraw such
supply at any time, if he thinks it necessary so to do, in order to maintain a sufficient supply of water
for domestic purpose.
174. Provision of communication pipes and fittings.
(1)When an application under section 172 or section 173 has been received, all necessary
communication pipes and fittings shall be supplied by the Municipality or the other agency, as the
case may be, and the work of laying and connecting such communication pipes and fittings shall be
executed under the orders of the Chief Municipal Executive Officer/ Municipal Executive Officer or
the other agency, as the case may be.(2)The cost of making such connections and of such
communications pipes and fittings and of the work of laying and connecting such communication
pipes and fittings shall be paid by the owner or the person making such
application.(3)Notwithstanding anything contained in sub-section (1), the Chief Municipal
Executive Officer/Municipal Executive Officer may require any owner, or the person applying for
supply of water, to provide, to his satisfaction, all Communication pipes and fittings, and to carry
out at the owner's or the applicant's cost and under his supervision and inspection the work of
laying and connecting such communication pipes and fittings.(4)Where it is practicable of supply
water at a reasonable cost within the meaning of subsection(2)of section 171, the work relating to
making of connection and fixing of communication pipes and fittings shall be executed within a
period of one month from the date of receipt of the application referred to in sub-section (1).(5)The
cost recovered under this section for making connection and supplying communication pipes and
fittings shall be spent only on works relating to water-supply.
175. Water-supply through hydrants, stand posts and other conveniences.
(1)The Municipality may, in exceptional circumstances, either on its own or through other agency,
provide, free of cost, supply of wholesome water to the public within the municipal area and may,
for the said purpose, erect public hydrants or stand-posts or other conveniences.(2)The Municipality
may order the closure of a public hydrant, stand-post or other conveniences for reasons to be
recorded in writing.(3)The Municipality may either on its own or through other agency provide for
safety, maintenance and use of such public hydrants, stand-posts or other conveniences, subject to
such conditions as may be specified by regulations.Arunachal Pradesh Municipal Act, 2007

176. Provision for fire hydrants.
(1)The Chief Municipal Executive Officer/ Municipal Executive Officer shall, either on his own or
through other agency, fix hydrants on water-mains, other than trunk mains, at such places as may
be most convenient for affording supply of water for extinguishing any fire, and shall keep in good
order such hydrants, and may, from time to time, renew every such hydrant.(2)Letters, marks or
figures shall be displayed prominently on a wall, building or other structure near every such hydrant
to denote the situation of such hydrant.(3)As soon as the work relating to any hydrant is completed,
the Chief Municipal Executive Officer/ Municipal Executive Officer or the other agency, as the case
may be, shall deposit a key thereof at the nearest place where a public fire engine is kept and in such
other places as he may deem necessary.(4)The Chief Municipal Executive Officer/ Municipal
Executive Officer may, at the request and expense of the owner or the occupier of any building
referred to in clause (a) of sub-section(3)of section 172, which is situated in or near a street in which
a pipe, not being a trunk main, is laid, and being of sufficient dimensions to carry a hydrant, fix on
the pipe, and deep in good order, and, from time to time, renew, on or more fire hydrants as near to
such building as may be convenient, to be used only for extinguishing fire.(5)The Chief Municipal
Executive Officer/ Municipal Executive Officer shall allow any person to take water for
extinguishing fire from any pipe on which a hydrant is fixed without any payment.
177. Supply of water to areas outside municipal area.
(1)The Municipality may, subject to the satisfaction of the reasonable requirements of water within
the municipal area, supply water to a local authority or any person outside the municipal area, either
by itself of through any other agency.(2)The supply of water under sub-section (1) shall be at such
rate, not being less than the cost of production and delivery, including the costs of debt servicing,
depreciation of plant and machinery, distribution-loss, and other charges, if any, as the Municipality
may, from time to time, determine.C. Planning, Construction, Maintenance and Management of
Waterworks.
178. Public tanks, sub-soil water, etc. to vest in Municipality.
- Subject to the provisions of chapter XXI, all public tanks, reservoirs, cisterns, wells, tubewells,
aqueducts, conduits, tunnels, pipes, taps and other waterworks, whether made, laid or erected at the
cost met from the Municipal Fund or otherwise, and all bridges, buildings, engines, works, material
and things connected therewith, or appertaining thereto, and any adjacent land, not being private
property, appertaining to any such water-source, which are situated within the municipal area, shall
vest in the Municipality.
179. Vesting of sub-soil rights.
- All rights over the sub-soil water resources within the municipal area shall vest in the Municipality.Arunachal Pradesh Municipal Act, 2007

180. Works to be undertaken for supply of water.
- Subject to the provisions of section 10, for the purpose of providing the municipal area with proper
and sufficient supply of water for public and private uses, the Municipality, either on its own or
through any other agency,-(a)shall cause to be constructed or maintained such tanks, reservoirs,
engines, pipes, taps, and other water works as may be necessary, within or outside the municipal
area,(b)may purchase, or take on lease, any waterworks, or rights to store or to take and convey
water, within or outside the municipal area, and(c)may enter into any agreement with any person or
authority for the supply of water :Provided that the Municipal may, with the approval of the State
Government, make over to, or take over from, a statutory body any waterworks so as to do anything
which may be necessary or expedient for the purpose of carrying out its functions under this Act or
under any other law for the time being in force.
181. Management of water works.
- Subject to the provisions of chapter XXI, the Chief Municipal Executive Officer/ Municipal
Executive Officer shall, either on his own or through any other agency, manage all waterworks and
allied facilities belonging to the Municipality and shall maintain the same in good repair and
efficient condition and shall cause to be done, from time to time, all such things as shall be
necessary or expedient for improving such waterworks and facilities.
182. Purity of water for Domestic purpose.
(1)The Chief Municipal Executive Officer/ Municipal Executive Officer shall, either on his own or
through any other agency, at all times, ensure that the water in any waterworks belonging to the
Municipality, from which water is supplied for domestic purposes, is wholesome.(2)The
Municipality or the other agency, as the case may be, shall, when so required by any competent
authority under any law for the time being in force, arrange for the examination of water supplied
for human consumption for the purpose of determining whether the water is wholesome.
183. Water not to be wasted.
(1)No person, being the occupier of any premises to which water is supplied by the municipality or
any other agency, as the case may be, under this chapter, shall, on account of negligence or other
circumstances under the control of such occupier, allow the water to be wasted, or allow the pipes,
works or fittings for the supply of water in his premises to be out of repair causing thereby waste of
water.(2)No person shall unlawfully flood, or draw off, divert, or take water from, any waterworks
belonging to, or under the control of, the Municipality, or from any watercourse or stream by which
such waterworks is supplied.(3)Any person who contravenes the provisions of this section shall be
liable to such fine, not exceeding ten thousand rupees, as may be determined by regulations.D.
Tube-wells and WellsArunachal Pradesh Municipal Act, 2007

184. Prohibition regarding sinking of tube wells or digging of wells etc.
(1)No person shall, except with the prior permission , in writing of the Chief Municipal Executive
Officer/ Municipal Executive Officer, sink any tube-well or dig or construct any new well, tank,
pond, cistern or fountain in any municipal area.(2)The Chief Municipal Executive Officer/
Municipal Executive Officer may grant such permission, and may issue a licence for the purposes of
sub-section (1), on such conditions, and on payment of such annual fee, as the Municipality may,
from time to time, specify.(3)If any such work of sinking of tube-well has begun or completed
without such permission, the Municipal Executive Officer may, -(a)by notice, in writing, require the
owner or the other person, who has done such work to fill up or demolish such work, within such
time as may be specified in the notice, and if the work of filling up or demolition is not done within
the time so specified, cause the work to be done and realize the expenses therefore from the owner
or the person to whom such notice was given, or(b)grant permission to retain such work on such
terms and conditions as the Empowered Standing Committee may consider fit to impose.
185. Power to require filling up of wells.
- Whenever a supply of water has been provided in any municipal area, the Municipality may, by
notice, in writing, require the owner, lessee or occupier, as the case may be, of a well, tube-well, tank
or other water area, forming a part of any premises in such area, to fill up such well, tank or other
water area.
186. Power to set apart wells, tanks, etc. for drinking, culinary, bathing, and
washing purposes.
- The Empowered Standing Committee may, by order published at such places as it may think fit, set
apart any tank, well, spring or watercourse, or any part thereof, vested in the Municipality or, by an
agreement with the opener thereof, any private tank, well, spring or watercourse or part thereof,
subject to any right which such owner may retain with the consent of the Empowered Standing
Committee, for any of the following purposes, namely:-(a)supply of water exclusively for drinking or
for culinary purposes or for both, or(b)bathing, or(c)washing animals or clothes, or(d)any other
purpose connected with health, cleanliness or comfort of the inhabitants, and may, by like order,
prohibit bathing, or washing of animals or clothes or other things at any public place, not set apart
for such purposes, or prohibit any other act by which water in any public place may be rendered foul
or unfit for use, or provide for alternative facilities and conveniences to regulate the use of any tank,
well, spring or watercourse to promote public safety, health and welfare.E. Water-supply Mains and
Pipes
187. Power to lay mains, service pipes, etc.
(1)The Chief Municipal Executive Officer/ Municipal Executive Officer may, either on his own or
through any other agency, lay, whether within or outside the municipal area, a main, or such service
pipes with such stopcocks and other water fittings as he may deem necessary for supply of water toArunachal Pradesh Municipal Act, 2007

premises-(a)in any street, and(b)with the consent of every owner or occupier of any land not
forming part of a street, in, over or on that land, and may, either on his own or through any other
agency, from time to time, inspect, repair, alter, or renew or may, at any time, remove any such
main, or service pipes, so laid, whether under this section or under any other provision of this Act
:Provided that where a consent required for the purposes of this sub-section is withheld, the Chief
Municipal Executive Officer/ Municipal Executive Officer may, after giving the owner or the
occupier of the land a notice, in writing, of his intention so to do, either on his own or through any
other agency, lay the main or the service pipes, as the case may be, in, over or on that land without
such consent.(2)Where a service main or a service pipe has been lawfully laid in, over or on the land
not forming part of a street, the Chief Municipal Executive Officer/ Municipal Executive Officer or
any other agency appointed by him may, from time to time, enter upon that land and inspect, repair,
alter, renew or remove the pipe or lay a new pipe in substitution thereof, but shall pay compensation
for any damage done in the course of such action.
188. Prohibition for laying water pipes and construction of latrines and
Cesspools.
- Subject to such terms and conditions as may be provided by regulations from time to time, the
Chief Municipal Executive Officer/ Municipal Executive Officer shall have the power to
prohibit-(a)laying of ware-pipes in any place where water is likely to be polluted,(b)construction of
latrine or cesspool within six metres of any well, tank, water -pipe, or cistern, or(c)the use of water
from any polluted source of supply.
189. Power in relation to water-supply.
- The Chief Municipal Executive Officer/ Municipal Executive Officer may, subject to such terms
and conditions as may be specified by regulations from time to time, require-(a)the provision of
separate supply-pipes for each land or building or each storey of a building,(b)the owner of a land or
building, or the person primarily liable for payment of tax in respect of a land or building, having no
supply, or inadequate supply, of wholesome water for domestic purposes, to take supply of water
from the mains of the Municipality and to set up electric pumps for the purpose, and(c)the occupier
of any land or building to which water is supplied by the Municipality, to keep the supply-pipes in
efficient repair.
190. Power to turn off supply of water to premises.
(1)Notwithstanding anything contained in this Act, the Municipal Executive Officer may cut off the
connection between any waterworks of the municipality and any premises to which water is supplied
from such water-works, or may turn off such supply, in any of the following cases, namely :-(a)if the
person, whose premises are supplied with water, neglects to pay any sum payable under sub-section
(2) of section 172 or sub-section (2) of section 173, when due,(b)if, after receipt of a notice, in
writing, from the Chief Municipal Executive Officer/Municipal Executive Officer requiring him to
refrain from so doing, the owner or the occupier of the premises continues to use the water or toArunachal Pradesh Municipal Act, 2007

permit the same to be used in contravention of the provisions of this Act or the regulations made
there-under,(c)if the occupier of the premises contravenes the provisions of sub-section (3) of
section 172,(d)if the occupier refuses to admit any officer or other employee of the Municipality,
duly authorized in that behalf, into the premises for the purpose of making any inspection under this
Act or the regulations made there-under,(e)if the owner or the occupier of the premises willfully or
tap conveying water from any waterworks of the Municipality,(f)if any pipes, taps, works or fittings,
connected with the supply of water to the premises, be found, on examination by the Chief
Municipal Executive Officer/ Municipal Executive Officer, to be out of repair to such an extent as to
cause so serious a waste of water that, in his opinion, immediate prevention is necessary,(g)if the
use of the premises for human habitation has been prohibited under this Act,(h)if there is any
water-pipe situated within the premises to which no tap or other efficient means of turning off the
water-supply is attached, and(i)if, by reason of a leak in the service pipe or fitting, damage is caused
to any public street and immediate prevention is necessary:Provided that-(i)water-supply shall not
be cut off or turned off in any case referred to in clause (g) or clause (i), unless a notice, in writing, of
not less than seventy-two hours has been given to the occupier of the premises, and(ii)in the case
referred to in clause (f) or clause (i), the Chief Municipal Executive Officer/ Municipal Executive
Officer may carry out necessary repair to pipes, taps, works, or fittings and recover the expenses
thereof from the owner or the occupier of the premises.(2)The expenses of cutting-off water-supply
shall be paid by the owner or the occupier of the premises, as the case may be, and shall be
recoverable from such owner or occupier as an arrear of tax under this Act.F. Water Meters and
Recovery of Charges
191. Power to provide water meters and recover charges.
- The Municipality may, -(a)by regulations, specify the terms and conditions for-(i)provision of
water meters, either by itself or through an agent or by the owner or the occupier of any land or
building, and(ii)recovery of charges for supply of such water as recorded by water meters,
and(b)take necessary steps for detection and elimination of any fraud in respect of such water
meters.
192. Entrustment of operation and maintenance of water works and billing
and collection of charges.
- The Chief Municipal Executive Officer/ Municipal Executive Officer may, with the prior approval
of the Empowered Standing Committee, entrust the work of operation and maintenance of
waterworks in the municipal area and the work of billing and collection of water charges under any
law for the time being in force, on any private agency.G. Offence in Relation to Water-supply
193. Liability for offence in relation to water supply.
- If any offence relating to water-supply is committed under this Act in any premises connected with
the municipal waterworks, the owner, the person primarily liable for payment of property tax, and
the occupier of the said premises shall be jointly and severally liable for such offence.Chapter-XXIIIArunachal Pradesh Municipal Act, 2007

Drainage and SewerageA. Functions in Relation to Drainage and Sewerage
194. Municipality to provide drainage, sewerage and outfall.
- The Municipality shall, either on its own or through any other agency, construct and maintain
drains and sewers, and provide a safe and sufficient outfall, in or outside the municipal area, for
effectual drainage and proper discharge of storm- water and sewage of the municipal area in such
manner as may not cause any nuisance, whether by flooding any part of the municipal area, or of the
areas surrounding the outfall, or in any other way:Provided that no place, which has not been used
before the commencement of this Act for any of the purposes specified in this section, shall be so
used except-(i)in conformity with the provisions of any State law relating to land use planning or
any other law relating thereto for the time being in force or(ii)with the approval of the State
government, in the absence of any such law:Provided further that with effect from such date as may
be appointed by the State Government in this behalf, no sewage shall be discharged into any
watercourse until it has been so treated as not to affect prejudicially the purity and the quality of the
water of such water course.
195. Provision of means for disposal of sewage.
- For the purposes of receiving, treating, storing, disinfecting, distributing, or otherwise disposing of
sewage, the Municipality may, either on its own or through any other agency, construct, operate,
maintain, develop and manage any works within or outside the municipal area.B. Proprietary Rights
of Municipality In respect of Drains and Sewage Disposal Works
196. Vesting of public drains and sewage disposal works.
- Subject to the provisions of chapter-XXI,-(a)all public drains, all drains in, alongside or under any
public street, and all sewage disposal works, constructed or acquired out of the Municipal Fund or
otherwise, and all works, materials and things appertaining thereto, which are situated within or
outside the municipal area, shall vest in the Municipality,(b)for the purposes of laying, constructing,
enlarging, deepening or otherwise repairing or maintaining any such drain or sewage disposal
system, so much of the sub-soil appertaining thereto, as may be necessary for such purposes, shall
be deemed also to vest in the Municipality, and(c)all drains and ventilation shafts, pipes and all
appliances and fittings connected with the drainage works constructed, erected or set up of the
Municipal Fund in or upon premises, not belonging to the Municipality, whether-(i)before or after
the commencement of this Act, and(ii)for the use of the owner or the occupier of such premises or
not, shall, unless the Municipality has otherwise determined, or does at any time otherwise
determine, vest, and shall be deemed always to have vested, in the Municipality.Explanation. - All
public and other drains, which vest in the Municipality, are hereinafter referred to in this Act as
municipal drains.Arunachal Pradesh Municipal Act, 2007

197. Power to make over to, or to take over from, statutory authority drainage
and sewerage works.
- The Municipality may, with the prior approval of the State Government and subject to such
conditions as the Municipality may determine, make over to, or take over from, an authority under
any law for the time being in force any drain or dower or sewage disposal works for administration
and management thereof.C. Municipal Drains
198. Power of making drains.
(1)The Chief Municipal Executive Officer/ Municipal Executive Officer, or any other agency
authorized by him in this behalf, may carry any municipal drain through, across, or under, any
street, or any place laid out as, or intended for, a street or under any cellar or vault, which may be
under any street, and, after giving a reasonable notice in writing to the owner or the occupier
thereof, into through or under any land whatsoever within the municipal area, or, for the purpose of
out-fall or distribution of sewage, outside the municipal area.(2)The Chief Municipal Executive
Officer/ Municipal Executive Officer, or any other agency authorized by him in this behalf, may
construct any new drain in place of an existing drain or repair or alter any municipal drain so
constructed.
199. Sewage and rain water drains to be separated.
- For the purpose of effectual drainage of any premises in accordance with the provisions of this
chapter, it shall be competent for the Chief Municipal Executive Officer/ Municipal Executive
Officer, or any other agency authorized by him in this behalf, to require that there shall be one drain
for sewage, offensive matter and polluted water and an entirely separate drain for rain water or
unpolluted sub-soil water or both rain water and unpolluted sub-soil water, each emptying into
separate municipal drains or other suitable places.
200. Alteration, discontinuance, cleansing, etc., of drains.
- Subject to such terms and conditions as may be specified by regulations from time to time, the
Chief Municipal Executive Officer/ Municipal Executive Officer, or any other agency authorized by
him in this behalf, may -(a)enlarge, alter the course of, lessen, or arch over, or otherwise improve,
any municipal drain within the municipal area,(b)discontinue, close up, or destroy any such
drain,(c)properly flush, clean, and empty such drain, and(d)restrict throwing, emptying, or turning
into any municipal drain, or into any matter likely to damage the drain or interfere with the free
flow of its contents or affect prejudicially the treatment and disposal of its contents, or any
chemicals, refuse or waste steam, or any liquid which is dangerous or is the cause or a nuisance or is
prejudicial to health, or any petroleum Class 'A', petroleum Class 'B' or petroleum Class
'C'.Explanation - For the purposes of this section, the expression "petroleum Class 'A', "Petroleum
class 'B', Petroleum Class 'C''' shall have the same meaning as in the Petroleum Act, 1934.D. Drains
of Private Streets and Drainage of PremisesArunachal Pradesh Municipal Act, 2007

201. Powers in relation to drainage.
- Subject to such terms and conditions as may be specified by regulations from time to time, the
Chief Municipal Executive Officer/ Municipal Executive Officer, or any other agency authorized by
him in this behalf, may-(a)permit the owner or the occupier of any premises having a drain, or the
owner of a private drain, to have his drain made to communicate with the municipal drain for
discharge of foul water,(b)limit the use of the municipal drain by the owner or the occupier of any
premises having a private drain or the owner of a private drain,(c)require the owner of any land or
building, which is without sufficient means of effectual drainage, to construct a drain and to provide
all such appliances and fittings as may be necessary for drainage of such undrained land or
building,(d)require the group of owners of a block of premises, which may be drained more
economically or advantageously in combination than separately, to undertake at their own expense
any work necessary for drainage of such block of premises to be drained by a combined
operation,(e)require the owner of any land or building to carry out such construction, repair or
other work as may be necessary for effectual drainage of such land or building, or(f)authorize any
person who desires to drain his land or building into a municipal drain through a drain of which he
is not an owner, to use the drain or declare such person to be the joint owner thereof.
202. Premises not to be erected without drains.
(1)It shall not be lawful to erect or re-erect any premises in the municipal area or to occupy any such
premises unless-(a)a drain is constructed of such size, materials and description, at such level, and
with such fall, as may appear to the Chief Municipal Executive Officer/ Municipal Executive Officer
to be necessary for the effectual drainage of such premises,(b)there have been provided and set up
on such premises such appliances and fittings as may appear to the Chief Municipal Executive
Officer/ Municipal Executive Officer to be necessary for the purposes of gathering or receiving the
filth and other polluted and obnoxious matters, and conveying the same, from such premises and of
effectually flushing the drain of such premises and every fixture connected therewith.(2)The drain
so constructed shall empty into a municipal drain situated at a distance of not exceeding thirty
metres from the premises, but if no municipal drain is situated without such distance, then, such
drain shall empty into a cesspool situated within the distance to be specified by the Chief Municipal
Executive Officer/ Municipal Executive Officer for the purpose.E. Trade Effluent
203. Special provisions relating to trade effluent.
- Subject to the provisions of this Act and the regulations made thereunder and of any other law for
the time being in force, the occupier of any trade premises may, with the approval of the
Municipality or, so far as may be for the time being in force, without such approval, discharge into
the municipal drain any trade effluent proceeding from such premises.
204. Special provision regarding drainage of trade effluent.
- Special provisions regarding drainage of trade effluent. Notwithstanding anything contained inArunachal Pradesh Municipal Act, 2007

this Act or the regulations made thereunder or any usage, custom or agreement, where, in the
opinion of the Chief Municipal Executive Officer/ Municipal Executive Officer, any trade premises
are without sufficient means of effectual drainage and treatment of trade effluent or the drains
thereof, though otherwise not objectionable, are not adapted to the general drainage system of the
municipal area, or the effluent is not of specified purity, the Municipal Executive Officer may, by
notice, in writing, require the owner or the occupier of such premises-(a)to discharge the trade
effluent in such manner, at such times, through such drains, and subject to such conditions, as may
be specified in the notice, and to cease to discharge the trade effluent otherwise than in accordance
with the notice,(b)to purify the trade effluent before its discharge into a municipal drain and to set
up for purifying the trade effluent such appliances, apparatus, fittings and plants, as may be
specified in the notice,(c)to construct a drain of such material, size and description, and laid at such
level, and according to such alignment, and with such fall and outlet, as may be specified in the
notice,(d)to alter, amend, repair or renovate any purification plant, existing drain, apparatus,
plant-fitting or article used in connection with any municipal or house-drain.Chapter-XXIV Other
Provisions Relating to Water-Supply, Drainage and Sewerage
205. Connection with waterworks mains and drains not to be made without
permission.
- Without the permission, in writing, of the Chief Municipal Executive Officer/ Municipal Executive
Officer, no person shall, for any purpose whatsoever, at any time, make, or cause to be made, any
connection or communication with any waterworks or mains or drains constructed or maintained
by, or vested in, the Municipality.
206. Buildings, railways and private streets not to be erected or constructed
over water mains or on municipal drains without permission.
(1)Without the permission of the Chief Municipal Executive Officer/ Municipal Executive Officer, no
building, wall, fence or other structure shall be erected, and no railway or private street shall be
constructed or maintained by, or vested in, the Municipality.(2)If any building, wall, fence or other
structure is erected, or any railway or private street is constructed, on any drain or waterworks
without the permission as aforesaid, the Municipal Executive Officer may do good in such manner
as he may think fit.(3)The expenses incurred by the Chief Municipal Executive Officer/ Municipal
Executive Officer for carrying out the purposes of sub-section (2), shall be paid by the owner of the
private street or of the building, fence, wall or other structure or, as the case may be, by the railway
administration or the person responsible and shall be recoverable as an arrear of tax under this Act.
207. Railway administration to be informed in certain cases.
- If the Chief Municipal Executive Officer/ Municipal Executive Officer desires to place or carry, any
pipe or drain or to do any other work connected with water-supply or drainage across any railway
line, he shall inform the railway administration, who may execute the same at the cost of the
Municipality.Arunachal Pradesh Municipal Act, 2007

208. Chief Municipal Executive Officer/ Municipal Executive Officer not to
sanction building plan unless plan relating to water supply etc. is in
conformity with rules and regulations.
- Subject to the provisions of section 10, any building plan submitted to the Chief Municipal
Executive Officer/ Municipal Executive Officer for sanction shall conform to such rules or
regulations relating to water-supply, drainage, privy, urinal accommodation, within the premises,
and sewerage as may be made in this behalf, and no building plan shall be sanctioned by the Chief
Municipal Executive Officer/ Municipal Executive Officer unless it so conforms.
209. Maps of underground water supply pipes, drains, etc.
- Subject to the provisions of section 10 and section 325, the Chief Municipal Executive Officer/
Municipal Executive Officer shall cause to be maintained complete survey maps, drawings and
descriptions or water-supply mains, supply-pipes, municipal drains, sewers, and connections
thereto from all premises in the municipal area.
210. Rights of user of property for aqueducts, lines, etc.
(1)The Chief Municipal Executive Officer/ Municipal Executive Officer may, either on his own or
through any other agency authorized by him in this behalf, place and maintain aqueducts, conduits
and lines of mains or pipes or drains over, under, along, or across any immovable property, whether
within or outside the limits of the municipal area, without acquiring such immovable property, and
may, at any time, for the purpose of examining, repairing, altering or removing such aqueducts,
conduits or lines of mains or pipes or drains, after giving a reasonable notice of his intention to do
so , enter on any such immovable property over, under, along or across which the aqueducts,
conduits, or lines of mains or pipes or drains have been placed :Provided that the Municipality or
the other agency, as the case may be, shall not acquire any right, other than a right of a user, in such
property over, under, along or across which any aqueduct, conduit or line of mains or pipe or drain
is placed.(2)The powers conferred under sub-section (1) shall not be exercised in respect of any
property which is vested in the State Government or any local authority, or is under the control or
management of the Central Government or the railway administration, save with the permission of
the State Government or the railway administration, as the case may be, and in accordance with
such regulations as may be made in this behalf:Provided that the Chief Municipal Executive Officer/
Municipal Executive Officer may, without such permission, repair, renew or amend any existing
works, the character or position of which is not to be altered, if such repair, renewal or amendment
is urgently necessary in order to maintain, without interruption, the supply of water, drainage, or
disposal of sewage, or is such that any delay would be dangerous to health, human life or
property.(3)In the exercise of the powers conferred on the Chief Municipal Executive Officer/
Municipal Executive Officer by this section, he, or any other agency authorized by him in this behalf,
shall cause as little damage and inconvenience as may be possible, and shall make full compensation
for any damage or inconvenience caused by him.Arunachal Pradesh Municipal Act, 2007

211. Power of owner of premises to place pipes and drains through land
belonging to other persons.
(1)If it appears to the Chief Municipal Executive Officer/ Municipal Executive Officer that the only
or the most convenient means of water-supply to, and drainage of, any along or across the
immovable property of another person, the Chief Municipal Executive Officer/ Municipal Executive
Officer, may, by order in writing, authorize the owner of such premises to place or carry such pipe or
drain over, under, along or across such immovable property :Provided that before making any such
order, the Chief Municipal Executive Officer/Municipal Executive Officer shall give to the owner of
the immovable property a reasonable opportunity of showing cause, within such time as should not
be made :Provided further that the owner of the premises shall not acquire any right, other than the
right of a user, in such immovable property over, under, along or across which any such pipe or
drain is placed or carried.(2)Upon the order under sub-section (1), the owner of the premises may,
after giving a reasonable notice of his intention to do so, enter upon such immovable property with
assistants and workmen at any time between sunrise and sunset for the purpose of placing a pipe or
drain over, under, along or across such immovable property for the purpose of repairing such pipe
or drain.(3)In placing or carrying a pipe or drain under this section, as little damage as possible
shall be done to such immovable property, and the owner of the premises shall-(a)cause the pipe or
drain to be placed or carried with the least possible delay,(b)fill in reinstate and make good at this
own cost and with the least possible delay, land opened, broken up or removed for the purpose of
placing or carrying such pipe or drain, and(c)pay compensation to the owner of such immovable
property and to any other person, who sustains damage by reason of the placing or carrying of such
pipe or drain.(4)If the owner of such immovable property over, under, along or across which a pipe
or drain has been placed or carried under this section, while such immovable property was not built
upon, desires to erect any building on such immovable property, the Chief Municipal Executive
Officer/ Municipal Executive Officer shall, by notice, in writing, require the owner of the premises to
close, remove or divert the pipe or drain in such manner as shall be approved by him and to fill in,
reinstate and make good such immovable property as if his/her pipe or drain had not been placed or
carried over, under, along or across such immovable property:Provided that no action under this
sub-section shall be taken unless, in the opinion of the Chief Municipal Executive Officer/ Municipal
Executive Officer, it is necessary or expedient for the construction of the proposed building, or the
safe enjoyments thereof, that the pipe or drain should be closed, removed or diverted.
212. Power of the Chief Municipal Executive Officer/ Municipal Executive
Officer to affix shafts etc. for ventilation of drain or cesspool and testing of
drain.
- Subject to such terms and conditions as may be specified by regulations from time to time, the
Chief Municipal Executive Officer/ Municipal Executive Officer may, either on his own or through
any other agency, authorized by him in this behalf,-(a)erect upon any land or building, or affix to the
outside of any building, or to any tree, any shaft or pipe as may appears to him to be necessary for
the purpose of ventilating any drain or cesspool, whether vested in the Municipality or not,
and(b)examine the condition of a private drain or cesspool within the municipal area in respect ofArunachal Pradesh Municipal Act, 2007

which there is reasonable ground for believing that such private drain or cesspool is in such
condition as is prejudicial to health, or is a nuisance, by applying any test other than a test by water
under pressure, and if he deems it necessary, by opening the ground.
213. Power of the Chief Municipal Executive Officer/ Municipal Executive
Officer to execute work after giving notice to person liable.
(1)When, under the provisions of this Act, any person is required, or is liable, to execute any work in
relation to water-supply, drainage and sewerage within the municipal area, the Chief Municipal
Executive Officer/ Municipal Executive Officer may, in accordance with the provisions of this Act
and the regulations made thereunder, cause such work to be executed after giving such person an
opportunity of executing such work within such time as may be specified by him for this
purpose.(2)The expenses incurred or likely to be incurred by the Chief Municipal Executive Officer/
Municipal Executive Officer in connection with the maintenance of such work or enjoyment of
amenities and conveniences rendered possible by such work shall be payable by the person or
persons enjoying such amenities and conveniences.(3)The expenses referred to in sub-section (2)
shall be recoverable from the person or persons liable therefore as an arrear of tax under this Act.
214. Work to be done by licensed plumber.
(1)The Empowered Standing Committee may grant licence to any person possessing such technical
qualifications as may be determined by regulations to act as a licensed plumber.(2)No person, other
than a licensed plumber, shall execute any work described in chapter XXII, and chapter XXIII, and
in this chapter, and no person shall permit any such work to be executed except by a licensed
plumber:Provided that if, in the opinion of the Chief Municipal Executive Officer/ Municipal
Executive Officer, the work is of a trivial nature, he may grant permission in writing for the
execution of such work by a person other than a licensed plumber:(3)The Municipality shall, by
regulations, provide for-(a)the terms and conditions of engagement of such licensed
plumbers,(b)their duties and responsibilities, and guidelines for their functions,(c)the charges to be
paid to them for different types of works,(d)the hearing and disposal of complaints made by the
owners or occupiers of any premises with regard to their work, and(e)the suspension or cancellation
of such licence, in case of contravention of any such regulations by any such plumber, and
prosecution thereof under this Act.
215. Power of access to waterworks and drainage and sewerage installations.
(1)The Chief Municipal Executive Officer/ Municipal Executive Officer, or any other agency
authorized by him in this behalf, or any person appointed by the State Government in this behalf,
may, for the purpose of inspecting or repairing or executing any work in, upon or in connection
with, any waterworks at all reasonable times,-(a)enter upon, and pass through, any land within or
outside the municipal area, adjacent to, or in the vicinity of such waterworks, in whomsoever such
land may vest, and(b)convey into and through any such land all necessary materials, tools and
implements.(2)In the exercise of any power conferred by this section, as little damage as possibleArunachal Pradesh Municipal Act, 2007

may be done, and compensation for any damage which may be done in the exercise of any such
power shall be paid by the Chief Municipal Executive Officer/ Municipal Executive Officer, or any
other agency authorized by him in this behalf, or, if the person so appointed by the State
Government has caused the damage, by the State Government.
216. Prohibition of certain acts.
(1)No person shall-(a)willfully obstruct any person acting under the authority of the Chief Municipal
Executive Officer/ Municipal Executive Officer in setting out the lines of any works or pull up or
remove any pillar, post or shaft fixed in the ground for the purpose of setting out lines of such
works, or deface or destroy any works made for such purpose, or(b)willfully or negligently break,
damage, turn on, open, close, shut off, or otherwise interfere with, any lock, cock, value, pipe, meter
or other work or apparatus belonging to the Municipality, or(c)unlawfully obstruct the flow of, or
flush, draw off, or divert, or take water from, any waterworks belonging to the Municipality,
or(d)unlawfully obstruct the flow of, or flush, draw off, or divert, or take, sewage work belonging to
the Municipal or break or damage any electrical transmission line maintained by the Municipality,
or(e)throw any material including plastic bags and containers or waste of dairies, piggeries and
poultry farms into any municipal drain or sewer, or(f)obstruct any officer or other employee of the
Municipal in the discharge of his duties under chapter XXII and under this chapter or refuse, or
willfully neglect, to furnish him with the means necessary for the making of any entry, inspection,
examination or inquiry thereunder in relation to any water or sewage work, or(g)bathe in, at, or
upon, any waterworks, or wash or throw or cause to enter therein any animal, or throw any rubbish,
dirt or filth into any waterworks or wash or clean therein any cloth, wool or leather or the skin of any
animal, or cause the water of any sink or drain or any steam-engine or boiler or any polluted water
to turn, or to be brought, into any waterworks, or do any other act, whereby the water in any
waterworks is fouled or is likely to be fouled.(2)Nothing in clause (b) of sub-section (1) shall apply to
a consumer closing the stopcock fixed on the service pipe supplying water to his premises so long as
he has obtained the consent of any other consumer whose supply will be affected thereby.
217. Sewerage charge and sewerage cess.
(1)The Municipality shall levy sewerage charge on the owners of premises for connection of such
premises to sewerage mains, such amount being not less than one-half of the amount chargeable for
water-supply under sub-section (2) of section 172 or water-supply under sub-section (2) of section
173, as the case may be, as may be determined by regulations from time to time.(2)Where the owner
of any premises in a locality where sewer is laid by the Municipality has not taken connection from
the sewerage mains, he shall be liable to pay a sewerage cess of such amount, not being more than
one-half of the amount chargeable as sewerage charge under sub-section (1), as may be determined
by regulations from time to time.(3)Where the owner fails to pay the sewerage charge or sewerage
cess, such sewerage charge or sewerage cess, as the case may be, shall be realized from the occupier,
and the occupier shall be entitled to recover the amount from the owner.(4)The connection of
premises to sewerage mains shall be provided within a period of thirty days from the date of receipt
of an application in this behalf from the owner of the premises.(5)The charges received by the
Municipality from the owner or the occupier for connecting the premises to sewerage system may beArunachal Pradesh Municipal Act, 2007

such, as may be determined by regulation.
218. Entrustment of operation and maintenance of sewerage works and
billing and collection of Sewerage charges.
- The Chief Municipal Executive Officer/ Municipal Executive Officer may, with the prior approval
of the Empowered Standing committee, entrust the work of operation and maintenance of sewerage
works in the municipal area and the work of billing and collection of sewerage charge or sewerage
cess to any agency under any law for the time being in force or any private agency.
219. Power of the State Government to exercise control over imperfect,
inefficient or unsuitable waterworks, drainage works or sewerage works.
(1)If, at any time, it appears to the State Government that any waterworks, or drainage works, or
sewerage works executed by, or vested in, the Municipality, are maintained, or worked, or run in an
imperfect, inefficient or unsuitable manner, the State Government may, by an order, in writing,
direct the municipality to show cause within the period specified in the order why the waterworks,
the drainage works or the sewerage works, as the case may be, with all plants, fittings and
appurtenances thereof should not be handed over to the control and management of any agency
belonging to the State Government or any authority under any law for the time being in force, as
may be specified in the order.(2)If no cause is shown to the satisfaction of the State Government
within the period specified in the order referred to in sub-section (1), or the cause shown appears to
be untenable, the State Government may, by order, in writing, direct that the waterworks, the
drainage works or the sewerage works, as the case may be,(29 of 86) with all plants, fittings and
appurtenances thereof shall be handed over, for such period as it may fix, to the control and
management of such persons, or agency, or authority, and on such terms and conditions, as the
State Government may determine.(3)During the period fixed under sub-section (2), the complete
control and management of such waterworks, drainage works or sewerage works, as the case may
be, shall vest in the person, or the agency, or the authority so appointed who shall engage such
establishment for the purpose of maintaining and working of such waterworks, drainage works or
sewerage works, as the case may be, as the State Government may from time to time determine; and
such establishment may include the employees of the Municipality who were employed, or have
been employed, in the maintenance or working of such waterworks, drainage works or sewerage
works.(4)The cost of such establishment, including costs of all materials, implements and stores,
shall be paid from the Municipal Fund within such period as may be fixed by the State Government.
220. Municipal Water-supply, Drainage and Sewerage Code.
(1)The Municipality shall prepare and maintain a Code to be called the Municipal Water-supply,
Drainage and Sewerage Code which shall include such regulations as may be made from time to
time relating to the construction, maintenance, repair and alteration of waterworks, water-supply
mains, supply-pipes, drains, sewers, privies and urinals, cesspools, and appurtenances thereof and
other matters under chapter XXII or chapter XXIII or this chapter.(2)Such regulations shall provideArunachal Pradesh Municipal Act, 2007

for inspection of premises by the Chief Municipal Executive Officer/ Municipal Executive Officer, or
any other officer, or any other agency, authorized by him in this behalf, as the case may be, to
ascertain compliance with the provisions of this Act and the rules the regulations made
thereunder.Chapter-XXV Solid WastesA. Functions in Relation to Solid Wastes Management
221. Duty of Municipality in respect of solid wastes management and
handling.
- Subject to the Provisions of section 10, the Municipality shall, within the municipal area, be
responsible for implementation of the rules made by the Central Government in exercise of the
powers conferred by the Environment (Protection) Act, 1986,() to regulate the management and
handling of municipal solid wastes and for development of any infrastructure for collection, storage,
transportation, processing and disposal of such solid wastes.
222. Entrustment of management and handling of solid wastes and billing
and collection of charge.
- Notwithstanding anything contained elsewhere in this Act, for the purposes of management and
handling of municipal solid wastes and for development of infrastructure, if any, for collection,
storage, transportation, processing and disposal of such solid wastes, a charge shall be levied, and
payment thereof shall be made, at such rate as the Municipality may fix from time to time:Provided
that the charge as aforesaid shall, as far as practicable, be such shall cover the costs on account of
management and handling of municipal solid wastes and development of infrastructure, if any, for
collection, storage, transportation, processing and disposal thereof and also the costs of
debt-servicing, depreciation of plant and machinery, and other charge, if any:Provided further that
the Chief Municipal Executive Officer/ Municipal Executive Officer may, with the prior approval of
the Empowered Standing Committee, entrust development of infrastructure for collection, storage,
transportation, processing and disposal of solid wastes and the work of management and handling
of municipal solid wastes and of billing and collection of the charges as aforesaid to any agency
under any law for the time being in force or to any other agency.
223. Functions of Municipality.
- Subject to the provisions of section 10, the Municipality shall, either on its own or through any
other agency authorized by it in this behalf,-(a)organize collection of municipal solid wastes through
any of the methods, like community bin collection (central bin),house-to- house collection, and
collection on regular preinformed times and schedules,(b)devise collection of wastes from slums and
squatter areas or other localities including hotels, restaurants, office complexes and commercial
areas,(c)remove at regular intervals all solid wastes so collected under clause (a) and clause (b) for
disposals on daily basis, and(d)arrange for making use of biodegradable wastes from vegetable
markets in an environmentally acceptable manner.Arunachal Pradesh Municipal Act, 2007

224. Solid wastes to be property of Municipality.
- All solid wastes deposited in public receptacles, depots and places provided or appointed under
section 225 and all solid wastes collected by the municipal employees or contractors or any other
agency authorized in this behalf shall be the property of the Municipality.
225. Appointment of places for disposal and final disposal of solid wastes.
- The Municipality may, either on its own or through any other agency, cause the solid wastes to be
disposed of at such place or places within or outside the municipal area, and in such manner, as it
considers suitable:Provided that no place which has not been used before the commencement of this
Act for the purpose specified in this section, shall be so used, except-(i)in conformity with the
provisions of any State law relating to development planning and land use control or any other law
relating thereto for the time being in force, or(ii)in the absence of any such law, with the approval of
the State Government:Provided further that the solid wastes shall not be finally disposed of in any
manner which the State Government may think fit to disallow.B. Collection and Removal of Solid
Wastes
226. Duty of owners and occupiers of premises to store solid wastes at
source of generation.
- It shall be the duty of the owners and the occupiers of all lands and buildings in the municipal
area-(a)to have the premises swept and cleaned on a regular basis,(b)to provide for separate
receptacles or disposal bags for the storage of-(i)organic and bio- degradable wastes,(ii)recyclable or
non- biogradable wastes, and(iii)domestic hazardous wastes,So as to ensure that these different
types of wastes do not get mixed,(c)to keep such receptacles in good condition and order, and(d)to
cause all such wastes, including rubbish, offensive matter, filth, trade refuse, carcasses of dead
animals, excrementitious matters, bio-medical wastes and other polluted and obnoxious matters to
be collected from their respective premises and to be deposited in community bins or receptacles at
such times and in such places as the Municipal Executive Officer may, be notice, specify.
227. Duty of Cooperative Housing society, Apartment owners' association,
etc.
- It shall be the duty of the managements of co-operative housing societies, apartment owners'
associations, residential and non-residential building complexes, educational building, institutional
building, assembly buildings, business buildings, mercantile buildings, industrial buildings, storage
buildings, and hazardous building to provide at their premises community bins or disposal bags of
appropriate size as may be specified by the Municipality for temporary storage of wastes (other than
recyclable wastes), hazardous wastes, and bio-medical wastes for their subsequent collection and
removal by the Municipality:Provided that a separate community bin shall be provided for the
storage of recyclable wastes where door to door collection is not made.Arunachal Pradesh Municipal Act, 2007

228. Prohibitions.
- No person and owner or occupier of any land or building shall-(a)litter or deposit at any public
place any solid waste,(b)deposit building rubbish in or along any public street, public place or open
land,(c)allow any filthy matter to flow on public places, or(d)deposit or otherwise dispose of the
carcass or any part of any dead animal at a place not provided or appointed for such purpose.
229. Punishment for littering on street and depositing or throwing any solid
waste.
(1)Whoever litters any street or public place or deposits or throws or causes or permits to be
deposited or thrown any solid waste or building rubbish at any place in contravention of the
provisions of this Act, or permits the flow of any filthy matter from his premises, shall be punished
on the spot with a fine, being not less than one hundred rupees, as may be determined by
regulations from time to time.(2)Such spot fines may be collected by officers, not below the rank of a
sanitary inspector, duly authorized by the Municipality in this behalf.
230. Bio-medical wastes.
- It shall be the duty of the Municipality, either on its own or through any other agency authorized
by it in this behalf, to implement the provisions of the rules made by the Central Government in
exercise of the powers Conferred by the Environment (Protection ) Act, 1986, to regulate the
management and handling of bio-medical wastes to the extent such rules apply to the Municipality.
231. Hazardous wastes.
- It shall be the duty of the Municipality, either on its own or through any other agency authorized
by it in this behalf, to implement the provisions of the rules made by the Central Government in
exercise of the powers conferred by the Environment ( Protection ) Act, 1986, to regulate the
management and handling of hazardous wastes to the extent such rules apply to the
Municipality.Chapter-XXVI State Municipal Regulatory Commission
232. Definitions.
- In this chapter, unless the context otherwise requires,-(a)"Chairperson" means the Chairperson of
the State Commission;(b)"High Court" means the High Court of the State;(c)"Member" means a
member of the State Commission, and includes the Chairperson, and a member of a regional branch
of the State Commission;(d)"State Commission" means the Municipal Regulatory Commission
constituted under sub-section (1) of section 233.Arunachal Pradesh Municipal Act, 2007

233. Constitution and incorporation of State Commission.
(1)The State Government shall, within three months from the date of commencement of this Act, by
notification, constitute a State commission to be known as the Arunachal Pradesh Municipal
Regulatory Commission to exercise the powers conferred on, and to perform the functions assigned
to, it under this Act.(2)The State Commission shall be a body corporate, having perpetual succession
and a common seal, and shall have the power to acquire, hold and dispose of property, both movable
and immovable, and to contract and shall, by the name as aforesaid, sue or be sued.(3)The head
office of State commission shall be at such place as the State Government may, by notification,
specify.(4)The State Commission shall consist of such members including the chairperson, being not
more than five, as the State Government may determine:Provided that the State Government may
establish one or more regional branches of the State Commission for such area or areas as the State
Government may determine, and each such regional branch shall have not less than two and not
more than three members.(5)The Chairperson and the other members shall be persons of ability,
integrity and standing who have adequate knowledge of, and have shown capacity in dealing with
problems relating to, urban affairs, municipal finance, economics, engineering, law or
management:Provided that the members of a regional branch of the State Commission for an area
shall be persons having adequate knowledge of that area.(6)The Chairpersons and the other
members shall be appointed by the State Government on the recommendation of the Selection
Committee constituted under section 234.(7)Notwithstanding anything contained in sub-section (5)
or sub-section (6), the State Government may appoint any person as the Chairperson from amongst
the persons who are or have been the judges of the High Court:Provided that no such appointment
shall be made except in consultation with the Chief Justice of the High Court;Provided further that
the State Government may appoint one of the members of a regional branch of the State
commission from amongst the persons who are or have been the District and Sessions
judges:Provided also that no such appointment shall be made except after consultation withChief
Justice of the High Court.(8)The Chairperson shall be the Chief Executive of the State
Commission.(9)The Chairperson or any other member shall not hold any other office.
234. Constitution of Selection Committee by State Government.
(1)The State Government shall, for the purposes of selection of members, constitute a Selection
committee consisting of-(a)a person, who has been the judge of the High Court, to be the
Chairperson, and(i)the Chief Secretary to the State Government, and(ii)an expert having not less
than ten years' experience in infrastructure finance, to be nominated by the state
Government;Provided that nothing contained in this sub-section shall apply to the appointment of a
person, who is or has been the judge of the High court, as the Chairperson.(2)No appointment of a
member shall be invalid merely by reason of any vacancy in the Selection committee.(3)The State
Government shall, within one month from the date of occurrence of any vacancy by reason of death,
resignation or removal, and six months before the superannuation, or the expiry of the term of
office, of a member, make a reference to the Selection committee for filing up of such
vacancy.(4)The Selection Committee shall finalize the selection of a member within one month from
the date of reference to it by the State Government.(5)Upon reference by the State Government, the
Selection Committee shall recommend a panel of two names for every vacancy in the office of aArunachal Pradesh Municipal Act, 2007

member.(6)Before recommending any person for appointment as a member, the Selection
Committee shall satisfy itself that such person does not have any financial or other interest which is
likely to affect prejudicially his function as a member.
235. Term of office, salary and allowances and other conditions of service of
Chairperson and other members.
(1)The Chairperson and the other members shall hold office as such for a term of five years from the
date of entering upon office, but shall not be eligible for re-appointment:(a)in the case of the
Chairperson, the age of sixty-five years, and(b)in the case of any other member, the age of sixty-two
years.(2)The salary and allowances payable to, and the other terms and conditions of service of, the
Chairperson and the other members shall be such as may be prescribed.(3)The salary and
allowances and the other terms and conditions of service of the chairperson or any other member
shall not be varied to his disadvantage.(4)The Chairperson and every other member shall, before
entering upon office, make, and subscribe to, an oath of office and of secrecy in such Form and
manner, and before such authority, as may be prescribed.(5)Notwithstanding anything contained in
sub-section (1) or sub-section (2), the chairperson or any other member may-(a)relinquish his office
by giving, in writing, to the Governor a notice of not less than three months; or(b)be removed from
his office in accordance with the provisions of section 236.(6)The Chairperson or any other member
ceasing to hold office as such shall be ineligible for further employment under the Central
Government or any State Government for a period of two years from the date from which he ceases
to hold such office, and shall not-(a)accept any commercial employment for a period of two years
from the date from which he ceases to hold such office, and(b)represent in any manner any person
before the State Commission or any similar Commission constituted by any other State
Government.Explanation. - For the purposes of this sub-section,-(i)"employment under the Central
Government or any State Government" shall include employment under a local authority or any
other authority within the territory of India or under the control of the central Government or a
State Government or under any corporation or society owned or controlled by the Central
Government or a State Government ;(ii)"commercial employment" shall mean employment in any
capacity under, or as agent of, a person engaged in any trading, or commercial, industrial, or
financial business, in any public utility undertaking, and shall include employment as a director of a
company or partner of a firm, and shall also include sitting up of practice, either independently or as
a partner of a firm or as an adviser or a consultant.
236. Removal of Chairperson and other members.
(1)Subject to the provisions of sub-section (3), the Chairperson or any other member shall only be
removed from his office by order of the Governor on the ground of proved misbehaviour after the
High Court, on reference being made to it by the Governor, has,on inquiry held in accordance with
such procedure as may be prescribed in that behalf by the High Court, reported that the member
ought, on such ground, to be removed.(2)The Governor may suspend the chairperson or any other
member in respect of whom a reference has been made to the High Court under sub-section (1) until
the Governor has passed orders on receipt of the report of the High Court on such
reference.(3)Notwithstanding anything contained in sub-section (1), the Governor may, by order,Arunachal Pradesh Municipal Act, 2007

remove from office the Chairperson or any other member, if he-(a)has been adjudged an insolvent,
or(b)has been convicted of an offence which, in the opinion of the State Government, involves moral
turpitude, or(c)has become physically or mentally incapable of action as a member, or(d)has
acquired such financial or other interest as is likely to affect prejudicially his functioning as a
member, or(e)has so abused his position as to render his continuance in office prejudicial to the
public interest.(4)Notwithstanding anything contained in sub-section (3), the Chairperson or any
other member shall not be removed from his office under this sub-section unless the High Court, on
a reference being made to it in this behalf by such procedure as may be prescribed in this behalf by
the High court, reported that the member ought, on such ground, to be removed.
237. Officers of State Commission and other staff.
(1)The State Commission may appoint a Secretary to exercise such powers, and perform such duties,
under the control of the Chairperson, as may be specified by regulations made by the State
Commission.(2)The State commission may, with the approval of the State Government, determine
the number, nature and categories of other officers and employees required to assist the State
commission in the discharge of its functions.(3)The salaries and allowances payable to, and the
other terms and conditions of service of, the secretary and the other officers and employees of the
State commission shall be such as may be determined by the State Commission by regulations with
the approval of the State Government.(4)The State Commission may appoint consultants to assist
the State Commission in the discharge of its functions on such terms and conditions as the State
Commission may, by order determine.
238. Functions of State Commission.
(1)Notwithstanding anything contained elsewhere in this Act, the State Commission shall discharge
the following functions, namely:-(a)to determine separately for each Municipality the rate at which
payment shall be made for water-supply under sub-section (2) of section 272 and sub-section (2) of
section 273,(b)to determine separately for each Municipality the sewerage charges on the owners of
premises for connection of such premises to sewerage mains under sub-section (1) of section
217,(c)to determine separately for each Municipality the rate or the principles for determination of
the amount of charges for solid waste management under clause (ii) of section 130,(d)to determine
separately for each Municipality the rate or the principles for determination of charges for any other
services,(e)to set standards for the provision of municipal services in the State including standards
relating to quality, continuity and reliability of such services,(f)to suggest avenues for participation
of private sector in the provision of municipal services,(g)to ensure a fair deal to the citizens,
and(h)to promote competition, efficiency and economy in the activities of the Municipalities in the
provision of municipal services.(2)Without prejudice to sub-section (1), the State Government may,
by notification, confer any of the following functions on the State commission, namely:-(a)to aid and
advise the State Government on any matter concerning the provision of municipal services in the
State and the formulation of State policies in this regard,(b)to collect and record information
concerning the provision of municipal services in the State,(c)to collect and publish data and
forecasts on the demand for, and the use of, municipal services in the State,(d)do adjudicate upon
the disputes and differences between any municipal authority and any suppliers of municipalArunachal Pradesh Municipal Act, 2007

services in the public or private sector on behalf of such municipal authority, or to refer such
matters for arbitration,(e)to co-ordinate with the environmental regulatory agencies and to evolve
policies and procedure for appropriate environmental regulation of municipal services, and(f)to aid
and advise the State Government on any other related matters referred to the State Commission by
the State Government.
239. The State Municipal Advisory Committee.
(1)The State commission may, by notification, constitute, with effect from such date as it may
specify in such notification, a Committee to be known as the State Municipal Advisory
Committee.(2)The State Municipal Advisory Committee shall consist of not more than twenty-one
members to represent the interest of commerce, industry, transport, agriculture, labour, consumers
of civic services, Municipalities, non-governmental organizations and academic and research bodies
in the municipal affairs sector.(3)The Chairperson and the other members shall be the ex-officio
Chairperson and the ex-officio members, respectively, of the State Municipal Advisory committee.
240. Objects and functions of the State Municipal Advisory Committee.
- The objects and functions of the State Municipal Advisory Committee shall be to advise the State
Commission on-(a)major questions of policy;(b)matters relating to quality, continuity and extent of
municipal services provided by the municipal authorities:(c)protection of consumers of municipal
services; and(d)improvement of overall standards of performance, efficiency and economy in the
provision of municipal services by municipal authorities.
241. Representation before State Commission.
- The State Commission shall authorize any person as it deems fit to represent the interest of the
consumers of municipal services in the proceedings before it.
242. Appeal to High Court in certain cases.
(1)Any person aggrieved by any decision or order of the State Commission may file an appeal to the
High Court.(2)Except as aforesaid, no appeal or revision shall lie to any Court from any decision or
order of the State Commission.(3)Every appeal under this section shall be preferred within sixty
days from the date of communication of the decision or order of the State Commission to the person
aggrieved by the said decision or order:Provided that High Court may entertain an appeal after the
expiry of the said period of sixty days, if it is satisfied that the aggrieved person had sufficient cause
for not preferring the appeal within the said period of sixty days.
243. Determination of rates of user charges by State Commission.
(1)Notwithstanding anything contained in any other law for the time being in force, the rates of user
charges referred to in section 238 shall be determined by the State Commission in accordance withArunachal Pradesh Municipal Act, 2007

the provisions of this Act and the rules and the regulations made thereunder.(2)The State
Commission shall determine by regulations separately for each Municipality the terms and
conditions of, and the rates for, user charges as aforesaid and, in doing so, shall be guided by the
following considerations, namely:-(a)that the rates progressively reflect the cost of supply of
municipal services at an adequate and improving level of efficiency,(b)the factors which would
encourage efficiency, economical use of resources, good performance, optimum investments and
other matters which the State Commission may consider appropriate;(c)that the interest of the
consumers of the municipal services are safeguarded and, at the same time, the consumers pay for
availing of the municipal services in a reasonable manner based on the average cost of such services;
and(d)the production, distribution, and supply of municipal civic services are conducted on
commercial basis.(3)The State Commission, while determining the user charges under this Act, shall
not have any undue preference for any Municipality but may differentiate between different
Municipalities, having regard to the population, density of population, revenue generation,
economic importance and the actual conditions obtaining in different municipal areas and the
managerial, technical, financial and organizational capacities of different Municipalities.(4)If the
State Government requires the grant of any subsidy to any consumer or class of consumers of
municipal services in the rates of user charges determined by the State Commission under this
section, the State Government shall pay the amount to compensate the Municipality or any other
agency affected by the grant of such subsidy in such manner as the State Commission may direct as
a condition for implementation of the subsidy provided by the State Government.(5)Where the State
Commission departs from any of the considerations specified in subsection(2), it shall record the
reasons in writing for such departure.
244. Budget of State commission.
- The State Commission shall prepare, in such Form, and at such time in each financial year, as may
be prescribed, its budget for the next financial year, showing the estimated receipts and expenditure
of the state Commission, and forward the budget to the State Government.
245. Accounts and audit of the State Commission.
(1)The State Commission shall maintain proper accounts and other relevant records and prepare an
annual statement of accounts in such Form as may be determined by the State Government in
consultation with the comptroller and Auditor- General of India.(2)The accounts of the State
Commission shall be audited by the Comptroller and Auditor- General of India at such intervals as
may be determined by him, and any expenditure incurred in connection with such audit shall be
payable by the State Commission to the Comptroller and Auditor-General of India.(3)The
Comptroller and Auditor-General of India and any person appointed by him in connection with the
audit of the accounts of the State Commission under this Act shall have the same rights and
privileges and authority in connection with such audit as the Comptroller and Auditor-General of
India generally has in connection with the audit of Government accounts and, in particular, shall
have the right to demand the production of books, accounts, connected vouchers and other
documents and papers and to inspect any of the offices of the State Commission.(4)The accounts of
the State Commission, as certified by the Comptroller and Auditor-General of India or any otherArunachal Pradesh Municipal Act, 2007

person appointed by him in this behalf, together with the audit report thereon shall be forwarded
annually to the State Government by the State Commission and the State Government shall cause
the audit report to be laid, as soon as may be after it is received, before State Legislature.
246. Annual report of the State Commission.
(1)The State Commission shall prepare every year in such Form, and within such time, as may be
prescribed; an annual report giving a summary of its activities during the previous year and copies
of the report shall be forwarded to the State Government.(2)A copy of the annual report received
under sub-section (1) shall be laid, as soon as may be after it is received, before the State Legislature.
247. Transparency in State commission.
- The State Commission shall ensure transparency while exercising the powers and discharging the
functions under this Act.
248. Directions by State Government.
(1)In the discharge of its functions, the State Commission shall be guided by such directions in
matters of policy involving public interest as the State Government may give to it in writing.(2)If any
question arises as to whether any such direction relates to a matter of policy involving public
interest, the decision of the State Government thereon shall be final.
249. Proceedings before State Commission.
- All proceedings before the State Commission shall be deemed to be judicial proceedings within the
meaning of section 193 and section 228 of the Indian Penal Code and the State Commission shall be
deemed to be a Civil Court for the purposes of section 345 and section 346 of the Code of Criminal
Procedure,1973,(2 of 1974).
250. Protection of action taken in good faith.
- No suit, prosecution or other legal proceeding shall lie against the State Government or the State
Commission or any officer of the State Commission for anything which is in good faith done or
intended to be done under this chapter or the rules or the regulations made thereunder.
251. Punishment for non-compliance of orders or directions under this Act.
- Whoever fails to comply with any order or direction given under this chapter within such time as
may be specified in the said order or direction or contravenes, or attempts to contravene, or abets
the contravention of, any of the provisions of this chapter or any rules or regulations made
thereunder shall be punishable with imprisonment for a term which may extend to six months or
with fine, which may extend to twenty-five thousand rupees, or with both, in respect of each suchArunachal Pradesh Municipal Act, 2007

offence, and, in the case of a continuing offence, with an additional fine which may extend to one
thousand rupees for every day during which the offence continues after conviction for the first such
offence.
252. Punishment for non-compliance of directions given by State
Commission.
(1)In case any complaint is filed before the State Commission by any person or if the State
Commission is satisfied that any person has contravened any directions issued by the State
Commission under this chapter, or the rules or the regulations made thereunder, the State
Commission may, after giving such person an opportunity of being heard in the matter, by order in
writing, direct that without prejudice to any other penalty to which he may be liable under this
chapter, such person shall pay, by way of penalty, a fine which shall not exceed twenty-five thousand
rupees for each such contravention and, in the case of a continuing continues after first such
contravention.(2)Any amount payable under this section, if not paid, may be recovered as an arrear
of land revenue.
253. Power of seizure.
- The State Commission or any officer, not below the rank of a Gazetted Officer, specially authorized
in this behalf by the State Commission may enter any building or place where the State Commission
has reason to believe that any document relating to the subject-matter of the inquiry may be found,
and may seize any such document or take extracts or copies therefrom, subject to the provisions of
section 100 of the Code of Criminal Procedure, 1973, in so far as it may be applicable .
254. Cognizance of offences.
- No Court shall take cognizance of an offence punishable under this chapter except upon a
complaint, in writing, made by the State Commission or by any officer duly authorized by the State
Commission in this behalf.
255. Inconsistency in laws.
- Nothing in this chapter or any rule or regulation made thereunder or any instrument having effect
by virtue of this chapter or the rule or the regulation made thereunder shall have effect in so far as it
is inconsistent with any provisions of the Consumer Protection Act, 1986.
256. Delegation.
- The State Commission may, by general or special order in writing, delegate to any member, or any
officer of the State Commission, or any other person, subject to such conditions, if any, as may be
specified in the order, such of its powers and functions under this chapter, except the power to
adjudicate disputes under clause (d) of sub-section 259, as it may deem necessary.Arunachal Pradesh Municipal Act, 2007

257. Overriding effect.
- Save as otherwise provided in section 255, the provisions of this chapter shall have effect
notwithstanding anything inconsistent therewith contained in any other law for the time being in
force.
258. Power of State Government to make rules.
(1)The State Government may, by notification, make rules to carry out the purposes of this
chapter.(2)In particular and without prejudice to the generality of the foregoing power, such rules
may provide for all or any of the following matters, namely:-(a)the salary, allowances and other
terms and conditions of service of the chairperson and the other members under sub-section (2) of
section 235;(b)the Form and the manner in which, and the authority before whom, the oath of office
and secrecy shall be subscribed under sub-section (4) of section 235;(c)the Form in which, and the
time at which, the State Commission shall prepare its budget under section 244;(d)the Form in
which the annual statement of accounts shall be prepared by the State Commission under
sub-section (1) of section 245;(e)the Form in which, and the time within which, the annual report
shall be furnished under sub-section (1) of section 246;(f)any other matter which may be, or is
required to be, prescribed by rules.
259. Power of State Commission to make regulations.
(1)The State Commission may, by notification, make regulations consistent with this Act and the
rules made thereunder to carry out the purposes of this Act.(2)In particular and without prejudice to
the generality of the foregoing power, such regulations may provide for all any of the following
matters, namely:-(a)the powers and the duties of the Secretary under sub-section (1) of section
237;(b)the salary and allowances and the other terms and conditions of service of the Secretary and
the other officers and other employees under sub-section (3) of section 237;(c)the terms and
conditions of appointment of consultants under sub-section (4) of section 237;(d)the manner in
which the rates of user charges shall be determined under section 243;(e)any other matter which
may be, or is required to be, provided by regulations.Chapter-XXVII Communication SystemsA.
Public Streets
260. Surface transport system and accessories.
- For the purposes of this Act,-(a)the surface transport systems shall include streets, roads,
footpaths, pedestrian pathways, parking areas, transportation terminals, both for passengers and
goods, bridges, sub-ways, over-bridges, ferries and inland water transport systems, and(b)the
transport system accessories shall includes traffic engineering schemes, street furniture, street
lighting, parking lots and bus stops.Arunachal Pradesh Municipal Act, 2007

261. Vesting of public street in Municipality.
(1)Subjects to the provisions of chapter XXI, all public streets and parking areas in any municipal
area including the soil, sub-soil, stones, other materials, side-drains, footpaths, pavements,
sub-ways and over-bridges and all erections, implements and trees and other things provided
therein, shall vest in the Municipality:Provided that no public street in the municipal area, which
immediately before the commencement of this Act vested in the State Government or in any
authority under any law for the time being in force, unless so directed by the authority competent to
take a decision in this behalf, vest in the Municipality by virtue of this sub- section.(2)The State
Government may, subject to such terms and condition as it may determine, by
notification-(a)transfer to any Municipality any public street or parking area belonging to it,
or(b)take over from any Municipality any public street or parking area, or(c)transfer such public
street or parking area, so taken over, to any authority under any law for the time being in force, or
any other agency, for a limited period for the purpose of proper maintenance and development of
such public street or parking area by such Municipality or the State Government or such authority
or agency, as the case may be.(3)The Chief Municipal Executive Officer/ Municipal Executive Officer
shall maintain a register, in such Form, and in such manner, as may be specified by regulations, and
such register shall separately include a list of all public streets vested in the Municipal or in such
authority or agency.(4)The Municipality may publish, in such From, and in such manner, as may be
provided by regulations, the contents of such register for sale to the public.
262. Functions of Municipality in respect of public streets etc.
(1)Subject to the provisions of section 10, the Municipality or any other agency, as the case may be,
shall cause all public streets, parking areas, squares, sub-ways or over-bridges vested in it to be
developed, maintained, controlled and regulated in accordance with the provisions of this Act and
the regulations made thereunder.(2)The Municipality or any other agency , as the case may be ,shall,
from time to time, cause all public streets vested in it to be leveled, metalled, paved, chandelled,
altered or repaired, and may widen extend or otherwise improve any such street or cause the soil
thereof to be raised, lowered or altered or may place and repair fences and guard- rails thereon for
the safety of pedestrians.
263. Power to make new public streets etc.
- Subject to the provisions of section 10, the Municipality or any other agency, as the case may be,
may, at any time,-(a)lay out and make new public streets, or(b)construct bridges or sub-ways,
or(c)turn or divert any existing public street, or(d)lay down and determine the position and
direction of a street or streets in any part of the municipal area notwithstanding that no proposal for
the erection of any building in its vicinity has been received, or(e)declare any street, made and duly
constructed under any scheme or any development or improvement scheme in pursuance of the
provisions of any law for the time being in force, to be a public street, or(f)declare any private street
to be a public street.Arunachal Pradesh Municipal Act, 2007

264. Minimum width of new public street.
- No new public street made, or declared as such, under this chapter, shall be less than ten metres in
width including the footpath:Provided that such width may be reduced by the Municipality in the
case of a class 'C' municipal area or a transitional area, for reasons to be recorded in writing, but the
width shall in no case be less than six meters.
265. Acquisition of lands and buildings for public streets, public parking
places and transportation terminals.
(1)The Municipality may, subject to the other provisions of this Act, require to be acquired-(a)any
land together with structure including building, if any, standing thereon for the purpose of
opening,widening, extending or otherwise improving any public street, parking or transportation
terminal, square, park or garden or making a new one or for enforcing the regular line of street,(b)in
relation to any land or any structure including building as aforesaid, such land or structure
including building as the Municipality may think expedient, outside the regular line or projected
regular line of the public street as aforesaid, and(c)any land for the purpose of laying out, or making
a public parking place.(2)Where any land or structure including building is required to be acquired
under sub-section (1) and the Municipality is satisfied that the remaining portion of the land will not
be suitable or fit for any beneficial use to the owner, it shall, at the request of the owner, proceed for
the acquisition, in addition, of such remaining portion of the land which shall, on acquisition, vest in
the Municipality.(3)Where any land or structure including building is required to be acquired under
sub-section (1) or sub-section (2), the procedure for such acquisition as provided in this Act shall
apply.
266. Permanent closure of public street.
(1)The Municipality may permanently close the whole or any part of a public street in the public
interest or for the purpose of carrying out the provisions of this Act:Provided that before closing
such public street, the Municipality shall, by notice published in such manner as may be provided by
regulations, give an opportunity to the residents likely to be affected by such closure to make
suggestions or objections, with respect to such closure, within one month from the date of
publication of the said notice, and shall consider all such suggestions, or objections.(2)Whenever
any public street or part thereof is permanently closed under sub-section (1), the site of such street
or any portion thereof may be disposed of as land vested in the Municipality.
267. Temporary closure of public street.
- The Chief Municipal Executive officer/ Municipal Executive Officer may temporarily close the
whole or any part of a public street to permit development and maintenance work, and may
authorize such closure for other purposes for any period not exceeding fifteen days.Arunachal Pradesh Municipal Act, 2007

268. Closure of public street for parking purposes and levy of parking fee.
(1)The Municipal may close any portion of a public street and declare it as a parking area.(2)Parking
fees at different rates for different types of vehicles, in different areas, for different times of the day,
and for different durations may be levied at such rates as may be determined by the Municipality by
regulations from time to time.
269. Rights of owners to require streets to be declared public.
(1)If any privates street has been leveled, paved, metalled, flagged, channeled, sewered, drained,
conserved, and lighted to the satisfaction of the Chief Municipal Executive Officer/Municipal
Executive Officer, he may, or on the requisition of a majority of the owners of such private street,
shall, declare such street to be a public street and, thereupon, the street shall vest in the
Municipality.(2)The Chief Municipal Executive Officer/ Municipal Executive Officer may, at any
time, by a notice fixed up in any street or part thereof, not maintainable by the Municipality, but
which has already been leveled, paved, metalled, flagged, channeled, drained, sewered, conserved
and lighted to his satisfaction, give intimation of his intention to declare such street or part thereof
to be a public street, and unless within thirty days of such notice, the owner or any one of the several
owners of such street or such part of a street, lodges objection thereto at the office of the
Municipality, the Chief Municipal Executive Officer/ Municipal Executive Officer may, by notice, in
writing, put up in such street or part thereof, declare such street or part thereof, as the case may be,
to be a public street vested in the Municipality.B. Traffic Engineering Schemes, Street Furniture,
Parking Lots and Bus Stops.
270. Traffic engineering schemes.
- The Municipality may, either on its own or through any other agency authorized by it in this
behalf, as and when necessary, having regard to the abutting land uses and traffic flow patterns,
implement traffic engineering schemes to ensure public safety, convenience and expenditure
movement of traffic including pedestrian traffic.
271. Street furniture and bus stops.
- Subject to the provisions of section 10, the Municipality shall, either on its own or through any
other agency authorized by it in this behalf, from time to time, cause various items of street
furniture including fences, guard-rails, traffic lights signs, street markings, median strips, bus stops
and any other item to be installed or done, and shall cause them to be maintained so as to ensure
public safety and convenience and expeditious movement of traffic including pedestrian traffic.C.
Street LightingArunachal Pradesh Municipal Act, 2007

272. Measures for lighting.
(1)The Chief Municipal Executive Officer/ Municipal Executive Officer shall, either on his own or
through any other agency:-(a)take measures for lighting, in a suitable manner, such public streets
and public places as may be specified by him,(b)procure, erect and maintain such number of lamps,
lamp-posts and other appurtenances as may be necessary for the purpose of lighting, and(c)cause
such lamps to be lighted by appropriate means.(2)The Chief Municipal Executive Officer/ Municipal
Executive Officer or any other agency may attach to the outside of any building brackets for lamps in
such manner as may not cause any injury or inconvenience thereto.Chapter-XXVIII Market,
Commercial Infrastructure and Slaughterhouses
273. Commercial Infrastructure.
- Subject to the provisions of chapter-XXI, the Municipality may, either on its own or through any
other agency authorized by it in this behalf, implement any scheme for construction, operation,
maintenance and management of commercial infrastructure including district centers,
neighborhood shopping centers, shopping malls and office complexes, and may rent out, lease or
dispose by outright sale, such commercial infrastructure or any part thereof.
274. Provision of municipal markets and slaughter houses.
(1)The Chief Municipal Executive Officer/ Municipal Executive Officer may, either on his own or
through any other agency, provide and maintain in the municipal area such number of municipal
markets, slaughterhouses or stockyards, as he thinks fit, together with stall, shops, sheds, pans and
other buildings and conveniences for the use of persons carrying on trade or business and may
provide and maintain in any such markets, buildings or other places, machines, weights, scales and
measures for the weighment or measurement of goods sold thereon.(2)Subject to such directions as
the Municipality may give in this behalf, the Chief Municipal Executive Officer/Municipal Executive
Officer or any other agency, as the case may be, may, after giving a notice, close any municipal
market or slaughterhouses or stockyard or any portion thereof on and from the date specified in the
notice, and the premises occupied for any municipal market, slaughterhouses or stockyard or any
portion thereof so closed may be disposed of as the property of the Municipality.
275. Use of municipal markets.
(1)No person shall, without the general or special permission, in writing, of the Chief Municipal
Executive Officer/ Municipal Executive Officer, sell, or expose for sale, any animal or article in any
municipal market within the municipal area.(2)Any person contravening the provisions of
sub-section (1) and any animal or article exposed for sale by such person may, by or under the order
of the Chief Municipal Executive Officer/ Municipal Executive Officer, be summarily removed from
the market by a police-officer or any officer or other employee of the Municipality authorized by the
Chief Municipal Executive Officer/ Municipal Executive Officer in this behalf.Arunachal Pradesh Municipal Act, 2007

276. Levy of stallage, rent and fee.
- Subject to such regulations as may be made from time to time, the Chief Municipal Executive
Officer/ Municipal Executive Officer, either on his own or through any other agency, as the case may
be, may charge stallage, rent or fee for the occupation or use of facilities in a municipal market or a
municipal slaughterhouses.Urban Environmental Management Community Health and Public
SafetyChapter - XXIX Local Agenda for Urban Environmental management
277. Duties of Municipality.
(1)Subject to the provision of section 10, and having regard to the linkages between urban economy,
infrastructure, productivity, poverty and environmental health in the municipal area, the
Municipality shall take adequate measures for -(a)management of urban environment,(b)measuring
quality of living and working environment,(c)monitoring of pollution levels and(d)undertaking
health risk assessment.(2)For carrying out the purposes of sub-section (1), the Municipality shall
involve such professional agencies and community based organization, either in the public sector or
in the private sector, as may be necessary, to -(a)carry out studies on vulnerability and risk
assessment,(b)enhance the capability of concerned municipal or other agencies through research
and training activities for better management of environment,(c)prepare environmental
management strategy and action plan, and establish adequate institutional framework for its
implementation, and(d)provide and manage environmental infrastructure services.
278. Function in relation to urban environmental management and
submission of report on environmental status of municipal area.
(1)Subject to the provision of section 10 and without prejudice to the generally of the provisions of
section 277, the Municipality shall, either by itself or through any other agency, undertake functions
relating to the following matters :-(a)supply of safe water,(b)low cost sanitation(c)environmentally
sound solid waste management,(d)toxic waste collection and disposal(e)waste recycling and
recovery(f)preservation of wetlands(g)control of air pollution,(h)control of sound
pollution,(i)control of cattle and other animal in the municipal area(j)area improvement and
resettlement,(k)promotion of urban agriculture and urban forestry(l)development of parks, gardens
and open spaces,(m)promotion of community awareness on environmental education and(n)such
other matters as the Municipality may consider necessary.(2)The Municipal Executive Officer shall
prepare and submit a report on the environmental status of the Municipal area at the time of
submission of the budgets estimates.
Chapter XXX
Environmental sanitation and community health
A. Duties and general powersArunachal Pradesh Municipal Act, 2007

279. Duties of Municipality for environmental sanitation.
- It shall be the duty of the Municipality or any other agency authorized by it in this behalf to take
adequate measures for each of the following matters, namely :-(a)inspection, supervision, regulation
and control of premises to ensure proper environmental sanitation,(b)regulation of public bathing
and washing(c)provision and maintenance of public conveniences,(d)licensing of animals and
control of stray animals(e)licensing of butchers and slaughterhouses and(f)control of nuisances.
280. Powers of the Chief Municipal Executive Officer/ Municipal Executive
Officer.
- Subject to such regulations as may be made in this behalf, the Chief Municipal Executive
Officer/Municipal Executive Officer may, either on his own or through any other agency authorized
by him in this behalf :-(a)cause any building or other premises to be inspected for the purpose of
ascertaining the sanitary condition thereof.(b)require the owner or the occupier of any land or
building or any part thereof.(c)issue such order as he deems necessary for the improvement of any
in-sanitary huts and sheds and untenanted premises which are likely to cause risk of diseases to the
inmates thereof or to the inhabitants of the neighborhoods or are, for any reason, likely to endanger
community health or safety,(d)by notice, prohibit the owner or the occupier from the cause of any
buildings, or any room in a building, which appears to him to be unfit for human habitations, as
dwelling or(e)direct the filling up of any well, pool, ditch, tank, pond, pit or undrained ground,
cistern or reservoir of any waste or stagnant water, which appear to him to be, or likely to become,
injurious to health or offensive to the neighborhood.
281. Power to regulate Excavation.
(1)The Chief Municipal Executive Officer/ Municipal Executive Officer may, by a general order, or
by a special order affecting such portion of the municipal area as may be specified therein,
prohibit-(a)the making of excavation for the purpose of taking earth therefrom or strong rubbish or
offensive matter therein or(b)the digging of cesspool, tanks, ponds, wells or pits, without his special
permission.(2)No persons shall make any excavation referred to in clause (a), or dig any cesspool,
tank, pond, well, or pit referred to in clause (b), of sub-section (1) in contravention of any such
order.(3)If any such excavation is made, or any such cesspool, tank, pond, well or pit is dug in
contravention of the order under sub-section (1), the Chief Municipal Executive Officer/Municipal
Executive Officer may, by notice, in writing, require the owner or the occupier of the land, on which
such excavation is made or such cesspool, tank, pond, well or pit is dug, to fill it up with earth or
other material approved by him.
282. Power to require trees, hedges etc. to be trimmed.
(1)The Chief Municipal Executive Officer/ Municipal Executive Officer may, if he thinks fit, by
notice, in writing, require the owner or the occupier of any land in the municipal area on which
trees, shrubs or hedges are growing to keep such tree, shrubs or hedge in a trim condition, andArunachal Pradesh Municipal Act, 2007

remove any such trees, shrubs and hedge, if it obstructs traffic on any street or poses a danger to
public safety or overhangs any street causing inconvenience or danger to the passer-by.(2)If it
appears to the Chief Municipal Executive Officer/ Municipal Executive Officer that immediate
action is necessary for public safety, he may, without notice as aforesaid cause such tree, shrub or
hedge to be removed from the land and the expenses thereof shall be paid by the owner or the
occupier of such land.B. Regulation of public bathing, washing etc.
283. Regulation of public bathing etc.
- The Chief Municipal Executive Officer/ Municipal Executive Officer may, by order -(a)regulate the
use by public of any river or other public place, whether vested in the Municipality or not, for
bathing or washing,(b)prohibit the use by the public of any lake, tank, reservoir, fountain, cistern,
duct, stand pipe, stream or well or any part of any river, whether vested in the Municipality or not,
for bathing or washing(c)prohibit steeping in any tank, reservoir, stream, well or ditch of any
animal, vegetable or mineral matter likely to render the water thereof offensive or dangerous to
health,(d)Prohibit bathing in any lake tank, reservoir, fountain, cistern, duct, stand-pipe, stream or
well by a person suffering from any contagious of infectious disease,(e)Prohibit any person engaged
in any trade or manufacture from causing to flow into any lake, tank, reservoir, cistern, well, duct or
other place for storage of water, whether vested in the Municipality or not, or drain or pipe
communicating therewith, any washing or other substance produced in the course of any such trade
or manufacture, or willfully do any act connected with any such trade or manufacture whereby such
water is likely to be fouled or corrupted or(f)Prohibit by notice, the washing of clothes by
washer-men in pursuance of their calling, except at such places as may be licensed for this
purpose.C. Public Conveniences
284. Public latrine and urinals.
(1)The Municipality shall, by itself or through any other agency, provide and maintain in proper and
convenient places a sufficient number of public latrines and urinals for use by the public.(2)Such
public latrines and urinals may be so constructed as to provide separate compartment for each
sex.D. General Provisions
285. Prohibition of nuisances.
- No person shall -(a)commit any nuisance in any public street or public place, or(b)unauthorized
affix upon any building, monument, post, well, fence, tree or other thing, any bill, notice or other
document, or(c)unauthorized deface, or write upon, or otherwise mark, any building, monument,
post, wall, fence, tree or other thing or(d)carry rubbish filth or other polluted and obnoxious matter
along any route in contravention of any prohibition made in this behalf by the Municipal Executive
Officer by notice or(e)bury or cremate or otherwise dispose of any corpses at a place not licensed for
the purpose or(f)disturb public peace or order in violation of sound pollution control order, if any
or(g)cause pollution of air in violation of air pollution control order, if any or(h)cause obstruction to
the movement of vehicular or pedestrian traffic without permission from the competent
authority.(2)Where the Chief Municipal Executive Officer/Municipal Executive Officer is of theArunachal Pradesh Municipal Act, 2007

opinion that there is a nuisance on any land or building, he may, by notice, in writing, require the
person by whose act, default or sufferance the nuisance arises or continues or all of the owners,
lessees or occupier of such land or building to remove or abate the nuisance by taking such measure,
in such manner, and within such period, as may be specified in the notice.(3)Where the Chief
Municipal Executive Officer/Municipal Executive Officer is of the opinion that immediate removal
of any nuisance continuing on any land or building in contravention of the provisions of this Act is
necessary, he may, for reasons to be recorded in writing, cause such nuisance to be removed
forthwith.
286. Control of pollution.
- Subject to the provisions of any law relating to air, water or noise pollution for the time being in
force and in accordance with any notification by the State Government in that behalf, the
Municipality may function as a competent authority for the enforcement of such law.
287. Power to require wells, tank etc. to be rendered safe.
- Where in any Municipal area, any well, tank, reservoir, pool, depression or excavation or any bank
or tree is, in the opinion of the Chief Municipal Executive Officer/ Municipal Executive Officer, in a
ruinous state for want of sufficient repairs, protection or enclosure and is a nuisance or is dangerous
to passers-by, the Chief Municipal Executive Officer/ Municipal Executive Officer may, by notice, in
writing, require the owner or the part-owner thereof, or failing any of them, the occupier thereof, to
repair, protect or enclose it in such manner as he thinks necessary, and if in the opinion of the Chief
Municipal Executive Officer/ Municipal Executive Officer, the danger is imminent, he shall
forthwith take such steps as he thinks necessary to avert such danger.
288. Quarrying, blasting, cutting timber or building operation.
- No person shall quarry, blast, cut timber, or carry on building operations in such manner as to
cause, or is likely to cause, danger to persons passing by, or dwelling or working in the
neighborhood.
289. Power to stop improper use of land or building.
- If, within any municipal area, any land or building, by reason of its being abandoned or
unoccupied :-(a)is in a filthy or unwholesome state or(b)has becomes a resort of -(i)Idle and
disorderly persons, or(ii)persons who have no ostensible means of subsistence or cannot give a
satisfactory account of themselves, or(c)is used for gambling or immoral purposes or(d)is likely to
occasion a nuisance.The Chief Municipal Executive Officer/ Municipal Executive Officer may, after
due enquiry, by notice, in writing, require the owner or the part owner or any person claiming to be
the owner or the part owner of such land or building, or the lessee, or any person claiming to be the
lessee thereof to -(i)secure, enclosed, cleanse or clear such land or building, or(ii)stop use of such
land or building for gambling or immoral purpose or(iii)abate the nuisanceWithin such time as mayArunachal Pradesh Municipal Act, 2007

be specified in the notice, and affix a copy of such notice on the door of the building or on some
conspicuous part of the land, as the case may be.
290. Polluters to pay.
- The Municipality may, by regulations, provide for recovery of charges and imposition of penalty on
those persons who are directly responsible for causing pollution of any kind referred to in this
chapter.
Chapter XXXI
Restraint of infection
291. Municipality to prevent and check dangerous diseases.
(1)It shall be the duty of the Municipality to take such measures as are necessary for preventing, or
checking the spread of any dangerous diseases in the municipal area or of any epidemic disease
among any animals therein(2)Any persons, whether as a medical practitioner or otherwise, being in
charge of or in attendance upon, any other person whom he knows or has reason to believe to be
suffering from a dangerous diseases, or being the owner, lessee, or occupier of any building in which
he knows that any such person is so suffering, shall forthwith give information respecting the
existence of such disease to the Chief Municipal Executive Officer/Municipal Executive Officer.
292. Power of the Chief Municipal Executive Officer/Municipal Executive
Officer to inspect any place and take measures to prevent spread of
dangerous diseases.
(1)The Chief Municipal Executive Officer/ Municipal Executive Officer may, at any time, by day or
by night, and with or without notice, inspect any place in which any dangerous diseases is reported
or suspected to exist, and take such measures as he may think fit to prevent the spread of such
diseases beyond such place, and shall forthwith send information thereof to the State Government,
the District Magistrate and the senior most functionary of the Health Department of the State in the
district.(2)When any person suffering from any dangerous disease is found to be :-(a)without proper
lodging or accommodation or(b)living in a room or house which he neither owns nor pay rent for ,
nor occupies as a guest or relative of the person who owns, or pay rend for such room or house,
or(c)living in a sarai, hotel, boarding-house, or hotel or(d)lodged in premises occupied by members
of two or more familiesThe Chief Municipal Executive Officer/Municipal Executive Officer or any
person authorized by him in this behalf may, on the advice of any Medical Officer, remove the
patient to any hospital or place at which persons suffering from such diseases are received for
medical treatment and may do anything necessary for such removal.Arunachal Pradesh Municipal Act, 2007

293. Power of the Chief Municipal Executive Officer/ Municipal Executive
Officer to cleanse, disinfect, destroy, or control places of infection.
(1)The Chief Municipal Executive Officer/ Municipal Executive Officer may cleanse, or disinfect, or
cause destruction of, any building, hut or shed, water source or lodging and eating house, if in his
opinion, such cleansing, disinfection or destruction would tend to prevent or check the spread of any
dangerous disease, and in case of emergency, he may cause such cleansing, or disinfection to be
done by the employees of the Municipality at the cost of the owner or the occupier of such place, or
at the cost of the Municipality, if in his opinion, such owner or the occupier is unable to pay the cost
owing to poverty.(2)Where the Chief Municipal Executive Officer/ Municipal Executive Officer is
satisfied that the destruction of any building, hut or shed, or clothing, or article is immediately
necessary for the purpose of preventing the spread of any dangerous disease, he may cause such
building, hut or shed, or clothing, or article to be destroyed :Provided that compensation may be
paid by the Chief Municipal Executive Officer/Municipal Executive Officer to any person who loss
substantially by the destruction of such building, hut or shed, or clothing or article.(3)The Chief
Municipal Executive Officer/ Municipal Executive Officer may, on being satisfied that it is in the
public interest so to do, by order, in writing, direct that any lodging house or any place in the
municipal area where articles of food and drink are sold, or prepared, stored or exposed for sale,
being a lodging house or place in which a case of dangerous disease exists or has recently occurred,
shall be closed for such period as may be specified in the order :Provided that such lodging house or
place may be declared to be open, if the Municipal Health Officer certified that it has been
disinfected or is free from infection.(4)The Chief Municipal Executive Officer/ Municipal Executive
Officer or any person authorized by the Municipality may, at all reasonable times, enter into and
inspect, any market, building, shop, stall or place, used for the sale of food or drink, or as a
slaughterhouse, or for the sale of drugs, and inspect and examine any food, drink, animal or drug,
which may be therein, and if any article of food or drink, animal or drug therein intended for the
consumption of persons, appears to be fit therefor, he may, by notice, restrict the sale of such food,
drink, animal or drug, in such manner and for such period as he may deem fit.(5)If the Chief
Municipal Executive Officer/ Municipal Executive Officer is of the opinion that the water in any
well, tank, or other place in the municipal area is likely to cause the spread of any disease, he may,
by notice, in writing, prohibits the removal or use of such water for drinking, and require the owner
or the person having control of such well, tank, or other place to take such steps as may be required
by the notice to prevent the public from having access to, or from using, such water and may take
such other steps as he may consider expedient to prevent the outbreak or spread of such disease
:Provided that in the case of an emergency, the Chief Municipal Executive Officer/Municipal
Executive Officer or any person authorized by him in this behalf may, with or without notice and at
any time, inspect and disinfect any well, tank or other place from which water is, or is likely to be
taken for the purpose of preventing the spread of any dangerous disease.
294. Special measures in case of outbreak of dangerous or epidemic diseses.
(1)In the event of any municipal area or any part thereof being visited or threatened by an outbreak
of any dangerous disease among the inhabitants thereof or of any epidemic disease among any
animals therein, the Chief Municipal Executive Officer/ Municipal Executive Officer may, if he thinkArunachal Pradesh Municipal Act, 2007

that the other provisions of this Act and the provisions of any other law for the time being in force
are insufficient for the purpose of preventing the outbreak of such disease, with the previous
approval of the Municipality :(a)take such special measures and(b)by notice, give such directions to
be observed by the public or by any class or section of the public as he thinks necessary to prevent
the outbreak of such disease :Provided that where, in the opinion of the Chief Municipal Executive
Officer/Municipal Executive Officer, immediate action is necessary, he may take such action without
such approval and, if he does so, he shall forthwith report such action to the Municipality.(2)Any
person, who commits a breach of any direction given in the notice under clause (b) of sub-section (1)
shall be deemed to have committed as offence under section 188 of the Indian Panel Code (45 of
1860).
295. Means for disinfection.
(1)The Municipality may, in its discretion, or shall, when the State Government so direct :(a)provide
proper places within the municipal area with necessary attendants and apparatus for disinfection of
conveyances, clothing, beddings, or other articles which have been exposed to infection, and Special
measures in case of outbreak of dangerous or epidemic diseases.(b)cause conveyances, clothing,
beddings or other articles brought for disinfection, to be disinfected, either free of charge or on
payment of such charges as it may fix.(2)The Chief Municipal Executive Officer/ Municipal
Executive Officer may notify places at which such conveyances, clothing, beddings or other articles,
which have been exposed to infection, shall be washed and if he does, so no person shall wash any
such conveyances, clothing, beddings or other articles at any place, not so notified, without previous
disinfection.(3)The Chief Municipal Executive Officer/Municipal Executive Officer may direct the
destruction of any clothing, bedding, or other article likely to retain infections and may give such
compensation as he thinks fit for any clothing, bedding or other article, so destroyed.
296. Special conveyance for carrying infected persons.
(1)Subject to such regulation as may be made in this behalf, the Chief Municipal Executive Officer/
Municipal Executive Officer may, either on his own or through any other agency, provide and
maintain suitable conveyances for the free carriage of persons suffering from any dangerous
diseases or dead bodies of persons who died of any such disease.(2)The Chief Municipal Executive
Officer/ Municipal Executive Officer may, either on his own or through any other agency, provide
for disinfection of any public conveyance, which has carried any person suffering from a dangerous
disease, or the corpses of a person who died of any such disease.
297. Prohibitions.
- Subject to such regulation as may be made in this behalf, the Chief Municipal Executive Officer/
Municipal Executive Officer may prohibit :(a)the letting out of any infected building without being
first disinfected(b)the disposal of infected articles without disinfection,(c)the washing of any
infected clothes by any washer man or laundry and(d)the making and selling of food, or washing of
cloths, by infected person.Arunachal Pradesh Municipal Act, 2007

Chapter XXXII
Disposal of the dead
298. Acts prohibited in connection with disposal of dead.
(1)No person shall :(a)retain a corpse on any premises without burning, burying or otherwise
lawfully disposing it of, for so long a time after death as to create a nuisance.(b)carry a corpse, or
part of a corpse, along any street without having or keeping such corpse or part of a corpse decently
covered or without taking such precautions to prevent risk of infection or injury to the community
health as the Chief Municipal Executive Officer/ Municipal Executive Officer may, by notice, from
time to time, think fit to require.(c)carry, except when no other route is available, a corpse or part of
a corpse along any street on which the carrying of corpse is prohibited by notice issued by the Chief
Municipal Executive Officer/ Municipal Executive Officer in this behalf.(d)remove corpse or part of
a corpse, which has been kept or used for purpose of dissection, otherwise than in a closed
receptacle or vehicle.(e)place or leave, during its conveyance, a corpse or part of a corpse, on or near
any street without urgent necessity.(f)bury, or caused to be buried, any corpse or part of a corpse in
the grave or vault or otherwise in such manner as may cause the surface of the coffin or, when no
coffin is used, of the corpse or part of the corpse, to be at a depth of less than two meters from the
surface of the ground.(g)built, dig or cause to be built or dug, any grave or vault in any burial ground
at a distance of less than one-half of a meter from the margin of any other grave or vault,(h)build or
dig, or cause to be built or dug, a grave or vault in any burial ground in any line, not marked out for
such purpose by or under the order of the Chief Municipal Executive Officer/ Municipal Executive
Officer,(i)reopen for the interment of a corpse or of any part of corpse a grave or vault already
occupied, without the written permission of the Chief Municipal Executive Officer/ Municipal
Executive Officer,(j)make, without the permission of the Chief Municipal Executive Officer/
Municipal Executive Officer, any vault or grave or interment within any wall, or underneath any
passage, porch, portico, plinth or verandah, of any place of worship.(k)make without permission of
the Chief Municipal Executive Officer/ Municipal Executive Officer, any interment or otherwise
dispose of any corpse in any place which is closed under section 300,(l)muild, dig or causing to be
built or dug, any grave or vault, or in any way, dispose of, or suffer or permit to be disposed of, any
corpse at any place, which is not permitted under this chapter, without the permission of the Chief
Municipal Executive Officer/ Municipal Executive Officer,(m)exhume without the permission of the
Chief Municipal Executive Officer/ Municipal Executive Officer, any body from any place for the
disposal of the dead except under the provision of the Code of Criminal Procedure, 1973, (2 of 1974)
or any other law for the time being in force.(2)The Chief Municipal Executive Officer/Municipal
Executive Officer may, in special cases, grant permission for any of the purpose referred to in
clauses (j) to (m) of sub-section (1), subject to such general or special order as the State Government
may, from time to time make in this behalf.(3)Any contravention of the provision of clauses (j) to
(m) of sub-section (1) shall be deemed to be a cognizable offence within the meaning of the Code of
Criminal Procedure, 1973.Arunachal Pradesh Municipal Act, 2007

299. Registration of places for disposal of the dead.
(1)Subject to such regulations as may be made in this behalf, every owner or person having the
control of any place already used for disposal of the dead, but which is not vested in, or owned by the
Municipality or any Board appointed by the State Government for administration of such place,
shall submit to the Chief Municipal Executive Officer/ Municipal Executive Officer an application
for registration of such place, containing such particulars as may be specified by the Municipality
within a period of three months from the date of commencement of this Act.(2)If the Chief
Municipal Executive Officer/ Municipal Executive Officer is satisfied with the application and the
particulars under sub-section (1), he may register such place on such terms and conditions as may
be provided by regulations.(3)The Chief Municipal Executive Officer/ Municipal Executive Officer
may, with the approval of the Empowered Standing Committee, provide suitable and convenient
place for the disposal of the dead within the municipal area, subject to the provisions of any State
law regulating such land use or, in the absence of any provisions of any State law in this behalf in the
municipal area, with the approval of the State Government.(4)No place which has not previously
been lawfully used or registered for the disposal of the dead shall be opened for such disposal except
in conformity with the provisions of any State law regulating such land use or in the absence of any
provisions of any State law in this behalf in the municipal area, with the approval of State
Government.
300. Power to require closing of burning and burial ground etc.
- Where the Chief Municipal Executive Officer/ Municipal Executive Officer is of the opinion that
any burning place or burial ground or place for the disposal of the dead has become offensive or
dangerous to the health of persons residing in the neighborhood or for any other reasons to be
recorded in writing, he may, with the previous approval of the Empowered Standing Committee,
and by notice in writing require the owner or the person in charge of such burning place or burial
ground or place for the disposal of the dead, to close such burning place or burial ground or place for
the disposal of the dead from such date as may be specified in the notice.
301. Disposal of dead animals.
(1)Whenever any animal, which is under the charge of any person dies such person shall within
twenty four hours of such death, either:(a)convey the carcass to a place provided or appointed under
this Act for the final disposal of carcasses of dead animals, or(b)give notice of the death to the
Municipal Executive Officer whereupon he shall cause the carcass to be disposed of.(2)In respect of
the disposal of the carcass of a dead animal under clause (b) of sub-section (1), the Chief Municipal
Executive Officer/ Municipal Executive Officer may charge such fee as may be determined by the
Municipality by regulations.(3)Where any dead animal does not belong to any person, the Chief
Municipal Executive Officer/ Municipal Executive Officer shall act immediately for causing the
carcass to be disposed of.Arunachal Pradesh Municipal Act, 2007

Chapter XXXIII
Urban Forestry, Parks, Gardens, Trees and Playgrounds.
302. Municipality to implement schemes.
(1)The Municipality shall take necessary steps for :(a)Promotion of urban forestry.(b)Creation of
public parks and gardens and planting of trees.(c)Provision of park and playgrounds for children
and youth.(d)Provision of street-side gardens.(e)Encouragement of nurseries, and(f)Organization of
flowers shows.(2)The Municipality may from time to time take steps to promote awareness about
the national heritage of flora and fauna among the school children and the youth.(3)The
municipality may from time to time take steps to promote harvesting of rain water in public parks,
gardens and other open space under its administrative control and may also undertake campaign to
promote public awareness for conservation of rain water.Regulatory Jurisdiction
Chapter XXXIV
Development Plans
303. Representation in District Planning Committee or Metropolitan Planning
Committee.
- Having regard to the provision of articles 243ZD and article 243ZE of the Constitution of India and
of any State law enacted under these articles a Municipality shall participate in the election of
members of the District Planning Committee or the Metropolitan Planning Committee, as the case
may be and such members shall actively represent the interests of the Municipality in such
committees.
304. Municipality to implement development plans.
(1)Having regard to the draft development plan, as prepared by the District Planning Committee or
the Metropolitan Planning Committee, as the case may be and as approved by the State
Government, the Municipality shall implement such components of such development plan as
relates to its jurisdiction and carry out such function as may be assigned to it in this
behalf.(2)Without prejudice to the generality of the foregoing provisions of this section and subject
to the provisions of section 10, the Municipality shall undertake :(a)Preparation of plans for
improvement under chapter XXXV and(b)Plans for infrastructure development including water
supply, drainage and sewerage, solid waste management, roads and transport system accessories.
Chapter XXXV
ImprovementArunachal Pradesh Municipal Act, 2007

305. Removal of congested buildings.
(1)If it appears to the Chief Municipal Executive Officer/ Municipal Executive Officer that any block
of building is in an unhealthy condition by reason of the manner in which the building are crowded
together or the narrowness, closeness, or faulty arrangement of streets or the want of proper
drainage and ventilation or the impracticability of cleansing the buildings or by reasons of any other
cause to be specified in writing, he shall cause block of buildings to be inspected by the Chief
Municipal Health Officer and the Chief Municipal Architect and Engineer , who shall consult the
owners and the occupier of such block of buildings and the owners and the occupier of other
building affected by the unhealthy condition and shall thereafter make a report in writing to him
regarding the sanitary condition of such block of buildings.(2)If, upon receipt of the report under
sub-section (1), the Chief Municipal Executive Officer/ Municipal Executive Officer considers that
the sanitary condition of such block of building is likely to cause risk of disease to the inhabitants of
the building or the neighborhood or otherwise to endanger the community health, he shall with the
approval of the Empowered Standing Committee, select the buildings which in his opinion should
wholly or in part be removed in order to abate the unhealthy condition of such block of building and
may thereupon by notice, in writing, require the owners of such buildings to remove them within
such period as may be specified in the notice :Provide that before issuing the notice, a reasonable
opportunity shall be given to the owners to show cause, either in writing or in person, why the
buildings should not be removed :Provided further that the Chief Municipal Executive Officer/
Municipal Executive Officer shall for the removal of any such building, which may have been erected
lawfully, pay compensation to the owner for any such building.(3)If the notice under sub-section (2)
requiring any owner of a building to remove sub building is not complied with then after the
expiration of the period specified in the notice, the Chief Municipal Executive Officer/ Municipal
Executive Officer may himself remove the building and recover from the owner of the building the
expenses of such removal as an arrear of tax under this Act.
306. Power to require improvement of building unfit for human habitation.
(1)If upon information in his possession, the Chief Municipal Executive Officer/ Municipal
Executive Officer is satisfied that any building is in any respect unfit for human habitation, he may
unless in his opinion the building is not capable of being rendered fit at a reasonable expense, serve
on the owner of the building a notice requiring him within such period, not being less than thirty
days, as may be specified in the notice, to execute the works of improvement specified therein, and
stating that in his opinion such works will render the building fit for human habitation.(2)In
addition to the notice served on the owner of the building under sub-section (1), the Chief Municipal
Executive Officer/ Municipal Executive Officer may also serve a copy of the notice on any other
person having an interest in the building, whether as a lessee or as a mortgagee or otherwise.(3)In
determining whether a building can be rendered fit for human habitation at a reasonable expense,
regard shall be had to the estimated cost of the works necessary to render the building so fit and the
estimated value which the building will have on completion of the works.(4)If the notice under
sub-section (1) requiring the owner of the building to execute the work of improvement is not
complied with, then on the expiration of the period specified in the notice, the Chief Municipal
Executive Officer/ Municipal Executive Officer may himself do the works required to be done by theArunachal Pradesh Municipal Act, 2007

notice and recover the expense incurred in connection therewith as an arrear of tax under this Act.
307. Power to order demolition of building unfit for human habitation.
(1)Where, upon information in his possession, the Chief Municipal Executive Officer/ Municipal
Executive Officer is satisfied that any building is unfit for human habitation and is not capable at a
reasonable expense of being rendered fit, he shall serve upon the owner of the building and upon
any other person having an interest in the building, whether as a lessee or as a mortgagee or
otherwise, a notice to show cause within such time as may be specified in the notice as to why an
order of demolition of the building should not be made.(2)If the owner of the building, or other
person upon whom a notice has been served under sub-section (1), appears in pursuance thereof
before the Chief Municipal Executive Officer/ Municipal Executive Officer and gives an undertaking
that he shall, within a period specified by the Chief Municipal Executive Officer/ Municipal
Executive Officer, execute such works of improvement in relation to the building as will, in the
opinion of the Chief Municipal Executive Officer/ Municipal Executive Officer, render the building
fit for human habitation or that the building shall not be used for human habitation until the Chief
Municipal Executive Officer/ Municipal Executive Officer on being satisfied that it has been
rendered fit for such habitation, cancels the undertaking, the Chief Municipal Executive Officer/
Municipal Executive Officer shall not make an order of demolition of the building.(3)If no such
undertaking as is referred to in sub-section (2) is given, or if, in a case where any such undertaking
has been given, the works of improvement to which the undertaking relates are not carried out
within the specified period or the building is used in contravention of the undertakings, the Chief
Municipal Executive Officer/ Municipal Executive Officer shall forthwith make an order of
demolition of the building requiring that the building shall be vacated within a period to be specified
in the order, not being less than thirty days from the date of the order, and demolished within six
weeks on the expiration of that period.(4)Where an order of demolition of a building under this
section has been made, the owner of the building or any other person having an interest therein
shall demolish such building within the period specified in the order and if such building is not
demolished the building, the Municipal Executive Officer shall sell the materials thereof.(5)Any
expenses incurred by the Chief Municipal Executive Officer/ Municipal Executive Officer for
carrying out the purpose of sub-section (4), which cannot be met out of the proceeds of the sale of
materials of the building, shall be recovered from the owner of the building or any other person
having an interest therein as an arrear of tax under this Act.(6)In determining, for the purpose of
this section and section 306, whether a building is unfit for human habitation, regard shall be has to
its condition in respect of the matters, such as :(a)Repairs,(b)stability,(c)freedom from
damp,(d)natural light and air,(e)water supply,(f)drainage and sanitary convenience and(g)facilities
for storage, preparation and cooking of food and for the disposal of rubbish, filth and other polluted
matter.and the building shall be deemed to be fit for human habitation only, if it is so defective in
one or more of the matters as aforesaid that it is not reasonably suitable for occupation in that
condition.(7)For the purpose of this section and section 306 "works of improvement" in relation to a
building shall include any one or more of the following :(a)necessary repairs,(b)structural
alterations,(c)provision of light points and water taps,(d)construction of drains, open or
covered,(e)provision of latrines and urinals(f)provision of additional or improvement fixtures and
fittings,(g)opening up or paving of courtyard,(h)removal of rubbish, filth and other polluted andArunachal Pradesh Municipal Act, 2007

obnoxious matter and,(i)any other work including the demolition of any building or any part thereof
which, in the opinion of the Municipal Executive Officer, is necessary for executing any of the works
as aforesaid.(8)The provisions of this section and section 305 and section 306 shall not apply in
relation to any building in any area which has been declared to be a slum area under any State law
relating to improvement or clearance of slums.
308. Area improvement scheme.
- If the Municipality, upon information in its possession in respect of any built-up area within the
municipal area, is satisfied that :(a)the building in that area are, by reason of disrepair or sanitary
defects, unfit for human habitation or are by reason of their bad arrangement or narrowness or bad
arrangement of the streets or wants of light air, ventilation or proper conveniences, dangerous or
injurious to the health of the inhabitants of that area or,(b)because of bad layout or obsolete or
undesirable dwellings, renewal of such area is necessary or,(c)there is need to create new or
improvement means of communication and facilities for traffic, and that the most satisfactory
methods of remedying these defects is to prepare an area improvement scheme in respect of such
area, the Municipality may pass a resolution so to do.Explanation. - For the purpose of this section
and section 309, the expression "built-up area" shall mean an area which in the opinion of the
Empowered Standing Committee is densely built-up.
309. Matters to be provided in area improvement scheme.
- An area improvement scheme may provide for all or any of the following matters, namely
:(a)laying out, or relaying out, land, either vacant or already built upon,(b)filling up, or reclamation,
of low lying swampy or unhealthy areas or leveling up of land,(c)redistribution of sites belonging to
owners of property comprised in the scheme,(d)reconstitution of plots,(e)construction or
reconstruction of buildings,(f)restriction on the erection or re-erection of any building or any class
of buildings,(g)imposition of conditions and restriction in regard to the open spaces to be
maintained around any building, percentage of built-up area for a plot, number, height and
character of buildings allowed in specified areas, sub-division of plots, discontinuance of
objectionable uses of land or building in any area for specified periods, parking spaces and loading
and unloading spaces for any building and advertisement signs,(h)closure or demolition of buildings
or portion of buildings unfit for human habitations,(i)demolition of obstructive buildings or
portions thereof,(j)laying out of new streets or roads and construction, diversion, extension,
alteration, improvement and closing up of streets or roads and other means of
communication,(k)regular line of street and prohibition of buildings within the regular line of
streets,(l)construction, alteration and removal of bridges and other structures,(m)provision for
traffic engineering schemes, street lighting, street furniture and other convenience,(n)provision for
water supply, sewerage, surface or sub-soil drainage and sewage disposal,(o)provision for open
spaces,(p)Preservation and protection of objects of historical importance or of national interest or of
natural beauty and of buildings actually used for religious purpose and(q)any other matter not
inconsistent with the provisions of this Act and for which, in the opinion of the Municipality, it is
expedient to make provision with a view to improving the area to which the scheme relates.Arunachal Pradesh Municipal Act, 2007

310. Submission of area improvement scheme to Municipality and State
Government.
(1)Every area improvement scheme shall, as soon as may be after it has been prepared, be submitted
for approval by the Chief Municipal Executive Officer/ Municipal Executive Officer to the
Municipality which may either approve the scheme without modifications or with such
modifications as it may consider necessary or reject the scheme with direction to the Chief
Municipal Executive Officer/ Municipal Executive Officer to have a fresh scheme prepared
according to such directions.(2)No area improvement scheme approved by the Municipality under
sub-section (1) which involves acquisition of land and provision of funding support from the State
Government, shall be valid unless it has been approved by the State Government,
311. Re-housing scheme.
- While preparing an improvement scheme under this chapter for any area the Chief Municipal
Executive Officer/ Municipal Executive Officer may also prepare a scheme (hereinafter referred to in
this Act as Re-housing scheme) for the construction, maintenance and management of such
buildings as he may consider necessary for providing accommodation for persons who are likely to
be displaced by the execution of the area improvement scheme.
312. Area improvement scheme and rehousing scheme to comply with
structure plan.
- No area improvement scheme or re-housing scheme prepared under this chapter shall be valid
unless such scheme is in conformity with the provisions of the structure plan, if any for the
Municipal area.Explanation. - "Structure Plan" shall mean a plan which provides a broad strategic
framework for preparation of subsequent local plans and takes into consideration the regional
context, the transportation linkages and the issues relating to employment, shelter and
environment.
313. Execution of area improvement scheme.
- Any area improvement scheme prepared under this chapter may be executed by the Municipality
itself or by such person or authority as the Empowered Standing Committee may select under
chapter XXI.
314. Power to acquire land and building for area improvement scheme.
- Subject to the provision of this Act, the Municipality may require acquisition of any land or
building, whether situated in the municipal area or not, for the purpose of :(i)opening out any
congested or unhealthy area or otherwise improving any portion of municipal area, or(ii)erecting
sanitary dwellings for working and poor people or(iii)executing any development plan or scheme for
the benefit of persons residing in the municipal area.Arunachal Pradesh Municipal Act, 2007

315. Power of Municipality to define and to alter limits of slum.
- The Municipality may define the external limits of any slum and may, from time to time, alters
such limits.
316. Slum improvement scheme.
(1)Notwithstanding anything contained in any other law for the time being in force, the Municipality
may with the approval of the State Government prepared such improvement scheme for the purpose
of effecting environmental or general improvement of slums as it may consider necessary and
publish a copy of such scheme in such manner as may be prescribed.(2)The slum improvement
scheme may provide for all or any of the following matters :-(a)water supply including sinking of
tube wells, laying of water pipelines, installation of overhead reservoirs and flushing arrangement
for privies and urinals,(b)drainage and sewerage including connections with any existing channel or
sewer main or laying or diverting of drains,(c)Conversion of service privies into septic tank privies
or water borne privies connected with sewer mains,(d)Sewerage and garbage removal,(e)Raising,
lowering or leveling of land and improvement of pathways and passages,(f)Lighting including laying
of cables or overhead lines,(g)Improvement of huts or other structure and(h)Such other matters as
may be considered necessary for carrying out the purposes of this chapter.(3)While approving any
slum improvement scheme, the State Government shall take into account the activities of other
agencies or authorities affecting all or any of the matters referred to in sub-section (2).
317. Acquistion of right of user.
(1)If, at any time, it becomes necessary to acquire the right of user in any land in or around any slum
for the purpose of implementing any improvement scheme in respect of such slum, the State
Government may, on the recommendation of the Municipality in this behalf declare, by notification,
its intention to acquire such right and inviting suggestion or objections from persons likely to be
affected thereby within such time as may be specified in the notification.(2)Every suggestion or
objection received under sub-section (1) shall be heard by the Chief Municipal Executive Officer/
Municipal Executive Officer after giving an opportunity to all persons affected to make personal
representation, if any.(3)The Chief Municipal Executive Officer/ Municipal Executive Officer shall
submit a report to the Empowered Standing Committee after the hearing under sub-section (2) and
after making such enquiry in this behalf as he may consider necessary.(4)After considering the views
of the Empowered Standing Committee, the State Government may, by notification declare that the
right of user in such land which shall be acquired.(5)With effect from the date if publications of the
notification under sub-section (4), the right of user in such land shall vest in the Municipality free
from all encumbrances.
318. Work to be executed in slum.
- Notwithstanding anything contained in the foregoing provisions of this chapter, the Municipal
Executive Officer may, for reasons of environmental sanitation cause the following works to beArunachal Pradesh Municipal Act, 2007

executed in any slum :(a)sinking of tube-wells inside a slum including laying of water-pipes lines,
installation of overhead reservoirs and other appurtenances necessary to maintain flushing
arrangements of privies and sewers,(b)laying of drains or diversion of existing drains,(c)conversion
of service privies into connected privies or septic tanks,(d)removal of silt from sewers and sludge
from septic tanks inside a slum,(e)removal of solid or liquid wastes from slums including cleansing
of the deck or squatting platform of the connected privies or septic tanks,(f)laying of internal
roads,(g)provision of street lighting and(h)repair work relating to any of the works referred to in
clauses (a) to (e).
Chapter XXXVI
Public streets
A. General Powers
319. Municipal Streets Technical Committee.
(1)The Municipality shall constitute a Municipal Streets Technical Committee with the following
elected members, namely :(a)in the case of a Class "A" Municipal Council, five Councillors to be
elected by the Municipal Council and(b)in the case of a Class "B" or Class "C" Municipal Council or a
Nagar Panchayat, three Councillors to be elected by the Class "B" or Class "C" Municipal Council or
the Nagar Panchayat as the case may be.(2)In addition to the members mentioned in sub-section
(1), the Municipal Street Technical Committee shall have six other members namely :(a)The Chief
Municipal Executive Officer/ Municipal Executive Officer who shall be the convenor of the
Committee,(b)The Municipal Engineer,(c)The Municipal Architect,(d)A police officer, not below the
rank of an Inspector or Police to be nominated by the Superintendent of Police of the District
concerned and(e)Two officers having responsibility for fire service and preparation of development
plans (ie Town Planner) for the municipal area to be nominated by the State Government either
from amongst the officers of the Municipality or from the officers of the concerned State
Government Departments or any authority under any law for the time being in force.(3)The term of
the Municipal Streets Technical Committee shall be such as may be specified by the Chief Councillor
and a new Municipal Streets Technical Committee shall be constituted before the expiry of the term
of the existing Municipal Streets Technical Committee.(4)The Municipal Streets Technical
Committee shall meet at least once in a month.(5)The Municipal Streets Technical Committee shall
in order to secure the expeditious, convenient and safe movement of traffic, including pedestrian
traffic and suitable and adequate parking facilities on and off the public streets and having regard to
:(a)the desirability of securing and maintaining reasonable access to premises,(b)the effect on the
amenities of any locality affected and(c)any other relevant matter referred to it by the
Municipality.aid, advise and assist the Municipality in the following matters namely
:-(i)classification of public streets and specification of width there of,(ii)prescription of regular line
of street,(iii)regulation of abutting land uses,(iv)regulation of traffic,(v)designation of on-street
parking areas(vi)allocation of rights of way for underground utilities(vii)placement of street
furniture,(viii)placement of authorized fixtures on streets such as electric and telegraph poles,
post-boxes, telephone junction boxes, sheds for buses and milk booths,(ix)opening of new publicArunachal Pradesh Municipal Act, 2007

streets,(x)permanent or temporary closure of existing public streets,(xi)declaring private streets as
public streets and(xii)any other matter that may be referred to it by the Municipality.(6)The
Municipal Streets Technical Committee shall make recommendation to the Municipality on any
matter in conformity with the structure plan, or a scheme under section 308 or section 311 as the
case may be or any other development and improvement scheme prepared by any competent
authority under any law for the time being in force, and shall take into account such plans,
proposals, surveys, studies and supporting technical data on such matter as might be in the
possession of the Municipality or any planning or development authority or any Department of the
State Government or any such competent authority.Explanation. - "Structure Plan" shall have the
same meaning as in the Explanation below section 312.(7)Municipal Streets Technical Committee
may call for any record, document, map or data from the Municipality or any planning or
development authority of any Department of the State Government or any other authority under any
State law for the time being in force, and thereupon, it shall be the duty of such Department or
authority to comply with such requisition.(8)The Municipality shall consider the recommendation
of the Municipal Streets Technical Committee and take such decision thereon as it think fit after
taking into account plans, proposals, survey, studies and supporting technical data, if any, referred
to in subsection (6).(9)If any doubt arises as to whether the decision under sub-section (8) is in
conflict with any plan, scheme or Programme of any competent authority under any law for the time
being in force, the matter shall be referred to the State Government whose decision thereon shall be
final.
320. Classification of public streets.
(1)Subject to the provision of section 10, the Empowered Standing Committee shall classify all
public streets in the municipal area in the following categories :-(a)Category -I - arterial
roads.(b)Category-II - sub-arterial roads.(c)Category-III- collector roads,(d)Category-IV - local
roads and,(e)Category -V- pedestrian pathways.(2)The classification shall be done with due regard
to the traffic rule of the particular public street and the nature and volume of traffic on it, its existing
width and abutting land uses :Provided that the different names of public streets, which constitute
essential parts of a continuous traffic corridor shall not come in the way of their inclusion in any
particular category.(3)The Empowered Standing Committee shall from time to time specify the
minimum widths of different categories of public streets with regard to the existing widths of such
streets as may be included in such categories :Provided that the minimum width of any public street
included in category I or category II or category III or category IV shall be not less than ten meters
including the adjoining footpath, if any and that of a public street included in category V shall be not
less than six meters :Provided further that such minimum widths may be revised by the Empowered
Standing Committee from time to time.(4)The classification of the public streets in different
categories may be revised from time to time.
321. Compulsory provision of footpaths.
(1)The Municipality shall ensure within a reasonable time and subject to the availability of
resources, that all public streets under category I , Category II and Category III have raised footpath
adjoining such public streets.(2)Notwithstanding the existing situation the Empowered StandingArunachal Pradesh Municipal Act, 2007

Committee shall specify different minimum widths for footpaths which are adjacent to the public
streets under Category I, Category II or Category III so as to be not less than one and a half meters
on each side in any case :Provided that more than one minimum width may be specified for the foot
path abutting each category of public streets so as to provide for different requirements owing to
different abutting land uses:Provided further that while prescribing or revising any regular line of a
public street, it shall be stipulated that the specification of minimum width for footpaths shall be
complied with.(3)The minimum widths referred to in sub-section (2) may be revised by the
Empowered Standing Committee.
322. Naming and numbering of streets.
(1)The Municipality shall -(a)determine the name or number by which any street or public place
vested in it shall be known,(b)cause to be put up or painted at a conspicuous part of any building,
wall or place at or near each end, corner or entrance of such streets or some convenient part of such
street, the name or number by which it shall be known, and(c)cause to be put up or painted on
boards of suitable size the name of any public place vested in the Municipality.(2)The Municipality
may having regard to the hierarchy of the street system, by regulations, specify the norms according
to which the streets may be named or numbered.(3)No person shall destroy, remove, deface or in
any way injure or alter any such name or number or sub-number put up or paint any name or
number or sub-number different from that put up or painted by order of the Municipality.
323. Unique premises number.
(1)Municipality shall, when so required by the State Government, assign a unique premises number
to every premises or part thereof in the municipal area and shall cause to be maintained a register
wherein such unique premises number shall be recorded in respect of each such
premises.Explanation.- In this section, the expression "unique premises number" shall mean a
number assigned to the premises or part thereof by the Municipality in the following manner,
namely :-(a)the first three digit indicating the ward number,(b)the next three digit indicating the
street number,(c)the next four digit indicating the premises number,(d)the next three digit
indicating the sub-premises number,(e)the next one digit indicating the code of the building use,
such as residential, commercial, industrial or other use, and(f)the last one digit indicating the code
of type of construction.(2)When the unique premises number in respect of premises in any ward of
the Municipality have been determined, the Chief Municipal Executive Officer/ Municipal Executive
Officer shall notify such unique premises number in such manner as may be prescribed.(3)When,
after the unique premises numbers in respect of premises in any ward have been notified under
sub-section (2), any person is required under this Act or any other State law to make any application
to the Municipality for any permission or license or for payment of any tax, or for payment of any
dues for any service or for such other purposes as may be prescribed, the person making the
application shall mention in the application the unique premises number assigned under
sub-section (1).Arunachal Pradesh Municipal Act, 2007

324. Rights of way for underground utilities.
- Subject to the provisions of the Indian Telegraph Act 1885 (13 of 1885), the Indian Electricity Act,
1910 (9 of 1910) and such other laws as may be notified by the State Government for the purposes of
this section, the State Government may, by rules provide for the following namely :-(a)the sanction
by the Municipality of specific rights of way in the sub-soil of public and private streets in any
municipal area for different public utilities including electric supply, telephone or other
telecommunication facilities, gas pipe, water supply, drainage and sewerage, and underground rail
system, pedestrian sub-ways, shopping plazas, warehousing facilities and apparatus and
appurtenances related thereto provided by the State Government or any statutory body or any
licensee under any of the above mentioned Acts or other laws,(b)the levy of any fee or charge under
any of the Acts or other laws as foresaid,(c)the furnishing to the Municipality of maps, drawings and
statements which shall enable it to compile and maintain precise records of the placement of the
underground utilities in the municipal area,(d)the fixing of time limit for execution of work and
imposing of such conditions in this respect as the Municipality may consider appropriate and(e)the
imposing of penalty in case of delay in the completion of work.
325. Maps of underground utilities.
- The Chief Municipal Executive Officer/ Municipal Executive Officer shall cause to be maintained
complete survey maps, drawing and descriptions of all underground utilities in the municipal area
and maps of fire hydrants and sewerage man - holes in such form and in such manner as may be
provided by regulations and shall ensure the secrecy of the same in conformity with the provisions
of any law relating to right to information.
326. Power to prohibit use of public streets for certain kind of traffic.
(1)The Municipality may by notice, in writing :-(a)prohibit or regulate, either temporarily or
permanently, vehicular traffic in any public street or any portion thereof so as to prevent danger,
obstruction or inconvenience to the public or to ensure quietness in any locality,(b)prohibit, in
respect of a public street or a portion thereof, the transit of any vehicle of such type, form,
construction, weight, emission or size or of any vehicle laden with such heavy or unwieldy object as
is likely to cause injury to the roadways or any construction thereon, or of any vehicle on the ground
of public convenience, except under such conditions as to time, mode of traction or locomotion use
of appliances for the protection of roadways, number of light and assistants and other general
precautions and on payment of such charges as may be specified by the Municipality generally or
specifically in each case,(c)prohibit at all times or during any particular hours, entry of any vehicular
traffic from or exit of such vehicular traffic into any premises from any particulars public street
carrying such traffic.(2)Any notice under sub-section (1) shall, if such notice applies to any
particulars public street, be pasted in conspicuous places at or near both ends of such public street
or any portion thereof to which such notice applied or if such notice applied generally to all public
streets, be advertised.(3)Notwithstanding anything contained in sub-section (1), the Municipality
may declare by notice in writing that any pedestrian pathway, or a portion thereof shall be used as
bicycle and pedestrian track.(4)The notice referred to in sub-section (3) shall be pasted inArunachal Pradesh Municipal Act, 2007

conspicuous places at or near both ends of such public street or any portion thereof to which the
provision of subsection (3) apply.B. Regular line of Street
327. Defining regular line of street.
(1)The Municipality may, with due regard to the minimum widths specified for various categories of
street including the footpaths adjoining the same, define the regular line on one or both sides of any
public street or portions thereof in accordance with the regulations made in this behalf and may
redefine at any time any such regular line :-Provided that before such defining or redefining, as the
case may be, the Municipality shall, by notice, afford a reasonable opportunity to the residents of
premises abutting on such public street to make suggestions or objections with respect to the
proposed defined or redefined line of the street and shall consider all such suggestions or objections
which may be made within one month from the date of publication of such notice:Provided further
that the street alignment of any public street operative under any law for the time being in force in
any part of the municipal area immediately before the commencement of this Act, shall be deemed
to be the regular line of such public street defined by the Municipality under this sub-section.(2)The
line defined or redefined shall be called the regular line of the street.(3)No person shall construct or
reconstruct any building or a portion thereof or any boundary wall or other structure whatsoever
within the regular line of a street.(4)The Chief Municipal Executive Officer/ Municipal Executive
Officer shall maintain a register containing such particulars as may be specified by the Municipality
in this behalf, with plans attached thereto, showing all public streets in respect of which the regular
line of the street has been defined or redefined and containing any other particulars which he may
deem necessary.(5)All such registers shall be open to inspection by any person on payment of such
fee, and any extract there from may be supplied on payment of such charge, as may be determined
by the Municipality by regulations.
328. Setting back Building to Regular line of street.
(1)If any part of a building on a public street is within the regular line of that street, the Municipality
may, proposed whenever necessary:-(a)to repair, rebuild or construct such building or to pull down
such building to an extent, measured in cubic metre, exceeding one-half thereof above the ground
level or,(b)to repair, remove, construct or reconstruct or make any additions to, or structural
alterations of, any portion of such building, which is within the regular line of the street, by order, as
respects the additions to, or rebuilding, construction, repair or alterations of, such building, to be set
back to the regular line of such street.(2)When any building or any part thereof within the regular
line of a public street falls down or is burnt down or is, whether by reason of any order of the
Municipality or otherwise, pulled down, the Chief Municipal Executive Officer/ Municipal Executive
Officer may forthwith take possession, on behalf of the Municipality, of the portion of the land
within the regular line of the street thereto occupied by such building and, if necessary, clear the
same.(3)Any land acquired under this section shall be deemed to be a part of the public street and
shall vest in the Municipality.Arunachal Pradesh Municipal Act, 2007

329. Compulsory setting back of building to regular line of street.
(1)Where any building or any part thereof is within the regular line of a public street and, in the
opinion of the Municipality, it is necessary to set back such building or part thereof to the regular
line of such street, the Chief Municipal Executive Officer/ Municipal Executive Officer shall, by a
notice served on the owner of such building in accordance with the provisions of this Act, require
him to show cause, within such period as may be specified in the notice, as to why such building or
part thereof, which is within the regular line of such street, should not be pulled down and the land
within the regular line acquired by the Municipality.(2)If the owner fails to show cause as required
under sub-section (1), the Chief Municipal Executive Officer/ Municipal Executive Officer may, with
the approval of the Municipality, require the owner, by another notice to be served on him in such
manner as may be specified by regulations, to pull down the building or part thereof, which is within
the regular line of the street, within such period as may be specified in the notice.
330. Setting forward of building to regular line of street.
- The Municipality may, upon such terms as it thinks fit, allow any building to be set forward for the
purpose of improving the regular line of a public street and may require any building to be set
forward in the case of reconstruction thereof or of a new construction.Explanation. - For the
purpose of this section, a wall separating any premises from a public street shall be deemed to be a
building, and it shall be deemed to be a sufficient compliance with the permission or the
requirement to set forward a building to the regular line of a street, if a wall of such materials and
dimensions, as are approved by the Municipality, is erected along such line.
331. Acquisition of open land and land occupied by platforms etc. within
regular line of street.
- If any land, whether open or enclosed, not vested in the Municipality and not occupied by any
building, is within the regular line of a public street or if any platform, verandah, step, compound
wall, hedge or fence or some other structure, authorized or not, external to a building abutting on a
public street, or a portion of such platform, verandah, step, compound wall, hedge, fence or other
structure is within the regular line of such street, the Chief Municipal Executive Officer/ Municipal
Executive Officer may, with the prior approval of the Municipality and after giving the owner of such
land or building not less than seven clear days' notice of his intention so to do, take possession, on
behalf of the Municipality, of such land with its enclosing wall, hedge or fence, if any, or of such
platform, verandah, step, compound wall, hedge, fence or other structure of any portion thereof
within the regular line of the public street, and, if necessary, clear the same, and the land so
acquired shall thereupon be deemed to be a part of the public street and shall vest in the
Municipality :Provided that where the land or the building is vested in the State Government or the
Central Government or any agency thereof, the Chief Municipal Executive Officer/ Municipal
Executive Officer shall not take possession thereof without the previous sanction of the State
Government or the Central Government, as the case may be.Arunachal Pradesh Municipal Act, 2007

332. Acquisition of remaining part of building and land after their portions
within regular line of street have been acquired.
(1)Where a land or building is partly within regular line of a public street and the Municipality is
satisfied that the land remaining after the excision of the portion within such line will not be suitable
or fit for any beneficial use, it may, at the request of the owner, acquire such land in addition to the
land within such line, and such surplus land shall be deemed to be part of the public street and shall
vest in the Municipality.(2)Such surplus land may, thereafter, be utilized for the purpose of setting
forward a building under section 330 or for such other purpose as the Municipality may deem fit.
333. Compensation to be paid in certain cases of setting back or setting
forward of building etc.
(1)A compensation shall be paid by the Municipality to the owner of any building or land acquired
for a public street under the provisions of section 328, section 329, section 331, or section 332 for
any loss which such owner may sustain in consequence of his building or land being so acquired and
for any expense incurred by such owner in consequence of any order made by the Municipality.(2)If,
in consequence of any order under section 330 to set forward a building, the owner of such building
sustains any loss or damage, compensation shall be paid to him by the Municipality for such loss or
damage.(3)If the additional land, which will be included in the premises of any person required or
permitted under sub-section (2) to set forward such building, belongs to the Municipality, the order
or permission of the Municipality to set forward the building shall be a sufficient conveyance to the
said owner of the said land, and the price to be paid to the Municipality by the said owner of such
additional land and the other terms and conditions of the conveyance shall be set forth in the order
or permission.(4)If, when the Municipality requires any building to be set forward, the owner of the
building is dissatisfied with the price fixed to be paid to the Municipality or with any of the terms or
conditions of conveyance, the Chief Municipal Executive Officer/ Municipal Executive Officer shall,
upon the applications of the owner at any time within fifteen days after the said terms and
conditions are communicated to him, refer the case to the court of the District Judge having
jurisdiction for determination, and the decision of the said court thereon shall be final.C.
Obstruction on Streets
334. Special provision regarding streets belonging to Central or State
Government.
(1)If any National highway, State highway, or a street is vested in the Central Government or the
State Government, as the case may be,-(a)the Municipality shall not, in respect of such national
highway, state highway, or street, grant permission to do any act, the doing of which without its
permission, in writing, would contravene the provisions of this Act, except with the sanction of the
Central Government or the State Government, as the case may be, and(b)if so required by the
Central Government or the State Government, the Municipality shall exercise the powers conferred
upon it by this Act or any regulations relating to such street.(2)In the case of roads vested in the
State Government, and passing through the municipal area, the Municipality shall have control overArunachal Pradesh Municipal Act, 2007

such roads in so far as permission for temporary occupation thereof and removal of encroachments
therefrom are concerned, but the maintenance of such roads shall remain with the State
Government.
335. Temporary erection on streets during festivals.
(1)The Chief Municipal Executive Officer/ Municipal Executive Officer may grant a permission, in
writing, for temporary erection of a booth, pandal, or any other structure on any public place on
occasions of ceremonies and festivals, on payment of such fee, and on such conditions, as may be
determined by the Municipality by regulations, and for such period as may be mentioned in the
letter of permission :Provided that no permission shall be given under this section without
consultation with the Superintendent of Police of the district or any police officer within such period
as may be mentioned in the letter of permission.(2)The person to whom such permission is granted
shall fill in the ground and reinstate the same to the satisfaction of the Chief Municipal Executive
Officer/ Municipal Executive Officer within such period as may be mentioned in the letter of
permission.
336. Precautions during construction or repair of street drain or premises.
- Subject to the terms and conditions as may be specified by regulations, the Chief Municipal
Executive Officer/ Municipal Executive Officer during construction or repair of any public street or
any municipal drain or any premises vested in the Municipality, shall -(a)cause the same to be
fenced and guarded,(b)take proper precaution against accident affection public street or adjoining
buildings,(c)prohibit, without his written permission, the deposit of any building material or the
setting up of any scaffolding or any temporary erection on any public street,(d)close any street
wholly or partly to traffic,(e)provide for necessary diversion of traffic, wherever necessary.(f)ensure
the reinstatement of the public street or restoration of any drain or premises to its original
condition, and(g)take steps for repairing or enclosing of any place which, in his opinion, is
dangerous or causing inconvenience to traffic along a street or to persons who have legal access
thereto or to the Neighborhood thereof, and recover the costs of such repair works from the owner
or the occupier of any such place or premises.
337. Power of Municipality in relation to regulation of street.
- Subject to such terms and conditions as may, from time to time, be specified by regulations, the
Municipality may -(a)prohibit or regulate vehicular traffic in any public street or any portion thereof
so as to prevent danger, obstruction or inconvenience to the public or injury to the
roadways.(b)prohibit, at all times or during any particular hours, entry of any vehicular traffic from,
or exit of such vehicular traffic into, any premises from any particular public street carrying such
traffic.(c)prohibit tethering of any animal for any purpose in any public street,(d)prohibit in any
street installation of structures or fixtures which may cause obstruction,(e)prohibit the opening of
the ground floor door, gate, bar or window outwards on any street,(f)prohibit projections upon any
street, or drain, or open channel in any street, and(g)remove anything erected, deposited or hawked
on any public place or public street in contravention of the provisions of this Act.Arunachal Pradesh Municipal Act, 2007

338. Restoration of municipal properties by public utilities.
(1)Subject to such terms and conditions as may be prescribed, any public utility concern requiring
the use of the sub-soil under any municipal street, drain, land or other property for the purpose of
laying lines for such utility service such as electric supply or telecommunication, shall obtain
permission of the Municipality for such use.(2)At the time of according such permission, the
Municipality shall, in consultation with such public utility, arrive at the full cost of restoration of the
sub-soil and the surface thereon and obtain an undertaking from the public utility that such
restoration shall be done at their cost so as to bring back the property to its original condition to the
satisfaction of the Municipality within a reasonable time after the completion of the work.
Chapter XXXVII
Buildings
A. Procedure
339. Definitions.
- In this chapter, unless the context otherwise requires, the expression-(1)"to erect a building"
means -(a)to erect a new building on any site, whether previously built upon or not,(b)to re-erect
means-(i)any building of which more than one-half of the cubical extent above the level of plinth
have been pulled down, burnt or destroyed, or(ii)any building of which more than one-half of the
superficial area of the external walls above the level of plinth has been pulled down, or(iii)any
frame-building of which more than half of the number of posts or beams in the external walls have
been pulled down,(c)to convert into a dwelling-house any building or any part of a building not
originally so constructed for human habitation or, if originally so constructed for human habitation,
subsequently appropriated for any other purpose,(d)to convert into more than one dwelling-house a
building originally constructed as one dwelling-house only,(e)to convert into a place of religious
worship or into a sacred building any place or building, not originally constructed for such
purpose,(f)to roof or cover an open space between walls or buildings to the extent of the structure
formed by the roofing or covering of such space,(g)to convert two or more tenements in a building
into a greater or lesser number of such tenements,(h)to convert into a stall, shop, office, warehouse
or godown, workshop, factory or garage any building not originally constructed for use as such, or to
convert any building constructed for such use, by sub-division or addition, into greater or lesser
number of such stalls, shops, offices, warehouses or godowns, workshops, factories or garages,(i)to
convert a building, which, when originally constructed, was legally exempt from the operation of any
building regulations or any rules made under this Act or in any other law for the time being in force,
into a building which, had it been originally erected in its converted form, would have been subject
to such building regulations,(j)to convert into, or use as, a dwelling-house any building, which has
been discontinued as, or appropriated for any purpose other than, a dwelling-house,(k)to make any
addition to a building, and(l)to remove or reconstruct the principal staircase of a building or to alter
its position ;(2)"occupancy" or use-group" means the principal occupancy for which a building or a
part of a building is used or intended to be used, and the occupancy classification shall, unlessArunachal Pradesh Municipal Act, 2007

otherwise spelt out in any development plan or any other improvement scheme under any law for
the time being in force, include -(a)residential buildings, that is to say, any building in which
sleeping accommodation is provided for normal residential purposes with or without cooking facility
or dining facility or both, and such building shall include one or two or multi-family dwelling,
lodging or rooming houses, hostels, dormitories, apartment houses and flats, and private
garages,(b)educational buildings, that is to say, any building used for school, college or day-care
purposes involving assembly for instruction, education or recreation incidental to educational
use,(c)institutional buildings, that is to say, any building or part thereof ordinarily providing
sleeping accommodation for occupants and used for the purposes of medical or other treatment or
care of persons suffering from physical or mental illness, disease or infirmity, care of infants,
convalescents or aged persons and for penal or correctional detention in which the liberty of the
inmates is restricted, and such buildings shall include hospitals, clinics, dispensaries, sanatoria,
custodial institutions, and penal institutions like jails, prisons, mental hospitals and
reformatories,(d)assembly buildings, that is to say, any building or part thereof where groups of
people congregate or gather for amusement or recreation or for social, religious, patriotic, civic,
travel, sports, and similar other purposes, and such buildings shall include theatres, motion picture
houses, drive-in-theatres, city halls, town halls, auditoria, exhibition halls, museums, skating rinks,
gymnasia, restaurants, eating-houses, hotels, boarding-houses, places of worship, dance halls, club
rooms, gymkhanas, passenger stations and terminals of air, surface and other public transportation
services, recreation piers, and stadium,(e)business buildings, that is to say, any building or part
thereof used for transaction of business or for the keeping of accounts and records or for similar
purposes and such buildings shall include offices, banks, professional establishments, court houses,
and libraries for the principal function of transaction of public business and keeping of books and
records, and shall also include office buildings (premises) solely or principally used as and office of
for office purpose.(f)Mercantile buildings, that is to say any building or part thereof used as shops,
stores or markets for display or sale or merchandise, either wholesale or retail or for office, storage
or service facilities incidental to the sale of merchandise and located in the same building and such
building shall include establishments wholly or partly engaged in wholesale trade, manufacturer's
whole sale outlets (including related storage facilities) warehouses, and establishment engaged in
truck transport (including truck transport booking agencies).(g)Industrial buildings, that is to say
any building or structure or part thereof in which products or materials of all kinds and properties
are fabricated, assembled or processed as in assembly plants and such buildings shall include
laboratories, power plants, smoke houses, refineries, gas plants, mills, dairies, factories, workshops,
automobile repair garages and printing presses.(h)Storage buildings, that is to say any building or
part thereof used primarily for the storage or sheltering of goods, wares or merchandise as in
warehouse and such building shall include cold storages, freight depots, transit sheds, store houses,
public garages, hangars, truck terminals, grain elevators, barns and stables,(i)Hazardous buildings,
that is to say any building or part thereof used for the storage, handling, manufacture or processing
of highly combustible or explosive materials or products, which are liable to burn with extreme
rapidity or which may produce poisonous fumes or explosions during storage, handling,
manufacture or processing or which involve highly corrosive, toxic or noxious alkalis, acids or other
liquid or chemicals producing flames, fumes, explosions or mixtures of dust or which result in the
division of matter into fine particles subject to spontaneous ignition :(3)"alteration" means the
change from one occupancy to another or the structural change, such as the addition to any area orArunachal Pradesh Municipal Act, 2007

height or the removal of a part of building or the change to the structure such as the construction or
cutting into or removal of any wall, partition, column, beams, joints, floor or other support of the
change to or closing of any required means of ingress or egress or the change to any fixture or
equipment ;(4)"plan" means a plan prepared by a surveyor or a draughtsman or an engineer holding
a degree of Bachelor of Engineering or an Architect registered under the Architect Act, 1972 (20 of
1972).Explanation. - For the purpose of classification of a building according to occupancy under
clause (2),(a)an occupancy shall be deemed to included subsidiary occupancies which are contingent
upon such occupancy, and(b)building with mixed occupancies shall mean those building in which
more than one occupancy are present in different portions thereof.
340. Prohibition of erection without sanction.
- No person shall erect, or commence to erect any building or execute any of the works specified in
section 339 in any municipal area, in accordance with the provision of this Act and the regulation
made thereunder in relation to such erection of building or execution of work, as the case may be
:Provided that the erection of a residential building upto a height of three storeys, or with a height of
eleven meters whichever is lower on a plot of land of three hundred square meter or less may be
commenced and may be proceeded with if the building plan has been prepared by an architect
registered under the Architect Act, 1972 (Act 2 of 1972) and authenticated by him certifying that the
building plan for such erection conforms to the provision of this Act and the rules and the
regulations made there under :Provided further that any such plan shall be submitted to the Chief
Municipal Executive Officer/ Municipal Executive Officer before commencement of the work
referred to in the first proviso for sanction thereof in due course :Provided also that if any deviation
from the provisions of this Act or the rules or the regulations made there under or any material
deviation from such plan is detected in erection of any such building, the Chief Municipal Executive
Officer/ Municipal Executive Officer may take necessary action against such person in accordance
with the provisions of this Act or the rules or the regulations made thereunder and in the case of any
deviation from the provisions of this Act, or the rules or the regulations made thereunder send a
report to the Institution of Architect or the Council of Architecture against the architect who
prepared the building plan and authenticated it by certifying that the building plan conforms to the
provisions of this Act or the rules or the regulations made there under for such action as the
Institution of Architects may deem fit :Provided also that the Chief Municipal Executive Officer/
Municipal Executive Officer shall by order direct that no certification by such architect in respect of
any building plan shall be accepted by the Municipality till a decision on the aforesaid report is
received from the Institution of Architects or the Council of Architecture by the Chief Municipal
Executive Officer/ Municipal Executive Officer:Provided also that in a case where the Chief
Municipal Executive Officer/ Municipal Executive Officer has sanctioned or provisionally
sanctioned erection of any building above a height of fourteen meters, he shall cause publication of
the fact of such sanction in such form and in such manner as may be prescribed, at the cost of the
person in whose favour such sanction has been given.Arunachal Pradesh Municipal Act, 2007

341. Erection of building.
(1)Subject to the provisions of section 340, every person who intends to erect a building shall apply
for sanction by giving a notice, in writing of his intention to the Chief Municipal Executive Officer/
Municipal Executive Officer in such form and containing such information as may be
prescribed.(2)Every such notice shall be accompanied by such documents and plans as may be
prescribed.
342. Application for addition to or repair of building.
(1)Subject to the provision of section 340, every person who intends to execute any of the works
specified in sub-section (b) of clause (1) of section 339 shall apply to the Chief Municipal Executive
Officer/ Municipal Executive Officer for sanction by giving a notice, in writing of his intension in
such form and containing such information as may be prescribed.(2)Every such notice shall be
accompanied by such documents and plans as may be prescribed.
343. Purpose for which building to be used and conditions of validity of
notice.
(1)Every person giving any notice of his intention to erect a building under section 431 shall specify
the purpose for which such building is intended to be used :Provided that for any building not more
than one class of use consisted with the occupancy or the use group within the meaning of clause (2)
of section 339, shall be considered except in respect of the case where under this Act or under any
other law for the time being in force, mixed occupancies of specified nature may be
permissible.(2)Every person giving any notice under section 341 of his intention to execute any of
the works specified in sub-clause (b) of clause (1) of section 339, shall specify whether the original
purpose for which such work as intended to be executed, is proposed or is likely to be changed by
such execution of work :Provided that if such change would result in mixed occupancies which are
contrary to the provisions of this Act or of any other law for the time being in force such change shall
not be allowed.(3)No notice shall be valid until the information required under sub-section (1) or
subsection(2)and any other information and plans which may be required by regulations made
under this Act have been furnished to the satisfaction of the Chief Municipal Executive Officer/
Municipal Executive Officer along with the notice.
344. Sanction or provisional sanction of refusal of building or work.
(1)Subject to the provision of section 340, the Chief Municipal Executive Officer/ Municipal
Executive Officer shall sanction, or provisionally sanction the erection of a building of the execution
of a work within the municipal area, unless such building or work would contravene any of the
provision of sub-section (2) of this section or the provision of section 355 or section 357.Provided
that no such sanction shall be accorded without the prior approval of the Empowered Standing
Committee in the case of any building, except a residential building proposed to be erected or
re-erected on a plot of land of five hundred square meters or less:Provided further that theArunachal Pradesh Municipal Act, 2007

Empowered Standing Committee shall consider the recommendation of the Municipal Building
Committee, and shall finalize its decision after such consideration.(2)The sanction for erection of a
building or execution of a work may be refused on the following grounds, namely :(a)that the
building or the work or the use of the site for the building or the work or any of the particulars
comprised in the site plan, ground plan, elevation, section or specification would contravene the
provisions of this Act or the rules or the regulations made thereunder or of any other law for the
time being in force or any scheme sanctioned thereunder,(b)that the notice for sanction does not
contain the particulars or is not prepared in the manner, required under the rules or the regulations
made in this behalf under this Act,(c)that any information or document required by the Chief
Municipal Executive Officer/ Municipal Executive Officer under this Act or the rules or the
regulations made thereunder has not been duly furnished,(d)that the building or the work would be
an encroachment on the State Government land or land vested in the Municipality, and(e)that the
site of the building or the work does not abut on a street or projected street and that there is no
access to such building or work from any such street by any passage or pathway appertaining to such
site.(3)Notwithstanding anything contained in this Act, the Chief Municipal Executive Officer/
Municipal Executive Officer may while granting permission under this chapter, specify such special
conditions relevant to each case, regarding disposal of solid, liquid or gaseous wastes or for parking
of vehicles or for loading or unloading of goods or for abatement of nuisance of any kind whatsoever
as he deems fit.(4)The Chief Municipal Executive Officer/ Municipal Executive Officer shall
communicate the sanction or the provisional sanction to the person who has given the notice under
section 341 or section 342 and where he refuses sanction or provisional sanction, either on any of
the grounds specified in sub-section (2) or under section 355 or section 357, he shall record a brief
statement of his reasons for such refusal in writing and shall communicate the refusal along with the
reason therefor to the person who has given the notice.(5)The sanction or the provisional sanction
or the refusal of sanction to the erection of a building or the execution of a work shall be
communicated in such manner as may be prescribed and in the case of sanction or provisional to the
erection of a building, the occupancy or use group shall be specifically stated in such sanction.
345. Municipal Building Committee for Municipal Councils or Nagar
Panchayats.
(1)In the case of a Municipal Councils or Nagar Panchayats, the Empowered Standing Committee
shall constitute a Municipal Building Committee with the Chief Municipal Executive Officer/
Municipal Executive Officer as its Chairperson and an officer of the Municipality as its
convenor.(2)The Municipal Building Committee shall have in addition to the Chairperson and the
convenor, six other members of whom :(a)one shall be an officer of the planning and development
authority for the municipal area under any law for the time being in force,(b)one shall be an officer
of the police authority responsible for traffic in the municipal area,(c)one shall be an officer of the
fire services having jurisdiction over the municipal area,(d)one shall be an architect having
experience of not less than five year,(e)one shall be an Civil Engineer having experience of not less
than five year,(f)one shall be an officer for the authority responsible for environmental management
of the municipal area and,(g)one shall be an officer of the State Government nominated by the State
Government.(3)The Municipal Building Committee may co-opt one person to be nominated by the
concerned department of the State Government while dealing with any case regarding anyArunachal Pradesh Municipal Act, 2007

educational building or institutional building or assembly building or industrial building or
hazardous building.(4)The Municipal Building Committee shall meet at such periodical intervals as
may be necessary but not less than once in every calendar month,(5)The Municipal Building
Committee shall scrutinize every application for erection or re-erection of a building for which
notice has been received under section 341, other than a residential building up to three storeys or
with a height of twelve meters whichever is higher on a plot of land of five hundred square meters or
less and make its recommendations :Provided that in respect of any building or execution of any
work, if such building or work as the case may be affects or is likely to affect -(i)the functioning of
the microwave system for telecommunication purposes, or(ii)any function for the purpose of civil
aviation, the Municipal Building Committee shall, if so considered necessary, refer the matter to the
concerned Department of the Central Government or authority for opinion before finalizing the
recommendations.(6)The recommendation of the Municipal Building Committee shall be referred
to the Empowered Standing Committee for its consideration and approval with or without
change:Provided that the reasons for any deviation from the recommendations shall be recorded in
writing.(7)The manner of conduct of business of the Municipal Building Committee and the
procedure to be followed by its shall be such as may be specified by regulations.
346. Committee for sanction of building plans in case of Class "C" Municipal
Councils and Nagar Panchayats.
- The State Government shall by order, in writing, constitute a Committee or Committee to deal with
the sanction of building plan for Class "C" Municipal Councils or Nagar Panchayats in the specified
municipal areas.
347. Sanction or provisional sanction accorded under misrepresentation.
- If, at any time after the communication of sanction or provisional sanction to the erection of any
building or the execution of any work, the Chief Municipal Executive Officer/ Municipal Executive
Officer is satisfied that such sanction or provisional sanction was accorded in consequence of any
materials misrepresentation or any fraudulent statement in the notice given or information
furnished under section 341 or section 342 or section 343, he may by order in writing, cancel for
reasons to be recorded in writing such sanction or provisional sanction as the case may be and any
building or any work commenced, erected or executed shall be deemed to have been commenced,
erected or executed without such sanction and shall be dealt with accordingly under the provisions
of this chapter :Provided that before making any such order, the Chief Municipal Executive Officer/
Municipal Executive Officer shall give a reasonable opportunity to the person affected to show cause
as to why such order should not be made.
348. When building or work may be proceeded with.
(1)Where within a period of sixty days or in cases falling under sub-clause (b) to sub clause (1) of the
clause (1) of section 339 within a period of thirty days of the receipt of any notice under section 341
or section 342 or of any information under section 343 the Chief Municipal Executive Officer/Arunachal Pradesh Municipal Act, 2007

Municipal Executive Officer does not refuse to sanction to the erection of any building or the
execution of any work or upon refusal does not communicate the refusal to the person who has
given the notice such person may make a representation in writing to the Chief Councillor :Provided
that if it appears to the Chief Municipal Executive Officer/ Municipal Executive Officer that the site
of the proposed building or work is likely to be affected by any scheme of acquisition of land for any
public purpose or by any proposed regular line of a public street or extension, improvement,
widening or alteration of any street, the Chief Municipal Executive Officer/ Municipal Executive
Officer may withheld sanction to the erection of the building or the execution of the work for such
period, not exceeding six months as he may deem fit and the period of sixty days as the case may be
the period of thirty days specified in this sub-section shall be deemed to commence from the date of
expiry of the period for which the sanction has been withheld.(2)Where the erection of building or
the execution of a work is sanctioned the person who has given the notice shall erect the building or
execute the work in accordance with such sanction and shall not contravene any of the provisions of
this Act or the rules or the regulation made there under or of any other law for the time being in
force,(3)If the person as aforesaid or any one lawfully claiming under him does not commence the
erection of the building or the execution of the work within two years of the date on which the
erection of the building or the execution of the work as the case may be, is sanctioned, he shall give
notice under section 341 or as the case may under section 342 for fresh sanction and the provisions
of this section shall apply in relation to such notice as they apply in relation to the original
notice.(4)Such person shall before commencing the erection of the building or the execution of the
work within the period specified in sub-section (3) shall give notice to the Chief Municipal Executive
Officer/ Municipal Executive Officer of the proposed date of commencement of such erection or
execution :Provided that if the commencement does not take place within fifteen days of the date of
the notice, the notice shall be deemed not to have been given and fresh notice shall be necessary in
this behalf.
349. Period for completion of building or work.
- The Chief Municipal Executive Officer/ Municipal Executive Officer shall while sanctioning the
erection of a building or the execution of a work, specify a reasonable period within which the
building or the work is to be completed and if the building or the work is not completed within the
period so specified, it shall not be continued thereafter without fresh sanction obtained in the
manner hereinbefore provided, unless the Chief Municipal Executive Officer/ Municipal Executive
Officer on an application made in this behalf, allows an extension of such period.
350. Order of demolition and stoppage of buildings or work in certain cases
and appeal.
(1)Where the erection of any building or the execution of any work has been commenced or is being
carried on or has been completed without or contrary to the sanction referred to in section 344 or in
contravention of any of the provisions of this Act or the rules or the regulations made thereunder,
the Chief Municipal Executive Officer/ Municipal Executive Officer may in addition to any other
action that may be taken under this Act, make an order directing that such erection or work shall be
demolished by the person at whose instance the erection or the work has been commenced or isArunachal Pradesh Municipal Act, 2007

being carried on or has been completed within such period not being less than five days and more
than fifteen days from the date on which a copy of the order of demolition with a brief statement of
the reasons therefore has been delivered to such person, as may be specified in the order :Provided
that no order of demolition shall be made unless such person has been given by means of a notice
served in such manner as the Chief Municipal Executive Officer/ Municipal Executive Officer may
think fit an opportunity of showing cause why such order shall not be made :Provided further that
where the erection of any building or the execution of any work has not been completed, the Chief
Municipal Executive Officer/ Municipal Executive Officer may by the same order or by a separate
order, whether made at the time of the issue of the notice under the first proviso or any time, direct
such person to stop the erection of such building or the execution of such work until the expiry of
the period within which an appeal against the order of demolition, if made may be preferred under
sub-section (3).Explanation. - In this chapter, " the person at whose instance" shall mean the owner
or the occupier or any other person who causes the erection of any building or the execution of any
work including alterations or additions of any to be some or does it by himself.(2)The Chief
Municipal Executive Officer/ Municipal Executive Officer may make an order under sub-section (1)
notwithstanding the fact that the assessment of such building has been made for the levy of the
property tax on lands and buildings.(3)Any persons aggrieved by an order of the Chief Municipal
Executive Officer/ Municipal Executive Officer under sub-section (1) may, within thirty days from
the date of the order, prefer an appeal against the order to the Municipal Building Tribunal
appointed under section 356.(4)Where as appeal is prepared under sub-section (3) against an order
under sub-section (1) the Municipal Building Tribunal may stay the enforcement of the order on
such terms, if any and for such periods as it may think fit :Provided that where the erection of any
building or the execution of any work has not been completed at the time of the order under that
sub-section (1), no order staying the enforcement of the order under that sub-section shall be made
by the Municipal Building Tribunal unless a surety, sufficient in the opinion of that Tribunal has
been given by the appellant for not proceeding with such erection or work pending the disposal of
the appeal.(5)Save as provided in this section, no court shall entertain any suit, application or other
proceeding for injunction or other relief against the Chief Municipal Executive Officer/ Municipal
Executive Officer to restraint him from taking any action, or making any order in pursuance of the
provisions of this section.(6)Every order made by the Municipal Building Tribunal on appeal and
subject to such order every order made by the Chief Municipal Executive Officer/ Municipal
Executive Officer under sub-section (1) shall be final and conclusive.(7)Where no appeal has been
preferred against an order made by the Chief Municipal Executive Officer/Municipal Executive
Officer under sub-section (1) or where an order under that sub-section has been confirmed on
appeal whether with or without modification the person against whom the order has been made
shall comply with the order within the period if any fixed by the Municipal Building Tribunal on
appeal and on the failure of such person to comply with the order within such period the Chief
Municipal Executive Officer/ Municipal Executive Officer may himself cause the building or the
work to which the order relates to be demolished and the expenses of such demolition shall be
recoverable from such person as an arrear of tax under this Act.(8)Notwithstanding anything
contained in this chapter, if the Empowered Standing Committee is of the opinion that immediate
action is called for in relation to a building or a work being carried on in contravention of the
provisions of this Act, it may for reasons to be recorded in writing cause such building or work to be
demolished forthwith.Arunachal Pradesh Municipal Act, 2007

351. Order of stoppage of building or work in certain cases.
(1)Where the demolition of any building or the erection of any building or the execution of any work
has been commenced or is being carried on without or contrary to the sanction referred to in section
344 or in contravention of any conditions subjects to which such sanction has been accorded or in
contravention of any provision of this Act or the rules or the regulations made there-under, the Chief
Municipal Executive Officer/ Municipal Executive Officer may in addition to any other action that
may be taken under this Act, by order require the person at whose instance the building or the work
has been commenced or is being carried on to stop the same forthwith.(2)(a)Notwithstanding
anything contained elsewhere in this Act or in any rules or regulations made there-under no owner
of any building and no person engaged in the construction of any building on behalf of the owner
thereof, shall allow storage or stagnation of water in the site for the construction of such building
and every such owner or every such person, as the case may be shall completely empty all collections
of such water at least once in a week.(b)Where the construction of a building is carried on in
contravention of the provisions of clause (a) the Chief Municipal Executive Officer/ Municipal
Executive Officer may in addition to any other action that may be taken under this Act, by order in
writing require the person at whose instance such storage or stagnation of water in the site for the
construction of the building is made to stop forthwith any further construction of the building and
such orders shall remain in force till the person as aforesaid complies with the requirements of the
order as aforesaid, to the satisfaction of the Chief Municipal Executive Officer/ Municipal Executive
Officer.(3)If an order by the Chief Municipal Executive Officer/ Municipal Executive Officer under
clause (b) of sub-section (2) directing any person to stop the construction of any building is not
complied with the Chief Municipal Executive Officer/ Municipal Executive Officer may take such
measures as he deems fit or may require any police officer to remove such person and all his
assistants and workmen from the premises within such time as may be specified by the Chief
Municipal Executive Officer/ Municipal Executive Officer and such police officer shall comply with
such requirement.(4)If an order by the Chief Municipal Executive Officer/ Municipal Executive
Officer under section 350 or under sub-section (1) of this section, directing any person to stop the
erection of any building or the execution of any work, is not complied with the Chief Municipal
Executive Officer/ Municipal Executive Officer may take such measures as he deems fit or may
require any police officer to remove such person and all his assistant and workmen from the
premises within such times as may be specified by the Chief Municipal Executive Officer/ Municipal
Executive Officer and such police officer shall comply with such requirements.(5)No court shall
entertain any suit application or other proceeding for injunction or other relief against the Chief
Municipal Executive Officer/ Municipal Executive Officer to restrain him from taking any action or
making any order in pursuance of the provisions of this section.(6)On the compliance with the
requirement under sub-section (5) the Chief Municipal Executive Officer/ Municipal Executive
Officer may, if he thinks fit, depute by an order in writing a police officer or an officer or other
employee of the Municipality to watch the premises in order to ensure that the erection of the
building or the execution of the work is not continued.(7)Where a police officer or an officer or other
employee of the Municipality has been deputed under sub-section (6) to watch the premises the cost
of such deputation to be determined by the Municipality by regulations, shall be paid by the person
at whose instance such erection or execution is being continued or to whom notice under subsection
(1) has been given and shall be recoverable from such person as an arrear of tax under this Act.Arunachal Pradesh Municipal Act, 2007

352. Construction of building in contravention of the provisions of the Act or
the rules made thereunder.
(1)Notwithstanding anything contained in this Act or the rules made there-under or in any other law
for the time being in force, any person who being responsible by himself or by any other person on
his behalf so constructs or attempts or conspires to so construct any new building or additional floor
or floors of any building, in contravention of the provisions of this Act or the rules made
there-under, as endangers or is likely to endanger human life or any property of the Municipality
whereupon the water supply, drainage or sewerage of the road traffic is disrupted or is likely to be
disrupted or is likely to cause a fire hazard shall be punishable with imprisonment of either
description for a term which may extend for five years and also with fine which may extend to fifty
thousand rupees.Explanation. - "Person" shall include an owner, occupier, lessee, mortgagee,
consultant, promoter or financier or a servant or agent of an owner, occupier, lessee, mortgagee,
consultant, promoter or financier who supervises or cause the construction of any new building or
additional floor or floors of any buildings as aforesaid.(2)The offence under sub-section (1) shall be
cognizable and non-bailable within the meaning of the Code of Criminal Procedure, 1973.(3)Where
an offence under sub-section (1) has been committed by a company the provisions of section 465 of
this Act shall apply to such company.Explanation. - "Company" shall have the same meaning as in
the Explanation to section 465.
353. Power of the Chief Municipal Executive Officer/Municipal Executive
Officer to require alteration of work.
(1)The Chief Municipal Executive Officer/ Municipal Executive Officer may at any time during the
erection of any building or the execution of any work or at any time within three months after the
completion thereof, by notice in writing specify any matter in respect of which such erection or
execution is without or contrary to the sanction referred to in section 344 or is in contravention of
any condition of such sanction or of any of the provisions of this Act or the rules or the regulations
made there-under and require the person who gave the notice under section 341 or section 342 or
the owner of such building or work either -(a)to make such alterations as may be specified by the
Chief Municipal Executive Officer/Municipal Executive Officer in the notice with the object of
bringing the building or the work in conformity with such sanction or such condition of such
sanction or the provisions of this Act or the rules or the regulations made thereunder, or(b)to show
cause within such period as may be stated in the notice, why such alterations should not be
made.(2)If such person or such owner does not show any cause as aforesaid, he shall be bound to
make the alterations specified in the notice.(3)If such person or such owner shows the cause as
aforesaid, the Chief Municipal Executive Officer/ Municipal Executive Officer shall by order either
cancel the notice issued under sub-section (1) or confirm the same subject to such modification as
he thinks fit.Arunachal Pradesh Municipal Act, 2007

354. Completion certificate.
(1)Every person giving a notice under section 341 or section 342 or every owner of a building or
work to which such notice relates shall within one month after completion of erection of such
building or execution of such work, deliver or send or cause to be delivered or sent to the Chief
Municipal Executive Officer/ Municipal Executive Officer a notice in writing of such completion
accompanied by a certificate in the form specified in the rules made in this behalf and shall gives to
the Chief Municipal Executive Officer/ Municipal Executive Officer all necessary facilities inspection
of such building or work.(2)No person shall occupy or permit any other person to occupy any such
building or use or permit any other person to use any buildings or a part thereof affected by any
such work until permission has been granted by the Chief Municipal Executive Officer/ Municipal
Executive Officer in this behalf in accordance with the rules and the regulations made under this Act
:Provided that if the Chief Municipal Executive Officer/ Municipal Executive Officer fails within a
period of thirty days of receipt of the notice of completion to communicate his refusal to grant such
permission such person may make a representation in writing to the Chief Councillor.B. Municipal
Building Code
355. Power of State Government to make building rules and to classify
municipal areas for the purpose of application of building rules.
(1)The State Government shall prepare a Code to be called the Municipal Building Code containing
rules providing for -(a)the regulation or restriction of the use of sites for buildings,(b)the regulation
or restriction of buildings and(c)compliance with the provision of any law relating to urban land
ceiling or urban land use planning.(2)without prejudice to the generality of the foregoing power
such Code may provide for all or any of the following matters :-(a)information and plans to be
submitted together with application under any of the provision of this chapter,(b)requirements of
sites,(c)means of access,(d)development of land into land sub-division and layout,(e)land use
classification and uses,(f)open space area and height limitations,(g)parking spaces,(h)requirement
of parts of building plinth, habitable room, kitchen, pantry, bathroom, water closet, loft, ledge,
mezzanine floor, store-room garage, roof, basement, chimney, lighting and ventilation of room,
parapet, wells, septic tanks and boundary wall,(i)provisions of lifts,(j)exit requirement including
doorways, corridors, passageways, staircase, ramps and lobbies,(k)fire protection requirement
including materials and designs for interior decoration,(l)special requirement of occupancies for
residential building, educational building, institutional building, assembly building, business
building, mercantile building, industrial building, storage building and hazardous building
(including those for assembly movement, parking loading, unloading, public convenience, water
supply and vendors plazas),(m)structural design,(n)quality of materials and
workmanship,(o)alternative materials, method of design, construction and tests,(p)building service
including electric supply and such supply from non-conventional sources of energy, air conditioning
or heating and telecommunication systems,(q)water supply, water harvesting and plumbing
services,(r)signs and outdoor display structures,(s)special requirement for building in the hill
areas,(t)special requirement of access for handicapped persons in respect of matters referred to in
chapter XXII, chapter XXIII, chapter XXIV and chapter XXV,(u)protection against natural disasters
including earthquakes any cyclones and technological disasters and(v)any other matter consideredArunachal Pradesh Municipal Act, 2007

necessary in relation to building activities.(3)The State Government may by notification exempt any
municipal area or any group of municipal areas as classified under section 7 from the operation of
all or any of the provisions of this chapter or the rules made under this section.(4)While such
exemption under sub-section (3) remains in force in any municipal area or group of municipal
areas, the State Government may make rules consistent with the provision of this chapter for
application to such municipal area or group of municipal areas.(5)Notwithstanding anything
contained in the foregoing provisions of this section, no building plan for a building on such plot
area, or for such use as may be prescribed which does not provide for electric supply from
non-conventional sources of energy and water harvesting shall be sanctioned by the Municipality.C.
Municipal Building Tribunal
356. Municipal Building Tribunal.
(1)The State Government may appoint one or more Municipal Building Tribunals (hereinafter
referred to in this section as the Tribunal) as may considered necessary to hear and decide appeals
arising out of matters referred to in chapter XXXVII in accordance with such procedure, and to
realize such fees in connection with such appeals, as may be prescribed.(2)Each Tribunal shall
consist of a Chairperson and such other members, not exceeding four, as the State Government may
determine.(3)The Chairperson and one other member shall be persons who are or have been
members of the State Higher Judicial Service, having such experience as may be prescribed.(4)At
least one of the remaining other members shall be a person who shall have such knowledge or
experience in town planning, civil engineering or architecture as may be prescribed.(5)The
Chairperson and the other members of the Tribunal shall be appointed by the State Government for
such period, and on such terms and conditions, as the State Government may determine and shall
be paid from the Municipal Fund :Provided that a Councillor or a person who is or has been an
officer or other employee of the Municipality shall not be eligible for appointment as a member of
the Tribunal.(6)The State Government may, if it thinks fit, remove for reason of incompetence or
misconduct or for any other good or sufficient reason the Chairperson or any other member of the
Tribunal.(7)The Tribunal shall have such officers and other employees, appointed on such terms
and conditions, as may be prescribed, and the expenses of the Tribunal shall be paid out of the
Municipal Fund.(8)The Provisions of Part II and Part III of the Limitation Act, 1963, relating to
appeal shall apply to every appeal preferred under this section.(9)No court shall have jurisdiction in
any matter for which provision is made in this chapter for appeal to the Tribunal.D. General Powers
357. Building at corners of streets.
(1)Notwithstanding anything contained in this Act or the rules and the regulations made thereunder
or of any other law for the time being in force, the Chief Municipal Executive Officer/ Municipal
Executive Officer may, in the case of any building which is intended to be erected at the corner of
two streets, -(a)refuse sanction for such reasons as may be recorded in writing, or(b)impose
restrictions on its use, or(c)place special conditions concerning exit to, or entry from, any street,
or(d)require it to be rounded off or splayed or cut off to such height and to such extent as he may
determine, or(e)acquire such portion of the site at the corner as he may consider necessary for
public convenience or amenity :Provided that nothing shall be done in any case under the provisionsArunachal Pradesh Municipal Act, 2007

of this subsection without any scrutiny of such case by the Municipal Building Committee for a
Municipal Corporation, Class 'A' Municipal Council and Class 'B' Municipal Council, constituted
under section 345, or the Committee for sanction of building plans in case of building plans for Class
'C' Municipal Councils and Nagar Panchayats, constituted under section 346, as the case may be,
and without prior approval of the Empowered Standing Committee in accordance with the
provisions of this chapter.(2)The Chief Municipal Executive Officer/ Municipal Executive Officer
may, by order, in writing, require any alteration, corresponding to any of the provisions in clauses
(b) to (e) of sub-section (1), to be made to any building completed before the commencement of this
Act.
358. Provision as to building and work on either side of new street or near
fly-over or transportation terminal.
(1)The sanction to the erection of any work on either side of a new street may be refused by the Chief
Municipal Executive Officer/ Municipal Executive Officer unless and until such new street has been
leveled, and, in the opinion of the Chief Municipal Executive Officer/ Municipal Executive Officer,
wherever practicable, metalled or paved, drained, lighted and laid with a water main, to his
satisfaction.(2)The sanction to the erection of any such building or the execution of any such work
may be refused by the Chief Municipal Executive Officer/ Municipal Executive Officer, if such
building or any portion thereof or such work comes within the regular line of any street, the position
and direction of which have been laid down by the Chief Municipal Executive Officer/ Municipal
Executive Officer but which has not been actually erected or executed, or if such building or any
portion thereof or such work is in contravention of any building plan or any other scheme or plan
prepared under this Act or any other law for the time being in force.(3)The Chief Municipal
Executive Officer/ Municipal Executive Officer may refuse permission for the erection or re-erection
of any building which, when completed, will be within such distance from a fly-over or over bridge
or transportation terminal or other construction as may be provided by rules or regulations made in
this behalf.
359. Provision against use of inflammable material for building etc. without
permission.
(1)No roof, verandah, pandal or wall or a building or no shed or fence shall be constructed or
reconstructed of cloth, grass leaves, mats or other inflammable materials except with the
permission, in writing, of the Chief Municipal Executive Officer/ Municipal Executive Officer, nor
shall any such roof, verandah, pandal, wall shed or fence, constructed or reconstructed in any year,
be retained in a subsequent year except with the fresh permission obtained in this behalf.(2)Every
permission under sub-section (1) shall expire at the end of the year for which it is granted.(3)The
Chief Municipal Executive Officer/ Municipal Executive Officer may regulate the use of materials,
design or construction or other practices for interior decoration in accordance with the rules and the
regulations in this behalf.Arunachal Pradesh Municipal Act, 2007

360. Power to regulate future construction of buildings in particular streets or
localities.
(1)The Chief Municipal Executive Officer/ Municipal Executive Officer may, subject to the prior
approval of the Empowered Standing Committee, give notice of his intention to declare -(a)that in
any street or portion thereof specified in such notice, the elevation and construction of the frontage
of all buildings or any classes of buildings erected or re-erected after such notice shall, in respect of
their architectural features, be such as the Empowered Standing Committee may consider suitable
to the locality, or(b)that in any locality specified in such notice, there shall be allowed the erection of
only detached or semi-detached building or both and that the land appurtenant to each such
building shall be of an area, being not less than that specified in such notice, or(c)that the division or
sub-division of building plots in a particular locality shall be of a minimum specified area, or(d)that
in any locality specified in the notice, the construction of more than a specified number of buildings
on each acre of land shall not be allowed, or(e)that in any street, portion of a street, or locality,
specified in such notice, the construction of any one or more of the different classes of buildings
(such as residential, educational, institutional, assembly, business, mercantile, industrial, storage,
and hazardous buildings) shall not be allowed without the special permission of the Empowered
Standing Committee.(2)The Empowered Standing Committee shall consider all suggestions or
objections received within a period of three months of the publications of such notice and may
confirm the declaration or may modify it so however that the effect of such notice is not
extended.(3)The Chief Municipal Executive Officer/ Municipal Executive Officer shall publish any
declaration so confirmed or modified in the official Gazette and the declaration shall take effect from
the date of such publication.(4)No person shall after the date of publications of such declaration,
erect or re-erect any building in contravention of such declaration.(5)The Empowered Standing
Committee shall ensure that such declaration is in conformity with the provisions of any State Law
relating to urban land use planning.
361. Power to stop excavation.
- If, during excavation or any other operation for the purpose of construction of any building or
execution of any work, any of the underground utilities (such as electric or telephone cables, water
supply, drainage and sewerage mains and gas pipes) is touched or is likely to be touched or if the
Chief Municipal Executive Officer/ Municipal Executive Officer is of the opinion that such
excavation may cause danger to the public, the Chief Municipal Executive Officer/ Municipal
Executive Officer may by order in writing stop forthwith any such excavation or other work till the
matter is investigated and decided to his satisfaction.
362. Power to require alteration of existing buildings.
- The Chief Municipal Executive Officer/ Municipal Executive Officer may with a view to promoting
convenience, safety, privacy of the public or the occupier, or sanitation or to securing conformity
with the provisions of this Act and the rules and the regulations made thereunder by order in writing
require the owner of any existing building to make such alteration therein and within such period asArunachal Pradesh Municipal Act, 2007

may be specified in the order :Provided that before making any such order, the Chief Municipal
Executive Officer/Municipal Executive Officer shall afford a reasonable opportunity to the owner to
show cause why such order should not be made.
363. Power to order removal of dangerous building.
(1)If any wall or building or anything affixed thereto, is deemed by the Chief Municipal Executive
Officer/ Municipal Executive Officer to be in a ruinous state, or is likely to fall or to be in any way
dangerous, he shall forthwith cause a notice, in writing to be served on the owner and to be put on
some conspicuous part of the wall or building or served on the occupier, if any of the building
requiring such owner or occupier forthwith to demolish, repair or secure such wall, building or thing
as the case may require.(2)The Chief Municipal Executive Officer/ Municipal Executive Officer may
if it appears to him necessary so to do cause a proper hoarding or fence or other means of protection
to be put up at the expense of the owner of such wall or building for the safety of the public or the
inmates thereof and may after giving them such notice as the Chief Municipal Executive Officer/
Municipal Executive Officer may think necessary require the inmates of the building to vacate
it.(3)The provisions of this Act and of any rules or regulations made thereunder relating to buildings
shall apply to any work done in pursuance or in consequence of a notice issued under sub-section
(1).(4)(a)Withstanding anything contained in the foregoing provisions of this section, the Chief
Municipal Executive Officer/ Municipal Executive Officer may forthwith or with such notice as he
thinks fit demolish, repair or secure or cause to be demolished, repaired or secured any such wall or
building or thing affixed thereto, on the report of the Municipality Architect and Town Planner,
certifying that such demolition, repair or securing of the building, wall or thing is necessary for the
safety of the public or the inmates of the building,(b)In any such case, the Chief Municipal Executive
Officer/ Municipal Executive Officer may cause the inmates of the building to be summarily
removed from such building or from such portion thereof as he may consider necessary.(c)All
expenses incurred by the Chief Municipal Executive Officer/ Municipal Executive Officer for
carrying out the purposes of this sub-section shall be paid by the owner of such wall, building or
thing.(5)Anything done or any action taken by the Chief Municipal Executive Officer/ Municipal
Executive Officer under sub-section (4) shall unless the contrary is proved be deemed to have been
done or taken lawfully and in good faith.
364. Inspection of building.
(1)The Chief Municipal Executive Officer/ Municipal Executive Officer may at any time during the
erection or re-erection of a building or the execution of any work under this chapter make an
inspection thereof without giving any previous notice of his intention so to do.(2)The Chief
Municipal Executive Officer/ Municipal Executive Officer may inspect any existing building at any
time by giving seven days notice in advance.
365. Permission in case of non-residential uses of premises.
(1)No person shall without the previous permission in writing of the Chief Municipal Executive
Officer/ Municipal Executive Officer otherwise than in conformity with the conditions if any of suchArunachal Pradesh Municipal Act, 2007

permission put any premises to non-residential use including the use for an educational building or
an institutional building or an assembly building or a business building or a mercantile building or
an industrial building or a storage building or a hazardous building.(2)The Chief Municipal
Executive Officer/ Municipal Executive Officer may refuse to give such permission in any case on
the ground that such use -(a)would be objectionable by reason of the density of population in the
neighbourhood, or(b)would add to the traffic constraint in the vicinity including parking spaces for
vehicles or(c)would not conform to other predominant uses in the neighbourhood or(d)would
constitute a fire hazard or(e)would be a nuisance to the inhabitant of neighbourhood or(f)in the case
of a hospital or a clinic would be harmful to the patient due to noise or an environment which poses
a health hazard or(g)in the case of an educational building would deprive the students of playground
facilities,(3)Subject to any land use control under this Act or any other law for the time being in
force, the decision of the Chief Municipal Executive Officer/ Municipal Executive Officer in every
case where permission is refused under this section shall be final.
366. Conditions for grants of permission.
- In the case of any premises for the use of which a licence or permission is required from the State
Government or any authority under any law for the time being in force, the Chief Municipal
Executive Officer/ Municipal Executive Officer shall not grant such permission under this Act to any
person until such person produces before the Chief Municipal Executive Officer/ Municipal
Executive Officer the licence or the permission from the State Government or such authority as the
case may be and submits duly authenticated copy thereof to him :Provided that in the case where
production of a permission of the Municipality is a precondition for the grant of a licence or
permission under any other law for the time being in force, the Chief Municipal Executive Officer/
Municipal Executive Officer may grant a provisional permission which shall be authenticated to be
final only upon production of a licence or permission under the said law.Provided further that such
provisional permission shall have validity only for the purpose of fulfilling any precondition for the
grant of the licence or the permission under any other law as aforesaid.E. Regulation of Building
Uses
367. Power to prohibit change of authorized use of building.
(1)No person shall without the permission in writing of the Chief Municipal Executive Officer/
Municipal Executive Officer or other than in conformity with the conditions of such permission
:(a)use or permit to be used for the purpose of human habitation any building or part thereof not
originally erected or authorized to be used for such purpose,(b)change or allow the change of the use
of a building for any purpose other than that specified in the sanctioned plan,(c)change or allow the
change of the use of any building erected before the commencement of this Act contrary to the use
for which such erection was originally sanctioned or to use to which such building was actually
put.(d)convert or allow the conversion of a tenement within a building to an occupational use, other
than the use intended in the original sanctioned plan or materially alter, enlarge or extend such
use.(2)If, in any case such permission is given no change of occupancy or use shall be allowed before
necessary alterations or provisions have been made to the satisfaction of the Chief Municipal
Executive Officer/ Municipal Executive Officer and in accordance with the provisions of this Act andArunachal Pradesh Municipal Act, 2007

the rules and the regulations made thereunder and any other law for the time being in force.(3)Any
change of use made before the commencement of this Act, except in so far as such use is permissible
under the provisions of an earlier State law on the subject in force before the commencement of this
Act, shall not be deemed to be a change in contravention of the provisions of this Act.(4)Without
prejudice to any other action that may be taken against any persons, whether owner or occupier
contraventing any provision of this section, the Municipality may levy on such person such fine, not
exceeding in each case rupees one hundred per square meter per month for the area under
unauthorized use throughout the period during which such contravention continues as may be
provided by regulations.(5)The Chief Municipal Executive Officer/ Municipal Executive Officer may
if he deems fit order that such unauthorized used be stopped forthwith:Provided that before making
any such order, he shall give a reasonable opportunity to the person affected to show cause why such
order shall not be made.(6)Any person aggrieved by an order of the Chief Municipal Executive
Officer/ Municipal Executive Officer under sub-section (5) may within thirty days from the date of
the order, prefer an appeal against the order to the Municipal Building Tribunal whose decision in
the matter shall be final and conclusive.(7)When an appeal is preferred under sub-section (6) the
Municipal Building Tribunal or the Municipality as the case may be may stay the enforcement of the
order made by the Chief Municipal Executive Officer/ Municipal Executive Officer under
sub-section(5)on such terms and for such period as it may think fit.(8)Save as otherwise provided in
this section no court shall entertain any suit , application or other proceeding for any relief or
injunction, restraining the Chief Municipal Executive Officer/ Municipal Executive Officer or the
Municipal Building Tribunal or the Municipality from taking any action or making any order in
pursuance of the provision of this section.Explanation. - For the purpose of this chapter
"unauthorized use" shall mean change or conversion of a building without sanction from one
occupancy or use group to another occupancy or use group referred to in sub-section (2) of section
339.
368. Power to prevent use of premises for specified purpose in particular
area for environmental reasons.
(1)The Municipality may give notice of its intention to declare that in any area specified in the
notice, no person shall for environmental reasons stated therein use any premises for any purpose
specified in the notice.(2)Any objection to any such notice shall be received within a period of thirty
days from the date of the notice.(3)The Municipality shall consider all objections received within the
period as aforesaid, giving any person affected by the notice an opportunity of being heard and may
thereupon make a declaration in accordance with the notice under sub-section (1) with such
modifications, if any as it may thinks fit.(4)Every such declaration shall be published in the manner
provided by regulations and shall take effect from the date of such publications.(5)No person shall
in any area specified in the declaration published under sub-section(4)use any premises for any
purpose specified in the declaration and the Chief Municipal Executive Officer/ Municipal Executive
Officer shall have the power to stop such use of any such premises by such means as he may
consider necessary.(6)The Municipality shall ensure that such declaration is in conformity with the
provisions of any land use plan in force in the municipal area under any State law regulating such
use.Chapter - XXXVIII Municipal LicencesArunachal Pradesh Municipal Act, 2007

369. Premises not to be used for nonresidential purpose without municipal
licence.
(1)Except as hereinafter provided in this Act, no person shall use or permit to be used any premises
for any of the non-residential purposes mentioned in the Schedule without or otherwise than in
conformity with the terms of a licence granted by the Chief Municipal Executive Officer/ Municipal
Executive Officer or the Wards Committee under sub-section (6) of section 30, as the case may be so
as not to contravene the provisions of sub-section (2) of this section.Provided that no such licence
shall be given in respect of any non-residential use of a premises, if such use in otherwise than in
conformity with the provisions of this Act or any other law for the time being in force or the rules or
the regulations or the orders made thereunder.Provided further that except in case which come
under the provisions of subsection (2) of this section or section 371 or section 373 the power issue
such licence within its jurisdiction may be exercised by the Wards Committee subject to such
conditions and in such manner as may be determined by regulations.(2)In the case of a
non-residential use of a premises for a purpose for which a licence or permission is required from
the State Government or any statutory body under any law for the time being in force, no licence
under this section shall be given until the licence or the permission under the said law has been
produced before the Chief Municipal Executive Officer/ Municipal Executive Officer and duly
authenticated copies thereof have been submitted to him :Provided that in the case where the
production of a licence under this Act is a preconditions for the grant of a licence under any other
law for the time being in force, the Chief Municipal Executive Officer may grant a provisional licence
which shall be authenticated to be final only upon the production of a licence or permission under
the said law :Provided further that such provisional licence shall have validity only for the purpose
of fulfilling the preconditions of the grant of a licence under any other law as aforesaid.(3)In
specifying the terms of a licence granted under this section, the Chief Municipal Executive Officer/
Municipal Executive Officer may require the licence to take all or any of such measures as he may
deem fit to guard against danger to life, health or property or for the abatement of nuisance of any
kind.(4)The Municipality shall by regulations, determine the fees to be paid in respect of a licence
granted under sub-section (1) and may specify different fees for different categories of
non-residential uses in different areas within the municipal area :Provided that no such fee shall
exceed rupees two thousand and five hundred in any case.(5)The Municipality may by regulations,
determine :-(a)as to when the initial licence is to be taken out and the procedure of annual renewal
thereof and(b)the matter connected with the display of licence, inspection or premises, power of
inspectors and such other matters as may be deemed necessary.
370. Registers to be maintain.
- The Chief Municipal Executive Officer/ Municipal Executive Officer shall maintain in such form
and in such manner as may be prescribed two separate registers of which -(a)one shall contain
premise wise information of non-residential uses indicating the unique premises number if any
assigned under this Act, and(b)the other shall contain such information on the basis of different
non-residential user group for factories, warehouses, medical institution, educational institution
and such other uses as may be provided by regulation.Arunachal Pradesh Municipal Act, 2007

371. Municipal licence for private markets.
(1)The Chief Municipal Executive Officer/ Municipal Executive Officer may with the prior approval
of the Municipality grants to any person a licence to establish or keep open a private market on
payment of such fees as may be determined by the Municipality by regulations and may specify such
conditions consistent with this Act as he may deem fit.(2)When the Chief Municipal Executive
Officer/ Municipal Executive Officer refuses to grants any licence, he shall record a brief statement
of the reasons for such refusal in writing.(3)The Chief Municipal Executive Officer/ Municipal
Executive Officer may with the prior approval of the Municipality and for reasons to be recorded in
writing by order suspended a licence in respect of a private market for such period as he thinks fit or
cancel such licence.(4)A private market in respect of which the licence has been suspended or
cancelled under sub-section (3) shall be closed with effect from such date as may be specified in the
order of suspension or cancellation.
372. Municipal licence for sale of flesh, fish and poultry.
(1)No person shall without or otherwise than in conformity with a licence from the Chief Municipal
Executive Officer/ Municipal Executive Officer carry on the trade of a butcher, fishmonger, poultry
or importer of flesh, intended for human food, or use any place for the sale of flesh, fish or poultry
intended for human food.Provided that no person shall sell or expose for sale any flesh obtained
from an animal unless the skinned carcass of the animal is stamped in such manner as the Chief
Municipal Executive Officer/ Municipal Executive Officer may by general order made in this behalf
require in token of the fact that the animal has been slaughtered in a municipal or licensed
slaughterhouse :Provided further that no licence shall be required for any place used for sale or
storage for sale of preserved flesh or fish contained in air tight or hermetically sealed
receptacles.(2)The Chief Municipal Executive Officer/ Municipal Executive Officer may by order and
subject to such conditions as to supervision and inspection as he may think fit to impose, grant a
licence or may by order and for reasons to be recorded in writing, refuse to grant a licence.(3)The
Municipality shall by regulation, determine the procedure for the issue of a licence and renewal
thereof.(4)If any place is used for the sale of flesh, fish or poultry intended for human food in
contravention of the provisions of this section, the Chief Municipal Executive Officer/Municipal
Executive Officer may stop the use of such place in such manner as he may consider necessary.
373. Prohibition of unlicensed activities.
(1)Without or otherwise than in conformity with the terms of a licence granted by the Chief
Municipal Executive Officer/ Municipal Executive Officer in this behalf, no person shall within the
municipal area use or permit to be used any land or building :(a)for keeping horses, cattle, or other
quadrupled animals or birds for transportation sale or hire or for sale of the produce, or(b)as a
market in respect of which a licence is required under this Act or(c)for carrying out work as an
artisan or(d)for trade of a butcher, fish-monger, poultry or importer of flesh intended for human
food or for sale thereof.(2)If any land or building, public or private use or permitted to be used in
contravention of the provisions of sub-section (1), the Chief Municipal Executive Officer/ Municipal
Executive Officer may stop the use thereof by such means as he deems fit and may confiscate anyArunachal Pradesh Municipal Act, 2007

article in respect of which such use is being made, and prepare an inventory thereof and in the case
of perishable items, auction them without notice.
374. Power to stop use of premises used in contravention of licences.
(1)If the Chief Municipal Executive Officer/ Municipal Executive Officer is of the opinion that any
premises is being used for a non-residential purpose without a licence under this Act or otherwise
than in conformity with the terms of a licence granted in respect thereof, he may stop the use of any
such premises for any such purpose for a specified period by such means as he may consider
necessary.(2)If a person continues to use a premises in contravention of the provisions of subsection
(1) the Chief Municipal Executive Officer/ Municipal Executive Officer may notwithstanding any
other action that may be taken against such person under this Act, levy on such person a continuing
fine in accordance with the provisions of subsection (4) of section 367.
375. Power to seize food or drug etc.
(1)The Chief Municipal Executive Officer/ Municipal Executive Officer or any officer or any other
employee of the Municipality authorized by him in this behalf may at the time in day or night
without notice, inspect and examine any food or drug or any utensil or vessel used for preparing,
manufacturing or storing such food or drug.(2)If, upon such inspection or examination any such
food or drug is in the opinion of the Chief Municipal Executive Officer/ Municipal Executive Officer
or any other officer or other employee authorized by him in this behalf, unwholesome or unfit for
human consumption or is not what it is represented to be or if any such utensil or vessel is of such
kind or in such state as to render any food or drug prepared, manufactured or stored therein,
unwholesome or unfit for human consumption, he may seize, seal or carry away such food or drug
or utensil or vessel.(3)If any food or drug seized under sub-section (2) is in the opinion of the Chief
Municipal Executive Officer/ Municipal Executive Officer unfit for human consumption he shall
cause such food or drug to be forthwith destroyed in such manner as to prevent its being exposed for
sale or used for human consumption and the expenses thereof shall be paid by the person in whose
possessions such food or drug was at the time of it seizure.Chapter - XXXIX Vital Statistics
376. Appointment of Chief Registrar and Registrars.
(1)The Chief Municipal Health Officer shall be the Chief Registrar of births and deaths occurring in
the municipal area.(2)The Chief Municipal Executive Officer/ Municipal Executive Officer shall for
the purpose of this chapter appoint such number of persons to be Registrars of births and deaths as
he deems necessary and shall define the respective areas which shall be under the charge or such
Registrars.
377. Duties of Registrar.
- Each Registrar shall keep himself informed of every birth or death occurring within the area of his
jurisdiction and shall ascertain such particulars in respect of every birth or death as may beArunachal Pradesh Municipal Act, 2007

prescribed in this behalf.
378. Registrar's books to be maintained.
(1)Such particulars regarding births and deaths as the Chief Municipal Executive Officer/ Municipal
Executive Officer may from time to time specify shall be entered in separate registers of births and
of deaths and such registers shall be maintained by each Registrar.(2)The Chief Municipal Executive
Officer/ Municipal Executive Officer shall specify the form of the registers required to be maintained
under sub-section (1) and the manner in which such registers shall be maintained.(3)On an
application from a person interested, the Chief Registrar or a Registrar as the case may be, shall
issue an extract from any entry in a register on payment of such fees as may be determined by the
Municipality by regulations.
379. Registration of births and deaths.
- Subject to the provisions of the Registration of Births and Deaths Act 1969(18 of 1969), the
Municipality shall cause registration of births and deaths taking place within the municipal area and
extracts of information therefrom shall be supplied on application in such form of a certificate, and
on payment of such fees as may be determined by regulations.
380. Registration of name of child or of alteration of name.
(1)When the births of any child has been registered and the name, if any by which it was registered
is altered or if it was registered without a name, when a name is given to it, the parent or the
guardian of such child or other person proposing such name to be altered or given may within sixty
months next after the registration of the birth, deliver to the Registrar of the area in which the birth
was registered such certificate as hereinafter provided and the Registrar upon the receipt of the
certificate shall without any erasure of the original entry, forthwith enter in the register the name
mentioned in the certificate as having been given to the child.(2)The certificate shall be in such form
as the Chief Municipal Executive Officer/ Municipal Executive Officer may from time to time specify
and shall be signed by the parent, or the guardian of the child or other person proposing the name of
the child to be altered or given.
381. Correction of errors in registers of births or deaths.
(1)Any clerical error which may at any time be discovered in a register of births or register of deaths
may be corrected by any person authorized in this behalf by the Chief Municipal Executive Officer/
Municipal Executive Officer.(2)An error of fact or substance in any such register may be corrected
by any person authorised as aforesaid by entry in the margin without any alteration of the original
entry upon production to the Chief Municipal Executive Officer/ Municipal Executive Officer by the
person requiring such error to be corrected of a declaration (setting forth the nature of the error and
the fact of the case) on oath made before a Magistrate, by the person required by this Act to give
information concerning the birth or death with reference to which the error has been made or inArunachal Pradesh Municipal Act, 2007

default of such person by a person having knowledge of the case.(3)Except as provided in
sub-section (2) no alteration shall be made in any such register.
382. Information of births.
- It shall be the duty of the father or the mother of every child born in the municipal area and in
default of the father or the mother of any relation of the child living in the same premises and in
defaults of such relation of the person having charge of the child to give to the best of his or her
knowledge and belief to the Registrar of the area concerned within eight days after such birth,
information containing such particulars as may be prescribed in this behalf.Provided that(a)in the
case of an illegitimate child no person shall as father of such child be required to give information
under this Act concerning the birth of such child and the Registrar shall not enter in the register the
name of any person as father of such child except at the joint request of the mother and the person
acknowledging himself to be the father of such child and such person shall in such case, sign the
register together with the mother.(b)a person required to give information only in default of some
other person shall not be bound to give such information if he believed and had reasonable grounds
for believing that such information had been given and(c)when a child is born in a hospital or a
nursing home or a maternity home, none but the officer-in-charge thereof shall be bound to forward
forthwith to the Registrar a report of such birth in such time and in such form as the Chief Registrar
may from time to time specify.
383. Information regarding finding of newborn child.
- In case any newborn child is found exposed it shall be the duty of any person finding such child or
of any person in whose charge such child may be place to give to the best of his knowledge and belief
to the Chief Registrar or the Registrar within eight days after the finding of such child such
information of the particulars required to be registered concerning the birth of such child as such
person possesses.
384. Information regarding deaths.
- It shall be the duty of the nearest relation present at the time of the death or in attendance during
the last illness of any person dying in the municipal area and in default of such relation of any
person present or in attendance at the time of the death and of the occupier of the premises in which
to his knowledge, the death took place and in default of the person as aforesaid of each inmate of
such premises and of the undertaker or other person causing the corpse of the deceased person to be
disposed of to give to the best of his knowledge and belief to the Registrar of the area within which
the death took place information containing such particulars as may be prescribed within twenty
four hours of such death :Provided that -(a)if the cause of death is known to be a dangerous diseases
the information as aforesaid shall be given within twelve hours of its occurrence and(b)if the death
of any person occurs in a hospital or a nursing home or a maternity home it shall be the duty of none
but the medical officer or other officer - incharge thereof to forward forthwith a report of such death
in such form as the Chief Registrar may from time to time specify.Arunachal Pradesh Municipal Act, 2007

385. Medical Practitioner to certify cause of death.
- In the case of a person who has been attended his last illness by a duly qualified medical
practitioner such practitioner shall within three days of his becoming cognizant of the death of such
person, sign and forward to the Chief Registrar a certificate of the cause of death of such person in
such form as shall from time to time be specified by the Chief Municipal Executive Officer/
Municipal Executive Officer in this behalf and the cause of death as stated in such certificate shall be
entered in the register together with the name of the certifying medical practitioner.
386. Duties of police in regard to unclaimed corpse.
- It shall be the duty of the police to convey every unclaimed corpse to a registered burial or burning
ground or other place for disposal of the dead or to a duly appointed mortuary and thereafter to
inform the Registrar within whose jurisdiction such corpse was found.
387. Sextons etc. not to bury etc. corpse.
- A sexton or a keeper of a registered burial or burning ground or other place for disposal of the
dead, whether situated in municipal area or not shall not bury burn or otherwise dispose of or allow
to be buried burnt or otherwise disposed of any corpse unless such corpse is accompanied by a
certificate in such form as may be prescribed and signed by a Registrar appointed under section 376
or by a registered medical practitioner or any other medical practitioner authorised by theChapter -
XL Disaster Management
388. Management of natural or technological disasters.
(1)As far as possible, the Municipality shall in collaboration with the concerned authorities of the
Central Government or the State Government including the meteorological office, shall prepare
environmental base maps and impact area diagrams and shall collect other relevant data and shall
take necessary steps for erecting installation and other accessories required to mitigate the effects of
natural or technological disasters.(2)The Municipality shall organize emergency operations and
promote public awareness in relation to disaster management.(3)The Municipality shall take
adequate measure to implement the regulations, if any made by the planning and urban
development authorities to mitigate earthquake hazards in high seismic zones and to promote
citizen awareness in this regard.Chapter - XLI Industrial Townships
389. Exclusion of industrial townships from municipal areas.
- No Municipality shall be constituted in such urban area or part thereof as the Governor may
having regard to the size of the area and the municipal services being provided or proposed to be
provided by an industrial establishment in that area and such other factors as he may deem fit by
notification specify to be an industrial township.Powers, Procedures, Offences And PenaltiesChapter
- XLII ProcedureA. Licence and PermissionArunachal Pradesh Municipal Act, 2007

390. Signature, condition, duration, suspension, revocation etc. of licence
and permission.
(1)Wherever it is provided in this Act or the rules or the regulations made thereunder that a licence
or a permission in writing may be granted for any purpose, such licence or permission shall be
signed by the Chief Municipal Executive Officer/ Municipal Executive Officer or by any other officer
empowered to grant such licence or permission under this Act or the rules or the regulations made
thereunder and shall specify the following particulars in addition to any other particulars required
to be specified under any other provision of this Act, or the rules or the regulation made thereunder
:(a)the date of the grant of licence or permission,(b)the purpose or the period, if any for which it is
granted,(c)restrictions or conditions of any subject to which it is granted,(d)the name and address of
the person to whom it is granted and(e)the fee, if any paid for the licence or the
permission.(2)Except as otherwise provided in this Act or the rules or the regulations made
thereunder for every such licence or permission, a fee may be charged at such rate as may from time
to time, be fixed by the Municipality and such fee shall be payable by the person to whom the licence
or the permission is granted.(3)Save as otherwise provided in this Act or the rules or the regulations
made thereunder, any licence or permission granted under this Act or the rules or the regulations
made thereunder may at any time, be suspended or revoked by the Chief Municipal Executive
Officer/ Municipal Executive Officer or the officer by whom it was granted, if he is satisfied that it
has been secured by the grantee through misrepresentation or fraud, or if any of the restrictions or
conditions of licence or permission has been infringed or evaded by the grantee, or if the grantee has
been convicted for the contravention of any of the provision of this Act or the rules or the
regulations made thereunder relating to any matter for which the licence or the permission as the
case may be was granted :Provided that -(a)before making any order of suspension or revocation, an
opportunity shall be given to the grantee of the licence or the permission to show cause why it
should not be suspended or revoked and(b)every such order shall contain a brief statement of the
reasons for the suspension or the revocation of the licence or the permission as the case may
be.(4)When any such licence or permission is suspended or revoked or when the period for which
such licence or permission was granted has expired the grantee shall for the purpose of this Act and
the rules and the regulations made thereunder be deemed to be without a licence or permission, as
the case may be until such time as the order suspending or revoking the licence of the permission as
the case may be is rescinded or until the license or the permission as the case may be is
renewed.(5)Every grantee of any licence or permission granted under this Act shall at all reasonable
times while such licence or permission as the case may be remain in force, if so required by the Chief
Municipal Executive Officer/ Municipal Executive Officer or the other officer by whom it was
granted, produced such licence or permission as the case may be.B. Entry and Inspection
391. Power to entry.
- The Chief Municipal Executive Officer/ Municipal Executive Officer or any other officer or
employee of the Municipal authorised by the Chief Municipal Executive Officer/ Municipal
Executive Officer in this behalf, or empowered by or under any provision of this Act, may enter into
or upon any land or building with or without assistants or workmen, for the purpose of
-(a)ascertaining whether in connection with the land or the building there is or has been anyArunachal Pradesh Municipal Act, 2007

contravention of the provisions of this Act or the rules or the regulations made there under
,or(b)ascertaining whether or not circumstances exist which render it necessary to take immediate
action by the Chief Municipal Executive Officer/ Municipal Executive Officer or any other officer or
employee of the Municipality authorised by him in this behalf , or empowered by or under any
provision of this Act or the rules or the regulations made thereunder, or(c)taking any action or
executing any work authorised or required by or under this Act or the rules or the regulations made
thereunder, or(d)making such inquiry, inspection, examination, measurement, valuation or survey
as may be authorized or required by or under this Act or as may be necessary for the proper
administration of this Act, or(e)generally ensuring efficient discharge of the functions by any of the
municipal authorities under this Act or the rules or the regulations made thereunder.
392. Power to enter land or adjoining land in relation to any work.
(1)The Chief Municipal Executive Officer/ Municipal Executive Officer or any person authorised by
him in this behalf, or empowered by or under this Act, may enter upon any land within fifty meters
of any work authorised by or under this Act with or without assistants or workmen , for the purpose
of depositing thereon any soil, gravel, stone or other materials or for obtaining access to such work
or for any other purpose connected with the execution thereof.(2)Every person so authorised shall,
before entering upon any such land , state the purpose thereof, shall , if so required by the owner or
the occupier thereof, fence off so much of the land as may be required for such purpose.(3)Every
person as aforesaid shall, in exercising any power conferred by this section, do as little damage as
may be necessary, and compensation shall be payable by the municipality in accordance with the
rules to the occupier of such building or such land or to both for any such damage, whether
permanent or temporary.
393. Breaking into building.
(1)It shall be lawful for the Chief Municipal Executive Officer/ Municipal Executive Officer or any
person authorised by him in this behalf, or empowered by or under this Act, to make any entry into
any place and to open or cause to be opened any door, gate or other barrier,-(a)if he considers the
opening thereof necessary for the purpose of such entry, and(b)if the owner or the occupier is absent
or, being present, refuses to open such door, gate or other barrier.(2)Before making any entry into
any such place or opening or causing to be opened any such door, gate or other barriers the Chief
Municipal Executive Officer/ Municipal Executive Officer or the person authorised or empowered in
this behalf shall call upon two or more respectable inhabitants of the locality in which the place to be
entered into is situated to witness the entry or the opening and may issue an order in writing to
them or any of them so to do.(3)A report shall be made to Empowered Standing Committee as soon
as may be after any entry has been made into any place or any door, gate or other barrier has been
opened under this section.
394. Time of making entry.
- Save as otherwise provided in this Act or the rules or the regulations made thereunder, no entry
authorized under this Act shall be made except between the hours of sunrise and sunset :ProvidedArunachal Pradesh Municipal Act, 2007

that if the Chief Municipal Executive Officer/ Municipal Executive Officer is satisfied that the
erection of any building or the execution of any work has been commenced or is being carried on in
contravention of the provisions of this Act in any premises between the period of sunset and sunrise
he may if he considers it necessary so to do enter such premises during such period accompanied by
a officer to make an inspection thereof and take such action as may be necessary under this Act.
395. Consent ordinarily to be obtained.
- Save as otherwise provided in this Act or the rules or the regulations made thereunder no land or
building shall be entered without the consent of the occupier, or if there is no occupier of the owner
thereof, and no such entry shall be made without giving such occupier or owner as the case may be
not less than twenty four hours notice in writing of the intention to make such entry.Provided that
no such notice shall be necessary if the Municipality considers for reasons to be recorded in writing
that there is immediate urgency of such entry and the services of a notice in writing may defeat its
purpose.Provided further that no such notice shall be necessary, if the land or the building to be
entered is a factory or workshop or trade premises or place used for any of the purpose referred to in
section 314 or a stable for horse or a shed for cattle or a latrine or a urinal or a work under
construction or for the purpose of ascertaining whether any animal intended for human
consumption is slaughter on such land or in such building in contravention of the provision of this
Act or the rules or the regulations made thereunder.
396. Regard to be had to social or religious usages.
- When any land uses as human dwelling is entered under this Act, due regard shall be paid to the
social religious customs and usages of the occupants of the place entered and no apartment in the
actual occupancy of a female shall be entered or broken open until she has been informed that she is
at liberty to withdraw and every reasonable facility has been afforded to her withdrawing.
397. Prohibition of obstruction or molestation in execution of work.
- No person shall obstruct or molest any person authorised or empowered by or under this Act, or
with whom the Municipality or any of the municipal authorities referred to in section 20 has
lawfully contracted, in the execution of his duty or anything which he is authorised or empowered or
required to do by virtue or in consequence of any of the provisions of this Act or the rules or the
regulations made thereunder, or in fulfillment of his contract as the case may be.C. Public Notice
and Advertisement
398. Public notices how to be made known.
- Every public notice give under this Act or the rules or the regulations made thereunder shall be in
writing under the signature of the Chief Municipal Executive Officer/ Municipal Executive Officer or
any other officer of the Municipality authorised by him in this behalf, and shall be widely made
known in the locality to be affected thereby by affixing copies thereof in conspicuous public placesArunachal Pradesh Municipal Act, 2007

within such locality or by publishing the same by advertisement in local newspapers or by such
other means as the Chief Municipal Executive Officer/ Municipal Executive Officer may think fit.
399. Newspapers in which advertisements or notice to be published.
- Whenever it is provided by or under this Act or the rules or the regulations made thereunder that
notice shall be given by advertisements in local newspapers or a notification or information shall be
published in local newspapers such notice, notification or information shall be inserted in at least
two newspapers of which at least one shall be in the regional language.D. Evidence
400. Proof of consent etc. of Municipality, Empowered Standing Committee,
Chief Councillor, Chief Municipal Executive Officer/Municipal Executive
Officer etc.
- Whenever under this Act or rules or the regulations made thereunder the doing of or the omission
to do anything or the validity of anything done depends upon the approval, sanction, consent,
concurrence, declaration, opinion or satisfaction of -(a)the Municipality or(b)The Empowered
Standing Committee or(c)The Chief Councillor or(d)The Chief Municipal Executive Officer/
Municipal Executive Officer or any other officer of the Municipality.As the case may be a document,
in writing signed -(i)in the case referred to in clause (a) and clause (b) by the Municipality Secretary
where there is a Municipality Secretary or where there is no Municipality Secretary by the Chief
Municipal Executive Officer/ Municipal Executive Officer and(ii)in the case referred to in clause (c)
and clause (d) by the Chief Municipal Executive Officer/ Municipal Executive Officer,purporting to
convey or set forth such approval, sanction, consent, concurrence, declaration, opinion, satisfaction
as the case may be shall be sufficient evidence thereof.E. Notices etc.
401. Notice etc. to fix reasonable time.
- Where any notice bill, order, or requisition, issued or made under this Act or the rules or the
regulations made thereunder required anything to be done for the doing of which no time is fixed in
this Act or the rules or the regulations made thereunder such notice, bill, order or requisition shall
specify a reasonable time for doing the same.
402. Signature on notice etc. may be stamped.
(1)Every licence, permission in writing, notice, bill summons or other documents which is required
by this Act or the rules or the regulations made thereunder to bear the signature of the Chief
Municipal Executive Officer/ Municipal Executive Officer or any other officer of the Municipality
shall be deemed to be properly signed if it bears a facsimile of the signature of the Chief Municipal
Executive Officer/ Municipal Executive Officer or such other officer as the case may be and stamped
thereupon.(2)Nothing is sub-section (1) shall be deemed to apply to a cheque drawn upon the
Municipal Fund under section 82.Arunachal Pradesh Municipal Act, 2007

403. Notice etc. by whom to be served or issued.
- Every notice, bill, summons or other document required by this Act or the rules or the regulations
made thereunder to be served upon, or issued to any person shall be served or issued by an officer or
other employee of the Municipality or by any person authorised by the Chief Municipal Executive
Officer/ Municipal Executive Officer in that behalf.
404. Service of notice etc.
(1)Every notice, bill, summons order, requisition or other document required or authorised by this
Act or the rules or the regulations made thereunder to be served or issued by or on behalf of the
Municipality or by any of the municipal authorities referred to in section 20 or by any officer or
other employee of the Municipality, shall save as otherwise provided in this Act or the rules or the
regulations made thereunder be deemed to be duly served.(a)where the person to be served is a
company, if the document is addressed to the Secretary of the company at its registered office or at
its principal office or place of business and is either -(i)sent by registered post or(ii)delivered at the
registered office or at the principal office or place of business of the company or(b)where the person
to be served is a partnership, if the document is addressed to the partnership at its principal place of
business, identifying it by the name or style under which its business is carried on and is either
-(i)sent by registered post or(ii)delivered at the said place of business or(c)where the person to be
served is a public body or a Municipality, or a society or other body, if the document is addressed to
the secretary, treasurer or other officer of such public body, Municipality, society, or other body at
its principal office, and is either, -(i)sent by registered post, or(ii)delivered at that office, and(d)in
any other case, if the document is addressed to the person to be served, and(i)is given or tendered to
him, or(ii)if such person cannot be found, is affixed on some conspicuous part of his last known
place of residence or business, if within the municipal area, or is given or tendered to some adult
member of his family, or is affixed on some conspicuous part of the land or building, if any, to which
it relates, or(iii)is sent by registered post to such person.(2)Any document, which is required or
authorized to be served on the owner or the occupier of any land or building, may be addressed to
"the owner" or "the occupier", as the case may be, of such land or building (naming such land or
building) without further name or description, and shall be deemed to be duly served, -(a)if the
document so addressed is sent or delivered in accordance with clause (d) of sub-section (1), or(b)If
the document or a copy thereof so addressed, is delivered to some person on the land or the building
or, where there is no such person to whom it can be delivered, is affixed to some conspicuous part of
such land or building.(3)Where a document is served on a partnership under this section, the
document shall be deemed to be duly served on each partner.(4)For the purpose of enabling any
document to be served on the owner of any premises, the Chief Municipal Executive Officer/
Municipal Executive Officer may, by notice, in writing, require the occupier of such premises to state
the name and address of the owner thereof.(5)Where the person on whom a document is to be
served is a minor, the service upon his guardian or any adult member of his family shall be deemed
to be service upon the minor.(6)Nothing in section 402 or section 403 or in this section shall apply
to any summons issue under this Act by any court.Explanation. - For the purposes of this section, a
servant shall not be deemed to be a member of the family.F. Enforcement of Orders to Execute
Works etc.Arunachal Pradesh Municipal Act, 2007

405. Time for complying with requisition or order, and power of the Chief
Municipal Executive Officer/ Municipal Executive Officer to enforce
requisition or order on default.
(1)When, under this Act or the rules or the regulations made thereunder, any requisition or order is
made by a notice, in writing, issued to any person or persons by any municipal authority or any
officer of the Municipality, such authority or officer shall specify in such notice such period within
which -(a)such requisition or order shall be complied with, and(b)any objection thereto, in writing,
shall be received by such authority or officer, as such authority or officer may consider
reasonably.(2)If any such requisition or order or any portion thereof is not complied with within the
period specified in the notice under sub-section (1), the Chief Municipal Executive Officer/
Municipal Executive Officer may, subject to the provisions of section 406 and such regulations as
may be made by the Municipality in this behalf, take such measures, or cause such measures to be
taken, as may, in his opinion, be necessary for causing due compliance with such requisition or
order, and, except where otherwise expressly provided in this Act or the rules or the regulations
made thereunder, the expenses, if any, incurred by such authority or officer in causing such
compliance shall be paid by the person or persons to whom such notice is issued.(3)The Chief
Municipal Executive Officer/ Municipal Executive Officer may take any scheme, execute any work,
or cause anything to be done under this section, notwithstanding any prosecution or punishment or
liability to punishment of any person under this Act or the rules or the regulations made thereunder
for his failure to comply with such requisition or order.
406. Submission of objections to comply with notice.
(1)Any person who has been served with a notice under sub-section (1) of section 405 may, within
such period as is specified in such notice, deliver to the municipal authority or the officer or the
Municipality, as the case may be, any objection, in writing, setting forth the objections which he may
desire to state for withdrawal or modification of such notice.(2)Every such objection shall be placed
before the Chief Municipal Executive Officer/ Municipal Executive Officer for determination and,
pending such determination, compliance with any requisition or order in accordance with such
notice shall be stayed.(3)The Chief Municipal Executive Officer/ Municipal Executive Officer or, if
he so directs, any other officer of the Municipality of such rank as may be specified by him, other
than an officer who has issued such notice, shall, after hearing the person concerned or his agent
duly authorized by him, in writing, in this behalf and after considering the circumstances of the case,
make such order, either confirming or modifying or cancelling the notice, as he thinks
fit.(4)(a)Where the Chief Municipal Executive Officer/ Municipal Executive Officer or the other
officer of the Municipality referred to in sub-section (3) makes an order under that sub-section,
either confirming or modifying the notice, he may, if he thinks fit, -(i)direct that a portion of the
expenses, if any, to be incurred in complying with the notice as confirmed or modified shall be borne
by the Municipality, and(ii)fix a time within which the notice so confirmed shall be complied
with.(b)If the notice as confirmed or modified is not complied with by such person within the time
fixed under sub-clause (ii) of clause (a), the Chief Municipal Executive Officer shall take such
measures, or cause such work to be executed, or such thing to be done, as may, in his opinion, beArunachal Pradesh Municipal Act, 2007

necessary for causing due compliance with such notice, and the expenses, if any, incurred by the
Chief Municipal Executive Officer is this behalf shall be payable to the Chief Municipal Executive
Officer on demand and, if not paid within ten days of such demand, shall be recoverable as an arrear
of tax under this Act.G. Recovery of Expenses.
407. Power of Municipality to enter into agreement for payment of expenses
in instalment.
(1)When, under this Act or the rules or the regulations make thereunder, the expenses of any
measure taken or work executed or thing done by or under the order of any municipal authority or
any officer of the Municipality or any Magistrate are payable by any person, the Chief Municipal
Executive Officer/ Municipal Executive Officer may, if he thinks fit and with the approval of the
Empowered Standing Committee, notwithstanding anything to the contrary contained in this Act or
the rules or the regulations made thereunder, enter into an agreement with such person for payment
of such expenses in such installments, and at such intervals, as will secure the recovery of the whole
amount due with interest thereon at such rate of interest as may be determined by the State
Government from time to time within such period, not exceeding six years, as the Municipality may
determine.(2)Every such agreement shall provide for adequate security against the whole amount
due from such person.
408. Power of Municipality to declare certain expenses to be an improvement
expenses.
(1)If any expenses are to be recovered or are incurred on account of any work mentioned -(a)in
section 199 and section 201, or(b)in the rules or the regulations made under this Act,The
Municipality may, if it thinks fit, declare such expenses to be an improvement expenses.(2)A register
shall be maintained by the Chief Municipal Executive Officer/ Municipal Executive Officer showing
all expenses, declared to be an improvement expenses under this section and such register shall be
open to inspection by any person upon payment of such fee as may from time to time be determined
by the Empowered Standing Committee.
409. Improvement expenses how recoverable and by whom payable.
(1)Any improvement expenses under section 408 shall be charge on the premises in respect of which
or for the benefit of which such expenses are incurred and shall be recoverable in such installments
and at such intervals, as may be sufficient to discharge such expenses with interest thereon at such
reasonable rate as may be determined by the Municipality from time to time and within such period
not exceeding thirty years as the Municipality may in each case determine.(2)The improvement
expenses shall be payable by the owner or the occupier of the premises on which such expenses are
chargeable.Arunachal Pradesh Municipal Act, 2007

410. Recovery of improvement expenses paid by occupier.
- Notwithstanding anything contained in section when the occupier of any premises pays any
installment of improvement expenses he shall subject to any agreement to the contrary if any
between himself and the owner of such premises be entitled to deduct the amount of such
installment from the rent payable by him to such owner or to recover such amount from such owner
in pursuance of any order of a court of competent jurisdiction.
411. Right of owner or occupier to redeem charge for improvement expenses.
- At any time before the expiration of the period for payment of any improvement expenses, the
owner or the occupier of the premises on which such expenses are chargeable may redeem such
charger by paying to the Municipality such part of such expenses as is still payable.
412. Execution of work by occupier on the failure of owner.
- Whenever the owner of any land or building fails to execute any work which he is required to be
executed under this Act or the rules or the regulations made thereunder, the occupier if any of such
land or building may with the approval of the Chief Municipal Executive Officer/ Municipal
Executive Officer execute such work and shall subject to any agreement to the contrary between
himself and the owner of such land or building be entitled to recover from the owner the reasonable
expenses incurred by him in the execution of the work and may deducted any amount thereof from
the rent payable by him to such owner.
413. Relief to receivers, agents and trustees.
(1)Whenever under this Act or the rules or the regulations made thereunder any person by reason of
his -(a)receiving the rent of any immovable property as receiver or agent or trustee of such property
or(b)being such receiver or agent or trustee would receive the rent if such property were let to a
tenant, is bound to discharge any obligation imposed on the owner of such property but has not at
his disposal funds, belonging or payable to such owner, sufficient for the purpose of discharging
such obligation he shall within a period of six weeks from the date of service upon him by any
municipal authority or officer of the Municipality empowered in this behalf under this Act, of any
notice requiring him to discharge such obligation apply to a court of competent jurisdiction for leave
to raise such funds or for such directions as he may consider necessary for such purpose.(2)If such
receiver or agent or trustee fails to apply to a court of competent jurisdiction under sub-section (1)
or after such court has granted leave to raise funds or has issued directions, fails to discharge such
obligation or to comply with such directions within twelve months of such leave or such directions
he shall be personally liable to discharge such obligation.H. Payment of CompensationArunachal Pradesh Municipal Act, 2007

414. General power of Municipality to pay compensation.
- In any case not otherwise expressly provided for in this Act or the rules or the regulations made
thereunder the Chief Municipal Executive Officer/ Municipal Executive Officer may with the prior
approval of the Empowered Standing Committee pay compensation to any person who sustains
damage by reasons of the exercise of any of the powers vested by this Act or the rules or the
regulations made thereunder on the Chief Municipal Executive Officer/ Municipal Executive Officer
or on any other officer or other employee of the Municipality.
415. Compensation to be paid for damage to property of Municipality.
(1)Any person who has been convicted of any offence under this Act or the rules or the regulations
made thereunder shall without prejudice to any punishment to which he may be subject be liable to
pay such compensation for any damage to any property of the Municipality resulting from such
offence as the appropriate municipal authority may consider reasonable.(2)In the case of any
dispute regarding the amount of compensation under sub-section (1) such amount shall on an
application, in writing made by such person to the Magistrate who convicts such person of such
offence be determined by such Magistrate and if the amount of compensation so determined is not
paid by such person, such amount shall be recovered under a warrant from such Magistrate as if it
were a fine imposed by him on the person liable thereof.I. Recovery of expenses or compensation in
case of disputes
416. Reference by Municipality to Civil Court in certain cases of recovery of
expenses.
(1)If in respect of any expenses referred to in section 407, any dispute arises, the Chief Municipal
Executive Officer/ Municipal Executive Officer shall refer such dispute to the Civil Court having
jurisdiction for determination.(2)Upon such reference, the Chief Municipal Executive Officer/
Municipal Executive Officer shall defer further proceedings for the recovery of such expenses and
shall recover only such amount if any as may be determined by the Civil Court having jurisdiction.
417. Application to Civil Court in certain cases of payment of expenses or
compensation.
- Save as otherwise provided in this Act or the rules or the regulations made thereunder or in any
other law for the time being in force in the case of any dispute in respect of any expenses or any
compensation payable to any person by any municipal authority or any officer or other employee of
the Municipality or any other person under this Act or the rules or the regulations made thereunder,
the amount of such expenses or such compensation shall be determined by the Civil Court having
jurisdiction at any time within one year from the date of such expenses or such compensation first
becoming due.Arunachal Pradesh Municipal Act, 2007

418. Recovery of expenses or compensation determined under section 417.
- If the amount of any expenses or compensation determined under section 417 is not paid on
demand such amount shall be recoverable as if the same were due under a decree of the Civil Court
having jurisdiction or in the manner provided in chapter XIX.
419. Recovery of expenses or compensation by suit in court.
- Notwithstanding anything contained in section 418, any expenses or compensation determined
under section 417 may be recovered by a suit brought in a court of competent jurisdiction.J.
Recovery of certain dues
420. Recovery of certain dues of Municipality.
- Save as otherwise provided in this Act or the rules or the regulations made thereunder any sum
due to the Municipality on account of any charge, cost, expense, fee, rate or rent or on any other
account under this Act or the rules or the regulations made thereunder shall be recoverable from the
person from whom such sum is due as if it were property tax.K. Obstruction of owner by occupier
421. Application to Civil Court by owner when occupier prevents him from
complying with the Act etc.
(1)Any owner of any land or building may, if he is prevented by the occupier thereof from complying
with any provision of the Act or the rules or the regulations made thereunder or any requirement
under any such provision in respect of such land or building shall apply to the Civil Court having
jurisdiction within the time fixed for compliance with such provision or requirement and thereupon,
such owner shall not be liable for his failure to comply with such provision or requirement within
the time fixed for such compliance.(2)On receipt of any application under sub-section (1) the Civil
Court may make an order in writing requiring the occupier of the land or the building as the case
may be to afford all reasonable facilities to the owner for complying with the provisions or the
requirement as aforesaid and may also, if it thinks fit, direct that the costs of such application and
order shall be paid by the occupier.(3)The occupier shall within eight days from the date of any
order under sub-section (2) afford all reasonable facilities to the owner in compliance with such
order, in the event of any continued refusal by the occupier to do so, the owner shall be discharged
during the continuance of such refusal from any liability which he would otherwise have incurred by
reason of his failure to comply with the provision or the requirement as aforesaid.L. Proceedings
before the Civil Court.
422. Proceedings in Civil Court.
(1)Whenever under this Act any application appeal or reference is made to a Civil Court having
jurisdiction, such Civil Court may for the purpose of any inquiry or proceeding in connection with
such application, appeal or reference summon and enforce the attendance of witness and compelArunachal Pradesh Municipal Act, 2007

them to give evidence or compel the production of documents by the same means and as far as
possible in the same manner as is provided in the Code of Civil Procedure 1908 and in all matters
relating to any such enquiry or proceedings the court shall be guided generally by the provisions of
the Code of Civil Procedure, 1908 (5 of 1908) so far as such provisions are applicable to such inquiry
or proceeding.(2)If in any such enquiry or proceeding any person summoned to appear before the
Court fails to do so the court may proceed with such inquiry or proceeding in his absence.(3)The
cost of every such inquiry or proceeding shall be payable by such person or persons and in such
proportions or proportions as the Court may direct and the amount of such cost shall be recoverable
as if the same were due under a decree of the court.
423. Fees in proceedings before Civil Court.
(1)The Municipality may specify a fee -(a)for making under this Act any application, appeal or
reference to a Civil Court having jurisdiction or(b)for issue of any summons or other process in
inquiry or proceeding in connection with such application, appeal or reference,Provided that the fee,
if any under clause (a) shall not in the case where the value of any claim is capable of being
estimated in money, exceed the fee leviable in a similar case under the Code of Civil Procedure
1908.(2)No application, appeal or reference under this Act shall be received by a Civil Court having
jurisdiction until the fee, if any under clause (a) of sub-section (1) has been paid,Provided that the
Civil Court may, in any case in which it thinks fit so to do -(i)receive such application, appeal or
reference or(ii)issue summons or other process, without payment of such fee.
424. Repayment of half of fees on settlement before hearing.
- Whenever under this Act any application, appeal or reference to a Civil Court having jurisdiction is
settled by agreement between the parties concerned before hearing of such application, appeal or
reference half the amount of any fee paid by any such parties under sub-section (2) of section 423
shall be repaid by the Civil Court to such party.M. Municipal Magistrate and proceedings before
Municipal Magistrates
425. Municipal Magistrate.
(1)The State Government may, in consultation with the High Court of the State appoint one or more
Judicial Magistrate of the First Class for the trial of offence against -(a)this Act, and(b)the rules and
the regulations made thereunder, and may prescribed the time within which and the place at which
such Judicial Magistrate or Judicial Magistrates shall sit for such trial of offences.(2)Every such
Judicial Magistrate shall exercise all other powers and discharge all the other functions of a
Magistrate as provided in this Act.(3)Every such Judicial Magistrate appointed under sub-section
(1) shall be called Municipal Magistrate.(4)A Municipal Magistrate shall be paid by the State
Government such salary, pension, leave and other allowances as it may from time to time
determine.(5)The Municipality shall pay to the Municipal Magistrate out of the Municipal Fund and
amount paid by the State Government on account of salary, pension, leave and other allowances of a
Municipal Magistrate together with the cost of establishment of such Municipal Magistrate and all
other incidental charge in such connection with such establishment.(6)Each Municipal MagistrateArunachal Pradesh Municipal Act, 2007

shall have jurisdiction over such municipal area or areas as may be specified by the State
Government by notification.(7)The procedure in the court of a Municipal Magistrate shall except
where otherwise specifically provided in this Act be in accordance with the provisions of the Code of
Criminal Procedure,1973 (2 of 1973).
426. Certain offences to be cognizable.
- The offences mentioned under section 340, section 350, section 353, section 397 and section 462
shall be cognizable within the meaning of the Code of Criminal Procedure, 1973.
427. Power of Municipal Magistrate to hear cases in absence of accused
summoned to appear.
- If, in any case any person who is summoned to appear before a Municipal Magistrate to answer
any charge of an offence under this Act or the rules or the regulations made thereunder, fails to
appear on the date and at the time and the place mentioned in the summons issued in this behalf or
on any subsequent date to which the hearing of such case is adjourned, the Municipal Magistrate
may if -(a)Service of the summons is to his satisfaction, proved to have been effected and,(b)No
sufficient cause is shown for non-appearance of such person.Hear and determine such case in the
absence of such person.
428. Limitation of time for prosecution.
- No person shall be liable to any punishment for an offence under this Act or the rules or the
regulations made thereunder unless a complain of such offence is made before a Municipal
Magistrate within six months next after -(a)the date of commission of such offence or,(b)the date on
which the commission or the continuance of such offence is first brought to the notice of the
Municipality or the Chief Municipal Executive Officer/ Municipal Executive Officer.
429. Complaint regarding nuisance and removal thereof.
(1)The Chief Municipal Executive Officer/ Municipal Executive Officer or any other officer of the
Municipality authorized by him in this behalf in writing or any person who resides or owns property
in the municipal area, may complain of the existence of any nuisance to a Municipal
Magistrate.(2)Upon receipt of any such complaint, the Municipal Magistrate after making such
inquiry as he considers necessary may if he thinks fit by an order in writing -(a)direct the person
responsible for such nuisance or the owner of the land or the building on which such nuisance exists
to take within such period as may be specified in the order such measures for abating, preventing
removing or remedying such nuisance as may appears to the Municipal Magistrate to be practicable
and reasonable and may direct the Chief Municipal Executive Officer/Municipal Executive Officer to
enforce any of the provisions of this Act or the rules or the regulations made thereunder for
prevention of such nuisance and(b)further direct the person held responsible for the nuisance to pay
to the complainant such reasonable cost of the complaint (including compensation for loss of timeArunachal Pradesh Municipal Act, 2007

in prosecution such complaint) as the Municipal Magistrate may determine :Provided that where in
the opinion of the Municipal Magistrate, immediate action to prevent the nuisance is necessary he
may dispense with the inquiry and make forthwith such order as he may consider necessary.(3)If
any person responsible for any nuisance or any owner of any land or building on which any nuisance
exists fails to comply with any order under sub-section (2) within the period specified in the order,
the Chief Municipal Executive Officer/ Municipal Executive Officer may on the expiry of such period
proceed to take necessary action in accordance with the order or may take such other measures to
abate, prevent, remove or remedy the nuisance as he may consider necessary and the cost of any
such action shall be recovered from such person or such owner as the case may be.
430. Power of Municipal Magistrate to direct payment of fine and demolition
of unlawful works.
(1)If under this Act or the rules or the regulations made thereunder any person is in respect of any
unlawful work liable -(a)to pay any fine and also(b)to demolish such work, the Municipal Magistrate
having jurisdiction may in his discretion, direct such person to pay the fine and also to demolish the
work.(2)All sums realized on account of fine under this section shall be credited to the Municipal
Fund.N. Legal Proceedings
431. Power to institute etc. legal proceedings and to obtain legal advices.
- The Chief Municipal Executive Officer/ Municipal Executive Officer may :-(a)take or withdraw
from proceeding against any person who is charge with -(i)any offence under this Act or any rules or
regulations made thereunder or(ii)any offence which affects or is likely to affect any property or
interest of the Municipality or the due administration of this Act or(iii)committing any nuisance
whatsoever or(b)contest or compromise any appeal against assessment of any tax or rate or,(c)take
or withdraw from or compromise any proceeding under this Act for the recovery of expenses or
compensation claimed to be due to the Municipality or(d)withdraw or compromise any claim for a
sum not exceeding one thousand rupees against any person or,(e)defend any suit or other legal
proceeding brought against the Municipality or against any municipal authority or any officer or
other employee of the Municipality in respect of anything done or omitted to be done by the
Municipality or such municipal authority or officer or other employee under this Act or the rules or
the regulations made thereunder in the official capacity or(f)compromise with the approval of the
Empowered Standing Committee or where there is no Empowered Standing Committee with the
approval of the Municipality any claim suit or other legal proceeding brought against the
Municipality or any municipal authority or any officer or other employee of the Municipality in
respect of anything done or omitted to be done under any of the foregoing clauses of this section
or,(g)withdraw from or compromise any claim against any person in respect of a penalty payable
under any contract entered into with such person by the Chief Municipal Executive Officer/
Municipal Executive Officer on behalf of the Municipality or,(h)institute or prosecute any suit or
other legal proceeding or with the approval of the Empowered Standing Committee or where there
is no Empowered Standing Committee with the approval of the Municipality withdraw from or
compromise any suit or claim other than a claim referred to in clause (d) instituted or made as the
case may be in the name of the Municipality or the Chief Municipal Executive Officer/ MunicipalArunachal Pradesh Municipal Act, 2007

Executive Officer or,(i)obtain for any of the purpose mentioned in the foregoing provisions of this
section or for securing lawful exercise or discharge of any power or duty vesting in or imposed upon,
any municipal authority or any officer or other employee or the Municipality such legal advise and
assistance as he may from time to time consider necessary or expedient or as he may be required by
the Municipality or the Empowered Standing Committee to obtain.
432. Notice limitations and tender of amends in suits against Municipality etc.
(1)No suit shall be instituted in any court having jurisdiction against any municipal authority or any
officer or other employee of the Municipality or any person acting under the direction of any
municipal authority or any officer or other employee of the Municipality in respect of anything done,
or purported to be done under this Act or the rules or the regulations made thereunder until the
expiration of one month next after a notice in writing has been delivered or left at the office of such
authority or at the office or the residence of such officer or other employee or person stating -(a)the
cause of action,(b)the name and residence of the intending plaintiff and(c)the relief which such
plaintiff claims,(2)Every such suit shall be commenced within four months next after accrual of the
cause of action and the plaint therein shall contain a statement that a notice has been delivered or
left as required under sub-section (1).(3)If the municipal authority at the office of which or the
officer or the other employee of the Municipality or the person acting under the direction of any
municipal authority or any officer or other employee of the Municipality at the office or the
residence of whom, a notice has been delivered or left under sub-section (1), satisfies the court
having jurisdiction that the relief claimed was tendered to the plaintiff before the institution of the
suit, the suit shall be dismissed.(4)Nothing in the foregoing provisions of this section shall apply to
any suit instituted under section 38 of the Specific Relief Act, 1963 (47 of 1963).
433. Indemnity.
- No suit shall be maintainable against any municipal authority or any officer or other employee of
the Municipality or any person acting under the direction of any municipal authority or any officer
or other employee of the Municipality or a Magistrate in respect of anything done lawfully and in
good faith with due care and attention under this Act or the rules or the regulations made
thereunder.O. Power and duties of Police Officer
434. Co-operation of police.
(1)Every Police- Officer-in-Charge of a police station within the jurisdiction of the Municipality and
every officer and every other employee, subordinate to him, if any (hereinafter referred to in this
section as the designated authority ) shall -(a)co-operative with the Municipality for carrying into
effect and enforcing the provisions of this Act and for maintaining good order in and outside the
municipal area and,(b)assist the Municipality or the Municipal Executive Officer or any other officer
or other employee of the Municipality in carrying out any order made by a Magistrate under this
Act.(2)It shall be the duty of every police officer -(i)to communicate without delay to the Chief
Municipal Executive Officer/ Municipal Executive Officer or any other officer of the Municipality
any information which he received in respect of any design to commit or any commission of anyArunachal Pradesh Municipal Act, 2007

offence under this Act or the rules or the regulations made thereunder and,(ii)to assist the Chief
Municipal Executive Officer/ Municipal Executive Officer or any other officer or other employee of
the Municipality requiring his aid for the lawful exercise of any power vesting in the Municipality or
the Chief Municipal Executive Officer/ Municipal Executive Officer or such other officer or other
employee under this Act or the rules or the regulations made thereunder.(3)Any officer or other
employee of the Municipality may when empowered by a general or special order of the designated
authority, if any on the recommendation of the Municipality in that behalf, exercise the powers of a
police for such of the purposes of this Act as may be specified in such general or special order.(4)The
District Magistrate, the Sub-Divisional Magistrate and the officer under them and the other
employee subordinate to them shall cooperate with the municipal authorities in the performance of
their duties under this Act.
435. Power of police to arrest offenders.
(1)Any Police Officer may arrest any person who commits in his view, any offence under this Act or
the rules or the regulations made thereunder provided that such person declines to give on demand
his name and address or gives a name or address which the Police Officer has reason to believe to be
false.(2)No person so arrested shall be detained in custody after his correct name and address are
ascertained or without the order of a Municipal Magistrate for a period longer than twenty four
hours from the time of arrests, exclusive of the period necessary for the journey from the place of
arrest to the court of such Municipal Magistrate.(3)On an application in writing of the Chief
Municipal Executive Officer/ Municipal Executive Officer or any other officer authorised by him in
this behalf, any police officer above the rank of a constable shall arrest any person who obstructs the
Chief Municipal Executive Officer/ Municipal Executive Officer or any other officer or other
employee of the Municipality in the exercise of any power or performance of any function or
discharge of any duty under this Act or the rules or the regulations made thereunder.(4)On an
application in writing of the Chief Municipal Executive Officer/ Municipal Executive Officer or any
other officer, not below the rank of an officer authorized in this behalf by the Chief Municipal
Executive Officer/ Municipal Executive Officer under sub-section (3), any police officer above the
rank of a constable shall arrest any person who is violation of the order referred to in sub-section (1)
of section 350 commences the erection of a building or execution of any work referred to in that
subsection or carries on such erection or such execution.P. General provisions
436. Validity of notice and other documents.
- No notice requisition license or permission in writing or any other document issued under this Act
shall be invalid merely by reason of defect form.
437. Admissibility of documents or entry as evidence.
- A copy of any receipt, application, plan, notice order or other document or any entry in a register in
the possession of any municipal authority shall if duly certified by the legal keeper thereof or other
person authorized by the Chief Municipal Executive Officer/ Municipal Executive Officer in this
behalf be admissible in evidence of the existence of the document or entry and shall be admitted asArunachal Pradesh Municipal Act, 2007

evidence of the matters and transaction therein recorded in every case where and to the same extent
to which the original document or entry would if produced have been admissible to prove such
matters and transactions.
438. Evidence of officer or employee of Municipality.
- No officer or other employee of the Municipality shall in any legal proceeding to which the
Municipality is not a party be required to produce any register or document the contents of which
can be proved under section 422 by a certified copy or to appear as a witness to prove any matter or
transaction recorded therein, save by an order made by a court having jurisdiction.
439. Prohibitions against obstruction of Chief Councillor or any municipal
authority etc.
- No person shall obstruct or molest -(a)any municipal authority or the Chief Councillor or the
Deputy Chief Councillor or a Councillor or the Chief Municipal Executive Officer/ Municipal
Executive Officer or any employee of the Municipality or any person employed by the Municipality
or,(b)any person authorised or empowered by or under this Act or with whom the Municipality or
any of the municipal authorities has lawfully entered into a contract,in the performances of his or its
duty or in the execution of his or its work or anything which he or it is empowered or required to do
by virtue or in consequence of any provision of this Act or the rules or the regulation made
thereunder or in the fulfillment of the contract as the case may be.
440. Prohibition against removal of mark.
- No person shall remove any mark set up for the purpose of indicating any level or direction
incidental to the execution of any work authorised by this Act or the rules or the regulations made
thereunder.
441. Prohibition against removal or obliteration of notice.
- No person shall without authority remove, destroy, deface or otherwise obliteration any notice
exhibited by or under the order of the Municipality or any municipal authority or any officer or
other employee of the Municipality specified by the Chief Municipal Executive Officer/ Municipal
Executive Officer in this behalf.
442. Prohibition against unauthorized dealing with public places or materials.
- No person shall without authority in that behalf remove earth, sand or other material from or
deposit any matter in or make any encroachment on any land vested in the Municipality or in any
way obstruct such land.Arunachal Pradesh Municipal Act, 2007

443. Liability for loss, waste or misapplication of money or property of
Municipality.
(1)Every person shall be liable for the loss, waste or misapplication of any money or other property
owned by vested in the Municipality if such loss, waste or misapplication is a direct consequence of
his neglect or misconduct in the performance of his duty and he may after being given opportunity
by a notice served in the manner provided for the service of summons in the Code of Civil Procedure
1908 (5 of 1908) to show caused by a representation in writing or oral, why he should not be
required to make good the loss by order be surcharged with the value of such property or the
amount of such money by the Director of Local Bodies and if the amount is not paid within one
month of the expiry of the period of appeal specified in sub-section (2) it shall be recoverable as an
arrear of tax leviable under this Act.(2)The person against whom an order under sub-section (1) is
made may within thirty days of the date of communications of the order, appeal to the State
Government and the State Government may confirm, modify or disallow the surcharge :Provided
that no person shall under this section be called upon to show cause after the expiry of a period of
four years or in the case of a Councillor after a period of one year from the occurrence of such loss or
waste or misapplication.
444. Councillors and officers and other employees of Municipality to be
public servants.
- Every Councillor, the Chief Municipal Executive Officer/ Municipal Executive Officer and every
other officer or other employee of the Municipality shall be deemed to be public servants within the
meaning of section 21 of the Indian Penal Code (45 of 1860).
445. Other laws not to be disregarded.
- Save as otherwise expressly provided in this Act, nothing contained in this Act shall be constructed
to authorised the Municipality or any municipal authority or any officer or other employee of the
Municipality to disregard any law for the time being in force.Chapter - XLIII Rules and Regulations
446. Power to make rules.
(1)The State Government may by notification and subject to the condition of previous publications
make rules for carrying out the purposes of this Act.(2)Any rules made under this Act may, provide
that any contravention thereof shall be punishable with fine which may extend to five thousand
rupees.(3)Every rule made under this Act shall be laid as soon as may be after it is made before the
State Legislature while it is in session for a total period of ten days which may be comprised in one
session or in two or more successive sessions and if before the expiry of the session in which it is so
laid or the successive sessions aforesaid, the State Legislature agrees in making any modification in
the rules or the State Legislature agrees that the rules should not be made the rule shall thereafter
have effect only in such modified form or be of no effect as the case may be so however that such
modification or annulment shall be without prejudice to the validity of anything previously done orArunachal Pradesh Municipal Act, 2007

omitted to be done under the rule.
447. Power to amend Schedule.
- The State Government may by notification add to amend or alter the Schedule to this Act.
448. Power to make regulations.
- The Municipality may from time to time make regulations not inconsistent with the provisions of
this Act or the rules made thereunder for the purpose of giving effect to the provisions of this Act.
449. Conditions precedent to making of regulations.
- The power to make regulations under this Act is subject to the condition of the regulations being
made after previous publication and to the following further conditions namely :(a)such draft of
regulations shall not be further proceeded with until a period of one month has expired from the
date of such publications.(b)for not less than one month during such period, a printed copy of such
draft shall be kept in the office of the Municipality for public inspection and any person shall be
permitted at any reasonable time to peruse such draft free of charge and,(c)printed copies of such
draft shall be obtainable by any person requiring such draft on payment of such fee as may be fixed
by the Empowered Standing Committee.
450. Regulations to be subject to approval of State Government.
(1)No regulation made by the Municipality under this Act shall have any effect until it has been
approved by the State Government and published in the Official Gazette.(iii)Before approving any
regulations, the State Government may make such changes therein as may appear to it to be
necessary.
451. Powers of State Government to cancel or modify regulations.
(1)If the State Government is at any time of the opinion that any regulations should be cancelled or
modified, either wholly or in part, it shall cause the reasons for such opinion to be communicated to
the Municipality and shall specify a reasonable period within which the Municipality may make such
representation with regard thereto as it may thinks fit.(2)After receipt and consideration of any such
representation or if in the meantime no such representation in received after the expiry of the period
as aforesaid, the State Government may at any time by notification cancel or modify such
regulations either wholly or in part.(3)The cancellation or modification of any regulation under
sub-section (2) shall take effect from such date as the State Government may specify in the
notification under that sub-section or if no such date is specified, from the date of publication of
such notification :Provided that such cancellation or modification shall not affect anything done or
suffered or omitted to be done under such regulation before such date.(4)Any modification under
sub-section (2) shall also be published in local newspapers.Arunachal Pradesh Municipal Act, 2007

452. Supplemental provisions respecting regulations.
- Any regulations which may be made by the Municipality under this Act may be made by the State
Government within one year from the date of commencement of this Act and any regulations so
made may be altered or rescinded by the Municipality with the approval of the State Government.
453. Penalty for breach of regulation.
(1)Any regulations made under this Act may provide that a contravention thereof shall be
punishable -(a)with fine which may extend to two thousand and five hundred rupees or,(b)with fine
which may extend to two thousand and five hundred rupees and in the case of a continuing
contravention with an additional fine which may extend to two hundred and fifty rupees for every
day during which such contravention continues after conviction for the first of such contravention
or,(c)with fine which may extend to two hundred and fifty rupees for every day during which the
contravention continues after the receipt by the person contravening the regulation of a notice
requiring such person to discontinue such contravention from the Chief Municipal Executive
Officer/ Municipal Executive Officer or any other officer of the Municipality, duly authorized in that
behalf.(2)Any such regulation may also provide that a person contravening that regulations shall be
required to remedy so far as lies in his power the mischief if any caused by such contravention.
454. Rules and regulations to be available for inspection and purchase.
(1)A copy of all rules and regulations made under this Act shall be kept at the office of the
Municipality and shall during office hours be open free of charge to inspection by any inhabitant of
the municipal.(2)Copies of such rules and regulations shall also be kept at the office of the
Municipality and shall be sold to the public at such price as the Empowered Standing Committee
may determine.
455. Doubts as to powers, duties or functions of municipal authorities.
- If any doubt arises as to the municipal authority to which any particular power, duties or function
appertains the Chief Councillor shall refer the matter to the State Government and the decision of
the State Government thereon shall be final.
Chapter XLIV
Offences and Penalties
456. Punishment for certain offence.
- Whoever -(a)contravenes any provisions of any of the sections, sub-section, clauses, provisos or
any other provision of this Act or,(i)with fine which may extend to such amount or with
imprisonment which may extend to such period, as the State Government may by rules, provideArunachal Pradesh Municipal Act, 2007

and,(ii)in the case of continuing contravention or failure with an additional fine which may extend
to such amount as the State Government may by rules provide for every day during which such
contravention or failure continues after conviction for the first such contravention or failure
:Provided that in the case of a Class 'A' Municipal Council or a Class 'B' Municipal Council or a Class
'C' Municipal Council or Nagar Panchayat, the amount to which the fine may extend for various
offences shall be such as the State Government may by rules, provide and in the case of continuing
contravention or failure the daily additional fine may extend to one tenth of the maximum amount
of fine provided for such class of municipalities in such rules.
457. Punishment for acquiring share or interest etc. with Municipality
- Any Councillor who knowingly acquires directly or indirectly any share or interest in any contract
made with or any work done for the Municipality except as a shareholder (other than a Director) in
an incorporated company or as a member of a co-operative society shall be deemed to have
committed the offence punishable under section 168 of the Indian Penal Code.
458. Fine for not paying tax under chapter XVII.
- If any person erects, exhibits, fixes or retains any advertisement referred to in chapter XVII
without paying any tax under that chapter, he shall be punished with fine which -(a)may extend to
an amount equal to five times the amount payable as such tax and(b)shall not ordinarily be less than
an amount equal to two times of such tax.
459. Fine for putting building to any use other than that for which a licence
has been granted.
- When any premises is used or is permitted to be used by any person for any purpose other than
that for which a licence has been granted under sub-section (1) of section 369 or as a stable or
cattle-shed or cow house, then such person shall without prejudice to any other penalty to which he
may be subjected, be liable to a fine which may extend in the case of a masonry building to two
hundred and fifty rupees and in the case of a hut to twenty five rupees and in the case if continuance
of such use to a further fine which may extend in the case of a masonry building to fifty rupees and
in the case of a hut to five rupees for each day during which such use continues after the first day.
460. Penalty for obstructing contractor.
- Whoever obstructs or molests any person with whom the Municipality has entered into a contract
for execution of any work under this Act shall on convictions be punished with imprisonment for a
term which may extend to two months or with fine which may extend to two hundred rupees.Arunachal Pradesh Municipal Act, 2007

461. Penalty for causing damage to property belong to Municipality.
- No person shall cause any damage to any property belonging to the Municipality. Any person
causing any damage to any property belonging to the Municipality shall on conviction be punished
with fine which may extend to one thousand rupees.
462. Encroachment on streets.
- No person shall cause any encroachment or obstruction on any municipal property such as a street
or footpath or park without specific permission of an officer of the Municipality duly authorised to
grant such permission. Any person causing such encroachment or obstruction on any municipal
property as aforesaid shall on conviction be punishable with fine which may extend to one thousand
rupees.
463. Punishment of imprisonment in default of payment of fine.
- In every case where under this Act an offence is punishable with fine or with imprisonment or fine
or with both and a person is sentenced by a Court having jurisdiction to pay a fine it shall be
competent for such Court to direct that in default of payment of fine, he shall suffer imprisonment
for such term or as the case may be such further term, not exceeding six months as the Court may
fix.
464. General penalty.
- Whoever in any case in which a penalty is not expressly provided by this Act fails to comply with
any notice or order or requisition issued under any provision thereof or otherwise contravenes any
of the provisions of this Act shall be punishable with fine which may extend to one thousand rupees
and in the case of a continuing failure or contravention with an additional fine which may extend to
one hundred rupees for every day after the first during which he has persisted in such failure or
contravention.
465. Offences by companies.
(1)Where an offence under this Act has been committed by a company every person who at the time
the offence was committed was in charge of and was responsible to the company for the conduct of
the business of the company as well as the company shall be deemed to be guilty of the offence and
shall be liable to be proceeded against and punished accordingly :Provided that nothing contained in
this sub-section shall render any such person liable to any punishment provided in this Act if he
proves that the offence was committed without his knowledge or that he exercise all due diligence to
prevent the commission of such offence.(2)Notwithstanding anything contained in sub-section (1)
where an offence under this Act has been committed by a company and it is proved that the offence
has been committed with the consent or connivance of or is attributable to any neglect on the part of
any director, manager, secretary or other officer of the company such director, manager, secretaryArunachal Pradesh Municipal Act, 2007

or other officer shall also be liable to be proceeded against and punished accordingly -Explanation. -
For the purpose of this section -(a)"company" means body corporate and includes a firm or other
association of individuals and(b)"director" in relation to a firm, means a partner in the firm.
466. Prosecution.
- Save as otherwise provided in this Act no Court shall proceed to the trial of any offence punishable
by or under this Act except on the complaint of or upon information received from the Chief
Municipal Executive Officer/ Municipal Executive Officer or any person authorised by him, by
general or special order in this behalf.
467. Compounding of offences.
(1)The Chief Municipal Executive Officer/Municipal Executive Officer or if so authorised by the
Municipality in this behalf by a general or special order Municipal Health Officer, the Municipal
Engineer or any other officer of the Municipality may either before or after the institutions of the
proceeding and on payment of such fee as may be specified by regulations, compound any offence as
may be classified as compoundable by the State Government by rules.(2)Notwithstanding anything
contained in sub-section (1) no offence punishable by or under this Act or by any rule or regulations
made thereunder shall be compoundable if such offence is committed due to the failure to comply
with any notice, order or requisition as the case may, be issued by or on behalf of any of the
municipal authorities referred to in section 20, unless and until such notice, order or requisition as
the case may be has been complied with in so far as such compliance is possible.(3)Where an offence
has been compounded, the offender if in custody shall be discharge and no further proceeding shall
be taken against him in respect of the offence so compounded.Chapter - XLV Supplemental
ProvisionsA. Extension of Act to other area and inclusion or exclusion of areas within or from the
Municipal area.
468. Powers of State Government to notify intention to extend Act to other
areas.
- Notwithstanding anything contained in any other law for the time being in force, the State
Government may by notification and in such other manner as it may determine, declare its intention
to extend, subject to such modification and restriction, if any as may be specified in the notification,
all or any of the provisions of this Act to any other area.B. Miscellaneous and Transitory Provisions
469. Provisions of the chapter to override other provisions.
- The provision of this chapter shall have effect notwithstanding anything to the contrary contained
elsewhere in this Act.Arunachal Pradesh Municipal Act, 2007

470. Removal of difficulties.
- If any difficulty arises in giving effect to the provisions of this Act, the State Government may as
occasion may required by order do or cause to be done anything which may be necessary for
removing the difficulties :Provided that no such order shall be made after the expiry of a period of
five years from the date of commencement of this Act.
471. Repeal and savings.
- With effect from the date of coming into force of this Act/ the other relevant laws/Acts which has
taken in the domain of Municipality shall stand repealed.
472. Transitory provisions.
(1)Notwithstanding anything to the contrary contained elsewhere in this Act, the State Government
may appoint a person to be called the Administrator to exercise all the powers and discharge all the
functions of the municipal authorities mentioned in section 20 for the period from the date of
coming into force of this Act till the first meeting of the Municipality at which a quorum is
present.(2)The Administrator appointed under sub-section (1) may constitute such Committees and
for such period as he may deem fit.(3)Each such Committee shall consist of not more than twenty
five person appointed on such terms and conditions as he Administrator may deem fit and shall
advise the Administrator in the discharge of his functions under this Act.
Schedule
(See section 369)Proposes for Which Premises May Not be Used Without a Licence or Written
Permission.
1. Aerated water - manufacturing
2. Aerated waters - manufacturing, parching, packing, pressing, cleaning,
cleansing, boiling, melting, grinding or preparing by any process,
whatsoever.
3. Aloe fibre and yarn - storing, packing, pressing, cleansing, preparing or
manufacturing by any process whatsoever.
4. Ammunition - Storing, pressing, cleansing, preparing or manufacturing by
any process whatsoever.Arunachal Pradesh Municipal Act, 2007

5. Arecanut - soaking of
6. Article made of flour - baking, preparing, keeping or storing for human
consumption (for other than domestic use).
7. Asafetida - storing.
8. Asafetida - except for domestic purposes.
9. Ash - storing, packing, pressing, cleansing, preparing or manufacturing by
any process whatsoever.
10. Ashes -except for domestic purposes.
11. Autocar or Autocycle servicing or repairing.
12. Bakelite goods - manufacturing or processing.
13. Bakelite goods - manufacturing, parching, packing, pressing, cleaning,
cleansing, boiling, melting, grinding or preparing by any process,
whatsoever.
14. Bamboo - storing for sale, hire or manufacture.
15. Bamboos - except for domestic purposes.
16. Banking
17. Bidi leaves - storing or processing.
18. Bidi leaves - except for domestic purposes.
19. Biddies (indigenous cigarettes) snuff, cigars or cigarettes manufacturing,
parching, packing, pressing, cleaning, cleansing, boiling, melting, grinding or
preparing by any process whatsoever.
20. Biscuit - baking, preparing, keeping or storing for human consumption
(for other than domestic use).Arunachal Pradesh Municipal Act, 2007

21. Bitumen - manufacturing, parching, packing, pressing, cleaning,
cleansing, boiling, melting, grinding or preparing by any process,
whatsoever.
22. Blacksmith.
23. Blasting powder - storing.
24. Blasting powder - manufacturing, parching, packing, pressing, cleaning,
cleansing, boiling, melting, grinding or preparing by any process,
whatsoever.
25. Blasting powder - except for domestic purposes.
26. Blood - storing, packing, pressing, cleansing, preparing or manufacturing
by any process whatsoever.
27. Blood - except for domestic purposes.
28. Bone - storing, packing, pressing, cleansing, preparing or manufacturing
by any process whatsoever.
29. Bones, bone meal or bone powder - except for domestic purposes.
30. Bone - manufacturing, parching, packing, pressing, cleaning, cleansing,
boiling, melting, grinding or preparing by any process, whatsoever.
31. Bread - baking, preparing, keeping or storing for human consumption (for
other than domestic use).
32. Brick - manufacturing
33. Bricks or tiles by hand power - manufacturing, parching, packing,
pressing, cleaning, cleansing, boiling, melting, grinding or preparing by any
process, whatsoever.
34. Bricks or tiles by Mechanical power - manufacturing, parching, packing,
pressing, cleaning, cleansing, boiling, melting, grinding or preparing by any
process, whatsoever.Arunachal Pradesh Municipal Act, 2007

35. Brushes - manufacturing, parching, packing, pressing, cleaning,
cleansing, boiling, melting, grinding or preparing by any process,
whatsoever.
36. Camphor - storing, packing, pressing, cleansing, preparing or
manufacturing by any process whatsoever or boiling.
37. Camphor - except for domestic purposes.
38. Candle - Packing, pressing, cleansing, preparing or manufacturing by any
process whatsoever.
39. Candle - manufacturing, parching, packing, pressing, cleaning, cleansing,
boiling, melting, grinding or preparing by any process, whatsoever.
40. Carbide of calcium - storing.
41. Carbide of calcium - except for domestic purposes.
42. Cardboard - storing.
43. Cardboard - except for domestic purposes.
44. Carpet - manufacturing.
45. Cashewnut - storing, packing, preparing or manufacturing by any process
whatsoever.
46. Catgut - storing, packing, pressing, cleansing, preparing or
manufacturing by any process whatsoever.
47. Catgut - manufacturing, parching, packing, pressing, cleaning, cleansing,
boiling, melting, grinding or preparing by any process, whatsoever.
48. Celluloid goods - storing.
49. Celluloid or celluloid goods - manufacturing, parching, packing, pressing,
cleaning, cleansing, boiling, melting, grinding or preparing by any process,
whatsoever.Arunachal Pradesh Municipal Act, 2007

50. Celluloid or celluloid goods - except for domestic purposes.
51. Cement - packing, pressing, cleansing, preparing or manufacturing by
any process whatsoever.
52. Cement concrete designs or models - manufacturing, parching, packing,
pressing, cleaning, cleansing, boiling, melting, grinding or preparing by any
process, whatsoever.
53. Charcoal - dumping, shifting, selling or storing.
54. Charcoal - manufacturing, parching, packing, pressing, cleaning,
cleansing, boiling, melting, grinding or preparing by any process,
whatsoever.
55. Charcoal - except for domestic purposes.
56. Chemicals - manufacturing, parching, packing, pressing, cleaning,
cleansing, boiling, melting, grindi or preparing by any process, whatsoever.
57. Chemicals preparation - storing, packing, pressing, cleansing, preparing
or manufacturing by any process whatsoever.
58. Chemicals, liquid - except for domestic purposes.
59. Chemical, non-liquid - except for domestic purposes.
60. Chilli -grinding by machinery.
61. Chilli (Dried) - selling wholesale or storing for wholesale trade.
62. Chilli - except for domestic purposes.
63. Chillis or masala or corn or seeds. Grinding of by mechanical means.
64. Chlorare mixture - storing, packing, pressing, cleansing, preparing or
manufacturing by any process whatsoever.Arunachal Pradesh Municipal Act, 2007

65. Chlorate mixture - except for domestic purposes.
66. Cinder - storing, packing, pressing, cleansing, preparing or
manufacturing by any process whatsoever or dumping or shifting.
67. Cinematograph films stripping in connection with any trade
manufacturing, parching, packing, pressing, cleaning, cleansing, boiling,
melting, grinding or preparing by any process, whatsoever.
68. Cinematograph film -shooting of, treating or processing.
69. Cinematograph films non-flammable or acetateorsafety base -except for
domestic purposes.
70. Cloth - dyeing, bleaching, mercerizing or storing.
71. Cloth is pressed bales or boras - except for domestic purposes.
72. Cloth or clothes of cotton, wool, silk, art silk etc. - except for domestic
purposes.
73. Cloth yarn or leather in indigo or in other colours. Dyeing or printing.
74. Cloth or yarn, bleaching.
75. Coal - dumping, shifting, selling or storing.
76. Coal - except for domestic purposes.
77. Coconut fibre - storing, packing, pressing, cleansing, preparing or
manufacturing by any process whatsoever.
78. Coconut fibre - except for domestic purposes.
79. Coconut husk - soaking of.
80. Coconut shell - storing.Arunachal Pradesh Municipal Act, 2007

81. Coir yarn - storing, packing, pressing, cleansing, preparing or
manufacturing by any process whatsoever.
82. Coke - storing.
83. Coke - except for domestic purposes.
84. Combustible material - storing.
85. Combustible - baking, preparing, keeping or storing for human
consumption (for other than domestic use).
86. Compound gas ( oxygen, nitrogen, hydrogen, carbon dioxide, sulphur,
chloride, acetylene) - storing.
87. Compound gas ( oxygen, nitrogen, hydrogen, carbon dioxide, sulphur,
chloride, acetylene) - except for domestic purposes.
88. Coppersmithy.
89. Copra - preparing or storing or selling wholesale.
90. Copra - except for domestic purposes.
91. Cosmetics or toilet goods - manufacturing, parching, packing, pressing,
cleaning, cleansing, boiling, melting, grinding or preparing by any process,
whatsoever.
92. Cotton of all kinds, cottons seed - storing, packing, pressing, cleansing,
preparing or manufacturing by any process whatsoever.
93. Cotton seeds - manufacturing, parching, packing, pressing, cleaning,
cleansing, boiling, melting, grinding or preparing by any process,
whatsoever.
94. Cotton seed - except for domestic purposes.Arunachal Pradesh Municipal Act, 2007

95. Cotton including kahok, surgical cotton and silky cotton - except for
domestic purposes.
96. Cotton refuse of waste or cotton yarn refuse or waste - except for
domestic purposes.
97. Cotton, cotton refuses, cotton waste, cotton yarn, silk, silk yarn inclusive
of waste yarn, art silk, art silk waste, art silk yarn, wool or woolen refuse or
waste - manufacturing, parching, packing, pressing, cleaning, cleansing,
boiling, melting, grinding or preparing by any process, whatsoever.
98. Cow-dungs cake - storing, packing, pressing, cleansing, preparing or
manufacturing by any process whatsoever.
99. Dammar (Resin) - manufacturing, parching, packing, pressing, cleaning,
cleansing, boiling, melting, grinding or preparing by any process,
whatsoever.
100. Detonators - storing.
101. Detonators - except for domestic purposes.
102. Drug - manufacturing, parching, packing, pressing, cleaning, cleansing,
boiling, melting, grinding or preparing by any process, whatsoever.
103. Drugs - details sale of.
104. Dry leaf - storing.
105. Dry leaves - except for domestic purposes.
106. Dye (Stuff) - packing, pressing, cleansing, preparing or manufacturing
by any process whatsoever.
107. Dynamite - storing.
108. Dynamite - manufacturing, parching, packing, pressing, cleaning,
cleansing, boiling, melting, grinding or preparing by any process,
whatsoever.Arunachal Pradesh Municipal Act, 2007

109. Dynamite - except for domestic purposes.
110. Eating house or catering establishment. Keeping of an.
111. Electroplating.
112. Explosive - Storing.
113. Explosive paint (nitro-cellulose, lacquer, enamel) - storing.
114. Explosive paint (nitro-cellulose, lacquer, enamel) - except for domestic
purposes.
115. Fat - storing, packing, pressing, cleansing, preparing or manufacturing
by any process whatsoever.
116. Fat - manufacturing, parching, packing, pressing, cleaning, cleansing,
boiling, melting, grinding or preparing by any process, whatsoever.
117. Fat - except for domestic purposes.
118. Felt - storing.
119. Felt - except for domestic purposes.
120. Fibre - selling or storing.
121. Fin - storing, packing, pressing, cleansing, preparing or manufacturing
by any process whatsoever.
122. Fins - except for domestic purposes.
123. Firewood - selling or storing.
124. Firewood - except for domestic purposes.
125. Fireworks - storing, packing, pressing, cleansing, preparing or
manufacturing by any process whatsoever.Arunachal Pradesh Municipal Act, 2007

126. Fireworks - manufacturing, parching, packing, pressing, cleaning,
cleansing, boiling, melting, grinding or preparing by any process,
whatsoever.
127. Fireworks - except for domestic purposes.
128. Fish - storing, packing, pressing, cleansing, preparing or manufacturing
by any process whatsoever.
129. Fish (dried) - except for domestic purposes.
130. Fish oil - storing, packing, pressing, cleansing, preparing or
manufacturing by any process whatsoever.
131. Flax- storing, packing, pressing, cleansing, preparing or manufacturing
by any process whatsoever.
132. Flax - manufacturing, parching, packing, pressing, cleaning, cleansing,
boiling, melting, grinding or preparing by any process, whatsoever.
133. Flax - except for domestic purposes.
134. Fleshing - storing, packing, pressing, cleansing, preparing or
manufacturing by any process whatsoever.
135. Flour - packing, pressing, cleansing, preparing or manufacturing by any
process whatsoever.
136. Food - manufacturing, parching, packing, pressing, cleaning, cleansing,
boiling, melting, grinding or preparing by any process, whatsoever.
137. Food - Retail sale of.
138. Fuel - using for any industrial purpose.
139. Fulminate - except for domestic purposes.Arunachal Pradesh Municipal Act, 2007

140. Fulminate of mercury - storing, packing, pressing, cleansing, preparing
or manufacturing by any process whatsoever.
141. Fulminate of mercury - except for domestic purposes.
142. Fulminate of silver - except for domestic purposes.
143. Furniture - making or storing for sale.
144. Gas - storing, packing, pressing, cleansing, preparing or manufacturing
by any process whatsoever.
145. Gas - manufacturing, parching, packing, pressing, cleaning, cleansing,
boiling, melting, grinding or preparing by any process, whatsoever.
146. Gelatine -storing.
147. Gelatine - except for domestic purposes.
148. Gelignite -except for domestic purposes.
149. Ghee - storing, packing, pressing, cleansing, preparing or
manufacturing by any process whatsoever.
150. Ghee - manufacturing, parching, packing, pressing, cleaning, cleansing,
boiling, melting, grinding or preparing by any process, whatsoever.
151. Glass or glass articles - manufacturing, parching, packing, pressing,
cleaning, cleansing, boiling, melting, grinding or preparing by any process,
whatsoever.
152. Glass leveling.
153. Glass cutting.
154. Glass polishing.Arunachal Pradesh Municipal Act, 2007

155. Gold - refining.
156. Goldsmithy.
157. Grain - selling wholesale or storing for wholesale trade.
158. Grain - Parching.
159. Gram - husking by machinery.
160. Grass - storing.
161. Grass - except for domestic purposes.
162. Groundnut - selling wholesale or storing for wholesale trade.
163. Groundnut seeds, tamarind or any other seeds, parching.
164. Gun-cotton - storing, packing, pressing, cleansing, preparing or
manufacturing by any process whatsoever.
165. Gun-cotton - except for domestic purposes.
166. Gunny bag - storing, packing, pressing, cleansing, preparing or
manufacturing by any process whatsoever.
167. Gunny bag - except for domestic purposes.
168. Gunpowder - storing, packing, pressing, cleansing, preparing or
manufacturing by any process whatsoever.
169. Gunpowder - manufacturing, parching, packing, pressing, cleaning,
cleansing, boiling, melting, grinding or preparing by any process,
whatsoever.
170. Gunpowder - except for domestic purposes.Arunachal Pradesh Municipal Act, 2007

171. Hair - storing, packing, pressing, cleansing, preparing or manufacturing
by any process whatsoever.
172. Hair - except for domestic purposes.
173. Hair dressing saloon or a barber's shop. Keeping of.
174. Hay - selling or storing.
175. Hay or fodder - except for domestic purposes.
176. Hemp - storing, packing, pressing, cleansing, preparing or
manufacturing by any process whatsoever.
177. Hemp - manufacturing, parching, packing, pressing, cleaning, cleansing,
boiling, melting, grinding or preparing by any process, whatsoever.
178. Hemp - except for domestic purposes.
179. Hessain cloth - storing.
180. Hessain cloth (Gunny bag cloth) - except for domestic purposes.
181. Hides - storing, packing, pressing, cleansing, preparing or
manufacturing by any process whatsoever.
182. Hides (dried) - except for domestic purposes.
183. Hides (raw) -except for domestic purposes.
184. Hides or skins, whether raw or dried. Tanning, pressing or packing.
185. Hoof - storing, packing, pressing, cleansing, preparing or manufacturing
by any process whatsoever.
186. Hoofs - except for domestic purposes.Arunachal Pradesh Municipal Act, 2007

187. Horn - storing, packing, pressing, cleansing, preparing or manufacturing
by any process whatsoever.
188. Horns - except for domestic purposes.
189. Ice - manufacturing
190. Ice (including dry ice) - manufacturing, parching, packing, pressing,
cleaning, cleansing, boiling, melting, grinding or preparing by any process,
whatsoever.
191. Incense - storing
192. Incense of esas - except for domestic purposes.
193. Ink for printing, printing, stamping etc. - manufacturing, parching,
packing, pressing, cleaning, cleansing, boiling, melting, grinding or
preparing by any process, whatsoever.
194. Insecticide or disinfectants - manufacturing, parching, packing,
pressing, cleaning, cleansing, boiling, melting, grinding or preparing by any
process, whatsoever.
195. Jaggery - storing, packing, pressing, cleansing, preparing or
manufacturing by any process whatsoever.
196. Jute - storing, packing, pressing, cleansing, preparing or manufacturing
by any process whatsoever.
197. Jute - except for domestic purposes.
198. Khaki - preparing
199. Khokas, boxes, barrels, furniture or any other article of wood - except
for domestic purposes.
200. Keeping of horses, cattle or other quadruped animals or birds for
transportation, sale or hire or for sale of the product thereof.Arunachal Pradesh Municipal Act, 2007

201. Lac - storing, packing, pressing, cleansing, preparing or manufacturing
by any process whatsoever.
202. Lacquer - except for domestic purposes.
203. Laundry shop. Keeping.
204. Lead - melting.
205. Leather - storing, packing, pressing, cleansing, preparing or
manufacturing by any process whatsoever.
206. Leather cloth or rexina cloth or water proof cloth - manufacturing,
parching, packing, pressing, cleaning, cleansing, boiling, melting, grinding or
preparing by any process, whatsoever.
207. Leather goods, manufacturing of by mechanical means.
208. Leather - except for domestic purposes.
209. Lime - storing, packing, pressing, cleansing, preparing or manufacturing
by any process whatsoever.
210. Lime - manufacturing, parching, packing, pressing, cleaning, cleansing,
boiling, melting, grinding or preparing by any process, whatsoever.
211. Limeshell -storing, packing, pressing, cleansing, preparing or
manufacturing by any process whatsoever.
212. Linseed oil - manufacturing, parching, packing, pressing, cleaning,
cleansing, boiling, melting, grinding or preparing by any process,
whatsoever.
213. Litho press. Keeping a-
214. Lodging house. Keeping of a-Arunachal Pradesh Municipal Act, 2007

215. Machinery - using for any industrial purpose.
216. Manure - storing, packing, pressing, cleansing, preparing or
manufacturing by any process whatsoever.
217. Marble cutting, grinding, dressing or polishing.
218. Match - storing, packing, pressing, cleansing, preparing or
manufacturing by any process whatsoever.
219. Matches for lighting (including Bengal matches) - manufacturing,
parching, packing, pressing, cleaning, cleansing, boiling, melting, grinding or
preparing by any process, whatsoever.
220. Matches for lighting ( including Bengal matches) - except for domestic
purposes.
221. Matirf-clifs and nillfiws - manufacturing, parching, packing, pressing,
cleaning, cleansing, boiling, melting, grinding or preparing by any process,
whatsoever.
222. Meat - storing, packing, pressing, cleansing, preparing or manufacturing
by any process whatsoever.
223. Metal (ferrous or non-ferrous or antimony by excluding precious metal)
cutting or treating metal by hammering, drilling, pressing, filling, polishing,
heating or by any other process whatever or assembling part of metal.
224. Metal ( including precious metals) - beating, breaking, hammering and
casting.
225. Methylated spirit or denatured spirit - storing.
226. Methylated spirit, denatured spirit or French polish - except for domestic
purposes.Arunachal Pradesh Municipal Act, 2007

227. Nitro - cellulose - except for domestic purposes.
228. Nitro - compound - storing, packing, pressing, cleansing, preparing or
manufacturing by any process whatsoever.
229. Nitro- compound - except for domestic purposes.
230. Nitro - glycerine -except for domestic purposes.
231. Nitro - mixture - storing, packing, pressing, cleansing, preparing or
manufacturing by any process whatsoever.
232. Nitro - mixture - except for domestic purposes.
233. Offal - storing, packing, pressing, cleansing, preparing or manufacturing
by any process whatsoever.
234. Offal - manufacturing, parching, packing, pressing, cleaning, cleansing,
boiling, melting, grinding or preparing by any process, whatsoever.
235. Offal - except for domestic purposes.
236. Oil - storing, packing, pressing, cleansing, preparing or manufacturing
by any process whatsoever.
237. Oil other than petroleum (either by mechanical power or by hand power
or ghani driven by bullock or any other animal) - manufacturing, parching,
packing, pressing, cleaning, cleansing, boiling, melting, grinding or
preparing by any process, whatsoever.
238. Oil other than petroleum - except for domestic purposes.
239. Oil - cloth - manufacturing, parching, packing, pressing, cleaning,
cleansing, boiling, melting, grinding or preparing by any process,
whatsoever.
240. Oilseeds - storing.Arunachal Pradesh Municipal Act, 2007

241. Oilseeds including almonds bur excluding cotton seeds - except for
domestic purposes.
242. Old paper or waste paper including old newspaper, periodicals,
magazines etc. except for domestic purposes.
243. Packing stuff (paper cutting, husic, saw dust etc,) - except for domestic
purposes.
244. Paddy - boiling or husking by machinery.
245. Paint - manufacturing or storing.
246. Paints - manufacturing, parching, packing, pressing, cleaning,
cleansing, boiling, melting, grinding or preparing by any process,
whatsoever.
247. Paints - except for domestic purposes.
248. Paper - packing, pressing, cleansing, preparing or manufacturing by any
process whatsoever.
249. Paper other than old in pressed bales or loose or in reams - except for
domestic purposes.
250. Paper or cardboard - manufacturing, parching, packing, pressing,
cleaning, cleansing, boiling, melting, grinding or preparing by any process,
whatsoever.
251. Petroleum product - storing, packing, pressing, cleansing, preparing or
manufacturing by any process whatsoever.
252. Petroleum product other than dangerous petroleum as defined in the
Petroleum Act. 1934 - except for domestic purposes.
253. Pharmaceutical or medical products - manufacturing, parching, packing,
pressing, cleaning, cleansing, boiling, melting, grinding or preparing by any
process, whatsoever.Arunachal Pradesh Municipal Act, 2007

254. Photography - studio.
255. Phosphorous - storing.
256. Phosphorous - except for domestic purposes.
257. Pickers from hides - manufacturing, parching, packing, pressing,
cleaning, cleansing, boiling, melting, grinding or preparing by any process,
whatsoever.
258. Pitch - storing, packing, pressing, cleansing, preparing or manufacturing
by any process whatsoever.
259. Pitch - manufacturing, parching, packing, pressing, cleaning, cleansing,
boiling, melting, grinding or preparing by any process, whatsoever.
260. Plastic or plastic goods - manufacturing or storing.
261. Plastic goods - manufacturing, parching, packing, pressing, cleaning,
cleansing, boiling, melting, grinding or preparing by any process,
whatsoever.
262. Plastic or plastic goods - except for domestic purposes.
263. Plywood - storing
264. Plywood - except for domestic purposes.
265. Polythene - manufacturing or storing.
266. Pottery - packing, pressing, cleansing, preparing or manufacturing by
any process whatsoever.
267. Pottery by hand power - manufacturing, parching, packing, pressing,
cleaning, cleansing, boiling, melting, grinding or preparing by any process,
whatsoever.Arunachal Pradesh Municipal Act, 2007

268. Pottery by mechanical or any power other than hand power
manufacturing, parching, packing, pressing, cleaning, cleansing, boiling,
melting, grinding or preparing by any process, whatsoever.
269. Precious metals, Refining of or recovering them from embroideries.
270. Printing press. Keeping a -
271. Radio - manufacturing, assembling, servicing and repairing.
272. Radio (wireless receiving set) selling, repairing, servicing or
manufacturing.
273. Rags including small piece or cuttings of cloth, Hessian cloths, gunny -
bag, cloth silk, art silk or woolen cloth - except for domestic purposes.
274. Resin (including rosin) - storing, packing, pressing, cleansing, preparing
or manufacturing by any process whatsoever.
275. Rosin or dram mar Battar otherwise known as Ral - except for domestic
purposes.
276. Rubber or rubber goods - manufacturing, parching, packing, pressing,
cleaning, cleansing, boiling, melting, grinding or preparing by any process,
whatsoever.
277. Rug - storing, packing, pressing, cleansing, preparing or manufacturing
by any process whatsoever.
278. Safety fuses, fog signals, cartridge etc. - except for domestic purposes.
279. Sago - manufacturing or distilling.
280. Salpetre - storing, packing, pressing, cleansing, preparing or
manufacturing by any process whatsoever.
281. Salpetre - except for domestic purposes.Arunachal Pradesh Municipal Act, 2007

282. Sandalwood - except for domestic purposes.
283. Sanitary ware of china - ware - manufacturing, parching, packing,
pressing, cleaning, cleansing, boiling, melting, grinding or preparing by any
process, whatsoever.
284. Shellac - storing, packing, pressing, cleansing, preparing or
manufacturing by any process whatsoever.
285. Silk - packing, pressing, cleansing, preparing or manufacturing by any
process whatsoever.
286. Silk waste or silk yarn waste, art silk waste or art silk yarn waste - except
for domestic purposes.
287. Silversmithy.
288. Sisal fibre - storing.
289. Sisal fibre - except for domestic purposes.
290. Skin - storing, packing, pressing, cleansing, preparing or manufacturing
by any process whatsoever.
291. Skin (raw or dried) - except for domestic purposes.
292. Soap - packing, pressing, cleansing, preparing or manufacturing by any
process whatsoever.
293. Soap - manufacturing, parching, packing, pressing, cleaning, cleansing,
boiling, melting, grinding or preparing by any process, whatsoever.
294. Spinning or weaving cotton, silk, art silk or jute or wool with the aid of
power.
295. Spirit - storing, packing, pressing, cleansing, preparing or
manufacturing by any process whatsoever.Arunachal Pradesh Municipal Act, 2007

296. Stone grinding, cutting, dressing or polishing.
297. Straw - selling or storing.
298. Straw - except for domestic purposes.
299. Sugar - packing, pressing, cleansing, preparing or manufacturing by any
process whatsoever.
300. Sugar - manufacturing, parching, packing, pressing, cleaning, cleansing,
boiling, melting, grinding or preparing by any process, whatsoever.
301. Sugar candy - packing, pressing, cleansing, preparing or manufacturing
by any process whatsoever.
302. Sulphur - storing, packing, pressing, cleansing, preparing or
manufacturing by any process whatsoever.
303. Sulphur - except for domestic purposes.
304. Surki - storing, packing, pressing, cleansing, preparing or
manufacturing by any process whatsoever.
305. Sweetmeat - baking, preparing, keeping or storing for human
consumption ( for other than domestic use).
306. Sweetmeat and confectionery goods - manufacturing, parching, packing,
pressing, cleaning, cleansing, boiling, melting, grinding or preparing by any
process, whatsoever.
307. Sweetmeat shop except in premises already licensed as an eating
house. Keeping.
308. Tallow - storing, packing, pressing, cleansing, preparing or
manufacturing by any process whatsoever.
309. Tallow - manufacturing, parching, packing, pressing, cleaning,
cleansing, boiling, melting, grinding or preparing by any process,
whatsoever.Arunachal Pradesh Municipal Act, 2007

310. Tallow - except for domestic purposes.
311. Tar - storing, packing, pressing, cleansing, preparing or manufacturing
by any process whatsoever.
312. Tar - manufacturing, parching, packing, pressing, cleaning, cleansing,
boiling, melting, grinding or preparing by any process, whatsoever.
313. Tar - storing, packing, pressing, cleansing, preparing or manufacturing
by any process whatsoever.
314. Tarpaulin - storing.
315. Tarpaulin - except for domestic purposes.
316. Thatching material - selling or storing.
317. Thinner - storing
318. Thinner - except for domestic purposes.
319. Tiles - manufacturing.
320. Timber - selling or storing
321. Timber - except for domestic purposes.
322. Timber or wood sawing or cutting by mechanical or electric power.
323. Tinsmithy.
324. Tobacco (including snuff, cigar, cigarette and Bidi) - storing, packing,
pressing, cleansing, preparing or manufacturing by any process whatsoever.
325. Turpine - storing, packing, pressing, cleansing, preparing or
manufacturing by any process whatsoever.Arunachal Pradesh Municipal Act, 2007

326. Turpine - except for domestic purposes.
327. Varnish - manufacturing or storing.
328. Varnish - manufacturing, parching, packing, pressing, cleaning,
cleansing, boiling, melting, grinding or preparing by any process,
whatsoever.
329. Varnish - except for domestic purposes.
330. Washerman's trade.
331. Welding of metal by electric, gas or any process whatsoever.
332. Wooden furniture, boxes, barrel, kokas or other articles of wood or of
plywood or of sandalwood manufacturing, parching, packing, pressing,
cleaning, cleansing, boiling, melting, grinding or preparing by any process,
whatsoever.
333. Wool - storing, packing, pressing, cleansing, preparing or manufacturing
by any process whatsoever.
334. Wool (raw) - except for domestic purposes.
335. Yarn - dyeing or bleaching.
336. Yarn other than waste yarn - except for domestic purposes.
337. Manufacturing article from which offensive or unwholesome smell,
fume, dust or noise arises.Arunachal Pradesh Municipal Act, 2007

