Delhi High Court Intellectual Property Rights Division Rules,
2022
DELHI
India
Delhi High Court Intellectual Property Rights Division
Rules, 2022
Rule 13 of 2022
Published in Delhi Gazette 474 on 24 February 2022• 
Commenced on 24 February 2022• 
[This is the version of this document from 24 February 2022.]• 
HIGH COURT OF DELHI: NEW DELHINOTIFICATIONDelhi, the 24th February, 2022No.
13/Rules/DHC.—Delhi High Court Intellectual Property Rights Division Rules, 2022Whereas, upon
the promulgation of the Tribunals Reforms (Rationalisation and Conditions of Service) Ordinance,
2021. (“Ordinance”), now the Tribunal Reforms Act, 2021(“TRA 2021”) and upon the
recommendation of the Committee constituted to take steps further to the said legislation, the
Hon’ble Chief Justice of the Delhi High Court has approved the creation of the Intellectual Property
Division (“IPD”) in the Delhi High Court to deal with matters relating to Intellectual Property Rights
(“IPR”) except cases to be dealt with by the Division Bench of the Delhi High Court.Whereas, the
Delhi High Court office order No. 667/Original Side/DHC dated 7th July, 2021 records the decision
of the Hon’ble Chief Justice to create the IPD.In exercise of the powers conferred by Section 7 of the
Delhi High Court Act, 1966, Section 129 of the Code of Civil Procedure, 1908, powers conferred
under the various Intellectual Property statutes as amended by the TRA 2021, the Delhi High Court
hereby makes the following Rules for the matters listed before it’s IPD with respect to practice and
procedure for the exercise of its original and appellate jurisdiction, and for other miscellaneous
petitions arising out of IPR and related statutes.The substantive provisions governing Intellectual
Property matters are contained in The Trade Marks Act, 1999; The Copyright Act, 1957; The Patents
Act, 1970; The Designs Act, 2000; The Geographical Indications of Goods (Registration and
Protection) Act, 1999; The Protection of Plant Varieties and Farmers’ Rights Act, 2001; The
Semiconductor Integrated Circuits Layout-Design Act, 2000; Information Technology Act, 2000 as
also in common law.
1. Short title and commencement
(i)These Rules shall be called ‘The Delhi High Court Intellectual Property Rights Division Rules,
2022. (DHC- IPD Rules, 2022);(ii)The Rules shall come into force on such date as the Chief Justice
of the Delhi High Court may notify inthe Official Gazette.Delhi High Court Intellectual Property Rights Division Rules, 2022

2. Definitions-In these Rules, unless the context otherwise requires
(a)“Act” (s)means the statutes mentioned below, as applicable:(i)The Copyright Act, 1957;(ii)The
Designs Act, 2000;(iii)The Geographical Indications of Goods (Registration and Protection) Act,
1999;(iv)The Information Technology Act, 2000;(v)The Patents Act, 1970;(vi)The Protection of
Plant Varieties and Farmers' Rights Act, 2001;(vii)The Semiconductor Integrated Circuits
Layout-Design Act 2000;(viii)The Trade Marks Act, 1999;(b)“Address for service” means the
address furnished by an applicant, appellant, complainant, petitioner, respondent including the
currently authorized trade mark agent, patent agent or other agent before the IPO as also the legal
practitioner, at which service of summons, notices or other processes may be effected;(c)“Agent”
includes a trade mark or patent agent as defined under Section 145, Trade Marks Act, 1999 and
Section 125,The Patents Act, 1970 duly authorized by the party concerned and who is entitled to
appear before the IPD along with a legal practitioner in order to assist the IPD;(d)“Appeal” includes
an appeal filed before, or transferred to, the IPD under the following sections of the respective Acts
with the following nomenclature:(i)Under Section 91 of The Trade Marks Act, 1999[C.A. (Comm.
IPD-TM)];(ii)Under Section 72 of The Copyright Act, 1957 [C.A. (Comm. IPD-CR)];(iii)Under
Section 117A of The Patents Act, 1970[C.A.(Comm. IPD-PAT)];(iv)Under Section 31of The
Geographical Indications of Goods (Registration and Protection) Act, 1999. [C.A.(Comm.
IPD-GI)];(v)Under Section 56 of The Protection of Plant Varieties and Farmers' Rights Act,
2001[C.A.(Comm. IPD-PV)];(vi)Under Section 42 of the Semiconductor Integrated Circuits
Layout-Design Act, 2000 [C.A.(Comm. IPD-SCD)];(vii)Under Sections 36 of the Designs Act, 2000
[C.A. (Comm. IPD-DE)];(viii)Under Section 62 of the Information Technology Act, 2000 [C.A.
(Comm. IPD-IT)](e)“Appellant” means a person before the IPD in appeal as defined in Rule 2(d)
and other appeals such as RFA and FAO;(f)“Evidence” shall be evidence filed before the IPD
including affidavits in evidence filed by the parties and experts along with documents and oral
evidence, if recorded;(g)“Fee” shall mean the fees prescribed in the Schedule II to these
Rules;(h)“Form” shall mean the form(s) prescribed in the Schedule I to these Rules;(i)“Intellectual
Property Rights (IPR) subject matter” for the purpose of these Rules, shall include:(i)Matters
pertaining to Patents, Copyrights, Trade Marks, Geographical Indications, Plant Varieties, Designs,
Semiconductor integrated circuit layout-designs, Traditional Knowledge and all rights under
common law, if any, associated therewith;(ii)Matters relating to passing off, acts of unfair
competition, disparagement, comparative advertising etc.;(iii)Protection of trade secrets,
confidential information and related subject matters;(iv)Tortious actions related to privacy and
publicity rights involving intellectual property issues;(v)Matters pertaining data exclusivity, domain
names and other matters relating to data protection involving intellectual property issues, as also
those arising under the Act(s) as defined in Rule 2(a) ;(vi)Matters involving internet violations
relating to any of the subject matters under clauses (i) through (v) above.Explanation:(i)for the
purpose of these Rules, cases pertaining to the Information Technology Act, 2000dealing with the
rights and liabilities of intermediaries, online market places, and e-commerce platforms involving
issues relating to any of the aforementioned subject matters, shall be deemed to be within the
purview of intellectual property rights;(ii)intermediaries, online market places, and e-commerce
platforms shall be interpreted in terms of the definition contained in Section 2(w) of the
Information Technology Act, 2000.(j)“Intellectual Property Rights Division (IPD)”refers to the
division in the Delhi High Court presided over by Single Judges to deal with disputes and casesDelhi High Court Intellectual Property Rights Division Rules, 2022

concerning IPR subject matter;(k)“Intellectual Property Office (IPO)” shall mean –(i)in case of
Trade Marks – Office of `Registrar of Trade Marks’;(ii)in case of Copyrights – Office of `Registrar of
Copyrights’;(iii)in case of Patents– Office of `Controller General of Patents, Designs and Trade
Marks’;(iv)in case of Geographical Indications–Office of `Registrar of Geographical
Indications’;(v)in case of Plant Varieties – ‘Protection of Plant Varieties and Farmers’ Rights
Authority’ or the ‘Plant Varieties Registry’, as applicable;(vi)in case of Semiconductor Integrated
Circuits Layout-Designs – Office of the `Registrar of the Semiconductor Integrated Circuits
Layout-Design’;(vii)in case of Designs – Office of ‘Controller General of Patents, Designs and Trade
Marks’.(l)“IPR subject matters or cases or proceedings or disputes” shall include all original
proceedings, appellate and other proceedings related to IPR subject matter(s)as defined in Rule 2(i)
above filed before the IPD and shall also include:(i)Revocation applications, cancellation
applications, other original proceedings, appeals and petitions from the various IPOs and all other
proceedings which were hitherto maintainable before the Intellectual Property Appellate Board
(“IPAB”) under provisions of the Act(s);(ii)All suits filed in which IPR subject matter is involved,
either under the respective statutes or under common law including suits relating to breach of
privacy and rights of publicity;(iii)Writ Petitions (Civil)[WP(C)],Civil Misc.
(Mains)[CM(Main)],Regular First Appeal[RFA], First Appeal from Order[FAO], Civil Revision
Petition[CRP] arising out of IPR subject matter(s) and disputes dealt with by the Commercial Courts
in Delhi, except matters that are to be dealt with by a Division Bench;(iv)All pending proceedings
before the IPAB relating to Delhi jurisdiction transferred to the Delhi High Court.(m)“legal
practitioner” shall have the same meaning as is assigned to it in the Advocates Act, 1961;(n)“Patent
Suit Rules, 2022” shall mean the High Court of Delhi Rules Governing Patent Suits,
2022;(o)“Petition” includes a Civil Original Petition, Writ Petition (Civil),Civil Misc. (Main), Civil
Revision Petition, and Appeals:(i)A Civil Original Petition means a petition under any of the
Act(s)filed before the IPD as an original proceeding;(ii)Writ Petition (Civil) means a
petition/application under Article 226 of the Constitution of India inter alia for issuance of a writ in
the nature of mandamus, certiorari, prohibition, and quo warranto;(iii)Civil Miscellaneous(Main)
means a petition under Article 227 of the Constitution of India;(iv)Civil Revision Petition means a
Petition under Section 115 of the Code of Civil Procedure, 1908.; and(v)Appeals as defined in Rule
2(d) and other appeals such as RFA and FAO filed before the IPD as an appellate
proceeding;(p)“Pleadings” shall include plaints, written statements, replications, applications,
appeals, complaints, counter affidavits, counterstatements, petitions, reviews, replies, rejoinders,
rejoinder affidavit filed before the IPD.
3. Applicability
These Rules shall govern and apply to all IPR subject matter(s) or cases or proceedings or disputes
before the IPD of the Delhi High Court.
4. Jurisdiction Every IPR subject matter or case or proceeding or dispute
filed before, or transferred to, the IPD, as defined in Rules 2(i), 2(j) and 2(l),
shall be heard and adjudicated by a Single Judge of the IPD except those that
are to be decided by a Division Bench as per Section 13 of the CommercialDelhi High Court Intellectual Property Rights Division Rules, 2022

Courts Act, 2015.
5. Filing and Nomenclature to be adopted for filing
The filing of IPR subject matter(s) or cases or proceedings or disputes before the IPD shall be under
the following categories with the nomenclature given below:(i)AppealsNomenclature:(a)Civil Appeal
(Comm. IPD-TM) under Trade Marks Act, 1999;(b)Civil Appeal (Comm. IPD-CR) under Copyright
Act, 1957;(c)Civil Appeal(Comm. IPD-PAT) under Patents Act, 1970;(d)Civil Appeal (Comm.
IPD-GI) under Geographical Indications of Goods (registration andProtection) Act, 1999;(e)Civil
Appeal (Comm. IPD-PV) under Protection of Plant Varieties and Farmers Right Act,
2001.
;(f)Civil Appeal (Comm. IPD-SCD) under The Semiconductor Integrated Circuits Layout-DesignAct,
2000;(g)Civil Appeal (Comm. IPD-DE) under Designs Act, 2000;(h)Civil Appeal (Comm. IPD-IT)
under Information Technology Act, 2000;(ii)Civil Original PetitionsNomenclature:(a)Civil Original
(Comm. IPD-TM)under Trade Marks Act, 1999;(b)Civil Original(Comm. IPD-CR)under Copyright
Act, 1957;(c)Civil Original(Comm.IPD-PAT)under Patents Act, 1970;(d)Civil Original (Comm.
IPD-GI)under Geographical Indications of Goods (registration andProtection) Act, 1999;(e)Civil
Original(Comm. IPD-PV)under Protection of Plant Varieties and Farmers Right Act,
2001.
;(f)Civil Original(Comm. IPD-SCD)under The Semiconductor Integrated Circuits Layout-DesignAct,
2000;(g)Civil Original(Comm. IPD-IT)under Section 46 of the Information Technology Act,
2000,where the claim exceeds INR 5 crores;(iii)Writ Petitions (Civil)Nomenclature:Writ Petition
(C)-IPD(iv)Civil Miscellaneous MainNomenclature: Civil Misc. (Main)-IPD(v)Regular First Appeal
(RFA)Nomenclature:RFA-IPD(vi)First Appeal from Order
(FAO)Nomenclature:FAO-IPD(vii)Execution First Appeal (EFA)Nomenclature:EFA-IPD(viii)Civil
Revision Petition (CRP)Nomenclature: CRP-IPD
6. Procedure for Appeals
(i)Appeals under Rule 2(d) of the present rules before the IPD shall be filed in the
formats/formsprescribed in Schedule I, within the period of limitation as prescribed in the
respective Act(s) alongwith the requisite Court fees as prescribed in Schedule II.(ii)Appeals shall
consist of the memorandum of parties, synopsis, list of dates, a brief memorandum ofappeal,
grounds of challenge in the appeal, the order impugned and affidavit of Appellant filing theAppeal
along with other details as required in the Form applicable. The Appellant shall disclose thedetails of
any prior litigation pending between the parties with respect to the subject matter in dispute.(iii)All
relevant forms, correspondence and other relevant documents forming part of the record of theIPO
shall ordinarily accompany the appeal.(iv)Documents that are not part of the record of the IPO shall
generally not be accepted by the IPD exceptwith the leave of the Court.(v)Memorandum of appealDelhi High Court Intellectual Property Rights Division Rules, 2022

shall specify as to whether the documents being filed are part of the record ofthe IPO and if any
additional documents are being filed, the details and relevance thereof shall bespecified. Such
documents shall be accompanied with an application seeking leave of the Court, inwhich case
principles akin to Order XLI Rule 27 of the Code of Civil Procedure, 1908 would apply.(vi)No
evidence shall be recorded in Appeals unless the Court deems it necessary. However, the IPD
maydirect the appearance of any witness, who has deposed before the IPO for the purpose of seeking
anyclarification.(vii)In all Appeals, all the contesting parties before the IPO shall be impleaded as
Respondents. Therespective IPO shall also be impleaded as a Respondent.(viii)Filing of a reply, in
an appeal, would be only upon specific directions of the Court, if the need arises.The opposite party
shall, however, during the course of hearing or otherwise, be entitled to producecopies of any
relevant record intended to be relied upon.(ix)Reply, if so directed, shall be filed within the period
prescribed by the Court or within 60 days fromthe date on which the Court directs the filing of such
Reply.(x)Rejoinder to the reply, if so directed, shall be filed within the period prescribed by the
Court or within
30. days from the date on which the Court directs the filing of such
Rejoinder.
(xi)Filing of any further affidavits or pleadings shall be strictly with the leave of the
Court.(xii)Procedures applicable to Civil Appeals filed before the Single Judge: The Delhi High
Court Rules andOrders, as also the practice directions, issued from time to time, to the extent there
is no inconsistencywith these Rules, shall be applicable to appeals filed before the IPD.
7. Procedure for Original Petitions (Civil Original Petition)
(i)Original petition shall consist of memorandum of parties, synopsis, list of dates and all other
detailsspecified in the respective forms and shall be accompanied by the affidavit of the
Petitioner/partyfiling the petition.(ii)The parties shall also file all other relevant documents in
support of the relief sought in the originalpetition. If interim orders are sought by the Petitioner, an
application under Order XXXIX Rule 1 andRule 2, Code of Civil Procedure, 1908 shall be filed
setting out the grounds for such interim order.Averments shall be made in the original petition
specifying as to which of the documents filed form
Part of – the record of the IPO.
(iii)Original petitions filed before the IPD under the respective statutes shall be filed in the
formats/formsprescribed in Schedule I of the present Rules [within the period of limitation, if any,
as prescribed inthe respective Act(s)] along with the requisite Court fees prescribed in Schedule
II.(iv)Original petitions shall be accompanied with all the relevant records from the respective
IPOincluding the relevant correspondence.(v)In case of an original petition relating to patents, the
complete specification of the patent along withdifferent versions/claims, if relevant, as also the
relevant forms filed before the IPO, shall also befiled.(vi)Documents shall be read as part of the
record, unless challenged by any party. Such challenge shall beraised at the very first instance i.e. inDelhi High Court Intellectual Property Rights Division Rules, 2022

the Reply or Rejoinder along with an affidavit ofadmission/denial. The admission/denial of the said
document(s) shall be conducted as per the DelhiHigh Court (Original Side) Rules, 2018. Denial of
documents which is evasive or without just reasonor cause, would be liable to be penalized with
costs.(vii)Framing of issues shall not be compulsory in the original petitions. In
revocation/cancellationpetitions, the Court may frame issues if deemed necessary. Upon completion
of pleadings, the Courtmay proceed to hear the petition finally.(viii)Filing of evidence may be
directed by the Court, only if the same is deemed necessary. The evidenceshall usually be in the form
of affidavits. Oral evidence including cross-examination may be directedfor reasons to be recorded
in the order of the Court. If oral evidence is directed, the procedure forrecording of evidence and
other related procedures shall be governed by these Rules as well as theDelhi High Court (Original
Side) Rules, 2018. In revocation/cancellation petitions, upon framing ofissues, the court may direct
filing of evidence by way of affidavit.(ix)Reply, if so directed, shall be filed within the period
prescribed by the Court or shall be filed within 60days from the date on which the Court directs the
filing of such Reply.(x)Rejoinder to the reply, if so directed, shall be filed within the period
prescribed by the Court or within
30. days from the date on which the Court directs the filing of such
Rejoinder.
(xi)Filing of any further affidavits or pleadings shall be strictly with the leave of the Court.(xii)In
case of petitions seeking revocation/cancellation, the Court may direct consolidation of the
saidpetition with a suit for infringement involving the same IPR subject matter.(xiii)Procedures
applicable to original petitions: The provisions of the Commercial Courts Act, 2015, DelhiHigh
Court (Original Side) Rules, 2018 and orders as also the practice directions issued from time totime,
to the extent there is no inconsistency with these Rules, shall be applicable to original petitionsfiled
in the IPD.
8. Procedure for Writ Petitions (Civil)
(i)Writ Petitions filed before the IPD, challenging any orders passed by the IPO/authority, shall
consistof a synopsis and list of dates and events, memo of parties, memorandum of the writ petition
includinggrounds of challenge, prayer/relief sought, affidavit in support. The Petitioner shall also
state both inthe application and in the affidavit whether any other remedy was availed of in respect
of the sameimpugned order and if so, provide details thereof including any order passed
therein.(ii)The impugned order, where applicable, shall be annexed with the writ
petition.(iii)Procedures applicable to Writ Petitions (Civil): The Delhi High Court Rules and orders,
as also thepractice directions issued from time to time, to the extent there is no inconsistency with
these Rules,shall be applicable to writ petitions filed before the IPD.
9. Procedure for Civil Miscellaneous Main Petition
(i)The Civil Miscellaneous Main Petitions challenging orders passed by the Commercial Courts or
otherdistrict courts/civil courts, relating to IPR disputes shall be filed and listed before the IPD.Delhi High Court Intellectual Property Rights Division Rules, 2022

Theformats for the said petitions will be governed by The Delhi High Court Rules and Orders.(ii)The
Civil Miscellaneous Main Petition shall consist of the memo of parties, synopsis and list of datesand
events, memorandum of the civil miscellaneous main petition, the grounds challenging the
order,prayer/the relief sought, affidavit and the impugned order.(iii)The petitioner shall file the
relevant pleadings of the original proceedings, relevant order sheets,issues, if framed, in the case,
pleadings in the relevant interim applications and documents which thepetitioner intends to rely
upon.Provided that every endeavor shall be made to place on record pleadings/documents (other
than caselaw) referred to in the impugned order.(iv)Filing of a reply would be only upon specific
directions of the Court, if the need arises. The oppositeparty shall, however, during the course of
hearing or otherwise, be entitled to produce copies of anyrelevant record intended to be relied upon.
10. Procedure for Regular First Appeal (RFA)
(i)Regular First Appeals shall be governed by The Delhi High Court Rules and
Orders/practicedirections, and pleadings shall be filed as per the Forms/formats prescribed
therein.(ii)Appeals shall consist of the memo of parties, synopsis, list of dates and events,
memorandum ofregular first appeal, grounds of challenge to the judgment/decree appealed
from/challenge in theappeal, prayer/relief prayed for. Certified copy of the judgment/decree
impugned shall be filed withinthe period of limitation along with affidavit.(iii)The entire record
forming part of the original proceeding shall be filed with the RFA, to the extentpossible.Provided
that every endeavor shall be made to place on record pleadings/documents (other than caselaw)
referred to in the impugned order.(iv)Filing of a reply would be only upon specific directions of the
Court, if the need arises. The oppositeparty shall, however, during the course of hearing or
otherwise, be entitled to produce copies of anyrelevant record intended to be relied upon.
11. Procedure for First Appeal from Order (FAO)
(i)The First Appeal from Order shall be governed by The Delhi High Court Rules and Orders,
andpleadings shall be filed as per the Forms/formats prescribed therein.(ii)Appeals shall consist of
the memo of parties, synopsis, list of dates and events, memorandum of firstappeal from order,
grounds of challenge to the order appealed from/grounds of challenge in theappeal, prayer/relief
sought, order impugned and affidavit.(iii)The appellant shall file the relevant pleadings of the
original proceedings, relevant order sheets,issues, if framed, in the case, pleadings in the relevant
interim applications and documents which thepetitioner intends to rely upon.Provided that every
endeavor shall be made to place on record pleadings/documents (other than caselaw) referred to in
the impugned order.(iv)Filing of a reply would be only upon specific directions of the Court, if the
need arises. The oppositeparty shall, however, during the course of hearing or otherwise, be entitled
to produce copies of anyrelevant record intended to be relied upon.
12. Procedure for Civil Revision Petition (CRP)
(i)Civil Revision Petitions shall be governed by The Delhi High Court Rules and
Orders/Practicedirections. Pleadings therein shall be filed as per the Forms / formats prescribed
therein.(ii)Revision Petitions shall consist of the memo of parties, synopsis, list of dates andDelhi High Court Intellectual Property Rights Division Rules, 2022

events,memorandum of revision petition, grounds of challenge to the impugned order, prayer/relief
sought,order impugned and affidavit.(iii)The petitioner shall file the relevant pleadings of the
original proceedings, relevant order sheets, issuesif framed in the case, pleadings in the relevant
interim applications and documents which thepetitioner intends to rely upon.Provided that every
endeavor shall be made to place on record pleadings/documents (other than caselaw) referred to in
the impugned order.(iv)Filing of a reply would be only upon specific directions of the Court, if the
need arises. The oppositeparty shall, however, during the course of hearing or otherwise, be entitled
to produce copies of anyrelevant record intended to be relied upon.
13. Additional Provisions for CM (Mains), RFAs, FAOs, and CRPs
(i)It shall be sufficient if copies of the documents mentioned in Rule 9, Rule 10, Rule 11 and Rule
12above are filed with self-certification of the counsel for the petitioner/appellant to the effect that
eachsuch document is the true copy of its respective original in the file of the Trial
Court.(ii)Ordinarily, the Court may decide these Petitions and Appeals on the basis of the grounds
raised in thepetition/memorandum of appeal and the record filed with the same.
14. Procedure for Suits
(i)Suits before the IPD shall be governed by the provisions of The Commercial Courts Act, 2015,
Codeof Civil Procedure, 1908 as applicable to commercial suits and the Delhi High Court (Original
Side)Rules, 2018.(ii)In addition to these Rules, Patent suits and actions shall be governed by the
Patent Suit Rules, 2022.
15. Recording of Evidence
If, in the opinion of the Court, it is expedient to do so, the Court may direct:(i)The recording of
evidence through video conference as per the High Court of Delhi Rules for VideoConferencing for
Courts 2021;(ii)The recording of evidence at any venue outside the premises of the Court;(iii)The
recording of evidence by a Local Commissioner;(iv)The use of videography and transcription
technology or any other form of recording evidence.
16. Hot-tubbing or other modes of recording evidence
In the case of evidence by experts, the same may be recorded by resorting to procedures such as
Hot-tubbing,as provided for in Rule 6, Chapter XI, Delhi High Court (Original Side) Rules, 2018, or
other such modes, asthe Court deems fit.
17. Discovery and Disclosure
(i)The procedure relating to the disclosure and discovery of documents (including by way
ofinterrogatories) shall be governed by the Code of Civil Procedure, 1908 as amended by
theCommercial Courts Act, 2015;(ii)Parties withholding discovery, or attempting to scuttle theDelhi High Court Intellectual Property Rights Division Rules, 2022

process of discovery, would be liable to bepenalized with costs as determined by the Court.
18. Preservation of Evidence by parties
(i)Upon initiating, or receiving notice about the institution of, proceedings before the IPD, the
parties tothe proceedings shall preserve all documentary, tangible and electronic material relating to
the subjectmatter of the proceedings which is capable of being relied upon as evidence;(ii)Prior to
the initiation of proceedings, a party may issue a Litigation Hold Notice (LHN) to such
otherparty(ies) against whom proceedings are sought to be initiated. The recipient of such LHN
shall, uponbeing duly served, be bound to preserve all documentary, tangible and electronic
material relating tothe subject matter of the proceedings which is capable of being relied upon as
evidenceProvided that, the party issuing the LHN is expected to commence litigation within a
reasonable time,not exceeding one year from the date of the LHN, beyond which such obligation to
preserve evidencewould cease to apply.(iii)Such material shall be preserved from the date on which
the obligation to preserve such material aroseunder clause (i) or (ii) above, and in a manner so as to
ensure that the same is not editable or cannot betampered with;(iv)Such material shall be preserved
for the duration of the litigation, including appellate proceedings, ifany. In the event no appeal has
been filed, the parties shall be at liberty to freely deal with suchmaterial only upon the completion of
six (6) months from the date of closure of the originalproceedings;(v)In addition to remedies under
civil and criminal law, failure to comply with this Rule would be liableto be penalized with costs as
determined by the Court.Explanation:For the purpose of Rule 18, documentary, tangible and
electronic material to be preserved shallinclude documents in tangible or electronic form including
letters, memos, internal and externalcorrespondence, graphic representations of any kind, images,
sounds, and data stored in any mediumrelating to the subject matter of the proceedings.
19. Confidentiality clubs and redaction of confidential information
(i)At any stage in a proceeding, the Court may constitute a confidentiality club or adopt such
measuresas appropriate, consisting of lawyers (external & in-house), experts as also nominated
representativesof the parties, for the preservation and exchange of confidential information filed
before the Courtincluding documents, as per the Delhi High Court (Original Side) Rules, 2018.Such
nominated representatives of the parties, appointed to the Club, may inter alia, be persons whoare
not in charge of, or active in, the day-to-day business operations and management of the
respectiveparties so as to maintain the integrity of the information so disclosed.The members so
constituting the Club shall be bound to desist from disclosing, sharing or utilizing,including to third
parties, the confidential or sensitive information that they may access, or becomeprivy to, in the
course of proceedings;(ii)The Court may, upon a request made by way of an application, direct the
redaction of suchinformation (including documents) it deems to be confidential;(iii)If any redacted
pleading/document is sought to be filed as being confidential, a non-redacted versionof the same
may be filed in a sealed cover along with an application supporting such claim forredaction.Delhi High Court Intellectual Property Rights Division Rules, 2022

20. Damages/Account of profits
A party seeking damages/account of profits, shall give a reasonable estimate of the amounts claimed
and thefoundational facts/account statements in respect thereof along with any evidence,
documentary and/or oral ledby the parties to support such a claim. In addition, the Court shall
consider the following factors whiledetermining the quantum of damages:(i)Lost profits suffered by
the injured party;(ii)Profits earned by the infringing party;(iii)Quantum of income which the injured
party may have earned through royalties/license fees, had theuse of the subject IPR been duly
authorized;(iv)The duration of the infringement;(v)Degree of intention/neglect underlying the
infringement;(vi)Conduct of the infringing party to mitigate the damages being incurred by the
injured party;In the computation of damages, the Court may take the assistance of an expert as
provided for under Rule 31 ofthese Rules.
21. Pleadings to be accompanied by affidavit of authorized representative
and relevant documents
All pleadings shall be accompanied by the affidavit of the authorized representative/parties
concerned anddocuments establishing the authorization such as Board Resolution and Power of
Attorney.
22. Advance Copy
In all matters filed before the IPD, advance copy shall be served at the address for service, as also
throughemail, at least two working days in advance, upon the Respondents including the
counsels/agents, who mayhave represented the Respondents before the IPO, or trial court, or
authority, as the case may be. Along withthe advance copy so provided, the likely date of listing shall
be intimated. Upon advance copy being served,parties/counsels/agents/authority shall be
represented on the first date of hearing before the Court. For the sakeof expeditious disposal, if in
the opinion of the Court no further notice is required, and if satisfactory proof ofservice is furnished,
no further notice would ordinarily be issued and the matter may be heard and disposed ofon the
first day of listing.Provided that, in the facts and circumstances of a given case, and on an
application, the Court may dispensewith advance service.
23. Nomination of Counsel by the IPO
The respective IPOs may nominate their counsel in order to appear before the IPD as also for
production ofrecords, if called for.
24. Process Fee
There shall be a one-time process fee as prescribed in The Delhi High Court (Original Side) Rules,
2018 withnecessary modifications to include Appellant and Petitioner as Plaintiff and Respondent
as the Defendant.Delhi High Court Intellectual Property Rights Division Rules, 2022

25. Intervention by third parties
In the matters listed before the IPD, intervention by the third parties may be permitted suo moto or
on anapplication by any person unless prohibited by law. Such person shall seek to intervene by
means of anapplication stating the nature of interest before the Court. The Court may refuse or
grant leave after hearing allconcerned parties, if so required, and on such terms and conditions as it
deems fit.
26. Consolidation of IPR subject matters or cases or proceedings or disputes
Where there are multiple proceedings relating to the same or related IPR subject matter,
irrespective of whetherthe said proceedings are between the same parties or not, the Court shall
have the power and the discretion,wherever appropriate, to direct consolidation of proceedings,
hearings, and also to direct consolidatedrecording of evidence/common trial and consolidated
adjudication. If the Court is of the opinion that anymatter pending before a Commercial Court is to
be consolidated with a matter pending before the IPD, it mayexercise powers of transfer under
Section 24, Code of Civil Procedure, 1908 for transfer and consolidation ofsuch matter to itself.
27. Summary Adjudication
In cases before the IPD, the Court may pass summary judgment, without the requirement of filing a
specificapplication seeking summary judgment on principles akin to those contained in Order
XIIIA, Code of CivilProcedure, 1908 as applicable to commercial suits under the Commercial Courts
Act, 2015.
28. Application of Statutes
The IPD, as may be applicable to the cases listed before it, apply the provisions of:(i)The
Commercial Courts Act, 2015 for suits and counter claims in matters relating to IPR
subjectmatter(s); and(ii)Patent Suit Rules, 2022 for Patent related disputes and actions.
29. General Clause
Procedures not specifically provided for in these Rules shall, in general, wherever applicable, be
governed byThe Civil Procedure Code, 1908,as applicable to commercial disputes, The Commercial
Courts Act, 2015,Indian Evidence Act, 1872 and the Delhi High Court (Original Side) Rules, 2018.
30. Power to remove difficulties
If any difficulty arises in giving effect to the provisions of these Rules, the Court may, by order, make
suchprovision not inconsistent with these Rules as may appear to be necessary or expedient for
removing suchdifficulty.Delhi High Court Intellectual Property Rights Division Rules, 2022

31. Panel of Experts
The Court may, in any IPR subject matter, seek assistance of expert(s) (including individuals and
institutions)relating to the subject matter of the dispute as may be necessary. The opinion of the
expert shall be persuasivein nature and shall not be binding on the Court. The IPD may maintain a
panel of experts to assist the Courtand which panel may be reviewed from time to time. The
remuneration of the expert(s) shall be decided by theIPD. Prior to appointment, a declaration will
be provided by the expert that he or she has no conflict of interestwith the subject matter of the
dispute and will assist the Court fairly and impartially.Provided that the protocol to be followed by
such expert(s) shall be prescribed by the IPD, from time to time.
32. Law Researcher(s)
(i)Judges of the IPD shall have the assistance of additional Law Researchers who shall possess
technicalqualifications. Such Law Researcher(s) shall be part of a common pool of Law Researchers
for theIPD. The number of law researchers would be at least two in number for each Bench of the
IPD. Thesaid Law Researchers would be attached to the IPD and not with the individual Judge
concerned;(ii)Such Law Researcher(s) may possess a degree in any technical field or specialization
in any IPRsubject matter or have experience in the field of intellectual property;(iii)The
appointment of such Law Researcher(s) shall be by a Committee designated by the Chief
Justice;(iv)Law Researcher(s) shall be appointed on the same terms as applicable to other Law
Researchersappointed in the Delhi High Court. The remuneration of such Law Researcher(s) shall
usually be theprevailing remuneration for law researchers of the Delhi High Court. However, in
exceptional cases,higher remuneration may also be approved by the Chief Justice;(v)Law
Researcher(s) with such qualifications may also be appointed to assist Division Benches dealingwith
cases involving IPR subject matter(s);(vi)Such Law Researcher(s) shall be in addition to the law
researchers appointed for assistance of Judgesunder the Delhi High Court Rules;(vii)Prior to
appointment, a declaration shall be provided by the Law Researcher(s) that he or she has noconflict
of interest with the subject matter of the dispute and will assist the court fairly and impartially.
33. Strict guidelines for written submissions and timelines for oral
submissions
The Court may direct the filing of written submissions in advance, prior to the date fixed for oral
arguments.The Court may also fix specific timeslots and restricted time limits for oral arguments, as
deemed appropriate.
34. Patents/Trade Mark Agents
Before the IPD, Agents who are registered as Patent agents or Trade Mark agents, as also
anyprofessional/academician having knowledge of the said subject matter of the dispute shall have a
right ofaudience, when permitted by the Court, to appear along with the counsels/legal practitioners
representing theparties to assist the Court.Delhi High Court Intellectual Property Rights Division Rules, 2022

35. Costs
In cases before the IPD, actual costs may be awarded by the Court as already provided for in the
Delhi HighCourt (Original Side) Rules, 2018.
36. Accessibility and Reasonable Accommodations
(i)All filings before the IPD shall be in a Portable Document Format with Optical Character
Recognition(OCR)enabled with image resolution of at least 300 dots per inch (dpi);(ii)The Court,
suo motu or upon a request made by way of application, may issue such direction(s) that itdeems
necessary for providing reasonable accommodation to such person(s) with a specified disabilityas
recognized under the Rights of Persons with Disabilities Act, 2016 for the sole purpose
ofparticipating in the proceedings before the IPD.
37. Mediation and Early Neutral Evaluation (ENE)
(i)At any stage, in any proceeding, if the Court is of the opinion that the parties ought to
exploremediation, the Court may appoint a qualified mediator or panel of mediators including
mediators withtraining or experience in IPR subject matter(s). Consent of the parties is not required
once the Court isof the opinion that an amicable resolution needs to be explored;(ii)Such mediation
will be conducted under the aegis of the Delhi High Court Mediation and ConciliationCentre and,
where necessary, in collaboration with the relevant IPO;(iii)At any stage the court may also direct
ENE by appointing a qualified and independent evaluator if it isof the opinion that such ENE would
assist in early resolution;(iv)Mediation/ENE proceedings may proceed concurrently with the legal
proceedings before the Court soas not to delay adjudication.
38. Appeals from orders of the IPD
Appeals, if maintainable, shall lie against orders of the IPD to the Division Bench either:(i)In the
form of a Letters Patent Appeal (LPA); or(ii)In the form of appeals to the Commercial Appellate
Division under Section 13, Commercial CourtsAct, 2015.
39. Condonation of delay
In case of delay in filing of petitions, appeals or any other proceeding beyond the relevant limitation
period, ifany, the Court shall have the power to condone delay on principles akin to Section 5 of the
Limitation Act,
1963. provided that an application demonstrating sufficient cause to explain
such delay is filed.Delhi High Court Intellectual Property Rights Division Rules, 2022

40. Cases transferred from the IPAB
All cases under various categories received in the Delhi High Court from the IPAB shall be registered
andlisted before the IPD, and given the nomenclature as provided for in these Rules. The IPD shall
broadly followthese Rules for the adjudication and disposal of the said cases, to such extent as
possible.
I
FORM-I
[Form under Section 47/57/125 of the Trade Marks Act, 1999](COURT FEES:_______IN THE
HIGH COURT OF DELHI AT NEW DELHI(Intellectual Property Division – Original Civil
Jurisdiction)C.O. (Comm.-IPD/TM)___ of ________(Full Name, address, e-mail and mobile
number ofthe petitioner(s)/applicant(s). In case of foreignpetitioner(s)/applicant(s), address for
service in Indiato be furnished)...Petitioner(s)/Applicant(s)Versus(Full Name(s), address, e-mail
and mobile number ofthe Respondent(s). In case of foreign Respondent(s),...Respondent(s)address
for service in India to be furnished)PETITION/APPLICATION UNDER SECTION47/ 57/ 125 OF
THE TRADE MARKS ACT, 1999 FOR_______________________________(score out the
provision not applicable)The Petitioner(s)/ Applicant(s) above named respectfully submits as
under:
1. Full Name of the Advocate :
2. Address, e-mail and mobile number of the Advocate :
3. Name and address of the Trade Marks Agent, if any :
4. Trade mark sought to be cancelled/varied/rectified –
(i)Registration no.(ii)Word mark/Device mark(The mark as appearing in the Registration
Certificate beaffixed)(iii)Date of filing of Application(iv)Date of advertisement in the Trade Marks
Journal anddetails thereof(v)Details of Opposition(s) filed if any(vi)Date of grant of
registration(vii)Renewal details:
5. Relief prayed and relevant section(s) :
6. Proprietor of the registered trade mark :Delhi High Court Intellectual Property Rights Division Rules, 2022

7. Details of predecessor-in-interest of the trade mark, if any :
8. Current status of the trade mark (print out from the website of the
Registry of Trade Marks to be attached):
9. Date of user claimed in the application for trade mark. :
10. Disclaimer/other conditions, if any :
11. Interest of the petitioner, in brief :
12. Grounds for seeking relief :
13. Details of any other proceedings pending with respect to the same
trade mark within the knowledge of the petitioner/Applicantincluding the forum:
14. Prayer :
[Name & Signature of the Advocatefor the Petitioner(s)/Applicant(s)]
15. Verification :
(Signature of the Petitioner(s)/Applicant(s)
16. Affidavit in support :
List of Documents
1. Copy of registration certificate/legal proceeding certificate obtained by the
respondent in respect of the impugned
mark. If the same is not available, copy of the certificate, along with the trademark journal and any
documentsshowing conditions which may have been imposed on the registration, be filed.
2. Current status of the trade mark printed from the website of the Trade
Marks Registry.Delhi High Court Intellectual Property Rights Division Rules, 2022

3. Any other relevant document(s)
NOTE:
1. All the pleadings shall be accompanied by the affidavit of the authorised
representative of the party
concerned.
2. Documents establishing authorization such as Power-of-Attorney, Board
Resolution etc. shall accompany the
petition.FORM-II[Form under Section 91 of the Trade Marks Act, 1999 and under Rule 156 of the
Trade Marks Rules, 2017][COURT FEES:_______]IN THE HIGH COURT OF DELHI AT NEW
DELHI(Intellectual Property Division – Appellate jurisdiction)C.A. (Comm-IPD/TM)___ of
________(Full Name, address, e-mail and mobile number ofthe Appellant(s). In case of foreign
Appellant(s),address for service in India to be furnished)...Appellant(s)Versus(Full Name, address,
e-mail and mobile number ofthe Respondent(s). In case of foreignrespondent(s)address for service
in India to befurnished)...Respondent(s)APPEAL UNDER SECTION 91 OF THE TRADE MARKS
ACT, 1999AND UNDER RULE 156 OF THETRADE MARKS RULES, 2017 CHALLENGING THE
ORDER DATED ________ PASSED BY_____________________________The appellant(s)
above named respectfully submits as under
1. Full Name of the Advocate :
2. Address, e-mail and mobile number of the Advocate :
3. Name and address of the Trade Mark Agent, if any :
4. Date of the impugned order appealed against :
5. Authority which passed the impugned order :
6. Provision under which the impugned order passed :
7. Period of limitation :
8. Delay, if any, in filing the appeal and reasons thereof :Delhi High Court Intellectual Property Rights Division Rules, 2022

9. Grounds of appeal :
10. Details of any other proceedings pending in respect of the same
trade mark within the knowledge of the Appellant:
11. Prayer :
(Name & Signature of theAdvocate/Appellant(s))
12. Verification :
[Signature of the Appellant(s)]
13. Affidavit in support. :
List of Documents
1. Copy of the impugned order passed by the IPO
2.
Any other relevant documents forming part of the record of the IPO.NOTE:
1. All the pleadings shall be accompanied by the affidavit of the authorised
representative of the party concerned.
2. Documents establishing authorization such as Power-of-Attorney, Board
Resolution etc. shall accompany the
appeal.FORM-III[Form under Section 19A of the Copyright Act 1957](COURT FEES:_______IN
THE HIGH COURT OF DELHI AT NEW DELHI(Intellectual Property Division – Original Civil
Jurisdiction)C.O. (Comm.-IPD/CR)___ of ________(Full Name, address, e-mail and mobile
number ofthe Complainant (s). In case of foreign Complainant(s), address for service in India to be
furnished)...Petitioner(s)/Complainant(s)Versus(Full Name(s), address, e-mail and mobile number
ofthe Respondent(s). In case of foreign Respondent(s),address for service in India to be
furnished)...Respondent(s)PETITION/COMPLAINT UNDER SECTION 19A OF THECOPYRIGHT
ACT, 1957The Petitioner(s)/complainant(s) above named respectfully submits as under:Delhi High Court Intellectual Property Rights Division Rules, 2022

1. Full Name of the Advocate :
2. Address, e-mail and mobile number of the Advocate :
3. Name, address, e-mail, mobile number and nationality of the
owner/Author/assignor:
4. Description of the work (Literary, Dramatic Musical, Artistic,
Cinematograph Film, Sound Recording) includingi. Title of the workii. Name, address and
nationality of the publisheriii. Year of first and last publicationiv. Country of first and last
publication:
5. If the copyright in the work is registered, details of
registration be provided:
6. Date of Assignment (copy of assignment deed be attached) :
7. Grounds for revocation of assignment or Nature of dispute
relating to the assignment:
8. Details of any other proceedings pending with respect to the
same work within the knowledge of the complainant(s):
9. Royalty payable, if any and justification thereof :
10. Prayer :
[Name & Signature of the Advocate forthe Petitioner(s)/Complainant(s)]
11. Verification :
(Signature of thePetitioner(s)/Complainant (s)
12. Affidavit in support :
List of DocumentsDelhi High Court Intellectual Property Rights Division Rules, 2022

1. Copy of assignment deed be attached
2. Any other relevant documents
NOTE:
1. All the pleadings shall be accompanied by the affidavit of the authorised
representative of the party concerned.
2. Documents establishing authorization such as Power-of-Attorney, Board
Resolution etc. shall accompany the
petition.FORM-IV[Form under Sections 31/31A/31B/31C/31D/32/32A/33Aof the Copyright Act
1957](COURT FEES:_______IN THE HIGH COURT OF DELHI AT NEW DELHI(Intellectual
Property Division – Original Civil Jurisdiction)C.O. (Comm.-IPD/CR)___ of ________(Full
Name, address, e-mail and mobile number ofthe Petitioner(s)/Complainant(s)/Applicant(s). Incase
of foreignPetitioner(s)/Complainant(s)/Applicant(s), addressfor service in India to be
furnished)...Petitioner(s)/Complainant(s)/Applicant(s)Versus(Full Name(s), address, e-mail and
mobile number ofthe Respondent(s). In case of foreign Respondent(s),address for service in India to
be furnished)...Respondent(s)PETITION/COMPLAINT/APPLICATION UNDER SECTIONS
31/31A/31B/31C/31D/32/32A/33A OFTHECOPYRIGHT ACT, 1957.(score out the provision not
applicable)The petitioner(s)/complainant(s)/ applicant(s) above named respectfully submits as
under:1. Full Name of the Advocate :2. Address, e-mail and mobile number of the Advocate :3.
Name, address, e-mail, mobile number and nationality of theowner/Author, if known. If
owner/author is dead, details of heirs,legal representatives if known to
thePetitioner(s)/Complainant(s)/Applicant(s):4. Details of copyright society, if applicable :5.
Description of the work (Literary, Dramatic Musical, Artistic,Cinematograph Film, Sound
Recording) for which licence issought/tariff is to be paidi. Title of the workii. Name, address and
nationality of the publisheriii. Whether work is published/unpublishediv. Year of first and last
publicationv. Country of first and last publication:6. If the work(s) for which licence is sought is a
Collection/Repertoire or a part thereof, then the name of the copyright owner of the entire
Collection/Repertoire:7. Details of Tariff Scheme published by the Copyright society, if applicable:8.
If the licence is applied for reproduction, publishing or re publishing/issuance of copiesi. Medium
through which copies would be issued -print/electronic/digital/onlineii. Estimated cost of the work
to be publishediii. Proposed retail price per copy of the workiv. Rate of royalty, currently being
charged by the owner, ifavailable or prevailing standards of royalty for such worksv. Rate of royalty,
last paid by the Complainant(s), ifapplicablevi. Rate of royalty, which the Complainant(s)
considersreasonable to be paid to the copyright ownervii. Means available to the Complainant (s) for
payment ofroyaltyviii. Language of proposed publication:9. If the licence is applied for performance
in publici. Number of performances of work proposed to be made under the licence applied forii.
Proposed place(s), date(s) and venue(s) of performanceiii. Estimated cost of each performanceiv.
Rate charged by the owner for comparable performances, if available or prevailing standards of
royalty for such worksv. Rate of royalty, which the applicant considers reasonable, to be paid to theDelhi High Court Intellectual Property Rights Division Rules, 2022

copyright ownervi. Means available to the Complainant(s) for payment of :royalty10. If the licence is
applied for communication to public by broadcasti. Duration of broadcast and the number of times
it is proposedto be broadcastii. The name of the channels and territorial coverage of thebroadcastiii.
Prevailing standards of royalties in regard to such worksiv. Rate of royalty, which the applicant
considers reasonable, tobe paid to the copyright ownerv. Means of the applicant for payment of the
royalty:11. Details of publication in newspaper as per Section 31A(2) :12. Nature of activities of
thePetitioner(s)/Applicant(s)/Complainant(s)undertaken for personswith disability as per Section
31B, if applicable:13. Details of prior notice given under Section 31C(2) or 31D(2), ifapplicable:14.
Whether the licence sought is in respect of a work which is not anIndian work, for the purposes of
teaching, scholarship, research,systematic instructional activities or for dissemination of theresults
of specialised, technical or scientific research to experts ina particular field under Section 327:15.
Whether the Petitioner(s)/Complainant (s)/Applicant(s) sought alicence from the owner of
copyright? If so details thereof:16. Whether copies of the work are available in India or have beenput
on sale in India?:17. Grounds for grant of Compulsory Licence/opposing TariffScheme:18. Prayer
:[Name & Signature of the Advocatefor the Petitioner(s)/Complainant(s)/Applicant(s)]19.
Verification :(Signature of the Petitioner(s)/Complainant(s)/Applicant(s)20. Affidavit in support
:List of Documents1. Copy of assignment deed, if applicable.2.All other relevant documents forming
part of the record of the IP Office.NOTE:1. All the pleadings shall be accompanied by the affidavit of
the authorised representative of the partyconcerned.2. Documents establishing authorization such
as Power-of-Attorney, Board Resolution etc. shall accompany thepetition.FORM-V[Form under
Section 31C(5)of The Copyright Act, 1957](COURT FEES:_______IN THE HIGH COURT OF
DELHI AT NEW DELHI(Intellectual Property Division – Original Civil Jurisdiction)C.O.
(Comm.-IPD/CR)___ of ________(Full Name, address, e-mail and mobile number ofthe
Petitioner(s)/Complainant(s)/Applicant(s). Incase of
foreignPetitioner(s)/Complainant(s)/Applicant(s), addressfor service in India to be
furnished)...Petitioner(s)/Complainant(s)/Applicant(s)Versus(Full Name(s), address, e-mail and
mobile number ofthe Respondent(s). In case of foreign Respondent(s),address for service in India to
be furnished)...Respondent(s)PETITION/COMPLAINT/APPLICATION UNDER SECTION 31C(5)
OF THE COPYRIGHT ACT, 1957.The petitioner(s)/complainant(s)/applicant(s) above named
respectfully submits as under:1. Full Name of the Advocate :2. Address, e-mail and mobile number
of the Advocate :3. Details of ownership of Sound Recordings for which relief isclaimed by
Petitioner(s)/Complainant(s)/Applicant(s):4. Details of the cover versions being published by the
Respondent(s) :5. Details of prior notice issued by the Respondent(s) to
theOwner(s)/Petitioner(s)/Complainant(s)/Applicant(s):6. Royalty paid, if any :7. Alterations made
by the Respondent (s), if any :8. Breach(es) by the Respondent(s) :9. Whether order of injunction
ceasing the making of further copies of the Sound Recording is sought. If so grounds thereof:10.
Amount and details of royalty claimed by thePetitioner(s)/Complainant(s)/Applicant(s):11. Prayer
:[Name & Signature of theAdvocate for the Petitioner(s)/Complainant(s)/Applicant(s)]12.
Verification :(Signature of the Petitioner(s)/Complainant(s)/Applicant(s)13. Affidavit in support
:List of Documents1. Relevant document(s).NOTE:1. All the pleadings shall be accompanied by the
affidavit of the authorised representative of the partyconcerned.2. Documents establishing
authorization such as Power-of-Attorney, Board Resolution etc. shall accompany
thepetition.FORM-VI[Form under Section 50 of the Copyright Act 1957](COURT
FEES:_______IN THE HIGH COURT OF DELHI AT NEW DELHI(Intellectual Property DivisionDelhi High Court Intellectual Property Rights Division Rules, 2022

– Original Civil Jurisdiction)C.O. (Comm.-IPD/CR)___ of ________(Full Name, address, e-mail
and mobile number ofthe Petitioner(s)/Complainant(s)/Applicant(s). Incase of
foreignPetitioner(s)/Complainant(s)/Applicant(s), addressfor service in India to be
furnished)...Petitioner(s)/Complainant(s)/Applicant(s)Versus(Full Name(s), address, e-mail and
mobile number ofthe Respondent(s). In case of foreign Respondent(s),address for service in India to
be furnished)...Respondent(s)PETITION/COMPLAINT UNDER SECTION 50 OF THECOPYRIGHT
ACT, 1957The Petitioner(s)/Complainant(s)/Applicant(s) above named respectfully submits as
under:1. Full Name of the Advocate :2. Address, e-mail and mobile number of the Advocate :3.
Name, address, e-mail, mobile number and nationality ofthe owner/Author/assignor:4. Description
of the work (Literary, Dramatic Musical,Artistic, Cinematograph Film, Sound Recording) includingi.
Title of the workii. Name, address and nationality of the publisher:iii. Year of first and last
publicationiv. Country of first and last publication:5. Details of registration :6. Grounds for
rectification :7. Details of any other proceedings pending with respect to the same work within the
knowledge of the petitioner(s):8. Prayer :[Name & Signature of the Advocate forthe
Petitioner(s)/Complainant(s)/Applicant(s)]9. Verification :(Signature of the
Petitioner(s)/Complainant(s)/Applicant(s)10. Affidavit in support :List of Documents1. Copy of
assignment deed be attached2. Any other relevant documentsNOTE:1. All the pleadings shall be
accompanied by the affidavit of the authorised representative of the partyconcerned.2. Documents
establishing authorization such as Power-of-Attorney, Board Resolution etc. shall accompany
thepetition.FORM-VII[Form for Appeals under Section 72 of the Copyright Act, 1957][COURT
FEES:_______]IN THE HIGH COURT OF DELHI AT NEW DELHI(Intellectual Property Division
– Appellate jurisdiction)C.A.(Comm.-IPD/CR)___ of ________(Full Name, address, e-mail and
mobile number ofthe Appellant(s). In case of foreign Appellant(s),address for service in India to be
furnished)...Appellant(s)Versus(Full Name, address, e-mail and mobile number ofthe
Respondent(s). In case of foreignrespondent(s)address for service in India to
befurnished)...Respondent(s)APPEAL UNDER SECTION 72 OF THE COPYRIGHTACT, 1957
CHALLENGING THE ORDER DATED______ PASSED BY _______The appellant(s) above
named respectfully submits as under:1.1Full Name of the Advocate :2. Address, e-mail and mobile
number of the Advocate :3. Date of the impugned order appealed against :4. Provision under which
the impugned order passed :5. Period of limitation :6. Delay, if any, in filing the appeal and reasons
thereof :7. Grounds of appeal :8. Details of any other proceedings pending in respect of the
samework(s) within the knowledge of the Appellant:9. Prayer :(Name & Signature of
theAdvocate/Appellant(s))10. Verification :[Signature of the Appellant(s)]11. Affidavit in support.
:List of Documents1.Impugned order.2. Any other relevant documents.NOTE:1. All the pleadings
shall be accompanied by the affidavit of the authorised representative of the partyconcerned.2.
Documents establishing authorization such as Power-of-Attorney, Board Resolution etc. shall
accompany theappeal.FORM-VIII[Form under Sections 64/71 of the Patents Act, 1970][COURT
FEES:_______IN THE HIGH COURT OF DELHI AT NEW DELHI(Intellectual Property Division
– Original Civil Jurisdiction)C.O. (Comm.-IPD/PAT)___ of ________(Full Name, address, e-mail
and mobile number ofthe petitioner(s)/applicant(s). In case of foreignpetitioner(s)/applicant(s),
address for service in Indiato be furnished)...Petitioner(s)/Applicant(s)Versus(Full Name(s),
address, e-mail and mobile number of...Respondent(s)the Respondent(s). In case of foreign
Respondent(s),address for service in India to be furnished)PETITION/APPLICATION UNDER
SECTION ____ OF THE PATENTSACT, 1970 SEEKING___________________TheDelhi High Court Intellectual Property Rights Division Rules, 2022

Petitioner(s)/Applicants(s) above named respectfully submit as under:1. 1. Full Name of the
Advocate :2. Address, e-mail and mobile number of the Advocate :3. Name and address of the
Patent Agent, if any :4. Patent sought to be revoked/rectified(i) Registration number(ii) Title of the
invention(iii) Date of filing of Application(iv) Date of advertisement in the Journal and
detailsthereof(v) Details of pre-grant Opposition(s) filed, if any(vi) Date of grant of patent(vii) Date
of expiry of the term of patent:5. Proprietor of the registered Patent :6. Details of
predecessor-in-interest of the Patent, if any :7. Current status of the Patent (print out from the
website ofthe Patent Office to be attached):8. Interest of the petitioner, in brief :9. Provisions
invoked for seeking revocation/ Rectification :10. Grounds for seeking revocation/ Rectification :11.
Details of any other proceedings pending with respect to the same patent or patent family within the
knowledge of the petitioner/Applicant:12. Prayer :[Name & Signature of the Advocatefor the
Petitioner(s)/Applicant(s)]13. Verification :(Signature of the Petitioner(s)/Applicant(s)14. Affidavit
in support :List of documents1. Copy of the complete specification of the Patent of which revocation
or rectification is sought be filed.2. Any other relevant documents.NOTE:1. All the pleadings shall be
accompanied by the affidavit of the authorised representative of the partyconcerned.2. Documents
establishing authorization such as Power-of-Attorney, Board Resolution etc. shall accompany
thepetition.FORM-IX[Form under Section 117-A of the Patents Act, 1970][COURT
FEES:_______]IN THE HIGH COURT OF DELHI AT NEW DELHI(Intellectual Property Division
– Appellate jurisdiction)C.A.(Comm.-IPD/PAT)___ of ________(Full Name, address, e-mail and
mobile number ofthe Appellant(s). In case of foreign Appellant(s),address for service in India to be
furnished)...Appellant(s)Versus(Full Name, address, e-mail and mobile number ofthe
Respondent(s). In case of foreignrespondent(s)address for service in India to
befurnished)...Respondent(s)APPEAL UNDER SECTION 117A OF THE PATENTSACT,1970
CHALLENGING THE ORDER DATED___ PASSED BY ___________________________The
appellant(s) above named respectfully submit as under:1. Full Name of the Advocate :2. Address,
e-mail and mobile number of the Advocate :3. Name and address of the Patent Agent, if any :4. Date
of the impugned order appealed against :5. Authority which passed the impugned order :6.
Provision under which the impugned order passed :7. Period of limitation :8. Delay, if any, in filing
the appeal and reasons thereof :9. Grounds of appeal :10. Details of any other proceedings pending
in respect of the same patent or patent family within the knowledge of the Appellant:11. Prayer
:(Name & Signature of theAdvocate/Appellant(s))12. Verification :[Signature of the Appellant(s)]13.
Affidavit in support. :List of Documents1. Copy of the impugned order passed by the IPO.2. Any
other relevant documents forming part of the record of the IPO.NOTE:1. All the pleadings shall be
accompanied by the affidavit of the authorised representative of the partyconcerned.2. Documents
establishing authorization such as Power-of-Attorney, Board Resolution etc. shall accompany
theappeal.FORM-X[Form under Sections 56 of the Protection of Plants Varieties and Farmers’
Rights Act, 2001][COURT FEES:_______IN THE HIGH COURT OF DELHI AT NEW
DELHI(Intellectual Property Division – Appellate Jurisdiction)C.A. (Comm.-IPD/PV)___ of
________(Full Name, address, e-mail and mobile number ofthe Appellant(s). In case of foreign
Appellant(s),address for service in India to be furnished)...Appellant(s)Versus(Full Name, address,
e-mail and mobile number ofthe Respondent(s). In case of foreignrespondent(s)address for service
in India to befurnished)...Respondent(s)APPEAL UNDER SECTION 56 OF THE PROTECTION OF
PLANTS VARIETIES AND FARMERSRIGHTS ACT, 2001 AGAINST ORDER DATED ______
PASSED BY ___________________________The Appellant(s) above named respectfullyDelhi High Court Intellectual Property Rights Division Rules, 2022

submits as under:1. Full Name of the Advocate :2. Address, e-mail and mobile number of the
Advocate :3. Plant Variety subject matter of the Appeal(i) Application/Registration number Type of
Plant Varietyregistered(ii) The PV as appearing in the Application/RegistrationCertificate be
affixed(iii) Date of filing of the Application:(iv) Date of advertisement in the Journal and details
thereof(v) Details of Opposition(s) filed if any(vi) Date of grant of registration(vii) Renewal details4.
Date of the order appealed against :5. Provision under which impugned order passed :6. Period of
limitation :7. Delay, if any, in filing the appeal and reasons thereof :8. Grounds of appeal :9.
Applicant/Proprietor of the PV :10. Authority which passed the impugned order :11. Details of any
other proceedings pending with respect to the same PV within the knowledge of the appellant(s):12.
Prayer :Name & Signature of theAdvocate for theAppellant(s)]13. Verification :[Signature of the
Appellant(s)]14. Affidavit in support :List of Documents1. Copy of the impugned order passed by the
IPO2. Any other relevant documents forming part of the record of the IPO.NOTE:1. All the
pleadings shall be accompanied by the affidavit of the authorised representative of the
partyconcerned.2. Documents establishing authorization such as Power-of-Attorney, Board
Resolution etc. shall accompany theappeal.FORM-XI[Form under Section 27/58 of the
Geographical Indications of Goods (Registration and Protection) Act, 1999][COURT
FEES:_______IN THE HIGH COURT OF DELHI AT NEW DELHI(Intellectual Property Division
– Original Civil Jurisdiction)C.O.(Comm.-IPD/GI)___ of ________(Full Name, address, e-mail
and mobile number ofthe petitioner(s)/applicant(s). In case of foreignpetitioner(s)/applicant(s),
address for service in Indiato be furnished)...Petitioner(s)/Applicant(s)Versus(Full Name(s),
address, e-mail and mobile number ofthe Respondent(s). In case of foreign Respondent(s),address
for service in India to be furnished)...Respondent(s)PETITION/APPLICATION UNDER SECTION
27/58 OF THE GEOGRAPHICAL INDICATIONS OFGOODS (REGISTRATION AND
PROTECTION) ACT, 1999 SEEKING _____________The Petitioner(s)/ Applicant(s) above
named respectfully submit as under:
1. Full Name of the Advocate :
2. Address, e-mail and mobile number of the Advocate :
3. Name and address of the Agent :
4. Geographical Indication(s) sought to be cancelled or varied
(i)Registration number(ii)Geographical Indication(The GI as appearing in the Registration
Certificate beaffixed)(iii)Date of filing of Application(iv)Date of advertisement in the
GeographicalIndication Journal and details thereof(v)Details of Opposition(s) filed if any(vi)Date of
grant of registration(vii)Renewal details:
5. Proprietor of the registered Geographical Indication :Delhi High Court Intellectual Property Rights Division Rules, 2022

6. Details of predecessor-in-interest of the Geographical Indication, if
any:
7. Details of homonymous Geographical Indication, if any Applied
for/registered:
8. Current status of the Geographical Indications (print-out from the
website of the Geographical Indications Registry to be attached):
9. Date of user claimed in the application for Geographical
Indications.:
10. Disclaimer/other conditions, if any :
11. Interest of the petitioner(s)/ applicant(s), in brief :
12. Grounds for seeking cancellation/relief :
13. Details of any other proceedings pending with respect to the same
GI within the knowledge of the Petitioner(s)/Applicant(s):
14. Prayer :
[Name & Signature of the Advocatefor the Petitioner(s)/Applicant(s)]
15. Verification :
(Signature of the Petitioner(s)/Applicant(s)
16. Affidavit in support :
List of documents
1. Copy of registration certificate obtained by the respondent in respect of
the impugned GI.Delhi High Court Intellectual Property Rights Division Rules, 2022

2. Current status of the GI printed from the website of the GI Registry
3. Relevant documents.
NOTE:
1. All the pleadings shall be accompanied by the affidavit of the authorised
representative of the party
concerned.
2. Documents establishing authorization such as Power-of-Attorney, Board
Resolution etc shall accompany the
petition.FORM-XII[Form under Sections 31 of the Geographical Indications Of Goods (Registration
and Protection) Act, 1999 and Rul
116. of the Geographical Indications of Goods (Registration and Protection)
Rules, 2002]
[COURT FEES:_______IN THE HIGH COURT OF DELHI AT NEW DELHI(Intellectual Property
Division – Appellate jurisdiction)C.A.(Comm.-IPD/GI)___ of ________(Full Name, address,
e-mail and mobile number ofthe Appellant(s). In case of foreign Appellant(s),address for service in
India to be furnished)...Appellant(s)Versus(Full Name, address, e-mail and mobile number ofthe
Respondent(s). In case of foreignrespondent(s)address for service in India to
befurnished)...Respondent(s)APPEAL UNDER SECTION 31 OF THEGEOGRAPHICAL
INDICATIONS OF GOODS (REGISTRATIONAND PROTECTION) ACT, 1999AND RULE 116 OF
THE GEOGRAPHICAL INDICATIONS OF GOODS(REGISTRATION AND PROTECTION) RULES,
2002CHALLENGING THE ORDER DATED ________PASSED BY
_____________________________The Appellant(s) above named respectfully submit as
under:
1. Full Name of the Advocate :
2. Address, e-mail and mobile number of the Advocate. :
3. Name and address of the Agent :
4. Geographical Indication(s)subject matter of the Appeal
(i)Registration number(ii)Geographical Indication(The GI as appearing in the Registration
Certificate beaffixed)(iii)Date of filing of Application(iv)Date of advertisement in theDelhi High Court Intellectual Property Rights Division Rules, 2022

GeographicalIndication Journal and details thereof(v)Details of Opposition(s) filed if any(vi)Date of
grant of registration(vii)Renewal details:
5. Date of the impugned order appealed against :
6. Applicant/Proprietor of the Geographical Indication :
7. Authority which passed the impugned order :
8. Provision under which impugned order passed :
9. Period of limitation :
10. Delay, if any, in filing the appeal and reasons thereof. :
11. Grounds of appeal :
12. Details of any other proceedings pending with respect to the same
GI within the knowledge of the appellant(s):
13. Prayer :
(Name & Signature of theAdvocate/Appellant(s))
14. Verification :
[Signature of the Appellant(s)]
15. Affidavit in support. :
List of Documents
1. Copy of the impugned order passed by the IPO
2.
Any other relevant documents forming part of the record of the IPO.NOTE:Delhi High Court Intellectual Property Rights Division Rules, 2022

1. All the pleadings shall be accompanied by the affidavit of the authorised
representative of the party
concerned.
2. Documents establishing authorization such as Power-of-Attorney, Board
Resolution etc. shall accompany the
appeal.FORM-XIII[Form under Section 40 of the Semiconductor Integrated Circuits Layout-Design
Act, 2000](COURT FEES:_______IN THE HIGH COURT OF DELHI AT NEW
DELHI(Intellectual Property Division – Original Civil Jurisdiction)C.O. (Comm.-IPD/SCD)___ of
________(Full Name, address, e-mail and mobile number ofthe petitioner(s)/applicant(s). In case
of foreignpetitioner(s)/applicant(s), address for service in Indiato be
furnished)...Petitioner(s)/Applicant(s)Versus(Full Name(s), address, e-mail and mobile number
ofthe Respondent(s). In case of foreign Respondent(s),address for service in India to be
furnished)...Respondent(s)PETITION/APPLICATION UNDER SECTION 40 OF THE
SEMICONDUCTOR INTEGRATED CIRCUITSLAYOUT-DESIGN ACT, 2000 FOR
_______________________________The Petitioner(s)/ Applicant(s) above named
respectfully submits as under:
1. Full Name of the Advocate :
2. Address, e-mail and mobile number of the Advocate :
3. Name and address of the Agent, if any: :
4. Details of Layout-design for which royalty is being claimed: :
5. Relief prayed and relevant section(s) :
6. Brief facts :
7. Grounds in support for seeking royalty: :
8. Benefit accrued by performing, or directing to be performed, the
acts referred to Section 18(1)(b) in respect of layout-design:
9. Details of any other proceedings pending with respect to the
same layout-design within the knowledge of thepetitioner/Applicant including the forum:Delhi High Court Intellectual Property Rights Division Rules, 2022

10. Prayer :
[Name & Signature of the Advocatefor the Petitioner(s)/Applicant(s)]
11. Verification :
(Signature of the Petitioner(s)/Applicant(s)
12. Affidavit in support :
List of Documents
1. Copy of registration certificate obtained by the respondent in respect of
the impugned layout-design.
2. Current status of the layout-design.
3. Any other relevant document(s).
NOTE:
1. All the pleadings shall be accompanied by the affidavit of the authorised
representative of the party
concerned.
2. Documents establishing authorization such as Power-of-Attorney, Board
Resolution etc. shall accompany the
petition.FORM-XIV[Form under Section 41 of the Semiconductor Integrated Circuits Layout-Design
Act, 2000](COURT FEES:_______IN THE HIGH COURT OF DELHI AT NEW
DELHI(Intellectual Property Division – Original Civil Jurisdiction)C.O. (Comm.-IPD/SCD)___ of
________(Full Name, address, e-mail and mobile number ofthe petitioner(s)/applicant(s). In case
of foreignpetitioner(s)/applicant(s), address for service in Indiato be
furnished)...Petitioner(s)/Applicant(s)Versus(Full Name(s), address, e-mail and mobile number
ofthe Respondent(s). In case of foreign Respondent(s),address for service in India to be
furnished)...Respondent(s)PETITION/APPLICATION UNDER SECTION 41 OF THE
SEMICONDUCTOR INTEGRATED CIRCUITSLAYOUT-DESIGN ACT, 2000 FOR
_______________________________The Petitioner(s)/ Applicant(s) above named
respectfully submits as under:Delhi High Court Intellectual Property Rights Division Rules, 2022

1. Full Name of the Advocate :
2. Address, e-mail and mobile number of the Advocate :
3. Name and address of the Agent, if any :
4. Details of Layout-design sought to be cancelled :
5. Relief prayed and relevant section(s) :
6. Proprietor of the registered layout-design :
7. Grounds for seeking relief :
8. Details of any other proceedings pending with respect to the same
layout-design within the knowledge of the petitioner/Applicantincluding the forum:
9. Prayer :
____________________[Name & Signature of the Advocatefor the Petitioner(s)/Applicant(s)]
10. Verification :
(Signature of the Petitioner(s)/Applicant(s)
11. Affidavit in support :
List of Documents
1. Copy of registration certificate obtained by the respondent in respect of
the impugned layout-design.
2. Current status of the layout-design
3. Any other relevant document(s)
NOTE:Delhi High Court Intellectual Property Rights Division Rules, 2022

1. All the pleadings shall be accompanied by the affidavit of the authorised
representative of the party
concerned.
2. Documents establishing authorization such as Power-of-Attorney, Board
Resolution etc. shall accompany the
petition.FORM-XV[Form under Section 42 of the Semiconductor Integrated Circuits Layout-Design
Act, 2000][COURT FEES:_______]IN THE HIGH COURT OF DELHI AT NEW
DELHI(Intellectual Property Division – Appellate Jurisdiction)C.A. (Comm.-IPD/SCD)___ of
________(Full Name, address, e-mail and mobile number ofthe Appellant(s). In case of foreign
Appellant(s),address for service in India to be furnished)...Appellant(s)Versus(Full Name, address,
e-mail and mobile number ofthe Respondent(s). In case of foreignrespondent(s)address for service
in India to befurnished)...Respondent(s)APPEAL UNDER SECTION 42 OF THE
SEMICONDUCTOR INTEGRATED CIRCUITS LAYOUT-DESIGN ACT, 2000 CHALLENGING THE
ORDER DATED _____ PASSED BY_____________________________The appellant(s)
above named respectfully submit as under:
1. Full Name of the Advocate :
2. Address, e-mail and mobile number of the Advocate :
3. Name and address of the Agent, if any :
4. Date of the impugned order appealed against :
5. Authority which passed the impugned order :
6. Provision under which the impugned order passed :
7. Period of limitation :
8. Delay, if any, in filing the appeal and reasons thereof :
9. Grounds of appeal :
10. Details of any other proceedings pending in respect of the same or
related layout-design within the knowledge of the Appellant:Delhi High Court Intellectual Property Rights Division Rules, 2022

11. Prayer :
(Name & Signature of theAdvocate/Appellant(s))
12. Verification :
[Signature of the Appellant(s)]
13. Affidavit in support. :
List of Documents
1. Copy of the impugned order passed by the IPO
2.
Any other relevant documents forming part of the record of the IPO.NOTE:
1. All the pleadings shall be accompanied by the affidavit of the authorised
representative of the party
concerned.
2. Documents establishing authorization such as Power-of-Attorney, Board
Resolution etc. shall accompany the
appeal.FORM-XVI[Form under Section 36 of the Designs Act, 2000][COURT FEES:_______]IN
THE HIGH COURT OF DELHI AT NEW DELHI(Intellectual Property Division – Appellate
jurisdiction)C.A.(Comm.-IPD/DE)___ of ________(Full Name, address, e-mail and mobile
number ofthe Appellant(s). In case of foreign Appellant(s),address for service in India to be
furnished)...Appellant(s)Versus(Full Name, address, e-mail and mobile number ofthe
Respondent(s). In case of foreignrespondent(s)address for service in India to
befurnished)...Respondent(s)APPEAL UNDER SECTION 36 OF THE DESIGNS ACT,
2000CHALLENGING THE ORDER DATED___ PASSED BY
___________________________The appellant(s) above named respectfully submit as under:
1. Full Name of the Advocate :
2. Address, e-mail and mobile number of the Advocate :Delhi High Court Intellectual Property Rights Division Rules, 2022

3. Name and address of Agent, if any :
4. Date of the impugned order appealed against :
5. Authority which passed the impugned order :
6. Provision under which the impugned order passed :
7. Period of limitation :
8. Delay, if any, in filing the appeal and reasons thereof :
9. Grounds of appeal :
10. Details of any other proceedings pending in respect of the same or
related design within the knowledge of the Appellant:
11. Prayer :
(Name & Signature of theAdvocate/Appellant(s)
12. Verification :
[Signature of the Appellant(s)]
13. Affidavit in support. :
List of Documents
1. Copy of the impugned order passed by the IPO
2.
Any other relevant documents forming part of the record of the IPO.NOTE:
1. All the pleadings shall be accompanied by the affidavit of the authorised
representative of the party
concerned.Delhi High Court Intellectual Property Rights Division Rules, 2022

2. Documents establishing authorization such as Power-of-Attorney, Board
Resolution etc. shall accompany the
appeal.FORM-XVII[Form under Section 46 of the Information Technology Act, 2000][COURT
FEES:_______]IN THE HIGH COURT OF DELHI AT NEW DELHI(Intellectual Property Division
– Original Civil Jurisdiction)C.O. (Comm.-IPD/IT)___ of ________(Full Name, address, e-mail
and mobile number ofthe Petitioner(s). In case of foreign Petitioner(s),address for service in India to
be furnished)...Petitioner(s)Versus(Full Name, address, e-mail and mobile number ofthe
Respondent(s). In case of foreignrespondent(s)address for service in India to
befurnished)...Respondent(s)PETITION UNDER SECTION 46 OF THE INFORMATION
TECHNOLOGY ACT, 2000 CLAIMINGINJURY/DAMAGESThe Petitioner(s) above named
respectfully submits as under:
1. 1.. Full Name of the Advocate :
2. Address, e-mail and mobile number of the Advocate :
3. Period of limitation, if any :
4. Brief introduction and details of the contravention committed
under the provisions of the Information Technology Act, 2000and/or rules and regulations
thereunder.:
5. Compensation for injury/damages claimed1
:
6. Justification thereof, in terms of Section 47, Information
Technology Act, 2000
7. Prayer :
(Name & Signature of theAdvocate/Petitioner(s))
8. Verification :
[Signature of the Petitioner(s)]Delhi High Court Intellectual Property Rights Division Rules, 2022

9. Affidavit in support. :
List of Documents
1.
All relevant documents to establish the contravention under the Information Technology Act, 2000;
2. All relevant documents in support of the claim for injury/compensation
claim for damages.
NOTE:
1. All the pleadings shall be accompanied by the affidavit of the authorised
representative of the party
concerned.
2. Documents establishing authorization such as Power-of-Attorney, Board
Resolution etc. shall accompany the
petition.FORM-XVIII[Form under Section 62 of the Information Technology Act, 2000][COURT
FEES:_______]IN THE HIGH COURT OF DELHI AT NEW DELHI(Intellectual Property Division
– Appellate Jurisdiction)C.A. (Comm.-IPD/IT)___ of ________
1.
A claim for compensation before the Delhi High Court would lie only if the claim exceeds INR 5
crores.(Full Name, address, e-mail and mobile number ofthe Appellant(s). In case of foreign
Appellant(s),address for service in India to be furnished)...Appellant(s)Versus(Full Name, address,
e-mail and mobile number ofthe Respondent(s). In case of foreignrespondent(s)address for service
in India to befurnished)...Respondent(s)APPEAL UNDER SECTION 62 OF THE INFORMATION
TECHNOLOGY ACT, 2000 CHALLENGINGTHE ORDER DATED ___ PASSED BY
___________________________The appellant(s) above named respectfully submit as under:
1. Full Name of the Advocate :
2. Address, e-mail and mobile number of the Advocate :Delhi High Court Intellectual Property Rights Division Rules, 2022

3. Date of the impugned order appealed against :
4. Authority/forum which passed the impugned order :
5. Provision under which the impugned order passed :
6. Period of limitation :
7. Delay, if any, in filing the appeal and reasons thereof :
8. Grounds of appeal :
9. Prayer :
(Name & Signature of theAdvocate/Appellant(s))
10. Verification :
[Signature of the Appellant(s)]
11. Affidavit in support. :
List of Documents
1. Copy of the impugned order passed by the relevant authority/forum.
2. Any other relevant documents forming part of the record of the relevant
authority.
NOTE:
1. All the pleadings shall be accompanied by the affidavit of the authorised
representative of the party
concerned.
2. Documents establishing authorization such as Power-of-Attorney, Board
Resolution etc. shall accompany the
appeal.Delhi High Court Intellectual Property Rights Division Rules, 2022

II
Sr.
No.Items Court Fees
1. Application or Petition filed under Sections 47/57/125 of the Trade Marks
Act, 1999.
, in alternative or in conjunction.Rs. 10,000/-
2. Appeal filed to the High Court under Section91 of Trade Marks Act, 1999.
Rs. 10,000/-
3. Petition or Complaints filed under Section 19A of the Copyright Act, 1957
with
respect to assignment of the Copyright Act.Rs. 5000/-
4. Petition or Complaint or Application filed under Section 31 of the Copy
Right
Act, 1957· for Compulsory Licence in works withheld from Public.Rs. 10,000/-
5. Petition or Complaint or Application filed under Section 31A of the
Copyright
Act 1957 for Compulsory Licence in Unpublished or Published Works.Rs. 10,000/-
6. Petition or Complaint or Application filed under Section 31B of the
Copyright
Act, 1957 for Compulsory Licence for Benefit of Disabled.Rs. 10,000/-
7. Petition or Complaint or Application filed under Section 31C of the
Copyright
Act, 1957 for Statutory Licence for cover versions.Rs. 10,000/-Delhi High Court Intellectual Property Rights Division Rules, 2022

8. Petition or Complaint or Application filed under Section 31D of the
Copyright
Act, 1957 for Statutory Licence for Broadcasting of Literary and Musical Worksand Sound
Recording.Rs. 10,000/-
9. Petition or Complaint or Application filed under Section 32 of the
Copyright
Act, 1957 for Licence to Produce and Publish Translations.Rs. 10,000/-
10. Petition or Complaint or Application filed under Section 32A of the
Copyright
Act, 1957 for Licence to Reproduce and Publish Works for Certain Purposes.Rs. 10,000/-
11. Petition or Complaint or Application filed under Section 31C (5) of the
Copyright Act, 1957 to the effect that the owner of the right has not paid in fullfor any sound
recordings purporting to be made in pursuance of this Section.Rs. 10,000/-
12. Application for rectification of register filed under Section 50 of the
Copyright
Act.Rs. 10,000/-
13. Appeal made under Section 72 of the Copyright Act, 1957 against the
order of
the Registrar.Rs. 5000/-
14. Petition or Application made under Section 64 of the Patents Act, 1970 for
Revocation of Patent.Rs. 10,000/-
15. Petition or Application made under Section 71 of the Patent Act, 1970 for
Rectification of Register.Rs. 10,000/-Delhi High Court Intellectual Property Rights Division Rules, 2022

16. Appeal filed under Section 117A of the Patents Act, 1970. Rs. 10,000/-
17. Petition or Application for rectification of the register by cancelling,
expunging
or varying of any entry under Section 27 of the Geographical Indications ofGoods (Registration and
Protection) Act, 1999.Rs. 5000/-
18. Appeal from the order of the Registrar filed under Section 31 of the
Geographical Indications of Goods (Registration and Protection) Act, 1999.Rs. 5000/-
19. Appeal filed under Section 56 of the Protection of Plants Varieties and
Farmers
Right Act, 2001.Rs. 5000/-
20. Petition filed under Section 46 of the Information Technology Act, 2000
seeking
compensation/damages.Rs. 5000/-
21. Appeal filed under Section 62 of the Information Technology Act, 2000.
Rs. 5000/-
22. Appeal filed under Section 36 of the Designs Act, 2000. Rs. 5000/-
23. Any other original petition/appeal not mentioned above. Rs. 5000/-
24. Any other miscellaneous application not mentioned above. Rs. 500/-
By Order of the Court,MANOJ JAIN, Registrar GeneralUploaded by Dte. of Printing at Government
of India Press, Ring Road, Mayapuri, New Delhi-110064and Published by the Controller of
Publications, Delhi-110054. SURENDERMAHADASAMDigitally signed by
SURENDERMAHADASAMDate: 2022.02.25 16:44:07 +05'30'Delhi High Court Intellectual Property Rights Division Rules, 2022

