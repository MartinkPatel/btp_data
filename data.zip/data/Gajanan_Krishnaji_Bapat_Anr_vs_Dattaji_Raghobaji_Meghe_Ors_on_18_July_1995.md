Gajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe &
Ors on 18 July, 1995
Equivalent citations: 1995 AIR 2284, 1995 SCC (5) 347, AIR 1995 SUPREME
COURT 2284, 1995 AIR SCW 3407, (1995) 3 SCJ 321, 1995 (5) SCC 347, (1995)
5 JT 410 (SC)
Author: M.K Mukherjee
Bench: M.K Mukherjee
           PETITIONER:
GAJANAN KRISHNAJI BAPAT & ANR.
        Vs.
RESPONDENT:
DATTAJI RAGHOBAJI MEGHE & ORS.
DATE OF JUDGMENT18/07/1995
BENCH:
ANAND, A.S. (J)
BENCH:
ANAND, A.S. (J)
MUKHERJEE M.K. (J)
CITATION:
 1995 AIR 2284            1995 SCC  (5) 347
 JT 1995 (5)   410        1995 SCALE  (4)469
ACT:
HEADNOTE:
JUDGMENT:
J U D G E M E N T DR. ANAND. J.
This appeal under Section 116-A of the Representation of People Act 1951 (hereinafter referred to as
the Act). by two electors is directed against the judgment and order of a learned Single Judge of the
Nagpur Bench of the High Court of Judicature at Bombay dismissing the election petition. TheGajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

returned candidate has also filed cross-objections challenging those findings which have gone
against him. Both shall be disposed of by this common judgment.
The appellants filed an election petition under Section 80 of the Act challenging the election of
respondent No.1, Dattaji Raghobaji Meghe, the returned candidate from 23 Nagpur Parliamentary
Constituency in the elections held for the Xth Lok Sabha and also sought a declaration to the effect
that respondent No.2 Shri Banwarilal Bhagwandas Purohit be declared as the duly elected candidate
from the said Constituency after setting aside the election of the returned candidate. The challenge
to the election of respondent No.1 was mainly based on the allegations of commission of various
corrupt practices by him and/or his election agent detailed in the petition.
Appellant No.1 was at the relevant time the Vice President of Bhartiya Janta Party (Nagpur City)
Nagpur while appellant No.2 was a worker of the Bhartiya Janta Party. Respondent No.2, Shri
Banwarilal Bhagwandas Purohit, the defeated candidate had been sponsored as a candidate by the
Bhartiya Janta Party while respondent No.1 Datta Raghobaji Meghe, the returned candidate, had
been sponsored by Congress (I). Besides respondents 1 and 2, the other candidates, who had
contested the election and had not withdrawn their candidatures from the contest, numbering more
than forty two were also joined as respondents to the election petition.
The main case of the appellants projected before the High Court and canvassed before us against the
returned candidate was that the expenditure incurred or authorised by respondent No.1 or his
election agent was much more than what had been disclosed by him in the return of expenditure
lodged under Section 78 of the Act with the District Election officer and that huge expenditure
incurred by him in connection with his election had been suppressed. It was further alleged that
though the expenditure incurred in connection with the election of respondent No.1 was shown to
have been incurred by the political party, some other sympathetic associations, organisations,
individuals, friends and well-wishers, the said expenditure in fact had been incurred and/or
authorised by respondent No.1 and/or his election agent and the amount spent by those
organisations had been provided out of the funds made available by respondent No.1 to those
parties for making the payment and their names were given only to conceal the truth of the
transactions so as to escape from the mischief of Section 123 (6) of the Act. It was pleaded that some
of the organisations under whose names the advertisements had appeared, were in fact non-existent
and that the individuals who were shown ostensibly to have incurred some expenditure for
furtherance of the prospects of the election of respondent No.1, had actually no funds of their own to
spend and respondent No.1 had placed his own funds in their hands to meet the expenditure.
According to the appellants, the expenditure incurred by respondent No.1 was far in excess of the
limit prescribed by Section 77 of the Act read with Rule 90 of the Conduct of Election Rules 1961
(hereinafter the Rules') and the return of election expenditure did not reflect the correct state of
affairs. Since respondent No.1 had exceeded the prescribed limit of expense, he was guilty of
committing the corrupt practice under Section 123 (6) of the Act and his election was, therfore,
liable to be declared void and respondent No.1 also disqualified for committing the corrupt practice.
Respondent No.1 before filing his written statement raised a preliminary objection, through Ex.16
and Ex.17, to the effect that the allegations made in the petition were vague and that material factsGajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

and particulars had not been supplied and as such the vague pleadings were liable to be struck off
and the election petition rejected under Section 81(3) read with Section 86 of the Act. On
29.10.1991, however, Ex.16 was rejected while application Ex.17 was allowed to the extent that the
allegations made in the petition regarding the commission of corrupt practice under Section 123(2)
and (3A) were found to be vague and non- specific and the pleadings in that connection were
directed to be struck off. Against the order of rejection of the preliminary objection raised in Ex, 16,
respondent No.1 preferred a special leave petition being SLP(c) No.19165- 66/91 in this Court which
was dismissed on 20th December 1991 by the following order :
"The special leave petitionis -
dismissed. However,this order will not prevent him from raising objections, which are available to
him according to law, when the evidence is made on the relevant allegations."
Subsequently, an application, Ex. 27, filed by the appellants for leave to amend the election petition
for correcting certain inadvertant "errors, omissions and slips"
was allowed on 28.11.1991 and the necessary corrections were carried out in the
election petition. Again an application Ex. 47/A filed by the appellants seeking
further amendment of the verification clause of the petition was allowed by the Court
on 18.01.1992, after an earlier application, Ex. 44, filed by the appellants seeking
amendment of the election petition had been allowed on 18.12.1991.
A detailed written statement was thereafter filed by respondent No.1 in which the
charges levelled against him in the election petition were vehemently denied.
Respondent No.1, in respect of certain items of expenditure, took a specific stand that
the expenditure on those items as detailed by the appellants in the election petition,
were incurred by Nagpur City District Congress Committees and Nagpur Gramin
Congress Committee and not by him. Similarly, in respect of some other items of
expenditure, respondent No.1 took the plea that the expenditure in respect of those
items was incurred by certain organisations, associations, individuals, friends and
well-wishers, without any authority or consent of respondent No.1 or his election
agent and completely on their own volitions. In the written statement, the names of
some of the organisations and individuals as well as the associations of persons and
the political party who had incurred the expenditure were furnished by respondent
No.1. It was maintained by respondent No.1 that he had not incurred any expenditure
besides the one reflected in the return of election expense and had not committed any
corrupt practice. After the amendments were carried out by the appellants, the
returned candidate, Respondent No.1 filed yet another application Ex.50 seeking
striking out of some other `vague and non-specific' pleadings but the same was
rejected, though the prayer of Respondent No.1 to amend the written statement made
through application Ex.49 was allowed on 9.1.1992.
From the pleadings of the parties, the following issues were framed on 21.1.1992:-Gajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

(1)Do the petitioners prove that they were electors in the election held for the Tenth
Lok Sabha from 23, Nagpur Parliamentary Constituency?
(2) (a) Do the petitioners prove that a meeting was held in the office of the
Maharashtra State Handloom Corporation on 17.5.91 during the Tenth Lok Sabha
Election from 23, Nagpur Parliamentary Constituency?
(b) Do the petitioners further prove that the said meeting was addressed by the
respondent No.1?
(c) Do the petitioners prove that in the said meeting, respondent No.1 had declared
that labour charges for handloom weavers would be increased by 0.35 paise per sq.
metre from June 1991?
(d) Do the petitioners prove that the said declaration of increase in the labour charges
was made by respondentNo.1 to hold out promise of gratification for inducing the
weavers numbering 1,50,000 to vote for the respondent No.1?
(e) Do the petitioners prove that the said declaration made by the respondent No.1
amounts to commission of corrupt practice within the meaning of Section 123(1)(A)
i.e. bribery?
(f) Do the petitioners further prove that the said declaration made by respondent
No.1 also amounts to undueinfluence constituting commission of corrupt practice
under Section 123(2) and further amounts to direct or indirect interference or
attempt to interfere with the free exercise of electoral rights of the handloom weavers
who were electors in the said election?
(3) Do the petitioners prove that the respondent No.1 has not maintained correct and
proper accounts as is required to be maintained under Section 77 and has incurred
expenses in excess of the limit prescribed thereunder and thereby committed corrupt
practice under Section 123(6) of the Act? (4) Do the petitioners prove that the
respondent No.1 incurred more expenditure than what is disclosed by him in the
return of expenditure annexed as Annexure 7 to the petition, on the following items
as alleged in paras 2, 4 to 2.10 of the petition, on account of the (i) payments made to
Shri Devi Sharda Mangal Karyalaya, Nagpur, by way of office rent?
(ii) payments made to M/S Vishwa Bharti Typing Institute, Nagpur.
(iii) payments made to M/S Prince Travels, Nagpur, for hiring autorickshaws and
taxis.
(iv) payments made to M/S Pramod Automobiles, Nagpur.Gajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

(v) payments made to M/S Raj Automobiles, Nagpur.
(5) (a) Do the petitioners prove that the respondent No.1 has authorised and/or
incurred expenditure on the undermentioned items which has not been disclosed in
the return of expenditure annexed as Annexure 7 to the petition as alleged in paras
mentioned in the petition described against each item hereunder?
(b)(i) Do the petitioners prove that printing cards at Annexure 9 indicate that the
same have been published by Nagpur City District Congress Committee, Nagpur, but
the expenditure incurred on printing and distribution of about 15 lacs voter-cards has
been made by respondent No.1 to the extent of Rs.2,25,000/-. Do the petitioners
further prove that the respondent No.1 has got printed those cards at Shakti Offset
Works, Nagpur and the said firm received a total amount of Rs.2,25,000/- from
respondent No.1?
(ii) Do the petitioners prove that respondent 1 got printed 3,25000 posters of
different sizes though those posters show that they were issued by President, Nagpur
District Congress Committee and the entire expenditure of these posters to the tune
of Rs.3,40,250/- was made by respondent No.1?
(iii) Do the petitioners prove that the respondent No.1 published his candidature by
large size cut-outs at places mentioned in Annexure 11 alleged to be prepared by
persons whose names are given in Annexure 10? Do the petitioners further prove that
cost of these cutouts comes out to Rs.2,83000/- as given in Annexure 11 and was
incurred by respondent No.1 by paying the same to persons mentioned in Annexure
10?
(iv) Do the petitioners prove that the respondent No.1 advertised his candidature by
wall paintings at different locations at Annexure 12 costing about Rs.88500/-? Do the
petitioners further prove that these wall paintings work was got executed by
respondent No.1 through painters and incurred expenditure of it by payment of
charges of painters?
(v) Do the petitioners prove that about 12,40,830 lettrers such as those at Annexure
13 $ 14 were got prepared by the respondent No.1 and were sent to voters and almost
all the voters received these letters? Do the petitioners further prove that although on
this letter, it appears that the same is being sent at the instance of Sarva Dharma
Sambhav Samajik Sanghatna, trhe expenditure required in fact was incurred by
respondent No.1 to the extent of Rs.12,40,830/-?
(vi) Do the petitioners prove that advertisement in newspapers at Annexure A at Sl.
Nos.A2, A5, A7, A8, A10, A14 to A19, A22 to A27, A28(b), A30(a) (first part) A30 (b)
(second part);Gajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

Annexure B at Sl. Nos. B4 to B9, B11 to B14,B17 and B18, Annexure C at Sl.
Nos. C1, C2, C4, C5, C10,C12, C14 to C18, C23 $ C24. Annexure D: at Sl. Nos.
D1, D2, D3, D5, D7, D8, D11, D13, and D15: Annexure E at Sl. Nos. E1, E2, E9, and E10; Annexure F,
At Sl. Nos. F1, F2, F3, F6, F10, F14 and F16; Annexure G at Sl. Nos. G1, G2 and G3; Annexure H at
Sl. Nos. H11 to H14, H17, H8, H11 and H17, were published by respondent No.1 himself in
connection with the election and he himself incurred the expenditure?
(vii) Do the petitioners prove that the advertisements appearing in newspapers at- Annexure A: at
S.Nos. A6, A9, A11 to A13, A20, A21, A27(a), A28, A30(b) (first part) and A31(b);
Annexure B: At S. Nos. B1, B2, B3, B10, B15, B16 and B19.
Annexure C: at S. Nos. C3, C6 to C9, C11, C13, C19 to C22.
Annexure D: at Sl. Nos. D6, D9, D10, D12, and D14.
Annexure E: At Sl. Nos. E3 to E8;
Annexure F: at S. Nos. F3, F5, F7 to F9, F11 to F13 & F15;
Annexure G: at S. Nos. G4 to G8; are published in connection with election by the respondent No.1
and the expenditure of which is incurred by the respondent No.1 himself though in the said
advertisement the names of publishers are shown as persons other than the respondent No.1 as
given in Annexures.
(6) (a) Do the petitioners prove that the respondent No.1 had employed M/S Yugdharma Consultant
and Commercial Services, Nagpur to publicise his candidature and incurred expenditure as per the
details shown in Annexures 17 and 18 alleged in para 2.13 of the petition.
(b) Do the petitioners prove that besides the above agency, the respondent No.1 had employed two
other agencies, namely, Orange City Advertising and Prasad Publicity for publishing his candidature
by advertisements issued in the nesspapers and thereby authorised and incurred expenditure as per
details shown in Annexure 18A, 18B and 18C and alleged in paras 2.23A to 2.23D of the petition?
(c) Do the petitioners prove that election agent of respondent No.1 incurred total expenditure to the
tune of Rs.39500/- on 14.6.91 and 17.6.91 for publication of advertisement in connection with the
election?
(7) Do the petitioner prove that the respondent No.47 did not properly scrutinise the nomination of
the respondent No.3 and he was allowed to represent himself as such, althoough a wireless message
dated 26.4.91 to the contrary was received by the Returning Officer prior to the acceptance of the
nomination papers from the Chief Electoral Officer of the Maharashtra ?Gajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

(8) Do the petitioners prove that by allowing the respondent No.3 to represent himself as the official
candidate of R.P.I.(k), the result of the election of the respondent No.1 has been materially affected?
(9) Are the petitioners entitled to have inspection of the ballot papers on the basis of the allegations
made in paras 3.1 to 3.11 of the petition and the allegations made in paras 1 to 13 of Ex.28?
(10) Do the petitioners prove that the election of the respondent No.1 to the Tenth Lok Sabha from
23, Nagpur Parliamentary Constituency is void on accunt of the commission of corrupt practices
under Section 123(1A) & Section 123(2) and Section 123(6) of the Act?
(11) Do the petitioners prove that the respondent No.2 has secured majority of valid votes to entitle
him to be declared as duly elected from 23, Nagpur Parliamentary Constituency to the Tenth Lok
Sabha?
(12) Do the petitioners prove that but for the votes obtained by respondent No.1 by alleged corrupt
practices, the respondent No.2 would have obtained majority of valid votes to entitle him to be
declared duly elected ?
(13) whether respondent No.2 can be declared as duly elected to the Tenth Lok Sabha from 23,
Nagpur Parliamentary Constituency, Nagpur ?
(14) What order?
After the evidence of some of the witnesses was recorded on behalf of the appellants, Election
Petitioner No.1 filed an application, Ex. 701 on 27.5.1992, once again for amending the election
petition in the light of the evidence recorded. Respondent No.1 filed his objections to the said
application through Ex. 834 on 15.6.1992. The learned Single Judge, allowed the application
permitting the election petitioner to amend the election petition once again and being of the view
that no new issue was required to be framed on the basis of the proposed amendments directed that
the Respondent No.1 could apply for recalling any of the petitioners' witnesses for further cross-
examination On 17.6.1992, Respondent No.1 filed an application Ex. 835 for leave to amend the
written statement which was also allowed. We shall advert to the proceedings concerning various
amendments in the latter part of this judgment.
The learned Single Judge after conclusion of the evidence and after hearing learned counsel for the
parties held that the appellants (election petitioners) had proved that respondent No.1 had not
maintained a correct and proper account of the election expenditure as is required to be maintained
under Section 77 of the Act. It was also found that respondent No.1 had not shown in his return an
expenditure to the extent of Rs.58220/- apart from the expenditure shown by him in the return of
election expenditure but since the addition of the said amount, to the amount of expenditure shown
by respondent No.1 in his return of election expenses, did not exceed the permissible limit of
Rs.1,50,000/-, the returned candidate, respondent No.1, did not commit any corrupt practice as
envisaged by Section 123(6) and dismissed the election petition but without any order as to costs in
favour of Respondent No.1.Gajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

Since, in this appeal learned counsel for the appellants Dr. Ghatate has confined his case to issues 3,
4(V), 5(b) (i) (ii) (v) (vi) (vii); issue No.6 (a) (b) (c); and partly Issue No.10, we are, as such, relieved
of the necessity of dealing with the other issues. We confirm the findings of the High Court in
respect of those issues of which correctness has not been disputed before us.
The right to elect and the right to be elected are statutory rights. These rights do not inhere in a
citizen as such and in order to exercise the right certain formalities as provided by the Act and the
Rules made thereunder are required to be strictly complied with. The statutory requirements of
election law are to be strictly observed because the election contest is not an action at law or a suit in
equity but it is a purely statutory proceeding unknown to the common law. The Act is a complete
code in itself for challenging an election and an election must be challenged only in the manner
provided for by the Act. In Jyoti Basu Vs. Debi Ghosal (1982 (3) SCR 318), this Court observed:
"A right to elect, fundamental though it is to democracy, is, anomalously enough, neither a
fundamental right nor a Common Law Right. It is pure and simple, a statutory right. So is the right
to be elected. So is the right to dispute an election. Outside of statute, there is no right to elect, no
right to be elected and no right to dispute an election. Statutory creations they are, and therefore,
subject to statutory limitation. An Election petition is not an action at Common Law, nor in equity.
It is a statutory proceeding to which neither the Common Law nor the principles of Equity apply but
only those rules which the statute makes and applies. It is a special jurisdiction, and a special
jurisdiction has always to be exercised in accordance with the statute creating it. Concepts familiar
to Common Law and Equity must remain strangers to Election Law unless statutorily embodied. A
Court has no right to resort to them on considerations of alleged policy because policy in such
matters as those, relating to the trial of election disputes, is what the statute lays down, In the trial
of election disputes, Court is put in a straight jacket."
Though the election of a successful candidate is not to be interfered with lightly and the verdict of
the electorate upset, this Court has emphasised in more than one case that one of the essentials of
the election law is to safeguard the purity of the election process and to see that people do not get
elected by flagrant breaches of the law or by committing corrupt practices. It must be remembered
that an election petition is not a matter in which the only persons interested are the candidates who
fought the election against each other. The public is also substantially interested in it and it is so
because election is an essential part of a democratic process. It is equally well settled by this Court
and necessary to bear in mind that a charge of corrupt practice is in the nature of a quasi criminal
charge, as its consequence is not only to render the election of the returned candidate void but in
some cases even to impose upon him a disqualification for contesting even the next election. The
evidence led in support of the corrupt practice must therefore, not only be cogent and definite but if
the election petitioner has to succeed, he must establish definitely and to the satisfaction of the court
the charge of corrupt practice which he levels against the returned candidate. The onus lies heavily
on the election petitioner to establish the charge of corrupt practice and in case of doubt the benefit
goes to the returned candidate. In the case of an election petition, base on allegations of commission
of corrupt practice, the standard of proof is generally speaking that of criminal trials, which requires
strict proof of the charge beyond a reasonable doubt and the burden of proof is on the petitioner and
that burden does not shift. (See with advantage : Nihal Singh Vs. Rao Birendra Singh & Anr (1970Gajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

(3) SCC, 239); Om Prabha Jain Vs. Charan Das & Anr. (1975 (Supp) SCR, 107); Daulat Ram
Chauhan Vs. Anand Sharma (1984 (2) SCR, 419) and Quamarul Islam Vs. S.K. Kanta And Others
(1994 Supp (3) SCC, 5).
By this proposition, however, we should not be understood to mean or imply that the returned
candidate is absolved from his liability to bring forth evidence on the record to rebut the case of the
petitioner and to particularly prove such facts which are within his special knowledge (Section 106
Evidence Act). Though, the nature of allegations in cases alleging corrupt practices are quasi-
criminal and the burden is heavy on him who assails an election but unlike in a criminal trial, where
an accused has the liberty to keep silent, during the trial of an election petition the returned
candidate has to place before the Court his version and to satisfy the Court that he had not
committed the corrupt practice as alleged in the petition and wherever necessary by adducing
evidence besides giving his sworn testimony denying the allegations. However, this stage reaches if
and when the election petitioner leads cogent and reliable evidence to prove the charges levelled
against the returned candidate as, only then, can it be said that the former has discharged his
burden. That necessarily means, that if the election petitioner fails to adduce such evidence which
may persuade the Court to draw a presumption in his favour the returned candidate will not be
required to discharge his burden by adducing evidence in rebuttal. While on this point it will be also
pertinent to mention that the election petitioner has stablish the charge by proof beyond reasonable
doubt and not merely by preponderance of probabilities as in civil action. In Surendra Singh Vs.
Hardayal Singh [AIR 1985 SC 89], this Court held it as "very well settled and uniformally accepted
that charges of corrupt practices are to be equated with criminal charges and proof thereof would be
not preponderance of probabilities, as in civil action, but proof beyond reasonable doubt and if after
balancing the evidence adduced there still remains little doubt in proving the charge its benefit must
go to the returned candidate.' Various tests have been laid down by the High Courts and by this
Court to determine the extent of proof required to establish a corrupt practice. The most well
accepted test however is that the charge must be established fully to the satisfaction of the Court.
While insisting upon the standard of strict proof beyond a reasonable doubt, the courts are not
required to extend or stretch the doctrine to such an extreme extent as to make it well neigh
impossible to prove any allegation of corrupt practice and as was said in Harcharan Singh Vs. Sajjan
Singh [AIR 1985 SC 236] "such an approach would defeat and frustrate the very laudable and
sacrosanct object of the Act in maintaining purity of the electoral process".
We are in respectful agreement with the above view. Some times direct evidence about the
commission of corrupt practice may not be forthcoming or available and in that case, the charge
may be proved by producing circumstantial evidence but the courts, in such cases insist, that each of
the circumstances must be proved individually and all the circumstances put together must point
unerringly only to the hypothesis of the commission of the corrupt practice by the returned
candidate and must not be capable of any other hypothesis consistent with the innocence of the
returned candidate. (See : Quamarul Islam Vs. S.K. Kanta And Others (supra); Raj Narain Vs. Indira
Gandhi (1976 (2) SCR, 347); Ch. Razik Ram Vs. Ch. Jaswant Singh Chouhan and Others (1975 (4)
SCC, 769).Gajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

The election law insists that to unseat a returned candidate, the corrupt practice must be specifically
alleged and strictly proved to have been committed by the returned candidate himself or by his
election agent or by any other person with the consent of the returned candidate or by his election
agent. Suspicion, howsoever, strong cannot take the place of proof, whether the allegations are
sought to be established by direct evidence or by circumstantial evidence. Since, pleadings play an
important role in an election petition, the legislature has provided that the allegations of corrupt
practice must be properly alleged and both the material facts and particulars provided in the
petition itself so as to disclose a complete cause of action.
Section 83 of the Act provides that the election petition must contain a concise statement of the
material facts on which the petitioner relies and further that he must set forth full particulars of the
corrupt practice that he alleges including as full a statement as possible of the name of the parties
alleged to have committed such corrupt practices and the date and place of the commission of each
of such corrupt practice. This Section has been held to be mandatory and requires first a concise
statement of material facts and then the full particulars of the alleged corrupt practice. So as to
present a full picture of the cause of action.
A petition levelling a charge of corrupt practice is required, by law, to be supported by an affidavit
and the election petitioner is also obliged to disclose his source of information in respect of the
commission of the corrupt practice. This becomes necessary to bind the election petitioner to the
charge levelled by him and to prevent any fishing or roving enquiry and to prevent the returned
candidate from being taken by a surprise. (See: Samant N. Balakrishna Vs. George Fernandez and
others (AIR 1969 SC, 1201).
The jurisdiction to try an election petition has been vested in the High Courts. Election petitions are
generally speaking tried by experienced Judges of the High Courts. Those learned Judges have the
benefit of observing the witnesses when they give evidence. Therefore, the appreciation of evidence
by the High Court is entitled to great weight. Generally speaking this Court accepts the findings of
fact arrived at by the High Court after appreciation of evidence. (See Sheodan Singh Vs Mohan Lal
Gautam (AIR 1969 SC 1024). Being the court of First Appeal, however, this court has no inhibition
in reversing such a finding, of fact or law, which has been recorded on a misreading or wrong
appreciation of the evidence or the law, but ordinarily and generally speaking this court does not, as
it ought not to, interfere with the findings of fact recorded by the learned trial Judge of the High
Court, unless there are compelling reasons to do so. It is in the light of the above settled principles,
that we shall consider the materials on the record and the findings of the High Court in respect of
which challenge has been made before us.
As already noticed, the appellants confined their challenge to the findings in respect of some of the
issues only which relate to the commission of corrupt practice of incurring or authorising
expenditure in excess of the prescribed limits within the meaning of Section 123(6) of the Act. It
would, therefore, be appropriate to consider the parameters of the alleged corrupt practice before we
examine the findings and the arguments in respect of the relevant issues.Gajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

Section 77 of the Act provides that 'every candidate at an election shall either by himself or by his
election agent keep a separate and correct account of all expenditure in connection with the election
incurred or authorised by him or by his election agent between the date of publication of the
notification calling the election and the date of declaration of the result thereof, both days inclusive,
Explanation (1) which was introduced by the Amendment Act of 1974 declares that any expenditure
incurred or authorised in connection with the election of a candidate by a political party or by any
other association or body of persons or by any individual, (other than the candidate or his election
agent) shall not be deemed to have been, expenditure in connection with the election incurred or
authorised by the candidate or by his election agent for the purposes of sub- section (1) of Section
77. Sub-section (2) of Section 77 provides that the account of election expenses shall contain such
particulars as may be prescribed and sub-section (3) lays down that the total of the said expenditure
shall not exceed such amount as may be prescribed. Vide Section 78 of the Act the account of
election expenses is required to be lodged with District Election Officer by every candidate at an
election within thirty days from the date of election of the returned candidate. The maximum
amount of election expenditure which may be incurred by the candidates for the parliamentary and
Assembly Constituencies has been prescribed in Rule 90 of the Conduct of Election Rules 1961. In so
far as the Parliamentary Elections are concerned, the said limit is Rs.1,50,000/-. Under Section
123(6) of the Act, the incurring or authorising of expenditure in contravention of Section 77 of the
Act amounts to commission of a corrupt practice. However, every contravention of Section 77 of the
Act does not fall within the mischief of Section 123(6) of the Act. Neither the violation of sub-
section (1) of Section 77 nor the violation of sub-section (2) of Section 77 amounts to the commission
of the corrupt practice under Section 123(6) of the Act. However, Section 77(3) mandates that the
total of the expenditure in connection with the election shall not exceed the prescribed limit and
therefore the provisions of Section 123(6) of the Act are related only to Section 77(3) of the Act. If a
candidate incurs or authorises expenditure in excess of the prescribed limits, he commits the
corrupt practice under Section 123(6) of the Act and his election is liable to be set aside and he also
incurs the disqualification of being debarred from contesting the next election. From a plain reading
of Section 123(6) and 77 including Explanation I to the Section 77 of the Act, it is therefore clear that
in order to be a corrupt practice, the excessive expenditure must be incurred or authorised by the
candidate or his election agent. An expenditure incurred by a third person, which is not authorised
by the candidate or his election agent is not a corrupt practice. In Magh Raj Patodia Vs R.K. Birla,
[AIR 1971 SC 1295] after referring to a catena of authorities even before the inclusion of Explanation
I to Section 77 of the Act by the Amendment Act 58 of 1974, it was emphasised that to prove the
corrupt practice of incurring or authorising expenditure beyond the prescribed limit, it is not
sufficient for the petitioner to merely prove that the expenditure beyond the prescribed limit had
been incurred in connection with the election of the returned candidate, but he must go further and
prove that the excess expenditure was authorised or incurred with the consent of the returned
candidate or his election agent. In Raj Narain Vs. Indira Gandhi (1976 (2) SCR 347) this Court
reaffirmed the above view and taking note of the Amendment Act 58 of 1974, opined that voluntary
expenditure incurred by friends, relations, or sympathisers of the candidate or the candidates'
political party are not required to be included in the candidate's return of expenses, unless the
expenses were incurred in the circumstances from which it could be positively inferred that the
successful candidate had undertaken that he would reimburse the party or the person who incurred
the expense. It is not enough to prove that some advantage accrued to the returned candidate orGajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

even that the expenditure was incurred for the benefit of the returned candidate or that it was within
the knowledge of the returned candidate and he did not prevent it, to clothe the returned candidate
with the liability of committing the alleged corrupt practice. Noticing that during an election, the
sponsoring or supporting political parties as well as friends, sympathisers and well-wishers do
sometimes inour expenditure not only without the consent of the concerned candidate but even
without his knowledge this court opined that the successful candidate cannot be clothed with all
such expenses to suffer the disqualification.
In P.Nalla Thampy Vs. Union of India [AIR 1958 SC 1133], a Constitution Bench of this Court
examined the validity of Explanation (1) to Section 77 (1) of the Act (introduced in 1974) and
Chandrachud CJ (as he then was) while upholding its constitutionality, observed:
"In any democratic system of Government, political parties occupy a distinct and unique place. They
are looked upon as guardian angles by their members., though, occasionally, they fail to discharge
the benign role of guardian, leave alone the angelic part of it. It is through them that the generality
of the people attempt to voice or ventilate their grievances. Considering, also the power which they
wield in the administration of Governmental affairs, a special conferment of benefits on them in the
matter of mobilities governing the election process cannot be regarded as unreasonable or
arbitrary."
The Constitution Bench thus emphatically laid down that unless the expenditure is in fact incurred
or authorised by the candidate or his election agent, he cannot be saddled with that expenditure. Of
course a candidate cannot be permitted to place his own funds in the power or possession of a
political party, an association, or some other persons or individuals for being spent on his behalf and
then plead for the protection under Explanation (1) to Section 77 of the Act. Where the election
petitioner successfully establishes that the funds were provided by the returned candidate, it would
be immaterial as to who actually made the payments, which ought to have been included in the
return of election expense. It is not "whose hand it is that spends the money". The essence of the
matter is "whose money it is" that has been spent. In order that explanation (1) to Section 77 of the
Act may apply, therefore, it must be proved that the source of the expenditure incurred was not out
of the money of the candidate or his election agent.
Respondent No. 1 lodged the account of his election expenses with the District Election Officer on
12th July, 1991, supported by 45 vouchers disclosing the total expenditure of Rs. 72,421.85. The
appellants in the election petition pleaded that Respondent No. 1 had not kept a true and correct
account of the expenditure incurred and/or authorised by him or by his election agent in relation to
the elections held on 12th June, 1991 and had exceeded the prescribed limit and thereby committed
the corrupt practice under Section 123(6) of the Act. The appellants alleged that a huge amount of
expenditure incurred in connection with the election of Respondent No. 1 was falsely shown to have
been incurred by the political party and other associations, persons or individuals, though in fact the
expenditure had been incurred and/or authorised by Respondent No. 1 himself or by his election
agent. It was asserted that Respondent No. 1 had placed his own funds in the power and possession
of the political party, organisations and individuals for being spent in connection with his election in
order to circumvent the law and escape from the consequence of incurring and authorisingGajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

expenditure beyond the prescribed limits. It was alleged that Respondent No. 1 had incurred an
expenditure for the purpose of his election during the period 25.4.1991 to 16.6.1991 to the tune of Rs.
38,30,375.50, as against the permissible limit of Rs. 1,50,000.00. The statement showing the
expenditure allegedly incurred and authorised by Respondent No. 1 was given in para 2.24 of the
election petition. At the trial, however, items No. 2, 8, 9 and 14 out of that statement were not
pressed. The High Court, however, in para 200 of the judgment found that besides the expenditure
disclosed in the return of expenses filed by Respondent No. 1, he had also incurred the following
expenses, which had been suppressed:
Rs. 17,900.00 for the amount paid to Raj Automobiles; Rs. 1,320.00 for the
advertisement in the Tarun Bharat dated 28.4.1991.
Rs. 7,000.00 for the advertisement in Tarun Bharat -
Election Special.
Rs. 9,100.00 for the advertisement in Lokmat Dt.
12.5.1991 (Sharad Pawar Mitra Mandal) Rs. 22,900.00 in view of the findings
recorded on issue No. 5(b) (vi) & (vii).
---------------------
Total : Rs. 58,220.00
---------------------
and adding the amount of expenditure suppressed i.e. Rs. 58,220.00, to the declared expenses, the
High Court found that the return of expenditure filed by Respondent No. 1 should have been for a
sum of Rs. 1,30,641.85. However, since even that amount fell short of the permissible expenditure of
Rs. 1,50,000.00, it was found that Respondent No. 1 had not committed the corrupt practice within
the meaning of Section 123 (6) of the Act. Whereas the appellants have challenged the findings of
the High Court on some of the issues, as already noticed, the returned candidate, Respondent No. 1,
has also filed cross objections challenging the finding of the High Court in respect of the addition of
Rs. 58,220.00.
ISSUE NO. 4 (V) :
Though issue No. 4 concerns five items, it is only item No. (v) which has been pressed
before us by the learned counsel for appellants. The findings of the High Court on
items (i) to (iv) of Issue No. 4, which have been decided against the appellants have
not been challenged before us and therefore, we confirm the findings of the High
Court regarding those items. So far as Item No. (v) is concerned, it relates to the
payments made by respondent No. 1 to M/S Raj Automobiles for purchase of fuel etc.Gajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

According to the appellants, Respondent No. 1 in his return of expenditure submitted
to the District Election Officer had, under Items 31 to 34, shown the expenditure
incurred by him on account of purchases of petrol etc. from M/s. Raj Automobiles,
Civil Lines, Nagpur under bills No. 401 to 404 for the period 1.5.1991 to 12.6.1991 but
had failed to include the cost of 1180 litres of petrol also allegedly purchased by the
returned candidate from Raj Automobiles over and above the quantity of petrol
shown to have been purchased by Respondent No. 1 under bill Nos. 401, 402 and
403, as disclosed in the return of expenses filed by him for the period 1.5.1991 to
12.6.1991. The appellants specifically pleaded that petrol which had been shown to
have been purchased by respondent No. 1 was for three vehicles : (i) MH-31-G-1722;
(ii) MH-02-2200; and (iii) 7069 but the cost of purchase of 1180 litres of petrol had
been suppressed. In his written statement, Respondent No. 1, admitted that under
items 31 to 34 in his return of expenditure, he had shown the expenditure incurred by
him on account of the purchase of petrol from M/s. Raj Automobiles during 1.5.1991
to 12.6.1991 but denied that Raj Automobiles, Civil Lines, Nagpur had sold 1180 litres
of petrol over and above the quantity of petrol shown to have been purchased by him
under bill No. 401, 402, 403 filed alongwith the statement of account. It was pleaded
that the allegation was vague and based on speculation and that no particulars had
been given of the basis on which it was alleged that he had purchased 1180 litres of
petrol at the cost of Rs.17900/- in addition to what had been disclosed by him.
The appellants examined PW 36, Shankar Rao Gadge, who was working as an Accountant with Raj
Automobiles at the relevant time. He deposed that a credit account had been started for Respondent
No. 1 at the instance of Mrs. Shalini Bai Meghe (wife of respondent No. 1 and proprietor of Raj
Automobiles) and credit slip books had been issued to Respondent No. 1. That whenever petrol or
oil was purchased by or for respondent No.1, a copy of the credit slip used to be given to M/s. Raj
Automobiles and its counterfoil was retained by the customer. The original credit slips were lateron
returned to the first respondent alongwith the bill. The witness after referring to the record deposed
that fuel had been supplied to respondent No. 1 for car Nos. MH-31- 1722, MH-02-2200,
MK-1/1022 besides vehicle No. 1422 and 7069 during 1.5.91 to 16.6.91. He also proved a cash memo
dated 16.6.1991 for bill No. 2503 (Ex. 681) for sale of 10 liters of petrol sold to respondent No.1. The
witness admitted that receipt No. 843 dated 12.7.1991 (Ex. 680) was in respect of bill Nos. 401 to
405 for the consolidated amount of Rs. 12,152.40 and went on to say that the payments had been
made by a cheque by respondent No.1. According to the witness, except the petrol which was sold
under the cash memo Ex.680 all other petrol and oil sold to Datta Meghe was worth Rs. 12152.40 p.
All these transactions are carried over and entered in their accounts. "We did not sell either oil or
petrol besides these to Datta Meghe" was the categorical statement made by PW36 Gadge.
The appellants also examined Shri Prakash Baidya PW33. This witness earlier used to be a partner
in M/S Raj Automobiles till 1991 where after he ceased to have any concern with Raj Automobiles.
During the parliamentary elections, he was the General Secretary of the East Nagpur Assembly
Constituency for BJP, the party to which both the appellants as well as respondent No. 2 belonged
and was in charge of that area. He deposed that it is necessary to put one litre of oil if the
consumption of petrol is 100 to 125 liters and that in one litre of oil, the run of the vehicle would beGajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

about 1000 kms. on an average consumption at the rate of 10 kms per litre of petrol. During the
cross- examination, he admitted that he had deposed about the ratio of consumption of petrol and
oil from his experience and not from any book and also conceded that if an engine is old it would
consume more oil as well as more petrol and that the oil-petrol ratio varies according to the horse
power of the engine and its model and that if the chamber of the vehicle leaks, the consumption of
oil would be more because of leakage and not on account of the consumption. He admitted that he is
not an automobile engineer.
Respondent No. 1, the returned candidate in his statement admitted that his wife owns Raj
Automobiles and that petrol and oil were bought by him on credit from Raj Automobiles, except for
one cash transaction on 16.6.1992 for Rs. 147.40 (Ex. 681). He went on to add that he did not buy
petrol from any other petrol station except Raj Automobiles during the election period and that the
credit slips which used to be issued to Raj Automobiles were received back by him with the bill from
Raj Automobiles and after the bills were paid, the credit slips were destroyed. During his
cross-examination, he stated that he had three diesel and four petrol cars with him for his election
and that he had hired some motor cars and auto-rickshaw on 19, 20 and 21 May and 8, 9, 10 June,
1991 through Prince Travels. He disclosed the names of the parties from whom he had procured
those vehicles and asserted that besides Car No 7069 which he had procured from Nagar Yuvak
Sanstha, he used the cars of the workers who used to come and see him. According to him vehicle
No.7069 is NE and the model was 3/4 years old.
For coming to the conclusion that the returned candidate had purchased more fuel than the one
shown by him in his return of expenditure,the High Court relied upon the petrol-oil ratio as deposed
to by pw Baidya. It was found that the amount of oil admittedly purchased by the returned candidate
as per bill No.404 when considered in the light of the total fuel purchased would show that, much
more fuel would have been purchased to consume the quantity of oil purchased as per bill No.404. It
was found by the High Court on the basis of the calculations made that the returned candidate had
suppressed an expenditure to the tune of Rs.18,277.60 but since the appenllants had asserted that
there had been suppression of the use of 1180 litres of petrol worth Rs.17900/-only,therefore only
that much of expenditure could be added to the disclosed expenses of the returned candidate. The
High Court while entering into the calculations did not base itself on the oil-petrol ratio but
multiplied the consumption of petrol for one of the cars (MH-31G-1727), which was admittedly used
by respondent No.1 by 3 and drew an inference that for the other 3 cars also. the same amount of
petrol would have been consumed and thus found that the returned candidate would have
purchased more petrol worth atleast Rs.18277.60.
In the election petition a specific allegation had been made to the effect that the returned candidate
had purchased 1180 litres of petrol in addition to what had been disclosed by him from Raj
Automobiles. In the verification of the election petition,the appellants had disclosed the source of
information with regard to the contents of para 2.10 as based on the information received from Shri
Baidya PW. In the affidavit filed in support of the allegations of the said corrupt practice, the source
of information was also disclosed to be Shri Baidya PW. However, PW53, Shri Prakash Baidya, in his
deposition in court did not state that he had conveyed any information to the election petitioners
about the alleged excess purchase of 1180 litres of petrol by Respondent No.1 from M/s. RajGajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

Automobiles apart from the quantity of fuel purchased by him as disclosed in the return of election
expenditure. In his statement, he only speculated about the excess purchase of petrol on the basis of
oil-petrol ratio, based on his experience even though admittedly he is not an expert,not even an
automobile engineer. In the election petition nothing was said about the petrol-oil ratio as the basis
from which the appellants had inferred that 1180 litres of petrol had been purchased by the returned
candidate in addition to the quantity of fuel shown to have been purchased by him from Raj
Automobiles. Except for giving same figure of '1180' litres of petrol alleged to have been purchased
by respondent No.1, the appellants did not give any other facts or particulars in the election petition
for alleging purchase of 1180 litres of excess petrol and left the matter totally vague. Even in his own
statement,appellant No.1, did not disclose the basis for arriving at the figure of '1180'. An attempt
was apparently made to get sustenance from the testimony of Baidya PW53, admittedly a partyman
of the appellants and respondent No.2, to support the allegations made in the petition on the basis
of oil-petrol ratio. Even in that behalf we find that no evidence was led by the appellants to show as
to what were the models of the vehicles which were used by the returned candidate and the extent to
which all those vehicles had been used during the elections. The returned candidate, R1W1, was not
even asked a single question regarding the extent of the use of the different vehicles to determine the
mileage- run in respect of each one of those vehicles. No explanation was even sought from him
regarding the oil-petrol ratio or as to why so much of oil had been purchased for so little fuel. In this
connection,it is also relevant to note that PW33 Shri Vijay Rathi, the Accountant of Raj
Automobiles, had been summoned by the appellants alongwith the record presumably to prove the
excess sale of 1180 litres of petrol, apart from the fuel shown in bill Nos. 401, 402, 403 and 404 but
the record was never got exhibited and there is , thus, force in the submission of Mr Manohar,
learned counsel for the returned candidate that a presumption should be drawn against the
appellants to the effect that the summoned record being inconvenient was not got exhibited by the
appellants. The observation of the High Court, under the circumstances, to the effect that Raj
Automobiles had suppressed the record does not appear to be well founded as the summoned record
had been brought by PW33 to the court but the party chose not to get the same exhibited and no
fault can be found with Raj Automobiles The High Court, as already noticed, found the suppression
of Rs.18,277.60 on the calculation based on the quantity of petrol purchased for vehicle No.
MH-31-G-1722. The total petrol purchased for that vehicle was shown as 470 litres and the amount
of oil purchased for that was shown to be 22 litres.
Obviously, the ratio of oil-petrol as deposed to by Shri Baidya PW53, does not appear to have any
relation to the petrol-oil ratio for the said vehicle. On the basis of the ratio as deposed to by PW53,
more than 50 litres of oil should have been consumed for this vehicle. The High Court, as already
observed, calculated the cost of 470 litres of petrol as Rs.6927.80 and than multiplied it by 3 and
arrived at the figure of Rs.20,783.40 and deducting an amount of Rs.2505.80, which had been
shown to be cost of the petrol used for the two other vehicles used by the returned candidate,
determined the suppression at Rs.18277.60, but since the election petitioners had alleged
suppression of the use of 1180 litres of petrol worth Rs.17,900/- only, the High Court fastened the
liability on the first respondent not for the amount of Rs.18277.60 but Rs.17900/- only In our
opinion, the approach of the High Court was wrong and it fell into a complete error in making these
calculations which are not even based on guess work but are totally conjectural in nature. The type
of exercise done by the High Court had neither any factual foundation in the election petition norGajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

even in the evidence. The High Court made out a new case neither the one pleaded by the election
petitioners nor the one pleaded by the returned candidate. It was not a permissible course for the
High Court to adopt while dealing with the allegation of commission of a corrupt practice in an
election petition. Since, no evidence was led by the election petitioner about the alleged purchase of
excess of 1180 litres of petrol, the High Court ought to have found the issue against the appellants.
The finding of the High Court is, not on any evidence. Except PW1 who made a vague statement to
the effect that he had seen the vehicles pleaded in the election petition, on the roads throughout
during the election, without indicating when, where and which vehicle, on other evidence was
produced to show the extent to which the other vehicles in question had been used during the
election by Respondent No.1 or his election agent or by any other person with the consent of
respondent No.1 or his election agent. The election petitioner could have examined withnesses from
different segments of the constituency to depose, if they had seen the returned candidate or his
election agent in that area in any particular vehicle and then number of occasions when the returned
candidate had been so seen in different localities in the same or different vehicles to show the extent
of run of those vehicles by bringing out the total distance likely to have been covered. No such
evidence was led, though the production of such evidence was not an utter impossibility. That
vehicle No.1722 (which was made the basis for calculation of total run by the High Court) was more
extensively used, than the other vehicles is a reasonble possibility which cannot be ignored. It was
incumbent upon the appellants to prove the sale of 1180 litres of petrol in favour of Respondent No.1
by Raj Automobiles as alleged by them in the election petition, by leading cogent and satisfactory
evidence and they miserably failed to prove the said charge, let alone beyond a reasonable doubt.
Even the mathematical calculation made by the High Court also appears to be incorect but we need
not detain ourselves to point out the same because of the infirmities pointed out by us in the
approach of the High Court. The finding of the High Court on Issue No.4 (V), therefore, cannot be
sustained and we set aside that finding and hold that the appellants have failed to prove Issue No.4
(V) and consequently the addition of Rs.17,900.00 in the return of expenditure of respondent No.1
was not justified and the said amount shall have to be excluded. The cross-objection to that extent
succeeds and is allowed.
ISSUE NO.5 (b) (i) & (ii) The allegations of the election petitioners which led to the framing of Issue
No.5 (b) (i) and (ii) are contained in paragraphs 2.11 to 2.14 of the election petition and concern the
issuance of voter cards to 1243382 voters in the constituency by the returned candidate after getting
the same printed at a cost of Rs.2,25,000/- from Shakti Offset Works, appealing to the electorate to
vote for the returned candidate. Besides, Respondent No.1 is also alleged to have got printed posters
of different sizes, namely, one lakh posters of 20"x30"; one lakh fifty thousand posters of 18"x23"
and seventy five thousand posters of 15"x20" propogating his candidature and these posters of
different sizes, on an average of about 300 posters were exhibited at each of the 1250 polling booths
in the constituency. It was alleged that in all 3,25,000 posters were got printed by the returned
candidate between 25.4.91 and 21.5.91 after incurring an expense of Rs.3,40,250.00 for the printing
of the said posters and the first respondent did not include in the return of his election expenses
either the amount of Rs.2,25,000/- being the cost of the voters cards or Rs.3,40,250/- being the cost
of the posters. In the written statement, while admitting that the appeal made in the voter cards was
to cast votes in favour of the first respondent and that the posters were also published for the
furtherance of the prospects of the election of the first respondent, the returned candidate denied toGajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

have incurred any expenditure at all on printing and distribution of either the voter cards or the
posters. According to the first respondent, he learnt about the printing of about four lakh voter cards
by the Nagpur City District Congress Committee at its own expense and also came to know that
some posters had been got printed and published by Nagpur City District Congress Committee while
some more posters had been supplied by Congress (I) through its sub-organisations,at various
levels, as per the past practice and as per the practice being followed by the other parties also for
distribution and that he had neither authorised nor incurred any expense for the said cards and
posters and that the same had been published and distributed without his knowledge let alone his
consent.
The appellant Bapat PW1 in his statement deposed that voter cards had been issued about eight days
prior to the poll to every voter as mentioned in the voters list Ex.74 and according to his estimation
the cost of printing of the voter cards would be Rs.2,25,000/-. In the course of his statement he,
however, admitted that in the case of respondent No.2, Shri B. L. Purohit voter cards had also been
issued to the voters but went on to say that the same had been got printed by the BJP at its own
expense and were distributed by the workers of the B.J.P. without any expense being incurred or
borne by respondent No.2 himself. With regard to the publication of the posters, he deposed that the
posters had been used by the returned candidate extensively. Specimen of some of the posters were
produced as Ex.75 to Ex.78. PW1, asserted that the expenditure for the printing of voter cards and
the posters in the case of the returned candidate was borne by the first respondent himself and not
by anyone else.
The appellants in support of their case examined PW41 Suresh Deotale President of Nagpur Gramin
Congress, PW42 Baliram Dakhne Cashier, PW43 Baburao Zade, Secretary of the Gramin Congress
and PW46 Marotrao Kumbhalkar, Treasurer of the Nagpur District Congress Committee. The
evidence of all these withnesses however reveals that the Congress Committee had incurred the
expenditure for publication of advertisements, voters cards, posters etc. In connection with the
election of the returned candidate. These witnesses, however, admitted that the Congress party did
not maintain any account in respect of election expenses either for the local bodies, Legislative
Assemblies, or Parliament. That the work regarding the election propaganda and incurring of
election expenses used to be entrusted to one or the other of the office bearers by the Party. In the
case of the election of Datta Meghe, the witnesses deposed that the job had been entrusted to PW43
Baburao Zade. These witnesses further deposed that money for undertaking election expenses was
collected by the Congress Party in the form of collection coupons. That a part of the election coupons
were supplied by the All India Congress Committee in the demonination of Rs.2/- and Rs.5/- while
the rest were printed at the local levels. No account was, however, maintained of those coupons. The
posters were also supplied by All India Congress Committee and the Provincial Congress
Committee. PW43, Baburao Zade stated that Shakti Offset was one of the printers who had
undertaken the printing job and that the orders for printing work had been placed by him on Shakti
Offset through Shri Parshonikar. He admitted that he was a sitting MLA at the time of the election.
He however was not aware if Parshonikar was the Secretary of Nagpur Shahr Zila Congress
Committee. From The testimony of PW41 President of Nagpur Gramin Congress it emerges that the
manner of collection of funds for election purposes was through sale of coupons. The witness denied
that not maintaining of any accounts of those coupons, was a practice devised only for the presentGajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

election but asserted that it was a practice which used to be followed in all earlier elections also. He
went on to add and that when Shri Purohit, respondent No.2, was a Congress Candidate in the
Parliamentary elections of 1984 and 1989, the expense for his election propaganda had been
incurred by the Congress Committee also by raising funds through sale of coupons and that no
account had been kept either of the coupons or even of the total expense incurred during those
elections. He was emphatic that the Congress Committee did not maintain any account in respect of
the expenditure incurred by the party in connection with the elections to the local bodies, Legislative
Assembly or Parliamentary elections. The evidence of PW42 is almost on the same lines as that of
PW41 and PW43 in all material particulars. This witness further deposed that he had learnt from
PW43 Baburao Zade that an amount of Rs. 40000/- had been paid to Parshionikar towards the
election expenses and that some posters had been issued by the All India Congress Committee also.
The pass book of the Gramin Congress which was produced by the witness, revealed that after the
withdrawal of an amount of Rs.250/- on 26.9.90, the next withdrawal was only on 10.4.92 of
Rs.3500/- and that no other amount had either been deposited or withdrawn by the party from the
Bank. The evidence of the witnesses to the effect that funds for election expenses were collected by
sale of coupons and donations and no account was maintained of the receipt and expenses, thus,
receives corroboration from the Bank Pass Book of the Gramin Congress. The testimony of PW43
which supports the testimony of PW41 reveals that about 30000 to 40000 voter cards besides some
handbills worth Rs.2000/- to 3000/- had been got printed by the Party through Shakti Offset
Works. Explaining the reason for not maintaining any account of receipt and expense, the witnesses
stated that since persons who bought the coupons or gave donations were mostly businessmen, who
generally paid the amount by cash, and did not want any record of the payment made by them to be
kept, the accounts were not maintained. PW44 Vishnu Dutt Misra, Vice-President of the Nagpur
Nagar Zila congress and PW45 Awari, President of Nagpur Nagar Congress Comittee deposed on the
same lines as PW41 to PW43. PW46 Marotrao Kumbhalkar, the Treasurer of the Party, further
stated that the responsibility for the election propaganda of the returned candidate in the present
case had been placed on Shri Parshonikar, who was made the Secretary Incharge of the elections of
Respondent No.1 by the Party. According to PW46. an amount of about Rs.14 lakhs had been
collected through donations and sale of coupons, out of which Nagar Congress Committee had also
got coupons worth about Rs.7 lakhs printed and the remaining coupons worth Rs.7 lakhs had been
received from the All India Congress Committee. The job for giving advertisement to the
newspapers etc. on behalf of various Congress Committees and organisations had been entrusted to
Shri Parshionikar. He admitted that even in 1989 when respondent No.2, Banwarilal Purohit, had
contested the election as a Congress candidate, an amount of about Rs.12 lakhs to Rs.14 lakhs had
been collected through sale of coupons and donations and the same had been spent by the Party for
the furtherance of the election of Respondent No.2, Banwarilal Purohit, without maintaining any
account of receipt and expense.
Ashok Thakre PW54, the Manager of Shakti Offset Works deposed that none of the candidates had
approached him personally for placing orders for printing work. He disclosed the names of the
persons who had aproached him on behalf of different candidates to place orders in connection with
the printing of posters of different sizes, as reflected in Ex.75 to Ex.78 and asserted that orders had
been placed for the same by Shri Parshonikar and the posters had been got printed by Gramin
Congress for which purpose PW43 had also approached him. He went on to state that ShriGajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

Parshionikar had approached him on behalf of Nagar Zila Shehar Congress and that the printing
work was got done by Shri Pande on behalf of the Yuvak Congress. PW54 gave details of the various
posters printed by him and by reference to ledger Ex.738/9, stated that an amount of Rs.50000/-
has been shown to have been credited to the account by the President Nagar Shehr Congress
Committee on 13.5.91 under five different receipts, Ex.744 to 748, for Rs.10000/- each, totally
Rs.50,000/- He then deposed that a further sum of Rs.50000/- had been received by the press from
Nagpur Zila Congress Committee, Gramin-Vibhag and that a sum of Rs.50000/- had also been
received from Zila Congress Committee (Yuvak) on 6.6.91 and 23.10.91. An amount of Rs.10000/-
was received from Nagpur Zila Congress Committee (I) Gramin also. That all these amounts were
spent for the printing work entrusted by various Congress Committees and organisation of the
propaganda material for the election of the returned candidate. The returned candidate in his
deposition denied to have authorised or incurred any expense as alleged by the election petitioner in
connection aither with the printing of voter cards or the posters etc. and maintained that he had not
even taken the responsibility to reimburse the expenditure on behalf of any one and that no
expenditure in that behalf had been incurred by any one with his consent either.
After considering the evidence in its totality in the light of the pleadings in the election petition, we
find that the election petitioner has not adduced any cogent, satisfactory or reliable evidence to
establish that the expenditure of Rs.2,25,000/- and Rs.3,40,250/- as alleged in the petition had
been incurred and/or authorised by respondent No.1 for the printing of voter cards and the posters.
On the other hand it emerges, that the entire expenditure on that behalf was undertaken and borne
by the Congress Party and others and that it was so done as per the past practice also.
The argument of Dr. Ghatate however is that Thakre PW54, the Manager of Shakti Offset Works
who denied the receipt of any amount from the returned candidate could not be relied upon because
there has been some tampering with the record, including the ledger, and therefore it should be
inferred that he was helping the returned candidate. It was submitted by the learned counsel that
even though PW54 was produced and examined by the election petitioner, they were not bound by
his entire evidence and that once it was established that the record had been tampered with, the
onus would shift to the returned candidate to show that he was not responsible for the tampering or
that the tampering had not been done at his instance. This argument is fallacious and does not
impress us at all. There is no material brought on the record to even suggest let alone establish that
the tampering had been done in the record at the instance of the returned candidate. No sound
foundation had been laid either in the petition or in the evidence which may justify this court to
raise the inference, which the learned counsel invites us to draw. A similar argument had been
raised on behalf of the appellants in the trial court also and the learned trial Judge found that the
allegation of the tampering of the record by Shakti Offset Works at the instance of the returned
candidate had not at all been proved, much less satisfactorily. The trial court rightly found that the
practice followed by all political parties for printing of voter cards and posters had always been
much similar and the amounts for the said purpose used to be spent by the political parties by sale
of coupons and by receiving donations and even when respondent No.2 had contested the election
as a Congress candidate the same practice had been followed. The election petitioners have failed to
establish any link between the alleged expenses and the returned candidate for printing and
distribution of voters cards and posters and have not brought any circumstance on the record toGajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

show that the returned candidate had any hand in the tampering of record or even that the
tampering of the record was done for the benefit of the returned candidate only.
We wish, however, to point out that though the practice followed by political parties in not
maintaining accounts of receipts of the sale of coupons and donations as well as the expenditure
incurred in connection with the election of its candidate appears to be a reality but it certainly is not
a good practice. It leaves a lot of scope for soiling the purity of election by money influence. Even if
the traders and businessmen do not desire their names to be publicised in view the explanation of
the witnesses, nothing prevents the political party and particularly a National party from
maintaining its own accounts to show total receipts and expenditure incurred, so that there could be
some accountability. The practice being followed as per the evidence introduces the possiblity of
receipts of money from the candidate himself or his election agent for being spent for furtherance of
his election, without getting directly exposed, thereby defeating the real intention behind
Explanation I to Section 77 of the Act. It is, therefore, appropriate for the Legislature or the Election
Commission to intervene and prescribe by Rules the requirements of maintaining true and correct
account of the receipt and expenditure by the political parties by disclosing the sources of receipts as
well. Unless, this is done, the possibility of purity of elections being soiled by money influence
cannot really be ruled out. The political parties must disclose as to how much amount was collected
by it and from whom and the manner in which it was spent so that the court is in a position to
determine "whose money was actually spent" through the hands of the Party. It is equally necessary
for an election petitioner to produce better type of evidence to satisfy the court as to "whose money
it was" that was being spent through the party. Vague allegations and discrepent evidence may only
create a doubt but then the charge of corrupt practice cannot be held to be proved on mere lurking
suspicion or doubts.
Howsoever, undesirable and objectionable the practice might be, the fact remains that the evidence
led by the election petitioners in this case does not establish the charge levelled by them at all. In the
absence of any cogent, reliable, satisfactory and trustworthy evidence to show that the respondent
No.1 or his election agent had incurred or authorised the expenditure as alleged in the petition, the
trial court rightly found the issue against the election petitioner and we find no reason to take a
different view. We therefore, confirm the findings of the High Court on the said issue.
ISSUE 5 (B) (V) In para 2.20 of the election petition it has been pleaded that respondent No.1 had
sent personal inland letters to all the voters residing within the constituency and the appellants had
calculated the price of each such letter as Rupee One, inclusive of printing and postage. Two of such
letters, Annexures 13 and 14, containing the residential address of respondent No.1 allegedly
received by Vijay Shinde and Vinayak Gode PW49 were annexed with the election petition. It was
alleged that respondent No.1 had made an appeal through the inland letters to the voters to cast
their vote in his favour on 12.6.91. It was further stated that though the letters were shown to have
been sent by Sarva Dharma Samajik Sangathan, the expenditure for the same was in fact authorised
and incurred by respondent No.1 himself. It was pleaded that there were 1240830 voters in the
constituency and, therefore, respondent No.1 was alleged to have incurred an expenditure of
Rs.12,40,830/- on the inland letters and he had not shown the expenditure incurred by him in that
behalf in the return of expenditure filed by him and if the said amount is included, it would showGajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

that the returned candidate had incurred and authorised expenditure beyond the prescribed limits
and thus committed the corrupt practice under Section 123 (6) of the Act. In the written statement,
the returned candidate denied the allegations and styled the same as imaginary and baseless. He
denied to have sent any letter to Vijay Shinde and Vinayak Gode, Annexure 13 and 14 respectively or
to anyone else in the constituency. The allegation that he had incurred an expenditure of
Rs.12,40,830/- was vehemently denied. Respondent No.1 stated that according to the information
received by him after the election, the Sarva Dharma Samajik Sangathan had got printed about two
thousand letters similar to Annexure 13 and 14 and issued the same without his approval or consent
and the entire expenditure must have been borne by the Sangathan itself since it was neither
authorised nor incurred by him or by his election agent. It was stated that the allegation in the
paragraph were vague and general in nature and lacked essential ingredients and particulars and the
assention that all the voters in the constituency had received the letters from respondent No.1 was
based on speculation and conjectures and not on facts.
In the original written statement filed by the returned candidate in reply to para 2.20, it appears
that while he denied the "sending" of the inland letters identical to Annexures 13 and 14, there was
no specific denial made by him regarding his signatures allegedly appearing on those letters. In the
amended written statement, a specific denial was also incorporated stating that the respondent No.1
had not signed those letters and that inadvertantly it had been omitted to be mentioned in the
earlier written statement, while denying the sending of the inland letters. Thus, in the amended
written statement there was denial both, about the signatures as well as the sending of the letters by
the first respondent to the voters. Respondent No.1 also denied to have incurred or authorised any
expenditure in connection with the printing and postage of those inland letters.
Appellant No.1 Bapat, appearing as PW1 in his statement asserted that each one of the voters in the
constituency had received such an inland letter from respondent No. 1 but admitted during his cross
examination that he had no idea whether the letters had actually been signed by the first respondent
or by someone else. The petitioner also examined Shri JD Kotwal PW56 as the Hand-writing Expert
to identify the signatures of Respondent No. 1 on Annexures 13 and 14 (Ex.79 and 80), and to
compare the same with the admitted signatures of the first respondent. The Hand-writing Expert
PW56, however, did not support the case of the election petitioner and deposed that no opinion
could be expressed regarding the authorship or otherwise of the disputed signatures on Ex.79 and
80 (Annexure 13 and 14). With the denial by respondent No.1 that he had neither signed those
letters nor sent any such letters to the electorate and the evidence of the Hand-writing Expert PW56,
the appellants must be held to have failed to prove that the letters like Annexures 13 and 14 were
signed by respondent No.1 or that he was responsible for sending those letters to the electorate. The
argument of Dr. Ghatate that even if the letters had not been signed by respondent No.1, but since
the same had been sent as an appeal to vote for him, it should be presumed that he was the author
and sender of the letters, does not appeal to us. The court can only decide the case on the basis of the
evidence led and not on what ought to have been led. In the instant case, the election petitioners
have failed to examine any witness to show that the letters (like Annexure 13 and 14) had in fact
been sent by respondent No.1 to the electorate. The letters were, on the face of it, sent by the
Sangathan. No evidence has been led to show that the money spent by the Sangathan had been
provided by respondent No.1 either or that the Sangathan was a non-existant body. The allegationGajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

has remained totally unsubstantiated. It was certainly not obligatory for the returned candidate
under the circumstances, to have produced any witness from the Sangathan to prove that Sangathan
had sent the letters on its own or that it had also incurred the expenditure itself. Since, the case of
the returned candidate categorically had been that those letters were neither signed by him nor sent
by him nor did he incur any expenditure in respect thereof, it was for the election petitioners to
establish the charge by leading reliable and satisfactory evidence. The evidence of appellant Bapat
PW1, to the effect that he had made inquiry from the Charity Commissioner and learnt that there
was no such Sangathan registered with the Charity Commissioner, to urge that the Sangathan was a
`fake' organisation and was not a genuine society, ignores the fact that the registration of such a
Sangathan is not necessarily to be done only with the Charity Commissioners. The petitioner
admittedly made no inquiry from any other quarter to find out whether or not the Sangathan was in
fact in existence or not. The intrinsic evidence of the document shows that the letters were sent by
the Sangathan and keeping in view the evidence of the handwriting expert, it appears that the letters
bore the name of `Datta Meghe' and not his signatures. The petitioner could have produced some
witness from the Sangathan to show that no such letters had been sent by the Sangathan. The
petitioners did not even summon a witness from the Sangathan alongwith the record. Had it been
done and if the summons could not be served because of the alleged non-existence of such a
Sangathan, it may have been possible for the petitioner to argue that the Sangathan was a fake
organisation and that an inference may be drawn that the letters had been sent by respondent No.1
at his expense but no such inference can be drawn in favour of the appellants in view of the facts and
circumstances existing on the record. Respondent No.1 had disclosed the name of Shri Bhasme as
one of the officers of the Sangathan in his testimony and the appellants should have sought
permission of the Court to summon Shri Bhasme at that stage atleast but they did not do so for
reasons best known to them. We are unable to agree with Dr. Ghatate, that the evidence should have
been led by the returned candidate to prove that actually the letters had been sent by the Sangathan
after incurring the expenses itself and the petitioners should not be expected to lead such evidence.
The onus to prove the charge was on the election petitioners and in the absence of any satisfactory
evidence adduced to discharge that onus, the returned candidate was under no obligation to prove
that he was not responsible for committing the corrupt practice. Again, it is not the case of the
appellants that the expenditure had been incurred by the Sangathan, with the consent of the
returned candidate or his election agent nor is it their case that the returned candidate had
undertaken to reimburse the expenditure incurred by the Sangathan. The trial court, in our opinion,
after properly considering and appreciating the evidence rightly found that there was no evidence on
the record to support the plea that the first respondent had spent the amount as alleged on the
postage and printing of the inland letters of the type, Annexure 13 and 14 (Ex.79 and 80) or that he
had sent those letters to every voter in the constitutency. From the material on the record, there is
no scope even to raise a strong suspicion against the first respondent in that behalf. The appellants
appear to be labouring under the wrong impression that once they make an allegation against the
returned candidate, their responsibility is over and it is for the returned candidate to prove his
innocence. It is against the essential principles of election law. At the risk of repetition it may be
stated that where allegations of corrupt practice are alleged, it is for the election petitioners to prove
the charge against the returned candidate beyond a reasonable doubt to the satisfaction of the court.
The obligation of the returned candidate to rebut the allegations by leading evidence arises only
after the election petitioners have led dependable evidence in support of the charge of corruptGajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

practice and not till then. The appellants have in the present case failed to do so in respect of the
charge relating to issue No.5(b)(v) and accordingly we agree with the High Court that the returned
candidate was not required to refute the charge by leading evidence on this behalf. The issue is
accordingly decided against the appellants and we confirm the finding of the High Court.
Issue No. 5(b) (vi) & (vii) These two issues relate to the publication of certain advertisements in
various newspapers such as Nagpur Times, Nagpur Patrika, Nav Bharat Times, Tarun Bharat among
others. There is some connection between these issues and issues 6(a), (b) and (c), which we shall
deal with separately. According to the election petitioners, the returned candidate had opened an
account with Nav Bharat Times, Nagpur Times and Nagpur Patrika and had incurred an expense of
Rs. 4,89,424.00 for the publication of various advertisements in connection with his election in
those newspapers but the said amount was not included in the return of expenditure and that had
the same been included, the returned candidate would be shown to have incurred expenses beyond
the permissible limits. The break up of the amount (Rs. 4,89,424.00) allegedly incurred or
authorised by the returned candidate as given by the appellants is as follows:
(1) Nav Bharat Times = Rs. 2,61,274.00 (2) Nagpur Times & Nagpur Patrika = Rs.
2,28,150.00 It was alleged in the election petition that the returned candidate had an
account, Code No. M-0042 (Ex. 441), with the Newspaper Nav Bharat Times and
though it was shown that the expenses for the advertisements published in the
newspapers were borne by Nagpur District Congress Committee, Gramin Congress
Committee and some other organisations and individuals, but in fact the payments
had been made out of the amounts provided for by Respondent No. 1 to the said
Committees, organisations and individuals. In the written statement Respondent No.
1 denied that he had incurred or authorised any expenditure himself or through his
election agent in respect of the various advertisements appearing in Nav Bharat
Times, Nagpur Times and Nagpur Patrika as alleged in the election petition. It was
also denied that the advertisements had been published at the instance of or with the
knowledge of Respondent No. 1 or that he had placed his funds at the disposal of the
party and others to discharge the liability arising out of the publication of the
advertisements.
We shall first take up the publication of the advertisements in Nav Bharat Times for which it is
alleged that an expenditure of Rs. 2,61,274.00 was incurred or authorised by Respondent No. 1.
PW6 Narayan Gawalani, the Manager of Nav Bharat Times while appearing as a witness for the
election petitioner deposed that the newspaper receives advertisements through advertising
agencies, organisations and individuals. The agencies which had released advertisements during the
elections were Prasad Publicity, Yugdharma Consultants and Commercial Services (Y.C.C.S). For
Prasad Publicity and Y.C.C.S. they had a running account while Congress had no running account
with Nav Bharat. He then explained how various advertisements appearing in the paper came to be
published and disclosed the sources from which the same had come and also identified the person
or party who had made payments in respect of those advertisements. He went on to depose that
whenever the advertisements were received, they were entered in a register called the "RO InputGajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

Register"
but the same had not been preserved and had since been destroyed. That there was
no other proof pertaining to the receipt and publication of advertisements. He
produced the ledger and proved various advertisements, release orders, bills etc.
During his cross-examination, he was confronted with various receipts and he went
on to say "None of the advertisements of which the total works out to Rs. 26690/- as
stated above were given by Datta Meghe. The payment also was not made by Datta
Meghe for those advertisements. nor did he take responsibility for making these
payments."
While explaining the document Ex. 407 and the existence of words "(Datta Meghe Election
advertisements)" written in ink in the copy of Ex. 407, he expressed ignorance as to when or by
whom those words were inserted in the office copy. He admitted that in respect of Ex. 409A, the
words "Datta Meghe Account" did not appear in the original of the receipt but could not say as to
who had written those words in the copy. The witness in response to the question regarding the
association of Respondent No. 2, with the partners of the firm stated "I know Ramgopal
Maheshwari, Prakash Maheshwari. They are the partners of the firm which owns Nav Bharat. It is
true that on many common social formus they and Respondent No. 2 Banwarilal Purohit are
together. I do not know if they belong to the same community. It is not true that our management
has forged the duplicates of receipt books at the instance of Banwarilal Purohit in order to boster his
false claim in the petition."
The witness categorically asserted that "M 00042" is the code number of "Datta Meghe Election
Advertisement Account" and that all payments against the said code number and account had been
received from Nagpur Shahar District Congress-I Committee and that no payment was received
from Datta Meghe or from anyone else on behalf of Datta Meghe. PW7, Shri Sapre, Manager,
Accounts of Nav Bharat Times, deposed that Manmohan Maheshwari is the Editor of Nav Bharat
Times. That receipt Ex. 406 was issued first in the name of Datta Meghe but later on it was corrected
to show the name of the party as Congress Committee and it was done under his instructions
because it had been brought to his notice that payment had not been made by Datta Meghe but by
Nagpur Shahar Indira Congress Committee. He went on to state that the original receipt Ex. 406-A
was signed by Kulkarni. Explaining the difference in scoring of certain words in the carbon copy
Ex.406-A and its original Ex. 406-A, the witness stated that he had scratched the original name and
substituted it with the name of Shahar Congress Committee. He, however, could not state as to who
did the scoring in the original receipt Ex. 406-A, because the same had not been done by him. When
his attention was drawn to a number of other receipts and their carbon copies and particularly the
entries thereon, with a view to point out the difference between the entries in the originals and the
copies, the witness stated that since receipts had been issued by different persons like Kulkarni,
Prabhakar and others, he could not explain the reason as to why the corrections had been made but
asserted that the corrections had not been made only in the case of the receipts concerning
Respondent No. 1 but such corrections had been made also in respect of the receipts issued in favour
of some other candidates and all such corrections were made in routine. The witness then
categorically admitted "We do not have any personal account of the respondent No. 1 Datta MegheGajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

in the account books. Except for the `Datta Meghe Election Advertisement Account' there is no
other account in Datta Meghe's name. The receipt Ex. 406 was fully written by Kulkarni when it
came to me, and it bore the two bill numbers, and that was also the case with original Ex. 406-A. I
did not check up in whose names the two bills mentioned therein, stood. They had been checked by
the Advertisement Department."
PW8 Pannalal Poddar was working as an Assistant in the advertisement department of Nav Bharat
Times at the relevant time. He deposed that a subsidiary ledger was being maintained in the
advertisement department and that the bills which were prepared by the advertisement department
were entered in the said ledger against the accounts of the concerned parties and that he used to
maintain that register. He stated that at page 496 of the ledger, there exists an account in the name
of "Datta Meghe Election Advertisement Account" and that the said account had been written up to
page 498 under the same title. He stated that out of the writing "Datta Meghe Election Advertising
Account" Nagpur, the words "Datta Meghe, Nagpur" were in his handwriting but the remaining
words "Election Advertisement Account" were not in his handwriting and he could not even identify
the author of the words "Election Advertisement Account" in the above entry. He stated that entry
regarding bill No. 9101007 of May, 1991 for Rs. 10,000/- stood originally in the name of Datta
Meghe but that name was scored out later on but he could not say as to who had scored out the
name and susbsituted the same by "Nagpur Congress". That the scoring in the enteries had been
done in Bill Nos. 9101007, 9101343, 9101439 and 9101940 also by substituting the name of Datta
Meghe with Nagpur Congress and Nagpur Shahar Zila Congress-I. He, however, did not know as to
who had made the corrections or even the time when the same had been made or the reason why
they had been made. During his cross-examination, he admitted that there were neither any erasers
nor corrections in the subsidiary register in regard to the four bills (above noted) and that the
entries in that register had been made within 5 to 7 days of the issuing of the receipts. The witness
specifically admitted that it " is not possible to say by referring to the account whether payment was
received in this account through any other organisation except the Congress Committees."
Respondent No. 1 appearing as R1W1 deposed that Parshionikar had been entrusted with the work
of issuing advertisements on behalf of the Congress Committee. That Parshionikar was a man of his
confidence. He denied that he had himself entrusted any job of publication of the advertisements in
the newspapers to Parshionikar. He went on to add that he had not asked Nav Bharat Times to open
a separate account for his election advertisements and denied any knowledge whether Nav Bharat
Times had opened any account as "Datta Meghe Account". He denied the suggestion that Account
No. M-0042 had been opened by him initially in the name of "Datta Meghe Account" but was
lateron converted, at his instance, to the name of "Data Meghe Election Advertisements Account" to
escape the rigours of law. He went on to asert that he had not given any advertisement to Nav
Bharat Times nor had he paid any amount to the said paper.
Dr. Ghatate, learned counsel appearing for the appellants argued that since there was an account in
the name of Datta Meghe, being Account No. M-0042, and admittedly the District Congress
Committee had no account with Nav Bharat Times, the inference was obvious that the assertion of
the returned candidate that neither he had issued any advertisements in Nav Bharat Times nor did
he make any payment for the same or even agreed to reimburse the expenses incurred for theGajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

publication of the advertisements in the said paper was not correct. He submitted that the
interpolations made in the copy of the receipt Ex. 406 and its original Ex. 406-A was a tell tale
example of the tampering of the record by Nav Bharat Times with a view to help Respondent No. 1
to conceal the incurring of expenditure by him and that an adverse inference should be drawn that
all the scoring etc. by the employees of Nav Bharat Times only with a view to favour Respondent No.
1, In support of the argument, learned counsel pointed out that receipt Ex. 406 dated 17.5.1991 was
initially issued in the name of Datta Meghe and subsequently in the original receipt Ex. 406A, where
the name of the party had been initially left blank, the name of Congress Committee was written
even though in the carbon copy, the name of the party continued to be shown as Datta Meghe which
was also later on interpolated and substitued to read "Datta Meghe Election Advertisement
Account". Learned counsel submitted that from the fact that the original receipt Ex. 406A, was
produced during the cross-examination of the witness by the counsel for Respondent No. 1 the only
explanation for the original receipt Ex. 406-A being found in possession of Respondent No. 1, could
be that he had made the payment and kept the receipt, as otherwise there was no occasion for the
original receipt to be found with the counsel for the returned candidate.
Thus, wherever it was found that the involvement of Datta Meghe could be proved, his name was
scored off and replaced by Congress Committee etc. by Nav Bharat Times. According to Dr. Ghatate
even if Datta Meghe himself had not placed any order for issuance of any of to the newspaper, it was
out of the funds provided by him that the payments had been made and therefore the returned
candidate would be deemed to have incurred the said expenditure. Though the arguments of Dr.
Ghatate appear on the first blush to be attractive but they do not bear close scrutiny. Had receipt Ex.
406-A, which is the original of receipt Ex. 406 been with Respondent No. 1, containing a blank entry
which was later on filled up as District Congress Committee showing it as the party making the
payment, there was no reason why the same entry could not appear in the carbon copy Ex. 406, if
the employees from Nav Bharat Times were out to oblige Respondent No. 1. The explanation given
by the witnesses from Nav Bharat Times regarding the appearance of different names in the original
and the carbon copy, cannot be said to be wholly unacceptable, particularly in view of the attendant
circumstances. The possibility that interpolation was made in the copy of the receipt Ex. 406, to
create evidence against the returned candidate also cannot be ruled out particularly in view of the
association of respondent No. 2 with the management of Nav Bharat Times. If the original Ex. 406A
contained the name of Congress Committee and the entry in the carbon copy had been left blank, it
could have been filled up by adding the name of Datta Meghe That apart, the receipts Ex. 406-A and
its carbon copy Ex. 406 relate to payments made in respect of two bills based on two distinct release
order. Neither the correctness of the release orders, admittedly not issued by Datta Meghe, nor the
authenticity of the relevant bills, which bills again had not been drawn in the name of the returned
candidate, has been doubted by the appellants. Therefore, much capital cannot be made out of the
difference of the entrfes in the original and the carbon copy of receipts Ex. 406-A and Ex. 406, when
it is not disputed that Ex. 406 was actually issued in the name of Nagpur Shahar Indira Congress
Committee. It is also pertinent to notice here that the appellants have led no evidence whatsoever to
show that any order for advertisement had been placed by Respondent No. 1 himself or by his
election agent with Nav Bharat Times in respect of either of the two release orders or bills. Not a
single bill, out of the massive record produced by the appellants, is in the name of the returned
candidate. There is not a single receipt of payment issued in the name of the returned candidateGajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

either. The witnesses appearing on behalf of the petitioners have categorically asserted with
reference to the record that no amount had been paid by Respondent No. 1 for any of the
advertisements published by them in their newspapers. The learned Trial Judge has elaborately
considered various documents to which his attention was drawn and the arguments raised on the
basis of the so-called interpolations etc. on some of the documents and concluded that there had
been some errors in the mentioning of Code numbers in some receipts etc. But rightly found that the
first respondent could not be held responsible for any of those interpolations. No evidence direct or
circumstantial has been led by the petitioners to support the charges levelled against the returned
candidate to the effect that the returned candidate had provided funds to the party and it was his
money which was paid through the hands of the party. The allegation has remained absolutely
unsubstantiated. As a matter of fact, the evidence led by the election petitioners instead of
supporting their case, has to a large extent, demolished the same in as much as none of the
witnesses have contradicted the assertion of the returned candidate that he incurred no expense,
other than that which he had disclosed in the return of his election expense. The Trial Court
therefore, rightly held that the expenses in respect of all the advertisements (subject matter of the
issues) which were published in Nav Bharat Times could not be said to have been incurred or
authorised by the first respondent. We find that the conclusion arrived at by the Trial Court is based
on correct and proper appreciation of the evidence and learned counsel for the appellants has been
unable to point out any flaw or error in the reasoning of the learned Single Judge of the High Court.
We, accordingly uphold the finding of the High Court.
We shall now consider the allegations regarding the expenditure allegedly incurred in connection
with the advertisements which appeared in different issues of Nagpur Times and Nagpur Patrika for
the election of the returned candidate. It is not disputed that none of the advertisements were issued
by the returned candidate himself nor any bill was drawn against him nor any payment was received
from him. These advertisements appeared under different names. For example, the advertisements,
Ex. 84/13 and 84/15 appeared in the name of a "Well Wisher". The bill for those advertisements, Ex.
474, was drawn by the Nagpur Times /Nagpur Patrika combined in the name of "Nitin Furnitures"
and the receipt of payment, Ex. 475 was also drawn in the name of "Nitin Furnitures", Nagpur.
Similarly, two advertisements dated 8.6.1991 published in Nagpur Times being Ex. 84/14 and 85/15,
were published by "Punjab Woodcrafts". The bills in respect of the same were drawn in the name of
`Punjab Woodcrafts' for Rs. 15,000/- and the receipt, Ex. 477 dated 14.9.1991, also shows the name
of M/s. Punjab Woodcrafts as the party who had made the payment. The advertisement issued in
the Nagpur Times, Ex. 84/15 and in Nagpur Patrika, Ex. 85/16 were again published by a "Well
Wisher" and the bill Ex. 478 dated 30th June, 1991 for the said advertisement was issued in the
name of "Ranjit Engineering Works" and the receipt, Ex. 479, for the same was also issued in the
name of Ranjit Engineering Works (by mentioning its Code No. ICR-0436). Again, for the
advertisements published in Nagpur Times and Nagpur Patrika dated 10.6.1991, by a "Well Wisher",
the bill was prepared in the name of "Talmale Bandhu" on 30th June 1991 and the receipt in respect
of the said bill dated 14.9.1991 was also issued in favour of "Talmale Bandhu".
The appellants examined Shri Mahendra Bangarde PW 40 who was working as the Finance
Manager with Nagpur Times since 1983. He stated that Ms. Neelima used to work as the Data
Operator. She, however, was not the examined by the appellant. He proved various entries in theGajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

ledgers, bills and receipts concerning publication of advertisements in the Nagpur Times. He did not
state that any of those advertisements had been published either by Respondent No. 1 or by his
election agent or that any payment in respect thereof had been made by Respondent No. 1 or his
election agent nor even that respondent NO. 1 or his election agent had taken the responsibility for
making the payment for the concerned advertisements.
Santosh Sarode PW9 was working as the Manager General (Coordination) with the Nagpur Times at
the relevant time and deposed that he knew about the advertisements which were published in the
Nagpur Times and Nagpur Patrika during the last Lok Sabha elections. He deposed that various
advertisements which had appeared in the Nagpur Times in support of the election of the returned
candidate had been published at the instance of Shri Parshoinkar, who had taken the responsibility
for settling the bills in respect of those advertisements. He went on to say that it was at the asking of
Shri Parshoinkar that bill Ex. 474 for Rs. 15,000/- dated 30.6.1991 was drawn in the name of 'Nitin
Furnitures'. The payment for the said bill was received on 14.9.1991 from Nitin Furnitures. He
admitted that the Punjab Woodcrafts had an account with the Newspaper and that it was their
represntative who had requested them for the publication of an advertisement for which also Shri
Parshoinkar had taken the responsibility for making payment and that later on Shri Parshoinkar
had brought the amount and paid the same on behalf of Punjab Woodcrafts. The witness stated that
according to his knowledge, Shri Parshoinkar was an office bearer of the Congress Committee and
admitted that payments for some other bills also were made by Shri Parshoinkar on behalf of
various parties as well as on behalf of the Congress Committee. Referring to the corrections made in
the Code numbers appearing in certain bills, the witness stated that he had no knowledge as to who
had made those corrections or overwritings and when the same were made but categorically
asserted that all the payments had been made only by Shri Parshoinkar. The witness admitted that
there was an account styled as "Datta Meghe Election Advertisement Account" with his newspaper
and that the Nagpur Shahar District Congress Committee also had a separate account with his
paper. Explaining the corrections made in respect of recipts No. 779, 825, 1026, 1356 which had
been first shown credited in the account of "Datta Meghe Election Advertisement Account", the
witness stated that it was the Nagpur Shahar District Congress Committee, who had asked the
newspaper to publish the advertisements and had also undertaken the responsibility to make the
payment for the same and since the said Congress Committee had also an account with them
directly, they had transferred the "amounts" from "Datta Meghe Election Advertisement Account" to
the account of Nagpur Shahar District Congress Committee, as the advertisements had actually
emanated from the Congress Committee and payments had also been made by the Congress
Committee. The witness explained that initially in their records all the amounts which were being
received from Nagpur Shahar District Congress Committee as well as from Nagpur Gramin
Committee were being credited in the Account of 'Datta Meghe Election Advertisement Account' but
lateron the same were corrected to accord with the actualities and credited in the appropriate
Account of the party responsible for the advertisement and payments. The witness stated that since
Shri Parshoinkar had brought the payments for the advertisements from the Nagpur Shahar District
CongressCommittee, Nagpur Gramin Congress Committee, Nitin Furnitures, Punjab Woodcrafts,
Ranjit Engineering Works and Talmals Bandhu there had been some confusion about the
mentioning of the Code Numbers in various receipts. During his, cross-examination, the witness
categorically asserted that no payments were made by Datta Meghe for the advertisements whichGajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

were released by Prasad publicity nor had Datta Meghe taken the responsibility for making
payments in respect of those advertisements. Thus, we find that according to the witnesses
examined by the petitioners, neither Datta Meghe had issued any advertisement for publication nor
had he made any payments in respect of the advertisements issued at the instance of different
parties in the newspapers.
Respondent No. 1 during the course of his examination asserted:
"I had not asked any of the news papers to open an account in my name in respect of
the advertisements, during the election period. Neither did I ask my election agent or
any one else to open such an account on my behalf. I have no account in my name as
Datta Meghe with any of the news papers, because I never asked such account to be
opened. I learnt yesterday that an account had been opened in my name by Janvad,
only yesterday. I do not know whether that account had been opened during the
election period. It is not true that I had opened personal accounts in my name with
Nav Bharat, Nagpur Times and Nagpur Patrika in relation to the advertisements
during the election. It is not true that I had asked the entries which stood in my name
to be transferred in the name of the Congress Committees. It is not true that I
supplied the funds for publishing these advertisements to the Congress Committees,
or the institutions or individuals who made the payments."
The assertion of the returned candidate finds support from the witnesses produced by the
petitioners concerning the advertisements published in Nagpur Times and Nagpur Patrika.
The argument raised by Dr. Ghatate in respect of the advertisements published in Nagpur Times
and Nagpur Patrika was only a repetition of the arguments raised on behalf of the election petitiones
in the Trial court. The learned Single Judge, after examining minutely various bills, receipts,
advertisements and entries in the ledgers etc. as also analysing the oral evidence, came to the
conclusion that the election petitioners had failed to establish the charge levelled against
Respondent No. 1 to the effect that he was responsible for the publication of any of the
advertisements or that he had incurred or authorised any expenditure himself or through his
election agent or even that the funds allegedly provided by him had been utilised to discharge the
liabilities. The High Court found that the returned candidate could not be connected with any of the
interpolations or tampering with the record of the newspaper either and observed :
"The question, however, is whatever may be the reasons for the manipulation, can the
liability for manipulation be fastened on the first respondent. Merely because there
was a change in the names in the bills and there was every good reason for the name
of the first respondent, if it had appeared in the original document being suppressed
and there was a Datta Meghe Advertising Account 0056 in the book of Nav Samaj
Ltd., it cannot be said that the first respondent's name had appeared in the original
bill and that, that was removed and new names were substituted.Gajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

The mater cannot rest merely on surmises. The persons, who had actually accepted
the advertisements, were not examined. Though Sarode's version, when it comes to
be against the interest of the respondent No. 2. would have to be considered with
more care and caution for disbelieving the version that the first respondent was not
concerned with the advertisements some positive evidence was necessary. On the
other hand, the positive evidence is that the first respondent had not given these
advertisements and had not accepted the responsibility for these advertisements.
None from Talmale Bandu, Punjab Wood Craft, Ranjit Engineering Works and Nitin
Furniture was called as a witness to show that they had not given the advertisements.
If such evidence were led, then an inference could have legitimately been raised that
since they had not given these advertisements, they must have been given by the first
respondent, because he would be the person who would be really interested in
advancing his own cause. on their own, may come forward for giving the
advertisements, without any apparent motive, in the circumstances, though there is
no reason to doubt the evidence that the names in the bills and the receipts issued by
Nav Samaj Ltd. had been changed in order to conceal the real advertiser, I find that
that evidence by itself is not sufficient to clothe the first respondent with the
responsibility of giving the advertisements."
(Emphasis added) We find ourselves in complete agreement with the above opinion
of the High Court. Relevant witnesses were not examined by the election petitioners
for reasons best know to them. The appellants have offerred no explanation, much
less a satisfactory one, as to why those witnesses who were relevant and were likely to
shed some light were withheld. The evidence led by the appellants is not only
insufficient but also confusing, contradictory and often destructive of the case set up
by the petitioners. We are hesitant, in the face of the evidence on the record, to take a
view different than the High Court. On the basis of the above discussion, Issue 5(b)
(vi)&(vii), except to the extent we shall refer to certain items lateron, are held not to
have been established by the election petitioners and the same are decided against
them.
Issue No.6 (a).(b)&(c) In para 2.23 A of the amended election petition, the case
projected by the election petitioners was that the returned candidate, respondent No.
1, had got released various advertisements through Yugdharma Consultants and
Commercial services for publication in the newspaper 'Tarun Bharat'. A Statement,
Annexure 18-A, indicating the bills in respect of the advertisements allegedly released
by respondent No. 1 in the said newspaper was filed and it was alleged that an
amount of Rs. 2090.00 had been received by Tarun Bharat towards the
advertisement expenses. It was pleaded that though some of the bills had been been
drawn in the name of respondent No. 1 himself and he had been shown to have
settled those bills by making payments thereof, some of the other bills were
fictitiously shown under the names of certain dummy organisations or individuals,
though the payment in respect of each one of those items of advertisements was alsoGajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

made by respondent No. 1 himself and/or by his election agent, Shri Sudhakar
Deshmukh, during the period 25.4.1991 to 16.6.1991 and all that expense was
suppressed from the return of election expenses. In para 2.23/B of the amended
petition, it was pleaded that the advertisement details where of were contained in
Annexures 18-B and 18-C, had also been released for publication by respondent No. 1
himself and/or by his election agent or by the individuals/organisations and others
under the authority of Respondent No. 1 and or his election agent. to the daily
newspaper Hitvada, through Orange city Advertising, Nagpur and prasad Publicity,
Nagpur respectively and an amount of Rs. 40,000/- and 23,520/- had been paid to
Hitvada towards the charges of those advertisements through orange city Advertising
and prasad Publicity respectively. That even though the bills for the amount were
drawn in the name of certain organisations, and individuals actually the payments in
respect of each one of the bills, had been made by Respondent No. 1 himself and/or
his election agent, Shri Sudhakar Deshmukh, but the returned candidate had failed to
include the said expenditure in the return of his election expenses.
In Paragraph 2.23 C of the amended election petition, by reference to the statement
contained in Annexure 18-D, detailing the advertisements released through Prasad
Publicity to Tarun Bharat, it was pleaded that those advertisements had been issued
by respondent No. 1 for publication in Tarun Bharat and an amount of Rs. 71,440/-
had been paid to Tarun Bharat towards the publication of said advertisements and
even though some of the bills were drawn in the name of Respondent No.1 himself
and he made the payments thereof, the other bills had been fictitiously drawn in the
name of certain organisations or individuals, though in fact the payment in respect of
the same were made either by Respondent No. 1 himself or by his election agent shri
Sudhikar Deshmukh and that an expenditure of Rs. 71.440/- in that behalf was not
included by him in the return of election expenses.
The returned candidate in his written statement, while admitting the publication of
some of the advertisements in Tarun Bharat, the expenditure where of he had shown
in the return of election expenses, denied that he had made the payments of Rs.
2090.00 to Tarun Bharat as alleged in paragraph 2.23 A (Annexure 18A) or had even
asked them to publish the concerned advertisement. He also denied that he had
authorised or incurred an expenditure to the tune of Rs.40,000.00 and 23,520.00 as
alleged in para 2.23 B of the amended election petition in respect of the items
detailed in Annexure 18 B and 18 C. In reply to para 2.23 C, the returned candidate
denied to have incurred any expenditure himself or though his election agent or with
his consent through any other organisation, association or individual for the
advertisements, as itemised in Annexure 18-D, to the election petition. He asserted
that no expenditure with regard to the publication of the alleged advertisements had
been incurred or authorised by him and he categorically denied to have suppressed
any amount from the return of his election expense.Gajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

We shall first take up for consideration Issue No. 6(c) which concerns the publication
of seven advertisements, which according to the election petitioners were issued by
the election agent of Respondent No. 1, Shri Sudhakar Deshmukh and Published on
18.6.1991 in Lok Mat, Lok Mat Samachar, Hitavad, Nagpur Times, Nagpur Patrika,
Nav Bharat and Tarun Bharat. The said advertisements were "thanks giving"
advertisements. The total expenditure incurred in respect of the same as alleged in
the amended election petition was Rs. 39,500/-. Some of the advertisements were
alleged to have been directly released to the newspapers by the election agent of
Respondent No. 1 while others were alleged to have been released through prasad
Publicity.
According to Mr. Manohar, the learned senior counsel for the returned candidate the
expenses involved in the publication of all these advertisements, even if accepted as
true and assumed for the sake of argument to have been incurred or authorised by
the election agent of Respondent No. 1, were not required to be included in the
election expenses, as the advertisements had been published after the declaration of
the result and were not published during the crucial dates mentioned in Section 77 of
the Act.According to Dr. Ghatate, on the other hand, since the advertisements had
appeared in various newspapers on 18.6.1991, it would be reasonable to presume that
the advertisements had been issued prior to mid-night between 17th June,1991 and
18th June,1991 and therefore the expenditure involved in the publication of these
advertisements would be deemed to be an expenditure incurred in connection with
the election and was required to be included in the return of election expenditure.
As already noticed, Section 77(1) of the Act mandates that a separate and correct
account of all the expenditure in connection with the election, incurred or authorised
by the returned candidate or by his election agent between the dates on which he had
been nominated and the date of declaration of the results thereof, both dates
inclusive, shall be maintained. The High Court, after a detailed discussion of the
submissions made by learned counsel for the parties, which have been reiterated
before us also, came to the conclusion that all the seven advertisements for which the
total expenditure of Rs. 39,500/- was alleged to have been incurred or authorised by
the election agent of the returned candidate were "thanks giving" advertisements and
were published after the declaration of result and therefore they did not fall within
the prohibitory limits of the time schedule prescribed in Sub- section (1) of section 77
of the Act and were as such not required to be taken into account while computing
the expenses incurred by the first respondent.
We are in agreement with the view of the High Court that the advertisements in
question could not be said to have been issued in connection with the election, even if
that expression is to be given a wide amplitude. What is it that the Legislature
intended to achieve by prescribing the inner and the outer limits in Section 77 of the
Act ? Obviously, it was the elimination of money influence during the elections and
maintaining of purity of elections. The expenditure incurred after the declaration ofGajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

the result of the election can possibly have no nexus with the purity of the electoral
process. The very fact that the advertisements thanked the electorate for electing
Datta Meghe would show that the same could only have been issued for publication
after the declaration of Datta Meghe as the returned candidate. The expenditure
incurred in that connection therefore cannot be said to be an expenditure 'authorised'
or 'incurred' during the prohibited dates. Indeed, there may be cases where some
expenditure can be incurred or authorised by a returned candidate in connection
with his election, even after the declaration of the result, but unless that expenditure
can be related to the process of election, authorised or incurred during the
prohibitory limits set out in Section 77 (1) of the Act, it is not required to be included
in the return of expenses. The mere fact that the advertisements appeared in the
newspapers on the very next day cannot lead to any presumption that the
expenditure in connection therewith had been incurred or authorised by the returned
candidate during the prescribed prohibitory dates in anticipation of his being
declared elected. We, agree and uphold the finding of the High Court that there was
no nexus between the amount spent on thanks giving advertisements with the
election after the declaration of the result of election and decide issue No. 6(c) against
the election petitioners.
Issue No. 6(a) arises out of the allegations made in para 2.13 of the election petition
and the items contained in Annexures 17 and 18 to the petition. It deals with the
advertisements allegedly issued by Respondent No. 1 through M/s. Yugdharma
Consultants and Commercial Services, Nagpur (for short 'YCCS') to publicise his
candidature. A chart containing 27 items of expenditure incurred in respect of
various advertisements published on different dates in different newspapers in
connection with the election of the first respondent were relied upon to urge that the
advertisements had been released through two advertising agencies namely
Yogdharma Consultants & Commercial Services (YCCS) and Prasad Publicity.
According to the election petitioners Respondent No. 1 incurred an expenditure of
Rs.2,74,224/- on the advertisements released through YCCS but the said expenditure
has been suppressed by the returned candidate and if included in the return of
election expense, would show that the returned candidate had committed the corrupt
practice as envisaged by Section 123 (b) of the Act.
That some of the advertisements had been published in various newspapers and had been released
through YCCS or Prasad Publicity has not been disputed by learned counsel for Respondent No. 1
before us. His argument, however, is that neither Respondent No.1 had authorised the publication of
those advertisements through YCCS or Prasad Publicity nor had Respondent No.1 or his election
agent authorised or incurred the alleged expenditure of Rs. 2,74,224/- in respect of those
advertisements. The main thrust of the argument of Dr. Ghatate, appearing for the appellants, on
the other hand was that in the release orders which had been issued by YCCS the name of "Datta
Meghe" had been shown as the client and, therefore, it was futile to urge that respondent No.1 or his
election agent had not incurred or authorised the expenditure in connection with those
advertisements. Reliance was placed on the advertisements which appeared in the issues of Lok MatGajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

and Lok Mat Samachar dated 1.5.1991, 2.5.91, 3.5.91, 5.5.91, 6.5.91 and 21.5.91, being Ex. 83/2 to
83/6, 83/34, 83/35, and 83/91 to argue the expenditure in respect of the same had been incurred or
authorised by respondent No.1. We, however, find that the bills in respect of each of the aforesaid
advertisements were admittedly issued in the names of persons, other than the first respondent.
Those had been issued in the names of Sushila Bai Jadav; Nagpur Nagar Congress Committee;
Yuvak Congress Committee and Supersteel Furniture etc. Even in respect of the advertisements
which appeared in the issues of Yugdharma dated 1.5.91, 3.5.91, 8.5.91 and 11.5.91, the bills had
admittedly been issued in the names of Nagpur Nagar Zila Congress Committee. The election
petitioners sought to connect Respondent No.1 with the advertisements issued through YCCS by
pointing out that the name of Shri Datta Meghe had been shown as the client in those bills and,
therefore, he alone must be presumed to have discharged the liability arising out of those bills either
directly or by placing his funds in the hands of the parties in whose names the bills had been drawn.
Reliance has been placed on the statement of Shri Madhukar Kishti, PW 55 by learned counsel for
the appellants in support of his submissions.
Shri Madhukar Kishti, PW 55 was at the relevant time the Managing Director of Yugdharma
Cooperative Society, the parent company, which publishes the daily Yugdharma run by Yugdharma
Industrial Cooperative society. Yugdharma Workers Newspapers Pvt. Ltd. used to run the daily
Yugdharma prior to it being taken over by the YCCS. It was Yugdharma Workers Pvt. Ltd. who had
constituted YCCS in March 1990 as the sister concern for routing advertisements to different
newspapers. PW55 deposed that he used to do whatever work was required to be done by the YCCS.
He went on to state that YCCS released advertisements for publication for Datta Meghe's
candidature for the Parliamentary Elections of 1991 to various newspapers and asserted that those
advertisements were received by them from Yuvak Congress Committee etc. Explaining as to how
the name of Datta Meghe had appeared in certain release orders against the name of the client even
though Datta Meghe had not released any of the advertisements, the witness stated that since the
space had to be booked in relation to the election of Datta Meghe in various newspapers, the witness
had, on his own mentioned the name of Datta Meghe against the name of the client for the sake of
convenience, though Datta Meghe had not entrusted any advertisement to YCCS for publication.
The witness added that he had not received any orders personally on behalf of YCCS from any of the
clients of YCCS and that the orders used to be received by Shri Thakre Shri Prakash Deshpande. In
his cross-examination, the witness, however, conceded that the name of Datta Meghe had been
mentioned in cerain release orders only because the name of the client had not been disclosed by the
party and the space was required to be booked in the newspapaers in advance owing to the rush of
advertisements. Since, the advertisements were required to be published in connection with the
election of Datta Meghe, he had shown his name against the name of the client on his own accord.
PW55, further, admitted that neither any bill nor any receipt had been issued by the YCCS in the
name of Datta Meghe. Thus, we find that PW55 does not advance the case of the election petitioners
at all in so far as the allegations concerning issue No. 6(a) are concerned. Besides, this witness had
no personal knowledge of the nature of the transactions on the basis of which the release orders
came to be issued. The election petitioners had summoned various release orders and other record
from this witness to connect the name of Datta Maghe but curiously enough they were neither
exhibited nor got proved. The other witnesses, who could throw some light on the nature of the
transaction, like Shri Thakre and Shri Prakash Deshpande, though summoned, were not examinedGajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

on this aspect for reasons best known to them. The submission of learned counsel for the appellants
that the explanation given by PW55 regarding the reason for the name of Datta Meghe appearing in
some of the release orders is not satisfactory cannot help the appellants because there is no other
evidence or explanation offered by the election petitioner. Even otherwise the explanation appears
to be quite plausible. It was for the election petitioners to adduce better and cogent evidence, direct
or circumstantial, to show that the returned candidate had incurred or authorised either himself or
through his election agent the expenditure in respect of the advertisements issued by YCCS, as
alleged in the petition, but no such evidence was produced and the allegation has remained
unsubstantiated.
Shri Prakash Despande, PW11, the Deputy General Manager of Hitvada did prove the signatures of
PW55 on release order Ex. 586 dated 7.5.1991 but was silent about any transaction between YCCS
and the first respondent. Same position exists in respect of other advertisements also. We need not,
therefore, detain ourselves to refer to all other advertisements, their release orders, bills or receipts
because from the evidence of PW55 it stands established that no payment for any of the
advertisments issued by YCCS came from the returned candidate, Respondent No. 1 deposed that
the advertisements had been issued by different parties, associations and individuals and those
parties had made the necessary payments. The petitioners have led no evidence to show that the
advertisements which were issued under the names of different parties, organisations and
individuals like Nagpur Nagar Congress Committee, Indira Brigade, Youth Congress, Phartiva Sher
Sangathana, Vidharbha Professors Club etc. were in fact not issued by those parties, organisations,
institutions or individuals, by examining any witness from such bodies and, therefore, the argument
that the advertisements, though shown to have been issued by different parties and organistions
etc., were in fact issued at the instance of the first respondent or that it was his money which they
had paid to discharge the liabilities in respect of these advertisements, has no basis let alone any
foundation. The election petitioners have totally failed to bring any material on the record to
connect Respondent No. 1 either with the publication of or expenditure incurred in respect of the
various advertisements as alleged in the petition. Even though the names of the parties,
organisations, associations, institutions, and individuals etc. had been mentioned in the
advertisements as the sponsors of the advertisements, the election petitioners did not examine any
one of them to elicit from them that they had not issued or caused to be issued those advertisements
or that they had not incurred any expense in connection therewith. We are not impressed with the
submission of the learned counsel for the petitioners that since identical advertisements came to be
issued simultaneously in different newspapers on the same date or on different dates, an inference
should be raised that it was done only at the instance of the first respondent, because he alone was
the beneficiary irrespective of different names of sponsors. The argument has neither logic nor any
basis. The election petitioners led no evidence to even create a doubt about the identity of the
sponsors and merely because identical advertisements appeared on the same date, it is not possible
to hold that the sponsors were fictitious persons or that the actual sponsor was the returned
candidate himself. It is not unknown that during the elections, many sympathisers as well as 'others'
come forward to support the candidature of a particular candidate and sponsor and pay for the
advertisements which they get published to further the prospects of that candidate's election.
Moreover, apart from the returned candidate, the party which sponsors him as its candidate is
equally interested in the furtherance of the prospects of his election and may approach differentGajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

organisations, associations or individuals to sponsor and publish the advertisements at their
expense in favour of the candidate and even to suggest to them that the same could be done by
availing of the services of YCCS which was engaged in the propoganda cannot be ruled out. The
burden of proving the issue was heavy on the election petitioners but they have miserably failed to
discharge the burden. No evidence, direct or circumstantial has been led even to show that it was the
money of the returned candidate which had been used by the party, other associations, institutions
or persons, for the publication of the advertisements in various newspapers. The evidence on the
record does not lead to any inference that it was the first respondent's money which was used for
publication of advertisements and in the absence of such an evidence, no responsibility can be
fastened on the first respondent in respect of the expenditure incurred in connection with those
advertisements. The learned trial Judge after a detailed discussion of various exhibits and taking
into consideration the law on the subject concluded that :
........................................
" Datta Meghe's connection with the advertisements released by YCCS has not been
established, and there is no other evidence to show that Datta Meghe either incurred
or authorised the expenses for the advertisements released through YCCS, and all the
advertisements, which have been issued through the agency of YCCS will have to be
left out, while considering the expenses incurred or authorised by the first
respondent Datta Meghe."
We are in complete agreement with the above conclusions and nothing has been pointed out before
us to persuade us to take a different view. Issue No. 6(a) is, therefore, decided against the election
petitioners.
ISSUE NO. 6(b) According to the allegations contained in para 2.23-A of the amended election
petition, the returned candidate had, besides releasing advertisements through YCCS in various
newspapers also utilised the services of Orange City Advertising, Nagpur and Prasad Publicity,
Nagpur for publication of advertisements in connection with the furtherance of his elections in
various newspapers. The details of the advertisements allegedly released by the returned candidate
to the newspaper daily Hitvada through Orange City Advertising, Nagpur and Prasad Publicity
Nagpur were provided in Annexure 18B and C attached to the election petition. The total amount
alleged to have been spent by the returned candidate in that behalf was stated to be Rs.40,000/- and
Rs.23,520/-. In para 2.23-B the election petitioners averred that although, it appears from the
statements at Annex. 18B and 18C that the bills were issued in the name of certain organisations, the
payments in respect of each one of the bills had in fact been made by respondent No. 1 himself
and/or his election agent, Shri Sudhakar Deshmukh during the period from 25.4.91 to 16.6.91. It
was alleged that the orders for each of the items of advertisements appearing in the statements at
Anex. 18B 18C were also placed by respondent No. 1 himself and/or by his election agent Shri
Sudhakar Deshmukh or by the organisations and individuals as indicated in the statements at the
instance and under the authority of respondent No. 1 or his election agent. Besides the election
petitioners alleged in para 2.23-C that some more advertisements had been released by respondent
No. 1 during 25.4.91 to 16.6.91 through Prasad Publicity in Tarun Bharat and an expenditure ofGajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

Rs.71440/- had been incurred therefor which was also not disclosed by the returned candidate in the
return of his expense.
categorically denied that the advertisements detailed in Annexures 18B and 18C had been published
or issued by him and asserted that no expenditure in that behalf had been incurred or authorised by
him or by his election agent. It was denied that he had authorised and/or incurred an expenditure of
Rs.40000/- and Rs.23520/- as itemised in Annexure 18B and 18C. Similarly, it was asserted by the
returned candidate that he had not placed orders for any of the advertisements detailed in Annexure
18D either himself or through his election agent nor had he authorised any of the organisations or
individuals mentioned in Annexure 18D to get published the advertisements. It was maintained that
no expenditure whatsoever with regard to the advertisements itemised in Annexure 18D were
incurred or authorised by the returned candidate or by his election agent and therefore there was no
question of disclosing the same in the return of election expenses. With regard to The
advertisements allegedly released through Orange City Advertising, the learned trial Judge has
noticed:
"With regard to Issue No.6(b), the learned counsel for the petitioners stated that he
would not be in a position to urge that the expenditure on the advertisements
introduced in the expenditure incurred by the first respondent. I have already found
that no respondent. I have already found that no other item of expenditure incurred
through prasad Publicity, except what has been included in issue no. 5(b) (vi) & (vii)
can be included, and issue No. 6 (b) is answered accordingly."
Learned counsel for the appellants has not disputed the above finding before us and as such we have
no reason to take a view different than the one taken by the High Court.
We have dealt with in the earlier part of the judgment, the allegations relating to the expenditure
incurred by the returned candidate through Prasad Publicity, while dealing with issues 5(b) (vi) and
(vii). We shall now advert to the findings with regard to certain amounts which have been found to
have been suppressed by the returned candidate from the return of elections expenses.
The election petitioners relied upon the testimony of Shri Anant Shastri PW50, who used to carry on
the work of advertising agency in the name of prasad Publicity. The witness deposed that he knew
respondent No.1 and that he had received advertisements for publication in the newspapers from
several institutions with which respondent No.1 was connected. Those institutions included Radhika
Bai Meghe Memorial Trust; Nagar Yuvak Shikshan Sanstha; Polytechnic; Engineering College;
Dental College; Pharmacy and Medical College, being run by those institutions. That he had been
releasing the advertisements on behalf of those institutions since 1984. He went on to add that
payments had been received for the publication of the advertisements from various organisations as
also from Nagpur Shahr Zila Congress Committee and entered in a ledger which, however, had been
destroyed by him in the last week of March 1992. He stated that the account ledger had been
destroyed by him before he had received the summons to appear in the court as a witness in the
election petition. According to PW50 he did not himself write the account books and that the same
were written by his accountant Shri Dhale. After referring to the counter foil book, PW50 deposedGajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

that ledger folio No. 226 pertained to the account of Yashwantrao Chauhan Social Forum and that
counterfoil No.003363 from the same counterfoil book also bore ledger folio No. 226 and was issued
in the name of Datta Meghe Mitra Mandal. The word "staff" which had been written below "Datta
Meghe Mitra Mandal" in the copy had, however, been scored out later on. The witness went on to
say that counter foil No.003364 also bore ledger folio No. 226 and and was issued in the name of
Nagpur Zila Congress Committee. Counterfoil No. 003365 which also bore ledger folio No. 226 was
issued in the name of Narayan Ahuja while counterfoil No. 003366 with the same ledger folio No.
was issued in the name of Rajiv Sena. The witness explained as to how the same ledger folio No.
(226) appeared against various counterfoils and stated that various organisations which had come
forward to support the candidature of Datta Meghe and were releasing advertisements in his favour
had been clubbed together under one and the same ledger folio No. 226. He denied the suggestion
that the account against ledger folio No. 226 was of Datta Meghe and not of the organisations
clubbed together.
The High Court after considering the evidence of Anant Shastri PW50 in great details opined that
the witness was enjoying the patronage of the returned candidate and of various institutions with
which the returned candidate was connected and that the witness had destroyed the ledger, a
material document, "probably because those documents, if retained, would not have been
favourable to the first respondent". The High Court did not accept the explanation offered by Anant
Shastri PW50 regarding the time and reason for the destruction of the ledger. The High Court
repelled the argument of learned counsel for the returned candidate that the release order of prasad
Publicity Ex. 225 relating to advertisement Ex. 88/1 was suspicious because the date 28.4.91 did not
appear on the carbon copy Ex.712, which had been produced by Anant Shastri PW50 presumably
because the High Court felt that the witness was favouring the returned candidate. Similarly, the
High Court did not accept the criticism made by learned counsel for the respondent in respect of
release order No. 5031 dated 28.4.91 in which the name of Datta Meghe had appeared in the carbon
copy, as the client, though there was no mention of the date 28.4.91 on it. The High Court noticed
that though below the name of Datta Meghe, the word "Karyalaya" had been initially mentioned in
Ex. 711, the manner in which that word had been written would show that the word "Karyalaya"
might not have been written on 28.4.91 but on some other date. According to Shri Anant Shastri
PW50 the advertisement dated 28.4.91 had been given to him by Shri Vasant Parshonikar on behalf
of Nagpur Nagar Zila Congress and it was for publication of the programmes arranged by Nagpur
Nagar Zila Congress Committee. That he had given identical advertisements to four newspapers
including Nagpur Patrika and Lokmat. According to the witness, the word "Karyalaya" had been
omitted from Ex.325 inadvertently as he forgot to mention it. The witness, however, stated that
Datta Meghe was not his client for the said advertisement and the words 'Datta Meghe' were used
only as a caption and the actual bill was issued in the name of the real client, Nagpur Nagar Zila
Congress Comittee.
According to Shri Padmakar PaunikarPW3, bill Ex. 156 was issued to the party on 29.4.91 itself. It
was signed by Bhojraj PW12 and the receipt Ex.157 was also signed by Bhojraj PW12. He admitted
that both the bills EX.227 were prepared on two different type-writers and both bore the signatures
of PW12. he Conceded that the three bills dated 29.4.91 were issued on three different formats.
EX.156 was issued on the format Nar kesari Prakashan and disclosed Datta Meghe as the client andGajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

that advertisement had been released by prasad Publicity; EX.227 was on the format of Tarun
Bharat and showed Yashwantrao Chauhan Forum as the party Concerned; and EX. 603 was again
on the format of Tarun Bharat and showed Datta Meghe as the name of the client. According to
PW12, the name of Yashwantrao Chauhan Forum was shown as client in Ex. 227 because they had
asked for the bill in the name of Yashwantrao Forum when bill Ex. 227 was issued. The witness
admitted that all the three bills were identical. The High Court dealt with this issue relating to the
advertisement Ex.88/1 which had appeared in Tarun Bharat for a sum of Rs. 1320/- and observed:
"If one were to go only by the different formats on which the bills were issued and
different names which appeared on the bills, it would appear that there was a good
deal of confusion and on the basis of the bills themselves, no inference could be
raised as to who was the real client. If regard is to be had to the fact that the original
release orders mentioned the name of Datta Meghe as client, there was no reason for
Tarun Bharat to depart from normal practice of issuing the bills in the name of
Prasad Publicity by showing Datta Meghe as the client, and that seems to have been
done with the bill Ex.156) issued purportedly on 29.4.91 on the format of Narkeshri
Prakashan. By that time, the forms of Narkesari Prakashan were being used. It would
be only when a bill witha different name would be required that the change in the
name would appear, and the only person, who was interested in having a bill in the
name different from the one used in the release order, would be Prasad Publicity
which was represented by Anant Shastri. To the extent that Datta Meghe's name
appeared in the original release order, there is no demur even by Anant Shastri who
was a party to the transaction. If his version that the name of Datta Meghe was
mentioned merely as a caption was true, there was no difficulty for him to allow the
name of Datta Meghe to continue in the original bills which were issued. Coupled
with the position that all the original documents issued by Tarun Bharat are said to
have been handed over by Anant Shastri to a person about whose identity he was not
clear, it is difficult to accept the position that the name of Datta Meghe in the release
orders issued to Tarun Bharat appeared merely as a caption."
The High Court then opined:
"In view of the above factum, there can be no doubt, though there was a deliberate
attempt to disguise the transaction, that the amount of Rs.1320/- under the bill
Ex.156 for the advertisement published in Tarun Bharat dated 21.4.91 (Ex.88/1) on
the basis of which the release order (Ex.225), was paid bythe first respondent under
receipt Ex.157, on 29.4.91."
After hearing learned counsel for the returned candidate at length and going through the record, in
our opinion the finding recorded by the High Court is quite sound. The explanation for appearance
of the name of Datta Meghe in the release orders does not appeal to common sense. Anant Shastri
did not handover the documents to a 'stranger' whose identity he could not recollect and admittedly
he did not handover the same to Shri Parshoinikar. Thus, in the facts and circumstances on the
record, the High Court was was right in concluding that the expense for bill No. 156 in respect ofGajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

advertisement EX. 88/1 had been authorised or incurred by the returned candidate. Even the
challenge to the said finding by learned counsel for the returned candidate before us was only
half_hearted. We thus agree with the finding of the High Court and hold that the returned candidate
did incur an expenditure of Rs. 1320/- for Bill EX.156 in respect of the advertisement published in
Tarun Bharat Ex.88/1 but failed to include the same in the return of his election expenses. The High
Court rightly included that amount to the amount disclosed in the return of election expenditure.
Coming now to the advertisement which appeared in the Election Special Issue of Tarun Bharat
dated 21.5.91 and for which an expenditure of Rs.7000/- was alleged to have been incurred by the
returned candidate, we find that the plea with regard to this advertisement was not raised by the
appellants in the original election petition and was not even included in the first amended election
petition but was introduced for the first time by an amendment dated 18.12.91. In the verification to
the election petition, the contents of the relevant paragraphs were verified as 'partly based on
personal knowledge and partly on information rceived from ......Tarun Bharat.....In the affidavit filed
in support of the allegations of corrupt practice, again the contents of para 2.23 were verified as
based partly on personal knowledge and partly on information received from the official record of
Tarun Bharat. The election petitioner, however, did not in his deposition disclose the basis of his
'personal knowlege' for making the allegation. In the pleadings a wide latitude was left by the
election petitioners to lead evidence on any of the various 'possibilities' detailed in the election
petition. The 'vagueness' of the pleadings even after amendment shows that the election petitioners
were out on a wild goose chase and trying to fish for evidence so as to be able to fasten some liability
on the returned candidate or his election agent at least in some case. PW39 Laxman Trimbakrao
Joshi, the Chief Editor of Tarun Bharat was, examined by the election petitioners in support of the
allegations made in the petition regarding publication of the advertisement in Election Special Issue
of Tarun Bharat. He deposed that Tarun Bharat had decided to issue an Election Special Issue after
the elections were announced and that he had personally contacted Datta Meghe about 8 to 10 days
before the publication of the issue on telephone and had a talk with Datta Meghe personally and had
requested him for the issuance of an advertisement, as he was a contesting candidate. Datta Meghe,
according to the witness, had told him that he would think about the matter and admittedly,
thereafter, did not get in touch with him. The witness went on to state that an advertisement in
support of respondent No. 1 was published in Tarun Bharat dated 21.5.91. It had been received
through Prasad Advertising Agency (Prasad Publicity) who had also supplied the material for
publication. The witness, however, did not know whether the bill for the advertisement had been
prepared in the name of Prasad Publicity or someone else nor did he know nor as to who had paid
the bill. He did not even know as to who had instructed Prasad Publicity to give the advertisement or
who made the payment for the same to the Prasad Publicity. This advertisement Ex.221 is the
subject matter of three bill Ex. 192 bearing No.4167 (shown as Duplicate); Ex.234 No.4178 and
Ex.605, No.4167 (written after scoring out 4178). All the bills are dated 21.5.91. Where as in Ex.192,
which was on the format of Narkeshari Prakashan the bill was addressed to Prasad Publicity,
showing Datta Meghe's name as the party releasing the advertisement, Ex.234 was on the format of
Tarun Bharat and again addressed to Prasad Publicity but showing NSUI as the client while Ex.605
was issued on the format of Tarun Bharat and was addressed to prasad Publicity and showed Datta
Meghe as the client. The High Court after considering the evidence of PW3, Paunikar (who had
deposed that Prasad Publicity had not placed the order); PW39 Laxman Joshi, (who had deposedGajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

that the advertisement was received from the Prasad Publicity that the bill had been settled by
Prasad Publicity); PW50 Anant Shastri and PW12 Bhojraj, held that the advertisement had been
issued by respondent No. 1 and that Anant Shastri PW50 had manipulated the bills and the record
to help the returned candidate.
We have carefully perused paragraphs 154 to 157 of the judgment of the learned trial Judge dealing
with the question of the expenditure of Rs.7000/- in connection with the advertisement Ex.221 in
the Election Special Issue and the evidence on record. Keeping in view the difference in the three
bills relating to the same advertisement and the use of these different formats by Tarun Bharat, we
find it difficult to agree with the High Court that the election petitioners have established that
respondent No.1 had incurred the expenditure of Rs.7000/- in respect of publication of Ex.221. The
findings appear to be rather laboured ones and if Tarun Bharat advertising office was not "very
careful about giving the particulars to the bills which they issued and that the bills were not issued
from bound book" as observed by the High Court, no adverse.inference could be drawn against the
returned candidate. Indeed neither Shri Paunikar PW3 nor Bhojraj PW12 had any talk with Datta
Meghe in respect of any of the advertisement and from the testimony of PW39 Laxman Joshi, it is
not possible to hold that pursuant to the talk he had with the returned candidate, the advertisement
in question had been published by the returned candidate himself and not by or on behalf of NSUI
in whose favour the bill had been drawn. As already noticed neither in the verification of the petition
nor in the affidavit, PW39 had been disclosed as the source of information. The appellants have not
explained the basis for making the said allegtions. The findings of the High Court in our opinion are
based on surmises and conjectures and we agree with Mr. Manohar, learned senior counsel for the
returned candidate that in the face of the vague pleadings and inconclusive evidence led by the
election petitioner coupled with the discrepent evidence of PW39, who admittedly was not shown as
the source of information for the said allegation, it is not possible to hold that the advertisement in
question, Ex.221, had been released by and paid for by Datta Meghe himself. It is also relevant in
this connection to note that no release order had been got produced by the election petitioners in
respect of this advertisement which could disclose who the real client was. We, are therefore, of the
opinion that the material on the record was not sufficient to fasten the liability for the publication of
the advertisement in the Election Special Issue of Tarun Bharat Ex. 221 for Rs.7000/- on the
returned candidate. We, accordingly, set aside the finding of the High Court and hold that
Rs.7000/- was not spent by the returned candidate for the publication of Ex.221.
The High Court also found that an amount of Rs.9900/- in respect of Ex.258 had been suppressed
by the returned candidate from the return of his election expenses. The receipt Ex.258 shows that an
amount of Rs.9900/- was paid on 20.5.91 by Sharad Pawar Mitra Mandal for the publications of the
advertisement. A consolidated bill had been issued in the name of Sharad Pawar Mitra Mandal as
the publisher. According to PW4, Ashok Jain, the advertisements which appeared in Lokmat and
Lokmat Samachar Ex.83/18 and 83/19 dated 12.5.91 against bill No.257 had been given for
publication by Narayan Ahuja and Sharad Pawar Mitra Mandal. The witness admitted that in the
bill, the name of Narayan Ahuja was not mentioned and that the payment for the bill had been made
by Sharad Pawar Mitra Mandal. From a careful consideration of the observations of the High Court
in paras 183 to 187, the pleadings and the evidence in that behalf, we find that recourse has been
taken by the learned trial Judge to surmises and conjectures to hold that the expenditure had in factGajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

been incurred by respondent No.1 in respect of the said advertisement. There is not even an iota of
evidence on the record to show that the first respondent had incurred the expenditure of Rs.9100/-
as alleged by the election petitioners in their evidence, though not specifically pleaded in their
election petition both original and amended. The election petitioners had learnt about the role being
played by Narayan Ahuja even before they filed the election petition. It was for them to have
examined Narayan Ahuja to elicit from him as to whose funds he was utilising for making payments
for publication of various advertisements. The petitioners chose not to examine him for reasons best
known to them. We do not think that there was any obligation on the part of the returned candidate
to have examined Narayan Ahuja and lead negative evidence to the effect that no funds had been
provided to him by the returned candidate and that the payments had been made by the parties who
were responsible for the publication of various advertisements through him. The observations of the
High Court that Narayan Ahuja was a person "who had no financial or political background for
representing organisations", is clearly based on conjectures because the evidence on the record does
show that Narayan Ahuja had been working for the political parties and without there being any
pleading or evidence on the record, it was to say the least rather unfair for the High Court to
conclude that Narayan Ahuja had "neither any financial status nor any political background". We do
not find it possible to agree with the High Court that the returned candidate had suppressed the
amount of Rs.9100/- in respect of Ex.221 (receipt Ex.258) and accordingly set aside the said finding
of the High Court, which is not based on any satisfactory material on the record.
The finding of the High Court in respect of some of the items as detailed in Annexures 8 to 15,
involving an expenditure of Rs.22900/-, in our opinion are equally fallacious and conjectural. The
same are not based even on correct appreciation of evidence. Recourse has been taken to surmises
and imagination to return these findings. We find it difficult to subscribe to the view of the learned
trial Judge which is not supported by any material on the record. The positive evidence led by the
election petitioners is that the returned candidate had not himself or through his election agent
given any of the advertisements for publication and had not accepted any responsibility for making
payment in respect of any of those advertisement, even though the advertisement were issued for
the furtherance of his election prospects. There is no direct or circumstantial evidence led by the
election petitioners to show that the amount paid in the name of Sharad Pawar Mitra Mandal had
been placed at the disposal of the said Mandal by the returned candidate or his election agent. There
is no evidence even to suggest that respondent No.1 had undertaken the responsibility of making the
payments in connection with the expenses incurred by Sharad Pawar Mitra Mandal. The election
petitioners, for reasons best known to them, chose not to examine any witness from Talmale
Bandhu, Punjab Woodcraft, Ranjit Engineering Works, Nitin Furniture, Sharad Pawar Mitra
Mandal, D.M.M. Mandal and various other organisations under whose names either the
advertisements had been published or who had according to the evidence made payments for those
advertisements as per the bills and receipts on the record. If any evidence was led to the effect that
none of the persons, parties or organisations had in fact issued the advertisements or they or anyone
of them had denied the making of any payment, it may have been possible to argue that those
advertisements may have been got published by the first respondent himself or through his election
agent or through some other persons with his consent or with the consent of his election agent and
in that event the onus may have shifted to the returned candidate to explain the source of the
expenditure and in the absence of any satisfactory explanation it may have been possible to draw anGajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

inference that it was the money of the returned candidate. Since no such evidence was led and no
proof was submitted in support of the alleged charge, the question of shifting of onus on the
returned candidate to prove his non-liability did not arise. The High Court, therefore, was not
justified in saddling the returned candidate with any expense other than Rs.1320/- in addition to the
expenses disclosed by him in the return of his election expense.
Thus, on the settled principles extracted in an earlier part of this judgment, we find that the election
petitioners have miserably failed to discharge the onus of proving various charges levelled by them
against the returned candidate regarding the commission of corrupt practice under Section 123 (6)
of the Act. The High Court was, justified in holding that the returned candidate had not committed
any corrupt practice as envisaged by Section 123 (6) of the Act and in dismissing the election
petition. However, the High Court fell in error in holding that certain items of expenditure totalling
Rs.58,2220/- had been suppressed by the returned candidate and deserved to be included in the
return of his election expense. Except to the extent of Rs.1320/-, no other liability can be fastened on
the returned candidate in respect of the other items of the alleged expenditure on publication of
advertisements etc. The election appeal consequently fails and is dismissed with costs. The
cross-objections to the extent indicated above succeed and are allowed. The costs are assessed at
Rs.10000/-.
Before parting with the judgment we would, however, like to express our disapproval of the manner
in which amendments of the election petition were allowed on occasions more than once and how
evidence was allowed to be brought on the record against the pleadings and settled legal principles.
Section 86(5) of the Act deals with the amendment of an Election Petition. It lays down that the
High Court may upon such terms as to costs or otherwise, as it deems fit, allow amendment in
respect of particulars but there is a complete prohibition against any amendment being allowed
which may have the effect of introducing either material facts not already pleaded or of introducing
particulars of a corrupt practice not previously alleged in the petition. The first part of Section 86(5)
of the Act, therefore, is an enabling provision while the second part creates a positive bar. Of course,
the power of amendment given in the Code of Civil Procedure can be invoked by the High Court
because Section 86 of the Act itself makes the procedure applicable, as nearly as may be, to the trial
of election petition, but it must not be ignored that some of the Rules framed under the Act itself
over-ride certain provisions of the Civil Procedure Code and thus, the general power of amendment
drawn from the Code of Civil Procedure must be construed in the light of the provisions of the
election law and applied with such restraints as are inherent in an election petition. It appears to us
that the High Court did not properly consider the provisions of the election law while repeatedly
allowing amendments of the election petition in the present case. The High Court allowed an
application Ex.27 filed by the election petitioner for permission to amend the petition on 28.11.91.
Yet another application for amendment of the election petition, Ex.44 was again allowed by the High
Court on 18.12.91. The petitioner filed still another application, Ex.47A, to again amend the election
petition and the High Court allowed the same on 18.1.92. Even after the pleadings were completed
and the issues framed on 21st of January 1992 and a part of evidence had been led by the parties, the
High Court allowed one more application filed by the election petitioner No.1, Ex.701, and permitted
an amendment of the election petition, apparently to bring the evidence in conformity with theGajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

pleadings. In the first place, the High Court ought not to have allowed evidence to be led by the
election petitioners which was beyond the pleadings of the parties for no amount of evidence can
cure a defect in the pleadings but it was all the more improper for the trial court to have allowed the
pleadings to be amended so as to be brought in conformity with the evidence already led in the case.
To say the least, it was not a desirable or a proper course to be adopted in an election petition where,
as pointed out by this Court in Jagannath Vs. Jaswant Singh (1954 SCR 892), the statutory
requirements of the law of election must be strictly observed. Of course, since evidence was allowed
to be led, though beyond the pleadings without any objections from the opposite side, the court
could have evaluated and analysed the same to determine the worth of that evidence, which in the
facts and circumstances of the case came under a cloud but to allow the amendment of the pleadings
with a view to confer a `legal status' on the evidence already led was to say the least improper. The
reasons given by the learned trial judge to allow the election petition to be amended repeatedly
ignores the sanctity which is attached to the pleadings and the affidavit filed in support of an
election petition, which under law is required to be filed within a prescribed time and those reasons
do not impress us. We need say no more on this aspect of the case.Gajanan Krishnaji Bapat & Anr vs Dattaji Raghobaji Meghe & Ors on 18 July, 1995

