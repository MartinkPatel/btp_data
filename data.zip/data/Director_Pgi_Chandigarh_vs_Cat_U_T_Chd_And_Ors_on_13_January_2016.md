Director Pgi Chandigarh vs Cat U.T.Chd. And Ors on 13 January,
2016
            CWP No. 10681 of 2013
                                                                 1
                       IN THE HIGH COURT OF PUNJAB AND HARYANA
                                     AT CHANDIGARH
                                   CWP No. 10681 of 2013
                                   DATE OF DECISION :- January 13, 2016
            The Director, Post Graduate Institute of Medical Education &
            Research, Chandigarh.
                                                         ...Petitioners
                                   Versus
            The Central Administrative       Tribunal,   Chandigarh   Bench,
            Chandigarh and others.
                                                             ...Respondents
                                            CWP No. 19924 of 2013
            The Director, Post Graduate Institute of Medical Education &
            Research, Chandigarh.
                                                         ...Petitioners
                                   Versus
            The Central Administrative       Tribunal,   Chandigarh   Bench,
            Chandigarh and others.
                                                             ...Respondents
                                            CWP No. 19922 of 2013
            The Director, Post Graduate Institute of Medical Education &
            Research, Chandigarh.
                                                         ...Petitioners
                                   Versus
            The Central Administrative       Tribunal,   Chandigarh   Bench,
            Chandigarh and others.Director Pgi Chandigarh vs Cat U.T.Chd. And Ors on 13 January, 2016

                                                            ...Respondents
PARVINDER SINGH
2016.01.13 13:39
I attest to the accuracy and
authenticity of this document
Chandigarh
             CWP No. 10681 of 2013
                                                                  2
                                             CWP No. 19921 of 2013
            The Director, Post Graduate Institute of Medical Education &
            Research, Chandigarh.
                                                         ...Petitioners
                                 Versus
            The Central Administrative        Tribunal,   Chandigarh    Bench,
            Chandigarh and others.
                                                              ...Respondents
                                         CWP No. 25628 of 2013
            The Director, Post Graduate Institute of Medical Education &
            Research, Chandigarh.
                                                         ...Petitioners
                                 Versus
            The Central Administrative        Tribunal,   Chandigarh    Bench,
            Chandigarh and others.
                                                              ...Respondents
                                             CWP No. 14450 of 2013
            Rattan Kaur and others.                          ...Petitioners
                                 Versus
            Union of India and others.                       ...Respondents.
                                             CWP No. 19294 of 2013
            The Director, Post Graduate Institute of Medical Education &Director Pgi Chandigarh vs Cat U.T.Chd. And Ors on 13 January, 2016

            Research, Chandigarh.
                                                         ...Petitioners
PARVINDER SINGH
2016.01.13 13:39
I attest to the accuracy and
authenticity of this document
Chandigarh
             CWP No. 10681 of 2013
                                                               3
                                Versus
            The Central Administrative    Tribunal,   Chandigarh   Bench,
            Chandigarh and others.
                                                      ...Respondents
                                         CWP No. 19296 of 2013
            The Director, Post Graduate Institute of Medical Education &
            Research, Chandigarh.
                                                         ...Petitioners
                                Versus
            The Central Administrative    Tribunal,   Chandigarh   Bench,
            Chandigarh and others.
                                                          ...Respondents
                                         CWP No. 19297 of 2013
            The Director, Post Graduate Institute of Medical Education &
            Research, Chandigarh.
                                                         ...Petitioners
                                Versus
            The Central Administrative    Tribunal,   Chandigarh   Bench,
            Chandigarh and others.
                                                      ...Respondents
                                         CWP No. 19301 of 2013
            The Director, Post Graduate Institute of Medical Education &
            Research, Chandigarh.Director Pgi Chandigarh vs Cat U.T.Chd. And Ors on 13 January, 2016

                                                         ...Petitioners
                                Versus
            The Central Administrative    Tribunal,   Chandigarh   Bench,
            Chandigarh and others.
                                                          ...Respondents
PARVINDER SINGH
2016.01.13 13:39
I attest to the accuracy and
authenticity of this document
Chandigarh
             CWP No. 10681 of 2013
                                                                4
                                         CWP No. 19299 of 2013
            The Director, Post Graduate Institute of Medical Education &
            Research, Chandigarh.
                                                         ...Petitioners
                                Versus
            The Central Administrative    Tribunal,   Chandigarh    Bench,
            Chandigarh and others.
                                               ...Respondents
                                         CWP No. 19300 of 2013
            The Director, Post Graduate Institute of Medical Education &
            Research, Chandigarh.
                                                         ...Petitioners
                                Versus
            The Central Administrative    Tribunal,   Chandigarh    Bench,
            Chandigarh and others.
                                                      ...Respondents
                                         CWP No. 19302 of 2013
            The Director, Post Graduate Institute of Medical Education &
            Research, Chandigarh.Director Pgi Chandigarh vs Cat U.T.Chd. And Ors on 13 January, 2016

                                                         ...Petitioners
                                Versus
            The Central Administrative    Tribunal,   Chandigarh    Bench,
            Chandigarh and others.
                                                      ...Respondents
PARVINDER SINGH
2016.01.13 13:39
I attest to the accuracy and
authenticity of this document
Chandigarh
             CWP No. 10681 of 2013
                                                                5
                                         CWP No. 19298 of 2013
            The Director, Post Graduate Institute of Medical Education &
            Research, Chandigarh.
                                                         ...Petitioners
                                Versus
            The Central Administrative    Tribunal,   Chandigarh    Bench,
            Chandigarh and others.
                                                      ...Respondents
                                         CWP No. 19920 of 2013
            The Director, Post Graduate Institute of Medical Education &
            Research, Chandigarh.
                                                         ...Petitioners
                                Versus
            The Central Administrative    Tribunal,   Chandigarh    Bench,
            Chandigarh and others.
                                               ...Respondents
                                         CWP No. 25660 of 2013Director Pgi Chandigarh vs Cat U.T.Chd. And Ors on 13 January, 2016

            The Director, Post Graduate Institute of Medical Education &
            Research, Chandigarh.
                                                         ...Petitioners
                                Versus
            The Central Administrative    Tribunal,   Chandigarh    Bench,
            Chandigarh and others.
                                                      ...Respondents
PARVINDER SINGH
2016.01.13 13:39
I attest to the accuracy and
authenticity of this document
Chandigarh
             CWP No. 10681 of 2013
                                                                                 6
                                                       CWP No. 19303 of 2013
            The Director, Post Graduate Institute of Medical Education &
            Research, Chandigarh.
                                                         ...Petitioners
                                           Versus
            The Central Administrative                  Tribunal,   Chandigarh       Bench,
            Chandigarh and others.
                                                                         ...Respondents
            CORAM: HON'BLE MR.JUSTICE M.JEYAPAUL
                                HON'BLE MR. JUSTICE DARSHAN SINGH
            Present:- Mr. Rajesh Garg, Senior Advocate
                      with Nimrata Shergil, Advocate for the petitioner.
                                Mr. Brijesh Mittal, Advocate
                                for respondents 5 to 38 in CWP-14450-2013 and
                                respondents 2 to 34 in CWP-19922-2013
                                Mr. Jagdeep Jaswal, AdvocateDirector Pgi Chandigarh vs Cat U.T.Chd. And Ors on 13 January, 2016

                                for the respondents in CWP-10681-2013,
                                CWP-19294-2013, CWP-19296-2013, CWP-19298-2013,
                                CWP-19299-2013, CWP-19300-2013, CWP-19301-2013.
                                Mr. Ashwani Kumar, Respondent no.5 in person
                                Ms. Monika Jalota, Advocate for Mr. R.P.Singh, Advocate
                                for respondent no. 28
                                Mr. Kapil Kakkar, Advocate for the petitioners
                                in CWP No.14450 of 2013
                                Mr. Satbir S. Katnoria, Advocate
                                for respondent No.4 in CWP No.19302 of 2013
                                for respondent No.5 in CWP No.19303 of 2013
                                for respondent No.12 in CWP No.10681 of 2013
                                for respondent No.15 to 27 & 29 to 32 in CWP No.19924
                                of 2013
PARVINDER SINGH
2016.01.13 13:39
I attest to the accuracy and
authenticity of this document
Chandigarh
             CWP No. 10681 of 2013
                                                                                 7
                                 Mr. Babbar Khan, Advocate
                                 and Mr. Ravi Kant, Advocate for respondents no. 2 to 77.
                                 Mr. Ashwani Kumar Munjal-Respondent no.5 in person.
                                                ***
            1.         Whether Reporters of local papers may be allowed to see the
                       judgment?             Yes
            2.         To be referred to the Reporters or not?      Yes
            3.         Whether the judgment should be reported in the digest?          Yes
            M.JEYAPAUL, J.
Introduction :-
1. a)Aggrieved by the impugned order passed by the Tribunal directing the Post
Graduate Institute of Medical Education and Research, Chandigarh (PGI) to grant
the benefit of "Catch up Rule" to the contesting private respondents herein, (PGI) has
preferred these batch of Writ Petitions except Writ Petition No. 14450 of 2013 which
has been filed by the Scheduled Caste and Scheduled Tribe category employees.
b)C.W.P. Nos. 10681 of 2013, 19302 of 2013, 19303 of 2013 and 19924 of 2013 relate to the claim
made by the Senior Laboratory Technicians/Technical Assistant, CWP No. 19921 of 2013 by the
Private Secretaries, CWP No. 25660 of 2013 by the Store Officer and the remaining Writ Petitions byDirector Pgi Chandigarh vs Cat U.T.Chd. And Ors on 13 January, 2016

the Nursing Establishment of the medical dispensation for grant of the benefit of "Step up Rule"
enunciated by the Hon'ble Supreme Court of India. Pleadings :-
2. a)The pleadings of the parties in the respective Original Applications are found to
be quite identical in character. For the sake of brevity and also to avoid repetition, let
us give a brief account of the averments made by the applicants in O.A. No.
56/CH/2012 relating to CWP NO. 10681 of 2013.
b)The applicants belong to General Category whereas the 2nd respondent belongs to Scheduled
Caste category. The applicants were initially appointed with PGI as Junior Laboratory Technicians
on different dates and were Senior to the 2nd respondent Surinder Singh Banga. The next
promotional post for Junior Lab Technician is Senior Laboratory Technician which is filled up 100%
by promotion since 1981. the 2nd respondent therein being an employee belonging to Scheduled
Caste category was promoted as Senior Lab Technician prior to the applicants w.e.f. 14.8.1997
applying the rule of reservation. The applicants who belong to General Category were promoted as
Senior Laboratory Technician on various dates during the period from 27.9.2001 to 20.12.2002. At
the time of promotion of the applicants as Senior Laboratory Technician, respondent no.2 also was
in the same cadre.
c)The applicants seek benefit of "Catch up Rule" in terms of judgment passed by the Constitutional
Bench of the Hon'ble Supreme Court of India in the case of M. Nagaraj and others versus Union of
India and others (2006) 8 SCC 212. All the applicants are eligible for grant of "Catch up Rule" and
fixation of seniority above their juniors. They also seek quashment of the impugned promotion
order dated 15.1.2011 vide which their junior Surinder Singh Banga shown as 2nd respondent
therein has been promoted as Technical Assistant. Similar orders granting the benefit of "Catch up
Rule" have been passed by the PGI on 14.9.2010 and 13.4.2011. Parity of treatment in applying the
principles of "Catch up Rule" has also been sought by the applicants. Similar benefit of "Catch up
Rule" granted to one Gurmail Ram vide order dated 14.9.2010 w.e.f. 1.3.1992, as per the judgment of
the Central Administrative Tribunal, Chandigarh in T.A. No. 146 of 2009 pronounced on 25.5.2010
be extended to the applicants also.
d) PGI has contended in its written statement that the Original Applications filed by the applicants
are time barred, as they have failed to claim the benefit of the judgment in M.Nagaraj (supra) which
came to be pronounced in the year 2007 within 1½ years from the date of pronouncement of the
above judgment as provided for in the Central Administrative Tribunal's Act, 1985. The 85th
Constitutional amendment which introduced the phrase "with consequential seniority" was
validated by the Hon'ble Supreme Court in M. Nagaraj. The seniority of Gurmail Ram was fixed
above Jasmer Singh as Senior Lab Technician w.e.f. 1.3.1992, but he is not entitled to further
promotion as Technical Assistant in view of the 85th Constitutional amendment w.e.f. 17.6.1995.
3. Verdict of Tribunal :-
The Tribunal having referred to the judgments in Indra Sawhney versus Union of
India (1993 Vol.I SCT 448), Virpal Singh Chauhan etc. 1995(4) SCT 695, M. NagarajDirector Pgi Chandigarh vs Cat U.T.Chd. And Ors on 13 January, 2016

and others versus Union of India and others (2006) 8 SCC 212, Suraj Bhan Meena
and another versus State of Rajasthan and others SLP(Civil) No. 6385 of 2010
decided on 7.12.2010 and Laxmi Narayan Gupta versus Jas Singh & Others CWP No.
13218 of 2009 decided on 15.7.2011 held that so long as no survey was undertaken by
the State to find out inadequacy of representation in respect of members of the
Scheduled Caste and Scheduled Tribe in the services, the benefit of "Catch up Rule"
will have to be granted to the General Category employees.
4. March of Law :-
a) Article 16(4) of the Constitution :-
Article 16(4) of the Constitution of India which has made departure from the
principle of equality asserting positive discrimination reads as follows :-
"Nothing in this article shall prevent the State from making any provision for the
reservation of appointments or posts in favour of any backward class of citizens
which, in the opinion of the State, is not adequately represented in the services under
the State."
b) Indra Sawhney and others versus Union of India and others 1992 (supp.) (3)
Supreme Court cases 217 :-
Article 16(4) of the Constitution of India which enables the State to make provision
for reservation of appointments of posts in favour of Backward Class of citizens was
put to test in the above case. It was held therein that provision for reservation for
Backward Class can be made only in the matter of initial appointments. However,
there would be no reservations for them in the matter of promotions. Union of India
Versus Virpal Singh Chauhan and others 1995(4) SCT 695 affirmed the above
decision in Indra Sawhney (supra).
c)77th Amendment :-
The parliament having found that the Scheduled Caste and Scheduled Tribe
employees have been enjoying the facility of reservation in promotion since 1955 but
the ruling of the Hon'ble Supreme Court in Indra Sawhney (supra) has the propensity
to adversely effect the interest of Scheduled Caste and Scheduled Tribe employees,
felt the necessity of continuing the existing dispensation of providing reservation in
promotion in the case of the Scheduled Caste and the Scheduled Tribe employees. In
a positive expression of commitment of the government to protect the interest of
Scheduled Castes and Scheduled Tribes, the government have decided to continue
the existing policy of reservation in promotion for the Scheduled Castes and
Scheduled Tribes. To carry out the above avowed object, the Parliament amended
Article 16 of the Constitution of India by inserting a new clause 4A in the said ArticleDirector Pgi Chandigarh vs Cat U.T.Chd. And Ors on 13 January, 2016

to provide for reservation in promotion of the Scheduled Castes and Scheduled Tribes
on introduction of constitutional 77th amendment. Article 16(4A) of the Constitution
of India reads as follows :-
"Nothing, in this article shall prevent the State from making any provision for
reservation in matters of promotion to any class or classes of posts in the services
under the State in favour of the Scheduled Castes and the Scheduled Tribes which, in
the opinion of the State, are not adequately represented in the services under the
State."
It is to be noted that Article 16(4) of the Constitution of India speaks of reservation of
appointments in favour of any Backward Class of citizens but Article 16(4A) enables
the State to make provision for reservation in the matters of promotion to any post in
the services under the State in favour of the Scheduled Castes and Scheduled Tribes.
Of course, the State will have to arrive at a decision before resorting to the above
Constitutional provision that the Scheduled Castes and Scheduled Tribes are not
adequately represented in the services.
d) Union of India and others versus Virpal Singh Chauhan etc.1995(6) SCC 684 :-
The question that arose for determination before the Hon'ble Supreme Court of India
in the above case was whether any employee belonging to Scheduled Caste or
Scheduled Tribe category who got promotion earlier than his senior in General
Category because of reservation would also get consequential seniority in the
promotion post. The Hon'ble Supreme Court held that Scheduled Caste or Scheduled
Tribe category employee who was promoted earlier by virtue of Rule of
reservation/roster shall not be entitled to seniority over his senior in the feeder
category and that as and when a General Category candidate who was senior to him
in the feeder category is promoted, such General candidate will gain his seniority over
the reserved candidate, not withstanding the fact that he is promoted subsequent to
the reserved candidate. The above judicially formulated principle is called as "Catch
up Rule".
(e) 85th Constitutional amendment :-
The government felt that government servants belonging to the Scheduled Caste and
Scheduled Tribe who had been enjoying the benefit of consequential seniority on
their promotion on the basis of Rule of Reservation had received a jolt by the
judgment of the Hon'ble Supreme Court in Virpal Singh Chauhan (supra). The
government reviewed the position in the light of the views received from the various
quarters and in order to protect the interest of the government servants belonging to
Scheduled Caste and Scheduled Tribe it decided to bring an amendment to Article
16(4A) of the Constitution of India to provide for consequential seniority in the case
of promotion by virtue of Rule of Reservation. It also decided to give retrospectiveDirector Pgi Chandigarh vs Cat U.T.Chd. And Ors on 13 January, 2016

effect to the Constitutional amendment introduced to Article 16(4A) from the date of
coming into force of Article 16(4A) itself i.e. from the 17th day of June, 1995. The
amended Article 16 (4A) by virtue of the Constitutional 85th Amendment Act 2001
reads as follows :-
"Nothing in this article shall prevent the State from making any provision for
reservation in matters of promotion to any class with consequential seniority to any
class or classes of posts in the services under the State in favour of the Scheduled
Castes and the Scheduled Tribes which, in the opinion of the State, are not
adequately represented in the services under the State."
5. Submissions :-
a)It is the admitted case of PGI that they have never collected quantifiable data
disclosing inadequacy of representation of the Scheduled Castes and Scheduled
Tribes. In the above background it was submitted by the 5th respondent in CWP No.
19924 of 2013 and the learned counsel appearing for the contesting respondents in all
the Writ Petitions that the contesting respondents are entitled to the benefit of "Catch
up Rule" even after 85th constitutional Amendment. They also cited the decision of
the Hon'ble Supreme Court in Suraj Bhan Meena and another versus State of
Rajasthan and others Special Leave Petition (Civil) No. 6385 of 2010 decided on
7.12.2010, Lachhmi Narain Gupta and others versus Jarnail Singh and others CWP
No. 13218 of 2009 decided on 15.7.2011 by the Coordinate Bench of this Court and S.
Panneer Selvam and others versus Government of Tamil Nadu and Others Civil
Appeal Nos. 6631-6632 of 2015 decided on 27.8.2015 by the Hon'ble Supreme Court
to strengthen their submissions that in the absence of quantifiable data reflecting
inadequacy of representation of the Scheduled Castes and Scheduled Tribes, the
"Catch up Rule"
should be applied.
b)Per contra, the learned Senior Counsel appearing for PGI who is the petitioner in
all the Writ Petitions except CWP No. 14450 of 2013 submitted that though the
quantifiable data as regards inadequacy of representation of the Scheduled Caste and
Scheduled Tribe employees had not been collected by the PGI or the Union of India
who has control over PGI, the benefit of "Catch up Rule" is applicable only upto
17.6.1995, the date from which the 85th amendment introducing the phrase "with
consequential seniority" in Article 16(4A) of the Constitution has been made effective.
It is his further submission that even assuming that the State cannot give effect to the
above amendment introduced to Article 16(4A), unless quantifiable data as stated
above has been collected, the rider introduced by the Hon'ble Supreme Court in M.
Nagaraj (supra) will be effective only from the date of the judgment. At any rate, it is
submitted by him that the concept of "Catch up Rule" was completely erased by M.
Nagaraj (supra). Learned counsel for the Writ Petitioners in CWP No. 14450 of 2013Director Pgi Chandigarh vs Cat U.T.Chd. And Ors on 13 January, 2016

submitted that in view of the clear mandate in Article 16(4A) of the Constitution and
memorandum and clarificatory memorandum issued by Government of India, the
Writ Petitioners are entitled to promotion with consequential seniority.
6. Discussion :-
a) M. Nagaraj :-
In M. Nagaraj and others versus Union of India and others (2006) 8 SCC 212, it has
been held by the Hon'ble Supreme Court, while upholding the validity of 85th
amendment which introduced the important phrase "with consequential seniority" in
Article 16(4A) of the Constitution of India as follows:-
"81. Reading the above judgments, we are of the view that the concept of 'Catch up
Rule' and 'consequential seniority' are judicially evolved concepts to control the
extent of reservation. The source of these concepts is in service jurisprudence. These
concepts cannot be elevated to the status of an axiom like secularism, constitutional
sovereignty etc. It cannot be said that by insertion of the concept of 'consequential
seniority' the structure of Article 16(1) stands destroyed or abrogated.
It cannot be said that 'equality code' under Article 14, 15 and 16 is violated by deletion of the 'Catch
up Rule'. These concepts are based on practices. However, such practices cannot be elevated to the
status of a constitutional principle so as to be beyond the amending power of the Parliament.
Principles of service jurisprudence are different from constitutional limitations. Therefore, in our
view neither the 'Catch up Rule' nor the concept of 'consequential seniority' are implicit in clauses
(1) (4) of Article 16 as correctly held in Virpal Singh Chauhan (1995) 6 SCC 684.
83. The judgment in the case of M.G. Badappanavar 2001 (2) SCC 666 was mainly based on the
judgment in Ajit Singh (I) 1996(2) SCC 715 which had taken the view that the departmental circular
which gave consequential seniority to the 'roster- point promotee', violated Articles 14 and 16 of the
constitution. In none of the above cases, the question of the validity of the constitutional
amendments was involved. Ajit Singh (I) 1996(2) SCC 715, Ajit Singh (II) 1999 (7) SCC 209 and
M.G. Badappanavar 2001 (2) SCC 666 were essentially concerned with the question of 'weightage'.
Whether weightage of earlier accelerated promotion with consequential seniority should be given or
not to be given are matters which would fall within the discretion of the appropriate Government,
keeping in mind the backwardness, inadequacy of representation in public employment and overall
efficiency of services. The above judgments, therefore, did not touch the questions which are
involved in the present case.
84. Before dealing with the scope of the constitutional amendments we need to recap the judgments
in Indra Sawnhey 1992 Supp. (3) SCC 217 and R.K. Sabharwal (1995) 2 SCC 745. In the former case
the majority held that 50% rule should be applied to each year otherwise it may happen that the
open competition channel may get choked if the entire cadre strength is taken as a unit. However in
R.K. Sabharwal (1995) 2 SCC 745, this court stated that the entire cadre strength should be takenDirector Pgi Chandigarh vs Cat U.T.Chd. And Ors on 13 January, 2016

into account to determine whether the reservation up to the quota-limit has been reached. It was
clarified that the judgment in Indra Sawhney 1992 Supp. (3) SCC 217 was confined to initial
appointments and not to promotions. The operation of the roster for filling the cadre strength, by
itself, ensure that the reservation remains within the ceiling-limit of 50%.
85. In our view, appropriate Government has to apply the cadre strength as a unit in the operation
of the roster in order to ascertain whether a given class/group is adequately represented in the
service. The cadre strength as a unit also ensures that upper ceiling- limit of 50% is not violated.
Further, roster has to be post- specific and not vacancy based.
124. The impugned constitutional amendments by which Articles 16(4A) and 16(4B) have been
inserted flow from Article 16(4). They do not alter the structure of Article 16 (4). They retain the
controlling factors or the compelling reasons, namely, backwardness and inadequacy of
representation which enables the States to provide for reservation keeping in mind the overall
efficiency of the State administration under Article 335. These impugned amendments are confined
only to SCs and STs. They do not obliterate any of the constitutional requirements, namely,
ceiling-limit of 50% (quantitative limitation), the concept of creamy layer (qualitative exclusion), the
sub- classification between OBC on one hand and SCs and STs on the other hand as held in Indra
Sawhney 1992 Supp. (3) SCC 217, the concept of post-based Roster with in-built concept of
replacement as held in R.K. Sabharwal (1995) 2 SCC 745.
125. We reiterate that the ceiling-limit of 50%, the concept of creamy layer and the compelling
reasons, namely, backwardness, inadequacy of representation and overall administrative efficiency
are all constitutional requirements without which the structure of equality of opportunity in Article
16 would collapse.
126. However, in this case, as stated, the main issue concerns the "extent of reservation". In this
regard the concerned State will have to show in each case the existence of the compelling reasons,
namely, backwardness, inadequacy of representation and overall administrative efficiency before
making provision for reservation. As stated above, the impugned provision is an enabling provision.
The State is not bound to make reservation for SC/ST in matter of promotions. However if they wish
to exercise their discretion and make such provision, the State has to collect quantifiable data
showing backwardness of the class and inadequacy of representation of that class in public
employment in addition to compliance of Article 335. It is made clear that even if the State has
compelling reasons, as stated above, the State will have to see that its reservation provision does not
lead to excessiveness so as to breach the ceiling-limit of 50% or obliterate the creamy layer or extend
the reservation indefinitely.
127. Subject to above, we uphold the constitutional validity of the Constitution (Seventy-Seventh
Amendment) Act, 1995, the Constitution (Eighty-First Amendment) Act, 2000, the Constitution
(Eighty-Second Amendment) Act, 2000 and the Constitution (Eighty-Fifth Amendment) Act, 2001."
There is a clear mandate in M. Nagaraj that the State which prefers to exercise its discretion to make
provision for reservation in promotion with consequential seniority for the Scheduled Caste andDirector Pgi Chandigarh vs Cat U.T.Chd. And Ors on 13 January, 2016

Scheduled Tribe employees is duty bound to collect quantifiable data reflecting backwardness of the
class and inadequacy of the representation of that class in public employment in addition to
compliance of Article 335 of the Constitution of India.
b)Suraj Bhan Meena :-
The effect of failure on the part of the State to comply with the above rider in M.
Nagaraj has been dealt in Suraj Bhan Meena as follows :-
"46. The position after the decision in M. Nagaraj's case (supra) is that reservation of
posts in promotion is dependent on the inadequacy of representation of members of
the Scheduled Castes and Scheduled Tribes and Backward Classes and subject to the
condition of ascertaining as to whether such reservation was at all required. The view
of the High Court is based on the decision in M. Nagaraj's case (supra). As no exercise
was undertaken in terms of Article 16(4-A) to acquire quantifiable data regarding the
inadequacy of representation of the Schedule Castes and Scheduled Tribes
communities in public services, the Rajasthan High Court has rightly quashed the
notification dated 28.12.2002 and 25.4.2008 issued by the State of Rajasthan
providing for consequential seniority and promotion to the members of the
Scheduled Castes and Scheduled Tribes communities and the same does not call for
any interference. Accordingly, the claim of Petitioners Suraj Bhan Meena and Sriram
Choradian in Special Leave Petition (Civil) No. 6385 of 2010 will be subject to the
conditions laid down in M. Nagaraj's case (supra) and is disposed of accordingly.
Consequently, Special Leave Petition (C ) Nos. 7716, 7717, 7826 of 2010, filed by the
State of Rajasthan, are also dismissed."
In the aforesaid case, State of Rajasthan made provision for consequential seniority by issuing
notifications dated 28.12.2002 and 25.04.2008. It was put to challenge before the Rajasthan High
court which took a decision to quash the notifications as the mandate in M. Nagaraj was not
complied with by the State of Rajasthan while issuing the above notifications. The Hon'ble Supreme
Court interpreted the import of M. Nagaraj and held that Rajasthan High Court has rightly quashed
the above notifications providing for consequential seniority in the matter of promotion to the
members of the Scheduled Castes and Scheduled Tribes as inadequacy of representation of that
class was not quantified and demonstrated.
c)Laxmi Narayan Gupta :-
The coordinate Bench of this Court following the decisions in M. Nagaraj and Suraj
Bhan Meena observed in Laxmi Narayan Gupta (supra) as follows :-
"38. When the principles laid down in the case of M. Nagaraj (supra) and Suraj Bhan
Meena (supra) are applied to the notifications impugned in the present proceedings,
namely, 11.7.2002, 31.1.2005 (R-1 and R-2) and further notification dated 21.1.2009
and 10.8.2010, it becomes clear that no survey has been undertaken to find outDirector Pgi Chandigarh vs Cat U.T.Chd. And Ors on 13 January, 2016

inadequacy of representation in respect of members of the SC/ST in the services. The
aforesaid fact has been candidly admitted ini the written statement filed by
respondent Nos. 5 and 6. The aforesaid fact has also been conceded by the
respondent-Union of India in the communication dated 15.9.2010. In para (iv) of the
aforesaid communication it has been stated that no exercise was carried out to assess
the inadequacy of representation of SC/STs in the services under the Government of
India before issue of instructions dated 31.1.2005. The aforementioned
communication has been placed on record along with CM No. 14865 of 2010. In the
absence of any survey with regard to inadequacy as also concerning the overall
requirement of efficiency of the administration where reservation is to be made along
with backwardness of the class for whom the reservation is required, it is not possible
to sustain these notifications. Accordingly, it has to be held that these notifications
suffer from violation of the provisions of Articles 16(4A), 16(4B) read with Article 335
of the Constitution as interpreted by the Constitution Bench in M. Nagaraj's case
(supra) as well as in Suraj Bhan Meena's case (supra)."
This Court has observed in the above judgment that the State should have embarked upon the
exercise of assessing the inadequacy of representation of the members of the Scheduled Castes and
Scheduled Tribes before issuing instructions to give promotion with consequential seniority to the
employees of the Scheduled Castes and Scheduled Tribes.
d) S. Paneer Selvem :-
In S. Paneer Selvem (supra) the same question which has arisen for determination in
these Writ Petitions came up for consideration and the Hon'ble Supreme court has
ruled as follows :-
"31. The respondents' submission regarding inadequacy of representation of
Scheduled Castes/Scheduled Tribes in the Tamil Nadu Highways Engineering Service
by itself is not sufficient to uphold the inadequacy of representation of SCs/STs in the
said service. Even after Eighty-fifth Amendment, the State is duty bound to collect
data so as to assess the adequacy of representation of the Scheduled Caste candidates
in the service and based on the same the State should frame a policy/rules for
consequential seniority. No material is placed on record that the State of Tamil Nadu
has ever undertaken such exercise of collecting date of adequacy of representation of
the SC/ST candidates in the Tamil Nadu Highways Engineering Service. In the
absence of any rule conferring consequential seniority in the State of Tamil Nadu
'Catch up Rule' is applicable even amongst Junior Engineers promoted as ADEs
following rule of reservation and also for their inter-se seniority amongst AEs
promoted as ADEs and JEs promoted as ADEs following rule of reservation."
In the above decision, the Hon'ble Supreme Court finding that the there was no quantifiable data
collected by the State before making provisions for consequential seniority categorically held that
"Catch up Rule" will apply and as a result of which senior General Category candidates who wereDirector Pgi Chandigarh vs Cat U.T.Chd. And Ors on 13 January, 2016

promoted later in point of time than that of their juniors belonging to Scheduled Caste and
Scheduled Tribe Category will regain their seniority once they are promoted.
The above decision of the Hon'ble Supreme Court completely answers the question that has arisen
for determination in these Writ Petitions. Therefore, we have no hesitation to hold that Union of
India who has not collected any quantifiable data reflecting inadequacy of representation of the
members of Scheduled Castes and Scheduled Tribes cannot validly contend that "Catch up Rule"
will not apply to the General Category promotees.
7.Doctorine of overruling :-
a)The learned Senior Counsel appearing for PGI raised a very interesting issue
touching the doctrine of over ruling. It is his submission that the judgment in M.
Nagaraj upholding the 85th Constitutional amendment with a rider will apply only
prospectively and that, therefore, the action of the PGI prior to the verdict in M.
Nagaraj cannot be faulted. Per contra, the learned counsel appearing for the other
private respondents in all the Writ Petitions contended that it is a well settled
proposition of law that a decision rendered by the Court deciding the validity of a
statute under challenge will take effect from the date when the statute was made
operative.
b) The above controversy came up for determination by the Hon'ble Supreme Court
in M.A. Murthy versus State of Karnataka 2003 (7) SCC 517 wherein it was observed
as follows :-
"8. ........... The doctrine of prospective over-ruling which is a feature of American
jurisprudence is an exception to the normal principle of law, was imported and
applied for the first time in L.C. Golak Nath and others v. State of Punjab and another
(AIR 1967 SC 1643). In Managing Director, ECIL, Hyderabad and others vs. B.
Karunakar and others (1993 (4) SCC 727) : 1994(1) SCT 319 (SC) the view was
adopted. Prospective over-ruling is a part of the principles of constitutional canon of
interpretation and can be resorted to by this Court while superseding law declared by
it earlier. It is a device innovated to avoid reopening of settled issues, to prevent
multiplicity of proceedings, and to avoid uncertainty and avoidable litigation. In
other words, actions taken contrary to the law declared prior to the date of
declaration are validated in larger public interest. The law as declared applied to
future cases. (See Ashok Kumar Gupta vs. State of U.P., (1997) 5 SCC 201 : 1997(2)
SCT 381 (SC), Baburam v.
C.C. Jacob (1999) 3 SCC 362) : 1999(2) SCT 529 (SC). It is for this Court to indicate as to whether
the decision in question will operate prospectively. In other words, there shall be no prospective
over-ruling, unless it is so indicated in the particular decision. It is not open to be held that the
decision in a particular case will be prospective in its application by application of the doctrine ofDirector Pgi Chandigarh vs Cat U.T.Chd. And Ors on 13 January, 2016

prospective over-ruling."
c) In a later decision in General Manager, Uttranchal Jal Sansthan versus Laxmi Devi and others
2010(1) SCT 187, the Hon'ble Supreme Court reiterated the above view and held as follows:-
"29. Submissions of the learned counsel for the respondents is that the said decision
is not applicable :
a) as it was rendered in 2006 whereas the cause of action for filing the writ petitions
arose in 2002 and b) a distinction must be made between the appointment on ad hoc
basis and appointment on compassionate ground. As to the first submission above, it
is worth mentioning that judicial decisions unless otherwise specified are
retrospective. They would only be prospective in nature if it has been provided
therein. Such is clearly not the case in Umadeyi (supra)."
d) There is no observation in M. Nagaraj that the pre- condition mandated for providing reservation
in promotion and consequential seniority while upholding 85th amendment would apply only
prospectively. Therefore, applying the above ratio laid down by the Hon'ble Supreme Court, we have
no hesitation to hold that the mandates in the shape of rider contemplated in M. Nagaraj (supra)
will take effect from 17.6.1995, the date on which 85th amendment was supposed to take effect.
8.Claim on parity :-
a) Learned Senior Counsel appearing for PGI submitted that the contesting
respondents have also been given the benefit of "Catch up Rule" upto 17.6.1995 in
terms of the judgment in Gurmail Ram in T.A. No. 146/CH/2009 dated 7.12.2009
and 25.5.2010.
Therefore, it is contended that the claim of the contesting respondents for application of "Catch up
Rule" has been taken care of by applying the decision in Gurmail Ram. Per contra, the 5th
respondent in CWP NO. 19924 of 2013 and the learned counsel appearing for private respondents in
other Writ Petitions vehemently contended that they are entitled to the benefit of "Catch up Rule"
even after 17.6.1995 as M. Nagaraj has retrospective application.
b)We are in full agreement with the submissions made on the side of the contesting
respondents. We have already held relying upon the decision in M.A. Murthy and
Laxmi Devi that the ruling in M. Nagaraj will apply retrospectively. In other words,
the amendment introduced vide 85th amendment to Article 16(4A) of the
Constitution will apply with the above rider in M. Nagaraj from the date when 85th
amendment was supposed to have come into force. Therefore, the contesting
respondents are entitled to enjoy the concept of "Catch up Rule" evolved by the
judiciary. But we make it clear that the above "Catch up Rule" will have no
application to the employees belonging to Scheduled Caste and Scheduled TribeDirector Pgi Chandigarh vs Cat U.T.Chd. And Ors on 13 January, 2016

category who have been promoted on their own merit/seniority sans any concession
granted to them.
9.Limitation :-
a) It was lastly urged by the learned Senior Counsel appearing for PGI that the claim
of the contesting respondents are hopelessly barred by limitation, inasmuch as they
have not challenged the seniority fixed at the relevant point of time. It was contended
by the 5th respondent in CWP NO. 19924 of 2013 and the learned counsel appearing
for the other private respondents that they were under legitimate expectation that the
benefit granted to the co-employee Gurmail Ram in T.A. No. 146/CH/2009 would be
extended to them. But unfortunately it was denied and, therefore, they had to step
into the portals of the Court of Law to redress their grievances.
b) Some of the aggrieved parties to the common judgment under challenge before
this Court earlier challenged before the Coordinate Bench of this Court which has
already held that the claim of the contesting respondents was not barred by
limitation.
Further, it is noticed that the benefit of "Catch up Rule" accorded to a co-employee by name Gurmail
Ram in T.A. No. 146/CH/2009 was not extended to the contesting respondents. Therefore, we are of
the view that the contesting respondents cannot be shown the doors on the technical ground that
they have knocked at the doors of the Court belatedly.
10.Victims of circumstances & wake up call :-
a) The State has a constitutional duty to empower certain sections of society who
needed succor to uplift themselves from their contemptible situation. Article 46 of
the Constitution of India, though a directive principle, is in the nature of benchmark
for good governance to the government. The above Article was intended to help the
depressed classes who otherwise had little opportunity of raising their standards.
b) M.Nagaraj was pronounced by the Hon'ble Supreme Court on 19.10.2006. The
85th amendment which was upheld in M. Nagaraj, of course, with a rider, has taken
effect from 17.6.1995, the date on which 85th amendment was supposed to take
effect. The parliament in its wisdom has introduced a provision in Article 16(4A) to
grant reservation in promotion with consequential seniority to the Scheduled Caste
and Scheduled Tribe category employees, if in the opinion of the State they have not
been adequately represented. The Courts have interpreted that quantifiable data to
reflect the inadequacy of representation of the employees of Scheduled Caste and
Scheduled Tribe should be collected by the State before venturing into the affirmative
action in terms of Article 16(4A) of the Constitution. It is really paining to note that
the employees of the Scheduled Caste and Scheduled Tribe, who have been given
such a Constitutional protection under Article 16(4A) have been compelled toDirector Pgi Chandigarh vs Cat U.T.Chd. And Ors on 13 January, 2016

approach the Courts to give effect to the Constitutional provision introduced by 85th
amendment. On the other hand, General Category employees taking advantage of the
fact that the State is reluctant to take required efforts to comply with the mandates in
M. Nagaraj institute number of cases before the Court of law. In the unequal fight,
the Scheduled Caste and Scheduled Tribe employees have suffered very much. In
spite of such a Constitutional provision introduced to grant benefit to the socially,
economically, culturally and educationally disadvantaged sections of the society, they
could not enjoy the fruits thereof.
c) I am aware of the dictum in M. Nagaraj that the provision in Article 16(4A) is only
an enabling provision. In other words the State is not bound to make reservation for
SC/ST in matters of promotion. But once they have chosen to make reservation in
promotion in terms of the above Article, they have to collect quantifiable data
showing inadequacy of representation of SC/ST. In the instant case official
memorandum No. 20011/1/2001-
Estt.(D) Government of India, Ministry of Personnel, Public Grievances and Pensions (Department
of Personnel and Training), New Delhi dated 21.1.2002 reflects that the Union of India has exercised
its discretion to make provision for reservation in promotion. Learned counsel for Union of India
also admitted the above position. But it failed its constitutional duty to collect quantifiable data as
mandated in M. Nagaraj. In fact in a subsequent decision in S.V. Joshi and others vs. State of
Karnataka and others (2012) 7 SCC 41, the Hon'ble Supreme Court had an occasion to direct the
States concerned in terms of M. Nagaraj to collect quantifiable data for validating reservation.
d) There was patent failure on the part of the States in not following the mandates in M. Nagaraj in
spite of the fact that they have decided to exercise their option to make reservation in promotion and
left the members of the Scheduled Caste and Scheduled Tribe to suffer for the past nine long years.
It appears that the States expect a Writ of Mandamus to embark upon an affirmative action. Such a
despicable attitude of the State in not adhering to the mandates of the Court while making an
attempt to enforce the benevolent provision of the Constitution is really contemptible. Had the
States woken up to the reality in the light of the decision in M. Nagaraj, hundreds of Original
Applications before the various Administrative Tribunals and hundreds of Writ Petitions before the
High Courts in our country could have been avoided. The callous inaction on the part of the States in
not collecting the quantifiable data as mandated in M. Nagaraj has virtually generated resourceful
litigation in the country. In fact, injustice had been perpetuated to the members of the Scheduled
Castes and Scheduled Tribes who longed to reap the benefit of Article 16(4A). Now it is time to wake
up the sleeping giant.
11. Mandate to remove injustice :-
a) In view of the above, Union of India is directed to collect quantifiable data as
regards the inadequacy of representation of the Scheduled Caste and Scheduled Tribe
employees in promotion post of all cadres in all the departments, institutions and
undertakings under its domain and control in which they have exercised theirDirector Pgi Chandigarh vs Cat U.T.Chd. And Ors on 13 January, 2016

discretion to accord reservation in promotion and formulate a policy to grant the
benefit of reservation in promotion with consequential seniority to the members of
the Scheduled Caste and Scheduled Tribe in terms of Article 16(4A) of the
Constitution of India.
b) Article 335 of the Constitution of India provides that while making appointment to
services and posts in connection with the affairs of the Union of India or of a State,
the claim of the members of Scheduled Caste and Scheduled Tribe shall be taken into
consideration consistently with the maintenance of efficiency of administration. A
provision has been introduced in the Article 335 by the Constitution (82nd
Amendment) Act, 2000 w.e.f. 8.9.2000 to the effect that while making reservation in
matters of promotion to the members of the Scheduled Castes and Scheduled Tribes,
there is no bar for the States to give relaxation in qualifying marks in any
examination or lower the standards of evaluation. Union of India shall also address
the above proviso provided under Article 335 of the Constitution of India while
formulating the policy referred to above.
The above exercise as directed by us shall be completed by Union of India within three months from
the date of this judgment.
12. Result :-
In the result, I find that there is virtually no scope for review of the well merited
common judgment passed by the Tribunal. Therefore all these Writ Petitions stand
dismissed with the above direction.
(M. JEYAPAUL) JUDGE (DARSHAN SINGH) JUDGE January 13, 2016 p.singhDirector Pgi Chandigarh vs Cat U.T.Chd. And Ors on 13 January, 2016

