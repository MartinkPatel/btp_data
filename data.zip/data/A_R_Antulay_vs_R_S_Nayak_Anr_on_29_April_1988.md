A.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988
Equivalent citations: 1988 AIR 1531, 1988 SCR SUPL. (1) 1, AIR 1988
SUPREME COURT 1531, 1988 (2) SCC 602, 1988 SCC(CRI) 372, 1988 (16) IJR
(SC) 452, 1988 (2) JT 325, (1988) SC CR R 577
Author: Sabyasachi Mukharji
Bench: Sabyasachi Mukharji, Misra Rangnath, G.L. Oza, B.C. Ray
           PETITIONER:
A.R. ANTULAY
        Vs.
RESPONDENT:
R.S. NAYAK & ANR.
DATE OF JUDGMENT29/04/1988
BENCH:
MUKHARJI, SABYASACHI (J)
BENCH:
MUKHARJI, SABYASACHI (J)
RANGNATHAN, S.
VENKATACHALLIAH, M.N. (J)
VENKATACHALLIAH, M.N. (J)
MISRA RANGNATH
OZA, G.L. (J)
RAY, B.C. (J)
CITATION:
 1988 AIR 1531            1988 SCR  Supl. (1)   1
 1988 SCC  (2) 602        JT 1988 (2)   325
 CITATOR INFO :
 F          1989 SC1335  (22,23)
 D          1990 SC 535  (3)
 R          1990 SC1480  (55)
 R          1990 SC1737  (6)
 R          1990 SC1828  (16)
 RF         1991 SC 101  (66)
 E&D        1991 SC 818  (30)
 RF         1991 SC 884  (16)
 D          1991 SC2176  (51)
 RF         1992 SC 248  (41,42,43)
 RF&E       1992 SC 522  (23)
 RF         1992 SC 604  (140,143)
 R          1992 SC1277  (25)
 RF         1992 SC1701  (9,10,58)A.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

ACT:
     Constitution of  India, 1950:  Articles 13,  14, 21, 32
Prosecution of appellant for offences under sections 161 and
165 I.P.C.-Trial  under Criminal  Law Amendment Act, 1952 to
be held  by Special Judge only-Supreme Court in its judgment
directing trial  to be  held by High Court Judge-Validity of
Supreme Court  Judgment-Whether infringement  of fundamental
right of  accused involved-Whether  procedure established by
law  violated-Power   to  create  or  enlarge  jurisdiction-
Legislative in character.
Articles 32,  134, 136, 737, 139, 141 and 142-Powers of
review-Nature and  scope of-Whether Supreme Court can review
its directions  if they result in deprivation of fundamental
rights of  a citizen-Whether Supreme Court can issue writ of
certiorari to  quash judicial order passed by another Bench-
Whether a  larger Bench can overrule or recall a decision of
a smaller Bench.
Articles 140,  141, 142  and 145: Jurisdiction-Want of-
Can be  established only by a superior court-No decision can
be impeached  collatterally by  any inferior  court-Superior
court can  always correct  errors by  petition or  ex debito
justitiae Judgments per incuriam-Effect of.
Criminal Law  (Amendment) Act,  1952: Sections  6 &  7-
offences under  Act to  be tried only by Special Judge-order
of Supreme  Court transferring  and directing  trial by High
Court Judge-Whether  legally authorised-Non-substante clause
in s.7(1)-Effect of.
Criminal Procedure Code, 1973: Sections 374, 406 & 407-
Transfer of  case-Power of transfer postulates that Court to
which transfer  or withdrawal  is. sought  is  competent  to
exercise jurisdiction  over  case-Intra  state  transfer  is
within jurisdiction of the appropriate High Court.
2
     Practice and  Procedure:  Judgment  of  Supreme  Court-
Directions issued  in proceedings  inter partes-Found bad in
law or  violative of  Articles 14 and 21 of the Constitution
and  principles  of  natural  justice  Whether  immune  from
correction even though they cause prejudice and do injury.
     Criminal Trial-Criminal  Procedure Code, 1973-sec. 223-
Whether an  accused can  demand as  of a  right  trial  with
co-accused.
     lnterpretation of  statutes-Words to  be  given  normal
meaning   with   reference   to   context-Golden   rule   of
interpretation-When to be resorted to.
     Legal Maxims:  Actus curiae  neminem gravabid-Coram non
judice-Per   curiam-Ex    debito    justitiae-Nunc-Pro-tunc-
Applicability of.
HEADNOTE:
     The appellant  was the  Chief Minister  of  MaharashtraA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

between June  9, 1980 and January 12, 1982, when he resigned
that office  in deference to the judgment of High Court in a
writ petition filed against him, but continued as an MLA.
     On August  9, 1982,  respondent No.  1, a  member of  a
political party  filed a  complaint before  a Special  Judge
against the  appellant and others for offences under ss. 161
and 165  of the  Indian Penal  Code and  s. 5 of the Criminal
Law Amendment  Act, 1952 and also under ss. 384 and 420 read
with ss. 109 and 120B of the Indian Penal Code.
     The Special  Judge issued  process  to  the  appellant.
Later, the  Special Judge  over-ruled the  objection of  the
appellant to  take cognizance  of the  offences on a private
complaint,  and   to  issue   process,  in  the  absence  of
notification under  s. 7(2)  of the  Criminal Law  Amendment
Act, 1952,  specifying as  to which  of  the  three  special
Judges of the area should try such cases.
     Against  this,   the   appellant   filed   a   revision
application  in   the  High   Court,  which   dismissed   it
subsequently. The appellant's Special Leave Petition against
this was  dismissed by the Supreme Court which held that the
complaint filed by respondent No. 1 was clearly maintainable
and cognizance was properly taken of it.
     During the  pendency of the revision application in the
High Court,  the State Government notified the Special Judge
to try the off-
3
ences specified  under s.  6(1) of  the  Act  and  appointed
another Special Judge, who discharged the appellant, holding
that a  member of  the Legislative  Assembly  was  a  public
servant and  there was no valid sanction for prosecuting the
appellant. Against this order of discharge. respondent No. 1
filed a  Criminal Revision  Application in  the High  Court,
which was subsequently withdrawn to this Court.
     On an  appeal filed  by respondent No. 1 directly under
Article  136  of  the  Constitution  against  the  order  of
discharge, the  Supreme Court  held  on  16.2.1984,  that  a
member of the Legislative Assembly was not a public servant,
and set  aside the  order of  the Special  judge. The  Court
observed that  though nearly 2 1/2 years had rolled by since
prosecution against the accused, who was Chief Minister of a
State, was  launched and  his character  and integrity  came
under cloud, the case had not moved an inch further and that
an expeditious  trial was  primarily in  the interest of the
accused and  mandate of Article 21. It further observed that
expeditious disposal  of a criminal case was in the interest
of both  the prosecution and the accused. It, therefore, suo
motu withdrew  this  special  case  and  another  one  filed
against the appellant by another person and transferred them
to the  High Court, with the request to the Chief Justice to
assign these two cases to a sitting Judge of the High Court,
who should  proceed to  expeditiously dispose  of the cases,
preferably by holding trial from day to day.
     Pursuant to the directions of this Court dated FebruaryA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

16, 1984  the Chief  Justice of  the High Court assigned the
cases to  one of  the Judges  of that  Court. The  appellant
appeared before  him and  raised an  objection that the case
could be  tried only  by a  Special Judge  appointed by  the
Government under  the 1952  Act. The Judge rejected this and
other objections  holding that  he was bound by the order of
the Supreme Court .
     Special Leave  Petitions as  well as  a  writ  petition
filed by  the appellant  against the aforesaid decision were
dismissed by  this Court on April 17, 1984, holding that the
Judge was perfectly justified, and indeed it was his duty to
follow the  decision of this Court which was binding on him.
It also  observed that  the writ  petition  challenging  the
validity of  the order and judgment of this Court as nullity
or  otherwise   could  not  be  entertained,  and  that  the
dismissal of  the writ  petition  would  not  prejudice  the
petitioner's  right   to  approach   this  Court,   with  an
appropriate review  petition or any other application, which
he may be entitled to in law.
4
     Thereafter,  the  cases  were  transferred  to  another
Special Judge,  who framed  21 charges and declined to frame
22 other  charges proposed  by respondent  No. 1. This Court
allowed respondent  No.1`s appeal by special leave except in
regard  to  three  draft  charges  under  s.  384  IPC,  and
requested the  High Court  to nominate  another Judge to try
the cases.
     The Judge,  to whom  the cases were transferred, framed
79 charges  against the  appellant, and  refused to  proceed
against the other named conspirators.
     Against the  aforesaid order,  the  appellant  filed  a
Special Leave  Petition before  this Court  questioning  the
jurisdiction of  the  Special  Judge  to  try  the  case  in
violation of the appellant's fundamental rights conferred by
Articles 14  and 21  and the  provisions of the Criminal Law
Amendment Act  of 1952.  The appellant  also filed a Special
Leave Petition  against the  decision of  the Judge, holding
that none  of the  79 charges  framed  against  the  accused
required sanction  under s.  197(1) of  the Cr.  P.C., and a
writ petition  challenging a  portion of  s. 197(1) as ultra
vires Articles 14 and 21 of the Constitution.
     This Court  granted special  leave in the Special Leave
Petition questioning  the jurisdiction  of the Special Judge
to try  the case  and stayed further proceedings in the High
Court. It  also issued  notice in  the other  Special  Leave
Petition and  the writ  petition, and  directed these  to be
tagged on to the appeal.
     An application filed by respondent No. 1 for revocation
of the  Special Leave  was  dismissed  and  the  appeal  was
referred to a Bench of seven Judges. The other Special Leave
Petition and  the writ  petition were  delinked, to be heard
after the disposal of the appeal.
     In the appeal, two questions arose, namely, (1) whetherA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

the directions  given by  this Court on 16th February, 1984,
withdrawing the  special  cases  pending  in  the  Court  of
Special Judge  and transferring  the same  to the High Court
with the  request to the Chief Justice to assign these cases
to a  sitting Judge  of that High Court in breach of s. 7(1)
of the  Criminal Law Amendment Act, 1952 which mandated that
the offences,  as in  this case,  should be  tried only by a
Special Judge,  thereby denying at least one right of appeal
to the  appellant was violative of Articles 14 and 21 of the
Constitution and whether such direction were at all valid or
legal and  (2) if  such directions  were not at all valid or
legal in  view of  the Court's  order  of  April  17,  1984,
whether the present
5
appeal was sustainable or the grounds therein justiciable in
these  proceedings.   In  other   words,  whether  the  said
directions in  a proceeding  inter parties were binding even
if bad  in law  or violative  of Articles  14 and  21 of the
Constitution and  as such,  immune from  correction by  this
Court even though they caused prejudice and injury.
     Allowing the appeal, and setting aside and quashing all
the proceedings subsequent to the directions of the Court on
16.2.1984 and  directing that  the trial  should proceed  in
accordance with law, i.e. Criminal Law Amendment Act, 1952.
^
     HELD:
     Majority: Sabyasachi  Mukharji, Oza  and Natarajan, JJ.
Per Sabyasachi Mukharji. J:
     1. Section 7(1) of the Criminal Law Amendment Act, 1952
creates a  condition which  is sine qua non for the trial of
offences under  s. 6(1)   of the  said Act.  The condition is
that notwithstanding  anything  contained  in  the  Code  of
Criminal Procedure or any other law, the said offences shall
be triable  by Special  Judges only.  The offences specified
under s. 6(1) of the 1952 Act are those punishable under ss.
161, 162,  163, 164 and 165A of the Indian Penal Code and s.
5 of the Prevention of Corruption Act, 1947. [44B-C,49H,A]
     Gurcharan Das  Chadha v.  State of  Rajasthan, [1966] 2
S.C.R. 678 referred to.
     Therefore, the  order of  this Court  transferring  the
cases to  the High  Court on  16th February,  1984  was  not
authorised by  law. This  Court, by its directions could not
confer jurisdiction  on the High Court to try any case, when
it did not possess such jurisdiction under the scheme of the
1952 Act. [49A-B]
     Kiran Singh  and others  v.  Chaman  Paswan  &  Others,
[1955] 1 SCR 117 at 121 and M. L. Sethi v. R. P. Kapur, 1973
1 SCR 697 relied on.
     2.1 The  power to  create or  enlarge  jurisdiction  is
legislative in  character, so  also the  power to  confer  a
right  of  appeal  or  to  take  away  a  right  of  appeal.
Parliament alone  can  do  it  by  law.  No  Court,  whether
superior or  inferior  or  both  combined  can  enlarge  theA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

jurisdiction of  the Court  or divest a person of his rights
of revision and appeal. [50E]
6
     M.L. Sethi  v. R.P.  Kapur, [1973]  1 SCR  697 and Raja
Soap Factory v. S. P. Shantara;, 1965 2 SCR 800 referred to.
     Halsbury's Laws of England, 4th Vol.10 page at para 720
and Ammon  Rubinstein's Jurisdiction  and Illegality, [1965]
Edn. pp. 16-50 referred to.
     2.2 Want  of jurisdiction  can be established solely by
superior court and in practice, no decision can be impeached
collaterally by  any interior  court, but the superior court
can always  correct its  own error  brought  to  its  notice
either by way of petition or ex debito justitiae.[50G]
     Rubinstein's  jurisdiction  and  illegality(1965  Edn.)
referred to.
     2.3 The  distinction between  an  error  which  entails
absence  of  jurisdiction  and  an  error  made  within  the
jurisdiction is  so fine  that it  is rapidly  being eroded.
[69H.70A]
     Anismatic Ltd.  v. Foreign  Compensation  Commissioner,
[1969] 1 All E.R.208 at 241 referred to.
     This is  not a  case of  collateral attack  on judicial
proceedings; it  is a  case where  the Court having no court
superior to it rectifies its own order. [69]
     The impugned directions were void because power was not
there for  this Court to transfer a proceeding under the Act
of 1952 from one Special Judge to the High Court. [69G]
     The singling  out of the appellant for a speedier trial
by the High Court for an offence which the High Court had no
jurisdiction to  try under  the Act of 1952 was unwarranted,
unprecedented and  directions given  by this  Court for  the
said purposes  were not warranted. When that fact is brought
to the  notice of  the court,  it must remedy the situation.
[51D-E]
     2.4 In  rectifying the  error, no  personal inhibitions
should debar  this Court  because no person should suffer by
reason of  any mistake  of this  Court. Here  no rule of res
judicata would apply to prevent this Court from entertaining
the grievance and giving appropriate directions.[51E-F]
     Soni Vrajlal  Jethalal v.  Soni Jadavji  and Govindji &
Ors.. AIR 1972 Gujarat 148 approved.
7
     In the  earlier judgment,  the points for setting aside
the decision  did not  include the question of withdrawal of
the case  from the  Court of  Special Judge  to the  Supreme
Court and transfer of it to the High Court. Unless a plea in
question is taken it cannot operate as res judicata.[62G-H]
     Shivshankar Prasad  Shah and  others  v  Baikunth  Nath
Singh and  others, [1969]  1 S.C.C.  718; Bikan  Mahuri  and
others v.  Mst. Bibi  Walian and  others, A.I.R.  1939 Patna
633; S.L.  Kapoor v.  Jagmohan and  others, [1981]  1 S.C.C.
746; Maneka Gandhi v. Union of India, [1978] 2 S.C.R. 621 at
pages 674-681  and Bengal  Immunity Co. Ltd. v. The State ofA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

Bihar and others, [1955] 2 SCR 603 and 623 referred to.
     3.1 Section  407 of  the Criminal  Procedure  Code  was
subject to  over-riding mandate  of s.  7(1)  of the 1952 Act
and, hence  it does  not permit the High Court to withdraw a
case  for   trial  to  itself  from  the  Court  of  Special
Judge.[60D-E]
     3.2 Article  134(1)(b) of  the  Constitution  does  not
recognise in  every High  Court power  to withdraw for trial
cases from  any Court subordinate to its authority. At least
this Article cannot be construed to mean that where power to
withdraw is  restricted, it  can be  widened  by  virtue  of
Article 134(1)(b) of the Constitution. [67B-C]
     3.3 Where  by a  specific clause  of a specific statute
the power  is given  for trial by the Special Judge only and
transfer can  be from  one such  Judge  to  another  Special
Judge, there  is no  warrant to  suggest that the High Court
has power to transfer Such a case from a Judge under s. 6 of
the Act  of 1952 to itself. It is not a case of exclusion of
the superior Courts. [67C]
     In the facts of the instant case, the criminal revision
application which  was pending before the High Court even if
it was  deemed to be transferred to this Court under Article
139A of  the Constitution,  it would  not have  vested  this
Court with  power larger than what is contained in s. 407 of
Criminal Procedure  Code.  Under  s.  407  of  the  Criminal
Procedure Code read with the Criminal Law Amendment Act, the
High Court  could not  transfer to  itself proceedings under
ss. 6 and 7 of the said Act. This Court, by transferring the
proceedings  tb  itself,  could  not  have  acquired  larger
jurisdiction. The  fact that  the objection  was not  raised
before this  Court gave  directions on  16th February,  1984
cannot amount to any waiver. [161F-G]
8
     Ledgard  v.  Bull,  131  A  134,  Meenakshi  Naidoo  v.
Subramaniya A Sastri, 141 A 160 referred to.
     3.4 The  Parliament did  not grant  to  the  Court  the
jurisdiction to  transfer a case to the High Court. However,
as  the   superior  Court   is  deemed  to  have  a  general
jurisdiction, the  law presumes  that the Court acted within
jurisdiction. [60G]
     In the  instant case,  the presumption cannot be taken,
firstly,  because  the  question  of  jurisdiction  was  not
agitated before  the Court;  secondly, these directions were
given per incuriam and thirdly, the superior Court alone can
set aside an error in its directions when attention is drawn
to that  error. This  view is  warranted only because of the
peculiar facts  and circumstances  of the present case. Here
the trial  of a  citizen in  a Special  Court under  special
jurisdiction is  involved; hence  the liberty of the subject
is involved. [60H,61A-B]
     Kuchenmeister  v.  Home  office,  [1958]  1  Q.B.  496;
Attorney General  v. Herman  James Sillam,  [1864] 10 H.L.C.
703 and Issacs v.Robertson, [1984] 3 A.I.R. 140 referred to.A.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

     Jurisdiction and Illegality by Amnon Rubinstein, [1965]
Edn. referred to.
     4.1 Per incuriam are those decisions given in ignorance
or forget  fulness of  some inconsistent statutory provision
or some  authority binding on the Court concerned so that in
such cases  some part  of the  decision or  some step in the
reasoning on  which it is based is found, on that account to
be demonstrably wrong. If a decision is given per in curiam,
the Court can ignore it. [52A-B, 53G]
     Morelle v.  Wakeling, [1955]  1 ALL  ER 708;  State  of
Orissa v. The Titaghur Paper Mills Co. Ltd., [1985] 3 SCR 26
and Bengal  Immunity Co. Ltd. v. State of Bihar [1955] 2 SCR
603, 623 referred to.
     In the instant case, when this Court gave directions on
16th February  1984, for  disposal of  the case  against the
appellant by  the  High  Court,  it  was  oblivious  of  the
relevant provisions of the law and the decision in Anwar Ali
Sarkar's case, which is a binding precedent [51G-H]
     4.2 A  Full Bench  or a Constitution Bench decision was
binding on  the Constitution Bench because it was a Bench of
seven Judges. There is
9
a hierarchy  in this  Court itself  where larger     Benches
over-rule smaller  Benches which is the crystallised rule of
law. [52E,F]
     State of  West Bengal  v. Anwar  Ali Sarkar, [1952] SCR
284; Nattulal v. Radhe Lal, [1975] 1 SCR 127; Union of lndia
and Anr. v. KS. Subramaniam, [1977] 1 SCR 87 at p. 92; State
of U.P.  v. Ram  Chandra Trivedi,  [1977] 1  SCR 462 at 473;
Halsbury's Laws  of England, 4th Edn. Vol. 26 page 297, para
578 and  page 300,  relevant notes  on 8.11  and 15; Dias on
Jurisprudence, 5th  Edn. pages 128 and 130; Young v. Bristol
Aeroplane Co.  Ltd. [1944] 2 AER 293 at 300; Moore v. Hewitt
1947 2 AER 270 at 272A; Penny v. Mcholas, 1950 2 AER 92A and
Javed Ahmed  Abdul Hamid  Pawala v.  State  of  Maharashtra,
[1985] 2 SCR 8 referred to.
     It  was   manifest  to   the   Bench   that   exclusive
jurisdiction created under s. 7(1) of the 1952 Act read with
s. 6  of the  said Act,  when brought  to the  notice of the
Court, precluded  the exercise  of power under s. 407 of the
Code. There  was no  argument, no submission and no decision
on this  appeal at  all. There  was no  prayer in the appeal
which was  pending before  this Court  for such  directions.
[59D-E]
     The order  of this  Court was clearly per incuriam. The
Court was not called upon to and did not, decide the express
limitation on  the power  conferred by  s. 407  of the Code.
which includes  offences by public servants mentioned in the
1952 Act  to be  over-ridden in  the  manner  sought  to  be
followed as  a consequential  direction of  this Court. This
Court did  not have  jurisdiction to  transfer the  case  to
itself. That  will be  evident from an analysis of different
provisions of the Code as well as the 1952 Act [50C-D]A.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

     Therefore, in  view of  the clear provisions of s. 7(2)
of  the   Act  of  1952  and  Articles  14   and  21  of  the
Constitution these directions were legally wrong. [52C]
     4.3 Though  the previous  statute is referred to in the
other judgment  delivered on  the same  date, in  connection
with other  contentions, s.  7(1) was  not  referred  to  in
respect of the impugned directions. Hence these observations
were indubitably per incuriam. [66A]
     Miliangos v.  George Frank (Textiles) Ltd, [1975] 3 All
E.R. 801 at 821 referred to.
     5. This  Court is  not powerless  to correct  its error
which has the
10
effect of  depriving a citizen of his fundamental rights and
more so,  the A  right to  life and liberty. It can do so in
exercise of  its inherent  jurisdiction  in  any  proceeding
pending before  it without insisting on the formalities of a
review application. [54A-B]
     Powers of  review can  be exercised  in a petition file
under Article 136 or Article 32 or under any other provision
of the  Constitution if  the Court  is  satisfied  that  its
directions  have   resulted  in   the  deprivation   of  the
fundamental rights  of a  citizen or  any legal right of the
petitioner. [54B-C]
     The Supreme  Court has the power to review either under
Article 137  or suo motu the directions given by this Court.
[62E]
     Prem Chand Garg v. Excise Commissioner, U.P. Allahabad,
[1963] Suppl.1  SCR 885; Naresh Shridhar Mirajkar and others
v. State of Maharashtra and another, [1966] 3 S.C.R. 744 and
Smt. Ujjam  Bai v.  State of  U.P.,  [1963]  1  S.C.R.  778;
Kailash Nath  v. State  of U.P.  AIR 1957  (SC) 790;  P.S.R.
Sadhananatham v.  Arunachalam, [1980]  2 S.C.R. 873; Suk Das
v. Union  Territory of  Arunachal Pradesh,  [1986] 2  S.C.C.
401; Asrumati  Devi v. Kumar Rupendra Deb Raikot and others,
[1953] S.C.R.  1159; Satyadhyan  Ghosal and  others v.  Smt.
Deorajin Debi  and another,  [1960] 3  S.C.R. 590;  Sukhrani
(dead) by  L.Rs. and  others v.  Hari  Shanker  and  others,
[1979] 3  S.C.R. 671  and Bejoy  Gopal  Mukherji  v.  Pratul
Chandra Ghose, [1953] S.C.R. 930 referred to.
     6. It  is also  well settled that an elementary rule of
justice is  that no  party should  suffer by  mistake of the
Court. [63B]
     Sastri Yagnapurushadji  and others  v. Muldas Bhudardas
Vaishya and  another, [1966]  3 S.C.R.  242; Jang  Singh  v.
Brijlal [1964]  2 S.C.R. 145;Bhajahari Mondal v.The State of
West Bengal, [1959] S.C.R. 1276 at 1284-1286 and Asgarali N.
Singaporawalle v. The State of Bombay 1957 S.C.R. 678 at 692
referred to.
     It was  a mistake  of so  great  a  magnitude  that  it
deprives  a   man  by   being  treated  differently  of  his
fundamental right  for defending himself in a criminal trial
in accordance with law. Therefore, when the attention of theA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

Court is  drawn, the  Court has  always the  power  and  the
obligation to  correct it  ex debito justitiae and treat the
second application  by its  inherent power,  as a  power  of
review to correct the original mistake. [56C-D]
     The directions  have been  issued without observing the
principle of audi alteram partem.[53D]
11
     This  Court   is  not  debarred  from  re-opening  this
question and  giving proper  directions and  correcting  the
error in the present appeal. [53C]
     The appellant  should not  suffer  on  account  of  the
direction of  this Court  based upon  an  error  leading  to
conferment of jurisdiction. [53B]
     7. The  principle of  finality on  which Article 145(e)
proceeds applies  to both  judgments and  orders made by the
Supreme  Court.   But  directions   given  per  incuriam  in
violation  of  certain  constitutional  limitations  and  in
derogation of  the principles  of natural justice can always
be remedied by the court ex debite justitiae. [68F-G]
     In the  instant  case,  this  Court  is  correcting  an
irregularity committed  by the  Court not on construction or
misconstruction  of  a  statute  but  on  non-perception  of
certain  provisions  and  certain  authorities  which  would
amount to  derogation of  the constitutional  rights of  the
citizen. [69C-D]
     Issacs v.  Robertson, [1984]  3 A.E.R. 140 and Re Recal
Communications Ltd. Case, [1980] 2 A.E.R. 634 referred to.
     8. No  prejudice  need  be  proved  for  enforcing  the
fundamental rights.  Violation of a fundamental right itself
renders the  impugned action void. So also, the violation of
the  principles   of  natural  justice  renders  the  act  a
nullity.[59H]
     9.1 Four  valuable rights  of the  appellant have  been
taken away by the impugned directions.
     i)   The right  to be  tried  by  a  Special  Judge  in
          accordance with  the procedure  established by law
          and enacted by Parliament.
     ii)  The right of revision to the High Court under s. 9
          of the Criminal Law Amendment Act.
     iii) The  right of first appeal to the High Court under
          the same section
     iv)  The right  to move the Supreme Court under Article
          136 thereafter  by way  of  a  second  appeal,  if
          necessary.
     The right  of the  appellant under Article 14 regarding
equality
12
before  the  law  and  equal  protection  of  law  has  been
violated. The  appellant has  also a right not to be singled
out for special treatment by a Special Court created for him
alone. This  right is  implicit in  the right  to  equality.
[60A-C,62A-B]
     State of  West Bengal  v. Anwar  Ali Sarkar, [1952] SCRA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

284 relied on.
     The appellant  has a  further right under Article 21 of
the Constitution-a  right to  trial by a Special Judge under
s. 7(1)  of the  1952 Act which is the procedure established
by law  made by  the Parliament  and a further right to move
the High Court by way of revision or first appeal under s. 9
of the said Act. He has also a right not to suffer any order
passed behind  his back by a Court in violation of the basic
principles of  natural justice. Directions having been given
in this case without hearing the appellant, though the order
was passed in the presence of the counsel for the appellant,
these are bad. [62B-Dl
     It is proper for this Court to act ex debito justitiae,
in favour of the fundamental rights of the appellant. [62E]
     Nawabkhan Abbas  Khan v. The State of Gujarat, [1974] 3
SCR 427 referred to.
     9.2 There was prejudice to the accused in being singled
out as a special class of accused for a special dispensation
witbout any  room for  any appeal  as of  right and  without
power of revision to the High Court. [67G]
      Romesh Chandra Arora v. The State, [1960] 1 SCR 924 at
927 distinguished.
     9.3 The  trial even  of person  holding  public  office
though to  be made  speedily must be done in accordance with
the procedure  estab lished  by law.  The provisions of s. 6
read with  s. 7  of  the  Act  of  1952  in  the  facts  and
circumstances of  this case  is the procedure established by
law, and  any deviation even by a judicial direction will be
negation of the rule of law. [68D-E]
     By judicial direction, the rights and previliges of the
accused have  been curtailed  without any  justification  in
law. [ 68B]
     State of  West Bengal  v. Anwar  Ali Sarkar, [1952] SCR
284 relied on.
13
     Re: Special Courts Bill, [1978] 1979 2 SCR 476 referred
to.
     9.4 The right of appeal under s. 374 of the Cr. P.C. is
confined only  to cases  decided by  the High  Court in  its
Letters Patent  jurisdiction which in terms is extraordinary
original criminal  jurisdiction' under  clause 27 of Letters
Patent. [63F]
     Kavasji Pestonji  Dalal v.  Rustomji Sorabji  Jamadar &
Anr., AIR  1949 Bom.  42, Sunil  Chandra Roy  & Anr.  v. The
State AIR  1954 Cal.  305; Sasadhar  Acharjya &  Anr. v. Sir
Charles Tegart  & Ors.,  [1935] Cal. Weekly Notes1089;People
insurance Co.  Ltd. v.  Sardul Singh Caveeshgar & Ors. J AIR
1961 Punj.  87 and  P.P. Front,  New Delhi  v. K.  K  Birla.
[1984] Cr. L.J. 545 referred to.
     9.5 By the time the Code of Criminal Procedure 1973 was
framed, Article 21 had not been interpreted so as to include
one right of appeal both on facts and law. [64C]
     10. Words  should  normally  be  given  their  ordinaryA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

meaning bearing  in mind  the context.  It is only where the
literal meaning  is not clear that one resorts to the golden
rule   of   interpretation   or   the   mischief   rule   of
interpretation. [66C]
     Sussex Peerage  Claim, [1844]  11 Cl.  & Fin. 85 at 143
referred to.
     Cross: Statutory Interpretation, p. 36.
     In view  of the  specific language  used in s. 7 of the
1952 Act,  it is  not  necessary  to  consider  whether  the
procedure for  trial by  Special Judges  under the  Code has
stood repealed  or not.  The concept  of repeal  may have no
application in this case. [66B]
     11. No  man is  above the law, but at the same time, no
man can  be denied his rights under the Constitution and the
laws. He has a right to be dealt with in accordance with the
law and not in derogation of it. [71B]
     This Court, in its anxiety to facilitate the parties to
have a  speedy trial,  gave direction on 16th February, 1984
without conscious awareness of the exclusive jurisdiction of
the Special  Courts under  the 1952  Act and  that being the
only procedure established by law, there can be no deviation
from the  terms of  Article 21 of the Constitution of India.
That is  the only  procedure under which it should have been
guided. [71B-C]
14
     By reason of giving the impugned directions, this Court
had also  unintentionally caused the appellant the denial of
rights under  Article 14  of the Constitution by denying him
the equal  protection of  law by  being singled  out  for  a
special procedure not provided for by law. [71C-D]
     When these  factors are  brought to  the notice of this
Court, even  if there  are any  technicalities,  this  Court
should  not  feel  shackled  and  decline  to  rectify  that
injustice; or  otherwise, the  injustice noticed will remain
forever a blot on justice. [71D]
     12.1 The  basic fundamentals  of the  administration of
justice are  simple. No  man should  suffer because  of  the
mistake of  Court. No man should suffer a wrong by technical
procedure of  irregularities. Rules  or procedures  are  the
hand-maids of  justice and  not the mistress of the justice.
If a  man has  been wronged  so long  as it  lies within the
human machinery of administration of justice that wrong must
be remedied. [72B-C]
     12.2 The  maxim "Actus  Curiae Neminem Gravabit"-An act
of the  Court shall prejudice no man-is founded upon justice
and good  sense and affords a safe and certain guide for the
administration of the law. [71E]
     Alaxander Rodger  v. The  Comptoir Dlescompte  De Paris
Cham Reports, Vol. III 1869-71 p. 465 at 475 referred to.
     13. Purity  of public  life  is  one  of  the  cardinal
principles which  t. must  be upheld  as a  matter of public
policy.  Allegations   of  legal  infractions  and  criminal
infractions must  be investigated in accordance with law andA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

procedure established under the Constitution. [73B]
     Even if  the accused has been wronged, if he is allowed
to be  left in doubt that would cause more serious damage to
him. Public  confidence in  public administration should not
be eroded  any further.  One wrong  cannot  be  remedied  by
another wrong. [73B]
     The legal  wrong that  has been  done to  the appellant
should be remedied and right should be done. In doing so, no
more further  injury should be caused to the public purpose.
[73C]
     The  impugned   directions  were  in  deprival  of  the
Constitutional rights and contrary to the express provisions
of the Criminal Law
15
Amendment Act,  1952, in  violation  of  the  principles  of
natural justice,  and without precedent in the background of
the Act  of 1952.  The directions  definitely  deprived  the
appellant of  certain rights  of appeal and revision and his
rights under the Constitution. [69F]
     Having regard  to the  enormity of  the consequences of
the error  to the  appellant and  by reason of the fact that
the directions  were given  suo motu, there is nothing which
detracts the  power of  the Court  to review its judgment ex
debito justitiae in case injustice has been caused. No Court
however high  has jurisdiction  to give an order unwarranted
by the Constitution. [70A-B]
     Ittavira Mathai  v. Varke,P Varkey and others, [1964] 1
SCR 495 referred to.
     Bhatia Cooperative  Housing Society Ltd. v. D.C. Patel,
[1953] SCR 185 at 190 distinguished.
     Since   this   Court   infringed   the   Constitutional
safeguards granted  to a citizen or to an accused, in giving
the directions  and injustice  results therefrom, it is just
and  proper  for  the  Court  to  rectify  and  recall  that
injustice in  the peculiar  facts and  circumstances of this
case.  Therefore,   all  the   proceedings  in   the  matter
subsequent to  the directions  of this Court on February 16,
1984, are set aside and quashed and the trial should proceed
in accordance  with law,  that is  to say,  under the Act of
1952. [70C,73D-E]
     R.S. Nayak  v. A.R.  Antulay, [1984]  2 SCR  495;  A.R.
Antulay v.  Ramdas Sriniwas  Nayak and another, [1984] 2 SCR
914; Abdul  Rehman Antulay v. Union of India and others etc.
[1984] 3  SCR 482 at 483; Kailash Nath v. State of U.P., AIR
1957 SC  790; Sukdas v. Union Territory of Arunachal Pradesh
Discretion to  Disobey by  Mortimer R. Kadish and Sanford H.
Kadish pages 111 and 112 referred to.
Per Ranganath Misra, J. (Concurring)
     14. Section  7(1) has  clearly provided  that  offences
specified in sub-section (1) of s. 6 shall be triable by the
Special Judge  only and  has taken  away the  power  of  the
courts established  under the  Code of Criminal Procedure to
try those  offences. As  long as s. 7 of the Amending Act ofA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

1952 holds  the field it was not open to any court including
the Apex  Court to  act contrary  to s. 7(1) of the Amending
Act.[81E-F]
16
     State of West Bengal v. Anwar Ali Sarkar, 1952 SC R 284
referred to.
     15. The  power to  transfer a  case  conferred  by  the
Constitution or  by s. 406 of the Code of Criminal Procedure
does not  specifically relate  to the Special Court. Section
406 of  the Code  could be applied on the principle that the
Special Judge  was a  subordinate court  for transferring  a
case from one Special Judge to another Special Judge because
such a  transfer would not contravene the mandate of s. 7(1)
of the  Amending Act  of 1952.  While that  may be  so,  the
provisions for transfer, do not authorise transfer of a case
pending in the court of a Special Judge first to the Supreme
Court and  then to  the High Court for trial. This Court did
not possess  the power  to transfer the proceedings from the
Special Judge to the High Court. [81G-H,82A]
     Raja Soap  Factory v. S.P. Santharaj, [1965] 2 SC R 800
referred to.
     16.1  It   is  the   settled  position   in  law   that
jurisdiction of courts comes solely from the law of the land
and cannot be exercised other wise. [77E]
     16.2 Jurisdiction  can be  exercised only when provided
for either  in the  Constitution or  in the laws made by the
Legislature. Jurisdiction  is thus the authority or power of
the court  to deal  with a matter and make an order carrying
binding force in the facts. [77G]
     17. By  the change  of forum  of trial  the accused has
been pre  judiced. By  this process  he misses  a  forum  of
appeal because  if the trial was handled by a Special Judge,
the first  appeal would  lie to the High Court and a further
appeal by special leave could come before this Court. If the
matter is  tried by  the High  Court there would be only one
forum of  appeal being this Court, whether as of right or by
way of special leave. [83H, 84A-B]
     18. The transfer was a suo motu direction of the court.
Since this  particular aspect  of the  matter had  not  been
argued and  counsel did  not have an opportunity of pointing
out the legal bar against transfer, the Judges of this Court
obviously did  not take note of the special provisions In s.
7(1)  of   the  1952   Act.  If   this  position   had  been
appropriately placed,  the direction  for transfer  from the
court of  exclusive jurisdiction to the High Court would not
have been  made by the Constitution Bench. It is appropriate
to presume  that this Court never intends to act contrary to
law. [82E-F]
17
     19. One  of the  well-known principles  of law  is that
decision made  by a competent court should be taken as final
subject to  further proceedings  contemplated by  the law of
procedure. In  the absence  of any  further proceedings, theA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

direction of  the Constitution  Bench on  16th of  February,
1984 became  final and  it is  the obligation of everyone to
implement the  direction of the apex Court. Such an order of
this Court  should by  all canons  of judicial discipline he
binding on  this Court as well and cannot be interfered with
after attaining finality. [84C-D]
     20.1 It  is a  well-settled position in law that an act
of the court should not injure any of the suitors. [84F]
     Alexander Rodger  v. The  Comptori D'Escompte De Paris,
[1871] 3 PC 465 referred to.
     20.2. Once  it is  found that  the order of transfer by
this Court  was not  within jurisdiction by the direction of
the transfer  of the  proceedings made  by this  Court,  the
appellant should not suffer. [85B]
     20.3 This  being the  apex Court,  no litigant  has any
opportunity of  approaching any higher forum to question its
decisions. Once  judicial satisfaction  is reached  that the
direction was  not open  to be  made and it is accepted as a
mistake of  the court,  it is  not only appropriate but also
the duty  of the  Court to rectify the mistake by exercising
inherent powers.  A mistake of the Court can be corrected by
the  Court  itself  without  any  fetters.  In  the  present
situation, the  Court's inherent  powers can be exercised to
remedy the mistake. [87F,88B-C]
     Gujarat v.  Ram Prakash  [1970] 2  SCR  875;  Alexander
Rodger v.  The Comptori D'Escompte De Paris, [1871] 3 PC 465
and Krishna  Deo v.  Radha Kissan,  [1953] SCR  136; Debi v.
Habib lLR  35 All  331 and  Murtaza v. Yasin. AIR 191 PC 857
referred to.
     20.4 The injustice done should be corrected by applying
the principle  actus curiae  neminem gravabit, an act of the
court shall prejudice no one.[88H]
     20.5 To err is human. Courts including the apex one are
no  exception.   To  own   up  the   mistake  when  judicial
satisfaction is reached does not militate against its status
or authority. Perhaps it would enhance both. [89B]
     21. If  a mistake is detected and the apex Court is not
able to
18
correct it  with a  view to  doing justice for fear of being
misunderstood, the  cause of  justice is bound to suffer and
for the  apex Court  the apprehension  would not  be a valid
consideration. This Court, while administering justice, does
not take  into consideration  as to  who is before it. Every
litigant is  entitled to  the same  consideration and  if an
order is warranted in the interest of justice, the status or
influence of the accused cannot stand in the way as a bar to
the making of that order. [89F-G]
     22. Finality  of the  orders is  the rule. By directing
recall of  an order,  the well-settled  propositions of  law
would not  be set  at naught. Such a situation may not recur
in the  ordinary course of judicial functioning and if there
be one,  certainly the  Bench before  which it  comes  wouldA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

appropriately deal  with it. Nn strait jacket formula can be
laid down for judicial functioning particularly for the apex
Court. The  apprehension that  the decision  to  recall  the
earlier decision  may be  used as  a precedent  to challenge
judicial orders  of this  Court is perhaps misplaced because
those who  are familiar  with the  judicial functioning  are
aware of  the limits  and they  would not  seek support from
this case  as a  precedent.  This  Court  is  sure  that  if
precedent  value  is  sought  to  be  derived  out  of  this
decision, the  Court which  is  asked  to  use  this  as  an
instrument  would   be  alive  to  the  peculiar  facts  and
circumstances of the case in which this order is being made.
[87H, 90A-B]
     23. Under  the Rules of the Court a review petition was
not to be heard in Court and was liable to be disposed of by
circulation. In  these circumstances, the petition of appeal
could not be taken as a review petition. [87E]
     24. Benches of this Court are not subordinate to larger
Benches thereof and certiorari is, therefore, not admissible
for quashing  of the orders made on the judicial side of the
Court. [85C]
     Naresh Chandra  Mirajkar & Ors. v. State of Maharashtra
JUDGMENT:
Prem Chand Garg v. Excise Commissioner, U.P., Allahabad 1963 1 SCR 885 referred to.
25. Apart from the fact that the petition of review had to be filed within 30 days-and here there has
been inordinate delay-the petition for review had to be placed before the same Bench and now that
two of the learned judges of that Constitution Bench are still available, it must have gone only before
a Bench of five with those two learned Judges. [87D-E]
26. It is time to sound a note of caution. This Court under its Rules of Business ordinarily sits in
divisions and not as a whole one. Each Bench, whether small or large, exercises the powers vested in
the Court and decisions rendered by the Benches irrespective of their size are considered as
decisions of the Court. The practice has developed that a larger Bench is entitled to overrule the
decision of a smaller Bench notwithstanding the fact that each of the decisions is that of the Court.
That principle, however, would not apply in the present situation, and since this Court is sitting as a
Bench of Seven this Court is not entitled to reverse the decision of the Constituffon Bench. [89B-C]
27. Overruling when made by a larger Bench of an earlier decision of a smaller one is intended to
take away the precedent value of the decision without affecting the binding effect of the decision in
the particular case. [89C] In the instant case, the appellant is, therefore, not entitled to take
advantage of the matter being before a larger Bench. In fact, if it is a case of exercise of inherent
powers to rectify a mistake it was open even to a five-Judge Bench to do that and it did not require a
Bench larger than the Constitution Bench for that purpose. [89D] Per Oza, J. (Supplementing)
28. The jurisdiction to try a case could only be conferred by law enacted by the legislature and this
Court could not confer jurisdiction if it does not exist in law. [90F]A.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

29. No doubt a judgment or an order passed by this Court will not be open to a writ of certiorari
even if an error is apparent. But at the same time, there should be no hesitation in correcting an
error in exercise of inherent jurisdiction if it comes to the notice of the Court. [90D-E] In the instant
case, it is this error which is sought to be corrected, although it is being corrected after long lapse of
time. [90F] Per Ray,J.(Concurring)
30. The Jurisdiction or power to try and decide a cause is conferred on the courts by the Law of the
Lands enacted by the Legislature or by the provisions of the Constitution and the court cannot
confer a jurisdiction on itself which is not provided in the law and judicial order of this Court is not
Emenable to a writ of certiorari tor correcting any error in the judgment. However, since the act of
the court should not injure any of the suitors, the error in question is sought to be corrected. after a
lapse of more than three years. [90H,91A-B] Per Venkatachaliah, J. (Dissenting) 31.1 The
exclusiveness of jurisdiction uf the special judge under s. 7(1) of 1952 Act depends on the
construction to be placed on the relevant statutory-provision. If on such a construction, however
erroneous it may be, the court holds that the operation of s. 407 Cr. P.C. is not excluded, that
interpretation will denude the plenitude of the exclusivity claimed for the forum. To say that the
court usurped legislative powers and created a new jurisdiction and a new forum ignores the basic
concept of functioning of courts. The power to interpret laws is the domain and function of courts.
[108D-E] Thomas v. Collins, 323 (1945) US 516 referred to. 31.2 The earlier decision proceeded on a
construction of s. 7(1) of the Act and s. 407 of Cr. P.C. This bench does not sit in appeal over what
the five Judge Bench said and proclaim how wrong they were. This Bench is simply not entitled to
embark, at a later stage, upon an investigation of the correctness of the very decision. The same
bench can, of course, reconsider the matter under Article 137.
32.1 The expression "jurisdiction" or the power to determine is a verbal cast of many colours. In the
case of a Tribunal, an error of law might become not merely an error m jurisdiction but might
partake of the character of an error of jurisdiction. But, otherwise jurisdiction is a 'legal shelter', a
power to bind despite a possible error in the decision. [102C] 32.2. In relation to the powers of
superior courts, the familiar distinction between jurisdictional issues and adjudicatory issues
approts priate to Tribunals of limited jurisdiction has no place. [102A] 32.3 Before a superior court
there is no distinction in the quality of the decision-making-process respecting jurisdictional
questions on the one hand and adjudicatory issues or issues pertaining to the merits, on the other.
[102B] 32.4 The existence of jurisdiction does not depend on the correctness of its exercise. The
authority to decide embodies a privilege to bind despite error, a privilege which is inherent in and
indispensable to every judicial function. The characteristic attribute of a judicial act is that it binds
whether it be right or it be wrong. [102D] Mallikarjun v. Narhari, [1900] 27 I.A. 2 10 referred to.
Anismatic Ltd. v. Foreign Compensation Commission, [1969] 1 All ER 208 distinguished.
32.5 A finding of a superior court even on a question of its own jurisdiction, however grossly
erroneous it may otherwise be, is not a nullity nor one which could at all be said to have been
reached without jurisdiction, susceptible to be ignored or to admit of any collateral attack.
Otherwise, the adjudications of superior courts would be held up to ridicule and the remedies
generally arising from and considered concomitants of such classification of judicial-errors would beA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

so seriously abused and expanded as to make a mockery of those foundational principles essential to
the stability of administration of justice. [102G,103A] 32.6 The superior court has jurisdiction to
determine its own jurisdiction and an error in that determination does not make it an error of
jurisdiction. [103B] Holdsworth (History of English Law) Vol. 6 page 239 and Rubinstein:
Jurisdiction and Illegality referred to.
Re Racal Communications Ltd. [1980] 2 All ER 634 and Issac v. Robertson, [1984] 3 All ER 140
referred to.
32.7 Superior courts apart, even the ordinary civil courts of the land have jurisdiction to decide
questions of their own jurisdiction. [105H] It would be wholly erroneous to characterise the
directions issued by the five Judge Bench as a nullity, amenable to be ignored or so declared in a
collateral attack. [106E]
33. A judgment, inter-parties, is final and concludes the parties. [106F] Re Hastings (No. 3) [1969] 1
All ER 698; Daryao v. State of UP, [1962] 1 SCR 574; Trilok Chand v. H.B. Munshi, [1969] 2 SCR
824 and Shiv Nandan Paswan v. State of Bihar, [ 1987] 1 SCC 288 at 343 relied on 34.1 All accused
persons cannot claim to be tried by the same Judge. The discriminations inherent in the choice of
one of the concurrent jurisdictions are not brought about by an inanimate statutory-rule or by
executive fiat. The withdrawal of a case under s. 407 is made by a conscious judicial act and is the
result of judicial discernment. If the law permits the withdrawal of the trial to the High Court from a
Special Judge, such a law enabling withdrawal would not, prima facie, be bad as violation of Article
14. [114G-H, 115A] 34.2 No doubt, the fundamental right under Article 14 has a very high place in
constitutional scale of values. Before a person is deprived of his personal liberty, not only that the
procedure established by law must strictly be complied with and not departed from to the
disadvantage or detriment of the person but also that the procedure for such deprivation of personal
liberty must be reasonable, fair and just. Article 21 imposes limitations upon the procedure and
requires it to conform to such standards of reasonableness, fairness and justness as the Court acting
as sentinel of fundamental rights would in the context, consider necessary and requisite. The Court
will be the arbiter of the question whether the procedure is reasonable, fair and just. [114D-F] 34.3
The five judge bench in the earlier case has held that such a transfer is permissible under law. That
decision had assumed finality. The appeal to the principle in Anwar Ali's Sarcar's case, in such a
context would be out of place. [115A] State of West Bengal v. Anwar Ali Sarkar, [1952] SCR 284
distinguished.
35. That a trial by a Judge of the High Court makes for added re-assurance of justice, has been
recognised in a number of judicial pronouncements. The argument that a Judge of the High Court
may not necessarily possess the statutory- qualifications requisite for being appointed as a Special
Judge appears to be specious. A judge of the High Court hears appeals arising from the decisions of
the Special Judge and exercises a jurisdiction which includes powers co- extensive with that of the
trial court. [115C-D]
36. The plea that transfer of the case to the High Court involves the elimination of the appellant's
right of appeal to the High Court which he would otherwise have and that the appeal under ArticleA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

136 of the Constitution as of right cannot be accepted in view of s. 374, Cr. P.C. which provides such
an appeal, as of right, when the trial is held by the High Court. [117A-B]
37. Directions for transfer were issued on 16.2.1984 in the open court in the presence of appellant's
counsel at the time of pronouncement of the judgment and counsel had the right and the
opportunity of making submission to the court as to the permissibility or otherwise of the transfer.
After the directions were pronounced and before the order was signed, though there was
opportunity for the appellant's counsel to make submission in regard to the alleged illegality or
impropriety of the directions, appellant did not utilise the same. That apart, even after being told by
two judicial orders that appellant, if aggrieved, may seek a review, he did not do so. Even the
grounds urged in the many subsequent proceedings appellant took to get rid of the effect of the
direction do not appear to include the grievance that he had no opportunity of being heard. [115F,
G-H,116A-B] Therefore, where a party having had an opportunity to raise a grievance in the earlier
proceedings does not do so and makes it a technicality later, he cannot be heard to complain. [116B]
Rules of natural justice embodies fairness in action. By all standards, they are great assurances of
justice and fairness. But they should not be Pushed to a breaking point. [116F] R. v. Secretary of
State for Home Deptt. ex-parte Mughal, [1973] 3 All ER 796, referred to.
38.1 The circumstance that a decision is reached per- incuriam, merely serves to denude the
decision of its precedent-value. Such a decision would not be binding as a judicial precedent. A
co-ordinate bench can discharge with it and decline to follow it. A larger bench can over-rule such
decision. When a previous decision is so overruled it does not happen nor has the overruling bench
any jurisdiction so to do that the finality of the operative order, inter-parties, in the previous
decision is over- turned. In this context the word 'decision' means only the reason for the previous
order and not the operative-order in the previous decision, binding inter-parties. Even if a previous
decision is over-
ruled by a larger-bench, the efficacy and binding nature, of the adjudication expressed in the
operative order remains undisturbed interparties. [119B-D] 38.2 Even if the earlier decision of the
five judge bench is perincuriam the operative part of the order cannot be interfered with in the
manner now sought to be done. That apart, the five judge bench gave its reason. The reason may or
may not be sufficient. There is advertence to s. 7(1) of the 1952 Act and to exclusive jurisdiction
created thereunder. There is also reference to s. 407 of the Criminal Procedure Code. [119D-E] 39.1
An erroneous decision must be as binding as a correct one. It would be an unattainable ideal to
require the binding effect of a judgment to depend on its being correct in the absolute, for the test of
correctness would be resort to another Court the infallibility of which is again subject to a similar
further investigation. [101D-E] 39.2 However, motions to set aside the judgments are permitted
where a judgment was rendered in ignorance of the fact that u necessary party had not been served
at all, and was wrongly shown as served or in ignorance of the fact that a necessary-party had died
and the estate was not represented, or where a judgment was obtained by fraud, and it tended to
prejudice a non-party, as in the case of judgments in-rem such as for divorce, or jactitation or
probate etc. even a person, not eo-nomine a party to the proceedings, or where a party has had no
notice and a decree is made against him in which case, the party is said to become entitled to relief
ex-debito justitiae, on proof of the fact that there was no service, since there is no trial at all and theA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

judgment is for default. [110C-F] Cases of such frank failure of natural justice are obvious cases
where relief is granted as of right. [111A] Where a person is not actually served out but is held
erroneously, to have been served, he can agitate that grievance only in that forum or in any further
proceeding therefrom. [111A] Issac v. Robertson, [1984] 3 All ER 140 distinguished. Rajunder
Narain Rae v. Bijai Govind Singh, 2 MIA 181, referred to.
D.M. Gordan: Actions to set aside judgment, [1961] 77 Law quarterly Review 358 In the present case
by the order dated 5.4.1984 a five judge bench set-out, what according to it was the legal basis and
source of jurisdiction to order transfer. On 17.4.1984 appellant's writ petition challenging that
transfer as a nullity was dismissed. These orders are not which appellant is entitled to have set aside
ex-debito justitiae by another Bench. [111C-D]
40. The pronouncements of every Division-Bench of this Court are pronouncements of the Court
itself. A larger bench, merely on the strength of its numbers, cannot un-do the finality of the
decisions of Other division benches. [108H] 41.1 The power to alter a decision by review must be
expressly conferred or necessarily inferred. The power of review and the limitations on the power
under Article 137 are implict recognitions of what would, otherwise, be final and irrevocable. No
appeal could be made to the doctrine of inherent powers of the Court either. Inherent powers do not
confer, or constitute a source of jurisdiction :. They are to be exercised in aid of a e that is already
invested. [120F-G] 41.2 If the decision suffers from an error, the only way to correct it, is to go in
Review under Article 137 read with order 40 Rule 1 framed under Article 145 before "as far as is
practicable" the same judges. This is not a matter merely of some dispensable procedural 'form' but
the requirement of substance. [109A] In the instant case, the remedy of the appellant is recourse to
Article 137, no where else. This is both in good sense and good law. [120G] Judicial proceedings of
this Court are not subject to writ jurisdiction thereof. [118H] Naresh Sridhar Mirajkar & Ors. v. State
of Maharashtra & Anr., [1966] 3 SCC 744 followed.
Prem Chand Garg v. Excise Commissioner, UP, [1963] 1 SCR 885, referred to.
Kadesh & Kadesh: Discretion to Disobey, [1973] edn. P. 111, referred to.
42. The maxim Actus Curiae Neminem Gravabid had no application to conscious conclusions
reached in a judicial decision. The maxim is not a source of a general power to reopen and rehear
adjudication which have otherwise assumed finality. The maximum operates in a different and
narrow area. The best illustration of the operation of the maxim is provided by the application of the
rule of nunc-pro-tunc. For instance, if owing to the delay in what the court should, otherwise, have
done earlier but did later, a party suffers owing to events occurring in the interrugnum, the Court
has the power to remedy it. The area of operation of the maxim is, generally, procedural. Errors in
judicial findings, either of facts or law or operative decisions consciously arrived at as a part of the
judicial-exercise cannot be interfered with by resort to this maxim. [120B-C]
43. Those who do not put the teachings of experience and the lessons of logic out of consideration
would tell what inspires confidence in the judiciary and what does not. Judicial vacillations fall in
the latter category and undermine respect of the judiciary and judicial institutions, denudingA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

thereby respect for law and the confidence in the even handedness in the administration of justice
by Courts. [120E] This Court had, therefore, the jurisdiction and power to with draw and transfer
the cases from Special Judge to the High Court, and the directions for trial of the offences by a
Special Judge are not void and these directions could not be challenged in a collateral attack. This
Court had not created a new jurisdiction and usurped legislative power violating the basic tenet of
doctrine of separation of powers. [99C-F, 114D, 106E]
44. An accused person cannot assert any right to a joint trial with his co-accused. Normally it is the
right of the prosecution to decide whom it prosecutes. It can decline to array a person as a
co-accused and, instead examine him as a witness for the prosecution. What weight is to be attached
to that evidence, as it may smack of the testimony of a guilty partner in crime, is a different matter.
Prosecution can enter Nolle proseque against any accused- person. It can seek to withdraw a charge
against an accused person. These propositions are too well settled to require any further elaboration.
[98B-D] Choraria v. Maharashtra, [1969] 2 SCR 624, referred to. In the instant case, the appellant
cannot be heard to complain. Of the so called co-conspirators some have been examined already as
pro-
secution witnesses; some others proposed to be so examined; and two others, had died in the
interregnum. The appeal, on the point, has no substance and would require to be dismissed. [98G]
Per Ranganathan, J. (partly concurring/dissenting) 45.1 The language of s. 7(1) of the 1952 Act
places a definite hurdle in the way of construing s. 407 of the Cr. P.C. as overriding its provisions. In
view of non-obstante clause also, it cannot be held that the provisions of s. 407 of the 1973 Cr. P.C.
will override, or even operate consistently with, the provisions of the 1952 Act. Similarly, the power
of transfer contained m clause 29 of the letters Patent of the High Court cannot be exercised in a
manner not contemplated by s. 7(1) of the 1952 Act. [131D- E] 45.2 A power of transfer postulates
that the court to which transfer or withdrawal is sought is competent to exercise jurisdiction over
the case. [130F] Raja Soap Factory v. Shantaraj, [ 1965] 2 SCR, relied on.
45.3 The power of transfer contained in the Code of Criminal Procedure cannot be availed of to
transfer a criminal case from a Special Judge to any other criminal court or even to the High Court.
The case can be transferred only from one special judge to another special judge; it cannot be
transferred even to a High Court Judge except where a High Court Judge is appointed as a Special
Judge. [130E-F] Gurcharan Das Chadha v. State of Rajasthan, [1966] 2 SCR, referred to.
45.4 Not all the judges of the High Court (but only those elevated from the State subordinate
judiciary) would fulfil the qualifications prescribed under s. 6(2) of the 1952 Act. Though there is
nothing in ss. 6 and 7 read together to preclude altogether the appointment of a judge of the High
Court fulfilling the above qualifications as a special judge such is not the (atleast not the normal)
contemplation of the Act. The scheme of the Act, in particular the provisions contained in ss. 8(3A)
and 9, militate against this concept. [126C, E] Hence, in the instant case apart from the fact that no
appointment of a High Court Judge, as a Special Judge, has in fact been made, it is not possible to
take the view that the statutory provisions permit the conferment of a jurisdiction to try this case on
a High Court Judge as a Special Judge. [126F] 45.5 The 1952 Act sought to expedite the trial of cases
involving public servants by the creation of courts presided over by experienced special judges to beA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

appointed by the State (government. Effect is only 13 being given to the express and specific words
used in s. 7(1) and no question arises of any construction being encouraged that is repugnant to the
Cr. P.C. Or involves an implied repeal, pro tanto, of its provisions. [132D. E] 46.1 The word
"jurisdiction is a verbal coat of many colours. " It is used in a wide and broad sense while dealing
with administrative or quasi-judicial tribunals and subordinate courts over which the superior
courts exercise a power of judicial review and superintendence. Then it is only a question of "how
much latitude the court is prepared to allow" and "there is no yardstick to determine the magnitude
of the error other than the opinion of the court.
" [158A-B] M. L. Sethi v. Kapur, [ 1973] I SCR 697, referred to. 46.2 The Superior
Courts, with unlimited jurisdiction are always presumed to act with jurisdiction and
unless it is clearly shown that any particular order is patently one which could not, on
any conceivable view of its jurisdiction, have been passed by such court, such an
order can neither be ignored nor even recalled, annulled, revoked or set aside in
subsequent proceedings by the same court. [158B-C ] Dhirendera Kumar v.
Superintendent, [1955] I SCR 224; Kiran Singh v. Chaman Paswan, AIK 1955 S.C.R.
117; Anisminic Ltd. v. Foreign Compensation Commissioner, [1969] 2 A.C. 147; Badri
Prasad v. Nagarmal, [1959] 1 Supp. S.C.R. 769; Surajmul Nagarmul v. Triton
Insurance Co. Ltd., [1924] L.R. 52 I.A. 126; Balai Chandra Hazra v. Shewdhari
Jadhav, [1978] 3 S.C.R. 147; Ledgard v. Bull, L.R. 13 I.A. 134; Meenakshi Naidu v.
Subramaniya Sastri, L.R. 14 I.A. 140; Sukhrani v. Hari Shankar, [1979] 3 S.C.R. 671;
Re: Recal Communications Ltd., [1980] 2 AER 634 and lssacs v. Robertson, [1984] 3
AER
140. referred to.
In the present case, the order passed is not one of patent lack of jurisdiction. Though
the direction in the order dated 16.2.1984 cannot be justified by reference to Article
142 of the Constitution of s. 407 of the 1973 Cr.P.C., that is not an incontrovertible
position. It was possible for another court to give a wider interpretation to these
provisions and come to the conclusion that such an order could be made under those
provisions. If this Court had discussed the relevant provisions and specifically
expressed such a conclusion, it could not have been modified in subsequent
proceedings by this Bench merely because it was inclined to hold differently. The
mere fact that the direction was given, without an elaborate discussion, cannot
render it vulnerable to such review . [158D-F]
47. Unless the earlier order is vitiated by a patent lack of jurisdiction or has resulted in grave
injustice or has clearly abridged the fundamental rights of the appellant, this Court should not
declare that an order passed by a five-Judge Bench is wrong, and annul it. The present case cannot
be brought within the narrow range of exceptions which calls for such interference. [166E] The
direction issued by this Court in the impugned order cannot be said to be based on a view which is
manifestly incorrect, palpably absurd or patently without jurisdiction. Whether it will be considered
right or wrong by a different Bench having a second-look at the issue is a totally different thing.A.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

[167E] 48.1 The powers of the Supreme Court to transfer cases from one court to another are to be
found in Article 139-A of the Constitution and s. 406 of the Cr.P.C. The provisions envisage either
inter-state transfers of cases i.e. from a court in one State to a court in another State or the
withdrawal of a case by the Supreme Court to itself. Intra- State transfer among courts subordinate
to a High Court to inter-se or from a court subordinate to a High Court to the High Court is within
the jurisdiction of the appropriate High Court. [133F-G] 48.2 The powers of the Supreme Court, in
disposing of an appeal or revision, are circumscribed by the scope of the proceedings before it.
[133H] In the instant case, the question of transfer was not put in issue before the Supreme Court.
The Court was hearing an appeal from the order of discharge and connected matters. There was no
issue or controversy or discussion before it as to the comparative merits of a trial before a special
judge vis-a-vis one before the High Court. There was only an oral request said to have been made,
admittedly after the judgment was announced. Wide as the powers under Article 141 are, they do not
envisage an order of the type presently in question. [134A, C-D] K.M. Nanavati v. The State of
Bombay, [1961] SCR 497 distinguished.
48.3 If the provisions of the 1952 Act read with Article 139-A and ss. 406-407 of the Cr.P.C. do not
permit the transfer of the case from a special judge to the High Court, that effect cannot be achieved
indirectly. In the circumstances of the case, the Supreme Court cannot issue the impugned direction
in exercise of the powers under Article 142 or under s. 407 available to it as an appellate court.
[l34F] Hari v. Emperor, AIR 1935 PC 122, referred to. The direction that the trial should be shifted
to the High Court can hardly be described as a consequential or incidental order. Such a direction
did not flow, as a necessary consequence of the conclusion of the court on the issues and points
debated before it. Therefore, this Court was in error when it directed that the trial of the case should
be before a High Court Judge, in consequence of which the appellant is being tried by a Court which
has no jurisdiction-and which cannot be empowered by the Supreme Court-to try him. The
continued trial before the High Court, therefore, infringes Article 21 of the Constitution. [135E- GI
49.1 Section 407 cannot be challenged under Article 14 as it is based on a reasonable classification
having relation to the objects sought to be achieved. Though, in general, the trial of cases will be by
courts having the normal jurisdiction over them, the exigencies of the situation may require that
they be dealt with by some other court for various reasons. Likewise, the nature of a case, the nature
of issues involved and other circumstances may render it more expedient, effective, expeditious or
desirable that the case should be tried by a superior court or the High Court itself. [136E-F3] 49.2
The power of transfer and withdrawal contained in s. 407 of the Cr.P.C. is one dictated by the
requirements of justice and is, indeed, but an aspect of the supervisory powers of a superior Court
over courts subordinate to it. [136FJ] 49.3 A judicial discretion to transfer or withdraw is vested in
the highest court of the State and is made exercisable only in the circumstances set out in the
section. Such a power is not only necessary and desirable but indispensable in the cause of the
administration of justice. The accused will continue to be tried by a or equal or superior jurisdiction.
[136G] The accused will, therefore, suffer no prejudice by reason of the application of s. 407. Even if
there is a differential treatment which causes prejudice, it is based on logical and acceptable
considerations with a view to promote the interests of justice. The transfer or withdrawal of a case to
another court or the High Court, in such circumstances, can hardly be said to result in hostile
discrimination against the accused in such a case. [137A-B] 49.4 only a power of transfer is being
exercised by the supreme Court which is sought to be traced back to the power of the High CourtA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

under s. 407. [137E] State v. Anwar Ali Sarkar, [1952] SCR 284, distinguished.
Kathi Raning Rawat v. The State of Saurashtra, [1952] 3 SCR 435, Re: Special Courts Bill, [1978]
(1972) 2 SCR 476 and Shukla v. Delhi Administration, [1980] 3 SCR 500, referred to.
50. l Where a case is withdrawn and tried by the Court, the High Court will be conducting the trial in
the exercise of its extraordinary original criminal jurisdiction. Here though the ordinary original
criminal jurisdiction is vested in a subordinate criminal court or special judge, a case is withdrawn
by the High Court to itself for trial. [139F, H] Madura Tirupparankundram etc. v. Nikhan Sahib, 35
C.W.N. 1088; Kavasji Pestonji v. Rustomji Sorabji, AIR 1949 Bombay 42; Sunil Chandra Roy and
another v. The State, AIR 1954 Calcutta 305; Peoples Insurance Co. Ltd. v. Sardul Singh Caveeshar
and others, AIR 1961 Punjab 87 and People's Patriotic Front v. K. K. Birla and others, [ 1984] Crl.
L.J. 545, referred to.
50.2 In a withdrawn case, right of first appeal to the Supreme Court against the order passed by the
High Court will be available to the accused under s. 374 of the 1973 Cr. P.C., and the accused has the
privilege of being tried in the first instance by the High Court itself with a right to approach the apex
Court by way of appeal. The apprehension that the judgment in the trial by the High Court, will be
final, with only a chance of obtaining special leave under Article 136 is totally unfounded. The
Supreme Court will consider any petition presented under Article 136 in the light of the in built
requirements of Article 21 and dispose it of as if it were itself a petition of appeal from the judgment.
Therefore an accused tried directly by the High Court by withdrawal of his case from a subordinate
court, has a right of appeal to the Supreme Court under s. 374 of the Cr. P.C. The allegation of an in-
fringement of Article 21 in such cases is, therefore, - unfounded. [140B-F] Sadanathan v.
Arunachalam, [1981] 2 SCR 673, distinguished.
50.3 The court to which the case has been transferred is a superior court and in fact the High Court.
However, the High Court Judge is not a person to whom the trial of the case can be assigned under
s.7(1) of the 1952 Act. The circumstances that a much superior forum is assigned to try a case than
the one normally available cannot by itself be treated as a "sufficient safeguard and a good
Substitute"
for the normal forum and the rights available under the normal procedure. [131G-H]
Surajmal Mohta v. Vishwanath Sastry, [1955] 1 SCR, referred to.
50.4 The accused here loses his right of coming up in revision or appeal to the High
Court from the interlocutory and final orders of the trial court, and the right of
having two courts subordinate court and the High Court-adjudicate upon his
contentions before bringing the matter up in the Supreme Court. Though these are
not such caps as violate the fundamental rights of such an accused, they are
circumstances which create prejudice to the accused and may not be Overlooked in
adopting one construction of the statue in preference to the other. [132A-B] 51.1 t It is
true that the audi altarem partem rule is a basic requirement of the rule of law. ButA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

the degree of compliance with this rule and the extent or consequences flowing from
failure to do so will vary from case to case. [168B] Nawabkhan Abbaskhan v. State,
[1974] 3 SCR 427, referred to.
In the instant case the appellant had been given no chance of being heard before the
impugned direction was given and it cannot be said whether the Bench would have
acted in the same way even if he had been given such opportunity. However, in the
circumstances of the case. this is not a fit case to interfere with the earlier order on
that ground. [167H, 168A]
51.2 The rules of natural justice must not be stretched too far. They should not be allowed to be
exploited as a purely technical weapon to undo a decision which does not in reality cause substantial
injustice and which, had the party been really aggrieved thereby, could live been set right by
immediate action. [169C] R. v. Secretary of State for Home Department ex parte Mughal, [1973] 3
All ER 796, referred to.
The direction of 16.2.1984 cannot be said to have infringed the fundamental rights of the appellant
or caused any miscarriage of justice. The appellant did know on 16.2.1984 that the judges were
giving such a direction and yet he did not protest. Perhaps he did think that being tried by a High
Court Judge would be more beneficial to him, as indeed it was likely to be. That apart, several
opportunities were available for the appellant to set this right. He did not move his little finger to
obtain a variation of this direction from this Court. He is approaching the Court nearly after two
years of his trial by the learned judge in the High Court. Volumes of testimony have been recorded
and numerous exhibits have been admitted as evidence. Though the trial is only at the stage of the
framing of charges, the trial being according to the warrant procedure, a lot of evidence has already
gone in and if the directions of this Court are re-called, it would wipe the slate clean. To take the
entire matter back at this stage to square No. 1 would be the very negation of the purpose of the 1952
Act to speed up all such trials and would result in more injustice than justice from an objective point
of view. [168G-H, 169A-B] 52.1 Situations can and do arise where this Court may be constrained to
recall or modify an order which has been passed by it earlier and that when ex facie there is
something radically wrong with the earlier order, this Court may have to exercise its plenary and
inherent powers to recall the earlier order without considering itself bound by the nice technicalities
of the procedure for getting this done. [163C] 52.2 Where a mlstake is committed by a subordinate
court or a High Court, there are ample powers in this Court to remedy the situation. But where the
mistake is in an earlier order of this Court, there is no way of having it corrected except by
approaching this Court. Sometimes, the remedy sought can be brought within the four corners of the
procedural law in which event there can be hurdle in the way of achieving the desired result. But the
mere fact that, for some reason, the conventional remedies are not available should not render this
Court powerless to give relief. [163D-E] Ghulam Sarwar v. Union of India, [1965] 2 S.C.C. 271; Soni
Vrijlal Jethalal v. Soni Jadavji Govindji, AIR 1972 Guj. 148; Jang Singh v. Brij Lal [1964] 2 S.C.R.
145 at p. 159; Bhagat Ram v. State, [1972] 2 S.C.C. 466 and State v. Tara Chand, [1973] S.C.C. Cr.
774, referred to.A.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

52.3 lt may not be possible or prudent to lay down comprehensive list of defects that will attract the
ex debito justiae relief. [163E] 52.4 Suffice it to say that the court can grant relief where there is
some manifest illegality or want of jurisdiction in the earlier order or some palpable in Justice is
shown to have resulted. Such a power can be traced either to Article 142 of the Constitution or to the
powers inherent in this Court as the apex Court and the guardian of the Constitution. [163F] Issac v.
Robertson, [1984] 3 AER 140. referred to. 52.5 However, such power has to be exercised in the
"rarest of rare" cases and there is great need for judicial discipline of the highest order in exercising
such a power, as any laxity in this regard may not only impair the eminence, dignity and integrity of
this Court but may also lead to chaotic consequences. Nothing should be done to create an
impression that this Court can be easily persuaded to alter its views on any matter and that a larger
Bench of the Court will not only be able to reverse the precedential effect of an earlier ruling but may
also be inclined to go back on it and render it ineffective in its application and binding nature even
in regard to subsequent proceedings in the same case. [163G-H 164A] Bengal Immunity Company
Ltd. v. The State of Bihar and ors., [1953] 2 SCR 603 and Sheonandan Paswan v. State of Bihar &
Ors., [1987] 1 SCR 288, referred to.
53. The power of review is conferred on this Court by Article 137 of the Constitution. It is subject not
on to the provisions of any law made by Parliament but also to rules made by this Court under
article 145. [142H] The order dated 16.2.1984 does not suffer from any error apparent on the face of
the record which can be rectified on a review application. The prayer for review has been made
beyond the period mentioned in Rule 2 of order XL of the Supreme Court Rules. No doubt this
Court has power to extend the time within which a review petition may be filed. But having regard to
the circumstances of the case there is hardly any reason to condone the delay in the prayer for
review. [144A-B,143B,147H] The appellant was alive to all his present contentions. At least when the
writ petition was dismissed as an inappropriate remedy, he should have at once moved this Court
for review. [148A] That apart even if the Court is inclined to condone the delay, the application will
have to be heard as far as possible by the same Judges who disposed of the earlier matter. [148B]
54. It will not behove the prestige and glory of this Court as envisaged under the Constitution if
earlier decisions are revised or recalled solely because a later Bench takes a different view of the
issues involved. Granting that the power of review is available, it is one to be sparingly exercised
only in extraordinary or emergent situations when there can be no two opinions about the error or
lack of jurisdiction in the earlier order and there are adequate reasons to invoke a resort to an
unconventional method of recalling or revoking the same. Such a situation is not present in the
instant case. [167F-G]
55. Prem Chand Garg cannot be treated as an authority for the proposition that an earlier order of
this Court could be quashed by the issue of a writ on the ground that it violated the fundamental
rights. Mirajkar clearly precludes such a course. [155G-H] Prem Chand Garg v. Excise
Commissioner, [1963] Supp. 1 SCR 885, explained and distinguished.
Naresh Shridhar Mirajkar and others v. State of Maharashtra and another. [1966] SCR 744 relied
on.A.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

The direction issued by this Court was not warranted in law, being contrary to the special provisions
of the 1952 Act, was also not in conformity with the principles of natural justice and that unless the
direction can be justified with reference to s. 407 of the Cr.P.C., the petitioner's fundamental rights
under Articles 14 and 21 of the Constitution can be said to have been infringed by reason of this
direction. [142C] However, this is not one of those cases in which it is considered appropriate to
recall the earlier direction and order a re-trial of the appellant de novo before a Special Judge.
[169D] & CRIMINAL APPELLATE JURISDICTION: Criminal Appeal No. 468 of 1986.
From the Judgement and order dated 24.7.86 of the Bombay High Court in Special Cash No. 24/82.
P.P. Rao, R.D. Ovlekar. M.N. Dwevedi (Not in WP. No.
542) Sulman Khurshid, N.V. Pradhan, D.R. Gadgil, R.S. Desai, M.N. Shroff K.V. Sreekumar and P.S.
Pradhan for the Petitioner Ram Jethmalani, Miss Rani Jethmalani and Ashok Sharma for the
Respondents.
A.M. Khanwilkar and A.S.Bhasme for the Respondents- State.
The majority Judgment of Sabyasachi Mukharji, G.L. Oza and S. Natarajan, JJ. was delivered by
Mukharji, J. Ranganath Misra and B.C. Ray, JJ. gave separate concurring opinions. G.L. Oza, J. also
gave a separate opinion. M.N. Venkatachaliah, J. delivered a dissenting opinion S. Ranganathan, j
was a partly concurring and partly dissenting opinion:
SABYASACHI MUKHARJI, J. The main question involved in this appeal, is whether
the directions given by this Court on 16th February, 1984. as reported in R.S. Nayak
v. A.R. Antulay,[1984] 2 S.C.R. 495 at 557 were legally proper. The next question is,
whether the action and the trial proceedings pursuant to those directions, are legal
and valid. Lastly, the third consequential question is, can those directions be recalled
or set aside or annulled in those proceedings in the manner sought for by the
appellant. In order to answer these questions certain facts have to be borne in mind.
The appellant became the Chief Minister of Maharashtra on or about 9th of June,
1980. On 1st of September, 1981, respondent No. 1 who is a member of the Bharatiya
Janta Party applied to the Governor of the State under section 197 of the Criminal
Procedure Code, 1973 (hereinafter referred to as the Code) and section 6 of the
Prevention of Corruption Act, 1947 (hereinafter referred to as the Act) for sanction to
prosecute the appellant. On 11th of September, 1981, respondent No. 1 filed a
complaint before the Additional Metropolitan Magistrate, Bombay against the
appellant and other known and unknown persons for alleged offence under sections
161 and 165 of the Indian Penal Code and section 5 of the Act as also under sections
384 and 420 read with sections 109 and 120B of the Indian Penal Code. The learned
Magistrate refused to take cognizance of the offences under the Act without the
sanction for prosecution. Thereafter a criminal revision application being C.R.A. No.
1742 of 1981 was filed in the High Court of Bombay, by respondent No. 1.A.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

The appellant thereafter on 12th of January, 1982 resigned from the position of Chief
Minister in deference to the judgment of the Bombay High Court in a writ petition
filed against him. In CRA No. 1742 of 1981 filed by respondent No. 1 the Division
Bench of the High Court held that sanction was necessary for the prosecution of the
appellant and the High Court rejected the request of respondent No. 1 to transfer the
case from the Court of the Additional Chief Metropolitan Magistrate to itself.
On 28th of July, 1982, the Governor of Maharashtra granted sanction under section
197 of the Code and section 6 of the Act in respect of five items relating to three
subjects only and refused sanction in respect of all other items.
Respondent No. 1 on 9th of August, 1982 filed a fresh complaint against the appellant
before the learned Special Judge bringing in many more allegations including those
for which sanction was refused by the Governor. It was registered as a Special Case
No. 24 of 1982. It was submitted by respondent No. 1 that there was no necessity of
any sanction since the appellant had ceased to be a public servant after his
resignation as Chief Minister.
The Special Judge, Shri P.S. Bhutta issued process to the appellant without relying on
the sanction order dated 28th of July, 1982. On 20th of October, 1982, Shri P.S.
Bhutta overruled the appellants objection to his jurisdiction to take cognizance of the
complaint and to issue process in the absence of a notification under section 7(2) of
the Criminal Law Amendment Act, 1952 (hereinafter referred to as 1952 Act)
specifying which of the three Special Judges of the area should try such cases.
The State Government on 15th of January, 1983 notified the appointment of Shri R.B.
Sule as the Special Judge to try the offences specified under section 6(1) of the 1952
Act. On or about 25th of July 1983, it appears that Shri R.B. Sule, Special Judge
discharged the appellant holding that a member of the Legislative Assembly is a
public servant and there was no valid sanction for prosecuting the appellant.
On 16th of February, 1984, in an appeal filed by respondent No. 1 directly under
Article 136, a Constitution Bench of this Court held that a member of the Legislative
Assembly is not a public servant and set aside the order of Special Judge Sule.
Instead of remanding the case to the Special Judge for disposal in accordance with
law, this Court suo motu withdrew the Special Cases No. 24/82 and 3/83 (arising out
of a complaint filed by one P.B. Samant) pending in the Court of Special Judge,
Greater Bombay, Shri R.B. Sule and transferred the same to the Bombay High Court
with a request to the learned Chief Justice to assign these two cases to a sitting Judge
of the High Court for holding the trial from day to day. These directions were given,
according to the appellant, without any pleadings, without any arguments, without
any such prayer from either side and without giving any opportunity to the appellant
to make his submissions before issuing the same. It was submitted that the
appellant's right to be tried by a competent court according to the procedureA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

established by law enacted by Parliament and his rights of appeal and revision to the
High Court under section 9 of the 1952 Act had been taken away.
The directions of this Court mentioned hereinbefore are contained in the decision of
this Court in R.S. Nayak v. A.R. Antulay, [1984] 2 S.C.R. 495 at 557. There the Court
was mainly concerned with whether sanction to prosecute was necessary. It was held
that no such sanction was necessary in the facts and circumstances of the case. This
Court further gave the following directions:
"The accused was the Chief Minister of a premier State- the State of Maharashtra. By
a prosecution launched as early 'as on September 11, 1981, his character and integrity
came under a cloud. Nearly two and a half years have rolled by and the case has not
moved an inch further. An expeditious trial is primarily in the interest of the accused
and a mandate of Article 21. Expeditious disposal of a criminal case is in the interest
of both the prosecution and - the accused. Therefore, Special Case No. 24 of 1982 and
Special Case No. 3/83 pending in the Court of Special judge, Greater Bombay Shri
R.B. Sule are withdrawn and transferred to the High Court of Bombay with a request
to the learned Chief Justice to assign these two cases to a sitting Judge of the High
Court. On being so assigned, the learned Judge may proceed to expeditiously dispose
of the cases preferably by holding the trial from day to day."
The appellant as mentioned hereinbefore had appeared before the Special Judge and objected to the
jurisdiction of the learned Judge on the ground that the case had not been properly allocated to him
by the State Government. The Special Judge Bhutta after hearing the parties had decided the case
was validly filed before him and he had properly taken cognizance. He based his order on the
construction of the notification of allocation which was in force at that time. Against the order of the
learned Special Judge rejecting the appellant's contention, the appellant filed a revision application
in the High Court of Bombay. During the pendency of the said revision application, the Government
of Maharashtra issued a notification appointed Special Judge R.B. Sule, as the Judge of the special
case. it is the contention of the respondents before us that the appellant thereafter did not raise any
further objection in the High Court against cognizance being taken by Shri Bhutta. It is important to
take note of this contention because one of the points urged by Shri Rao on behalf of the appellant
was that not only we should set aside the trial before the High Court as being without jurisdiction
but we should direct that no further trial should take place before the Special Judge because the
appellant has suffered a lot of which we shall mention later but also because cognizance of the
offences had not been taken properly. In order to meet the submission that cognizance of the
offences had not been taken properly, it was urged by Shri Jethmalani that after the Government
Notification appointing Judge Sule as the Special Judge, the objection that cognizance of the
offences could not be taken by Shri Bhutta was not agitated any further. The other objections that
the appellant raised against the order passed by Judge Bhutta were dismissed by the High Court of
Bombay. Against the order of the Bombay High Court the appellant filed a petition under Article 136
of the constitution. The appeal after grant of leave was dismissed by a judgment delivered on 16th
February, 1984 by this Court in A.R. Antulay v. Ramdas Sriniwas Nayak and another, [1984] 2 S
C.R. 914. There at page 954 of the report, this Court categorically observed that a private complaintA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

filed by the complaint was clearly maintainable and that the cognizance was properly taken. This
was the point at issue in that appeal. This was decided against the appellant. On this aspect
therefore, the other point is open to the appellant. We are of the opinion that this observation of this
Court cannot by any stretch of imagination be considered to be without jurisdiction. Therefore, this
decision of this Court precludes any scope for argument about the validity of the cognizance taken
by Special Judge Bhutta. Furthermore, the case had proceeded further before the Special Judge,
Shri Sule and the learned Judge passed an order of discharge on 25th July, 1983. This order was set
aside by the Constitution Bench of this Court on 16th February, 1984, in the connected judgment
(vide 1984 2 S.C.R. 495). The order of taking cognizance had therefore become final and cannot be
reagitated. Moreover section 460(e) of the Code expressly provides that if any Magistrate not
empowered by law to take cognizance of an offence on a complaint under section 190 of the Code
erroneously in good faith does so his proceedings shall not be set aside merely on the ground that he
was not so empowered.
Pursuant to the directions of this Court dated 16th February, 1984, on 1st of March, 1984, the Chief
Justice of the Bombay High Court assigned the cases to S.N. Khatri, J. The appellant, it is contended
before us, appeared before Khatri, J. and had raised an objection that the case could be tried by a
Special Judge only appointed by the Government under the 1952 Act. Khatri, J. On 13th of March,
1984, refused to entertain the appellant's objection to jurisdiction holding that he was bound by the
order of this Court. There was another order passed on 16th of March, 1984 whereby Khatri, J. dealt
with the other contentions raised as to his jurisdiction and rejected the objections of the appellant.
Being aggrieved the appellant came up before this Court by filing special leave petitions as well as
writ petition. This Court on 17th April, 1984, in Abdul Rehman Antulay v. Union of India and others
etc., [1984] 3 S.C.R. 482 at 483 held that the learned Judge was perfectly justified and indeed it was
the duty of the learned Judge to follow the decision of this Court which was binding on him. This
Court in dismissing the writ petition observed, inter alia, as follows:
"In my view, the writ petition challenging the validity of the order and judgment
passed by this Court as nullity or otherwise incorrect cannot be entertained. I wish to
make it clear that the dismissal of this writ petition will not pre judice the right of the
petitioner, to approach the Court with an appropriate review petition or to file any
other application which he may be entitled in law to file."
D.N. Mehta, J. to whom the cases were transferred from Khatri, J. framed charges under 21 heads
and declined to frame charges under 22 other heads proposed by respondent No. 1. This Court
allowed the appeal by special leave preferred by respondent No. 1 except in regard to three draft
charges under section 384, I.P.C. (extortion) and directed the Court below to frame charges with
regard to all other offences alleged. This Court requested the Chief Justice of the Bombay High
Court to nominate another Judge in place of D.N. Mehta, J. to take up the trial and proceed
expeditiously to dispose of the case finally. See in this connection R. S. Nayak v. A .R. Antulay and
another, [1986] 2 S.C.C. 716.A.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

P.S. Shah, J. to whom the cases were referred to from D.N. Mehta, J. On 24th of July, 1986
proceeded to frame as many as 79 A charges against the appellant and decided not to proceed
against the other named co-conspirators. This is the order impugned before us. Being aggrieved by
the aforesaid order the appellant filed the present Special leave Petition (Crl.) No. 2519 of 1986
questioning the jurisdiction to try the case in violation of the appellant's fundamental rights
conferred by Articles 14 and 21 and the provisions of the Act of 1952. The appellant also filed Special
leave Petition (Crl.) No. 2518 of 1986 against the judgment and order dated 21st of August, 1986 of
P.S. Shah, J. holding that none of the 79 charges framed against the accused required sanction
under section 197(1) of the Code. The appellant also filed a Writ Petition No. 542 of 1986 challenging
a portion of section 197(1) of Code as ultra vires Articles 14 and 21 of the Constitution.
This Court granted leave in Special Leave Petition (Crl. ) No. 2519 of 1986 after hearing respondent
No. 1 and stayed further proceedings in the High Court. This Court issued notice in Special Leave
Petition (Crl.) No. 2518 and Writ Petition (Crl.) No. 542 of 1986 and directed these to be tagged on
with the appeal arising out of Special Leave Petition (Crl. ) No. 2519 of 1986.
On 11th of October, 1986 the appellant filed a Criminal Miscellaneous Petition for permission to
urge certain additional grounds in support of the plea that the origination of the proceedings before
the Court of Shri P.S. Bhutta, Special Judge and the process issued to the appellant were illegal and
void ab initio.
This Court on 29th October, 1986 dismissed the application for revocation of special leave petition
filed by respondent No. 1 and referred the appeal to a Bench of 7 Judges of this Court and indicated
the points in the note appended to the order for consideration of this Bench.
So far as SLP (Crl.) No. 2518/86 against the judgment and order dated 21st August, 1986 of P.S.
Shah, J. Of the Bombay High Court about the absence of sanction under section 197 of the Code is
concerned, we have by an order dated 3rd February, 1988 delinked that special leave petition
inasmuch as the same involved confederation of an independent question and directed that the
special leave petition should be heard by any appropriate Bench after disposal of this appeal,
Similarly, Writ Petition (Crl.) No. 542 of 1986 challenging a H portion of section 197(1) of the
Criminal Procedure Code as ultra vires Articles 14 and 21 of the Constitution had also to be delinked
by our order dated 3rd February, 1988 to be heard along with special leave petition no 2518 of 1986.
This judgment therefore, does not cover these two matters.
In this appeal two questions arise, namely, (1) whether the directions given by this Court on 16th of
February, 1984 in R.S. Nayak v. A.R. Antulay, [1984] 2 S.C.R. 495 withdrawing the Special Case No.
24/82 and Special Case No. 3/83 arising out of the complaint filed by one shri P.B. Samant pending
in the Court of Special Judge, Greater Bombay, Shri R.B. Sule, and transferring the same to the High
Court of Bombay with a request to the Chief Justice to assign these two cases to a sitting Judge of
the High Court, in breach of section 7(1) of the Act of 1952 which mandates that offences as in this
case shall be tried by a Special Judge only thereby denying at least one right of appeal to the
appellant was violative of Articles 14 and 21 of the Constitution and whether such directions were at
all valid or legal and (2) if such directions were not at all valid or legal in view. Of the order datedA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

17th. Of April, 1984 referred to hereinbefore, is this appeal sustainable or the grounds therein
justiciable in these proceedings. In other words,- are 711 the said directions in a proceedings inter-
parties binding even if bad in law or violative of Articles 14 and 21 of the Constitution and as such
are immune from correction by this Court even though they cause prejudice and do injury? These
are the basic questions which this Court must answer in this appeal.
The contention that has been canvassed before us was that save as provided in sub-section (1) of
section 9 of the Code the provisions thereof corresponding to section 9(1) of the Criminal Procedure
Code, 1898) shall so far as they are not inconsistent with the Act apply to the proceedings before the
Special Judge and for purposes of the said provisions the Court of the Special Judge shall be deemed
to be a Court of Session trying cases without a jury or without the aid of assessors and the person
conducting the prosecution before a Special Judge shall be deemed to be a public prosecutor. It was
submitted 'before us that it was a private complaint and the prosecutor was not the public
prosecutor. This was another infirmity which this trial suffered, it was pointed out. In the
background of the main issues involved in this appeal we do not propose to deal with this subsidiary
point which is of not any significance.
The only question with which we are concerned in this appeal is, whether the case which is triable
under the 1952 Act only by a Special Judge appointed under section 6 of the said Act could be
transferred to the High Court for trial by itself or by this Court to the High Court for trial by it.
Section 406 of the Code deals with transfer of criminal cases and provides power to this Court to
transfer cases and appeals whenever it is made to appear to this Court that an order under this
section is expedient for the ends of justice. The law provides that this Court may direct that any
particular case or appeal be transferred from one High Court to another High Court or from a
Criminal Court subordinate to one High Court to another Criminal Court of equal or superior
jurisdiction subordinate to another High Court. Equally section 407 deals with the power of High
Court to transfer cases and appeals. Under section 6 of the 1952 Act, the State Government is
authorised to appoint as many Special Judges as may be necessary for such area or areas for
specified offences including offences under the Act. Section 7 of the 1952 Act deals with cases triable
by Special Judges. The question, therefore, is whether this Court under section 406 of the Code
could have transferred a case which was triable only by a Special Judge to be tried by the High Court
or even if an application had been made to this Court under section 406 of the Code to transfer the
case triable by a Special Judge to another Special Judge could that be transferred to a High Court,
for trial by it. It was contended by Shri Rao that the jurisdiction to entertain and try cases is
conferred either by the Constitution or by the laws made by Parliament. He referred us to the
powers of this Court under Articles 32, 131, 137, 138, 140, 142 and 145(1) of the Constitution. He also
referred to Entry 77 of List I of the Constitution which deals with the constitution of the courts. He
further submitted that the appellant has a right to be tried in accordance with law. and no procedure
which will deny the equal protection of law can be invented and any order passed by this Court
which will deny equal protection of laws would be an order which is void by virtue of Article 13(2) of
the Constitution. He referred us to the previous order of this Court directing the transfer of cases to
the High Court and submitted that it was a nullity because of the consequences of the wrong
directions of this Court. The enormity of the consequences warranted this Court's order being
treated as a nullity. The directions denied the appellant the remedy by way of appeal as of right.A.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

Such erroneous or mistaken directions should be corrected at the earliest opportunity, Shri Rao
submitted.
Shri Rao also submitted that the directions given by the Court were without jurisdiction and as such
void. There was no jurisdiction, according to Shri Rao, or power to transfer a case from the Court of
the Special Judge to any High Court. Section 406 Gf the Code only permitted transfer of cases from
one High Court to another High Court or from a Criminal Court subordinate to one High Court to a
Criminal Court subordinate to another High Court. It is apparent that the impugned directions
could not have been given under section 406 of the Code as the Court has no such power to order
the transfer from the Court of the Special Judge to the High Court of Bombay.
Section 7(1) of the 1952 Act creates a condition which is sine qua non for the trial of offences under
section 6(1) of the said Act. The condition is that notwithstanding anything contained in the Code of
Criminal Procedure or any other law, the said offences shall be triable by Special Judges only.
(Emphasis supplied). Indeed conferment of the exclusive jurisdiction of the Special Judge is
recognised by the judgment delivered by this Court in A.R. Antulay v. Ramdas Sriniwas Nayak and
another, [1984] 2 S.C.R. 914 where this Court had adverted to section 7(1) of the 1952 Act and at
page 931 observed that section 7 of the 1952 Act conferred exclusive jurisdiction on the Special
Judge appointed under section 6 to try cases set out in section 6(1)(a) and 6(1)(b) of the said Act.
The Court emphasised that the Special Judge had exclusive jurisdiction to try offences enumerated
in section 6(1)(a) and (b). In spite of this while giving directions in the other matter, that is, R.S.
Nayak v. A.R. Antulay, [1984] 2 S.C.R. 495 at page 557, this Court directed transfer to the High
Court of Bombay the cases pending before the Special Judge. It is true that section 7(1) and Section
6 of the 1952 Act were referred to while dealing with the other matters but while dealing with the
matter of directions and giving the impugned directions, it does not appear that the Court kept in
mind the exclusiveness of the jurisdiction of the Special Court to try the offences enumerated in
section 6.
Shri Rao made a point that the directions of the Court were given per incuriam, that is to say
without awareness of or advertence to the exclusive nature of the jurisdiction of the Special Court
and without reference to the possibility of the violation of the fundamental rights in a case of this
nature as observed by a seven Judges Bench decision in The State of West Bengal v. AnwarAli Sarkar
[1952] S.C.R. 284.
Shri Ram Jethmalani on behalf of the respondents submitted that the judgment of the Constitution
Bench of this Court was delivered on 16th of February, 1984 and counsel for both sides were present
and it was neither objected to nor stated by the appellant that he wanted to be heard in regard to the
transfer of the trial forum. He submitted that the order of discharge was not only challenged by a
special leave petition before this Court but also that a revision application before the High Court
being Criminal Revision Application No. 354/83 was filed but the Criminal Revision Application by
an order of this Court was withdrawn and heard along with the special leave petition. That
application contained a prayer to the effect that the order of discharge be set aside and the case be
transferred to the High Court for trial. Therefore, it was submitted that the order of transfer was
manifestly just. There was no review against this order. It was submitted that the order of transfer toA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

a superior court cannot in law or in fact ever cause any harm or prejudice to any accused. It is an
order made for the benefit of the accused and in the interests of justice. Reliance was placed on
Romesh Chandra Arora v. The State, [1960] 1 S.C.R. 924 at 927 and 934. It was further submitted by
Shri Jethmalani that a decision which has become final cannot be challenged. Therefore, the present
proceedings are an abuse of the process of the Court, according to him. It was further submitted that
all the attributes of a trial court were present in a Court of Appeal, an appeal being a continuation of
trial before competent Court of Appeal and, therefore, all the qualifications of the trial court were
there. The High Court is authorised to hear an appeal from the judgment of the Special Judge under
the Act of 1952. It was submitted that a Special Judge except in so far as a specific provision to the
contrary is made is governed by all the provisions of the Code and he is a Court subordinate to the
High Court. See A.R. Antulay v. R.S. Nayak and another, [1984] 2 S.C.R. 914 at 943 and 944.
It was submitted that power under section 526 of the old Code corresponding to section 407 of the
new Code can be exercised qua a Special Judge. This power, according to Shri Jethmalani, is
exerciseable by the High Court in respect of any case under Section 407(1)(iv) irrespective of the
Court in which it is pending. This part of the section is not repealed wholly or pro tanto, according to
the learned counsel, by anything in the 1952 Act. The Constitution Bench, it was submitted,
consciously exercised this power. It decided that the High Court had the power to transfer a case to
itself even from a Special Judge. That decision is binding at least in this case and cannot be
reopened, it was urged. In this case what was actually decided cannot be undone, we were told
repeatedly. It will produce an intolerable state of affairs. This Court sought to recognise the
distinction between finality of judicial orders qua the parties and the reviewability for application to
other cases. Between the parties even a wrong decision can operate as res judicata. The doctrine of
res judicata is applicable even to criminal trials, it was urged. Reliance was placed on Bhagat Ram v.
State of Rajasthan, [1972] 2 S.C.C.466. A judgment of a High Court is binding in all subsequent
proceedings in the same case; more so, a judgment which was unsuccessfully challenged before this
Court.
It is obvious that if a case could be transferred under section 406 of the Code from a Special Judge it
could only be transferred to another Special Judge or a court of superior jurisdiction but
subordinate to the High Court. No such court exists. Therefore, under this section the power of
transfer can only be from one Special Judge to another Special Judge. Under section 407 however,
corresponding to section 526 of the old Code, it was submitted the High Court has power to transfer
any case to itself for being tried by it, it was submitted.
It appears to us that in Gurcharan Das Chadha v. State of Rajasthan, [1966] 2 S.C.R. 678 an identical
question arose. The petitioner in that case was a member of an All India Service serving in the State
of Rajasthan. The State Government ordered his trial before the Special Judge of Bharatpur for
offences under section 120B/161 of the Indian Penal Code and under sections 5(1)(a) and (d) and
5(2) of the Act. He moved this Court under section 527 of the old Code praying for transfer of his
case to another State on various grounds. Section 7(1) of the Act required the offences involved in
that case to be tried by a Special Judge only, and section 7(2) of the Act required the offences to be
tried by a Special Judge for the area within which these were committed which condition could
never be satisfied if there was a transfer. This Court held that the condition in sub-section (1) ofA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

section 7 of the Act that the case must be tried by a Special Judge, is a sine qua non for the trial of
offences under section 6. This condition can be satisfied by transferring the case from one Special
Judge to another Special Judge. Sub-section (2) of section 7 merely distributes, it was noted, work
between Special Judges appointed in a State with reference to territory. This provision is at par with
the section of the Code which confers territorial jurisdiction on Sessions Judges and magistrates. An
order of transfer by the very nature of things must sometimes result in taking the case out of the
territory. The third sub-section of section 8 of the Act preserves the application of any provision of
the Code if it is not inconsistent with the Act save as provided by the first two sub-sections of that
Section. It was held by this Court that section 527 of the old Code, hence, remains applicable if it is
not inconsistent with section 7(2) of the Act. It was held that there was no inconsistency between
section 527 of the Code and section 7(2) of the Act as the territorial jurisdiction created by the latter
operates in a different sphere and under different circumstances. Inconsistency can only be found if
two provisions of law apply in identical circumstances, and create contradictions. Such a situation
does not arise when either this Court or the High Court exercises the power of transfer. Therefore,
this Court in exercise of its jurisdiction and power under section 521 of the Code can transfer a case
from a Special Judge subordinate to one High Court to another Special Judge subordinate to
another High Court. It has to be emphasised that that decision was confined to the power under
section 527 of the previous Code and to transfer from one Special to another Special Judge though of
another State. It was urged by Shri Jethmalani that Chadha's case (supra) being one of transfer from
one Special Judge to another the judgment is not an authority for the proposition that it cannot be
transferred to a court other than that of a Special Judge or to the High Court. But whatever be the
position, this is no longer open at this juncture.
The jurisdiction, it was submitted, created by section 7 of the Act of 1952 is of exclusiveness qua the
Courts subordinate to the High Court. It is not exclusive qua a Court of superior jurisdiction
including a Court which can hear an appeal against its decision. The non obstante clause does not
prevail over other provisions of the Code such as those which recognise the powers of the superior
courts to exercise jurisdiction on transfer. It was submitted that the power of transfer vested in the
High Court is exercisable qua Special Judges and is recognised not merely by Chadha's case but in
earlier cases also, Shri Jethmalani submitted.
It was next submitted that apart from the power under sections 406 and 407 of the Code the power
of transfer is also exercisable by the High Court under Article 228 of the Constitution. There' is no
doubt that under this Article the case can be withdrawn from the Court of a Special Judge. It is open
to the High Court to finally dispose it of. A chartered High Court can make orders of transfer under
clause 29 of the Letters Patent. Article 134(1)(b) of the Constitution expressly recognises the
existence of such power in every High Court.
It was further submitted that any case transferred for trial to the High Court in which it exercises
jurisdiction only by reason of the order of transfer is a case tried not in ordinary original criminal
jurisdiction but in extraordinary original criminal jurisdiction. Some High Courts had both ordinary
criminal jurisdiction as well as extraordinary criminal original jurisdiction. The former was
possessed by the High Courts of Bombay, Madras and Calcutta. The first two High Courts abolished
it in the 40's and the Calcutta High Court continued it for quite some time and after the 50's in aA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

truncated form until it was finally done away with by the Code. After the Code the only original
criminal jurisdiction possessed by all the High Courts is extraordinary. It can arise by transfer under
the Code or the Constitution or under clause 29 of the Letters Patent. It was submitted that it was
not right that extraordinary original criminal jurisdiction is contained only in clause 24 of the
Letters Patent of the Bombay High Court. This is contrary to section 374 of the Code itself. That
refers to all High Courts and not merely all or any one of the three Chartered High Courts. In P.P.
Front, New Delhi v. KK. Birla and others, [1984] Criminal Law Journal 545, the Delhi High Court
recognised its extraordinary original criminal jurisdiction as the only one that it possessed. The
nature of this jurisdiction is clearly explained in Madura, Tirupparankundram etc. v. Alikhan Sahib
and Ors, 35 Calcutta Weekly Notes, 1088 and Sunil Chandra Roy and another v. The State, A.I.R.
1954 Calcutta 305, paragraph 15. Reference may also be made to the Law Commissioner's 41st
Report, paragraphs 3.1 to 3.6 at page 29 and paragraph 31. 10 at page 259.
The 1952 Act was passed to provide for speedier trial but the procedure evolved should not be so
directed, it was submitted, that it would violate Article 14 as was held in Anwar Ali Sarkar's case
(supra).
Section 7 of the 1952 Act provides that notwithstanding anything contained in the Code of Criminal
Procedure, or in any other law the offences specified in sub-section (1) of section 6 shall be triable by
Special Judges only. So the law provides for a trial by Special Judge only and this is notwithstanding
anything contained in sections 406 and 407 of the Code of Criminal Procedure, 1973. Could it,
therefore, be accepted that this Court exercised a power not given to it by Parliament or the
Constitution and acted under a power not exercisable by it? The question that has to be asked and
answered is if a case is tried by a Special Judge or a court subordinate to the High Court against
whose order an appeal or a revision would lie-to the High Court, is transferred by this Court to the
High Court and such right of appeal or revision is taken away would not an accused be in a worse
position than others? This Court in R.S. Nayak v. A.R. Antulay, [1984] 2 S.C.R. 495 did not refer
either to section 406 or section 407 of the Code. It is only made dear that if the application had been
made to the High Court under section 407 of the Code, the High Court might have transferred the
case to itself The second question that arises here is if such a wrong direction has been given by this
Court can such a direction inter-parties be challenged subsequently. This is really a value
perspective judgement.
In Kiran Singh and others v. Chaman Paswan and others, l 19551 1 S.C.R. 117 at 121 Venkatarama
Ayyar, J. Observed that the fundamental principle is well established that a decree passed by a Court
without jurisdiction is a nullity, and that its validity could be set up whenever and wherever it is
sought to be enforced or relied upon-even at the stage of execution and even in collateral
proceedings. A defect of jurisdiction whether it is pecuniary or territorial, or whether it is in respect
of the subject-matter of the action, strikes at the very authority of the Court to pass any decree, and
such a defect cannot be cured even by consent of parties.
This question has been well put, if we may say so, in the decision of this Court in M.L. Sethi v. R.P.
Kapur, [1973] 1 S.C.R. 697 where Mathew, J. Observed that the jurisdiction was a verbal coat of
many colours and referred to the decision in Anisminic Ltd. v. Foreign Compensation Commission,A.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

[1969] 2 A.C. 147 where the majority of the House of Lords dealt with the assimilation of the
concepts of 'lack' and 'excess' of jurisdiction or, in other words, the extent to which we have moved
away from the traditional concept of jurisdiction. The effect of the dicta was to reduce the difference
between jurisdictional error and error of law within jurisdiction almost to a vanishing point. What is
a wrong decision on a question of limitation, he posed referring to an article of Professor H.W.R.
Wade, "Constitutional and Administrative Aspects of the Anismanic case" and concluded; "it is a bit
difficult to understand how an erroneous decision on a question of limitation or res judicata would
oust the jurisdiction of the Court in the primitive sense of the term and render the decision or decree
embodying the decision a nullity liable to collateral attack .. And there is no yardstick to determine
the magnitude of the error other than the opinion of the Court." (Emphasis supplied) While
applying the ratio to the facts of the present controversy, it has to be borne in mind that section 7(1)
of the 1952 Act creates a condition which is sine qua non for the trial of offenders under section 6(1)
of that Act. In this connection, the offences specified under section 6(1) of the 1952 Act are those
punishable under sections 161, 162,  163, 164 and 165A of the Indian Penal Code and section 5 of the
1947 Act. Therefore, the order of this Court transferring the cases to the High Court on 16th
February, 1984, was not authorised by law. This Court, by its directions could not confer jurisdiction
on the High Court of Bombay to try any case which it did not possess such jurisdiction under the
scheme of the 1952 Act. It is true that in the first judgment in A.R. Antulay v. Ramdas Sriniwas
Nayak and another, [1984] 2 S.C.R. 914 when this Court was analysing the scheme of the 1952 Act, it
referred to sections 6 and 7 at page 931 of the Reports. The arguments, however, were not advanced
and it does not appear that this aspect with its remifications was present in the mind of the Court
while giving the impugned directions.
Shri Jethmalani sought to urge before us that the order made by the Court was not without
jurisdiction or irregular. We are unable to agree. It appears to us that the order was quite clearly per
incuriam. This Court was not called upon and did not decide the express limitation on the power
conferred by section 407 of the Code which includes offences by public servants mentioned in the
1952 Act to be overridden in the manner sought to be followed as the consequential direction of this
Court. This Court, to be plain, did not have jurisdiction to transfer the case to itself. That will be
evident from an analysis of the different provisions of the Code as well as the 1952 Act. The power to
create or enlarge jurisdiction is legislative in character, so also the power to confer a right of appeal
or to take away a right of appeal. Parliament alone can do it by law and no Court. whether superior
or inferior or both combined can enlarge the jurisdiction of a Court or divest a person of his rights of
revision and appeal. See in this connection the observations in M.L. Sethi v. R.P. Kapur (supra) in
which Justice Mathew considered Anisminic, [1969] 2 AC 147 and also see Halsbury's Laws of
England, 4th Edn. Vol. 10 page 327 at para 720 onwards and also Amnon Rubinstein 'Jurisdiction
and Illegality' (1965 Edn. pages 16-50). Reference may also be made to Raja Soap Factory v. S. P.
Shantaraj, [1965] 2 SCR 800.
The question of validity, however, is important in that the want of jurisdiction can be established
solely by a superior Court and that, in practice, no decision can be impeached collaterally by any
inferior Court. But the superior Court can always correct its own error brought to its notice either by
way of petition or ex debito justitiae. See Rubinstein's Jurisdiction and Illegality' (supra).A.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

In the aforesaid view of the matter and the principle reiterated, it is manifest that the appellant has
not been ordered to be tried by a procedure mandated by law, but by a procedure which was
violative of Article 21 of the Constitution. That is violative of Articles 14 and 19 of the Constitution
also, as is evident from the observations of the 7 Judges Bench judgment in Anwar Ali Sarkar's case
(supra) where this Court found that even for a criminal who was alleged to have committed an
offence, a special trial would be per se illegal because it will deprive the accused of his substantial
and valuable privileges of defences which, others similarly charged, were able to claim. As Justice
Vivian Bose observed in the said decision at page 366 of the report, it matters not whether it was
done in good faith, whether it was done for the convenience of Government, whether the process
could be scientifically classified and labelled, or whether it was an experiment for speedier trial
made for the good of society at large. Justice Bose emphasised that it matters not how lofty and
laudable the motives were. The question which must be examined is, can fair minded, reasonable,
unbiased and resolute men regard that with equanimity and call it reasonable, just and fair, regard it
as equal treatment and protection in the defence of liberties which is expected of a sovereign
democratic republic in the conditions which are obtained in India today. Judged by that view the
singling out of the appellant in this case for a speedier trial by the High Court for an offence of which
the High Court had no jurisdiction to try under the Act of 1952 was, in our opinion, unwarranted,
unprecedented and the directions given by this Court for the said purpose, were not warranted. If
that is the position, when that fact is brought to our notice we must remedy the situation. In
rectifying the error, no procedural inhibitions should debar this Court because no person should
suffer by reason of any mistake of the Court. The Court, as is manifest, gave its directions on 16th
February, 1984. Here no rule of res judicata would apply to prevent this Court from entertaining the
grievance and giving appropriate directions. In this connection, reference may be made to the
decision of the Gujarat High Court in Soni Vrajlal Jethalal v. Soni Jadavji Govindji and others, A.I.R.
1972 Guj. 148. Where D.A. Desai, J. speaking for the Gujarat High Court observed that no act of the
court or irregularity can come in the way of justice being done and one of the highest and the first
duty of all Courts is to take care that the act of the Court does no in jury to the suitors.
It appears that when this Court gave the aforesaid directions on 16th February, 1984, for the
disposal of the case against the appellant by the High Court, the directions were given oblivious of
the relevant provisions of law and the decision in Anwar Ali Sarkar's case (supra).
See Halsbury's Laws of England, 4th End, Vol. 26, page 297, para 578 and page 300, the relevant
notes 8, 11 and 15; Dias on Jurisprudence, 5th Edn., pages 128 and 130; Young v. Bristol Aeroplane
Co. Ltd., [1944] 2 AER 293 at 300. Also see the observations of Lord Goddard in Moore v. Hewitt,
[1947] 2 A.E.R. 270 at 272-A and Penny v. Nicholas, [1950] 2 A.E.R. 89, 92A. "per incuriam" are
those decisions given in ignorance or forgetfulness of some inconsistent statutory provision or of
some authority binding on the Court concerned, so that in such cases some part of the decision or
some step in the reasoning on which it is based, is found, on that account to be demonstrably wrong.
See Morelle v. Wakeling, [1955] 1 All E.R. 708, 718F. Also see State of Orissa v. The Titaghur Paper
Mills Co. Ltd., [19851 3 SCR
26. We are of the opinion that in view of the clear provisions of section 7(2) of the Criminal Law
Arnendment Act, 1952 and Articles 14 and 21 of the Constitution, these directions were legallyA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

wrong.
The principle that the size of the Bench-whether it is comprised of two or three or more Judges-does
not matter, was enunciated in Young v. Bristol Aeroplane Co. Ltd. (supra) and followed by Justice
Chinnappa Reddy in Javed Ahmed Abdul Hamid Pawala v. State of Maharashtra, [1985] 2 SCR 8
where it has been held that a Division Bench of three Judges should not overrule a Division Bench of
two Judges, has not been followed by our Courts. According to wellsettled law and various decisions
of this Court, it is also well-settled that a Full Bench or a Constitution Bench decision as in Anwar
Ali Sarkar's case (supra) was binding on the Constitution Bench because it was a Bench of 7 Judjes.
The principle in England that the size of the Bench does not matter, is clearly brought out in the
decision of Evershed M.R. in the case of Morelle v. Wakeling (supra). The law laid down by this
Court is somewhat different. There is a hierarchy within the Court itself here, where larger Benches
overrule smaller Benches. See the observations of this Court in Mattulal v. Radhe Lal, [1975] 1 SCR
127, Union of India & Anr. v. K.S. Subramanian, [1977] 1 SCR 87 at page 92 and State of U.P. v. Ram
Chandra Trivedi, [1977] 1 SCR 462 at 473. This is the practice followed by this Court and now it is a
crystallised rule of law. See in this connection, as mentioned hereinbefore, the observations of the
State of Orissa v. Titagarh Paper Mills (supra) and also Union of India and others v. Godfrey Philips
India Ltd., [1985] Suppl 3 SCR 123 at 145.
In support of the contention that a direction to delete wholly the impugned direction of this Court be
given, reliance was placed on Satyadhvan Ghoshal v. Deorajini Devi, [1960] 3 SCR
590. The ratio of the decision as it appears from pages 601 to 603 is that the judgment which does
not terminate the proceedings, can be challenged in an appeal from final proceedings. It may be
otherwise if subsequent proceedings were independent ones.
The appellant should not suffer on account of the direction of this Court based upon an error leading
to conferment of jurisdiction.
In our opinion, we are not debarred from re-opening this question and giving proper directions and
correcting the error in the present appeal, when the said directions on 16th February, 1984, were
violative of the limits of jurisdiction and the directions have resulted in deprivation of the
fundamental rights of the appellant, guaranteed by Articles 14 and 21 of the Constitution. The
appellant has been treated differently from other offenders, accused of a similar offence in view of
the provisions of the Act of 1952 and the High Court was not a Court competent to try the offence. It
was directed to try the appellant under the directions of this Court, which was in derogation of
Article 21 of the Constitution. The directions have been issued without observing the principle of
audi alteram partem. It is true that Shri Jethmalani has shown us the prayers made before the High
Court which are at page 121 of the paper- book. He argued that since the transfers have been made
under section 407, the procedure would be that given in section 407(8) of the Code. These
directions, Shri Jethmalani sought to urge before us, have been given in the presence of the parties
and the clarificatory order of April 5, 1985 which was made in the presence of the appellant and his
Counsel as well as the Counsel of the State Government of Maharashtra, expressly recorded that noA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

such submission was made in connection with the prayer for grant of clarification. We are of the
opinion that Shri Jethmalani is not right when he said that the decision was not made per incuriam
as submitted by the appellant. It is a settled rule that if a decision has been given per incuriam the
Court can ignore it. It is also true that the decision of this Court in the case of The Bengal Immunity
Co. Ltd. v. The State of Bihar & Ors. [1955] 2 SCR 603 at 623 was not regarding an order which had
become conclusive inter-parties. The Court was examining in that case only the doctrine of
precedents and determining the extent to which it could take a different view from one previously
taken in a different case between different parties.
According to Shri Jethmalani, the doctrine of per incuriam has no application in the same
proceedings. We are unable to accept this A contention. We are of the opinion that this Court is not
powerless to correct its error which has the effect of depriving a citizen of his fundamental rights
and more so, the right to life and liberty. It can do so in exercise of its inherent jurisdiction in any
proceeding pending before it without insisting on the formalities of a review application. Powers of
review can be exercised in a petition filed under Article 136 or Article 32 or under any other
provision of the Constitution if the Court is satisfied that its directions have resulted in the
deprivation of the fundamental rights of a citizen or any legal right of the petitioner. See the
observations in Prem Chand Garg v. Excise Commissioner, U.P. Allahabad, [1963] Supp. 1 S.C.R.
885.
In support of the contention that an order of this Court be it administrative or judicial which is
violative of fundamental right can always be corrected by this Court when attention of the Court is
drawn to this infirmity, it is instructive to refer to the decision of this Court in Prem Chand Garg v.
Excise Commissioner, U.P., Allahabad (supra). This is a decision by a Bench of five learned Judges.
Gajendragadkar, J. spoke for four learned Judges including himself and Shah, J. expressed a
dissenting opinion. The question was whether Rule 12 of order XXXV of the Supreme Court Rules
empowered the Supreme Court in writ petitions under Article 32 to require the petitioner to furnish
security for the costs of the respondent. Article 145 of the Constitution provides for the rules to be
made subject to any law made by Parliament and Rule 12 was framed thereunder. The petitioner
contended that the rule was invalid as it placed obstructions on the fundamental right guaranteed
under Article 32 to move the Supreme Court for the enforcement of fundamental rights. This rule as
well as the judicial order dismissing the petition under Article 32 of the Constitution for
non-compliance with Rule 12 of order XXXV of the Supreme Court Rules were held invalid. In order
to appreciate the significance of this point and the actual ratio of that decision so far as it is relevant
for our present purpose it is necessary to refer to a few facts of that decision. The petitioner and 8
others who were partners of M/s. Industrial Chemical Corporation, Ghaziabad, had filed under
Article 32 of the Constitution a petition impeaching the validity of the order passed by the Excise
Commissioner refusing permission to the Distillery to supply power alcohol to the said petitioners.
The petition was admitted on 12th December, 1961 and a rule was ordered to be issued to the
respondents, the Excise Commissioner of U.P., Allahabad, and the State of U.P. At the time when
the rule was issued, this Court directed under the impugned rule that the petitioners should deposit
a security Of Rs.2,500 in cash within six weeks. According to the practice of this A Court prevailing
since 1959, this order was treated as a condition precedent for issuing rule nisi to the impleaded
respondents. The petitioners found it difficult to raise the amount and so on January 24, 1962, theyA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

moved this Court for modification of the said order as to security. This application was dismissed,
but the petitioners were given further time to deposit the said amount by March 26, 1962. This order
was passed on March 15, 1962. The petioners then tried to collect the requisite fund, but failed in
their efforts and that led to the said petition filed on March 24, 1962 by the said petitioners. The
petitioners contended that the impugned rule, in so far as it related to the giving of security, was
ultra vires, because it contravened the fundamental right guaranteed to the petitioners under Article
32 of the Constitution. There were two orders, namely, one for security of costs and another for the
dismissal of the previous application under Article 32 of the Constitution.
This Court by majority held that Rule 12 of order XXXV of the Supreme Court Rules was invalid in
so far as it related to the furnishing of security. The right to move the Supreme Court, it was
emphasised, under Article 32 was an absolute right and the content of this right could not be
circumscribed or impaired on any ground and an order for furnishing security for the respondent's
costs retarded the assertion or vindication of the fundamental right under Article 32 and
contravened the said right. The fact that the rule was discretionary did not alter the position.
Though Article 142(1) empowers the Supreme Court to pass any order to do complete justice
between the parties, the Court cannot make an order inconsistent with the fundamental rights
guaranteed by Part III of the Constitution. No question of inconsistency between Article 142(1) and
Article 32 arose. Gajendragadkar, J. speaking for the majority of the Judges of this Court said that
Article F 142(1) did not confer any power on this Court to contravene The provisions of Article 32 of
the Constitution. Nor did Article 145 confer power upon this Court to make rules, empowering it to
contravene the provisions of the fundamental right. At page 899 of the Reports, Gajendragadkar, J.
reiterated that the powers of this Court are no doubt very wide and they are intended and "will
always be exercised in the interests of justice." But that is not to say that an order can be made by
this Court which is inconsistent with the fundamental rights guaranteed by Part III of the
Constitution. It was emphasised that an order which this Court could make in order to do complete
justice between the parties, must not only be consistent with the fundamental rights guaranteed by
the Constitution, but it cannot even be inconsistent with the substantive provisions of the relevant
statutory laws (Emphasis A supplied). The Court therefore, held that it was not possible to hold that
Article 142(1) conferred upon this Court powers which could contravene the provisions of Article 32.
It follows, therefore, that the directions given by this Court on 16th February, 1984, on the ground of
expeditious trial by transferring Special Case No. 24 of 1982 and Special Case No. 3 of 1983 pending
in the Court of Special Judge, Greater Bombay, Shri S.B. Sule, to the High Court of Bombay with a
request to the learned Chief Justice to assign these two cases to a sitting Judge of the High Court
was contrary to the relevant statutory provision, namely, section 7(2) of the Criminal law
Amendment Act, 1952 and as such violative of Article 21 of the Constitution. Furthermore, it violates
Article 14 of the Constitution as being made applicable to a very special case among The special
cases, without any guideline as to which cases required speedier justice. If that was so as in Prem
Chand Garg's case, that was a mistake of so great a magnitude that it deprives a man by being
treated differently of his fundamental right for defending himself in a criminal trial in accordance
with law. If that was so then when the attention of the Court is drawn the Court has always the
power and the obligation to correct it ex debito justitiae and treat the second application by its
inherent power as a power of review to correct the original mistake. No suitor should suffer for the
wrong of the Court. This Court in Prem Chand Garg's case struck down not only the administrativeA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

order enjoined by Rule 12 for deposit of security in a petition under Article 32 of the Constitution
but also struck down the judicial order passed by the Court for non- deposit of such security in the
subsequent stage of the same proceeding when attention of the Court to the infirmity of the rule was
drawn. It may be mentioned that Shah, J. was of the opinion that rule 12 was not violative. For the
present controversy it is not necessary to deal with this aspect of the matter.
The power of the Court to correct an error subsequently has been reiterated by a decision of a bench
of nine Judges of this Court in Naresh Shridhar Mirajkar and others v. State of Maharashtra and
another, [1966] 3 S.C.R. 744. The facts were different and not quite relevant for our present
purposes but in order to appreciate the contentions urged, it will be appropriate to refer to certain
portions of the same. There was a suit for defamation against the editor of a weekly newspaper,
which was filed in the original side of the High Court. One of the witnesses prayed that the Court
may order that publicity should not be given to his evidence m the press as his business would be
affected. After hearing arguments, the trial Judge passed an oral order prohibiting the publication of
the evidence of the witness. A reporter of the weekly along with other journalists moved this Court
under Article 32 of the Constitution challenging the validity of the order. It was contended that: (1)
the High Court did not have inherent power to pass the order; (2) the impugned order violated the
fundamental rights of the petitioners under Article 19(1)(a); and (3) the order was amenable to the
writ jurisdiction of this Court under Article 32 of the constitution It was held by Gajendragadkar,
C.J. for himself and five other learned Judges that the order was within the inherent power of the
High Court. Sarkar, J. was of the view that the High Court had power to prevent publication of
proceedings and it was a facet of the power to hold a trial in camera and stems from it. Shah, J. was,
however, of the view that the Code of Civil Procedure contained no express provision authorising the
Court to hold its proceedings in camera, but if excessive publicity itself operates as an instrument of
injustice, the Court has inherent jurisdiction to pass an order excluding the public when the nature
of the case necessitates such a course to be adopted. Hidayatullah, J. was, however, of the view that
a Court which was holding a public trial from which the public was not excluded, could not suppress
the publication of the deposition of a witness, heard not in camera but in open Court, on the request
of the witness that his business would suffer. Sarker, J. further reiterated that if a judicial tribunal
makes an order which it has jurisdiction to make by applying a law which is valid in all respects, that
order cannot offend a fundamental right. An order which is within the jurisdiction of the tribunal
which made it, if the tribunal had jurisdiction to decide the matters that were litigated before it and
if the law which it applied in making the order was a valid law, could not be interfered with. It was
reiterated that the tribunal having this jurisdiction does not act without jurisdiction if it makes an
error in the application of the law.
Hidayatullah, J. Observed at page 790 of the report that in Prem Chand Garg's case the rule
required the furnishing of security in petition under Article 32 and it was held to abridge the
fundamental rights. But it was said that the rule was struck down and not the judicial decision which
was only revised. That may be so. But a judicial decision based on such a rule is not any better and
offends the fundamental rights just the same and not less so because it happens to be a judicial
order. If there be no appropriate remedy to get such an order removed because the Court has no
superior, it does not mean that the order is made good. When judged under the Constitution it is
still a void order although it may bind parties unless set aside. Hidayatullah, J. reiterated thatA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

procedural safeguards are as important as other safeguards. Hidayatullah, J. reiterated that the
order committed a breach of the fundamental right of freedom of speech and expression. We are,
therefore, of the opinion that the appropriate order would be to recall the directions contained in the
order dated 16th February, 1984.
In considering the question whether in a subsequent proceeding we can go to the validity or
otherwise of a previous decision on a question of law inter-parties, it may be instructive to refer to
the decision of this Court in Smt. Ujjam Bai v. State of Uttar Pradesh, [1963] 1 S.C.R.
778. There, the petitioner was a partner in a firm which carried on the business of manufacture and
sale of hand-made bidis. On December 14, 1957, the State Government issued a notification under
section 4(1)(b) of the U.P. Sales Tax Act, 1948. By a subsequent notification dated 25th November,
1958, hand-made and machine-made bidis were unconditionally exempted from payment of sales
tax. The Sales Tax officer had sent a notice to the firm for the assessment of tax on sale of bidis
during the assessment period 1st of April, 1958 to June 30, 1958. The firm claimed that the
notification dated 14th December, 1957 had exempted bidis from payment of sales tax and that,
therefore, it was not liable to pay sales tax on the sale of bidis. This position was not accepted by the
Sales Tax officer who passed certain orders. The firm appealed under section 9 of the Act to the
Judge (Appeals) Sales Tax, but that was dismissed. The firm moved the High Court under Article
226 of the Constitution. The High Court took the view that the firm had another remedy under the
Act and the Sales Tax officer had not committed any apparent error in interpreting the notification
of December 14, 1957. The appeal against the order of the High Court on a certificate under Article
133(1)(a) of the Constitution was dismissed by this Court for non-prosecution and the firm filed an
application for a restoration of the appeal and condonation of delay. During the pendency of that
appeal another petition was filed under Article 32 of the Constitution for the enforcement of the
fundamental right under Articles 19(1)(g) and 31 of the Constitution. Before the Constitution Bench
which heard the matter a preliminary objection was raised against the maintainability of the petition
and the correctness of the decision of this Court in Kailash Nath v. State of U.P., A.I.R. 1957 S.C. 790
relied upon by the petitioner was challenged. The learned Judges referred the case to a larger Bench.
It was held by this Court by a majority of five learned Judges that the answer to the questions must
be in the negative. The case of Kailash Nath was not correctly decided and the decision was not
sustainable on the authorities on which it was based. Das, J. speaking for himself observed that the
right to move this Court by appropriate proceedings for the enforcement of fundamental rights
conferred by Part III of the Constitution was itself a guaranteed fundamental right and this Court
was not trammelled by procedural technicalities in making an order or issuing a writ for the
enforcement of such rights. The question, however, was whether, a quasi-judicial authority which
made an order in the undoubted exercise of its jurisdiction in pursuance of a provision of law which
was intra vires, an error of law or fact committed by that authority could not be impeached
otherwise than on appeal, unless the erroneous determination related to a matter on which the
jurisdiction of that body depended. It was held that a tribunal might lack jurisdiction if it was
improperly constituted. In such a case, the characteristic attribute of a judicial act or decision was
that it binds, whether right or wrong, and no question of the enforcement of a fundamental right
could arise on an application under Article 32. Subba Rao, J. was, however, unable to agree.A.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

Shri Jethmalani urged that the directions given on 16th February, 1984, were not per incuriam. We
are unable to accept this submission. It was manifest to the Bench that exclusive jurisdiction created
under section 7(1) of the 1952 Act read with section 6 of the said Act, when brought to the notice of
this Court, precluded the exercise of the power under section 407 of the Code. There was no
argument, no submission and no decision on this aspect at all. There was no prayer in the appeal
which was pending before this Court for such directions. Furthermore, in giving such directions, this
Court did not advert to or consider the effect of Anwar Ali Sarkar's case (supra) which was a binding
precedent. A mistake on the part of the Court shall not cause prejudice to any one. He further added
that the primary duty of every Court is to adjudicate the cases arising between the parties. According
to him, it is certainly open to a larger Bench to take a view different from that taken by the earlier
Bench, if it was manifestly erroneous and he urged that the trial of a corrupt Chief Minister before a
High Court, instead of a Judge designated by the State Government was not so injurious to public
interest that it should be overruled or set aside. He invited us to consider two questions: (1) does the
impugned order promote justice? and (2) is it technically valid? After considering these two
questions, we are clearly of the opinion that the answer to both these questions is in the negative. No
prejudice need be proved for enforcing the fundamental rights. Violation of a fundamental right
itself renders the impugned action void. So also the violation of the principles of natural justice
renders the act a nullity. Four valuable rights, it appears to us, of the appellant have been taken
away by the impugned directions;
(i) The right to be tried by a Special Judge in accordance with the procedure established by law and
enacted by Parliament.
(ii) The right of revision to the High Court under section 9 of the Criminal Law Amendment Act.
(iii)The right of first appeal to the High Court under the same section.
(iv) The. right to move the Supreme Court under Article 136 thereafter by way of a second appeal, if
necessary.
In this connection Shri Rao rightly submitted that it is no necessary to consider whether section 374
of the Criminal Procedure Code confers the right of appeal to this Court from the judgment of a
learned Judge of the High Court to whom the case had been assigned inasmuch as the transfer itself
was illegal. One has to consider that section 407 of the Criminal Procedure Code was subject to the
overriding mandate of section 7(1) of the 1952 Act, and hence, it does not permit the High Court to
withdraw a case for trial to itself from the Court of Special Judge. It was submitted by Shri Rao that
even in cases where a case is withdrawn by the High Court to itself from a criminal court other than
the Court of Special Judge, the High Court exercised transferred jurisdiction which is different from
original jurisdiction arising out of initiation of the proceedings in the High Court. In any event
section 374 of Criminal Procedure Code limits the right to appeals arising out of clause 24 of the
Letters Patent.
In aid of the submission that procedure for trial evolved in derogation of the right guaranteed under
Article 21 of the Constitution would be bad, reliance was placed on Attorney General of India v.A.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

Lachma Devi and others, [1985] 2 Scale 144. In aid of the submission on the question of validity our
attention was drawn to 'Jurisdiction and Illegality' by Amnon Rubinstein (1965 Edn.). The
Parliament did not grant to the Court the jurisdiction to transfer a case to the High Court of
Bombay. However, as the superior Court is deemed to have a general jurisdiction, the law presumes
that the Court acted within jurisdiction. In the instant case that presumption cannot be taken, firstly
because the question of jurisdiction was not agitated before the Court, secondly these directions
were given per incuriem as mentioned hereinbefore and thirdly the superior Court alone can set
aside an error in its directions when attention is drawn to that error. This view is warranted only
because of peculiar facts and circumstances of the present case. Here the trial of a citizen in a
Special Court under special jurisdiction is involved, hence, the liberty of the subject is involved. In
this connection, it is instructive to refer to page 126 of Rubinstein's aforesaid book. It has to be
borne in mind that as in Kuchenmeister v. Home office, [1958] 1 Q.B. 496 here form becomes
substance. No doubt, that being so it must be by decisions and authorities, it appears to us patently
clear that the directions given by this Court on 16th February, 1984 were clearly unwarranted by
constitutional provisions and in derogation of the law enacted by the Parliament. See the
observations of Attorney General v. Herman James Sillem, [1864] 10 H.L.C. 703, where it was
reiterated that the creation of a right to an appeal is an act which requires legislative authority,
neither an inferior Court nor the superior Court or both combined can create such a right, it being
one of limitation and extension of jurisdiction. See also the observations of Isaacs v. Roberston,
[1984] 3 A.E.R. 140 where it was reiterated by Privy Council that if an order is regular it can be set
aside by an appellate Court; if the order is irregular it can be set aside by the Court that made it on
the application being made to that Court either under the rules of that Court dealing expressly with
setting aside orders for irregularity or ex debito justitiae if the circumstances warranted, namely,
violation of the rules of natural justice or fundamental rights. In Ledgard v. Bull, 13 I.A. 134, it was
held that under the old Civil Procedure Code under section 25 the superior Court could not make an
order of transfer of a case unless the Court from which the transfer was souht to be made, had
jurisdiction to try. In the facts of the instant case, the criminal revision application which was
pending before the High Court even if it was deemed to be transferred to this Court under Article
139A of the Constitution it would not have vested this Court with power larger than what is
contained in section 407 of Criminal Procedure Code. Under section 407 of the Criminal Procedure
Code read with the Criminal law Amendment Act, the High Court could not transfer to itself
proceedings under sections 6 and 7 of the said Act. This Court by transferring the proceedings to
itself, could not have acquired larger jurisdiction. The fact that the objection was not raised before
this Court giving directions on 16th February, 1984 cannot amount to any waiver. In Meenakshi
Naidoo v. Subramaniya Sastri, 14 I.A. 160 it was held that if there was inherent incompetence in a
High Court to deal with all questions before it then consent could not confer on the High Court any
jurisdiction which it never possessed.
We are clearly of the opinion that the right of the appellant under Article 14 regarding equality
before the law and equal protection of law in this case has been violated. The appellant has also a
right not to be singled out for special treatment by a Special Court created for him alone. This right
is implicit in the right to equality. See Anwar Ali Sarkar's case (supra).A.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

Here the appellant has a further right under Article 21 of the Constitution-a right to trial by a Special
Judge under section 7(1) of the 1952 Act which is the procedure established by law made by the
Parliament, and a further right to move the High Court by way of, revision or first appeal under
section 9 of the said Act. He has also a right not to suffer any order passed behind his back by a
Court in violation of the basic principles of natural justice. Directions having been given in this case
as we have seen without hearing the appellant though it appears from the circumstances that the
order was passed in the presence of the counsel for the appellant, these were bad.
In Nawabkhan Abbaskhan v. The State of Gujarat, [1974]3 S.C.R. 427, it was held that an order
passed without hearing a party which affects his fundamental rights, is void and as soon as the order
is declared void by a Court, the decision operates from its nativity. It is proper for this Court to act
ex debito justitiae, to act in favour of the fundamental rights of the appellant.
In so far as Mirajkar's case (supra) which is a decision of a Bench of 9 Judges and to the extent it
affirms Prem Chand Garg's case (supra), the Court has power to review either under section 137 or
suo motu the directions given by this Court. See in this connection P.S.R. Sadhananatham v.
Arunachalam, [1980] 2 SCR 873 and Suk Das v. Union of Territory of Arunachal Pradesh, [1986] 2
S.C.C.
401. See also the observations in Asrumati Debi v. Kumar Rupendra Deb Raikot and others, [1953]
S.C.R. 1159, Satyadhyan Ghosal and others v. Smt. Deorajin Debi and another, [1960] 3 S.C.R. 590,
Sukhrani (dead) by L.Ls. and others v. Hari Shanker and others, [1979] 3 S.C.R. 671 and Bejoy Gopal
Mukherji v. Pratul Chandra Ghose, [1953] S.C.R.
930. We are further of the view that in the earlier judgment the points for setting aside the decision,
did not include the question of withdrawal of the case from the Court of Special Judge to Supreme
Court and transfer it to the High Court. Unless a plea in question is taken it cannot operate as res
judicata. See Shivshankar Prasad Shah and others v. Baikunth Nath Singh and others, [1969] 1
S.C.C. 718, Bikan Mahuri and others v. Mst. Bibi Walian and others, A.I.R. 1939 Patna 633. See also
S. L. kapoor v. Jagmohan and others, [1981] 1 S.C.R. 746 on the question of violation of the
principles of natural justice. Also see Maneka Gandhi v. Union of India, [1978] 2 S.C.R. 621 at pages
674-68 1. Though what is mentioned hereinbefore in the Bengal Immunity Co. Ltd. v. The State of
Bihar and others (supra), the Court was not concerned with the earlier decision between the same
parties. At page 623 it was reiterated that the Court was not bound to follow a decision of its own if it
was satisfied that the decision was given per incuriam or the attention of the Court was not drawn. It
is also well settled that an elementary rule of justice is that no party should suffer by mistake of the
Court. See Sastri Yagnapurushadji and others v. Muldas Bhudardas Vaishya and another, [1966] 3
S.C.R. 242, Jang Singh v. Brijlal, l 1964] 2 S.C.R. 145, Bhajahari Mondal v. The State of West Bengal,
[1959] S.C.R. 1276 at 1284-1286 and Asgarali N. Singaporawalla v. The State of Bombay, [1957]
S.C.R. 678 at
692. Shri Rao further submitted that we should not only ignore the directions or set aside the
directions contained in the order dated 16th February, 1984, but also direct that the appellant
should not suffer any further trial. It was urged that the appellant has been deprived of hisA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

fundamental right guaranteed under Articles 14 and 21 as a result of the directions given by this
Court. Our attention was drawn to the observations of this Court in Suk Das's case (supra) for this
purpose. He further addressed us to the fact that six and half years have elapsed since the first
complaint was lodged against the appellant and during this long period the appellant has suffered a
great deal. We are further invited to go into the allegations and to held that there was nothing which
could induce us to prolong the agony of the appellant. We are, however, not inclined to go into this
question.
The right of appeal under section 374 is limited to Clause 24 of Letters Patent. It was further
submitted that the expression 'Extraordinary original criminal jurisdiction' under section 374 has to
be understood having regard to the language used in the Code and other relevant statutory
provisions and not with reference to decisions wherein Courts described jurisdiction acquired by
transfer as extraordinary original jurisdiction. In that view the decisions referred to by Shri
Jethmalani being Kavasji Pestonji Dalal v. Rustomji Sorabji jamadar & Anr., AIR 1949 Bom. 42,
Sunil Chandra Roy & Anr. v. The State, AIR 1954 Cal. 305, Sasadhar Acharjya & Anr. v. Sir Charles
Tegart & Ors., [1935] Cal. Weekly Notes 1088, Peoples' Insurance Co. Ltd. v. Sardul Singh
Caveeshgar & Ors., AIR 1961 Punj. 87 and P.P. Front, New Delhi v. K. K. Birla, [1984] Cr. L.J. 545
are not relevant.
It appears to us that there is good deal of force in the argument that-section 411A of the old Code
which corresponds to section 374 of the new Code contained the expression 'original jurisdiction'.
The new Code abolished the original jurisdiction of High Courts but retained the extraordinary
original criminal jurisdiction conferred by clause 24 of the Letters Patent which some of the High
Courts had.
The right of appeal is, therefore, confined only to cases decided by the High Court in its Letter
Patent jurisdiction which in terms is `extraordinary original criminal jurisdiction'.
By the time the new Code of Criminal Procedure 1973 was framed, Article 21 had not been
interpreted so as to include one right of appeal both on facts and law.
Shri Ram Jethmalani made elaborate submissions before us regarding the purpose of the Criminal
Law Amendment Act and the constitution of the Special Court. In our opinion, these submissions
have no relevance and do not authorise this Court to confer a special jurisdiction on a High Court
not warranted by the statute. The observations of this Court in Re The Special Courts Bill, 1978,
[1979] 2 SCR 476 are not relevant for this purpose. Similarly, the observations on right of appeal in
V. C. Shukla v. Delhi Administration, [1980] 3 SCR 500, Shri Jethmalani brought to our notice
certain facts to say that the powers given in the Criminal Law Amendment Act were sought to be
misused by the State Government under the influence of the appellant. In our opinion, these
submissions are not relevant for the present purpose. Mr. Jethmalani submitted that the argument
that in so far as section 407 purports to authorise such a transfer it stands repealed by section 7(1) of
the Criminal Law Amendment Act is wrong. He said it can be done in its extraordinary criminal
jurisdiction. We are unable to accept this submission. We are also unable to accept the submission
that the order of transfer was made with full knowledge of section 7(1) of the Criminal LawA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

Amendment Act and the so- called exclusive jurisdiction was taken away from Special Judges and
the directions were not given per incuriam. That is not right. He drew our attention to the principles
of interpretation of statutes and drew our attention to the purpose of section 7(1) of the Act. He
submitted that when the Amending Act changes the law, the change must be confined to the
mischief present and intended to be dealt with. He drew us to the Tek Chand Committee Report and
submitted that he did not wish that an occasional case withdrawn and tried in a High Court was
because of delay in disposal of corruption cases. He further submitted that interference with existing
jurisdiction and powers of superior Courts can only be by express and clear language. It cannot be
brought about by a side wind.
Thirdly, the Act of 1952 and the Code have to be read and construed together, he urged. The Court is
never anxious to discover a repugnancy and infer apro tanto repeal. Resort to the non obstante
clause is permissible only when it is impossible to harmonise the two provisions.
Shri Jethmalani highlighted before us that it was for the first time a Chief Minister had been found
guilty of receiving quid pro quo for orders of allotment of cement to various builders by a Single
Judge of the High Court confirmed by a Division Bench of the High Court. He also urged before us
that it was for the first time such a Chief Minister did not have the courage to prosecute his special
leave petition before this Court against the findings of three Judges of the High Court. Shri
Jethmalani also urged that it was for the first time this Court found that a case instituted in 1982
made no progress till 1984. Shri Jethmalani also sought to contend that section 7(1) of the 1952 Act
states "shall be triable by Special Judges only", but does not say that under no circumstances the
case will be transferred to be tried by the High Court even in its Extraordinary original Criminal
Jurisdiction. He submitted that section 407(1)(iv) is very much in the statute and and it is not
repealed in respect of the cases pending before the Special Judge. There is no question of repealing
section 407(1)(iv). Section 407 deals with the power of the High Court to transfer cases and appeals.
Section 7 is entirely different and one has to understand the scheme of the Act of 1952, he urged. It
was an Act which provided for a more speedy trial of certain offences. For this it gave power to
appoint Special Judges and stipulated for appointment of Special Judges under the Act. Section 7
states that notwithstanding anything contained in the Code, the offences mentioned in sub-section
(1) of section 6 shall be triable by Special Judges only. By express terms therefore, it takes away the
right to transfer cases contained in the Code to any other Court which is not a Special Court. Shri
Jethmalani sought to urge that the Constitution Bench had considered this position. That is not so.
He submitted that the directions of this Court on 16th February, 1984 were not given per incuriam
or void for any reason. He referred us to Dias on jurisprudence, 5th Edition, page 128 and relied on
the decision of Milianges v. George Frank (Textiles) Ltd., [1975] 3 All E.R. 801 at 821. He submitted
that the per incuriam rule A does not apply where the previous authority is alluded to. It is true that
previous statute is referred to in the other judgment delivered on the same date in connection with
different contentions. Section 7(1) was not referred to in respect of the directions given on 16th
February, 1984 in the case of R.S. Nayak v. A.R. Antulay (supra). Therefore, as mentioned
hereinbefore the observations indubitably were per incuriam. In this case in view of the specific
language used in section 7, it is not necessary to consider the other submissions of Shri Jethmalani,
whether the procedure for trial by Special Judges under the Code has stood repealed or not. The
concept of repeal may have no application in this case. It is clear that words should normally beA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

given their ordinary meaning bearing in mind the context. It is only where the literal meaning is not
clear that one resorts to the golden rule of interpretation or the mischief rule of interpretation. This
is well illustrated from the observations of Tindal, C.J. in Sussex Peerage Claim, [18441 11 Cl & Fin
85 at 143. He observed:
"The only rule for the construction of Acts of Parliament is that they should be
construed according to the intent of the Parliament which passed the Act. If the
words of the statute are in themselves precise and unambiguous, then no more can be
necessary than to expound those words in that natural and ordinary sense. The words
themselves alone do, in such case, best declare the intention of the lawgiver. But if
any doubt arises from the terms employed by the legislature, it has always been held
a safe means of collecting the intention, to call in aid the ground and cause of making
the statute, and to have recourse to the preamble, which, according to Chief Justice
Pyer, Stewell v. Lord Zouch, [1569] 1 Plowd 353 at 369 is a key to open the minds of
the makers of the Act, and the mischiefs which they intend to redress".
This passage states the commonly accepted view concerning the relationship between the literal and
mischief rules of interpretation of statutes. Here there is no question as to what was the previous law
and what was intended to be placed or replaced as observed by Lord Wilberforce in 274 House of
Lords Debate, Col. 1294 on 16th November, 1966, see Cross; Statutory Interpretation, second
edition, page 36. He observed that the interpretation of legislation is just a part of the process of
being a good lawyer; a multi-faceted thing, calling for many varied talents; not a subject which can
be confined in rules.
When the words are clear nothing remains to be seen. If words are as such ambiguous or doubtful
other aids come in. In this context, the submission of controversy was whether the Code repealed
the Act of 1952 or whether it was repugnant or not is futile exercise to undertake. Shri Jethmalani
distinguished the decision in Chadha's case, which has already been discussed. It is not necessary to
discuss the controversy whether the Chartered High Courts contained the Extraordinary original
Criminal Jurisdiction by the Letters Patent.
Article 134(1)(b) does not recognise in every High Court power to withdraw for trial cases from any
Court subordinate to its authority. At least this Article cannot be construed to mean where power to
withdraw is restricted, it can be widened by virtue of Article 134(1)(b) of the Constitution. Section
374 of the Code undoubtedly gives a right of appeal. Where by a specific clause of a specific statute
the power is given for trial by the Special Judge only and transfer can be from one such Judge to
another Special Judge, there is no warrant to suggest that the High Court has power to transfer such
a case from a Judge under section 6 of the Act of 1952 to itself. It is not a case of exclusion of the
superior Courts. So the submissions made on this aspect by Shri Jethmalani are not relevant.
Dealing with the submission that the order of the Constitution Bench was void or non-est and it
violated the principles of natural justice, it was submitted by Shri Jethmalani that it was factually
incorrect. Inspite of the submissions the appellant did not make any submission as to directions for
transfer as asked for by Shri Tarkunde. It was submitted that the case should be transferred to theA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

High Court. The Court merely observed there that they had given ample direction. No question of
submission arose after the judgment was delivered. In any case, if this was bad the fact that no
objection had been raised would not make it good. No question of technical rules or res judicata
apply, Shri Jethmalani submitted that it would amount to an abuse of the process of the Court. He
referred us to Re Tarling, [1979] 1 All E.R. 981 at 987; Ali v. Secretary of State for the Home
Department, [1984] 1 All E.R. 1009 at 1014 and Seervai's Constitutional Law, Vol. 1, pages 260 to
265. We are of the opinion that these submissions are not relevant. There is no abuse of the process
of the Court. Shri Jethmalani submitted that there was no prejudice to the accused. There was
prejudice to the accused in being singled out as a special class of accused for a special dispensation
without room for any appeal as of right and without power of the revision to the High Court. There .
prejudice in that. Reliance placed on the decision of this Court in Ramesh Chandra Arora v. The
State, [1960] 1 S.C.R. 924 at 927 was not proper in the facts of this case.
If a discrimination is brought about by judicial perception and not by executive whim, if it is
unauthorised by law, it will be in derogation of the right of the appellant as the special procedure in
Anwar Ali Sarkar's case (supra) curtailed the rights and privileges of the accused. Similarly, in this
case by judicial direction the rights and privileges of the accused have been curtailed without any
justification in law. Reliance was placed on the observations of the seven Judges Bench in Re:
Special Courts Bill, 1978 (supra). Shri Jethmalani relied on the said observations therein and
emphasised that purity in public life is a desired goal at all times and in all situations and ordinary
Criminal Courts due to congestion of work cannot reasonably be expected to bring the prosecutions
to speedy termination. He further submitted that it is imperative that persons holding high public or
political office must be speedily tried in the interests of justice. Longer these trials last, justice will
tarry, assuming the charges to be justified, greater will be the impediments in fostering democracy,
which is not a plant of easy growth. All this is true but the trial even of person holding public office
though to be made speedily must be done in accordance with the procedure established by law. The
provisions of section 6 read with section 7 of the Act of 1952 in the facts and circumstances of this
case is the procedure established by law; any deviation even by a judicial direction will be negation
of the rule of law.
Our attention was drawn to Article 145(e) and it was submitted that review can be made only where
power is expressly conferred and the review is subject to the rules made under Article 145(e) by the
Supreme Court. The principle of finality on which the Article proceeds applies to both judgments
and orders made by the Supreme Court. But directions given per incuriam and in violation of certain
constitutional limitations and in derogation of the principles of natural justice can always be
remedied by the court ex debite justitiae. Shri Jethmalani's submission was that ex debite justitiae,
these directions could not be recalled. We are unable to agree with this submission.
The Privy Council in Isaacs v. Robertson, [1984] 3 A.E.R. 140 held that orders made by a Court of
unlimited jurisdiction in the course of contentious litigation are either regular or irregular. If an
order is regular it can only be set aside by an appellate Court; if it is irregular it can be set aside by
the Court that made it on application being made to that Court either under rules of Court dealing
expressly with setting aside orders for irregularity or ex debite justitiae if the circumstances
warranted, namely, where there was a breach of the rules of natural justice etc. Shri JethmalaniA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

urged before us that Lord Diplock had in express terms rejected the argument that any orders of a
superior Court of unlimited jurisdiction can over be void in the sense that they can be ignored with
impunity. We are not concerned with that. Lord Diplock delivered the judgment. Another Judge
who sat in the Privy Council with him was Lord Keith of Kinkel. Both these Law Lords were parties
to the House of Lords judgment in Re Racal Communications Ltd . case [1980] 2 A.E.R. 634 and
their Lordships did not extend this principle any further. Shri Jethmalani submitted that there was
no question of reviewing an order passed on the construction of law. Lord Scarman refused to
extend the Anisminic principle to superior Courts by the felicitous statement that this amounted to
comparison of incomparables. We are not concerned with this controversy. We are not comparing
incomparables. We are correcting an irregularity committed by Court not on construction or
misconstruction of a statute but on non-perception of certain provisions and certain authorities
which would amount to derogation of the constitutional rights of the citizen.
The directions given by the order of 16th February, 1984 at page 557 were certainly without hearing
though in the presence of the parties. Again consequential upon directions these were challenged
ultimately in this Court and finally this Court reserved the right to challenge these by an appropriate
application.
The directions were in deprival of Constitutional rights and contrary to the express provisions of the
Act of 1952. The directions were given in violation of the principles of natural justice. The directions
were without precedent in the background of the Act of 1952. The directions definitely deprived the
appellant of certain rights of appeal and revision and his rights under the Constitution.
We do not labour ourselves on the question of discretion to disobey a judicial order on the ground of
invalid judicial order. See discretion to Disobey by Mertimer R. Kadish and Sanford H. Kadish pages
111 and 112. These directions were void because the power was not there for this Court to transfer a
proceeding under the Act of 1952 from one Special Judge to the High Court. This is not a case of
collateral attack on judicial proceeding; it is a case where the Court having no Court superior to it
rectifies its own order. We recognise that the distinction between an error which entails absence of
jurisdiction and an error made within the jurisdiction is very fine. So fine indeed that it is rapidly
being eroded as observed by Lord Wilberforce in Anisminic Ltd. v. Foreign Compensation
Commissioner, [1959] 1 All E.R. 208 at 244. Having regard to the enormity of the consequences of
the error to the appellant and by reason of the fact that the directions were given suo motu, we do
not find there is anything in the observations of Ittavira Mathai v. Varkey Varkey and another,
[19641 1 S.C.R. 495 which detract the power of the Court to review its judgment ex debite justitiae in
case injustice has been caused. No court, however, high has jurisdiction to give an order
unwarranted by the Constitution and, therefore, the principles of Bhatia Co- operative Housing
Society Ltd. v. D. C. Patel, [1953] S.C.R. 185 at 190 would not apply.
ln giving the directions this Court infringed the Constitutional safeguards granted to a citizen or to
an accused and injustice results therefrom. It is just and proper for the Court to rectify and recall
that in justice, in the peculiar facts and circumstances of this case This case has caused us
considerable anxiety. The appellant accused has held an important position in this country, being
the Chief Minister of a premier State of the country. He has been charged with serious criminalA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

offences. His trial in accordance with law and the procedure established by law would have to be in
accordance with the 1952 Act. That could not possibly be done because of the directions of this Court
dated 16th February, 1984, as indicated above. It has not yet been found whether the appellant is
guilty or innocent. It is unfortunate, unfortunate for the people of the State, unfortunate for the
country as a whole, unfortunate for the future working of democracy in this country which, though is
not a plant of an easy growth yet is with deep root in the Indian polity that delay has occurred due to
procedural wrangles. The appellant may be guilty of grave offences alleged against him or he may be
completely or if not completely to a large extent, innocent. Values in public life and perspective of
these values in public life, have undergone serious changes and erosion during the last few decades.
What was unheard of before is common place today. A new value orientation is being undergone in
our life and in our culture. We are at the threshold of the cross-roads of values. It is, for the
sovereign people of the country to settle those conflicts yet the Courts have vital roles to play in such
matters. With the avowed object of speedier trial the case of the appellant had been transferred to
the High Court but on grounds of expediency of trial he cannot be subjected to a procedure
unwarranted by law, and contrary to the constitutional provisions. The appellant may or may not be
an ideal politician. It is a fact, however, that the allegations have been brought against him by a
person belonging to a political party opposed to his but that is not the decisive factor. If the
appellant Shri Abdul Rehman Antulay has infringed law, he must be dealt with in accordance with
the law. We proclaim and pronounce that no man is above the law, but at the same time reiterate
and declare that no man can be denied his rights under the Constitution and the laws. He has a right
to be dealt with in accordance with the law and not in derogation of it. This Court? in its anxiety to
facilitate the parties to have a speedy trial gave directions on 16th February, 1984 as mentioned
hereinbefore without conscious awareness of the exclusive jurisdiction of the Special Courts under
the 1952 Act and that being the only procedure established by law, there can be no deviation from
the terms of Article 21 of the Constitution of India. That is the only procedure under which it should
have been guided. By reason of giving the directions on 16th February, 1984 this Court had also
unintentionally caused the appellant the denial of rights under Article 14 of the Constitution by
denying him the equal protection of law by being singled out for a special procedure not provided for
by law. When these factors are brought to the notice of this Court, even if there are any technicalities
this Court should not feel shackled and decline to rectify that injustice or other vise the injustice
noticed will remain forever a blot on justice. It has been said long time ago that "Actus Curiae
Neminem Gravabit"-an act of the Court shall prejudice no man. This maxim is founded upon justice
and good sense and affords a safe and certain guide for the administration of the law.
Lord Cairns in Alexander Rodger v. The Comptoir D'escompte De Paris, (Law Reports Vol. III
1869-71 page 465 at page 475) observed thus:
"Now, their Lordships are of opinion, that one of the first and highest duties of all
Courts is to take care that the act of the Court does no injury to any of the Suitors,
and when the expression 'the act of the Court' is used, it does not mean merely the act
of the Primary Court, or of any intermediate Court of appeal, but the act of the Court
as a whole, from the lowest Court which entertains jurisdiction over the matter up to
the highest Court which finally disposes of the case. It is the duty of the aggregate of
those Tribunals, if I may use the expression, to take care that no act of the Court inA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

the course of the whole of the proceedings does an injury to the suitors in the Court."
This passage was quoted in the Gujarat High Court by D.A. Desai, J. speaking for the Gujarat High
Court in Vrajlal v. Jadavji (supra) as mentioned before. It appears that in giving directions on 16th
February, 1984, this Court acted per incuriam inasmuch it did not bear in mind consciously the
consequences and the provisions of sections 6 and 7 of the 1952 Act and the binding nature of the
larger Bench decision in Anwar Ali Sarkar's case (supra) which was not adverted to by this Court.
The basic fundamentals of the administration of justice are simple. No man should suffer because of
the mistake of the Court. No man should suffer a wrong by technical procedure of irregularities.
Rules or procedures are the hand-maids of justice and not the mistress of the justice. Ex debite
justitiae, we must do justice to him. If a man has been wronged so long as it lies within the human
machinery of administration of justice that wrong must be remedied. This is a peculiar fact of this
case which requires emphasis.
Shri Rao, learned counsel for the appellant has vehemently canvassed before us that the appellant
has suffered a great wrong for over six and a half years. He has undergone trials and proceedings
because of the mistakes of the Court. Shri Rao submitted that the appellant should be made not to
suffer more. Counsel urged that political battles must be fought in the political arena. Yet a charge of
infraction of law cannot remain uninvestigated against an erstwhile Chief Minister of a premier
State of the country.
Shri Rao has canvassed before us on the authority of Hussainara Khatoon v. Home Secretary, State
of Bihar, Patna, [1979] 3 S.C.R. 169 at 179-180; Kadra Pahadiyal (1) v. State of Bihar, A.I.R. 1981 S.C.
939; Kadra Pahadiya (II) v. State of Bihar, A.I.R. 1982 S.C. 1167 and Sheela Barse v. Union of India,
A.I.R. 1986 S.C. 1773. He has, however, very strongly relied upon the observations of this Court in
SukDas v. Union Territory of Arunachal Pradesh (supra). In that case the appellant a government
servant was tried and convicted to suffer imprisonment for two years for offences under Section 506
read with Section 34, I.P.C. He was not represented at the trial by any lawyer by reason of his
inability to afford legal representation. On appeal the High Court held that the trial was not vitiated
since no application for legal aid was made by him. On appeal this Court quashed the conviction and
considered the question whether the appellant would have to be tried in accordance with law after
providing legal assistance to him. This Court felt that in the interests of justice the appellant should
be reinstated in service without back wages and accordingly directed that no trial should take place.
Shri Rao submitted that we should in the facts of this case in the interests of justice direct that the
appellant should not be tried again. Shri Rao submitted to let the appellant go only on this long
delay and personal inconveniences suffered by the appellant, no more injury be caused to him. We
have considered the submission. Yet we must remind ourselves that purity of public life is one of the
cardinal principal which must be upheld as a matter of public policy. Allegations of legal infractions
and criminal infractions must be investigated in accordance with law and procedure established
under the Constitution. Even if he has been wronged, if he is allowed to be left in doubt that would
cause more serious damage to the appellant. Public confidence in public administration should not
be eroded any further. One wrong cannot be remedied by another wrong.A.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

ln the aforesaid view of the matter and having regard to the facts and circumstances of the case, we
are of the opinion that the legal wrong that has been caused to the appellant should be remedied. Let
that wrong be therefore remedied. Let right be done and in doing so let no more further injury be
caused to public purpose.
ln the aforesaid view of the matter the appeal is allowed; all proceedings in this matter subsequent
to the directions of this Court on 16th February, 1984 as indicated before are set aside and quashed.
The trial shail proceed in accordance with law, that is to say under the Act of 1952 as mentioned
hereinbefore.
RANGANATH MISRA, J: I have had the advantage of perusing the judgment proposed by my
learned Brother Mukharji, J. While I agree with the conclusion proposed by my esteemed Brother,
keeping the importance of the matter, particularly the consequences the decision may generate as
also the fact that I was a party to the two-Judge Bench decision of this Court reported in 1986 (2)
SCC 716 in view, I propose to express my opinion separately.
Abdul Rehman Antulay, the appellant, was the Chief Minister of the State of Maharashtra from 1980
till January 20, 1982, when he resigned his office but continued to be a member of the Maharashtra
Legislative Assembly. Ramdas Shrinivas Nayak, Respondent No. I herein, lodged a complaint in the
Court of Chief Metropolitan Magistrate, 28th Esplanade, Bombay, on September ll, 1981, against
Antulay alleging commission of several offences under the lndian Penal Code as also Section 5(2) of
the Prevention of Corruption Act, 1947 ('1947 Act' for short). The learned Magistrate was of the view
that prosecution under Sections 161 and 165 of the Penal Code and Section 5 of the 1947 Act
required sanction as a condition precedent and in its absence the complaint was not maintainable.
The Governor of Bombay later accorded sanction and the Respondent no. 1 filed a fresh complaint,
this time in the Court of the Special Judge of Bombay, alleging the commission of those offences
which had formed the subject- matter of the complaint before the Magistrate. On receiving
summons from the Court of the particular Special Judge, Antulay took the stand that the said
Special Judge had no jurisdiction to entertain the complaint in view of the provisions of Section 7 of
the Criminal Law Amendment Act, 1952 (hereinafter referred to as the 1952 Act) to take cognizance
and such cognizance could not be taken on a private complaint. These objections were overruled by
the Special judge by order dated October 20, 1982, and the case was set down for recording evidence
of the prosecution. The Criminal Revision Petition of the accused against the order of the Special
Judge was rejected by the Bombay High Court and it held that a private complaint was maintainable
and in view of the notification specifying a particular Special Judge for the offences in question there
was no basis for the objections. This Court granted special leave to the accused against the decision
of the High Court that a private complaint was maintainable. Criminal Appeal No. 347 of 1983 thus
came to be instituted. ln the meantime, objection raised before the Special Judge that without
sanction the accused who still continued to be a member of Legislative Assembly, could not be
prosecuted came to be accepted by the Special Judge. The complainant filed a criminal revision
application before the High Court questioning that order. This Court granted special leave against
the decision that sanction was necessary, whereupon Criminal Appeal No. 356 of 1983 was
registered and the pending criminal revision application before the High Court was transferred to
this Court. Both the criminal appeals and the transferred criminal revision were heard together by aA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

five-Judge Bench of this Court but the two appeals were disposed of by two separate judgments
delivered on February 16, 1984. The judgment in Criminal Appeal No. 347 of 1983 is reported in
(1984) 2 SCR 914. In the present appeal we are not very much concerned with that judgment. The
judgment of Criminal Appeal No. 356 of 1983 is reported in (1984) 2 SCR
495. As already noticed the main theme of the criminal appeal was as to whether a member of the
Legislative Assembly was a public servant for whose prosecution for the offences involved in the
complaint sanction was necessary as a condition precedent. This Court at page 557 of the Reports
came to hold:
"To sum up, the learned Special Judge was clearly in error in holding that M.L.A. is a
public servant within the meaning of the expression in Section 12(a) and further
erred in holding that a sanction of the Legislative Assembly of Maharashtra or
majority of the members was a condition precedent to taking cognizance of offences
committed by the accused. For the reasons herein stated both the conclusions are
wholly unsustainable and must be quashed and set aside."
Consequently this Court directed:
"This appeal accordingly succeeds and is allowed. The order and decision of the
learned Special Judge Shri R.B. Sule dated July 25, 1983 discharging the accused in
Special Case No. 24 of 1982 and Special Case No. 3/1983 is hereby set aside and the
trial shall proceed further from the stage where the accused was discharged."
This Court gave a further direction to the following effect:
"The accused was the Chief Minister of a premier State-the State of Maharashtra. By
a prosecution launched as early as on September 11, 1981, his character and integrity
came under a cloud. Nearly 2 1/2 years have rolled by and the case has not moved an
inch further. An expeditious trial is primarily in the interest of the accused and a
mandate of Article 21. Expeditious disposal of a criminal case is in the interest of
both, the prosecution and the accused. Therefore, Special Case No. 24 of 1982 and
Special Case No. 3/83 pending in the Court of Special Judge, Greater Bombay Shri
R.B. Sule are withdrawn and transferred to the High Court of Bombay with a request
to the learned Chief Justice to assign these two cases to a sitting Judge of the High
Court. On being so assigned, the learned Judge may proceed to expeditiously dispose
of the cases preferably by holding the trial from day to day."
Pursuant to this direction, the two cases came to be posted for trial before Khatri J. Of the Bombay
High Court and trial opened on April 9, 1984. The appellant challenged Khatri J.'s jurisdiction on
12th March, 1984 when the matter was first placed before him but by two separate orders dated 13th
March, 1984 and 16th March, 1984, the learned Judge rejected the objection by saying that he was
bound by this Court's direction of the 16th February, 1984. Antulay then moved A this Court by
filing an application under Article 32 of the Constitution. A two-Judge Bench consisting of DesaiA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

and A.N. Sen. JJ. by order dated 17th April, 1984 dismissed the applications by saying:
Sen, J .:
"There is no merit in this writ petition. The writ petition is accordingly dismissed.
In my view, the writ petition challenging the validity of the order and judgment
passed by this Court as nullity or otherwise incorrect cannot be entertained. I wish to
make it clear that the dismissal of this writ petition will not prejudice the right of the
petitioner to approach the Court with an appropriate review petition or to file any
other application which he may be entitled in law to file."
Desai, J.:
"I broadly agree with the conclusion recorded by my brother. The learned Judge in
deciding the SLP (Crl.) Nos. 1949-50 of 1984 has followed the decision of this Court.
The learned Judge was perfectly justified and indeed it was the duty of the learned
Judge to follow the decision of this Court which is binding on him. Special leave
petitions are dismissed. " (1984(3) SCR 482). 16 witnesses were examined by Khatri
J. by July 27, 1984. Khatri J. was relieved of trying the case on his request,
whereupon the learned Chief Justice nominated Mehta J. to continue the trial. 41
more witnesses were examined before him and at the stage when 57 witnesses in all
had been examined for the prosecution, the Trial Judge invited the parties to
consider the framing of charges. 43 draft charges were placed for his consideration
on behalf of the prosecution and the learned Trial Judge framed 21 charges and
recorded an order of discharge in respect of the remaining 22. At the instance of the
complainant, Respondent No. 1, the matter came before this Court in appeal on
special leave and a two-Judge Bench of which I happened to be one, by judgment
dated April 17, 1986, in Criminal Appeal No. 658 of 1985 [(1962) 2 SCC 716] set aside
the order of discharge in regard to the several offences excepting extortion and
directed the learned Trial Judge to frame charges for the same. This Court requested
the learned Chief Justice of the Bombay High Court to nominate another Judge to
take up the matter from the stage at which Mehta J. had made the order of discharge.
Shah J. came to be nominated by the learned Chief Justice to continue the trial. By
order dated July 24, 1986, Shah J. rejected the application of the accused for
proceeding against the alleged co-conspirators by holding that there had been a long
delay, most of the prosecution witnesses had already been examined and that if the
co-conspirators were then brought on record, a de novo trial would be necessitated.
The appellant challenged the order of Shah J. by filing a special leave petition before
this Court wherein he further alleged that the High Court had no jurisdiction to try
the case. A two-Judge Bench, of which Mukherji J., my learned brother, was a
member, granted special leave, whereupon this Criminal Appeal (No. 468 of 1986)
came to be registered. The Respondent No. 1 asked for revocation of special leave in
Criminal Miscellaneous Petition No. 4248 of 1986. While rejecting the saidA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

revocation application, by order dated October 29, 1986, the two-Judge Bench
formulated several questions that arose for consideration and referred the matter for
hearing by a Bench of seven Judges of the Court. That is how this seven-Judge Bench
has come to be constituted to hear the appeal.
It is the settled position in law that jurisdiction of courts comes solely from the law of
the land and cannot be exercised otherwise. So far as the position in this country is
concerned conferment of jurisdiction is possible either by the provisions of the
Constitution or by specific laws enacted by the Legislature. For instance, Article 129
confers all the powers of a court of record on the Supreme Court including the power
to punish for contempt of itself. Articles 131, 132, 133, 134, 135, 137, 138 and 139
confer different jurisdictions on the Supreme Court while Articles 225, 226, 227, 228
and 230 deal with conferment of jurisdiction on the High Courts. Instances of
conferment of jurisdiction by specific law are very common. The laws of procedure
both criminal and civil confer jurisdiction on different courts. Special jurisdiction is
conferred by special statute. It is thus clear that jurisdiction can be exercised only
when provided for either in the Constitution or in the laws made by the Legislature.
Jurisdiction is thus the authority or power of the court to deal with a matter and
make an order carrying binding force in the facts. In support of judicial opinion for
this view reference may be made to the permanent edition of 'Words and Phrases Vol.
23A' at page 164. It would be appropriate to refer to two small passages occurring at
pages 174 and 175 of the Volume. At page 174, referring to the decision in Carlile v.
National Oil & Development Co. it has been stated:
"Jurisdiction is the authority to hear and determine, and in order that it may exist the
following are essential: (1) A court created by law, organized and sitting; (2) authority
given it by law to hear and determine causes of the kind in question; (3) power given
it by law to render a judgment such as it assumes to render; (4) authority over the
parties to the case if the judgment is to bind them personally as a judgment in
personam, which is acquired over the plaintiff by his appearance and submission of
the matter to the court, and is acquired over the defendant by his voluntary
appearance, or by service of process on him; (5) authority over the thing adjudicated
upon its being located within the court s territory, and by actually seizing it if liable to
be carried away; (6) authority to decide the question involved, which is acquired by
the question being submitted to it by the parties for decision."
Article 139A of the Constitution authorises this Court to transfer cases from a High Court to itself or
from one High Court to another and is, therefore, not relevant for our purpose. Section 406 of the
Code empowers this Court to transfer cases and appeals by providing:
"(1) Whenever it is made to appear to the Supreme Court that an order under this
section is expedient for the ends of justice, it may direct that any particular case of
appeal be transferred from one High Court to another High Court or from a Criminal
Court subordinate to one High Court to another Criminal Court of equal or superiorA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

jurisdiction subordinate to another High Court.
(2) The Supreme Court may act under this section only on the application of the
Attorney-
General of India or of a party interested, and every such application shall be made by motion, which
shall, except when the applicant is the Attorney-General of India or the Advocate-General of the
State, be supported by affidavit or affirmation.
(3)...................".
The offences alleged to have been committed by the accused here are either punishable under the
Penal Code or under Act 2 of 1947, both Of which could have been tried in an appropriate court
under the Criminal Procedure Code; but Parliament by the Criminal Law Amendment Act 46 of
1952 (1952 Act for short) amended both the Penal Code as also the Criminal Procedure Code with a
view to providing for a more speedy trial of certain offences. The relevant sections of the 1952 Act
are sections 6, 7, 8, 9 and 10. For convenience, they are extracted below:
"6. Power to appoint special Judges (1) The State Government may, by notification in
the Official Gazette, appoint as many special Judges as may be necessary for such
area or areas as may be specified in the notification to try the following offences,
namely,
(a) an offence punishable under section 161, section 162, section 163, section 164,
section 165 or section 165A of the Indian Penal Code (45 of 1860) or section 5 of the
Prevention of Corruption Act, 1947 (2 of 1947);
(b) any conspiracy to commit or any attempt to commit or any abetment of any of the
offences specified in clause (a).
(2) A persorn shall not be qualified for appointment as a special Judge under this Act
unless he is, or has been, a Sessions Judge or an Additional Sessions Judge or an
assistant Sessions Judge under the Code of Criminal Procedure, 1898 (5 of 1898)."
"7. Class triable by Special Judges (1) Notwithstanding anything contained in the
Code of Criminal Procedure? 1898 (5 of 1898) or in any other law the offences
specified in sub-section (1) of section 6 shall be triable by Special Judges only;
(2) Every offence specified in sub-section
(l) of section 6 shall be tried by the Special Judge for the area within which it was
committed.A.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

Or where there are more Special Judges than one for such area. by such one of them as may be
specified in this behalf by the State Government.
(3) When trying any case, a Special Judge may also try any offence other than an offence specified in
section 6 A with which the accused may, under the Code of Criminal Procedure, 1898 (5 of 1898), be
charged at the same trial".
8. Procedure and powers of Special Judges (
1) A Special Judge may take cognizance of offences without the accused being committed to him for
trial, and in trying the accused persons, shall follow the procedure prescribed by the Code of
Criminal Procedure, 1898 (5 of 1898), for the trial of warrant cases by Magistrates.
(2) A special Judge, may, with a view to obtaining the evidence of any person supposed to have been
directly or indirectly concerned in, or privy to, an offence, tender a pardon to such person on
condition of his making a full and true disclosure of the whole circumstances within his knowledge
relating to the offence and to every other person concerned, whether as principal or abettor, in the
commission thereof; and any pardon so tendered shall, for the purposes of sections 339 and 339-A
of the Code of Criminal Procedure, 1898 (5 of 1898), be deemed to have been tendered under section
338 of that Code.
(3) Save as provided in sub-section ( 1 ) or sub-section (2), the provisions of the Code of Criminal
Procedure 1898 (5 of 1898), shall, so far as they are not inconsistent with this Act, apply to the
proceedings before a Special Judge; and for the purposes of the said provisions, the Court of the
Special Judge shall be deemed to be a Court of Session trying cases without a jury or without the aid
of assessors and the person conducting a prosecution before a Special Judge shall be deemed to be a
public prosecutor.
(3-A) In particular, and without prejudice to the generality of the provisions contained in sub-
section (3), the provisions of sections 350 and 549 of the Code of Criminal Procedure, 1898 (5 of
1898), shall, so far as may be. apply to the proceedings before a Special Judge, and for the purposes
of the said provisions a special Judge shall be deemed to be a Magistrate.
(4) A special Judge may pass upon any person convicted by him any sentence authorized by law for
punish-
ment of the offence of which such person is convicted."
"9. Appeal and revision-The High Court may exercise, so far as they may be
applicable, all the powers conferred by Chapters XXXI and XXXII of the Code of
Criminal Procedure, I898 (1; of 1898) on a High Court as if the Court of the special
Judge were a Court of Session trying cases without a jury within the local limits of the
jurisdiction of the High Court. ' "10. Transfer of certain pending cases-All cases
triable by a special Judge under section 7 which, immediately before theA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

commencement of this Act, were pending before any Magistrate shall, on such
commencement, be forwarded for trial to the special Judge having jurisdiction over
such cases."
On the ratio of the seven-Judge Bench decision of this Court in the Slate of West Bengal v. Anwar Ali
Sarkar, [ 1952] SCR 284 the vires of this Act are not open to challenge. The majority of the learned
Judges in Anwar Ali Sarkar's case expressed the view that it was open to the Legislature to set up a
special forum for expedient trial of particular class of cases. Section 7( l) has clearly provided that
offences specified in sub-section (1) of section 6 shall be triable by the Special Judge only and has
taken away the power of the courts established under the Code of Criminal Procedure to try those
offences. Section 10 of the Act required all pending cases on the date of commencement of the Act to
stand transferred to the respective Special Judge. Unless there be challenge to the provision creating
exclusive jurisdiction of the Special Judge, the procedural law in the Amending Act is binding on
courts as also the parties and no court is entitled to make orders contrary to the law which are
binding. As long as section 7 of the Amending Act of 1952 hold the field it was not open to any court
including the apex Court to act contrary to section 7(1) of the Amending Act.
The power to transfer a case conferred by the Constitution or by section 406 of the Code of Criminal
Procedure does not specifically relate to the special Court. Section 406 of the Code could perhaps be
applied on the principle that the Special Judge was a subordinate court for transferring a case from
one special Judge to another special Judge. That would he so because such a transfer would not
contravene the mandate of section 7( l ) of the Amending Act of 1952 . While that may be so, the
provisions for transfer, already referred to. do not authorise H transfer of a case pending in the court
of a special Judge first to the Supreme Court and then to the High Court for trial. A four Judge
Bench in Raja Soap Factory v. S.P. Santharaj, [1956] 2 SCR 800 was considering the jurisdiction of
the High Court to deal with a matter Shah J., as he then was, spoke for the court thus:
"But if the learned Judge, as reported in the summary of the judgment, was of the
opinion that the High Court is competent to assume to itself jurisdiction which it
does not otherwise possess, merely because an 'extra-ordinary situation' has arisen,
with respect to the learned Judge, we are unable to approve of that view. By
'jurisdiction' is meant the extent of the power which is conferred upon the court by its
Constitution to try a proceeding; its exercise cannot be enlarged because what the
learned Judge calls an extra ordinary situation 'requires' the Court to exercise it".
Brother Mukharji in his elaborate judgment has come to the conclusion that the question of
transferring the case from the court of the special Judge to the High Court was not in issue before
the five- Judge Bench. Mr. Jethmalani in course of the argument has almost accepted the position
that this was not asked for on behalf of the complainant at the hearing of the matter before the
Constitution Bench. From a reading of the judgment of the Constitution Bench it appears that the
transfer was a suo motu direction of the court. Since this particular aspect of the matter had not
been argued and counsel did not have an opportunity of pointing out the legal bar against transfer,
the learned Judges of this Court obviously did not take note of the special provisions in section 7(1)
of the 1952 Act. I am inclined to agree with Mr. Rao for Antulay that if this position had beenA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

appropriately placed, the direction for transfer from the court of exclusive jurisdiction to the High
Court would not have been made by the Constitution Bench. It is appropriate to presume that this
Court never' intends to act contrary to law.
There is no doubt that after the Division Bench of Desai and Sen, JJ. dismissed the writ petition and
the special leave petitions on 17th April, 1984, by indicating that the petitioner could file an
appropriate review petition or any other application which he may be entitled in law to file. no
further action was taken until charges Were framed on the basis of evidence of 57 witnesses and a
mass of documents. After a gap of more than three years. want of jurisdiction of the High Court was
sought to be reagitated before the two-Judge Bench in the present proceedings. During this
intervening period of three years or so a lot of evidence was collected by examining the prosecution
witnesses and exhibiting documents. A learned Judge of the High Court devoted his full time to the
case. Mr. Jethmalani pointed out to us in course of his argument that the evidence that has already
been collected is actually almost three-fourths of what the prosecution had to put in. Court's time
has been consumed, evidence has been collected and parties have been put to huge expenses. To
entertain the claim of the appellant that the transfer of the case from the Special Judge to the High
Court was without authority of law at this point of time would necessarily wipe out the evidence and
set the clock back by about four years. It may be that some of the witnesses may no longer be
available when the de novo trial takes place. Apart from these features, according to Mr. Jethmalani
to say at this stage that the DIRECTION given by a five-Judge Bench is not binding and, therefore,
not operative will shake the confidence of the litigant public in the judicial process and in the
interest of the system it should not be done. Long arguments were advanced on either side in
support of their respective stands-the appellant pleading that the direction for transfer of the
proceedings from the Special Judge to the High Court was a nullity and Mr. Jethmalani contending
that the apex Court had exercised its powers for expediting the trial and the action was not contrary
to law. Brother Mukharji has dealt with these submissions at length and I do not find any necessity
to dwell upon this aspect in full measure. In the ultimate analysis I am satisfied that this Court did
not possess the power to transfer the proceedings from the Special Judge to the High Court. Antulay
has raised objection at this stage before the matter has been concluded. In case after a full dressed
trial, he is convicted, there can be no doubt that the wise men in law will raise on his behalf, inter
alia, the same contention as has been advanced now by way of challenge to the conviction. If the
accused is really guilty of the offences as alleged by the prosecution there can be no two opinions
that he should be suitably punished and the social mechanism of punishing the guilty must come
heavily upon him. No known loopholes should be permitted to creep in and subsist so as to give a
handle to the accused to get out of the net by pleading legal infirmity when on facts the offences are
made out. The importance of this consideration should not be overlooked in assessing the situation
as to whether the direction of this Court as contained in the five-Judge Bench decision should be
permitted to be questioned at this stage or not.
Mr. Rao for Antulay argued at length and Brother Mukharji has noticed all those contentions that by
the change of the forum of the trial the accused has been prejudiced. Undoubtedly, by this process
he misses a forum of appeal because if the trial was handled by a Special Judge, the first appeal
would lie to the High Court and further appeal by special leave could come before this Court. If the
matter is tried by the High Court there would be only one forum of appeal being this Court, whetherA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

as of right or by way of special leave. The appellant has also contended that the direction violates
Article 14 of the Constitution because he alone has been singled out and picked up for being treated
differently from similarly placed accused persons. Some of these aspects cannot be overlooked with
ease. I must, however, indicate here that the argument based upon the extended meaning given to
the contents of Article 21 of the Constitution, though attractive have not appealed to me.
One of the well-known principles of law is that decision made by a competent court should be taken
as final subject to further proceedings contemplated by the law of procedure. In the absence of any
further proceeding, the direction of the Constitution Bench of 16th of February, 1984 became final
and it is the obligation of everyone to implement the direction of the apex Court. Such an order of
this Court should by all canons of judicial discipline be binding on this Court as well and cannot be
interfered with after attaining finality. Brother Mukharji has referred to several authorities in
support of his conclusion that an order made without jurisdiction is not a valid one and can be
ignored, overlooked or brushed aside depending upon the situation. I do not propose to delve into
that aspect in my separate judgment.
It is a well-settled position in law that an act of the court should not injure any of the suitors. The
Privy Council in the well-known decision of Alexander Rodger v. The Comptori D' Escompte De
Paris, [1871] 3 P.C. 465 observed:-
"One of the first and highest duties of all courts is to take care that the act of the court
does no injury to any of the suitors, and when the expression act of the court is used,
it does not mean merely the act of the primary court, or of any intermediate court of
appeal, but the act of the court as a whole, from the lowest court which entertains
jurisdiction over the matter upto the highest court which finally disposes of the case.
It is the duty of the aggregate of those Tribunals, if I may use the expression, to take
care that no act of the court in the course of the whole of the proceed ings does an
injury to the suitors in courts."
Brother Mukharji has also reffered to several other authorities which support this view.
Once it is found that the order of transfer by this Court dated 16th of February, 1984, was not within
jurisdiction by the direction of the transfer of the proceedings made by this Court, the appellant
should not suffer.
What remains to be decided is the procedure by which the direction of the 16th of February, 1984,
could be recalled or altered. There can be no doubt that certiorari shall not lie to quash a judicial
order of this Court. That is so on account of the fact that the Benches of this Court are not
subordinate to larger Benches thereof and certiorari is, therefore, not admissible for quashing of the
orders made on the judicial side of the court. Mr. Rao had relied upon the ratio in the case of Prem
Chand Garg v. Excise Commissioner, U.P., Allahabad, [1963] 1 SCR 885. Brother Mukharji has dealt
with this case at considerable length. This Court was then dealing with an Article 32 petition which
had been filed to challenge the vires of rule 12 of order 35 of this Court's Rules. Gajendragadkar, J.,
as the learned Judge then was, spoke for himself and three of his learned brethren including theA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

learned Chief Justice. The facts of the case as appearing from the judgment show that there was a
judicial order directing furnishing of security of Rs.2,500 towards the respondent's costs an(l the
majority judgment directed "In the result, the petition is allowed and the order passed against the
petitioners on December 12, 1961, calling upon them to furnish security of Rs.2,500 is set aside."
Shah, J. who wrote a separate judgment upheld the vires of the rule and directed dismissal of the
petition. The fact that a judicial order was being made the subject matter of a petition under Article
32 of the Constitution was not noticed and whether such a proceeding was tenable was not
considered. A nine-Judge Bench of this Court in Naresh Shridhar Mirajkar & Ors. v. State of
Maharashtra & Anr., [1966] 3 SCR 744 referred to the judgment in Prem Chand Garg's case (supra).
Gajendragadkar, CJ., who delivered the leading and majority judgment stated at page 765 of the
Reports:
"ln support of his argument that a judicial decision can be corrected by this Court in
exercise of its writ jurisdiction under Article 32(2), Mr. Setalvad has relied upon
another decision of this Court in Prem Chand Garg v. Excise Commissioner, U. P.
Allahabad (supra) . In that case, the petitioner had been required to furnish security
for the costs of the respondent under rule 12 of order 35 of the Supreme Court Rules.
By his petition filed under Article 32, he contended that the rule was invalid as it
placed obstructions on the fundamental right guaranteed under Article 32 to move
the Supreme Court for the enforcement of fundamental rights. This plea was upheld
by the majority decision with the result that the order requiring him to furnish
security was vacated. In appreciating the effect of this decision, it is necessary to bear
in mind the nature of the contentions raised before the Court in that case. The rule
itself, in terms, conferred discretion on the court. while dealing with applications
made under Article 32, to impose such terms as to costs as to the giving of security as
it thinks fit. The learned Solicitor General who supported the validity of the rule,
urged that though the order requiring security to be deposited may be said to retard
or obstruct the fundamental right of the citizen guaranteed by Article 32(1), the rule
itself could not be effectively challenged as invalid, because it was merely
discretionary; it did not impose an obligation on the court to demand any security;
and he supplemented his argument by contending that under Article 142 of the
Constitution, the powers of this court were wide enough to impose any term or
condition subject to which proceedings before this Court could be permitted to be
conducted. He suggested that the powers of this Court under Article 142 were not
subject to any of the provisions contained in Part III including Article 32(1). On the
other hand, Mr. Pathak who challenged the validity of the rule, urged that though the
rule was in form and in substance discretionary, he disputed the validity of the power
which the rule conferred on this Court to demand security .. It would thus be seen
that the main controversy in the case of Prem Chand Garg centered round the
question as to whether Article 145 conferred powers on this Court to make rules,
though they may be inconsistent with the constitutional provisions prescribed by Part
III. Once it was held that the powers under Article 142 had to be read subject not only
to the fundamental rights, but to other binding statutory provisions, it became clearA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

that the rule which authorised the making of the impugned order was invalid. It was
in that context that the validity of the order had to be incidentally examined. The
petition was made not to challenge the order as such, but to challenge the validity of
the rule under which the order was made. Once a rule was struck down as being
invalid, the order passed under the said rule had to be vacated. It is difficult to see
how this decision can be pressed into service by Mr. Setalvad in support of the
argument that a judicial order passed by this Court was held to be subject to the writ
jurisdiction of this Court itself .. ".
In view of this decision in Mirajkar's case (supra) it must be taken as concluded that judicial
proceedings in this Court are not subject to the writ jurisdiction thereof.
On behalf of the appellant,- at one stage, it was contended that the appeal may be taken as a review.
Apart from the fact that the petition of review had to be filed within 30 days-and here there has been
inordinate delay-the petition for review had to be placed before the same Bench and now that two of
the learned Judges of that Constitution Bench are still available, it must have gone only before a
Bench of five with those two learned Judges. Again under the Rules of the Court a review petition
was not to be heard in Court and was liable to be disposed of by circulation. In these circumstances.
the petition of appeal could not he taken as a review petition. The question, therefore, to be
considered now is what is the modality to be followed for vacating the impugned direction.
This being the apex Court, no litigant has any opportunity of approaching any higher forum to
question its decisions. Lord Buckmaster in 1917 A.C. 170 stated:
"All rules of court are nothing but provisions intended to secure proper
administration of justice. It is, therefore, essential that they should be made to serve
and be subordinate to that purpose."
This Court in Gujarat v. Ram Prakash, [1970] 2 SCR 875 reiterated the position by saying:
"Procedure is the handmaid and not a mistress of law, intended to subserve and
facilitate the cause of justice and not to govern or obstruct it, like all rules of
procedure, this rule demands a construction which would promote this Once judicial
satisfaction is reached that the direction was not open to be made and it is accepted
as a mistake of the court, it is not only appropriate but also the duty of the Court to
rectify the mistake by exercising inherent powers. Judicial opinion heavily leans in
favour of this view that a mistake of the Court can be corrected by the Court itself
without any fetters. This is on the principle as indicated in Alexander Rodger's case
(supra). l am of the view that in the present situation, the Court's inherent powers can
be exercised to remedy the mistake. Mahajan, J. speaking for a four-Judge Bench in
Kishan Deo v. Radha Kissen, [ 1953] SCR 136, at page 153 stated:
"The Judge had jurisdiction to correct his own error without entering into a
discussion of the grounds taken by the decree-holder or the objections raised by theA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

judgment debtors . "
The Privy Council in Debi v. Habib, ILR 35 All. 331, pointed out that an abuse of the process of the
Court may be committed by the court or by a party. Where a court employed a procedure in doing
something which it never intended to do and there is an abuse of the process of the court it can be
corrected. Lord Shaw spoke for the Law lords thus:
"Quite apart from section 151, any court might have rightly considered itself to
possess an inherent power to rectify the mistake which had been inadvertently
made."
It was pointed out by the Privy Council in Murtaza v. Yasin, AIR 1916 PC 8:. that:
"Where substantial injustice would othenwise result, the court has, in their Lordships
opinion, an inherent power to set aside its own judgments of condemnation so as to
let in bona fide claims by parties .. ".
Indian authorities are in abundance to support the view that injustice done should be corrected by
applying the principle actus curiae neminem gravabit an act of the court shall prejudice no one.
To err is human, is the off-quoted saying. Courts including the apex one are no exception. To own up
the mistake when judicial satisfaction is reached does not militate against its status or authority.
Perhaps it would enhance both.
It is time to sound a note of caution. This Court under its Rules of Business ordinarily sits in
divisions and not as a whole one. Each Bench, whether small or large, exercises the powers vested in
the Court and decisions rendered by the Benches irrespective of their size are considered as
decisions of the Court. The practice has developed that a larger Bench is entitled to overrule the
decision of a smaller Bench notwithstanding the fact that each of the decisions is that of the Court.
That principle, however, would not apply in the present situation and since we are sitting as a Bench
of Seven we are not entitled to reverse the decision of the Constitution Bench. Overruling when
made by a larger Bench of an earlier decision of a smaller one is intended to take away the precedent
value of the decision without affecting the binding effect of the decision in the particular case.
Antulay, therefore, is not entitled to take advantage of the matter being before a larger Bench. In
fact, if it is a case of exercise of inherent powers to rectify a mistake it was open even to a five-Judge
Bench to do that and it did not require a Bench larger than the Constitution Bench for that purpose.
Mr. Jethmalani had told us during arguments that if there was interference in this case there was
possibility of litigants thinking that the Court had made a direction by going out of its way because
an influential person like Antulay was involved. We are sorry that such a suggestion was made
before us by a senior counsel. If a mistake is detected and the apex Court is not able to correct it with
a view to doing justice for fear of being misunderstood, the cause of justice is bound to suffer and for
the apex Court the apprehension would not be a valid consideration. Today it is Abdul Rehman
Antulay with a political background and perhaps some status and wealth but tomorrow it can be anyA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

ill-placed citizen. This Court while administering justice does not take into consideration as to who
is before it. Every litigant is entitled to the same consideration and if an order is warranted in the
interest of justice, the contention of Mr. Jethmalani cannot stand in the way as a bar to the making
of that order.
There is still another aspect which should be taken note of. Finality of the orders is the rule. By our
directing recall of an order the well-settled propositions of law would not be set at naught. Such a
situation may not recur in the ordinary course of judicial functioning and if there be one certainly
the Bench before which it comes would appropriately deal with it. No strait jacket formula can be
laid down for judicial functioning particularly for the apex Court. The apprehension that the present
decision may be used as a precedent to challenge judicial orders of this Court is perhaps misplaced
because those who are familiar with the judicial functioning are aware of the limits and they would
not seek support from this case as a precedent. We are sure that if precedent value is sought to be
derived out of this decision, the Court which is asked to use this as an instrument would be alive to
the peculiar facts and circumstances of the case in which this order is being made.
I agree with the ultimate conclusion proposed by my earned brother Mukharji.
OZA, J. I had the opportunity to go through opinion prepared by learned brother Justice Mukharji
and I agree with his opinion. I have gone through these additional reasons prepared by learned
brother Justice R.N. Misra. It appears that the learned brother had tried to emphasise that even if
an error is apparent in a judgment or an order passed by this Court it will not be open to a writ of
certiorari and I have no hesitation in agreeing with this view expressed. At the same time I have no
hesitation in observing that there should be no hesitation in correcting an error in exercise of
inherent jurisdiction if it comes to our notice.
It is clear from the opinions of learned brothers Justice Mukharji and Justice Misra that the
jurisdiction to try a case could only be conferred by law enacted by the legislature and this Court
could not confer jurisdiction if it does not exist in law and it is this error which is sought to be
corrected. Although it is unfortunate that it is being corrected after long lapse of time. I agree with
the opinion prepared by Justice Mukharji and also the additional opinion prepared by Justice Misra
.
RAY, J. I have the privilege of going through the judgment prepared by learned brother Mukharji, J
and I agreed with the same. Recently, I have received a separate judgment from brother R.N. Misra,
J and I have decipherred the same.
In both the judgments it has been clearly observed that judicial order of this court is not amenable
to a writ of certiorari for correcting any error in the judgment. It has also been observed that the
jurisdiction or power to try and decide a cause is conferred on the courts by the Law of the Lands
enacted by the Legislature or by the provisions of the Constitution. It has also been highlighted that
the court cannot confer a jurisdiction on itself which is not provided in the law. It has also been
observed that the act of the court does not injure any of the suitors. It is for this reason that the error
in question is sought to be corrected after a lapse of more than three years. I agree with the opinionA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

expressed by Justice Mukharji in the judgment as well as the additional opinion given by Justice
Misra in his separate judgment.
VENKATACHALIAH, J. Appellant, a former Chief Minister of Maharashtra, is on trial for certain
offences under Sections 161, 165, Indian Penal Code and under the Prevention of Corruption Act,
1947. The questions raised in this appeal are extra-ordinary in many respects touching, as they do,
certain matters fundamental to the finality of judicial proceedings. It also raises a question-of far-
reaching consequences-whether, independently of the review jurisdiction under Article 137 of the
Constitution, a different bench of this Court, could undo the finality of earlier pronouncements of
different benches which have, otherwise, reached finality.
If the appeal is accepted, it will have effect of blowing-off, by a side-wind as it were, a number of
earlier decisions of different benches of this Court, binding inter-parties, rendered at various stages
of the said criminal prosecution including three judgments of 5 judge benches of this Court. What
imparts an added and grim poignance to the case is that the appeal, if allowed, would set to naught
all the proceedings taken over the years before three successive Judges of the High Court of Bombay
and in which already 57 witnesses have been examined for the prosecution-all these done pursuant
to the direction dated 16.12.1984 issued by a five judge Bench of this Court. This by itself should be
no deterrant for this Court to afford relief if there has been a gross miscarriage of justice and if
appropriate proceedings recognised by law are taken. Lord Atkin said "Finality is a good thing, but
justice is a better". [See 60 Indian Appeals 354 PC]. Considerations of finality are subject to the
paramount considerations of justice; but the remedial action must be appropriate and known to law.
The question is whether there is any such gross miscarriage of justice in this case, if so whether relief
can be granted in the manner now sought.
The words of caution of the judicial committee in Venkata Narasimha Appa Row v. The Court of
Wards & Ors. [1886] 1 ILR 660 (at page 664) are worth recalling:
"There is a salutary maxim which ought to be observed by all courts of last
resort-interest reipublicae ut sit finis litium. Its strict observance may occasionally
entail hardship upon individual litigants, but the mischief arising from that source
must be small in comparison with the great mischief which would necessarily result
from doubt being thrown upon the finality of the decisions of such a tribunal as this."
(emphasis supplied).
2. I have had the opportunity, and the benefit, of reading in draft the learned and instructive
opinions of my learned Brothers Sabyasachi Mukharji J., and Ranganath Misra J. They have, though
for slightly differing reasons, proposed to accept the appeal. This will have the effect of setting-aside
five successive earlier orders of different benches of the Court made at different stages of the
criminal prosecution, including the three judgments of Benches of five Judges of this Court in R.S.
Nayak v. A.R. Antulay, [1984] 2 SCR 495 and A . R. Antulay v. R. S. Nayak, [1984] 2 SCR 914 and R.
S. Nayak v. A. R. Antulay, [1984] 3 SCR 412.A.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

I have bestowed a respectful and anxious consideration to the weighty opinion of my brothers with
utmost respect, I regret to have to deny myself the honour of agreeing with them in the view they
take both of the problem and the solution that has commended itse1f to them. Apart from other
things, how can the effect and finality of this Court's order dated 17.4.1984 in Writ Petition No. 708
of 1984 be unsettled in these proceedings? Admittedly, this order was made after hearing and does
not share the alleged vitiating factors attributed to the order dated 16.2.1984. That order concludes
everything necessarily inconsistent with it. In all humility, I venture to say that the proposed remedy
and the procedure for its grant are fraught with far greater dangers than the supposed injustice they
seek to relieve:
and would throw open an unprecedented procedural flood-gate which might, quite
ironically, enable a repetitive challenge to the present decision itself on the very
grounds on which the relief is held permissible in the appeal. To seek to be wiser than
the law, it is said, is the very thing by good laws forbidden. Well trodden path is the
best path.
Ranganath Misra J. if I may say so with respect, has rightly recognised these
imperatives:
"It is time to sound a note of caution. This Court under its rules of business ordinarily
sits in divisions and not as a whole one. Each Bench, whether small or large, exercises
the powers vested in the Court and decisions rendered by the Benches irrespective of
their size are considered as decisions of the Court. The practice has developed that a
larger bench is entitled to over-rule the decision of a small bench notwithstanding the
fact that each of the decisions is that of the Court. That principle, however, would not
apply in the present situation and since we are sitting as a Bench of Seven we are not
entitled to reverse the decision of the Constitution Bench."
Learned brother, however, hopes this case to be more an exception than the Rule C "Finality of the
orders is the rule. By our directing recall of an order the well-settled propositions of law would not
be set at naught. Such a situation may not recur in the ordinary course of judicial functioning and if
there be one, certainly the bench before which it comes would appropriately deal with it. "
3. A brief advertence to certain antecedent events which constitute the back-drop for the proper
perception of the core-issue arising in this appeal may not be out of place:
Appellant was the Chief Minister of Maharashtra between 9.6.1980 and 12.1.1982 on
which latter date he resigned as a result of certain adverse findings made against him
in a Court proceeding. On 9.8.1982, Ramdas Srinivas Nayak, respondent No. 1, with
the sanction of the Governor of Maharashtra, accorded on 28.7.1982, filed in the
Court of Special-Judge, Bombay, a criminal Case No. 24 of 1982 alleging against the
appellant certain offences under Section 161 and 165 of Indian Penal Code and
Section 6 of the Prevention of Corruption Act, 1947, of which the Special-Judge took
cognisance.A.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

Appellant questioned the jurisdiction of Special Judge to take cognisance of those offences on a
private complaint. On 20.10.1982, the Special Judge over-ruled the objection. On 7.3.1983, the High
Court dismissed appellant's revision petition in which the order of the Special Judge was assailed.
The criminal case thereafter stood transferred to another Special Judge, Shri R.B. Sule. Appellant
did not accept the order of the High Court dated 7.3.1983 against which he came up in appeal to this
court, by Special-leave, in Criminal appeal No. 347 of 1983. During the pendency of this appeal,
however, another important event occurred. The Special Judge, Shri R.B. Sule, by his order dated
25.7.1983, discharged the appellant, holding that the prosecution was not maintainable without the
sanction of the Maharashtra Legislative Assembly, of which the appellant continued to be a member,
notwithstanding his ceasing to be Chief Minister. Respondent No. 1 challenged this order of
discharge in a Criminal Revision Petition No. 354 of 1982 before the High Court of Bombay.
Respondent No. 1 also sought, and was granted, special-leave to appeal against Judge Sule's order
directly to this court in Criminal appeal No. 356 of 1983. This Court also withdrew to itself the,said
criminal revision application No. 354 of 1982 pending before the High Court. All the three
matters-the two appeals (Crl. A. 347 of 1983 and 356 of 1983) and Criminal Revision Petition so
withdrawn to this Court-were heard by a five Judge bench and disposed of by two separate
Judgments dated 16.2.1984.
By Judgment in Crl. appeal No. 356 of 1983 R. S. Nayak v. A. R. Antulay, [1984] 2 SCR 495 this
Court, while setting aside the view of the Special Judge that sanction of the Legislative Assembly was
necessary, further directed the trial of the case by a Judge of the Bombay High Court. This Court
observed that despite lapse of several years after commencement of the prosecution the case had
"not moved an inch further", that "expeditious trial is primarily necessary in the interest of the
accused and mandate of Article 21", and that "therefore Special case No. 24 of 1982 and Special Case
No. 3 of 1983 pending in the Court of Special Judge, Greater Bombay, Shri R.B. Sule" be withdrawn
and transferred to the High Court of Bombay, with a request to the learned Chief Justice to assign
these two cases to a sitting Judge of the High Court. The Judge so designated was also directed to
dispose of the case expeditiously, preferably "by holding the trial from day-to-day".
Appellant, in these proceedings, does not assail the correctness of the view taken by the 5 Judge
Bench on the question of the sanction. Appellant has confined his challenge to what he calls the
constitutional infirmity-and the consequent nullity-of the directions given as to the transfer of the
case to a Judge of the High Court.
In effctuation of the directions dated 16.2.1984 of this Court the trial went on before three successive
learned Judges of the High Court. It is not necessary here to advert to the reasons for the change of
Judges. It is, however, relevant to mention that when the matter was before Khatri J. who was the
first learned Judge to be designated by the Chief Justice on the High Court, the appellant challenged
his jurisdiction, on grounds which amounted to a challenge to the validity of directions of this Court
for the transfer of the case. Khatri J. quite obviously, felt bound to repel the challenge to his
jurisdiction. Learned Judge said appellant's remedy, if any was to seek a review of the directions
dated 16.2.1984 at the hands of this Court.A.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

Learned Judge also pointed out in his order dated 14.3.1984 what, according to him, was the true
legal position permitting the transfer of the case from the Special-Judge to be tried by the High
Court in exercise of its extra-ordinary original criminal jurisdiction. In his order dated 16.3.1984,
Khatri J. Observed:
"..... Normally it is the exclusive jurisdiction of a Special Judge alone to try corruption
charges. This position flows from Section 7 of the 1952 Act. However, this does not
mean that under no circumstances whatever, can trial of such offences be not tried by
a Court of superior jurisdiction than the Special Judge. I have no hesitation in
contemplating at three situations in which a Court of Superior jurisdiction could try
such offence .. "
"8. The third situation can be contemplated under the Code of Criminal Procedure
itself where a Court of superior jurisdiction may have to try the special cases.
Admittedly, there are no special provisions in the 1952 Act or 1947 Act relating to the
transfer of special cases from one Court to the other. So by virtue of the combined
operation of Sec. 8(3) of the 1952 Act and Section 4(2) of the Code of Criminal
Procedure, the High Court will have jurisdiction under Sec 407 of the Code in relation
to the special cases also. An examination of the provisions of Section 407 leaves no
doubt that where the requisite conditions are fulfilled, the High Court will be within
its legitimate powers to direct that a special case be transferred to and tried before
itself."
Appellant did not seek any review of the directions at the hands of the Bench which had issued
them, but moved in this Court a Writ Petition No. 708 of 1984 under Article 32 of the Constitution
assailing taken by Khatri J. as to jurisdiction which in substance meant a challenge to the original
order dated 16.2.1984 made by this court. A A division Bench consisting of D.A. Desai and A.N. Sen,
JJ. dismissed the writ petition on 17.4.1984. Sen, J. speaking for the bench said:
"In my view, the writ petition challenging the validity of the order and judgment
passed by this Court as nullity or otherwise is incorrect, cannot be entertained. I wish
to make it clear that the dismissal of this writ petition will not prejudice the right of
the petitioner to approach the Court with an appropriate review petition or to file any
other application which he may be entitled in law to file."
(emphasis supplied) [A.R. Antulay v. Union, []984] 3 SCR 482] This order has become final. Even
then no review was sought.
It is also relevant to refer here to another pronouncement of a five Judge bench of this Court dated
5.4.1984 in R.S. Nayak v. A.R. Antulay, [1984] 3 SCR 412 in Criminal misc. petition No. 1740 of 1984
disposing of a prayer for issue of certain directions as to the procedure to be followed before the
designated Judge of the High Court. The bench referred to the provisions of law, which according to
it, enabled the transfer of the trial of the criminal case to the High Court. The view taken by my two
learned Brothers, it is needless to emphasise, has the effect of setting at naught this pronouncementA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

of the five Judge Bench as well. The five Judge bench considered the legal foundations of the power
to transfer and said:
" ....... To be precise, the learned Judge has to try the case according to the procedure
prescribed for cases instituted otherwise than on police report by Magistrate. This
position is clearly an unambiguous in view of the fact that this Court while allowing
the appeal was hearing amongst others Transferred case No. 347 of 1983 being the
Criminal Revision Application No. 354 of 1983 on the file of the High Court of the
Judicature at Bombay against the order of the learned Special Judge, Shri R.B. Sule
discharging the accused. If the criminal revision application was not withdrawn to
this Court, the High Court while hearing criminal revision application could have
under sec. 407(8), Code of Criminal Procedure, 1973, would have to follow the same
procedure which the Court of Sr"
Judge would have followed if the case would not have been so transferred ..
(emphasis supplied) According to the Bench, the High Court's power under Section 407, Criminal
Procedure Code for withdrawing to itself the case from a Special Judge, who was, for this purpose, a
Sessions Judge, was preserved notwithstanding the exclusivity of the jurisdiction of the Special
Judge and that the Supreme Court was entitled to and did exercise that, power as the Criminal
Review application pending in the High Court had been withdrawn to the Supreme Court. The main
basis of appellant's case is that all this is per-incurriam, without jurisdiction and a nullity .
In the meanwhile Mehta J. was nominated by the Chief Justice of the High Court in place of Khatri.
J. In addition to the 17 witnesses already examined by Khatri J. 41 more witnesses were examined
for the prosecution before Mehta J. of the 43 charges which the prosecution required to be framed
in the case, Mehta J. declined to frame charges in respect of 22 and discharged the appellant of
those alleged offences. Again respondent No. 1 came up to this Court which by its order dated
17.4.1986 in Criminal Appeal No. 658 of 1985, [reported in (1985) 2 SCC 716] set aside the order of
discharge in regard to 22 offences and directed that charges be drawn in respect of them. This Court
also suggested that another Judge be nominated to take up the case. It is, thus, that Shah J came to
conduct the further trial.
4. I may now turn to the occasion for the present appeal. In the further proceedings before Shah J.
the appellant contended that some of the alleged co-conspirators, some of whom had already been
examined as prosecution witnesses, and some others proposed to be so examined should also be
included in the array of accused persons. This prayer, Shah J had no hesitation to reject. It is against
this order dated 24.7.1986 that the present appeal has come up. With this appeal as an opening,
appellant has raised directions of the five Judges Bench, on 16.2.1984; of the serious violations of his
constitutional- rights; of a hostile discrimination of having to face a trial before a Judge of the High
Court instead of the Special-Judge, etc. A Division Bench consisting of E.S. Venkataramiah and
Sabyasachi Mukharji JJ. in view of the seriousness of the grievances aired in the appeal, referred it
to be heard by a bench of seven Judges.A.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

5. The actual decision of Shah J in the appeal declining to pro-
ceed against the alleged co-conspirators is in a short compass. But the appeal itself, has assumed a
dimension far beyond the scope of the order it seeks to be an appeal against. The appeal has become
significant not for its pale determined by the order under appeal; but more for the collateral
questions for which it has served as a spring board in this Court.
6. Before going into these challenges, it is necessary to say something on the merits of the order
under appeal itself. An accused person cannot assert any right to a joint trial with his co-accused.
Normally it is the right of the prosecution to decide whom it prosecutes. It can decline to array a
person as a co-accused and, instead, examine him as a witness for the prosecution. What weight is to
be attached to that evidence, as it may smack of the testimony of a guilty partner, in crime, is a
different matter. Prosecution can enter Nolle proseque against any accused-person. It can seek to
withdraw a charge against an accused person. These propositions are too well settled to require any
further elaboration. Suffice it to say that the matter is concluded by the pronouncement of this Court
in Choraria v. Maharashtra, [1968] 2 SCR 624 where Hidayathullah J referred to the argument that
the accomplice, a certain Ethyl Wong in that case, had also to be arrayed as an accused and repelled
it, observing:
"... Mr. Jethmalani's argument that the Magistrate should have promptly put her in
the dock because of her incriminating answers overlooks S. 132 (proviso)".
"... The prosecution was not bound to prosecute her, if they thought that her evidence
was necessary to break a smugglers' ring. Ethyl Wong was prosecuted by S. 132
(proviso) of the Indian Evidence Act even if she gave evidence incriminating herself.
She was a competent witness although her evidence could only be received with the
caution necessary in all accomplice evidence ... "
On this point, really, appellant cannot be heard to complain. Of the so called co-conspirators some
have been examined already as prosecution witnesses; some others proposed to be so examined; and
two others, it would appear, had died in the interregnum. The appeal on the point has no substance
and would require to be dismissed. We must now turn to the larger issue raised in the appeal.
7. While Shri P.P. Rao, learned Senior Counsel for the appel-
lant, handling an otherwise delicate and sensitive issue, deployed all the legal tools that a first rate
legal-smithy could design, Shri Ram Jethmalani, learned Senior Counsel, however, pointed out the
impermissibility both as a matter of law and propriety of a different bench embarking upon the
present exercise which, in effect, meant the exertion of an appellate and superior jurisdiction over
the earlier five Judge Bench and the precedential problems and anomalies such a course would
create for the future.
8. The contentions raised and urged by Shri P.P. Rao admit of being summarised and formulated
thus:A.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

(a) That Supreme Court has, and can, exercise only such jurisdiction as is invested in
it by the Constitution and the laws; that even the power under Article 142(1) is not
unfettered, but is confined within the ambit of the jurisdiction otherwise available to
it; that the Supreme Court, like any other court, cannot make any order that violates
the law; that Section 7(1) of the Criminal Law (Amendment) Act, 1952, (1952 Act)
envisages and sets-up a special and exclusive forum for trial of certain offences; that
the direction for trial of those offences by a Judge of the High Court is wholly without
jurisdiction and void; and that 'Nullity' of the order could be set up and raised
whenever and wherever the order is sought to be enforced or effectuated;
(b) That in directing a Judge of the High Court to try the case the Supreme Court
virtually sought to create a new jurisdiction and a new forum not existent in and
recognised by law and has, accordingly, usurped Legislative powers, violating the
basic tenets of the doctrine of separation of powers;
(c) That by being singled out for trial by the High Court, appellant is exposed to a
hostile discrimination, violative of his fundamental rights under Articles 14 and 21
and if the principles in State of West Bengal v. Anwar Ali Sarkar, [1952] SCR 284. The
law applicable to Anwar Ali Sarkar should equally apply to Abdul Rahman Antulay.
(d) That the directions for transfer were issued without affording an opportunity to
the appellant of being hear,, and therefore void as violative of Rules of Natural
Justice.
(e) That the transfer of the case to the High Court deprived appellant of an appeal, as
of right, to the High Court. At least one appeal, as of right is the minimal
constitutional safeguard.
(f) That any order including a judicial order, even if it be of the highest Court, which
violates the fundamental rights of a person is a nullity and can be assailed by a
petition under Article 32 of the Constitution on the principles laid down in Prem
Chand Garg v. Excise Commissioner, UP., [1963] J 1 SCR 885.
(g) That, at all events, the order dated 16.2.1984 in so far as the impugned direction is
concerned, is per incuriam passed ignoring the express statutory provisions of
Section 7(1) of Criminal Law (Amendment) Act, 1952, and the earlier decision of this
Court in Gurucharan Das Chadha v. State of Rajasthan, [1966] 2 SCR 678.
(h) That the direction for transfer of the case is a clear and manifest case of mistake
committed by the Court and that when a person is prejudiced by a mistake of Court it
is the duty of the Court to correct its own mistake: Actus Curiae Nominem Gravabit.
9. Courts are as much human institutions as any other and share all human susceptibilities to error.
Justice Jackson said:A.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

"...... Whenever decisions of one Court are reviewed by another, a percentage of them
are reversed. That reflects a difference in outlook normally found between personnel
comprising different courts. However, reversal by a higher court is not proof that
justice is thereby better done. There is no doubt that if there were a super-Supreme
Court a substantial proportion of our reversals of state Courts would also be reversed.
We are not final because we are infallible, but we are infallible only because we are
final . "
(See Brown v. Allen, [1944] US 443 at 540.
In Broom v. Cassel, [1972] AC 1027 (at 1131) Lord Diplock said:
" ... It is inevitable in a hierarchical system of courts that there are decisions of the
supreme appellate tribunal which do not attract the unanimous approval of all
members of the judiciary. When I sat in Court of Appeal I sometimes thought the
House of Lords was wrong in over ruling me. Even since that time there have been
occasions, of which the instant appeal itself is one, when, alone or in company, I have
dissented from a decision of the majority of this House. But the judicial system only
works if someone is allowed to have the last word and if that last word, once spoken,
is loyally accepted."
Judge Learned Hand, referred to as one of the most profound legal minds in the jurisprudence of
the English speaking world, commended the Cromwellian intellectual humility and desired that
these words of Cromwell be written over the portals of every church, over court house and at every
cross road in the nation: "I beseech ye ....................... think that ye may be mistaken."
As a learned author said, while infallibility is an unrealisable ideal, "correctness", is often a matter of
opinion. An erroneous decision must be as binding as a correct one. It would be an unattainable
ideal to require the binding effect of a judgment to defend on its being correct in the absolute, for
the test of correctness would be resort to another Court the infallibility of which is, again subject to a
similar further investigation. No self- respecting Judge would wish to act if he did so at the risk of
being called a usurper whenever he failed to anticipate and predict what another Judge thought of
his conclusions. Even infallibility would not protect him he would need the gift of prophecy-ability
to anticipate the fallibilities of others as well. A proper perception of means and ends of the judicial
process, that in the interest of finality it is inevitable to make some compromise between its
ambitions of ideal justice in absolute terms and its limitations.
10. Re: Contentions (a) ar.d (b): In the course of arguments we were treated to a wide ranging, and
no less interesting, submissions on the concept of "jurisdiction" and "nullity" in relation to judicial
orders. Appellant contends that the earlier bench had no jurisdiction to issue the impugned
directions which were without any visible legal support, that they are 'void' as violative of the
constitutional-rights of the appellant, and, also as violating the Rules of natural justice.
Notwithstanding these appeal to high-sounding and emotive appellateous; I have serious
reservations about both the permissibility-in these proceedings-of an examination of the merits ofA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

these challenges. Shri Rao's appeal to the principle of "nullity" and reliance on a collateral challenge
in aid thereof suffers from a basic fallacy as to the very concept of the jurisdiction of superior courts.
In relation to the powers of superior courts, the familiar distinction between jurisdictional issues
and adjudicatory issues-appropriate to Tribunals of limited jurisdiction,-has no place. Before a
superior court there is no distinction in the quality of the decision-making-process respecting
jurisdictional questions on the one hand and adjudicatory issues or issues pertaining to the merits,
on the other.
11. The expression "jurisdiction" or the power to determine is, it is said, a verbal cast of many
colours. In the case of a Tribunal, an error of law might become not merely an error in jurisdiction
but might partake of the character of an error of jurisdiction. But, otherwise, jurisdiction is a 'legal
shelter'-a power to bind despite a possible error in the decision. The existence of jurisdiction does
not depend on the correctness of its exercise. The authority to decide embodies a privilege to bind
despite error, a privilege which is inherent in and indispensable to every judicial function. The
characteristic attribute of a judicial act is that it binds whether it be right or it be wrong. In
Malkarjun v. Narahari, [1900] 27 I.A. 216 the executing Court had quite wrongly, held that a
particular person represented the estate of the deceased Judgment-debtor and put the property for
sale in execution. The judicial committee said:
"In doing so, the Court was exercising its jurisdiction. It made a sad mistake, it is
true; but a court has jurisdiction to decide wrong as well as right. If it decides wrong,
the wronged party can only take the course prescribed by law for setting matters right
and if that course is not taken the decision, however wrong. cannot be disturbed."
In the course of the arguments there were references to the Anisminic case. In my view, reliance on
the Anisminic principle is wholly misplaced in this case. That case related to the powers of Tribunals
of limited jurisdiction. It would be a mistake of first magnitude to import these inhibitions as to
jurisdiction into the concept of the jurisdiction of superior courts. A finding of a superior court even
on a question of its own jurisdiction, however grossly erroneous it may, otherwise be, is not a
nullity; nor one which could at all be said to have been reached without jurisdiction, susceptible to
be ignored or to admit of any collateral-attack. Otherwise, the adjudications of superior courts
would be held-up to ridicule and the remedies generally arising from and considered concomitants
of such classification of judicial-errors would be so seriously abused and expanded as to make a
mockery of those foundational principles essential to the stability of administration of justice.
The superior court has jurisdiction to determine its own jurisdiction and an error in that
determination does not make it an error of jurisdiction. Holdsworth (History of English Law vol. 6
page 239) refers to the theoritical possibility of a judgment of a superior court being a nullity if it
had acted coram-non- judice. But who will decide that question if the infirmity stems from an act of
the Highest Court in the land? It was observed:
". . . It follows that a superior court has jurisdiction to determine its own jurisdiction;
and that therefore an erroneous conclusion as to the ambit of its jurisdiction is
merely an abuse of its jurisdiction, and not an act outside its jurisdiction ......A.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

" . . . ln the second place, it is grounded upon the fact that, while the judges of the
superior courts are answerable only to God and the king, the judges of the inferior
courts are answerable to the superior courts for any excess of jurisdiction . . . " E
"Theoritically the judge of a superior court might be liable if he acted coram non
judice; but there is no legal tribunal to enforce that liability. Thus both lines of
reasoning led to the same conclusion-the total immunity of the judges of the superior
courts." F Rubinstein in his "Jurisdiction and Illegality" says:
" .... In practice, every act made by a superior court is always deemed valid (though,
possibly, voidable) wherever it is relied upon. This exclusion from the rules of validity
is indispensable. Superior courts knew the final arbiters of the validity of acts done by
other bodies; their own decisions must be immune from collateral attack unless
confusion is to reign. The superior courts decisions lay down the rules of validity but
are not governed by these rules."
(See P. 12) A clear reference to inappositeness and limitations of the Anisminic Rule in relation to
Superior Court so to be found in the opinion of Lord Diplock in Re Racal Communications Ltd. [
198() 2 All E.R. 634], thus:
"There is in my view, however, also an obvious distinction between jurisdiction
conferred by a statute on a court of law of limited jurisdiction to decide a defined
question finally and conclusively or unappealably, and a similar jurisdiction
conferred on the High Court or a judge of the High Court acting in his judicial
capacity. The High Court is not a court of limited jurisdiction and its constitutional
role includes the interpretation of written laws. There is thus no room for the
inference that Parliament did not intend the High Court or the judge of the High
Court acting in his judicial capacity to be entitled and, indeed, required to construe
the words of the statute by which the question submitted to his decision was defined.
There is simply no room for error going to his jurisdiction, or as is conceded by
counsel for the respondent, is there any room for judicial review. Judicial review is
available as a remedy for mistakes of law made by inferior courts and tribunals only.
Mistakes of law made by judges of the High Court acting in their judicial capacity as
such can be corrected only by means of appeal to an appellate court and if, as in the
instant case, the statute provides that the judge's deci- sion shall not be appealable,
they cannot be corrected at all." [See page 639 & 640l. In the same case, Lord
Salmon, said:
"The Court of Appeal, however, relied strongly on the decision of your Lordship's
House in Anisminic Ltd. v. Foreign Compensation Commission, [1969] 1 All ER 209.
That decision however was not, in my respectful view in any way relevant to the
present appeal. It has no applica- tion to any decision or order made at first instance
in the High Court of Justice. It is confined to decisions made by commissioners,
tribunals or inferior courts which can now be reviewed by the High Court of Justice,
just as the decision of inferior courts used to be reviewed by the old Court of King'sA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

Bench under the prerogative writs. If and when any such review is made by the High
Court. it Can be A appealed to the court of Appeal and hence, by lave, to your
Lordship's House. [See page 6411. Again in Issac v. Robertson, [1984] 3 All E.R. 140
the Privy Council reiterated the fallacy of speaking in the language of Nullity void,
etc., in relation to Judgement of superior courts. lt Was pointed out that it could only
be called 'irregular'. Lord Diplock observed: "Their L,ordships would, however, take
this opportunity to point out that in relation to orders of a court of unlimited
jurisdiction it is misleading to seek to draw distinctions between orders that are. "
void' in the sense that they can be ignored with impunity by those persons to whom
they are addressed, and orders that arc "voidable' and may be enforced unless and
until they are set aside. Dicta that refers to the possibility of these being such a
distinction between orders to which the description 'void' and 'void. able' respectively
have been applied can be found in the opinion given by the judicial committee of the
Privy Council in Marsh v. Marsh, [1945] AC 271 at 284 and Maxfoy v. United Africa
Co. Ltd., [19611] All EWR 1169. [1962] AC 152, but in neither of those appeals not in
any other case to which counsel has been able to refer their Lordships has any order
of a court of unlimited jurisdiction been held to fall in a category of court orders that
can simply be ignored because they are void ipso facto without there being any need
for proceeding to have them set aside.The cases that are referred to in these dicta do
not support the proposition that there is any category of orders of a court of
unlimited jurisdiction of this kind .. ' F "The contrasting legal concepts of voidness
and voidability form part of the English Law of contract. They are inapplicable to
orders made by a court of unlimited jurisdiction in the course of contentious
litigation.Such an order is either irregular or regular. if it is irregular it can be sel
aside by the court that made it on application to High court. if it is regular it can only
be set aside by an appellate court on appeal if there is one to which an appeal lies.
"[See page 143] Superior courts apart, even the ordinary civil courts of the land have
jurisdiction to decide questions of their own jurisdiction. This Court, in the context of
the question whether the provisions of Bombay Rents, Hotel and Lodging House
Rates Control Act, 1947, was not attracted to the premises in question and whether,
consequently, the exclusion under Section 28 of that Act, of the jurisdiction of all
courts other than the Court of Small Causes in Greater Bombay did not operate,
observed:
"... The crucial point, therefore, in order to determine the question of the jurisdiction
of the City Civil Court to entertain the suit, is to ascertain whether, in view of Section
4 of the Act, the Act applies to the premises at all. If it does, the City Civil Court has
no jurisdiction but if it does not then it has such jurisdiction. The question at once
arises as to who is to decide this point in controversy. It is well settled that a Civil
Court has inherent power to decide the question of its own jurisdiction, although, as a
result of its enquiry, it may turn out that it has no jurisdiction over the suit.
Accordingly, we think, in agreement with High Court that this preliminary objection
is not well founded in principle or on authority and should be rejec- ted." [See AIR
1953 (SC) 16 at 19. Bhatia Co- operative Housing Society Ltd. v. D. C. Patel] It would,A.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

in my opinion, be wholly erroneous to characterise the directions issued by the five
Judge bench as a nullity, amenable to be ignored or so. declared in a collateral attack.
12. A judgment, inter-parties, is final and concludes the parties. In Re Hastings (No. 3) [ 1959] l All
ER 698, the question arose whether despite the refusal of a writ of Habeas Corpus by a Divisional
Court of the Queen's bench, the petitioner had, yet, a right to apply for the writ in the Chancery
Division. Harman J. called the supposed right an illusion:
"Counsel for the applicant, for whose argument I for one am much indebted, said that
the clou of his case as this, that there still was this right: to go from Judge to Judge,
and that if that were not so the whole structure would come to the ground ...."
"I think that the Judgment of the Queen's bench Divisional Court did make it clear
that this supposed right was an illusion. If that be right, the rest follows. No body
doubts that there was a right to go from court to court, as my Lord has already
explained. There are no different courts now to go to. The courts that used to sit in
banc have been swept away and their places taken by Divisional Courts, which are
entirely the creatures of statute and rule. Applications for a writ of habeas corpus are
assigned by the rule to Divisional Courts of the Queen's Bench Division, and that is
the only place to which a applicant may go ...... " [See page 701] In Daryao v. State of
U. P., [1962] 1 SCR 574 it was held:
"It is in the interest of the public at large that a finality should attach to the binding
decisions pronounced by courts of competent jurisdiction, and it is also in the public
interest that individuals should- not be vexed twice over with the same kind of
litigation. If these two principles form the foundation of the general rule of
res-judicata they cannot be treated as irrelevant or inadmissible even in dealing with
fundamental rights in petitions filed under Article 32". [See page 583].
In Trilok Chand v. H. B. Munshi, [1969] 2 SCR 824 Bachawat J. recognised the same
limitations even in matter pertaining to the conferment of fundamental rights.
"... The right to move this Court for enforcement of fundamental rights is guaranteed
by Article 32. The writ under Article 32 issues as a matter of course if a breach of a
fundamental right is established. But this does not mean that in giving relief under
Article 32 the Court must ignore and trample under foot all laws of procedure,
evidence. limitation, res judicata and the like ....
".... the object of the statutes of limitation was to give effect to the maxim 'interest
reipublicate ut sit finislitium' (Cop Litt 303)-the interest of the State requires that
there should be a limit to litigation. The rule of res judicata is founded upon the same
rule of public policy ...... " [See page 842 and 843] It is to be recalled that an earlier
petition, W.P. No. 7()8 of 1984 under Article 32 moved before this Court had been
dismissed, reserving leave to the appellant to seek review.A.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

The words of Venkataramiah J in Sheonandan Paswan v. State of Bihar, [1987]1 SCC
288 at 343 are apt and are attracted to the present case:
"The reversal of the earlier judgment of this court by this process strikes at the
finality of judgments of this Court and would amount to the abuse of the power of
review vested in this Court, particularly in a criminal case. It may be noted that no
other court in the country has been given the power of review in criminal cases. I am
of the view that the majority judgment of Baharul Islam and R.B. Misra, JJ. should
remain undisturbed. This case cannot be converted into an appeal against the earlier
decision of this Court. "
(Emphasis supplied)
13. The exclusiveness of jurisdiction of the special judge under Section 7(1) of 1952 Act, in turn,
depends on the construction to be placed on the relevant statutory- provision. If on such a
construction, however erroneous it may be, the court holds that the operation of Sec. 407, Cr.P.C. is
not excluded, that interpretation will denude the plenitude of the exclusivity claimed for the forum.
To say that the court usurped legislative powers and created a new jurisdiction and a new forum
ignores the basic concept of functioning of courts. The power to interpret laws is the domain and
function of courts. Even in regard to the country's fundamental-law as a Chief Justice of the
Supreme Court of the United States said: "but the Constitution is what the judges say it is". In
Thomas v. Collins, 323 (1945) US 516 it was said:
"The case confronts us again with the duty our system places on this Court to say
where the individual's freedom ends and the State's power begins. Choice on that
border, now as always is, delicate ...."
I am afraid appellant does himself no service by resting his case on these high conceptual
fundamentals.
14. The pronouncements of every Division-Bench of this Court are pronouncements of the Court
itself. A larger bench, merely on the strength of its numbers, cannot un-do the finalily of the
decisions of Other division benches. If the decision suffers from an error the only A way to correct it,
is to go in Review under Article 137 read with order 40 Rule I framed under Article 145 before "as far
as is practicable" the same judges. This is not a matter merely of some dispensable procedural 'form'
but the requirement of substance. The reported decisions on the review power under the (Civil
Procedure Code when it had a similar provision for the same judges hearing the matter demonstrate
the high purpose sought to be served thereby.
15. In regard to the concept of Collateral Attack on Judicial Proceedings it is instructive to recall
some observations of Van Fleet on the limitations and their desirability-on such actions.
"one who does not understand the theory of a science, who has no clear conception of
its principles, cannot apply it with certainty to the problems; it is adapted to solve. InA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

order to understand the principles which govern in determining the validity of
RIGHTS AND TITLES depending upon the proceedings of judicial tribunals,
generally called the doctrine of COLLATERAL ATTACK ON JUDG-MENTS, it is
necessary to have a clear conception of the THEORY OF JUDICIAL PROCEEDINGS
.....
" .. And as no one would think of holding a judgmenf of the court of last resort void if
its jurisdiction were debatable or even colorable, the same rule must be applied to the
judgments of all judicial tribunals. This is the true theory of judicial action when
viewed collaterally. If any jurisdictional question is debatable or colorable, the
tribunal must decide it; and an erroneous conclusion can ony be corrected by some
proceeding provided by law for so doing, com- monly called a Direct Attack. It is only
where it can be shown lawfully, that some matter or thing essential to jurisdiction is
wanting, that the proceeding is void, collaterally.
It is the duty of the courts to set their faces against all collateral assaults on judicial
proceedings for two reasons, namely: First. Not one case in a hundred has any merits
in it "... Second. Thc second reason why the courts should reduce the chances for a
successful collateral attack to the H lowest minimum is, that they bring the courts
themselves into disrepute. Many people look upon the courts as placed where
jugglery and smartness are substituted for justice "...... such things tend to weaken
law and order and to cause men to settle their rights by violence. For these reasons,
when the judgment rendered did not exceed the possible power of the court7 and the
notice was sufficient to put the defendant upon inquiry, a court should hesitate long
before holding the proceedings void collaterally (emphasis supplied)
16. But in certain cases, motions to set aside Judgments are permitted where,,for instance a
judgment was rendered in ignorance of the fact that a necessary party had not been served at all,
and was wrongly shown as served or in ignorance of the fact that a necessaryD party had died, and
the estate was not represented. Again, a judgment obtained by fraud could be subject to an action
for setting it aside. Where such a judgment obtained by fraud tended to prejudice a non party, as in
the case of judgments in-rem such as for divorce, or jactita tion or probate etc. everl a person, not
eo-nomine a party to the proceedings, could seek a setting-aside of the judgment.
Where a party nas naa no nonce ana a aecree ls maae agamst him, he can approach the court for
setting-aside the decision. In such a case the party is said to become entitled to relief ex-debito
justitiae, on proof of the fact that there was no service. This is a class of cases where there is no trial
at all and the judgment is for default. D.N. Gordan, in his "Actions to set aside judgments." (1961 77
Law Quarterly Review 356) says:
"The more familiar applications to set aside judgments are those made on motion
and otherwise summarily. But there are judgments obtained by default, which do not
represent a judicial determination. In general, Judgments rendered after a trial are
conclusive between the parties unless and until reversed on appeal. Certainly inA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

general judgments of superior courts cannot be overturned or questioned bet ween
the parties in collateral actions. Yet there is a type of collateral action known as an
action of review, by which even a superior court's judgment can be questioned, even
between the parties, and set aside Cases of such frank failure of natural justice are
obvious cases where relief is granted as of right. Where a person is not actually served
but is held erroneously, to have been served, he can agitate that grievance only in that
forum or in any further proceeding therefrom. In Issac's case [ 1984] 3 All ER 140
privy council referred to:
" ....... , .. a category of orders of such a court which a person affected by the order is
entitled to apply to have set aside ex-debito justitiae in exercise of the inherent
jurisdiction of the court without needing to have recourse to the Rules that deal
expressly with proceedings to setaside orders for irregularity and give to the judge a
discretion as to the order he will make".
In the present case by the order dated 5.4.1984 a five judge bench set-out, what according to it, was,
the legal basis and source of jurisdiction to order transfer. On 17.4.1984 appellant's writ petition
challenging that transfer as a nullity was dismissed. These orders are not which appellant is entitled
to have set-aside ex-debito justitiae by another bench. Reliance on the observations in Issac's case is
wholly misplaced.
The decision of the Privy Council in Rajunder Narain Rae v. Bijai Govind Singh, [2 NIA 181]
illustrates the point. Referring to the law on the matter, Lord Brougham said: E "It is
unquestionably the strict rule, and ought to be distinctly understood as such, that no cause in this
Court can be re-heard, and that an order once made, that is, a report submitted to His Majesty and
adopted, by being made an order in Council, is final, and cannot be altered. The same is the case of
the judgments of the House of Lords, that is, of the Court of Parliament, or of the King in Parliament
as it is sometimes expressed, the only other supreme tribunal in this country. Whatever, therefore,
has been really determined in these Courts must stand, there being no power of re-hearing for
purpose of changing the judgment pronounced; nevertheless, if by misprision in embodying the
judgments, errors have been introduced, these Courts possess, by common law, the same power
which the Courts of Record and Statute have of rectifying the mistakes which have crept in. The
Courts of Equity may correct the Decrees made while they are in minutes; when they are complete
they can only vary them by re-hearing; and when they are signed and enrolled they can no longer be
reheard, but they must be altered. if at all, by Appeal. The Courts of Law, after the term in which the
judgments are given can only alter them so as to correct misprisions, a power given by the Statutes
of Amendment. The House of Lords exercises a similar power of rectifying mistakes made in
drawing up its own judgments, and this Court must possess the same authority. The Lords have,
however, gone a step further, and have corrected mistakes introduced through inadvertence in the
details of judgments; or have supplied manifest defects, in order to enable the Decrees to be
enforced, or have added explanatory matter, or have reconciled inconsistencies. But with the
exception of one case in 1669. Of doubtful authority, here, and another in Parliament of still less
weight in 1642 (which was an Appeal from the Privy Council to Parliament, and at a time when the
Government was in an unsettled state), no instance, it is believed, can be produced of a rehearingA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

upon the whole cause., and an entire alteration of the judgment once pronounced.. .."
17. The second class of cases where a judgment is assailed for fraud, is illustrated by the Duchess of
Kingston s case ( 1776 2 Sm. L.C. 644 13th Ed.). ln that case, the Duchess was prosecuted for bigamy
on the allegation that she entered into marriage while her marriage to another person, a certain
Hervey, was still subsisting. In her defence, the Duchess relied upon a decree of jactitation from an
ecclesiastical court which purported to show that she had never been married to Hervey. The
prosecution sought to get over this on the allegation the decree was obtained in a sham and collusive
proceeding. The House of lords held the facts established before Court rendered the decree nugatory
and was incapable of supplying that particular defence. De Grey CJ said that the collusive decree
was not be impeached from within; yet like all other acts of the highest authority, it is impeachable
from without, although it is not permitted to show that the court was mistaken, it may be shown that
they were misled. Fraud which affected the judgment with described by the learned Chief Justice as
an "extrinsic collateral act. which vitiates the most solemn proceedings of courts of justice.. '
18. The argument of nullity is too tall and has no place in this case. The earlier direction proceeded
on a construction of Section 7(1)  Of the Act and Section 407 Cr.P.C. We do not sit here in appeal
over what the five Judge bench said and proclaim how wrong they were. We are, simply, not entitled
to embark, at a later stage, upon an investigation of the correctness of the very same decision. The
same bench can, of course, reconsider the matter under Article 137.
However, even to the extent the argument goes that the High Court under Section 407 Cr.P.C. could
not withdraw to itself a trial from Special-Judge under the 1952 Act, the view of the earlier bench is
a possible view. The submissions of Shri Ram Jethmalani that the exclusivity of the jurisdiction
claimed for the special forum under the 1952 Act is in relation to Courts which would, otherwise, be
Courts of competing or co-ordinate jurisdictions and that such exclusivity does not effect the
superior jurisdiction of the High Court to withdraw, in appropriate situations, the case to itself in
exercise of its extraordinary original criminal jurisdiction; that canons of Statutory- construction,
appropriate to the situation, require that the exclusion of jurisdiction implied in the 1952 amending
Act should not be pushed beyond the purpose sought to be served by the amending law; and that the
law while creating the special jurisdiction did not seek to exclude the extra- ordinary jurisdiction of
the High Court are not without force. The argument, relying upon Kavasji Pestonji Dalal v. Rustor,
Sorabji Jamadar & Anr., AIR 1949 Bombay 42 that while the ordinary competing jurisdictions of
other Courts were excluded, the extraordinary jurisdiction of the High Court was neither intended to
be. nor, in fact, affected, is a matter which would also bear serious examination. In Sir Francis
Bennion's Statutory Interpretation, there are passages at page 433 which referring to presumption
against implied repeal, suggest that in view of the difficulties in determining whether an implication
of repeal was intended in a particular situation it would be a reasonable presumption that where the
legislature desired a repeal, it would have made it plain by express words. In Sutherland Statutory
construction the following passages occur:
"Prior statutes relating to the same subject matter are to be compared with the new
provisions; and if possible by reasonable construction, both are to be so construed
that effect is given to every provision of each. Statutes in pari materia although inA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

apparent conflict, are so far as reasonably possible constructed to be in harmony with
each other."
(Emphasis supplied) "When the legislature enacts a provision, it has before it a 11 the other
provisions relating to the same subject matter which it enacts at that time, whether in the same
statute or in a separate Act. It is evident that it has in mind the provisions of a prior Act to which it
refers, whether it phrases the later Act as amendment or an independent Act. Experience indicates
that a legislature does not deliberately enact inconsistent provisions when it is rec ogzant of them
both, without expressly recognizing the inconsistency. (emphasis supplied) Reliance by Shri Ram
Jethmalani on these principles to support his submission that the power under Section 407 was
unaffected and that the decision in State of Rajasthan v. Gurucharan Das Chadda (supra), can not
also be taken to have concluded the matter, is not un-arguable. I would, therefore, hold contentions
(a) and (b) against appellant.
19 Re: contention (c):
The fundamental right under Article 14, by all reckoning, has a very high place in
constitutional scale of values. Before a person is deprived of his personal liberty, not
only that the Procedure established by law must strictly be complied with and not
departed from to the disadvantage or detriment of the person but also that the
procedure for such deprivation of personal liberty must be reasonable, fair and just.
Article 21 imposes limitations upon the procedure and requires it to conform to such
standards of reasonableness, fairness and justness as the Court acting as sentinel of
fundamental rights would in the context, consider necessary and requisite. The court
will be the arbiter of the question whether the procedure is reasonable, fair and just.
If the operation of Section 407, Cr.P.C. is not impliedly excluded and therefore,
enables the withdrawal of a case by the High Court to itself for trial as, indeed, has
been held by the earlier bench, the argument based on Article 14 would really amount
to a challenge to the very vires of Section 407. All accused persons cannot claim to be
tried by the same Judge. The discriminations-inherent in the choice of one of the
concurrent jurisdictions-are not brought about by an inanimate statutory-rule or by
executive fiat. The withdrawal of a case under Section 407 is made by a conscious
judicial act and is the result of judicial discernment. If the law permits the withdrawal
of the trial to the High Court from a Special Judge, such a law enabling withdrawal
would not, prima facie, be bad as violation of Article 14. The five Judge bench in the
earlier case has held that such a transfer is permissible under law. The appeal to the
principle in Anwar Ali Sarkar's case (supra), in such a context would be somewhat
out of place.
If the law did not permit such a transfer then the trial before a forum which is not
according to law violates the rights of the accused person. In the earlier decision the
transfer has been held to be permissible. That decision has assumed finality.A.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

If appellant says that he is singled out for a hostile treatment on the ground alone
that he is exposed to a trial before a Judge of the . High Court then the submission
has a touch of irony. Indeed that a trial by a Judge of the High Court makes for added
re-assurance of justice, has been recognised in a number of judicial pronouncement.
The argument that a Judge of the High Court may not necessarily possess the
statutory-qualifications requisite for being appointed as a Special Judge appears to be
specious. A judge of the High Court hears appeals arising from the decisions of the
Special Judge, and exercises a jurisdiction which includes powers co-extensive with
that of the trial court. There is, thus, no substance in contention (c).
21. Re: Contention(d):
This grievance is not substantiated on facts; nor, having regard to the subsequent
course of events permissible to be raised at this stage. These directions, it is not
disputed, were issued on 16.2.1984 in the open Court in the presence of appellant's
learned counsel at the time of pronouncement of the judgment. Learned counsel had
the right and the opportunity of making an appropriate submission to the court as to
the permissibility or otherwise of the transfer. Even if the submissions of Shri Ram
Jethmalani that in a revision application Section 403 of the Criminal Procedure Code
does not envisage a right of being heard and that transfer of a case to be tried by the
Judge of the High Court cannot, in the estimate of any right thinking person, be said
to be detrimental to the accused person is not accepted, however, applicant, by his
own conduct, has disentitled himself to make grievance of it in these proceedings. It
cannot be said that after the directions were pronounced and before the order was
signed there was no opportunity for the appellant's learned counsel to make any
submissions in regard to the alleged illegality or impropriety of the directions.
Appellant did not utilise the opportunity. That apart, even after being told by two A
judicial orders that appellant, if aggrieved, may seek a review he did not do so. Even
the grounds urged in the many subsequent proceedings appellant took to get rid of
the effect of the direction do not appear to include the grievance that he had no
opportunity of being heard. Where, as here, a party having had an opportunity to
raise a grievance in the earlier proceedings does not do so and makes it a technicality
later he cannot be heard to complain. Even in respect of so important jurisdiction as
Habeas Corpus, the observation of Gibson J in Re. Tarling l 19791 1 All E.R. 981 at
987 are significant:
"Firstly, it is clear to the Court that an applicant for habeas corpus is required to put
forward on his initial application then whole of the case which is then fairly available
to him he is not free to advance an application on one ground, and to keep back a
separate ground of application as a basis for a second or renewed application to the
Court.
The true doctrine of estoppel known as res judicata does not apply to the decision of
this Court on an application for habeas corpus we refer to the words of Lord ParketA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

CJ delivering the Judgment of the Court in Re. Hastings (No. 2). There is, however, a
wider sense in which the doctrine of res judicata may be applicable, whereby it
becomes an abuse of process to raise in subsequent proceedings matters which could,
and therefore, should have been litigated in earlier proceedings .. "
This statement of the law by Gibson J was approved by Sir John Donaldson MR in
the Court of appeal in Ali v. Secretary of State for the Home Department, [1984] 1 All
E.R. 1009 at 1019.
Rules of natural justice embodies fairness in-action. By all standards, they are great
assurances of Justice and fairness. But they should not be pushed to a breaking point.
It is not inappropriate to recall what Lord Denning said in R. v. Secretary of State for
the Home Department ex-parte Mughal, [1973] 3 All ER 796:
" ... The rules of natural justice must not be stretched too far. Only too often the
people who have done wrong seek to invoke the rules of natural justice so as to avoid
the consequences . "
Contention (d) is insubstantial.
22. Re. Contention (e): A The contention that the transfer of the case to the High
Court involves the elimination of the appellant's right of appeal to the High Court
which he would otherwise have and that the appeal under Article 136 of the
Constitution is not as of right may not be substantial in view of Section 374, Cr. P.C.
which provides such an appeal as of right, when the trial is held by the High Court.
There is no substance in contention (e) either.
23. Re.Contention (f):
The argument is that the earlier order of the five Judge bench in so far as it violates
the fundamental rights of the appellant under Article 14 and 21 must be held to be
void and amenable to challenge under Article 32 in this very Court and that the
decision of this Court in Premchand Garg's case (supra) supports such a position. As
rightly pointed out by Ranganath Misra, J. Premchand Garg's case needs to be
understood in the light of the observations made in Naresh Sridhar Mirajkar & Ors. v.
State of Maharashtra & Anr., [ 1966] 3 SCC 744. In Mirajkar's case, Gajendragadkar,
CJ., who had himself delivered the opinion in Garg's case, noticed the contention
based on Garg's case thus:
"ln support of his argument that a judicial decision can be corrected by this Court in
exercise of its writ jurisdiction under Article 32(2), Mr. Setalvad has relied upon
another decision of this Court in Prem Chand Garg v. Excise Commissioner, UP,
Allahabad (supra) .. "A.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

Learned Chief Justice referring to the scope of the matter that fell for consideration in Garg's case
stated:
".... It would thus be seen that the main controversy in the case of Prem Chand Garg
centered round the question as to whether Article 145 conferred powers on this Court
to make rules, though they may be inconsistent with the constitutional provisions
prescribed by part III. Once it as held that the powers under Article 142 had to be
read subject not only to the fundamental rights, but to other binding statutory
provisions, it became clear that the ruler which authorised the making of the
impugned order was invalid. It was in that context that the validity of the order had
to be incidentally examined. The petition was A made not to challenge the order as
such, but to challenge the validity of the rule under which the order was made
Repelling the contention learned Chief Justice said:
"... It is difficult to see now this decision can be pressed into service by Mr. Setalvad
in support of the argument that a judicial order passed by this Court was held to be
subject to the writ jurisdiction of this Court itself .. "
A passage from Kadish & Kadish "Discretion to Disobey", 1973 Edn. may usefully by recalled:
"on one view, it would appear that the right of a citizen to defy illegitimate judicial
authority should be the same as his right to defy illegitimate legislative authority.
After all, if a rule that transgresses the Constitution or is otherwise invalid is no law
at all and never was one, it should hardly matter whether a court or a legislature
made the rule. Yet the prevailing approach of the courts has been to treat invalid
court orders quite differently from invalid statutes. The long established principle of
the old equity courts was that an erroneously issued injunction must be obeyed until
the error was judicially determined. Only where the issuing court could be said to
have lacked jurisdiction in the sense of authority to adjudicate the cause and to reach
the parties through its mandate were disobedient contemnors permitted to raise the
invalidity of the order as a full defence. By and large, American courts have declined
to treat the unconstitutionality of a court order as a jurisdictional defect within this
traditional equity principle, and in notable instances they have qualified that
principle even where the defect was jurisdiction in the accepted sense."
(See 111).
Indeed Ranganath Misra, J. in his opinion rejected the contention of the appellant in these terms:
"In view of this decision in Mirajkar's case, supra, it must be taken as concluded that
judicial proceedings in this Court are not subject to the writ jurisdiction thereof."
There is no substance in contention (f) either. AA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

24. Contention (g):
It is asserted that the impugned directions issued by the five Judge Bench was
per-incuriam as it ignored the Statute and the earlier Chadda's case. B But the point
is that the circumstance that a decision is reached per-incuriam, merely serves to
denude the decision of its precedent value. Such a decision would not be binding as a
judicial precedent. A co-ordinate bench can disagree with it and decline to follow it. A
larger bench can over rule such decision. When a previous decision is so overruled it
does not happen-nor has the overruling bench any jurisdiction so to do-that the
finality of the operative order, inter-parties, in the previous decision is overturned. In
this context the word 'decision' means only the reason for the previous order and not
the operative- order in the previous decision, binding inter-parties. Even if a previous
decision is overruled by a larger-bench, the efficacy and binding nature, of the
adjudication expressed in the operative order remains undisturbed inter-parties.
Even if the earlier decision of the five Judge bench is per- incuriam the operative part
of the order cannot be interfered within the manner now sought to be done. That
apart the five Judge bench gave its reason. The reason, in our opinion, may or may
not be sufficient. There is advertence to Section 7(1) of the 1952 Act and to the
exclusive jurisdiction created thereunder. There is also reference to Section 407 of
the Criminal Procedure Code. Can such a decision be characterised as one reached
per- incurium? Indeed, Ranganath Misra, J. says this on the point:
"Overruling when made by a larger bench of an earlier decision of a smaller one is
intended to take away the precedent value of the decision without affecting the
binding effect of the decision in the particular case. Antulay, therefore, is not entitled
to take advantage of the matter being before a larger bench .. "
I respectfully agree. Point (g) is bereft of substance and merits.
25. Re: Contention (h):
The argument is that the appellant has been prejudiced by a mistake of the Court and
it is not only within power but a duty as well, H of the Court to correct its own
mistake, so that no party is prejudiced by the Court's mistake: Actus Curiae Neminem
Gravabid.
I am afraid this maxim has no application to conscious conclusions reached in a
judicial decision. The maxim is not a'source of a general power to reopen and rehear
adjudication which have otherwise assumed finality. The maxim operates in a
different and narrow area. The best illustration of the operation of the maxim is
provided by the application of the rule of nunc-pro-tunc. For instance, if owing to the
delay in what the court should, otherwise, have done earlier but did later, a party
suffers owing to events occurring in the interrugnum, the Court has the power to
remedy it. The area of operation of the maxim is. generally, procedural. Errors inA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

judicial findings, either of facts or law or operative decisions consciously arrived at as
a part of the judicial-exercise cannot be interfered with by resort to his maxim. There
is no substance in contention (h).
26. lt is true that the highest court in the land should no., by technicalities of procedure forge fetters
on its own feet and disable itself in cases of serious miscarriages of justice. It is said that "Life of law
is not logic; it has been experience." But it is equally true as Cordozo said: But Holmes did not tell us
that logic is to be ignored when experience is silent. Those who do not put the teachings of
experience and the lessons of logic out of consideration would tell what inspires confidence in the
judiciary and what does not. Judicial vacillations fall in the latter category and undermine respect of
the judiciary and judicial institutions, denuding thereby respect for law and the confidence in the
even-handedness in the administrating of justice by Courts. It would be gross injustice, says an
author, (Miller-'data of jurisprudence') to decide alternate cases on opposite principles. The power
to alter a decision by review must be expressly conferred or necessarily inferred. The power of
review-and the limitations on the power-under Article 137 are implicit recognitions of what would,
otherwise, be final and irrevocable. No appeal could be made to the doctrine of inherent powers of
the Court either. Inherent powers do not confer, or constitute a source of, jurisdiction. They are to
be exercised in aid of a jurisdiction that is already invested. The remedy of the appellant, if any, is
recourse to Article 137; no where else. This appears to me both good sense and good law.
The appeal is dismissed.
RANGANATHAN, J. 1. I have had the benefit of perusing the drafts of the judgments proposed by
my learned brothers Sabyasachi Mukharji, Ranganath Misra and Venkatachaliah, JJ. On the
question whether the direction given by this Court in its judgment dated 16.2.1984 should be
recalled, I find myself in agreement with the conclusion of Venkatachaliah, J. (though for slightly
different reasons) in preference to the conclusion reached by Sabyasachi Mukharji, J. and
Ranganath Misra, J. I would, therefore, like to set out my views separately on this issue.
THE ISSUES
1. This is an appeal by special leave from a judgment of Shah J., of the Bombay High Court. The
appellant is being tried for offences under Ss. 120B, 420, 161 and 165 of the Indian Penal Code
(I.P.C.) read with S. 5(1)(d) and 5(2) of the Prevention of Corruption Act, 1947. The proceedings
against the appellant were started in the Court of Sri Bhutta, a Special Judge, appointed under S.
6(1) of the Criminal Law (Amendment) Act, 1952 (hereinafter referred to as 'the 1952 Act'). The
proceedings have had a chequered career as narrated in the judgment of my learned brother
Sabyasachi Mukharji, J. Various issues have come up for consideration of this Court at the earlier
stages of the proceedings and the judgments of this Court have been reported In 1982 2 S.C.C. 463,
1984 2 SCR 495, 1984 2 SCR 914, 1984 3 SCR 412, 1984 3 SCR 482 and 1986 2 S.C.C. 716. At present
the appellant is being tried by a learned Judge of the Bombay High Court nominated by the Chief
Justice of the Bombay High Court in pursuance of the direction given by this Court in its order dated
16.2.1984 (reported in 1984 2 SCR 495). By the order presently under appeal, the learned Judge (s)
framed as many as 79 charges against the appellant and (b) rejected the prayer of the appellant thatA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

certain persons, named as co-conspirators of the appellant in the complaint on the basis of which
the prosecution has been launched should be arrayed as co-accused along with him. But the
principal contention urged on behalf of the appellant before us centres not round the merits of the
order under appeal on the above two issues but round what the counsel for the appellant has
described as a fundamental and far- reaching objection to the very validity of his trial before the
learned Judge. As already stated, the trial is being conducted by the learned Judge pursuant to the
direction of this Court dated 16.2.1984. The contention of the learned counsel is that the said
direction is per incuriam, illegal, invalid, contrary to the principles of natural justice and violative of
the fundamental rights of the petitioner. This naturally raises two important issues for our
consideration:
A. Whether the said direction is inoperative, invalid or illegal, as alleged; and B.
Whether, if it is, this Court can and should recall, withdraw, revoke or set aside the
same in the present proceedings.
Since the issues involve a review or reconsideration of a direction given by a Bench of
five judges of this Court, this seven-judge Bench has been constituted to hear the
appeal.
2. It is not easy to say which of the two issues raised should be touched upon first as, whichever one
is taken up first, the second will not arise for consideration unless the first is answered in the
affirmative. However, as the correctness of the direction issued is impugned by the petitioner, as
there is no detailed discussion in the earlier order on the points raised by the petitioner, and as
Sabyasachi Mukharji, J. has expressed an opinion on these contentions with parts of which I am
unable to agree, it will be perhaps more convenient to have a look at the first issue as if it were
coming up for consideration for the first time before us and then, depending upon the answer to it,
consider the second issue as to whether this Court has any jurisdiction to recall or revoke the earlier
order. The issues will, therefore, be discussed in this order.
A. ARE THE DIRECTIONS ON 16.2.1984 PROPER, VALID AND LEGAL?
3. For the appellant, it is contended that the direction given in the last para of the order of the Bench
of five Judges dated 16.2.1984 (extracted in the judgment of Sabyasachi Mukharji, J.) is vitiated by
illegality, irregularity and lack of jurisdiction on the following grounds:
(i) Conferment of jurisdiction on courts is the function of the legislature. It was not
competent for this Court to confer jurisdiction on a learned Judge of the High Court
to try the appellant, as, under the 1952 Act, an offence of the type in question can be
tried only by a special Judge appointed thereunder. This has been overlooked while
issuing the direction which is, therefore, per incuriam.
(ii) The direction above-mentioned (a) relates to an issue which was not before the
Court (b) on which no arguments were addressed and (c) in regard to which the
appellant had no opportunity to make his submissions.A.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

It was nobody's case before the above Bench that the trial of the accused should no longer be
conducted by a Special Judge but should be before a High Court Judge.
(iii) In issuing the impugned direction, the Bench violated the principles of natural justice, as
mentioned above. It also overlooked that, as a result thereof, the petitioner (a) was discriminated
against by being put to trial before a different forum as compared to other public servants accused of
similar offences and (b) lost valuable rights of revision and first appeal to the High Court which he
would have had, if tried in the normal course.
The direction was thus also violative of natural justice as well as the fundamental rights of the
petitioner under Article 14 and 21 of the Constitution.
Primary Jurisdiction
4. There can be-and, indeed, counsel for the respondent had-no quarrel with the initial premise of
the learned counsel for the appellant that the conferment of jurisdiction on courts is a matter for the
legislature. Entry 77 of List I, entry 3 of List II and entries 1, 2, 11A and 46 of List III of the Seventh
Schedule of the Constitution set out the respective powers of parliament and the State Legislatures
in that regard. It is common ground that the jurisdiction to try offences of the type with which are
concerned here is vested by the 1952 Act in Special Judges appointed by the respective State
Governments. The first question that has been agitated before us is whether this Court was right in
transferring the case for trial from the Court of a Special Judge, to a Judge nominated by the Chief
Justice of Bombay.
High Court's Power of Transfer
5. The power of the Supreme Court to transfer cases can be traced, in criminal matters, either to Art.
139A of the Constitution or Section 406 of the Code of Criminal Procedure ("Cr. P.C.), 1973. Here,
again, it is common ground that neither of these provisions cover the present case. Sri Jethmalani,
learned counsel for the respondent, seeks to support the order of transfer by reference to Section
407 (not Section 406) of the Code and cl. 29 of the Letters Patent of the Bombay High Court. Section
407 reads thus:
(1) Whenever it is made to appear to the High Court-
(a) that a fair and impartial inquiry or trial cannot be had in any Criminal Court
subordinate thereto, or
(b) that some question of law of unusual difficulty is likely to arise, or
(c) that an order under this section is required by any provision of this Code, or will
tend to the general convenience of the parties or witnesses, or is expedient for the
ends of justice, it may order-A.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

(i) that any offence be inquired into or tried by any Court not qualified under Section
177 to 185 (both inclusive), but in other respects competent to inquire into or try such
offences;
(ii) that any particular case or appeal, or class of cases or appeals, be transferred from
a Criminal Court subordinate to its authority to any other such Criminal Court of
equal or superior jurisdiction;
(iii) that any particular case be committed for trial to a Court of Session; or
(iv) that any particular case or appeal be transferred to and tried before itself.
(2) the High Court may act either on the report of the lower court or on the
application of a party interested or on its own initiative:
     XXX                    XXX                          XXX
     XXX                    XXX                          XXX
     XXX                    XXX                          XXX
(9) Nothing in this section shall be deemed to affect any order of Government under
Section 197."
And cl. 29 of the Letters Patent of the Bombay High Court runs thus:
"And we do further ordain that the said High Court shall have power to direct the
transfer of any criminal case or appeal from any Court to any other Court of appeal or
superior jurisdiction, and also to direct the preliminary investigation of trial of any
criminal case by any officer of Court otherwise competent to investigate or try it
though such case belongs, in ordinary course, to the jurisdiction of some other
officer, of Court."
The argument is that this power of transfer vested in the High Court can well be exercised by the
Supreme Court while dealing with an appeal from the High Court in the case.
6. For the appellant, it is contended that the power of transfer under section 407 cannot be invoked
to transfer a case from a Special Judge appointed under the 1952 Act to the High Court. Learned
counsel for the appellant contends that the language of section 7(1) of the Act is mandatory; it
directs that offences specified in the Act can be tried only by persons appointed, under S. 6(2) of the
Act, by the State Government, to be special judges, No other Judge, it is said, has jurisdiction to try
such a case, even if he is a Judge of the High Court. In this context, it is pointed out that a person, to
be appointed as a special Judge, under section 6(2) of the 1952 Act, should be one who is, or has
been, a Sessions Judge (which expression in this context includes an Additional Sessions Judge
and/or an Assistant Sessions Judge). All High Court Judges may not have been Sessions Judges
earlier and, it is common ground, Shah, J. who has been nominated by the Chief Justice for trying
this case does not fulfill the qualifications prescribed for appointment as a Special Judge. But, thatA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

consideration apart, the argument is that, while a High Court can transfer a case from one special
judge to another, and the Supreme Court, from a special judge in one State to a special judge in
another State, a High Court cannot withdraw a case from a Special Judge to itself and the Supreme
Court cannot transfer a case from a Special Judge to the High Court.
7. On the other hand, it is contended for the respondent that the only purpose of the 1952 Act is to
ensure that cases of corruption and bribery do not get bogged up in the ordinary criminal courts
which are over- burdened with all sorts of cases. Its object is not to create special courts in the sense
of courts manned by specially qualified personnel or courts following any special type of procedure.
All that is done is to earmark some of the existing sessions judges for trying these offences
exclusively. The idea is just to segregate corruption and bribery cases to a few of the sessions judges
so that they could deal with them effectively and expeditiously. It is a classification in which the
emphasis is on the types of offences and nature of offenders rather than on the qualifications of
judges. That being so, the requirement in section 7(1) that these cases should be tried by special
judges only is intended just to exclude their trial by the other normal criminal courts of coordinate
jurisdiction and not to exclude the High Court.
8. Before dealing with these contentions, it may be useful to touch upon the question whether a
judge of a High Court can be appointed by the State Government as a special judge to try offences of
the type specified in section 6 of the 1952 Act. It will be seen at once that not all the judges of the
High Court (but only those elevated from the State subordinate judiciary) would fulfill the
qualifications prescribed under section 6(2) of the 1952 Act. Though there is nothing in ss. 6 and 7
read together to preclude altogether the appointment of a judge of the High Court fulfilling the
above qualifications as a special judge, it would appear that such is not the (atleast not the normal)
contemplation of the Act. Perhaps it is possible to argue that, under the Act, it is permissible for the
State Government to appoint one of the High Court Judges (who has been a Sessions Judge) to be a
Special Judge under the Act. If that had been done, that Judge would have been a Special Judge and
would have been exercising his original jurisdiction in conducting the trial. But that is not the case
here. In response to a specific question put by us as to whether a High Court Judge can be appointed
as a Special Judge under the 1952 Act, Shri Jethmalani submitted that a High Court Judge cannot be
so appointed. I am inclined to agree. The scheme of the Act, in particular the provision contained in
ss. 8(3A) and 9, militate against this concept. Hence, apart from the fact that in this case no
appointment of a High Court Judge, as a Special Judge, has in fact been made, it is not possible to
take the view that the statutory provisions permit the conferment of a jurisdiction to try this case on
a High Court Judge as a Special Judge.
9. Turning now to the powers of transfer under section 407, one may first deal with the decision of
this Court in Gurucharan Das Chadha v. State of Rajasthan, [1966] 2 S.C.R. 678 on which both
counsel strongly relied. That was a decision by three judges of this Court on a petition under section
527 of the 1898 Cr.P.C. (corresponding to section 406 of the 1973 Cr.P.C.). The petitioner had
prayed for the transfer of a case pending in the court of a Special Judge in Bharatpur, Rajasthan to
another criminal court of equal or superior jurisdiction subordinate to a High Court other than the
High Court of Rajasthan. The petition was eventually dismissed on merits. But the Supreme Court
dealt with the provisions of section 527 of the 1898 A Cr.P.C. in the context of an objection taken byA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

the respondent State that the Supreme Court did not have the jurisdiction to transfer a case pending
before the Special Judge, Bharatpur. The contention was that a case assigned by the State
Government under the 1952 Act to a Special Judge cannot be transferred at all because, under the
terms of that Act, which is a self-contained special law, such a case must be tried only by the
designated Special Judge. The Court observed that the argument was extremely plausible but not
capable of bearing close scrutiny. After referring to the provisions of section 6, 7 and 8 of the 1952
Act, the Court set out the arguments for the State thus:
"The Advocate-General, Rajasthan, in opposing the petition relies principally on the
provisions of section 7(1) and 7(2) and contends that the two sub-sections create two
restrictions which must be read together. The first is that offences specified in section
6(1) can be tried by Special Judges only. The second is that every such offence shall
be tried by the Special Judge for the area within which it is committed and if there
are more special judges in that area by the Special Judge chosen by the Government.
These two conditions, being statutory, it is submitted that no order can be made
under section 527 because, on transfer, even if a special judge is entrusted with the
case, the second condition is bound to be broken."
Dealing with this contention the Court observed:
"This condition, if literally understood, would lead to the conclusion that a case once
made over to a special Judge in an area where there is no other special Judge, cannot
be transferred at all. This could hardly have been intended. If this were so, the power
to transfer a case intra-state under s. 526 of the Code of Criminal Procedure, on a
parity of reasoning, must also be lacking. But this Court in Ramachandra Parsad v.
State of Bihar, [1962] 2 S.C.R. 50 unheld the transfer of a case by the High Court
which took it to a special judge who had no jurisdiction in the area where the offence
was committed. In holding that the transfer was valid this Court relied upon the third
sub-section of Section 8 of the Act. That sub-section preserves the application of any
provision of the Code of Criminal Procedure it it is not inconsistent with the Act, save
as provided in the first two sub-sections of that section. The question, therefore,
resolves itself to this: Is there an inconsistency between S. 527 of the Code and the
second sub-section of S. 7? The answer is that there is none. Apparently this Court in
the earlier case found no inconsistency and the reasons appear to be there: The
condition that an offence specified in S. 6(2) shall be tried by a special Judge for the
area within which it is committed merely specifies which of several special Judges
appointed in the State by the State Government shall try it. The provision is
analogous to others under which the jurisdiction of Magistrates and Sessions Judges
is deter mined on a territorial basis. Enactments in the Code of Criminal Procedure
intended to confer territorial jurisdiction upon courts and Presiding officers have
never been held to stand in the way of transfer of criminal cases outside those areas
of territorial jurisdiction. The order of transfer when it is made under the powers
given by the Code invests another officer with jurisdiction although ordinarily he
would lack territorial jurisdiction to try the case. The order of this Court, therefore,A.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

which transfer(s) a case from one special Judge subordinate to one High Court to
another special Judge subordinate to another High Court creates jurisdiction in the
latter in much the same way as the transfer by the High Court from one Sessions
Judge in a Session Division to another Sessions Judge in another Sessions Division.
There is no comparison between the first sub- section and the second sub-section of
Section 7. The condition in the second sub-section of S. 7 is not of the same character
as the condition in the first sub-section. The first sub-section creates a condition
which is a sine qua non for the trial of certain offences. That condition is that the trial
must be before a special Judge. The second sub- section distributes the work between
special Judges and lays emphasis on the fact that trial must be before a special Judge
appointed for the area in which the offence is committed. This second condition is on
a par with the distribution of work territorially between different Sessions Judges and
Magistrates. An order of transfer, by the very nature of things must, some times,
result in taking the case out of the territory and the provisions of the Code which are
preserved by the third sub-
section of S. 8 must supervene to enable this to be done and the second sub-section of
S. 7 must yield. We do not consider that this creates any inconsistency because the
territorial jurisdiction created by the second sub-section of S. 7 operates in a different
sphere and under different circumstances. Inconsistency can only be found if two
provisions of law apply in identical circumstances and create contradictions. Such a
situation does not arise when either this Court or the High Court exercises its powers
of transfer. We are accordingly of the opinion that the Supreme Court in exercise of
its jurisdiction and power under S. 527 of the Code of Criminal Procedure can
transfer a case from a Special Judge subordinate to the High Court to another special
Judge subordinate to another High Court. "
(emphasis added)
10. The attempt of Sri Jethmalani is to bring the present case within the scope of the observations
contained in the latter part of the extract set out above. He submits that a special judge, except
insofar as a specific provision to the contrary is made, is a court subordinate to the High Court, as
explained in 1984 2 S.C.R. 914 (at pages 943-4) and proceedings before him are subject to the
provisions of the 1973 Cr.P.C.; the field of operation of the first sub- section of section 7 is merely to
earmark certain Sessions Judges for purposes of trying cases of corruption by public servants and
this provision is, in principle, not different from the earmarking of cases on the basis of territorial
jurisdiction dealt with by sub-section 2 of section 7. The argument is no doubt a plausible one. It
does look somewhat odd to say that a Sessions Judge can, but a High Court Judge cannot, try an
offence under the Act. The object of the Act, as rightly pointed out by counsel, is only to segregate
certain cases to special courts which will concentrate on such cases so as to expedite their disposal
and not to oust the superior jurisdiction of the High Court or its powers of superintendencet over
subordinate courts under article 227 of the Constitution, an aspect only of which is reflected in s.
407 of the Cr.P.C. However, were the matter to be considered as res integra, I would be inclined toA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

accept the contention urged on behalf of the appellant, for the following reasons. In the first place,
the argument of the counsel for the respondent runs counter to the observations made by the
Supreme Court in the earlier part of the extract set out above that the first sub-section of section 7
and the second sub-section are totally different in character. The first sub-section deals with a sine
qua non for the trial of certain offences, whereas the second sub-section is only of a pro-
cedural nature earmarking territorial jurisdiction among persons competent to try the offence. They
are, therefore, vitally different in nature. The Supreme Court has clearly held in the passage
extracted above that the case can be transferred only from one special judge to another. In other
words, while the requirement of territorial jurisdiction is subordinate to S. 406 or 407, the
requirement that the trial should be by a special judge is not. It is true that those observations are
not binding on this larger Bench and moreover the Supreme Court there was dealing only with an
objection based on sub-section (2) of Section 7. It is, however, clear that the Bench, even if it had
accepted the transfer petition of Gurcharan Das Chadha, would have rejected a prayer to transfer
the case to a court other than that of a Special Judge appointed by the transferee State. I am in
respectful agreement with the view taken in that case that there is a vital qualitative difference
between the two sub-sections and that while a case can be transferred to a special judge who may
not have the ordinary territorial jurisdiction over it, a transfer cannot be made to an ordinary
magistrate or a court of session even if it has territorial jurisdiction. If the contention of the learned
counsel for the respondent that s. 7(1) and s. 407 operate in different fields and are not inconsistent
with each other were right, it should be logically possible to say that the High Court can, under s.
407, transfer a case from a special judge to any other Court of Session. But such a conclusion would
be clearly repugnant to the scheme of the 1952 Act and plainly incorrect. It is, therefore, difficult to
accept the argument of Sri Jethmalani that we should place the restriction contained in the first
sub-section of section 7 also as being on the same footing as that in the second sub- section and hold
that the power of transfer contained in the Criminal Procedure Code can be availed of to transfer a
case from a Special Judge to any other criminal court or even the High Court. The case can be
transferred only from one special judge to another special judge; it cannot be transferred even to a
High Court Judge except where a High Court Judge is appointed as a Special Judge. A power of
transfer postulates that the court to which transfer or withdrawal is sought is competent to exercise
jurisdiction over the case. (vide, Raja Soap Factory v. Shantaraj, [1965] 2 S.C.R. 800).
11. This view also derives support from two provisions of S. 407 itself. The first is this. Even when a
case is transferred from one criminal court to another, the restriction as to territorial jurisdiction
may be infringed. To obviate a contention based on lack of territorial jurisdiction in the transferee
court in such a case, clause
(ii) of s. 407 provides that the order of transfer will prevail, lack of jurisdiction under Ss. 177 to 185
of the Code notwithstanding. The second difficulty arises, even under the Cr.P.C. itself, by virtue of
S. 197 which not only places restriction on the institution of certain prosecutions against public
servants without Government sanction but also empowers the Government, inter alia, to determine
the court before which such trial is to be conducted. When the forum of such a trial is transferred
under s. 407 an objection may be taken to the continuance of the trial by the transferee court based
on the order passed under s. 197. This eventuality is provided against by s. 407(9) of the Act whichA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

porvides that nothing in s. 407 shall be deemed to affect an order passed under s. 407. Although
specifically providing for these contingencies, the section is silent in so far as a transfer from the
court of a Special Judge under the 1952 Act is concerned though it is a much later enactment.
12. On the contrary, the language of s. 7(1) of the 1952 Act places a definite hurdle in the way of
construing s. 407 of the Cr.P.C. as overriding its provisions. For, it opens with the words:
"Notwithstanding anything contained in the Code of Criminal Procedure, 1898 or in
any other law".
In view of this non-obstanti clause also, it becomes difficult to hold that the provisions of section
407 of the 1973 Cr.P.C. will override, or even operate consistently with, the provisions of the 1952
Act. For the same reason it is not possible to hold that the power of transfer contained in clause 29
of the Letters Patent of the Bombay High Court can be exercised in a manner not contemplated by
section 7(1) of the 1952 Act.
13. Thirdly, whatever may be the position where a case is transferred from one special judge to
another or from one ordinary subordirate criminal court to another of equal or superior jurisdiction,
the withdrawal of a case by the High Court from such a Court to itself for trial places certain
handicaps on the accused. It is true that the court to which the case has been transferred is a
superior court and in fact, the High Court. Unfortunately, however, the high Court judge is not a
person to whom the trial of the case can be assigned under s. 7(1) of the 1952 Act. As pointed out by
the Supreme Court in Surajmal Mohta v. Viswanatha Sastry, [1955] 1 S.C.R. 448 at pp. 464 in a
slightly different context, the circumstance that a much superior forum is assigned to try a case than
the one normally available cannot by itself be treated as a "sufficient safeguard and a good
substitute" for the normal forum and the rights available under the normal procedure. The accused
here loses his right of coming up in revision or appeal to the High Court from the interlocutory and
final orders of the trial court. He loses the right of having two courts-a subordinate court and the
High Court- adjudicate upon his contentions before bringing the matter up in the Supreme Court.
Though, as is pointed out later, these are not such handicaps as violate the fundamental rights of
such an accused, they are circumstances which create prejudice to the accused and may not be
overlooked in adopting one construction of the statute in preference to the other.
14. Sri Jethmalani vehemently contended that the construction of s. 407 sought for by the appellant
is totally opposed to well settled canons of statutory construction. He urged that the provisions of
the 1952 Act should be interpreted in the light of the objects it sought to achieve and its amplitude
should not be extended beyond its limited objective. He said that a construction of the Act which
leads to repugnancy with, or entails pro tanto repeal of, the basic criminal procedural law and seeks
to divest jurisdiction vested in a superior court should be avoided. These aspects have been
considered earlier. The 1952 Act sought to expedite the trial of cases involving public servants by the
creation of courts presided over by experienced special judges to be appointed by the State
Government. There is however nothing implausible in saying that the Act having already earmarked
these cases for trial by experienced Sessions Judges made this provision immune against the
applicability of the provisions of other laws in general and the Cr.P.C. in particular. Effect is onlyA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

being given to these express and specific words used in section 7(1) and no question arises of any
construction being encouraged that is repugnant to the Cr.P.C. Or involves an implied repeal, pro
tanto, of its provisions. As has already been pointed out, if the requirement in s. 7(1) were held to be
subordinate to the provisions contained in s. 406-7, then in principle, even a case falling under the
1952 Act can be transferred to any other Sessions Judge and that would defeat the whole purpose of
the Act and is clearly not envisaged by it.
Supreme Court's power of transfer
15. It will have been noticed that the power of transfer under section 407 or cl. 29 of the Letters
Patent which has been discussed above is a power vested in the High Court. So the question will
arise whether, even assuming that the High Court could have exercised such power, the Supreme
Court could have done so. On behalf of the respondent, it was contended that, as the power of the
High Court under s. 407 can be exercised on application of a party or even suo motu and can be
exercised by it at any stage irrespective of whether any application or matter in connection with the
case is pending before it or not, the Supreme Court, as an appellate Court, has a co-equal
jurisdiction to exercise the power of transfer in the same manner as the High Court could. In any
event, the Supreme Court could exercise the power as one incidental or ancillary to the power of
disposing of a revision or appeal before it. The appellants, however, contend that, as the power of
the Supreme Court to order transfer of cases has been specifically provided for in section 406 and
would normally exclude cases of intra-state transfer covered by section 407 of the Code, the statute
should not be so construed as to imply a power of the Supreme Court, in appeal or revision, to
transfer a case from a subordinate court to the High Court. The argument also is that what the
Supreme Court, as an appellate or revisional court, could have done was either (a) to direct the High
Court to consider whether this was a fit case for it to exercise its power under section 407(1)(iv) to
withdraw the case to itself and try the same with a view to expeditiously dispose it of or (b) to have
withdrawn the case to itself for trial. But, it is contended, no power which the Supreme Court could
exercise as an appellate or revisional court could have enabled the Supreme Court to transfer the
case from the Special Judge to the High Court.
16. Here also, the contentions of both parties are nicely balanced but I am inclined to think that had
the matter been res integra and directions for transfer were being sought before us for the first time,
this Court would have hesitated to issue such a direction and may at best have left it to the High
Court to consider the matter and exercise its own discretion. As already pointed out, the powers of
the Supreme Court to transfer cases from one court to another are to be found in Article 139-A of the
Constitution and section 406 of the Cr.P.C. The provisions envisaged either inter-state transfers of
cases i.e. from a court in one State to a court in another State or the withdrawal of a case by the
Supreme Court to itself. Intra- State transfer among courts subordinate to a High Court inter-se or
from a court subordinate to a High Court to the High Court is within the jurisdiction of the
appropriate High Court. The attempt of counsel for the resondent is to justify the transfer by
attributing the powers of the High Court under section 407 to the Supreme Court in its capacity as
an appellate or revisional court. This argument overlooks that the powers of the Supreme Court, in
disposing of an appeal or revision, are circumscribed by the scope of the proceedings before it. In
this case, it is common ground that the question of transfer was not put in issue before the SupremeA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

Court.
17. The reliance placed in this context on the provisions contained in articles 140 and 142 of the
Constitution and S. 401 read with S. 386 of the Cr.P.C. does not also help. Article 140 is only a
provisions enabling Parliament to confer supplementary powers on the Supreme Court to enable it
to deal more effectively to exercise the jurisdication conferred on it by or under the Constitution.
Article 142 is also not of much assistance. In the first place, the operative words in that article, again
are "in the exercise of its jurisdiction." The Supreme Court was hearing an appeal from the order of
discharge and connected matters. There was no issue or controversy or discussion before it as to the
comparative merits of a trial before a special judge vis-a-vis one before the High Court. There was
only an oral request said to have been made, admittedly, after the judgment was announced. Wide
as the powers under article 141 are, they do not in my view, envisage an order of the type presently
in question. The Nanavati case (1961 SCR 497, to which reference was made by Sri Jethmalani,
involved a totally different type of situation. Secondly, it is one of the contentions of the appellant
that an order of this type, far from being necessary for doing complete justice in the cause or matter
pending before the Court, has actually resulted in injustice, an aspect discussed a little later. Thirdly,
however wide and plenary the language of the article, the directions given by the Court should not
be inconsistent with, repugnant to or in violation of the specific provisions of any statute. If the
provisions of the 1952 Act read with article 139-A and Ss.406-407 of the Cr.P.C. do not permit the
transfer of the case from a special judge to the High Court, that effect cannot be achieved indirectly.
it is, therefore, difficult to say, in the circumstances of the case, that the Supreme Court can issue the
impugned direction in exercise of the powers under Article 142 or under s. 407 available to it as an
appellate court.
18. Learned counsel for the complainant also sought to support the order of transfer by reference to
section 386 and 401 of the 1973 Cr.P.C. He suggested that the Court, having set aside the order of
discharge, had necessarily to think about consequential orders and that such directions as were
issued are fully justified by the above provisions. He relied in this context on the decision of the
Privy Council in Hari v. Emperor, AIR 1935 P.C.122. It is difficult to accept this argument. Section
401 provides that, in the revision pending before it, the High Court can exercise any of the powers
conferred on a court of appeal under section 386. Section 386, dealing with the powers of the
appellate court enables the court, in a case such as this: (i) under clause (a), to alter or reverse the
order under appeal/revision; or (ii) under clause (e), to make any amendment or any consequential
or incidental order that may be just or proper. The decision relied on by counsel, Hari v. Emperor,
AIR 1935 P.C. 122, is of no assistance to him. In that case, the Additional Judicial Commissioner,
who heard an appeal on a difference of opinion between two other judicial commissioner had come
to the conclusion that the conviction had to be set aside. Then he had the duty to determine what
should be done and S. 426 of the 1898 Cr.P.C. (corresponding to section 386 of the 1973 Cr.P.C.)
exactly provided for the situation and empowered him:
"to reverse the finding and sentence and acquit or discharge the accused or order him
to be retried by a court of competent jurisdiction subordinate to such apellate Court."A.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

In the present case, the Special Judge. Sri Sule, had discharged the accused because of his
conclusion, that the prosecution lacked the necessary sanction. The conclusion of the Supreme
Court that this conclusion was wrong meant, automatically, that the prosecution had been properly
initiated and that the proceedings before the Special Judge should go on. The direction that the trial
should be shifted to the High Court can hardly be described as a consequential or incidental order.
Such a direction did not flow, as a necessary consequence of the conclusion of the court on the issues
and points debated before it. I am, therefore, inclined to agree with counsel for the appellant that
this Court was in error when it directed that the trial of the case should be before a High Court
Judge.
19. It follows from the above discussion that the appellant, in consequence of the impugned
direction, is being tried by a 'Court which has no jurisdiction-and which cannot be empowered by
the Supreme Court-to try him. The continued trial before the High Court, therefore, infringes Article
21 of the Constitution.
Denial of equality and violation of Article 21.
20. It was vehemently contended for the appellant that, by giving the impugned direction, this Court
has deprived the appellant of his fundamental rights. He has been denied a right to equality,
inasmuch as his case has been singled out for trial by a different, though higher, forum as compared
to other public servants. His fundamental right under Article 21, it is said, has been violated,
inasmuch as the direction has deprived him of a right of revision and first appeal to the High Court
which he would have had from an order or sentence had he been tried by a Special Judge and it is
doubtful whether he would have a right to appeal to this Court at all. It is pointed out that a right of
first appeal against a conviction in a criminal case has been held, by this Court, to be a part of the
fundamental right guaranteed under Article 21 of the Constitution. It is not necessary for me to
consider these arguments in view of my conclusion that the High Court could not have been directed
to try the petitioner's case. I would, however, like to say that, in my opinion, the arguments based on
Articles 14 and 21 cannot be accepted, in case it is to be held for any reason that the transfer of the
apellant's case to the High Court was valid and within the competence of this Court. I say this for the
following reason: If the argument is to be accepted, it will be appreciated, it cannot be confined to
cases of transfer to the High Court of cases under the 1952 Act but would also be equally valid to
impugn the withdrawal of a criminal case tried in the normal course under the Cr.P.C. from a
subordinate court trying it to the High Court by invoking the powers under section 407. To put it in
other words, the argument, in substance, assails the validity of secion 407 of the 1973 Cr.P.C. In my
opinion, this attack has to be repelled. The section cannot be challenged under Article 14 as it is
based on a reasonable classification having relation to the objects sought to be achieved. Though, in
general, the trial of cases will be by courts having the normal jurisdiction over them, the exigencies
of the situation may require that they be dealt with by some other court for various reasons.
Likewise, the nature of a case, the nature of issues involved and other circumstances may render it
more expedient, effective, expeditious or desirable that the case should be tried by a superior court
or the High Court itself. The power of transfer and withdrawal contained in s. 407 of the Cr.P.C. is
one dictated by the requirements of justice and is, indeed, but an aspect of the supervisory powers of
a superior court over courts subordinate to it: (see also sections 408 to 411 of the Cr.P.C.). A judicialA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

discretion to transfer or withdraw is vested in the highest court of the State and is made exercisable
only in the circumstances set out in the section. Such a power is not only necessary and desirable but
indispensable in the cause of the administration of justice. The accused will continue to be tried by a
court of equal or superior jurisdiction. Section 407(8) read with S. 474 of the Cr.P.C. and section
8(3) of the 1952 Act makes it clear that he will be tried in accordance with the procedure followed by
the original Court or ordinarily by a Court of Session. The accused will, therefore, suffer no prejudice
by reason of the application of s. 407. Even if there is a differential treatment which causes
prejudice, it is based on logical and acceptable considerations with a view to promote the interest of
justice. The transfer or withdrawal of a case to another court or the High Court, in such
circumstances, can hardly be said to result in hostile discrimination against the accused in such a
case.
21. Considerable reliance was placed on behalf of the appellant on State v. Anwar Ali Sarkar, [1952]
S.C.R. 284. This decision seems to have influenced the learned judges before whom this appeal first
came up for hearing in referring the matter to this larger Bench and has also been aplied to the facts
and situation here by my learned brother, Sabyasachi Mukharji, J. But it seems to me that the said
decision has no relevance here. There, the category of cases which were to be allocated to a Special
Judge were not well defined; the selection of cases was to be made by the executive; and the
procedure to be followed by the special courts was different from the normal criminal procedure. As
already pointed out, the position here is entirely different. The 1952 legislation has been enacted to
give effect to the Tek Chand Committee and to remedy a state of affairs prevalent in respect of a well
defined class of offences and its provisions constituting special judges to try offences of corruption is
not under challenge. Only a power of transfer is being exercised by the Supreme Court which is
sought to be traced back to the power of the High Court under s. 407. The vires of that provision also
is not being challenged. What is perhaps being said is that the Supreme Court ought not to have
considered this case a fit one for withdrawal for trial to the High Court. That plea should be and is
being considered here on merits but the plea that Article 14 has been violated by the exercise of a
power under s. 407 on the strength of Anwar Ali Sarkar's case wholly appears to be untenable.
Reference may be made in this context to Kathi Raning Rawat v. The State of Saurashtra, [1952] 3
S.C.R. 435 and Re: Special Courts Bill, 1978, [1979] 2 S.C.R. 476 and Shukla v. Delhi Administration,
[1980] 3 S.C.R. 500, which have upheld the creation of special judges to try certain classes of
offences.
22. It may be convenient at this place to refer to certain observations by the Bench of this Court,
while referring this matter to the larger Bench, in a note appended to their order on this aspect. The
learned Judges have posed the following questions in paragraphs 4 and 6 of their note:
"4. The Criminal Law Amendment Act, 1952 as its preamble says is passed to provide
for speedier trial? Does not further speeding up of the case by transferring the case to
the High Court for speedy disposal violate the principle laid down by seven learned
Judges of this Court in Anwar Ali Sarkar's case (1952) S.C.R. 284 and result in
violation of Article 14 of the Constitution? The following observations of Vivian Bose,
J. in Anwar Ali Sarkar's case at pages 366-387 of the Report are relevant:A.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

'Tested in the light of these considerations, I am of opinion that the whole of the West
Bengal Special Courts Act of 1950 offends the provisions of Article 14 and is therefore
bad. When the froth and the foam of discussion is cleared away and learned dialectics
placed on one side, we reach at last the human element which to my mind is the most
important of all. We find men accused of heinous crimes called upon to answer for
their lives and liberties. We find them picked out from their fellows, and however
much the new procedure may give them a few crumbs of advantage, in the bulk they
are deprived of substantial and valuable privileges of defence which others, similarly
charged, are able to claim. It matters not to me, nor indeed to them and their families
and their friends, whether this be done in good faith, whether it be done for the
convenience of government, whether the process can be scientifically classified and
labelled, or whether it is an experiment in speedier trials made for the good of society
at large. It matters now how lofty and laudable the motives are. The question with
which I charge myself is, can fair-minded, reasonable, unbiassed and resolute men,
who are not swayed by emotion or prejudice, regard this with equanimity and call it
reasonable, just and fair, regard it as that equal treatment and protection in the
defence of liberties which is expected of a sovereign democratic republic in the
conditions which obtain in India today? I have but one answer to that. On that short
and simple ground I would decide this case and hold the Act bad.' (Underlining by
us) Do not the above observations apply to judicial orders also?
6. Does the degree of heinousness of the crime with which an accused is charged or
his status or the influence that he commands in society have any bearing on the
applicability or the constriction of Article 14 or Article 21.?"
23. In my opinion, the answers to the questions posed will, again, depend on whether the impugned
direction can be brought within the scope of section 407 of the 1973 Cr.P.C. Or not. If I am right in
my conclusion that it cannot, the direction will clearly be contrary to the provisions of the Cr.P.C.
and hence violative of Article 21. It could also perhaps be said to be discriminatory on the ground
that, in the absence of not only a statutory provision but even any well defined policy or criteria, the
only two reasons given in the order-namely, the status of the petitioner and delay in the progress of
the trial-are inadequate to justify the special treatment meted out to the appellant. On the other
hand, if the provisions of section 407 Cr.P.C. are applicable, the direction will be in consonance with
a procedure prescribed by law and hence safe from attack as violative of Article 21. The reasons
given, in the context of the developments in the case, can also be sought to be justified in terms of
clauses (a), (b) or (c) of Section 407(1). In such an event, the direction will not amount to an
arbitrary discrimination but can be justified as the exercise of a choice of courses permitted under a
valid statutory classification intended to serve a public purpose.
24. The argument of infringment of article 21 is based essentially on the premise that the accused
will be deprived, in cases where the trial is withdrawn to the High Court of a right of first appeal.
This fear is entirely unfounded. I think Sri Jethmalani is right in contending that where a case is
thus withdrawn and tried by the Court, the High Court will be conducting the trial in the exercise of
its extraordinary original criminal jurisdiction. As pointed out by Sabyasachi Mukharji, J., the oldA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

Presidency- town High Courts once exercised original jurisdiction in criminal matters but this has
since been abolished. One possible view is that now all original criminal jurisdiction exercised by
High Court is only extraordinary original criminal jurisdiction. Another possible view is that still
High Courts do exercise ordinary original criminal jurisdiction in habeas corpus and contempt of
court matters and also under some specific enactments (e.g. Companies' Act Ss. 454 and 633). They
can be properly described as exercising extraordinary original criminal jurisdiction, where though
the ordinary original criminal jurisdiction is vested in a subordinate criminal court or special Judge,
a case is withdrawn by the High Court to itself for trial. The decision in Madura Tirupparankundram
etc. v. Nikhan Sahib, 35 C.W.N. 1088, Kavasji Pestonji v. Rustomji Sorabji, AIR 1949 Bombay 42,
Sunil Chandra Roy and another v. The State, AIR 1954 Calcutta 305, People's Insurance Co. Ltd. v.
Sardul Singh Caveeshar and others, AIR 1961 Punjab 87 and People's Patriotic Front v. K.K. Birla
and others, [1984] Crl. L.J . 545 cited by him amply support this contention. If this be so, then Sri
Jethmalani is also right in saying that a right of first appeal to the Supreme Court against the order
passed by the High Court will be available to the accused under s. 374 of the 1973 Cr.P.C. In other
words, in the ordinary run of criminal cases tried by a Court of Sessions, the accused will be tried in
the first instance by a court subordinate to the High Court; he will then have a right of first appeal to
the High Court and then can seek leave of the Supreme Court to appeal to it under Article 136. In the
case of a withdrawn case, the accused has the privilege of being tried in the first instance by the High
Court itself with a right to approach the apex Court by way of appeal. The apprehension that the
judgment in the trial by the High Court, in the latter case, will be final, with only a chance of
obtaining special leave under article 136 is totally unfounded. There is also some force in the
submission of Sri Jethmalani that, if that really be the position and the appellant had no right of
appeal against the High Court's judgment, the Supreme Court will consider any petition presented
under Article 136 in the light of the inbuilt requirements of Article 21 and dispose of it as if it were
itself a petition of appeal from the judgment. (see, in this context, the observations of this Court in
Sadananthan v. Arunachalam, [1980] 2 S.C.R. 673. That, apart it may be pointed out, this is also an
argument that would be valid in respect even of ordinary criminal trials withdrawn to the High
Court under s. 407 of the Cr.P.C. and thus, like the previous argument regarding Article 14,
indirectly challenges the validity of S.407 itself as infringing Article 21. For the reasons discussed, I
have come to the conclusion that an accused, tried directly by the High Court by withdrawal of his
case from a subordinate court, has a right of appeal to the Supreme Court under s. 374 of the Cr.P.C.
The allegation of an infringement of Article 2 1 in such cases is. therefore. unfounded. Natural
Justice
25. The appellant's contention that the impugned direction is sued by this Court on 16.2.1984 was in
violation of the principles of natural justice appears to be well founded. It is really not in dispute
before us that there was no whisper or suggestion in the proceedings before this Court that the
venue of the trial should be shifted to the High Court. This direction was issued suo motu by the
learned Judges without putting it to the counsel for the parties that this was what they proposed to
do. The difficulties created by observations or directions on issues not debated before the Court have
been highlighted by Lord Diplock in Hadmor Productions Ltd. v. Hamilton, [1983] A.C. 191). In that
case, Lord Denning, in the Court of Appeal, had in his judgment, relied on a certain passage from
the speech of Lord Wedderburn in Parliament as reported in Hansard (Parliamentary Reports) in
support of the view taken by him. The counsel for the parties had had no inkling or information thatA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

recourse was likely to be had by the Judge to this source, as it had been authoritatively held by the
House of Lords in Davis v. Johns, [1979] A.C. 264 that these reports should not be referred to by
counsel or relied upon by the court for any purpose. Commenting on this aspect, Lord Diplock
observed:
"Under our adversary system of procedure, for a judge to disregard the rule by which
counsel are bound has the effect of depriving the parties to the action of the benefit of
one of the most fundamental rules of natural justice: the right of each to be informed
of any point adverse to him that is going to be relied upon by the judge and to be
given an opportunity of stating what his answer to it is. In the instant case, counsel
for Hamilton and Bould complained that Lord Denning M.R. had selected one speech
alone to rely upon out of many that had been made .. and that, if he has counsel had
known that (Lord Denning) was going to do that, not only would he have wished to
criticise what Lord Wedderburn had said in his speech ....... but he would also have
wished to rely on other speeches disagreeing with Lord Wedderburn if he, as counsel,
had been entitled to refer to Hansard ....."
The position is somewhat worse in the present case. Unlike the Hamilton case (supra) where the
Judge had only used Hansard to deal with an issue that arose in the appeal, the direction in the
present case was something totally alien to the scope of the appeal, on an issue that was neither
raised nor debated in the course of the hearing and completely unexpected.
26. Shri Jethmalani submitted that, when the judgment was announced, counsel for the
complainant (present respondent) had made an oral request that the trial be transferred to the High
Court and that the Judges replied that they had already done that. He submitted that, at that time
and subsequently, the appellant could have protested and put forward his objections but did not and
had thus acquiesced in a direction which was, in truth, beneficial to him as this Court had only
directed that he should be tried by a High Court Judge, a direction against which no one can
reasonably complain. This aspect of the respondent's arguments will be dealt with later but, for the
present, all that is necessary is to say that the direction must have come as a surprise to the
appellant and had been issued without hearing him on the course proposed to be adopted.
Conclusion
27. To sum up, my conclusion on issue A is that the direction issued by the Court was not warranted
in law, being contrary to the special provisions of the 1952 Act. was also not in conformity with the
principles of natural justice and that, unless the direction can be justified with reference to S. 407 of
the Cr. P.C., the petitioner's fundamental rights under Articles 14 and 21 can be said to have been
infringed by reason of this direction. This takes me on to the question whether it follows as a
consequence that the direction issued can be, or should be, recalled, annulled, revoked or set aside
by us now.
B. CAN AND SHOULD THE DIRECTION OF 16.2.84 BE RECALLED?A.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

28. It will be appreciated that, whatever may be the ultimate conclusion on the correctness,
propriety or otherwise of the Court's direction dated 16.2.1984, that was a direction given by this
Court in a proceeding between the same parties and the important and farreaching question that
falls for consideration is whether it is at all open to the appellant to seek to challenge the correctness
of that direction at a later stage of the same trial.
Is a review possible?
29. The first thought that would occur to any one who seeks a modification of an order of this Court,
particularly on the ground that it contained a direction regarding which he had not been heard,
would be to seek a review of that order under Article 137 of the Constitution read with the relevant
rules. Realising that this would be a direct and straight forward remedy, it was contended for the
appellant that the present appeal may be treated as an application for such review.
30. The power of review is conferred on this Court by Article 137 of the Constitution which reads
thus:
"Subject to the provisions of any law made by Parliament or any rules made under
Article 145, the Supreme Court shall have power to review any judgment pronounced
or order made by it."
It is subject not only to the provisions of any law made by Parliament (and there is no such law so
far framed) but also to any rules made by this Court under Article 145. This Court has made rules in
pursuance of art. 145 which are contained in order XL in Part VIII of the Supreme Court Rules.
Three of these rules are relevant for our present purposes. They read as follows:
"(1) The Court may review its judgment or order, but no appliction for review will be
entertained in a civil proceeding except on the ground mentioned in order XLVII,
rule 1 of the Code, and in a criminal proceeding except on the ground of an error
apparent on the face of the record. (Z) An application for review shall be by a petition.
and shall be filed within thirty days from the date of the judgment or order sought to
be reviewed. It shall set out clearly its grounds for review.
(3) Unless otherwise ordered by the Court an application for review shall be disposed
of by circulation without any oral arguments, but the petitioner may supplement his
petition by additional written arguments. The court may either dismiss the petition
or direct notice to the opposite party. An application for review shall as far as
practicable be circulated to the same Judge or Bench of Judges that delivered the
judgment or order sought to be reviewed."
31. It is contended on behalf of the respondent that the present pleas of the appellant cannot be
treated as an application for review, firstly, because they do not seek to rectify any error apparent on
the face of the record; secondly, because the prayer is being made after the expiry of the period of
thirty days mentioned in rule 2 and there is no sufficient cause for condoning the delay in theA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

making of the application and thirdly, for the reason that a review petition has to be listed as far as
practicable before the same Judge or Bench of Judges that delivered the order sought to be reviewed
and in this case at least two of the learned Judges, who passed the order on 16.2.1984, are still
available to consider the application for review. These grounds may now be considered.
32. For reasons which I shall later discuss, I am of opinion that the order dated 16.2.1984 does not
suffer from any error apparent on the face of the record which can be rectified on a review
application. So far as the second point is concerned, it is common ground that the prayer for review
has been made beyond the period mentioned in Rule 2 of order XL of the Supreme Court Rules. No
doubt this Court has power to extend the time within which a review petition may be filed but
learned counsel for the respondent vehemently contended that this is not a fit case for exercising the
power of condonation of delay. It is urged that, far from this being a fit case for the entertainment of
the application for review beyond the time prescribed, the history of the case will show that the
petitioner has deliberately avoided filing a review petition within the time prescribed for reasons
best known to himself .
33. In support of his contention, learned counsel for the respondent invited our attention to the
following sequence of events and made the following points:
(a) The order of this Court was passed on 16.2.1984.
At the time of the pronouncement of the said order, counsel for the present respondent had made a
request that the trial of the case may be shifted to the High Court and the Court had observed that a
direction to this effect had been included in the judgment. Even assuming that there had been no
issues raised and no arguments advanced on the question of transfer at the time of the hearing of
the appeals, there was nothing to preclude the counsel for the appellant, when the counsel for the
complainant made the above request, from contending that it should not be done, or, at least, that it
should not be done without further hearing him and pointing out this was not a matter which had
been debated at the hearing of the appeal. But no, the counsel for the accused chose to remain quiet
and did not raise any objection at that point of time. He could have filed a review application soon
thereafter but he did not do so. Perhaps he considered, at that stage, that the order which after all
enabled him to be tried by a High Court Judge in preference to a Special Judge was favourable to
him and, therefore, he did not choose to object.
(b) The matter came up before the trial judge on 13th March, 1984. The accused, who appeared in
person, stated that he did not want to engage any counsel "at least for the present'. A He would not
put down his arguments in writing and when he argued the gravemen of his attack was that this
Court's order transferring the trial from the Special Judge to the High Court was wrong on merits.
Naturally, the learned Judge found it difficult to accept the contention that he should go behind the
order of the Supreme Court. He rightly pointed out that if the accused had any grievance to make,
his proper remedy was to move the Supreme Court for review of its judgment or for such further
directions or clarifications as may be expedient. Thus, as early as 13th March, 1984, Khatri, J., had
given a specific opportunity to the accused to come to this Court and seek a review of the direction. it
can perhaps be said that on 16.2.1984, when this Court passed the impugned direction, the appellantA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

was not fully conscious of the impact of the said direction and that, therefore, he did not object to it
immediately. But, by the 13th March, 1984, he had ample time to think about the matter and to
consult his counsel. The appellant himself was a barrister. He chose not to engage counsel but to
argue himself and, even after the trial court specifically pointed out to him that it was bound by the
direction of this Court under Arts. 141 and 144 of the Constitution and that, if at all, his remedy was
to go to the Supreme Court by way of review or by way of an application for clarification, he chose to
take no action thereon.
c) on 16th March, 1984, Khatri, J. disposed of the preliminary objections raised by the accused
challenging the jurisdiction and competence of this Court to try the accused. Counsel for the
respondent points out that, at the time of the hearing, the appellant had urged before Khatri, J. all
the objections to the trial, which he is now putting forth. These objections have been summarised in
paragraph 3 of the order passed by the learned Judge and each one of them has been dealt with
elaborately by the learned Judge. It has been pointed out by him that the Supreme Court was
considering not only the appeals preferred by the accused and the complainant, namely, Crl. Appeal
Nos. 246, 247 and 356 of 1983 but also two revision petitions being C.R. Nos. 354 'and 359 of 1983
which had been withdrawn by the Supreme Court to itself for disposal along with Crl. Appeal No.
356 of 1983. A little later in the order the learned Judge pointed out that, even assuming that in the
first instance the trial can be conducted only by a Special Judge, the proceedings could be
withdrawn by the high Court to itself under powers vested in it under Article 228(a) of the
Constitution as well as section 407 of the Cr.P.C. When the criminal revisions stood transferred to
the Supreme Court (this was obviously done under Article 139-A though that article is not
specifically mentioned in the judgment of the Supreme Court), the Supreme Court could pass the
order under Article 139-A read with Article 142. The learned Judge also disposed of the objections
based on Article 21. He pointed out that as against an ordinary accused person tried by a special
judge, who gets a right of appeal to the High Court, a court of superior jurisdiction, with a further
right of appeal to the Supreme Court under s. 374 of the Cr.P.C. and that an order of transfer passed
in the interest of expeditious disposal of a trial was primarily in the interests of the accused and
could hardly be said to be pre judicial to the accused. Despite the very careful and fully detailed
reasons passed by the High Court, the appellant did not choose to seek a review of the earlier
direction.
(d) Against the order of the learned Judge dated 16.3.1984 the complainant came to the Court
because he was dissatisfied with certain observations made by the trial Judge in regard to the
procedure to be followed by the High Court in proceeding with the trial. This matter was heard in
open court by same five learned Judges who had disposed of the matter earlier on 16.2.1984. The
accused was represented by a senior counsel and the Government of Maharashtra had also engaged
a senior counsel to represent its case. Even at this hearing the counsel for the appellant did not
choose to raise any objection against the direction given in the order dated 16.2.1984. The appeal
before the Supreme Court was for getting a clarification of the very order dated 16.2.1984. This was
a golden opportunity for the appellant also to seek a review or clarification of the impugned
direction, if really he had a grievance that he had not been heard by the Court before it issued the
direction and that it was also contrary to the provisions of the 1952 Act as well as violative of the
rights of the accused under Art. 21 of the Constitution.A.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

(e) The petitioner instead filed two special leave petitions and a writ petition against the orders of
Khatri. J. dated 13.3.1984 and 16.3.1984. In the writ petition, the petitioner had mentioned that the
impugned direction had been issued without hearing him. In these matters counsel for the accused
made both oral and written submissions and all contentions and arguments, which have now been
put forward, had been raised in the written arguments. The appeals and writ petition were disposed
of by this Court. This Court naturally dismissed the special leave petitions pointing out that the High
Court was quite correct in considering itself bound by the directions of the Court. The Court also
dismissed the writ petition as without merit. But once again it observed that the proper remedy of
the petitioner was elsewhere and not by way of a writ petition. These two orders, according to the
learned counsel for the respondent, conclude the matter against the appellant. The dismissal of the
writ petition reminded the petitioner of his right to move the Court by other means and, though this
advice was tendered as early as 17.4.1984, the petitioner did nothing. So far as the special leave
petition was concerned, its dismissal meant the affirmation in full of the decision given by Justice
Khatri dismissing and disposing of all the objections raised by the petitioner before him. Whatever
may have been the position on 16.2.1984 or 16.3.1984, there was absolutely no explanation or
justification for the conduct of the petitioner in failing to file an application for review between
17.4.1984 and october, 1986.
34. Recounting the above history, which according to him fully explained the attitude of the accused,
learned counsel for the respondent submitted that in his view the appellant was obviously trying to
avoid a review petition perhaps because it was likely to go before the same learned Judges and he
did not think that he would get any relief and perhaps also because he might have felt that a review
was not an adequate remedy for him as, under the rules, it would be disposed of in chamber without
hearing him once again. But, whatever may be the reason, it is submitted, the delay between April
1984 and october, 1986 stood totally unexplained and even now there was no proper review petition
before this Court. In the circumstances, it is urged that this present belated prayer for review.
35. There is substance in these contentions. The prayer for review is being made very belatedly, and
having regard to the circumstances outlined above there is hardly any reason to condone the delay
in the prayer for review. The appellant was alive to all his present contentions as is seen from the
papers in the writ petition. At least when the writ petition was dismissed as an inappropriate
remedy, he should have at once moved this Court for review. The delay from April 1984 to october
1986 is totally inexplicable. That apart, there is also validity in the respondent's contention that.
even if we are inclined to condone the delay, the application will have to be heard as far as possible
by the same learned Judges who disposed of the earlier matter. In other words, that application will
have to be heard by a Bench which includes the two learned Judges who disposed of the appeal on
16.2.1984 and who are still available in this Court to deal with any proper review application, that
may be filed. However, since in my view, the delay has not been satisfactorily explained, I am of
opinion that the prayer of the appellant that the present pleas may be treated as one in the nature of
a review application and the appellant given relief on that basis has to be rejected. Is a writ
maintainable?
36. This takes one to a consideration of the second line of attack by the appellant's counsel. His
proposition was that a judicial order of a court-even the High Court or this Court may breach theA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

principles of natural justice or the fundamental rights and that, if it does so, it can be quashed by
this Court in the exercise of its jurisdiction under Article 32. In other words, the plea would seem to
be that the present proceedings may be treated as in the nature of a writ petition to quash the
impugned order on the above ground. The earliest of the cases relied upon to support this
contention is the decision in Prem Chand Garg v. Excise Commissioner, [1963] Supp. 1 S.C.R. 885,
which may perhaps be described as the sheet-anchor of the appellant's contentions on this point.
The facts of that case have been set out in the judgment of Sabyasachi Mukharji, J. and need not be
repeated. The case was heard by a Bench of five judges. Four of them, speaking through
Gajendragadkar, J. held that Rule 12 of order XXXV of the Supreme Court Rules violated Article 32
and declared it invalid. This also set aside an earlier order dated 12.12.1961 passed by the Court in
pursuance of the rule calling upon the petitioner to deposit cash security. Sri Rao contended that
this case involved two separate issues for consideration by the Court:
(a) the validity of the rule and (b) the validity of the order dated 12.12.1961; and that
the decision is authority not only for the proposition that a writ petition under Article
32 could be filed to Impugn the constitutional validity of a rule but also for the
proposition that the Court could entertain a writ petition to set aside a judicial Order
passed by the Court earlier on discovering that it is inconsistent with the
fundamental rights of the petitioner.
Counsel submitted that an impression in the minds of some persons that the decision in Prem
Chand Garg is not good law after the decision of the nine-Judge Bench in Naresh Sridhar Mirajkar v.
State, [1966]3 S.C.R. 744 is incorrect. He submitted that, far from Garg's case being overruled, it has
been confirmed in the later case.
37. Mirajkar was a case in which the validity of an interlocutory order passed by a judge of the
Bombay High Court pertaining to the publication of reports of the proceedings in a suit pending
before him was challenged by a journalist as violating his fundamental rights under Article 19 of the
Constitution. The matter came to the Supreme Court by way of a writ petition under Article 32. The
validity of the order was upheld by the majority of the Judges while Hidayatullah J. dissented. In
this connection it is necessary to refer to a passage at p. 767 in the judgment of Gajendragadkar, C.J.
"Mr. Setalvad has conceded that if a court of competent jurisdiction makes an order
in a proceeding before it, and the order is inter- partes, its validity cannot be
challenged by invoking the jurisdiction of this Court under Art. 32, though the said
order may affect the aggrieved party's fundamental rights. His whole argument
before us has been that the impugned order affects the fundamental rights of a
stranger to the proceeding before the Court; and that, he contends, justifies the
petitioners in moving this Court under Artc. 32. It is necessary to examine the
validity of this argument.
The question before the Supreme Court was thus as to whether, even at the instance
of a stranger to the earlier proceedings, the earlier order could be challenged by
means of a writ petition under Article 32. One of the questions that had to beA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

considered by the Court was whether the judicial order passed by the learned judge of
the High Court was amenable to be writ jurisdiction of the Court under Article 32. On
this question, the judges reacted differently:
(i) Gajendragadkar, CJ and Wanchoo, Mudholkar, Sikri and Ramaswamy, JJ. had
this to say:
"The High Court is a superior Court of Record and it is for it to consider whether any
matter falls within its jurisdiction Or not. The order is a judicial order and if it is
erroneous, a person aggrieved by it, though a stranger, could move this Court under
Article 136 and the order can be corrected in appeal but the question about the
existence of the said jurisdiction as well as the validity or the propriety of the order
cannot be raised in writ proceedings under article 32.',
(ii) Sarkar J. also concurred in the view that this Court had no power to issue a
certiorari to the High Court.
He observed:
"I confess the question is of some haziness. That haziness arises because the courts in
our country which have been given the power to issue the writ are not fully analogous
to the English courts having that power. We have to seek a way out for ourselves.
Having given the matter my best consideration, I venture to think that it was not
contemplated that a High Court is an inferior court even though it is a court of
limited jurisdiction. The Constitution gave power to the High Court to issue the writ.
In England, an inferior court could never issue the writ. I think it would be abhorrent
to the principle of certiorari if a Court which can itself issue the writ is to be made
subject to be corrected by a writ issued by another court. When a court has the power
to issue the writ, it is not according to the fundamental principles of certiorari, an
inferior court or a court of limited jurisdiction. It does not cease to be so because
another Court to which appeals from it lie has also the power to issue the writ. That
should furnish strong justification for saying that the Constitution did not
contemplate the High Courts to be inferior courts so that their decisions would be
liable to be quashed by writs issued by the Supreme Court which also had been given
power to issue the writs. Nor do I think that the cause of justice will in any manner be
affected if a High Court is not made amenable to correct by this Court by the issue of
the writ. In my opinion, therefore, this Court has not power to issue a certiorari to a
High Court."
(iii) Bachawat J. held:
"The High Court has jurisdiction to decide if it could restrain the publication of any
document or information relating to the trial of a pending suit or concerning which
the suit is brought, if it erroneously assume a jurisdiction not vested in it, its decisionA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

may be set aside in appropriate proceedings but the decision is not open to attack
under Article 32 on the ground that it infringes the fundamental right under Article
19(1)(a). If a stranger is prejudiced by an order forbidding the publication of the
report of any proceeding, his proper course is only to apply to the Court tn lift the ban
"
(iv) Justice Shah thought that, in principle, a writ petition could perhaps be filed to challenge an
order of a High Court on the ground that it violated the fundamental rights of the petitioner under
Articles 20, 21 and 22 but he left the question open. He, however, concluded that an order of the
nature in issue before the Court could not be said to infringe Article 19.
38. Hidayatullah J., as His Lordship then was, however, dissented. He observed:
"Even assuming the impugned order means a temporary suppression of the evidence
of the witness, the trial Judge had no jurisdiction to pass the order. As he passed no
recorded order, the appropriate remedy (in fact the only effective remedy) is to seek
to quash the order by a writ under Article 32.
There may be action by a Judge which may offend the fundamental rights under
articles 14, 15, 19, 20, 21 and 22 and an appeal to this Court will not only be
practicable but will also be an ineffective remedy and this Court can issue a writ to
the High Court to quash its order under Article 32 of the Constitution. Since there is
no exception in Article 32 in respect of the High Courts there is a presumption that
the High Courts are not excluded. Even with the enactment of Article 226, the power
which is conferred on the High Court is not in every sense a coordinate power and the
implication of reading articles 32, 136 and 226 together is that there is no sharing of
the powers to issue the prerogative writs possessed by this Court. Under the total
scheme of the Constitution, the subordination of the High Courts to the Supreme
Court is not only evident but is logical."
His Lordship proceeded to meet an objection that such a course might cast a slur on the High Courts
or open the floodgates of litigation. He observed:
"Article 32 is concerned with Fundamental Rights and Fundamental Rights only. It is
not concerned with breaches of law which do not involve fundamental rights directly.
The ordinary writs of certiorari, mandamus and prohibition can only issue by
enforcement of Fundamental Rights. A clear cut case of breach of Fundamental Right
alone can be the basis for the exercise of this power. I have already given examples of
actions of courts and judges which are not instances of wrong judicial orders capable
of being brought before this court only by appeal but breaches of Fundamental Rights
clear and simple. Denial of equality as for example by excluding members of a
particular party or of a particular community from the public court room in a public
hearing without any fault, when others are allowed to stay on would be a case of
breach of fundamental right of equal protection given by this Constitution. Must anA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

affected person in such a case ask the Judge to write down his order, so that he may
appeal against it? or is he expected to ask for special leave from this Court? If a High
Court judge in England acted improperly, there may be no remedy because of the
limitations on the rights of the subject against the Crown. But in such circumstances
in England the hearing is considered vitiated and the decision voidable. This need not
arise here. The High Court in our country in similar circumstances is not immune
because there is a remedy to move this court for a writ against discriminatory
treatment and this Court should not in a suitable case shirk to issue a writ to a High
Court Judge, who ignores the fundamental rights and his obligations under the
Constitution. Other cases can easily be imagined under Article 14, 15, 19, 20, 21 and
22 of the Constitution, in which there may be action by a Judge which may offend the
fundamental rights and in which an appeal to this Court will not only be not
practicable but also quite an ineffective remedy.
We need not be dismayed that the view I take means a slur on the High Courts or that
this Court will be flooded with petitions under Article 32 of the Constitution.
Although the High Courts possess a power to interfere by way of high prerogative
writs of certiorari, mandamus and prohibition, such powers have not been invoked
against the normal and routine work of subordinate courts and tribunals. The reason
is that people understand the difference between an approach to the High Court by
way of appeals etc. and approach for the purpose of asking for writs under Article
226. Nor have the High Courts spread a Procrustean bed for high prerogative writs
for all actions to lie. Decisions of the courts have been subjected to statutory appeals
and revisions but the losing side has not charged the Judge with a breach of
fundamental rights because he ordered attachment of property belonging to a
stranger to the litigation or by his order affected rights of the parties or even
strangers. This is because the people understand the difference between normal
proceedings of a civil nature and proceedings in which there is a breach of
fundamental rights. The courts acts, between parties and even between parties and
strangers, done impersonally and objectively are challengeable under the ordinary
law only. But acts which involve the court with a fundamental right are quite
different."
One more passage from the judgment needs to be quoted. Observed the learned Judge:
"I may dispose of a few results which it was suggested, might flow from my view that
this Court can issue a high prerogative writ to the High Court for enforcement of
fundamental rights. It was suggested that the High Courts might issue writs to this
Court and to other High Courts and one Judge or Bench in the High Court and the
Supreme Court might issue a writ to another judge or Bench in the same Court. This
is an erroneous assumption. To begin with High Courts cannot issue a writ to the
Supreme Court because the writ goes down and not up. Similarly, a High Court
cannot issue a writ to another High Court. The writ does not go to a court placed onA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

an equal footing in the matter of jurisdiction XX XX XX I must hold that this English
practice of not issuing writs in the same court is in the very nature of things. One
High Court will thus not be able to issue a writ to another High Court nor even to a
court exercising the powers of the High Court. In so far as this Court is concerned,
the argument that one Bench or one Judge might issue a writ to another Bench or
Judge, need hardly be considered. My opinion gives no support to such a view and I
hope I have said nothing to give countenance to it. These are imaginary fears which
have no reality either in law or in fact."
39. I have set out at length portions from the judgment of Hidayatullah, J. as Shri Rao placed
considerable reliance on it. From the above extracts, it will be seen that the majority of the Court
was clearly of opinion that an order of a High Court cannot be challenged by way of a writ petition
under Article 32 of the Constitution on the ground that it violates the fundamental rights, not even
at the instance of a person who was not at all a party to the proceedings in which the earlier order
was passed. Even Hidayatullah, J. has clearly expressed the view that, though a writ of certiorari
might issue to quash the order of a High Court in appropriate case, it cannot lie from a Bench of one
court to another Bench of the same High Court. Subba Rao, C.J. has also made an observation to
like effect in regard to High Court Benches inter se in Ghulam Sarwar v. Union, [1967] 2 S.C.R. 271.
The decision in Prem Chand Garg, seems to indicate to the contrary. But it is clearly distinguishable
and has been distinguished by the nine judge Bench in Mirajkar. The observations of
Gujendragadkar, C.J. (at p. 766), and Sarkar, J. (at p. 780), be seen in this context. In that case, it is
true that the order passed by the Court directing the appellant to deposit security was also quashed
but that was a purely consequential order which followed on the well-founded challenge to the
validity of the rule. Hidayatullah, J. also agreed that this was so and explained that the judicial
decision which was based on the rule was only revised. (p.790).
40. Sri Rao also referred to Sadhanatham v. Arunachalam, [1980] 2 S.C.R. 873. In that case, the
petitioner was acquitted by the High Court, in appeal, of charges under section 302 and 148 of the
Indian Penal Code. The brother of the deceased, not the State or the informant, petitioned this court
under Article 136 of the Constitution for special leave to appeal against the acquittal. Leave was
granted and his appeal was eventually allowed by the High Court. The judgment of the High Court
was set aside and the conviction and sentence imposed by the trial court under section 302 was
upheld by the Supreme Court in his earlier decision reported in [1979] 3 S.C.R. 482. Thereupon, the
petitioner filed a writ petition under Article 32 of the Constitution, challenging the validity of the
earlier order of this Court. Eventually, the petition was dismissed on the merits of the case.
However, learned counsel for the appellant strongly relied on the fact that in this case a Bench of
five judges of this Court entertained a petition under Article 32 to reconsider a decision passed by it
in an appeal before the Court. He submitted that it was inconceivable that it did not occur to the
learned judges who decided the case that, after Mirajkar, a writ petition under Article 32 was not at
all entertainable. He, therefore, relied upon this judgment as supporting his proposition that in an
appropriate case this court can entertain a petition under Article 32 and review an earlier decision of
this court passed on an appeal or on a writ petition or otherwise. This decision, one is constrained to
remark, is of no direct assistance to the appellant. It is no authority for the proposition that an
earlier order of the court could be quashed on the ground that it offends the Fundamental Right. AsA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

the petition was eventually dismissed on the merits, it was not necessary for the court to consider
whether, if they had come to the conclusion that the earlier order was incorrect or invalid, they
would have interfered therewith on the writ petition filed by the petitioner.
41. Two more decisions referred to on behalf of the appellant may be touched upon here. The first
was the decision of this Court in Attorney-General v. Lachma Devi, AIR 1986 S.C. 467. In that case
the High Court had passed an order that certain persons found guilty of murder should be hanged in
public. This order was challenged by a writ petition filed under article 32 by the Attorney-General of
India, on the ground that it violated Article 21 of the Constitution. This petition was allowed by this
Court. The second decision on which reliance was placed is that in Sukhdas v. Union Territory,
[1986] 2 S.C.C. 401. In that case the petitioner, accused of a criminal offence had not been provided
with legal assistance by the court. The Supreme Court pointed out that this was a constitutional
lapse on the part of the court and that the conviction on the face of the record suffered from a fatal
infirmity. These decisions do not carry the petitioner any further. Sukhdas was a decision on an
appeal and Lachma Devi does not go beyond the views expressed by Hidayatullah, J. and Shah, J. in
Mirajkar.
42. On a survey of these decisions, it appears to me that Prem Chand Garg cannot be treated as an
authority for the proposition that an earlier order of this Court could be quashed by the issue of a
writ on the ground that it violated the fundamental rights. Mirajkar clearly precludes such a course.
It is, therefore, not possible to accept the appellant's plea that the direction dated 16.2.1984 should
be quashed on the grounds put forward by the petitioner. Inherent power to declare orders to be
null and void
43. The next line of argument of learned counsel for the appellant is that the order dated 16.2.1984,
in so far as it contained the impugned direction, was a complete nullity. Being an order without
jurisdiction, it could be ignored by the person affected or challenged by him at any stage of the
proceedings before any Court, particularly in a criminal case, vide Dhirendra Kumar v.
Superintendent, [1955] 1 S.C.R. 224. Counsel also relied on the following observations made in
Kiran Singh v . Chaman Paswan, [AIR 1955 S.C.R. 117.] "The answer to these contentions must
depend on what the position in law is when a Court entertains a suit or an appeal over which it has
no jurisdiction, and what the effect of Section 11 of the Suits Valuation Act is on that position. It is a
fundamental princple well established that a decree passed by a Court without jurisdiction is a
nullity, and that its invalidity could be set up whenever and wherever it is sought to be enforced or
relied upon, even at the stage of execution and even in collateral proceedings. A defect of
jurisdiction, whether it is pecuniary or territorial, or whether it is in respect of the subject matter of
the action, strikes at the very authority of the Court to pass any decree, and such a defect cannot be
cured even by consent of parties. If the question now under consideration fell to be determined only
on the application of general principles governing the matter, there can be no doubt that the District
Court of Monghyr was coram non judice, and that its judgments and decree would be nullities.
(emphasis added) He also extensively quoted from the dicta of this Court in M. L. Sethi v. R.P.
Kapur, [1973] 1 S.C.R. 697, where after setting out the speeches of Lord Reid and Lord Pearce in
Anisminic Ltd. v. Foreign Compensation Commissioner, [1969] 2 A.C. 147 this Court observed:A.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

"The dicta of the majority of the House of Lords in the above case would show the
extent to which 'lack' and 'excess' of jurisdiction have been assimilated or, in other
words, the extent to which we have moved away from the traditional concept of
"jurisdiction". The effect of the dicta in that case is to reduce the difference between
jurisdictional error and error of law within jurisdiction almost to vanishing point. The
practical effect of the decision is that any error of law can be reckoned as
jurisdictional. This comes perilously close to saying that there is jurisdiction if the
decision is right in law but none if it is wrong. Almost any misconstruction of a
statute can be represented as "basing their decision on a matter with which they have
no right to deal", "impose an unwarranted condition" or "addressing themselves to a
wrong question." The majority opinion in the case leaves a Court or Tribunal with
virtually no margin of legal error. Whether there is excess or jurisdiction or merely
error within jurisdiction can be determined only by construing the empowering
statute, which will give little guidance. It is really a question of how much latitude the
Court is prepared to allow. In the end it can only be a value judgment (see R.W.R.
Wade, "Constitutional and Administrative Aspects of the Anisintic case", Law
Quarterly Review, Vo. 85, 1969 p. 198). Why is it that a wrong decision on a question
of limitation or res judicata was treated as a jurisdictional error and liable to be
interfered with in revision? It is a bit difficult to understand how an erroneous
decision on a question of limitation or res judicata could oust the jurisdiction of the
Court in the primitive sense of the term and render the decision or a decree
embodying the decision a nullity liable to collateral attack. The reason can only be
that the error of law was considered as vital by the Court. And there is no yardstick to
determine the magnitude of the error other than the opinion of this Court."
He also referred to Badri Prasad v. Nagarmal, [1959] 1 Supp. S.C.R. 769 which followed the clear law
laid down in Surajmul Nagarmul v. Trilon Insurance Co. Ltd., [1924] L.R. 52 I.A. 126, Balai Chandra
Hazra v. Shewdhari Jadav, [1978] 3 S.C.R. 147 which followed Ledgard v. Bull, (L.R. 13 I.A. 134;
Meenakshi Naidu v. Subramaniya Sastri, L.R. 14 I.A. 140 and Sukhrani v. Hari Shankar, [1979] 3
S.C.R 671. Sri Rao, citing a reference from Halsbury's Laws of England (4th Edition) Vol. X, para
713, pages 321-2, contended that the High Court's jurisdiction clearly stood excluded by s. 7(1) of the
1952 Act and, hence, the direction of the Supreme Court was also one without jurisdiction.
44. In dealing with this contention, one important aspect of the concept of jurisdiction has to be
borne in mind. As pointed out by Mathew J. in Kapur v. Sethi, (supra), the word "jurisdiction is a
verbal coat of many colours.". It is used in a wide and broad sense while dealing with administrative
or quasi-judicial tribunals and subordinate courts over which the superior courts exercise a power of
judicial review and superintendence. Then it is only a question of "how much latitude the court is
prepared to allow" and "there is no yardstick to determine the magnitude of the error other than the
opinion of the court." But the position is different with superior courts with unlimited jurisdiction.
These are always presumed to act with jurisdiction and unless it is clearly shown that any particular
order is patently one which could not, on any conceivable view of its jurisdiction, have been passed
by such court, such an order can neither be ignored nor even recalled, annulled, revoked or set aside
in subsequent proceedings by the same court. This distinction is well brought out in the speeches ofA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

Lord Diplock, Lord Edmund- Devier and Lord Scarman in Re. Racal Communications Ltd., [1980] 2
A.E.R. 634. In the interests of brevity, I resist the temptation to quote extracts from the speeches
here.
45. In the present case, the order passed is not one of patent lack of jurisdiction, as I shall explain
later. Though I have come to the conclusion, on considering the arguments addressed now before
us, that the direction in the order dated 16.2.1984 cannot be justified by reference to Article 142 of
the Constitution or S. 407 of the 1973 Cr. P.C., that is not an incontrovertible position. It was
possible for another court to give a wider interpretation to these provisions and come to the
conclusion that such an order could be made under those provisions. If this Court had discussed the
relevant provisions and specifically expressed such a conclusion, it could not have been modified in
subsequent proceedings by this Bench merely because we are inclined to hold differently. The mere
fact that the direction was given, without an elaborate discussion, cannot render it vulnerable to
such review.
46. Shri P.P. Rao then placed considerable reliance on the observations of the Privy Council in
Isaacs v. Robertson, [1984] 3 A.E.R.140 an appeal from a decision of the Court of Appeal of St.
Vincent and the Grenadines. Briefly the facts were that Robertson had obtained an interim
injunction against Isaacs and two others on 31.5.1979 which the latter refused to obey. The
respondents motion for committal of the appellant for contempt was dismissed by the High Court of
Saint Vincent. The Court of Appeal allowed the respondents application; the appellants were found
to be in contempt and also asked to pay respondents costs. However, no penalty was inflicted
because the appellant would have been entitled to succeed on an application for setting aside the
injunction, has he filed one. The main attack by the appellant on the Court of Appeal's judgment was
based on the contention that, as a consequence of the operation of certain rules of the Supreme
Court of St. Vincent, the interlocutory injunction granted by the High Court was a nullity: so
disobedience to it could not constitute a contempt of court. Lord Diplock observed:
Glosgow J. accepted this contention, the Court of Appeal rejected it, in their
Lordships' view correctly, on the short and well established ground that an order
made by a court of unlimited jurisdiction, such as the High Court of Saint Vincent
must be obeyed unless and until it has been set aside by the court. For this
proposition Robotham AJA cited the passage in the judgment of Romer L.J. in
Hadkinson v. Hadkinson, [1952] 2 All. E.R. 567 at 569, (1952) P. 285 at 288. It is the
plain and unqualified obligation of every person against, or in respect of whom an
order is made by a Court of competent jurisdiction to obey it unless and until that
order is discharged. The uncompromising nature of this obligation is shown by the
fact that it extends even to cases where the person affected by an order believes it to
be irregular or even void. Lord Cotteniiam, Leven to cases where the person affected
by an order believes it to be irregular or even void. Lord Cotteniiam, L.C. said in
Chuck v. Cremer, [1946] 1 Coop Temp Cott 338 at 342, 47 E.R.884 at 855: "A party,
who knows of an order, whether null or valid, regular or irregular, cannot be
permitted to disobey it .. It would be most dangerous to hold that the suitors, or their
solicitors, could themselves judge whether an order was null or valid-whether it wasA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

regular or irregular. That they should come to the court and not take upon
themselves to determine such a question. That the course of a party knowing of an
order, which was null or irregular, and who might be affected by it, was plain. He
should apply to the Court that it might be discharged. As long as it existed it must not
be obeyed." Such being the nature of this obligation, two consequences will, in
general, follow from its breach. The first is that anyone who dis-
obeys an order of the court.....is in contempt and may be published by committal or
attachment or otherwise.
It is in their Lordships view, says all that needs to be said on this topic. It is not itself
sufficient reason for dismissing this appeal. Having said this, the learned Law Lord
proceeded to say:
"The cases that are referred to in these dicta do not support the proposition that there
is any category of orders of a court of unlimited jurisdiction of this kind, what they do
support is the quite different proposition that there is a category of orders of such a
court which a person affected by the order is entitled to apply to have set aside ex
debito justitiae in the exercise of the inherent jurisdiction of the court without his
needing to have recourse to the rules that deals expressly with proceedings to set
aside orders for irregularity and give to the Judge a discretion as to the order he will
make. The judges in the case that have drawn the distinction between the two types of
orders have cautiously refrained from seeking to lay down a comprehensive
definition of defects that bring an order in the category that attracts ex debito
justitiae the right to have it set aside save that specifically it includes orders that have
been obtained in breach of rules of natural justice. The contrasting legal concepts of
voidness and voidability form part of the English law of contract. They are
inapplicable to orders made by a court of unlimited jurisdiction in the course of
contentions litigation. Such an order is either irregular or regular. If it is irregular it
can be set aside by the court that made it on application to that court, if it is regular it
can only be set aside by an appellate court on appeal if there is one to which an
appeal lies."
Sri Rao strongly relied on this passage and, modifying his earlier, somewhat extreme, contention
that the direction given on 16.2.1984 being a nullity and without jurisdiction could be ignored by all
concerned-even by the trial judge-he contended, on the strength of these observations, that he was
at least entitled ex debito justitiae to come to this Court and request the court, in the interests of
justice, to set aside the earlier order "without his needing to have recourse to the rules that deal
expressly with proceedings to set aside orders for irre gularity", if only on the ground that the order
had been made in breach of the principles of natural justice. Violation of the principles of natural
justice, he contended, renders the direction a nullity without any further proof of prejudice (see
Kapur v. Jagmohan, [1981] 1 S.C.R. 746 at 766) .A.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

47. Learned counsel contended, in this context, that the fact the direction had been given in the
earlier proceedings in this very case need not stand in the way of our giving relief, if we are really
satisfied that the direction had been issued per incuriam, without complying with the principles of
natural justice and purported to confer a jurisdiction on the High Court which it did not possess. In
this context he relied on certain decisions holding that an erroneous decision on a point of
jurisdiction will not constitute res judicata. In Mathura Prasad v. Dossibai, [1970] 3 S.C.R. 830, this
Court observed:
"A question relating to the jurisdiction of a Court cannot be deemed to have been
finally determined by an erroneous decision of the Court. If by an erroneous
interpretation of the statute, the Court holds that it has no jurisdiction, the question
would not, in our judgment, operate as res judicata. Similarly, by an erroneous
decision, if the Court assumes jurisdiction which it does not possess under the
statute, the question cannot operate as res judicata between the same parties,
whether the cause of action in the subsequent litigation is the same or otherwise. It is
true that in determining the application of the rule of res judicata the Court is not
concerned with the correctness or otherwise of the earlier judgment. The matter in
issue, if it is one purely of fact, decided in the earlier proceeding by a competent court
must in a subsequent litigation between the same parties be regarded as finally
decided and cannot be re-opened. A mixed question of law and fact determined in the
earlier proceeding between the same parties may not, for the same reason, be
questioned in a subsequent proceeding between the same parties.
0 xxxxx xxxxx Where, however the question is one purely of law and it relates to the
jurisdiction of the Court or a decision of the court sanctioning something which is
illegal, by resor to the rule of res judicata a party affected by the decision will not be
precluded from challenging the validity of that order under the rule of res judicata,
for a rule of procedure cannot supersede the law of the land. "
Counsel also relied on the decision of this Court in Ghulam Sarwar v. Union of India, [1956] 2
S.C.C.271, where it was held that the principle of constructive res judicata was not applicable to
habeas corpus proceedings. He also referred to the observations of D.A. Desai J. in Soni Vrijlal
Jethalal v. Soni Jadavji Govindji, AIR 1972 Guj. 148 that no act of the court or irregularity can come
in the way of justice being done and one of the highest and the first duty of all courts is to take care
that the act of the court does no injury to the suitors. He also made reference to the maxim that an
act of, or mistake on the part, of a court shall cause prejudice to no one, vide: Jang Singh v. Brij Lal,
[1964] 2 S.C.R. 145 at p. 159. Relying on these decisions and passages from various treatises which I
do not consider it necessary to set out in in extenso here, Sri Rao contended that this court should
not consider itself bound by the earlier order of the Bench or any kind of technicality where the
liberty of an individual and the rights guaranteed to him under Articles 14 and 21 of the Constitution
are in issue. It is urged that, if this Court agrees with him that the direction dated 16.2.1984 was an
illegal one, this Court should not hesitate nay, it should hasten-to set aside the said order and repair
the injustice done to the appellant without further delay. On the other hand, Sri Jethmalani
vehemently urged that the present attempt to have the entire matter reopened constitutes a grossA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

abuse of the process of court, that it is well settled that the principle of res judicata is also available
in criminal matters (vide Bhagat Ram v. State, [1972] 2 S.C.C. 466 and State v. Tara Chand, [1973]
S.C.c. Crl. 774) that in the United States the principle of res judicata governs even jurisdictional
issues and that "the slightest hospitality to the accused's pleas will lead to a grave miscarriage of
justice and set up a precedent perilous to public interest.
48. I have given careful thought to these contentions. The appellant's counsel has relied to a
considerable extent on the maxim "actus curiae neminem gravabit" for contending that it is not only
within the power, but a duty as well, of this Court to correct its own mistakes in order to see that no
party is prejudiced by a mistake of the Court. I am not persuaded that the earlier decision could be
reviewed on the application of the said maxim. I share the view of my learned brother
Venkatachaliah, J. that this maxim has very limited application and that it cannot be availed of to
correct or review specific conclusions arrived at in a judicial decision. My. brother Venkatachaliah,
J. has further taken the view that this Court cannot exercise any inherent powers for setting right
any injustice that may have been caused as a result of an earlier order of the Court. While alive to the
consideration that "the highest court in the land should not, by technicalities of procedure, forge
fetters on its own feet and disable itself in cases of serious miscarriages of justice", he has,
nevertheless, come to the conclusion that "the remedy of the appellant, if any, is by recourse to
article 137 and nowhere else." It is at this point that I would record a dissent from his opinion. In my
view, the decisions cited do indicate that situations can and do arise where this Court may be
constrained to recall or modify an order which has been passed by it earlier and that when ex facie
there is something radically wrong with the earlier order, this Court may have to exercise its plenary
and inherent powers to recall the earlier order without considering itself bound by the nice
technicalities of the procedure for getting this done. Where a mistake is committed by a subordinate
court or a High Court, there are ample powers in this Court to remedy the situation. But where the
mistake is in an earlier order of this Court, there is no way of having it corrected except by
approaching this Court. Sometimes, the remedy sought can be brought within the four comers of the
procedural law in which event there can be no hurdle in the way of achieving the desired result. But
the mere fact that, for some reason, the conventional remedies are not available should not, in my
view, render this Court powerless to give relief. As pointed out by Lord Diplock in Isaac v.
Robertson, [ 19841 3 A.E.R. 140, it may not be possible or prudent to lay down a comprehensive list
of defects that will attract the ex debito justitiae relief. Suffice it to say that the court can grant relief
where there is some manifest illegality or want of jurisdiction in the earlier order or some palpable
injustice is shown to have resulted. Such a power can be traced either to article 142 of the
Constitution or to the powers inherent in this Court as the apex court and the guardian of the
Constitution.
49. It is, however, indisputable that such power has to be exercised in the "rarest of rare" cases. As
rightly pointed out by Sri Jethmalani, there is great need for judicial discipline of the highest order
in exercising such a power, as any laxity in this regard may not only impair the eminence, dignity
and integrity of this Court but may also lead to chaotic consequences. Nothing should be done to
create an impression that this Court can be easily persuaded to alter its views on any matter and that
a larger Bench of the Court will not only be able to reverse the precedential effect of an earlier ruling
but may also be inclined to go back on it and render it ineffective in its application and bindingA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

nature even in regard to subsequent proceedings in the same case. In Bengal Immunity Company
Limited v. The State of Bihar and Ors., [1955] 2 S.C.R. 603, this Court held that it had the power, in
appropriate cases, to reconsider a previous decision given by it. While concurring in this conclusion,
Venkatarama Ayyar, J. sounded a note of warning of consequences which is more germane in the
present context:
"The question then arises as to the principles on which and the limits within which
this power should be exercised. It is of course not possible to enumerate them
exhaustively, nor is it even desirable that they should not crystallised into rigid and
inflexible rules. But one principle stands out prominently above the rest, and that is
that in general, there should be finality in the decisions of the highest courts in the
land, and that is for the benefit and protection of the public. In this connection, it is
necessary to bear in mind that next to legislative enactments, it is decisions of Courts
that form the most important source of law. It is on the faith of decisions that rights
are acquired and obligations incurred, and States and subjects alike shape their
course of action. It must greatly impair the value of the decisions of this Court, if the
notion came to be entertained that there was nothing certain or final about them,
which must be the consequence if the points decided therein came to be
re-considered on the merits every time they were raised. It should be noted that
though the Privy Council has repeatedly declared that it has the power to reconsider
its decisions, in fact, no instance has been quoted in which it did actually reverse its
previous decision except in ecclesiastical cases. If that is the correct position, then the
power to reconsider is one which should be exercised very sparingly and only in
exceptiona1 circumstances, such as when a material provision of law had been
overlooked, or where a fundamental assumption on which the decision is base(1 turns
out to be mistaken. In the present case, it is not suggested that in deciding the
question of law as they did in The State of Bombay v. The United Motors (India) Ltd.,
[1953] S.C.R. l069 the learned Judges ignored any material provisions of law, or were
under any misapprehension as to a matter fundamental to the decision. The
arguments for the appellant before us were in fact only a repetition of the very
contentions which were urged before the learned Judges and negatived by them. The
question then resolves itself to this. Can we differ from a previous decision of this
Court, because a view contrary to the one taken therein appears to be preferable? I
would unhesitatingly answer it in the negative, not because the view previously taken
must necessarily be infallible but because it is important in public interest that the
law declared should be certain and final rather than that it should be declared in one
sense. Or the other. That, I conceive, in the reason behind article 141. There are
questions of law on which it is not possible to avoid difference of opinion, and the
present case is itself a signal example of it. The object of article 141 is that the
decisions of this Court on these questions should settle the controversy, and that they
should be followed as law by all the Courts, and if they are allowed to be reopened
because a different view appears to be the better one, then the very purpose with
which article 141 has been enacted will be defeated, and the prospect will have been
opened of litigants subjecting our decisions to a continuous process of attack beforeA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

successive Benches in the hope that with changes in the personnel of the Court which
time must inevitably bring, a different view might find acceptance. I can imagine
nothing more damaging to the prestige of this Court or to the value of its
pronouncements. In James v. Commonwealth, 18 C.L.R.54, it was observed that a
question settled by a previous decision should not be allowed to be reopened "upon a
mere suggestion that some or all of the Members of the later Court might arrive at a
different conclusion if the matter was res integra. Otherwise, there would be grave
danger of want of continuity in the interpretation of the law" (per Griffiths, C.J. at p.
58). It is for this reason that article 141 invests decisions of this Court with special
authority, but the weight of that authority can only be what we ourselves give to it."
Even in the context of a power of review, properly so called, Ven- kataramiah, J. had this to say in
Sheonandan Paswan v. State of Bihar & Ors., [1987] 1 S.C.C. 288:
"The review petition was admitted after the appeal had been dismissed only because
Nandini Satpathy cases, (1987 1 S.C.C.269 and 1987 lS.C.C.279) had been
subsequently referred to a larger bench to review the earlier decisions. When the
earlier decisions are allowed to remain intact, there is no justification to reverse the
decision of this Court by which the appeal had already been dismissed. There is no
warrant for this extraordinary procedure to be adopted in this case. The reversal of
the earlier judgment of this Court by this process strikes at the finally of judgments of
this Court and would amount to the abuse of the power of review vested in this Court,
particularly in a criminal case. It may be noted that no other court in the country has
been given the power of review in criminal cases. I am of the view that the majority
judgment of Baharul Islam and R.B. Misra, JJ. should remain undisturbed. This case
cannot be converted into an apeal against the earlier decision of this Court "
The attempt of the appellant here is more far-reaching. He seeks not the mere upsetting of a
precedent of this Court nor the upsetting of a decision of a High Court or this Court in accordance
with the normal procedure. What he wants from us is a declaration that an order passed by a five
judge Bench is wrong and that it should, in effect, be annulled by us. This should not be done, in my
view, unless the earlier order is vitiated by a patent lack of jurisdiction or has resulted in grave
injustice or has clearly abridged the fundamental rights of the appellant. The question that arises is
whether the present case can be brought within the narrow range of exceptions which calls for such
interference. I am inclined to think that it does not.
50. I have indicated earlier, while discussing the contentions urged by Shri P.P. Rao that some of
them were plausible and, that, if I were asked to answer these questions posed by counsel for the
first time, I might agree with his answers. But I have also indicated that, in my view, they do not
constitute the only way of answering the questions posed by the learned counsel. Thus, to the
question: did this Court have the jurisdiction to issue the impugned direction, a plausible answer
could well be that it did, if one remembers that one of the transferred cases before this Court was the
revision petition before the Bombay High Court in which a transfer of the case to the High Court has
been asked for and if one gives a wide interpretation to the provisions of Article 142 of theA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

Constitution. On the question whether this Court could transfer the case to a High Court Judge, who
was not a Special Judge, a court could certainly accept the view urged by Sri Ram Jethmalani that s.
7(1) of the 1952 Act should not be so construed as to exclude the application of the procedural
provisions of the Cr.P.C. in preference to the view that has found favour with me. Though the order
dated 16.2.1984 contains no reference to, or discussion of, S. 407 Cr.P.C., this line of thinking of the
judges who issued the direction does surface in their observations in their decision of even date
rendered on the complainant's special leave petition, [1984] 2 S.C.R. 914 at page 943-4.I have
already pointed out that, if the transfer is referable to s. 407 of the 1973 Cr.P.C., it cannot be
impugned as offending Article 14 and 21 of the Constitution. The mere fact that the judges did not
discuss at length the facts or the provisions of s. 407 Cr.P.C. vis-a-vis the 1952 Act or give a reasoned
order as to why they thought that the trial should be in the High Court itself cannot render their
direction susceptible to a charge of discrimination. A view can certainly be taken that the mere
entrustment of this case to the High Court for trial does not perpetrate manifest or grave injustice.
On the other hand, prima facie, it is something beneficial to the accused and equitable in the interest
of justice. Such trial by the High Court, in the first instance, will be the rule in cases where a criminal
trial is withdrawn to the High Court under s. 407 of the Cr.P.C. Or where a High Court judge has
been constituted as a Special Judge either under the 1952 Act or some other statute. The absence of
an appeal to the High Court with a right of seeking for further leave to appeal to the Supreme Court
may be considered outweighed by the consideration that the original trial will be in the High Court
(as in Sessions cases of old, in the Presidency Towns) with a statutory right of appeal to the Supreme
Court under s. 374 of the Cr.P.C. In this situation, it is difficult to say that the direction issued by
this Court in the impugned order is based on a view which is manifestly incorrect, palpably absurd
or patently without jurisdiction. Whether it will be considered right or wrong by a different Bench
having a second-look at the issues is a totally different thing. It will be agreed on all hands that it will
not behove the prestige and glory of this Court as envisaged under the Constitution if earlier
decisions are revised or recalled solely because a later Bench takes a different view of the issues
involved. Granting that the power of review is available, it is one to be sparingly exercised only in
extraordinary or emergent situations when there can be no two opinion about the error or lack of
jurisdiction in the earlier order and there are adequate reasons to invoke a resort to an
unconventional method of recalling or revoking the same. In my opinion, such a situation is not
present here.
51. The only question that has been bothering me is that the appellant had been given no chance of
being heard before the impugned direction was given and one cannot say whether the Bench A
would have acted in the same way even if he had been given such opportunity. However, in the
circumstances of the case, I have come to the conclusion that this is not a fit case to interfere with
the earlier order on that ground. It is true that the audi altarem partem rule is a basic requirement of
the rule of law. But judicial decisions also show that the degree of compliance with this rule and the
extent of consequences flowing from failure to do so will vary from case to case. Krishna Iyer, J.
Observed thus in Nawabkhan Abbaskhan v. State, [1974]3 S.C.R. 4/7 thus:
"an order which infringed a fundamental freedom passed in violation of the audi
alteram partem rule was a nullity. A determination is no determination if it is
contrary to the constitutional mandate of Art. 19. On this footing the externmentA.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

order was of no effect and its violation was not offence. Any order made without
hearing the party affected is void and ineffectual to bind parties from the beginng if
the injury is to a constitutionally guaranteed right. May be that in ordinary legislation
or at common law a Tribunal having jurisdiction and failing to-hear the parties may
commit an illegality which may render the proceedings voidable when a direct attack
was made thereon by way of appeal, revision or review but nullity is the consequence
of unconstitutionality and so the order of an administrative authority charged with
the duty of complying with natural justice in the exercise of power before restricting
the fundamental right of a citizen is void ab initio and of no legal efficacy. The duty to
hear menacles his jurisdictional exercise and any act is, in its inception, void except
when performed in accordance with the conditions laid down in regard to hearing. "
(emphasis added) So far as this case is concerned, I have indicated earlier that the
direction Of 16.2.1984 cannot be said to have infringed the fundamental rights of the
appellant or caused any miscarriage of justice. As pointed out by Sri Jethmalani, the
appellant did know, on 16.2.84, that the judges were giving such a direction and yet
he did not protest. Perhaps he did think that being tried by a High Court Judge would
be more beneficial to him, as indeed was likely to be. That apart, as discussed earlier,
several opportunities were available for the appellant to set this right. He did not
move his little finger to obtain a variation of this direction from this Court. He is
approaching the Court nearly after two years of his trial by the learned judge in the
High Court. Volumes of testimony, we are told, have been recorded and numerous
exhibits have been admitted as evidence. Though the trial is only at the stage of the
framing charges, the trial being according to the warrant procedure, a lot of evidence
has already gone in and the result of the conclusions of Sabyasachi Mukharji, J.
would be to wipe the slate clean. To take the entire matter back at this stage to square
no. 1 would be the very negation of the purpose of the 1952 Act to speed up all such
trials and would result in more injustice than justice from an objective point of view.
As pointed out by Lord Denning in R. v. Secretary of State for the Home Departrnent
ex parte Mughal, l 19731 3 All E.R. 796, the rules of natural justice must not be
stretched too far. They should not be allowed to be exploited as a purely technical
weapon to undo a decision which does not in reality cause substantial injustice and
which, had the party been really aggrieved thereby, could have been set right by
immediate action. After giving my best anxious and deep thought to the pros and
cons of the situation I have come to the conclusion that this is not one of those cases
in which I would consider it appropriate to recall the earlier direction and order a
retrial of the appellant de novo before a Special Judge. I would, therefore, dismiss the
appeal.
O R D E R In view of the majority judgments the appeal is allowed; all proceedings in
this matter subsequent to the directions of this Court on 16th February, 1984 as
indicated in the judgment are set aside and quashed. The trial shall proceed in
accordance with law, that is to say, under the Act of 1952.
N.P.V.A.R. Antulay vs R.S. Nayak & Anr on 29 April, 1988

