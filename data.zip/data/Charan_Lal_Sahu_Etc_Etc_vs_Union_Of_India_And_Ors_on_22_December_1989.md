Charan Lal Sahu Etc. Etc vs Union Of India And Ors on 22
December, 1989
Equivalent citations: 1990 AIR 1480, 1989 SCR SUPL. (2) 597, AIR 1990
SUPREME COURT 1480, (1989) 4 JT 582 (SC), (1990) 1 COMLJ 125, 1990 (1)
SCC 613
Author: Sabyasachi Mukharji
Bench: Sabyasachi Mukharji, K.N. Singh, A.M. Ahmadi, K.N. Saikia
           PETITIONER:
CHARAN LAL SAHU ETC. ETC.
        Vs.
RESPONDENT:
UNION OF INDIA AND ORS.
DATE OF JUDGMENT22/12/1989
BENCH:
MUKHARJI, SABYASACHI (CJ)
BENCH:
MUKHARJI, SABYASACHI (CJ)
SINGH, K.N. (J)
RANGNATHAN, S.
AHMADI, A.M. (J)
SAIKIA, K.N. (J)
CITATION:
 1990 AIR 1480            1989 SCR  Supl. (2) 597
 1990 SCC  (1) 613        JT 1989 (4)   582
 CITATOR INFO :
 E          1991 SC 101  (30,278)
 E          1992 SC 248  (31,33,35,36,44,70,71,79,80,81
ACT:
    Constitution  of  India,  1950:  Articles  14,  19   and
21--Bhopal  Gas  Leak Disaster (Processing of  claims)  Act,
1985--Whether constitutionally valid.
    Preamble  and  Articles  38,  39  and  39A--Doctrine  of
'parens  patriae'--Applicability  of Exercise  of  sovereign
power--Limitations.   Articles  21 ,  48A  and   51(g)--Human
rights--State's obligation to protect--Need for enacting law
protecting  the constitutional rights of  citizens--Evolving
standards  highlighted by clauses 9 and 13 of U.N.  Code  of
Conduct on transnational corporations.Charan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

    Bhopal  Gas  Leak Disaster (Processing of  claims)  Act,
1985:  Sections 3, 4, 5, 9 and  11--Constitutional  validity
of.  Central  Govt.  representing victims  in  suit  against
multinational company--Govt. holding share in company--Govt.
alleged to be joint tort feasor--Whether competent to repre-
sent victims--Whether principles of natural justice  violat-
ed.
    Settlement  of claims before  court--Pre-decisional  and
post  decisional notice--Need for----Effect of non-issue  of
notice.
    Power conferred on Central Govt. to represent victims in
suit-Divesting individual rights to legal  remedy--Procedure
followed-Whether consistent with the Code of Civil Procedure
1908.
    Interim  Compensation--Payment of.  Precautionary  meas-
ures-Need  for--Guidelines for the future--Immediate  relief
to victims-Setting up of a Tribunal--Creation of  Industrial
Disaster Fund-Mooted.
Code of Civil Procedure, 1908: Order I Rule 8 and  Order
23  Rule  3B--Procedure followed under the Bhopal  Gas  Leak
Disaster  (Processing  of claims) Act,  1985--Central  Govt.
representing victims in suit-Divesting individual rights  to
legal remedy--Whether procedure
598
standard and fair--Whether violative of principles of  natu-
ral justice.
    Administrative Law--Principles of Natural Justice.'  Act
of  Parliament within legislative  competence--applicability
of the principles.
    Pre-decisional  notice  not  given--Effect  of.  Central
Government representing victims in a suit against a multina-
tional  company--Govt.  having  shares  in  company--Alleged
tort-feasor--Whether  competent to  represent  victims--Doc-
trine that no man shall be judge of his own  cause--Doctrine
of necessity----Doctrine of 'defacto validity'--Doctrine  of
bona fide representation--Applicability of.
    Statutory   construction:  Constructive  intuition   ap-
proach--statute     to    be    read    purposefully     and
meaningfully--Regard to be had to the spirit of the  statute
and the mischief intended to be cured by it.
    Law  of Torts: Bhopal Gas Leak Disaster  (Processing  of
claims)   Act,   1985--Grant  of  interim  relief   to   the
victims--Whether  inherent in the Act and the Scheme  framed
thereunder--Liability  of  tort-feasor-Whether  limited   to
civil  liability to compensation-whether  includes  criminal
liability to punitive damages also.
HEADNOTE:
    Union  Carbide  (India) Ltd. (UCIL) is a  subsidiary  of
Union  Carbide  Corporation (UCC), a New  York  Corporation.
UCIL was incorporated in India in 1954. 50.99% of its  shareCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

holding was with UCC and 22% of the shares were held by Life
Insurance Corporation of India and Unit Trust of India. UCIL
owned  a  chemical plant in Bhopal for  the  manufacture  of
pesticides using Methyl Isocyanate (MIC) a highly toxic gas.
    On  the night between 2nd and 3rd December, 1984,  there
was a massive escape of lethal gas from the MIC Storage tank
at  the Bhopal plant resulting in the tragic death of  about
3,000  people.  Thousands of people suffered  injuries.  The
environment also got polluted, badly affecting the flora and
the fauna.
    On  behalf  of  the victims, many suits  were  filed  in
various District Courts in the United States of America. All
such  suits  were  consolidated by  the  Judicial  Panel  on
Multi-District  Litigation  and were assigned  to  the  U.S.
District  Court,  Southern District of New  York  and  Judge
Keenan was the Presiding Judge throughout. Later, the  legal
battle shifted to Indian Courts, as it could not proceed  in
the U.S. Courts, on the ground of forum non conveniens.
599
    Meanwhile,  the Bhopal Gas Leak Disaster (Processing  of
claims)  1985 was passed by the Government of India  with  a
view  to secure that the claims arising out of or  connected
with the Bhopal gas leak disaster were dealt with  speedily,
effectively and equitably.
    Union of India filed a suit for damages in the  District
Court of Bhopal on 5.9.86. However, there were  negotiations
for  a settlement; hut ultimately the settlement  talks  had
failed.
    On 17.12.1987, the District Judge ordered interim relief
of  Rs.350  crores.  On appeal, the High  Court,  on  4.4.88
modified  the  order of the District Judge  and  ordered  an
interim relief of Rs.250 crores.
    Aggrieved,  the  UCC as also the Union  of  India  filed
petitions  for  special leave before this Court.  Leave  was
granted.  By  its  orders dated 14.2.89  and  15.2.89,  this
Court,  on the basis of a settlement arrived at between  the
parties,  directed  UCC  to pay a sum of  470  million  U.S.
Dollars  to  the Union of India in full  settlement  of  all
claims, rights and liabilities related to and arising out of
the Bhopal gas disaster.
    The  said orders were passed keeping in view the  Bhopal
Gas Disaster (Processing of claims) Act, 1985.
    The present Writ Petitions challenge the  constitutional
validity of the said Act inter alia on the grounds that  the
Act is violative of the fundamental rights guaranteed  under
Articles 14, 19 and 21 of the Constitution: that the Act  is
violative of the Principles of Natural Justice mainly on the
ground  that Union of India, being a joint  tort-feasor,  in
that it has permitted establishment of such factories  with-
out necessary safeguards, has no locus standi to  compromise
on  behalf of the victims; that the victims and their  legal
heirs were not given the opportunity of being heard,  before
the  Act  was passed; that in the guise of giving  aid,  theCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

State could not destroy the rights inherent in its citizens;
nor  could it demand the citizens to surrender their  rights
to the State; that vesting of the rights in Central  Govern-
ment was bad and unreasonable because there was conflict  of
interest  between  the Central Government and  the  victims.
since  the Central Government owned 22% share in  UCIL,  and
that  would make the Central Government a Judge in  its  own
cause.
Disposing of the Writ Petitions, this Court,
600
HELD: Sabyasachi Mukharji, CJ and K.N. Saikia, J.--Per C J:
    1.1  The Act is constitutionally valid. It  proceeds  on
the  hypothesis  that until the claims of  the  victims  are
realised  or obtained from the delinquents, namely, UCC  and
UCIL by settlement or by adjudication and until the proceed-
ings  in  respect thereof continue, the  Central  Government
must  pay interim compensation or maintenance for  the  vic-
tims. In entering upon the settlement in view of s. 4 of the
Act, regard must be had to the views of the victims and  for
the  purpose of giving regard to these, appropriate  notices
before  arriving at any settlement, was necessary.  In  some
cases,  however, post-decisional notice might be  sufficient
but in the facts and the circumstances of the present  case,
no useful purpose would be served by giving a post-decision-
al  hearing having regard to the circumstances mentioned  in
the  order  of  this Court dated 4th May,  1989  and  having
regard to the fact that there are no further additional data
and facts available with the victims which can be profitably
and  meaningfully presented to controvert the basis  of  the
settlement  and further having regard to the fact  that  the
victims  had their say, or on their behalf their  views  had
been  agitated in these proceedings, and will  have  further
opportunity  in  the pending  review  proceedings.  [703E-H;
704A]
    1.2 Though settlement without notice is not quite  prop-
er,  on  the  materials so far available, it  is  seen  that
Justice  has  been done to the victims but justice  has  not
appeared to have been done. In view of the magnitude of  the
misery  involved and the problems in this case, the  setting
aside of the settlement on this ground in view of the  facts
and the circumstances of this case keeping the settlement in
abeyance  and giving notice to the victims for a  post-deci-
sional  hearing  would not be in the  ultimate  interest  of
justice.  It is true that not giving notice was  not  proper
because principles of natural justice are fundamental in the
constitutional  set up of this country. No man or  no  man's
right should be affected without an opportunity to ventilate
his views. Justice is a psychological yearning, in which men
seek acceptance of their view point by having an opportunity
of vindication before the forum or the authority enjoined or
obliged to take a decision affecting their right. Yet in the
particular  situations, one has to bear in mind how  an  in-
fraction  of that should be sought to be removed in  accord-Charan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

ance  with justice. "To do a great right" after all.  it  is
permissible  sometimes "to do a little wrong". In the  facts
and  circumstances  of the case, this is one of  those  rare
occasions. [701G-H; 702A-C]
     2.1  The constitutional validity of the  statute  would
have to be determined on the basis of its provisions and  on
the  ambit of its operation as reasonably construed. It  has
to be borne in mind that if so
601
judged it passed the test of reasonableness, then the possi-
bility  of the power conferred being improperly used  is  no
ground for pronouncing the law itself invalid. [659E-G]
    2.2  Conceptually and from the jurisprudential point  of
view,  especially in the background of the Preamble  to  the
Constitution  of  India  and the mandate  of  the  Directive
Principles, it was possible to authorise the Central Govern-
ment to take over the claims of the Victims to fight against
the  multinational  corporation in respect  of  the  claims.
Because  of the situation the victims were under  disability
in pursuing their claims in the circumstances of the  situa-
tion  fully  and properly. But there is  no  prohibition  or
inhibition,  for Indian State taking over the claims of  the
victims  or for the State acting for the victims as the  Act
has sought to provide. [640E-H]
    2.3 The Act does provide a special procedure in  respect
of  rights  of the victims and to that  extent  the  Central
Govt. takes upon itself the rights of  the victims. It is  a
special  Act  providing a special procedure for  a  kind  of
special  class  of victims. In view of the enormity  of  the
disaster  the  victims of the Bhopal gas leak  disaster,  as
they were placed against the multi-national and a big Indian
Corporation  and in view of the presence of foreign  contin-
gency  lawyers to whom the victims were exposed, the  claim-
ants and victims can legitimately be described as a class by
themselves different and distinct, sufficiently separate and
identifiable to be entitled to special treatment for  effec-
tive, speedy, equitable and best advantageous settlement  of
their claims. There indubitably is differentiation. But this
differentiation  is based on a principle which has  rational
nexus with the aim intended to be achieved by this differen-
tiation.  The disaster being unique in its character and  in
the recorded history of industrial disaster, situated as the
victims  were  against  a  mighty  multinational  with   the
presence  of  foreign  contingency lawyers  looming  on  the
scene,  there were sufficient grounds for such  differentia-
tion and different treatment. In treating the victims of the
gas  leak disaster differently and providing them  a  proce-
dure,  which  was just, fair, reasonable and which  was  not
unwarranted or unauthorised by the Constitution, Article  14
is not breached. [683E-H; 684A-B]
    Collector of Customs, Madras v. Nathella Sampathu  Chet-
ty, [1962] 3 SCR 786; P.J. Irani v. State of Madras,  [1962]
1  SCR 169; D.K. Trivedi v. State of Gujarat, [1986]  Suppl.Charan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

SCC 20, relied on.
    Ballast  Corporation v. O.D. Commission, [1960] AC  490,
referred to-
602
    3.1  The  present case is one where the Govt.  of  India
only represented the victims as a party' and did not adjudi-
cate between the victims and the UCC. It is the court  which
would adjudicate the rights of the victims. The  representa-
tion  of  the victims by the Government of India  cannot  be
held  to  be  bad, and there is and there was  no  scope  of
violation of any principle of natural justice. [670B]
    3.2 The connotation of the term "parens patria"  differs
from country to country, for instance, in England it is  the
King, in America it is the people, etc. According to  Indian
concept  parens patria doctrine recognised King as the  pro-
tector  of all citizens as parent. The Government is  within
its duty to protect and to control persons under disability.
Conceptually, the parens patriae theory is the obligation of
the  State to protect and take into custody the  rights  and
privileges of its citizens for discharging its  obligations.
Our Constitution makes it imperative for the State to secure
to  all its citizens the rights guaranteed by the  Constitu-
tion and where the citizens are not in a position to  assert
and  secure their rights, the State must come  into  picture
and  protect  and fight for the right of the  citizens.  The
Preamble to the Constitution, read with the Directive  Prin-
ciples  contained  in Articles 38, 39 and  39A  enjoins  the
State  to take up these responsibilities. It is the  protec-
tive measure to which the social welfare state is committed.
It  is  necessary for the State to  ensure  the  fundamental
rights in conjunction with the Directive Principles of State
Policy to effectively discharge its obligation and for  this
purpose, if necessary, to deprive some rights and privileges
of  the individual victims or their heirs to  protect  their
rights better and secure these further. [638E-H; 639A]
    3.3  The UCC had to be sued before the American  courts.
The tragedy was treated as a national calamity and the Govt.
of India had the right, and indeed the duty, to take care of
its  citizens, in the exercise of its parens patriae  juris-
diction  or  on principles analogous thereto.  After  having
statutorily  armed  itself  in recognition  of  such  parens
patriae right or on principles analogous thereto, it went to
the  American Courts. No other person was properly  designed
for  representing  the victims, as a foreign  court  had  to
recognise a right of representation. The Govt. of India  was
permitted  to represent was permitted to represent the  vic-
tims  before  the American courts. Private  plaintiffs  were
also  represented  by their attorneys. The  order  of  Judge
Keenan  permitted the Govt. of India to represent  the  vic-
tims. If there was any remote conflict of interests  between
the  Union  of India and the victims  from  the  theoretical
point  of view the doctrine of necessity would override  the
possible   violation   of   the   principles   of    naturalCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

justice--that  no  man  should be Judge  in  his  own  case.
[669C-F]
603
    3.4  The Act in question has been passed in  recognition
of the right of the sovereign to act as parens patriae.  The
Government  of India in order to effectively  safeguard  the
rights  of the victims in the matter of the conduct  of  the
case  was entitled to act as parens patriae, which  position
was reinforced by the statutory provisions, namely the  Act.
It  has to be borne in mind that conceptually and  jurispru-
dentially, the doctrine of parens patriae is not limited  to
representation  of some of the victims outside the  territo-
ries  of the country. It is true that the doctrine has  been
so  utilised in America so far. Where citizens of a  country
are  victims of a tragedy because of the negligence  of  any
multinational  in peculiar situation arises which calls  for
suitable  effective machinery to articulate  and  effectuate
the  grievance  and demands of the victims,  for  which  the
conventional  adversary system would be totally  inadequate.
The State in discharge of its sovereign obligation must come
forward.  The  Indian State because  of  its  constitutional
commitment  is obliged to take upon itself the claim of  the
victims and to protect them in their hour of need. [658B-F]
    3.5 There is no bar on the State to assume responsibili-
ties  analogous to parens patriae to discharge  the  State's
obligations under the Constitution. What the Central Govern-
ment has done in the instant case seems to be an  expression
of  its sovereign power. This power is plenary and  inherent
in every sovereign state to do all things which promote  the
health, peace, moral, education and good order of the people
and tend to increase the wealth and prosperity of the State.
Sovereignty is difficult to define. By the nature of things,
the State Sovereignty in these matters cannot be limited. It
has  to  be adjusted to the conditions touching  the  common
welfare  when covered by legislative enactments. This  power
is  to the public what the law of necessity is to the  indi-
vidual. It is comprehended in the maxim salus populi suprema
lex--regard for public welfare is the highest law. It is not
a  rule, it is an evolution. This power has always  been  as
broad  as  public welfare and as strong as the  arm  of  the
state, this can only be measured by the legislative will  of
the people, subject to the fundamental rights and  constitu-
tional limitations. This is an emanation of sovereignty  and
it  is the obligation of the State to assume such  responsi-
bilities and protect its citizens. [658G-H; 659A-C]
    3.6  In the instant case, the victims cannot be  consid-
ered  to be any match to the multinational companies or  the
Government  with whom in the conditions that the victims  or
their  representatives were after the  disaster  physically,
mentally, financially, economically and also because of  the
position  of  litigation would have to contend.  In  such  a
situation of
604Charan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

predicament the victims can legitimately be considered to be
disabled.  They  were in no position by themselves  to  look
after  their  own interest effectively or  purposefully.  In
that  background,  they are people who  needed  the  State's
protection  and should come within the umbrella  of  State's
sovereignty  to assert, establish and maintain their  rights
against  the  wrong  doers in this mass  disaster.  In  that
perspective,  it is jurisprudentially possible to apply  the
principle  of  parens patriae doctrine to the  victims.  But
quite  apart from that, it has to be borne in mind  that  in
this  case the State is acting on the basis of  the  Statute
itself.  For the authority of the Central Government to  sue
for and on behalf of or instead in place of the victims,  no
other  theory, concept, or any jurisprudential principle  is
required  than the Act itself. The Act empowers and  substi-
tutes the Central Government. The victims have been divested
of their rights to sue and such claims and such rights  have
been vested in the Central Government. The victims have been
divested because the victims were disabled. The  disablement
of the victims vis-a-vis their adversaries in this matter is
a self evident factor. Even if the strict application of the
'parens  patriae' doctrine is not in order, as a concept  it
is a guide. The jurisdiction of the State's power cannot  be
circumscribed by the limitations of the traditional  concept
of parens patriae. Jurisprudentially it could be utilised to
suit or alter or adapt itself to the changed  circumstances.
In the situation in which the victims were, the State had to
assume  the  role of a parent protecting the rights  of  the
victims who must come within the protective umbrella of  the
State  and the common sovereignty of the Indian people.  The
act  is an exercise of the sovereign power of the State.  It
is an appropriate evolution of the expression of sovereignty
in  the situation that had arisen. It has to be accepted  as
such. [685C-H]
    3.7  The  concept  of parens patriae can  be  varied  to
enable  the Government to represent the victims  effectively
in domestic forum if the situation so warrants. There is  no
reason  to  confine the 'parens patriae'  doctrine  to  only
quasi-sovereign right of the State independent of and behind
the title of the citizen. [692B-C]
    3.8 The power to compromise and to conduct the  proceed-
ings  are not uncanalised or arbitrary. These  were  clearly
exercisable  only in the ultimate interests of the  victims.
The possibility of abuse of a statute does not impart to  it
any element of invalidity. [659C-D]
    E.P.  Royappa v. State of Tamil Nadu, [1974] 2 SCR  348;
Menaka  Gandhi  v. Union of India, [1978] 2  SCR  621;  R.D.
Shetty v. International Airport Authority of India, [1979] 3
SCR 1014 followed.
605
Ram Saroop v. S.P. Sahi, [1969] 2 Suppl. SCR 583 relied on.
    Budhkaran Chankhani v. Thakur Prasad Shah, AIR 1942  Col
311; Banku Behari Mondal v. Banku Behari Hazra, AIR 1943 CalCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

203; Medai Dalavoi T. Kumaraswamy Mudaliar v. Medai  Dalavoi
Rajammal, AIR 1957 Mad. 563 approved.
    State of U.P. v. Poosu, [1978] 3 SCR 1005; K.M. Nanavati
v.  State of Bombay, [1961] 1 SCR 497; Ram Gopal Sarubai  v.
Smt. Sarubhai & Ors., [1981] 4 SCC 505; India Mica &  Mican-
ite  Industries Ltd. v. State of Bihar & Ors. [1982]  3  SCC
182; Alfred L Snapp & SonInc. v. Puerto Rico, 458 US 592 73,
Ed.  2d 995, 102 s. ct. 3260; State of Georgia v.  Tennessee
Copper  Co.,  206 US 230, 51 L.Ed. 1038 27 s. et.  618,  re-
ferred to.
    B.K. Mukherjea on Hindu Religious and Charitable Trusts,
Tagore  Law  Lectures,  5th Edn. p. 404;  Words  &  Phrases,
permanent Edn.
vol.  33  p. 99; Black's Law Dictionary, 5th Edn.  1979,  p.
1003; Weaver's Constitutional Law, p. 490; American  Consti-
tutional  Law  by  Lawrence H. Tribe 1978  Edn.  para  3.24,
referred to.
    4.1  Section  3  provides for the  substitution  of  the
Central  Government with the right to represent and  act  in
place of (whether within or outside India) every person  who
has  made or is entitled to make, a claim in respect of  the
disaster. The State has taken over the rights and claims  of
the  victims  in  the exercise of sovereignty  in  order  to
discharge  the constitutional obligations as the parent  and
guardian  of  the  victims who in the  situation  as  placed
needed  the umbrella of protection. Thus, the State has  the
power  and jurisdiction and for this purpose unless the  Act
is otherwise unreasonable or violative of the constitutional
provisions  no question of giving a hearing to  the  parties
for taking over these rights by the State arises. For legis-
lation by the Parliament, no principle of natural justice is
attracted provided such legislation is within the competence
of  the  legislature. Indeed the present Act is  within  the
competence  of the Parliament. Section 3 makes  the  Central
Government the dominoes litis and it has the carriage of the
proceedings, but that does not solve the problem of by  what
procedure the proceedings should be carried. [692A-D]
    4.2  Section  4 means and entails that  before  entering
into  any settlement affecting the rights and claims of  the
victims  some kind of notice or information should be  given
to the victims. [699D]
606
    4.3 Sections 3 and 4 are categorical and clear. When the
expression is explicit, the expression is conclusive,  alike
in what it says and in what it does not say. These give  the
Central Government an exclusive right to act in place of the
persons who are entitled to make claim or have already  made
claim.  The expression 'exclusive' is explicit and  signifi-
cant.  The  exclusively cannot be wittled  down  or  watered
down. The said expression must be given its full meaning and
extent.  This is corroborated by the use of  the  expression
'claim'  for  all purposes. If such duality  of  rights  are
given  to. the Central Government alongwith the  victims  inCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

instituting  or  proceeding for the realisation or  the  en-
forcement  of  the  claims arising out of  Bhopal  gas  leak
disaster, then that would be so cumbersome that it would not
be speedy, effective or equitable and would not be the  best
or  more  advantageous  procedure for  securing  the  claims
arising out of the leakage. [683A-C]
    4.4 Sections 3 and 4 of the Act should be read  together
alongwith  other  provisions of the Act  and  in  particular
sections 9 and 11 of the Act. These should be appreciated in
the  context of the object sought to be achieved by the  Act
as indicated in the Statement of objects and Reasons and the
Preamble  to the act. The Act was so designed that the  vic-
tims  of the disaster are fully protected and the claims  of
compensation  or  damages for loss of life or  personal  in-
juries  or  in respect of other matters arising  out  of  or
connected  with the disaster are processed speedily,  effec-
tively,  equitably and to the best advantage of  the  claim-
ants. Section 3 of the Act is subject to other provisions of
the  Act which includes Sections 4 and 11. Section 4 of  the
Act  opens  with non-obstante clause, vis-a-vis,  section  3
and, therefore overrides section 3. [659G-H; 660A-B]
    4.5 In the instant case, the Government of India is only
capable  to represent the victims as a party. The  adjudica-
tion of the claims would be done by the Court. The  doctrine
of 'Bona fide Representation' as also 'defacto validity' are
not applicable to the present case. [690F]
Basheshar v. Income Tax Commissioner, AIR 1959 SC 149; In re
Special Courts Bill, [1979] 2 SCR 476; A.R. Antulay v.  R.S.
Nayak  & Anr., [1988] 2 SCC 602; Ram Krishna Dalmia v.  Ten-
dulkar,  [1955]  SCR 279; Ambika Prasad Mishra v.  State  of
U.P.  &  Ors. etc. [1980] 3 SCR 1159;  Bodhan  Chowdhary  v.
State  of Bihar, [1955] 1 SCR 1045; Lakshmi Kant  Pandey  v.
Union of India, [1984] 2 SCR 795; M/s Mackinnon Mackenzie  &
Co.  Ltd.  v. Audrey D' Costa and Anr., [1987]  2  SCC  469;
Sheela  Barse  v. Secretary, Children Aid  Society  &  Ors.,
[1987]  1  SCR  870; Gokaraju Rangaraju v.  State  of  A.P.,
[1981]  3  SCR  474; Pushpadevi M. Jatia  v.  M.L.  Wadhwan.
[1987] 3 SCC 367;
607
M/s  Beopar  Sahayak (P) Ltd. & Ors. v. Vishwanath  &  Ors.,
[1987]  3  SCC  693; Dharampal Singh v.  Director  of  Small
Industries Services & Ors., AIR 1980 SC 1888; N.K.  Mohammed
Sulaiman  v. N.C. Mohammed lsmail & Ors., [1966] 1 SCR  937;
Malkariun Bin Shidrammappa Pasare v. Narhari Bin Shivappa  &
Anr., 271 A 216, referred to.
Black's Law Dictionary 5th Edn. p. 437, referred to.
    5.  The restrictions or limitations on  the  substantive
and procedural rights in the Act will have to be judged from
the point of view of the particular Statute in question.  No
abstract rule or standard of reasonableness can be  applied.
That  question has to be judged having regard to the  nature
of  the rights alleged to have been infringed in this  case,
the  extent and urgency of the evil sought to  be  remedied,Charan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

disproportionate  imposition, prevailing conditions  at  the
time, all these facts will have to be taken into  considera-
tion.  Having considered the background, the plight  of  the
impoverished, the urgency of the victims' need, the presence
of the foreign contingency lawyers, the procedure of settle-
ment  in  USA in mass action, the strength  of  the  foreign
multinationals, the nature of injuries and damages, and  the
limited  but significant right of participation of the  vic-
tims  as contemplated by s. 4 of the Act, the Act cannot  be
condemned as unreasonable. [684C-E]
State of Madras v. V.G. Row, [1952] SCR 597, referred to.
    6.1 In view of the principles settled by this Court  and
accepted all over the world in a case of this magnitude  and
nature, when the victims have been given some say by Section
4 of the Act, in order to make that opportunity contemplated
by section 4 of the Act, meaningful and effective, it should
be so read that the victims have to be given an  opportunity
of making their representation before the court comes to any
conclusion in respect of any settlement. How that opportuni-
ty should be given, would depend upon the particular  situa-
tion. Fair procedure should be followed in a  representative
mass tort action. [696E-F]
    6.2  One assumption under which the Act is justified  is
that  the victims were disabled to defend themselves  in  an
action  of this type. If that is so, then the  Court  cannot
presume that the victims were a lot, capable and informed to
be able to have comprehended or contemplated the settlement.
In  the aforesaid view of the matter notice  was  necessary.
The  victims at large did not have the notice.  The  Central
Government  as the representative of the victims  must  have
the  views  of the victims and place such  view  before  the
court in such manner it considers neces-
608
sary  before  a settlement is entered into. If  the  victims
want  to advert to certain aspect of the matter  during  the
proceedings under the Act and settlement indeed is an impor-
tant  stage in the proceedings, opportunities must be  given
to the victims. Individual notices may not be necessary. The
Court can, and should in such situation formulate modalities
of giving notice and public notice can also be given  invit-
ing views of the victims by tile help of mass media.  Howev-
er,  it is not necessary that such views would  require  the
consent of all the victims. [698B-C; 698G-H; 699A]
    6.3 One of the important requirements of justice is that
people affected by an action or inaction should have  oppor-
tunity to have their say. That opportunity the victims  have
got  when these applications were heard and they were  heard
after utmost publicity and they would have further  opportu-
nity when review application against the settlement would be
heard. 1700G-H; 701A]
    7.1  The Act does not expressly exclude the  application
of  the Code of Civil Procedure. Section 11 of the Act  pro-
vides the overriding effect indicating that anything  incon-Charan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

sistent  with  the provisions of the Act or  in  other  laws
including the Civil Procedure Code should be ignored and the
Act  should prevail. Strictly speaking, Order 1 Rule 8  will
not apply to a suit or a proceeding under the Act. It is not
a  case of one having common interest with others. Here  the
plaintiff, the Central Government has replaced and  divested
the victims. 1696H; 697A-B]
    7.2  In the instant case, there is no question of  aban-
donment as such of the suit or part of the suit, the  provi-
sions  of order XXIII Rule 1 would also not strictly  apply.
However, Order XXIH Rule 3B of the Code is an important  and
significant  pointer  and  the principles  behind  the  said
provision  would apply to this case. The said rule  3B  pro-
vides  that no agreement of compromise in  a  representative
suit  shall be entered into without the leave of  the  Court
expressly  recorded in the proceedings; and sub-rule (2)  of
rule  3B enjoins that before granting such leave  the  court
shall  give notice in such manner as it may think fit  in  a
representative action. Representative suit has been  defined
under  Explanation to the said rule vide clause (d)  as  any
other suit in which the decree passed may, by virtue of  the
provisions this Code or of any other law for the time  being
in  force, bind any person who is not named as party to  the
suit. Indubitably the victims would be bound by the  Settle-
ment  though  not  named in the suit. 11his  is  a  position
conceded by all. If that is so, it would be a representative
suit  in terms of and for the purpose of Rule 315  of  Order
XXIII  of the Code. If the principles of this rule  are  the
principles  of  natural justice then we are of  the  opinion
that
609
the principles behind it would be applicable; and also  that
section 4 of the Act should be so construed in spite of  the
difficulties of the process of notice and other difficulties
of  making  "informed decision making  process  cumbersome".
[697C-G]
    7.3  In  as  much as section 4 of the Act  had  given  a
qualified  right  of  participation to  the  victims,  there
cannot  be  any question of violation of the  principles  of
natural justice. The scope of the application of the princi-
ples  of  natural  justice cannot be judged  by  any  strait
jacket formula. [662G-H]
R. Viswanathan v. Rukn-ul-Mulk Syed Abdul Wajid, [1963] 3
SCR  22;  M. Narayanan Nambiar v. State  of  Kerala,  [1963]
Supp. (2) 724; Chintaharan Ghose & Ors. v. Gujaraddi Sheik &
Ors.,  AIR 1951 Cal. 456; Ram 'Sarup v. Nanak Ram, AIR  1952
All. 275; referred to.
    8. The Act has to be understood that it is in respect of
the  person responsible, being the person  in-charge-of  the
UCIL and the parent company UCC. This interpretation of  the
Act  is further strengthened by the fact that  a  'claimant"
has been defined in clause (c) of Section 2 as a person  who
is  entitled to make a claim and the expression "person"  inCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

Section  2(e)  includes the Government. Therefore,  the  Act
proceeded  on the assumption that the Government could be  a
claimant being a person as such. [690A-B]
    9.1  The fact that the provisions of the  principles  of
natural  justice  have to be complied with,  is  undisputed.
This is well-settled by the various decisions of the  Court.
The Indian Constitution mandates that clearly, otherwise the
Act and the actions would be violative of Article 14 of  the
Constitution  and  would  also  be  destructive  of  Article
19(1)(g) and negate Article 21 of the Constitution by  deny-
ing a procedure which is just, fair and reasonable. [693D-E]
    9.2  Rules  of natural justice are not  embodied  rules.
Hence,  it was not possible to make an exhaustive  catalogue
of  such  rules. Audi alteram partem is a  highly  effective
rule  devised by the Courts to ensure that a  statutory  au-
thority  arrives at a just decision and it is calculated  to
act as a healthy check on the abuse or misuse of power.  The
rules  of  natural  justice can operate only  in  areas  not
covered  by any law validly made. The general  principle  as
distinguished  from an absolute rule of uniform  application
is  that where a statute does not in terms exclude the  rule
of prior hearing but contemplates a post-decisional hearing
610
amounting  to a full review of the original order on  merits
then such a statute would be construed as excluding the audi
alteram  partem  rule at the pre-decisional  stage.  If  the
statute  conferring the power is silent with regard  to  the
giving  of a pre-decisional hearing to the  person  affected
the  administrative decision after  post-decisional  hearing
was good. [694A-D]
    9.3 In the instant case, no question of violation of the
principle  of natural justice arises, and there is no  scope
for the application of the principle that no man should be a
Judge  in  his  own cause. The Central  Government  was  not
judging any claim, but was fighting and advancing the claims
of  the  victims.  The adjudication would  be  done  by  the
courts, and therefore, there is no scope of the violation of
any principle of natural justice. [688G-H; 689A-B]
    Menaka Gandhi v. Union of India, [1978] 2 SCR 621;  Olga
Tellis  v. Bombay Municipal Corporation, [1985] Supp. 2  SCR
51;  Union of India v. Tulsi Ram Patel, [1985] Supp.  2  SCR
131;  Swadeshi Cotton Mills v. Union of India, [1981] 2  SCR
533, relied on.
    Ganga Bai v. Vijay Kumar, [1974] 3 SCR 882; S.L.  Kapoor
v.  Jagmohan, [1981] 1 SCR 745; Sangram v. Election  Commis-
sion, [1955] 2 SCR 1, referred to.
    10.  Though  not expressly stated, the Act  proceeds  on
'the  major inarticulate premise'. It is on this promise  or
premise  that  the State would be justified in  taking  upon
itself the right and obligation to proceed and prosecute the
claim and deny access to the courts of law to the victims on
their own. If it is only so read, it can only be held to  be
constitutionally valid. It has to be borne in mind that  theCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

language of the Act does not militate against this construc-
tion  but on the Contrary. Sections 9, 10 and the scheme  of
the Act suggest that the Act contains such an obligation. If
it  is so read, then only meat can be put into the  skeleton
of  the  Act making it meaningful and  purposeful.  The  Act
must, therefore, be so read. This approach to the  interpre-
tation of the Act can legitimately be called the  'construc-
tive  intuition' which is a permissible mode of viewing  the
Acts of Parliament. The freedom to search for 'the spirit of
the  Act'  or the quantity of the mischief at  which  it  is
aimed (both synonymous for the intention of the  parliament)
opens  up  the possibility of liberal  interpretation  "that
delicate and important branch of judicial power, the conces-
sion of which is dangerous, the denial ruinous". Given  this
freedom it is a rare opportunity though never to be  misused
and challenge for the Judges to adopt and give meaning to
611
the act, articulate and inarticulate and thus translate  the
intention  of  the Parliament and fulfil the object  of  the
Act.  After  all, the Act was passed to give relief  to  the
victims, who, it was thought, were unable to establish their
own rights and fight for themselves. [687E-H; 688A]
    11.1 The circumstances that financial institutions  held
shares  in the UCIL would not disqualify the  Government  of
India  from acting as parens patriae and in discharging  its
statutory  duties  under the Act. The suit  was  filed  only
against  the UCC and not against UCIL. On the basis  of  the
claim made by the Government of India, UCIL was not a neces-
sary  party.  It was suing only the multinational  based  on
several  legal grounds of liability of the UCC, inter  alia,
on  the basis of enterprise liability. If the Government  of
India had instituted a suit against UCIL to a certain extent
it  would have weakened its case against UCC in view of  the
judgment of this Court in M.C. Mehta's case. [668H; 669A-B]
M.C. Mehta v. Union of India, [1987] 1 SCR 819, referred to.
    11.2 Even if there was any remote conflict of  interests
between the Union of India and the victims on account of the
sharesholding,  doctrine  of necessity  would  override  the
possible  violation  of the principles of  natural  justice.
[669F]
    Kasturilal  Ralia Ram Jain v. State of UP, [1965] 1  SCR
375;  State  of Rajasthan v. Vidyawati, [1962] 2  Supp.  SCR
989;  J. Mohapatra & Co. & Anr. v. State of Orissa  &  Anr.,
[1984] 4 SCC 103, referred to.
    Halsbury's  Laws  of England, Vol. 1, 4th Edn.  para  73
Smith's  Judicial Review of Administrative Action, 4th  Edn.
pp. 276-277; Natural Justice by G.A. Flick, [1979] Edn.  pp.
138-141, referred to.
    12.  The  Act does not create new causes  of  action  or
create  special courts. The jurisdiction of the civil  court
to entertain suit would still arise out of section 9 of  the
CPC  and the substantive cause of action and the  nature  of
the  reliefs  available would also continue  to  remain  un-Charan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

changed.  The only difference produced by the provisions  of
the Act would be that instead of the suit being filed by the
victims  themselves the suit would be filed by  the  Central
Government on their behalf. [655F]
    13. Normally, in measuring civil liability, the law  has
attached  more importance to the principle  of  compensation
than  that of punishment. Penal redress,  however,  involves
both compensation to the
612
person  injured  and punishment as deterrence. The  Act,  as
such does not abridge or curtail damage or liability whatev-
er that might be. So the challenge to the Act on the  ground
that there has been curtailment or deprivation of the rights
of  the  victims which is unreasonable in the  situation  is
unwarranted and cannot be sustained. [680G-H; 681A-F]
    Roshanlal  Kuthiala & Ors. v. R.B. Mohan  Singh,  Oberoi
(1975) 2 SCR 491; Nandram Heeralal v. Union of India & Anr.,
AIR 1978 M.P. 209; Ryland v. Flatcher, (1868) Vol 3 LR E&  I
Appeal  Cases  330; Rookes v. Barnard, [1964] AC  1129,  re-
ferred to.
Salmond's Law of Torts, 15th Edn. p. 30, referred to.
    14.  The Act in question does not purport to  deal  with
the  criminal liability, if any, of the parties  or  persons
concerned nor it deals with any of the consequences  flowing
from  those. This position is clear from the provisions  and
the preamble to the Act. [636F]
    15. The major inarticulate premise apparent from the Act
and the scheme and the spirit of the Act is that so long  as
the  rights  of the victims are prosecuted  the  state  must
protect  the victims. Otherwise the object of the Act  would
be  defeated its purpose frustrated. Therefore,  continuance
of the payments of the interim maintenance for the continued
sustenance  of the victims is an obligation arising  out  of
State's assumption of the power and temporary deprivation of
the  rights of the victims and divestiture of the  right  of
the victims to fight for their own rights. This is the  only
reasonable  interpretation which is just, fair  and  proper.
[686B-C]
    16. The promises made to the victims and hopes raised in
their hearts and minds can only be redeemed in some  measure
if  attempts  are made vigorously to distribute  the  amount
realised to the victims in accordance with the scheme.  That
would be redemption to a certain extent. The law relating to
damages  and payment of interim damages or  compensation  to
the victims of this nature should be seriously and scientif-
ically examined by the appropriate agencies. [704F-H; 705A]
    17.  The  Bhopal  Gas Leak disaster  and  its  aftermath
emphasise the need for laying down certain norms and  stand-
ards that the Government may follow before granting  permis-
sion or licences for the running of industries dealing  with
materials which are of dangerous potentialities. The Govern-
ment,  should, therefore, examine or have the problem  exam-
ined by an expert committee as to what should be the  condi-Charan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

tions on
613
which  future licences and/or permission for running  indus-
tries  on  Indian  soil would be granted  and  for  ensuring
enforcement of those conditions, sufficient safety  measures
should  be formulated and scheme of  enforcement  indicated.
The Government should insist as a condition precedent to the
grant of such licences or permission, creation of a fund  in
anticipation  by the industries to be available for  payment
of  damages  out  of the said fund in case  of  leakages  or
damages in case of accident or disaster flowing from  negli-
gent  working  of such industrial operations or  failure  to
ensure  measures preventing such occurrence. The  Government
should  also ensure that the parties must agree to abide  to
pay such damages out of the said Fund by procedure separate-
ly  evolved for computation and payment of  damages  without
exposing  the victims or sufferers of the negligent  act  to
the  long and delayed procedure. Special procedure  must  be
provided  for and the industries must agree as  a  condition
for  the grant of licence to abide by such procedure  or  to
abide  by  statutory arbitration. The basis for  damages  in
case  of  leakages and accident should also  be  statutorily
fixed  taking into consideration the nature of  damages  in-
flicted, the consequences thereof and the ability and capac-
ity  of  the parties to pay. Such should  also  provide  for
deterrant or punitive damages, the basis for which should be
formulated  by a proper expert committee or by  the  Govern-
ment.  For  this  purpose, the Government  should  have  the
matter  examined by such body as it considers necessary  and
proper  like the Law Commission or other  competent  bodies.
This is vital for the future. [705B-F]
    18.  That people are born free, the dignity of the  per-
sons  must be recognised, and competent tribunal is  one  of
the surest methods of effective remedy. If, therefore, as  a
result  of this tragedy new consciousness and  awareness  on
the  part of the people of this country to be more  vigilant
about  measures  and the necessity of ensuring  more  strict
vigilance  for permitting the operations of  such  dangerous
and poisonous gases dawn, then perhaps the tragic experience
of Bhopal would not go in vain. [682D-E]
Per Singh, J. (concurring):
    1.1  In India, the need for industrial  development  has
led to the establishment of a number of plants and factories
by  the domestic companies and under-takings as well  as  by
Transnational  Corporations.  Many of these  industries  are
engaged  in  hazardous or  inherently  dangerous  activities
which  pose potential threat to life, health and  safety  of
persons working in the factory, or residing in the surround-
ing  areas. Though working of such factories and  plants  is
regulated by a
614
number of laws of our country, there is no special  legisla-
tion providing for compensation and damages to outsiders whoCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

may suffer on account of any industrial accident. As the law
stands today, affected persons have to approach civil courts
for obtaining compensation and damages. In civil courts, the
determination  of amount of compensation or damages as  well
the liability of the enterprise has been bound by the shack-
les of conservative principles. [707D-G]
    1.2 The principles laid down in Ryland v. Fletcher  made
it difficult to obtain adequate damages from the  enterprise
and  that  too only after the negligence of  enterprise  was
proved. [707G-H]
    1.3  The  law laid down in Oleum Gas Leak  case  made  a
land-mark  departure from the conservative  principles  with
regard to the liability of an enterprise carrying on hazard-
ous or inherently dangerous activities. [709C]
    1.4 In the instant case, there is no scope for any doubt
regarding the liability of the UCC for the damage caused  to
the human beings and nature in and around Bhopal. [709E]
    Ryland  v. Fletcher, [1868] LR 3 HL 330; M.C.  Mehta  v.
Union of India, [1987] 1 SCR 819, referred to.
    2.  In the context of our national dimensions  of  human
rights, right to life, liberty, pollution free air and water
is guaranteed by the Constitution under Articles 21, 48A and
51(g),  it is the duty of the State to take effective  steps
to  protect  the  constitutional  rights  guaranteed.  These
rights must be integrated and illumined by evolving interna-
tional dimensions and standards, having regard to our sover-
eignty  as highlighted by Clauses 9 and 13 of U.N.  Code  of
Conduct  on Transnational Corporations. Such a law may  pro-
vide  for conditions for granting licence  to  Transnational
Corporations,  prescribing norms and standards  for  running
industries on Indian soil ensuring the above said  constitu-
tional  rights  of our people. A  Transnational  Corporation
should be made liable and subservient to laws of our country
and  the  liability should not be  restricted  to  affiliate
company only but the parent corporations should also be made
liable for any damage caused to the human beings or ecology.
The law must require transnational Corporations to agree  to
pay  such  damages  as may be determined  by  the  statutory
agencies and forum constituted under it without exposing the
victims  to  long  drawn litigation. In order  to  meet  the
situation, to avoid delay and to ensure immediate relief  to
the victims, the law should
615
provide  for constitution of tribunals regulated by  special
procedure for determining compensation to victims of  indus-
trial disaster or accident, appeal against which may lie  to
this  Court on the limited ground of questions of  law  only
after depositing the amount determined by the Tribunal.  The
law should also provide for interim relief to victims during
the pendency of proceedings. These steps would minimise  the
misery and agony of victims of hazardous enterprises. [710H;
711A-F]
    3. Industrial development in our country and the hazardsCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

involved  therein,  pose a mandatory need  to  constitute  a
statutory "Industrial Disaster Fund", contributions to which
may  be made by the Government, the industries whether  they
are  transnational  corporations or  domestic  undertakings,
public or private. The extent of contribution may be  worked
out  having regard to the extent of hazardous nature of  the
enterprise  and  other allied matters. The  fund  should  be
permanent in nature. so that money is readily available  for
providing immediate effective relief to the victims. [711  G
-H; 712A]
Ranganathan and Ahmadi, J J----Per Ranganathan, J.  (Concur-
ring).'
    1. The provisions of the Act, read by themselves,  guar-
antee  a complete and full protection to the rights  of  the
claimants in every respect. Save only that they cannot  file
a  suit themselves, their right to acquire redress  has  not
really been abridged by the provisions of the Act.  Sections
3  and  4 of the Act completely vindicate  the  objects  and
reasons  which compelled Parliament to enact this  piece  of
legislation. Far from abridging the rights of the  claimants
in  any manner, these provisions are so worded as to  enable
the Government to prosecute the litigation with the  maximum
amount  of resources, efficiency and competence at its  com-
mand.  as well as with all the assistance and help that  can
be  extended to it by such of those litigants and  claimants
as  are capable of playing more than a mere passive role  in
the litigation. [720G-H; 721A-B]
    2. Even if the provisions of s. 3 had been  scrupulously
observed  and the names of all parties, other than the  Cen-
tral  Government,  had been got deleted from  the  array  of
parties  in the suits and proceedings pending in this  coun-
try,  the result would not have been fatal to the  interests
of the litigants. On the contrary, it enabled the  litigants
to obtain the benefit of all legal expertise at the  command
of  the  Government  of India  in  exercising  their  rights
against  the Union Carbide Corporation. Such  representation
can well be justified by resort to a principle analogous to,
if not precisely the same, as that of, "parens
616
patriae". A victim of the tragedy is compelled to part  with
a  valuable  right  of his in order that it  might  be  more
efficiently  and  satisfactorily exploited for  his  benefit
than he himself is capable of. It is of course possible that
there may be an affluent claimant or lawyer engaged by  him,
who may be capable of fighting the litigation better. It  is
possible  that the Government of India as a litigant may  or
may not be able to pursue the litigation with as much deter-
mination or capability as such a litigant. But in a case  of
the  present  type one should not be confounded  by  such  a
possibility. There are more indigent litigants than affluent
ones.  There  are more illiterates  than  enlightened  ones.
There are very few of the claimants, capable of finding  the
financial wherewithal required for fighting the  litigation.Charan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

Very  few of them are capable or prosecuting such a  litiga-
tion in this country not to speak of the necessity to run to
a foreign country. The financial position of UCIL was negli-
gible  compared  to the magnitude of the  claim  that  could
arise and, though eventually the battle had to be pitched on
our own soil, an initial as well as final recourse to  legal
proceedings in the United States was very much on the cards,
indeed  inevitable. In this situation, the  legislature  was
perfectly justified in coming to the aid of the victims with
this piece of legislation and in asking the Central  Govern-
ment  to shoulder the responsibility by substituting  itself
in place of the victims for all purposes connected with  the
claims. [716C-H; 717A]
    3.  Section  4  adequately safeguards  the  interest  of
individual victims. It enables each one of them to bring  to
the  notice  of the Union any special  features  or  circum-
stances which he would like to urge in respect of any matter
and if any such features are brought to its notice the Union
is obliged to take it into account. The individual claimants
are also at liberty to engage their own counsel to associate
with the State counsel in conducting the proceedings. If the
suits  in  this case had proceeded, in  the  normal  course,
either to the stage of a decree or even to one of settlement
the  claimants  could have kept themselves  abreast  of  the
developments  and the statutory provisions would  have  been
more than adequate to ensure that the points of view of  all
the victims are presented to the court. Even a settlement or
compromise could not have been arrived at without the  court
being  apprised of the views of any of them who chose to  do
so. The statute has provided that though the Union of  India
will  be the dominus litis in the suit, the interest of  all
the victims and their claims should be safeguarded by giving
them  a  voice in the proceedings to  the  extent  indicated
above. This provision of the statute is an adaptation of the
principle  of Order 1 Rule 8 and of order XXIII Rule  38  of
the Code of Civil Procedure in its application to the  suits
governed  by it and, though the extent of participation  al-
lowed to
617
the victims is somewhat differently enunciated in the legis-
lation,  substantially  speaking, it  does  incorporate  the
principles of natural justice to the extent possible in  the
circumstances. The statute cannot, therefore, be faulted  on
the  ground  that it denies the victims  an  opportunity  to
present  their views or places them at any  disadvantage  in
the matter of having an effective voice in settling the suit
by way of compromise. [724G-H; 725A-D]
    4. Sections 3 and 4 combine together the interest of the
weak,  illiterate, helpless and poor victims as well as  the
interest  of  those who could have managed  for  themselves,
even  without  the help of this enactment.  The  combination
thus  envisaged enables the Government to fight  the  battle
with the foreign adversary with the full aid and  assistanceCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

of  such of the victims or their legal advisers as are in  a
position  to  offer any such assistance.  Though  section  3
denies the climants the benefit of being eo nominee  parties
in  such suits or proceedings, section 4 preserves  to  them
substantially  all  that they can achieve by  proceeding  on
their  own.  In other words, while seeming  to  deprive  the
claimants of their right to take legal action on their  own,
it has preserved those rights, to be exercised indirectly. A
conjoint  reading of sections 3 and 4 would show that  there
has  been  no  real total deprivation of the  right  of  the
claimants  to enforce their claim for damage in  appropriate
proceedings  before any appropriate forum. There is  only  a
restriction  of this right which, in the  circumstances,  is
totally reasonable and justified. [718D-G ]
    5.  It is not possible to bring the suits brought  under
the  Act  within  the categories  of  representative  action
envisaged in the Code of Civil Procedure. The Act deals with
a  class  of  action which is sui generis and  for  which  a
special  formula has been found and encapsuled in s. 4.  The
Act  divests the individual claimants of their right to  sue
and vests it in the Union. In relation to the suit in India,
the  Union  is the sole Plaintiff. none of  the  others  are
envisaged  as plaintiffs or respondents. The victims of  the
tragedy were so numerous that they were never defined at the
stage of filing the plaint nor do they need to be defined at
the stage of settlement. The litigation is carried on by the
State in its capacity not exactly the same as, but  somewhat
analogous  to  that of "parens patriae". In the  case  of  a
litigation  by a Karta of a Hindu undivided family or  by  a
guardian  on  behalf of a ward, who is  non-sui  juris,  the
junior  members  of the family or the wards, are not  to  be
consulted before entering into a settlement. In such  cases,
court  acts  as guardian of such persons to  scrutinise  the
settlement and satisfy itself that it is in the best  inter-
est  of all concerned. If it is later discovered that  there
has  been  any  fraud or collusion, it may be  open  to  the
junior members of the
618
family or the wards to call the Karta or guardian to account
but,  barring  such a contingency, the settlement  would  be
effective and binding. In the same way, the Union as "parens
patriae'  would  have  been at liberty to  enter  into  such
settlement  as  it considered best on its own and  seek  the
Court's approval therefore. [723G-H; 724A-D]
    6.  It is common knowledge that any authority  given  to
conduct a litigation cannot be effective unless it is accom-
panied by an authority to withdraw or settle the same if the
circumstances  call for it. The vagaries of a litigation  of
this magnitude and intricacy could not be fully anticipated.
There were possibilities that the litigation may have to  be
fought  out to the bitter finish. There  were  possibilities
that  the UCC might be willing to adequately compensate  the
victims  either  on their own or at the  insistence  of  theCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

Government concerned. There was also the possibility,  which
had  already been in evidence before Judge Keenan, that  the
proceedings  might  ultimately  have to  end  in  negotiated
settlement.  In  most of the mass disaster  cases  reported,
proceedings finally end in a compromise, if only to avoid an
indefinite prolongation of the agonies caused by such  liti-
gation. The legislation, therefore, cannot be considered  to
be  unreasonable merely because in addition to the right  to
institute  a suit or other proceedings it also empowers  the
Government  to  withdraw  the proceedings or  enter  into  a
compromise. [719B-E]
M.C. Mehta v. Union of India, [1987] 1 SCR 819, referred to.
    7.  The Act has provided an adequate opportunity to  the
victims  to speak out and if they or the counsel engaged  by
some  of them in the trial court had kept in touch with  the
proceedings  in this court, they could have  most  certainly
made  themselves heard. If a feeling has gained ground  that
their voice has not been fully heard, the fault was not with
the statute but was rather due to the development leading to
the  finalisation of the settlement when the appeal  against
the interim order was being heard in this Court. [726B-D]
    8.  In the field of torts, under the common law of  Eng-
land, no action could be laid by the dependants or heirs  of
a  person whose death was brought about by the tortious  act
of another on the maxim actio personalis maritur cum persona
although  a  person  injured by a similar  act  could  claim
damages for the wrong done to him. In England this situation
was  remedied by the passing of Fatal Accidents  Act,  1846,
popularly  known  as  Lord Compbell's  Act.  Thereafter  the
Indian  Legislature enacted the Fatal Accidents  Act,  1855.
This Act is fashioned on the
619
lines  of the English Act of 1840. Even though  the  English
Act has undergone a substantial change, our law has remained
static and seems a trifle archaic. The magnitude of the  gas
leak  disaster in which hundreds lost their lives and  thou-
sands were maimed, not to speak of the damage to  livestock,
flora  and fauna, business and property, is an  eye  opener.
The  nation must learn a lesson from this traumatic  experi-
ence and evolve safeguards atleast for the future. The  time
is  ripe  to take a fresh look at the outdated  century  old
legislation  which  is  out of tune  with  modern  concepts.
[728F-H; 729A-B]
    9. The Central Government will be well advised to insist
on  certain  safeguards before  permitting  a  transnational
company  to do business in the country. It is  necessary  to
insist on a right to be informed of the nature of the  proc-
esses  involved so as to take prompt action in the event  of
an accident. The victims in this case have been considerably
handicapped on account of the fact that the immediate  tort-
feasor  was  the  subsidiary of a  multi-national  with  its
Indian  assets  totally  inadequate to  satisfy  the  claims
arising out of the disaster. It is, therefore, necessary  toCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

evolve,  either by international consensus or by  unilateral
legislation, steps to overcome these handicaps and to ensure
that  foreign corporations seeking to establish an  industry
here,  agree to submit to the jurisdiction of the Courts  in
India in respect of actions for tortious acts in this  coun-
try; that the liability of such a corporation is not limited
to  such of its assets (or the assets of its affiliates)  as
may be found in this country, but that the victims are  able
to reach out to the assets of such concerns anywhere in  the
world;  and  that any decree obtained in  Indian  Courts  in
compliance  with  due  process of law is  capable  of  being
executed against the foreign corporation, its affiliates and
their  assets without further procedural hurdles.  in  those
other countries. [729G-H; 730A-E]
    10. It is hoped that calamities like the one which  this
country has suffered will serve as catalyst to expedite  the
acceptance  of an international code on such matters in  the
near future. [730F-G]
JUDGMENT:
ORIGINAL JURISDICTION: Writ Petition No. 268 of 1989 etc. etc. (Under Article 32 of the
Constitution of India). K. Parasaran, Attorney General, R.K. Garg, Ms. Indira Jaising, L.N. Sinha,
Dr. V. Gauri Shankar, Vepa P. Sarathi, Shanti Bhushan, Rakesh Luthra, C.L. Sahu, Indeevar
Goodwill, N.S. Malik, N.S. Pundir, R.C, Kaushik, D.K. Garg, Rajeev Dhawan, Miss Kamini Jaiswal,
Anip Sachthey, R.C. Pathak, H.D. Pathak, Harish Uppal, S.K. Gambhir, Gopal Subramanium, D.S.
Shastri, Arun Sharma, Miss A. Subhashini, C.V.S. Rao, Satish K. Agnihotri, Ashok Kumar Singh,
R.K. Jain, Kailash Vasdev and Prashant Bhushan for the appearing parties.
The Judgments of the Court were delivered by SABYASACHI MUKHARJI, CJ. 1. Is the Bhopal Gas
Leak Disaster (Processing of Claims) Act, 1985 (hereinafter referred to as 'the Act') is
constitutionally valid? That is the question.
2. The Act was passed as a sequel to a grim tragedy. On the night of 2nd December, 1984 occurred
the most tragic industrial disaster in recorded human history in the city of Bhopal in the State of
Madhya Pradesh in India. On that night there was massive escape of lethal gas from the MIC storage
tank at Bhopal Plant of the Union Carbide (I) Ltd. (hereinafter referred to as 'UCIL') resulting in
large scale death and untold disaster. A chemical plant owned and oper- ated by UCIL was situated
in the northern sector of the city of Bhopal. There were numerous hutments adjacent to it on its
southern side, which were occupied by impoverished squatters. UCIL manufactured the pesticides,
Sevin and Tamik, at the Bhopal plant, at the request of, it is stated by Judge John F. Keenan of the
United States District Court in his judgment, and indubitably with the approval of the Govt. of India.
UCIL was incorporated in 1984 under the appropriate Indian law: 50.99% of its shareholdings were
owned by the Union Carbide Corporation (UCC), a New York Corporation, L.I.C. and the Unit Trust
of India own 22% of the shares of U.C.I.L., a subsidiary of U.C.C.Charan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

3. Methyl Isocyanate (MIC), a highly toxic gas, is an ingredient in the production of both Sevin and
Temik. On the night of the tragedy MIC leaked from the plant in substan- tial quantities. the exact
reasons for and circumstances of such leakage have not yet been ascertained or clearly estab- lished.
The results of the disaster were horrendous. Though no one is yet certain as to how many actually
died as the immediate and direct result of the leakage, estimates at- tribute it to about 3,000. Some
suffered injuries the ef- fects of which are described as Carcinogenic and ontogenic by Ms. Indira
Jaisingh, learned counsel; some suffered injuries serious and permanent and some mild and
temporary. Livestock was killed, damaged and infected. Businesses were interrupted. Environment
was polluted and the ecology af- fected, flora and fauna disturbed.
4. On 7th December, 1984, Chairman of UCC Mr. Warren Anderson came to Bhopal and was
arrested. He was later released on bail. Between December 1984 and January 1985 suits were filed
by several American lawyers in the courts in America on behalf of several victims. It has been stated
that within a week after the disaster, many American law- yers, described by some as 'ambulance
chasers', whose fees were stated to be based on a percentage of the contingency of obtaining
damages or not, flew over to Bhopal and ob- tained Powers of Attorney to bring actions against UCC
and UCIL. Some suits were also filed before the District Court of Bhopal by individual claimants
against UCC (the American Company) and the UCIL.
5. On or about 6th February, 1985, all the suits in various U.S. Distt. Courts were consolidated by the
Judicial Panel on Multi-District Litigation and assigned to U.S. Distt. Court, Southern Distt. of New
York. Judge Keenan was at all material times the Presiding Judge there.
6. On 29th March, 1985, the Act in question was passed. The Act was passed to secure that the
claims arising out of or connected with the Bhopal gas leak disaster were dealt with speedily,
effectively and equitably. On 8th April, 1985 by virtue of the Act the Union of India filed a complaint
before the U.S. Distt. Court, Southern Distt. of New York. On 16th April, 1985 at the first pre-trial
conference in the consolidated action transferred and assigned to the U.S. Distt. Court, Southern
Distt., New York, Judge Keenan gave the following directions:
(i) that a three member Executive Committee be formed to frame and develop issues
in the case and prepare expeditiously for trial or settle-
ment negotiations. The Committee was to com- prise of one lawyer selected by the firm retained by
the Union of India and two other lawyers chosen by lawyers retained by the individual plaintiffs.
(ii) that as a matter of fundamental human decency, temporary relief was necessary for the-victims
and should be furnished in a systematic and coordinated fashion without unnecessary delay
regardless of the posture of the litigation then pending.
7. On 24th September, 1985 in exercise of powers con- ferred by section 9 of the Act, the Govt. of
India framed the Bhopal Gas Leak Disaster (Registration and Processing of Claims) Scheme, 1985
(hereinafter called the Scheme).Charan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

8. On 12th May, 1986 an order was passed by Judge Keenan allowing the application of UCC on
forum non convenience as indicated hereinafter. On 21st May, 1986 there was a motion for fairness
hearing on behalf of the private plaintiffs. On 26th June, 1986 individual plaintiffs filed appeal
before the US Court of Appeal for the second circuit challenging the order of Judge Keenan. By an
order dated 28th May, 1986 Judge Keenan declined the motion for a fairness hearing. The request
for fairness hearing was rejected at the instance of Union of India in view of the meagerness of the
amount of proposed settlement. On 10th July, 1986 UCC filed an appeal before the US Court of
Appeal for the Second Circuit. It challenged Union of India being entitled to American mode of
discovery, but did not challenge the other two conditions imposed by Judge Keenan, it is stated. On
28th July, 1986 the Union of India filed cross-appeal before the US Court of Appeal praying that
none of the conditions imposed by Judge Keenan should be disturbed. In this connection it would be
pertinent to set out the conditions incorporated in the order of Judge Keenan, dated 12th May, 1986
whereby he had dismissed the case before him on the ground of forum non convenience, as
mentioned before. The conditions were fol- lowing:
1. That UCC shall consent to the jurisdiction of the courts of India and shall continue
to waive defenses based on the statute of limita- tion,
2. That UCC shall agree to satisfy any judg-
ment rendered by an Indian court against it and if applicable, upheld on appeal, provided the
judgment and-affirmance "comport with minimal requirements of due process"; and
3. That UCC shah be subject to discovery under the Federal Rules of Civil Procedure of the US after
appropriate demand by the plaintiffs.
9. On 5th September, 1986 the Union of India filed a suit for damages in the Distt. Court of Bhopal,
being regu- lar suit No. H 13/86. It is this suit, inter alia, and the orders passed therein which were
settled by the orders of this Court dated 14th & 15th February, 1989, which will be referred to later.
On 17th November, 1986 upon the applica- tion of the Union of India, the Distt. Court, Bhopal,
grant- ed a temporary injunction restraining the UCC from selling assets, paying dividends or
buying back debts. On 27th November, 1986 the UCC gave an undertaking to preserve and maintain
unencumbered assets to the extent of 3 billion US dollars.
10. On 30th November, 1986 the Distt. Court, Bhopal lifted the injunction against the Carbide
selling assets on the strength of the written undertaking by UCC to maintain unencumbered assets
of 3 billion US dollars. On 16th Decem- ber, 1986 UCC filed a written statement contending that
they were not liable on the ground that they had nothing to do with the Indian Company; and that
they were a different legal entity; and that they never exercised any control and that they were not
liable in the suit. Thereafter, on 14th January, 1987 the Court of Appeal for the Second Circuit
affirmed the decision of Judge Keenan but deleted the condi- tion regarding the discovery under the
American procedure granted in favour of the Union of India. It also suo motu set aside the condition
that on the judgment of the Indian court complying with due process and the decree issued should
be satisfied by UCC. 1t ruled that such a condition cannot be imposed as the situation was coveredCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

by the provi- sions of the Recognition of Foreign Country Money Judgments Act.
11. On 2nd April, 1987, the court made a written propos- al to all parties for considering
reconciliatory interim relief to the gas victims. In September, 1987, UCC and the Govt. of India
sought time from the Court of Distt. Judge, Bhopal, to explore avenues for settlement. It has been
asserted by the learned Attorney General that the possibili- ty of settlement was there long before
the full and final settlement was effected. He sought to draw our attention to the assertion that the
persons concerned were aware that efforts were being made from time to time for settlement.
However, in November'87 both the Indian Govt. and the Union Carbide announced that settlement
talks had failed and Judge Deo extended the time.
12. The Distt. Judge of Bhopal on 17th December, 1987 ordered interim relief amounting to Rs.350
crores. Being aggrieved thereby the UCC filed a Civil Revision which was registered as Civil Revision
Petition No. 26/88 and the same was heard. On or about 4th February, 1988, the Chief Judi- cial
Magistrate of Bhopal ordered notice for warrant on Union Carbide, Hong Kong for the criminal case
filed by CBI against Union Carbide. The charge sheet there was under
sections 304, 324, 326, 429 of the Indian Penal Code read with section 35 IPC and
the charge was against S/Shri Warren Anderson, Keshub Mahindra. Vijay Gokhale, J.
Mukund, Dr. R.B. Roy Chowdhay. S.P. Chowdhary, K.V. Shetty, S.1. Qureshi and
Union Carbide of U.S.A., Union Carbide of Hong Kong and Union Carbide having
Calcutta address. It charged the Union Carbide by saying that MIC gas was stored
and it was further stated that MIC had to be stored and handled in stainless steel
which was not done. The charge sheet, inter alia, stated that a Scientific Team headed
by Dr. Varadarajan had concluded that the factors which had led to the toxic gas
leakage causing its heavy toll existed in the unique properties of very high reactivity,
volatility and inhalation toxicity of MIC. It was further stated in the charge sheet that
the needless storage of large quantities of the material in very large size containers
for inordi- nately long periods as well as insufficient caution in design, in choice of
materials of construction and in provi- sion of measuring and alarm instruments,
together with the inadequate controls on systems of storage and on quality of stored
materials as well as lack of necessary facilities for quick effective disposal of material
exhibiting instability, led to the accident. It also charged that MIC was stored in a
negligent manner and the local administration was not informed, inter alia, of the
dangerous effect of the expo- sure of MIC or the gases produced by its reaction and
the medical steps to be taken immediately. It was further stated that apart from the
design defects the UCC did not take any adequate remedial action to prevent back
flow of solution from VGS into RVVH and PVH lines. There were various other acts of
criminal negligence alleged. The High Court passed an order staying the operation of
the order dated 17.12.87 directing the defendant-applicant to deposit Rs.3,500 mil-
lions within two months from the date of the said order. On 4th April, 1988 the
judgment and order were passed by the High Court modifying the order of the Distt.
Judge, and granting interim relief of Rs.250 crores. The High Court held that under
the substantive law of torts, the Court has jurisdiction to grant interim relief underCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

Section 9 of the CPC. On 30th June, 1988 Judge Deo passed an order restrain- ing
the Union Carbide from settling with any individual gas leak plaintiffs. On 6th
September, 1988 special leave was granted by this Court in the petition filed by UCC
against the grant of interim relief and Union of India was also granted special leave in
the petition challenging the reduc- tion of quantum of compensation from Rs.350
crores to Rs.250 crores. Thereafter, these matters were heard in November-
December'88 by the bench presided over by the learned Chief Justice Of India and
hearing, continued also in January Feb- ruary'89 and ultimately on 14-15th February,
1989 the order culminating in the settlement was passed.
13. In judging the constitutional validity of the Act, the subsequent events, namely, how the Act has
worked itself out, have to be looked into. It is, therefore, necessary to refer to the two orders of this
Court. The proof of the cake is in its eating, it is said, and it is perhaps not possible to ignore the
terms of the settlement reached on 14th and 15th February, 1989 in considering the effect of the lan-
guage used in the Act. Is that valid' or proper--or has the Act been worked in any improper way?
These questions do arise.
14. On 14th February, 1989 an order was passed in C.A. Nos. 3187-88/88 with S.L.P. (C) No.
13080/88. The parties thereto were UCC and the Union of India as well as Jana Swasthya Kendra,
Bhopal, Zehraeli Gas Kand Sangharsh Morcha, Bhopal. MP. That order recited that having
considered all the facts and the circumstances of the case placed before the Court, the material
relating to the proceedings in the Courts in the United States of America, the offers and
counter-offers made between the parties at different stages during the various proceedings, as well
as the complex issues of law and fact raised and the submissions made thereon, and in particular the
enormity of human suffering occasioned by the Bhopal Gas disaster and the pressing urgency to
provide immediate and substantial relief to victims of the disaster, the 'Court found that the case
was preeminently fit for an overall settlement between the parties covering all litigations, claims,
rights and liabil- ities relating to and arising out of the disaster and it was found just, equitable and
reasonable to pass, inter alia, the following orders:
.lm "(1) The Union Carbide Corporation shall pay a sum of U.S. Dollars 470 million
(Four hundred and seventy millions) to the Union of India in full settlement of all
claims, fights and liabilities related to and arising out of Bhopal Gas disaster.
(2) The aforesaid sum shall be paid by the Union Carbide Corporation to the Union of
India on or before 31st March, 1989.
(3) To enable the effectuation of the settlement, all civil proceedings related to and
arising out of the Bhopal Gas disaster shall hereby stand transferred to this Court and
shall stand concluded in terms of the settlement, and all criminal proceedings related
to and arising out of the disaster shall stand quashed wherever these may be pending
15. A written memorandum was filed thereafter and the Court on 15th February, 1989 passed an
order after giving due consideration thereto. The terms of settlement were as follows:Charan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

"1. The parties acknowledge that the order dated February 14, 1989 disposes of in its
entirety all proceedings in Suit No. 1113 of 1986. This settlement shall finally dispose
of all past, present and future claims, causes of action and civil and criminal
proceedings (of any nature whatsoever wherever pending) by all Indian citizens and
all public and private entities with respect to all past, present or future deaths,
personal injuries, health effects, compensation, losses, damages and civil and
criminal complaints of any nature whatsoever against UCC, Union Carbide India
Limited, Union Carbide Eastern, and all of their subsidiaries and affiliates as well as
each of their present and former directors, officers, employees, agents,
representatives, attorneys, advocates and solicitors arising out of, relating to or
connected with the Bhopal gas leak disaster, including past, present and future
claims, causes of action and proceedings against each other. All such claims and
causes of action whether within or outside India of Indian citizens, public or private
entities are hereby extinguished, including without limitation each of the claims filed
or to be filed under the Bhopal Gas Leak Disaster (Registration and Processing of
Claims) Scheme 1985, and all such civil proceedings in India are hereby transferred
to this Court and are dismissed without preju- dice, and all such criminal proceedings
in- cluding contempt proceedings stand quashed and accused deemed to be
acquitted.
2. Upon full payment in accordance with the Court's directions the undertaking given
by UCC pursuant to the order dated November 30, 1986 in the District Court, Bhopal
stands discharged, and all orders passed in Suit No. 1113 of 1986 and or in any
Revision therefrom, also stand discharged."
16. It appears from the statement of objects & reasons of the Act that the Parliament recognized that
the gas leak disaster involving the release, on 2nd and 3rd December, 1984 of highly noxious and
abnormally dangerous gas from a plant of UCIL, a subsidiary of UCC, was of an unprecedented
nature, which resulted in loss of life and damage to proper- ty on an extensive scale, as mentioned
before. It was stated that the victims who had managed to survive were still suffering from the
adverse effects and the further complica- tions which might arise in their cases, of course, could not
be fully visualised. It was asserted by Ms. Indira Jaising that in case of some of the victims the
injuries were carcinogenic and ontogenic and these might lead to further genetic complications and
damages. The Central Govt. and the Govt. of Madhya Pradesh and various agencies had to incur
expenditure on a large scale for containing the disaster and mitigating or otherwise coping with the
effects thereto. Accordingly, the Bhopal Gas Leak Disaster (Processing of Claims) Ordinance, 1985
was promul- gated, which provided for the appointment of a Commissioner for the welfare of the
victims of the disaster and for the formulation of the Scheme to provide for various matters
necessary for processing of the claims and for the utilisa- tion by way of disbursal or otherwise of
amounts received in satisfaction of the claims.
17. Thereafter, the Act was passed which received the assent of the President on 29th March, 1985.
Section 2(b) of the Act defines 'claim'. It says that "claims" means--(i) a claim, arising out of, or
connected with, the disaster, for compensation or damages for any loss of life or personal injuryCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

which has been, or is likely to be suffered; (ii) a claim, arising out of, or connected with, the disaster,
for any damage to property which has been, or is likely to be, sustained; (iii) a claim for expenses
incurred or required to be incurred for containing the disaster or mitigating or otherwise coping
with the effects of the disaster; (iv) any other claim (including any claim by way of loss of business or
employment) arising out of, or connected with, the disas- ter. A "claimant" is defined as a person
entitled to make a claim. It has been provided in the Explanation to Section 2 that for the purpose of
clauses (b) and (c), where the death of a person has taken place as a result of the disaster, the claim
for compensation or damages for the death of such person shall be for the benefit of the spouse,
children (including a child in the womb) and other heirs of the deceased and they shall be deemed to
be the claimants in respect thereof.
18. Section 3 is headed "Power of Central Govt. to represent claimants". It provides as follows:
"3(1) Subject to the other provisions of this Act, the Central Government shall, and
shall have the exclusive right to, represent, and act in place of (whether within or
outside India) every person who has made, or is enti-
tled to make, a claim for all purposes con-
nected with such claim in the same manner and to the same effect as such persons.
(2) In particular and without prejudice to the generality of the provisions of sub-section (1), the pur-
poses referred to therein include--
(a) Institution of any suit or other proceed- ing in or before any court or other authority (whether
within or outside India) or withdraw- al of any such suit or other proceeding, and
(b) entering into a compromise.
(3) The provisions of sub-section (1) shall apply also in relation to claims in respect of which suits or
other proceedings have been instituted in or before any court or other authority (whether within or
outside India) before the commencement of this Act:
Provided that in the case of any such suit or other proceeding with respect to any
claim pending immediately before the commencement of this Act in or before any
court or other authority outside India, the Central Govt. shall represent, and act in
place of, or along with, such claimant, if such court or other authority so permits."
19. Section 4 of the Act is headed as "Claimant's right to be represented by a legal practitioner". It
provides as follows:
"Notwithstanding anything contained in section 3, in representing, and acting in
place of, any person in relation to any claim, the Central Government shall have dueCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

regard to any matters which such person may require to be urged with respect to his
claim and shall, if such person so desires, permit at the expense of such person, a
legal practitioner of his choice to be associated in the conduct of any suit or other
proceeding relating to his claim."
20. Section 5 deals with the powers of the Central Govt. and enjoins that for the purpose of
discharging its func- tions under this Act, the Central Govt. shall have the powers of a civil court
while trying a suit under the Code of Civil Procedure, 1908. Section 6 provides for the ap- pointment
of a Commissioner and other officers and employ- ees. Section 7 deals with powers to delegate.
Section 8 deals with limitation, while section 9 deals with the power to frame Scheme. The Central
Govt. was enjoined to frame a scheme which was to take into account, inter alia, the processing of
the claims for securing their enforcement, creation of a fund for meeting expenses in connection
with the administration of the Scheme and of the provisions of this Act and the amounts which the
Central Govt. might, after due appropriation made by the Parliament by law in that behalf, credit to
the fund referred to in clauses above and any other amounts which might be credited to such fund.
Such Scheme was enjoined, as soon as after it had been framed, to be laid before each House of
Parliament. Section 10 deals with removal of doubts. Section 11 deals with the overriding effect and
provides that the provisions of the Act and of any Scheme framed thereunder shall have effect
notwithstanding anything inconsistent therewith contained in any enactment other than the Act or
any instrument having effect by virtue of any enactment other than the Act.
21. A Scheme has been framed and was published on 24th September, 1985. Clause 3 of the said
Scheme provides that the Deputy Commissioners appointed under Section 6 of the Act shall be the
authorities for registration of Claims (including the receipt, scrutiny and proper categorisation of
such claims under paragraph 5 of the Scheme) arising within the areas of their respective
jurisdiction and they shall be assisted by such other officers as may be appointed by the Central
Govt. under Section 6 of the Act for scrutiny and verification of the claims and other related matters.
The Scheme also provides for the manner of filing claims. It enjoins that the Dy. Commissioner shall
provide the required forms for filing the applications. It also provides for categorisation and
registration of claims. Sub-clause (2) of Clause 5 enjoins that the claims received for registration
shall be placed under different heads.
22. Sub-clause (3) of clause 5 enjoins that on the consideration of claims made under paragraph 4 of
the Scheme, if the Dy. Commissioner is of the opinion that the claims fall in any category different
from the category mentioned by the claimant, he may decide the appropriate category after giving
an opportunity to the claimant to be heard and also after taking into consideration any facts made
available to him in this behalf. Sub-clause (6) of Clause 5 enjoins that if the claimant is not satisfied
with the order of the Dy. Commissioner, he may prefer an appeal against such order to the
Commissioner, who shall decide the same.
23. Clause 9 of the Scheme provides for processing of Claims Account Fund, which the Central Govt.
may, after due appropriation made by Parliament, credit to the said Fund. It provides that there
shall also be a Claims and Relief Fund, which will include the amounts received in satisfaction of the
claims and any other amounts made available to the Commissioner as donation or for reliefCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

purposes. Subclause (3) of clause 10 provides that the amount in the said Fund shall be applied by
the Commissioner for, disbursal of amounts in settlement of claims, or as relief, or apportionment of
part of the Fund for disbursal of amounts in settlement of claims arising in future or for disbursal of
amounts to the Govt. of Madhya Pradesh for the social and economic rehabilitation of the persons
affected by the Bhopal gas leak disaster.
24. Clause 11 of the Scheme deals with the disbursal, apportionment of certain amounts, and
sub-clause (2) thereof enjoins that the Central Govt. may determine the total amount of
compensation to be apportioned for each category of claims and the quantum of compensation
payable, in gener- al, in relation to each type of injury or loss. Sub-clause (5) thereto provides that in
case of a dispute as to disbur- sal of the amounts received in satisfaction of claims, an appeal shall lie
against the order of the Dy. Commissioner to the Additional Commissioner, who may decide the
matter and make such disbursal as he may, for reasons to be record- ed in writing, think fit. The
other clauses are not relevant for our present purposes.
25. Counsel for different parties in all these matters have canvassed their submissions before us for
the gas victims. Mr. R.K. Garg, Ms. Indira Jaising, and Mr. Kailash Vasudev have made various
submissions challenging the valid- ity of the Act on various grounds. They all have submitted that
the Act should be read in the way they suggested and as a whole. Mr. Shanti Bhushan, appearing for
interveners on behalf of Bhopal Gas Peedit Mahila Udyog Sangathan and following him Mr.
Prashant Bhushan have urged that the Act should be read in the manner canvassed by them and if
the same is not so read then the same would be violative of the fundamental rights of the victims,
and as such unconstitu- tional. The learned Attorney General assisted by Mr. Gopal Subramanium
has on the other hand urged that the Act is valid and constitutional and that the settlement arrived
at on 14th/15th February is proper and valid.
26. In order to appreciate the background Ms. Indira Jaising placed before us the proceedings of the
Lok Sabha wherein Mr. Veerendra Patil, the Hon'ble Minister, stated on March 27, 1985 that the
tragedy that had occurred in Bhopal on 2nd and 3rd December, 1984 was unique and
unprecedented in character and magnitude not only for our country but for the entire world. It was
stated that one of the options available was to settle the case in Indian courts. The second one was to
file the cases in American courts. Mr. Patil reiterated that the Govt. wanted to pro- ceed against the
parent company and also to appoint a Com- mission of Inquiry.
27. Mr. Garg in support of the proposition that the Act was unconstitutional, submitted that the Act
must be exam- ined on the touchstone of the fundamental rights on the basis of the test laid down by
this court in state of Madras v. V.G, Row, [1952] SCR 597, There at page 607 of the report this Court
has reiterated that in considering the reasona- bleness of the law imposing restrictions on the
fundamental rights, both the substantive and the procedural aspects of the impugned restrictive law
should be examined from the point of view of reasonableness. And the test of reasonable- ness,
wherever prescribed, should be applied to each indi- vidual Statute impugned, and no abstract
standard or general pattern of reasonableness can be laid down as applicable to all cases. The nature
of the right alleged to have been infringed, the underlying purpose of the restrictions im- posed, the
extent and urgency of the evil sought to be remedied thereby, the disproportion of the imposition,Charan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

the prevailing conditions at the time, should all enter into the judicial verdict. (The emphasis
supplied). Chief Justice Patanjali Sastri reiterated that in evaluating such elusive factors and
forming their own conception of what is reasona- ble, in the circumstances of a given case, it is
inevitable that the social philosophy and the scale of values of the judges participating in the
decision would play an important role.
28. Hence, whether by sections, 3, 4 & 11 the rights of the victims and the citizens to fight for their
own causes and to assert their own grievances have been taken away validly and properly, must be
judged in the light of the prevailing conditions at the time, the nature of the right of the citizen, the
purpose of the restrictions on their rights to sue for enforcement in the courts of law or for
punishment for offences against his person or property, the urgency and extent of the evils sought to
be remedied by the Act, and the proportion of the impairment of the rights of the citizen with
reference to the intended remedy pre- scribed. According to Mr. Garg, the present position called for
a comprehensive appreciation of the national and inter- national background in which precious
rights to life and liberty were enshrined as fundamental rights and remedy for them was also
guaranteed under Article 32 of the Constitu- tion. He sought to urge that multinational corporations
have assumed powers or potencies to override the political and economic independence of the
sovereign nations which have been used to take away in the last four decades, much wealth out of
the Third World. Now these are plundered much more than what was done to the erstwhile colonies
by imperialist nations in the last three centuries of foreign rule. The role of courts in cases of conflict
between rights of citi- zens and the vast economic powers claimed by multinational corporations to
deny moral and legal liabilities for their corporate criminal activities should not be lost sight of. He,
in this background, urged that these considerations assume immense importance to shape human
fights jurispru- dence under the Constitution, and for the Third World to regulate and control the
power and economic interests of multinational corporations and the power of exploitation and
domination by developed nations without submitting to due observance of the laws of the
developing countries. It therefore appears that the production of, or carrying on trade in dangerous
chemicals by multinational industries on the soil of Third World countries call for strictest en-
forcement of constitutional guarantees for enjoying human fights in free India, urged Mr. Garg. In
this connection, our attention was drawn to the Charter of Universal Declara- tion of Human Rights.
Article 1 of the Universal Declaration of Human Rights, 1948 reiterates that all human-beings are
born free and equal in dignity and rights. Article 3 states that everyone has right to life, liberty and
security of person. Article 6 of the Declaration states that everyone has the right to recognition
everywhere as a person before the law. Article 7 states that all are equal before the law and are
entitled without any discrimination to equal protec- tion of the law. All are entitled to equal
protection against any discrimination in violation of the Declaration of Human Rights and against
any incitement to such discrimi- nation. Article 8 states that everyone has the right to an effective
remedy by competent National Tribunal for acts violating fundamental rights guaranteed to him by
the Con- stitution or by the law. It is, therefore, necessary to bear in mind that Indian citizens have a
fight to live which cannot be taken away by the Union of India or the Govt. of a State, except by a
procedure which is just, fair and reason- able. The right to life includes the fight to protection of
limb against mutilation and physical injuries, and does not mean merely the fight to breathe but also
includes the fight to livelihood. It was urged that this right is available in all its dimension till the
last breath against all injuries to head, heart and mind or the lungs affecting the citizen or his nextCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

generation or of genetic disorders. The enforce- ment of the right to life or limb calls for adequate
and appropriate reliefs enforceable in courts of law and of equity with sufficient power to offer
adequate deterrence in all cases of corporate criminal liability under strict liability, absolute liability,
punitive liability and crimi- nal prosecution and punishment to the delinquents. The damages
awarded in civil jurisdiction must be commensurate to meet well-defined demands of evolved
human rights jurisprudence in modern world. It was, therefore, submitted that punishment in
criminal jurisdiction for serious offences is independent of the claims enforced in civil jurisdiction
and no immunity against it can be granted as part of settlement in any civil suit. If any Act
authorises or permits doing of the same, the same will be unwarranted by law and as such bad. The
Constitution of India does not permit the same.
29. Our attention was drawn to Article 21 of the Consti- tution and the principles of international
law. Right to equality is guaranteed to every person under Art. 14 in all matters like the laws of
procedure for enforcement of any legal or constitutional right in every jurisdiction, sub- stantive law
defining the rights expressly or by necessary implications, denial of any of these rights to any class of
citizens in either field must have nexus with constitution- ally permissible object and can never be
arbitrary. Arbi- trariness is, therefore, anti-thetical to the right of equality. In this connection,
reliance was placed on the observations of this Court in E.P. Royappa v. State of Tamil Nadu & Anr.,
[1974] 2 SCR 348 and Maneka Gandhi v. Union of India, [1978] 2 SCR 621 where it was held that
the view that Articles 19 & 21 constitute watertight compartments has been rightly overruled.
Articles dealing with different fundamen- tal rights contained in Part III of the Constitution do not
represent entirely separate streams of rights which do not mingle at any point of time. They. are all
parts of an integrated scheme in the Constitution and must be preserved and cannot be destroyed
arbitrarily. Reliance was placed on the observations in R.D. Shetty v. The I.A.A. of India & Ors.,
[1979] 3 SCR 1014. Hence, the rights of the citizens to fight for remedies and enforce their rights
flowing from the breach of obligation in respect of crime cannot be obliterated. The Act and Sections
3, 4 & 11 of the Act in so far as these purport to do so and have so operated, are violative of Articles
14, 19(1)(g) and 21 of the Constitu- tion. The procedure envisaged by the said Sections deprives the
just and legitimate rights of the victims to assert and obtain their just dues. The rights cannot be so
destroyed. It was contended that under the law the victims had right to ventilate their rights.
30. It was further contended that Union of India was a joint tort-feasor along with UCC and UCIL. It
had negligent- ly permitted the establishment of such a factory without proper safeguards exposing
the victims and citizens to great danger. Such a person or authority cannot be entrusted to represent
the victims by denying the victims their rights to plead their own cases. It was sub- mitted that the
object of the Act was to fully protect people against the disaster of highly obnoxious gas and disaster
of unprecedented nature. Such an object cannot be achieved without enforcement of the criminal
liability by criminal prosecution. Entering into settlement without reference to the victims was,
therefore, bad and unconstitu- tional, it was urged. If an Act, it was submitted, permits such a
settlement or deprivation of the rights of the vic- tims, then the same is bad.
31. Before we deal with the various other contentions raised in this case, it is necessary to deal with
the appli- cation for intervention and submission made on behalf of the Coal India in Writ Petition
No. 268/89 wherein Mr. L.N. Sinha in his written submission had urged for the intervener thatCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

Article 21 of the Constitution neither confers nor creates nor determines the dimensions nor the
permissible limits of restrictions which appropriate legislation might impose on the right to life or
liberty. He submitted that provisions for procedure are relevant in judicial or quasi judicial
proceedings for enforcement of rights or obliga- tions. With regard to alteration of rights, procedure
is governed by the Constitution directly. He sought to inter- vene on behalf of Coal India and wanted
these submissions to be taken into consideration. However, when this contention was sought to be
urged before this Court on 25th April, 1989, after hearing all the parties, it appeared that there was
no dispute between the parties in the instant writ petitions between the victims and the Government
of India that the rights claimed in these cases are referrable to Article 21 of the Constitution.
Therefore, no dispute really arises with regard to the contention of Coal India and we need not
consider the submissions urged by Shri Sinha on behalf of the intervener in this case. It has been so
re- corded.
32. By the order dated 3rd March, 1989, Writ Petitions Nos. 268/89 and 164/86 have been directed
to be disposed of by this Bench.' We have heard these two writ petitions along with the other writ
petitions and other matters as indicated hereinbefore. The contentions are common. These writ
peti- tions question the validity of the Act and the settlement entered into pursuant to the Act. Writ
Petition No. 164/86 is by one Shri Rakesh Shrouti who is an Indian citizen and claims to be a
practising advocate having his residence at Bhopal. He says that he and his family members were at
Bhopal on 2nd/3rd December, 1984 and suffered immensely as a result of the gas leak. He
challenges the validity of the Act on various grounds. He contends that the Union of India should
not have the exclusive right to represent the victims in suits against the Union Carbide and thereby
deprive the victims of their right to sue and deny access to justice. He further challenges the right of
the Union of India to represent the victims against Union Carbide because of conflict of interests.
The conduct of the Union of India was also deprecated and it was further stated that such conduct
did not inspire confidence. In the premises, the said petitioner sought a declaration under Article 32
of the Constitution that the Act is void, inoperative and unen- forceable as violative of Articles 14, 19
& 21 of the Con- stitution- Similarly, the second writ petition, namely, writ petition No. 268/89
which is filed by Sh. Charan Lal Sahu, who is also a practising Advocate on behalf of the victims and
claims to have suffered damages as a result of the gas leak. challenges the Act. He further challenges
the settle- ment entered into under the Act. He says that the said settlement was violative of
principles of natural justice and the fundamental right of the said petitioner and other victims. It is
his case that in so far as the Act permits such a course to be adopted, such a course was not
permissi- ble under the Constitution. He further asserts that the Union of India was negligent and a
joint tort-feasor. In the premises, according to him, the Act is bad, the settlement is bad and these
should be set aside.
33. In order to determine the question whether the Act in question is constitutionally valid or not in
the light of Articles 14, 19(l)(g) and 21 of the Constitution, it is necessary to find out what does the
Act actually mean and provide for. The Act in question, as the Preamble to the Act states, was passed
in order to confer powers on the Central Government to secure that the claims arising out of, or
connected with, the Bhopal gas leak disaster are dealt with speedily, effectively, equitably and to the
best advantage of the claimants and for matters incidental thereto. There- fore, securing the claims
arising out of or connected with the Bhopal gas leak disaster is the object and purpose of the Act. WeCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

have noticed the proceedings of the Lok Sabha in connection with the enactment of the Act. Our
attention was also drawn by the learned Attorney General to the proceed- ings of the Rajya Sabha
wherein the Hon'ble Minister, Shri Virendra Patil explained that the bill enabled the Govern- ment
to assume exclusive right to represent and act, whether within or outside India in place of every
person who had made or was entitled to make claim in relation to the disas- ter and to institute any
suit or other proceedings or enter into any compromise as mentioned in the Act. The whole object of
the Bill was to make procedural changes to the existing Indian law which would enable the Central
Govern- ment to take up the responsibility of fighting litigation on behalf of these victims. The first
point was that it sought to create a locus standi in the Central Government to file suits on behalf of
the victims. The object of the Statute. it was highlighted, was that because of the dimen- sion of the
tragedy covering thousands of people, large number of whom being poor, would not be able to go to
the courts, it was necessary to create the locus standi in the Central Government to start the
litigation for payment of compensation in the courts on their behalf. The second aspect of the Bill
was that by creating this locus standi in the Central Government, the Central Government became
compe- tent to institute judicial proceedings for payment of com- pensation on behalf of the victims.
The next aspect of the Bill was to make a distinction between those on whose behalf suits had
already been filed and those on whose behalf proceedings had not yet then been instituted. One of
the Members emphasised that under Article 21 of the Constitu- tion, the personal liberty of every
citizen was guaranteed and it has been widely interpreted as to what was the mean- ing of the
expression 'personal liberty'. It was cmphasised that one could not take away the right of a person,
the liberty of a person, to institute proceedings for his own benefit and for his protection. It is from
this point of view that it was necessary, the member debated, to preserve the right of a claimant to
have his own lawyers to represent him along with the Central Government in the proceedings under
Section 4 of the Act, this made the Bill constitution- ally valid.
34. Before we deal with the question of constitutionali- ty, it has to be emphasised that the Act in
question deals with the Bhopal gas leak disaster and it deals with the claims meaning thereby claims
arising out of or connected with the disaster for compensation of damages for loss of life or any
personal injury which has been or is likely to be caused and also claims arising out of or connected
with the disaster for any damages to property or claims for expenses incurred or required to be
incurred for containing the disaster or making or otherwise coping with the impact of the disaster
and other incidental claims. The Act in question does not purport to deal with the criminal liabili- ty,
if any, of the parties or persons concerned nor it deals with any of the consequences flowing from
those. This posi- tion is clear from the provisions and the Preamble to the Act. Learned Attorney
General also says that the Act does not cover criminal liability. The power that has been given to the
Central Government is to represent the 'claims', meaning thereby the monetary claims. The
monetary claims, as was argued on behalf of the victims, are damages flowing from the gas disaster.
Such damages, Mr. Garg and Ms. Jais- ing submitted, are based on strict liability, absolute liability
and punitive liability. The Act does not, either expressly or impliedly, deal with the extent of the
damages or liability. Neither section 3 nor any other section deals with any consequences of criminal
liability. The expression "the Central Government shall, and shall have the exclusive right to,
represent, and act in place of (whether within or outside India) every person who has made, or is
entitled to make, a claim for all purposes connected with such claim in the same manner and to the
same effect as such person", read as it is, means that Central Government is substituted and vestedCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

with the exclusive right to act in place of the victims, i.e., eliminating the victims, their heirs and
their legal representatives, in respect of all such claims arising out of or connected with the Bhopal
gas leak disas- ter. The right, therefore, embraces right to institute proceedings within or outside
India along with right to institute any suit or other proceedings or to enter into compromise.
Sub-section 1 of section 3 of the Act, there- fore, substitutes the Central Government in place of the
victims. The victims, or their heirs and legal representa- tives, get their rights substituted in the
Central Govern- ment along with the concomitant right to institute such proceedings, withdraw such
proceedings or suit and also to enter into compromise.The victims or the heirs or the legal
representatives of the victims, are substituted and their rights are vested in the Central Government.
This happens by operation of section 3 which is the legislation in question. Sub-section (3) of section
3 makes it clear that the provi- sions of sub-section (1) of section 3 shall also apply in relation to
claims in respect of which suits or other pro- ceedings have been instituted in or before any court or
other authority (whether within or outside India) before the commencement of this Act, but makes a
distinction in the case of any such suit or other proceeding with respect to any claim pending
immediately before the commencement of this Act in or before any court or other authority outside
India, and provides that the Central Government shall repre- sent, and act in place of, or along with,
such claimant, if such court or other authority so permits. Therefore, in cases where such suits or
proceedings have been instituted before the commencement of the Act in any court or before any
authority outside India, the section by its own force will not come into force in substituting the
Central Govern- ment in place of the victims or the heirs or their legal representatives, but the
Central Government has been given the right to act in place of, or along with, such claimant,
provided such court or other authority so permits. It is to have adherence and conformity with the
procedure of the countries or places outside India, where suits or proceed- ings are to be instituted
or have been instituted. There- fore, the Central Government is authorised to act along with the
claimants in respect of proceedings instituted outside India subject to the orders of such courts or
the authori- ties. Is such a right valid and proper?
35. There is the concept known both in this country and abroad, called "parens patriae. Dr. D.K.
Mukherjea in his "Hindu Law of Religious and Charitable Trusts", Tagore Law Lectures, Fifth
Edition, at page 404, referring to the concept of parens patriae, has noted that in English Law, the
Crown as parens patriae is the constitutional protector of all property subject to charitable trusts,
such trusts being essentially matters of public concern. Thus the posi- tion is that according to
Indian concept parens patriae doctrine recognized King as the protector of all citizens and as parent.
In Budhakaran Chankhani v. Thakur Prasad Shah, AIR 1942 Cal. 311 the position was explained by
the Calcutta High Court at page 3 18 of the report. The same position was reiterated by the said
Court in Banku Behary Mondal v. Banku Behary Hazra & Anr., AIR 1943 Cal. 203 at page 205 of the
report. The position was further elaborated and explained by the Madras High Court in Medai
Dalavoi T. Kumaraswami Mudaliar v. Medai Dalavoi Rajammal, AIR 1957 Mad. 563 at page 567 of
the report. This Court also recog- nized the concept of parens patriae relying on the observa- tions of
Dr. Mukherjea aforesaid in Ram Saroop v. S.P. Sahi, [1959] 2 Supp. SCR 583, at pages 598 and 599.
In the "Words and Phrases" Permanent edition, Vol. 35 at p. 99, it is stated that parens patriae is the
inherent power and author- ity of a Legislature to provide protection to the person and property of
persons non suijuris, such as minor, insane, and incompetent persons, but the words "parens
patriae" meaning thereby 'the father of the country', were applied originally to the King and are usedCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

to designate the State referring to its sovereign power of guardianship over persons under disability,
(Emphasis supplied). Parens patriae jurisdic- tion, it has been explained, is the right of the sovereign
and imposes a duty on sovereign, in public interest, to protect persons under disability who have no
rightful pro- tector. The connotation of the term "parens patriae" differs from country to country, for
instance, in England it is the King, in America it is the people, etc. The Government is within its duty
to protect and to control persons under disability. Conceptually, the parens patriae theory is the
obligation of the State to protect and take into custody the rights and the privileges of its citizens for
discharging its obligations. Our Constitution makes it imperative for the State to secure to all its
citizens the rights guaran- teed by the Constitution and where the citizens are not in a position to
assert and secure their rights, the State must come into picture and protect and fight for the rights of
the citizens. The Preamble to the Constitution, read with the Directive Principles, Articles 38, 39 and
39A enjoins the State to take up these responsibilities. It is the protective measure to which the
social welfare state is committed. It is necessary for the State to ensure the funda-
mental rights in conjunction with the Directive Princi- ples of State Policy to effectively discharge its
obliga- tion and for this purpose, if necessary, to deprive some rights and privileges of the individual
victims or their heirs to protect their rights better and secure these further. Reference may be made
to Alfred L. Snapp & Son, Inc. v. Puerto Rico, 458 US 592, 73 L. Ed. 2d 995, 1028. Ct, 3260 in this
connection. There it was held by the Supreme Court of the United States of America that
Commonwealth of Puerto have standing to sue as parens patriae to enjoin apple growers'
discrimination against Puerto Rico migrant farm workers. This case illustrates in some aspect the
scope of 'parens patriae'. The Commonwealth of Puerto Rico sued in the United States District Court
for the Western District of Virginia, as parens patriae for Puerto Rican migrant farm workers, and
against Virginia apple growers, to enjoin discrimination against Puerto Ricans in favour of Jamaican
workers in violation of the Wagner-Peyser Act, and the Immigration and Nationality Act. The
District Court dis- missed the action on the ground that the Commonwealth lacked standing to sue,
but the Court of Appeal for the Fourth Circuit reversed it. On certiorari, the United States Supreme
Court affirmed. In the opinion by White, J. joined by Burger, Chief Justice and Brennan, Marshall,
Blackman, Rennquist, Stevens, and O'Connor, JJ., it was held that Puerto Rico had a claim to
represent its quasi sovereign interests in federal court at least which was as strong as that of any
State, and that it had parens patriae standing to sue to secure its residents from the harmful effects
of discrimination and to obtain full and equal participation in the federal employment service
scheme established pursu- ant to the Wagner-Peyser Act and the Immigration and Nation- ality Act
of 1952. Justice White referred to the meaning of the expression "parens patriae". According to
Black's Law Dictionary, 5th Edition 1979, page 1003, it means literally 'parent of the country' and
refers traditionally to the role of the State as a sovereign and guardian of persons under legal
disability. Justice White at page 1003 of the report emphasised that the parens patriae action had its
roots in the common-law concept of the "royal prerogative". The royal prerogative included the right
or responsibility to take care of persons who were legally unable, on account of mental incapacity,
whether it proceeds from nonage, idiocy, or lunacy to take proper care of themselves and their
property. This prerogative of parens patriae is inherent in the supreme power of every state, whether
that power is lodged in a royal person or m the legislature and is a most beneficent function. After
discussing several cases Justice White observed at page 1007 of the report that in order to maintain
an action, in parens patriae, the state must artic- ulate an interest apart from the interests ofCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

particular parties, i.e. the State must be more than a nominal party. The State must express a
quasi-sovereign interest. Again an instructive insight can be obtained from the observations of
Justice Holmes of the American Supreme Court in the case of Georgia v. Tennessee Copper Co., 206
US 230, 51 L.Ed. 1038, 27 S Ct 618, which was a case involving air pollution in Georgia caused by the
discharge of noxious gases from the defendant's plant in Tennessee. Justice Holmes at page 1044 of
the report described the State's interest as follows:
"This is a suit by a State for an injury to it in its capacity of quasi-sovereign. In that
capacity the State has an interest independent of and behind the titles of its citizens,
in all the earth and air within its domain. It has the last word as to whether its
mountains shall be stripped of their forests and its inhabitants shall breathe pure air.
It might have to pay individuals before it could utter that word, but with it remains
the final power ......
..... When the States by their union made the forcible abatement of outside nuisances
impossible to each, they did not thereby agree to submit to whatever might be done.
They did not renounce the possibility of making reasonable demands on the ground
of their still remaining quasi-sovereign inter- ests"
36. Therefore, conceptually and from the jurisprudential point of view, especially in the background
of the Preamble to the Constitution of India and the mandate of the Direc- tive Principles, it was
possible to authorise the Central Government to take over the claims of the victims to tight against
the multinational Corporation in respect of the claims. Because of the situation the victims were
under disability in pursuing their claims in the circumstances of the situation fully and properly. On
its plain terms the State has taken over the exclusive right to represent and act in place of every
person who has made or is entitled to make a claim for all purposes connected with such claim in
the same manner and to the same effect as such person. Whether such provision is valid or not in
the background of the requirement of the Constitution and the Code of Civil Procedure, is another
debate. But there is no prohibition or inhibition, in our opinion, conceptually or jurisprudential- ly
for Indian State taking over the claims of the victims or for the State acting for the victims as the Act
has sought to provide. The actual meaning of what the Act has provided and the validity thereof,
however, will have to be examined in the light of the specific submissions advanced in this case.
37. Ms. Indira Jaising as mentioned hereinbefore on behalf of some other victims drew out attention
to the background of the passing of the Act in question. She drew our attention to the fact that the
Act was to meet a specif- ic situation that had arisen after the tragic disaster and the advent of
American lawyers seeking to represent the victims in American courts. The Government's view,
according to her, as was manifest from the Statement of Objects and Reasons, debates of the
Parliament, etc. was that the inter- ests of the victims would be best served if the Central
Government was given the right to represent the victims in the courts of United States as they would
otherwise be exploited by 'ambulance-chasers' working on contingency fees. The Government also
proceeded initially on the hypoth- esis that US was the most convenient forum in which to sue UCC.
The Government however feared that it might not have locus standi to represent the victims in the
courts of the United States of America unless a law was passed to enable it to sue on behalf of theCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

victims. The dominant object of the Act, therefore, according to her, was to give to the Government
of India locus Standi to sue on behalf of the victims in foreign jurisdiction, a standing which it other-
wise would not have had. According to her, the Act was never intended to give exclusive rights to the
Central Government to sue on behalf of the victims in India or abroad. She drew our attention to the
parliamentary debates as mentioned hereinbefore. She drew our attention to the expression 'parens
patriae' as appearing in the Words and Phrases, Volume 31 p. 99. She contends that the Act was
passed to provide locus standi only to represent in America. She drew our attention to the
"American Constitutional Law by Lau- rence B. Trioe, 1978 Edition at paragraph 3.24, where it was
stated that in its capacity as proprietor, a state may satisfy the requirement of injury to its own
interests by an assertion of harm to the state as such. It was further stated by the learned author
there that the State may sue under the federal anti-trust laws to redress wrongs suffered by it as the
owner of a railroad and as the owner and opera- tor of various public institutions. It was emphasised
that in its quasi-sovereign capacity, the state has an interest, independent of and behind the titles of
its citizens, in all the earth and air within its domain. It was sought to be suggested that in the
instant Act no such right was either asserted or mentioned. The State also in its quasi-sovereign
capacity is entitled to bring suit against a private indi- vidual to enjoin a corporation not to
discharge noxious gases from its out of state plant into the suing state's territory. Finally, it was
emphasised that as 'parens patr- iae' on behalf of the citizens, where a state's capacity as parens
patriae is not negated by the federal structure, the protection of the general health, comfort, and
welfare of the state's inhabitants has been held to give the state itself a sufficient interest. Ms.
Jaising sought to contend that to the extent that the Act was not confined to empowering the
Government to sue on behalf of those who were not sui generis but extended also to representing
those who are, this exercise of the power cannot be referrable to the doctrine of 'parens patriae'. To
the extent, it is not confined in enabling the Government to represent its citizens in foreign
jurisdiction but empowered it to sue in local courts to the exclusion of the victims it cannot be said
to be in exercise of doctrine of 'parens patriae', according to her. We are unable to agree. As we have
indicated before conceptually and juris- prudentially there is no warrant in the background of the
present Act, in the light of circumstances of the Act in question to confine the concept into such
narrow field. The concept can be varied to enable the Government to represent the victims
effectively in domestic forum if.the situation so warrants. We also do not find any reason to confine
the 'parens patriae' doctrine to only quasisovereign right of the State independent of and behind the
title of the citi- zens, as we shall indicate later.
38. It was further contended that deprivation of the rights of the victims and denial of the rights of
the vic- tims or the fights of the heirs of the victims to access to justice was unwarranted and
unconstitutional. She submitted that it has been asserted by the Government that the Act was
passed pursuant to Entry 13 of the List I of the Seventh Schedule to the Constitution. It was
therefore submitted that to the extent it was a law relating to civil procedure, it sets up a different
procedure for the Bhopal gas victims and denies to them equality before law, violating Article 14 of
the Constitution. Even assuming that due to the magnitude of the disaster, the number of claimants
and their disabili- ty they constituted a separate class and that it was permis- sible to enact a special
legislation setting up a special procedure for them, the reasonableness of the procedure has still to
be tested. Its reasonableness, according to her, will have to be judged on the touchstone of the
existing Civil Procedure Code of 1908 and when so tested, it is found wanting in several respects. ItCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

was also contended by the Government that it was a legislation relating to "actionable wrongs"
under Entry 8 of the Concurrent List of the Seventh Schedule. But so read, she said, it could only
deal with the procedural aspects and not the substantive aspect of "ac- tionable wrongs". If it does,
then the reasonableness of a law must be judged with reference to the existing substan- tive law of
actionable wrongs and so judged it is in viola- tion of many constitutional rights as it takes away
from the victims the right to sue for actionable wrongs according to counsel for the victims.
According to her, it fails to take into account the law of strict liability for ultra hazardous activity as
clarified by this Court in M.C. Meh- ta's, case (supra). She further submitted that it is a bad Act as it
fails to provide for the right to punitive damages and destruction of environment.
39. It was contended on behalf of the Central Government that the Act was passed to give effect to
the Directive Principle as enshrined under Article 39-A of the Constitu- tion of India. It was, on the
other side, submitted that it is not permissible for the State to grant legal aid on pain of destroying
rights that inhere in citizens or on pain of demanding that the citizens surrender their rights to the
State. The Act in fact demands a surrender of rights of the citizens to the State. On the interpretation
of the Act, Ms. Indira Jaising submitted that sections 3 and 4 as noted above, give exclusive power to
the Government to represent the victims and there is deprivation of the victims' right to sue for the
wrongs done to them which is uncanalised and unguided and the expression "due regard" in section
4 of the Act does not imply consent and as such violative of the rights of the victims. The right to be
associated with the conduct of the suit is hedged in with so many conditions that it is illusory.
According to her, a combined reading of sections 3 and 4 of the act lead to the conclusion that the
victims are displaced by the Central Government which has constituted itself as the "surrogate" of
the claimants, that they have no control over the proceedings, that they have no right to decide
whether or not to compromise and if so on what terms and they have no right to be heard by the
court before any such compromise is effected. Therefore, section 3 read with section 4, according to
her, hands over to the Government all effective rights of the victims to sue and is a naked usurption
of power. It was submitted that in any event on a plain reading of the Act, section 3 read with section
4 did not grant the Government immunity from being sued as a joint tort-feasor.
40. It was further urged that section 9 makes the Gov- ernment the total arbitor in the matter of the
registration, processing and recording of claims. Reference was made to section 9(2)(a), (b) and (c)
and disbursal of claims under sections 9(2)(f) and 10. It was urged that the Deputy Com- missioner
and Commissioner appointed under the Act and the Scheme are subordinates and agents of the
Central Govern- ment. They replace impartial and independent civil court by officers and
subordinates of the Central Government. Clause 11 of the Scheme makes the Central Government,
according to counsel, judge in its own cause inasmuch as the Central Government could be and was
in fact a joint tort-feasor. It was submitted that sections 5 to 9 of the Act read with the Scheme do
not set up a machinery which is constitutionally valid. The Act, it was urged, deprives the victims of
their rights out of all proportion to the object sought to be achieved, namely, to sue in foreign
jurisdic- tion or to represent those incapable of representing them- selves. The said object could be
achieved, according to counsel, by limiting the right to sue in foreign jurisdic- tion alone and in any
event representing only those victims incapable of representing themselves. The victims who wish to
sue for and on their own behalf must have power to sue, all proper and necessary parties including
Government of India, Government of Madhya Pradesh, UCIL and Shri Arjun Singh to vindicateCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

their right to life and liberty and their rights cannot and should not be curtailed, it was submitted.
Hence, the Act goes well beyond its objects and imposes excessive restriction amounting to
destruction of the rights of the victims, according to. counsel. In deciding whether any rights are
affected, it is not the object of the Act that is relevant but its direct and inevitable effect on the rights
of the victims that is material. Hence no matter how laudable the object of the Act is alleged to be by
the Government of India, namely, that it is an Act to give effect to Directive Principles enshrined in
Article 39-A of the Constitution, the direct and inevitable effect of sec- tion 3 according to counsel
for the victims is to deprive the victims of the right to sue for and on their own behalf through
counsel of their choice and instead empower the Central Government to sue for them.
41. The Act is, it was contended, unconstitutional because it deprives the victims of their right to life
and personal liberty guaranteed by Article 21. The right to life and liberty includes the right to sue
for violations of the right, it was urged. The right to life guaranteed by Article 21 must be interpreted
to mean all that makes life livable, life in all its fullness. According to counsel, it includes the right to
livelihood. Reference was made to the decision of Olga Tellis v. B.M.C., [1985] Supp. 2 SCR 51 at p.
78-83. This right, it was contended, is inseparable from the reme- dy. It was urged that personal
liberty includes a wide range of freedoms to decide how to order one's affairs. Reference was made
to Maneka Gandhi v. Union of India, (supra), The right to life and liberty also includes the right to
healthy environment free from hazardous pollutants. The right to life and liberty, it was submitted,
is inseparable from the remedy to judicial vindication of the violation of that right--the right of
access to justice must be deemed to be part of that right. Therefore, the importance is given to the
right to file a suit for an actionable wrong. See Ganga Bai v. Vijay Kumar, [1974] 3 SCR 882 at 886.
According to counsel appearing for the victims, the Act read strictly infringes the right to life and
personal liberty because the right to sue by the affected person for damages flowing from
infringement of their rights is taken away. Thus, it was submitted that not just some inci- dents of
the right to life, but the right itself in all its fullness is taken away. Such depravation, according to
counsel, of the right is not in accordance with procedure established by law inasmuch as the law
which takes away the right, i.e., impugned Act is neither substantively nor procedurally just, fair or
reasonable. A law which divests the victims of the right to sue to vindicate for life and personal
liberty and vests the said right in the Central Government is not just, fair or reasonable. The victims
are sui generis and able to decide for themselves how to vindi- cate their claims in accordance with
law. There is, there- fore, no reason shown to exist for divesting them of that right and vesting that
on the Central Government.
42. All the counsel for the victims have emphasised that vesting of the right in Central Government
is bad and unrea- sonable because there is conflict of interests between the Central Government and
the victims. It was emphasised that the conflict of interest has already prejudiced the victims in the
conduct of the case inasmuch as a compromise unac- ceptable to the victims has been entered into
in accordance with the order of this Court of 14th/15th February, 1989 without heating the victims.
This conflict of interest will continue, it was emphasised, to adversely affect the victims inasmuch as
section 9 of the Act read with clauses 5, 10 and 11 of the Scheme empower the Central Government
to process claims, determine the category into which these fall, deter- mine the basis on which
damages will be payable to each category and determine the amount of compensation payable to
each claimant. Learned counsel urged that the right to a just, fair and reasonable procedure wasCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

itself a guaranteed fundamental right under Article 14 of the Constitution. This included right to
natural justice. Reference was made to Olga Tellis's. case (supra) and S.L. Kapoor v. Jagmohan,
[1981] 1 SCR 746 at 753, 766. The right to natural justice is included in Article 14 Tulsi Ram v. Union
of India, [1985] Supp. 2 SCR 131. Reference was also made to Maneka Gandhi's, case (supra). It was
contended by counsel that the right to natural justice is the right to be heard by Court at the
pre-decisional stage, i.e., before any compromise is effected and accepted. Reference was made to
the decision of this Court in Swadeshi Cotton v. Union of India, [1981] 2 SCR 533. It was submitted
that natural justice is a highly effective tool devised by the Courts to ensure that a statu- tory
authority arrives at a just decision. It is calculated to act as a healthy check on the abuse of power.
Natural justice is not dispensable nor is it an empty formality. Denial of that right can and has led to
the miscar-
riage of justice in this case. According to counsel, if the victims had been given an opportunity to be
heard, they would, inter alia, have pointed out that the amount agreed to be paid by UCC was
hopelessly inadequate and that UCC, its officer and agents ought not to be absolved of criminal
liability, that the Central Government itself was liable to have been sued as a joint tort-feasor and,
according to counsel, had agreed to submit to a decree if found liable under the order dated 31st
December, 1985, that suits had been filed against the State of Madhya Pradesh, Shri Arjun Singh
and UCIL which said suits cannot be deemed to have been settled by the compromise/order of
14th/15th February, 1989. It was also pointed out that Union of India was under
a duty to sue UCIL, which it had failed and neglected to do. It was submitted that to
the extent that the statute does not provide for a pre-decisional hearing on the
fairness of the proposed settlement or compromise by Court, it is void as offending
natural justice hence violative of Articles 14 and 21 of the Constitution. Alternatively,
it was contended by the counsel that since the statute neither expressly nor by
necessary implication bars the right to be heard by Court before any compromise is
effected such a right to a pre- decisional hearing by Court must be read into section
3(2)(b) of the Act. Admittedly, it does not expressly ex- clude the right to a hearing by
Court prior to any settle- ment being entered into. Far from excluding such a right by
necessary implication, having regard to the nature of the rights affected, i.e., the right
to life and personal liber- ty, such a right to hearing must be read into the Act in
order to ensure that justice is done to the victims, accord- ing to all the counsel. The
Act sets up a procedure differ- ent from the ordinary procedure established by law,
namely, Civil Procedure Code. But it was submitted that the Act should be
harmoniously read with the provisions of Civil Procedure Code and if it is not so read,
then the Act in question would be unreasonable and unfair. In this connec- tion,
reliance was placed on the provisions of Order I, Rule 4, Order 23, Rule 1 proviso,
Order 23, Rule 3-9 and Order 32, Rule 7 of CPC and it was submitted that these are
not inconsistent with the Act. On the contrary these are neces- sary and
complementary, intended to ensure that there is no miscarriage of justice. Hence
these must be held to apply to the facts and circumstances of the case and the
impugned Act must be read along with these provisions. Assuming that the said
provisions do not directly apply then, provisions analogous to the said provisionsCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

must be read with section 3(2)(b) to make the Act reasonable, it was submitted. It
was urged that if these are not so read then the absence of such provisions would vest
arbitrary and unguided powers in the Central Government making section 3(2)(b)
unconstitutional. The said provisions are intended to ensure the machinery of
accountability to the victims and to provide to them, an opportunity to be heard by
court before any compromise is arrived at. In this connection, reference was made to
Rule 23(3) of the Federal Rules of Civil Procedure in America which provides for a
hearing to the victims before a compro- mise is effected. The victims as plaintiffs in
an Indian court cannot be subjected to a procedure which is less fair than that
provided by a US forum initially chosen by the Government of India, it was urged.
43. Counsel submitted that Section 6 of the Act is unreasonable because it replaces an
independent and impar-
tial Civil Court of competent jurisdiction by an Officer known as the Commissioner to be appointed
by the Central Government. No qualification, according to counsel, had been prescribed for the
appointment of a Commissioner and clause 5 of the Scheme framed under the Act vests in the
Commis- sioner the judicial function of deciding appeals against the order of the Deputy
Commissioner registering or refusing to register a claim. It was further submitted that clause 11(2)
of the Scheme is unreasonable because it replaces an inde- pendent and impartial civil court of
competent jurisdiction with the Central Government, which is a joint tort-feasor for the purpose of
determining the total amount of compensa- tion to be apportioned for each category of claims and
the quantum of compensation payable for each type of injury or loss. It was submitted that the said
function is a judicial function and if there is any conflict of interest between the victims and Central
Government, vesting such a power in the Central Government amounts to making it a judge in its
own cause. It was urged that having regard to the fact that amount received in satisfaction of the
claims is ostensibly pre-determined, namely, 470 million dollars unless the order of 14th/15th
February is set aside which ought to be done, according to counsel, the Central Government would
have a vested interest in ensuring that the amount of damages to be disbursed does not exceed the
said amount. Even otherwise, according to counsel, the Government of India has been sued as a
joint tort-feasor, and as they would have a vested interest in depressing the quantum of damages,
payable to the victims. This would, according to counsel, result in a deliberate under-estimation of
the extent of injuries and compensation payable.
44. Clause 11(4) of the Scheme, according to counsel, is unreasonable inasmuch as it does not take
into account the claims of the victims to punitive and exemplary damages and damages for loss and
destruction of environment. Counsel submitted that in any event the expression "claims" in section
2(b) cannot be interpreted to mean claims against the Central Government, the State of Madhya
Pradesh, UCIL, which was not sued in suit No. 1113/86 and Shri Arjun Singh, all of whom have been
sued as joint tort feasors in relation to the liability arising out of the disaster. Counsel submitted that
if section 3 is to be held to be intra vires, the word "exclusive" should be severed from section 3 and
on the other hand, if section 3 is held ultra vires, then victims who have already filed suits or those
who had lodged claims should be entitled to continue their own suits as well as Suit No. 1113/86 as
plaintiffs with leave under Order 1 Rule 8. Counsel submitted that interim relief as decided by thisCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

Court can be paid to the victims even otherwise also, according to counsel, under clause 10(2)(b) of
the Scheme.
45. Counsel submitted that the balance of $ 470 million after deducting interim relief as determined
by this Court should be attached. In any event, it was submitted that, it be declared that the word
"claim" in section 2 does not include claims against Central Govt. or State of Madhya Pradesh or
UCIL. Hence, it was urged that the rights of the victims to sue the Government of India, the State of
Madhya Pradesh or UCIL would remain unaffected by the Act or by the compromise effected under
the Act. Machinery to decide suit expeditiously has to be devised, it was submitted. Other suits filed
against UCC, UCIL, State of Madhya Pradesh and Arjun Singh should to be transferred to the
Supreme Court for trial and disposal, according to counsel. It was submit- ted that the Court should
fix the basis of damages payable to different categories, namely, death and disablement mentioned
under clause 5(2) of the scheme. Counsel submitted that this Court should set up a procedure which
would ensure that an impartial judge assisted by medical experts and assessors would adjudicate the
basis on which an individual claimant would fall into a particular category. It was also urged that
this Court should quantify the amount of compen- sation payable to each category of claimant in
clause 5(2) of the Scheme. This decision cannot, it was submitted, be left to the Central Government
as is purported to be done by clause 11(2) of the Scheme.
This Court must set up, it was urged, a trust with independent trustees to administer the trust and
trustees to be accountable to this Court. An independent census should be carried out of number of
claimants, nature and extent of injury caused to them, the category into which they fall.
Apportionment of amounts should be set aside or invested for future claimants, that is the category
in clause 5(2)(a) of the Scheme, which is, according to counsel, of utmost impor- tance since the
injuries are said to be. carcinogenic and ontogen- ic and wide affecting persons yet unborn.
47. Shri Garg, further and on behalf of some of the victims counsel, urged before us that deprivation
of the rights of the victims and vesting of those fights in the State is violative of the rights of the
victims and cannot. be justified or warranted by the Constitution. Neither section 3 nor section 4 of
the Act gives any right to the victims; on the other hand, it is a complete denial of access to justice
for the victims, according to him. This, according to counsel, is arbitrary. He also submitted that
section 4 of the Act, as it stands, gives no right to the victims and as such even assuming that in
order to fight for the rights of the victims, it was necessary to substitute the victims even then in so
far as the victims have been denied the right of say, in the conduct of the proceedings, this is
disproportionate to the benefit conferred upon the victims. Denial of rights to the victims is so great
and deprivation of the right to natural justice and access to justice is so tremendous that judged by
the well settled principles by which yardsticks provisions like these should be judged in the
constitutional framework of this country, the Act is violative of the fundamental rights of the vic-
tims. It was further submitted by him that all the rights of the victims by the process of this Act, the
right of the victims to enforce full liability against the multinationals as well as against the Indian
Companies, absolute liability and criminal liability have all been curtailed.
48. All the counsel submitted that in any event, the criminal liability cannot be subject matter of this
Act. Therefore, the Government was not entitled to agree to any settlement on the ground thatCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

criminal prosecution would be withdrawn and this being a part of the consideration or inducement
for settling the civil liability, he submitted that the settlement arrived at on the 14th/l5th February,
1989 as recorded in the order of this Court is wholly unwar- ranted, unconstitutional and illegal.
49. Mr. Garg additionally further urged that by the procedure of the Act, each individual claim had
to be first determined and the Government could only take over the aggregate of all individual
claims and that could only be done by aggregating the individual claims of the victims. That was not
done, according to him. Read in that fashion, according to Shri Garg, the conduct of the Government
in implementing the Act is wholly improper and unwarranted. It was submitted by him that the
enforcement of the fight of the victims without a just, fair and reasonable procedure which is vitally
necessary for representing the citizens or victims was bad. It was further urged by him that the
Bhopal gas victims have been singled out for hostile discrimination resulting in total denial of all
procedures of approach to competent courts and tribunals. It was submitted that the Central
Government was incompetent to represent the victims in the litigations or for enforcement of the
claims. It was then submitted by him that the claims of the victims must be enforced fully against
the Union Carbide Corporation carry- ing on commercial activities for profit resulting in unprec-
edented gas leak disaster responsible for a large number of deaths and severe injuries to others. It
was submitted that the liability of each party responsible, including the Government of India, which
is a joint tort-feasor along with the Union Carbide, has to be ascertained in appropriate proceedings.
It was submitted on behalf of the victims that Union of India owned 22% of the shares in Union
Carbide and therefore, it was incompetent to represent the victims. There was conflict of interest
between the Union of India and the Union Carbide and so Central Government was incompe- tent.
It is submitted that pecuniary interest howsoever small disqualifies a person to be a judge in his own
cause. The settlement accepted by the Union of India, according to various counsel is vitiated by the
pecuniary bias as holders of its shares to the extent of 22%.
50. It was submitted that the pleadings in the court of the United States and in the Bhopal court
considered in the context of the settlement order of this Court accepted by the Union of India
establish that the victims' individuality were sacrificed wontedly and callously and, therefore, there
was violation, according to some of the victims, both in the Act and in its implementation of Articles
14, 19(l)(g) and 21 of the Constitution.
51. The principles of the decision of this Court in M.C. Mehta & Anr. v. Union of India, [1987] 1 SCR
819 must be so interpreted that complete justice is done and it in no way excludes the grant of
punitive damages for wrongs justifying deterrents to ensure the safety of citizens in free India. No
multinational corporation, according to Shri Garg, can claim the privilege of the protection of Indian
law to earn profits without meeting fully the demands of civil and criminal justice administered in
India with this Court functioning as the custodian. Shri Garg urged that the liability for damages, in
India and the Third World Coun- tries, of the multinational companies cannot be less but must be
more because the persons affected are often without remedy for reasons of inadequate facilities for
protection of health or property. Therefore, the damages sustainable by Indian victims against the
multinationals dealing with dangerous gases without proper security and other measures are far
greater than damages suffered by the citizens of other advanced and developed countries. It is,
therefore, neces- sary to ensure by damages and deterrent remedies that these multinationals areCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

not tempted to shift dangerous manufac- turing operations intended to advance their strategic
objec- tives of profit and war to the Third World Countries with little respect for the right to life and
dignity of the people of sovereign third world countries. The strictest enforcement of punitive
liability also serves the interest of the American people. The Act, therefore, according to Shri Garg is
clearly unconstitutional and therefore, void.
52. It was urged that the settlement is without juris- diction. This Court was incompetent to grant
immunity against criminal liabilities in the manner it has purported to do by its order dated
14th/l5th February, 1989, it was strenuously suggested by counsel. It was further submitted that to
hold the Act to be valid, the victims must be heard before the settlement and the Act can only be
valid if it is so interpreted. This is necessary further, according to Shri Garg, to lay down the scope of
heating. Shri Garg also drew our attention to the scheme of disbursement of relief to the victims. He
submitted that the scheme of disbursement is unreasonable and discriminatory because there is no
proce- dure which is just, fair and reasonable in accordance with the provisions of Civil Procedure
Code. He further submitted that the Act does not lay down any guidelines for the con- duct of the
Union of India in advancing the claims of the victims. There were no essential legislative guidelines
for determining the rights of the victims, the conduct of the proceedings on behalf of the victims and
for the relief- claimed. Denial of access to justice to the victims through an impartial judiciary is so
great a denial that it can only be consistent with the situation which calls for such a drastic
provision. The present circumstances were not such. He drew our attention to the decision of this
Court in Basheshar v. Income Tax Commissioner, AIR 1959 SC 149; in Re Special Courts Bill, [1979]
2 SCR 476; A.R. Antulay v. R.S. Nayak & Anr., [1988] 2 SCC 602; Ram Krishna Dalmia v. Ten-
dulkar, [1955] SCR 279; Ambika Prasad Mishra etc. v. State of U.P. & Ors. etc., [1960] 3 SCR 1159
and Bodhan Chowdhary v. State of Bihar, [1955] 1 SCR 1045. Shri Garg further submitted that
Article 21 must be read with Article 51 of the Constitution and other directive principles. He drew
our attention to Lakshmi Kant Pandey v. Union of India, [1984] 2 SCR 795; M/s Mackinnon
Machkenzie & Co. Ltd. v. Audrey D'Costa and Anr., [1987] 2 SCC 469; Sheela Barse v. Secretary,
Children Aid Society & Ors., [1987] 1 SCR 870. Shri Garg submitted that in india, the national
dimensions of human rights and the international dimensions are both congruent and their
enforcement is guaranteed under Articles 32 and 226 to the extent these are enforceable against the
State, these are also enforceable against transnational corpora- tions inducted by the State on
conditions of due observance of the Constitution and all laws of the land. Shri Garg submitted that
in the background of an unprecedented disas- ter resulting in extensive damage to life and property
and the destruction of the environment affecting large number of people and for the full protection
of the interest of the victims and for complete satisfaction of all claims for compensation, the Act
was passed empowering the Government of India to take necessary steps for processing of the
claims and for utilisation of disbursal of the amount re- ceived in satisfaction of the claims. The
Central Government was given the exclusive right to represent the victims and to act in place of, in
United States or in india, every citizen entitled to make a claim. Shri Garg urged that on a proper
reading of section 3(1) of the Act read with section 4 exclusion of all victims for all purpose is
incomplete and the Act is bad. He submitted that the decree for adjudica- tion of the Court must
ascertain the magnitude of the dam- ages and should be able to grant reliefs required by law under
heads of strict liability, absolute liability and punitive liability.Charan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

53. Shri Garg submitted that it is necessary to consider that the Union of India is liable for the torts.
In several decisions to which Shri Garg grew our attention, it has been clarified that Government is
not liable only if the tortious act complained has been committed by its servants in exer- cise of its
sovereign powers bY which it is meant powers that can be lawfully exercised under sovereign rights
only vide Nandram Heeralal v. Union of India & Anr., AIR 1978 M.P. 209 at p. 212. There is a real
and marked distinction between the sovereign functions of the government and those which are
non-sovereign and some of the functions that fall in the latter category are those connected with
trade, commerce, business and industrial undertakings. Sovereign functions are such acts which are
of such a nature as cannot be performed by a private individual or association unless powers are
delegated by sovereign authority of state.
54. According to Shri Garg, the Union and the State Governments under the Constitution and as per
laws of the Factories, Environment Control, etc. are bound to exercise control on the factories in
public interest and public purpose. These functions are not sovereign func-
tions, according to Shri Garg, and the Government in this case was guilty of negligence. In support
of this, Shri Garg submitted that the offence of negligence on the part of the Govt. would be evident
from the fact that--
(a) the Government allowed the Union Carbide factory to be installed in the heart of the city;
(b) the Government allowed habitation in the front of the factory knowing that the most dangerous
and lethal gases were being used in the manufacturing processes;
(c) the gas leakage from this factory was a common affair and it was agitated continuously by the
people journalists and it was agitated in the Vidhan Sabha right from 1980 to 1984.
These features firmly proved, according to Shri Garg, the grossest negligence of the governments.
Shri Garg submitted that the gas victims had legal and moral right to sue the governments and so it
had full right to im-
plead all the necessary and proper parties like Union Carbide, UCIL, and also the then Chief
Minister Shri Arjun Singh of the State. He drew our attention to Order 2, rule 3, of the Civil
Procedure Code. In suits on joint torts, according to Shri Garg, each of the joint tort feasors is
responsible for the injury sustained for the common acts and they can all be sued together. Shri
Garg's main criticism has been that the most crucial question of corporate responsibility of the
people's right to life and their right to guard it as enshrined in Article 21 of the Constitution were
sought to be gagged by the Act. Shri Garg tried to submit that this was an enabling Act only but not
an Act which deprived the victims of their right to sue. He submitted that in this Act, there is denial
of natural justice both in the institution under section 3 and in the conduct of the suit under section
4. It must be seen that justice is done to all (R. Viswanathan v. Rukh-ul-Mulk Syed Abdul Wajid,
[1963] 3 SCR 22). It was urged that it was necessary to give a reasona- ble notice to the parties. He
referred to M. Narayanan Nambiar v. State of Kerala, [1963] Supp. 2 SCR 724.Charan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

55. Shri Shanti Bhushan appearing for Bhopal Gas Peedit Mahila Udyog Sangathan submitted that if
the Act is to be upheld, it has to be read down and construed in the manner urged by him. It was
submitted that when the Bhopal Gas disaster took place, which was the worst industrial disaster in
the world which resulted in the deaths of several thousands of people and caused serious injuries to
lakhs others, there arose a right to the victims to get not merely damages under the law of the torts
but also arose clearly, by virtue of right to life guaranteed as fundamen- tal right by Article 21 of the
Constitution a right to get full protection of life and limb. This fundamental right also, according to
Shri Shanti Bhushan, embodied within itself a right to have the claim adjudicated by the estab-
lished courts of law. It is well settled that right of access to courts in respect of violation of their
fundamen- tal rights itself is a fundamental right which cannot be denied to the people. Shri Shanti
Bhushan submitted that there may be some justification for the Act being passed. He said that the
claim against the Union Carbide are covered by the Act. The claims of the victims against the Central
Government or any other party who is also liable under tort to the victims is not covered by the Act.
The second point that Shri Shanti Bhushan made was that the Act so far as it empowered the Central
Government to represent and act in place of the victims is in respect of the civil liability arising out
of disaster and not in respect of any right in respect of criminal liability. The Central Govt.,
according to Shri Shanti Bhushan, cannot have any right or authority in relation to any offences
which arose out of the disaster and which resulted in criminal liability. It was submitted that there
cannot be any settlement or compromise in rela- tion to non-compoundable criminal cases and in
respect of compoundable criminal cases the legal right to compound these could only be possessed
by the victims alone and the Central Government could not compound those offences on their
behalf. It was submitted by Shri Shanti Bhushan that even this Court has no jurisdiction whatsoever
to transfer any criminal proceedings to itself either under any provi- sion of the Constitution or
under any provision of the Criminal Procedure Code or under any other provision of law and,
therefore, if the settlement in question was to be treated not as a compromise but as an order of the
Court, it would be without jurisdiction and liable to be declared so on the principles laid down,
according to Shri Bhushan, by this Court in Antulay's case (supra). Shri Shanti Bhushan submitted
that even if under the Act, the Central Government is considered to be able to represent the victims
and to pursue the litigation on their behalf and even to enter into compromise on their behalf, it
would be a gross violation of the constitutional rights of the victims to enter into a settlement with
the Union Carbide without giving the victims opportunities to express their views about the fairness
or adequacy of the settlement before any court could permit such a settlement to be made.
56. Mr. Shanti Bhushan submitted that the suit which may be brought by the Central Government
against Union Carbide under section 3 of the Act would be a suit of the kind contemplated by the
Explanation to Order 23, rule 3 of the Code of Civil Procedure since the victims are not parties and
yet the decree obtained in the suit would bind them. It was, therefore, urged by Shri Shanti Bhushan
that the provi- sions of Section 3(1) of the Act merely empowers the Central Government to enter
into a compromise but did not lay down the procedure which was to be followed for entering into
any compromise. Therefore, there is nothing which is inconsist- ent with the provisions of Order 23
Rule 3-B of the CPC to which the provisions Section 11 of the Act be applied. If, however, by any
stretch of argument the provisions of the Act could be construed so as to override the provisions of
Order 23 Rule 3-B CPC, it was urged, the same would render the provisions of the Act violative of
the victims' funda- mental rights and the actions would be rendered unconstitu- tional. If itCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

empowered the Central Government to compromise the victims' rights, without even having to
apply the prin- ciples of natural justice, then it would be unconstitutional and as such bad. Mr.
Shanti Bhushan, Ms. Jaising and Mr. Garg submitted that these procedures must be construed in
accordance with the provisions contained in Order 23 Rule 3-B CPC and an opportunity must be
given to those whose claims are being compromised to show to the court that the compromise is not
fair and should not accordingly be permit- ted by the court. Such a hearing in terms, according to
counsel, of Order 23 Rule 3-B CPC has to be before the compromise is entered into. It was then
submitted that section 3 of the Act only empowers the Central Government to represent and act in
place of the victims and to institute suits on behalf of the victims or even to enter into compro- mise
on behalf of the victims.
57. The Act does not create new causes of action create special courts. The jurisdiction of the civil
court to entertain suit would still arise out of section 9 of the CPC and the substantive cause of
action and the nature of the reliefs available would also continue to remain unchanged. The only
difference produced by the provisions of the Act would be that instead of the suit being filed by the
victims themselves the suit would be filed by the Central Government on their behalf.
58. Shri Shanti Bhushan then argued that the cause of action of each victim is separate and entitled
him to bring a suit for separate amount according to the damages suffered by him. He submitted
that even where the Central Government was empowered to file suits on behalf of all the victims it
could only ask for a decree of the same kind as could have been asked for by the victims themselves,
namely, a decree awarding various specified amounts to different victims whose names had to be
disclosed. According to Shri Shanti Bhushan, even if all the details were not available at the time
when the suit was filed, the details of the victims' damages had to be procured and specified in the
plaint before a proper decree could be passed in the suit. even if the subject matter of the suit had to
be compromised between the Central Government and the Union Carbide the compromise had to
indicate as to what amount would be pay- able to each victim, in addition to the total amount which
was payable by Union Carbide, submitted Shri Shanti Bhushan. It was submitted that there was
nothing in the Act which permitted the Central Government to enter into any general compromise
with Union Carbide providing for the lumpsum amount without disclosure as to how much amount
is payable to each victim.
59. If the Act in question had not been enacted, the victims would have been entitled to not only sue
Union Carbide themselves but also to enter into any compromise or settlement of their claims with
the Union Carbide immediate- ly. The provisions of the Act, according to Mr. Shanti Bhushan,
deprive the victims of their legal right and such deprivation of their rights and creation of a
corresponding right in the Central Government can be treated as reasonable only if the deprivation
of their rights imposed a corre- sponding liability on the Central Government to continue to pay
such interim relief to the victims as they might be entitled to till the time that the Central
Government is able to obtain the whole amount of compensation from the Union Carbide. He
submitted that the deprivation of the right of the victims to sue for their claims and denial of access
to justice and to assert their claims and the substi- tution of the Central Government to carry on the
litigation for or on their behalf can only be justified, if and only if the Central Government is
enjoined to provide for such interim relief or continue to provide in the words of Judge Keenan, as aCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

matter of fundamental human decency, such interim relief, necessary to enable the victims to fight
the battle. Counsel submitted that the Act must be so read. Shri Shanti Bhushan urged that if the Act
is construed in such a manner that it did not create such an obligation on the Central Government,
the Act cannot be upheld as a reasonable provision when it deprived the victims of their normal
legal rights of immediately obtaining compensation from Union Carbide. He referred to section
10(b) of the Act and clause 10 and 11(1) of the Scheme to show that the legislative policy underlying
the Bhopal Act clearly contemplated pay- ment of interim relief to the victims from time to time till
such time as the Central Government was able to recover from Union Carbide full amount of
compensation from which the interim reliefs paid by the Central Government were to be deducted
from the amount payable to them by way of final disbursal of the amounts recovered.
60. The settlement is bad, according to Shri Shanti Bhushan if part of the bargain was giving up of
the criminal liability against UCIL and UCC. Shri Shanti Bhushan submit- ted that this Court should
not hesitate to declare that the settlement is bad because the fight will go on and the victims should
be provided reliefs and interim compensation by the Central Government to be reimbursed
ultimately from the amount to be realised by the Central Government. This obligation was over and
above the liability of the Central Government as a joint tort-feasor, according to Shri Shanti
Bhushan.
61. Shri Kailash Vasdev, appearing for the petitioners in Writ Petition No. 155 1/86 submitted that
the Act dis- placed the claimants in the matter of their right to seek redressal and remedies of the
actual injury and harm caused individually to the claimants. The Act in question by re- placing the
Central Government in place of the victims. by conferment of exclusive right to sue in place of
victims, according to him, contravened the procedure established by law. The right to sue for the
wrong done to an individual was exclusive to the individual. It was submitted that under the civil
law of the country, individuals have rights to enforce their claims and any deprivation would place
them into a different category from the other litigants. The right to enter into compromise, it was
further submitted, without consultation of the victims, if that is the con- struction of section 3 read
with section 4 of the Act, then it is violative of procedure established by law. The proce- dure
substituted, if that be the construction of the Act, would be in violation of the principles of natural
justice and as such bad. It was submitted that the concept of 'parens patriae' would not be applicable
in these cases. It was submitted that traditionally, sovereigns can sue under the doctrine of 'parens
patriae' only for violations of their "quasi-sovereign" interests. Such interests do not include the
claims of individual citizens. It was submitted that the Act in question is different from the concept
of parens patriae because there was no special need to be satisfied and a class action, according to
Shri Vasdev, would have served the same purpose as a suit brought under the statute and ought to
have been preferred because it safeguarded claimants' right to procedural due process. In addition, a
suit brought under the statute would threaten the victims' substantive due process rights. It was
further submitted that in order to sustain an action, it was neces- sary for the Government of India
to have standing
62. Counsel submitted that 'parens patriae' has received no judicial recognition in this country as a
basis for recovery of money damages for injuries suffered by individu- als. He may be right to that
extent but the doctrine of parens patriae has been used in India in varying contexts andCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

contingencies.
63. We are of the opinion that the Act in question was passed in recognition of the right of the
sovereign to act as parens patriae as contended by the learned Attorney General. The Government of
India in order to effectively safeguard the rights of the victims in the matter of the conduct of the
case was entitled to act as parens patriae, which position was reinforced by the statutory provisions,
namely, the Act. We have noted the several decisions re- ferred to hereinbefore, namely,
Bhudhkaran Chankhani v. Thakur Prasad Shad, (supra); Banku Behary Mondal v. Banku Behari
Hazra, (supra); Medai Dalavoi T. Kumaraswami Mudaliar v. Medai Dalavai Rajammal, (supra) and
to the decision of this Court in Mahant Ram Saroop Dasji v. S.P. Sahi, (supra) and the decision of
the American Supreme Court in Alfred Schnapp v. Puerto Rico, (supra). It has to be borne in mind
that conceptually and jurisprudentially, the doctrine of parens patriae is not limited to
representation of some of the victims outside the territories of the country. It is true that the
doctrine has been so utilised in America so far. In our opinion, learned Attorney General was right
in contending that where citizens of a country are victims of a tragedy because of the negligence of
any multinational, a peculiar situation arises which calls for suitable effective machinery to
articulate and effectuate the grievances and demands of the victims, for which the conventional
adversary system would be totally inadequate. The State in discharge of its sovereign obligation
must come forward. The Indian state because of its constitutional commitment is obliged to take
upon itself the claims of the victims and to protect them in their hour of need. Learned Attorney
General was also right in submitting that the decisions of the Calcutta, Madras and U.S. Supreme
Court clearly indicate that parens patriae doctrine can be invoked by sovereign state within India,
even if it be contended that it has not so far been invoked inside India in respect of claims for
damages of victims suffered at the hands of the multinational. In our opinion, conceptually and
jurisprudentially, there is no bar on the State to assume responsibilities analogous to parens patriae
to discharge the State's obligations under the Constitution. What the Central Government has done
in the instant case seems to us to be an expression of its sover- eign power. This power is plenary
and inherent in every sovereign state to do all things which promote the health, peace, morals,
education and good order of the people and tend to increase the wealth and prosperity of the state.
Sovereignty is difficult to define. See in this connection, Weaver on Constitional Law, p. 490. By the
nature of things, the state sovereignty in these matters cannot be limited. It has to be adjusted to the
conditions touching the common welfare when covered by legislative enactments. This power is to
the public what the law of necessity is to the individual. It is comprehended in the maxim salus
populi suprema lex--regard for public welfare is the highest law. It is not a rule, it is an evolution.
This power has always been as broad as public welfare and as strong as the arm of the state, this can
only be measured by the legislative will of the people, subject to the fundamental rights and
constitutional limita- tions. This is an emanation of sovereignty subject to as aforesaid. Indeed, it is
the obligation of the State to assume such responsibility and protect its citizens. It has to be borne in
mind, as was stressed by the learned Attorney General, that conferment of power and the manner of
its exercise are two different matters. It was submitted that the power to conduct the suit and to
compromise, if neces- sary, was vested in the Central Government for the purpose of the Act. The
power to compromise and to conduct the proceedings are not uncanalised or arbitrary. These were
clearly exercisable only in the ultimate interests of the victims. The possibility of abuse of a statute
does not impart to it any element of invalidity. In this connection, the observations of ViscountCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

Simonds in Belfast Corporation v. O.D. Commission, [1950] AC 490 at 520-21 are relevant where it
was emphasised that validity of a measure is not be determined by its application to particular cases.
This Court in Collector of Customs, Madras v. Nathella Sampathu Chetty, [1962] 3 SCR 786 at 825
emphasised that the consti- tutional validity of the statute would have to be determined on the basis
of its provisions and on the ambit of its operation as reasonably construed. It has to be borne in
mind that if upon so judged it passes the test of reasona- bleness, then the possibility of the powers
conferred being improperly used is no ground for pronouncing the law itself invalid. See in this
connection also the observations in P.J. Irani v. State of Madras, [1962] 2 SCR 169 at 178 to 181 and
D.K. Trivedi v. State of Gujarat, [1986] Supp. SCC 20 at 60-61
64. Sections 3 and 4 of the Act should be read together as contended by the learned Attorney
General, along with other provisions of the Act and in particular sections 9 and 11 of the Act. These
should be appreciated in the context of the object sought to be achieved by the Act as indicated in
the Statement of Objects and Reasons and the Preamble to the Act. The Act was so designed that the
victims of the disaster are fully protected and the claims of compensation or damages for loss of life
or personal injuries or in' respect of other matters arising out of or connected with the disaster are
processed speedily, effectively, equitably and to the best advantage of the claimants. Section 3 of the
Act is subject to other provisions of the Act which includes sections 4 and 11. Section 4 of the Act
opens with non- obstante clause, vis-a-vis, section 3 and therefore, over- rides section 3. Learned
Attorney General submitted that the right of the Central Government under section 3 of the Act was
to represent the victims exclusively and act in the place of the victims. The Central Government, it
was urged, in other words, is substituted in the place of 'the victims and is the dominus litis. Learned
Attorney General submitted that the dominus litis carries with it the right to conduct the suit in the
best manner as it deems fit, including, the right to withdraw and right to enter into compromise.
The right to withdraw and the right to compromise conferred by section 3(2) of the Act cannot be
exercised to defeat the rights of the victims. As to how the rights should be exer- cised is guided by
the objects and the reasons contained in the Preamble, namely, to speedily and effectively process
the claims of the victims and to protect their claims. The Act was passed replacing the Ordinance at
a time when many private plaintiffs had instituted complaints/suits in the American Courts. In such
a situation, the Government of India acting in place of the victims necessarily should have right
under the statute to act in all situations including the position of withdrawing the suit or to enter
into com- promise. Learned Attorney General submitted that if the UCC were to agree to pay a lump
sum amount which would be just, fair and equitable, but insists on a condition that the proceedings
should be completely withdrawn, then necessarily there should be power under the Act to so
withdraw. Accord- ing to him, therefore, the Act engrafted a provision empow- ring the Government
to compromise. The provisions under section 3(2)(b) of the Act to enter into compromise was
consistent with the powers of dominus litis. In this connec- tion, our attention was drawn to the
definition of 'Dominus Litis' in Black's Law Dictionary, Fifth Edition, P. 437, which states as follows:
"'Dominus litis'. The master of the suit; i.e. the person who was really and directly
inter- ested in the suit as a party, as distinguished from his attorney or advocate. But
the term is also applied to one who, though not originally a party, has made himself
such, by interven- tion or otherwise, and has assumed entire control and
responsibility for one side and is treated by the Court as liable for costs. Vir- giniaCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

Electric & Power Co, v. Bowers, ISI Va., 542, 25 S.E. 2d 361,263".
65. Learned Attorney General sought to contend that the victims had not been excluded entirely
either in the conduct of proceedings or in entering into compromise, and he re- ferred to the
proceedings in detail emphasising the partici- pation of some of the victims at some stage. He drew
our attention to the fact that the victims had filed separate consolidated complaints in addition to
the complaint filed by the Government of India. Judge Keenan of the Distt. Court of America had
passed orders permitting the victims to be represented not only 'by the private Attorneys but also by
the Govt. of India. Hence, it was submitted that it could not be contended that the victims had been
excluded. Learned Attorney General further contended that pursuant to the orders passed by Judge
Keenan imposing certain conditions against the Union Carbide and allowing the motion for forum
non convenience of the UCC that the suit came back to India and was instituted before the Distt.
Court of Bhopal. In those circumstances, it was urged by the learned Attorney General that the
private plaintiffs who went to America and who were represented by the contingency lawyers fully
knew that they could also have joined in the said suit as they were before the American Court along
with the Govt. of India. It was contended that in the proceedings at any point of time or stage
including when the compromise was entered into, these private plaintiffs could have participated in
the court proceedings and could have made their representa- tion, if they so desired. Even in the
Indian suits, these private parties have been permitted to continue as parties represented by
separate counsel even though the Act empowers the Union to be the sole plaintiff. Learned Attorney
General submitted that Section 4 of the Act clearly enabled the victims to exercise their right of
participation in the proceedings. The Central Govt. was enjoined to have due regard to any matter
which such person might require to be urged. Indeed, the learned Attorney General urged very
strenuously that in the instant case, Zehreeli Gas Kand Sangharsh Morcha and Jana Swasthya
Kendra (Bhopal) had filed before the Distt. Judge, Bhopal, an application under Order I Rule 8 read
with Order I Rule 10 and Section 15 1 of the CPC for their-intervention on behalf of the victims. They
had participated in the hearing before the learned Distt. Judge, who referred to their intervention in
the order. It was further emphasised that when the UCC went up in revision to the High Court of
Madhya Pradesh at Jabalpur against the interim compensation ordered to be paid by the Distt.
Court, the intervener through its Advocate, Mr. Vibhuti Jha had participated in the proceedings. The
aforesaid Association had also intervened in the civil appeals preferred pursuant to the special leave
granted by this Court to the Union of India and Union Carbide against the judgment of the High
Court for interim compensation. In those circumstances, it was submitted that there did not exist
any other gas victim intervening in the proceedings, claiming participa- tion under Section 4. Hence,
the right to compromise provid- ed for by the Act, could not be held to be violative of the principles
of natural justice. According to the learned Attorney General, this Court first proposed the order to
counsel in court and after they agreed thereto, dictated the order on 14th February, 1989. On 15th
February, 1989 after the Memorandum of Settlement was filed pursuant to the orders of the court,
further orders were passed. The said Association, namely, Zehreeli Gas Kand Sangharsh Morcha was
present, according to the records, in the Court on both the dates and did not apparently object to the
compromise. Mr. Charanlal Sahu, one of the petitioners in the writ petition, had watched the
proceedings and after the Court had passed the order on 15th February, 1989 mentioned that he had
filed a suit for Rs. 100 crores. Learned Attorney General submit- ted that Mr. Sahu neither protested
against the settlement nor did he make any prayer to be heard. Shri Charan Lal Sahu, in the petitionCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

of opposition in one of these matters have prayed that a sum of Rs. 100 million should be paid over
to him for himself as well as on behalf of those vic- tims whom he claimed to represent. In the
aforesaid back- ground on the construction of the Section, it was urged by the learned Attorney
General that Section 3 of the Act cannot be held to be unconstitutional. The same provided a just,
fair and reasonable procedure and enabled the victims to participate in the proceedings at all
stages--those who were capable and willing to do so. Our attention was drawn to the fact that
Section 11 of the Act provides that the provisions of the Act shall have effect notwithstanding
anything inconsistent therewith contained in any other enactment other than the Act. It was,
therefore, urged that the provisions of the Civil Procedure Code stood overridden in respect of the
areas covered by the Act, namely, (a) representation, (b) powers of representation; and (c) com-
promise.
66. According to the learned Attorney General, the Act did not violate the principles of natural
justice. The provisions of the CPC could not be read into the Act for Section 11 of the Act provides
that the application of the provision of the Civil Procedure Code in so far as those were inconsistent
with the Act should be construed as over- ridden in respect of areas covered by it. Furthermore,
inasmuch as Section 4 had given a qualified right of partic- ipation to the victims, there cannot be
any question of violation of the principles of natural justice. The scope of the application of the
principles of natural justice cannot be judged by any strait jacket formula. According to him, the
extension of the principles of natural justice beyond what is provided by the Act in Sections 3 & 4,
was unwarranted and would deprive the provisions of the Statute of their efficacy in relation to the
achievement of 'speedy relief', which is the object intended to be achieved. He emphasised that the
process of notice, consultation and exchange of information, informed decision-making process, the
modali- ties of assessing a consensus of opinion would involve such time that the Govt. would be
totally unable to act in the matter efficiently, effectively and purposefully on behalf of the victims for
realisation of the just dues of the victims. He further urged that the Civil Procedure Code before its
amendment in 1976 did not have the provisions of Order l Rules 8(4), (5) & (6) and Explanations
etc. nor Order XXIII Rules 3A and 3B. Before the amendment the High Court had taken a view
against the requirement of hearing the parties represented in the suit under Order 1, Rule 8 before it
before settling or disposing of the suit. Our attention was drawn to the decision of the Calcutta High
Court in Chintaharan Ghose & Ors. v. Gujaraddi Sheik & Ors., AIR 1951 Cal. 456 at 457-459,
wherein it was held by the learned Single Judge that the plaintiff in a representative suit had right to
compromise subject to the conditions that the suit was properly filed in terms of the provisions of
that Rule and the settlement was agreed bona fide. Learned Attorney General in that context
contended that when the suit was validly instituted, the plaintiff had a right to compromise the suit
and there need not be any provision for notice to the parties represented before entering into any
compromise. Reliance was placed on the decision of the Allahabad High Court in Ram Sarup v.
Nanak Ram, AIR 1952 Allahabad 275, where it was held that a compromise entered into in a suit
filed under Order 1 Rule 8 of the CPC was binding on all persons as the plaintiffs who had instituted
the suit in representative capacity had the authority to compromise. He further submitted that most,
if not all, of the victims had given their powers of attorney which were duly filed in favour of the
Union of India. These powers or attorney have neither been impeached nor revoked or with- drawn.
By virtue of the powers of attorney the Union of India, it was stated, had the authority to file the
suits and to compromise the interests of the victims if so re- quired. The Act in question itselfCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

contemplates settlement as we have noted, and a settlement would need a common spokesman.
67. It was submitted that the Govt. of India as the statutory representative discharged its duty and is
in a centralised position of assessing the merits and demerits of any proposed course of action. So
far as the act of compro- mise, abridging or curtailing the ambit of the rights of the victims, it was
submitted that in respect of liabilities of UCC & UCIL, be it corporate, criminal or tortious, it was
open to an individual to take a decision of enforcing the liability to its logical extent or stopping
short of it and acceding to a compromise. Just as an indi- vidual can make an election in the matter
of adjudication of liability so can a statutory representative make an elec- tion. Therefore, it is
wholly wrong to contend, it was urged, that Section 3(ii)(b) is inconsistent with individu- al's right of
election and at the same time it provides the centralised decision-making processes to effectively
adjudge and secure the common good. It was only a central agency like the Govt. of India, who could
have a perspective of the totality of the claims and a vision of the problems of individual plaintiffs in
enforcing these, it was urged. It was emphasised that it has to be borne in mind that a com- promise
is a legal act. In the present case, it is a part of the conduct of the suit. It is, therefore, imperative
that the choice of compromise is made carefully, cautiously and with a measure of discretion, it was
submitted. But if any claimant wished to be associated with the conduct of the suit, he would
necessarily have been afforded an opportunity for that purpose, according to the learned Attorney
General. In this connection, reference was made to Section 4 of the Act. On the other hand, an
individual who did not partici- pate in the conduct of the suit and who is unaware of the various
intricacies of the case, could hardly be expected to meaningfully partake in the legal act of
settlement either in conducting the proceedings or entering into compromise, it was urged. In those
circumstances, the learned Attorney General submitted that the orders of 14-15th February, 1989
and the Memorandum of Settlement were justified both under the Act and the Constitution.
According to him, the terms of Settlement might be envisaged as pursuant to Section 3(ii)(b) of the
Act, which was filed according to him pursu- ant to judical direction. He sought more than once to
empha- sise, that the order was passed by the highest Court of the land in exercise of extraordinary
jurisdiction vested in it under the Constitution.
68. Our attention was drawn to several decisions for the power of this Court under Articles 136 and
142 of the Con- stitution. Looked closely at the provisions of the Act, it was contended that taking
into consideration all the factors, namely, possibilities of champerty, exploita- tion, unconscionable
agreements and the need to represent the dead and the disabled, the course of events would reveal a
methodical and systematic protection and vindication of rights to the largest possible extent. It was
observed that the rights are indispensably valuable possessions, but the rights is something which a
man can stand on, something which must be demanded or in- sisted upon without embarrassment
or shame. When rights are curtailed, permissibility of such a measure can be examined only upon
the strength, urgency and the preeminence of rights and the largest good of the largest number
sought to b,e served by curtailment. Under the circumstances which were faced by the victims of
Bhopal gas tragedy, the justi- fying basis, according to the learned Attorney General, or ground of
human rights is that every person morally ought to have something to which he or she is entitled. It
was empha- sised that the Statute aimed at it. The Act provides for assumption of rights to sue with
the aim of securing speedy, effective and equitable results to the best advantage of the claimants.
The Act and the scheme, according to the learned Attorney General, sought to translate thatCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

profession into a system of faith and possible association when in doubt. Unless such a profession is
shown to be unconscionable under the circumstances or strikes judicial conscience as a sub- version
of the objects of the Act, a declaredly fair, just and equitable exercise of a valid power would not be
open to challenge. He disputed the submission that the right to represent victims postulated as
contended mainly by the counsel on behalf of the petitioners, a pre-determination of each individual
claim as a sine qua non for proceeding with the action. Such a construction would deplete the case of
its vigour, urgency and sense of purpose, he urged. In this case, with the first of the cases having
been filed in U.S. Federal Court on December 7, 1984 a settlement would have been reached for a
much smaller sum to the detriment of the victims. Learned Attorney General emphasised that this
background has to be kept in mind while adjudging the valid- ity of the Act and the appropriateness
of the conduct of the suit in the settlement entered into.
69. He submitted that it has to be borne in mind that if the contentions of the petitioners are
entertained, the rights theoretically might be upheld but the ends of justice would stand sacrificed.
It is in those circumstances that it was emphasised that the claimant is an individual and is the best
person to speak about his injury. The knowledge in relation to his injury is relevant for the purpose
of com- pensation, whose distribution and disbursement is the sec- ondary stage. It is fallacious to
suggest that the plaint was not based upon necessary data. He insisted that the figures mentioned in
the plaint although tentative were not mentioned without examination or analysis.
70. It was further submitted by the learned Attorney General that while the Govt. of India had
proceeded against the UCC, it had to represent the victims as a class and it was not possible to
define each individual's right after careful scrutiny, nor was it necessary or possible to do so in a
mass disaster case. The settlement was a substitute for adjudication since it involved a process of
reparation and relief. The relief and reparation cannot be said to be irrelevant for the purpose of the
Act. It was stated that the alleged liability of the Govt. of India or any claim asserted against the
alleged joint tort-feasor should not be allowed to be a constraint on the Govt. of India to protect the
interests of its own citizens. Any counter-claim by UCC or any claim by a citizen against the Govt.
cannot vitiate the action of the State in the collective interest of the victims, who are the citizens.
Learned Attorney General submitted that any industrial activity, normally, has to be licensed. The
mere regulation of any activity does not carry with it legally a presumption of liability for injury
caused by the activity in the event of a mishap occurring in the course of such an activity. In any
event, the learned Attor- ney General submitted the Govt. of India enjoys sovereign immunity in
accordance with settled law. If this were not the case, the Sovereign will have to abandon all
regulatory functions including the licensing of drivers of automobiles. Hence, we have to examine
the question whether even on the assumption that there was negligence on the part of the Govt. of
India in permitting/licensing of the industry set up by the Union Carbide in Bhopal or permitting
the factory to grow up, such permission or conduct of the Union of India was responsible for the
damage which has been suffered as a result of Bhopal gas leakage. It is further to be examined
whether such conduct was in discharge of the sovereign functions of the Govt., and as such damages,
if any, result- ing therefrom are liable to be proceeded against the Govt. as a joint tort-feasor or not.
In those circumstances, it was further asserted on behalf of the Union of India that though
calculation of damages in a precise manner is a logical consequence of a suit in progress it cannot be
said to be a condition precedent for the purpose of settling the matter. Learned Attorney GeneralCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

urged that the accountabil- ity to the victims should be through the court. He urged that the
allegation that a large number of victims did not give consent to the settlement entered into, is really
of no relevance in the matter of a compromise in a mass tort action. It was highlighted that it is
possible that those who do not need urgent relief or are uninformed of the issues in the case, may
choose to deny consent and may place the flow of relief in jeopardy. Thus, consent based upon
individual subjective opinion can never be correlated to the proposal of an overall settlement in an
urgent matter. Learned Attorney General urged further that if indeed con- sent were to be insisted
upon as a mandatory requirement of a Statute, it would not necessarily lead to an accurate reflection
of the victims' opinion as opinions may be diverse. No individual would be in a position to relate
himself to a lump sum figure and would not be able to define his expectations on a global criteria. In
such cir- cumstances the value of consent is very much diminished. It was urged that if at all consent
was to be insisted it should not be an expression of the mind without supporting information and
response. To make consent meaningful it is necessary that it must be assertion of a fight to be exer-
cised in a meaningful manner based on information and com- prehension of collective welfare and
individual good. In a matter of such dimensions the insistence upon consent will lead to a process of
enquiry which might make effective consideration of any proposal impossible. For the purpose of
affording consent, it would also be necessary that each individual not only assesses the damages to
himself objec- tively and places his opinion in the realm of fair expecta- tion, but would also have to
do so in respect of others. The learned Attorney General advanced various reasons why it is difficult
now or impossible to have the concurrence of all.
71. In answer to the criticism by the petitioners, it was explained on behalf of the Union of India that
UCIL was not impleaded as a party in the suit because it would have militated against the plea of
multinational enterprise liability and the entire theory of the case in the plaint. It was highlighted
that the power to represent under the Act was exclusive, the power to compromise for the Govt. of
India is without reference to the victims, yet it is a power guided by the sole object of the welfare of
the victims. The presence and ultimately the careful imprimatur of the judi- cial process is the best
safeguard to the victims. Learned Attorney General insisted that hearing the parties after the
settlement would also not serve any purpose. He urged that it can never be ascertained with
certainty whether the victims or groups have authorised what was being allegedly spoken on their
behalf; and that the victims would be unable to judge a proposal of this nature. A method of
consensus need not be evolved like in America where every settlement made by contingency fee
lawyers who are anxious to obtain their share automatically become adversaries of the victims and
the court should therefore be satisfied. Here the Court arrived at the figure and directed the parties
to file a settlement on the basis of its order of February 14, 1985 and the interveners were heard, it
was urged. It was also urged that notice to the victims individually would have been a difficult
exercise and analysis of their response time consuming.
72. The learned Attorney General urged that neither the Central Govt. nor the State Govt. of Madhya
Pradesh is liable for the claim of the victims. He asserted that, on the facts of the present case, there
is and can be no li- ability on their part as joint tort-feasors. For the welfare of the community
several socio-economic activities will have to be permitted by the Govt. Many of these activities may
have to be regulated by licensing provisions contained in Statutes made either by Parliament or by
State Legislatures. Any injury caused to a person, to his life or liberty in the conduct of a licensedCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

authority so as to make the said licensing authority or the Govt. liable to damages would not be in
conformity with jurisprudential principle. If in such circumstances it was urged on behalf of the
Govt., the public exchequer is made liable, it will cause great public injury and may result in
drainage of the treasury. It would terrorise the welfare state from acting for development of the
people, and will affect the sovereign governmental activities which are beneficial to the community
not being adequately licensed and would thereby lead to public injury. In any event, it was urged on
behalf of the Govt., that such licensing authorities even assuming without admitting could be held to
be liable as joint tort feasors, it could be so held only on adequate allegations of negligence with full
particulars and details of the alleged act or omission of the licensing authority alleged and its direct
nexus to the injury caused to the victims. It had to be proved by cogent and adequate evidence. On
some conjecture or surmise without any foundation on facts, Govt's right to represent the victims
cannot be challenged. It was asserted that even if the Govt. is considered to be liable as a joint tort
feasor, it will be entitled to claim sovereign immunity on the law as it now stands.
73. Reference was made to the decision of this Court in Kasturilal Kalia Ram Jain v. The State of
U.P., [1965] 1 SCR 375 where the conduct of some police officers in seizing gold in exercise of their
statutory powers was held to be in discharge of the sovereign functions of the State and such
activities enjoyed sovereign immunities. The liability of the Govt. of India under the Constitution
has to be referred to Article 300, which takes us to Sections 15 & 18 of the Indian Independence Act,
1947, and Section 176(1) of the Govt. of India Act, 1935. Reference was also made to the observations
of this Court in The State of Rajasthan v. Mst. Vidhyawati, & Anr., [1962] 2 Supp. SCR 989.
74. We have noted the shareholding of UCC. The circum- stances that financial institutions held
shares in the UCIL would not disqualify the Govt. of India from acting as patens patriae and in
discharging of its statutory duties under the Act. The suit was filed only against the UCC and not
against UCIL. On the basis of the claim made by the Govt. of India, UCIL was not a necessary party.
It was suing only the multinational based on several legal grounds of liability of the UCC, inter alia.
on the basis of enterprise liability. If the Govt. of India had instituted a suit against UCIL to a certain
extent it would have weakened its case against UCC in view of the judgment of this Court in M.C.
Mehta's case (supra). Accord- ing to learned Attorney General, the Union of India in the present
case was not proceeding on the basis of lesser liability of UCC predicated in Mehta's case but on a
differ- ent jurisprudential principle to make UCC strictly and absolutely liable for the entire
damages.
75. The learned Attorney General submitted that even assuming for the purpose of argument
without conceding that any objection can be raised for the Govt. of India repre- senting the victims,
to the present situation the doctrine of necessity applied. The UCC had to be sued before the
American courts. The tragedy was treated as a national calamity, and the Govt. of India had the
right, and indeed the duty, to take care of its citizens, in the exercise of its parens patriae jurisdiction
or on principle analogous thereto. After having statutorily armed itself in recogni- tion of such
parens patraie right or on principles analogous thereto, it went to the American courts. No other
person was properly designed for representing the victims as a foreign court had to recognise a right
of representation. The Govt. of India was permitted to represent the victims before the American
courts. Private plaintiffs were also represented by their attorneys. A Committee of three attorneysCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

was formed before the case proceeded before Judge Keenan. It was high- lighted that the order of
Judge Keenan permitted the Govt. of India to represent the victims. If there was any remote conflict
of interests between the Union of India and the victims from the theoretical point of view the
doctrine of necessity would override the possible violation of the principles of natural justice--that
no man should be Judge in his own case. Reference may be made to Halsbury's Laws of England,
Vol. 1, 4th Edn., page 89, para 73, where it was pointed that that if all the members of the only
tribunal competent to determine a matter are subject to disqualifica- tion, they may be authorised
and obliged to hear that matter by virtue of the operation of the common law doctrine of necessity.
Reference was also made to De Smith's Judicial Review of Administrative Action (4th Edn. pages
276-277. See also G.A. Flick--Natural Justice, [1879] pages 138-141. Reference was also made to the
observations of this Court in J. Mohapatra & Co.
& Anr. v. State of Orissa & Anr., [1984] 4 SCC 103, where at page 112 of the report, the Court
recognised 'the principle of necessity. It was submitted that these were situations where on the
principle of doctrine of necessity a person interested was held not disqualified to adjudicate on his
rights. The present is a case where the Govt. of India only represented the victims as a party and did
not adjudicate between the victims and the UCC. It is the Court which would adjudicate the rights of
the victims. The representation of the victims by the Govt. of India cannot be held to be bad, and
there is and there was no scope of violation of any principle of natural justice. We are of the opinion
in the facts and the circumstances of the case that this contention urged by Union of India is right.
There was no scope of violation of the principle of natural justice on this score.
76. It was also urged that the doctrine of de facto representation will also apply to the facts and the
circum- stances of the present case. Reliance was placed on the decision of this Court in Gokaraju
Rangaraju etc. v. State of A.P., [1981] 3 SCR 474, where it was held that the doc- trine of de facto
representation envisages that acts per- formed within the scope of assumed official authority in the
interest of public or third persons and not for one's own benefit, are generally to be treated as
binding as if they were the acts of officers de jure. This doctrine is rounded on good sense, sound
policy and practical expediency. It is aimed at the prevention of public and private mischief and
protection of public and private interest. It avoides end- less confusion and needless chaos.
Reference was made to the observations of this Court in Pushpadevi M. Jatia v. M.L. Wadhawan,
[1987] 3 SCC 367 at 389-390 and M/s. Beopar Shayak (P) Ltd. & Ors. v. Vishwa Nath & Ors., [1987]
3 SCC 693 at 702 & 703. Apart from the aforesaid doctrine, doctrine of bona fide representation was
sought to be resorted to in the circumstances. In this connection, reference was made to Dharampal
Sing, v. Director of Small Industries Services & Ors., AIR 1980 SC 1888; N.K. Mohammad Sulaiman
v. N.C. Mohammad Ismail & Ors., [1966] 1 SCR 937 and Malkarjun Bin Shigramappa Pasara v.
Narhari Bin Shivappa & Anr., 27 IA 2
16.
77. It was further submitted that the initiation of criminal proceedings and then quashing thereof,
would not make the Act ultra vires so far as it concerned. Learned Attorney General submitted that
the Act only authorised the Govt. of India to represent the victims to enforce their claims for
damages under the Act. The Govt. as such had nothing to do with the quashing of the criminalCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

proceedings and it was not representing the victims in respect of the criminal liability of the UCC or
UCIL to the victims. He further submitted that quashing of criminal proceedings was done by the
Court in exercise of plenary powers under Articles 136 and 142 of the Constitution. In this
connection, reference was made to State of U.P. v. Poosu & Anr., [1976] 3 SCR 1005; K.M. Nanavati
v. The State of Bombay, [1961] 1 SCR 497. According to the learned Attorney General, there is also
power in the Supreme Court to suggest a settlement and give relief as in Ram Gopal v. Smt. Sarubai
& Ors., [1981] 4 SCC 505; India Mica & Micanite Industries Ltd. v. State of Bihar & Ors., [1982] 3
SCC 182.
78. Learned Attorney General urged that the Supreme Court is empowered to act even outside a
Statute and give relief in addition to what is contemplated by the latter in exercise of its plenary
power. This Court acts not only as a Court of Appeal but is also a Court of Equity. See Roshanlal
Kuthiala & Ors. v. R.B. Mohan Singh Oberoi, [1975] 2 SCR 49
1. During the course of heating of the petitions, he in- formed this Court that the Govt. of India and
the State Govt. of Madhya Pradesh refuted and denied any liability, partial or total, of any sort in the
Bhopal gas Leak disas- ter, and this position is supported by the present state of law. It was,
however, submitted that any claim against the Govt. of India for its alleged tortious liability was out-
side the purview of the Act and such claims, if any, are not extinguished by reason of the orders
dated 14th & 15th February, 1989 of this Court.
79. Learned Attorney General further stated that the amount of $ 470 million which was secured as
a result of the memorandum of settlement and the said orders of this Court would be meant
exclusively for the benefit of the victims who have suffered on account of the Bhopal gas leak disas-
ter. The Govt. of India would not seek any reimbursement on account of the expenditure incurred
suo motu for relief and rehabilitation of the Bhopal victims nor will the Govt. or its instrumentality
make any claim on its own arising from this disaster. He further assured this Court that in the event
of disbursement of compensation being initiated either under the Act or under the orders of this
Court, a notifica- tion would be instantaneously issued under Section 5(3) of the Act authorising the
Commissioner or any other officers to discharge functions and exercise all or any powers which the
Central Govt. may exercise under Section 5 to enable the victims to place before the Commissioner
or the Dy. Commis- sioner any additional evidence that they would like to be considered.
80. The Constitution Bench of this Court presided over by the learned Chief Justice has pronounced
an order on 4th May, 1989 giving reasons for the orders passed on 14th-- 15th February, 1989.
Inasmuch as good deal of criticism was advanced before this Court during the hearing of the
arguments on behalf of the petitioners about the propriety and validity of the settle- ment dated
14th-15th February, 1989 even though the same was not directly in issue before us, it is necessary to
refer briefly to what the Constitution Bench has stated in the said order dated 4th May, 1989. After
referring to the facts leading to the settlement, the Court has set out the brief reason on the
following points:
(a) How did the Court arrive at the sum of 470 million US dollars for an overall
settlement?Charan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

(b) Why did the Court consider the sum-of 470 millions US dollars as 'just, equitable
and reasonable'? (c) Why did the Court not pro-
nounce on certain important legal questions of far-reaching importance said to arise in the appeals
as to the principles of liability of monolithic, economically entrenched multina- tional companies
operating with inherently dangerous technologies in the developing countries of the third world?
These questions were said to be of great contemporary rele-
vance to the democracies of the third world.
This Court recognised that there was another aspect of the review pertaining to the part of the
settlement which terminated the criminal proceedings. The questions raised on the point in the
review-petitions, the Court was of the view, prima facie merit consideration and therefore, abstained
from saying anything which might tend to prejudge this issue one way or the other.
81. The basic consideration, the Court recorded, moti- vating the conclusion of the settlement was
the compelling need for urgent relief, and the Court set out the law's delays duly considering that
there was a compelling duty both judicial and humane, to secure immediate relief to the victims. In
doing so, the Court did not enter upon any forbidden ground, the court stated. The Court noted that
indeed efforts had already been made in this direction by Judge Keenan and the learned District
Judge of Bhopal. Even at the opening of the arguments in the appeals, the Court had suggested to
learned counsel to reach a just and fair settlement. And when counsel met for re-scheduling of the
hearings the suggestion was reiterated. The Court recorded that the response of learned counsel was
positive in at- tempting a settlement but they expressed a certain degree of uneasiness and
skepticism at the prospects of success in view of their past experience of such negotiations when, as
they stated, there had been uninformed and even irresponsi- ble criticism of the attempts at
settlement.
82. Learned Attorney General had made available to the Court the particulars of offers and
counter-offers made on previous occasions and the history of settlement. In those circumstances,
the Court examined the prima facie material as the basis of quantification of a sum which, having
regard to all the circumstances including the prospect of delays inherent in the judicial process in
India and thereafter in the matter of domestication of the decree in the U.S. for the purpose of
execution and directed that 470 million US dollars, which upon immediate payment with interest
over a reasonable period, pending actual distribution amongst the claimants, would aggregate to
nearly 500 million US dollars or its rupee equivalent of approximately Rs.750 crores which the
learned Attorney General had suggested, be made the basis of settlement, and both the parties
accepted this direction.
83. The Court reiterated that the settlement proposals were considered on the premise that the
Govt. had the exclu- sive statutory authority to represent and act on behalf of the victims and neither
counsel had any reservation on this. The order was also made on the premise that the Act was a
valid law. The Court declared that in the event the Act is declared void in the pending proceedings
challenging its validity, the order dated 14th February, 1989 would require to be examined in theCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

light of that decision. The Court also reiterated that if any material was placed before it from which a
reasonable inference was possible that the UCC had, at any time earlier, offered to pay any sum
higher than an outright down payment of US 470 million dollars, this Court would straightaway
initiate suo motu action requiring the concerned parties to show cause why the order dated 14th
February'89 should not be set aside and the parties relegat- ed to their original positions. The Court
reiterated that the reasonableness of the sum was based not only on inde- pendent quantification
but the idea of reasonableness for the present purpose was necessarily a broad and general estimate
in the context of a settlement of the dispute and not on the basis of an accurate assessment by
adjudication. The Court stated that the question was, how good or reasona- ble it was as a
settlement, which would avoid delay, uncer- tainties and assure immediate payment. An estimate in
the very nature of things, would not have the accuracy of an adjudication. The Court recorded the
offers, counter-offers, reasons and the numbers of the persons treated and the claims already made.
The Court found that from the order of the High Court and the admitted position on the plaintiff's
side, a reasonable prima facie estimate of the number of fatal cases and serious personal injury
cases, was possible to be made. The Court referred to the High Court's assessment and procedure to
examine the task of assessing the quantum of interim compensation. The Court referred to M. C
Mehta's case reiterated by the High Court, bearing in mind the factors that if the suit proceeded to
trial the plaintiff-Union of India would obtain judgment in respect of the claims relating to deaths
and personal injuries in the following manner:-
(a) Rs.2 lakhs in each case of death; (b) Rs.2 lakh in each case of total permanent
disability; (c) Rs. 1 lakh in each case of permanent partial disablement; and (d)
Rs.50,000 in each case of temporary partial disablement.
84. Half of these amounts were awarded as interim com- pensation by the High Court.
85. The figures adopted by the High Court in regard to the number of fatal cases and cases of serious
personal injuries did not appear to have been disputed by anybody before the High Court, this Court
observed. From those figures, it came to the conclusion that the total number of fatal cases was
about 3,000 and of grievous and serious personal injuries, as verifiable from the records was
30,000. This Court also took into consideration that about 8 months after the occurrence a survey
had been conducted for the purpose of identification of cases. These figures indi- cated less than
10,000. In those circumstances, as a rough and ready estimate, this Court took into consideration
the prima facie findings of the High Court and estimated the number of fatal cases of 3,000 where
compensation could range from Rs. 1 lakh to Rs.3 lakhs. This would account for Rs.70 crores, nearly
3 times higher than what would have otherwise been awarded in comparable cases in motor vehicles
accident claims.
86. The Court recognised the effect of death and reiter- ated that loss of precious human lives is
irreparable. The law can only hope to compensate the estate of a person whose life was lost by the
wrongful act of another only in the way the law was equipped to compensate i.e. by monetary
compen- sation calculated on certain well-recognised principles.Charan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

"Loss to the estate" which is the entitlement of the estate and the 'loss of dependency'
estimated on the basis of capitalised present value awardable to the heirs and
depend- ants, this Court considered, were the main components in the computation
of compensation in fatal accident actions, but the High Court adopted a higher basis.
The Court also took into account the personal injury cases, and stated that these
apportionments were merely broad considerations gener- ally guiding the idea of
reasonableness of the overall basis of settlement, and reiterated that this exercise was
not a pre-determination of the quantum of compensation amongst the claimants
either individually or catagory-wise, and that the determination of the actual
quantum of compensation payable to the claimants has to be done by the authorities
under the Act. These were the broad assessments and on that basis the Court made
the assessment. The Court believed that this was a just and reasonable assessment
based on the materials available at that time. So far as the other question, name- ly,
the vital juristic principles of great contemporary relevance to the Third World
generally, and to India in particular, touching problems emerging from the pursuit of
such dangerous technologies for economic gains by multi- nationals in this case, the
Court recognised that these were great problems and reiterated that there was need
to evolve a national policy to protect national interests from such ultra-hazardous
pursuits of economic gain; and that Jurists, technologists and other experts in
economics. environmen- tology, futurology, sociology and public health should
identify the areas of common concern and help in evolving proper criteria which
might receive judicial recognition and legal sanction. The Court reiterated that some
of these problems were referred to in M.C. Mehta's case (supra). But in the present
case, the compulsions of the need for immedi- ate relief to tens of thousands of
suffering victims could not wait till these questions vital though these be, were
resolved in due course of judicial proceedings; and the tremendous suffering of
thousands of persons compelled this Court to move into the direction of immediate
relief which, this Court thought, should not be subordinated to the uncer- tain
promises of the law, and when the assessment of fair- ness of the amount was based
on certain factors and assump- tions not disputed even by the plaintiffs.
87. Before considering the question of constitutional validity of the Act, in the light of the
background of the facts and circumstances of this case and submissions made, it is necessary to
refer to the order dated 3rd March, 1989 passed by the Constitution Bench in respect of writ peti-
tions Nos. 164/86 and 268/89, consisting of 5 learned Judges presided over by the Hon'ble the
Chief Justice of India. The order stated that these matters would be listed on 8th March, 1989 before
a Constitution Bench for decision "on the sole question whether the Bhopal Gas Leak Disaster
(Process- ing of Claims) Act, 1985 is ultra vires". This is a judicial order passed by the said
Constitution Bench. This is not an administrative order. Thus, these matters are before this Court.
The question, therefore, arises; what are these matters? The aforesaid order specifically states that
these matters were placed before this Bench on the "sole question"
whether the Act is ulta vires.Charan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

Hence, these matters are not before this Bench for disposal of these writ petitions. If
as a result of the determina- tion, one way or the other, it is held, good and bad, and
that some relief becomes necessary, the same cannot be given or an order cannot be
passed in respect thereof, except declaring the Act or any portion of the Act, valid or
in- valid constitutionally as the decision might be.
88. In writ petition No. 268/89 there is consequential prayer to set aside the order dated 14/15th
February, 1989. But since the order dated 3rd March, 1989 above only sug- gests that these matters
have been placed before this Bench 'on the sole question' whether the Bhopal Act is ultra vires or
not, it is not possible by virtue of that order to go into the question whether the settlement is valid or
liable to be set aside as prayed for in the prayers in these appli- cations.
89. The provisions of the Act have been noted and the rival contentions of the parties have been set
out before. It is, however, necessary to reiterate that the Act does not in any way circumscribe the
liability of the UCC, UCIL or even the Govt. of India or Govt. of Madhya Pradesh if they are jointly or
severally liable. This follows from the construction of the Act, from the language that is apparent.
The context and background do not indicate to the contrary. Counsel for the victims plead that that
is so. The learned Attorney General accepts that position. The liability of the Government is,
however, disputed. This Act also does not deal with any question of criminal liability of any of the
parties concerned. On an appropriate reading of the relevant provisions of the Act, it is apparent
that the criminal liability arising out of Bhopal gas leak disaster is not the subject-matter of this Act
and cannot be said to have been in any way affected, abridged or modified by virtue of this Act. This
was the contention of learned counsel on behalf of the victims. It is also the contention of the
learned Attor- ney General. In our opinion, it is the correct analysis and consequence of the relevant
provisions of the Act. Hence, the submissions made on behalf of some of the victims that the Act was
bad as it abridged or took away the victims' right to proceed criminally against the delinquent, be it
UCC or UCIL or jointly or severally the Govt. of India, Govt. of Madhya Pradesh or Mr. Arjun Singh,
the erstwhile Chief Minister of Madhya Pradesh, is on a wrong basis. There is no curtailment of any
right with respect to any criminal liability. Criminal liability is not the subject-matter of the Act. By
the terms of the Act and also on the concessions made by the learned Attorney General, if that be so,
then can non-prosecution in criminal liability be a consideration or valid consideration for
settlement of claims under the Act?
This is a question which has been suggested and articulated by learned counsel appearing for the
victims. On the other hand, it has been asserted by the learned Attorney General that that part of the
order dated 14/15th February, 1989 dealing with criminal prosecution or the order of this Court was
by virtue of the inherent power of this Court under Articles 136 & 142 of the Constitution. These, the
learned Attorney General said, were in the exercise of plenary powers of this Court. These are not
considerations which induced the parties to enter into settlement. For the pur- pose of
determination of constitutional validity of the Act, it is however necessary to say that criminal
liability of any of the delinquents or of the parties is not the subject-matter of this Act and the Act
does not deal with either claims or rights arising out of such criminal liabil- ity. This aspect is
necessary to be reiterated on the ques- tion of validity of the Act.Charan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

90. We have set out the language and the purpose of the Act, and also noted the meaning of the
expression 'claim' and find that the Act was to secure the claims connected with or arising out of the
disaster so that these claims might be dealt with speedily, affectively, equitably and to the best
advantage of the claimants. In our opinion, Clause
(b) of Section 2 includes all claims of the victims arising out of and connected with the disaster for
compensation and damages or loss of life or personal injury or loss to the business and flora and
fauna. What, however, is the extent of liability, is another question. This Act does not purport to or
even to deal with the extent of liability arising out of the said gas leak disaster. Hence, it would be
improper or incorrect to contend as did Ms. Jaising, Mr Garg and other learned counsel appearing
for the victims, that the Act circumscribed the liability--criminal, punitive or absolute of the parties
in respect of the leakage. The Act provides for a method or procedure for the establishment and
enforcement of that liability. Good deal of argument was advanced before this Court on the question
that the settle- ment has abridged the liability and this Court has lost the chance of laying down the
extent of liability arising out of disaster like the Bhopal Gas Leak disaster. Submissions were made
that we should lay down clearly the extent of liability arising out of these types of disasters and we
should fur- ther hold that the Act abridged such liability and as such curtailed the rights of the
victims and was bad on that score. As mentioned hereinbefore, this is an argument under a
misconception. The Act does not in any way except to the extent indicated in the relevant provisions
of the Act circumscribe or abridge the extent of the rights of the victims so far as the liability of the
delinquents are concerned. Whatever are the rights of the victims and what- ever claims arise out of
the gas leak disaster for compensation, personal injury, loss of life and property, suffered or likely to
be sustained or expenses to be incurred or any other loss are covered by the Act and the Central
Govt. by operation of Section 3 of the Act has been given the exclusive right to represent the victims
in their place and stead. By the Act, the extent of liability is not in any way abridged and, therefore, if
in case of any industrial disaster like the Bhopal Gas Leak disaster, there is right in victims to
recover damages or compensation on the basis of absolute liability, then the same is not in any
manner abridged or curtailed.
91. Over 120 years ago Rylands v. Fletcher, [1868] Vol. 3 LR E & I Appeal Cases 330 was decided in
England. There A, was the lessee of certain mines. B, was the owner of a mill standing on land
adjoining that under which the mines were worked. B, desired to construct a reservoir, and
employed competent persons, such as engineers and a contractor, to construct it. A, had worked his
mines up to a spot where there were certain old passages of disused mines; these passages were
connected with vertical shafts which communi- cated with the land above, and which had also been
out of use for years, and were apparently filled with marl and the earth of the surrounding land. No
care had been taken by the engineer or the contractor to block up these crafts, and shortly after
water had been introduced into the reservoir it broke through some of the shafts, flowed through the
old passage and flooded As mine. It was held by the House of Lords in England that where the
owner of land, without wilfulness or negligence, uses his land in the ordinary manner of its use,
though mischief should thereby be occa- sioned to his neighbour, he will not be liable in damages.
But if he brings upon his land any thing which would not naturally come upon it, and which is in
itself dangerous, and may become mischievous if not kept under proper control, though in so doing
he may act without personal wilfulness or negligence, he will be liable in' damages for any mischiefCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

thereby occasioned. In the background of the facts it was held that A was entitled to recover
damages from B, in respect of the injury. The question of liability was high- lighted by this Court in
M.C. Mehta's case (supra) where a Constitution Bench of this Court had to deal with the rule of strict
liability. This Court held that the rule in Ry- lands v. Fletcher, (supra) laid down a principle that if a
person who brings on his land and collects and keep there anything likely to do harm and such thing
escapes and does damage to another, he is liable to compensate for the damage caused. This rule
applies only to nonnatural user of the land and does not apply to things naturally on the land or
where the escape is due to an act of God and an act of a stranger or the default of the person injured
or where the things which escape are present by the consent of the person injured or in certain cases
where there is a statutory authority. There, this Court observed that the rule in Rylands v. Fletcher,
(supra) evolved in the 19th century at a time when all the developments of science and technology
had not taken place, and the same cannot afford any guidance in evolving any standard of liability
consistent with the constitutional norms and the needs of the present day economy and social
structure. In a modern industrial society with highly de- veloped scientific knowledge and
technology where hazardous or inherently dangerous industries are necessary to be carried on as
part of the developmental process, Courts should not feel inhibited by this rule merely because the
new law does not recognise the rule of strict and absolute liability in case of an enterprise engaged in
hazardous and dangerous activity. This Court noted that law has to grow in order to satisfy the
needs of the fast changing society and keep abreast with the economic developments taking place in
the country. Law cannot afford to remain static. This Court reiterated there that if it is found
necessary to construct a new principle of liability to deal with an unusual situa- tion which has
arisen and which is likely to arise in future on account of hazardous or inherently dangerous
industries which are concomitant to an industrial economy, the Court should not hesitate to evolve
such principle of liability merely because it has not been so done in England. According to this
Court, an enterprise which is engaged in a hazardous or inherently dangerous industry which poses
potential threat to the health and safety of the persons working in the factory and residing in the
surrounding areas owes an absolute and non-delegable duty to the community to ensure that no
harm results to anyone. The enterprise must be held to be under an obligation to provide that the
hazardous or inherently dangerous activity in which it is engaged must be conducted with the
highest standards of safety and if any harm results to anyone on account of an accident in the
operation of such activity resulting, for instance, in escape of toxic gas the enterprise is strictly and
absolute- ly liable to compensate all those who were affected by the accident as part of the social cost
for carrying on such activity, regardless of whether it is carried on carefully or not. Such liability is
not subject to any of the excep- tions which operate vis-a-vis the tortious principle of strict liability
under the rule in Rylands v. Fletcher. If the enterprise is permitted to carry on a hazardous or
dangerous activity for its profit, the law must presume that such permission is conditional on the
enterprise absorbing the cost of any accident arising on account of such activity as an appropriate
item of its overheads. The enterprise alone has the resources to discover and guard against haz- ards
or dangers and 'to provide warning against potential hazards.
This Court reiterated that the measure of compensation in these kinds of cases must be correlated to
the magnitude and capacity of the enterprise because such compensation must have a deterrent
effect. The larger and more prosperous the enterprise, the greater must be the amount of
compensation payable by it for the harm caused on account of an accident in the carrying on of theCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

hazardous or inherently dangerous activity by the enterprise. The determination of actual damages
payable would depend upon various facts and circum- stances of the particular case.
92. It was urged before us that there was an absolute and strict liability for an enterprise which was
carrying on dangerous operations with gases in this country. It was further submitted that there was
evidence on record that sufficient care and attention had not been given to safe- guard against the
dangers of leakage and protection in case of leakage. Indeed, the criminal prosecution that was
launched against the Chairman of Union Carbide Shri Warren Anderson and others, as indicated
before, charged them along with the defendants in the suit with delinquency in these matters and
criminal negligence in conducting the toxic gas operations in Bhopal. As in the instant adjudication,
this Court is not concerned with the determination of the actual extent of liability, we will proceed
on the basis that the law enunciated by this Court in M.C. Mehta's case (supra) is the decision upon
the basis of which damages will be payable to the victims in this case. But then the practical question
arises: what is the extent of actual damages payable, and how would the quantum of damages be
computed? Indeed, in this connection, it may be appropriate to refer to the order passed by this
Court on 3rd May, 1989 giving reasons why the settlement was arrived at at the figure indicated.
This Court had reiterated that it had proceeded on certain prima facie undisputed figures of death
and substantially compen- sating personal injury. This Court has referred to the fact that the High
Court had proceeded on the broader principle in M.C. Mehta's case (supra) and on the basis of the
capaci- ty of the enterprise because the compensation must have deterrent effect. On that basis the
High Court had proceeded to estimate the damages on the basis of Rs.2 lakhs for each case of death
and of total permanent disability, Rs. 1 lakh for each case of partial permanent disability and
Rs.50,000 for each case or' temporary partial disability. In this connection, the controversy as to
what would have been the damages if the action had proceeded, is another matter. Normally, in
measuring civil liability, the law has attached more importance to the principle of compensation
than that of punishment. Penal redress, however, involve both compen- sation to the person injured
and punish-
ment as deference. These problems were highlighted by the House of Lords in England in Rookes v.
Barnard, [1964]AC 1129, which indicate the difference between aggravated and exemplary damages.
Salmond on the Law of Torts, 15th Edition at p. 30 emphasises that the function of damages is
compen- sation rather than punishment, but punishment cannot always be ignored. There are views
which are against exemplary damages on the ground that these infringe in principle the object of law
of torts, namely, compensation and not punish- ment and these tend to impose something
equivalent to fine in criminal law without the safeguards provided by the criminal law. In Rookes v.
Barnard (supra), the House of Lords in England recognised three classes of cases in which the award
of exemplary damages was considered to be justi- fiable. Awards must not only, it is said,
compensate the parties but also deter the wrong doers and others from similar conduct in future.
The question of awarding exem- plary or deterrent damages is said to have often confused civil and
criminal functions of law. Though it is considered by many that it is a legitimate. encroachment of
punishment in the realm of civil liability, as it operates as a re- straint on the transgression of law
which is for the ulti- mate benefit of the society. Perhaps, in this case, had the action proceeded, one
would have realised that the fall out of this gas disaster might have been formulation of a con- cept
of damages, blending both civil and criminal liabili- ties. There are, however, serious difficulties inCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

evolving such an actual concept of punitive damages in respect of a civil action which can be
integrated and enforced by the judicial process. It would have raised serious problems of pleading,
proof and discovery, and interesting and challeng- ing as the task might have been, it is still very
uncertain how far decision based on such a concept would have been a decision according to 'due
process' of law acceptable by international standards. There were difficulties in that attempt. But as
the provisions stand these considerations do not make the Act constitutionally invalid. These are
matters on the validity of settlement. The Act, as such does not abridges or curtail damages or
liability whatever that might be. So the challenge to the Act on the ground that there has been
curtailment or deprivation of the rights of the victims which is unreasonable in the situation is
unwarranted and cannot be sustained.
93. Mr. Garg tried to canvass before us the expanding of horizons of human rights. He contended
that the conduct of the multinational corporations dealing with dangerous gases for the purpose of
development specially in the conditions prevailing under the Third world countries requires closer
scrutiny and vigilance on the part of emerging nations. He submitted that unless courts are alert and
active in preserving the rights of the individuals and in enforcing criminal and strict liability and in
setting up norms com- pelling the Govt. to be more vigilant and enforcing the sovereign will of the
people of India to oversee that such criminal activities which endanger even for the sake of
developmental work, economy and progress of the country, the health and happiness of the people
and damage the future prospects of health, growth and affect and pollute the environment, should
be curbed and, according to him, these could only be curbed by insisting through the legal adjudi-
cation, punitive and deterrent punishment in the form of damages. He also pleaded that norms
should be set up indi- cating how these kinds of dangerous operations are to be permitted under
conditions of vigilance and survillence. While we appreciate the force of these arguments, and en-
dorse his plea that norms and deterrence should be aspired for, it is difficult to correlate that aspect
with the present problem in this decision.
94. We do reiterate, as mentioned in the Universal Declaration of Human Rights that people are
born free and the dignity of the persons must be recognised and an effec- tive remedy by competent
tribunal is one of the surest method of effective remedy. If, therefore, as a result of this tragedy new
consciousness and awareness on the part of the people of this country to be more vigilant about
meas- ures and the necessity of ensuring more strict vigilance for permitting the operations of such
dangerous and poisonous gases dawn, then perhaps the tragic experience of Bhopal would not go in
vain.
95. The main question, however, canvassed by all learned counsel for the victims was that so far as
the Act takes away the right of the victims to fight or establish their own rights, it is a denial of
access to justice, and it was contended that such denial is so great a deprivation of both human
dignity and right to equality that it cannot be justi- fied because it would be affecting right to life,
which again cannot be deprived without a procedure established by law which is just, fair and
reasonable.
96. On this aspect, Shri Shanti Bhushan tried to urge before us that sections 3 & 4 of the Act. in so
far as these enjoin and empower the Central Govt. to institute or prose- cute proceedings was onlyCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

an enabling provision for the Central Govt. and not depriving or disabling provisions for the victim.
Ms. Jaising sought to urge in addition, that in order to make the provisions constitutionally valid, we
should eliminate the concept of exclusiveness to the Central Govt. and give the victims right to sue
along with the Central Govt. We are unable to accept these submissions.
97. In our opinion, Sections 3 & 4 are categorical and clear. When the expression is explicit, the
expression is conclusive, alike in what it says and in what it does not say. These give to the Central
Government an exclusive right to act in place of the persons who are entitled to make claim or have
already made claim. The expression 'exclusive' is explicit and significant. The exclusivily cannot be
whittled down or watered down as suggested by counsel. The said expression must be given its full
meaning and extent. This is corroborated by the use of the expression 'claim' for all purposes. If such
duality of rights are given to the Central Govt. along with the victims in instituting or proceeding for
the realisation or the enforcement of the claims arising out of Bhopal gas leak disaster, then that
would be so cumbersome that it would not be speedy, effec- tive or equitable and would not be the
best or more advanta- geous procedure for securing the claims arising out of the leakage. In that
view of the matter and in view of the language used and the purpose intended to be achieved, we are
unable to accept this aspect of the arguments advanced on behalf of the victims. It was then
contended that by the procedure envisaged by the Act, the victims have been de- prived and
denied.their rights and property to fight for compensation. The victims, it has been asserted, have
been denied access to justice. It is a great deprivation, it was urged. It was contended that the
procedure evolved under the Act for the victims is peculiar and having good deal of disadvantages
for the victims. Such special disadvantageous procedure and treatment is unequal treatment, it was
sug- gested. It was, therefore, violative of Article 14 of the Constitution, that is the argument
advanced.
98. The Act does provide a special procedure in respect of the rights of the victims and to that extent
the Central Government takes upon itself the rights of the victims. It is a special Act providing a
special procedure for a kind of special class of victims. In view of the enormity of the disaster the
victims of the Bhopal gas leak disaster, as they were placed against the multinational and a big
Indian corporation and in view of the presence of foreign contin- gency lawyers to whom the victims
were exposed, the claim- ants and victims can legitimately be described as a class by themselves
different and distinct, sufficiently separate and indentifiable to be entitled to special treatment for
effec- tive, speedy, equitable and best advantageous settlement of their claims. There indubitably is
differentiation. But this differentiation is based on a principle which has rational nexus with the aim
intended to be achieved by this differen- tiation. The disaster being unique in its character and in
the recorded history of industrial disasters situated as the victims were against a mighty
multinational with the presence of foreign contingency lawyers. looming on the scene, in our
opinion, there were sufficient grounds for such differentiation and different treatment. In treating
the victims of the gas leak disaster differently and provid- ing them a procedure, which was just, fair,
reasonable and which was not unwarranted or unauthorised by the Constitu- tion, Article 14 is not
breached. We are, therefore, unable to accept this criticism of the. Act.
99. The second aspect canvassed on behalf of the victims is that the procedure envisaged is
unreasonable and as such not warranted by the situation and cannot be treated as a procedureCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

which is just, fair and reasonable. The argument has to be judged by the yardstick, as mentioned
hereinbe- fore, enunciated by this Court in State of Madras v. V.G. Rao, (supra). Hence, both the
restrictions or limitations on the substantive and procedural rights in the impugned legis- lation will
have to be judged from the point of view of the particular Statute in question. No abstract rule or
standard of reasonableness can be applied. That question has to be judged having regard to the
nature of the rights alleged to have been infringed in this case, the extent and urgency of the evil
sought to be remedied, disproportionate imposition, prevailing conditions at the time, all these facts
will have to be taken into consideration. Having considered the back- ground, the plight of the
impoverished, the urgency of the victims' need, the presence of the foreign contingency lawyers, the
procedure of settlement in USA in mass action, the strength for the foreign multinationals, the
nature of injuries and damages, and the limited but significant right of participation of the victims
as contemplated by s.4 of the Act, the Act cannot be condemned as unreasonable.
100. In this connection, the concept of 'parens patriae' in jurisprudence may be examined. It was
contended by the learned Attorney General that the State had taken upon itself this onus to
effectively come in as parens patriae, we have noted the long line of Indian decisions where, though
in different contexts, the concept of State as the parent of people who are not quite able to or
competent to fight for their rights or assert their rights, have been utilised. It was contended that the
doctrine of parens patriae cannot be applicable to the victims. How the concept has been understood
in this country as well as in America has been noted. Legal dictionaries have been referred to as
noted before. It was asserted on behalf of the victims by learned counsel that the concept of 'parens
patriae' can never be invoked for the purpose of suits in domestic juris- diction of any country. This
can only be applied in respect of the claims out of the country in foreign jurisdiction. It was further
contended that this concept of 'parens patraie' can only be applied in case of persons who are under
disability and would not be applicable in respect of those who are able to assert their own rights. It is
true that victims or their representatives are sui generis and cannot as such due to age, mental
capac- ity or other reason not legally incapable for suing or pursuing the remedies for the rights yet
they are at a tremendous disadvantage in the broader and comprehensive sense of the term. These
victims cannot be considered to be any match to the multinational companies or the Govt. with
whom in the conditions that the victims or their representa- tives were after the disaster physically,
mentally, finan- cially, economically and also because of the position of litigation would have to
contend. In such a situation of predicament the victims can legitimately be considered to be
disabled. They were in no position by themselves to look after their own interests effectively or
purposefully. In that background, they are people who needed the State's protection and should
come within the umbrella of State's sovereignty to assert, establish and maintain their rights against
the wrong doers in this mass disaster. In that perspective, it is jurisprudentially possible to apply the
principle of parens patriae doctrine to the victims. But quite apart from that, it has to be borne in
mind that in this case the State is acting on the basis of the Statute itself. For the authority of the
Central Govt. to sue for and on behalf of or instead in place of the victims, no other theory, concept
or any jurisprudential principle is required than the Act itself. The Act empowers and substi- tutes
the Central Govt. It displaces the victims by opera- tion of Section 3 of the Act and substitutes the
Central Govt. in its place. The victims have been divested of their rights to sue and such claims and
such rights have been vested in the Central Govt. The victims have been divested because the victims
were disabled. The disablement of the victims vis-a-vis their adversaries in this matter is aCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

self-evident factor. If that is the position then, in our opinion, even if the strict application of the
'parens patriae' doctrine is not in order, as a concept it is a guide. The jurisdiction of the State's
power cannot be circumscribed by the limitations of the traditional concept of parens patriae.
Jurisprudentially, it could be utilised to suit or alter or adapt itself in the changed circum- stances.
In the situation in which the victims were, the State had to assume the role of a parent protecting the
rights of the victims who must come within the protective umbrella of the State and the common
sovereignty of the Indian people. As we have noted the Act is an exercise of the sovereign power of
the State. It is an appropriate evolution of the expression of sovereignty in the situation that had
arisen. We must recognize and accept it as such.
101. But this right and obligation of the State has another aspect. Shri Shanti Bhushan has argued
and this argument has also been adopted by other learned counsel appearing for the victims that
with the assumption by the State of the jurisdiction and power as a parent to fight for the victims in
the situation there is an imcumbent obliga- tion on the State, in the words of Judge Keenan, 'as a
matter of fundamental human decency' to maintain the victims until the claims are established and
realised from the foreign multinationals. The major inarticulate premise apparent from the Act and
the scheme and the spirit of the Act is that so long as the rights of the victims are prose- cuted the
State must protect and preserve the victims. Otherwise the object of the Act would be defeated, its
purpose frustrated. Therefore, continuance of the payments of the interim maintenance for the
continued sustenance of the victims is an obligation arising out of State's assump- tion of the power
and temporary deprivation of the rights of the victims and divestiture of the rights of the victims to
fight for their own rights. This is the only reasonable interpretation which is just, fair and proper.
Indeed, in the language of the Act there is support for this interpre- tation. Section 9 of the Act gives
power to the Central Govt. to frame by notification, a scheme for carrying into effect the purposes of
the Act. Sub-section (2) of Section 9 provides for the matters for which the scheme may provide.
Amongst others, clause (d) of Section 9(2) provides for creation of a fund for meeting expenses in
connection with the administration of the Scheme and of the provisions of the Act; and clause (e) of
Section 9(2) covers the amounts which the Central Govt. "may after due appropriation made by
Parliament by law in that behalf, credit to the fund re- ferred to in clause (d) and any other amounts
which may be credited to such fund". Clause (f) of Section 9(2) speaks of the utilisation, by way of
disbursal (including apportion- ment) or otherwise, of any amounts received in satisfaction of the
claims. These provisions are suggestive but not explicit. Clause (b) of Section 10 which provides that
in disbursing under the scheme the amount received by way of compensation or damages in
satisfaction of a claim as a result of the adjudication or settlement of the claim by a court or other
authority, deduction shall be made from such amount of the sums, if any, paid to the claimant by the
Govt. before the disbursal of such amount. The Scheme framed is also significant. Clause 10 of the
Scheme provides for the claims and relief funds and includes disbursal of amounts as relief
including interim relief to persons af- fected by the Bhopal gas leak disaster and Clause 11(1)
stipulates that disbursal of any amounts under the scheme shall be made by the Deputy
Commissioner to each claimant through credit in a bank or postal saving account, stressing that the
legislative policy underlined the Bhopal Act contemplated payment of interim relief till such time as
the' Central Govt. was able to recover from the Union Carbide full amount of compensation from
which the interim reliefs already paid were to be deducted from the amount payable to them for the
final disbursal. The Act should be construed as creating an obligation oh the Central Govt. to payCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

interim relief as the Act deprives the victims of normal and immediate right of obtaining
compensation from the Union Carbide. Had the Act not been enacted, the victims could have and
perhaps would have been entitled not only to sue the Union Carbide themselves, but also to enter
into settlement or compromise of some sort with them. The provi- sions of the Act deprived the
victims of that legal right and opportunity, and that deprivation is substantial depri- vation because
upon immediate relief depends often the survival of these victims. In that background, it is just and
proper that this deprivation is only to be justified if the Act is read with the obligation of granting
interim relief or maintenance by the Central Government until the full amount of the dues of the
victims is realised from the Union Carbide after adjudication or settlement and then deducting
therefrom the interim relief paid to the victims. As submitted by learned Attorney General, it is true
that there is no actual expression used in the Act itself which expressly postulates or indicates such a
duty or obligation under the Act. Such an obligation is, however, inherent and must be the basis of
properly construing the spirit of the Act. In our opinion, this is the true basis and will be in
consonance with the spirit of the Act. It must be, to use the well-known phrase 'the major
inarticulate premise' upon which though not expressly stated, the Act proceeds. It is on this promise
or premise that the State would be justified in taking upon itself the right and obligation to proceed
and prosecute the claim and deny access to the courts of law to the victims on their own. If it is only
so read, it can only be held to be constitutionally valid. It has to be borne in mind that the language
of the Act does not militate against this construction but on the contrary, Sections 9, 10 and the
scheme of the Act suggest that the Act contains such an obligation. If it is so read, then only meat
can be put into the skeleton of the Act making it meaningful and purposeful. The Act must,
therefore, be so read. This ap- proach to the interpretation of the Act can legitimately be called the
'constructive intuition' which, in our opinion, is a permissible mode of viewing the Acts of
Parliament. The freedom to search for 'the spirit of the Act' or the quanti- ty of the mischief at which
it is aimed (both synonymous for the intention of the parliament) opens up the possibility of liberal
interpretation "that delicate and important branch of judicial power, the concession of which is
dangerous, the denial ruinous". Given this freedom it is a rare opportunity though never to be
misused and challenge for the Judges to adopt and give meaning to the Act, articulate and
inarticulate, and thus translate the intention of the Par- liament and fulfil the object of the Act. After
all, the Act was passed to give relief to the victims who, it was thought, were unable to establish their
own rights and fight for themselves. it is common knowledge that the victims were poor and
impoverished. How could they survive the long ordeal of litigation and ultimate execution of the
decree or the orders unless provisions be made for their sustenance and maintenance, especially
when they have been deprived of the fight to fight for these claims themselves? We, there- fore, read
the Act accordingly.
102. It was, then, contended that the Central Govt. was not competent to represent the victims. This
argument has been canvassed on various grounds. It has been urged that the Central Govt. owns
22% share in UCIL and as such there is a conflict of interest between the Central Govt. and the
victims, and on that ground the former is disentitled to represent the latter in their battle against
UCC and UCIL. A large number of authorities on this aspect were cited. However, it is not necessary
in the view we have taken to deal with these because factually the Central Govt. does not own any
share in UCIL. These are the statutory independent organisations, namely, Unit Trust of India and
Life Insur- ance Corporation, who own 20 to 22% share in UCIL. The Govt. has certain amount ofCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

say and control in LIC and UTI. Hence, it cannot be said, in our opinion, that there is any con- flict
of interest in the real sense of the matter in respect of the claims of Bhopal gas leak disaster between
the Cen- tral Govt. and the victims. Secondly, in a situation of this nature, the Central Govt. is the
only authority which can pursue and effectively represent the victims. There is no other organisation
or Unit which can effectively represent the victims. Perhaps, theoretically, it might have been
possible to constitute another independent statutory body by the Govt. under its control and
supervision in whom the claim of the victims might have been vested and substituted and that Body
could have been entrusted with the task of agitating or establishing the same claims in the same
manner as the Central Govt. has done under the Act. But the fact that that has not been done, in our
opinion, does not in any way affect the position. Apart from that, lastly, in our opinion, this concept
that where there is a conflict of interest, the person having the conflict should not be entrusted with
the task of this nature, does not apply in the instant situation. In the instant case, no question of
violation of the principle of natural justice arises, and there is no scope for the application of the
principle that no man should be a Judge in his own cause. The Central Govt. was not judging any
claim, but was fighting and ad- vancing the claims-of the victims. In those circumstances, it cannot
be said that there was any violation of the prin- ciples of natural justice and such entrustment to the
Cen- tral Govt. of the right to ventilate for the victims was improper or bad. The adjudication would
be done by the courts, and therefore there is no scope of the violation of any principle of natural
justice.
103. Along with this submission, the argument was that the power and the right given to the Central
Govt. to fight for the claims of the victims, is unguided and uncanalised. This submission cannot be
accepted. Learned Attorney General is right that the power conferred on the Central Govt. is not
uncanalised. The power is circumscribed by the purpose of the Act. If there is any improper exercise
or transgres- sion of the power then the exercise of that power can be called in question and set
aside, but the Act cannot be said to be violative of the rights of the victims on that score. We have
noted the relevant authorities on the question that how power should be exercised is different and
separate from the question whether the power is valid or not. The next argument on behalf of the
victims was that there was con- flict of interest between the victims and the Govt. viewed from
another aspect of the matter. It has been urged that the Central Govt. as well as the Govt. of Madhya
Pradesh along with the erstwhile Chief Minister of the State of Madhya Pradesh Shri Arjun Singh
were guilty of negligence, malfeasance and non-feasance, and as such were liable for damages along
with Union Carbide and UCIL. In other words, it has been said that the Govt. of India and the Govt.
of Madhya Pradesh along with Mr. Arjun Singh are joint tort- feasors and joint wrong doers.
Therefore. it was urged that there is conflict of interest in respect of the claims arising out of the the
gas leak disaster between the Govt. of India and the victims and in such a conflict, it is improper,
rather illegal and unjust to vest in the Govt. of India the rights and claims of the victims. As noted
before, the Act was passed in a particular background and, in our opinion, if read in that
background, only covers claims against Union Carbide or UCIL. "Bhopal gas leak disaster" or
"disaster" has been defined in clause (a) of Section (2) as the occurrence on the 2nd and 3rd days of
December, 1984 which involved the release of highly noxious and abnormally dangerous gas from a
plant in Bhopal (being a plant of the UCIL, a subsidiary of the UCC of U.S.A.) and which resulted in
loss of life and damage to property on an extensive scale.Charan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

104. In this context, the Act has to be understood that it is in respect of the person responsible,
being the person in-charge-of the UCIL and the parent company UCC. This interpretation of the Act
is further strengthened by the fact that a "claimant" has been defined in clause (c) of Section 2 as a
person who is entitled to make a claim and the expression "person" in Section 2(e) includes the
Govt. Therefore, the Act proceeded on the assumption that the Govt. could be a claimant being a
person as such. Further- more, this construction and the perspective of the Act is strengthened if a
reference is made to the debate both in the Lok Sabha and Rajya Sabha to which references have
been made.
105. The question whether there is scope for the Union of India being responsible or liable as a joint
tort feasor is a difficult and different question. But even assuming that it was possible that the
Central Government might be liable in a case of this nature, the learned Attorney Gener- al was right
in contending that it was only proper that the Central Government should be able and authorised to
repre- sent the victims. In such a situation, there will be no scope of the violation of the principles of
natural justice. The doctrine of necessity would be applicable in a situation of this nature. The
doctrine has been elaborated, in Hals- bury's Laws of England, 4th Edition, p, 89, paragraph 73,
where it was reiterated that even if all the members of the Tribunal competent to determine a matter
were subject to disqualification, they might be authorised and obliged to hear that matter, by virtue
of the operation of the common law doctrine of necessity,, An adjudicator who is subject to
disqualification on the ground of bias or interest in the matter which he has to decide may in certain
circumstances be required to adjudicate if there is no other person who is competent or authorised
to be adjudicator or if a quorum cannot be formed without him or if no other competent tribu- nal
can be constituted. In the circumstances of the case, as mentioned hereinbefore, the Government of
India is only capable to represent the victims as a party. The adjudica- tion, however, of the claims
would be done by the Court. In those circumstances, we are unable to accept the challenge on the
ground of the violation of principles of natural justice on this score. The learned Attorney General,
howev- er, sought to advance, as we have indicated before, his contention on the ground of de facto
validity. He referred to certain decisions. We are of the opinion that this prin- ciple will not be
applicable. We are also not impressed by the plea of the doctrine of bona fide representation of the
interests of victims in all these proceedings. We are of the opinion that the doctrine of bonafide
representation would not be quite relevant and as such the decisions cited by the learned Attorney
General need not be considered.
106. There is, however, one other aspect of the matter which requires consideration. The victims can
be divested of their rights i.e. these can be taken away from them provided those rights of the
victims are ensured to be established and agitated by the Central Govt. following the procedure
which would be just, fair and reasonable. Civil Procedure Code is the guide which guides civil
proceedings in this country and in other countries procedure akin to Civil Procedure Code. Hence,
these have been recognised and ac- cepted as being in consonance with the fairness of the
proceedings and in conformity with the principles of natural justice. Therefore, the procedure
envisaged under the Act has to be judged whether it is so consistent. The Act, as indicated before.
has provided the procedure under sections 3 and 4. Section 11 provides that the provisions of the Act
and of any Scheme flamed thereunder shall have effect not- withstanding anything inconsistent
therewith contained in any enactment other than the Act or any instrument having effect by virtueCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

of any enactment other than the Act. Hence, if anything is inconsistent with the Act for the time
being, it will not have force and the Act will override those provisions to the extent it does. The Act
has not specifi- cally contemplated any procedure to be followed in the action to be taken pursuant
to the powers conferred under section 3 except to the extent indicated in section 4 of the Act. Section
5, however, authorises the Central Government to have the powers of a civil court for the purpose of
discharging the functions pursuant to the authority vested under sections 3 and 4 of the Act. There
is no question of Central Government acting as a court in respect of the claims which it should
enforce for or on behalf or instead of the victims of the Bhopal gas leak disaster. In this connection,
it is necessary to note that it was submitted that the Act, so far as it deals with the claims of the
victims, should be read in conformity with Civil Procedure Code and/or with the principles of
natural justice; and unless the provisions of/the Act are so read it would be violative of Articles 14
and 21 of the Constitution in the sense that there will be deprivation of rights to/fife and liberty
without following a procedure which is just, fair and reasonable. That is the main submission and
contention of the different counsel for the victims who have appeared. The different view points
from which this contention has been canvassed have been noted before. On the other hand, on
behalf of the Government, the learned Attorney General has canvassed before us that there were
sufficient safeguards consistent with the principles of natural justice within this Act and beyond
what has been provided for in a situation for which the Act was enacted, nothing more could be
provided and further reading down the provisions of the Act in the manner suggested would defeat
the purpose of the Act. The aforesaid section 3 provides for the substitu- tion of the Central
Government with the' right to represent and act in place of (whether within or outside India) every
person who has made, or is entitled to make, a claim in respect of the disaster. The State has taken
over the rights and claims of the victims in the exercise of sovereignty in order to discharge the
constitutional obligations as the parent and guardian of the victims who in the situation as placed
needed the umbrella of protection. Thus, the State has the power and jurisdiction and for this
purpose unless the Act is otherwise unreasonable or violative of the con- stitutional provisions, no
question of giving a hearing to the parties for taking over these fights by the State arises. For
legislation by the Parliament, no principle of natural justice is attracted provided such legislation is
within the competence of the legislature, which indeed the present Act is within the competence of
the Parliament. We are in agreement with the submission of the learned Attorney General that
section 3 makes the Central Government the dominus litis and it has the carriage of the proceedings,
but that does not solve the problem of by what procedure the proceedings should be carried.
107. The next aspect is that section 4 of the Act, which, according to the learned Attorney General
gives limited rights to the victims in the sense that it obliges the Central Government to have due
regard to any matters which such person may require to be urged with respect to his claim and shall,
if such person so desires, permit at the expense of such person, a legal practitioner of his choice to
be associated in the conduct of any suit or other proceeding relating to his claim". Therefore, it
obliges the Central Government to have 'due regard' to any matters, and it was urged on behalf of
the victims that this should be read in order to make the provisions constitutionally valid as
providing that the victims will have a say in the conduct of the proceedings and as such must have
an opportunity of knowing what is happening either by instructing or giving Opinions to the Central
Government and/or providing for such directions as to settlement and other matters. In other
words, it was contended on behalf of the victims that the victims should be given notice of theCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

proceedings and there- by an opportunity, if they so wanted, to advance their view:
and that to make the provisions of s. 4 meaningful and effective unless notice was
given to the victim, disabled as he is, the assumption upon which the Act has been
enacted, could not come and make suggestion in the proceedings. If the victims are
not informed and given no opportunity, the purpose of s. 4 cannot be attained.
108. On the other hand, the learned Attorney General suggested that s. 4 has been complied with,
and contended that the victims had notice of the proceedings. They had knowledge of the suit in
America, and of the order passed by Judge Keenan. The private plaintiffs who had gone to America
were represented by foreign contingency lawyers who knew fully well what they were doing and they
had also joined the said suit along with the Government of India. Learned Attor- ney General
submitted that s. 4 of the Act clearly.enabled the victims to exercise their right of participation in the
proceedings. According to him, there was exclusion of vic- tims from the process of adjudication but
a limited partici- pation was provided and beyond that participation no further participation was
warranted and no further notice was just- fied either by the provisions of the Act as read with the
constitutional requirements or under the general principles of natural justice. He submitted that the
principles of natural justice cannot be put into strait jacket and their application would depend upon
the particular facts and the circumstances of a situation. According to the learned Attorney General,
in the instant case, the legislature had formulated the area where natural justice could be applied,
and upto what area or stage there would be association of the victims with the suit, beyond that no
further applica- tion of any principle of natural justice was contemplated.
109. The fact that the provisions of the principles of natural justice have to be complied with, is
undisputed. This is well-settled by the various decisions of the Court. The Indian Constitution
mandates that clearly, otherwise the Act and the actions would be violative of Article 14 of the
Constitution and would also be destructive of Article 19(1)(g) and negate Article 21 of the
Constitution by deny- ing a procedure which is just, fair and reasonable. See in this connection, the
observations of this Court in Maneka Gandhi's case (supra) and Olga Tellis's case (supra). Some of
these aspects were noticed in the decision of this Court in Swadeshi Cotton Mills v. Union of India
(supra). That was a decision which dealt with the question of taking over of the industries under the
Industries (Development and Regula- tion) Act, 1951. The question that arose was whether it was
necessary to observe the rules of natural justice before issuing a notification under section 18A(1) of
the Act. It was held by the majority of Judges that in the facts of that case there had been
non-compliance with the implied require- ment of the audi alteram partem rule of natural justice at
the pre-decisional stage. The order in that case could be struck down as invalid on that score but the
court found that in view of the concession a heating would be afforded to the company, the case was
remitted to the Central Government to give a full, fair and effective hearing. It was held that the
phrase 'natural justice' is not capable of static and precise definition. It could not be imprisoned in
the straight-jacket or a cast-iron formula. Rules of natural justice are not embodied rules. Hence, it
was not possible to make an exhaustive catalogue of such rules. This Court reiterated that audi
ateram partem is a highly effective rule devised by the Courts to ensure that a statutory authority
arrives at a just decision and it is calculated to act as a healthy check on the abuse or misuse of
power. The rules of natural justice can operate only in areas not covered by any law validly made.Charan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

The general principle as distinguished from an absolute rule of uniform application seems to be that
where a statute does not in terms exclude this rule of prior hearing but contemplates a
post-decisional hearing amounting to a full review of the original order on merits then such a statute
would be con- strued as excluding the audi alteram partem rule at the pre-decisional stage. If the
statute conferring the power is silent with regard to the giving of a pre-decisional hearing to the
person affected the administrative decision after post-decisional hearing was good.
110. The principles of natural justice have been exam- ined by this Court in Union of India & Anr. v.
Tulsi Ram Patel & Ors., (supra). It was reiterated, that the princi- ples of natural justice are not the
creation of Article 14 of the Constitution. Art. 14 is not the begetter of the principles of natural
justice but their constitutional guardian. The principles of natural justice consist, inter alia, of the
requirement that no man should be condemned unheard. If, however, a legislation or a Statute
expressly or by necessary implication excludes the application of any particular principle of natural
justice then it requires close Scrutiny of the Court.
111. It has been canvassed on behalf of the victims that the Code of Civil Procedure is an instant
example of what is a just, fair and reasonable procedure, at least the princi- ples embodied therein
and the Act would be unreasonable if there is exclusion of the victims to vindicate properly their
views and rights. This exclusion may amount to denial of justice. In any case, it has been suggested
and in our opinion, there is good deal of force in this contention, that if a part of the claim, for good
reasons or bad, is sought to be compromised or adjusted without at least con- sidering the views of
the victims that would be unreasonable deprivation of the rights of the victims. After all, it has to be
borne in mind that injustice consists in the sense in the minds of the people affected by any act or
inaction a feeling that their grievances. views or claims have gone 'unheeded or not considered. Such
a feeling is in itself an injustice or a wrong. The law must,be so construed and implemented that
such a feeling does not generate among the people for whose benefit the law is made. Right to a
hearing or representation before enter- ing into a compromise seems to be embodied in the due
proc- ess of law understood in the sense the term has been used in the constitutional jargon of this
country though perhaps not originally intended. In this connection, reference may be made to the
decision of this Court in Sangram Singh v. Election Tribunal, Kotah, [1955] 2 SCR 1. The
Representation of the People Act, 1951 contains section 90 and the proce- dure of Election Tribunals
under the Act was governed by the said provision. Sub-section (2) of section 90 provides that
"Subject to the provisions of this Act and of any rules made thereunder, every election petition shall
be tried by the Tribunal, as nearly as may be, in accordance with the proce- dure applicable under
the Code of Civil Procedure, 1908 to the trial of suits". Justice Bose speaking for the court said that it
is procedure, something designed to facilitate justice and further its ends, and cannot be considered
as a penal enactment for punishment or penalties; not a thing designed to trip people up rather then
help them. It was reiterated that our laws of procedure are grounded on the principle of natural
justice which requires that men should not be condemned unheard, that decisions should not be
reached behind their backs, that proceedings that affect their lives and property should not continue
in their ab- sence and that they should not be precluded from participat- ing in them. Of course,
there may be exceptions and where they are clearly defined these must be given effect to. But taking
by and large, and subject to that proviso, our laws of procedure should be construed, wherever that
is reasona- bly possible, in the light of that principle. At page 9 of the report, Justice Bose observedCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

as under:
"But that a law of natural justice exists in the sense that a party must be heard in a
Court of laW, or at any rate be afforded an opportunity to appear and defend himself,
unless there is express provision to the contrary, is, we think, beyond dispute. See the
observations of the Privy Council in Balakrishna Udayar v. Vasudeva Ayyar, (ILR 40
Mad. 793, 800) and especially in T.M. Barter v. African Products Ltd., (AIR 1928 PC
261) where Lord Buckmaster said "no forms or proce- dure should ever be permitted
to exclude the presentation of a litigant's defence". Also Hari Vishnu's case which we
have just quoted. In our opinion, Wallace J. was right in Venka- tasubbiah v.
Lakshminarasimham, (AIR 1925 Mad. 1274) in holding that "One cardinal principle
to be observed in trials by a Court obviously is that a party has a right to appear and
plead his cause on all occasions when that cause comes on for hearing", and that "It
follows that a party should not be deprived of that right and in fact the Court has no
option to refuse that right, unless the Code of Civil Procedure deprives him of it".
112. All civilised countries accept the right to be heard as part of the due process of law where
questions affecting their rights, privileges or claims are considered or adjudicated.
113. In S.L. Kapoor v. Jagmohan & Ors., [1981] 1 SCR 746 at 765, Chinnappa Reddy, J. speaking for
this Court observed that the concept that justice must not only be done but must manifestly be seen
to be done, is basic to our system. It has been reiterated that the principles of natural justice know of
no exclusionary rule dependent on whether it would have made any difference if natural justice had
been ob- served. The non-observance of natural justice is itself prejudice to any man and proof of
prejudice independently of proof of denial of natural justice is unnecessary and it has been said that
it will come from a person who has denied justice that the person who has been denied justice, is not
prejudiced. Principles of natural justice must, therefore, be followed. That is the normal
requirement:
114. In view of the principles settled by this Court and accepted all over the world, we are of the
opinion that in case of this magnitude and nature, when the victims have been given some say by
Section 4 of the Act, in order to make that opportunity contemplated by section 4 of the Act,
meaningful and effective, it should be so read that the victims have to be given an opportunity of
making their representation before the court comes to any conclusion in respect of any settlement.
How that opportunity should be given, would depend upon the particular situation. Fair procedure
should be followed in a representative mass tort action. There are instances and some of these were
also placed before us during the hearing of these matters indi- cating how the courts regulate giving
of the notice in respect of a mass action where large number of people's views have to be
ascertained. Such procedure should be evolved by the court when faced with such a situation.
115. The Act does not expressly exclude the application of the Code of Civil Procedure. Section 11 of
the Act provides the overriding effect indicating that anything inconsistent with the provisions of the
Act in other law including the Civil Procedure Code should be ignored and the Act should prevail.Charan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

Our attention was drawn to the provisions of Order 1 Rule 8(4) of the Code. Strictly speaking, Order
1 Rule 8 will not apply to a suit or a proceeding under the Act. It is not a case of one having common
interest with others. Here the plaintiff, the Central Govt. has replaced and divested the victims.
116. Learned Attorney General submitted that as the provisions of the Code stood before 1976
Amendment, the High Courts had taken the view that hearing of the parties repre- sented in the suit,
was not necessary, before compromise. Further reference was made to proviso to Order XXIII Rule
1. As in this case there is no question, in our opinion, of abandonment as such of the suit or part of
the suit, the provisions of this Rule would also not strictly apply. However, Order XXIII Rule 3B of
the Code is an important and significant pointer and the principles behind the said provision would
apply to this case. The said rule 3B pro- vides that no agreement or compromise in a representative
suit shall be entered into without the leave of the court expressly recorded in the proceedings; and
sub-rule (2) of rule 3B enjoins that before granting such leave the court shall give notice in such
manner as it may think fit in a representative action. Representative suit, again, has been defined
under Explanation to the said rule vide clause (d) as any other suit in which the decree passed may,
by virtue of the provisions of this Code or of any other law for the time being in force, bind any
person who is not named as party to the suit. In this case, indubitably the victims would be bound by
the settlement though not named in the suit. This is a position conceded by all. If that is so, it would
be a representative suit in terms of and for the purpose of Rule 3B of Order XXIII of the Code. If the
prin- ciples of this rule are the principles of natural justice then we are of the opinion that the
principles behind it would be applicable; and also that section 4 should be so construed in spite of
the difficulties of the process of notice and other difficulties of making "informed decision making
process cumbersome", as canvassed by the learned Attorney General.
117. In our opinion, the constitutional requirements, the language of the Section, the purpose of the
Act and the principles of natural justice lead us to this interpretation of Section 4 of the Act that in
case of a proposed or con- templated settlement, notice should be given to the victims who are
affected or whose rights are to be affected to ascertain their views. Section 4 is significant. It enjoins
the Central Govt. only to have "due regard to any matters which such person may require to be
urged". So, the obligation is on the Central Govt. in the situation contemplated by Section 4 to have
due regard to the views of the victims and that obligation cannot be discharged by the Central Govt.
unless the victims are told that a settlement is proposed, intended or contemplated. It is not
necessary that such views would require consent of all the victims. The Central Govt. as the
representative of the victims must have the views of the victims and place such views before the
court in such manner it considers necessary before a settlement is entered into. If the victims want
to advert to certain aspect of the matter during the proceedings under the Act and settlement indeed
is an important stage in the proceedings, opportuni- ties must be given to the victims. Individual
notices may not be necessary. The Court can, and in our opinion, should in such situation formulate
modalities of giving notice and public notice can also be given inviting views of the vic- tims by the
help of mass media.
118. Our attention was drawn to similar situations in other lands , where in mass disaster actions of
the present type or mass calamity actions affecting large number of people, notices have been given
in different forms and it may be possible to invite the views of the victims by announcement in theCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

media, Press, Radro, and TV etc. intimating the victims that a certain settlement is proposed or
contemplat- ed and inviting views of the victims within a stipulated period. And having regard to the
views, the Central Govt. may proceed with the settlement of the action. Consent of all is not a
pre-condition as we read the Act under Section
4. Hence, the difficulties suggested by the learned Attorney General in having the consent of all and
unanimity, do not really arise and should not deter us from construing the section as we have.
119. The next aspect of the matter is, whether in the aforesaid light Section 4 has been complied
with. The fact that there was no Learned Attorney General, however, sought to canvas the view that
the victims had notice and some of them had participat- ed in the proceedings. We are, however,
unable to accept the position that the victims had notice of the nature contem- plated under the Act
upon the underling principle of Order XXIII Rule 3B of the Code. It is not enough to say that the
victims must keep vigil and watch the proceeding. One as- sumption under which the Act is justified
is that the vic- tims were disabled to defend themselves in an action of this type. If that is so, then
the Court cannot presume that the victims were a lot, capable and informed to be able to have
comprehended or contemplated the settlement. In the aforesaid view of the matter, in our opinion,
notice was necessary. The victims at large did not have the notice.
120. The question, however, is that the settlement had been arrived at after great deal of efforts to
give immedi- ate relief to the victims. We have noticed the order dated 4th May, 1989 passed by this
Court indicating the reasons which impelled the Court to pass the orders on 14/15th February, 1989
in terms and manner as it did. It has been urged before us on behalf of some of the victims that jus-
tice has not been done to their views and claims in respect of the damages suffered by them. It
appears to us by reading the reasons given by this Court on 4th May, 1989 that jus- tice perhaps has
been done but the question is, has justice appeared to have been done and more precisely, the
question before this Court is: does the Act envisage a procedure or contemplate a procedure which
ensures not only that justice is done but justice appears to have been done. If the proce- dure does
not ensure that justice appears to have been done, is it valid? Therefore, in our opinion, in the
background of this question we must hold that Section 4 means and entails that before entering into
any settlement affecting the rights and claims of the victims some kind of notice or information
should be given to the victims; we need not now spell out the actual notice and the manner of its
giving to be consistent with the mandate and purpose of section 4 of the Act.
121. This Court in its order dated 4th May, 1989 had stated that in passing orders on 14th/15th
February, 1989, this Court was impelled by the necessity of urgent relief to the victims rather than to
depend upon the uncertain promise of law. The Act, as we have construed, requires notice to be
given in what form and in what manner, it need not be spelled out, before entering into any
settlement of the type with which we are concerned. It further appears that that type of notice which
is required to be given had not been given. The question, therefore, is what is to be done and what is
the consequence? The Act would be bad if it is not construed in the light that notice before any
settlement under S. 4 of the Act was required to be given. Then arises the question of consequences
of not giving the notice. In this adjudication, we are not strictly concerned with the validity or
otherwise of the settlement, as we have indicat- ed hereinbefore. But constitutional adjudicationCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

cannot be divorced from the reality of a situation, or the impact of an adjudication. Constitutional
deductions are never made in the vacuum. These deal with life's problems in the reality of a given
situation. And no constitutional adjudication is also possible unless one is aware of the
consequences of such an adjudication. One hesitates in matters of this type where large conse-
quences follow one way or the other to put as under what others have put together. It is well to
remember, as did Justice Holmes, that time has upset many fighting faiths and one must always
wagar one's salvation upon some prophecy based upon imperfect knowledge. Our knowledge
changes; our perception of truth also changes. It is true that notice was required to be given and
notice has not been given. The notice which we have contemplated is a notice before the settlement
or what is known in legal terminology as 'pre- decisional notice'. But having regard to the urgency of
the situation and having regard to the need for the victims for relief and help and having regard to
the fact that so much effort has gone in finding a basis for the settlement, we, at one point of time,
thought that a post-decisional hearing in the facts and circumstances of this case might be consid-
ered to be sufficient compliance with the requirements of principles of natural justice as embodied
under s. 4 of the Act. The reasons that impelled this Court to pass the orders of 14th/15th February,
1989 are significant and compelling. If notice was given, then what would have happened? It has
been suggested on behalf of the victims by counsel that if the victims had been given an opportunity
to be heard, then they would have perhaps pointed out, inter alia, that the amount agreed to be paid
through the settlement was hope- lessly inadequate. We have noted the evidence available to this
Court which this Court has recorded in its order dated 4th May, 1989 to be the basis for the figure at
which the settlement was arrived at. It is further suggested that if an opportunity had been given
before the settlement, then the victims would have perhaps again pointed out that crimi- nal liability
could not be absolved in the manner in which this Court has done on the 14th/l5th February, 1989.
It was then contended that the Central Government was itself sued as a joint tort feasor. The Central
Government would still be liable to be proceeded in respect of any liability to the victims if such a
liability is established; that liability is in no way abridged or affected by the Act or the settle- ment
entered into. It was submitted on behalf of the victims that if an opportunity had been given, they
would have perhaps pointed out that the suit against the Central Gov- ernment, Government of
Madhya Pradesh and UCIL could not have been settled by the compromise. It is further-suggested
that if given an opportunity, it would have been pointed out that the UCIL should have also been
sued. One of the impor- tant requirements of justice is that people affected by an action or inaction
should have opportunity to have their say. That opportunity the victims have got when these appli-
cations were heard and they were heard after utmost publici- ty and they would have further
opportunity when review application against the settlement would be heard.
122. On behalf of the victims, it was suggested that the basis of damages in view of the observations
made by this Court in M.C. Mehta's case (supra) against the victims of UCC or UCIL would be much
more than normal damages suffered in similar case against any other company or party which is
financially not so solvent or capable. It was urged that it is time in order to make damages deterrent
the damages must be computed on the basis of the capacity of a delinquent made liable to pay such
damages and on the monitory capacity of the delinquent the quantum of the damages awarded
would vary and not on the basis of actual consequences suffered by the victims. This is an uncertain
promise of law. On the basis of evidence available and on the basis of the princi- ples so far
established, it is difficult to foresee any reasonable possibility of acceptance of this yardstick. AndCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

even if it is accepted, there are numerous difficulties of getting that view accepted internationally as
a just basis in accordance with law. These, however, are within the realm of possibility.
123. It was contended further by Shri Garg, Shri Shanti Bhushan and Ms. Jaising that all the further
particulars upon which the settlement had been entered into should have been given in the' notice
which was required to be given before a settlement was sanctified or accepted. We are unable to
accept this position. It is not necessary that all other particulars for the basis of the proposed
settlement should be disclosed in a suit of this nature before the final decision. Whatever data was
already there have been disclosed, that, in our opinion, would have been sufficient for the victims to
be able to give their views, if they want to. Disclosure of further particulars are not warranted by the
requirement of principles of natural justice. Indeed, such disclosure in this case before finality might
jeopar- dise luther action, if any, necessary so consistent with justice of the case.
124. So on the materials available, the victims would have to express their views. The victims have
not been able to show at all any other point or material which would go to impeach the validity of
the settlement. Therefore, in our opinion, though settlement without notice is not quite proper, on
the materials so far available, we are of the opinion that justice has been done to the victims but jus-
tice has not appeared to have been done. In view of the magnitude of the misery involved and the
problems in this case, we are also of the opinion that the setting aside of the settlement on this
ground in view of the facts and the circumstances of this case keeping the settlement in abeyance
and giving notice to the victims for a post-deci- sional hearing would not be in the ultimate interest
of justice. It is true that not giving notice, was not proper because principles of natural justice are
fundamental in the constitutional set up of this country. No man or no man's right should be
affected without an opportunity to ventilate his views. We are also conscious that justice is a psycho-
logical yearning, in which men seek acceptance of their view point by having an opportunity of
vindication of their view point before the forum or the authority enjoined or obliged to take a
decision affecting their right. Yet, in the par- ticular situations, one has to bear in mind how an
infrac- tion of that should be sought to be removed is accordance with justice. In the facts and the
circumstances of this case where sufficient opportunity is available when review application is heard
on notice, as directed by Court, no further opportunity is necessary and it cannot be said that
injustice has been done. "To do a great right" after all, it is permissible sometimes "to do a little
wrong". In the facts and circumstances of the case, this is one of those rare occasions. Though
entering into a settlement without the required notice is wrong, in the facts and the circum- stances
of this case, therefore, we are of the opinion, to direct that notice should be given now, would not
result in dain justice in the situation. In the premises, no further consequential order is necessary by
this Court. Had it been necessary for this Bench to have passed such a consequential order, we
would not have passed any such consequential order in respect of the same.
125. The sections and the scheme dealing with the deter- mination of damages and distribution of
the amount have also been assailed as indicated before. Our attention was drawn to the provisions
of the Act dealing with the payment of compensation and the scheme framed therefore. It was
submit- ted that section 6 of the Act enjoins appointment by the Central Government of an officer
known as the Commissioner for the welfare of the victims. It was submitted that this does not give
sufficient judicial authority to the officer and would be really leaving the adjudication under theCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

scheme by an officer of the executive nature. Learned Attor- ney General has, however, submitted
that for disbursement of the compensation contemplated under the Act or under the orders of this
Court, a notification would be issued under section 6(3) of the Act authorising the Commissioner or
other officers to exercise all or any of the powers which the Central Government may exercise under
section 6 to enable the victims to place before the Commissioner or Deputy Commissioner any
additional evidence that they would like to adduce. We direct so, and such appropriate notifica-
tion be issued. We further direct that in the scheme of categorisation to be done by the Deputy
Commissioner should be appealable to an appropriate judicial authority and the Scheme should be
modified accordingly. We reiterate that the basis of categorisation and the actual categorisation
should be justifiable and judicially reviewable-the provisions in the Act and the Scheme should be so
read. There were large number of submissions made on behalf of the victims about amending the
scheme. Apart from and to the extent indicated above, in our opinion, it would be unsafe to tinker
with the scheme piecemeal. The scheme is an integrated whole and it would not be proper to amend
it piecemeal. We, however, make it clear that in respect of categorisation and claim, the authorites
must act on principles of natural justice and act quasi-judicially.
126. As mentioned hereinbefore, good deal of arguments were advanced before us as to whether the
clause in the settlement that criminal proceedings would not be proceeded with and the same will
remain quashed is valid or invalid. We have held that these are not part of the proceedings under the
Act. So the orders on this aspect in the order of 14th/15th February, 1989 are not orders under the
Act. Therefore, on the question of the validity of the Act, this aspect does not arise whether the
settlement of criminal proceedings or quashing the criminal proceedings could be a valid
consideration for settlement or whether if it was such a consideration or not is a matter which the
court reviewing the settlement has to decide.
127. In the premise, we hold that the Act is constitu- tionally valid in the manner we read it. It
proceeds on the hypothesis that until the claims of the victims are realised or obtained. from the
delinquents, namely, UCC and UCIL by settlement or by adjudication and until the proceedings in
respect thereof continue the Central Government must pay interim compensation or maintenance
for the victims. In entering upon the settlement in view of s. 4 of the Act, regard must be had to the
views of the victims and for the purpose of giving regard to these, appropriate notices before arriving
at any settlement, was necessary. In some cases, however, post-decisional notice might be sufficient
but in the facts and the circumstances of this case, no useful purpose would be served by giving a
post-decisional hearing having regard to the circumstances mentioned in the order of this Court
dated 4th May, 1989 and having regard to the fact that there are no further additional data and facts
available with the victims which can be profitably and meaningfully presented to controvert the
basis of the set- tlement and further having regard to the fact that the victims had their say or on
their behalf their views had been agitated in these proceed- ings and will have further opportunity in
the pending review proceedings. No further order on this aspect is necessary. The sections dealing
with the payment of compensation and categorisation should be implemented in the manner
indicated before.Charan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

128. The Act was conceived on the noble promise of giving relief and succour to the dumb, pale,
meek and impoverished victims of a tragic industrial gas leak disas- ter, a concomitant evil in this
industrial age of technolog- ical advancement and development. The Act had kindled high hopes in
the hearts of the. weak and worn, wary and forlorn. The Act generated hope of humanity. The
implementation of the Act must be with justice. Justice perhaps has been done to the victims
situated as they were, but it is also true that justice has not appeared to have been done. That is a
great infirmity. That is due partly to the fact that proce- dure was not strictly followed as we have
understood it and also partly because of the atmosphere that was created in the country, attempts
were made to shake the confidence of the people in the judicial process and also to undermine the
credibility of this Court. This was unfortunate. This was perhaps due to misinformed public opinion
and also due to the fact that victims were not initially taken into confi- dence in reaching the
settlement. This is a factor which emphasises the need for adherence to the principles of natural
justice. The credibility of judiciary is as impor- tant as the alleviation of the suffering of the victims,
great as these were. We hope these adjudications will re- store that credibility. Principles of natural
justice are integrally embedded in our constitutional framework and their pristine glory and
primacy cannot and should not be allowed to be submerged by the exigencies of particular situations
or cases. This Court must always assert primacy of adherence to the principles of natural justice in
all adjudications. But at the same time, these must be applied in a particular manner in particular
cases having regard to the particular circumstances. It is, therefore, necessary to reiterate that the
promises made to the victims and hopes raised in their hearts and minds can only be redeemed in
some measure if attempts are made vigorously to distribute the amount realised to the victims in
accordance with the scheme as indicated above. That would be a redemption to a certain extent. It
will also be necessary to reiterate that attempts should be made to formulate the principles of law
guiding the Government and the authorities to permit carry- ing on of trade dealing with materials
and things which have dengerous consequences within sufficient specific safeguards especially in
case of multinational corporations trading in India. An awareness on these lines has dawned. Let
action follow that awareness. It is also necessary to reit- erate that the law relating to damages and
payment of inter- im damages or compensation to the victims of this nature should be seriously and
scientifically examined by the appropriate agencies.
129. The Bhopal Gas Leak disaster and its aftermath of that emphasise the need for laying down
certain norms and standards the Government to follow before granting permis- sions or licences for
the running of industries dealing with materials which are of dangerous potentialities. The Govern-
ment should, therefore, examine or have the problem examined by an expert committee as to what
should be the conditions on which future licences and/or permission for running industries on
Indian soil would be granted and for ensuring enforcement of those conditions, sufficient safety
measures should be formulated and scheme of enforcement indicated. The Government should
insist as a condition precedent to the grant of such licences or permissions, creation of a fund in
anticipation by the industries to be available for payment of damages out of the said found in case of
leakages or damages in case of accident or disaster flowing from negli- gent working of such
industrial operations or failure to ensure measures preventing such occurrence. The Government
should also ensure that the parties must agree to abide to pay such damages out of the said damages
by procedure sepa- rately evolved for computation and payment of damages with- out exposing the
victims or sufferers of the negligent act to the long and delayed procedure. Special procedure mustCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

be provided for and the industries must agree as a condition for the grant of licence to abide by such
procedure or to abide by statutory arbitration. The basis for damages in case of leakages and
accident should also be statutorily fixed taking into consideration the nature of damages in- flicted,
the consequences thereof and the ability and capac- ity of the parties to pay. Such should also
provide for deterrent or punitive damages, the basis for which should be formulated by a proper
expert committee or by the Govern- ment. For this purpose, the Government should have the matter
examined by such body as it considers necessary and proper like the Law Commission or other
competent bodies. This is vital for the future.
130. This case has taken some time. It was argued exten- sively. We are grateful to counsel who have
assisted in all these matters. We have reflected. We have taken some time in pronouncing our
decision. We wanted time to lapse so that the heat of the moment may calm down and proper
atmosphere restored. Justice, it has been said, is the constant and perpetual disposition to render
every man his due. But what is a man's due in a particular situation and in a particular
circumstances is a matter for appraisement and adjustment. It has been said that justice is
balancing. The balances have always been the symbol of even-handed justice. But as said Lord
Denning in Jones v. National Coal Board Ltd., [1957] 2 QB 55, at 64-let the advocates one after the
other put the weights into the scales--the 'nicely calculated less or more'--but the judge at the end
decides which way the balance tilts, be it ever so slightly. This is so in every case and every situation.
13 1. The applications are disposed of in the manner and with the direction, we have indicated
above. SINGH, J. 1 have gone through the proposed judgment of my learned brother, Sabyasachi
Mukharji, CJI. I agree with the same but I consider it necessary to express my opinion on certain
aspects.
Five years ago between the night of December 2-3, 1984 one of the most tragic industrial disasters in
the recorded history of mankind occurred in the city of Bhopal, in the State of Madhya Pradesh, as a
result of which several per- sons died and thousands were disabled and physically inca- pacitated for
life. The ecology in and around Bhopal was adversely affected and air, water and the atmosphere
waspol- luted, its full extent has yet to be determined. UnionCar- bide India Limited (UCIL) a
subsidiary of Union Carbide Corporation (a Transnational Corporation of United States) has been
manufacturing pesticides at its plant located in the city of Bhopal. In the process of manufacture of
pesti- cide the UCIL had stored stock of Methyl Isocyanate commonly known as MlC a highly toxic
gas. On the night of the trage- dy, the MIC leaked from the plant in substantial quantity causing
death and misery to the people working in the plant and those residing around it. The
unprecedented catastrophe demonstrated the dangers inherent in the production of haz- ardous
chemicals even though for the purpose of industrial development. A number of civil suits for
damages against the UCC were filed in the United States of America and also in this Country. The
cases filed in USA were referred back to the Indian courts by Judge Keenan details of which are
contained in the judgment of my learned brother Mukharji, CJI. Since those who suffered in the
catastrophe were mostly poor, ignorant, illiterate and ill-equipped to pursue their claims for
damages either before the courts in USA or in Indian courts, the Parliament enacted the Bhopal Gas
Leak Disaster (Processing of Claims) Act 1985 (hereinafter re- ferred to as 'the Act') conferring
power on the Union of India to take over the conduct of litigation in this regard in place of theCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

individual claimants. The facts and circumstances which led to the settlement of the claims before
this Court have already been stated in detail in the judgment of Mukharji, CJI, and therefore, I need
not refer to those facts and circumstances. The constitutional validity of the Act has been assailed
before us in the present petitions. If the Act is declared unconstitutional, the settlement which was
recorded in this Court, under which the UCC has already deposited a sum of Rs.750 crores for
meeting the claims of Bhopal Gas victims, would fall and the amount of money which is already in
deposit with the Registry of this Court would not be available for relief to the victims. Long and de-
tailed arguments were advanced before us for a number of days and on an anxious consideration
and having regard to the legal and constitutional aspects and especially the need for immediate help
and relief to the victims of the gas disaster, which is already delayed, we have upheld the
constitutional validity of the Act. Mukharji, CJI has ren- dered a detailed and elaborate judgment
with which I re- spectfully agree. However, I consider it necessary to say few words with regard to
the steps which should be taken by the Executive and the Legislature to prevent such tragedy in
future and to avoid the prolonged misery of victims of in industrial disaster.
We are a developing country, our national resources are to be developed in the field of science,
technology, indus- try and agriculture. The need for industrial development has led to the
establishment of a number of plants and factories by the domestic companies and under industries
are engaged in hazardous or inherently dangerous activities which pose potential threat to life,
health and safety of persons working in the factory, or residing in the surrounding areas. Though
working of such factories and plants is regu- lated by a number of laws of our country, i.e. the
Factories Act, Industrial Development and Regulation Act and Workmen's Compensation Act etc.
there is no special legislation pro- viding for compensation and damages to outsiders who may
suffer on account of any industrial accident. As the law stands to-day, affected persons have to
approach civil courts for obtaining compensation and damages. In civil courts, the determination of
amount of compensation or damages as well as the liability of the enterprise has been bound by the
shackles of conservative principles laid down by the House of Lords in Ryland v. Herchief, [1868]
LR 3 HL page 330. The principles laid therein made it difficult to obtain adequate damages from the
enterprise and that too only after the negligence of the enterprise was proved. This continued to be
the position of law, till a Constitution Bench of this Court in M.C. Mehta v. Union of India, [1987] 1
SCC 420, commonly known as Sriram Oleum Gas Leak case evolved principles and laid down new
norms to deal adequately with the new problems arising in a highly industrialised economy. This
Court made judicial innovation in laying down principles with regard to liabili- ty of enterprises
carrying hazardous or inherently dangerous activities departing from the rule laid down in Ryland v.
Fletcher. The Court held as under:
"We are of the view that an enterprise which is engaged in a hazardous or inherently
dan- gerous industry which poses a potential threat to the" health and safety of the
persons working in the factory and residing in the surrounding areas owes an
absolute and non- delegiable duty to the community to ensure that no harm results to
any one on account of hazardous or inherently dangerous nature of the activity which
it has undertaken. The enterprise must be held to be under an obliga- tion to provide
that the hazardous or inher- ently dangerous activity in which it is en- gaged must be
conducted with the highest standards of safety and if any harm results on account ofCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

such activity, the enterprise must be absolutely liable to compensate for such harm
and it should be no answer to the enter- prise to say that it had taken all reasonable
care and that the harm occurred without any negligence on its part. Since the persons
harmed on account of the hazardous or inher- ently dangerous activity carried on by
the enterprise would not be in a position to isolate the process of operation from the
hazardous preparation of substance or any other related element that caused the
harm the enterprise must be held strictly liable for causing such harm as a part of the
social cost of carrying on the hazardous or inherently dangerous activity. If the
enterprise is permitted to carry on an hazardous or inher- ently dangerous activity for
its profit, the law must presume that such permission is conditional on the enterprise
absorbing the cost of any accident arising on account of such hazardous or inherently
dangerous activi- ty as an appropriate item of its overheads. Such hazardous or
inherently dangerous activi- ty for private profit can be tolerated only on condition
that the enterprise engaged in such hazardous or inherently dangerous activity
indemnifies all those who suffer on account of the carrying on of such hazardous or
inherent- ly dangerous activity regardless of whether it is carried on carefully or not.
This principle is also sustainable on the ground that the enterprise alone has the
resource to discover and guard against hazards or dangers and to provide warning
against potential hazards. We would therefore hold that where an enterprise is
engaged in a hazardous or inher- ently dangerous activity and harm results to anyone
on account of an accident in the opera- tion of such hazardous or inherently
dangerous activity resulting, for example, in escape of toxic gas the enterprise is
strictly and absolutely liable to compensate all those who are affected by the accident
and such liabili- ty is not subject to any of the exceptions which operate vis-a-vis the
tortious principle of strict liability under the rule in Rylands v. Fletcher."
The law so laid down made a land-mark departure from the conservative principles with regard to
the liability of an enterprise carrying on hazardous or inherently dangerous activities.
In the instant cases there is no dispute that UCIL a subsidiary of UCC was carrying on activity of
manufacturing pesticide and in that process it had stored MIC a highly toxic and dangerous gas
which leaked causing vast damage not only to human life but also to the flora and fauna and ecology
in and around Bhopal. In view of this Court's deci- sion in M.C. Mehta's case there is no scope for
any doubt regarding the liability of the UCC for the damage caused to the human beings and nature
in and around Bhopal. While entering into the settlement the UCC has accepted its li- ability and for
that reason it has deposited a sum of Rs.750 crores in this Court. The inadequacy of the amount of
com- pensation under the settlement was assailed by the counsel for the petitioners but it is not
necessary for us to ex- press any opinion on that question as review petitions are pending before
another Constitution Bench and more so as in the present cases we are concerned only with the
constitu- tional validity of the Act.
The Bhopal Gas tragedy has raised several important questions regarding the functioning of
multi-nationals in third world countries.After the Second world war colonial rule came to end in
several parts of the globe, as a number of natives secured independence from foreign rule. TheCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

political domination was over but the newly born nations were beset with various problems on
account of lack of finances and development. A number of multi-nationals and transnational
corporations offered their services to the under-developed and developing countries to provide
finances and technical know-how by setting up their own industries in those countries on their own
terms that brought problems with regard to the control over the functioning of the transnational
corporations. Multi-national companies in many cases exploited the under- developed nations and
in some cases they influenced politi- cal and economic policies of host countries which subverted the
sovereignty of those countries. There has been com- plaints against the multi-nationals for adopting
unfair and corrupt means to advance their interests in the host coun- tries. Since this was a
worldwide phenomena the United Nations took up the matter for consideration. The Economic and
Social Council of the United Nations established a Commission on Transnational Corporations to
conduct research on various political, economic and social aspects relating to transnational
corporations. On a careful and detailed study the Commission submitted its Report in 1985 for
evolv- ing a Code of Conduct for Transnational Corporations. The Code was adopted in 1986 to
which large number of countries of the world are signatories. Although it has not been fully finalised
as yet, the Code presents a comprehensive instru- ment formulating the principles of Code of
Conduct for transnational corporations carrying on their enterprises in under developed and
developing countries. The Code contains provisions regarding ownership and control designed to
strike balance between the competing interests of the Trans- national Corporation and the host
countries. It extensively deals with the political, economic, financial, social and legal questions. The
Code provides for disclosure of infor- mation to the host countries and it also provides guidelines for
nationalisation and compensation, obligations to inter- national law and jurisdiction of courts. The
Code lays down provisions for settlement of disputes between the host States and an affiliate of a
Transnational Corporation. It suggests that such disputes should be submitted to the national courts
or authorities of host countries unless amicably settled between the parties. It provides for the
choice of law and means for dispute settlement arising out of contracts. The Code has also laid down
guidelines for the determination of settlement of disputes arising out of accident and disaster and
also for liability of Transnation- al Corporations and the jurisdiction of the courts. The Code is
binding on the countries which formally accept it. It was stated before us that India has accepted the
Code. If that be so, it is necessary that the Government should take effective measures to translate
the provisions of the Code into specific actions and policies backed by appropriate legislation and
enforcing machinery to prevent any accident or disaster and to secure the welfare of the victims of
any industrial disaster.
In the context of our national dimensions of human rights, right to life, liberty, pollution free air and
water is guaranteed by the Constitution under Articles 21, 48A and 5l(g), it is the duty of the State to
take effective steps to protect the guaranteed constitutional rights. These rights must be integrated
and illumined by the evolving international dimensions and standards, having regard to our
sovereignty, as highlighted by Clauses 9 and 13 of U.N. Code of conduct on Transnational
Corporations. The evolving standards of international obligations need to be respected, maintaining
dignity and sovereignty of our people, the State must take effective steps to safeguard the
constitutional rights of citizens by enacting laws. The laws so made may provide for conditions for
granting licence to Transnational Corpora- tions, prescribing norms and standards for running
indus- tries on Indian soil ensuring the constitutional rights of our people relating to life, liberty, asCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

well as safety to environment and ecology to enable the people to lead a healthy and clean life. A
Transnational Corporation should be made liable and subservient to laws of our country and the
liability should not be restricted to affiliate company only but the parent corporation should also be
made liable for any damage caused to the human being or ecology. The law must require
transnational corporations to agree to pay such damages as may be determined. by the statutory
agencies and forum constituted under it without exposing the victims to long drawn litigation.
Under the existing civil law damages are determined by the Civil Courts, after a long drawn
litigation, which destroys the very purpose of awarding damages. In order to meet the situation, to
avoid delay and to ensure immediate relief to the victims we would suggest that the law made by the
Parliament should provide for constitution of tribunals regulated by special procedure for
determining compensation to victims of industrial disaster or accident, appeal against which may lie
to this Court on limited ground of questions of law only after depositing the amount determined by
the Tribunal. The law should also provide for interim relief to victims during the pendency of
proceedings. These steps would minimise the misery and agony of victims of hazardous enterprises.
There is yet another aspect which needs consideration by the Government and the Parliament.
Industrial development in our country and the hazards involved therein, pose a mandatory need to
constitute a statutory "Industrial Disas- ter Fund", contributions to which may be made by, the Gov-
ernment, the industries whether they are transnational corporations or domestic undertakings
public or private. The extent of contribution may be worked out having regard to the extent of
hazardous nature of the enterprise and other allied matters. The Fund should be permanent in
nature, so that money is readily available for providing immediate effective relief to the victims. This
may avoid delay, as has happened in the instant case in providing effective relief to the victims. The
Government and the Parliament should therefore take immediate steps for enacting laws, having
regard to these suggestions, consistent with the international norms and guidelines as contained in
the United Nations Code of Con- duct on Transnational Corporations.
With these observations, I agree with the order proposed by my learned brother, Sabyasachi
Mukharji, CJI. RANGANATHAN, J. Five years ago, this country was shaken to its core by a national
catastrophe, second in magnitude and disastrous effects only to the havoc wrought by the atomic
explosions in Hiroshima and Nagasaki. Multitudes of illiterate and poverty-stricken people in and
around Bhopal suffered damage to life and limb due to the escape of poi- sonous Methyl Isocyanate
(MIC) gas from one of the storage tanks at the factory of the Union Carbide (India) Limited (UCIL)
in Bhopal, a wholly owned subsidiary of the multina- tional giant, the Union Carbide Corporation
(UCC). A number of civil suits claiming damages from the UCC were filed in the United States of
America and similar litigation also followed in Indian courts. Fearing the possibilities of the
exploitation of the situation by vested interests, the Government of India enacted, the Bhopal Gas
Leak Disaster (Processing of Claims) Act, 1985 ('the Act') to regulate the course of such litigation.
Briefly speaking, it empowered the Union of India to take over the conduct of all litiga- tion in this
regard and conduct it in place of, or in asso- ciation with, the individual claimants. It also enabled
the Union to enter into a compromise with the UCC and UCIL and arrive at a settlement. The writ
petitions before us have been filed challenging the constitutional validity of this statute on the
ground that the divestiture of the claimants' individual rights to legal remedy against the
multinational for the consequences of carrying on dangerous and hazardous activities on our soilCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

violates the fundamental rights guaranteed under article 14, 19 and 21 of the Constitution. In
consequence of certain proceedings before Judge Keenan of the U.S. District Courts, the venue of
the litiga- tion shifted to India. In the principal suit filed in India by the Union (Civil Suit No.
1113/86) orders were passed by the trial court in Bhopal directing the UCC to deposit Rs.370 crores
(reduced to Rs.250 crores by the Madhya Pra- desh High Court) as interim payment to the gas
victims pending disposal of the suit. There were appeals to this Court in which the UCC contested
the Court's jurisdiction to pass an order for an interim payment in a suit for money, while the Union
pleaded that a much higher interim payment should have been granted. When the matter was being
argued in this Court, a settlement was arrived at between the Union and the UCC under which a sum
of Rs.750 crores has been received by the Union in full settlement of all the claims of all victims of
the gas leak against the UCC. The Union also agreed to withdraw certain prosecutions that had been
initiated against the officials of the UCC and UCIL in this connec- tion. This settlement received the
imprimatur of this Court in its orders dated 14th & 15th February, 1989. It is unfortunate that,
though the writ petitions before us were pending in this Court at that time, neither their contents
nor the need for considering first the issue of the validity of the Act before thinking of a settlement
in pursuance of its provisions seem to have been effectively brought to the notice of the Bench which
put an end to all the litigation on this topic in terms of the settlement. The settlement thus stood
approved while the issue of validity of the Act under which it was effected stood undecided. When
this was brought to the notice of the above Bench, it di- rected these writ petitions to be listed before
a different Bench 'to avoid any possible feeling that the same Bench may be coloured in its views on
the issue by reason of the approval it had given to the fait accompli viz. the settle- ment. That is now
these matters came before us. The petitioners, claiming to represent a section of the victims are,
firstly, against any settlement at all being arrived at with the UCC. According to them, it is more
important to ensure by penal action that multinational corporations do not play with the lives of
people in de- veloping and under developed countries than to be satisfied with mere compensation
for injury and that the criminal prosecutions initiated in this case should have been pur- sued.
Secondly, they are of the view that the amount for which the claims have been settled is a pittance,
far below the amount of damages they would have been entitled to, on the principles of strict,
absolute and punitive liability enunciated by this Court in Mehta's case [1987] 1 S.C.R.
819. Thirdly, their grievance is that no publicity at all was given, before this court passed its order, to
enable individual claimants or groups of them to put forward their suggestions or objections to the
settlement proposed. Their interests were sealed, they say, without complying with elementary
principles of natural justice. They contend that the provisions of an Act which has made such a
settlement possible cannot be constitutionally valid.
The arguments before us ranged over a very wide ground, covered several issues and extended to
several days. This Bench has been placed in somewhat of a predicament as it has to pronounce on
the validity of the provisions of the Act in the context of an implementation of its provisions in a
particular manner and, though we cannot (and do not) express any views regarding the merits of the
settlement, we are asked to consider whether such settlement can be consistent with a correct and
proper interpretation of the Act tested on the touchstone of the fundamental rights guaranteed
under the Constitution. Mukharji, C.J., has outlined the issues, dealt elaborately with the
contentions urged, and given expression to his conclusions in a learned, elaborate and detailedCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

judgment which we have had the advantage of perus- ing in draft. Our learned brother K.N. Singh,
J., has also highlighted certain aspects in his separate judgment. We are, in large measure, in
agreement with them, but should like to say a few words on some of the issues in this case,
particularly those in regard to which our approach has been somewhat different:
1. The issue regarding the validity of the Act turns principally on the construction of
sections 3 and 4 of the Act. We are inclined to hold that the fact that a settlement has
been effected, or the circumstances in which or the amount for which the claims of
the victims have been set-
tled, do not have a bearing on this question of interpreta- tion and have to be left out of account
altogether except as providing a contextual background in which the question arises. Turning
therefore to the statute and its implica- tions, the position is this. Every person who suffered as a
consequence of the gas leak had a right to claim compensa- tion from the persons who, according to
him, were liable in law for the injury caused to him and also a fight to insti- tute a suit or proceeding
before any court or authority with a view to enforce his right to claim damages. In the normal course
of events, such a claimant who institute a suit or proceeding would have been at complete liberty to
withdraw the said suit or proceeding or enter into any compromise he may choose in that regard.
Section 3 undoubtedly takes away this fight of the claimant altogether: (a) except to the limited
extent specified in the proviso to S. 3(3) and (b) subject to the provisions of S. 4, for this section
clearly states that it is the Central Government and the Central Government alone which has the
right to represent and act in place of the claimants, whether within or outside India, for all purposes
in connection with the enforcement of his claims. We may first consider how far the main provision
in S. 3 (leaving out of account the proviso as well as section 4) is compatible with the Constitution
The first question that arises is whether the legisla- ture is justified in depriving the claimants of the
right and privilege of enforcing their claims and prosecuting them in such manner as they deem fit
and in compulsorily inter- posing or substituting the Government in their place. We think that, to
this question, there can be only one answer. As pointed out by our learned brother, the situation was
such that the victims of the tragedy needed to be protected against themselves as their adversery
was a mighty multi- national corporation and proceedings to a considerable extent had been
initiated in a foreign country, where the conduct of the cases was entrusted to foreign lawyers under
a system of litigation which is unfamiliar to us here. In the stark reality of the situation, it cannot
even be plau- sibly contended that the large number of victims of the gas leak disaster should have
been left to fend for itself and merely provided with some legal aid of one type or another. It is
necessary to remember that, having regard to the identity of the principal ground of claim of all the
vic- tims, even if a single victim was not diligent in conducting his suit or entered into a compromise
or submitted to a decree judging the issues purely from his individual point of view, such a decision
or decree could adversely affect the interests of the innumerable other victims as well. In fact, it
appears that a settlement between one set of claim- ants and the adversary corporation was almost
imminent and would perhaps have been through out for the timely interven- tion of the Government
of India. The battle for the enforce- ment of one's rights was bound to be not only prolonged but also
very arduous and expensive and the decision of the legislature that the fight against the adversary
should be consolidated and its conduct handed over to the Government of India--it may perhaps
have been better if it had been handed over to an autonomous body independent of the Govern-Charan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

ment but, as pointed out by our learned brother, the course adopted was also not objectionable--was
perhaps the only decision that could have been taken in the circumstances. This is indeed a unique
situation in which the victims, in order to realise to the best advantage their rights against UCC, had
to be helped out by transposing that right to be enforced by the Government.
We did not indeed understand any learned counsel before us to say that the legislature erred in
entrusting the Government of India with the responsibility of fighting for the victims. The only
grievance is that in the process their right to take legal proceedings should not have been completely
taken away and that they should also have had the liberty of partici- pating in the proceedings right
through. In fact, though the Act contemplates the Central Government to completely act in place of
the victims, the Government of India has not in fact displaced them altogether. In all the
proceedings pending in this country, as well as those before Judge Keenan, the Government of India
has conducted the proceed- ings but the other victims or such of them as chose to associate
themselves in these proceedings by becoming par- ties were not shut out from taking part in the
proceedings. In fact, as the learned Attorney General pointed out, one of the groups of litigants did
give great assistance to the trial judge at Bhopal. But even if the provisions of S. 3 had been
scrupulously observed and the names of all parties, other than the Central Government, had been
got deleted from the array of parties in the suits and proceedings pending in this country, we do not
think that the result would have been fatal to the interests of the litigants. On the con- trary, it
enabled the litigants to obtain the benefit of all legal expertise at the command of the Government of
India in exercising their rights against the Union Carbide Corpora- tion. Such representation can
well be justified by resort to a principle analogous to, if not precisely the same as that of, "parens
patriae". A victim of the tragedy is compelled to part with a valuable right of his in order that it
might be more efficiently and satisfactory 'exploited for his benefit than he himself is capable of. It is
of course possible that there may be an affluent claimant or lawyer engaged by him, who may be
capable of fighting the litiga- tion better. It is possible that the Government of India as a litigant may
or may not be able to pursue the litigation with as much determination or capability as such a
litigant. But in a case of the present type one should not be con- founded by such a possibility. There
are more indigent litigants than affluent ones. There are more illiterates than enlightened ones.
There are very few of the claimants, capable of finding the financial wherewithal required for
fighting the litigation. Very few of them are capable of prosecuting such a litigation in this country
not to speak of the necessity to run to a foreign country. The financial position of UCIL was
negligible compared to the magnitude of the claim that could arise and, though eventually the battle
had to be pitched on our own soil, an initial as well as final recourse to legal proceedings in the
United States was very much on the cards, indeed inevitable. In this situa- tion, the legislature was
perfectly justified in coming to the aid of the victims with this piece of legislation and in asking the
Central Government to shoulder the responsibility by substituting itself in place of the victims for all
purposes connected with the claims. Even if the Act had provided for a total substitution of the
Government of India in place of the victims and had completely precluded them from exercising
their rights in any manner, it could perhaps have still been contended that such deprivation was
necessary in larger public interest.
But the Act is not so draconian in its content. Actual- ly, as we have said a little earlier, the grievance
of the petitioners is not so much that the Government was entrusted with the functions. of aCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

dominus litis in this litigation. Their contention is that the whole object and purpose of the litigation
is to promote the interests of the claimants, to enable them to fight the UCC with greater strength
and determination, to help them overcome limitations of time, money and legal assistance and to
realise the best compensa- tion possible consistent not only with the damage suffered by them but
also consistent with national honour and pres- tige. It is suggested that the power conferred on the
Gov- ernment should be construed as one hedged in by this domi- nant object. A divestiture of the
claimant's right in this situation would be reasonable, it is said, only if the claimant's rights are
supplemented by the Government and not supplanted by it.
Assuming the correctness of the argument, the provisions of the proviso to S. 3(3) and of section 4
furnish an answer to this contention. While the provision contained in the main part of section 3
may be sufficient to enable the Government of India to claim to represent the claimants and initiate
and conduct suits or proceeding on their behalf, the locus standi of the Government of India in suits
filed by other claimants before the commencement of the Act out- side India would naturally depend
upon the discretion of the court enquiring into the matter. That is why the proviso to section 3
makes the right of the Government of India to represent and act in place of the victims in such
proceed- ings subject to the permission of the court or authority where the proceedings are pending.
It is of course open to such court to permit the Central Government even to displace the claimants if
it is satisfied that the authority of the Act is sufficient to enable it to do so. In the present case it is
common ground that the proceedings before Judge Keenan were being prosecuted by the Central
Government along with various individual claimants. Not only did Judge Keenan permit the
association of the Government of India in these proceedings but the Government of India did have a
substan- tial voice in the course of those proceedings as well. Again section 4 mandates that,
notwithstanding anything contained in section 3, the Central Government, in repre- senting and
acting in place of any person in relation to any claim, shall have due regard to any matters which
such person may require to be urged with respect to his claim. It also stipulates that if such person
so desires, the Central Government shall permit, at the expense of such person, a legal practitioner
of his choice to be associated in the conduct of any suit or other proceeding relating to his claim. In
other words, though, perhaps, strictly speaking, under section 3 the Central Government can totally
exclude the victim himself or his legal practitioner from taking part in the proceedings (except in
pending suits outside India), section 4 keeps the substance of the rights of the victims in tact. It
enables, and indeed obliges, the Govern- ment to receive assistance from individual claimants to the
extent they are able to offer the same. If any of the vic- tims or their legal advisers have any specific
aspect which they would like to urge, the Central Government shall take it into account. Again if any
individual claimant at his own expense retains a legal practitioner of his own choice, such legal
practitioner will have to be associated with the Government in the conduct of any suit or proceeding
relating to his claim. Sections 3 and 4 thus combine together the interests of the weak, illiterate,
helpless and poor victims as well as the interests of those who could have managed for themselves,
even without the help of this enactment. The combination thus envisaged enables the Government
to fight the battle with the foreign adversary with the full aid and assistance of such of the victims or
their legal advisers as are in a position to offer any such assistance. Though section 3 denies the
claimants the benefit of being eo nominee parties in such suits or proceedings, section 4 preserves to
them substantially all that they can achieve by proceeding on their own. In other words, while
seeming to deprive the claimants of their right to take legal action on their own, it has preservedCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

those rights, to be exercised indirectly. A conjoint reading of sections 3 and 4 would, in our opinion,
therefore show that there has been no real total deprivation of the right of the claimants to enforce
their claim for damages in appropriate proceedings before any appropriate forum. There is only a
restriction of this right which, in the circumstances, is totally reasonable and justified. The validity
of the Act is, therefore, not liable to be challenged on this ground.
The next angle from which the validity of the provision is attacked is that the provision enabling the
Government to enter into a compromise is bad. The argument runs thus: The object of the
legislation can be furthered only if it per- mits the Government to prosecute the litigation more
effec- tively and not if it enables the Government to withdraw it or enter into a compromise.
According to them, the Act fails the impecunious victims in this vital aspect. The authority conferred
by the Act on the Government to enter into a settlement or compromise, it is said, amounts to an
absolute negation of the rights of the claimants to compensation and is capable of being so exercised
to render such rights totally valueless, as in fact, it is said, has happened.
It appears to us that this contention proceeds on a misapprehension. It is common knowledge that
any authority given to conduct a litigation cannot be effective unless it is accompanied by an
authority to withdraw or settle the same if the circumstances call for it. The vagaries of a litigation of
this magnitude and intricacy could not be fully anticipated. There were possibilities that the litiga-
tion may have to be fought out to the bitter finish. There were possibilities that the UCC might be
willing to ade- quately compensate the victims either on their own' or at the insistence of the
Government concerned. There was also the possibility, which had already been in evidence before
Judge Keenan, that the proceedings might ultimately have to end in a negotiated settlement. One
notices that in most of the mass disaster cases reported, proceedings finally end in a compromise if
only to avoid an indefinite prolongation of the agonies caused by such litigation. The legislation,
therefore, cannot be considered to be unreasonable merely because in addition to the right to
institute a suit or other proceedings it also empowers the Government to with- draw the proceedings
or enter into a compromise. Some misgivings were expressed, in the course of the hearing, of the
legislative wisdom (and, hence the validity) of entrusting the carriage of these proceedings and, in
particular, the power of settling it out of Court, to the Union of India. It was contended that the
union is itself a joint tort-feasor (sued as such by some of the victims) with an interest (adverse to
the victims) in keeping down the amount of compensation payable to the minimum so as to reduce
its own liability as a joint tort-feasor. It seems to us that this contention in misconceived. As pointed
out by Mukharji, C.J., the Union of India itself is one of the entities affected by the gas leak and has a
claim for com- pensation from the UCC quite independent of the other vic- tims. From this point of
view, it is in the same position as the other victims and, in the litigation with the UCC, it has every
interest in securing the maximum amount of compen- sation possible for itself and the other
victims. It is, therefore, the best agency in the circumstances that could be looked up to for fighting
the UCC on its own as well as on behalf of the victims. The suggestion that the Union is a joint
tort-lessor has been stoutly resisted by the learned Attorney General. But, even assuming that the
Union has some liability in the matter, we fail to see-how it can derive any benefit or advantage by
entering into a low settlement with the UCC. as is pointed out later in this judgment and by
Mukharji, C.J., the Act and Scheme thereunder have provided for an objective and quasi-judicial
determination of the amount of damages pay- able to the victims of the tragedy. There is no basis forCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

the fear expressed during the hearing that the officers of the Government may not be objective and
may try to cut down the amounts of compensation, so as not to exceed the amount received from the
UCC. It is common ground and, indeed, the learned Attorney General fairly conceded, that the
settle- ment with the UCC only puts an end to the claims against the UCC and UCIL and does not in
any way affect the victims' rights, if any, to proceed against the Union, the State of Madhya Pradesh
or the ministers and officers thereof, if so advised. If the Union and these officers are joint tort-
lessors, as alleged, the Union will not stand to gain by allowing the claims against the UCC to be
settled for a low figure. On the contrary it will be interested in settling the claims against the UCC at
as high a figure as possible so that its own liability as a joint tort-feasor (if made out) can be
correspondingly reduced. We are, therefore, unable to see any vitiating element in the legislation
insofar as it has entrusted the responsibility not only of carrying on but also of entering into a
settlement, if thought fit.
Nor is there basis for the contention that the Act enables a settlement to be arrived at without a
proper opportunity to the claimants to express their views on any proposals for settlement that may
be mooted. The right of the claimant under section 4 to put forward his suggestions or to be
represented by a legal practitioner to put forth his own views in the conduct of the suit or other
proceeding certainly extends to everything connected with the suit or other proceeding. If, in the
course of the proceedings there should arise any question of compromise or settlement, it is open to
the claimants to oppose the same and to urge the Central Government to have regard to specific
aspects m arriving at a settlement. Equally it is open to any claimant to employ a legal practitioner
to ventilate his opinions in regard to such proposals for settlement. The provisions of the Act, read
by themselves, therefore, guarantee a complete and full protection to the rights of the claimants in
every respect. Save only that they cannot file a suit themselves, their right to acquire redress has not
really been abridged by the provisions of the Act. Sections 3 and 4 of the Act properly read, in our
opinion, completely vindicate the objects and reasons which compelled Parliament to enact this
piece of legislation.
Far from abridging the rights of the claimants in any man- ner, these provisions are so worded as to
enable the Govern- ment to prosecute the litigation with the maximum amount of resources,
efficiency and competence at its command as well as with all the assistance and help that can be
extended to it by such of those litigants and claimants as are capable of playing more than a mere
passive rule in the litigations But then, it is contended, the victims have had no opportunity of
considering the settlement proposals mooted in this case before they were approved by the Court.
This aspect is dealt with later.
2. One of the contentions before us was that the UCC and UCIL are accountable to the public for the
damages caused by their industrial activities not only on a basis of strict liability but also on the
basis that the damages to be awarded against them should include an element of punitive liability
and that this has been lost sight of while approv- ing of the proposed settlement. Reference was
made in this context to M.C. Mehta's case (supra). Whether the settlement should have taken into
account this factor is, in the first place, a moot question. Mukharji, C.J. has pointed out--and we are
inclined to agree-that this is an "uncertain province of the law" and it is premature to say whether
this yard- stick has been, or will be, accepted in this country, not to speak of its internationalCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

acceptance which may be necessary should occasion arise for executing a decree based on such a
yardstick in another country. Secondly, whether the settle- ment took this into account and, if not,
whether it is bad for not having kept this basis in view are questions that touch the merits of the
settlement with which we are not concerned. So we feel we should express no opinion here on this
issue. It is too far-fetched, it seems to us, to con- tend that the provisions of the Act permitting the
Union of India to enter into a compromise should be struck down as unconstitutional because they
have been construed by the Union of India as enabling it to arrive at such a settle- ment.
The argument is that the Act confers a discretionary and enabling power in the Union to arrive at a
settlement but lays down no guidelines or indications as to the stage at which, or circumstances in
which, a settlement can be reached or the type of settlement that can be arrived at; the power
conferred should, therefore, be struck down as unguided, arbitrary and uncanalised. It is difficult to
accept this contention. The power to conduct a litigation, particularly in a case of this type, must, to
be effective, necessarily carry with it a power to settle it at any stage. It is impossible to provide
statutorily any detailed catalogue of the situations that would justify a settlement or the basis or
terms on which a settlement can be arrived at. The Act. moreover, cannot be said to have conferred
any unguided or arbitrary discretion to the Union in conducting proceedings under the Act.
Sufficient guidelines emerge from the Statement of Objects and Reasons of the Act which makes it
clear that the aim and purpose of the Act is to secure speedy and effective redress to the victims of
the gas leak and that all steps taken in pursuance of the Act should be for the implementation of the
object. Whether this object has been achieved by a particular settlement will be a different question
but it is altogether impossible to say that the Act itself is bad for the reason alleged. We, therefore,
think it necessary to clarify, for our part, that we are not called upon to express any view on the
observa- tions in Mehta's case and should not be understood as having done so.
3. Shri Shanti Bhushan, who supported the Union's stand as to the validity of the Act, however,
made his support conditional on reading into its provisions an obligation on the part of the Union to
make interim payments towards their maintenance and other needs consequent on the tragedy,
until the suits filed on their behalf ultimately yield tangible results. That a modern welfare State is
under an obligation to give succour and all kinds of assistance to people in distress cannot at all be
gainsaid. In point of fact also, as pointed out by the learned Chief Justice, the provisions of the Act
and scheme thereunder envisage interim payments to the victims; so, there is nothing objectionable
in this Act on this aspect. However, our learned brother has accept- ed the argument addressed by
Shri Shanti Bhushan which goes one step further viz. that the Act would be unconstitutional unless
this is read as "a major inarticulate promise" under- lying the Act. We doubt whether this extension
would be justified for the hypothesis underlying the argument is, in the words of Sri Shanti
Bhushan, that had the victims been left to fend for themselves, they would have had an "immedi- ate
and normal right of obtaining compensation from the Union Carbide" and, as the legislation has
vested their rights in this regard in the Union, the Act should be con- strued as creating an
obligation on the Central Government to provide interim relief. Though we would emphatically
reiterate that grant of interim relief to ameliorate the plight of its subjects in such a situation is a
matter of imperative obligation on the part of the State and not merely 'a matter of fundamental
human decency' as Judge Keenan put it, we think that such obligation flows from its character as a
welfare State and would exist irrespective of what the statute may or may not provide. In our viewCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

the validity of the Act does not depend upon its explicitly or implicitly providing for interim
payments. We say this for two reasons. In the first place, it was, and perhaps still is, a moot question
whether a plaintiff suing for damages in tort would be entitled to advance or interim payments in
anticipation of a decree. That was, indeed, the main point on which the interim orders in this case
were challenged before this Court and, in the context of the events that took place, remains
undecided. It may be men- tioned here that no decided case was brought to our notice in which
interim payment was ordered pending disposal of an action in tort in this country. May be there is a
strong case for ordering interim payments in such a case but, in the absence of full and detailed
consideration, it cannot be assumed that, left to themselves, the victims would have been entitled to
a "normal and immediate" right to such payment. Secondly, even assuming such right exists, all that
can be said is that the State, which put itself in the place of the victims, should have raised in the suit
a demand for such interim compensation--which it did--and that it should distribute among the
victims such interim compensation as it may receive from the defendants. To say that the Act would
be bad if it does not provide for payment of such compensa- tion by the Government irrespective of
what may happen in the suit is to impose on the State an obligation higher than what flows from its
being subrogated to the rights of the victims. As we agree that the Act and the scheme thereunder
envisage interim relief to the victims, the point is perhaps only academic. But we felt that we should
mention this as we are not in full agreement with Mukharji, C.J., on this aspect on the case.
4. The next important aspect on which much debate took place before us was regarding the validity
of the Act qua the procedure envisaged by it for a compromise or settle- ment. It was argued that if
the suit is considered as a representative suit no compromise or settlement would be possible
without notice in some appropriate manner to all the victims of the proposed settlement and an
opportunity to them to ventilate their views thereon (vide Order XXIII, r. 3B, C.P.C.). The argument
runs thus: S. 4 of the Act either incorporates the safeguards of these provisions in which event any
settlement effected without compliance with the spirit, if not the letter, of these provisions would be
ultra vires the Act. Or it does not, in which event, the provisions of S. 4 would be bad as making
possible an arbi- trary deprivation of the victims' rights being inconsistent with, and derogatory of,
the basic rules established by the ordinary Law of the land viz. the Code of Civil Procedure. We are
inclined to take the view that it is not possible to bring the suits brought under the Act within the
categories of representative action envisaged in the Code of Civil procedure. The Act deals with a
class of action which is sui generis and for which a special formula has been found and encapsuled
in S.
4. The Act divests the individual claimants of their right to sue and vests it in the Union. In relation
to suits in India, the Union is the sole plaintiff, none of the others are envisaged as plaintiffs or
respondents. The victims of the tragedy were so numerous that they were never defined at the stage
of filing the plaint nor do they need to be de- fined at the stage of a settlement. The litigation is car-
ried on by the State in its capacity, not exactly the same as but somewhat analogous to that of a
"parens patriae". In the case of a litigation by karta of a Hindu Undivided Family or by a guardian on
behalf of a ward, who is non-sui juris, for example, the junior members of the family or the wards,
are not to be consulted before entering into a set- tlement. In such cases, the Court acts as guardian
of such persons to scrutinise the settlement and satisfy itself that it is in the best interest of all
concerned. It is later discovered that there has been any fraud or collusion, it may be open to theCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

junior members of the family or the wards to call the karta or guardian to account but, barring such
a contingency, the settlement would be effective and binding. In the same way, the Union as "parens
patriae" would have been at liberty to enter into such settlement as it consid- ered best on its own
and seek the Court's approval there- fore.
However, realising that the litigation is truly fought on behalf and for the benefit of innumerable,
though not fully identified victims the Act has considered it necessary to assign a definite role to the
individual claimants and this is spelt out in S. 4. This section directs:
(i) that the union shall have due regard to any matters which such person may
require to be urged with respect to his claim; and
(ii) that the Union shaH, if such person so desires, permit at the expense of such
person, a legal practitioner of his choice to be associated in the conduct of any suit or
other proceeding relating to his claim.
This provision adequately safeguards the interests of indi- vidual victims. It enables each one of
them to bring to the notice of the Union any special features or circumstances which he would like to
urge in respect of any matter and if any such features are brought to its notice the Union is obliged
to take it into account. Again, the individual claimants are also at liberty to engage their own counsel
to associate with the State counsel in conducting the proceed- ings. If the suits in this case had
proceeded, in the normal course, either to the stage of a decree or even to one of settlement the
claimants could have kept themselves abreast of the developments and the statutory provisions
would have been more than adequate to ensure that the points of view of all the victims are
presented to the court. Even a settlement or compromise could not have been arrived at without the
court being apprised of the views or any of them who chose to do so. Advisedly, the statute has
provided that though the Union of India will be the dominus litis in the suit, the interests of all the
victims and their claims should be safeguarded by giving them a voice in the proceedings to the
extent indi- cated above. This provision of the statute is an adaptation of the principle of O.I.r. 8 and
of Or. XXIII r. 3 of the Code of Civil Procedure in its application to the suits governed by it and,
though the extent of participation allowed to the victims is somewhat differently enunciated in the
legislation, substantially speaking, it does incorporate the principles of natural justice to the extent
possible in the circumstances. The statute cannot, therefore, be fault- ed, as has been pointed out
earlier also, on the ground that it denies the victims an opportunity to present their views or places
them at any disadvantage in the matter of having an effective voice in the matter of settling the suit
by way of compromise.
The difficulty in this case has arisen, as we see it, because of a fortuitous circumstance viz. that the
talks of compromise were mooted and approved in the course of the hearing of an appeal from an
order for interim payments. Though compromise talks had been in the air right from the beginning
of this episode, it is said that there was an element of surprise when they were put forward in Court
in February, 1989. This is not quite correct. It has been pointed out that even when the issue
regarding the interim relief was debated in the courts below, attempts were made to settle the whole
litigation. The claimants were aware of this and they could--perhaps should--have anticipated thatCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

similar attempts would be made in this Court also. Though certain parties had been associated with
the conduct of the proceedings in the trial court--and the trial judge did handsomely acknowledge
their contribution to the proceed- ings--they were apparently not alert enough to keep a watch- ing
brief in the Supreme Court, may be under the impression that the appeal here was concerned only
with the quantum of interim relief. One set of parties was present in the Court but, apart from
praying that he should be forthwith paid a share in the amount that would be deposited in Court by
the UCC in pursuance of the settlement, no attempt appears to have been made to put forward a
contention that the amount of settlement was inade-
quate or had not taken into account certain relevant consid- erations. The Union also appears to
have been acting on the view that it could proceed ahead on its own both in its capacity as "parens
patraie" as well as in view of the powers of attorney held by it from a very large number of the
victims though the genuineness of this claim is now contested before us. There was a day's interval
between the enunciation of the terms of the settlement and their approv- al by the Court. Perhaps
the Court could have given some more publicity to the proposed settlement in the newspapers, radio
and television and also permitted some time to lapse before approving it, if only to see whether there
were any other points of view likely to emerge. Basically speaking, however, the Act has provided an
adequate opportunity to the victims to speak out and if they or the counsel engaged by some of them
in the trial court had kept in touch with the proceedings in this court, they could have most certainly
made themselves heard. If a feeling has gained ground that their voice has not been fully heard, the
fault was not with the statute but was rather due to the developments leading to the finalisation of
the settlement when the appeal against the interim order was being heard in this Court. One of the
points of view on which considerable emphasis was laid in the course of the arguments was that in a
case of this type the offending parties should be dealt with strictly under the criminal law of the
Land and that the inclusion, as part of the settlement, of a term requiring the withdrawal of the
criminal prosecutions launched was totally unwarranted and vitiates the settlement. It has been
pointed out by Mukharji, C.J. ,--and we agree--that the Act talks only of the civil liability of, and the
proceedings against, the UCC or UCIL or others for damages caused by the gas leak. It has nothing
to say about the criminal liability of any of the parties involved. Clearly, therefore, this part of the
settlement comprises a term which is outside the purview of the Act. The validity of the Act cannot,
there- fore, be impugned on the ground that it permits--and should not have permitted-the
withdrawal of criminal proceedings against the delinquents. Whether in arriving at the settle- ment,
this aspect could also have been taken into account and this term included in it, is a question
concerning the validity of the settlement. This is a question outside the terms of reference to us and
we, therefore, express no opinion in regard thereto.
5. A question was mooted before us as to whether the actual settlement--if not the statutory
provision--is liable to be set aside on the grounds that the principles of natu- ral justice have been
flagrantly violated. The merits of the settlement as such are not in issue before us and nothing we
say can or should fetter the hands of the Bench hearing a review petition which has already been
filed, from passing such orders thereon as it considers appropriate.
Our learned brother, however, has, while observing that the question referred to us is limited to the
validity of the Act alone and not the settlement, incidentally discussed this aspect of the case too. HeCharan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

has pointed out that justice has in fact been done and that all facts and aspects rele- vant for a
settlement have been considered. He has pointed out that the grievance of the petitioners that the
order of this Court did not give any basis for the settlement has since been sought to be met by the
order passed on 4th May, 1989 giving detailed reasons, This shows that the Court had applied its
mind fully to the terms of the settlement in the light of the data as well as all the circumstances
placed before it and had been satisfied that the settlement pro- posed was a fair and reasonable one
that could be approved. In actions of this type, the Court's approval is the true safety valve to
prevent unfair settlements and the fact is that the highest Court of the land has given thought to the
matter and seen it fit to place its seal of approval to the settlement. He has also pointed out that a
post-decisional hearing in a matter like this will not be of much avail. He has further pointed out
that a review petition has already been filed in the case and is listed for hearing. The Court has
already given an assurance in its order of May 4, 1989, that it will only be too glad to consider any
aspects that may have been overlooked in considering the terms of the settlement. Can it be said, in
the circumstances, that there has been a failure of justice which compels us to set aside the
settlement as totally violative of fundamental rights? Mukharji, C.J., has pointed out that the answer
to this question should be in the negative. It was urged that there is a feeling that the maxim:
"Justice must not only be done but must also appear to be done" has not been fully complied with
and that perhaps, if greater publicity had attended the hearing, many other facts and aspects could
have been high- lighted resulting in a higher settlement or no settlement at all. That feeling can be
fully ventilated and that deficien- cy can be adequately repaired, it has been pointed out by
Mukharji, C.J., in the hearing on the review petition pend- ing before this Court. Though we are
prima facie inclined to agree with him that there are good reasons why the settle- ment should not
be set aside on the ground that the princi- ples of natural justice have been violated, quite apart
from the practical complications that may arise as the result of such an order, we would not express
any final opinion on the validity of the settlement but would leave it open to be agitated, to the
extent permissible in law, in the review petition pending before this Court.
There is one more aspect which we may perhaps usefully refer to in this context. The scheme of the
Act is that on the one hand the Union of India pursues the litigiation against the UCC and the UCIL;
on the other all the victims of the tragedy are expected to file their claims before the prescribed
authority and have their claims for compensation determined by such authority. Certain infirmities
were pointed out on behalf of the petitioners in the statutory provisions enacted in this regard. Our
learned brother has dealt with these aspects and given appropriate directions to ensure that the
claims will be gone into by a quasi judicial authority (unfettered by executive prescriptions of the
amounts of compensation by categorising the nature of in- juries) with an appeal to an officer who
has judicial quali- fications. In this manner the scheme under the Act provides for a proper
determination of the compensation payable to the various claimants. Claims have already been filed
and these are being scrutinised and processed. A correct picture as to whether the amount of
compensation for which the claims have ben settled is meagre, adequate or excessive will emerge
only at that stage when all the claims have been processed and their aggregate is determined. In
these cir- cumstances, we feel that no useful purpose will be served by a post-decisional hearing on
the quantum of compensation to be considered adequate for settlement.Charan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

For these reasons, it would seem more correct and proper not to disturb the orders of 14-15
February, 1989 on the ground that the rules of natural justice have not been complied with,
particularly in view of the pendency of the review petition.
6. Before we conclude, we would like to add a few words on the state of the law of torts in this
country. Before we gained independence, on account of our close association with Great Britain, we
were governed by the common law principles. In the field of torts, under the common law of
England, no action could be laid by the dependants or heirs of a person whose death was brought
about by the tortious act of another on the maxim actio personalis moritur cum persona, although a
person injured by a similar act could claim damages for the wrong done to him. In England this
situation was remedied by the passing of the Fatal Accidents Act, 1846, popularly known as Lord
Campell's Act. Soon thereafter the Indian Legislature enacted the Fatal acci- dents Act, 1855. This
Act is fashioned on the lines of the English Act of 1846. Even though the English Act has undergone
a sub- stantial change, our law has remained static and seems a trifle archaic. The magnitude of the
gas leak disaster in which hundreds lost their lives and thousands were maimed, not to speak of the
damage to livestock, flora and fauna, business and property, is an eye opener. The nation must learn
a lesson from this traumatic experience and evolve safeguards atleast for the future. We are of the
view that the time is ripe to take a fresh look at the outdated cen- tury old legislation which is out of
tune with modern con- cepts.
While it may be a matter for scientists and technicians to find solutions to avoid such large scale
disasters, the law must provide an effective and speedy remedy to the victims of such torts. The
Fatal Accidents Act, on account of its limited and restrictive application, is hardly suited to meet
such a challenge. We are, therefore, of the opinion that the old antiquated Act should be drastically
amended or fresh legislation should be enacted which should, inter alia, contain appropriate
provisions in regard to the fol- lowing matters:
(i) The payment of a fixed minimum compensa-
tion on a "no-fault liability" basis (as under
the Motor Vehicles Act), pending final adjudi- cation of the claims by a prescribed
forum;
(ii) The creation of a special forum with specific power to grant interim relief in
appropriate cases;
(iii) The evolution of a procedure to be followed by such forum which will be
conducive to the expeditious determination of claims and avoid the high degree of
formalism that at- taches to proceedings in regular courts; and
(iv) A provision requiring industries and concerns engaged in hazardous activities to
take out compulsory insurance against third party risks.Charan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

In addition to what we have said above, we should like to say that the suggestion made by our
learned brother, K.N. Singh J., for the creation of an Industrial Disaster Fund (by whatever name
called) deserves serious consideration. We would also endorse his suggestion that the Central
Govern- ment will be well advised if, in future, it insists on certain safeguards before permitting a
transnational company to do business in this country. The necessity of such safe- guards, atleast in
the following two directions, is high- lighted in the present case:
(a) Shri Garg has alleged that the processes in the Bhopal Gas Plant were so much
shrouded in secrecy that neither the composition of the deadly gas that escaped nor
the proper anti-
dote therefore were known to anyone in this country with the result that the steps taken to combat
its effects were not only delayed but also totally inadequate and ineffective. It is necessary that this
type of situation should be avoided. The Government should therefore insist, when granting licence
to a transnational company to establish its indus- try here, on a right to be informed of the nature of
the processes involved so as to be able to take prompt action in the event of an accident.
(b) We have seen how the victims in this case have been considerably handicapped on account of the
fact that the immediate tort-feasor was the subsidiary of a multi-national with its Indian assets
totally inadequate to satisfy the claims arising out of the disaster. It is, therefore, necessary to
evolve, either by international consensus or by unilateral legislation, steps to overcome these
handicaps and to ensure (i) that foreign corporations seeking to establish an industry here, agree to
submit to the jurisdiction of the Courts in India in respect of actions for tortious acts in this country;
(ii) that the liability of such a corporation is not limited to such of its assets (or the assets of its
affiliates) as may be found in this country, but that the victims are able to reach out to the assets of
such concerns anywhere in the world; (iii) that any decree obtained in Indian Courts in compliance
with due process of law is capable of being executed against the foreign corpora- tion, its affiliates
and their assets without further procedural hurdles, in those other countries.
Our brother, K.N. Singh, J., has in this context dealt at some length with the United Nations Code of
Conduct for multi-national Corporations which awaits approval of various countries. We hope that
calamities like the one which this country has suffered will serve as catalysts to expedite the
acceptance of an international code on such matters in the near future.
With these observations, we agree with the order pro- posed by the learned Chief Justice.
G.N.                                         Petitions  dis-
posed of.Charan Lal Sahu Etc. Etc vs Union Of India And Ors on 22 December, 1989

