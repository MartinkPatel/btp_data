Bihar Street Vendors (Protection of livelihood and regulation of
Street Vending) Schemes 2017
BIHAR
India
Bihar Street Vendors (Protection of livelihood and
regulation of Street Vending) Schemes 2017
Rule
BIHAR-STREET-VENDORS-PROTECTION-OF-LIVELIHOOD-AND-REGULATION-OF-STREET-VENDING-SCHEMES-2017
of 2017
Published on 15 February 2017• 
Commenced on 15 February 2017• 
[This is the version of this document from 15 February 2017.]• 
[Note: The original publication document is not available and this content could not be
verified.]• 
Bihar Street Vendors (Protection of livelihood and regulation of Street Vending) Schemes
2017Published vide Notification No. 04/SV(NULM)-04/2015-415/UD & HD, dated 15.2.2017Last
Updated 7th February, 2020No. 04/SV(NULM)-04/2015-415/UD & HD. - In exercise of the powers
conferred by Section 38 of the Street Vendors (Protection of Livelihood and Regulation of Street
Vending) Act, 2014 (Central Act 7 of 2014), the State Government after consultation with the Urban
Local Bodies and Town Vending Committees do hereby make the following Scheme for the purpose
of the said Act, namely :-Chapter - I Preliminary
1. Short title and commencement.
(1)This Scheme may be called The Street Vendors (Protection of Livelihood and Regulation of Street
Vending) Scheme-2017.(2)It shall come into force on such date, as State Government may, by
notification, fixed and different dates may be fixed different Municipalities.
2. Definitions.
(1)In this Scheme, unless the context otherwise requires:-(a)"Act" means the Street
Vendors(Protection of Livelihood and Regulation of Street Vending) Act, 2014( Central Act 7 of
2014);(b)"appropriate Government" means the Government of Bihar;(c)"local authority" means a
Municipal Corporation or a Municipal Council or a Nagar Panchayat, by whatever name called, [or
the Cantonment Board, or as the case may be, a civil area committee appointed under section 47 of
the Cantonment Act, 2006 [or such other body entitled to function as a local authority in any city orBihar Street Vendors (Protection of livelihood and regulation of Street Vending) Schemes 2017

town to provide civic services and regulate street vending in that city or town;(d)"notification"
means a notification published in the Official Gazette and the term "notify" shall be constructed
accordingly;(e)"street vendor" means a person engaged in vending of articles, goods, wares, food
items or merchandise of everyday use or offering services to the general public, in street, lane, side
walk, footpath, pavement, public park, or any other public place or private area, from a temporary
built up structure or by moving from place to place and includes hawker, peddler, squatter and all
other synonymous term which may be local or region specific; and the words "street vending" with
their grammatical variations and cognate expressions, shall be constructed
accordingly;(f)"stationary vendors" means street vendors who carry out vending Activities on
regular basis at a specific location;(g)"mobile vendors" means street vendors who carry out vending
Activities in designated area by moving from one place to another place vending their goods and
services;(h)"festive market" means a market where sellers and buyers have traditionally congregated
for the sale and purchase of products or services during festival season of the city or town and has
been determined as such by the local authority on the recommendations of the Town Vending
Committee;(i)"heritage market" means a market which has completed more than fifty years in one
place where sellers and buyers have traditionally congregated for the sale and purchase of products
or services and has been determined as such by the local authority on the recommendations of the
Town Vending Committee;(j)"natural Market" means a market where sellers and buyers have
traditionally congregated for the sale and purchase of products or services and has been determined
as such by the local authority on the recommendations of the Town Vending Committee;(k)"niche
market" means a market where sellers and buyers have traditionally congregated for the sale and
purchase of niche products or services and has been determined as such by the local authority on the
recommendations of the Town Vending Committee;(l)"night bazaar" means a bazaar where sellers
and buyers have traditionally congregated for the sale and purchase of products or services after
evening i.e. during night and has been determined as such by the local authority on the
recommendations of the Town Vending Committee;(m)"seasonal market" means a market where
sellers and buyers have traditionally congregated for the sale and purchase of products or services
during specific seasons and has been determined as such by the local authority on the
recommendations of the Town Vending Committee;(n)"weekly market" means a market where
sellers and buyers have weekly congregated for the sale and purchase of products or services and has
been determined as such by the local authority on the recommendations of the Town Vending
Committee;(o)"Town Vending Committee" means the body constituted by the appropriate
Government under Section 22 of the Act;(p)"vending zone" means an area or a place or a location
designated as such by the local authority, on the recommendations of the Town Vending Committee,
for the specific use by street vendors for the street vending and includes footpath, side walk,
pavement, embankment, portions of a street, waiting area for public or any such place considered
suitable for vending Activities and providing services to the general public.(q)"Plan" means the Plan
made under First Schedule of Section 22 of the Act;(r)"planning authority" means an Urban
Development Authority or any other authority in any city or town designated by the appropriate
Government as responsible for regulating the land use by defining the precise extent of areas for any
particular Activity in the master plan or development plan or zonal plan or layout plan or any other
spatial plan under the Town and Country Planning Act or the Urban Development Act or the
Municipal Act, which is legally enforceable for the time being as the case may be;(s)"public purpose"
includes in the context of the Act(i) widening of roads, streets, lanes;(ii) shifting the alignment ofBihar Street Vendors (Protection of livelihood and regulation of Street Vending) Schemes 2017

roads, streets, lanes;(iii) erecting flyovers with or without clover leaves and slip down roads; (iv)
erecting underpasses; (v) development of land owned by public authorities for some public projects;
(vi)laying of water, or sewer pipe lines;(vii) erecting intermediate pumping stations for the services;
(viii) any project related with public transport like BRTS, Metro, etc.; (ix) erection of Economically
Weaker Section(EWS) Housing; (x) Creation Parks, Gardens and Recreational Area; (xi)
Conservation of any eco system resource in that area and (xii) Any other development work taken by
the local authority, the beneficiary of which will be the community at large.(t)"Scheme" means the
Scheme made under Second Schedule of section 38 of the Act;(u)"Section" means section of the
Act;(v)"holding capacity" means the maximum number of street vendors who can be accommodated
in any vending zone and has been determined as such by the local authority on the
recommendations of the Town Vending Committee;(w)"Grievance Redressal Committee" means a
committee constituted by the Government of Bihar under sub- section (1) of section 20 of the
Act;(2)Words and expressions defined in the Act and used but not defined in this scheme shall have
the same meaning as respectively assigned to them in the Act.Chapter -II Manner of Conducting
Survey
3. Process of Survey.
(1)The Town Vending Committee shall conduct the survey itself or go it done by any suitable
agency.(2)Adequate publicity of the proposal shall be given in the following manner:-(i)On its
websites(ii)by publishing in any two prominent local newspapers published in the local language of
the area(iii)by placing it on the notice board of the office, and(iv)by placing a copy in any
conspicuous place in the local market within the jurisdiction of the local authority(3)Camps may be
organized for the survey of street vendors after prior information
4.
The survey outcome shall be available in the digital format
5.
In the survey report the street vending activity carried on from the carriage way shall be specifically
mentioned and marked on the map. Similarly, mode of vending shall also be clearly indicated.
Manner of vending may be any of the following:-(1)Push cart/ motorized vehicle(2)Floor
spread(3)Rack and hanging frame mode
6.
Subject to the provisions of the Act and the provisions contained in the Scheme, the Town Vending
Committee shall, as far as practicable, ensure that all existing Street Vendors identified in the survey
conducted under section-3 are accommodated in the vending zone.Chapter - III Issue of Identity
Card and Certificate of VendingBihar Street Vendors (Protection of livelihood and regulation of Street Vending) Schemes 2017

7. The period within which Identity Card and certificate of vending shall be
issued to the street vendors identified under survey.
- The street vendor identified by the survey shall be issued Identity card and certificate of vending
within a maximum period of six [6] months' time from the date of survey.
8. The terms and conditions subject to which Identity card and certificate of
vending may be issued to a street vendor including to those persons who
wish to engage on street vending during the intervening period of two
surveys.
- The criterion under which Identity Card and certificate of vending to street vendors will be
issued:-(i)Name shall include in the survey carried out by the TVC.(ii)shall be street vendor only and
will not be engaged in any other occupation.(iii)No other parallel vending site in any other place by
the same persons. However his/her spouse and any child above 14 years of age can have a different
vending site.(iv)shall engage the vending by him or her though family or other people (if he/she has
completed 14 years) can be involved.(v)Any street vendor who has completed the age of 14 years of
age.(vi)New Street vendor who wish to carry on street vending during the intervening period of two
surveys, has to apply through Town Vending Committee for the Identity card and vending
certificate.
9. The form and manner in which the certificate of vending shall be issued to
a street vendor.
- (i) Photo of the vendor-(ii)Name of the vendor-(iii)Name of the spouse or dependent child if
involved in vending with the vendor-(iv)Age and Sex of the person/s whose photo
appears-(v)Address of residence-(vi)Category of Vending (Mobile/Stationary/Natural/Weekly
etc.)-(vii)Name of Vending Place (whether it is historical place, park, market, in front of
school/college/hospital/bus stand or malls etc.)-(viii)Name of the Municipal body-(ix)Date of
Issuing Vending Certificate-(x)Validity (Since the law provides for survey every five year, the
certificate of vending should also be issued for five year)-(xi)Unique Registration Number-
10. The form and manner of issuing identity cards to street vendors.
- (i) Name of the vendor-(ii)Age-(iii)Sex-(iv)Address of residence-(v)Address of the vending
site-(vi)Photo-(vii)Phone Number-(viii)Category of vending-(ix)Municipal ward or zone
number-(x)Police station-(xi)Validity period-(xii)Signature of the authority with seal-
11. The period of validity of Identity card and certificate of vending.
- The Identity card and vending certificate shall be renewed after every five [5] years through a
simple process of paying the fees. The deposit of fees and issue of receipt shall be considered to beBihar Street Vendors (Protection of livelihood and regulation of Street Vending) Schemes 2017

adequate proof of the renewal of vending certificate.Chapter -IV Renewal, Suspension and
Cancellation of Certificate of Vending
12. The period for which and the manner in which a certificate of vending
may be renewed and the fees for such renewal.
(1)The vending certificate may be renewed after every five [5] years .It shall be a simple process of
submitting the fees and renewing the vending certificate.The Town Vending Committee will put up
the list of the vendors whose due dates for renewal falls within a period of two months. In the said
paper the amount as well as the places or institution where it can be paid can be indicated.(2)TVC
will publish a list of defaulter street vendors who has failed to pay the renewal fees of vending
certificate.(3)The renewable fees of the vending certificate shall not be less than Rs.500.(4)1 (One)
month's period will be granted for the payment of renewal fees without any penalty.(5)In case of
loosing Identity Cards or Certificate of vending, TVC can issue the duplicate Identity card or
Certificate of vending with the cost of Rs. 50/ to street vendors.
13. The manner in which the certificate of vending may be suspended or
cancelled.
- The TVC shall impose fine and a warning on the street vendor found guilty of breach of conditions
laid down in the vending certificate. The following will be the breach of conditions:-(i)If he/she
caring out vending squatting/ hawking in the area/market other than mentioned in the vending
license.(ii)Misrepresented the age (minimum age is 14 years) for eligibility to get vending
certificate;(iii)If the area allotted has been increased or unauthorized occupying additional
area.(iv)If no registration has be done under FSSAI in case of food vendors.(v)If any permanent
structure has been constructed on the allotted place.(vi)If certificate of vending is sold or leased out
to any other person.(vii)If the vending certificate has not been renewed after the prescribed period is
over.(viii)Any street vendor who has employed any child below 14 years of age [under Child Labour
(Prohibition and Bye-laws [Regulation]) Act, 2005 will be given a warning by the TVC. But failing
that their vending certificate will be cancelled.(ix)Any street vendor who is guilty of misbehaviour
with women vendor will be given a warning based on the written complaint filed by the
aggrieved.(x)The TVC should make a committee [Headed by a woman official] to take into account
the Domestic Violence Act, 2005, Harassment at workplace (Prevention, Prohibition and redressal)
Act-2013 and also Indian Penal Code to protect women at work place.Chapter - V Categories of
Street Vendors and Fees
14. The categories of street vendors.
- The vendors can also be categorized as :(i)Stationary;(ii)Mobile;(iii)Any other which may the state
Govt. provide for.Bihar Street Vendors (Protection of livelihood and regulation of Street Vending) Schemes 2017

15. The other categories of persons for preference for issue of Identity card
and certificate of vending.
- TVC will accord priority for senior citizen, physically challenged, single mothers and widows.
16. The vending fees to be paid on the basis of category of street vending,
which may be different for different cities.
- The vending fees shall be according to the category of the street vendors and the status of the
market.[Explanation. - Income potential differs from area to area. High footfall areas offer high
vending opportunity compared to lean footfall areas. Therefore it is only correct to fix the fees at
different rates for different categories of vending zones. Similar will be the arguments for varied
rates for cities and towns of different categories.]TVC shall have to fix fees/levies depending on the
footfall of the area but fees shall be minimum Rs.150 and maximum Rs.1500 per month. Every year
a minimum 10% increase shall be imposed. Local authority can collect vending fee annually if it
deems fit.
17. The manner of collecting, through banks, counters of local authority and
counters of Town Vending Committee, vending fees, maintenance charges
and penalties for registration, use of parking space for mobile stalls and
availing of civic services.
- Every TVC will have a bank account and street vendors will deposit the money per month or year
into that account along with the details in the prescribed form. An annual audit of the account will
be carried out by the TVC. The local authority concerned is free to make its own any alternative
arrangement for collection for TVC.Chapter - VI Relocation and Eviction of Street Vendors
18. The public purposes for which a street vendor may be relocated and the
manner of relocating street vendor.
(1)Any project of public purpose, requiring temporary or permanent shifting of the street vendors in
the project related area, the concern authorities shall consider following two points for
relocation:(i)During the time of construction/development the street vendors may be adjusted in a
nearby place temporarily or permanently.(ii)After completion of the project, the street vendors may
be adjusted in the same place of public purpose area for vending to the extent possible but it is not
compulsory/mandatory.(2)Rehabilitation of street vendors under any public purpose would require
taking of the following steps:-(a)Give an estimate of footfall status in an area where from the
vendors are to be shifted.(b)Total number of vendors to be shifted.(c)Footfall status of the
alternative sites.(d)Carrying capacity of the alternative sites.(e)Likely availability of vending space
after the project is completed.(f)Temporary allotment of sites for shifting the vendors may be done
by lots.(g)In case number of the vendors in the original site is more than the number which could be
accommodated after the project is completed, allotment by lot can be adopted.(h)The vendors whoBihar Street Vendors (Protection of livelihood and regulation of Street Vending) Schemes 2017

were carrying on business from a government land can either be placed in a plot owned by the
public authority or can be organized on the road depending on the availability.
19. The manner of evicting a street vendor.
(1)TVC should bring in its agenda and discuss the issue of eviction of street vendors 2 months prior
to the issuance of 1 month notice of eviction, so that a survey can be conducted to identify an equally
vending site for the street vendors(2)The 1 month written notice should be served via registered post
prior eviction in the name of street vendor. It can be served personally also.(3)In case registered
post comes back undelivered, the said notice should be posted on the area where from he is carrying
on his vending. That should be considered as the service of the notice.
20. The following shall be the manner of giving notice for eviction of a street
vendor.
(1)One month notice prior eviction under Section 18 of the Act.(2)The notice of eviction should be in
the name of the street vendor who is getting evicted via registered post or personally.
21. The manner of evicting a street vendor physically on failure to evict.
(1)Under Section 18 of the Act the street vendor who fails to move out on the expiry of the eviction
notice period shall be liable to pay for everyday default.(2)The default amount or the penalty
payable by the street vendor may extend up to Rs. 250 only. However, the penalty fees will not
exceed the value of the goods seized.Chapter - VII Seizure of Goods
22. The manner of seizure of goods by the local authority, including
preparation and issue of list of goods seized.
- Under Section-19 of the Act, following steps may be followed with regard to seizure of
goods:(i)Only the authorized person from the local authority will conduct seizure of goods.(ii)The
list of goods seized will be made by the concerned authority and the same will be duly signed by the
concerned authority.(iii)The street vendor, whose goods are seized, will be given proper receipt by
the authority.
23. The manner of reclaiming seized goods by the street vendors and the
fees for the same.
(1)Under Section 19(2) the local authority may release the perishable seized goods same day of the
such seizure and in case of non-perishable goods within 2 working days.(2)The fees to be paid by the
street vendor for reclaiming the goods may not exceed the value of the total seized goods of the
vendor.(3)In case of vending without certificate then the charge should not exceed Rs. 500/- for
reclaiming seized goods(4)In case of perishable goods, the vendor may be given option to take the
goods back immediately by paying necessary penalty or within the working period in the next 24Bihar Street Vendors (Protection of livelihood and regulation of Street Vending) Schemes 2017

hours.Chapter - VIII Social Audit
24. The form and the manner to carry out social audit of the Activities of
Town Vending Committee and maintenance of records.
- Every TVC shall constitute a three member unit for the purpose of carrying out social audit under
Section 26(3). The social audit unit shall be an independent body.(1)The social audit unit shall
consist of the following:-(a)An eminent Academician in the field of Sociology(b)An eminent Social
Activist(c)A Retired AdministratorSupporting adequate Secretariat Staff with office space and
equipment should be provided by the local authority(2)The social audit shall be carried out at least
once in three years. The schedule for conduct of the social audit shall be determined at an
appropriate time(3)The TVC shall provide details of all relevant information, at least a fortnight
before the social audit process commences. This shall include the following:-(a)Status of
implementation of the Act and the Scheme for Street Vendors.(b)A record of the minutes of the
meetings of the TVC conducted in those years.(c)Record of all registered street vendors.(d)Records
of appeals made before the local authority under Section 11 of the Act.(e)Record of all
grievances/disputes brought before the Grievance Redressal Committee under Section 20 of the
Act.(f)Record of the total number and details of evictions and confiscation of goods and relocation of
street vendors taken place in those years.(g)Records of social audit reports, if any, taken place
previously.(4)The social audit unit shall conduct meetings and focused group discussions with street
vendors on various aspects of the implementation of the Act and the Scheme.(5)The social audit unit
shall record in writing grievances of street vendors on any issue faced by them.(6)At the culmination
of the social audit process, the unit shall record its findings in writing.(7)The social audit unit shall
hold a social audit public meeting at the TVC office. TVC members and representatives of the local
authority shall attend the meeting. Street vendors of the particular area and other persons from the
public may participate in the meeting. The social audit unit shall read out its findings at the meeting.
Street vendors shall be encouraged to testify and the TVC shall respond to each of the issues
identified in the social audit by giving clarification and/or explanation to the affected party and the
public as to why a certain action was taken or not taken.(8)The social audit unit shall give adequate
notice of the social audit public meeting by a public notice.(9)The local authority shall on each
finding of the social audit in cases of gaps, lapses or deviations fix responsibility and shall take
immediate corrective or disciplinary action. In case of a dispute, an administrative enquiry shall be
conducted by the local authority and action taken accordingly in the shortest time possible and in
any case not later than a month.(10)The statutory requirement of conducting social audit shall not
preclude any independent initiative to carry out normal audit of accounts.(11)Social audit reports
submitted in this process shall form part of the record and shall be responded to by the TVC. Where
shortcomings are found immediate action shall be taken as per these rules. The social audit report
as well as the action taken report shall form part of the record and shall be public
information.(12)The budget for conducting social audit shall be allocated from amongst the
administrative cost allowed for TVC.Chapter - IX MiscellaneousBihar Street Vendors (Protection of livelihood and regulation of Street Vending) Schemes 2017

25. The conditions under which private places may be designated as
restriction-free-vending zones, restricted - vending zones and no-vending
zones.
- Where the local authority decides to declare any private land as the vending zone, it shall take into
consideration the possibility of offering compensation in form of additional floor space Index (FSI)
or Floor Area Ratio (FAR) than prevailing in that area or Transferrable Development rights (TDR)
in case the General Development Control Regulations (DGCR) of the local authority has got the
provisions of it. The street vendors are to be accommodated in the ground level only.
26. The terms and conditions for street vending including norms to be
observed for up keeping public health and hygiene.
(1)The Local Authority of the concerned area will provide these vendors a proper place to dispose off
their waste materials in order to maintain a hygienic environment.(2)The street vendors will use
proper covered dustbins to dispose off the waste materials. The used water will also be disposed off
in a covered container.(3)The Local Authority will ensure and provide the street vendors clean and
fresh water along with street light facility wherever it is possible.(4)Attempt may be made to provide
clean and properly constructed toilets with water and electricity facility in order to maintain public
health and hygiene near the street vending strips.(5)Every street vendor will have service record
book and TVC only can/ will access that. Based on that TVC can award prize/impose fine upon the
vendor.
27. The designation of State Nodal Officer for co-ordination of all matters
relating to street vending at the state level.
(1)The designated Nodal Officer should not be below the Joint Secretary level.(2)The nodal officer
shall have at least a half yearly meeting with the Local Authorities in order to get himself acquainted
with various field level issues.(3)The nodal officer may have the feedback forms from the street
vendors about the problems faced by them.
28. The manner of maintenance of proper records and other documents by
the Town Vending Committee, Local Authority, planning authority and state
nodal officer in respect of street vendors.
(1)On -line software will be developed by the state governments for keeping the records of the street
vendors.(2)The local authority must enter the data of the surveyed street vendors through online
process.(3)The certificate of vending and identity card must be on-line generated.Bihar Street Vendors (Protection of livelihood and regulation of Street Vending) Schemes 2017

29. The manner of carrying out vending Activities on time-sharing basis.
(1)The TVC will determine it depending on the market needs.(2)Women vendors will not be
discriminated while allotting time - sharing vending Activities.
30. The principles for determining of vending zones as
restriction-free-vending zones, restricted-vending zones and no- vending
zones.
(1)An intensity of foot fall, Road width and Density of the vehicular and pedestrian movement shall
be the cornerstone for deciding vending and no vending zone. There shall be no restricted free
vending zones in the city and no vending zone should be very minimal. The TVC shall decide the
particular street or market as vending zone or no vending zone as specified below and accordingly
the space should be allotted.(2)There shall not be any totally restriction- free-vending zones in the
city. Carrying capacity of an area would put up the ultimate limit on the number of street vendors
which can be positioned in any area. However, there shall not be any restriction on mobile vending
in this area if vendors continuously move without affecting traffic and commuter movements. In
such cases the TVC has to decide the total number of such mobile vendors can be accommodate after
taking into account the area of significant footfall and 1/3rd of the holding capacity of the area.
Otherwise there is every chance of mobile vending itself creating problem for the traffic movement,
as the mobile vending invariably takes place from the carriage way.(3)Restricted vending zones will
be linked with the road width in the following manner:-(a)There shall not be any stationary street
vending on a road having width less than 3.5 meters.(b)There shall not be any stationary street
vending on a road having width between 3.5 meters to 6 meters. However, street vending shall be
allowed if such road is declared as no vehicular road. In such cases, the street vending shall be
restricted to 2.0 meter.(c)There shall not be any stationary street vending on a road having width
between 6 meters to 9 meters. However, street vending shall be allowed if such road is declared one
way vehicular road.(d)There shall be only one side stationary street vending on a road having width
between 12 meters to 24 meters while both side stationary vending shall be allowed on a road having
road width of 30 meters and above.(e)Number of street vendors shall be decided by considering
holding capacity of each designated vending area on such a road.(f)Such stationary vending shall be
allowed after taking the clearance from traffic police regarding the smooth vehicular and pedestrian
movement. If required, road side parking shall be banned in such area where street vending is
allowed.(g)Mobile vending shall be allowed on such road looking to the traffic and pedestrian
movement.(h)A suggestive road design is provided in the annexure appended to the scheme(4)The
following shall be no vending zone.-The Town Vending Committee may decide the distance to be
kept free from Street Vending near the important institutions like Secretariat and District
Collectorate, Offices of the District Panchayat, Municipal Corporation, Municipality, Nagar
Panchayat, Court, Cantonment Board and State Archaeological Monuments attracting a high
footfall, any crossing of two or more roads on all sides or both sides of the railway crossing and any
declared heritage structure by the local authority at its discretion taking into account the specifics of
the area of concerned.Bihar Street Vendors (Protection of livelihood and regulation of Street Vending) Schemes 2017

31. The principles for determining holding capacity of vending zones and the
manner of undertaking comprehensive census and survey.
(1)Under section 3 of the Act 2.5% of the population of street vendors of a ward/ zone will be
accommodated as per the holding capacity.(2)The holding capacity of a vending zone will be
according to the vending site divided by the total area of the vending area.(3)For Areas to be allotted
to individual vendors Criterion may be kept by the TVC as follows:-(i)A maximum of 2 sq. mts area
as 'vending area' shall be provided to each vendor/hawker with dimension of 1.6 meter x 1.2
meter.(ii)Passage of 1.0 meter width in front of stalls/ push carts shall be reserved as 'extension' for
consumers/ users to stand or buy goods.(iii)A walkway/footpath of 1.0/2.0 meters width shall be
provided for pedestrians, in front of extension space depending on the road width.(iv)In no case, the
carriageway shall be allowed to be used for street vending.(v)If the width of road permits, street
vending may be allowed on both sides of the road.(vi)No vending Activity shall be allowed at a
distance of 50 meters from any junction/exit/entry of road or the railway crossing.
32. Criteria of relocation.
(1)Relocation will be avoided as far as possible, unless there is clear and urgent need for the land in
question;(2)Affected vendors or their representatives shall be involved in planning and
implementation of the rehabilitation project;(3)The TVC shall engage in the dialogues with the
representatives of the markets.(4)Mutually agreed place for relocation should be considered under
the implementation of the rehabilitation project.(5)Affected vendors shall be relocated so as to
improve their livelihoods and standards of living or at least to restore them, in real terms to
pre-evicted levels;(6)Livelihood opportunities created by new infrastructure development projects
may try to accommodate the displaced vendors so that they can make use of the livelihood
opportunities created by the new infrastructure;(7)Loss of assets shall be avoided;(8)Any transfer of
title or other interest in land shall not affect the rights of street vendors on such land, and any
relocation consequent upon such a transfer shall be done in accordance with the provisions of this
Act;(9)Any Natural markets where street vendors have conducted business for over fifty years shall
be declared as heritage markets, and the street vendors in such markets shall not be
relocated;(10)The Municipal body shall prepare a list of such markets and declare them as "Heritage
Markets". The Municipal bodies in collaboration with the tourism department shall promote such
markets as tourist markets by incorporating such elements as may bring in local flavor in that
market.AnnexureRoad Designing With Street Vending Space(in meters)
Sl.
No.Width of Road (in
meters)FootpathStreet Vending
SpaceService
RoadCycle
TrackCarriagewayCentral
verge
1 3.5 0.0 0.0 0.0 0.0 0.0 0.0
 0.0 2.0 0.0 0.0 0.0 0.0
2 6.0 0.0 0.0 0.0 0.0 0.0 0.0
 0.0 2.0 0.0 0.0 0.0 0.0
3 9.0 1.0 0.0 0.0 0.0 3.5 0.0Bihar Street Vendors (Protection of livelihood and regulation of Street Vending) Schemes 2017

 1.0 3.0 0.0 0.0 0.0 0.5
4 12.0 1.0 3.0 0.0 0.0 3.5 0.0
5 15.0 1.0 3.0 0.0 0.0 5.0 0.0
6 18.0 1.0 3.0 0.0 0.0 6.0 1.0
7 24.0 1.5 3.0 0.0 0.0 8.5 1.0
8 30.0 1.5 3.0 0.0 1.0 9.0 1.0
9 36.0 2.0 3.0 0.0 1.5 11.0 1.0
10 40.0 2.0 3.0 0.0 1.5 13.0 1.0
11 60.0 3.0 4.0 5.0 2.0 15.0 2.0
Sl.
No.CarriagewayCycle
TrackService
RoadStreet vending
spaceFootpathVending
statusConditionally
allowed
1 0.0 0.0 0.0 0.0 0.0 Not allowed  
0.0 0.0 0.0 0.0 0.0 AllowedNo vehicular
area
2 0.0 0.0 0.0 0.0 0.0 Not allowed  
0.0 0.0 0.0 0.0 0.0 AllowedNo vehicular
area
3 3.5 0.0 0.0 0.0 1.0 Not allowed  
3.5 0.0 0.0 0.0 1.0 Allowed One way road
4 3.5 0.0 0.0 0.0 1.0 Allowed One side
5 5.0 0.0 0.0 0.0 1.0 Allowed One side
6 6.0 0.0 0.0 0.0 1.0 Allowed One side
7 8.5 0.0 0.0 0.0 1.5 Allowed One side
8 9.0 1.0 0.0 3.0 1.5 Allowed Both sides
9 11.0 1.5 0.0 3.0 2.0 Allowed Both sides
10 13.0 1.5 0.0 3.0 2.0 Allowed Both sides
11 15.0 2.0 5.0 4.0 3.0 Allowed Both sides
Note. - These calculations are subject to approval of traffic division for carrying capacity of vehicular
traffic.For two lane traffic minimum 7 meters is required for carrying traffic.Minimum area
available for street vending - 3 meters.Minimum space requirement for pedestrian movements - 1.0
meters.Bihar Street Vendors (Protection of livelihood and regulation of Street Vending) Schemes 2017

