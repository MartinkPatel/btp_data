Devendra Rameshchandra Jain vs The State Of Maharashtra
And Others on 15 April, 2024
Author: Mangesh S. Patil
Bench: Mangesh S. Patil, R.G. Avachat
                                        1                     Cri. Appln. 2562-2019-FB-Ref
          IN THE HIGH COURT OF JUDICATURE AT BOMBAY
                      BENCH AT AURANGABAD
                 CRIMINAL APPLICATION NO. 2562 OF 2019
(AWADHESH KUMAR PARASNATH PATHAK V. THE STATE OF MAHARASHTRA AND ANOTHER)
                                 AND
                 CRIMINAL APPLICATION NO. 1987 OF 2019
    (JAYESH S/O. AMBADAS DUDEKAR VS. THE STATE OF MAHARASHTRA AND OTHERS)
                 CRIMINAL APPLICATION NO. 1988 OF 2019
     (DEVENDRA RAMCHANDRA JAIN VS. THE STATE OF MAHARASHTRA AND OTHERS)
                 CRIMINAL WRIT PETITION NO. 947 OF 2019
       (ARUN S/O SHRIRAM TIDKE VS. THE STATE OF MAHARASHTRA AND ANOTHER)
                                      AND
                              A.C.B. NO. 58 OF 2019
  (GRIND MASTER MACHINES PVT. LTD. VS. THE STATE OF MAHARASHTRA AND OTHERS)
                                                ...
               Mr. P.P. Uttarwar, Advocate for applicant in Cr.Appln. 2562/2019
                        PP for the respondent - State : Mr. A.B. Girase
           Mr. Bharat Chug i/b. Mr. Tapan K. Sant, Advocate for respondent no. 2
         Mr. R.F. Totala, Advocate along with Mr. Rahul Totala, Ms. Riya M. Jariwal,
Mr. Swapnil Lohiya, Mr. Ganesh S. Yada, Mr. Vedant S. Kabra i/b. Mr. R.A. Karwa, Advocate
for applicant in ACB/58/2019 and advocate for respondent no. 3 in Cr.Appln 1987/2019 and
             1988/2019 and Advocate for respondent no. 2 in Cr. W.P./947/2019
Mr. Abhaykumar D. Ostwal, Advocate along with Mr. P.M. Salunke, Mr. V.L. Bhange, Mr. S.S.
    Munit, Mr. R.N. Patil, Advocate for respondent no. 2 in ACB/58/2019 and advocate for
                   applicant in Cr. Application no. 1987/2019 and 1988/2019
               Mr. Kiran Jadhav, Advocate for respondent no. 3 in ACB/58/2019
            Mr. Ajit Gaikwad Patil, Advocate for respondent no. 4 in ACB/58/2019
                                            ...
                      CORAM                       : MANGESH S. PATIL,
                                                    R.G. AVACHAT &Devendra Rameshchandra Jain vs The State Of Maharashtra And Others on 15 April, 2024

                                                    SHAILESH P. BRAHME, JJJ.
                      RESERVED ON   : 23 FEBRUARY 2024
                      PRONOUNCED ON : 15 APRIL 2024
JUDGMENT (MANGESH S. PATIL, J.) :
We have heard both the sides extensively.
2 Cri. Appln. 2562-2019-FB-Ref
2. In view of conflict between a division bench which decided Gagan Harsh Sharma Vs. State of
Maharashtra and others; (2019) Cri.L.J. 1398 and a division bench dealing with Awadhesh Kumar
Parasnath Pathak Vs. The State of Maharashtra and another and connected matters (Criminal
Application 2562 of 2019, Aurangabad Bench - order dated 26-02-2020), the latter being unable to
concur with the former, following questions have been referred to us for answers :
1) Whether Section 43 read with Section 66 of I.T. Act covers the cases:-
a) Involving the obtaining of permission, by cheating the owner or any other person,
who is incharge of computer, computer system or computer network, and thereby
induced the owner or person in charge of the computer, computer system or comuter
network for doing the act enumerated in Section 43 of the I.T. Act ?
b) The expression fraudulently or dishonestly covers the cases in which permission is
obtained from the owner or person who is incharge of computer or computer system
or computer network by cheating him ?
c) Whether Section 72 of the I.T. Act covers all the ingredients of Sections 406, 408,
409 of the Indian Penal Code especially cases in which access is secured dishonestly
to any electronic correspondence, information, document or other material and the
said electronic record correspondence, information, document or material in
misappropriated or converted for one's own use?
d) Whether the acts done under Sections 43 or 72 of the I.T. Act cover the criminal
acts done with common intention ?
3. By relying upon the decision of the Supreme Court in the matter of Sharat Babu Digumarti V.
Government of NCT of Delhi; AIR 2017 SC 150, the division bench in Gagan Harsh Sharma held that
even a dishonest and fraudulent act falls within the scope of 3 Cri. Appln. 2562-2019-FB-Ref section
66 of the Information Technology Act, 2000 (IT Act). Sections 79 and 81 give overriding effect and
the offences pertaining to electronic record, covered by the IT Act being punishable under section 43
read with section 66 would take out the provisions of the Indian Penal Code. In Awadhesh Kumar
Parasnath Pathak (supra), the division bench expressed, for the reasons mentioned in the order,
that it was not agreeable with the observations in Gagan Harsh Sharma.Devendra Rameshchandra Jain vs The State Of Maharashtra And Others on 15 April, 2024

4. Incidentally, it is a matter of record that the decision in the matter of Gagan Harsh Sharma was
challenged before the Supreme Court but the Special Leave Petition was dismissed. In the context of
a similar interplay between the provisions of Legal Metrology Act, 2009 and the relevant offences
under the Indian Penal Code, was dealt with by the Supreme Court in State of Uttar Pradesh V.
Aman Mittal and another; (2019) 19 SCC 740. Similar issues were raised and even Gagan Harsh
Sharma was cited before the Supreme Court together with the decision in the matter of Sharat Babu
Digumarti. However, considering the fact situation in the matter of Gagan Harsh Sharma and
observing that dismissal of the Special Leave Petition against the order would not amount to merger
of the order passed by the High Court in the Supreme Court order, the issue was left open to be
decided in an appropriate case with following observations in paragraph no. 25 :
4 Cri. Appln. 2562-2019-FB-Ref "25. The Bombay High Court in Gagan Harsh
Sharma v. State of Maharashtra, 2018 SCC OnLine Bom. 17705 has found that even a
dishonest and fraudulent act falls within the scope of Section 66 of the IT Act. We are
not called upon in the present appeals to examine whether an accused can be tried for
an offence under IPC in view of Section 66 of the IT Act. Such question can be raised
and decided in an appropriate case."
5. However, the decision in Sharat Babu Digumarti was commented in following words :-
"28. Sharat Babu Digumarti v. State (NCT of Delhi), (2017) 2 SCC 18 is a judgment
dealing with obscenity in the electronic form. This Court has held that the IT Act is a
special enactment. Since the offence has nexus or connection with the electronic
record the protection and effect of Section 79 cannot be ignored and negated. Section
292 IPC makes sale of obscene books as an offence which cannot be made out in view
of special provision made in the IT Act. The said judgment is, that an offence
pertaining to electronic record falls within Section 67 of the IT Act, whereas, Section
292 IPC deals with an offence of obscenity in the printed format, therefore, two
offences operate in different fields."
6. With this preface, we turn to the questions referred to us. There are plethora of judgments
wherein the Supreme Court and the High Courts have been called upon to face similar fact
situations concerning interplay between the provisions defining the acts which amount to the
offences contained in the special statute vis a vis the offences defined under the general law i.e. the
Indian Penal Code, where these offences under different statutes are similar.
7. In the matter of Sharat Babu Digumarti, the allegations were in respect of transmission of obscene
material in electronic form wherein section 292 of the Indian Penal Code was invoked and by 5 Cri.
Appln. 2562-2019-FB-Ref referring to the provision fo section 79 and 81 of the IT Act, it was held
that since IT Act is a latter enactment and section 67 of the IT Act makes publication and
transmission of the obscene material in electronic form punishable, the accused would come out of
the net of section 292 of the Indian Penal Code. The issue before the Supreme Court was as to
whether the appellant who was discharged of section 67 of the IT Act could be proceeded under
section 292 of the Indian Penal Code. In the context of such an issue, following were theDevendra Rameshchandra Jain vs The State Of Maharashtra And Others on 15 April, 2024

observations :-
"32. Section 81 of the IT Act also specifically provides that the provisions of the Act
shall have effect notwithstanding anything inconsistent therewith contained in any
other law for the time being in force. All provisions will have their play and
significance, if the alleged offence pertains to offence of electronic record. It has to be
borne in mind that IT Act is a special enactment. It has special provisions. Section
292 IPC makes offence sale of obscene books, etc. but once the offence has a nexus or
connection with the electronic record the protection and effect of Section 79 cannot
be ignored and negated. We are inclined to think so as it is a special provision for a
specific purpose and the Act has to be given effect to so as to make the protection
effective and true to the legislative intent. This is the mandate behind Section 81 of
the IT Act. The additional protection granted by the IT Act would apply."
8. By referring to paragraph no. 10 from the Solidaire India Ltd. Vs. Fairgrowth Financial Services
Ltd.; (2001) 3 SCC 71, following conclusion was drawn in paragraph no. 37 :
"37. The aforesaid passage clearly shows that if legislative intendment is discernible
that a latter enactment shall prevail, the same is to be interpreted in accord with the
said intention. We have already referred to the scheme of the IT Act and how
obscenity pertaining to electronic record falls under the scheme of the Act. We have
also referred to Sections 79 and 81 of the IT Act. Once the special provisions having
the 6 Cri. Appln. 2562-2019-FB-Ref overriding effect do cover a criminal act and the
offender, he gets out of the net of IPC and in this case, Section 292. It is apt to note
here that electronic forms of transmission are covered by the IT Act, which is a
special law. It is settled position in law that a special law shall prevail over the general
and prior laws. When the Act in various provisions deals with obscenity in electronic
form, it covers the offence under Section 292 IPC." (emphasis supplied)
9. It is thus apparent that Sharat Babu Digumarti was a matter where the issue under consideration
was whether offence under section 67 of the IT Act and the one under section 292 of the Indian
Penal Code are the same. It is in this context, the decision in Sharat Babu Digumarti will have to be
understood.
10. It would be necessary to understand as to how the division bench in Gagan Harsh Sharma has
referred to & relied upon Sharat Babu Digumarti. Following paragraphs are relevant :
"27. Applying the aforesaid principles to the facts involved in the case, perusal of the
complaint would reveal that the allegations relate to the use of the data code by the
employees of the complainant company by accessing the Code and stealing the said
data by using the computer source code. The Act of accessing or securing access to
computer/computer system or computer network or computer resources by any
person without permission of the owner or any person who is in charge of the
computer, computer system, computer network or downloading of any such data orDevendra Rameshchandra Jain vs The State Of Maharashtra And Others on 15 April, 2024

information from computer in a similar manner falls within the purview of Section 43
of the Information Technology Act, 2000. When such Act is done dishonestly and
fraudulently it would attract the punishment under Section 66 of the Information
Technology Act, such Act being held to be an offence. The ingredients of dishonesty
and fraudulently are the same which are present if the person is charged with Section
420 of the Penal Code, 1860. The offence of Section 379 in terms of technology is also
covered under Section 43. Further, as far as Section 408 is concerned which relates to
criminal breach of trust, by a clerk or servant who is entrusted in such capacity with
the property or with any dominion over property, would also fall within the purview
of Section 43 would intents to 7 Cri. Appln. 2562-2019-FB-Ref cover any act of
accessing a computer by a person without permission of the owner or a person in
charge of computer and/or stealing of any data, computer data base or any
information from such computer or a computer system including information or data
held or stored in any removable storage medium and if it is done with fraudulent and
dishonest intention then it amounts to an offence. The ingredients of an offences
under which are attracted by invoking and applying the Section 420, 408, 379 of the
Indian Penal Code are covered by Section 66 of the Information Technology Act,
2000 and prosecuting the petitioners under the both Indian Penal Code, 1860 and
Information Technology Act would be a brazen violation of protection against double
jeopardy.
28. In such circumstances if the special enactment in form of the Information
Technology Act contains a special mechanism to deal with the offences falling within
the purview of Information Technology Act, then the invocation and application of
the provisions of the Penal Code, 1860 being applicable to the same set of facts is
totally uncalled for. Though the learned APP as well as Shri. Gupte has vehemently
argued that the prosecution under the provisions of the Penal Code, 1860 can be
continued and at the time of taking cognizance the Competent Court can determine
the provisions of which enactments are attracted and it is too premature to exclude
the investigation in the offences constituted under the Penal Code, 1860, we are not
ready to accept the said contention of the learned Senior Counsel, specifically in the
light of the observations of the Hon'ble Apex Court in the case of Sharat Babu
Digumarti (Supra). We are of the specific opinion that it is not permissible to merely
undergo the rigmarole of investigation although it is not open for the Investigating
Officer to invoke and apply the provisions of the Penal Code, 1860, in light of the
specific provisions contained in the Information Technology Act, 2000 and leave it to
the discretion of the Police Authorities to decide in which direction the investigation
is to be proceeded. The Information Technology Act, 2000 being a special enactment,
it requires an able investigation keeping in mind the purpose of the enactment and to
nab the new venturing of crimes with the assistance of the Technology."
11. In the matter of Awadeshkumar Parasnath Pathak, a co- ordinate division bench was unable to
agree with Gagan Harsha Sharma and has pointed out as to how the offences as defined under
section 43 read with section 66 and section 72 are not the same 8 Cri. Appln. 2562-2019-FB-RefDevendra Rameshchandra Jain vs The State Of Maharashtra And Others on 15 April, 2024

offences as defined and made punishable under section 406, 408, 420 of the Indian Penal Code.
12. It, therefore, becomes imperative that ingredients of all these relevant offences are examined
carefully in juxtaposition.
COMPARISON OF INGREDIENTS OF VARIOUS SECTIONS No. S.43(b) IT Act S.66 IT Act S.72 IT
Act S.405/406 IPC S.408 IPC S.409 IPC S.420 IPC 1 Unauthorized Unauthorized Disclosure
Entrustment of Entrustment of Entrustment of Dishonest or downloading downloading without
property or of property or of property or of fraudulent or copying or or copying or consent of the
dominion over dominion over dominion over deception of a extraction extraction person property
property property person from a from a concerned, to computer computer any other person 2 Of
any data or Of any data or Of electronic Dishonest Dishonest Dishonest Inducement of computer
computer record, book, misappropriation misappropriation misappropriation person so database or
database or register, or conversion to or conversion to or conversion to deceived to information
information corresponden his own use of the his own use of the his own use of the (a) deliver any ce,
said property OR said property OR said property OR property to any information, Dishonest use of
Dishonest use of Dishonest use of person, or document or willful suffering of willful suffering of
willful suffering of (b) to make, other material any other person any other person any other person
alter or destroy to do so in to do so in to do so in any valuable violation of (a) any violation of
violation of (a) any security or directions of law (a) any directions directions of law anything which
prescribing the of law prescribing prescribing the is sealed or mode in which the mode in which
mode in which capable of being such property is to such property is to such property is to converted
into a be discharged, or be discharged, or be discharged, or valuable security
(b) any Legal (b) any Legal (b) any Legal contract made contract made contract made touching
touching discharge touching discharge of such of such trust discharge of such trust trust 3 With
Accused The accused was The accused was dishonest or secures a clerk or a a public servant or
fraudulent access in servant a banker, intention pursuance of merchant, broker, (Mens Rea) powers
attorney or agent conferred under this act 4 The accused was entrusted with that property in such
capacity Question no. 1(a) & 1(b) :-
Submissions :
13. Learned advocates for the applicants would argue that the provisions of IPC
cannot be invoked when provisions of the IT Act are 9 Cri. Appln. 2562-2019-FB-Ref
applicable. They would rely upon Supreme Court's decision in Sharat Babu Digumarti
(supra) to submit that when the special provisions, which have a superior effect,
encompass a criminal act and the offender, the latter is exempted from the Indian
Penal Code. The legal principle is clear; a special law will take precedence over the
general and earlier laws. Further, relying on the decision of this Court in Gagan
Harsh Sharma (supra) they would submit that the unauthorized access or securing
access to computer/computer system or computer network or computer resources by
any person without permission of the owner or any person who is in charge of the
computer, computer system, computer network or downloading of any such data orDevendra Rameshchandra Jain vs The State Of Maharashtra And Others on 15 April, 2024

information from computer is covered by section 43 of the IT Act. If such acts are
conducted with dishonest and fraudulent intentions, they become punishable by
invoking section 66 of the IT Act. Additionally, the technological equivalent of the
offence under section 379 is also covered by section 43 of IT Act. Moreover, section
408, which deals with criminal breach of trust by an entrusted clerk or servant, falls
under the ambit of section 43 of IT Act. Any act of accessing a computer by a person
without permission of the owner or a person in charge of computer and/or stealing of
any data, computer data base or any information from such computer or a computer
system including information or data held or stored in any removable storage
medium, if done with fraudulent and dishonest intent, constitutes an offence 10 Cri.
Appln. 2562-2019-FB-Ref invoking greater punishment in view of section 66 of IT
Act. The ingredients of offences under sections 420, 408, and 379 of the Indian Penal
Code are subsumed under section 66 of the IT Act. Therefore, prosecuting individuals
under both, the Indian Penal Code and the IT Act for the same offence would
contravene the legal protection against double jeopardy. In situations where the
Information Technology Act provides a specific framework for addressing offences
applicable of provisions of the Indian Penal Code to the same facts is unsustainable.
The IT Act's specialized mechanisms are designed to supersede the general statutes in such cases.
14. They would submit that reliance placed by the respondents in the case of Sayyad Hassan Sayyed
Subhan (supra) is not relevant to the current matter due to the explicit ruling in Sharat Babu
Digumarti (supra).
15. They would further submit that in Aman Mittal (supra), it is held that Gagan Harsh Sharma
(supra), recognized that dishonest and fraudulent acts are covered by Section 66 of the IT Act.
Therefore, it would not be apt to rely on the decision in the matter of Aman Mittal (supra).
Moreover, the issue involved in Aman Mittal (supra) was regarding weights and measures to which
a specific Chapter in IPC is provided and Legal Metrology Act, 2009 explicitly makes it clear that the
provisions of IPC which relate to offences with regard to weight and 11 Cri. Appln.
2562-2019-FB-Ref measure from Chapter XIII of IPC will not apply. Similar provision is absent in
IT Act therefore again it would not be relevant to rely Aman Mittal (supra). Therefore, they
submitted that the questions (a) & (b) be answered in affirmative.
16. The learned advocates for the respondents and the learned PP specifically submit that Section 43
of the Information Technology Act, 2000 does not address the scenarios involving inducement to
defraud, which would lead a person to act or refrain from acting in a way they otherwise would not,
as described in Section 415 of the IPC nor does it cover the induced delivery of property, as in
Section 420 of the IPC. Section 43 pertains to unauthorized computer usage for certain listed
actions. If a complainant is deceived into copying data or handing over property (which should also
encompass data), due to the fraudulent actions of the accused, he would be liable under Sections
415, 417, and 420 of the IPC, along with Section 43 of the IT Act. Additionally, Section 43 could
apply if the accused is alleged to have committed the specified acts via another person, who might be
completely unaware with or without invoking abetment provisions. Therefore,it was submitted thatDevendra Rameshchandra Jain vs The State Of Maharashtra And Others on 15 April, 2024

question no. 1(a) be answered in the negative.
17. The learned advocates for the respondents and the learned PP would submit that the terms
'dishonestly' and 'fraudulently' 12 Cri. Appln. 2562-2019-FB-Ref in Section 66 of the IT Act are not
meant to encompass all scenarios. Section 43 imposes liability for a defined set of actions performed
personally, which subject the individual to penalties but not criminal prosecution. However, when
these actions are carried out with a guilty state of mind or mens rea, as specified by 'fraudulently' or
'dishonestly' in Section 66 of the IT Act, they constitute an offence. Essentially, Section 43 addresses
the act itself, while Section 66 concerns the mental state behind the act, establishing it as an offence.
If the actions of the accused equate to 'cheating', as defined in Sections 415 and 420 of the IPC, then
those offences are separately applicable. Section 43 does not account for inducement to defraud or
causing someone to act or refrain from acting due to deception, which is covered under Section 415
of the IPC. section 420 of the IPC would also cover induced delivery of property. Section 43 solely
pertains to unauthorized computer use for specific actions. If permission has been deceitfully
obtained, then the offence falls under section 415 of the IPC, and if it results in the induced delivery
of property, section 420 of the IPC can be invoked as well. Therefore, they prayed that question no.
1(b) be answered in negative.
Analysis :
18. As can be understood, section 43 makes various acts punishable wherein a person
without permission of the owner or any 13 Cri. Appln. 2562-2019-FB-Ref other
person incharge of the computer, computer system or computer network either
accesses, downloads or introduces virus or damages the computer, computer system
network data or creates disruption or refuses access, destroys or deletes the
information or steals, conceals or alters the computer source code.
19. By virtue of section 66, additionally, any act as is defined under section 43 is done
dishonestly and fraudulently attracts a greater punishment. However, neither section
43 nor section 66 take within its sweep a situation where the acts done thereunder as
done by resorting to inducement, which is an additional ingredient for the offences
under section 415 and 420 of the Indian Penal Code, if a person accesses or secures
access to computer, computer system or downloads something, by inducing the
owner or any other person who is incharge.
The offence under section 43 read with section 66 only contemplates a situation where someone
dishonestly or fraudulently does any act under section 43. However, if it is done with permission
accorded, labouring under some inducement, in our considered view, such an act would be an
offence under section 415 and 420 of the Indian Penal Code and section 43 read with section 66 of
the IT Act fall short to cover such offences. It is in this context, the definition of cheating under
section 415 will have to be understood, simultaneously, with the definitions of 'dishonestly'
contained in section 24 and 'fraudulently' contained in section 25 of the Indian Penal Code.
14 Cri. Appln. 2562-2019-FB-RefDevendra Rameshchandra Jain vs The State Of Maharashtra And Others on 15 April, 2024

20. Sections 24, 25 and 415 of the Indian Penal Code read thus:-
"24. "Dishonestly".--Whoever does anything with the intention of causing wrongful
gain to one person or wrongful loss to another person, is said to do that thing
"dishonestly".
25. "Fraudulently".--A person is said to do a thing fraudulently if he does that thing with intent to
defraud but not otherwise.
415. Cheating.--Whoever, by deceiving any person, fraudulently or dishonestly induces the person so
deceived to deliver any property to any person, or to consent that any person shall retain any
property, or intentionally induces the person so deceived to do or omit to do anything which he
would not do or omit if he were not so deceived, and which act or omission causes or is likely to
cause damage or harm to that person in body, mind, reputation or property, is said to "cheat".
Explanation.-- A dishonest concealment of facts is a deception within the meaning of this section."
21. The use of word 'deceiving' in section 415 is in addition to the words 'fraudulently' or
'dishonestly' used therein. A plain reading would clearly indicate that in order to constitute
'cheating' as defined under section 415, element of deceit is an additional requirement, over and
above the intention of the person resorting to such deceit being fraudulent and dishonest. It is,
therefore, apparent that though section 66 of the IT Act covers the ingredients of 'fraudulently' and
'dishonestly', it does not cover the element of 'deceit' which is an additional concomitant for
constituting the act as 'cheating' as defined under section 415 of the Indian Penal Code.
15 Cri. Appln. 2562-2019-FB-Ref
22. It would be necessary to emphasize that though some ingredients of offence punishable under
section 43 read with section 66 of the Indian Penal Code are overlapping with the offence of
cheating defined under section 415 and the one punishable under section 420, those are not exactly
the same offences.
23. As we have indicated herein-above, the observations which we emphasized from paragraph no.
37 of Sharat Babu Digumarti (supra) comprehend the situation where the offence under the special
act having a overriding effect and the one under the general law are the same.
24. It is in this context that a reference to section 26 of the General Clauses Act, as has been done in
several matters including Aman Mittal (supra) would be relevant, which reads as under:-
"26. Provision as to offences punishable under two or more enactments.--Where an
act or omission constitutes an offence under two or more enactments, then the
offender shall be liable to be prosecuted and punished under either or any of those
enactments, but shall not be liable to be punished twice for the same offence."Devendra Rameshchandra Jain vs The State Of Maharashtra And Others on 15 April, 2024

25. In the matter of Aman Mittal, reference to the decision in the matter of Syyed Hassan was made,
which was a matter in respect of section 55 of the Food and Safety Standards Act, 2006 in
juxtaposition to section 188 of the Indian Penal Code, Sangeetaben Mahendrabhai Patel which was a
similar issue regarding section 138 16 Cri. Appln. 2562-2019-FB-Ref of the Negotiable Instruments
Act and section 406, 420 read with section 114 of the Indian Penal Code; and the doctrine of
harmonious construction resorted to by referring to the decision in the matter of Macquarie Bank
Limited vs Shilpi Cable Technologies Ltd.; (2018) 2 SCC 674. Referring to these decisions, while
considering the offences punishable under the Legal Metrology Act, 2009, in comparison to the
offences under section 415, 467, 468, 477 of the Indian Penal Code as also the element of common
intention under section 34 or conspiracy under section 120-B of the Indian Penal Code, following
conclusions in paragraph no. 35 of Aman Mittal were made and would be the guiding factors even
for deciding the questions referred to us:-
"35. The scheme of the Act is for the offences for use of weights and measures which
are non-standard and for tampering with or altering any standards, secondary
standards or working standards of any weight or measure. The Act does not foresee
any offence relating to cheating as defined in Section 415 IPC or the offences under
Sections 467, 468 and 471 IPC. Similarly, an act performed in furtherance of a
common intention disclosing an offence under Section 34 is not covered by the
provisions of the Act. An offence disclosing a criminal conspiracy to commit an
offence which is punishable under Section 120-B IPC is also not an offence under the
Act. Since such offences are not punishable under the provisions of the Act, therefore,
the prosecution for such offences could be maintained since the trial of such offences
is not inconsistent with any of the provisions of the Act. Similar is the provision in
respect of the offences under Sections 467, 468 and 471 IPC as such offences are not
covered by the provisions of the Act."
17 Cri. Appln. 2562-2019-FB-Ref
26. With respect, adopting the same line of reasoning, we have no manner of doubt in answering the
issue no. 1(a) and 1(b) in the negative.
Question no. 1(c):-
Submissions :
27. They would submit that taking into account the ingredients for constituting an offence under
section 72, those are covered by sections 406, 408 and 409 which are different facets of breach of
trust and, therefore, an individual cannot be punished twice for the similar offences but under the
different statutes. They, therefore, submitted that question no. 1(c) be answered in the affirmative.
28. As against this, learned advocate for the respondents and the learned PP would submit that
section 72 of the IT Act is specifically applicable to individuals who have been granted authority
under the IT Act or its rules or regulations pertaining to their acts or omissions. Section 72 does notDevendra Rameshchandra Jain vs The State Of Maharashtra And Others on 15 April, 2024

contemplate a situation and cover the cases where such breach of trust contemplated under section
72 is additionally for one's own use when he secures access to the electronic record, book, register,
correspondence, documents etc. not only without the consent of the person but for his own use and
constitutes misappropriation as defined under section 403 of the Indian 18 Cri. Appln.
2562-2019-FB-Ref Penal Code. They submitted that question no. 1(c) be answered in the negative.
Analysis :
29. A similar exercise, as we have done while answering questions no. 1(a) and 1(b)
will have to be undertaken for answering even this question. Section 72 of the IT Act
and section 403, 406, 408 and 409 of the Indian Penal Code would be relevant which
reads as under :
S.72 IT Act S.403 IPC S.406 IPC S.408 IPC S.409 IPC
72. Penalty for breach of 403. Dishonest 406. Punishment 408. Criminal breach 409.
Criminal breach of confidentiality and privacy.-- misappropriation of for criminal of
trust by clerk or trust by public servant, Save as otherwise provided in property. -
Whoever breach of trust.-- servant.--Whoever, or by banker, merchant this Act or any
other law for the dishonestly Of criminal Whoever commits being a clerk or servant
or agent.--Whoever, time being in force, any person misappropriation of criminal
breach of or employed as a clerk being in any manner who, in pursuance of any of the
propertymisappropriates trust shall be or servant, and being in entrusted with
property, powers conferred under this Act, or converts to his own punished with any
manner entrusted or with any dominion rules or regulations made use any movable
imprisonment of in such capacity with over property in his thereunder, has secured
access property, shall be either description property, or with any capacity of a public
to any electronic record, book, punished with for a term which dominion over
property, servant or in the way of register, correspondence, imprisonment of either
may extend to three commits criminal his business as a information, document or
other description for a term years, or with fine, breach of trust in banker, merchant,
material without the consent of which may extend to two or with both. respect of that
property, factor, broker, attorney the person concerned discloses years, or with fine,
or shall be punished with or agent, commits such electronic record, book, with both.
imprisonment of either criminal breach of trust register, correspondence, description
for a term in respect of that information, document or other which may extend to
property, shall be material to any other person seven years, and shall punished with
shall be liable to penalty which also be liable to fine. imprisonment for life, or may
extend to five lakh rupees. with imprisonment of either description for a term which
may extend to ten years, and shall also be liable to fine.
30. As can be understood, section 72 only makes punishable the act which is in
breach of confidentiality and privacy and again is done without the consent of the
person concerned. Section 406, 408, 409 of the Indian Penal Code are the cases ofDevendra Rameshchandra Jain vs The State Of Maharashtra And Others on 15 April, 2024

criminal breach of trust, criminal breach of trust by a clerk or servant or by public
servant,
19 Cri. Appln. 2562-2019-FB-Ref banker, merchant etc. Section 405 defines criminal breach of trust
to mean whoever being in any manner entrusted with the property dishonestly misappropriates or
converts to his own use that property or disposes of it in violation of the direction or contract
touching the discharge of the trust. In turn, one will have to refer to definition of 'dishonest
misappropriation' defined under section 403 which amounts to the dishonest misappropriation or
conversion to one's own use of any movable property.
31. Considering the ingredients of the offence punishable under section 72 in comparison to the
offences under section 406, 408, 409 in the light of section 403 and 405 of the Indian Penal Code,
section 72 does not comprehend a situation where the breach of confidentiality or privacy, which is
per se made punishable having been done without consent of the owner, a situation where such
breach of confidentiality is resorted to for converting the property to one's own use or access to the
computer or computer system is done dishonestly. Section 72 only contemplates a situation where
someone secures access to the electronic record / information. But if this act is done dishonestly for
one's own use, it would be an act which would be punishable only under section 406, 408 and 409
of the Indian Penal Code and section 72 would fall short to cover this kind of offence. Hence, we
answer this question also in the negative.
20 Cri. Appln. 2562-2019-FB-Ref Question 1(d):-
Submissions :
32. Learned advocate for the applicants would submit that section 43 covers the case
of cheating and even expression 'dishonestly and fraudulently' are covered wherein
the permission is obtained from the owner by cheating and even Section 72 of IT Act
covers all the ingredients of 406, 408, 409 of IPC.
33. Learned advocates for the applicants also submitted that section 72 uses the word
'any person'. Though the IT Act does not define it, rule 2(i) of the Information
Technology (Certifying Authorities) Rules, 2000 defines it to mean that it shall
include an individual, or company or association or body of individuals, whether
incorporated or not or Central Government or a State Government or any of
Ministries or Departments, Agencies or Authorities of such Government.
34. They would also refer to section 11 of the Indian Penal Code containing a similar
definition, to submit that even in the absence of a provision similar to section 34 of
IPC where a person punishable under section 43 and 72 would impliedly cover the
situation where the offences are committed by two or more persons by sharing a
common intention. They, therefore, submitted that question no. 1(d) be answered in
the affirmative.Devendra Rameshchandra Jain vs The State Of Maharashtra And Others on 15 April, 2024

21 Cri. Appln. 2562-2019-FB-Ref
35. Learned advocate for the respondents and the learned PP would submit that the acts done under
Section 43 or 72 of the I.T. Act, would not cover the criminal acts done with common intention. Such
common intention implies a collective liability, meaning one individual is held accountable for
another's actions. These sections do not address this concept. It is only when multiple individuals
act in furtherance of their common intention and there is commonality of intent and
complementarity in action, that Section 34 of the IPC becomes applicable. This section ensures that
all involved parties are held equally responsible, regardless of their individual roles or whether they
personally executed the act. Therefore, it was submitted that question no. 1(d) be answered in the
negative.
Analysis :
36. Ex facie, neither section 43 nor section 72 makes punishable an offence as defined therein when
it is committed by two or more persons by sharing a common intention, neither is there any other
provision in the IT Act which would demonstrate the legislature having comprehended a situation
where these offences are committed by sharing a common intention as defined under section 34 of
the Indian Penal Code. Independently, even this aspect, in the context of Legal Metrology Act, 2009
was considered in Aman Mittal, in 22 Cri. Appln. 2562-2019-FB-Ref concluding paragraph (supra).
With respect, we follow the same line of reasoning. Hence, we answer this question also in the
negative.
37. The common thread deducible from various judgments of the Supreme Court covering similar
issues, where an act is an offence under a special statute having an overriding effect over the offence
covered by the general law like Indian Penal Code, is that in order to exclude the general law or the
offence therein, ingredients of the offence defined under the special statute and the Indian Penal
Code will have to be the same. If even one ingredient of an offence under the Indian Penal Code is
missing in the act which has been made punishable under the special statute, the Indian Penal Code
section will not be excluded and still can be resorted to albeit, the provisions of section 71 of the
Indian Penal Code and section 26 of the General Clauses Act will have to be borne in mind by the
Courts while imposing the sentences.
38. We are alive to the fact that these observations of ours' may not be necessary for answering the
questions referred to us, however, we are making these observations as an abundant precaution to
enable the trial Courts faced with such a situation when they are called upon, to consider these
aspects.
23 Cri. Appln. 2562-2019-FB-Ref
39. Hence, we answer all the questions referred to us in the negative.
40. Matters be now placed before the appropriate bench for adjudication.Devendra Rameshchandra Jain vs The State Of Maharashtra And Others on 15 April, 2024

[ SHAILESH P. BRAHME ]    [ R. G. AVACHAT ]   [ MANGESH S. PATIL ]
       JUDGE                    JUDGE               JUDGE
arp/Devendra Rameshchandra Jain vs The State Of Maharashtra And Others on 15 April, 2024

