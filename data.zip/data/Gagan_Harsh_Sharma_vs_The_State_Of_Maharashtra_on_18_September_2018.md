Gagan Harsh Sharma vs The State Of Maharashtra on 18
September, 2018
Author: Sadhana S. Jadhav
Bench: Sadhana S. Jadhav
                                    1                     901.aba1823.812.doc
            IN THE HIGH COURT OF JUDICATURE AT BOMBAY
                 CRIMINAL APPELLATE JURISDICTION
   CRIMINAL ANTICIPATORY BAIL APPLICATION NO. 1823 OF 2017
Gagan Harsh Sharma.                                   ..Applicant.
V/s.
State of Maharashtra & anr.                           ..Respondents.
                                   WITH
       CRIMINAL ANTICIPATORY BAIL APPLICATION NO. 812 OF 2018
Shagun Sharma.                                        ..Applicant.
V/s.
State of Maharashtra.                                 ..Respondent.
Mr. Amit Desai, Sr. Counsel a/w. Mr. Pranav Badheka a/w. Mr. Ryan
Shrivastava a/w. Mr. Niranjan Pachupate a/w. Mr. Pradee Parmar a/w.
Mr. Prashant Pawar I/b. Mr. Mehul R. Thakker, advocate for applicant in
ABA 1823/2017.
Mr. Amit Desai, Sr. Counsel a/w. Ms. N.S. Nappinai I/b. Noelle Ann Park,
advocate for applicant in ABA 812/2018.
Mr. Niranjan Mundargi a/w. Mr. Pandit Kasar a/w. Mr. Rohit Manggule
a/w. Mr. Harish Khedkar a/w. Mr. Nihar Thackeray I/b. Vis Legis Law
Practice, advocate for intervenor.
Ms. Veera Shinde, APP for State.
Mr. S.A. Malve, PN, Shahupuri Police Station, Kolhapur.
                              CORAM : SMT. SADHANA S. JADHAV, J.Gagan Harsh Sharma vs The State Of Maharashtra on 18 September, 2018

RESERVED ON : JULY 31, 2018.
Talwalkar 2 901.aba1823.812.doc PRONOUNCED ON : SEPTEMBER 18, 2018.
P. C. :
1 Heard the learned Senior Counsel for the applicants, Learned Counsel for the
intervenor and the learned APP for State.
2 These are applications under section 438 of the Code of Criminal Procedure, 1908.
The applicants herein are apprehending their arrest in Crime No. 346 of 2017
registered at Shahupuri Police Station, Kolhapur for offence punishable under
section 379, 408, 420, 420b of the Indian Penal Code read with section 43, 65, 66 of
the Information Technologies Act, section 63 and 63b of the Copy Right Act.
3 It is the case of the prosecution that on 27/8/2017 Shadaab Abdul Shaikh lodged a
report at the police station alleging therein that he is working as the head of
Administration and Human Resource Department in Manorama InfoSolutions Pvt.
Ltd., Kolhapur.
That one Mr. Ashwin Danigond is the Chief Executive Officer and Managing Director of the said
company. The main work of the company is to develop healthcare softwares for hospital
managements, to develop and distribute the same and also maintenance of the said softwares. The
company has engaged 171 employees. Every employee is bound to give an undertaking/bond to the
company that he shall not give any Talwalkar 3 901.aba1823.812.doc details of work of the company,
source code or any other information about software to any other company while in service or after
service as the work in the said company involves healthcare software development. The first
informant is concerned with the supervision of the employees' work to ensure that there is no
violation of the bond/undertaking given by employees under the Intellectual Property Rights Act. It
is alleged by the first informant that while he was going through the profile of Suresh Mahajan, he
had noticed that Suraj had published his own software and had also distributed the same. The first
informant had suspected that there was theft of the data and software of the company and therefore,
he checked the profile and other details of Suraj Mahajan. He had informed the director of the
company that Suraj Mahajan was involved in installing software namely, Cleave Track with the help
of Gururaj Janardhan Nimbargi, who happens to be the network head of the same company. It had
transpired that there was breach of trust, as server access of the company was given to the
employees. In fact, the said software was developed by the company and not by Suraj Mahajan in his
personal capacity. On the basis of the said information, Crime No. 346 of 2017 is registered at
Sahupuri Police Station. Investigation was set in motion. Perused papers of investigation.
4 In the year 2015, Monorama InfoSolutions Pvt. Ltd. had Talwalkar 4 901.aba1823.812.doc signed
a letter of intent with Bliss GVS Pharma and Bliss GVS Health Care, whereby Bliss GVS Health Care
was to purchase the Development, Implementation, Training and Support (on site and off site) of
ERP software for their healthcare division operating at Kenya. A software in the name of lifeline EGagan Harsh Sharma vs The State Of Maharashtra on 18 September, 2018

Clinic Enterprises and Lifeline E Claims was developed for Bliss GVS Health Care. The accused
applicant-Gagan Sharma was General Manager of Bliss GVS Pharma Ltd., Mumbai and a Director of
Bliss GVS Healthcare Ltd.. The Bliss GVS Health Care Ltd. had obtained tender in Kenya for clinical
operations and insurance. Demonstrations were exchanged between both the companies. In the
meanwhile, AON Insurance Company, Kenya has signed a service agreement with Bliss GVS Health
Care. It appears that one Asterisk Solutions Limited had moved their operations of claims
management to AON Insurance Company. There was tie up of Bliss GVS Healthcare and Asterisk
Solutions Limited for using E-Claims system prepared by the company for claim submission and
processing. Hence, Aon Insurance Company, Kenya had also requested for the demonstration of
E-claims software to the complainant company. The said demonstration was done by Mr. Devansh
Khanna, Mr. Ali Asif Madani and Mr. Anand Sanmani to the team of AON Insurance Company,
Kenya. 5 In the course of investigation, it had transpired that Mr. Talwalkar 5 901.aba1823.812.doc
Anand Sanmani was won over by Bliss GVS at Kenya i.e. by the applicant Gagan Sharma. Shagun
Sharma, applicant in ABA 812 OF 2018 is the bother of applicant Gagan Sharma. The employees of
Manorama InfoSolutions Ltd. i.e. Anand Sanmani and others were informed that Shagun Sharma is
also developing one healthcare application portal like Practo and Mr. Anand Sanmani was requested
to assist Shagun Sharma. Mr. Anand Sanmani was won over by both the applicants by offering
different hampers and valuable perks in the nature of pleasure trips etc. 6 It has transpired from the
papers of investigation that Manorama InfoSolution Private Ltd. got the Software Project namely,
Lifeline E-Clinic Enterprise and Lifeline E-claims for Bliss GVS Healthcare Limited, Kenya. In
October, 2015, there were exchange of demonstrations and links. A team was deputed to Kenya in
November, 2015. The team comprised of Digvijay Ghatage, Nilesh Patil, Anand Sanmani, Vinayak
Sutar, Anup Tiwari and Santosh Patil. On 15/12/2015 Digvijay Ghatage, a member of Manorama
team returned to Kolhapur to discuss further strategy. The rest of the team had come into contact
with Gagan Sharma who was the General Manager of Bliss GVS Pharma Ltd and was at the same
time appointed as Director in Bliss GVS Healthcare Limited, Kenya. The team had then started
preparing the data for E- Clinic and E-claims. In the meanwhile, one of the employee was Talwalkar
6 901.aba1823.812.doc terminated by Manorama. Thereafter, Asterisk Solutions had come into
picture and the passwords were floated from one company to another. 7 It appears that Gagan
Sharma had given offer to Anand Sanmani to join his company. It appears from the papers of
investigation that Gagan Sharma had informed Anand Sanmani that he plans to design a system for
HMIS which would be flexible and easy to use than Manorama. He was also asked to take Code of
Manorama which is deployed for Bliss GVS Healthcare Ltd., Kenya and asked his other colleagues to
join him as he intends to sell the said software to African Continent. Thereafter, Anand Sanmani
took other colleagues such as Amruta Patil, Sheetal Banne, Snehal Mane, Suraj Mahajan, Nitin
Kamble and Nilesh Patil. Nilesh Patil and Sheetal Banne had informed that they would join
subsequently. They had put up their office. Suraj Mahajan was responsible for overall coding and
development of each module and he would be the moderator for all development developed by
Amruta and Nitin Kamble. The employees of Manorama were directed to use the knowledge bank
and resources of Manorama from healthcare domains in order to overcome the loopholes of
Manorama's e-clinic. Certain expenses were paid to Anand Sanmani. The employees of Manorama
were then introduced to Shagun, brother of Gagan Sharma. Both the brothers had asked Anand
Sanmani to set up office in Mumbai Talwalkar 7 901.aba1823.812.doc and join immediately. Both
the brothers had explained to Anand Sanmani their concept, process and modus operendi and theGagan Harsh Sharma vs The State Of Maharashtra on 18 September, 2018

scope of OPD HMIS. They were directed to use the reference code of Manorama which was deployed
for Bliss GVS Healthcare Limited, Kenya. A rent agreement was signed between Anand Sanmani
and Ashok Rokade in respect of the office premises to be rented at Jarag Nagar, Kolhapur and
Anand Sanmani had signed under the authority and on behalf of RiteSource Pharma Solutions.
Salaries of employees were fixed in June, 2017 and on 23/6/2017 Suraj Mahajan had transferred the
code of MediHope from Manorama's server to Amruta Patil by We-Transfer. She had down-loaded
it in her laptop and the same was sealed in the course of investigation. Between 24/6/2017 and
26/6/2017 Suraj Mahajan had tested the same. On 27/6/2017 Vaidehi Kulkarni was recruited. The
laptops were sent by applicant Gagan Sharma. Two laptops were carried and transported by Tanmay
Hatti from Bliss GVS Pharma Solutions Limited, Mumbai to Kolhapur out of which one was used by
Vaidehi Kulkarni.
8 They had then taken source code of e-claims from Manorama. The said e-code was transferred in
favour of applicant Shagun Sharma and his team.
Talwalkar 8 901.aba1823.812.doc 9 The learned APP has submitted that the applications like Scrum
methodology for project management were introduced by Shagun, who had given demonstration of
Trello Tool. It appears that Anand Sanmani was working under the instructions of both the
brothers. Since this is an application for pre-arrest bail, it would not be appropriate to consider the
entire material transpired in the course of investigation.
10 According to the learned Senior Counsel, the offences under the Information Technologies Act as
alleged by the prosecution are bailable offences. It is submitted that it cannot be said that the
applicants have committed an offence punishable under section 408 and 420 of the Indian Penal
Code. It is also submitted that this is not a case of theft as there was a contract for using the data
base. It is submitted that there is no question of criminal breach of trust, as they had authority to
use the code.
11 Section 408 of the Indian Penal Code reads as under :
"408. Criminal breach of trust by clerk or servant.-- Whoever, being a clerk or servant
or employed as a clerk or servant, and being in any manner entrusted in such
capacity with property, or with any dominion over property, commits criminal breach
of trust in respect of that property, shall be Talwalkar 9 901.aba1823.812.doc
punished with imprisonment of either description for a term which may extend to
seven years, and shall also be liable to fine."
At this juncture, it would be necessary to consider the application of section 408 of the Indian Penal
Code.
12 It appears from the papers of investigation that in fact, Nitin Kamble, Snehal Mane and Anand
Sanmani had signed confidentiality agreement and the applicants had induced themto commit
breach of the same for their own benefit and had obtained the code and other relevant information
for their personal use. In fact, the applicants have committed an offence punishable under sectionGagan Harsh Sharma vs The State Of Maharashtra on 18 September, 2018

463 and 464 of the Indian Penal Code.
13 There is sufficient material to indicate that Shagun Sharma had operated the links provided by
Suraj Mahajan as according to the intervenor, it had transpired that on 11/8/2017 Shagun Sharma
uploaded code on Github and named the repository as RiteHeal-Pro with the help of HackerMartin
user on GitHub. Mr. Vishal Dhull and Mr. Vipin Gupta were the participants in the said team who
operated the code of RiteHeal-Pro on GitHub.
Talwalkar 10 901.aba1823.812.doc 14 It is pertinent to note that they had set up office for the
employees of Manorama InfoSolutions during the period of their service. The applicants herein had
induced the employees to open up an office for them and had provided all necessary financial aid. In
fact, the company data was transferred to the applicants and their company RiteSource Pharma
Solutions Pvt. Ltd. That during the period of June, 2016 to August, 2016, Asterisk Solution Ltd.
moved their operations of Claims Management to AON Insurance Company, Kenya. 15 The
statements of employees such as Anand Sanmani and others were recorded in the course of
investigation and based on the documentary evidence, they had disclosed to the police that they
were induced by the applicants to steal the data from Manorama. The investigating agency has also
perused the server set up by the accused applicants, which was installed for SAP application in the
office premises at Andheri alongwith the pharmaceuticals labs and machinery. An agreement was
signed with Mr. Roakade for renting premises for Rite Pharma Solutions Pvt. Ltd. and the accused
had deposited Rs. 50,000/- into the bank account of Anand Sanmani on 15/5/2017. From 6/6/2017
to 19/6/2017 Mr. Sanmani had received salaries, rent and office operational costs from the accounts
of Rite Pharma Solutions Pvt. Ltd. Talwalkar 11 901.aba1823.812.doc Suraj Mahajan and Sanmani
were informed by the applicants that there is a business opportunity from the Ministry of Zambia
for e-claims process and that they should show demonstration of e-claims. The data base and source
code of Manorama was used for the purpose of demo and for hosting the same. According to the
learned Senior Counsel, the data was used only for the purpose of demonstration. In fact, what was
used was the source code. Rite Pharma Solutions Pvt. Ltd. appears to have purchased the clouds
space and uploaded company data base for HMIS and e-claim. Suraj Mahajan had obliged and
thereafter the said application was published at I-cloud by removing all the references of the said
company i.e. Manorama. Not only that but the reference of Manorama was removed from e-claims
and source code and uploaded on the repository.
16 It is apparent on the face of the record that there is a criminal breach of trust and the
requirement of section 408 of the Indian Penal Code are fulfilled. As far as section 420 of the Indian
Penal Code is concerned, the fact that the applicants-accused have benefited from committing
breach is sufficient to attract the provisions of section 420 of the Indian Penal Code.
17 Section 66 of the Information Technologies Act, 2000 is Talwalkar 12 901.aba1823.812.doc
reproduced herein below :
"66 Computer related offences. -If any person, dishonestly or fraudulently, does any
act referred to in section 43, he shall be punishable with imprisonment for a term
which may extend to three years or with fine which may extend to five lakh rupees orGagan Harsh Sharma vs The State Of Maharashtra on 18 September, 2018

with both.
Explanation. -For the purposes of this section,-
(a) the word "dishonestly" shall have the meaning assigned to it in section 24 of the
Indian Penal Code (45 of 1860);
(b) the word "fraudulently" shall have the meaning assigned to it in section 25 of the
Indian Penal Code (45 of 1860).]"
18 Statute mandates that the word dishonestly shall have meaning as assigned to section 24 of the
Indian Penal Code. Section 24 has to be read in consonance with section 420 of the Indian Penal
Code which read as follows :
24. "Dishonestly"
Whoever does anything with the intention of causing wrongful gain to one person or wrongful loss
to another person, is said to do that thing "dishonestly".
420. Cheating and dishonestly inducing delivery of property Whoever cheats and thereby
dishonestly induces the person deceived to deliver any property to any person, or to make, alter or
destroy the whole or any part of a valuable security, or anything which is signed or sealed, and which
is capable of being converted into a valuable security, shall be punished with imprisonment of either
description for a term which may extend Talwalkar 13 901.aba1823.812.doc to seven years, and shall
also be liable to fine. The main ingredient of section 420 of the Indian Penal Code is cheating and
dishonestly inducing delivery of property. In the present case, the employees of Manorama were
dishonestly induced to commit breach of the agreement and deliver the data of Manorama Solutions
to the applicants.
19 The possibility of invocation of section 463 of the Indian Penal Code at the time filing of
charge-sheet also cannot be ruled out. This Court is of the prima facie opinion that the offence
committed by the applicants would also fall under section 463 of the Indian Penal Code, which reads
as follows :
"463. Forgery Whoever makes any false documents or part of a document with intent
to cause damage or injury, to the public or to any person, or to support any claim or
title, or to cause any person to part with property, or to enter into any express or
implied contract, or with intent to commit fraud or that fraud may be committed,
commits forgery."
20 Learned Senior Counsel submits that it cannot be said that it was capable of being converted into
valuable security. Needless to say that the theft of the data base has diminishing value and utility
and it has caused gross loss to Manorama Solution. It appears from papers of Talwalkar 14
901.aba1823.812.doc investigation that the ramification of the present case are much larger thanGagan Harsh Sharma vs The State Of Maharashtra on 18 September, 2018

what is seen from the report on the basis of which FIR is lodged, since the material discovered in the
course of investigation would show that it has international ramification.
21 Learned APP submits that prima facie section 65 and 66 of the Information Technologies Act are
apparent but the possibility that while filing charge-sheet, section 66(F) of the Information
Technologies Act being invoked cannot be ruled out. The case also involves the insurance claims of
the citizens. It is also submitted that interpolation of medical data with the aid of other
pharmaceutical companies whose names are transpired in the course of investigation to disclose the
personal information of the health management, enhancement of all claims to insurance companies
cannot be ruled out and relying upon the said data, the insurance companies may have to shell out
huge costs and malafide claims. It is not just the first informant company which is at loss. On the
basis of the said data, the possibility that Insurance Company would be cheated cannot be ruled out.
Hence, it would amount to fabrication of evidence.
22 Learned Senior Counsel has placed implicit reliance on the words "valuable security". Section
463 and 464 of the Indian Penal Code Talwalkar 15 901.aba1823.812.doc have now encompassed
electronic records also. Valuable security would amount to anything that would have marketable
value. Black's Law Dictionary defines the word "valuable" as "worth a good price", "having financial
or market value". Moreover, the parties were bound by legal contract with Manorama InfoSolution.
This is a case, which requires custodial interrogation of all the accused concerned. At this stage, it
would not be appropriate to decide as to whether an offence under section 420 or 408 of the Indian
Penal Code is made out. The learned APP submits that the charge-sheet could be filed for some
more serious charges and the prosecution must have a fair opportunity of investigation. The field of
information technology is expanding day by day. The accused persons are taking advantage of the
loop-holes of the technology.
23 According to intervenor, the applicants teamed with Devansh Khanna of Asterisk Solutions Pvt.
Ltd. and hatched the present crime to provide software support to AON Insurance Company based
in Kenya and African continent and secure the healthcare software market of African continent and
capture the market of Manorama InfoSolutions Pvt. Ltd. with the theft of the source code devised by
Manorama InfoSolutions Pvt. Limited by inducing its employees. There is also material to show that
Anand Sanmani and others were made to work for Talwalkar 16 901.aba1823.812.doc both the
applicants.
24 According to the intervenor, the cost of source code and data stolen by the applicants and other
accused is more than worth Rs. 160 Crores and it had taken almost 3 to 4 years for preparing for
such source code. Hence, it can be safely inferred that the applicants have committed an offence of
theft and cheating alongwith other offences. The company had got right over source code and the
same has been unauthorisedly used by the applicants. It is pertinent to note that the contract
between Manorama InfoSolution and other companies was intact.
25 No fault can be found with the investigating agency for applying only section 379, 408, 420 of the
Indian Penal Code in the FIR, since at the time of registration of FIR, there is no meticulous
examination of the nature of the offence and appropriate sections can be invoked only at the time ofGagan Harsh Sharma vs The State Of Maharashtra on 18 September, 2018

filing of the charge-sheet. 26 In view of this, this Court, upon perusing the records of investigation,
is of the prima facie opinion that the applicants herein are the master-mind behind the entire case
and therefore, they do not deserve grant of pre-arrest bail. Hence, the applications being sans
Talwalkar 17 901.aba1823.812.doc merits stand rejected.
27 It is made clear that the observations are prima facie and are restricted to the application under
section 438 of the Code of Criminal Procedure, 1973 and the same shall not be taken into
consideration for discharge application, quashing of FIR or at the time of trial.
28 Both the applications are disposed of accordingly. 29 At this stage, Learned Counsel for the
applicants seeks a stay to the order of this Court rejecting the bail. In view of this, the applicants
stand protected till 1/10/2018.
                                                         [SMT. SADHANA S. JADHAV, J.]
            Digitally
            signed by
            Aruna
Aruna       Sandeep
Sandeep     Talwalkar
Talwalkar   Date:
            2018.09.18
            16:51:31
            +0530
                         TalwalkarGagan Harsh Sharma vs The State Of Maharashtra on 18 September, 2018

