Dekhari Tea Co. Ltd. vs Assam-Bengal Railway Co., Ltd. And
Anr. on 12 January, 1921
Equivalent citations: 66IND. CAS.469, AIR 1921 CALCUTTA 239
JUDGMENT
Rankin, J.
1. In this case the question arises as to the proper principles upon which the damages have to be
calculated.
2. The action was fried before me a considerable time ago and I held the second defendant Company
to be liable to the f plaintiffs on the ground of negligence and under the provisions of the Indian
Carriers Act. The plaintiff Company are incorporated in England and the question arises with regard
to 96 packages of tea out of a total consignment of 343. The tea was being carried by the defendant
Company to Chittagong and the plain purpose of its carrying was that it might be shipped from
Chittagong to England and sold there. I am relieved of having to consider any disputed fact as to
whether there is or is not a market for tea at Chittagong. If there was it may well be that the measure
of damages would have to ba assessed according to the rates prevailing in that market. But Mr. Roy
for the defendants has relieved me of much unnecessary trouble by pointing out that, upon the facts
in that case, he has no interest save in establishing, that the true way of calculating in rape as the
damages which the plaintiff can recover is by taking the rate of exchange today, that is to say,
prevailing at the date of judgment as distinct from, lot us say, the rate prevailing at the date of the
breach. The exact terms of the submission male by Mr. Roy I have already read out, but I will
incorporate them for convenience in this judgment. Mr. Roy's submission was as
follows:---"Without prejudice to any right of appeal upon law or otherwise, I am prepared to accept
the figure of Rs. 6,339-30 as damages, should the following contention fail, namely, that the loss
caused to the Plaintiff being in the first instance measureable in sterling, judgment must be based '
upon such starling sum converted into rupees at the rule of exchange prevailing on the date Of the
judgment." Mr. Langford James for the plaintiff Company says that the sum of Rs. 6, 339-3-0 will
Company his clients. I am, therefore, relieved, front considering any question as between the rate of
exchange prevailing on 2lst December 1915, being the data on which this tea was destroyed by fire
and the rate prevailing one or two months afterwards, at the date, namely, on which the tea would
normally have arrive in England and been sold in the English market. The question is confined to
the---Is the rate of exchange on the data of judgment applicable?---In support of the proposition
that the rate of exchange today is to be adopted, Mr. Roy has relied upon the that that the plaintiff
Company is incorporated in England, To my mind that is an entirely irrelevant circumstance. The
reference to English prices or the English market arises, if at all, entirely by reason of one or other of
two facts, first, that the goods were going to be sold in England and, secondly, that there was no
market at Chittagong or short of England upon which damages could be fairly assessed. ThatDekhari Tea Co. Ltd. vs Assam-Bengal Railway Co., Ltd. And Anr. on 12 January, 1921

England is the place where the Company was incorporated has no bearing whatsoever. Mr. Roy has
also relied upon a decision of my learned brother Mr. Justice Buckland given apparently in
November 1919 in a Suit No. 693 of 1919 between the Deutsche Asiatiche Bank and D. K. Panva &
Co, The decision appears to have bean given before the decisions to which I am about to refer and I
must draw attention also to the fact that the case there was a case of debt and not of damages. It
appears to have been a suit on a Bill of Exchange and I do not understand that there is any written
judgment in which the principles of the matter can be found discussed.
2. Now, bearing in mind the question, which is simply whether or not the date of judgment is the
date upon which the rate of exchange is for this purpose to be taken, I find that the matter is
concluded by resent authority. There is the decision, in the first place, of Me. Justice Roche is the
case of Di Berdinando v. Simon Smits & Co. (1920) 2 K: B. 704, which was affirmed unanimously on
this point by the Court of Appeal whose decision is repotted in L, R. 1920, 3 K. B., page 409 [Di
Ferdinando v. Simon Smits & Co, (1920) 8 K. B. 409 : 83 L. J. K. B. 1039 : 23 Com, Cas. 37: 36 T. L.
R. 797: (1920) W. N. 273.]. In addition to this case there is the decision of Mr. Justice B(sic)ailhache
in Barry v. Van Ben Hurk (1920) 6 K. B. 703 : 89 L, J. K. B. 899 : 123 L. T. 719 : 61 S. J. 602 : 36 T. L.
R. 663., and there is also the decision of Mr. Justice McCardie in the case of Lebeaupin v. Orispin
(1920) 2 K. B. 714 at p. 745, 89 L. J. K. B. 1024 : 25 Com. Cas. 335 : 64 S. J. 652 : 36 T. L. R. 739.. At
one time, American authorities seem to have rendered it doubtful whether the rate, of exchange on
the date of judgment, was not the true rate in the case of an act of for debt as distioct from damages
but in my view, as Mr. Justice McCardie has shown, that proposition is not now in accordance with
the bast opinion. The question, before me is, whether the rite prevailing on the data of judgment is
the rate applicable in a suit for damages, and as to that the whole body of recant authority is, against
the contention of the defendant. The reasons given by Mr. Justice Bailhache are very convinsing,
that the plaintiff may sue immediately a breach takes place, that, the damages are then crystalized,
that the, law will in general take no account of necessary delay in bringing the suit to a hearing. The
iuconvenienses of taking the rate as on the date of judgment are pointed out by Mr. Justice
McCardie very forcibly. The decisions seem to be all one way except, for the first decision of Mr.
Justice Roche in the case of Kirsch & Co, v. Allen Harding & Co. (1919) W. N. 301 : 38 T. L. R. 59
affirmed an appeal (1920). W. N. 73 : 89 L. J. K, B. 265 123 L. T 105 25 Com. Cas. 174 : 36 T. L. R.
245,. That opinion, was subsequently altered. I would only add, for myself, that a Court which can
only give judgment in terms of the currency can never undertake to ensure payment of the exact
equivalent at the time of payment of a given quantity of another currency. The rate of exchange on
the day of payment may be an ideal, but it is an impossible ideal; the rate at the time of judgment is
not the ideal; it is not necessarily nearer to the rate at the tints of payment than the rate of any other
day. The contention put forward by the defendant Company must, I think, be overruled. Judgment
mast, therefore, be given for Rs. 6, 333-3-0 in terms of the submission made by Mr. Roy. The
plaintiff must have his costs.Dekhari Tea Co. Ltd. vs Assam-Bengal Railway Co., Ltd. And Anr. on 12 January, 1921

