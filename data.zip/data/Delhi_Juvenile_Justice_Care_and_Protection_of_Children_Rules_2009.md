Delhi Juvenile Justice (Care and Protection of Children) Rules,
2009
DELHI
India
Delhi Juvenile Justice (Care and Protection of
Children) Rules, 2009
Rule
DELHI-JUVENILE-JUSTICE-CARE-AND-PROTECTION-OF-CHILDREN-RULES-2009
of 2009
Published on 1 January 2009• 
Commenced on 1 January 2009• 
[This is the version of this document from 1 January 2009.]• 
[Note: The original publication document is not available and this content could not be
verified.]• 
Delhi Juvenile Justice (Care and Protection of Children) Rules, 2009Published vide Notification F.
No. 61 (9)/JJ Amended Act/AD-1/DWCD/2009(To be Published in Part IV of the Delhi Gazette
Extra Ordinary)Notification F. No. 61 (9)/JJ Amended Act/AD-I/DWCD/2009. - In exercise of the
powers conferred by section 68 of the Juvenile Justice (Care and Protection of Children) Act, 2000
(56 of 2000), the Lt. Governor of the National Capital Territory of Delhi, hereby makes the following
rules namely :-Chapter - I Preliminary
1. Short title and commencement.
(1)These rules may be called Delhi Juvenile Justice (Care and Protection of Children) Rules,
2009.(2)They shall come into force on the date of their publication in the Official Gazette.
2. Definition.
- In these rules, unless the context otherwise requires-(a)"abandoned" means an unaccompanied
and deserted child who is declared abandoned by the Committee after due inquiry;(b)"Act" means
the Juvenile Justice (Care and Protection of Children) Act, 2000 (56 of 2000) as amended by the
Juvenile Justice (Care and Protection of Children) Amendment Act, 2006 (33 of 2006);(c)"best
interest of the child" means a decision taken to ensure the physical, emotional, intellectual, social
and moral development of juvenile or child;(d)"child friendly" means any process and
interpretation, attitude, environment and treatment, that is humane, considerate and in the best
interest of the child;(e)"community service" implies service rendered to the society by juveniles inDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

conflict with law in lieu of or in addition to other judicial remedies and penalties, which is not
degrading and dehumanizing. Examples of this may include (only non hazardous part) :i. cleaning a
park;ii. getting involved with Habitat for Humanity;iii. serving the elderly in nursing homes;iv.
helping out a local fire or police department;v. helping out at a local hospital or nursing home;
andvi. serving disabled children.(f)"detention" in case of juveniles in conflict with law means
"protective custody" in line with the principles of restorative justice;(g)"Form" means the form
annexed to these rules;(h)"individual care plan" is a comprehensive development plan for a juvenile
or child based on age specific and gender specific needs and the case history of the juvenile or child,
prepared in consultation with the juvenile or child and parent/guardian, if available in order to
restore the juvenile's or child's self-esteem, dignity and self-worth and nurture him into a
responsible citizen and accordingly the plan shall address the following needs of a juvenile or a
child:i. Health needs;ii. Emotional and psychological needs;iii. Educational and training needs;iv.
Leisure, creativity and play;v. Attachments and relationships;vi. Protection from all kinds of abuse,
neglect and maltreatment;vii. Social mainstreaming; andviii. Follow-up post release and
restoration.(i)"institution" means an observation home, or a special home, or a children's home or a
shelter home set up, certified or recognized and registered under sections 8, 9, 34, sub-section (3) of
section 34 and section 37 of the Act respectively;(j)"Officer-in-charge" or such other nomenclature
as issued by the State Government, means a person appointed for the control and management of
the institution;(k)"orphan" means a child who is without parents or willing and capable legal or
natural guardian;(l)"place of safety" means any institution set up and recognized under sub-section
(3) of section 12 and sub-section (1) of section 16 of the Act for juvenile in conflict with law or
children;(m)"recognised" means a person found fit by the competent authority or, an institution
found fit by the State Government on the recommendation of the competent authority as per clauses
(h) and (i) of section (2) of the Act; or, recognition of an institution or agency or voluntary
organisation by the State Government to operate as a children's home, observation home and
special home; or a shelter home, specialised adoption agency or after care organization under
sub-section (1) of section 37, sub-section (4) of section 41 and clause (a) of section 44 of the
Act;(n)"registered" means all institutions or agencies or voluntary organisations providing
residential care to children in need of care and protection registered under sub-section (3) of section
34;(o)"State Government" means the Lieutenant Governor of the National Capital Territory of Delhi
appointed by the President under article 239 of the Constitution;(p)"street and working children"
means children without ostensible means of livelihood, care, protection and support in accordance
with the provisions laid down under clause (d) (1) of section 2 of the Act;(q)"surrendered child"
means a child, who in the opinion of the Committee, is relinquished on account of physical,
emotional and social factors beyond the control of the parent or guardian;(r)all words and
expressions defined in the Act and used, but not defined in these rules, shall have the same meaning
as assigned to them in the Act.Chapter - II Fundamental Principles of Juvenile Justice and
Protection of Children
3. Fundamental principles to be followed in administration of these rules.
(1)The State Government, the Juvenile Justice Board, the Child Welfare Committee or other
competent authorities or agencies, as the case may be, while implementing the provisions of these
rules shall abide and be guided by the principles, specified in sub-rule (2).(2)The followingDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

principles shall, inter alia, be fundamental to the application, interpretation and implementation of
the Act and the rules made hereunder:I. Principle of presumption of innocence:(a)A juvenile or
child or juvenile in conflict with law is presumed to be innocent of any malafide or criminal intent
up to the age of eighteen years.(b)The juvenile's or juvenile in conflict with law's or child's right to
presumption of innocence shall be respected throughout the process of justice and protection, from
the initial contact to alternative care, including aftercare.(c)Any unlawful conduct of a juvenile or a
child or a juvenile in conflict with law which is done for survival, or is due to environmental or
situational factors or is done under control of adults, or peer groups, ought to be covered by the
principles of innocence.(d)The basic components of presumption of innocence are:(i)Age of
innocence - Age of innocence is the age below which a juvenile or child or a juvenile in conflict with
law cannot be subjected to the criminal justice system. The Beijing Rule 4(1) clearly lays down that
"the beginning of the age of criminal responsibility shall not be fixed at too low an age level bearing
in mind the facts of mental and intellectual maturity". In consonance with this principle, the mental
and intellectual maturity of juvenile or child or a juvenile in conflict with law below eighteen years is
considered insufficient through out the world.(ii)Procedural protection of innocence - All procedural
safeguards that are guaranteed by the Constitution and other statutes to the adults and that go in to
strengthen the juvenile's or child's right to presumption of innocence shall be guaranteed to
juveniles or the children or juveniles in conflict with law.(iii)Provisions of Legal aid and Guardian
Ad Litem Juveniles in conflict with law have a right to be informed about the accusations against
them and a right to be legally represented. Provisions must be made for guardian ad litem, legal aid
and other such assistance through legal services at State expense. This shall also include such
juvenile's right to present his case before the competent authority on his own.II. Principle of dignity
and worth:(a)Treatment that is consistent with the child's sense of dignity and worth is a
fundamental principle of juvenile justice. This principle reflects the fundamental human right
enshrined in Article 1 of the Universal Declaration of Human Rights that all human beings are born
free and equal in dignity and rights. Respect of dignity includes not being humiliated, personal
identity, boundaries and space being respected, not being labelled and stigmatized, being offered
information and choices and not being blamed for their acts.(b)The juvenile's or child's right to
dignity and worth has to be respected and protected throughout the entire process of dealing with
the child from the first contact with law enforcement agencies to the implementation of all measures
for dealing with the child.III. Principle of Right to be heard:Every child's right to express his views
freely in all matters affecting his interest shall be fully respected through every stage in the process
of juvenile justice. Children's right to be heard shall include creation of developmentally appropriate
tools and processes of interacting with the child, promoting children's active involvement in
decisions regarding their own lives and providing opportunities for discussion and debate.IV.
Principle of Best Interest:(a)In all decisions taken within the context of administration of juvenile
justice, the principle of best interest of the juvenile or the juvenile in conflict with law or child shall
be the primary consideration.(b)The principle of best interest of the juvenile or juvenile in conflict
with law or child shall mean for instance that the traditional objectives of criminal justice,
retribution and repression, must give way to rehabilitative and restorative objectives of juvenile
justice.(c)This principle seeks to ensure physical, emotional, intellectual, social and moral
development of a juvenile in conflict with law or child so as to ensure the safety, well being and
permanence for each child and thus enable each child to survive and reach his or her full
potential.V. Principle of family responsibility:(a)The primary responsibility of bringing up children,Delhi Juvenile Justice (Care and Protection of Children) Rules, 2009

providing care, support and protection shall be with the biological parents. However, in exceptional
situations, this responsibility may be bestowed on willing adoptive or foster parents.(b)All decision
making for the child should involve the family of origin unless it is not in the best interest of the
child to do so.(c)The family - biological, adoptive or foster (in that order), must be held responsible
and provide necessary care, support and protection to the juvenile or child under their care and
custody under the Act, unless the best interest measures or mandates dictate otherwise.VI. Principle
of Safety (no harm, no abuse, no neglect, no exploitation and no maltreatment):(a)At all stages,
from the initial contact till such time he remains in contact with the care and protection system, and
thereafter, the juvenile or child or juvenile in conflict with law shall not be subjected to any harm,
abuse, neglect, maltreatment, corporal punishment or solitary or otherwise any confinement in jails
and extreme care shall be taken to avoid any harm to the sensitivity of the juvenile or the
child.(b)The state has a greater responsibility for ensuring safety of every child in its care and
protection, without resorting to restrictive measures and processes in the name of care and
protection.VII. Positive measures:(a)Provisions must be made to enable positive measures that
involve the full mobilization of all possible resources, including the family, volunteers and other
community groups, as well as schools and other mainstream community institutions or processes,
for the purpose of promoting the well-being of the juvenile or child through individual care plans
carefully worked out.(b)The positive measures shall aim at reducing vulnerabilities and reducing the
need for intervention under the law, as well as effective, fair and humane dealing of the juvenile or
child.(c)The positive measures shall include avenues for health, education, relationships,
livelihoods, leisure, creativity and play.(d)Such positive measures must facilitate the development of
identity for the child and provide them with an inclusive and enabling environment.VIII. Principle
of non-stigmatizing semantics, decisions and actions:The non-stigmatizing semantics of the Act
must be strictly adhered to, and the use of adversarial or accusatory words, such as, arrest, remand,
accused, charge sheet, trial, prosecution, warrant, summons, conviction, inmate, delinquent,
neglected, custody or jail is prohibited in the processes pertaining to the child or juvenile in conflict
with law under the Act.IX. Principle of non-waiver of rights:(a)No waiver of rights of the child or
juvenile in conflict with law, whether by himself or the competent authority or anyone acting or
claiming to act on behalf of the juvenile or child, is either permissible or valid.(b)Non-exercise of a
fundamental right does not amount to waiver.X. Principle of equality and
non-discrimination:(a)There shall be no discrimination against a child or juvenile in conflict with
law on the basis of age, sex, place of birth, disability, health, status, race, ethnicity, religion, caste,
cultural practices, work, activity or behaviour of the juvenile or child or that of his parents or
guardians, or the civil and political status of the juvenile or child.(b)Equality of access, equality of
opportunity, equality in treatment under the Act shall be guaranteed to every child or juvenile in
conflict with law.XI. Principle of right to privacy and confidentiality:The juvenile's or child's right to
privacy and confidentiality shall be protected by all means and through all the stages of the
proceedings and care and protection processes.XII. Principle of last resort:Institutionalisation of a
child or juvenile in conflict with law shall be a step of the last resort after reasonable inquiry and
that too for the minimum possible duration.XIII. Principle of repatriation and restoration:(a)Every
juvenile or child or juvenile in conflict with law has the right to be re-united with his family and
restored back to the same socio-economic and cultural status that such juvenile or child enjoyed
before coming within the purview of the Act or becoming vulnerable to any form of neglect, abuse or
exploitation.(b)Any juvenile or child, who has lost contact with his family, shall be eligible forDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

protection under the Act and shall be repatriated and restored, at the earliest, to his family, unless
such repatriation and restoration is likely to be against the best interest of the juvenile or the
child.XIV. Principle of Fresh Start:(a)The principle of fresh start promotes new beginning for the
child or juvenile in conflict with law by ensuring erasure of his past records.(b)The State shall seek
to promote measures for dealing with children alleged or recognized as having impinged the penal
law, without resorting to judicial proceedings.Chapter - III Juvenile in Conflict with Law
4. Juvenile Justice Boards.
- There shall be one or more Juvenile Justice Boards in the National Capital Territory of Delhi,
which shall be constituted by the State Government as per section 4 of the Act.
5. Composition of the Juvenile Justice Board.
(1)The Board shall consist of a Metropolitan Magistrate or a Judicial Magistrate of the first class, as
the case may be, and two social workers of whom at least one shall be a woman, forming a bench:
Provided that the Principal Magistrate of the Board shall review the pendency of cases before the
Board and take such steps, as may be necessary in the expeditious disposal of the cases.(2)Every
such bench shall have the powers conferred by the Code of Criminal Procedure 1973 (2 of
1974).(3)(i)A Magistrate with special knowledge or training in child psychology or child welfare shall
be designated as the Principal Magistrate of the Board.(ii)In case the Principal Magistrate with such
special knowledge or training is not available, then, the State Government shall provide for such
short-term training in child psychology or child welfare as it considers necessary.(4)The two social
workers, of whom at least one shall be a woman, shall be appointed by the State Government on the
recommendation of the Selection Committee set up under rule 91 of these rules.(5)The State
Government shall provide for such training and orientation in child psychology, child welfare, child
rights, national and international standards for juvenile justice to all members of the Board as it
considers necessary, in accordance with the Integrated Child Protection Scheme of the Central
Government.
6. Tenure of the Board.
(1)The Board shall have a tenure of three years and the appointment of members shall also be for
three years from the date of their appointment.(2)A social worker being a member of the Board shall
be eligible for appointment for a maximum of two consecutive terms.(3)Any extension of the tenure
of members of the Board shall be on the basis of their performance appraisal by the District Child
Protection Unit of the State Government and on the recommendation of a Selection Committee
constituted for the purpose and the performance appraisal of members of the Board shall
necessarily assess their participation in the proceedings of the Board and contribution in case
disposal.(4)A member may resign any time, by giving one month's advance notice in writing or may
be removed from his office as provided in sub-section (5) of section 4 of the Act.(5)Any vacancy in
the Board may be filled by appointment of another person from the panel of names prepared by the
Selection Committee, and shall hold office for the remaining term of the Board.Delhi Juvenile Justice (Care and Protection of Children) Rules, 2009

7. Qualifications for Members of the Board.
(1)The social worker to be appointed as a member of the Board shall be a person not less than 35
years and not more than 65 years of age at the time of appointment/extension, who has a
post-graduate degree in social work, health, education, psychology, child development or any other
social science discipline and has been actively involved and engaged in planning, implementing and
administering measures relating to child welfare for at least seven years.(2)No person shall be
considered for selection as a Member of the Board, if he,-(a)has been convicted under any
law;(b)have ever indulged in child abuse or employment of child labour or any other human rights
violations or immoral act;(c)is holding such other occupation that does not allow him to give
necessary time and attention to the work of the Board;(d)does not fulfill the qualification and
experience prescribed in the Act and the rules made there under and in such a case the Selection
Committee shall after due inquiry and on establishment of such fact, reject his application and
recommend the name of the next person from the list of names prepared for filling the vacancies.
8. Sitting and conveyance allowances.
- The social worker members of the Board shall be paid such travel and sitting allowance, as the
State Government may determine, but it shall not be less than rupees one thousand per sitting.
9. Sittings of the Board.
(1)The Board shall hold its sittings in the premises of an Observation Home or, at a place in
proximity to the observation home or, at a suitable premise in any institution run under the Act, and
in no circumstances shall the Board operate from within any court premises.(2)The premises where
the Board holds its sittings shall be child-friendly and shall not look like a court room in any manner
whatsoever; for example, the Board shall not sit on a raised platform and the sitting arrangement
shall be uniform, and there shall be no witness boxes.(3)The Board shall meet on all working days of
a week, unless the case pendency is less in a particular district and concerned authority issues an
order in this regard.(4)A minimum of three-fourth attendance of the Chairperson and Members of
the Board is necessary in a year.(5)Every member of the Board shall attend a minimum of six hours
per sitting.
10. Functions of the Board.
- The Board shall perform the following functions to achieve the objectives of the Act,
namely:-(a)adjudicate and dispose cases of juveniles in conflict with law;(b)take cognizance of
crimes committed under section 23 to 28 of the Act;(c)monitoring institutions for juveniles in
conflict with law and seeking compliance from them in cases of any noticeable lapses and
improvement based on suggestions of the Board;(d)deal with non-compliance on the part of
concerned government functionaries or functionaries of voluntary organizations, as the case may be,
in accordance with due process of law;(e)pass necessary direction to the district authority and police
to create or provide necessary infrastructure or facilities so that minimum standards of justice andDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

treatment are maintained in the spirit of the Act;(f)maintain liaison with the Committee in respect
of cases needing care and protection;(g)liaison with other Boards in the National Capital Territory of
Delhi and other States or Union Territories to facilitate speedy inquiry and disposal of cases through
due process of law;(h)take suitable action for dealing with unforeseen situations that may arise in
the implementation of the Act and remove such difficulties in the best interest of the juvenile;(i)send
quarterly information about juveniles in conflict with law produced before them, to the District,
State Child Protection Unit, the State Government and also to the Chief Judicial Magistrate or Chief
Metropolitan Magistrate for review under sub-section (2) of section 14 of the Act;(j)any other
function assigned by the State Government from time to time relating with juveniles in conflict with
law.
11. Pre and Post-Production action of police and other agencies.
(1)In dealing with cases of juveniles in conflict with law the Police or the Juvenile or the Child
Welfare Officer from the nearest police station, shall not be required to register an FIR or file a
charge-sheet, except where the offence alleged to have been committed by the juvenile is of a serious
nature such as rape, murder or when such offence is alleged to have been committed jointly with
adults; instead, in matters involving simple offences, the Police or the Juvenile or the Child Welfare
Officer from the nearest police station shall record information regarding the offence alleged to have
been committed by the juvenile in the general daily diary followed by a report containing social
background of the juvenile and circumstances of apprehension and the alleged offence and forward
it to the Board before the first hearing.(2)The police or the Juvenile or the Child Welfare Officer
from the nearest police station, shall exercise the power of apprehending the juvenile only in cases
of his alleged involvement in serious offences (entailing a punishment of 7 years or more
imprisonment for adults).(3)For all other cases involving offences of non-serious nature (entailing a
punishment of less than 7 years imprisonment for adults) and cases where apprehension is not
necessary in the interest of the juvenile, the police or the Juvenile or the Child Welfare Officer from
the nearest police station, shall intimate the parents or guardian of the juvenile about forwarding
the information regarding nature of offence alleged to be committed by their child or ward along
with his socio-economic background to the Board, which shall have the power to call the juvenile for
subsequent hearings. Whenever a juvenile is apprehended "apprehension memo" in Form XXV shall
be prepared. The personal search of the Juvenile shall be conducted and Form - XXVI shall be filled
with relevant information. When a juvenile or child requires to be medically examined, request for
Medical Examination Report in Form - XXIV shall be prepared.(4)In such cases where
apprehension apparently seems to be in the interest of the juvenile, the police or the Juvenile or the
Child Welfare Officer from the nearest police station, shall rather treat the juvenile as a child in need
of care and protection and produce him before the Board, clearly explaining the juvenile's need for
care and protection in its report and seek appropriate orders from the Board under rule 13 (1) (b) of
these rules.(5)As soon as a juvenile alleged to be in conflict with law is apprehended by the police,
the concerned police officer shall inform:(a)the designated Juvenile or the Child Welfare Officer in
the nearest police station to take charge of the matter;(b)the parents or guardian of the juvenile
alleged to be in conflict with law about the apprehension of the juvenile, about the address of the
Board where the juvenile will be produced and the date and time when the parents or guardian need
to be present before the Board (as per form XXIII).(c)the concerned probation officer, of suchDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

apprehension to enable him to obtain information regarding social background of the juvenile and
other material circumstances likely to be of assistance to the Board for conducting the inquiry. The
Investigating Officer shall record the child version of the incident in the presence of Juvenile
Welfare Officer/ fit person/ parents/ guardian. The child version of the incident shall be verified and
if it comes to notice that an adult has caused the juvenile to be in the conflict situation an action
against such adult shall be initiated keeping the interest of juvenile in mind and to ensure that he
keeps away from such influence. The child version of the incident along with the verification of the
same shall be produced before the Juvenile Justice Board.(6)Soon after apprehension, the juvenile
shall be placed under the charge of the Juvenile or Child Welfare Officer from the nearest police
station.(7)The police apprehending a juvenile in conflict with law shall in no case put send the
juvenile in lock-up or delay his charge being transferred to the Juvenile or the Child Welfare Officer
from the nearest police station.(8)A list of all designated Juvenile or Child Welfare Officers in a
district and members of Special Juvenile Police Unit with contact details shall be prominently
displayed in every police station.(9)The police or the Juvenile or the Child Welfare Officer from the
nearest police station, shall also record the social background of the juvenile and circumstances of
apprehension and offence alleged to have been committed in the case diary of each juvenile, which
shall be forwarded to the Board forthwith.(10)For gathering the best available information it shall be
incumbent upon the Police or the Juvenile or the Child Welfare Officer from the nearest police
station, to contact the parents or guardians of the juvenile and also apprise them of the juvenile's
law breaking behaviour.(11)The Police or the Juvenile or the Child Welfare Officer from the Special
Juvenile Police Unit, or the recognized voluntary organization shall be responsible for the safety and
provision of food and basic amenities to the juveniles apprehended or kept under their charge
during the period such juveniles are with them.(12)The State Government shall recognize only such
voluntary organizations that are in a position to provide the services of probation, counseling, case
work, a safe place and also associate with the Police or the Juvenile or the Child Welfare Officer
from the Special Juvenile Police Unit, and have the capacity, facilities and expertise to do so as
protection agencies that may assist the Police or the Juvenile or the Child Welfare Officer from the
police at the time of apprehension, in preparation of the report containing social background of the
juvenile and circumstances of apprehension and the alleged offence, in taking charge of the juvenile
until production before the Board, and in actual production of the juvenile before the Board within
twenty-four hours.(13)(a)The Juvenile or the Child Welfare Officer from the nearest police station,
or where such officer has not been designated as per provisions laid down under sub-section (2) of
section 63 of the Act or is not available for some official reasons, the police officer who had
apprehended the juvenile shall produce the juvenile before the Board within 24 hours as per sub
section 1 of section 10 of the Act.(b)In case the Board is not sitting, the juvenile in conflict with law
shall be produced before a single member of the Board as per the provisions laid down under the
sub-section (2) of section 5 of the Act.(c)When a juvenile is produced before an individual member
of the Board, and an order obtained, such order shall need ratification by the Board in its next
meeting.(14)When the juvenile is released when apprehension in a case is not warranted then an
undertaking on a non-judicial paper, of the parents/ guardians or a fit person in whose custody the
juvenile/child in conflict with law is released in the interest of the child, shall be made in Form -
XXVII to ensure their presence on the dates during enquiry/ proceedings of the Board.Delhi Juvenile Justice (Care and Protection of Children) Rules, 2009

12. Procedure to be followed in determination of Age.
(1)In every case concerning a child or a juvenile in conflict with law, the court or the Board or as the
case may be the Committee referred to in rule 19 of these rules shall determine the age of such
juvenile or child or a juvenile in conflict with law within a period of thirty days from the date of
making of the application for that purpose.(2)The court or the Board or as the case may be the
Committee shall decide the juvenility or otherwise of the juvenile or the child or as the case may be
the juvenile in conflict with law, prima facie on the basis of physical appearance or documents, if
available, and send him to the observation home or in jail.(3)In every case concerning a child or
juvenile in conflict with law, the age determination inquiry shall be conducted by the court or the
Board or, as the case may be, the Committee by seeking evidence by obtaining -(a)(i)the date of birth
certificate from the school (other than a play school) first attended; and in the absence
whereof;(ii)the birth certificate given by a corporation or a municipal authority or a
panchayat;(iii)the matriculation or equivalent certificates, if available;(b)and only in the absence of
either (i), (ii) or (iii) of clause (a) above, the medical opinion will be sought from a duly constituted
Medical Board, which will declare the age of the juvenile or child. In case exact assessment of the age
cannot be done, the Court or the Board or, as the case may be, the Committee, for the reasons to be
recorded by them, may, if considered necessary, give benefit to the child or juvenile by considering
his/her age on lower side within the margin of one year and, while passing orders in such case shall,
after taking into consideration such evidence as may be available, or the medical opinion, as the case
may be, record a finding in respect of his age and either of the evidence specified in any of the
clauses (a)(i), (ii), (iii) or in the absence whereof, clause (b) shall be the conclusive proof of the age
as regards such child or the juvenile in conflict with law.(4)If the age of a juvenile or child or the
juvenile in conflict with law is found to be below 18 years on the date of offence, on the basis of any
of the conclusive proof specified in sub-rule (3), the court or the Board or as the case may be the
Committee shall in writing pass an order stating the age and declaring the status of juvenility or
otherwise, for the purpose of the Act and these rules and a copy of the order shall be given to such
juvenile or the parent/ guardian/ person concerned.(5)Save and except where, further inquiry or
otherwise is required, inter alia, in terms of section 7A, section 64 of the Act and these rules, no
further inquiry shall be conducted by the court or the Board after examining and obtaining the
certificate or any other documentary proof referred to in sub-rule (3) of this rule.(6)The provisions
contained in this rule shall also apply to those disposed off cases, where the status of juvenility has
not been determined in accordance with the provisions contained in sub rule (3) and the Act,
requiring dispensation of the sentence under the Act for passing appropriate order in the interest of
the juvenile in conflict with law.
13. Post-production processes by the Board.
(1)On production of the juvenile before the Board, the report containing social background of the
juvenile and circumstances of apprehension and offence alleged to have been committed provided
by the officers, individuals, agencies producing the juvenile shall be reviewed by the Board, and the
Board shall pass the following order in the first summary inquiry on the same day,
namely:-(a)dispose off the case, if the evidence of his conflict with law appears to be unfounded or
where the juvenile is involved in trivial law breaking;(b)transfer to the Committee, mattersDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

concerning juveniles clearly stated to be in need of care and protection in the police report
submitted to the Board at the time of production of the juvenile;(c)release the juvenile in the
supervision or custody of fit persons or fit institutions or probation officers as the case may be,
through an order in Form-I, with a direction to appear or present a juvenile for an inquiry on a next
date;(d)detain the juvenile in an Observation Home or fit institution pending inquiry, only in cases
of juvenile's involvement in serious offences as per an order in Form-II;(e)in all cases of release
pending inquiry, the Board shall notify the next date of hearing, not later than 15 days of the first
summary enquiry and also seek social investigation report from the concerned Probation Officer
through an order in Form-III;(2)The Board shall take the following steps to ensure fair and speedy
inquiry, namely:-(a)at the time of initiating the inquiry, the Board shall satisfy itself that the juvenile
in conflict with law has not been subjected to any ill-treatment by the police or by any other person,
including a lawyer or probation officer and take corrective steps in case of such ill-treatment;(b)in
all cases under the Act the proceedings shall be conducted in as simple a manner as possible and
care shall be taken to ensure that the juvenile, against whom the proceedings have been instituted, is
given child-friendly atmosphere during the proceedings;(c)every juvenile brought before the Board
shall be given the opportunity to be heard and participate in his inquiry;(d)cases of petty offences, if
not disposed off by the Special Juvenile Police Unit or at the police station itself, may be disposed off
by the Board through summary proceedings or inquiry, while in cases of heinous offences entailing
punishment of 7 years or more prescribed for adults due process of inquiry in detail may
follow;(e)even in cases of inquiry pertaining to serious offences the Board shall follow the procedure
of trial in summons cases.(3)When witnesses are produced for examination in inquiry relating to a
juvenile in conflict with law, the Board shall keep in mind that the inquiry is not to be conducted in
the spirit of strict adversarial proceedings and it shall use the powers conferred by section 165 of the
Indian Evidence Act, 1872 (1 of 1872) so as to question the juvenile and proceed with the
presumptions that favour the juvenile's right to be restored.(4)While examining a juvenile in conflict
with law and recording his statement, the Board shall address the juvenile in a child-friendly
manner in order to put the juvenile at ease and to encourage him to state the facts and
circumstances without any fear, not only in respect of the offence of which the juvenile is accused,
but also in respect of the home and social surroundings and the influence to which the juvenile
might have been subjected.(5)The Board may take into account the report of the police containing
circumstances of apprehension and offence alleged to have been committed and the social
investigation report in Form-IV prepared by the Probation officer or the voluntary organization on
the orders of the Board as per Form-III, along with the evidence produced by the parties for arriving
at a conclusion about the juvenile.(6)Every inquiry by the Board shall be completed within a period
of four months after the first summary inquiry and only in exceptional cases involving transnational
criminality, large number of accused and inordinate delay in production of witnesses the period of
inquiry may be extended by two months on recording of reasons by the Board.(7)In all other cases
except where the nature of alleged offence is serious, delay beyond four to six months shall lead to
the termination of the proceedings.(8)Where the proceedings are delayed beyond six months on
account of serious nature of the offence alleged to have been committed by the juvenile, the Board
shall send a periodic report of the case to the Chief Judicial Magistrate or Chief Metropolitan
Magistrate stating the reason for delay as well as steps being taken to expedite the matter.Delhi Juvenile Justice (Care and Protection of Children) Rules, 2009

14. Legal Aid.
(1)The proceedings before the Board shall be conducted in non-adversarial environment, but with
due regard to the fact that the principle of due process guarantees rights such as right to counsel and
free legal aid.(2)The Board shall ensure that the Legal Officer in the District Child Protection Unit
and the State Legal Aid Services Authority shall extend free legal services to all the juvenile in
conflict with law.(3)The Legal Officer in the District Child Protection Unit and the State Legal Aid
Services Authority shall be under an obligation to provide legal services sought by the Board.(4)In
the event of shortfall in the State Legal Aid Services support, the Board shall be responsible for
seeking legal services from recognized voluntary legal services organizations or the university legal
services clinics.(5)The Board may also deploy the services of the student legal services volunteers
and nongovernmental organisation volunteers in para-legal tasks such as contacting the parents of
juveniles in conflict with law and gathering relevant social and rehabilitative information about the
juveniles.
15. Completion of Inquiry and Dispositional Alternatives.
(1)The Board shall complete every inquiry within the stipulated time of four months and on
recording a finding about juvenile's involvement in the alleged offence, pass one of the seven
dispositional orders enumerated in section 15 of the Act.(2)Before passing an order, the Board shall
obtain a social investigation report prepared by the probation officer or by a recognized voluntary
organization ordered to do so by the Board, and take the findings of the report into account.(3)All
dispositional orders passed by the Board shall necessarily include an individual care plan for the
concerned juvenile in conflict with law, prepared by a probation officer or voluntary organization on
the basis of interaction with the juvenile and his family where possible.(4)Where the Board decides
to release the juvenile after advice and admonition or after participation in-group counselling or
orders him to perform community service, necessary direction may also be made by the Board to the
District or State Child Protection Unit or the State Government for arranging such individual
counselling, group counselling and community service.(5)Where the Board decides to release the
juvenile in conflict with law on probation and place him under the care of the parent or guardian or
fit person, the person in whose custody the juvenile is released may be required to submit a written
undertaking in Form-V for the good behaviour and well-being of the juvenile for a maximum period
of three years.(6)The Board may order release of a juvenile in conflict with law on execution of a
personal bond without surety in Form VI.(7)In the event of placement of a juvenile in conflict with
law in care of a fit institution or special home, the Board shall keep in mind that the fit institution or
special home is located nearest to the place of residence of the juvenile's parent or guardian.(8)The
Board, where it releases a juvenile in conflict with law on probation and places him under the care of
parent or guardian or fit person or where the juvenile is released on probation and placed under the
care of fit institution, may order that the juvenile be placed under the supervision of a probation
officer. The period of supervision shall be a maximum of three years.(9)Where the Board decides
that a juvenile in conflict with law ought to be treated as a child in need of care and protection, it
shall make necessary orders for production of such juvenile before the nearest Committee for
suitable care, protection and rehabilitation.(10)Where it appears to the Board that the juvenile in
conflict with law has not complied with probation conditions, it may order the juvenile to be sent forDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

detention in a special home.(11)Where a juvenile in conflict with law who has attained the age of
sixteen years and the offence committed by him is of such a serious nature that in the satisfaction of
the Board, it is neither in the interest of the juvenile himself nor in the interest of other juveniles of
the special home, the Board may order the juvenile to be kept in a place of safety and in a manner
considered most appropriate by it.(12)The State Government shall make arrangement for complying
with the detention of special category of juveniles in conflict with law in place of safety other than
the special home.(13)In no case the period of detention shall exceed beyond the maximum period
provided in clause (g) of sub-section (1) of section 15 of the Act.
16. Institutions for juveniles in conflict with law.
(1)The State Government or the voluntary organisation recognized by that State Government shall
set up separate observation homes or special homes for boys and girls.(2)The observation homes or
special homes shall set up separate residential facilities for boys and girls up to 12 years, 13-15 years
and 16 years and above.(3)Every institution shall keep a copy of the Act, the rules made by the
Central Government and the State rules if any, for use by both staff, juveniles and children residing
therein.(4)The State Governments in collaboration with civil society shall develop and make
available simplified and child friendly versions of the Act and the rules in regional languages.(5)All
facilities and services for juveniles in conflict with law shall be made available and maintained as per
the provisions of the Act and the State rules.
17. Release.
(1)The Officer-in-charge shall maintain a roster of the cases of juveniles in conflict with law to be
released on the expiry of the period of stay as ordered by the Board.(2)Each case shall be placed
before the Management Committee set up under rule 55 of these rules by the concerned probation
officer or child welfare officer or case worker for ensuring proper release and social mainstreaming
of the juvenile post-release.(3)The release shall be as per the pre-release and post-release plan
prepared under the individual care plan and reviewed from time to time by the management
committee set up under rule 55 of these rules and in all cases of release, necessary action and
preparation shall be initiated well before the time of release and shall include preparation for
post-release follow-up.(4)The timely information of the release of a juvenile and of the exact date of
release shall be given to the parent or guardian and the parent or guardian shall be invited to come
to the institution to take charge of the juvenile on that date.(5)If necessary, the actual expenses of
the parent's or guardian's journey both ways and of the juvenile's journey from the institution shall
be paid to the parent or guardian by the Officer in-charge at the time of the release of the
juvenile.(6)If the parent or guardian, as the case may be, fails to come and take charge of the
juvenile on the appointed date, the juvenile shall be taken to his parent or guardian by the escort of
the juvenile police unit; and in case of a girl, she shall be escorted by a female escort, who shall hand
over her custody to her parent/ guardian.(7)At the time of release or discharge, a juvenile shall be
provided with a set of summer or winter clothing and essential toiletries, if the Officer-in-charge
considers it necessary.(8)If the juvenile has no parent or guardian, he may be sent to an aftercare
organization, or in the event of his employment, to the person who has undertaken to employ the
juvenile.(9)The Officer-in-charge of a girls' institution may, subject to the consent of the girl and theDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

approval of the competent authority, help the girl with her social re-integration by way of sending a
girl above the age of eighteen years to an after care programme or, helping her with some vocation
or gainful employment or, helping her settle into family life according to the procedure laid down by
the competent authority from time to time.(10)The Officer-in-Charge shall order the discharge in
Form-VII of any juvenile whose detention period has come to an end and inform the competent
authority within seven days of the action taken and if the date of release falls on a Sunday or a public
holiday, the juvenile may be discharged on the preceding day with an entry to that effect being made
in the register of discharge.(11)The Officer-in-charge shall in appropriate cases, order the payment
of subsistence money, at such rates as may be fixed from time to time, by the State or the District
Child Protection Unit or the State Government, and the railway or road, or both, fares, as the case
may be.(12)In deserving cases, the Officer-in-charge may provide the juvenile with such small tools,
as may be necessary, to start a work or business subject to such maximum cost as may be fixed by
the institution which shall also form part of the post-release plan.(13)Where a girl has no place to go
after release and requests for stay in the institution after the period of her stay is over, the
Officer-in-charge may, subject to the approval of the competent authority, allow her stay till the time
some other suitable arrangements are made.
18. Procedure to be followed in respect of sections 21, 22, 23, 24, 25 and 26
of the Act.
(1)In the event of violation of provisions laid down under section 21 of the Act,-(a)the Board shall
take cognizance of such violation by print or electronic media and shall initiate necessary inquiry
and pass appropriate orders as per provisions contained in subsection (2) of section 21 of the Act;
and(b)where the National or the State Commission for Protection of Child Rights takes suo motu
cognizance of violation under section 21 of the Act, it shall inform the District or the State Child
Protection Unit of the concerned district and the State directing them to initiate necessary action
through the Board.(2)In the event of an escape of a juvenile in conflict with law or a child, the
following action shall be taken within twenty-four hours,-(a)the Officer-in-Charge of any institution
shall immediately send a report to the area Police Station or Special Juvenile Police Unit along with
the details and description of the juvenile or child, with identification marks and a photograph, with
a copy to the Board, District Child Protection Unit and other authorities concerned;(b)the
Officer-in-charge of institutions other than shelter homes or drop-in-centres shall send the guards
or concerned staff in search of the juvenile, at places like railway stations, bus stands and other
places where the juvenile is likely to go;(c)the parents or guardians shall be informed immediately
about such escape; and(d)the Officer-in-charge of an institution other than a shelter home or
drop-in-centre shall hold an inquiry about such escape and send his report to the Board or
Committee and the authorities concerned and the report shall be placed before the Management
Committee set up under rule 55 of these rules in the next meeting for review.(3)The offence against
a juvenile in conflict with law or a child specified in section 23 shall be cognizable and bailable.
When an Officer-in-Charge of an institution owned and run by the State Government is accused of
an offence under section 23 alleged to have been committed by him while acting or purporting to act
in the discharge of his official duty, no court shall take cognizance of such offence nor shall the
Officer-in-Charge be arrested, except with the previous sanction of the State Government.(4)The
offences against a juvenile in conflict with law or a child specified in sections 24, 25 and 26 shall beDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

non-bailable besides being cognizable under the provisions of the code of Criminal Procedure, 1973
(2 of 1974) and the procedures shall apply on the Police, the Board and the concerned authorities
and functionaries accordingly.Chapter - IV Child in Need of Care and Protection
19. Child Welfare Committee.
- There shall be one or more Child Welfare Committee in the NCT of Delhi which shall be
constituted by the State Government through a notification in the Official Gazette as per sub-section
(1) of section 29 of the Act.
20. Composition of the Child Welfare Committee.
(1)The Committee shall consist of a Chairperson and four other members, of whom at least one shall
be a woman.(2)The Chairperson and members of the Committee shall be appointed on the
recommendation of a Selection Committee set up by the State Government, for the purpose under
rule 91.(3)The Selection Committee, while selecting the Chairperson and Members of the
Committee, shall ensure that none of them are from any adoption agency or children
institutions.(4)The State Government shall provide for such training and orientation in child
psychology, child welfare, child rights, national and international standards for juvenile justice to all
members of the Committee as it considers necessary.
21. Tenure of the Committee.
(1)The Committee shall have a tenure of three years and the tenure of Chairperson and Members
shall also be three years from the date of their appointment.(2)The Chairperson and Members of the
Committee shall be eligible for appointment for a maximum of two terms.(3)Extension of the tenure
of members of the Committee shall be on the basis of their performance appraisal by the State
Government.(4)With a view to ensuring continuity on completion of the tenure of a Committee, the
State Government shall constitute a new Committee before the expiry of the term of the existing
Committee; where after the existing Committee shall handover all records and information to the
newly formed Committee.(5)The Chairperson and Members may resign at any time by giving one
month's notice in writing or may be removed from office as provided in sub-section (4) of section 29
of the Act.(6)Any casual vacancy in the Committee may be filled by appointment of another person
from the panel of names prepared by the Selection Committee, and shall hold office for the
remaining term of the Committee.
22. Qualifications for Chairperson and Members of the Committee.
(1)A person to be selected as a Chairperson or Member of the Committee shall have either of the
following qualifications, in addition to a minimum of seven years experience in their respective
field:(i)a person with post graduate degree in social work, psychology, child development,
education, sociology, law, criminology and, where such a person is not available, a person with at
least a graduate degree in any of the social science disciplines;(ii)a teacher, doctor or a social workerDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

who has been involved in work concerning children.(2)The Chairperson or Member of the
Committee shall be a person not less than 35 years of age and not more than 65 years of age at the
time of appointment/extension.(3)No person shall be considered for Selection as a Chairperson or
Member of the Committee, if he,-(i)has a previous conviction record;(ii)has been involved in any
immoral act or in an act of child abuse or employment of child labour;(iii)is holding such full-time
occupation that may not allow him to give necessary time and attention to the work of the
Committee as per the Act and these rules;(iv)does not fulfill the qualification and experience
prescribed in the Act and the rules made thereunder, and in such a case the Selection Committee
shall after due inquiry and on establishment of such fact, reject his application and recommend the
name of the next person from the list of names prepared for filling the vacancies.
23. Sitting and conveyance allowances.
- The Chairperson and Members of the Committee shall be paid such travel and sitting allowance, as
the State Government may determine, but it shall not be less than rupees one thousand per sitting
per member.
24. Sitting of the Committee.
(1)The Committee shall hold its sittings in the premises of the children's home or, at a place in
proximity to the children's home or, at a suitable premise in any institution run under the Act.(2)On
receiving information about child or children in need of care and protection, if circumstances are
such that the child or children cannot be produced before the Committee, the Committee may move
out to reach the child or children and hold its sitting at a place that is convenient for such child or
children.(3)The premises where the Committee holds its sittings shall be child-friendly and shall not
look like a court room in any manner whatsoever; for example, the Committee shall not sit on a
raised platform and the sitting arrangement shall be uniform and there shall be no witness
boxes.(4)The Committee shall meet five days a week, which may be extended by the State
Government depending on case and pendency of work.(5)A minimum of three-fourth attendance of
the Chairperson and Members of the Committee is necessary in a year.(6)Every member of the
Committee shall attend a minimum of six hours per sitting during the official working hours which
may be extended by the State Government depending on pendency of work.
25. Functions and Powers of the Committee.
- The Committee shall perform the following functions to achieve the objectives of the Act,
namely:-(a)take cognizance of and receive children produced before the Committee;(b)decide on the
matters brought before the Committee;(c)reach out to such children in need of care and protection
who are not in a position to be produced before the Committee, being in difficult circumstances,
with support from the District Child Protection Unit or State Child Protection Unit or the State
Government;(d)conduct necessary inquiry on all issues relating to and affecting the safety and well
being of the child;(e)direct the Child Welfare Officers or Probation Officers or non-governmental
organisations to conduct social inquiry and submit a report to the Committee;(f)ensure necessary
care and protection, including immediate shelter;(g)ensure appropriate rehabilitation andDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

restoration, including passing necessary directions to parents or guardians or fit persons or fit
institutions in this regard, in addition to follow-up and coordination with District Child Protection
Unit or State Adoption Resource Agency and other agencies;(h)direct the Officer-in-charge of
children's homes/shelter homes/drop-in-centres to receive children requiring shelter and
care;(i)document and maintain detailed case record along with a case summary of every case dealt
by the Committee;(j)provide a child-friendly environment for children;(k)recommend fit
institutions to the State Government for the care and protection of children;(l)declare fit
persons;(m)declare a child legally free for adoption;(n)keep information about and take necessary
follow-up action in respect of missing children in their jurisdiction;(o)maintain liaison with the
Board in respect of cases needing care and protection;(p)visit each institution where children are
sent for care and protection or adoption at least once in three months to review the condition of
children in institutions, with support of the State Government and suggest necessary
action;(q)monitor associations and agencies within their jurisdiction that deal with children in order
to check on the exploitation and abuse of children;(r)co-ordinate with the Police, Labour
Department and other agencies involved in the care and protection of children with the support of
District Child Protection Unit or State Child Protection Unit or State Government;(s)liaison and
network with the corporate sector and non-governmental organisations for any of the above,
including for social inquiry, restoration and rehabilitation, as and when required; and(t)maintain a
suggestion box to encourage inputs from children and adults alike and take necessary action.
26. Procedure in relation to Committee.
(1)The quorum for the meeting shall be three members attending, which may include the
Chairperson.(2)Any decision taken by an individual member, when the Committee is not sitting,
shall require ratification by the Committee in its next sitting.(3)The Committee shall take into
consideration the age, developmental stage, physical and mental health, opinion of the child and the
recommendation of the child welfare officer or caseworker, prior to disposal of cases.(4)For final
disposal of a case, the order of the Committee shall be signed by at least two members, including the
Chairperson.
27. Production of a Child before the Committee.
(1)A child in need of care and protection shall be produced before the Committee within twenty-four
hours, excluding journey time, by one of the following persons-(a)any police officer or Special
Juvenile Police Unit or a designated police officer;(b)any public servant;(c)childline, a registered
voluntary organization or by such other voluntary organization or an agency as may be recognized
by the State Government;(d)social worker;(e)any public spirited citizen; or(f)by the child
himself.(2)Whenever the above mentioned person/s takes charge of Child in need of care &
protection, the information shall be given to the Police Control Room and Child Line as soon as
possible, giving the details of the child, the situation from which rescued, the time at which the
person took charge of the child including the place. The person taking charge of the child shall also
give his details like Name, Address and Organizations for which he is working and other relevant
details of members of the rescue team.(3)In case of a child under two years of age, who is medically
unfit, the person or the organization shall send a written report along with the photograph of theDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

child to the Committee within twenty-four hours and produce the child before the Committee as
soon as the child is medically fit along with a medical certificate to that effect.(4)The Committee can
suo motu take cognizance of cases brought to their notice and reach out to a child in need of care
and protection where necessary and the District or the State Child Protection Unit or the State
Government shall provide necessary support and assistance to the Committee for carrying out such
functions.(5)In case the Committee is not sitting, the child may be produced before the single
member of the Committee as per the provisions laid down under the sub-section (2) of section 30 of
the Act for being placed in safe custody of parent or guardian or fit person or fit institutions, as the
case may be, till such time that the child can be produced before the Committee.(6)In case the single
member is also not accessible, or that the hours are odd, the child shall be taken by an
non-governmental organisation or Childline or Police to an appropriate institution for children
registered under the Act with all the necessary documents, and placed in such institution till the
time of production before the Committee.(7)The concerned institution shall inform the Chairperson
or a member of the Committee about such child and produce the child before the Committee within
twenty four hours and in such cases, it may not be necessary for the person who brings a child in
need of care and protection to an institution to be present at the time of production of the child
before the Committee.(8)Whoever produces a child before the Committee shall submit a report on
the circumstances under which the child came to their notice and efforts made by them on
informing the police and the missing persons squad and in cases where a recognized voluntary
organization or any police personnel produce a child before the Committee, they shall also submit a
report on the efforts made by them for tracing the family of the child.(9)Any general medical or
gynaecological examination of children shall not be a pre-requisite for production of the child before
the Committee or admission in an institution.(10)The Committee shall facilitate the filing of a police
complaint and First Information Report in cases of missing children as well as matters of violence,
exploitation and abuse of children and arrange for required legal aid through the Legal Officer in the
District Child Protection Unit or District or State Legal Aid Services Authority or voluntary
organisations.(11)Each Committee shall send quarterly information about children in need of care
and protection received by them to the District or State Child Protection Unit or State
Government.(12)Children shall be provided a child-friendly environment during the proceedings of
the Committee.(13)The Committee shall have an empanelled list of lawyers, social workers and
mental health expert who may assist the Committee in dealing with cases of abused children and
who may also interface with the Public Prosecutor or Assistant Public Prosecutor to facilitate legal
services to the abused children, when the cases relating to such children are taken up in regular
criminal courts.(14)Every possible effort shall be made to trace the family with support from the
District Child Protection Unit, and assistance of recognized voluntary organizations, childline or
police may also be taken.(15)The Committee shall send the child to the designated place of safety,
with age and gender appropriate facilities, pending inquiry and in such eventuality, the District
Child Protection Unit or State Child Protection Unit or State Government shall provide transport or
make necessary budgetary allocations for such expenses based on the actual fare.(16)The child may
be escorted by the police officer or representative of the voluntary organization or by any other
arrangement as considered appropriate by the Committee with support from the District Child
Protection Unit and in case of a girl child, a female escort shall accompany the child.(17)A list of all
recognized child care institutions along with their capacity and appropriate facilities as prescribed
under section 34 of the Act, a list of all child related resource services and a list of contact details ofDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

all Child Welfare Committees across the country shall be provided to the Committee by the District
Child Protection Unit or State Government.(18)The Committee may, while making an order in Form
VIII placing a child under the care of a parent, guardian or fit person pending inquiry or at the time
of restoration, as the case may be, direct such parent, guardian or fit person to enter into an
undertaking in Form IX.(19)Whenever the Committee orders a child to be kept in an institution, it
shall forward to the Officer-in-charge of such institution a copy of the order of short term placement
pending inquiry, in Form X with particulars of the home and parents or guardian and previous
record.(20)Whenever the Committee orders a child to be kept in a fit institution as part of
restoration under clause (f) of sub- section (3) of section 39 of the Act, it shall forward a copy of its
order of restoration in Form XI to the Officer-in-charge of such institution.(21)The child shall be
placed in an institution closest to where his parents or guardians belong as far as possible, unless
the child has been subjected to abuse or exploitation by parents or guardians.
28. Procedure for inquiry.
(1)When a child is brought before the Committee, the Committee shall assign the case to a social
worker or caseworker or child welfare officer or Officer-in-charge as the case may be, of the
institution or any recognized agency for conducting the inquiry through an order in
Form-XII.(2)The Committee shall direct the concerned person or organization about the details or
particulars to be enquired into for developing an individual care plan and suitable
rehabilitation.(3)All inquiries conducted by a social worker or caseworker or child welfare officer or
Officer-in-charge of the institution or any recognized agency shall be as per Form-XIII and must
provide an assessment of the family situation of the child in detail, and explain in writing whether it
will be in the best interest of the child to restore him to his family.(4)The inquiry must be completed
within four months or within such shorter period as may be fixed by the Committee: Provided that
the Committee may, in the best interest of the child and for the reasons to be recorded in writing,
extend the said period under special circumstances.(5)After completion of the inquiry, if, the child is
under orders to continue in the children's home, the Committee shall direct the Officer-in-charge of
the home to submit quarterly progress report of such child and produce the child before the
Committee for an annual review of the progress.
29. Children's Homes.
(1)The State Government itself or in association with voluntary organizations, shall set up separate
homes for children in need of care and protection, in the manner specified below-(a)all children's
homes shall be registered as child care institutions under sub-section (3) of section 34 of the Act and
rule 71 of these rules;(b)all children's homes shall be certified as per the procedure laid down in rule
70;(c)all children's homes shall report to the concerned Committee about every child in need of care
and protection received by them;(d)children of both sexes below ten years may be kept in the same
home but separate facilities shall be maintained for boys and girls in the age group 5 to 10
years;(e)every children's home shall include separate facilities for children in the age group of 0-5
years with appropriate facilities for the infants;(f)separate children's homes shall be set up for boys
and girls in the age group 10 to 18 years;(g)children in the age group of 10 to 18 shall be further
segregated into two groups of 10 to 15 years and 15 to 18 years.(2)Each children home shall be aDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

comprehensive child care center with the primary objective to promote an integrated approach to
child care by involving the community and local Non-Governmental Organisations through the
Management Committee set up under rule 55 of these rules and the District Child Protection Unit or
State Child Protection Unit or the State Government shall make an annual performance review of
functioning of the children's homes.(3)The activities of such centre shall focus on:(a)preparing and
following individual care plans for every child, with rights based approach, specifically addressing
the child's physical and mental health, emotional needs, education, skill development, protection
and special needs if any;(b)family based non-institutional services, such as, foster family care,
adoption and sponsorship;(c)specialized services in situations of conflict or disaster and for juvenile
or children affected by terminal or incurable disease to prevent neglect by providing family
counselling, nutrition, health interventions, psycho-social interventions and
sponsorship;(d)emergency outreach service through childline (Toll free Help Line No.
1098);(e)linkages with Integrated Child Development Services to cater to the needs of children
below six years;(f)linkages with organizations and individuals who can provide support services to
children; and(g)opportunities to volunteers willing to provide various services for children.
30. Shelter Homes.
(1)For children in urgent need of care and protection, such as street children and run-away children,
the State Government shall support creation of requisite number of shelter homes or
drop-in-centres through the voluntary organizations.(2)Shelter homes shall include:(a)short-stay
homes for children needing temporary shelter, care and protection for a maximum period of one
year,(b)transitional homes providing immediate care and protection to a child for a maximum
period of four months,(c)24 hour drop-in-centres for children needing day care or night shelter
facility.(3)The shelter homes or drop-in-centres shall have the facilities of boarding and lodging,
besides the provision for fulfillment of basic needs in terms of clothing, food, health care and
nutrition, safe drinking water and sanitation.(4)There shall be separate shelter homes for girls and
boys as per rule 40(2)(d) of these rules.(5)All shelter homes shall provide requisite facilities for
education, vocational training, counselling and recreation or make arrangements for it in
collaboration with voluntary organizations or corporate sector.(6)The Committee, Special Juvenile
Police Units, public servants, Childlines, voluntary organizations, social workers and the children
themselves may refer a child to such shelter homes.(7)All shelter homes shall submit a report of
children using the shelter home facility along with a photograph of the child to the Committee, the
missing persons bureau or special juvenile police unit and the District Child Protection Unit or the
State Child Protection Unit.(8)The requirements of producing a child received by a shelter home
before the Committee, inquiry and disposal under sections 32, 33, 38 and 39 of the Act shall apply
only to shelter homes other than drop-in-centres as specified in rule 30(2)(c) of these rules.(9)The
services of Officer-in-charge, child welfare officer, social worker shall be provided for the proper
care, protection, development, rehabilitation and reintegration needs of children in shelter
homes.(10)No child shall ordinarily stay in a short stay home for more than a year except in special
circumstances with the approval of the Committee.Delhi Juvenile Justice (Care and Protection of Children) Rules, 2009

31. Guidelines for prevention of sexual abuse of children.
- The State Government, the Juvenile Justice Board, the Child Welfare Committee, other competent
authorities and agencies shall, in the best interest of children, ensure that every person, school or
such other educational institutions abide by the guidelines issued from time to time by Central
Government and State Government.
Chapter V
Rehabilitation and Social Reintegration
32. Rehabilitation and Social Reintegration.
- The primary aim of rehabilitation and social reintegration is to help children in restoring their
dignity and self-worth and main stream them through rehabilitation within the family where
possible, or otherwise through alternate care programmes and long-term institutional care shall be
of last resort.
33. Adoption.
(1)The primary aim of adoption is to provide a child who cannot be cared for by his biological
parents with a permanent substitute family.(2)For all matters relating to adoption, the guidelines
issued by the Central Adoption Resource Agency and notified by the Central Government under
sub-section (3) of section 41 of the Act, shall apply.(3)In case of orphaned and abandoned children
the following procedure shall apply, namely:-(a)Specialized Adoption Agencies shall produce all
orphaned and abandoned children who are to be declared legally free for adoption before the
Committee within twenty-four hours of receiving such children, excluding the time taken for
journey;(b)a child becomes eligible for adoption when the Committee has completed its inquiry and
declares the child legally free for adoption;(c)such declaration shall be made in Form XIV;(d)a child
must be produced before the Committee at the time of declaring such child legally free for
adoption;(e)whenever intimation is received by the police about an abandoned infant, the police
shall take charge of the infant and arrange to provide immediate medical assistance and
care;(f)subsequently, the child shall be placed in a specialized adoption agency or recognized and
certified children's home or in a paediatric unit of a Government hospital followed by production of
the child before the Committee within twenty-four hours;(g)procedure for declaring a child
abandoned and certifying him legally free for adoption;(i)in case of an abandoned child, the
recognized agency shall within twenty four hours, report and produce the child before the
Committee with the copy of the report filed with the police station in whose jurisdiction the child
was found abandoned;(ii)the Committee will institute a process of inquiry, which shall include a
thorough inquiry conducted by the Probation Officer or Child Welfare Officer, as the case may be
and who shall give report in Form XIII to the Committee containing the findings within one
month;(iii)there shall be a declaration by the specialized adoption agency, stating that there has
been no claimant for the child even after making notification in at least one leading national
newspaper and one regional language newspaper for children below two years of age and forDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

children above two years, an additional television or radio announcement and notification to the
missing persons squad or bureau shall be made;(iv)the steps stated in (iii) shall be taken within a
period of sixty days from the time when the child is found in case of a child below two years of age
and in case of children above two years of age, this period shall be four months;(v)the period of
notification shall run concurrently with the inquiry to be conducted and report submitted under
clause (ii) of this sub-rule;(vi)the Committee shall declare the child legally free for adoption on
completion of the process of inquiry, including declaration of the specialized adoption agency made
under clauses (ii) and (iii) of this sub-rule;(vii)no child above seven years who can understand and
express his opinion shall be declared free for adoption without his consent.(4)In case of surrendered
children the following procedure shall apply, namely:-(a)a surrendered child is one who had been
declared as such after due process of inquiry by the Committee and in order to be declared legally
free for adoption, a 'surrendered' child shall be any of the following:(i)born as a consequence of
non-consensual relationship;(ii)born of an unwed mother or out of wedlock;(iii)a child in whose
case one of the biological parents is dead and the living parent is incapacitated to take care;(iv)a
child where the parents or guardians are compelled to relinquish him due to physical, emotional and
social factors beyond their control;(b)serious efforts shall be made by the Committee for counselling
the parents, explaining the consequences of adoption and exploring the possibilities of parents
retaining the child and if, the parents are unwilling to retain, then, such children shall be kept
initially in foster care or arranged for their sponsorship;(c)if the surrender is inevitable, a deed of
surrender in Form XV shall be executed on a non judicial stamp paper in the presence of the
Committee;(d)the adoption agencies shall wait for completion of two months reconsideration time
given to the biological parent or parents after surrender;(e)in case of a child surrendered by his
biological parent or parents, the document of surrender shall be executed by the parent or parents
before the Committee;(f)after due inquiry, the Committee shall declare the surrendered child legally
free for adoption in Form XIII as the case may be after a sixty days' reconsideration period as per
Central Adoption Resource Agency guidelines.(5)For the purposes of section 41 of the Act, 'court'
implies a civil court, which has jurisdiction in matters of adoption and guardianship and may
include the court of the district judge, family courts and city civil court.
34. Foster Care.
(1)For children who cannot be placed in adoption, order shall be issued by the competent authority
in form XVII for carrying out foster care, as given in sub- section (2) of section 42 of the Act under
the supervision of a probation officer or case worker or social worker, as the case may be, and the
period of foster care shall depend on the need of the child.(2)Role of the Child Welfare
Committee:-(i)To select appropriate voluntary organization/s who shall assist the committee in all
reports about the foster care programme including first social investigation report in form XVI,
periodical follow up reports etc.(ii)To declare fit person for foster placement of the child.(iii)To send
the child to the children home for an initial period of one month for speedy inquiry.(iv)To order
placing of the child in foster care if found appropriate, in form XVII, initially for a period upto one
year. A copy of the order shall be sent to the officer incharge of the institution concerned, voluntary
organization, foster parents and the State Govt.(v)Follow up and supervision of the child with the
foster parents shall be done by the committee at such intervals as may be prescribed. Form XVI may
be used.(vi)To periodically review the foster care placements on the basis of any informationDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

received by it including the periodical reports (which should not be less than four in a year) of a
probation officer or case worker or social worker or voluntary organization, as the case may
be.(vii)On the basis of the aforesaid review and after giving the foster parents proper opportunity,
the committee may extend the period of foster placement or may revoke the foster placement of the
child in the foster family, duly explaining the reasons in its order. The committee may also consider
issuing orders under Section 23 to 28 of the Act, if necessary.(viii)To encourage and arrange
pre-foster placement meetings of the foster parents and the child with appropriate linkage and
co-ordination with the probation officer or case worker or social worker concerned.(ix)To maintain
complete records regarding foster placements.(x)The child placed in foster care may be encouraged
to spend few days in the children home to relate his experiences.(xi)To order the Drawing and
Disbursing Officer concerned to release the supplementary maintenance grant to the foster parents
and also the prescribed fees to the voluntary organizations, as per the existing norms.(xii)Foster
parents who wish to provide long term foster care for the child may be encouraged legal
guardianship of the child if the committee is satisfied with the progress of the child in the first two
years of foster placement.(xiii)Siblings, if any, shall be placed together with the same foster
parents.(3)Engagement of Voluntary Organization:-(i)Any organization desiring engagement under
these rules shall make an application together with a copy each of the rules, by laws, articles of
association, list of members of the society or the association running the organization, office-bearers
and a statement showing the status and past record of specialized child care services provided by the
organization to the Child Welfare Committee who shall after verifying the capacity of the
organization, in this regard may approve the engagement of the voluntary organization under these
rules on the condition that the organization shall always comply with the standards of services laid
down under the Act and the rules framed thereunder, from time to time.(ii)The voluntary
organization shall submit to the Child Welfare Committee concerned all reports as directed by the
committee in connection with the foster care placement, in the time prescribed by the committee.
These reports shall give all necessary details including the points covered in form XVI.(iii)The Child
Welfare Committee shall ensure payment of the prescribed fee to the voluntary organization for all
reports submitted by it, as per directions of the committee.(4)Recognition of fit persons for foster
placement:-(i)Any person desiring recognition under these rules as foster parent shall make an
application to the Child Welfare Committee. He/she shall enclose (with the application) consent of
the other spouse, if any, a certificate from a registered medical practitioner about the health
condition of all members of his/her family, a certificate of income from the employer or an affidavit
about the income attested by a magistrate in case of self-employed person, a character certificate
from a gazetted officer or recommendations from the local resident welfare association.(ii)The
decision to grant or withdraw the above recognition shall be taken by the committee after thorough
examination of the reports submitted by the welfare officer and/ or voluntary organization.(iii)The
committee may transfer the custody of a child kept in foster care from one fit person to another duly
explaining reasons therefor. The person concerned shall transfer custody of the child within 48
hours of such order by the committee, failing which the committee shall take appropriate action
under the law.(iv)The foster parents shall:-(a)treat the child with love and affection and ensure a
suitable atmosphere conducive to the child overall growth and development.(b)ensure that the child
is provided proper education.(c)allow the visits of biological parents of the child and respect their
views on the child's care and development.(d)comply with the directions given by the Child Welfare
Committee and the State Government with due urgency.(e)attend the Child Welfare CommitteeDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

whenever called to discuss the future plan in respect of the child.(f)submit to the Welfare Officer or
the authorized voluntary organization information about the child's health, education, behaviour,
conduct and any such matters concerning the child as may be required from time to time.(g)return
the child to the Child Welfare Committee whenever so directed by the committee.(h)intimate
immediately the welfare officer, Child Welfare Committee and the voluntary organization in case the
child is seriously ill.(i)intimate about the change of residential address to the Child Welfare
Committee and the voluntary organization concerned.(j)take written permission of the Child
Welfare Committee before taking the child out of station for more than a week.(k)Immediately
inform the Police and the committee if the child placed in foster care goes missing.
35. Criteria for selection of families for foster care.
(1)In case of the children covered under rule 34 of these rules, the following criteria shall apply for
selection of families for foster care, namely:-(i)foster parents should have stable emotional
adjustment within the family;(ii)foster parents should have an income in which they are able to
meet the needs of the child and are not dependent on the foster care maintenance payment;(iii)the
monthly family income shall be adequate to take care of foster children and approved by the
Committee;(iv)medical reports of all the members of the family residing in the premises should be
obtained including checks on Human Immuno Deficiency Virus (HIV), Tuberculosis (TB) and
Hepatitis B to determine that they are medically fit;(v)the foster parents should have experience in
child caring and the capacity to provide good child care;(vi)the foster parents should be physically,
mentally and emotionally stable;(vii)the home should have adequate space and basic
facilities;(viii)the foster care family should be willing to follow rules laid down including regular
visits to pediatrician, maintenance of child health and their records;(ix)the family should be willing
to sign an agreement and to return the child to the specialized adoption agency whenever called to
do so;(x)the foster parents should be willing to attend training or orientation programmes;
and(xi)the foster parents should be willing to take the child for regular (at least once a month in the
case of infants) checkups to a paediatrician approved by the agency.(xii)Parents who have been
residing within NCT of Delhi for at least 3 years.(2)There shall be no discrimination in selection of
foster-parents on the basis of caste, religion, ethnic status, disability, or health status and the best
interest of the child shall be paramount in deciding foster-care placement.(3)The foster parents shall
be declared 'fit persons' by the Committee before placing the child as per the provisions laid down in
clause (i) of section 2 of the Act after thorough assessment done by the Child Welfare Officer or
Social Worker as per Form XVI.
36. Pre-adoption Foster Care.
- In case of pre-adoption foster care, the provisions contained in sub-section (1) of section 42 and
the corresponding guidelines notified under subsection (3) of section 41 of the Act, shall apply.
37. Sponsorship.
(1)The State Government shall prepare sponsorship programme in consultation with the Non
Governmental Organisations, Child Welfare Committees, other relevant government agencies andDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

the corporate sector.(2)The State Government, with the help of District or State Child Protection
Units shall identify families and children at risk and provide necessary support services in the form
of sponsorship for child's education, health, nutrition and other developmental needs.(3)The
children's homes and special homes shall promote sponsorship programmes as laid down in section
43 of the Act.(4)The institutions receiving sponsorship, shall maintain proper and separate accounts
of all the receipts and payments for the programme.(5)The Board or the Committee shall make an
order in Form XVIII for support to a juvenile or child through sponsorship and send a copy to the
District or State Child Protection Unit or the State Government for appropriate action.
38. After Care Organisation.
(1)The State Government may set up an after care programme for care of juveniles or children after
they leave special homes and children's homes.(2)After care programmes may be made available for
18-21 year old persons, who have been pursuing education or vocational training in the institutions
and have no place to go to or are unable to support themselves, by the District or State Child
Protection Units in collaboration with voluntary organizations for the purpose of section 44 of the
Act and this rule.(3)Once the Board or the Committee passes an order in Form XIX for placing a
juvenile or a child completing 18 years of age under the after care programme, a copy of such order
shall be sent to the District and the State Child Protection Unit and the State Government, who shall
be responsible for arranging after care.(4)The Board or the Committee shall have jurisdiction over
persons placed in after care programme.(5)The objective of these organisations shall be to enable
such children to adapt to the society and during their stay in these transitional homes these children
will be encouraged to move away from an institution-based life to a normal one.(6)The key
components of the programme shall include:-(a)community group housing on a temporary basis for
groups of young persons aged 18-21 years;(b)encouragement to learn a vocation or gain employment
and contribute towards the rent as well as the running of the home;(c)encouragement to gradually
sustain themselves without state support and move out of the group home to stay in a place of their
own after saving sufficient amount through their earnings;(d)provision for a peer counsellor to stay
in regular contact with these groups to discuss their rehabilitation plans and provide creative outlets
for their energy and to tide over crisis periods in their life.(7)During the course of vocational
training a stipend may be provided till such time that the youth gets employment.(8)Loans may be
arranged for the youth in an after care programme aspiring to set up entrepreneurial activities on
the basis of an application made by them and due verification of the need for such a loan, and
necessary professional advice and training shall be made available to the youth in the after care
programme in this regard.(9)The structure shall include 6 to 8 youths in each group home who may
opt to stay together on their own and one peer counsellor for a cluster of five group homes.
39. Linkages and co-ordination.
(1)The State Government shall circulate a copy of the Act and the rules framed thereunder to
establish effective linkages between various government, non-government, corporate and other
community agencies for facilitating the rehabilitation and social reintegration of juveniles or
children through the Board or the Committee as the case may be.(2)The State Government with the
help of State or District Child Protection Unit shall identify the roles and responsibilities of eachDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

department at State or district levels for effective implementation of the Act and the rules and
inform them through a notification.(3)The State Government with the help of State or District Child
Protection Unit shall arrange for appropriate training and sensitization of functionaries of these
departments from time to time in coordination with National Institute of Public Cooperation and
Child Development and its Regional Centres.(4)The State Government with the help of State or
District Child Protection Unit shall develop effective networking and linkages with local
non-governmental organisations for specialized services and technical assistance like vocational
training, education, health care, nutrition, mental health intervention, drug de-addition and legal
aid services.
Chapter VI
Standards of Care for Institutions
40. Physical infrastructure.
(1)The homes for juveniles in conflict with law and children in need of care and protection shall
function from separate premises which should be accessible to persons with special needs.(2)The
accommodation in each institution shall be as per the following criteria, namely:-(a)Observation
Home:(i)Separate observation homes for girls and boys;(ii)Classification and segregation of
juveniles according to their age group preferably 7-12 years, 13-15years and 16-18 years, giving due
consideration to physical and mental status and the nature of the offence committed.(b)Special
Home:(i)Separate special homes for girls above the age of 10 years and boys in the age groups of 11
to 15 and 16 to 18 years;(ii)Classification and segregation of juveniles on the basis of age and nature
of offences and their mental and physical status(c)Children's Home:(i)While children of both sexes
below 10 years can be kept in the same home, separate bathing and sleeping facilities shall be
maintained for boys and girls in the age group of 0-5 years;(ii)Separate facilities for children in the
age group of 0-5 years with appropriate facilities for infants.(d)Shelter Home:(i)Separate shelter
homes for girls and boys;(ii)Separate shelter homes for girls above the age of 10 years and boys in
the age groups of 11 to 15 and 16 to 18 years.(3)The norms for building or accommodation for an
institution with 50 juveniles or children may be as under:(i)2 Dormitories Each 1000 Sq. ft. for 25
juveniles/children i.e. 2000 Sq. ft.(ii)2 Classrooms 300 Sq. ft. for 25 juveniles/children i.e. 600 Sq.
ft.(iii)Sickroom/First aid room 75 Sq. ft. per juvenile/children for 10 i.e. 750 Sq. ft.(iv)Kitchen 250
Sq. ft.(v)Dining Hall 800 Sq. ft.(vi)Store 250 Sq. ft.(vii)Recreation room 300 Sq. ft.(viii)Library 500
Sq. ft.(ix)5 bathrooms 25 Sq. ft. each i.e. 125 Sq. ft.(x)8 toilets/latrines 25 Sq. ft. each i.e. 200 Sq.
ft.(xi)Office rooms (a) 300 Sq. ft. (b) Superintendent's room 200 sq. fit(xii)Counselling and
guidance room 120 Sq. ft.(xiii)Workshop 1125 Sq. ft. for 15 juvenile @75 Sq. ft. per
trainee(xiv)Residence for Superintendent (a) 2 rooms of 250 Sq. ft. each (b) kitchen 75 Sq. ft. (c)
bathroom-cum-Toilet/latrine 50 Sq. ft(xv)Play ground Sufficient area according to the total number
of juveniles or children(4)The Superintendent shall stay within the institution and be provided with
quarters and in case he is not able to stay in the home for legitimate reasons (to be permitted by
Director, Child Protection), any other senior staff member of the institution shall stay in the
institution and be in a position to supervise the overall care of the children or juveniles and, take
decisions in the case of any crisis and emergency.(5)(i)the standards of accommodation as per theDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

norms laid down in rule 40 (3) shall be observed to the extent possible and shall include a minimum
of following facilities :(a)Dormitory: 40 Sq. ft. per juvenile or child(b)Classroom: 300 Sq. ft for 25
juvenile or child(c)Workshop: 75 Sq. ft. per juvenile or child(d)Play ground: Sufficient play ground
area shall be provided in every institution according to the total number of juveniles in
institution.(ii)there shall be proper and smooth flooring for preventing accidents.(iii)there shall be
adequate lighting, ventilation, heating and cooling arrangements, safe drinking water and clean
toilets, in terms of gender, age appropriateness and accessibility to persons with disability.(iv)all
institutions under the Act shall make provision of first aid kit, fire extinguishers in kitchen,
dormitories, store rooms, counselling room, periodic review of electrical installations, proper
storage and inspection of articles of food stuffs, stand-by arrangements for water storage and
emergency lighting.(6)The Observation homes and special homes shall be child-friendly and in no
way shall they look like a jail or lock-up.
41. Clothing and Bedding.
- The clothing and bedding shall be as per the scale and climatic conditions. The requirements of
each juvenile or child and the minimum standards for clothing and bedding are laid down in
Schedule-I of these rules.
42. Sanitation and Hygiene.
- Every institution shall have the following facilities, namely:-(a)sufficient treated drinking water;
water filters shall be installed;(b)sufficient water for bathing and washing clothes, maintenance and
cleanliness of the premises;(c)proper drainage system;(d)arrangements for disposal of
garbage;(e)protection from mosquitoes by providing mosquito nets;(f)annual pest
control;(g)sufficient number of well lit and airy toilets in the proportion of at least one toilet for
seven children;(h)sufficient number of well lit and airy bathrooms in the proportion of at least one
bath room for ten children;(i)sufficient space for washing;(j)clean and fly-proof kitchen and
separate area for washing utensils;(k)sunning of bedding and clothing;(l)maintenance of cleanliness
in the Medical Centre.
43. Daily Routine.
(1)Every institution shall have a daily routine for the juveniles or children developed in consultation
with the Children's Committees, which shall be prominently displayed at various places within the
institution.(2)The daily routine shall provide, inter alia, for a regulated and disciplined life, personal
hygiene and cleanliness, physical exercise, yoga, educational classes, vocational training, organized
recreation and games, moral education, group activities, prayer and community singing and special
programmes for sundays and holidays.
44. Nutrition and Diet Scale.
- The following nutrition and diet scale shall be followed by the institutions, namely:-(a)the childrenDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

shall be provided four meals in a day including breakfast;(b)the menu shall be prepared with the
help of a nutritional expert or doctor to ensure balanced diet and variety in taste as per the
minimum nutritional standard and diet scale set out in Schedule II of these rules;(c)every
institution under this Act shall strictly adhere to the minimum nutritional standard and diet scale
specified in Schedule II;(d)juveniles or children may be provided special meals on holidays and
festivals;(e)infants and sick juveniles or children shall be provided special diet according to the
advise of the doctor on their dietary requirement.
45. Medical Care.
- Every institution shall:(a)maintain a medical record of each juvenile or child on the basis of
monthly medical check-up and provide necessary medical facilities;(b)ensure that the medical
record includes weight and height record, any sickness and treatment, and other physical or mental
problem;(c)have arrangement for the medical facilities, including a doctor on call available on all
working days for regular medical check-ups and treatment of juveniles or children;(d)have sufficient
medical equipments to handle minor health problems including first aid kit with stock of emergency
medicines and consumables;(e)train all staff in handling first aid;(f)tie-up with local Primary Health
Centre, government hospital, medical colleges, other hospitals, clinical psychologists and
psychiatrists and mental health institutes for regular visits by their doctors and students and for
holding periodic health camps within the institutions;(g)make necessary arrangements for the
immunization coverage and maintain proper records in respect thereof;(h)take preventive measures
against out break of contagious or infectious diseases;(i)set up a system for referral of cases with
deteriorating health or serious cases to the nearest civil hospital or recognised treatment
centres;(j)keep sick children under constant medical supervision;(k)admit a juvenile or child
without insisting on a medical certificate at the time of admission;(l)arrange for a medical
examination of each juvenile or child admitted in an institution by the Medical Officer within twenty
four hours and in special cases or medical emergencies immediately;(m)arrange for a medical
examination of the juvenile or child by the Medical Officer at the time of transfer within twenty four
hours before transfer;(n)not carry out any surgical treatment on any juvenile or child without the
previous consent of his parent or guardian, unless either the parent or guardian cannot be found
and the condition of the juvenile or child is such that any delay shall, in the opinion of the medical
officer, involve unnecessary suffering or injury to the health of the juvenile or child, or otherwise
without obtaining a written consent to this effect from the Officer-in-charge of the
institution;(o)provide or arrange for regular counselling of every juvenile or child and ensure
specific mental health interventions for those in need of such services, including separate rooms for
counselling sessions within the premises of the institution;(p)refer such children who require
specialized drug abuse prevention and rehabilitation programme, to an appropriate centre
administered by qualified personnel where these programmes shall be adopted to the age, gender
and other specifications of the concerned child.
46. Mental Health.
(1)A mental health record of every juvenile or child shall be maintained by the concerned
institutions.(2)Both mileu based interventions that is creating an enabling environment for childrenDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

and individual therapy are must for every child and shall be provided in all institutions.Explanation.
- For the purpose of this sub-rule, mileu based intervention is a process of recovery, which starts
through providing an enabling culture and environment in an institution so as to ensure that each
child's abilities are discovered and they have choices and right to take to decisions regarding their
life and thus, they develop and identify beyond their negative experiences and such intervention has
a critical emotional impact on the child.(3)The environment in an institution shall be free from
abuse, allowing juveniles or children to cope with their situation and regain confidence.(4)All
persons involved in taking care of the juveniles or children in an institution shall participate in
facilitating an enabling environment and work in collaboration with the therapists.(5)Individual
therapy is a specialized process and each institution shall make provisions for it as a critical mental
health intervention.(6)Every institution shall have the services of trained counselors or
collaboration with external agencies such as child guidance centres, psychology and psychiatric
departments or similar government and non-governmental agencies, for specialized and regular
individual therapy for every juvenile or child in the institution.(7)A mental health care plan shall be
developed for every juvenile or child by the child welfare officers in consultation with mental health
experts associated with the institution and integrated into the individual care plan of the concerned
juvenile or child.(8)The recommendations of mental health experts shall be maintained in every
case file and integrated into the care plan for every child.(9)All care plans shall be produced before
the Management Committee set up under rule 55 of these rules every month and before the Child
Welfare Committee every quarter.(10)No juvenile or child shall be administered medication for
mental health problems without a psychological evaluation and diagnosis by appropriately trained
mental health professionals.
47. Education.
(1)Every institution shall provide education to all juveniles or children according to the age and
ability, both inside the institution or outside, as per the requirement.(2)There shall be a range of
educational opportunities including, mainstream inclusive schools, bridge school, open schooling,
non formal education and learning and input from special educators where needed.(3)Wherever
necessary, extra coaching shall be made available to school going children in the institutions by
encouraging volunteer services or tying up with coaching centers.
48. Vocational Training.
(a)Every institution shall provide gainful vocational training to juveniles or children.(b)The
institutions shall develop networking with Institute of Technical Instruction, Jan Shikshan
Sansthan, Government and Private Organization or Enterprises, Agencies or nongovernmental
organisations with expertise or placement agencies.(c)Superintendent of the Institution shall make
reasonable efforts for placement of children of 16-18 years of age as an apprentice.
49. Recreation facilities.
(1)A provision of guided recreation shall be made available to all juveniles or children in the
institutions.(2)It shall include indoor and outdoor games, music, television, picnics and outings,Delhi Juvenile Justice (Care and Protection of Children) Rules, 2009

cultural programmes and library.
50. Institutional Management of juveniles or children.
(1)The following procedure shall be followed in respect of the newly admitted juveniles:(a)receiving
and search;(b)disinfection and storing of juvenile's personal belongings and other valuables;(c)bath
and haircut (unless prohibited by religion);(d)issue of toiletry items; new set of clothes, bedding and
other outfit and equipment (as per scales);(e)medical examination and treatment where necessary
and in case of every juvenile suspected to be suffering from contagious or infectious diseases, mental
ailments or addiction;(f)segregation in specially earmarked dormitories or wards or hospitals in
case of a child suffering from contagious disease requiring special care and caution;(g)attending to
immediate and urgent needs of the juveniles like appearing in examinations, interview letter to
parents, personal problems and verification by the Officer-in-charge of age of juvenile as per order
of the Board.(2)Every newly admitted juvenile or child shall be placed under the care of specific
welfare officer or social worker or counsellor attached to the institutions or voluntary social worker
or counsellor.(3)Every newly admitted juvenile shall be familiarized with the institution and its
functioning and shall receive orientation in the following areas:(a)personal health, hygiene and
sanitation;(b)institutional discipline and standards of behaviour, respect for elders and
teachers;(c)daily routine, peer interaction, optimum use of developmental opportunities;
and(d)rights, responsibilities and obligations within the institution.(4)The designated officer shall
enter the name of the juvenile or child in the Admission Register and allocate appropriate
accommodation facility.(5)The photograph shall also be taken immediately for records and the case
worker or probation officer or welfare officer shall begin the investigation and correspondence with
the person, the juvenile or child might have named.(6)The Officer-in-charge shall see that the
personal belongings of the juvenile or child received by the institution is kept in safe custody and
recorded in the Personal Belonging Register and the item must be returned to the juvenile or child
when he leaves the institution.(7)The girl juvenile or child shall be searched by a female member of
the staff, and with due regard to decency and dignity of the juvenile or child.(8)The educational level
and vocational aptitude of the juvenile admitted, may be assessed on the basis of test and interview
conducted by the teacher, the workshop supervisor and other technical staff and necessary linkages
may also be established with outside specialists and community-based welfare agencies,
psychologist, psychiatrist, child guidance clinic, hospital and local doctors, open school or Jan
Sikshan Sansthan.(9)A case history of the juvenile or the child admitted to an institution shall be
maintained as per Form XX, which shall contain information regarding his socio-cultural and
economic background and these informations may invariably be collected through all possible and
available sources, including home, parents or guardians, employer, school, friends and
community.(10)A well conceived programme of pre-release planning and follow up of cases
discharged from special homes shall be organized in all institutions in close collaboration with
existing governmental and voluntary welfare organizations.(11)In the event of a juvenile or child
leaving the institution without permission or committing an offence within the institution, the
information shall be sent by the officer-in-charge of the concerned institution to the police and the
family, if known; and the detailed report of circumstances along with the efforts to trace the juvenile
or child where the juvenile or child is missing, shall be sent to the Board or Committee, as the case
may be.(12)An individual care plan for every juvenile or child in institutional care shall be developedDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

with the ultimate aim of the child being rehabilitated and re-integrated based on their case history,
circumstances and individual needs and the individual care plan shall be based on following
guidelines:(a)the Officer-in-charge, counsellor along with the child welfare officer or case worker, or
social worker shall prepare an individual care plan for every child in an institution within one month
of his admittance as per Form XXI;(b)all care plans shall include a plan for the juvenile's or child's
restoration, rehabilitation, reintegration and follow-up;(c)the care plan shall be reviewed quarterly
by the Management Committee set up under rule 55 of these rules for appropriate development and
rehabilitation including options for release or restoration to family or foster care or
adoption;(d)juveniles or children shall be consulted while determining their care plan;(e)continuity
of care plan shall be ensured in cases of transfer or repatriation or restoration.
51. Prohibited Articles.
- No person shall bring into the institution the following prohibited articles, namely:(a)fire-arms or
other weapons, whether requiring license or not (like knife, blades, lathi, spears and
swords);(b)alcohol and spirit of any description;(c)bhang, ganja, opium or other narcotic or
psychotropic substances;(d)tobacco; or(e)any other article specified in this behalf by the State
Government by a general or special order.
52. Articles found on search and inspection.
(1)The Officer-in-Charge shall see that every juvenile received in the institution is searched, his
personal belongings inspected and money or any valuables found with the juvenile is kept in the safe
custody of the Officer-in- Charge.(2)The girls shall be searched by a female member of the staff and
both the girls and boys shall be searched with due regard to decency and dignity.(3)In every
institution, a record of money, valuables and other articles found with a juvenile shall be maintained
in the "Personal Belongings Register".(4)The entries made in the Personal Belongings Register,
relating to each juvenile, shall be read over to juvenile in the presence of a witness, whose signature
shall be obtained in token of the correctness of such entries and it shall be countersigned by the
Officer-in-Charge.
53. Disposal of articles.
- The money or valuables belonging to a juvenile received or retained in an institution shall be
disposed of in the following manner, namely:(a)on an order made by the competent authority in
respect of any juvenile, directing the juvenile to be sent to an institution, the Officer-in-Charge shall
deposit such juvenile's money together with the sale proceeds in the manner laid down from time to
time in the name of the juvenile;(b)the juvenile's money shall be kept with the Officer-in-Charge and
valuables, clothing, bedding and other articles, if any, shall be kept in safe custody;(c)when such
juvenile is transferred from one institution to another, all his money, valuables and other articles,
shall be sent along with the juvenile to the Officer-in-Charge of the institution to which he has been
transferred together with a full and correct statement of the description and estimated value
thereof;(d)at the time of release of such juvenile, the valuables and other articles kept in safe
custody and the money deposited in name of the juvenile shall be handed over to the parent orDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

guardian, as the case may be, with an entry made in this behalf in the register and signed by the
Officer-in-Charge;(e)when a juvenile in an institution dies, the valuable and other articles left by the
deceased and the money deposited in the name of the juvenile shall be handed over by the
Officer-in-Charge to any person who establishes his claim thereto and executes an indemnity
bond;(f)a receipt shall be obtained from such person for having received such valuables and other
articles and the amount;(g)if no claimant appears within a period of six months from the date of
death or escape of such juvenile, the valuables and other articles and amount shall be disposed of as
per the decision taken by Management Committee set up under rule 55 of these rules.
54. Maintenance of case file.
(1)The case file of each juvenile and child shall be maintained in the institution containing the
following information:(a)report of the person or agency who produced the juvenile before the
Board;(b)officer-in-charge's, probation officer's or child welfare officer's, counsellor's and
caseworkers reports;(c)information from previous institution;(d)report of the initial interaction
with the juvenile, information from family members, relatives, community, friends and
miscellaneous information;(e)source of further information;(f)observation reports from staff
members;(g)regular health status reports from Medical Officer, drug de-addiction progress reports,
progress reports vis-a-vis psychological counselling or any other mental health intervention, where
applicable;(h)Intelligence Quotient (I.Q) testing, aptitude testing, educational or vocational
tests;(i)social history;(j)summary and analysis by case-worker and Officer-in-charge;(k)instruction
regarding training and treatment programme and about special precautions to be taken;(l)leave and
other privileges granted;(m)special achievements and violation of rules, if any, ;(n)quarterly
progress report;(o)individual care plan, including pre-release programme, post release plan and
follow-up plan as prescribed in Form XXI;(p)leave of absence or release under supervision;(q)final
discharge;(r)follow-up reports;(s)annual photograph;(t)case history duly filled in prescribed Form
XX;(u)follow-up report of post release cases as per direction of the competent authority if any;
and(v)remarks.(2)All the case files maintained by the institutions and the Board or Committee shall,
as far as possible, be computerised and networked so that the data is centrally available to the State
and the District Child Protection Unit and the State Government.
55. Management Committee.
(1)Every institution shall have a Management Committee for the management of the institution and
monitoring the progress of every juvenile and child.(2)In order to ensure proper care and treatment
as per the individual care plans, a juvenile or child shall be grouped on the basis of age, nature of
offence or kind of care required, physical and mental health and length of stay order.(3)The
Management Committee shall consist of the following personnel:
District Child Protection Officer (District Child ProtectionUnit) - Chairperson
Officer-in-Charge-
Member-Secretary
Probation Officer or Child Welfare Officer or Case Worker - MemberDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

Medical Officer - Member
Psychologist or Counsellor - Member
Workshop Supervisor or Instructor in Vocation - Member
Teacher - Member
Social Worker Member of Juvenile Justice Board or ChildWelfare Committee - Member
A juvenile or child representative from each of the Children'sCommittees (on a
monthly rotation basis to ensure representationof juveniles or children from all
age groups)- Member
A representative from Senior Citizen forum and/or ResidentWelfare
Association- Member/s
One Non-Government Organization Representative - Member
(4)Where voluntary organizations are involved in providing professional and technical services like
education, vocational training, psychosocial care, mental health intervention and legal aid, the
Management Committee may invite a representative of such voluntary organizations as a special
invitee to the Management Committee meetings.(5)(a)The Management Committee shall meet every
month to consider and review :(i)custodial care or care in the institution, housing, area of activity
and type of supervision or interventions required;(ii)medical facilities and treatment;(iii)food,
water, sanitation and hygiene conditions;(iv)mental health interventions with the juveniles and
children;(v)individual problems of juveniles and children, provision of legal aid services and
institutional adjustment, leading to the quarterly review of individual care plans;(vi)vocational
training and opportunities for employment;(vii)education and life skills development
programmes;(viii)social adjustment, recreation, group work activities, guidance and
counseling;(ix)review of progress, adjustment and modification of residential programmes to the
needs of the juveniles and children;(x)planning post-release or post-restoration rehabilitation
programme and follow up for a period of two years in collaboration with aftercare
services;(xi)pre-release or pre-restoration preparation;(xii)release or restoration;(xiii)post release
or post-restoration follow-up;(xiv)minimum standards of care, including infrastructure and services
available;(xv)daily routine;(xvi)community participation and voluntarism in the residential life of
children such as education, vocational activities, recreation and hobby;(xvii)oversee that all registers
as required under the Act and rules are maintained by the institution, check and verify these
registers, duly stamped and signed in the monthly review meetings;(xviii)matters concerning the
Children's Committees;(xix)any other matter which the Officer-in-Charge may like to bring
up.(b)The officer-in-charge or child welfare officer shall file a quarterly progress report of every
juvenile or child in the case file and send a copy to the District Child Protection Unit and Board or
Committee, as the case may be.(6)The Management Committee shall set up a complaint and redress
mechanism in every institution and a Children's Suggestion Box shall be installed in every
institution at a place easily accessible to juveniles and children away from the office set up and
closer to the residence or rooms or dormitories of the children.(7)(a)The Children's Suggestion Box,
whose key shall remain in the custody of the Chairperson of the Management Committee, shall be
checked every week by the Chairperson of the Management Committee or his representative from
District Child Protection Unit, in the presence of the members of the Children's Committees.(b)If
there is a problem or suggestion that requires immediate attention, the chairperson of the
Management Committee shall call for an emergency meeting of the Management Committee toDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

discuss and take necessary action.(c)The quorum for conducting the emergency meetings shall be
five members, including two members of Children's Committees, Chairperson of the Management
Committee, Member of Committee or the Board as the case may be and the Officer-in-Charge of the
institution.(d)In the event of a serious allegation or complaint against the Officer-in-Charge of the
institution, he shall not be part of the emergency meeting and another available member of the
Management Committee shall be included in his place.(e)All suggestions received through the
suggestion box and action taken as a result of the decisions made in the emergency meeting or
action required to be taken shall be placed for discussion and review in the monthly meeting of the
Management Committee.(8)A Children's Suggestion Book shall be maintained in every institution
where the complaints and action taken by the Management Committee are duly recorded and such
action and follow up shall be communicated to the Children's Committees after every monthly
meeting of the Management Committee.(9)The Board or Committee shall review the Children's
Suggestion Book at least once in three months.
56. Children's Committees.
(1)Officer-in-Charge of every institution for juveniles or children shall facilitate the setting up of
Children's Committees for three different age groups of children, viz., 7-12 years, 13-15 years and
16-18 years and these Children's Committees shall be constituted solely by children.(2)Such
Children's Committee shall be encouraged to participate in following activities:(a)improvement of
the condition of the institution;(b)reviewing the standards of care being followed;(c)preparing daily
routine and diet scale;(d)developing educational, vocational and recreation plans;(e)supporting
each other in managing crisis;(f)reporting abuse and exploitation by peers and
caregivers;(g)creative expression of their views through wall papers or newsletters or paintings or
music or theater;(h)management of institution through the Management Committee.(3)The
Officer-in-Charge shall ensure that the Children's Committees meet every month and maintain a
register for recording its activities and proceedings, and place it before the Management Committee
in their monthly meetings.(4)The Officer-in-Charge shall ensure that the Children's Committees are
provided with essential support and materials including stationary, space and guidance for effective
functioning.(5)The Officer-in-Charge shall, as far as possible, seek assistance from local voluntary
organization or child participation experts for the setting up and functioning of the Children's
Committees.(6)The local voluntary organization or child participation expert shall support the
Children's Committees in the following:(a)selecting their leaders;(b)conducting the monthly
meetings;(c)developing rules for the functioning of Children's Committees and following
it;(d)maintaining records and Children's Suggestion Book and other relevant documents;(e)any
other innovative activity.(7)The Management Committee shall seek a report from the
Officer-in-Charge on the setting up and functioning of the Children's Committees, review these
reports in their monthly meetings and take necessary action where required.
57. Rewards and Earnings.
- The rewards to a juvenile or child, at such rates as may be fixed by the management of the
institution from time to time, may be granted by the Officer-in-Charge as an encouragement to
steady work and good behaviour; and at the time of release, the reward shall be handed over afterDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

obtaining a receipt from the parent or the guardian who comes to take charge of the juvenile or child
or juvenile or child himself.
58. Visits to and communication with juveniles or children.
(1)The parents and relatives of the juveniles or children shall be allowed to visit atleast twice in a
month or in special cases, more frequently at the discretion of the Officer-in-Charge as per the
visiting hours laid down by him, except where parents or relatives or guardian have been found to be
responsible for subjecting the juvenile or child to violence, abuse and exploitation.(2)The receipt of
letters by the juveniles or children of the institution shall not be restricted and they shall have
freedom to write as many letters as they like at all reasonable times; and the institution shall ensure
that where parents, guardians or relatives are known, at least one letter is written by the juvenile or
children every month for which the postage shall be provided by the institution.(3)The
Officer-in-Charge may peruse any letter written by or to the juvenile or children, and may for the
reasons that he considers sufficient refuse to deliver or issue the letter and forward it to the
Committee after recording his reasons in a book maintained for the purpose.(4)The
Officer-in-Charge shall, in special circumstances or as per orders of the Board or Committee, allow a
juvenile or child to make telephonic communication with his parents or guardians or relatives.
59. Death of a juvenile or child.
- On the occurrence of any case of death or suicide in an institution the procedure to be adopted
shall be as under : -(1)In the event of an unnatural death or suicide of a juvenile or child in an
institution it is imperative for the institution to ensure that an inquest and post-mortem
examination is held at the earliest.(2)In case of natural death or due to illness of a juvenile or child,
the Officer-in-charge shall obtain a report of the Medical Officer stating the cause of death and a
written intimation about the death shall be given immediately to the State Government, nearest
Police Station, the Board or Committee, the Delhi Commission for Protection of Child Rights, and
National Human Rights Commission (in case of custodial institutions), any other concerned
authority and the parents or guardians or relatives of the juvenile or child.(3)Whenever a sudden or
violent death or death from suicide or accident takes place, immediate information shall be given by
the case-worker or probation officer or welfare officer to the Officer-in-Charge and the Medical
Officer and the Officer-in-Charge shall immediately inform the nearest police station, Board or
Committee and parents or guardians or relatives of the deceased juvenile or child.(4)If a juvenile or
child dies within twenty four hours of his admission to the institution, the Officer-in-charge of the
institution shall report the matter to the officer-in-charge of the Police Station having jurisdiction
and the District Medical Officer or the nearest Government Hospital and the parents or guardians or
relatives of such juvenile or child without delay.(5)The Officer-in-charge shall also immediately give
intimation to nearest Magistrate empowered to hold inquests and to the Board or as the case may be
the Committee.(6)The Officer-in-Charge and the Medical Officer at the institution shall record the
circumstances of the death of the child and send a report to the concerned Magistrate, the
Officer-in-charge of the police station having jurisdiction, the Committee and the District Medical
Officer or the nearest government hospital where the dead body of the juvenile or child is sent for
examination, inspection and determination of the cause of death and the Officer-in-charge and theDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

Medical Officer shall also record in writing their views on the cause of the death if any, and submit it
to the concerned Magistrate and the Officer-in-charge of the police station having
jurisdiction.(7)The officer-in-charge and the Medical Officer shall make themselves available for any
inquiries initiated by the police or the Magistrate concerning the cause of death and other details
regarding such juvenile or child.(8)As soon as the inquest is held, the body shall be handed over to
the parents or guardian or relatives or, in the absence of any claimant, the last rituals shall be
performed under the supervision of the officer-in-charge in accordance with the known religion of
the juvenile or child.
60. Abuse and exploitation of the juvenile or child.
(1)Every institution shall have systems of ensuring that there is no abuse, neglect and maltreatment
and this shall include the staff being aware of what constitutes abuse, neglect and maltreatment as
well as early indicators of abuse, neglect and maltreatment and how to respond to these.(2)In the
event of any physical, sexual or emotional abuse, including neglect of juveniles and children in an
institution by those responsible for care and protection, the following action shall be taken:(i)the
incidence of abuse and exploitation must be reported by any staff member of the institution
immediately to the Officer-in-Charge on receiving such information;(ii)when an allegation of
physical, sexual or emotional abuse comes to the knowledge of the Officer-in-Charge, a report shall
be placed before the Board or Committee, which in turn, may transfer such a juvenile or child to
another institution or place of safety or fit person and shall order for special investigation;(iii)the
Board or Committee may direct the local police station or Special Juvenile Police Unit to register a
case, take due cognizance of such occurrences and conduct necessary investigations;(iv)the Board or
Committee shall take necessary steps to ensure completion of all inquiry and provide legal aid as
well as counselling to the juvenile or child victim;(v)the Officer-in-charge of the institution shall also
inform the chairperson of the management committee and place a copy of the report of the incident
and subsequent action taken before the management committee in its next meeting;(vi)in the event
of any other crime committed in respect of juveniles or children in institutions, the Board or
Committee shall take cognizance and arrange for necessary investigation to be carried out by the
local police station or Special Juvenile Police Unit;(vii)the Board or Committee may consult
Children's Committee setup in each institution to enquire into the fact of abuse and exploitation as
well as seek assistance from relevant voluntary organizations, child rights experts, mental health
experts or crisis intervention centres in dealing with matters of abuse and exploitation of juveniles
or children in an institution.
61. Juvenile or Child suffering from dangerous diseases or mental health
problems.
(1)When a juvenile or a child placed under the care of a fit person or a fit institution under the
provisions of the Act, is found to be suffering from a disease or physical or mental health problems
requiring prolonged medical treatment, or is found addicted to a narcotic drug or psychotropic
substance, the juvenile or the child may be sent by an order of the competent authority to an
appropriate place for such period as may be certified by medical officer to be necessary for proper
treatment of the juvenile or the child or for the remainder of the term for which he has toDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

stay.(2)When the juvenile or the child is cured of the disease or physical or mental health problems,
the competent authority may, if the juvenile or child is still liable to stay, order the juvenile or the
child to be placed back in the care of fit person or institution from where the juvenile or child was
removed for treatment and if the juvenile or the child is no longer liable to be kept under the care of
fit person or institution, the competent authority may order him to be discharged.(3)The order of
restoration of a juvenile or a child suffering from an infectious or contagious disease to his parents
or guardian shall be based on the principle of best interest of the juvenile or child, keeping in mind
the risk of stigmatization and discrimination and discontinuation of treatment.(4)Where there is no
organization either within the jurisdiction of the competent authority, or nearby District or State for
care and protection of juveniles or children suffering from serious psychiatric or physical disorder
and infection, as required under section 58 of the Act, necessary organization shall be set up by the
State Government at such places, as it may deem fit to cater to the special needs of such juveniles or
children.
62. Leave of absence of a juvenile or child.
(1)A juvenile or child in an institution may be allowed to go on leave of absence or released under
supervision for examination or admission, special occasions like marriage or emergencies like death
or accident or serious illness in the family.(2)While the leave of absence for short period generally
not exceeding seven days excluding the journey time may be recommended by the Officer-in-charge,
but granting of such leave shall be by the Board or Committee.(3)The parents or guardian of the
juvenile or the Officer-in-charge on behalf of the juvenile or child may submit an application to the
Board or Committee requesting for relieving the juvenile or child on leave, stating clearly the
purpose for the leave and the period of leave.(4)While considering the application of leave of
absence, the Board or Committee shall hear the juvenile or child or the parents or guardians of the
juvenile or child and if the Board or Committee considers that granting of such leave is in the
interest of the juvenile or child, appropriate order shall be made and the Board or Committee may
call for a report from the probation officer or child welfare officer in case the preliminary
information gathered from the juvenile or child or concerned parent or guardian is not sufficient for
the purpose.(5)While issuing orders sanctioning the leave of absence or relieving under supervision,
as the case may be, the competent authority shall mention the period of leave and the conditions
attached to the leave order, and if any of these conditions are not complied with during the leave
period, the juvenile or child may be called back to the institution.(6)The parent or guardian shall
arrange to escort the juvenile or child from and to the institution and where this is not possible, the
Officer-in-charge may arrange to escort the juvenile or child to the place of the family and back. In
case the parents or guardian is willing to arrange escort but does not have requisite financial means,
the Officer-in-charge shall arrange for the travelling expenses as admissible under the rules.(7)If the
juvenile or child runs away from the family during the leave period, the parent or guardian is
required to inform the Officer-in-charge of the institution immediately, and try to trace the juvenile
or child and if found, the juvenile or child shall be brought back to the institution immediately.(8)If
the juvenile or child is not found within twenty four hours, the Officer-in-Charge shall report the
matter to the nearest police station and missing person's bureau, but no adverse disciplinary action
shall be taken against the juvenile or child and procedure laid down under the Act shall be
followed.(9)If the parent or guardian does not take proper care of the juvenile or child during theDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

leave period or does not bring the juvenile or child back to the institution within the stipulated
period, such leave may be refused on later occasions.(10)If the juvenile or child does not return to
the institution on expiry of the sanctioned leave, the Board or Committee shall refer the case to
police for taking charge of the juvenile and bring him back to the institution.(11)The period of such
leave shall be counted as a part of the period of stay in the institution and the time which elapses
after the failure of a juvenile to return to the institution within the stipulated period, shall be
excluded while computing the period of his stay in the institution.
63. Inspection.
(1)The State Government shall constitute State, District or city level inspection committee.(2)The
inspection committees shall visit and oversee the conditions in the institutions and appropriateness
of the processes for safety, well being and permanence, review the standards of care and protection
being followed by the institutions, look out for any incidence of violation of child rights, look into the
functioning of the Management Committee and Children's Committee set up under rules 55 and 56
of these rules and give appropriate directions.(3)The team shall also make suggestions for
improvement and development of the institution.(4)The team shall consist of a minimum of five
members with representation from the State Government, the Board or Committee, the Delhi
Commission for the Protection of Child Rights or the State Human Rights Commission, medical and
other experts, voluntary organizations and reputed social workers.(5)The inspection shall be carried
out at least once in every three months.(6)The inspection visit shall be carried out by not less than
three members.(7)The team may visit the institutions either by prior intimation or make a surprise
visit.(8)The team shall interact with the children during the visits to the institution, to determine
their well-being and uninhibited feed back.(9)The follow up action on the findings and suggestion of
the children shall be taken by all concerned authorities.(10)The action taken report, findings and
suggestions from the Inspection Committee shall be sent to the District Child Protection Unit and
the State Government.
64. Social Audit.
(1)The State Government shall monitor and evaluate the implementation of the Act annually by
reviewing matters concerning establishment of Board or Committee or Special Juvenile Police Unit
where required, functioning of Board or Committee or Special Juvenile Police Unit, functioning of
institutions and staff, functioning of adoption agencies, child friendly administration of juvenile
justice and any other matter concerning effective implementation of the Act in the State.(2)The
social audit shall be carried out with support and involvement of organizations working in the field
of mental health, child care and protection and public accountability.
65. Restoration and Follow-up.
(1)The order for restoration of the juvenile or child shall be made by the Board or Committee on the
basis of a fair hearing of the juvenile or child and his parents or guardian, as well as on the reports of
the Probation Officers or Child Welfare Officers or non-governmental organisations directed by the
Board or Committee to conduct the home study and any other relevant document or report broughtDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

before the Board or Committee for deciding the matter.(2)The Board or Committee shall send a
copy of the restoration order along with a copy of the order for escort as per Form XXII to the
District Child Protection Unit or State Government who shall provide funds for restoration of the
juvenile or child.(3)Every restoration shall be planned for as part of the individual care plans
prepared by the case-workers or counsellors or child welfare officers or probation officer, as the case
may be.(4)Besides police, the Board or Committee may seek collaboration with non-governmental
organisations to accompany juveniles or children back to their family for restoration.(5)In case of
girls, the juvenile or child shall necessarily be accompanied by female escorts.(6)The expenses
incurred on restoration of a juvenile or child, including travel and other incidental expenses, shall be
borne by the District Child Protection Unit or State Government, if directed by the competent
authority.(7)When a juvenile or child expresses his unwillingness to be restored back to the family,
the Board or Committee shall make a note of it in its records in writing and such juvenile or child
shall not be coerced or persuaded to go back to the family, particularly if the social investigation
report of the child welfare officer or probation officer establishes that restoration to family may not
be in the best interest of the juvenile or child or, if the parents or guardians refuse to accept the
juvenile or child back.(8)A follow-up plan shall be prepared as part of the individual care plans by
the Child Welfare Officers or Probation Officers or non-governmental organisations assigned by the
Board or Committee to assist in restoration of the child.(9)A quarterly follow-up report shall be
submitted to the Board or Committee by the concerned Child Welfare Officer or Probation Officer or
non-governmental organisation for a period of two years with a copy to the officer-in-charge of the
institution from where the juvenile or child is restored.(10)The follow-up report shall clearly state
the situation of the juvenile or child post restoration and the juvenile's or child's needs to be met by
the State Government in order to reduce further vulnerability of the juvenile or child.(11)The
officer-in-charge shall file the follow-up report in the case-file of the juvenile or child and place the
report before the management committee set up under rule 55 of these rules in its next
meeting.(12)The officer-in-charge shall also send a copy of the follow-up reports to the District Child
Protection Unit.(13)Where a follow-up is not possible due to unavailability of government
functionaries or nongovernmental organisations, the concerned District Child Protection Unit shall
provide necessary assistance and support to the concerned Board or Committee.
66. Visitor's Book.
(1)A Visitor's Book shall be maintained, in every institution, in which the person visiting the home
shall record the date of his visit with remarks or suggestions, which he may think proper.(2)The
Officer- in-charge shall forward a copy of every such entry to the District Child Protection Unit or
State Government, with such remarks as he may desire to offer in explanation or otherwise; and
thereon, the designated authority shall issue such orders as he may consider necessary.
67. Maintenance of Registers.
- The Officer- in-charge shall maintain in his office, such registers and forms, as required by the Act
and as specified by these rules made there under and the list of registers or files or books to be
maintained shall minimally comprise of:(a)Admission and discharge register;(b)Supervision
register;(c)Medical file or medical report;(d)Nutrition diet file;(e)Stock register;(f)LogDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

book;(g)Order book;(h)Meeting book;(i)Cash book;(j)Budget statement file;(k)Inquiry report
file;(l)Individual case file with individual care plan;(m)Children's Suggestion book;(n)Visitor's
book;(o)Staff movement register;(p)Personal belongings register;(q)Minutes register of
Management Committee;(r)Minutes register of Children's Committees; and(s)Attendance register
for staff and juveniles or children.
68. Personnel or Staff of a Home.
(1)The personnel strength of a home shall be determined according to the duty, posts, hours of duty
per day and category of children that the staff is meant to cater to.(2)The institutional organizational
set up shall be fixed in accordance with the size of the home, the capacity, workload, distribution of
functions and requirements of programmes.(3)The whole-time staff in a home may consist of
Officer-in-charge, Probation Officer (in case of Observation home or Special home), Case Workers
(in case of Children's home or shelter home or after care organization), Child Welfare Officers,
Counsellor, Educator, Vocational Training Instructor, Medical Staff, Administrative staff, Care
Takers, house father and house mother, child mentors, volunteers, store keeper, cook, helper,
washerman, safai karamchari, gardener as required.(4)The part-time staff, shall include
Psychiatrist, Psychologist, Occupational therapist, and other professionals as may be required by
time to time.(5)The staff of the home shall be subject to control and overall supervision of the
Officer-in-charge who by order, shall determine their specific responsibilities and shall keep the
concerned authority informed of such orders made by him from time to time.(6)The duties and
responsibilities of the staff under the Officer-in-charge shall be fixed in keeping with the statutory
requirements of the Act.(7)The Officer-in-charge or such other staff who may be required, shall be
available in the premises of the home.(8)The number of posts in each category of staff shall be fixed
on the basis of capacity of the institution; and the staff shall be appointed in accordance with the
educational qualifications, training and experience required for each category.(9)The suggested
staffing pattern for an institution with a capacity of 100 juveniles or children could be as mentioned
below:
S. No. Staff/Personnel No. of Posts
(1) Officer-in-Charge (Superintendent) 1
(2) Counsellor 1
(3) Probation Officer or Welfare Officer 3
(4) House Mother or House Father (shift duty) 4
(5) Educator 2 (voluntary or part time)
(6) Doctor 1 (voluntary or part time)
(7) Paramedical staff 1
(8) L.D.C. + U. D.C 2
(9) Art & Craft cum Music Teacher 1 (part time)
(10) Care Taker or Ayahs 10
(11) PT Instructor cum Yoga Trainer 1 (part time)
(12) Driver 1Delhi Juvenile Justice (Care and Protection of Children) Rules, 2009

(13) Cook 2
(14) Helper 2
(15) Housekeeping 2
(16) Gardner 1 (part time)
(10)The number of posts in the category of counsellor, case worker or probation officer, house father
or house mother, educator, and vocational instructor may proportionally increase with the increase
in the capacity of the institution.(11)In case of institutions housing infants or children upto 12 years
of age or physically or mentally challenged ones, provision for ayahs and paramedical staff shall be
made as per the need.
Chapter VII
Miscellaneous
69. Recognition of fit persons or fit institution.
(1)Any individual who is willing temporarily to receive a juvenile or child in need of care, protection
or treatment for a period as may be necessary, may be recognized by the competent authority as a fit
person after due verification of their credentials and reputation.(2)Any suitable place or institution,
the manager of which is willing temporarily to receive a juvenile or child in need of care and
protection for a period as may be necessary, may be recognized by the State Government as a fit
institution on the recommendation of the competent authority.(3)An institution recognized as a fit
institutions shall,(a)meet the standards of care laid down in the Act and the rules made
thereunder;(b)have the capacity and willingness to meet the standards of care laid down in the Act
and the rules;(c)receive and provide basic services for care and protection of the juveniles and
children;(d)prevent subjection of juvenile or child to any form of cruelty or exploitation or neglect;
and(e)abide by the orders of the competent authority.(4)A list of fit institutions approved by the
State Government shall be kept in the office of the Board and the Committee.(5)A fit institution with
collateral branches may send the juvenile or child placed therein by an order of the competent
authority to any of its branches after seeking permission from the competent authority.(6)Before
declaring any person as a fit person or recommending an institution as a fit institution, the
competent authority shall hold due enquiry and only on being satisfied, recognition shall be given.
70. Registration under the Act.
(1)All institutions and organisations running institutional or non-institutional care services for
children in need of care and protection, whether run by the government or voluntary organization,
shall get themselves registered under sub-section (3) of section 34 of the Act.(2)All such institutions
shall make an application together with a copy each of rules, bye-laws, memorandum of association,
list of governing body, office bearers, balance sheet of past three years, statement of past record of
social or public service provided by the institution or organization to the State Government (along
with the copy to the competent authority) who shall after verifying that provisions made in the
institution or organization for the care and protection of children, health, education, boarding andDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

lodging facilities, if any, vocational facilities and scope of rehabilitation, may issue a registration
certificate to such organization under sub-section (3) of section 34 of the Act and as per this rule.
71. Certification or recognition and transfer of Management of Institutions
and after care organizations.
(1)Any organization requiring certification under the Act shall make an application together with a
copy each of the rules, bye-laws articles of association, list of members of the society or the
association running the organization, office bearers and a statement showing the status and past
record of specialized childcare services provided by the organization, to the State Government along
with a copy to the competent authority. The State Government shall after verifying the provisions
made in the organization for the boarding and lodging, general health, educational facilities,
vocational training and treatment services may grant certification or recognition for a maximum
period of 3 years at a time, (subject to annual review), under sections 8, 9, 34, 37, 55, 41 and 44 of
the Act, as the case may be, on the condition that the organization shall comply with the standards
or services as laid down under the Act and the rules framed their under, from time to time and to
ensure an all round growth and development of juvenile or child placed under its charge.(2)The
competent authority within a month of the receipt of the application shall after due inquiry,
recommend or advise otherwise the State Government for such recognition.(3)The State
Government may, transfer the management of any State run institution under the Act to a voluntary
organization of repute, who has the capacity to run such an institution; and certify or recognize the
said voluntary organization as a fit institution to own the requisite responsibilities under a
Memorandum of Understanding for a specified period of time.(4)The State Government may, if
dissatisfied with the conditions, rules, management of the organization certified or recognized under
the Act, at any time, by notice served on the manager of the organization, declare that the certificate
or recognition of the organization, as the case may be, shall stand withdrawn as from a date
specified in the notice and from the said date, the organization shall cease to be an organization
certified or recognised under sections 8, 9, 34, 37, 41 or 44 of the Act, as the case may be:Provided
that the concerned organization shall be given an opportunity of making a representation in writing,
within a period of thirty days, against the grounds of withdrawal of certificate or recognition of that
organization.(5)The decision to withdraw or to restore the certificate or recognition of the
organization may be taken, on the basis of a thorough investigation by a specially constituted
advisory board under section 62 of the Act.(6)When an organization ceases to be an organization,
certified or recognised under sections 8, 9, 34, 37, 41 or 44 of the Act, the juvenile or the child kept
therein shall, be transferred to some other institution of repute, certified or recognized under
sections 8, 9, 34, 37, 41 or 44 of the Act or discharged, in accordance with the provisions of the Act
and the rules relating to their discharge and transfer by giving intimation of such discharge or
transfer to the Board or the Committee, as the case may be.
72. Grant in aid to certified or recognized organization.
(1)An organization certified or recognized under sections 8, 9, 34, 37 or 44 of the Act, may during
the period when certification or recognition is in force, may apply for grants-in-aid by the State
Government, for the maintenance of juvenile or child received by them under the provisions of theDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

Act; and for expenses incurred on their education, treatment, vocational training, development and
rehabilitation.(2)The grants-in-aid may be admissible, at such rates, which shall be sufficient to
meet the prescribed norms, in such manner and subject to such conditions as may be mutually
agreed to by both the parties.(3)In case of transfer of management of government run homes under
sections 8, 9, 34, subsection (3) of section 34, 37 or 44 of the Act to a voluntary organization, funds
shall be given to the voluntary organization as grant-in-aid as per the Memorandum of
Understanding signed between both the parties.
73. Admission of outsiders.
(1)No stranger shall be admitted to the premises of the institution, except with the permission of the
Officer- in-charge or on an order from the Board or Committee.(2)In special cases, where parents or
guardians have travelled a long distance from another state or district, the Officer-in-Charge shall
allow parents or guardians entry into the premises and a meeting with their children, provided they
possess proper identification and are not reported to have subjected the juvenile or child to abuse
and exploitation.
74. Identity Photos.
(1)On admission to a home established under the Act, every juvenile or child shall be
photographed.(2)One photograph shall be kept in the case file of the juvenile or the child, one shall
be fixed with the index card, a copy shall be kept in an album serially numbered with the negative in
another album, and a copy of the photograph shall be sent to the Board or Committee as case may
be, as well as to the district or State Child Protection Unit.(3)In case of a child missing from an
institution or in case of lost children received by an institution, a photograph of the child with
relevant details shall be sent to the missing person's bureau and the local police station.
75. Police Officers to be in plain clothes.
- While dealing with a juvenile or a child under the provisions of the Act and the rules made
thereunder, except at the time of arrest, the Police Officer shall wear plain clothes and not the police
uniform.
76. Prohibition on the use of handcuffs and fetters.
- No child or the juvenile in conflict with law dealt with under the provisions of the Act and the rules
made there under shall be handcuffed or fettered.
77. Procedure to be followed by a Magistrate not empowered under the Act.
(1)When any juvenile or child is produced before a Magistrate other than Board or Committee, and
the Magistrate is of the opinion that such person is a juvenile or child, he shall record his reasons
and send the juvenile or child to the appropriate competent authority.(2)In case of a juvenileDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

produced before a Magistrate not empowered under this Act, such Magistrate shall direct the case to
be transferred to the Board for inquiry and disposal.(3)In case of a child in need of care and
protection produced as a victim of a crime before a Magistrate not empowered under the Act, such
Magistrate shall transfer the matter concerning care and protection, rehabilitation and restoration
of the child to the appropriate Committee.
78. Transfer.
(1)During the inquiry, if it is found that the juvenile or child hails from a place outside the
jurisdiction of the Board or Committee, the Board or Committee shall order the transfer of the
juvenile or child and send a copy of the order to the State Government or State or District Child
Protection Unit. Provided that:(i)such transfer is in the best interest of the juvenile or child;(ii)no
child shall be transferred or proposed to be transferred only on the ground that the child has created
problems or, has become difficult to be managed in the existing institution or, is suffering from a
chronic or terminal illness or, on account of disability;(iii)such transfer shall only take place after
the completion of evidence and cross examination that may be required in a legal proceeding
involving a juvenile or child; and(iv)the reasons for and circumstances of such transfer are recorded
in writing.(2)The State Government or State or District Child Protection Unit shall
accordingly:(i)send the information of transfer to the appropriate competent authority having
jurisdiction over the area where the child is ordered to be transferred by the Board or Committee;
and(ii)send a copy of the information to the Officer-in-charge of the institution where the child is
placed for care and protection at the time of the transfer order.(3)On receipt of copy of the
information from the State Government or State or District Child Protection Unit, the
Officer-in-charge shall arrange to escort the child at government expenses to the place or person as
specified in the order.(4)On such transfer, case file and records of the juvenile or child shall be sent
along with the juvenile or child.
79. Procedure for sending a juvenile or child outside the jurisdiction of the
competent authority.
(1)In the case of a juvenile or a child whose ordinary place of residence lies outside the jurisdiction
of the competent authority, and if the competent authority considers it necessary to take action
under section 50 of the Act, it shall direct a probation officer or case worker or child welfare officer,
as the case may be, to make enquiries as to the fitness and willingness of the relative or other person
to receive the juvenile or the child at the ordinary place of residence, and whether such relative or
other fit person can exercise proper care and control over the juvenile or the child.(2)Where a
juvenile or child is ordered to be sent to the ordinary place of residence or to a relative or fit person,
execution of a bond by the juvenile or child without any surety, in Form VI, is necessary along with
an undertaking by the said relative or fit person in Form V or IX as the case may be.(3)Any breach of
a bond or undertaking or of both given under sub-rule (2) of this rule, shall render the juvenile liable
to be brought before the competent authority, who may make an order directing the juvenile to be
sent to an institution home.(4)Any juvenile or a child, who is a foreign national and who has lost
contact with his family shall also be entitled for protection.(5)The juvenile or the child, who is a
foreign national, shall be repatriated, at the earliest, to the country of his origin in co-ordinationDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

with the respective Embassy or High Commission.(6)The Board or Committee shall keep the
Ministry of External Affairs informed about repatriation of every juvenile or child of foreign
nationality carried out on the orders of the Board or Committee.(7)A copy of the order passed by the
competent authority under section 50 of the Act shall be sent to-(a)the probation officer or child
welfare officer who was directed to submit a report under sub-rule (1) of this rule;(b)the probation
officer or child welfare officer, if any, having jurisdiction over the place where the juvenile or the
child is to be sent;(c)the competent authority having jurisdiction over the place where the juvenile or
the child is to be sent; and(d)the relative or the person who is to receive the juvenile or the
child.(e)the approved escort by fax or any other instantaneous mode of communication.(8)During
the pendency of the order under sub-rule (6) of this rule, the juvenile or the child shall be sent by the
competent authority to an observation home or children's home as the case may be.(9)Where the
competent authority considers it expedient to send the juvenile or the child back to his ordinary
place of residence under section 50, the competent authority shall inform the relative or the fit
person, who is to receive the juvenile or the child accordingly; and shall invite the said relative or fit
person to come to the home, to take charge of the juvenile or the child on such date, as may be
specified by the competent authority.(10)The competent authority inviting the said relative or fit
person under sub-rule (8) of this rule may also direct, if necessary, the payment to be made by the
Officer-in-charge of the home, of the actual expenses of the relative or fit person's journey both
ways, by the appropriate class and the juvenile's or child's journey from the home to his ordinary
place of residence, at the time of sending the juvenile or the child.(11)If the relative or the fit person
fails to come to take charge of the juvenile or the child on the specified date, the juvenile or the child
shall be taken to his ordinary place of residence by the escort as decided by the competent authority
and in the case of a girl, at least one escort shall be a female.
80. State Child Protection Unit.
- The specific functions of the State Child Protection Unit shall include:(a)implementation of the Act
and supervision and monitoring of agencies and institutions under the Act;(b)set up, support and
monitor the District Child Protection Units;(c)represent State Child Protection Unit as a member in
the Selection Committee for appointment of members of Boards or Committees;(d)make necessary
funds available to the District Child Protection Units for providing or setting up required facilities to
implementation the Act;(e)network and coordinate with all government departments to build
inter-sectoral linkages on child protection issues, including Departments of Health, Education,
Social Welfare, Urban Basic Services, Backward Classes & Minorities, Youth Services, Police,
Judiciary, Labour, State AIDS Control Society, among others;(f)network and coordinate with civil
society organizations working for the effective implementation of the Act;(g)training and capacity
building of all personnel (Government and Non-government) working under the Act;(h)establish
Minimum Standards of Care and ensure its implementation in all institutions set up under the
Act;(i)review of the functioning of Committees; and(j)all other functions necessary for effective
implementation of the Act.Delhi Juvenile Justice (Care and Protection of Children) Rules, 2009

81. District Child Protection Unit.
(1)The District Child Protection Unit shall coordinate and implement all child rights and protection
activities at district level.(2)The specific functions of the District Child Protection Unit shall
include:(a)ensure effective implementation of the Act at district or city levels by supporting creation
of adequate infrastructure, such as, setting up Boards, Committees, Special Juvenile Police Units
and homes in each districts;(b)identify families at risk and children in need of care and
protection;(c)assess the number of children in difficult circumstances and creating district-specific
databases to monitor trends and patterns of children in difficult circumstances;(d)periodic and
regular mapping of all child related services at district for creating a resource directory and making
the information available to the Committees and Boards from time to time;(e)implement family
based non-institutional services including sponsorship, foster care, adoption and after
care;(f)ensure setting up of District, Block and Village level Child Protection Committees for
effective implementation of programmes as well as discharge of its functions;(g)facilitate transfer of
children at all levels for either their restoration to their families or placing the child in long or
short-term rehabilitation through institutionalisation, adoption, foster care and
sponsorship;(h)supporting State Adoption Resource Agency in implementation of family based
non-institutional services at district level;(i)network and coordinate with all government
departments to build inter-sectoral linkages on child protection issues, including Departments of
Health, Education, Social Welfare, Urban Basic Services, Backward Classes & Minorities, Youth
Services, Police, Judiciary, Labour, State AIDS Control Society, among others;(j)network and
coordinate with civil society organizations working under the Act;(k)develop parameters and tools
for effective monitoring and supervision of agencies and institutions in the district in consultation
with experts in child welfare;(l)supervise and monitor all institutions or agencies providing
residential facilities to children in district;(m)train and build capacity of all personnel (Government
and Non-government) implementing the Act to provide effective services to children;(n)organize
quarterly meeting with all stakeholders at district level including CHILDLINE, Specialized Adoption
Agencies, Officer-in-charges of homes, non-governmental organizations and members of public to
review the progress and implementation of the Act; and(o)liaison with the State Child Protection
Unit, State Adoption Resource Agency at State level and District Child Protection Units of other
districts.
82. Setting of the Child Welfare Committee.
(1)The State Government shall set up by notification in Official Gazette one or more Child Welfare
Committees under section 29 of the Act in the NCT of Delhi with requisite infrastructure, personnel,
and finances for smooth running, as listed below:(a)the infrastructure may consist of a sitting hall, a
separate room for the Committee, room for office staff, waiting room for children, waiting room for
parents or guardian, room for personal interaction between the child or parents and the Committee,
a record room, safe drinking water facility and toilets;(b)the State Government shall provide
necessary human resource support for every Committee, including welfare officer, steno-typist or
computer operator, peon, safai karamchari.(2)The allowances of the Chairperson and Members
shall be disbursed by the District Child Protection Unit or State Government as per rule 23 of these
rules.Delhi Juvenile Justice (Care and Protection of Children) Rules, 2009

83. Setting up of Juvenile Justice Board.
- The State Government shall set up by notification in Official Gazette one or more Juvenile Justice
Board in the NCT of Delhi, with requisite infrastructure, personnel, besides the Principal Magistrate
and Members and Finances as listed below:(1)Infrastructure may consist of a Board Room, waiting
room for children, a room for Principal Magistrate and Members, a record room, room for
Probation Officers, waiting room for parents and visitors, safe drinking water facility and
toilets.(2)The State Government shall provide necessary human resource support for every Board,
including probation officer, steno-typist or computer operator, peon, safai karamchari.
84. Special Juvenile Police Unit.
(1)The State Government shall appoint a Special Juvenile Police Unit at the District level within four
months of the notification of these rules and the unit shall consist of a juvenile or child welfare
officer of the rank of police inspector and two paid social workers having experience of working in
the field of child welfare, of whom one shall be a woman.(2)The District Child Protection Unit or the
State Government shall provide services of its two social workers to the Special Juvenile Police Unit
for discharging their duties.(3)The juvenile or child welfare officer at the police station shall be a
person with aptitude and appropriate training and orientation to handle the cases of juveniles or
children in terms of the provisions of the Act.(4)The transfer and posting of the designated Juvenile
or Child Welfare Officer shall be within the Special Juvenile Police Units of other police stations or
district unit, unless there is an exceptional case of promotion and in such cases, other police officer
must be designated and deputed in the unit so that there is no shortfall.(5)Special Juvenile Police
Unit at district level shall coordinate and function as a watch-dog for providing legal protection
against all kinds of cruelty, abuse and exploitation of child or juvenile.(6)The unit shall take serious
cognizance of adult perpetrators of crimes against children and see to it that they are without delay
apprehended and booked under the appropriate provisions of the law and for this purpose the
district level units shall maintain liaison with other units of police station.(7)The Special Juvenile
Police Units shall seek assistance from the voluntary organizations, panchayats and gramsabhas or
Resident Welfare Associations in identifying juveniles in conflict with law as well as reporting cases
of violence against children, child neglect and child abuse.(8)The Special Juvenile Police Units shall
particularly seek assistance from voluntary organizations recognized as protection agencies by the
State Government for the purpose of assisting Special Juvenile Police Units and local police stations
at the time of apprehension, in preparation of necessary reports, for taking charge of juveniles until
production and at the time of production before the Board as per rule 11 (12) of these rules.(9)The
Deputy Commissioner of Police in a district shall head the Special Juvenile Police Unit and oversee
its functioning from time to time.(10)A Nodal Officer from Police not less than the rank of Joint
Commissioner of Police shall be designated to coordinate and upgrade role of police on all issues
pertaining to care and protection of children or juveniles under Act.(11)Any police officer found
guilty, after due inquiry, of torturing a child, mentally or physically, shall be liable to be removed
from service, besides being prosecuted for the offence.Delhi Juvenile Justice (Care and Protection of Children) Rules, 2009

85. Honorary or Voluntary Welfare Officers and Probation Officers.
- To augment the existing probation service, honorary or voluntary welfare officers and probation
officers may be appointed from the voluntary organization and social workers found fit for the
purpose by the competent authority and their services may also be co-opted into the
implementation machinery by the orders of the competent authority.
86. Duties of the Officer-in-Charge of an institution.
(1)The Officer-in-charge shall have the primary responsibility of maintaining the institution and
shall stay within the institutional premises to be readily available as and when required by the
juveniles or children and the staff and in case where an accommodation is not available within the
institutional premises, the Officer-in-charge shall stay at a place in close proximity to the institution
till such time that such an accommodation is made available within the institution.(2)The general
duties and functions of the Officer-in-charge shall include:(a)compliance with provisions of the Act
and the rules and orders made thereunder;(b)compliance with the orders of the Board or
Committee;(c)providing homely atmosphere of love, affection, care, development and welfare for
juveniles or children;(d)maintaining minimum standards of care in the institution;(e)proper
maintenance of buildings and premises;(f)security measures and periodical inspection, including
daily inspection and rounds of the institution, proper storage and inspection of food stuffs as well as
food being served;(g)supervision and monitoring of juveniles' or children's discipline and well
being;(h)planning implementation and coordination of all institutional activities, programmes and
operations, including training and treatment programmes or correctional activities as the case may
be;(i)prompt action to meet emergencies including regular fire drills and evacuation
plan;(j)ensuring accident and fire preventive measures within the institutional premises;(k)stand-by
arrangements for water storage, power plant, emergency lighting;(l)careful handling of plants and
equipments;(m)segregation of a juvenile or child suffering from contagious or infectious
diseases;(n)observance and follow-up of daily routine;(o)filing of monthly report of juvenile or child
in the case file;(p)organize local and national festivals in the institution;(q)organize trips or
excursions or picnics for juveniles or children;(r)preparation of budget and control over financial
matters;(s)allocation of duties to personnel;(t)supervision over office administration, including
attending to personnel welfare and staff discipline;(u)prompt, firm and considerate handling of all
disciplinary matters;(v)organize the meetings of the Management Committee set up under rule 55 of
these rules and provide necessary support(w)maintenance of all records and registers required
under the Act and the rules and monthly verification of the same by the Management Committee set
up under rule 55 of these rules;(x)liaison, coordination and cooperation with the District Child
Protection Unit or State Government as and when required; and(y)coordination with the legal
officer in the District Child Protection Unit to ensure that every juvenile is legally represented and
provided free legal aid and other necessary support or, where the District Child Protection Unit has
not been set up, services of the District or State Legal Services Authority shall be made
available.(z)organize child committees and provide necessary support.Delhi Juvenile Justice (Care and Protection of Children) Rules, 2009

87. Duties of a Probation Officer or Child Welfare Officer or Case Worker.
(1)Every probation officer or child welfare officer or case-worker shall carry out all directions given
by the Board or Committee or concerned authority and shall perform the following duties, functions
and responsibilities:(a)making social investigation of the juvenile (Form IV) or the child (Form XIII)
through personal interview and from the family, social agencies and other sources;(b)attending the
proceedings of the Board or Committee and submitting reports as and when required;(c)clarifying
problems of the juvenile or the child and dealing with their difficulties in institutional
life;(d)participating in the orientation, monitoring, education, vocational and rehabilitation
programmes;(e)establishing co-operation and understanding between the juvenile or the child and
the Officer- in-charge;(f)assisting the juvenile or the child to develop contacts with family and also
providing assistance to family members;(g)developing a care plan for every child in consultation
with the juvenile or child and following up its implementation;(h)participating in the pre-release
programme and helping the juvenile or the child to establish contacts which can provide emotional
and social support to juvenile or child after their release;(i)establishing linkages with voluntary
workers and organizations to facilitate rehabilitation and social reintegration of juveniles and to
ensure the necessary follow-up;(j)follow-up of juveniles after their release and extending help and
guidance to them;(k)visiting regularly the residence of the juvenile or child under their supervision
and also places of employment or school attended by such juvenile or child and submitting
fortnightly reports as prescribed in Form XXI;(l)accompanying juveniles or children where ever
possible, from the office of the Board to observation home, special home, children's home or fit
person, as the case may be; and(m)maintaining case file and such registers as may be specified from
time to time.(2)On receipt of information from the Police or Juvenile or Child Welfare Officer of the
Police under clause (b) of section 13 of the Act, the probation officer shall inquire into the
antecedents and family history of the juvenile or the child and such other material circumstances, as
may be necessary and submit a social investigation report as early as possible, in Form IV or XIII, to
the Board.
88. Duties of House Father or House Mother.
(1)The general duties, functions and responsibilities of a house father, house mother and other care
takers shall be as follows:(a)handling juvenile or child with love and affection;(b)taking proper care
and welfare of juvenile or child;(c)maintaining discipline among the juveniles or
children;(d)maintenance, sanitation and hygiene;(e)implementing daily routine in an effective
manner and ensuring children's involvement;(f)looking after the security and safety arrangements
of the home; and(g)escorting juveniles or children, whenever they go out of the home.
89. Disqualification for officer-in-charge, probation officer or child welfare
officer or case-worker, house father or house mother and other care givers
and staff.
(1)The officer-in-charge, probation officer or child welfare officer or case-worker, house father or
house mother and other care givers and staff shall not employ a juvenile or child under theirDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

supervision or care and protection for their own purposes or take any private service from
them.(2)Any report of physical, sexual or emotional abuse of a juvenile or a child in an institution or
outside, by a caregiver, shall hold them liable for disqualification after due inquiry.
90. Training of Personnel.
(1)The State Government or the Officer-in-charge, in collaboration with reputed organisations shall
provide for training of personnel of each category of staff, in keeping with their statutory
responsibilities and specific jobs requirements.(2)The training programme shall
include-(a)orientation and induction training of the newly-recruited staff,(b)refresher training
courses and skill enhancement programmes for all care givers once a year, and(c)staff conferences,
seminars, workshops
91. Selection Committee and its composition.
- The State Government shall constitute a Selection Committee by notification in the official gazette,
for a period of five years, consisting of the following five members, namely:(a)a retired judge of High
Court or retired Secretary to the Government of NCT of Delhi as the Chairperson;(b)one
representative from the concerned Department of State Government not below the rank of Director
as the Member Secretary;(c)one representative from a reputed non-governmental organization,
working in the area of child welfare but not running any children institution;(d)a representative
from academic bodies concerned with social work, psychology, sociology, child development,
education, law, criminology and with experience of working on children's issues; and(e)a
representative of the National or State Human Rights Commission or, National or Delhi
Commission for Protection of Child Rights or, National or Delhi Commission for Women.
92. Functions of the Selection Committee.
(1)(a)In making appointment of members of the Board or Committee, the Selection Committee shall
take into consideration the applications received in this regard in response to a public advertisement
to this effect by the State Government; and(b)the Selection Committee shall select and recommend a
panel of names to the State Government for appointment as members of the Board or Committee
from amongst the applications received.(2)In the event of any complaint against a member of the
Board or Committee, the Selection Committee shall hold necessary inquiry and recommend
termination of appointment of such member to State Government, if required.(3)(a)The Selection
Committee, at the time of recommending names for appointment as member of Board or Committee
shall also prepare a panel of names for each Board or Committee to fill in vacancies, which may arise
during the tenure of the Board or Committee.(b)In the event of a vacancy in the Board or
Committee, the District Child Protection Unit shall inform the State Child Protection Unit or State
Government for filling up such vacancy.(c)The State Government shall fill the vacancies on the basis
of the panel of names recommended by the Selection Committee.Delhi Juvenile Justice (Care and Protection of Children) Rules, 2009

93. Advisory Board.
(1)The State Government shall constitute Advisory Board at State level for a period of three
years.(2)The Advisory Board shall hold at least two meetings in a year.(3)The Advisory Board shall
inspect the various institutional or non-institutional services and the recommendations made shall
be acted upon by the State Government.(4)The Advisory Board may consist of representatives of the
State Government, members of the competent authority, academic institutions, locally respectable
and spirited citizens, representatives of non-governmental organizations.(5)The termination,
resignation, or other vacancy caused in the advisory board and appointment of new members
therein shall be done by the State Government.
94. Openness & Transparency.
(1)All Children's homes shall be open to visitors with the permission of the Officer-in-charge and the
Committee or Officer-in-charge as the case may be, may consider appropriate to allow
representatives of local self government, voluntary organizations, social workers, researchers,
medicos, academicians, prominent personalities, media and any other persons as visitors, as the
Officer-in-charge considers appropriate keeping in view the security, welfare and the interest of the
children.(2)The Officer-in-charge of the home shall encourage active involvement of local
community in improving the conditions in the homes, if, the members of the community want to
serve the institution or want to contribute through their expertise.(3)The Officer-in-charge shall
maintain a visitors book and the remarks of the visitors given therein shall be considered by the
advisory inspecting authority.(4)While visiting an institution, the visitors will not say or do anything
that undermines the authority of the Officer-in-charge or is in contravention of the Act or rules or
impinges on the dignity of the children.
95. Juvenile Justice Fund.
(1)The State Government shall create a Fund at the State level under section 61 of the Act to be
called the 'Juvenile Justice Fund' (herein under referred to as the Fund) for the welfare and
rehabilitation of the juvenile or the child dealt with under the provisions of the Act.(2)In addition to
donations, contributions or subscriptions coming under sub-section (2) of section 61, the Central
Government shall also make contribution to the Fund.(3)The Fund shall be applied:(a)to implement
programmes for the welfare, rehabilitation and restoration of juveniles or children;(b)to pay
grant-in-aid to non-governmental organizations;(c)to do all other things that are incidental and
necessary for the above purposes.(4)The management and administration of the Fund shall be
under the control of the State Advisory Board under sub-section (3) of section 61 of the Act.(5)The
assets of the Fund shall include all such grants and contributions, recurring or nonrecurring, from
the Central Government and State Government or any other statutory or non-statutory bodies set up
by the Central or State Government as well as the voluntary donations from any individual or
organization.(6)All withdrawals shall be made by cheques or requisitions, as the case may be, signed
by the secretary-cum-treasurer and in the case of amounts exceeding rupees one thousand, they
shall be signed duly by the secretary-cum-treasurer and a member of the board of management to
be nominated by the State Advisory Board.(7)The regular accounts shall be kept of all money andDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

properties, and all incomes and expenditure of the Fund and shall be audited by a notified firm of
Chartered Accountants, or any other recognized authorities as may be appointed by the
Board.(8)The auditors shall also certify the expenditure from the Fund made by the
secretary-cum-treasurer.(9)All contracts and other assurances shall be in the name of the board of
management and signed on their behalf by the secretary-cum-treasurer and one member of the
board of the management authorised by it for the purpose.(10)The board of management shall
invest for the time being the proceeds of sale or other disposal of the property, as well as any money
or property not immediately required to be used to serve the objective of the Fund, in any one or
more of the modes of investment authorised by law for the investment of trust moneys as the board
of management may think proper.(11)The board of management may delegate to one or more of the
members such of its powers, which in its opinion are merely a procedural arrangement.
96. Pending Cases.
(1)No juvenile in conflict with law or a child shall be denied the benefits of the Act and the rules
made thereunder.(2)All pending cases which have not received a finality shall be dealt with and
disposed of in terms of the provisions of the Act and the rules made thereunder.(3)Any juvenile in
conflict with law, or a child shall be given the benefits under sub-rule (1) of this rule, and it is hereby
clarified that such benefits shall be made available to all those accused who were juvenile or a child
at the time of commission of an offence, even if they cease to be a juvenile or a child during the
pendency of any inquiry or trial.(4)While computing the period of detention or stay or sentence of a
juvenile in conflict with law or of a child, all such period which the juvenile or the child has already
spent in custody, detention, stay or sentence of imprisonment shall be counted as a part of the
period of stay or detention or sentence of imprisonment contained in the final order of the court or
the Board.
97. Disposed off cases of juveniles in conflict with law.
- The State Government or as the case may be the Board may, either suo motu or on an application
made for the purpose, review the case of a person or a juvenile in conflict with law, determine his
juvenility in terms of the provisions contained in the Act and rule 12 of these rules and pass an
appropriate order in the interest of the juvenile in conflict with law under section 64 of the Act, for
the immediate release of the juvenile in conflict with law whose period of detention or
imprisonment has exceeded the maximum period provided in section 15 of the said Act.
98. Disposal of records or documents.
- The records or documents in respect of a juvenile or a child or a juvenile in conflict with law shall
be kept in a safe place for a period of seven years and no longer, and thereafter be destroyed by the
Officer-in-charge or Board or Committee, as the case may be.Delhi Juvenile Justice (Care and Protection of Children) Rules, 2009

99. Repeal.
- The Juvenile Justice (Care and Protection of Children) Rules, 2002, notified vide F.No.61
(2)/DO-I/DSW/2001/8969-984 dated : 19th August, 2002 in the Delhi Gazette Extraordinary, Part
IV, are hereby repealed.
Schedule 1
Clothing, Bedding, Toiletries and other Articles (Rule 41)
1. Juveniles or children shall be provided with the following articles : -
Bedding
S. No. Article Quantity to be provided per child
1. Towels (4ft x 2ft) 3 per Years
2. Cotton Bed Sheets 4 per 2 Years
3. Pillow 1 per 2 Years
4. Pillow Covers 2 per 2 Years
5. Woolen blankets 3 per 3 Years
6. Cotton durry 1 per 2 Years
7. Mattress 1 per 3 Years
8. Mosquito Net 1 per 2 Years
Clothing for girls
1.Skirts & Blouse or Salwar Kameez or Half Sari
with blousesand petticoats5 sets per year for girls depending on age and
regionalpreferences
2.Banyans 6 per year for younger girls
3.Brassieres 6 per year for older girls
4.Panties 6 per year
5.Sanitary Towels 12 packs per year for older girls
6.Woollen Sweaters (full sleeves) 2 in 2 years
7.Woollen Sweaters (half sleeves) 1 in 1 year
8.Woollen Shawls 1 in 1 year
Clothing for boys
1.Shirts 4 per year
2.Shorts 4 per year for younger boys
3.Pants 4 per year for older boys
4.Vest 4 per year
5.Underwear 4 per yearDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

6.Woolen Jerseys (full sleeves) 2 in 2 years
7.Woolen Jerseys (half sleeves) 1 in 1 year
8.Scarfs/ cap 2 in 2 years
Miscellaneous Articles
1.Slippers 2 pair per year
2.Sports Shoes 1 pair per year
3.School Uniform 2 sets per year for children attending outside schools
4.School Shoes 1 pair per year for children attending outside schools
5.School Bag and Stationery 1 sets per year for children attending outside schools
6.Handkerchiefs 6 per year
7.Kurta Payjama 2 sets per year
8.Track suit 1 set per year
9.Socks 4 pairs per year
Note. - (a) In addition to the clothing specified above, each child shall be provided, once in three
years, with a suit consisting of one white shirt, one pair of Khaki shorts or pants, one pair of white
canvas shoes and one blazer for use during ceremonial occasions. In the case of girls it shall be one
white half sari or one salwar kameez or one white skirt and one white blouse, a pair of white canvas
shoes and a blazer.
2. In every hospital attached to the institution where there is provision for
in-patient cots, the following scale has to be followed : -
 Night clothing & bedding Scale for supply
1.Mattress One per bed per 3 years
2.Cotton Bed Sheets Four per bed per year
3.Pillows One per bed per two year
4.Pillow Covers Four per bed per year
5.Woollen blankets One per bed per 2 years
6.Pyjamas and loose shirts (Hospital type for boys) 3 pairs per child per year
7.Skirts and blouses or salwar kameez for girls 3 pairs per child per year
8.Cotton durry One per bed per three years
Note. - (i) When a child is admitted as an in-patient in the institution Hospital, the Institution
Doctor shall issue the in-patient with the hospital clothing, the clothes, on body being preserved,
duly washed and handed back, at the time of the child's discharge from the hospital.(ii)Each child
shall be provided with Kit Box or a Locker, as per convenience and necessity.(iii)The Superintendent
may make arrangements for two-tier bed system in place of conventional cots, as per convenience
and necessity.Delhi Juvenile Justice (Care and Protection of Children) Rules, 2009

3. Toiletry : Every resident of the Home shall be issued with oil, soap and
other material for in accordance with the following scales : -
Hair oil for grooming the hair 100 mgs per month
Toilet soap or carbolic soap 1 large bar per month
Tooth paste and brush 1 Brush per 3 months 50 gms paste per month
Comb 1 per year
Shampoo sachets (for girls) 4 per month
Note. - (a) For washing of cloth and towels, bed-sheet etc., the following scale may be followed : -
(i)Washing Soap 3 soap for one month (125 gms) or equivalent washing powder
(ii)Whitening/bleaching agent to the extent required only for white clothing
Provided, however, the hospital clothing is not mixed with other clothing at the time of washing and
if necessary, the Superintendent can issue the above items separately for washing of hospital
clothing. The superintendent may get installed washing machines, as required.(b)The children
attending school outside the institution may be issued with one additional bar of washing soap (100
gms) per head per month for washing their school uniform.
4. The following items shall be provided for maintaining the Homes in a
healthy and sanitary condition :
Item Scale of Supply
Broom Stick 25 to 40 Nos. per month depending on the area of theinstitution
Pesticide spray As per the institution Doctor's advice
Effective bugs killing agent As required
Phenyl and cleaning acid
(daily)Depending on the area of lavatories to be cleaned as perinstitution
Doctor's advice.
Mosquito repellent 2 per room per month
II
Nutrition and Diet Scale (Rule 44)
S. No. Name of the articles of diet Scale per head per day
1.Rice/ Wheat/ Ragi/ Jowar/
Bread600 Gms, (700 Gms for 16-18 yrs age) of
which atleast 100 gmsto be either Wheat or
Ragi or Jowar
2. Dal/ Rajma/Chana 120 Gms
3. Edible Oil 50 Gms
4. Onion 25 Gms
5. Salt 25 GmsDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

6. Turmeric 05 Gms
7. Coriander Seed Powder 05 Gms
8. Ginger 05 Gms
9. Garlic 05 Gms
10. Tamarind/Mango powder 05 Gms
11. Milk (at breakfast) 300 ml
12. Dry Chilies 05 Gms
13. Vegetables Leafy 100 Gms
 Non-leafy 130 Gms
14. Curd or Butter Milk 100 Gms/ Ml
15.Chicken once a week or Eggs 4
days or paneer once a week115 Gms
16. Nutri-nuggets twice a week 30 Gms
17. Jaggery & Ground Nut Seeds60 Gms each (100 Gms for paneer) once in
a week
18. Sugar 40 Gms
19. Jam/ Butter 25 Gms
20. Tea 4 Gms per day
Following items for
50 Children per day
19. Pepper 25 Gms
20. Jeera Seeds 25 Gms
21. Black Gramdal 50 Gms
22. Mustard Seeds 50 Gms
23. Ajwain Seeds 50 Gms
On Chicken Day for
10 Kg. of Chicken
24. Garam Masala 10 Gms
25. Kopra 150 Gms
26. Khas Khas 150 Gms
27. Groundnut Oil 500 Gms
For Sick Children
28. Bread 500 Gms
29. Milk 500 Ml
Other Items
30. LP Gas for Cooking only  
Instructions:(2)Variation in Diet(a)Three varieties of dal i.e., Toor (Tuvari), Moong (Green Gram)
and Chana (Bengal Gram) may be issued alternatively.(b)The Superintendent may also arrange toDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

substitute chicken with fish at his discretion, provided that there is no extra expenditure to
Government.(c)On non-vegetarian days, vegetarian children shall be issued with either 60 Gms of
Jaggery and 60 Gms of Groundnut seeds per head in the shape of laddus or any other sweet dish or
100 gms paneer.(d)Potatoes shall be issued in lieu of vegetables once in a week.(e)Leafy vegetables
such as Fenugreek (Methi), Spinach (Palak), Sarson (Mustard leaves) Gongura Thotakura or any
other saag etc., may also be issued once in a week. If a kitchen garden is attached to any institution
leafy vegetables, in addition to drumstick trees, curry leaves trees and coriander leaves, should be
grown and issued and the Superintendent should try to issue variety of vegetables and see that the
same vegetable is not repeated for at least a period of one week.(f)The Superintendent may make
temporary alternations in the scale of diet in individual cases when considered necessary by him, or
on the institution Doctor's advice subject to the condition that the scale laid down is not
exceeded.(3)Meal Timing and Menu:(a)Breakfast before 8:30 am(i)Upma or chapattis made of
Wheat or Ragi or any other dish.(ii)Chutneys from Gongura or fresh curry leave or fresh coriander
or Coconut and Putnadal etc., dal/vegetable may be issued as a dish.(iii)Milk(iv)Any seasonal fruit
in sufficient quantity(b)Lunch at 1:00 P.M. and Dinner After 7:00 P.M.(i)Rice/ Chapattis or
combination of both(ii)Vegetable Curry(iii)Sambar or Dal(iv)Butter Milk or
curd(4)Others:(a)Depending on the season, the Superintendent shall have the discretion to alter the
time for distribution of food.(b)On the advise of the Institution Doctor, every sick child who is
prevented from taking regular food, on account of his ill-health, may be issued with medical diet, as
indicated in diet scale.(c)Extra diet for nourishment like milk, eggs, sugar and fruits shall be issued
to the children on the advice of the institution Doctor in addition to the regular diet, to pick up
weight or for other health reasons and for the purpose of calculation of the daily ration, the sick
children shall be excluded from the day's strength.(d)On the following national and festival
occasions, sweet dishes may be distributed to all the children at the Home at the rate fixed by the
Commissioner, from time to time.
1. Republic Day (26th January )
2. Ambedkar's Birthday (14th April)
3. Independence Day(15th August)
4. Mahatma Gandhi's Birth Day (2nd October)
5. Children's Day (14th November)
6. Child Rights Day (20th November)
7. Dussehra (Vijayadasami)Delhi Juvenile Justice (Care and Protection of Children) Rules, 2009

8. Deepavali
9. Ramzan (Id-Ul-Fitr)
10. Bakrid (Id-Ul-Zuha)
11. Christmas (25th December)
The States may specify additional festivals depending upon local preferences.Form-I[Rule
13(1)(c)]Supervision OrderWhen the Juvenile is placed under the care of a parent, guardian or other
fit person/fit institution Profile No. ____________________ of _________ 20 ____.Whereas
(name of the juvenile/) has this day found to have committed an offence and has been placed under
the care of (name) __________(address)
_________________________________________ on executing a bond by the said
_________________________________and the Board is satisfied that it is expedient to deal
with the said juvenile by making an order placing him/her under supervision.It is hereby ordered
that the said juvenile be placed under the supervision of
____________________________________________ probation officer/case worker, for a
period of _____________________________ subject to the following conditions.
1. that the juvenile along with the copies of the order and the bond executed
by the said__________________________________________________ shall
be produced before the probation officer/caseworker named therein
_______________________________.
2. that the juvenile shall be submitted to the supervision of the aforesaid
probation officer/ case worker.
3. that the juvenile shall reside at _________________ for a period of
____________.
4. that the juvenile shall not be allowed to quit the district jurisdiction of
_________without the permission of the probation officer/case worker.
5. that the juvenile shall not be allowed to associate with bad characters.
6. that the juvenile shall live honestly and peacefully; and will go to school
regularly/ endeavour to earn an honest livelihood.Delhi Juvenile Justice (Care and Protection of Children) Rules, 2009

7. that the juvenile shall attend the attendance centre regularly.
8. that the person under whose care the juvenile is placed shall arrange for
the proper care, education and welfare of the juvenile.
9. that the preventive measures will be taken by the person under whose care
the juvenile is placed to see that the juvenile does not commit any offence
punishable by any law in India.
10. that the juvenile shall be prevented from taking narcotic drugs or
psychotropic substances or any other intoxicants.
11. That the directions given be the probation officer/case worker from time
to time, for the due observance of the conditions mentioned above, shall be
carried out.
Dated this______________________day of______________________
20___.(signature)Principal Magistrate, Juvenile Justice BoardAdditional, conditions, if any may be
inserted by the Juvenile Justice BoardForm-II[Rule 13(1)(d)]Order of detention under Sub-Section
_______ of Section ______, Sub-Section _____ of Section __________ and Sub-Section
__________ of Section ___.ToThe Officer in
charge________________________________Whereas on the _____________ day of
___________20____, ____________ (name of the juvenile), son/ daughter of
__________________, aged_____, residing at ____________________________ being
found in Profile No. _____________ to be juvenile in conflict with law/ section
_________________ is order by me ___________________ Principal Magistrate, Juvenile
Justice Board under section_____________________ of Juvenile Justice Act, 2000 to be kept
in the Observation Home/ Special Home/ __________________ for a period of
__________.This is to authorize and require you to receive the said juvenile; into your charge, and
to keep him/her in the Observation Home/ Special Home/ _______________________ for the
aforesaid order to be carried into execution according to law.Given under my hand and the seal of
Juvenile Justice BoardThis __________________________ day of
_________________________ 20.(signature)Principal Magistrate, Juvenile Justice
BoardEncl:Copy of the judgement, if any, or orders, particulars of home and case history and
individual care plan, if any:Strike which is not required.Form-IIIOrder of Social
Investigation/Inquiry[Rule 13(1)(e) and (5)]ToProbation Officer/Case Worker/Person in-charge of
Voluntary Organization/Case Worker _________________________________Whereas a
report/complaint under section ___________ of the Juvenile Justice (Care and Protection of
children) Act, 2000 has been received from________ in respect of______________(name of
the juvenile), son/daughter of __________________ approximate age _____ residing at
__________________________, who has been produced before the Board.You are hereby
directed to enquire into the social antecedents, family background and circumstances of the allegedDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

offence by the said juvenile and submit your social investigation report on or before
_______________or within such time allowed to you by the Board.You are also hereby directed
to consult an expert in child psychology, psychiatric treatment or counselling for their expert
opinion if necessary and submit such report along with your Social Investigation Report.Dated this
____________________________day of
__________________20______.(signature)Principal Magistrate, Juvenile Justice BoardForm
IV[Rules 13(5) and 87(1)(a) and (2)]Social Investigation ReportSl.
No.________________Submitted to the Juvenile Justice
Board______________________________(address).Probation Department/Concerned State
Government Authority/Voluntary
Organisation_________________________________________(Signature and
Stamp)Profile No.Under section:Title of Profile:Police Station:Nature of offence charge:
Name Religion
Father's Name Caste
Permanent Address Year of birth
Last address before apprehension Age
 Sex
Previous institutional/case history and individual care plan, if anyFamily
Members of family Name Age Health Education OccupationMonthly
earningsDisabilitiesAny other
e.g. social
habits
Father         
Step-father         
Mother         
Step-mother         
Siblings         
Any other legal
guardian/ relative        
If married, relevant
particulars______________________________________________________________________Other
near relatives or agencies
Interested______________________________________________________________Attitude
towards religion normal and ethical code of the home etc.
__________________________________________Social and economic
status________________________________________________Delinquency record of
members of family____________________________________Present living conditions
_________________________________________________Relationship between
parents/ Parents and children especially with the juvenile under
investigation________________________________________Other factors of importance
if any___________________________________________Juveniles HistoryMental
condition(Present andDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

past)________________________________________________________Physical
condition(Present and
past)________________________________________________________Habits,
interests(moral, recreational
etc.)__________________________________________________Outstanding
characteristics and personality traits_______________________________Companions and
their influence____________________________________________Truancy from home,
if any ________________________________________________School (attitude
towards school, teachers, class mates and
vice-versa)____________________________________________________________________________________Work
record (jobs held, reasons for leaving, vocational interests, attitude towards job or
employers)___________________________Neighbourhood and neighbours
report______________________Parent's attitude towards discipline in the home and child's
reaction______________________Any other remarksResult of InquiryEmotional
factorsPhysical conditionIntelligenceSocial and economic factorsReligious factorsSuggested causes
of the problemsAnalysis of the case including reasons for delinquencyOpinion of experts
consultedRecommendation regarding treatment and its Plan by Probation OfficerSignature of the
Probation Officer/Case WorkerForm - V[Rules 15(5) and 79(2)]Undertaking/Bond to be Executed
by a Parent/Guardian/Relative/Fit Person in whose Care a Juvenile is PlacedWhereas I
___________________________ being the parent, guardian, relative or fit person under
whose care _____________________________________(name of the juvenile) has been
ordered to be placed by the Juvenile Justice Board __________________________, have been
directed by the said Board to execute an undertaking/ bond with surety in the sum of
Rs.________/-
(Rupees____________________________________________________) or without
surety. I hereby bind myself on the said ________________________________ being placed
under my care. I shall have the said ________________________ properly taken care of and I
do further bind myself to be responsible for the good behaviour of the said
__________________________________and to observe the following conditions for a
period of _________________ years w.e.f _________________.
1. that I shall not change my place of residence without giving previous
intimation in writing to the Juvenile Justice Board through the Probation
Officer/Case Worker;
2. that I shall not remove the said juvenile from the limits of the jurisdiction of
the Juvenile Justice Board without previously obtaining the written
permission of the Board;
3. that I shall send the said juvenile daily to school/to such vocation as is
approved by the Board unless prevented from so doing by circumstances
beyond control;Delhi Juvenile Justice (Care and Protection of Children) Rules, 2009

4. that I shall send the said juvenile to an Attendance Centre regularly unless
prevented from doing so by circumstances beyond my control;
5. that I shall report immediately to the Board whenever so required by it;
6. that I shall produce the said juvenile in my care before the Board, if he/she
does not follow the orders of Board or his/her behaviour is beyond control;
7. that I shall render all necessary assistance to the Probation Officer /Case
Worker to enable him to carry out the duties of supervision;
8. in the event of my making default herein, I undertake to produce myself
before the Board for appropriate action or bind myself, as the case may be,
to forfeit to Government the sum of Rs.__________
(Rupees______________________________).
Dated this __________________________day of _____________________20.Signature
of person executing the Undertaking/Bond.(Signed before me)Principal Magistrate, Juvenile Justice
BoardAdditional conditions, if any, by the Juvenile Justice Board may be entered numbering them
properly;(Where a bond with sureties is to executed add)I/We __________________ of
____________________ (place of residence with full particulars) hereby declare
myself/ourselves as surety/sureties for the aforesaid _____________ (name of the person
executing the undertaking/bond) to adhere to the terms and conditions of this undertaking/bond.
In case of ________________ (name of the person executing the bond) making fault therein,
I/We hereby bind myself/ourselves jointly or severally to forfeit to government the sum of
Rs._______________/- (Rupees_____________________________________) dated
this the __________ day of ___________________20 ______ in the presence of
________________________.Signature of Surety(ties)(Signed before me)Principal Magistrate,
Juvenile Justice BoardForm VI[Rules 15(6) and 79(2)]Personal Bond by Juvenile/ChildPersonal
Bond to be signed by juvenile/child who has been ordered under Clause ____________of
Sub-Section _________ of Section ____________ of the Act.Whereas, I
_____________________ inhabitant of _______________ (give full particulars such as
house number, road, village/town, tehsil, district, state) _________________ have been ordered
to be sent back/restored to my native place by the Juvenile Justice Board/Child Welfare Committee
________________________ under section ____________ of the Juvenile Justice (Care and
Protection of Children) Act, 2000 on my entering into a personal bond under sub-rule _____ of
rule ____ and sub-rule ____ of rule ____ of these Rules to observe the conditions mentioned
herein below. Now, therefore, I do solemnly promise to abide by these conditions during the
period__________________.I hereby bind myself as follows:Delhi Juvenile Justice (Care and Protection of Children) Rules, 2009

1. That during the period________ I shall not ordinarily leave the
village/town/district to which I am sent and shall not ordinarily return
to_________________ or go anywhere else beyond the said district without
the prior permission of the Board/Committee;
2. That during the said period I shall attend school/ vocational training in the
village/town or in the said district to which I am sent;
3. That in case of my attending school/ vocational training at any other place
in the said district I shall keep the Board/Committee informed of my ordinary
place of residence.
I hereby acknowledge that I am aware of the above conditions which have been read over/explained
to me and that I accept the same.(Signature or thumb impression of the juvenile/child)Certified that
the conditions specified in the above order have been read over/explained to (Name of
juvenile/child)_________________________and that he/she has accepted them as the
conditions upon which his/her period of detention/ placement in safe custody may be
revoked.Certified accordingly that the said juvenile/child has been released/relived on
the________________________.Signature and Designation of the certifying authorityi.e.
Officer-in-charge of the institutionForm VII[Rule 17(10)]Discharge
OrderI________________________name and designation of the discharging authority
_______________ State Government/ Union Territory Administration, do by this order
permit__________________________ son/ daughter of _________________________
residence_____________________________ Profile Number __________________ who
was ordered to be detained/placed in a observation home/special home/after care home by the
Juvenile Justice Board ______________________________under section
_________________ of the Juvenile Justice (Care and Protection of Children) Act 2000, for a
term of __________________ on the ____________day of _____________
20__________ and who is now in the ______________ home, at
________________________to be discharged from the said_______________ home and
supervision and the authority of ________________________________ during the
remaining period of stay.This order is granted subject to the conditions hereon, upon the breach of
any of which it shall be liable to be revoked.Signature and Designation of Releasing AuthorityDated
:Place :Conditions:
1. The discharged person shall proceed to __________ and live under the
supervision and authority of _______________ until the expiry of the period
of his/her detention unless the remission is sooner cancelled.Delhi Juvenile Justice (Care and Protection of Children) Rules, 2009

2. He/She shall not, without the consent of the ______________remove
himself/herself from that place or any other place, which may be named by
the said _______________.
3. He/she shall obey such instruction as he/she may receive from the said
__________________ with regard to punctual and regular attendance at
school/vocation or otherwise.
4. He/She shall attend the Attendance Centre located at _________________
regularly.
5. He/She shall abstain from committing any offense and shall lead a sober
and industrious life to the satisfaction of _________________________.
6. In the even of his/her committing a breach of any of the above conditions
the remission of the period of detention hereby granted shall be liable to be
cancelled and on such cancellation he/she shall be dealt with under sub
section (3) of section 59 of the Juvenile Justice (Care & Protection of
Children) Act 2000.
I hereby acknowledge that I am aware of the above conditions which have been read over/explained
to me and that I accept the same.(Signature or mark of the released juvenile)Certified that the
conditions specified in the above order have been read over/explained to (Name of
juvenile/child)_________________________and that he/she has accepted them as the
conditions upon which his/her period of detention may be revoked.Certified accordingly that the
said juvenile/child has been discharged on the________________.Signature and Designation of
the certifying authorityi.e. Officer-in-charge of the institutionForm VIII[Rule 27(18)]Supervision
OrderWhen the Child is placed under the case of a parent guardian or other fit person Case
No.______________________ of ____________________ 20______Whereas (name of
the child) _______________ has this day been found to be in need of care and protection, and
has been placed under the care and supervision of (name) ____________ (address)
___________________on executing a bond by the said
_______________________________ and the Committee is satisfied that it is expedient to
deal with the said child by making an order placing him/her under supervision.It is hereby ordered
that the said child be placed under the supervision of (name)___________(address)
____________________________________ for a period of
________________________ subject to the following conditions that:Delhi Juvenile Justice (Care and Protection of Children) Rules, 2009

1. the child along with the copies of the order and the bond, if any, executed
by the said________________________________ shall be produced before
the Committee as and when required by the person executing the bond
2. the child shall be placed under the supervision of the aforesaid
parent/guardian/ fit person.
3. the child shall reside at ______________________ for a period of
____________
4. the child shall not be allowed to quit the district jurisdiction of
_______________ with the permission of the Committee.
5. the child shall go to school regularly/endeavour to earn an honest
livelihood.
6. the person under whose care the child is placed shall arrange for the
proper care, education and welfare of the child.
7. the child shall not be allowed to associate with undesirable characters and
shall be prevented from coming in conflict with law.
8. the child shall be prevented from taking narcotic drugs or psychotropic
substances or any other intoxicants.
9. the directions given by the Committee from time to time, for the due
observance of the conditions mentioned above, shall be carried out.
Dated this ________________ day of ___________________ 20
_____________(Signature)Chairperson, Child Welfare Committee• Additional conditions, if any
may be interested by the Child Welfare CommitteeForm IX[Rules 27(18) and 79(2)]Undertaking by
the Parent or 'Fit Person' to whom Child is RestoredI
____________________________________ resident of House no. _________
Street_____________ Village/Town ___________ District ________ State ___________
do hereby declare that I am willing to take charge of (name of the child)__________________
Aged _______ under the orders of the Child Welfare Committee__________________ subject
to the following terms and conditions:I. If his/her conduct is unsatisfactory I shall at once inform
the Committee.II. I shall do my best for the welfare and education of the said child as long as he/ she
remains in my charge and shall make proper provision for his/her maintenance.III. In the event of
his/her illness, he/she shall have proper medical attention in the nearest hospital.IV. I undertake toDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

produce him/her before the competent authority as and when required.Date this ................day of
..............SignatureSignature and address of witness(es)(Signed before me)Chairperson, Child
Welfare CommitteeForm X[Rule 27(19)]Order of Short Term Placement Pending InquiryToThe
Officer In-charge________________________________________
Name of the child :
Sex :
Age :
Father's Name :
Mother's Name :
Address :
Date of receiving by Organization/Institution :
Produced by :
This is to authorize and direct you to receive the said child in your charge, and keep her/him in the
Shelter Home/Children's home for care and protection under section 33 (1) of the J.J. Act,
2000.Next Date:(Signature)Chairperson/ MemberChild Welfare CommitteeForm XI[Rule
27(20)]Order of Restoration of a Child to an InstitutionToThe
Officer-in-Charge__________________________________Whereas on the
____________ day of ____________20 ___ (name of the child)
______________________, son/daughter of ________________ aged _____ residing at
__________ being in care and protection under section 33(4) of the Juvenile Justice (Care and
Protection) Act 2000 is ordered by the Child Welfare Committee
_________________________, to be kept in the Children's Home/ Shelter Home
_________________________________________ for a period of
________________.This is to authorize and require you to receive the said child in your charge,
and to kept him/her in the Children's Home/ Shelter Home _________________ for the
aforesaid order to be carried into execution according to law.Given under my hand and the seal of
Child Welfare Committee.This __________________________ day of
_________________________ 20.(signature)Chairperson/ MemberChild Welfare
CommitteeEncl:Copy of the orders, particulars of home and previous record, case history and
individual care plan, whichever is applicable:Form-XII[Rule 28(1)]Order for EnquiryToChild
Welfare Officer/Person in-charge of Voluntary Organization/Social
Worker/Case-Worker____________________________________________________Whereas
a report under section ___________ of the Juvenile Justice (Care and Protection of children) Act,
2000 has been received from ____________________ in respect of (name of the
child)______________, aged (approximate)____, son/daughter of _________residing
at_______________________________, who has been produced before the Committee
under section______ of the Juvenile Justice (Care and Protection of Children) Act, 2000.You are
hereby directed to enquire into the social and family background of the said child and submit your
inquiry report on or before ___________or within such time allowed to you by the
Committee.You are also hereby directed to consult an expert in child psychology, psychiatric
treatment or counselling for their expert opinion if necessary and submit such report along with
your Inquiry Report.You are hereby directed to enquire into the character and social antecedents ofDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

the said juvenile and submit your social investigation report on or before
__________________________ or within such time allowed to you by the
Board/Committee.Dated this _______________________day of
__________________20______.(signature)Chairperson/MemberChild Welfare
CommitteeSealCopy to :
1. The Officer In-charge
Form XIII[Rules 28(3); 33(3)(g)(ii); and (4)(f); and 87(1)(a) and (2)]Format for Inquiry ReportSl.
No________________Produced before the Child Welfare
Committee________________________ (address).Case No.Concerned Government
Department/ Voluntary OrganisationCategory of child in need of care and
protection:______________________________________________________________________
Name Religion
Father's Name Caste
Permanent Address Year of birth
Address of last residence Age
 Sex
Previous institutional/case history and individual care plan, if anyFamily
Members of family Name Age Health Education OccupationMonthly
earningsDisabilitiesAny other
e.g. social
habits
Father         
Step-father         
Mother         
Step-mother         
Siblings         
Any other legal
guardian/ relative        
If married, relevant
particulars_____________________________________________________________________Other
near relatives or agencies
interested______________________________________________________________Attitude
towards religion, normal and ethical code of the home
etc.___________________________________________Social and economic
status________________________________________________Delinquency record of
members of family____________________________________Present living
conditions__________________________________________________Relationship
between parent/parents and children especially with the said child
_________________________________________Other factors of importance if
any___________________________________________Child's HistoryMentalDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

condition(Present and
past)________________________________________________________Physical
condition(Present and
past)________________________________________________________Habits,
interests(moral, recreational
etc.)__________________________________________________Outstanding
characteristics and personality traits_______________________________Companions and
their influence____________________________________________Truancy from home,
if any ________________________________________________School (attitude
towards school, teachers, class mates and vice-versa)
_________________________________________________Work record (jobs held,
reasons for leaving vocational interests, attitude towards job or
employers)___________________________or Neighbourhood and neighbours
report___________________________Parent's attitude towards discipline in the home and
child's reaction______________________________Any other remarksResult of
InquiryEmotional factorsPhysical conditionIntelligenceSocial and economic factorsReligious
factorsReasons for child's need for care and protectionOpinion of experts
consultedRecommendation of Child Welfare Officer/Case Worker/Social Worker regarding
psychological support, rehabilitation and reintegration of the child and suggested planSignature of
the Child Welfare Officer/Case Worker/Social WorkerForm XIV[Rule 33(3)(c)]Order for Declaring
Child Legally Free for Adoption
1. In exercise of the powers vested in the Child Welfare
Committee_______________ constituted under
sub-section________________ of section__________ of the Juvenile Justice
(Care and Protection of Children) Act, 2000 and sub-rule____ of rule____ of
these rules, minor______________________ born on (date) ________ placed
in custody of Specialised Adoption Agency (name & address)
_____________________, __________________________vide order
___________ dated _____________ of the Chairperson, Child Welfare
Committee ________________________, has been declared legally free for
adoption on the basis of details furnished through:
(a)Inquiry/home study conducted by Child Welfare Officer/Social Worker/ Case
Worker(b)Document of surrender executed by the parent(s) and surrender deed signed in the
presence of the Committee under sub-rules __________ of rule _____ of these
rules(c)Declaration submitted by the Specialised Adoption Agency under sub-rules_______ of rule
______ of these rulesDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

2. ____________________________ (name of the Specialised Adoption
Agency) shall fulfill all conditions specified in Juvenile Justice (Care and
Protection of Children) Act, 2000 and the rules relating thereto and furnish a
copy of adoption decree/guardianship order in respect of the minor as may
be required by Committee and the concerned Department of the State
Government of ____________.
Photo  
To be attested by the Chairperson/ Member, CWCDate:Place :Chairperson/MemberChild Welfare
CommitteeFor completion by the Specialised Adoption Agency.I. I have read and understood
Chapters III and IV of Juvenile Justice (Care and Protection of Children) Act, 2000 and the rules
thereunder and agree to abide/be bound by the same while placing said minor in adoption.II. I
further declare that the particulars stated in the declaration submitted by me on
____________________ true and correct. In case they are found to be false or incorrect, the
Committee has right to suspend this Release Order for (name of the minor)
____________________________ and ask for production of said minor before the
Committee.Date:Place:Child Welfare Officer/Social WorkerForm XV[Rule 33(4)(c)]Deed of
SurrenderI __________________________ d/o or s/o___________________________
residing at_____________________________________ am not in a position due to social
reasons/ due to being single/ ill/ disabled to take care of my child (name, if any) _____________
approximate age_____ years. I am explained the consequences of surrendering my child by the
Child Welfare Officer/Social Worker (name) ___________________and the Child Welfare
Committee ______________. In full knowledge of all these facts, I am surrendering my child
before the Committee today, dated _______________. Within two months from this stated date
if I do not revise my decision to take back my child and do not approach the said Committee for the
same, the Committee shall declare my child legally free for adoption and I shall have no further
claim on my child.Signature of parent/guardian in case of no surviving parentDateThat I
_________________________________Child Welfare Officer/Social Worker have explained
the procedure and the consequences of surrendering the child to the concerned parent/guardian on
(date) ______________.
Photo  
To be attested by the Chairperson/ Member, CWC(Signed before me)Chairperson/ MemberChild
Welfare CommitteeForm XVI[Rule 35(3)]A. Foster Carer's Assessment
1. Agency Details
Name of the AgencyAddressTelephoneFaxE-mailName of the Social
WorkerTelDate_____________________ (Form Completed)Delhi Juvenile Justice (Care and Protection of Children) Rules, 2009

2. Details of the Applicant
SurnameFull NameDate of BirthReligionLanguage(s) spoken at HomeOccupation(a)Nature of
Work(b)Hours of WorkAddressTelephone
3. Description of a preferred child
The type of child, the foster-carer would consider(To be filled after a full discussion with the
Foster-carer)
Age Range Under 2 years 3-6 years 7-12 years 13-15 years 16-18 years
Sl. No. Type of Placement Duration
 Pre-adoption  
 Emergency  
 Short-term  
 Assessment  
 Long-term  
The Child an applicant can care for (Please Tick)A child who is:i. Neglectedii. Orphanediii. With
Physical impairmentiv. Mental impairmentv. Hearing impairmentvi. Speech impairmentvii. Special
Education needsviii. Learning difficultiesix. Physical abusex. Sexual abusexi. Who does not relate
easilyxii. Who needs control/may defy authorityxiii. Born of rape/incestxiv. Who's parent(s)
suffering from diseasexv. Whose parent(s) is HIV positivexvi. Whose parent(s) are AIDS patientxvii.
Whose parent(s) are alcoholicxviii. Drug addictsxix. Are in jailxx. Relinquishedxxi. Belong to
another castexxii. Are of different religion
4. Profile of the family
Brief Family Profile
Name Gender Approx. Age Occupation Education Relationship with the applicant
      
      
(Give details of personalities, family life, experiences etc. Also highlight specific qualities of the
family that can match with a child's needs. The details should facilitate initial identification of a
potential match with a specific child.)Accommodation (House)(Details of type, size, own/rented
space, amenities etc.)Neighbourhood(Details of composition, amenities and facilities, public
transport etc.)
5. Verification of applicant's identity
Place of residencePeriod of stayNationalityMarital status (date/length of marriage)Has either of the
applicant had a previous marriage? DetailsIf children from previous marriage? DetailsSpecifyDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

documents seen with date
6. Career History
(Details of education, employment, voluntary work, part time work, leisure activities)
7. Agency Inquiries:
Medical checkPolice checkEmployer
8. Personal references (from 2 persons)
• This section to be completed after interviews with two references; information gathered through
these interviews should include:• Length of time known• Relationship to the applicant• Provide
evidence on the applicants ability to perform the tasks involved in _________• Caring for
children• Providing a safe and caring environment• Applicant as a neighbour• Interests, talents,
personalityAssessment of the social worker for these referencesB. Home Study ReportA Home Study
Report of the foster carer(s) being a crucial document being prepared by the social worker of the
Specialised Adoption Agency based on the information collected by the format given above should
broadly include the following information:• Social status and family background• Description of the
home• Standard of living as it appears in the home• Current relations amongst the members in the
home• Status of development of the children already in the home• Employment and economic
status• Health details• Details of facilities of education, medical, vocational trainings available in the
neighbourhood• Reasons for wanting a child in foster care• Attitudes of the grandparents and other
relatives• Anticipated plans for the foster child• Legal status of the foster carer(s)• Willingness to
undergo training.C. Details of Applicant(s)
1. Background:
Family structure with details of parents and siblings, significant details of other family members,
childhood experiences, etc.
2. Relationships:
If couple - Length of married life, what qualities does each applicant bring to the partnership, what
makes the relationship positive for each other? Within the relationship how do applicants cope with
problems/stress/anger? How do applicants support each other? What is each applicant's assessment
of how the foster placement will affect his or her relationship?
3. Decision making:
How is decision - making exercised in this relationship and how does each of the applicants view
this? Is there wider extended family involvement in the couple's decision-making process? If so, howDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

will this affect the child to be placed?What are the strengths and vulnerabilities of this partnership?•
Children• Children and their parents' relationships• Children's attitude and readiness for a foster
placement sibling. Describe each child and their temperament, any special talent and need, how
children have been involved in preparation.
4. Applicants support networks:
Give a general picture of support systems currently used by the applicants including extended
family, friends, neighbours, religious activities, community groups etc. include details of the location
etc.
5. Other significant members of the family:
Living in the house or not. Their relationship to the applicants, how much time they spent within the
home, their attitude to the proposed placement? How important is their acceptance of placement to
the applicant.
6. Description of the family life style:
Outline what family considers important e.g. how important are religious & cultural practices. How
is affection show in the family? How do the members spend their time? What expectations family
members have with regard to personal space? What value is placed on education/hobbies and
leisure activities that the whole family undertakes?
7. Parenting capacities:
Experience of the applicants of caring and working with children. Describe their adjustment to
parenthood. What is their understanding of how children develop? Using their own childhood
experiences what patterns of parenting would the repeat and what would they change? What is their
understanding of their own parenting strengths/potentials and about their parenting skills to meet
the needs of individual child. To what extent they would expect other family members to be involved
in parenting of their children/placed children. How will they ensure that a child will be safe from
physical sexual abuse in their family and within wider support networks?
8. Managing Unacceptable Behaviour:
What are rules in the household? How do the applicants show approval/disapproval? What are
discipline measures they use? Their attitude towards punishment?What do they anticipate would be
the issues and difficulties and themselves for their own children and for their support network?
What do they anticipate would be the issues and difficulties for the child? Which changes do they
anticipate would need in their lifestyle?Social workers assessment:It should provide an analysis of
all the information collected through the format and its significance with regard to the capacity of
the applicant to carryout fostering task: (What skills do the applicants have in relating to andDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

working with children? How well will the applicant work with the agency, with biological parents?
What are the strengths and resources of the applicants and which are the areas where they may
experience difficulty? Also the point of disagreement between the social worker and the applicants
should be recorded here)Recommendations of the Child Welfare Officer/Social
Worker(Signature)Form XVII[Rule 34(1)]Order of Foster Care PlacementThe child (name and
address) _____________________ approximate age______ d/o or s/o
Mr.______________ and Mrs._____________or Ms.___________________ is in need of
care and protection of a family. Mr._____________________________ and
Mrs._________________ or Ms._________________ resident of (complete address and
contact
numbers)_______________________________________________________is/ are
declared fit person/persons for foster-care placement of the child based on the home study report of
the Child Welfare Officer/Social Worker Ms./ Mr.______________ of the organization (address)
_____________________________________________________.The child (name)
________________ is placed in foster care for a period of _______________(days/ months),
under the supervision of the aforesaid Child Welfare Officer/Social Worker (name and contact)
________________________________.Chairperson/ MemberChild Welfare
CommitteeForm XVIII[Rule 37(5)]Order of Sponsorship PlacementThe juvenile/child (name and
address) ________________________________approximate age______ d/o or s/o
Mr.___________________ and Mrs. ________________or Ms.__________________
has been identified by the State/ District Child Protection Unit as a juvenile/child at risk needing
urgent care and protection. On the basis of the Inquiry Report submitted by the State/District Child
Protection Unit/ Child Welfare Officer/ Social Worker it is established that the said juvenile/child
needs sponsorship support for education/ health/ nutrition/ other developmental needs
______________________ (please specify). The State/District Child Protection Unit is hereby
directed to release Rs.______ per month/ Rs.________ as one time sponsorship support to the
said juvenile/ child for a period of _________ (days/month) and carryout necessary follow up.The
State/District Child Protection Unit is also directed to clearly lay down the terms and conditions for
sponsorship support and follow up.Principal Magistrate, Juvenile Justice
Board/Chairperson/Member, Child Welfare CommitteeCopy to: State/District Child Protection Unit
or concerned Department of the State GovernmentForm XIX[Rule 38(3)]Order of After Care
PlacementThe juvenile/child (name) ________________ d/o or s/o _________________
has/ will be completing 18 years of age on (date) _____________. She/ he is still in need of care
and protection for the purpose of rehabilitation and reintegration. She/he is placed in (name of
organization)_____________________ for providing aftercare. The In-charge of the
Organization is directed to admit the child and provide all possible opportunities for her/ his
rehabilitation and reintegration in its truest sense. The person shall be provided all these
opportunities maximum till the age of 21 years only or till reintegration in the society, whichever is
earlier. The In-charge will send half yearly report on the status of the child/youth to the Child
Welfare Committee.The State/District Child Protection Unit is hereby directed to arrange for
aftercare for the said juvenile/child for a period of _________ (days/month) and carryout
necessary follow up. The State/District Child Protection Unit is also directed to clearly lay down the
terms and conditions for aftercare programme and carryout necessary follow up.Principal
Magistrate, Juvenile Justice Board/Chairperson/Member, Child Welfare CommitteeCopy to:Delhi Juvenile Justice (Care and Protection of Children) Rules, 2009

State/District Child Protection Unit or concerned Department of the State GovernmentForm
XX[Rule 50(9) and 54(1)(t)]Case History Form for Children in Need of Care and
ProtectionCase/Profile No.______________Date & Time_________________
 Affix a latest photograph here
A. Personal Data
1. Name
2. Male / Female (tick the appropriate category)
3. (a) age at the time of admission
(b)present age:
4. Category:
- Separated from family- Abandoned/deserted- Victim of exploitation and violence (give detail)-
Run-away- Any other
5. Religion Hindu (OC/BC/SC/ST)Muslim/Christian/Other (pl. specify)
6. Location of Residence Urban/Sub-urban/Rural/Slum/Industrial/Other (Pl. specify)
7. Native District & State:
8. By whom the juvenile was brought before the Child Welfare Committee:
I. Police-Local Police/Special Juvenile Police Unit/Railway Police/Women PoliceII. Probation
OfficersIII. Social Welfare OrganizationIV. Social WorkerV. Parent(s)/Guardian (s) (please Specify
the relationship)VI. Child himself/herself
9. Reasons for leaving the family
I. Abuse by parent(s)/guardian(s)/step parents(s)II. In search of employmentIII. Peer group
influenceIV. Incapacitation of parentsV. Criminal behaviour of parentsVI. Separation of ParentsVII.
Demise of parentsVIII. PovertyIX. Others (please specify)
10. Types of abuse met by the child
I. Verbal abuse - parents/siblings/employers/others (pl. specify)II. Physical abuse - denial of food/
beaten mercilessly/ causing injury (pl. specify)III. Sexual abuse parents/siblings/Employers/others
(Pl. specify)IV. Others - parents/siblings/employers/others (pl. Specify)Delhi Juvenile Justice (Care and Protection of Children) Rules, 2009

11. Health status of the child before admission.
I. Respiratory disorders - present / not known / absentII. Hearing impairment - present / not
known / absentIII. Eye diseases - present / not known / absentIV. Dental disease - present / not
known / absentV. Cardiac diseases - present / not known / absentVI. Skin disease - present / not
known / absentVII. Sexually transmitted diseases - present / not known / absentVIII. Neurological
disorders - present / not known / absentIX. Mental handicap - present / not known / absentX.
Physical handicap - present / not known / absentXI. Others (pl. specify) - present / not known /
absent
12. With whom the child was staying prior to admission
I. Parent(s) - Mother / Father / BothII. Guardian(s) - RelationshipIII. FriendsIV. On the streetV.
Night shelterVI. Orphanages / Hostels/ Similar HomesVII. Other (pl. specify)
13. Visit of the parents to meet the child
I. Prior to institutionalisation - Frequently / Occasionally / Rarely / NeverII. After
institutionalisation - Frequently / Occasionally / Rarely / Never
14. Visit of the child to his family
I. Prior to institutionalisation - Frequently / Occasionally / Rarely / During festival times / During
summer holidays / Whenever fallen sick / NeverII. After institutionalisation - Mention dates :
DD.MM.YY
15. Correspondence with parents -
I. Prior to institutionalisation - Frequently / Occasionally / Rarely / During festival times / During
summer holidays /Whenever fallen sick / NeverII. After institutionalisation - Frequently /
Occasionally / Rarely / During festival times / During summer holidays /Whenever fallen sick /
NeverB. Childhood History (up to the age of 12 years)
16. Details of immunization provided
17. Details of handicap
I. Hearing impairment By birth/ After accident/ diseases
II. Speech impairment By birth/ After accident/ diseases
III. Physical handicap By birth/ After accident/ diseases
IV. Mental handicap By birth/ After accident/ diseases
V. Others (please specify)  Delhi Juvenile Justice (Care and Protection of Children) Rules, 2009

C. Family Details :
18. Household Composition:
S. No. Name & Relationship Age Sex Education Occupation Income
1 2 3 4 5 6 7
       
Health History of Mental illness Handicap Habit Socialization
8 9 10 11 12
     
19. Type of family:
Nuclear family / joint family/ broken family
20. Relationship among the family members:
I.Father & mother Cordial/ Non cordial/ Not known
II.Father & child Cordial/ Non cordial/ Not known
III.Mother & child Cordial/ Non cordial/ Not known
IV.Father & siblings Cordial/ Non cordial/ Not known
V.Mother & siblings Cordial/ Non cordial/ Not known
VI.Juvenile & siblings Cordial/ Non cordial/ Not known
21. History of crime committed by family members:
S.
No.RelationshipNature of
crimeArrest if any
madePeriod of
confinementPunishment
awarded
1. Father     
2. Step-father     
3. Mother     
4. Step-mother     
5. Brother     
 (a)(b)(c)(d)     
6. Sister     
 (a)(b)(c)(d)     
7. Child     
8.Others (uncle/ aunty/
grandparents)    Delhi Juvenile Justice (Care and Protection of Children) Rules, 2009

22. Parental care towards juvenile before admission:
I. Over protectionII. AffectionateIII. AttentiveIV. Not affectionateV. Not attentiveVI. RejectionD.
Adolescence History (Between 12 and 18 years)
23. Puberty
EarlyMiddle ageLate
24. Details of delinquent behaviour if any
I. StealingII. Pick pocketingIII. Arrack sellingIV. Drug pedalingV. Petty offencesVI. Violent
crimeVII. RapeVIII. None of the aboveIX. Others (please specify)
25. Reason for delinquent behaviour
I. Parental neglectII. Parental overprotectionIII. Parents criminal behaviourIV. Parents influence
(negative)V. Peer group influenceVI. To buy drugs/alcoholVII. Others (pl. specify)
26. Habits
A B
i) Smoking i) Watching TV/movies
ii) Alcohol consumption ii) Playing indoor/outdoor games
iii) Drug use (specify) iii) Reading books
iv) Gambling iv) Religious activities
v) Begging v) Drawing/painting/acting/singing
vi) Any other vi) Any other
E. Employment DetailsEmployment details of the juveniles prior to entry into the Home:
S.No. Details of employment Duration Wages earned
I. Cooly   
II. Rag picking   
III. Mechanic   
IV. Hotel work   
V. Tea shop work   
VI. Shoe polish   
VII. Household works   
VIII. Others (pl. specify)   Delhi Juvenile Justice (Care and Protection of Children) Rules, 2009

27. Details of income utilization:
I. Sent to family to meet family needII. For dress materialsIII. For gamblingIV. For prostitutionV.
For alcoholVI. For drugVII. For smokingVIII. Savings
28. Details of savings
I. With employersII. With friendsIII. Bank/Post OfficeIV. Others (pl. specify)
29. Duration of working hours
I. Less than six hoursII. Between six and eight hoursIII. More than eight hoursF. Educational
Details
30. The details of education of the juvenile prior to the admission to
Children's Home
I. IlliterateII. Studied up to V StandardIII. Studied above V Std but below VIII StandardIV. Studied
above VIII Std but below X StandardV. Studied above X Standard
31. The reason for leaving the School
I. Failure in the class last studiedII. Lack of interest in the school activitiesIII. Indifferent attitude of
the teachersIV. Peer group influenceV. To earn and support the familyVI. Sudden demise of
parentsVII. Rigid school atmosphereVIII. Absenteeism followed by running away from schoolIX.
Others (pl. specify)
32. The details of the school in which studied last:
I. Corporation/Municipal/Panchayat UnionII. Government/SC Welfare School/BC Welfare
SchoolIII. Private managementIV. Convents
33. Medium instruction:
Hindi/English/Urdu/Tamil/Malayalam/Kannada/ TeluguOther language (please specify)
34. After admission to Children's Home, the educational attainment from the
date of admission till date;
No. of years Class studied Promoted /detainedDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

35. Vocational training undergone form the date of admission into Children's
Home till date.
No. of years Name of Vocational Trade Proficiency Attained
36. Extra curricular activities developed form the date of admission into the
Children's Home till date
I. ScoutII. Sports (please specify)III. Athletics (please specify)IV. DrawingV. PaintingVI. Others (pl.
specify)G. Medical History
37. Height and weight at the time of admission:
38. Physical condition:
39. Medical history of child (gist):
40. Medical history of parent/guardian (gist):
41. Present health status of the child:
Sl. No. Annual Observation Date of review 1stQuarter 2ndQuarter 3rdQuarter 4thQuarter
1. Height      
2. Weight      
3. Nutritious diet given      
4. Stress disease      
5. Dental      
6. ENT - Tonsils      
7.External eye problem :
vision     
 Left      
 Right      
42. Height and Weight Chart:
Date, Month & Year Height Admissible weight Actual weight
    
    
    
    
    Delhi Juvenile Justice (Care and Protection of Children) Rules, 2009

    
H. Social History
43. Majority of the friends are
I. EducatedII. IlliterateIII. The same age groupIV. Older in ageV. Younger in ageVI. Same sexVII.
Opposite sexVIII. Association with gangs
44. The reaction of the society when the child first came out of the family
I. SupportiveII. RejectionIII. AbuseIV. Ill-treatmentV. Exploitation
45. The reaction of the police towards children
I. PassionateII. CruelIII. AbuseIV. ExploitationV. Ill-treatment
46. The response of the general public towards the child
History of the Child (Gist)i. Educationii. Healthiii. Vocational trainingiv. Extra curricular activitiesv.
OthersSuggestion of Child Welfare Officer/ Probation Officer after orientation to juvenile/child and
the response towards orientation.Follow up by Child Welfare Officer/ Probation Officer/ Case
Worker/ Social Worker Quarterly Review of Case History by Management
CommitteeSuperintendent/Welfare Officer/Probation OfficerForm XXI[Rules 50(12)(a), 54(1)(o)
and 87(1)(k)]Individual Care PlanIndividual care plan for each child shall be prepared following the
principle of the best interest of the child. In preparing individual care plan the care options in the
following order of preferences shall be considered:(i)Preserving the biological family(ii)Kinship
Care(iii)In-country adoption(iv)Foster Care(v)Inter-country Adoption(vi)Institutional
CareCase/Profile No. of 20____(year) of the Board/CommitteeAdmission No.Date of Admission:A.
Personal Details
1. Name of the Child:
2. Age:
3. Sex: Male/Female
4. Father's/Mother's name:
5. Nationality:Delhi Juvenile Justice (Care and Protection of Children) Rules, 2009

6. Religion/caste:
7. Educational Attainment:
8. Summary of Case History:
Health needsEmotional and psychological support neededEducational and Training needsLeisure,
creativity and playAttachments and RelationshipsReligious beliefsProtection from all kinds of
abuse, neglect and maltreatmentSocial mainstreamingFollow-up post release/restorationB.
Fortnightly Progress Report of Probationer
Part One – 1. Name of the Probation Officer/Case Worker
2. For the month of
3. Registration No.
4. Competent Authority
5. Profile No.
6. Name of the Child
7. Date of Supervision Order
8. Address of the Child
9. Period of Supervision
Part Two – {|
|-| Places of interview| Dates|-| ............................| ......................|-| ............................|
......................|-| ............................| ......................|}
1. Where the child is residing?
2. Progress made in any educational/training course.Delhi Juvenile Justice (Care and Protection of Children) Rules, 2009

3. What work he/she is doing and his/her monthly average earning, if
employed.
4. Savings kept in the Post Office.
5. Savings Bank Account in his/her name.
6. Remarks on his/her general conduct and progress.
7. Whether property cared for?
Part Three – 1. Any proceedings before the competent authority
of or
(a)Variation of conditions of bond(b)Change of residence(c)Other matters
2. Period of supervision completed on.......................
3. Result of supervision with remarks (if any)
4. Name and Addresses of the parent or guardian or fit person under whose
care the juvenile is to live after the supervision is over.
Date of report_____________Signature of the Probation Officer/Case Worker_______C.
Pre-Release ReportTick whichever is applicable
Final Release  Transfer   
1. Details of place of transfer and concerned authority responsible in the
place of transfer/release
2. Details placement of the juvenile/child in different institutions
3. Training undergone and skills acquired
4. Final progress report of the officer-in-charge/probation officer/child
welfare officer/case worker/social worker (to be attached)Delhi Juvenile Justice (Care and Protection of Children) Rules, 2009

5. Date of release/transfer
6. Date of repatriation
7. Requisition for escort if required
8. Identification of escort
9. Recommended rehabilitation plan including possible placements
10. Sponsorship requirement and report, if applicable
11. Identification of Probation Officer/Case worker/social
worker/non-governmental organization for post-release follow-up
12. Memorandum of Understanding with non-governmental organization
identified for post-release follow-up
13. Identification of sponsorship agency/individual sponsor for the child
post-release, if any
14. Memorandum of Understanding between the sponsoring agency and
individual sponsor
15. Details of Savings Account of the child, if any
16. Details of child's earnings and belongings if any
17. Details of awards/rewards due to the child if any
18. Opinion of the child
19. Any other information
Note: Pre-release report shall be prepared 6 months prior to the date of release/transfer of
juvenile/child and shall take into account the recommendations of the last review report and all
other relevant information.D. Post-Release ReportDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

1. Status of Bank Account : Closed / Transferred
2. Earnings and belongings of the child : handed over to the child or his/her
parents/guardians - Yes/No
3. First interaction report of the probation officer/child welfare officer/case
worker/social worker/non-governmental organisation identified for follow-up
with the child post-release
4. Placement of the juvenile/child if any
5. Family's behaviour towards the child
6. Social milieu of the child, particularly attitude of neighbours/community
7. How is the child using the skills acquired?
8. Whether the child has been admitted to a school or vocation? Give date
and name of the school/institute/any other agency
9. Report of second and third follow-up interaction with the child after two
months and six months respectively
Form XXII[Rule 65(2)]Escort OrderCase No...................In the matter of Boy/Girl
Child...........................................Aged about.....................year takenCharged for sole custody
underSection 33(3) of the JuvenileJustice Act 2000The Parents of the boy/girl child are reported to
be residing at:He/She therefore be sent under supervision of a proper police/ non-governmental
organization escort to the________________________________________.For tracing and
for handing over to the parents or close relatives of the said Boy Child/Girl Child residing at the
aforesaid address or at other Place which may be shown by the Child, if no such parents or relative
are traced or if traced but they are unwilling to take charge of the boy/girl be kept in the custody of
the Superintendent.................................Children's Home and the said Boy/Girl child be produced
before the concerned Child Welfare Committee for further orders.OrdersPending Escort, the said
Boy/Girl Child shall remain in Children's Home, residing at present at
______________________The State/District Child Protection Unit, or Police Department or
non-governmental organization/ Childline shall positively make immediate arrangement not less
than 15 days from the date of receipt of this order by him and send the said Boy Child/Girl Child at
his/her aforesaid place of residence.Dated this...................day
of.....................200.................Chairperson/MemberChild Welfare CommitteeCC to:Delhi Juvenile Justice (Care and Protection of Children) Rules, 2009

1. The Superintendent, Children Home,.
2. The State/District Child Protection Unit or non-governmental organization
or Childline
Ref.: 1. Order of admission of minor................born on................Profile No.................Form
XXIII[Rule 11(1)(b)]Intimation of ApprehensionDate :Sir/Madam,
1. You [Name of Parents/Guardian/Concerned Officer], [W/o / S/o / from
<NGOs' name>] are hereby informed through this intimation that [name of
juvenile alleged to be in conflict with law] has been apprehended by [Police
Station] on the ground of him being found in conflict with law under
[Section...........] of [name of Act] on [Date & Time]. He/she has been
apprehended from [Description of place] by the undersigned.
2. [Description of circumstances in which juvenile alleged to be in conflict
with law has been found to be in conflict with law].
3. Juvenile [Name] has been kept at [address of the place where Juvenile has
been kept at present] and he is being brought before Juvenile Justice Board
at [Full address of Juvenile Justice Board] on [Date & Time] and you are
requested to be present there.
Sd/[Name and Signature of Concerned officerFrom Special Juvenile Police Unit/OfficerIn charge of
the Police Station][Name of Police Station][Date]CC.
1. Juvenile Justice Board [Full Address]
2. Concerned Probation Officer
Form-XXIVRequest for Medical ExaminationCase
FIR/D.D.No....................Date......................U/s.....................P.S..........................Distt.................................Delhi.To,The
Chief Medical
Officer.......................................................................................................................DelhiSubject:
Request for Medical ExaminationSir,With due respect I am sending
Master/Ms......................................S/o, D/o, W/o
Sh..............................................R/o.................................................Age......................in the
custody/protection of 1. Const...........................No. .......................2. W/Const. .........................
No...........................It is therefore, requested that the child/patient may kindly be medically
examinedAnd opinion regarding his/her injuries/ailment may be furnished.Thanking you,Name of
JWO ...........................P.S .............................................Distt..................Delhi/NewDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

DelhiDate............................................Form - XXVApprehension MemoFIR No./D.D.
No...................... U/S ........................ Date ..................... Police Station ........................
District.....................
1.Name of the child with alias (if any) ...............................
2.Present address of the Child ...............................
3.Permanent address of the child ...............................
4.FIR/ DD No. & Section (s) of Law ...............................
5.Place of apprehension ...............................
6.Date & time of apprehension ...............................
7.Name, address & telephone number of the person informedabout
apprehension...............................
8.Relation of the person with juvenile ...............................
9.Name, Rank and No. of the officer, making the apprehension ...............................
10.Name, Rank and No. of the, Juvenile Welfare Officer ...............................
Witnesses with Address
1. ...........................
.........................
2. ...........................
.........................
3. ...........................
.........................Signature by Patent/ guardian/Probation Officer/ Social WelfareSignature of
Juvenile Welfare OfficerPS .......................... Delhi/ New Delhi..............................Note : One copy to
be delivered to the member of Child's family.Form - XXVIPersonal Search MemoFIR No./D.D.
No................. U/S ................ Date ................... Police Station ....................
District......................Delhi.In the presence of the following witnesses the personal search of
Master/Ms.................... S/o .................................... Address ............................................Telephone
No. ..............................................................Was conducted as per law under the provisions of Section
51 of Cr.P.C. and following articles have been recovered from his/her possession and the same have
been taken into the police possession, through this memo.
1. ...................................Delhi Juvenile Justice (Care and Protection of Children) Rules, 2009

2. ...................................
3. ...................................
4. ...................................
5. ...................................
6. ...................................
Witness (with name & address):-
1.
) ..........................................
2.
) ..........................................Sd Juvenile or Child Welfare OfficerP.S.
..............................................Date .............................................Form - XXVIIUndertakingUndertaking
to be given by parent/ guardian/ fit person in whose custody juvenile/ child in conflict with law
(JCL)/ Child in need of care and protection (CNCP) is released by a police officer.Case No.
......................................... of ................................. 20........................Whereas .......................... has
been found to be in conflict with law/ in need of care and protection, and has been placed under the
care and supervision of(Name)............................ (Address)
........................................................Subject to following conditions, that :-
1. The child shall be produced before the Juvenile Justice Board (JJB)/ Child
Welfare Committee (CWC) as and when required by me.
2. The child shall remain under my supervision.
3. The child shall reside at ...............................and address of child shall not
be changed without information to the JWO/JJB/CWC.
4. The child shall go to school regularly.
5. The child shall be permitted to make endeavour to earn an honest
livelihood.Delhi Juvenile Justice (Care and Protection of Children) Rules, 2009

6. I shall arrange for the proper care, education and welfare of the child.
7. The child shall not be allowed to associate with undesirable characters
and shall be prevented from coming in conflict with law again.
8. The child shall be prevented from taking Narcotic Drugs or Psychotropic
Substances or any other intoxicants.
This ...................................day of ..................................200Signature of parent/guardian/fit
personCounter signed by JWOPS............................Delhi/ New DelhiForm - XXVIIISocial
Background ReportUnder Juvenile Justice (Care and Protection of Children) Rules, 2007For Under
Rule 11 (6)Personal History
1. Name of the child .......................................
2. Age (attach proof/ documents) ....................... 3. Sex ........................
4. Religion .......................... 5. Caste ...........................
6. Educational Qualification (child studying in school) :
Name of the school ...............................................Name of the school (last attended in case child is a
school drop-out) ....................................
7. Whether child is working (if yes, mention details) : ..................... Yes/ No
...........
Nature of work .................................................Place of work ..................................................Address
of work place ......................................................Name of the Employer/Firm/Company
.........................................................Telephone No. ....................................................
8. Residential address/contact number (with landmark):
Present Address ...............................................................Telephone No.
...............................................................Permanent Address
..................................................................Telephone No. ............................ (Landmark)
.................................................
9. Does child has any history of addiction to Drugs/Alcohol/Tobacco items.
If yes, Specify the same ......................................................................Family BackgroundDelhi Juvenile Justice (Care and Protection of Children) Rules, 2009

Members of the
familyName/
AgeHealth
(Disability, if
any)Education OccupationMonthly
incomeAny habit of
Drugs, Alcohol,
Tobacco
Father       
Mother       
Siblings (if
married please
specify)      
Any other legal
guardian      
10. Date, time and place of apprehension .......................................................
11. Date, time and place of sharing information with the parents/guardian/fit
person:
..................................................... PS Reference ............................ DD No.....................................
12. Where the child kept during custody of police/JWO:
................................................Name of Juvenile Welfare Officer/Police officer in whose custody child
kept :................................................Case BackgroundDD Entry No. .................. FIR No .......................
Police Station ..................Section of law ...............................................................Any adult involved in
this case : (if yes, give details) ..................................................Name of Investigation/ Handling
officer with contact number :................................... PIS No. .............................. Telephone No.
......................Name of Juvenile Officer with contact number :..................................... PIS No.
.......................... Telephone No. ..........................Name & Signature of JWO .......................Date
...........................Delhi Juvenile Justice (Care and Protection of Children) Rules, 2009

