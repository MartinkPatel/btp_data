Centrlal Board Of Sec.Education & Anr vs Aditya Bandopadhyay
& Ors on 9 August, 2011
Equivalent citations: 2011 AIR SCW 4888, 2011 (8) SCC 497, AIR 2011 SC
(CRIMINAL) 2000, 2012 (1) AIR JHAR R 321, 2012 (1) AIR KAR R 163, (2011) 3
CAL LJ 85, (2012) 1 CIVLJ 752, (2011) 7 MAD LJ 1237, (2011) 4 MAD LW 289,
(2011) 6 ANDHLD 38, (2011) 8 SCALE 645, (2011) 4 ESC 600, (2011) 4 JCR 14
(SC), (2011) 5 MPHT 1, (2011) 4 GAU LT 1, (2011) 106 ALLINDCAS 187 (SC),
(2011) 2 CLR 478 (SC), (2011) 88 ALL LR 701, (2011) 6 ALL WC 5567, (2011) 3
CIVILCOURTC 596, (2011) 2 ORISSA LR 746, (2011) 2 WLC(SC)CVL 592, 2011
(4) KCCR SN 463 (SC), 2011 (9) ADJ 7 NOC
Author: R.V.Raveendran
Bench: A. K. Patnaik, R. V. Raveendran
                                                                                       Reportable
                     IN THE SUPREME COURT OF INDIA
                      CIVIL APPELALTE JURISDICTION
                       CIVIL APPEAL NO.6454  OF 2011
                      [Arising out of SLP [C] No.7526/2009]
Central Board of Secondary Education & Anr.                       ... Appellants
Vs.
Aditya Bandopadhyay & Ors.                                        ... Respondents
                                         With
CA No. 6456 of 2011 (@ SLP (C) No.9755 of 2009)
CA Nos.6457-6458 of 2011 (@ SLP (C) Nos.11162-11163 of 2009)Centrlal Board Of Sec.Education & Anr vs Aditya Bandopadhyay & Ors on 9 August, 2011

CA No.6461 of 2011 (@ SLP (C) No.11670 of 2009)
CA Nos.6462 of 2011 (@ SLP (C) No.13673 of 2009)
CA Nos.6464 of 2011 (@ SLP (C) No.17409 of 2009)
CA Nos. 6459 of 2011 (@ SLP (C) No.9776 of 2010)
CA Nos.6465-6468 of 2011 (@ SLP (C) Nos.30858-30861 of 2009)
                                 J U D G M E N T
R.V.RAVEENDRAN, J.
Leave granted. For convenience, we will refer to the facts of the first case.
2. The first respondent appeared for the Secondary School Examination, 2008 conducted by the
Central Board of Secondary Education (for short `CBSE' or the `appellant'). When he got the mark
sheet he was disappointed with his marks. He thought that he had done well in the examination but
his answer-books were not properly valued and that improper valuation had resulted in low marks.
Therefore he made an application for inspection and re-evaluation of his answer-books. CBSE
rejected the said request by letter dated 12.7.2008. The reasons for rejection were:
(i) The information sought was exempted under Section 8(1)(e) of RTI Act since
CBSE shared fiduciary relationship with its evaluators and maintain confidentiality of
both manner and method of evaluation.
(ii) The Examination Bye-laws of the Board provided that no candidate shall claim or
is entitled to re-evaluation of his answers or disclosure or inspection of answer
book(s) or other documents.
(iii) The larger public interest does not warrant the disclosure of such information
sought.
(iv) The Central Information Commission, by its order dated 23.4.2007 in appeal no.
ICPB/A-3/CIC/2006 dated 10.2.2006 had ruled out such disclosure."
3. Feeling aggrieved the first respondent filed W.P. No.18189(W)/2008 before the Calcutta High
Court and sought the following reliefs : (a) for a declaration that the action of CBSE in excluding the
provision of re- evaluation of answer-sheets, in regard to the examinations held by it was illegal,
unreasonable and violative of the provisions of the Constitution of India; (b) for a direction to CBSE
to appoint an independent examiner for re- evaluating his answer-books and issue a fresh marks
card on the basis of re- evaluation; (c) for a direction to CBSE to produce his answer-books in regard
to the 2008 Secondary School Examination so that they could be properly reviewed and fresh marks
card can be issued with re-evaluation marks; (d) for quashing the communication of CBSE datedCentrlal Board Of Sec.Education & Anr vs Aditya Bandopadhyay & Ors on 9 August, 2011

12.7.2008 and for a direction to produce the answer-books into court for inspection by the first
respondent. The respondent contended that section 8(1)(e) of Right to Information Act, 2005 (`RTI
Act' for short) relied upon by CBSE was not applicable and relied upon the provisions of the RTI Act
to claim inspection.
4. CBSE resisted the petition. It contended that as per its Bye-laws, re- evaluation and inspection of
answer-books were impermissible and what was permissible was only verification of marks. They
relied upon the CBSE Examination Bye-law No.61, relevant portions of which are extracted below:
"61. Verification of marks obtained by a Candidate in a subject
(i) A candidate who has appeared at an examination conducted by the Board may
apply to the concerned Regional Officer of the Board for verification of marks in any
particular subject. The verification will be restricted to checking whether all the
answer's have been evaluated and that there has been no mistake in the totalling of
marks for each question in that subject and that the marks have been transferred
correctly on the title page of the answer book and to the award list and whether the
supplementary answer book(s) attached with the answer book mentioned by the
candidate are intact. No revaluation of the answer book or supplementary answer
book(s) shall be done.
(ii) Such an application must be made by the candidate within 21 days from the date
of the declaration of result for Main Examination and 15 days for Compartment
Examination.
(iii) All such applications must be accompanied by payment of fee as prescribed by
the Board from time to time.
(iv) No candidate shall claim, or be entitled to, revaluation of his/her answers or
disclosure or inspection of the answer book(s) or other documents.
xxxx
(vi) In no case the verification of marks shall be done in the presence of the candidate or anyone else
on his/her behalf, nor will the answer books be shown to him/her or his/her representative.
(vii) Verification of marks obtained by a candidate will be done by the officials appointed by or with
the approval of the Chairman.
(viii) The marks, on verification will be revised upward or downward, as per the actual marks
obtained by the candidate in his/her answer book. xxxx
62. Maintenance of Answer Books The answer books shall be maintained for a period of three
months and shall thereafter be disposed of in the manner as decided by the Chairman from time toCentrlal Board Of Sec.Education & Anr vs Aditya Bandopadhyay & Ors on 9 August, 2011

time."
(emphasis supplied) CBSE submitted that 12 to 13 lakhs candidates from about 9000 affiliated
schools across the country appear in class X and class XII examinations conducted by it and this
generates as many as 60 to 65 lakhs of answer- books; that as per Examination Bye-law No.62, it
maintains the answer books only for a period of three months after which they are disposed of. It
was submitted that if candidates were to be permitted to seek re-evaluation of answer books or
inspection thereof, it will create confusion and chaos, subjecting its elaborate system of
examinations to delay and disarray. It was stated that apart from class X and class XII examinations,
CBSE also conducts several other examinations (including the All India Pre-Medical Test, All India
Engineering Entrance Examination and Jawahar Navodaya Vidyalaya's Selection Test). If CBSE was
required to re-evaluate the answer-books or grant inspection of answer-books or grant certified
copies thereof, it would interfere with its effective and efficient functioning, and will also require
huge additional staff and infrastructure. It was submitted that the entire examination system and
evaluation by CBSE is done in a scientific and systemic manner designed to ensure and safeguard
the high academic standards and at each level utmost care was taken to achieve the object of
excellence, keeping in view the interests of the students. CBSE referred to the following elaborate
procedure for evaluation adopted by it :
"The examination papers are set by the teachers with at least 20 years of teaching
experience and proven integrity. Paper setters are normally appointed from amongst
academicians recommended by then Committee of courses of the Board. Every paper
setter is asked to set more than one set of question papers which are moderated by a
team of moderators who are appointed from the academicians of the University or
from amongst the Senior Principals. The function of the moderation team is to ensure
correctness and consistency of different sets of question papers with the curriculum
and to assess the difficulty level to cater to the students of different schools in
different categories. After assessing the papers from every point of view, the team of
moderators gives a declaration whether the whole syllabus is covered by a set of
question papers, whether the distribution of difficulty level of all the sets is parallel
and various other aspects to ensure uniform standard. The Board also issues detailed
instructions for the guidance of the moderators in order to ensure uniform criteria
for assessment.
The evaluation system on the whole is well organized and fool-proof. All the
candidates are examined through question papers set by the same paper setters.
Their answer books are marked with fictitious roll numbers so as to conceal their
identity. The work of allotment of fictitious roll number is carried out by a team
working under a Chief Secrecy Officer having full autonomy. The Chief Secrecy
Officer and his team of assistants are academicians drawn from the Universities and
other autonomous educational bodies not connected with the Board. The Chief
Secrecy Officer himself is usually a person of the rank of a University professor. No
official of the Board at the Central or Regional level is associated with him in
performance of the task assigned to him. The codes of fictitious roll numbers andCentrlal Board Of Sec.Education & Anr vs Aditya Bandopadhyay & Ors on 9 August, 2011

their sequences are generated by the Chief Secrecy Officer himself on the basis of
mathematical formula which randomize the real roll numbers and are known only to
him and his team. This ensures complete secrecy about the identification of the
answer book so much so, that even the Chairman, of the Board and the Controller of
Examination of the Board do not have any information regarding the fictitious roll
numbers granted by the Chief Secrecy Officer and their real counterpart numbers.
At the evaluation stage, the Board ensures complete fairness and uniformity by
providing a marking scheme which is uniformity applicable to all the examiners in
order to eliminate the chances of subjectivity. These marking schemes are jointly
prepared at the Headquarters of the Board in Delhi by the Subject Experts of all the
regions. The main purpose of the marking scheme is to maintain uniformity in the
evaluation of the answer books.
The evaluation of the answer books in all major subjects including mathematics,
science subjects is done in centralized "on the spot"
evaluation centers where the examiners get answer book in interrupted serial orders. Also, the
answer books are jumbled together as a result of which the examiners, say in Bangalore may be
marking the answer book of a candidate who had his examination in Pondicherry, Goa, Andaman
and Nicobar islands, Kerala, Andhra Pradesh, Tamil Nadu or Karnataka itself but he has no way of
knowing exactly which answer book he is examining. The answer books having been marked with
fictitious roll numbers give no clue to any examiner about the state or territory it belongs to. It
cannot give any clue about the candidate's school or centre of examination. The examiner cannot
have any inclination to do any favour to a candidate because he is unable to decodify his roll number
or to know as to which school, place or state or territory he belongs to. The examiners check all the
questions in the papers thoroughly under the supervision of head examiner and award marks to the
sub parts individually not collectively. They take full precautions and due attention is given while
assessing an answer book to do justice to the candidate. Re- evaluation is administratively
impossible to be allowed in a Board where lakhs of students take examination in multiple subjects.
There are strict instructions to the additional head examiners not to allow any shoddy work in
evaluation and not to issue more than 20-25 answer books for evaluation to an examiner on a single
day. The examiners are practicing teachers who guard the interest of the candidates. There is no
ground to believe that they do unjust marking and deny the candidates their due. It is true that in
some cases totaling errors have been detected at the stage of scrutiny or verification of marks. In
order to minimize such errors and to further strengthen and to improve its system, from 1993
checking of totals and other aspects of the answers has been trebled in order to detect and eliminate
all lurking errors.
The results of all the candidates are reviewed by the Results Committee functioning at the Head
Quarters. The Regional Officers are not the number of this Committee. This Committee reviews the
results of all the regions and in case it decides to standardize the results in view of the results shown
by the regions over the previous years, it adopts a uniform policy for the candidates of all the
regions. No special policy is adopted for any region, unless there are some special reasons. ThisCentrlal Board Of Sec.Education & Anr vs Aditya Bandopadhyay & Ors on 9 August, 2011

practice of awarding standardized marks in order to moderate the overall results is a practice
common to most of the Boards of Secondary Education. The exact number of marks awarded for the
purpose of standardization in different subjects varies from year to year. The system is extremely
impersonalized and has no room for collusion infringement. It is in a word a scientific system."
CBSE submitted that the procedure evolved and adopted by it ensures fairness and accuracy in
evaluation of answer-books and made the entire process as foolproof as possible and therefore
denial of re-evaluation or inspection or grant of copies cannot be considered to be denial of fair play
or unreasonable restriction on the rights of the students.
5. A Division Bench of the High Court heard and disposed of the said writ petition along with the
connected writ petitions (relied by West Bengal Board of Secondary Education and others) by a
common judgment dated 5.2.2009. The High Court held that the evaluated answer-books of an
examinee writing a public examination conducted by statutory bodies like CBSE or any University or
Board of Secondary Education, being a `document, manuscript record, and opinion' fell within the
definition of "information" as defined in section 2(f) of the RTI Act. It held that the provisions of the
RTI Act should be interpreted in a manner which would lead towards dissemination of information
rather than withholding the same; and in view of the right to information, the examining bodies
were bound to provide inspection of evaluated answer books to the examinees. Consequently it
directed CBSE to grant inspection of the answer books to the examinees who sought information.
The High Court however rejected the prayer made by the examinees for re-evaluation of the
answer-books, as that was not a relief that was available under RTI Act. RTI Act only provided a
right to access information, but not for any consequential reliefs. Feeling aggrieved by the direction
to grant inspection, CBSE has filed this appeal by special leave.
6. Before us the CBSE contended that the High Court erred in (i) directing CBSE to permit
inspection of the evaluated answer books, as that would amount to requiring CBSE to disobey its
Examination Bye-law 61(4), which provided that no candidate shall claim or be entitled to
re-evaluation of answer books or disclosure/inspection of answer books; (ii) holding that Bye-law
61(4) was not binding upon the examinees, in view of the overriding effect of the provisions of the
RTI Act, even though the validity of that bye-law had not been challenged; (iii) not following the
decisions of this court in Maharashtra State Board of Secondary Education vs. Paritosh B. Sheth
[1984 (4) SCC 27], Parmod Kumar Srivastava vs. Chairman, Bihar PAC [2004 (6) SCC 714], Board of
Secondary Education vs. Pavan Ranjan P [2004 (13) SCC 383], Board of Secondary Education vs. S
[2007 (1) SCC 603] and Secretary, West Bengal Council of Higher Secondary Education vs. I Dass
[2007 (8) SCC 242]; and (iv) holding that the examinee had a right to inspect his answer book under
section 3 of the RTI Act and the examining bodies like CBSE were not exempted from disclosure of
information under section 8(1)(e) of the RTI Act. The appellants contended that they were holding
the "information" (in this case, the evaluated answer books) in a fiduciary relationship and therefore
exempted under section 8(1)(e) of the RTI Act.
7. The examinees and the Central Information Commission contended that the object of the RTI Act
is to ensure maximum disclosure of information and minimum exemptions from disclosure; that an
examining body does not hold the evaluated answer books, in any fiduciary relationship either withCentrlal Board Of Sec.Education & Anr vs Aditya Bandopadhyay & Ors on 9 August, 2011

the student or the examiner; and that the information sought by any examinee by way of inspection
of his answer books, will not fall under any of the exempted categories of information enumerated in
section 8 of the RTI Act. It was submitted that an examining body being a public authority holding
the `information', that is, the evaluated answer-books, and the inspection of answer-books sought
by the examinee being exercise of `right to information' as defined under the Act, the examinee as a
citizen has the right to inspect the answer-books and take certified copies thereof. It was also
submitted that having regard to section 22 of the RTI Act, the provisions of the said Act will have
effect notwithstanding anything inconsistent in any law and will prevail over any rule, regulation or
bye law of the examining body barring or prohibiting inspection of answer books.
8. On the contentions urged, the following questions arise for our consideration :
(i) Whether an examinee's right to information under the RTI Act includes a right to
inspect his evaluated answer books in a public examination or taking certified copies
thereof?
(ii) Whether the decisions of this court in Maharashtra State Board of Secondary
Education [1984 (4) SCC 27] and other cases referred to above, in any way affect or
interfere with the right of an examinee seeking inspection of his answer books or
seeking certified copies thereof?
(iii) Whether an examining body holds the evaluated answer books "in a fiduciary
relationship" and consequently has no obligation to give inspection of the evaluated
answer books under section 8 (1)(e) of RTI Act?
(iv) If the examinee is entitled to inspection of the evaluated answer books or seek
certified copies thereof, whether such right is subject to any limitations, conditions or
safeguards?
Relevant Legal Provisions
9. To consider these questions, it is necessary to refer to the statement of objects and reasons, the
preamble and the relevant provisions of the RTI Act. RTI Act was enacted in order to ensure
smoother, greater and more effective access to information and provide an effective framework for
effectuating the right of information recognized under article 19 of the Constitution. The preamble
to the Act declares the object sought to be achieved by the RTI Act thus:
"An Act to provide for setting out the practical regime of right to information for
citizens to secure access to information under the control of public authorities, in
order to promote transparency and accountability in the working of every public
authority, the constitution of a Central Information Commission and State
Information Commissions and for matters connected therewith or incidental thereto.
Whereas the Constitution of India has established democratic Republic; And whereas
democracy requires an informed citizenry and transparency of information which areCentrlal Board Of Sec.Education & Anr vs Aditya Bandopadhyay & Ors on 9 August, 2011

vital to its functioning and also to contain corruption and to hold Governments and
their instrumentalities accountable to the governed;
And whereas revelation of information in actual practice is likely to conflict with
other public interests including efficient operations of the Governments, optimum
use of limited fiscal resources and the preservation of confidentiality of sensitive
information; And whereas it is necessary to harmonise these conflicting interests
while preserving the paramountcy of the democratic ideal."
Chapter II of the Act containing sections 3 to 11 deals with right to information and obligations of
public authorities. Section 3 provides for right to information and reads thus: "Subject to the
provisions of this Act, all citizens shall have the right to information." This section makes it clear
that the RTI Act gives a right to a citizen to only access information, but not seek any consequential
relief based on such information. Section 4 deals with obligations of public authorities to maintain
the records in the manner provided and publish and disseminate the information in the manner
provided. Section 6 deals with requests for obtaining information. It provides that applicant making
a request for information shall not be required to give any reason for requesting the information or
any personal details except those that may be necessary for contacting him. Section 8 deals with
exemption from disclosure of information and is extracted in its entirety:
"8. Exemption from disclosure of information -- (1) Notwithstanding anything
contained in this Act, there shall be no obligation to give any citizen,-
(a) information, disclosure of which would prejudicially affect the sovereignty and
integrity of India, the security, strategic, scientific or economic interests of the State,
relation with foreign State or lead to incitement of an offence;
(b) information which has been expressly forbidden to be published by any court of
law or tribunal or the disclosure of which may constitute contempt of court;
(c) information, the disclosure of which would cause a breach of privilege of
Parliament or the State Legislature;
(d) information including commercial confidence, trade secrets or intellectual
property, the disclosure of which would harm the competitive position of a third
party, unless the competent authority is satisfied that larger public interest warrants
the disclosure of such information;
(e) information available to a person in his fiduciary relationship, unless the
competent authority is satisfied that the larger public interest warrants the disclosure
of such information;
(f) information received in confidence from foreign Government;Centrlal Board Of Sec.Education & Anr vs Aditya Bandopadhyay & Ors on 9 August, 2011

(g) information, the disclosure of which would endanger the life or physical safety of
any person or identify the source of information or assistance given in confidence for
law enforcement or security purposes;
(h) information which would impede the process of investigation or apprehension or
prosecution of offenders;
(i) cabinet papers including records of deliberations of the Council of Ministers,
Secretaries and other officers:
Provided that the decisions of Council of Ministers, the reasons thereof, and the
material on the basis of which the decisions were taken shall be made public after the
decision has been taken, and the matter is complete, or over:
Provided further that those matters which come under the exemptions specified in
this section shall not be disclosed;
(j) information which relates to personal information the disclosure of which has no
relationship to any public activity or interest, or which would cause unwarranted
invasion of the privacy of the individual unless the Central Public Information Officer
or the State Public Information Officer or the appellate authority, as the case may be,
is satisfied that the larger public interest justifies the disclosure of such information:
Provided that the information which cannot be denied to the Parliament or a State
Legislature shall not be denied to any person. (2) Notwithstanding anything in the
Official Secrets Act, 1923 (19 of 1923) nor any of the exemptions permissible in
accordance with sub-section (1), a public authority may allow access to information,
if public interest in disclosure outweighs the harm to the protected interests.
(3) Subject to the provisions of clauses (a), (c) and (i) of sub-section (1), any
information relating to any occurrence, event or matter which has taken place,
occurred or happened twenty years before the date on which any request is made
under secton 6 shall be provided to any person making a request under that section:
Provided that where any question arises as to the date from which the said period of
twenty years has to be computed, the decision of the Central Government shall be
final, subject to the usual appeals provided for in this Act."
(emphasis supplied) Section 9 provides that without prejudice to the provisions of
section 8, a request for information may be rejected if such a request for providing
access would involve an infringement of copyright. Section 10 deals with severability
of exempted information and sub-section (1) thereof is extracted below:Centrlal Board Of Sec.Education & Anr vs Aditya Bandopadhyay & Ors on 9 August, 2011

"(1) Where a request for access to information is rejected on the ground that it is in
relation to information which is exempt from disclosure, then, notwithstanding
anything contained in this Act, access may be provided to that part of the record
which does not contain any information which is exempt from disclosure under this
Act and which can reasonably be severed from any part that contains exempt
information."
Section 11 deals with third party information and sub-section (1) thereof is extracted below:
"(1) Where a Central Public Information Officer or a State Public Information Officer,
as the case may be, intends to disclose any information or record, or part thereof on a
request made under this Act, which relates to or has been supplied by a third party
and has been treated as confidential by that third party, the Central Public
Information Officer or State Public Information Officer, as the case may be, shall,
within five days from the receipt of the request, give a written notice to such third
party of the request and of the fact that the Central Public Information Officer or
State Public Information Officer, as the case may be, intends to disclose the
information or record, or part thereof, and invite the third party to make a
submission in writing or orally, regarding whether the information should be
disclosed, and such submission of the third party shall be kept in view while taking a
decision about disclosure of information:
Provided that except in the case of trade or commercial secrets protected by law,
disclosure may be allowed if the public interest in disclosure outweighs in importance
any possible harm or injury to the interests of such third party."
The definitions of information, public authority, record and right to information in clauses (f), (h),
(i) and (j) of section 2 of the RTI Act are extracted below:
"(f) "information" means any material in any form, including records, documents,
memos, e-mails, opinions, advices, press releases, circulars, orders, logbooks,
contracts, reports, papers, samples, models, data material held in any electronic form
and information relating to any private body which can be accessed by a public
authority under any other law for the time being in force;
(h) "public authority" means any authority or body or institution of self-
government established or constituted-
(a) by or under the Constitution;
(b) by any other law made by Parliament;
(c) by any other law made by State Legislature;Centrlal Board Of Sec.Education & Anr vs Aditya Bandopadhyay & Ors on 9 August, 2011

(d) by notification issued or order made by the appropriate Government, and includes any-
(i) body owned, controlled or substantially financed;
(ii) non-Government organisation substantially financed, directly or indirectly by funds provided by
the appropriate Government;
(i) "record" includes-
(a) any document, manuscript and file;
(b) any microfilm, microfiche and facsimile copy of a document;
(c) any reproduction of image or images embodied in such microfilm (whether enlarged or not); and
(d) any other material produced by a computer or any other device;
(j) "right to information" means the right to information accessible under this Act which is held by
or under the control of any public authority and includes the right to-
(i) inspection of work, documents, records;
(ii) taking notes, extracts or certified copies of documents or records;
(iii) taking certified samples of material;
(iv) obtaining information in the form of diskettes, floppies, tapes, video cassettes or in any other
electronic mode or through printouts where such information is stored in a computer or in any other
device;
Section 22 provides for the Act to have overriding effect and is extracted below:
"The provisions of this Act shall have effect notwithstanding anything inconsistent
therewith contained in the Official Secrets Act, 1923 (19 of 1923), and any other law
for the time being in force or in any instrument having effect by virtue of any law
other than this Act."
10. It will also be useful to refer to a few decisions of this Court which considered the importance
and scope of the right to information. In State of Uttar Pradesh v. Raj Narain - (1975) 4 SCC 428,
this Court observed:
"In a government of responsibility like ours, where all the agents of the public must
be responsible for their conduct, there can but few secrets. The people of this country
have a right to know every public act, everything, that is done in a public way, by theirCentrlal Board Of Sec.Education & Anr vs Aditya Bandopadhyay & Ors on 9 August, 2011

public functionaries. They are entitled to know the particulars of every public
transaction in all its bearing. The right to know, which is derived from the concept of
freedom of speech, though not absolute, is a factor which should make one wary,
when secrecy is claimed for transactions which can, at any rate, have no repercussion
on public security."
(emphasis supplied) In Dinesh Trivedi v. Union of India - (1997) 4 SCC 306, this Court held:
"In modern constitutional democracies, it is axiomatic that citizens have a right to
know about the affairs of the Government which, having been elected by them, seeks
to formulate sound policies of governance aimed at their welfare. However, like all
other rights, even this right has recognised limitations; it is, by no means, absolute.
..................Implicit in this assertion is the proposition that in transaction which have
serious repercussions on public security, secrecy can legitimately be claimed because
it would then be in the public interest that such matters are not publicly disclosed or
disseminated.
To ensure the continued participation of the people in the democratic process, they
must be kept informed of the vital decisions taken by the Government and the basis
thereof. Democracy, therefore, expects openness and openness is a concomitant of a
free society. Sunlight is the best disinfectant. But it is equally important to be alive to
the dangers that lie ahead. It is important to realise that undue popular pressure
brought to bear on decision-makers is Government can have frightening side-effects.
If every action taken by the political or executive functionary is transformed into a
public controversy and made subject to an enquiry to soothe popular sentiments, it
will undoubtedly have a chilling effect on the independence of the decision-maker
who may find it safer not to take any decision. It will paralyse the entire system and
bring it to a grinding halt. So we have two conflicting situations almost enigmatic and
we think the answer is to maintain a fine balance which would serve public interest."
In People's Union for Civil Liberties v. Union of India - (2004) 2 SCC 476, this Court held that right
of information is a facet of the freedom of "speech and expression" as contained in Article 19(1)(a) of
the Constitution of India and such a right is subject to any reasonable restriction in the interest of
the security of the state and subject to exemptions and exceptions. Re : Question (i)
11. The definition of `information' in section 2(f) of the RTI Act refers to any material in any form
which includes records, documents, opinions, papers among several other enumerated items. The
term `record' is defined in section 2(i) of the said Act as including any document, manuscript or file
among others. When a candidate participates in an examination and writes his answers in an
answer-book and submits it to the examining body for evaluation and declaration of the result, the
answer-book is a document or record. When the answer-book is evaluated by an examiner
appointed by the examining body, the evaluated answer-book becomes a record containing the
`opinion' of the examiner. Therefore the evaluated answer-book is also an `information' under the
RTI Act.Centrlal Board Of Sec.Education & Anr vs Aditya Bandopadhyay & Ors on 9 August, 2011

12. Section 3 of RTI Act provides that subject to the provisions of this Act all citizens shall have the
right to information. The term `right to information' is defined in section 2(j) as the right to
information accessible under the Act which is held by or under the control of any public authority.
Having regard to section 3, the citizens have the right to access to all information held by or under
the control of any public authority except those excluded or exempted under the Act. The object of
the Act is to empower the citizens to fight against corruption and hold the Government and their
instrumentalities accountable to the citizens, by providing them access to information regarding
functioning of every public authority. Certain safeguards have been built into the Act so that the
revelation of information will not conflict with other public interests which include efficient
operation of the governments, optimum use of limited fiscal resources and preservation of
confidential and sensitive information. The RTI Act provides access to information held by or under
the control of public authorities and not in regard to information held by any private person. The
Act provides the following exclusions by way of exemptions and exceptions (under sections 8, 9 and
24) in regard to information held by public authorities:
(i) Exclusion of the Act in entirety under section 24 to intelligence and security
organizations specified in the Second Schedule even though they may be "public
authorities", (except in regard to information with reference to allegations of
corruption and human rights violations).
(ii) Exemption of the several categories of information enumerated in section 8(1) of
the Act which no public authority is under an obligation to give to any citizen,
notwithstanding anything contained in the Act [however, in regard to the information
exempted under clauses (d) and (e), the competent authority, and in regard to the
information excluded under clause (j), Central Public Information Officer/State
Public Information Officer/the Appellate Authority, may direct disclosure of
information, if larger public interest warrants or justifies the disclosure].
(iii) If any request for providing access to information involves an infringement of a
copyright subsisting in a person other than the State, the Central/State Public
Information Officer may reject the request under section 9 of RTI Act.
Having regard to the scheme of the RTI Act, the right of the citizens to access any information held
or under the control of any public authority, should be read in harmony with the
exclusions/exemptions in the Act.
13. The examining bodies (Universities, Examination Boards, CBSC etc.) are neither security nor
intelligence organisations and therefore the exemption under section 24 will not apply to them. The
disclosure of information with reference to answer-books does not also involve infringement of any
copyright and therefore section 9 will not apply. Resultantly, unless the examining bodies are able to
demonstrate that the evaluated answer-books fall under any of the categories of exempted
`information' enumerated in clauses (a) to (j) of sub-section (1) section 8, they will be bound to
provide access to the information and any applicant can either inspect the document/record, take
notes, extracts or obtain certified copies thereof.Centrlal Board Of Sec.Education & Anr vs Aditya Bandopadhyay & Ors on 9 August, 2011

14. The examining bodies contend that the evaluated answer-books are exempted from disclosure
under section 8(1)(e) of the RTI Act, as they are `information' held in its fiduciary relationship. They
fairly conceded that evaluated answer-books will not fall under any other exemptions in sub- section
(1) of section 8. Every examinee will have the right to access his evaluated answer-books, by either
inspecting them or take certified copies thereof, unless the evaluated answer-books are found to be
exempted under section 8(1)(e) of the RTI Act.
Re : Question (ii)
15. In Maharashtra State Board, this Court was considering whether denial of re-evaluation of
answer-books or denial of disclosure by way of inspection of answer books, to an examinee, under
Rule 104(1) and (3) of the Maharashtra Secondary and Higher Secondary Board Rules, 1977 was
violative of principles of natural justice and violative of Articles 14 and 19 of the Constitution of
India. Rule 104(1) provided that no re-evaluation of the answer books shall be done and on an
application of any candidate verification will be restricted to checking whether all the answers have
been examined and that there is no mistake in the totalling of marks for each question in that
subject and transferring marks correctly on the first cover page of the answer book. Rule 104(3)
provided that no candidate shall claim or be entitled to re-evaluation of his answer-books or
inspection of answer- books as they were treated as confidential. This Court while upholding the
validity of Rule 104(3) held as under :
".... the "process of evaluation of answer papers or of subsequent verification of
marks" under Clause (3) of Regulation 104 does not attract the principles of natural
justice since no decision making process which brings about adverse civil
consequences to the examinees in involved. The principles of natural justice cannot
be extended beyond reasonable and rational limits and cannot be carried to such
absurd lengths as to make it necessary that candidates who have taken a public
examination should be allowed to participate in the process of evaluation of their
performances or to verify the correctness of the evaluation made by the examiners by
themselves conducting an inspection of the answer-books and determining whether
there has been a proper and fair valuation of the answers by the examiners."
So long as the body entrusted with the task of framing the rules or regulations acts within the scope
of the authority conferred on it, in the sense that the rules or regulations made by it have a rational
nexus with the object and purpose of the statute, the court should not concern itself with the wisdom
or efficaciousness of such rules or regulations.... The Legislature and its delegate are the sole
repositories of the power to decide what policy should be pursued in relation to matters covered by
the Act ... and there is no scope for interference by the Court unless the particular provision
impugned before it can be said to suffer from any legal infirmity, in the sense of its being wholly
beyond the scope of the regulation making power or its being inconsistent with any of the provisions
of the parent enactment or in violation of any of the limitations imposed by the Constitution.
It was perfectly within the competence of the Board, rather it was its plain duty, to apply its mind
and decide as a matter of policy relating to the conduct of the examination as to whether disclosureCentrlal Board Of Sec.Education & Anr vs Aditya Bandopadhyay & Ors on 9 August, 2011

and inspection of the answer books should be allowed to the candidates, whether and to what extent
verification of the result should be permitted after the results have already been announced and
whether any right to claim revaluation of the answer books should be recognised or provided for. All
these are undoubtedly matters which have an intimate nexus with the objects and purposes of the
enactment and are, therefore, with in the ambit of the general power to make regulations...."
This Court held that Regulation 104(3) cannot be held to be unreasonable merely because in certain
stray instances, errors or irregularities had gone unnoticed even after verification of the concerned
answer books according to the existing procedure and it was only after further scrutiny made either
on orders of the court or in the wake of contentions raised in the petitions filed before a court, that
such errors or irregularities were ultimately discovered. This court reiterated the view that "the test
of reasonableness is not applied in vacuum but in the context of life's realities" and concluded that
realistically and practically, providing all the candidates inspection of their answer books or
re-evaluation of the answer books in the presence of the candidates would not be feasible. Dealing
with the contention that every student is entitled to fair play in examination and receive marks
matching his performance, this court held :
"What constitutes fair play depends upon the facts and circumstances relating to each
particular given situation. If it is found that every possible precaution has been taken
and all necessary safeguards provided to ensure that the answer books inclusive of
supplements are kept in safe custody so as to eliminate the danger of their being
tampered with and that the evaluation is done by the examiners applying uniform
standards with checks and crosschecks at different stages and that measures for
detection of malpractice, etc. have also been effectively adopted, in such cases it will
not be correct on the part of the Courts to strike down, the provision prohibiting
revaluation on the ground that it violates the rules of fair play. It appears that the
procedure evolved by the Board for ensuring fairness and accuracy in evaluation of
the answer books has made the system as fool proof as can be possible and is entirely
satisfactory. The Board is a very responsible body. The candidates have taken the
examination with full awareness of the provisions contained in the Regulations and
in the declaration made in the form of application for admission to the examination
they have solemnly stated that they fully agree to abide by the regulations issued by
the Board. In the circumstances, when we find that all safeguards against errors and
malpractices have been provided for, there cannot be said to be any denial of fair play
to the examinees by reason of the prohibition against asking for revaluation.... "
This Court concluded that if inspection and verification in the presence of the candidates, or
revaluation, have to be allowed as of right, it may lead to gross and indefinite uncertainty,
particularly in regard to the relative ranking etc. of the candidate, besides leading to utter confusion
on account of the enormity of the labour and time involved in the process. This court concluded :
"... the Court should be extremely reluctant to substitute its own views as to what is
wise, prudent and proper in relation to academic matters in preference to those
formulated by professional men possessing technical expertise and rich experience ofCentrlal Board Of Sec.Education & Anr vs Aditya Bandopadhyay & Ors on 9 August, 2011

actual day-to-day working of educational institutions and the departments
controlling them. It will be wholly wrong for the court to make a pedantic and purely
idealistic approach to the problems of this nature, isolated from the actual realities
and grass root problems involved in the working of the system and unmindful of the
consequences which would emanate if a purely idealistic view as opposed to a
pragmatic one were to be propounded."
16. The above principles laid down in Maharashtra State Board have been followed and reiterated in
several decisions of this Court, some of which are referred to in para (6) above. But the principles
laid down in decisions such as Maharashtra State Board depend upon the provisions of the rules and
regulations of the examining body. If the rules and regulations of the examining body provide for
re-evaluation, inspection or disclosure of the answer-books, then none of the principles in
Maharashtra State Board or other decisions following it, will apply or be relevant. There has been a
gradual change in trend with several examining bodies permitting inspection and disclosure of the
answer-books.
17. It is thus now well settled that a provision barring inspection or disclosure of the answer-books
or re-evaluation of the answer-books and restricting the remedy of the candidates only to
re-totalling is valid and binding on the examinee. In the case of CBSE, the provisions barring re-
evaluation and inspection contained in Bye-law No.61, are akin to Rule 104 considered in
Maharashtra State Board. As a consequence if an examination is governed only by the rules and
regulations of the examining body which bar inspection, disclosure or re-evaluation, the examinee
will be entitled only for re-totalling by checking whether all the answers have been evaluated and
further checking whether there is no mistake in totaling of marks for each question and marks have
been transferred correctly to the title (abstract) page. The position may however be different, if there
is a superior statutory right entitling the examinee, as a citizen to seek access to the answer books, as
information.
18. In these cases, the High Court has rightly denied the prayer for re- evaluation of answer-books
sought by the candidates in view of the bar contained in the rules and regulations of the examining
bodies. It is also not a relief available under the RTI Act. Therefore the question whether re-
evaluation should be permitted or not, does not arise for our consideration. What arises for
consideration is the question whether the examinee is entitled to inspect his evaluated answer-books
or take certified copies thereof. This right is claimed by the students, not with reference to the rules
or bye-laws of examining bodies, but under the RTI Act which enables them and entitles them to
have access to the answer-books as `information' and inspect them and take certified copies thereof.
Section 22 of RTI Act provides that the provisions of the said Act will have effect, notwithstanding
anything inconsistent therewith contained in any other law for the time being in force. Therefore the
provisions of the RTI Act will prevail over the provisions of the bye-laws/rules of the examining
bodies in regard to examinations. As a result, unless the examining body is able to demonstrate that
the answer-books fall under the exempted category of information described in clause (e) of section
8(1) of RTI Act, the examining body will be bound to provide access to an examinee to inspect and
take copies of his evaluated answer-books, even if such inspection or taking copies is barred under
the rules/bye-laws of the examining body governing the examinations. Therefore, the decision ofCentrlal Board Of Sec.Education & Anr vs Aditya Bandopadhyay & Ors on 9 August, 2011

this Court in Maharashtra State Board (supra) and the subsequent decisions following the same, will
not affect or interfere with the right of the examinee seeking inspection of answer-books or taking
certified copies thereof.
Re : Question (iii)
19. Section 8(1) enumerates the categories of information which are exempted from disclosure
under the provisions of the RTI Act. The examining bodies rely upon clause (e) of section 8(1) which
provides that there shall be no obligation on any public authority to give any citizen, information
available to it in its fiduciary relationship. This exemption is subject to the condition that if the
competent authority (as defined in section 2(e) of RTI Act) is satisfied that the larger public interest
warrants the disclosure of such information, the information will have to be disclosed. Therefore the
question is whether the examining body holds the evaluated answer-books in its fiduciary
relationship.
20. The term `fiduciary' and `fiduciary relationship' refer to different capacities and relationship,
involving a common duty or obligation. 20.1) Black's Law Dictionary (7th Edition, Page 640) defines
`fiduciary relationship' thus:
"A relationship in which one person is under a duty to act for the benefit of the other
on matters within the scope of the relationship. Fiduciary relationships - such as
trustee-beneficiary, guardian-ward, agent-principal, and attorney-client - require the
highest duty of care. Fiduciary relationships usually arise in one of four situations :
(1) when one person places trust in the faithful integrity of another, who as a result
gains superiority or influence over the first, (2) when one person assumes control and
responsibility over another, (3) when one person has a duty to act for or give advice
to another on matters falling within the scope of the relationship, or (4) when there is
a specific relationship that has traditionally been recognized as involving fiduciary
duties, as with a lawyer and a client or a stockbroker and a customer."
20.2) The American Restatements (Trusts and Agency) define `fiduciary' as one whose intention is
to act for the benefit of another as to matters relevant to the relation between them. The Corpus
Juris Secundum (Vol. 36A page
381) attempts to define fiduciary thus :
"A general definition of the word which is sufficiently comprehensive to embrace all
cases cannot well be given. The term is derived from the civil, or Roman, law. It
connotes the idea of trust or confidence, contemplates good faith, rather than legal
obligation, as the basis of the transaction, refers to the integrity, the fidelity, of the
party trusted, rather than his credit or ability, and has been held to apply to all
persons who occupy a position of peculiar confidence toward others, and to include
those informal relations which exist whenever one party trusts and relies on another,
as well as technical fiduciary relations. The word `fiduciary,' as a noun, means oneCentrlal Board Of Sec.Education & Anr vs Aditya Bandopadhyay & Ors on 9 August, 2011

who holds a thing in trust for another, a trustee, a person holding the character of a
trustee, or a character analogous to that of a trustee, with respect to the trust and
confidence involved in it and the scrupulous good faith and candor which it requires;
a person having the duty, created by his undertaking, to act primarily for another's
benefit in matters connected with such undertaking. Also more specifically, in a
statute, a guardian, trustee, executor, administrator, receiver, conservator, or any
person acting in any fiduciary capacity for any person, trust, or estate. Some
examples of what, in particular connections, the term has been held to include and
not to include are set out in the note."
20.3) Words and Phrases, Permanent Edition (Vol. 16A, Page 41) defines `fiducial relation' thus :
"There is a technical distinction between a `fiducial relation' which is more correctly
applicable to legal relationships between parties, such as guardian and ward,
administrator and heirs, and other similar relationships, and `confidential relation'
which includes the legal relationships, and also every other relationship wherein
confidence is rightly reposed and is exercised.
Generally, the term `fiduciary' applies to any person who occupies a position of
peculiar confidence towards another. It refers to integrity and fidelity. It
contemplates fair dealing and good faith, rather than legal obligation, as the basis of
the transaction. The term includes those informal relations which exist whenever one
party trusts and relies upon another, as well as technical fiduciary relations."
20.4) In Bristol and West Building Society vs. Mothew [1998 Ch. 1] the term fiduciary was defined
thus :
"A fiduciary is someone who has undertaken to act for and on behalf of another in a
particular matter in circumstances which give rise to a relationship of trust and
confidence. The distinguishing obligation of a fiduciary is the obligation of loyalty.....
A fiduciary must act in good faith; he must not make a profit out of his trust; he must
not place himself in a position where his duty and his interest may conflict; he may
not act for his own benefit or the benefit of a third person without the informed
consent of his principal."
20.5) In Wolf vs. Superior Court [2003 (107) California Appeals, 4th 25] the California Court of
Appeals defined fiduciary relationship as under :
"any relationship existing between the parties to the transaction where one of the
parties is duty bound to act with utmost good faith for the benefit of the other party.
Such a relationship ordinarily arises where confidence is reposed by one person in
the integrity of another, and in such a relation the party in whom the confidence is
reposed, if he voluntarily accepts or assumes to accept the confidence, can take no
advantage from his acts relating to the interests of the other party without the latter'sCentrlal Board Of Sec.Education & Anr vs Aditya Bandopadhyay & Ors on 9 August, 2011

knowledge and consent."
21. The term `fiduciary' refers to a person having a duty to act for the benefit of another, showing
good faith and condour, where such other person reposes trust and special confidence in the person
owing or discharging the duty. The term `fiduciary relationship' is used to describe a situation or
transaction where one person (beneficiary) places complete confidence in another person (fiduciary)
in regard to his affairs, business or transaction/s. The term also refers to a person who holds a thing
in trust for another (beneficiary). The fiduciary is expected to act in confidence and for the benefit
and advantage of the beneficiary, and use good faith and fairness in dealing with the beneficiary or
the things belonging to the beneficiary. If the beneficiary has entrusted anything to the fiduciary, to
hold the thing in trust or to execute certain acts in regard to or with reference to the entrusted thing,
the fiduciary has to act in confidence and expected not to disclose the thing or information to any
third party. There are also certain relationships where both the parties have to act in a fiduciary
capacity treating the other as the beneficiary. Examples of these are : a partner vis-`-vis another
partner and an employer vis-`-vis employee. An employee who comes into possession of business or
trade secrets or confidential information relating to the employer in the course of his employment,
is expected to act as a fiduciary and cannot disclose it to others. Similarly, if on the request of the
employer or official superior or the head of a department, an employee furnishes his personal details
and information, to be retained in confidence, the employer, the official superior or departmental
head is expected to hold such personal information in confidence as a fiduciary, to be made use of or
disclosed only if the employee's conduct or acts are found to be prejudicial to the employer.
22. In a philosophical and very wide sense, examining bodies can be said to act in a fiduciary
capacity, with reference to students who participate in an examination, as a government does while
governing its citizens or as the present generation does with reference to the future generation while
preserving the environment. But the words `information available to a person in his fiduciary
relationship' are used in section 8(1)(e) of RTI Act in its normal and well recognized sense, that is to
refer to persons who act in a fiduciary capacity, with reference to a specific beneficiary or
beneficiaries who are to be expected to be protected or benefited by the actions of the fiduciary - a
trustee with reference to the beneficiary of the trust, a guardian with reference to a
minor/physically/infirm/mentally challenged, a parent with reference to a child, a lawyer or a
chartered accountant with reference to a client, a doctor or nurse with reference to a patient, an
agent with reference to a principal, a partner with reference to another partner, a director of a
company with reference to a share-holder, an executor with reference to a legatee, a receiver with
reference to the parties to a lis, an employer with reference to the confidential information relating
to the employee, and an employee with reference to business dealings/transaction of the employer.
We do not find that kind of fiduciary relationship between the examining body and the examinee,
with reference to the evaluated answer-books, that come into the custody of the examining body.
23. The duty of examining bodies is to subject the candidates who have completed a course of study
or a period of training in accordance with its curricula, to a process of
verification/examination/testing of their knowledge, ability or skill, or to ascertain whether they can
be said to have successfully completed or passed the course of study or training. Other specialized
Examining Bodies may simply subject candidates to a process of verification by an examination, toCentrlal Board Of Sec.Education & Anr vs Aditya Bandopadhyay & Ors on 9 August, 2011

find out whether such person is suitable for a particular post, job or assignment. An examining
body, if it is a public authority entrusted with public functions, is required to act fairly, reasonably,
uniformly and consistently for public good and in public interest. This Court has explained the role
of an examining body in regard to the process of holding examination in the context of examining
whether it amounts to `service' to a consumer, in Bihar School Examination Board vs. Suresh
Prasad Sinha - (2009) 8 SCC 483, in the following manner:
"The process of holding examinations, evaluating answer scripts, declaring results
and issuing certificates are different stages of a single statutory non-commercial
function. It is not possible to divide this function as partly statutory and partly
administrative. When the Examination Board conducts an examination in discharge
of its statutory function, it does not offer its "services" to any candidate. Nor does a
student who participates in the examination conducted by the Board, hires or avails
of any service from the Board for a consideration. On the other hand, a candidate
who participates in the examination conducted by the Board, is a person who has
undergone a course of study and who requests the Board to test him as to whether he
has imbibed sufficient knowledge to be fit to be declared as having successfully
completed the said course of education; and if so, determine his position or rank or
competence vis-a- vis other examinees. The process is not therefore availment of a
service by a student, but participation in a general examination conducted by the
Board to ascertain whether he is eligible and fit to be considered as having
successfully completed the secondary education course. The examination fee paid by
the student is not the consideration for availment of any service, but the charge paid
for the privilege of participation in the examination.......... The fact that in the course
of conduct of the examination, or evaluation of answer-scripts, or furnishing of
mark-books or certificates, there may be some negligence, omission or deficiency,
does not convert the Board into a service-provider for a consideration, nor convert
the examinee into a consumer ........."
It cannot therefore be said that the examining body is in a fiduciary relationship either with
reference to the examinee who participates in the examination and whose answer-books are
evaluated by the examining body.
24. We may next consider whether an examining body would be entitled to claim exemption under
section 8(1)(e) of the RTI Act, even assuming that it is in a fiduciary relationship with the examinee.
That section provides that notwithstanding anything contained in the Act, there shall be no
obligation to give any citizen information available to a person in his fiduciary relationship. This
would only mean that even if the relationship is fiduciary, the exemption would operate in regard to
giving access to the information held in fiduciary relationship, to third parties. There is no question
of the fiduciary withholding information relating to the beneficiary, from the beneficiary himself.
One of the duties of the fiduciary is to make thorough disclosure of all relevant facts of all
transactions between them to the beneficiary, in a fiduciary relationship. By that logic, the
examining body, if it is in a fiduciary relationship with an examinee, will be liable to make a full
disclosure of the evaluated answer-books to the examinee and at the same time, owe a duty to theCentrlal Board Of Sec.Education & Anr vs Aditya Bandopadhyay & Ors on 9 August, 2011

examinee not to disclose the answer-books to anyone else. If A entrusts a document or an article to
B to be processed, on completion of processing, B is not expected to give the document or article to
anyone else but is bound to give the same to A who entrusted the document or article to B for
processing. Therefore, if a relationship of fiduciary and beneficiary is assumed between the
examining body and the examinee with reference to the answer-book, section 8(1)(e) would operate
as an exemption to prevent access to any third party and will not operate as a bar for the very person
who wrote the answer-book, seeking inspection or disclosure of it.
25. An evaluated answer book of an examinee is a combination of two different `informations'. The
first is the answers written by the examinee and second is the marks/assessment by the examiner.
When an examinee seeks inspection of his evaluated answer-books or seeks a certified copy of the
evaluated answer-book, the information sought by him is not really the answers he has written in
the answer-books (which he already knows), nor the total marks assigned for the answers (which
has been declared). What he really seeks is the information relating to the break-up of marks, that
is, the specific marks assigned to each of his answers. When an examinee seeks `information' by
inspection/certified copies of his answer-books, he knows the contents thereof being the author
thereof. When an examinee is permitted to examine an answer-book or obtain a certified copy, the
examining body is not really giving him some information which is held by it in trust or confidence,
but is only giving him an opportunity to read what he had written at the time of examination or to
have a copy of his answers. Therefore, in furnishing the copy of an answer-book, there is no question
of breach of confidentiality, privacy, secrecy or trust. The real issue therefore is not in regard to the
answer-book but in regard to the marks awarded on evaluation of the answer-book. Even here the
total marks given to the examinee in regard to his answer-book are already declared and known to
the examinee. What the examinee actually wants to know is the break-up of marks given to him, that
is how many marks were given by the examiner to each of his answers so that he can assess how is
performance has been evaluated and whether the evaluation is proper as per his hopes and
expectations. Therefore, the test for finding out whether the information is exempted or not, is not
in regard to the answer book but in regard to the evaluation by the examiner.
26. This takes us to the crucial issue of evaluation by the examiner. The examining body engages or
employs hundreds of examiners to do the evaluation of thousands of answer books. The question is
whether the information relating to the `evaluation' (that is assigning of marks) is held by the
examining body in a fiduciary relationship. The examining bodies contend that even if fiduciary
relationship does not exist with reference to the examinee, it exists with reference to the examiner
who evaluates the answer-books. On a careful examination we find that this contention has no
merit. The examining body entrusts the answer-books to an examiner for evaluation and pays the
examiner for his expert service. The work of evaluation and marking the answer-book is an
assignment given by the examining body to the examiner which he discharges for a consideration.
Sometimes, an examiner may assess answer-books, in the course of his employment, as a part of his
duties without any specific or special remuneration. In other words the examining body is the
`principal' and the examiner is the agent entrusted with the work, that is, evaluation of answer-
books. Therefore, the examining body is not in the position of a fiduciary with reference to the
examiner. On the other hand, when an answer-book is entrusted to the examiner for the purpose of
evaluation, for the period the answer-book is in his custody and to the extent of the discharge of hisCentrlal Board Of Sec.Education & Anr vs Aditya Bandopadhyay & Ors on 9 August, 2011

functions relating to evaluation, the examiner is in the position of a fiduciary with reference to the
examining body and he is barred from disclosing the contents of the answer-book or the result of
evaluation of the answer-book to anyone other than the examining body. Once the examiner has
evaluated the answer books, he ceases to have any interest in the evaluation done by him. He does
not have any copy-right or proprietary right, or confidentiality right in regard to the evaluation.
Therefore it cannot be said that the examining body holds the evaluated answer books in a fiduciary
relationship, qua the examiner.
27. We, therefore, hold that an examining body does not hold the evaluated answer-books in a
fiduciary relationship. Not being information available to an examining body in its fiduciary
relationship, the exemption under section 8(1)(e) is not available to the examining bodies with
reference to evaluated answer-books. As no other exemption under section 8 is available in respect
of evaluated answer books, the examining bodies will have to permit inspection sought by the
examinees.
Re : Question (iv)
28. When an examining body engages the services of an examiner to evaluate the answer-books, the
examining body expects the examiner not to disclose the information regarding evaluation to
anyone other than the examining body. Similarly the examiner also expects that his name and
particulars would not be disclosed to the candidates whose answer-books are evaluated by him. In
the event of such information being made known, a disgruntled examinee who is not satisfied with
the evaluation of the answer books, may act to the prejudice of the examiner by attempting to
endanger his physical safety. Further, any apprehension on the part of the examiner that there may
be danger to his physical safety, if his identity becomes known to the examinees, may come in the
way of effective discharge of his duties. The above applies not only to the examiner, but also to the
scrutiniser, co-ordinator, and head-examiner who deal with the answer book. The answer book
usually contains not only the signature and code number of the examiner, but also the signatures
and code number of the scrutiniser/co- ordinator/head examiner. The information as to the names
or particulars of the examiners/co-ordinators/scrutinisers/head examiners are therefore exempted
from disclosure under section 8(1)(g) of RTI Act, on the ground that if such information is disclosed,
it may endanger their physical safety. Therefore, if the examinees are to be given access to evaluated
answer- books either by permitting inspection or by granting certified copies, such access will have
to be given only to that part of the answer-book which does not contain any information or signature
of the examiners/co- ordinators/scrutinisers/head examiners, exempted from disclosure under
section 8(1)(g) of RTI Act. Those portions of the answer-books which contain information regarding
the examiners/co-ordinators/scrutinisers/head examiners or which may disclose their identity with
reference to signature or initials, shall have to be removed, covered, or otherwise severed from the
non-exempted part of the answer-books, under section 10 of RTI Act.
29. The right to access information does not extend beyond the period during which the examining
body is expected to retain the answer-books. In the case of CBSE, the answer-books are required to
be maintained for a period of three months and thereafter they are liable to be disposed
of/destroyed. Some other examining bodies are required to keep the answer- books for a period ofCentrlal Board Of Sec.Education & Anr vs Aditya Bandopadhyay & Ors on 9 August, 2011

six months. The fact that right to information is available in regard to answer-books does not mean
that answer-books will have to be maintained for any longer period than required under the rules
and regulations of the public authority. The obligation under the RTI Act is to make available or give
access to existing information or information which is expected to be preserved or maintained. If the
rules and regulations governing the functioning of the respective public authority require
preservation of the information for only a limited period, the applicant for information will be
entitled to such information only if he seeks the information when it is available with the public
authority. For example, with reference to answer-books, if an examinee makes an application to
CBSE for inspection or grant of certified copies beyond three months (or six months or such other
period prescribed for preservation of the records in regard to other examining bodies) from the date
of declaration of results, the application could be rejected on the ground that such information is not
available. The power of the Information Commission under section 19(8) of the RTI Act to require a
public authority to take any such steps as may be necessary to secure compliance with the provision
of the Act, does not include a power to direct the public authority to preserve the information, for
any period larger than what is provided under the rules and regulations of the public authority.
30. On behalf of the respondents/examinees, it was contended that having regard to sub-section (3)
of section 8 of RTI Act, there is an implied duty on the part of every public authority to maintain the
information for a minimum period of twenty years and make it available whenever an application
was made in that behalf. This contention is based on a complete misreading and misunderstanding
of section 8(3). The said sub-section nowhere provides that records or information have to be
maintained for a period of twenty years. The period for which any particular records or information
has to be maintained would depend upon the relevant statutory rule or regulation of the public
authority relating to the preservation of records. Section 8(3) provides that information relating to
any occurrence, event or matters which has taken place and occurred or happened twenty years
before the date on which any request is made under section 6, shall be provided to any person
making a request. This means that where any information required to be maintained and preserved
for a period beyond twenty years under the rules of the public authority, is exempted from
disclosure under any of the provisions of section 8(1) of RTI Act, then, notwithstanding such
exemption, access to such information shall have to be provided by disclosure thereof, after a period
of twenty years except where they relate to information falling under clauses (a), (c) and (i) of
section 8(1). In other words, section 8(3) provides that any protection against disclosure that may be
available, under clauses (b), (d) to (h) and (j) of section 8(1) will cease to be available after twenty
years in regard to records which are required to be preserved for more than twenty years. Where any
record or information is required to be destroyed under the rules and regulations of a public
authority prior to twenty years, section 8(3) will not prevent destruction in accordance with the
Rules. Section 8(3) of RTI Act is not therefore a provision requiring all `information' to be preserved
and maintained for twenty years or more, nor does it override any rules or regulations governing the
period for which the record, document or information is required to be preserved by any public
authority.
31. The effect of the provisions and scheme of the RTI Act is to divide `information' into the three
categories. They are :Centrlal Board Of Sec.Education & Anr vs Aditya Bandopadhyay & Ors on 9 August, 2011

(i) Information which promotes transparency and accountability in the working of
every public authority, disclosure of which may also help in containing or
discouraging corruption (enumerated in clauses (b) and (c) of section 4(1) of RTI
Act).
(ii) Other information held by public authority (that is all information other than
those falling under clauses (b) and (c) of section 4(1) of RTI Act).
(iii) Information which is not held by or under the control of any public authority and
which cannot be accessed by a public authority under any law for the time being in
force.
Information under the third category does not fall within the scope of RTI Act. Section 3 of RTI Act
gives every citizen, the right to `information' held by or under the control of a public authority,
which falls either under the first or second category. In regard to the information falling under the
first category, there is also a special responsibility upon public authorities to suo moto publish and
disseminate such information so that they will be easily and readily accessible to the public without
any need to access them by having recourse to section 6 of RTI Act. There is no such obligation to
publish and disseminate the other information which falls under the second category.
32. The information falling under the first category, enumerated in sections 4(1)(b) & (c) of RTI Act
are extracted below :
"4. Obligations of public authorities.-(1) Every public authority shall--
                (a)                                              xxxxxx
                (b)                                              publish   within   one 
hundred and twenty days from the enactment of this Act,--
(i) the particulars of its organisation, functions and duties;
(ii) the powers and duties of its officers and employees;
(iii) the procedure followed in the decision making process, including channels of
supervision and accountability;
(iv) the norms set by it for the discharge of its functions;
(v) the rules, regulations, instructions, manuals and records, held by it or under its
control or used by its employees for discharging its functions;Centrlal Board Of Sec.Education & Anr vs Aditya Bandopadhyay & Ors on 9 August, 2011

(vi) a statement of the categories of documents that are held by it or under its control;
(vii) the particulars of any arrangement that exists for consultation with, or
representation by, the members of the public in relation to the formulation of its
policy or implementation thereof;
(viii) a statement of the boards, councils, committees and other bodies consisting of
two or more persons constituted as its part or for the purpose of its advice, and as to
whether meetings of those boards, councils, committees and other bodies are open to
the public, or the minutes of such meetings are accessible for public;
(ix) a directory of its officers and employees;
(x) the monthly remuneration received by each of its officers and employees,
including the system of compensation as provided in its regulations;
(xi) the budget allocated to each of its agency, indicating the particulars of all plans,
proposed expenditures and reports on disbursements made;
(xii) the manner of execution of subsidy programmes, including the amounts
allocated and the details of beneficiaries of such programmes;
(xiii) particulars of recipients of concessions, permits or authorisations granted by it;
(xiv) details in respect of the information, available to or held by it, reduced in an
electronic form;
(xv) the particulars of facilities available to citizens for obtaining information,
including the working hours of a library or reading room, if maintained for public
use; (xvi) the names, designations and other particulars of the Public Information
Officers;
(xvii) such other information as may be prescribed; and thereafter update these
publications every year;
(c) publish all relevant facts while formulating important policies or announcing the
decisions which affect public;
(emphasis supplied) Sub-sections (2), (3) and (4) of section 4 relating to dissemination of
information enumerated in sections 4(1)(b) & (c) are extracted below:
"(2) It shall be a constant endeavour of every public authority to take steps in
accordance with the requirements of clause (b) of sub-section (1) to provide as much
information suo motu to the public at regular intervals through various means ofCentrlal Board Of Sec.Education & Anr vs Aditya Bandopadhyay & Ors on 9 August, 2011

communications, including internet, so that the public have minimum resort to the
use of this Act to obtain information.
(3) For the purposes of sub-section (1), every information shall be disseminated
widely and in such form and manner which is easily accessible to the public.
(4) All materials shall be disseminated taking into consideration the cost
effectiveness, local language and the most effective method of communication in that
local area and the information should be easily accessible, to the extent possible in
electronic format with the Central Public Information Officer or State Public
Information Officer, as the case may be, available free or at such cost of the medium
or the print cost price as may be prescribed.
Explanation.--For the purposes of sub-sections (3) and (4), "disseminated" means making known or
communicated the information to the public through notice boards, newspapers, public
announcements, media broadcasts, the internet or any other means, including inspection of offices
of any public authority."
(emphasis supplied)
33. Some High Courts have held that section 8 of RTI Act is in the nature of an exception to section
3 which empowers the citizens with the right to information, which is a derivative from the freedom
of speech; and that therefore section 8 should be construed strictly, literally and narrowly. This may
not be the correct approach. The Act seeks to bring about a balance between two conflicting
interests, as harmony between them is essential for preserving democracy. One is to bring about
transparency and accountability by providing access to information under the control of public
authorities. The other is to ensure that the revelation of information, in actual practice, does not
conflict with other public interests which include efficient operation of the governments, optimum
use of limited fiscal resources and preservation of confidentiality of sensitive information. The
preamble to the Act specifically states that the object of the Act is to harmonise these two conflicting
interests. While sections 3 and 4 seek to achieve the first objective, sections 8, 9, 10 and 11 seek to
achieve the second objective. Therefore when section 8 exempts certain information from being
disclosed, it should not be considered to be a fetter on the right to information, but as an equally
important provision protecting other public interests essential for the fulfilment and preservation of
democratic ideals.
34. When trying to ensure that the right to information does not conflict with several other public
interests (which includes efficient operations of the governments, preservation of confidentiality of
sensitive information, optimum use of limited fiscal resources, etc.), it is difficult to visualise and
enumerate all types of information which require to be exempted from disclosure in public interest.
The legislature has however made an attempt to do so. The enumeration of exemptions is more
exhaustive than the enumeration of exemptions attempted in the earlier Act that is section 8 of
Freedom to Information Act, 2002. The Courts and Information Commissions enforcing the
provisions of RTI Act have to adopt a purposive construction, involving a reasonable and balancedCentrlal Board Of Sec.Education & Anr vs Aditya Bandopadhyay & Ors on 9 August, 2011

approach which harmonises the two objects of the Act, while interpreting section 8 and the other
provisions of the Act.
35. At this juncture, it is necessary to clear some misconceptions about the RTI Act. The RTI Act
provides access to all information that is available and existing. This is clear from a combined
reading of section 3 and the definitions of `information' and `right to information' under clauses
(f) and (j) of section 2 of the Act. If a public authority has any information in the form of data or
analysed data, or abstracts, or statistics, an applicant may access such information, subject to the
exemptions in section 8 of the Act. But where the information sought is not a part of the record of a
public authority, and where such information is not required to be maintained under any law or the
rules or regulations of the public authority, the Act does not cast an obligation upon the public
authority, to collect or collate such non- available information and then furnish it to an applicant. A
public authority is also not required to furnish information which require drawing of inferences
and/or making of assumptions. It is also not required to provide `advice' or `opinion' to an
applicant, nor required to obtain and furnish any `opinion' or `advice' to an applicant. The
reference to `opinion' or `advice' in the definition of `information' in section 2(f) of the Act, only
refers to such material available in the records of the public authority. Many public authorities have,
as a public relation exercise, provide advice, guidance and opinion to the citizens. But that is purely
voluntary and should not be confused with any obligation under the RTI Act.
36. Section 19(8) of RTI Act has entrusted the Central/State Information Commissions, with the
power to require any public authority to take any such steps as may be necessary to secure the
compliance with the provisions of the Act. Apart from the generality of the said power, clause (a) of
section 19(8) refers to six specific powers, to implement the provision of the Act. Sub-clause (i)
empowers a Commission to require the public authority to provide access to information if so
requested in a particular `form' (that is either as a document, micro film, compact disc, pendrive,
etc.). This is to secure compliance with section 7(9) of the Act. Sub-clause (ii) empowers a
Commission to require the public authority to appoint a Central Public Information Officer or State
Public Information Officer. This is to secure compliance with section 5 of the Act. Sub-clause (iii)
empowers the Commission to require a public authority to publish certain information or categories
of information. This is to secure compliance with section 4(1) and (2) of RTI Act. Sub-clause (iv)
empowers a Commission to require a public authority to make necessary changes to its practices
relating to the maintenance, management and destruction of the records. This is to secure
compliance with clause (a) of section 4(1) of the Act. Sub-clause (v) empowers a Commission to
require the public authority to increase the training for its officials on the right to information. This
is to secure compliance with sections 5, 6 and 7 of the Act. Sub-clause (vi) empowers a Commission
to require the public authority to provide annual reports in regard to the compliance with clause (b)
of section 4(1). This is to ensure compliance with the provisions of clause (b) of section 4(1) of the
Act. The power under section 19(8) of the Act however does not extend to requiring a public
authority to take any steps which are not required or contemplated to secure compliance with the
provisions of the Act or to issue directions beyond the provisions of the Act. The power under
section 19(8) of the Act is intended to be used by the Commissions to ensure compliance with the
Act, in particular ensure that every public authority maintains its records duly catalogued andCentrlal Board Of Sec.Education & Anr vs Aditya Bandopadhyay & Ors on 9 August, 2011

indexed in the manner and in the form which facilitates the right to information and ensure that the
records are computerized, as required under clause (a) of section 4(1) of the Act; and to ensure that
the information enumerated in clauses (b) and (c) of sections 4(1) of the Act are published and
disseminated, and are periodically updated as provided in sub- sections (3) and (4) of section 4 of
the Act. If the `information' enumerated in clause (b) of section 4(1) of the Act are effectively
disseminated (by publications in print and on websites and other effective means), apart from
providing transparency and accountability, citizens will be able to access relevant information and
avoid unnecessary applications for information under the Act.
37. The right to information is a cherished right. Information and right to information are intended
to be formidable tools in the hands of responsible citizens to fight corruption and to bring in
transparency and accountability. The provisions of RTI Act should be enforced strictly and all efforts
should be made to bring to light the necessary information under clause (b) of section 4(1) of the Act
which relates to securing transparency and accountability in the working of public authorities and in
discouraging corruption. But in regard to other information,(that is information other than those
enumerated in section 4(1)(b) and (c) of the Act), equal importance and emphasis are given to other
public interests (like confidentiality of sensitive information, fidelity and fiduciary relationships,
efficient operation of governments, etc.). Indiscriminate and impractical demands or directions
under RTI Act for disclosure of all and sundry information (unrelated to transparency and
accountability in the functioning of public authorities and eradication of corruption) would be
counter-productive as it will adversely affect the efficiency of the administration and result in the
executive getting bogged down with the non-productive work of collecting and furnishing
information. The Act should not be allowed to be misused or abused, to become a tool to obstruct
the national development and integration, or to destroy the peace, tranquility and harmony among
its citizens. Nor should it be converted into a tool of oppression or intimidation of honest officials
striving to do their duty. The nation does not want a scenario where 75% of the staff of public
authorities spends 75% of their time in collecting and furnishing information to applicants instead
of discharging their regular duties. The threat of penalties under the RTI Act and the pressure of the
authorities under the RTI Act should not lead to employees of a public authorities prioritising
`information furnishing', at the cost of their normal and regular duties.
Conclusion
38. In view of the foregoing, the order of the High Court directing the examining bodies to permit
examinees to have inspection of their answer books is affirmed, subject to the clarifications
regarding the scope of the RTI Act and the safeguards and conditions subject to which `information'
should be furnished. The appeals are disposed of accordingly.
............................J [R. V. Raveendran] ............................J [A. K. Patnaik] New Delhi;
August 9, 2011.Centrlal Board Of Sec.Education & Anr vs Aditya Bandopadhyay & Ors on 9 August, 2011

