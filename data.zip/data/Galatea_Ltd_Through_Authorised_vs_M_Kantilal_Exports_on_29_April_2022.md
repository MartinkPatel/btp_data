Galatea Ltd. Through Authorised ... vs M. Kantilal Exports on 29
April, 2022
Author: B.N. Karia
Bench: B.N. Karia
    C/SCA/2588/2020                              CAV JUDGMENT DATED: 29/04/2022
              IN THE HIGH COURT OF GUJARAT AT AHMEDABAD
                R/SPECIAL CIVIL APPLICATION NO. 2588 of 2020
                                    With
                R/SPECIAL CIVIL APPLICATION NO. 2592 of 2020
                                    With
                R/SPECIAL CIVIL APPLICATION NO. 2593 of 2020
                                    With
                R/SPECIAL CIVIL APPLICATION NO. 2595 of 2020
FOR APPROVAL AND SIGNATURE:
HONOURABLE MR. JUSTICE B.N. KARIA
==========================================================
1      Whether Reporters of Local Papers may be allowed               - YES -
       to see the judgment ?
2      To be referred to the Reporter or not ?                        - YES -
3      Whether their Lordships wish to see the fair copy               - NO -
       of the judgment ?
4      Whether this case involves a substantial question               - NO -
       of law as to the interpretation of the Constitution
       of India or any order made thereunder ?
SPECIAL CIVIL APPLICATION NO. 2588 of 2020
1.   GALATEA LTD. THROUGH AUTHORISED SIGNATORY SAIRA
     RANA
2.   SARINE TECHNOLOGIES LTD
          Versus
1.   M. KANTILAL EXPORTS
2.   MANJIBHAI PATEL PARTNER OF M KANTILAL EXPORTS
3.   PRAVINBHAI KHENI PARTNER M. KANTILAL EXPORTS
4.   PIKESHBHAIGalatea Ltd. Through Authorised ... vs M. Kantilal Exports on 29 April, 2022

5.   SUNILBHAI
6.   CARBON CREATION EXPORTS PRIVATE LIMITED
SPECIAL CIVIL APPLICATION NO. 2592 of 2020
1.   GALATEA LTD. THROUGH AUTHORISED SIGNATORY SAIRA
     RANA
2.   SARINE TECHNOLOGIES LTD
                                  Page 1 of 50
                                                        Downloaded on : Fri May 06 20:05:06 IST 2022
  C/SCA/2588/2020                           CAV JUDGMENT DATED: 29/04/2022
          Versus
1.    SAHAJANAND TECHNOLOGIES PRIVATE LIMITED
SPECIAL CIVIL APPLICATION NO. 2593 of 2020
1.   GALATEA LTD. THROUGH AUTHORISED SIGNATORY SAIRA
     RANA
2.   SARINE TECHNOLOGIES LTD
          Versus
1.   SAHAJANAND TECHNOLOGIES PRIVATE LIMITED
SPECIAL CIVIL APPLICATION NO. 2595 of 2020
1.   GALATEA LTD. THROUGH AUTHORISED SIGNATORY SAIRA
     RANA
2.   SARINE TECHNOLOGIES LTD
          Versus
1.   M. KANTILAL EXPORTS
2.   MANJIBHAI PATEL PARTNER OF M KANTILAL EXPORTS
3.   PRAVINBHAI KHENI PARTNER M. KANTILAL EXPORTS
4.   PIKESHBHAI
5.   SUNILBHAI
==========================================================
APPEARANCE
SPECIAL CIVIL APPLICATION NO. 2588 of 2020
MR NEERAJ MALHOTRA, SENIOR ADVOCATE with MR SANDEEP
GROVER, ADVOCATE for MR. ISHWER UPNEJA, ADVOCATE for
MR VARA GAUR, ADVOCATE for MR DILIP B RANA, ADVOCATE
for the Petitioners No. 1,2
MR. MEHUL SHARAD SHAH, ADVOCATE with MR DEV D PATEL,
ADVOCATE for the Respondents No. 4,5
MR PRATIK Y JASANI, ADVOCATE for the Respondents No. 1,6
SPECIAL CIVIL APPLICATION NO. 2592 of 2020 & SPECIAL CIVIL
APPLICATION NO. 2593 of 2020
MR SHALIN MEHTA, SENIOR ADVOCATE with MR SANDEEP
GROVER, ADVOCATE for MR. ISHWER UPNEJA, ADVOCATE for
MR VARA GAUR, ADVOCATE for MR DILIP B RANA, ADVOCATEGalatea Ltd. Through Authorised ... vs M. Kantilal Exports on 29 April, 2022

                            Page 2 of 50
                                                  Downloaded on : Fri May 06 20:05:06 IST 2022
  C/SCA/2588/2020                                CAV JUDGMENT DATED: 29/04/2022
for the Petitioners No. 1,2
MR SAURABH N SOPARKAR with MR MANAAL J DAVAWALA ,
ADVOCATE for the respondents
SPECIAL CIVIL APPLICATION NO. 2595 of 2020
MR YATIN OZA, ADVOCATE with MR SANDEEP GROVER,
ADVOCATE for MR. ISHWER UPNEJA, ADVOCATE for MR VARA
GAUR, ADVOCATE for MR DILIP B RANA, ADVOCATE for the
Petitioners No. 1,2
MR. MEHUL SHARAD SHAH, ADVOCATE with MR DEV D PATEL,
ADVOCATE for the Respondents No. 4,5
MR PRATIK Y JASANI, ADVOCATE for the Respondents No. 1,6
NOTICE SERVED BY DS(5) for the Respondent(s) No. 2,3
======================================================
 CORAM:HONOURABLE MR. JUSTICE B.N. KARIA
                            Date : 29/04/2022
                            CAV JUDGMENT
1. All these four petitioners are filed by the respective petitioners of the respective petitions under
Article 227 of the Constitution of India for the purpose of appointment of local commissioner and
carrying out for common as specified premised belonging to the respondent after learned trial court
denied their prayers as sought for in their applications Ex. 6 seeking appointment of local
commissioner vide order dated 27.01.2020. Learned Trial Court refused exparte order and issued
notice to the respondent herein.
2. As common question is involved in all of these four C/SCA/2588/2020 CAV JUDGMENT
DATED: 29/04/2022 petitioners, Special Civil Application No. 2592 of 2020 is treated as leading
matter and on a request being made by learned advocates for the respective parties, common order
is passed in all of these matters.
3. Brief background of the matter can be summarized as under:
3.1 Four different suits were filed by the present petitioners before the trial court ie.,
(I) Suit for Patent infringement by Galatea Ltd. and Sarine Technologies Ltd.
against Sahajanand Technologies Pvt. Ltd.; (II) Suit for copyright infringement of the softwares of
the Plaintiffs, ie, Sarine Technologies Ltd. and Galatea Ltd. against Sahajanand Technologies Pvt.
Ltd.; (III) Suit for Patent infringement by Galatea Ltd. and Sarine Technologies Ltd. against M.
Kantilal Exports and others.; (IV) Suit for copyright infringement of the softwares of the Plaintiffs,Galatea Ltd. Through Authorised ... vs M. Kantilal Exports on 29 April, 2022

ie., Sarine Technologies Ltd. and Galatea Ltd. against M Kantilal Exports and others. Along with the
suits filed by the petitioners, in a capacity of plaintiffs, applications Ex. 5 for interim injunction were
filed in all of these suits. Additionally, separate applications were filed for ex parte appointment of
court commissioners under Order 26 Rule 9 of the Civil Procedure Code, 1908 (hereinafter referred
to as "the Code") being applications filed under Exhibit - 6 in C/SCA/2588/2020 CAV JUDGMENT
DATED: 29/04/2022 all these suits. The Trial Court, instead of ex-parte order for appointing of
court commissioners, proceeded to issue notice to the Respondents in the suit vide order
27.01.2020.
3.2 Aggrieved by the said refusal to ex parte appointment of court commissioners, the
Plaintiffs-petitioners approached this Court vide four separate Special Civil Applications in respect
of each of the four suits. Vide detailed orders dated 29.01.2020, this Hon'ble Court was pleased to ex
parte appoint the court commissioners in all the four matters. In compliance with the orders passed
by this Court, the commissions were executed by the court commissioners appointed by this Court
on 01.02.2020. The court commissioners were accompanied by the technical experts nominated by
the Plaintiffs-petitioners as well as the counsel for the Plaintiffs-petitioners, in terms of express
directions issued by this Court vide order dated 29.01.2020. Hence, present petitions.
4. Heard learned advocates for the respective parties.
5. It was submitted by learned advocate for the petitioners that application Ex. 6 of the Trademark
Suit No. 6 of 2020 ("Local Commissioner Application") inter alia under Order XXVI Rule 9 and
Order XXXIX Rule 7 of the Code seeking appointment of Local Commissioner, at the cost and
expenses C/SCA/2588/2020 CAV JUDGMENT DATED: 29/04/2022 of the petitioners to visit the
premises of the respondents to inter alia inspect the machines, computer systems etc, found at the
premises of the respondents to ascertain and prove the infringing activities being carried out by the
respondents was wrongly ordered by the court below issuing notice to the respondents. It was
further submitted that appointment of court commissioner was sought in order to ascertain and
prove that respondents are manufacturing, selling, offering for sale and using machines/devices that
infringe patent of the petitioner no.1 as those machines/devices incorporate the patented technology
of petitioner no.1 in its patent No. IN271425, so as to result in the infringement of the said patent. It
was further submitted that arguments were advanced by learned advocate for the petitioners before
the trial court though the impugned order was passed in violation of the settled principle of law as
laid down by the Hon'ble Supreme Court of India and various High Courts across the country and
principle of natural justice. It was further submitted that the appointment of Court Commissioner in
intellectual property rights cases ex parte is desirable to ensure that the surprise element remains
intact, in absence whereof the Respondents would easily be in a position to remove the infringing
products when the Court Commissioner visits the premises of the respondents. That, the trial court
failed to exercise the C/SCA/2588/2020 CAV JUDGMENT DATED: 29/04/2022 jurisdiction vested
upon him in accordance with law especially in failing to pass orders which would preserve and
protect, the incriminating evidence. It was further submitted that trial court failed to consider that
the service of impugned order or notice in the applications on the Civil Applications on the
respondents could result in either the movement of the infringing machines or software to unknown
destination leaving no surviving evidence thereby causing grave prejudice to the petitioners, andGalatea Ltd. Through Authorised ... vs M. Kantilal Exports on 29 April, 2022

therefore, impugned order is liable to be quashed. It was further submitted that the trial court did
not appreciated the guidelines laid down by the learned Division Bench of Delhi High Court in Case
of "Autodesk Inc & Anr. v. A.V.T. Shankardass & Anrs, reported in AIR 2008 Delhi 167, wherein it is
held that on the question of appointment of a Local Commissioner in software infringement and
piracy matters is not as much to collect evidence but to preserve and protect the infringing evidence.
The pirated software or incriminating evidence can only be obtained from the premises of the
opposite party alone and in the absence of an ex-parte appointment of a Local Commissioner there
is likelihood that such evidence would be lost, removed or destroyed. That, trial court did not
consider the same while passing the impugned order, and therefore, also impugned order is
unsustainable in law. It was further submitted that during the hearing of C/SCA/2588/2020 CAV
JUDGMENT DATED: 29/04/2022 application Ex. 6 before the trial court, learned counsel
appearing for the plaintiffs-petitioners had relied upon various orders passed by the Hon'ble Delhi
High Court in suits wherein infringement of patent is an issue. That, the trial court ought to have
taken the same view unless the said orders were not applicable to the facts of the case on hand, for
which, trial court ought to have provided reasons for its disagreement to follow the said view. It was
further submitted that no reasons were recorded to justify its decision not to exercise its powers
under Order XXVI Rule 9 of the Code, despite the petitioners having made out a very good prima
facie case in view of the documents produced before the learned trial court. It is further submitted
that in cases involving patent and/or copyright infringement, an element of surprise is of critical
importance, and in fact necessary to subserve the ends of justice. However, trial court has grossly
and manifestly erred in not appreciating that issuance of notice without granting ex-parte ad interim
orders, would result in effacement of entire incriminating evidence. Referring the case of
"Laxmikant V. Patel v. Chetanbhat Shah & Anr, reported in (2002) 3 SCC 65. it is submitted that in
cases where the discretion exercised by the trial court or High Court against the plaintiff is neither
reasonable nor judicious, it becomes obligatory on the Appellate court to interfere and grant
interlocutory injunction.
C/SCA/2588/2020 CAV JUDGMENT DATED: 29/04/2022 Hence, it was requested by learned
advocate for the petitioners to quash and set aside the judgment and order dated 27.01.2020 passed
by the learned Additional District Judge, Surat below Exhibit 6 in Trademark Suit No. 6 of 2020 and
allied matters.
6. From the other side, learned advocate for the respondents herein of all these petitions have
opposed the submissions made by learned advocate for the petitioners and submitted that the
respondent ("STPL") is a company incorporated under the Companies Act having its registered
office at A1, Sahajanand Estate, Wakharia Wadi, Near Dabholi Char Rasta, Vad Road, Surat. It was
incorporated in 1993 and is engaged in developing cutting edge technological solutions for the
diamond industry. It was further submitted that respondent is one of the very global companies that
offer total technology solutions for diamond manufacturing, including diamond analysis and
planning, processing, cutting, blocking and polishing as well as safe diamond trading. That, the
respondent has average manpower strength of around 550 and in financial year 2019-20, its annual
R&D budget was over Rs. 3 crores. The respondent has been honoured by many national and
international bodies such as Good Design Award-Japan, Vision System Design Innovators Award -
USA, JNA Awards - Hong Kong-China and many more. On the national front, theGalatea Ltd. Through Authorised ... vs M. Kantilal Exports on 29 April, 2022

C/SCA/2588/2020 CAV JUDGMENT DATED: 29/04/2022 Respondent is a recipient of India
Design Mark Award twice, has won Platinum Level Quality Excellence Award by the Federation of
Indian Chambers of Commerce and Industry, for machine and production quality. The respondent
is broadly in business of two product categories, namely (I) Gemstone Planner and (ii) Laser
Diamond cutting machines. It was further submitted that the present petition is nothing but an
abuse of the process of law and devoid of any merit and does not disclose any cause of action,
therefore, present petitions are liable to be dismissed with exemplary costs. It was further submitted
that these proceedings have been initiated by the petitioners with the sole and ulterior motive of
harassing the respondent and to stifle healthy competition in the market, for causing wrongful loss
to respondent and thereby earning wrongful gain. That, in the industry, the petitioners and the
respondent are business rivals.
7. The petitioners have sought to invoke the extraordinary powers of this Court under Article 227 of
the Constitution of India, however, the petitioners have failed to make out any case for availing and
invoking the discretionary jurisdiction of this Court. That, trial court has passed the impugned order
after considering the facts and circumstances as put forth by the petitioners and considering the law
on the subject. The judgments as cited by the petitioners herein also put forth C/SCA/2588/2020
CAV JUDGMENT DATED: 29/04/2022 before the Ld. Trial Court which are duly considered and
thereafter, passed the impugned order. It was further submitted that no case was made out by the
petitioners for grant of any relief, much less any relief under Order 26 Rule 9 of the Code, and
therefore, the same cannot be termed as illegal, erroneous or otherwise merely because it did not
grant what the petitioners were sought for before the Trial Court. That, the second address
mentioned in cause title of application Exhibit - 6 and third address in the present petition is Avadh
2, Swami Paramanand Marg, Opp. Comet Motors, Katargam, Surat- 395004 which does not belong
to the Respondent. It is submitted that the petitioners have admitted on oath that the premises
located at the given address does not belong to the Respondent and they knew very well for over
several months that the premises belong to a third party namely STC Machines LLP and does not
belong to the Respondent. That, the petitioners immediately filed application dated 28.2.2020
under Order 1 Rule 10 of the Code for joining STC Machines LLP as proposed defendant in the suit
before the Trial Court. However, petitioners have till date neither sought modification of cause title
of present petition nor brought on record of the present petition the said fact of application for
adding proposed defendant in the suit. It was further submitted that the petitioners have admitted
on oath that the address is C/SCA/2588/2020 CAV JUDGMENT DATED: 29/04/2022 deliberately
and falsely reported as belonging to the Respondent and has abused the process of law before this
Court. That, petitioners have no cause of action against the Respondent and therefore false
statement of address was made in cause title, chose not to make STC Machines LLP as defendant in
the suit below, created confusion of identity by misrepresentation of addresses belonging to the
Respondent and under the entire facade obtained ex parte orders illegally for discovering the trade
secrets of the Respondent. That, the petitioners made up stories for conducting roving and fishing
inquiries with the ulterior motive of accessing the Respondent's confidential and proprietary
information and also with view to initiate vexatious and frivolous proceedings against the
Respondent so that rather than focusing on its day-to-day business, Respondent starts to devote its
time on such proceedings which in turn would ensure that there is no competition in the market.
That, the petitioners are intentionally making wrong and malicious statements in such articlesGalatea Ltd. Through Authorised ... vs M. Kantilal Exports on 29 April, 2022

which feature in prominent trade magazines stating that the Respondent is carrying out infringing
activities. That, the ulterior motive of the petitioners through the present petition is only to access
the Respondent's confidential and proprietary data and information which can then be used to the
detriment and disadvantage of the Respondent with the C/SCA/2588/2020 CAV JUDGMENT
DATED: 29/04/2022 view to monopolize the market and throttle and stifle any healthy
competition. That, the petitioners had expressed their wish to partner with the Respondent by using
the Respondents' robot and combine it with its own technology. In this regard, an email dated
27.7.2018 was addressed by Mr. Gilad Shaham, Product Manager, Diamond Manufacturing
Activities Sanne Technologies Pvt. Ltd. to the Respondent. It is further submitted that however due
to certain reasons, partnership did not fructify. It is further submitted that the CEO of the
petitioners had also visited the office of the respondent to have a personal meeting with a view to
settle all pending litigation and disputes and to start a new business partnership, which was also not
successful.
8. It was further submitted that despite best efforts of the petitioner, they could not gain access to
the Respondents' said confidential and proprietary information and technology. The petitioner then
came up with the novel idea of abusing the law by filing the suit before the Trial Court and then
before this Court by suppressing material facts and obtaining orders appointing local
commissioners, which under normal circumstances, they could not succeed despite various
attempts. It was further submitted that Mr. Gilad Shaham accompanied the Court Commissioners
and entered the Respondent's premises and accessed and shared the C/SCA/2588/2020 CAV
JUDGMENT DATED: 29/04/2022 Respondent's confidential and proprietary information and
technology by passing himself off as the petitioner's counsel, in total contravention of the order
dated 29.1.2020 passed by this Court. That, the petitioners have successful in their malafide motives
by using and abusing the process of law and using the orders of the Court as a tactical weapon to
procure trade secrets through illegal means. It was further submitted that petitioners have willfully
violated the order passed by this Court on 29.01.2020 by taking unauthorized actions and by
ignoring what was exactly ordered in black and white by this Court. It was further submitted that
this Court has clearly specified the locations/addresses where the Local Commissioners could visti
and inspect. However, at the time of conducting local commission, petitioners and their senior
officials barged into other premises of the respondent without any authority. It was further
submitted that the court commissioners appointed by this court were given authorization to visit
premises located at Plot No. 33, 34, 35, 52, 53 and 54, Surat Special Zone, Sachine, Surat, Gujarat
vide order dated 29.01.2020. It was further submitted that reasons known to the respondent, no
court commission was carried out at the said locations, which shows that petitioners were only
interested in visiting the location of the respondent whereby direct access to its confidential and
proprietary data would be C/SCA/2588/2020 CAV JUDGMENT DATED: 29/04/2022 available and
can be collected easily under the tarb of conducting court commissioner.
9. It was further submitted that in the order passed by this court it is nowhere stated that the
petitioners and their representatives including their senior officials could visit the premises of the
Respondent. Despite the same, the senior officials of the petitioners, namely, Ran Ziskind (CEO,
Galatea Le Ltd.), Gilad Shaham (Director, Product Management, Sarine Technologies Ltd.), and
Gilad Hassid (Vice President, Operations, Sarine Technologies Ltd.) illegally entered the premises ofGalatea Ltd. Through Authorised ... vs M. Kantilal Exports on 29 April, 2022

the Respondent. It was further submitted that they even entered the R&D facility of the Respondent,
accessed the systems, databases, confidential proprietary data and information and took copies of
the same. It was further submitted that the petitioners shared the said confidential and sensitive
data with their counterparts located overseas, in real time, via a video call, while the Court
Commission proceedings were ongoing.
10. It was further submitted that the Court Commissioner appointed by this Court took a back seat
and these officials were carrying out the entire "Court Commission" to gain access to the trade
secrets of the Respondent. That, this Court vide order dated 04.03.2020 C/SCA/2588/2020 CAV
JUDGMENT DATED: 29/04/2022 specifically directed that the Court Commissioner's Report be
kept in the custody of Nazir and same was required by the trial court then petitioners may approach
the trial court, which would then decide the application in accordance with law. It was further
submitted that the Court Commissioners have duly submitted the report on 21.9.2020 in sealed
covers to be kept in the custody of Nazir. That, in Commercial Trademark Civil Suit No. 12 of 2020
before the Trial Court , petitioners have submitted a true copy of the Court Commissioner's Report
at Annexure A-2 of the rejoinder affidavit. That, petitioners are already in possession of the Court
Commissioner's Report which is against the express directions and intentions of this Court. It was
further submitted that report of the court commissioner which was submitted in a sealed cover
before this Court has found its way into the petitioners' hand. That, the actions of the petitioners
raise a serious doubt in the integrity and the admissibility of the court. Commissioner's report and
and also of the fact as to whether the inspection carried out was independent of the influence of the
petitioners. It was further submitted that confidential and proprietary data and information of the
respondents have been illegally stolen under the guise of "Court Commission" and would be misused
to its disadvantage by the petitioners with a view to monopolize the market and throttle and stifle
healthy C/SCA/2588/2020 CAV JUDGMENT DATED: 29/04/2022 competition. That, the
Respondent has already filed separate contempt petitions for the said acts of the petitioners and are
still pending before this Court for adjudication. It was further submitted that allegations made by
the petitioners in the plaint are that the respondents have infringed its patent without giving any
evidence or semblance of proof in support thereof. The petitioners have failed to show that
respondents are in any way liable for any patent violations. It was further submitted that petitioners
have failed to demonstrate any special or deserving circumstances, which warrant ex-parte orders of
appointment of court commissioner.
11. Learned advocate for the respondents has denied that the respondents have infringed the patent
of the petitioners as there is no specific averments made by the petitioners as to any particular
product or model of the respondent which allegedly infringes its rights under the Patent Act. It was
further submitted that the petitioners have willfully suppressed and concealed the material facts
that Patent Application No. 876/CHENP/2008 dated 21.2.2008 was rejected by order dated
13.10.2020 and Appeal is pending before the Intellectual Property Appellate Board (IPAB). It was
further submitted that the petitioners' Israel Patent Application No. 181484 was abandoned way
back on 28.10 2010, and therefore, patent itself was obtained by unfair and illegal
C/SCA/2588/2020 CAV JUDGMENT DATED: 29/04/2022 means. It was further submitted that
the trial court has applied its mind, thereafter, denied the prayer as sought for in the application Ex.
6. It was submitted that the petitioners have consciously violated the order dated 29.01.2020 byGalatea Ltd. Through Authorised ... vs M. Kantilal Exports on 29 April, 2022

entering other locations belonging to the respondents which were not mentioned in the said order.
That, officials of the petitioners whose names were not mentioned in the said order entered the R&D
facility of the respondent and copied and shared the confidential and sensitive data of the
respondents with their counterparts located overseas, in real time, vide a video call, and that too
while the local commission proceedings were ongoing. That, the petitioners have only made bold
and vague allegations of alleged infringement of the patent by the respondents and has not even
identified or provided the details of any single product or machine of the respondent which infringes
its alleged patent of the petitioners. It was further submitted that the petitioners have admitted that
they do not have the evidence pertaining to the infringement and same shall be provided at the later
stage/post the completion of the Local Commission. It was further submitted that no local
commission can be ordered to gather evidence for the benefit of the plaintiffs-petitioners. It was
further submitted that the commission cannot be executed unless notice is given to the concerned
parties under Order 26 Rule 18 of the Code which C/SCA/2588/2020 CAV JUDGMENT DATED:
29/04/2022 is mandatory. It was further submitted that no notice of commission has been issued to
the respondents in the present case and the petitioners' along with its senior officials have illegally
entered the premises of the respondents and accessed the systems, databases, confidential
proprietary data and information and taken copies of the same. That, the petitioners are already in
possession of the report of the court commissioner, which is against the express directions and
intentions of this Court, which was not disclosed by the petitioners before this court and misguided
it to pass an order dated 03.03.2020/04.03.2020. That, Court commissioners' report shall be kept
in the custody of the Nazir and if, the same was required by learned trial court then the petitioner
may approach the trial court which would then decide the application in accordance with law. It was
further submitted that petitioners claimed and produced loose papers during the course of hearing
purporting to be of an application supposedly made on 05.03.2020 for calling of the court
commissioner's report submitted to this Court. However, said application is not even provided to
the respondent below nor it is accepted and still it is pending without hearing. It was further
submitted that the intention of this court to ensure that after carrying out the court commission, the
court commissioners were to submit the report in sealed cover and C/SCA/2588/2020 CAV
JUDGMENT DATED: 29/04/2022 this court, which was to be kept into the custody of Nazir till
further orders. It is further submitted that there is no provision of law under Order 26 Rule 10 of the
Code that copy of the commissioner's report be given to the parties against the express directions of
the court. It was further submitted that court commissioner's report which has been submitted in
the sealed cover before this Court has found its way into the petitioners' hands. It was further
submitted that after carrying out the court commission, immediately, the petitioners purposely
circulated disparaging/defaming articles regarding the respondent which featured in prominent
trade magazines stating that the respondent is carrying out infringing activities. It was further
submitted that petitioners are desperate and are trying their level best to damage the hard earned
goodwill of the respondent and cause injury to their business activities and are also trying to malign
the impeccable reputation of the respondent. It was further submitted that entire exercise, right
from the order dated 27.01.2020 passed by the trial court to the ex-parte court commission carried
out on 01.02.2020 was completed within short period without any notice to the respondents. It was
further submitted that since the commissioner has already been carried out, the respondent has no
recourse but to accept the illegal and invalid court commission and raise objections only before this
Court. It was C/SCA/2588/2020 CAV JUDGMENT DATED: 29/04/2022 further submitted thatGalatea Ltd. Through Authorised ... vs M. Kantilal Exports on 29 April, 2022

court commissioner was ordered by this court and respondent cannot raise objections against the
order of this Court before the trial court. That, the legality and validity of the order passed by this
Court has to be decided by this court only. Ultimately, it was requested by learned advocate for the
respondents to dismiss all these four petitions with exemplary costs for abuse of process of law and
report of the Court Commissioner needs to be recalled/set aside by this Court. In support of his
arguments, learned advocate for the respondents has produced following judgments:
1. AIR 1934 Mad 548
2. ILR 1977 K. Series 855
3. Order passed by this Court in SCA No. 8976 of 2007
4. 2019 (5) SCC (AIG) 194
5. Order passed by this court in SCA No.10186 of 2010
6. Order passed by this Court in SCA No. 11890 of 2010
12. Learned advocate for the petitioners in reply has submitted that the present petitions were for
appointment of court commissioner was ex-parte granted on 29.01.2020 and therefore, nothing
further survives in the present petitions and all the four petitions are liable to be disposed of with a
direction that reports lying with this court be sent to the C/SCA/2588/2020 CAV JUDGMENT
DATED: 29/04/2022 learned trial court and such reports be considered by the trial court in
accordance with law and subject to objections, if any, raised by the respondents upon receipt of the
court commissioners report. It was further submitted that weightage to be given to the court
commissioners' report, which may be determined by the trial court in accordance with law. It was
further submitted that any irregularities as alleged by the respondent in respect of the court
commissioner's report or any manner, in which, the commissions were executed by the court
commissioners is a matter which ought to be relegated to the trial court which can decide the same.
It was further submitted that the report clearly shows that the respondents are infringing the patent
and the copyright of the petitioners, which is demonstrated by the pictures and videos taken by the
court commissioner at the premised of the respondents and not merely as statements of the
commissioners. It was further submitted that the evidence collected by the commissioners is in
material form demonstrating the infringement and is not subject to any deliberations whatsoever,
nor is capable of being disputed by either of the respondents. That respondents are also attempting
to mischievously, misdirect the attention of this court. The latter contention of the respondent
cannot be considered by this court in absence of a challenge to the ex- parte order passed by this
court.
C/SCA/2588/2020 CAV JUDGMENT DATED: 29/04/2022
13. It was further submitted that there was no direction to the commissioner that the report should
not be supplied to the parties. Referring the order dated 03.03.2020, it was submitted that the alliedGalatea Ltd. Through Authorised ... vs M. Kantilal Exports on 29 April, 2022

applications are pending before the trial court. That petitioners have made request to the trial court
that the reports are required for the purpose of deciding certain applications filed by the petitioners
in the suit ie., impleadment applications and Exh.5 applications. If that was not the case, there was
no occasion for this court to use the expression allied applications in the said order and the court
would have instead used Exhibit 5 applications or the interim injunction applications. In support of
his arguments, learned advocate for the petitioners has relied upon the following judgments;
1. (1988) 2 SCC 196
2. (2020) 11 SCC 590
3. Suomotu v. State of Guajrat and others (22.05.2020- GUJHC)
4. Judgment of the Hon'ble Supreme Court in the case of Bhavnagar University v. Palitana Sugar
Mill Prvt. Ltd., and others
5. Judgment of the Hon'ble Delhi High Court in the case of Autodesk Inc & Anr v. AVT shankardass
& Anrs,
6. Judgment OF High Court of Madras in case of P. C/SCA/2588/2020 CAV JUDGMENT DATED:
29/04/2022 Moosa Kutty
14. Having heard learned advocates for the respective parties and perusing the material supplied on
record by the respective parties, it appears that in all petitions, petitioners are the original plaintiffs
and have preferred four suits before the trial court ie., (I) Suit for Patent infringement by Galatea
Ltd. and Sarine Technologies Ltd. against Sahajanand Technologies Pvt. Ltd.; (II) Suit for copyright
infringement of the softwares of the Plaintiffs, ie, Sarine Technologies Ltd. and Galatea Ltd. against
Sahajanand Technologies Pvt. Ltd.; (III) Suit for Patent infringement by Galatea Ltd. and Sarine
Technologies Ltd. against M. Kantilal Exports and others.; (IV) Suit for copyright infringement of
the softwares of the Plaintiffs, ie., Sarine Technologies Ltd. and Galatea Ltd. against M Kantilal
Exports and others.
15. Along with the suits, Ex. 5 applications for interim injunctions were filed and additionally,
separate applications were filed for ex parte appointment of court commissioners under Order 26
Rule 9 of the code being applications filed under Exhibit - 6 in all these suits. Prayer was made in
the application Ex. 6 to visit the premises of the respondents to interalia inspecting the machines,
computer systems etc found at the premises of the respondents to ascertain and prove the infringing
activities being carried out by the respondents. Suits C/SCA/2588/2020 CAV JUDGMENT DATED:
29/04/2022 along with the applicants for appointment of court commissioner were listed before the
trial court for hearing. Arguments were also advanced by the petitioners before the trial court and
the trial court, instead of exparte order for appointment of court commissioner proceedings issued
notice to the respondents in the suit vide order dated 27.01.2020.Galatea Ltd. Through Authorised ... vs M. Kantilal Exports on 29 April, 2022

16. Aggrieved by the said refusal to ex-parte appointment of court commissioners, petitioners -
plaintiffs have approached this court and on 29.01.2020, this court was pleased to pass following
order.
1. Heard learned senior advocate Shri Neeraj Malhotra appearing with learned advocate Mr. Dilip B.
Rana, for the petitioners. 2. The learned senior advocate Mr. Malhotra for the petitioners pointed
out that in the case of infringement of patent, usually the trial court used to grant appointment of
commissioner for bringing on record the alleged infringement by way of making local inspection as
well as inventory thereto and that fact is not looked into. Even this court as well as in this sort of
matter dealt with by the Delhi High Court, the Division Bench has also laid down certain guidelines.
Though the petitioners submitted all these details to the learned trial court, more particularly,
holding that the issue of patent is involved but the learned trial court was pleased to issue notice
instead of appointing the court commissioner for carrying out local inspection as well as inventory
as prayed for. The learned senior advocate placed reliance upon the decision laid down in the case of
Autodesk Inc and Anr. vs. A.V.T. Shankardas and Anr., reported in 2008 (105) DRJ 188(DB), and
more particularly, places reliance upon paragraph 14, which reads thus :
"Coming now to the question of guidelines to be set, we C/SCA/2588/2020 CAV
JUDGMENT DATED: 29/04/2022 have heard both the counsel for the parties. We
are conscious of the fact that it is neither feasible nor practical to lay down guidelines,
which would cater to numerous and all the situations that may arise. However, some
of the following relevant factors and guidelines are being enumerated which the
Court may take into consideration on the question of appointment of a Local
Commissioner in software infringement and piracy matters:- (i) The object of
appointment of a Local Commissioner in software piracy matters is not, as much to
collect evidence but to preserve and protect the infringing evidence. The pirated
software or incriminating evidence can only be obtained from the premises of the
opposite party alone and in the absence of an ex parte appointment of a Local
Commissioner there is likelihood that such evidence may be lost, removed or
destroyed; (ii) Request for ex parte appointment of a Local Commissioner in such
matters is usual and in fact is intended to sub serve the ends of justice as it is
imperative to have an element of surprise so that the actual position is not altered;
(iii) The test of reasonable and credible information regarding the existence of
pirated software or incriminating evidence should not be subjected to strict proof or
the requirement to demonstrate or produce part of the pirated
software/incriminating evidence at the initial stage itself. It has to be tested on the
touchstone of pragmatism and the natural and normal course of conduct and practice
in trade. (iv) It may not always be possible for a plaintiff to obtain any admission by
employing decoy customers and gaining access to the defendants premises. Any such
attempt also inheres in it the possibility of disappearance of the pirated
software/incriminating evidence in case the decoy customers is exposed. Accordingly,
visit by decoy customer or investigator is not to be insisted upon as pre condition. A
report of private Investigator need not be dis-regarded or rejected simply because of
his engagement by the plaintiff. The information C/SCA/2588/2020 CAVGalatea Ltd. Through Authorised ... vs M. Kantilal Exports on 29 April, 2022

JUDGMENT DATED: 29/04/2022 provided by the private Investigator should
receive objective evaluation. (v) In cases where certain and definite information with
regard to the existence of pirated software or incriminating evidence is not available
or where the Court may nurture some element of doubt, it may consider asking the
plaintiff to deposit cost in Court so that in case pirated software or incriminating
evidence is not found then the defendant can be suitably compensated for the
obtrusion in his work or privacy."
3. This Court is taken through the recitals and allegations levelled in the application as well as in the
petition and the present petitioners - plaintiffs apprehended that if notice be issued to the
respondents, there appears likelihood of removal of evidence of infringement of patent, and in that
view of the matter, the learned trial court could have issued ex-parte appointment of commissioner.
Even otherwise, he has submitted that this is to be done at the cost of the plaintiffs and it would not
be in any manner harmful to the respondents - defendants.
4. This Court has gone through the records and proceedings as well as allegations made therein.
Since inspection of only one premises as indicated in the application before the learned trial court in
prayer (B), is required to be undertaken by way of appointing local commissioner, consequently,
therefore, this Court is of the considered opinion to grant the application as prayed for, for
appointment of commissioner for local inspection as well as for carrying out inventory as prayed for,
in the above premises.
5. Mr. Fouzan Soniwala, advocate (mobile no. 91+9998441924) is appointed as the local
commissioner for carrying out the C/SCA/2588/2020 CAV JUDGMENT DATED: 29/04/2022
inspection. The petitioners-plaintiffs shall deposit Rs.1 Lac for remuneration payable to the
commissioner at the first instance before this Court and the commissioner shall carry out the local
inspection as well as inventory as prayed for within three days and shall make report within a period
of 15 days, from the date of issuance of the commission to him and seek police assistance if required.
The learned trial court shall act and facilitate in carrying out the purpose of Exh.-6. The local
commissioner shall prepare an on the spot proceedings and record the names of all the parties
presence. The respondents Nos.1 to 6 shall cooperate with the Commissioners in carrying out the
inspection as per this order.
6. It will be open for the petitioners-plaintiffs to send its counsel and experts with the commissioner.
7. Issue Notice for final disposal making it returnable on 3 rd March, 2020.
Direct service today is permitted."
17. It appears from the record that in compliance with the order passed by this Court, the
commissions were executed by the court commissioners appointed by this court on 10 th February
2020.Galatea Ltd. Through Authorised ... vs M. Kantilal Exports on 29 April, 2022

18. It further appears that in Special Civil Application No. 2588 of 2020 arising out of the patent
infringement against M. Kantilal Exports and Others and report of the court commissioner was
submitted and in the said proceedings, C/SCA/2588/2020 CAV JUDGMENT DATED: 29/04/2022
proceedings were duly signed by the representatives of the respondents wherein certain handwritten
objections were submitted by the representatives of the respondents to the court commissioner
which was form part of the court commissioner's report. Further, the court commissioner provided a
copy of 'on the spot' report to the representatives of both the parties.
19. It appears that in Special Civil Application No. 2592 of 2020 and Special Civil Application No.
2593 of 2020 arising out of the patent infringement and copy right infringement suits against
Sahajanand Technologies Private Limited and report of the court commissioner was submitted on
the spot proceedings duly signed by the representatives of the respondents. Further it appears that
respondent has filed contempt petition being Misc Civil Application No. 764 of 2020 and 765 of
2020 which would be dealt with separately by the court.
20. It appears that in Special Civil Application No. 2595 of 2020 arising out of the copy right
infringement suit filed against M. Kantilal Exports Pvt. Ltd., wherein report of the court
commissioner was submitted and reply was filed by the respondents no.4 and 5 on behalf of the
respondent no.1. Rejoinder was also filed by the petitioners to the reply of the C/SCA/2588/2020
CAV JUDGMENT DATED: 29/04/2022 respondent. On the spot proceedings have been duly signed
by the representatives of the respondents and certain handwritten objections were submitted by the
said representatives of the respondent to the court commissioner which would form a part of the
court commissioner's report. Court commissioner provided a copy of on the spot report to the
petitioners.
21. As per submissions of learned advocate for the petitioners, since the limited relief was sought for
in the present petitions for appointment of court commissioner which was ex-parte granted on
29.01.2020 and therefore, nothing further survives in the present petitions and all the four petitions
are liable to be disposed of with a direction that reports lying with this court be sent to the learned
trial court and such reports be considered by the trial court in accordance with law and subject to
objections, if any, raised by the respondents upon receipt of the court commissioners report cannot
be accepted as court commissioner was ordered by this court, therefore, trial court would not be in a
position to decide the legality and validity of all the objections raised by the respondent before this
court and therefore legality and validity of the order passed by this court has to be decided by this
court only.
22. It appears that while passing an order dated C/SCA/2588/2020 CAV JUDGMENT DATED:
29/04/2022 29.01.2020 by this Court, the judgment of the Hon'ble High Court of Delhi reported in
2008(105) DRJ 188(DB) in case of "Autodesk Inc & Anr. v. A.V.T. Shankardas & Anrs," was
considered by this Court. In this judgment, certain guideline were issued by Hon'ble High Court of
Delhi in a matter of software infringement and piracy and appointment of local commissioner
observing that it would not be a matter to collect evidence but to preserver and protect the
infringing evidence. It was further observed while issuing the guidelines that the pirated software or
incriminating evidence can only be obtained from the premises of the opposite party alone and inGalatea Ltd. Through Authorised ... vs M. Kantilal Exports on 29 April, 2022

the absence of an ex-parte appointment of a Local Commissioner there is likelihood that such
evidence would be lost, removed or destroyed. In the instance case, it is the case of the petitioners
before the trial court that patent report is infringed by the respondents herein. If we consider the
guidelines issued by Hon'ble Delhi High Court and the facts of the present case, patent would not be
physically installed machines/product, which could easily be removed or hidden as is sought to be
portrayed by the petitioners. Further, it appears from the judgment replied upon by the petitioners
that specific guidelines and manner in which, the court commission was to be carried out so that it
would result in undue loss of proprietary material and trade secrets of the C/SCA/2588/2020 CAV
JUDGMENT DATED: 29/04/2022 defendants. There cannot be a straitjacket formula where same
guidelines are to be followed in case of patent infringement or software piracy as the criteria would
be substantially different.
23. If we consider the application Ex. 6 preferred by the present petitioners for appointment of local
commissioner under Order 26 Rule 9 of the Code, it is nowhere alleged with respect to infringing
activities supposedly being carried out by the respondent herein. The petitioners have averred that
they did not have evidence pertaining to the infringement. For the sake of convenience, submissions
made by the petitioners in para 8 of the suit can be summarized as under:
"8. It is most respectfully submitted that it is clear that a prima facie case exists in
favour of the plaintiffs. Further, since the activities are being carried out by the
defendants covertly and surreptitiously, the plaintiffs do not have all the evidence
pertaining to the infringement of the patent held by the plaintiffs, and crave leave of
this Hon'ble Court to place on record further document/evidence in this regard, at a
later stage. Further, the plaintiffs most humbly request the assistance of this Hon'ble
Court to ensure justice is meted out to the plaintiffs herein and the defendants
and/or their affiliates, subsidiaries, representatives, agents, assigns, etc, be
restrained from indlging in such unlawful activities."
24. Further, it appears from the copy of the plaint in the suit produced before the trial court, three
addresses were C/SCA/2588/2020 CAV JUDGMENT DATED: 29/04/2022 provided by the
petitioners and out of them, only one was belonging to the respondent. Further it appears that
another 4 addresses were similarly added by way of annexure in the present petition and none of
them were belonging to the respondent. Total 7 addresses were provided by the petitioners. From
these 7 addresses, 3 addresses were provided before the trial court and 4 addresses were provided
before this Court. Out of them, only one address ie., A-1, Sahajanand Estate, Wakhariya Wadi, Near
Dabholi Char Rasta, Ved Road, Surat- 395004, was belonged to the respondent. It further appears
from the record that local commissioner was carried out at one address ie., Avadh 2, Swami
Parmanang Marg, Opp. Comet Motors, Katargam, Surat 395004, which was not belonged to the
respondent. The petitioners, in their rejoinder before the trial court and before this court, attempted
to portray the respondent as some infringer. Since the application dated 28.02.2020 was filed by the
petitioners under Order 1 Rule 10 of the Code for joining the correct party to whom the premises
belonged ie., STC Machines LLP was proposed defendant in the suit before the trial court, the
petitioners were aware about the address ie., Avadh 2, Swami Parmanang Marg, Opp. Comet
Motors, Katargam, Surat 395004 is not belonging to the respondent. Further it appears from theGalatea Ltd. Through Authorised ... vs M. Kantilal Exports on 29 April, 2022

record that petitioners have till date, not sought any modification of cause title of the
C/SCA/2588/2020 CAV JUDGMENT DATED: 29/04/2022 petition nor brought on record before
this Court in the present petitions the said fact of application for adding proposed defendant in the
suit under Order 1 Rule 10 of the Code . The petitioners have admitted on oath that said address was
deliberately reported as belonging to the respondent herein. Order passed by this Court on
29.01.2020 has never permitted any Senior officials from the petitioners entered into other
premises of the respondent, however, without authority, granted by this Court. In the order dated
29.01.2020, it appears that petitioners and other senior officials from the petitioners entered into
other premises of the respondent. The said premises are Plot No. 66, Surat Special Zone, Sachin,
Surat 394230 and Plot No. 5526, GIDC, Sachin Surat 394230. Further it appears that there is clear
breach of Order 26 Rule 18 of the Code. Under Oder 26 Rule 9 of the Code, this Court has discretion
to issue commission ex-parte however the said commission cannot be executed unless notice is
given to the concerned parties under Order 26 Rule 18 of the CPC which is mandatory. In the
present case, no notice of commission was issued, respondent herein and petitioners alongwith its
senior officials have entered into the premises of the respondent and accessed the systems,
databases, confidential proprietary data and information and taken copies of the same. Further it
appears from the record that petitioners have also shared the C/SCA/2588/2020 CAV JUDGMENT
DATED: 29/04/2022 said confidential datas with their counter part located overseas in real time via
a video call, while the court commission proceedings were ongoing.
25. In case of Modalavalasam Lattchan Naidu and another versus Rajah Saheb Maherban Destan
Raja and another, reported in AIR 1934 Mad 548, it was held as under:
"The Court granted the petition and issued a warrant to the Commissioner returnable
on August 3, 1932. The Commissioner completed his inspection on July 31, 1932, and
signed his report on August 22, 1932. No notice was given to defendants of this
second petition, nor was any notice given to them of the issue of the Commissioner
nor had they any opportunity afforded to them of being present when the
Commissioner made his inspection. The whole thing was done behind their back. It
must be remembered that Rule 10 (2) of Order XXVI, Civil Procedure Code, makes
the report of the Commissioner evidence in the suit. Therefore, it is of importance
that the report should not be founded on representation made to the Commissioner
or on matters brought to his notice by one party to the suit alone. Indeed, it is so
manifestly improper that one party to a suit should be given a commission and the
advantage of a report by the Commissioner without the knowledge of the opposite
party that I think this alone would be sufficient to justify the interference of a revision
Court. But there is Rule 18 of Order XXVI which says that when a commission is
issued under this order the Court shall direct that the parties shall appear before the
Commissioner in person or by their agents or Pleaders. Sub-rule 2 of Rule 18 says
that where all or any of the parties do not so appear the, Commissioner may proceed
in their absence. Rule 18 is mandatory, and is intended to ensure that the parties
have notice of the appointment of the Commissioner and that they must attend his
investigation. There is no power in the Court to issue C/SCA/2588/2020 CAV
JUDGMENT DATED: 29/04/2022 an ex parte commission. It has been suggestedGalatea Ltd. Through Authorised ... vs M. Kantilal Exports on 29 April, 2022

that an emergency excused the order of the District Munsif I think that there was no
more emergency on July 29, than there was on July 22, when the first petition was
filed; but an emergency could not absolve the District Munsif from complying with
Rule 18."
26. In case of Kishore H. Desai v. Lilawati Virji Chheda and Ors, reported in (1993) 2 Mah LJ 1155, it
is observed in para 13 to 21 as under:
"The Court has discretion to issue commission under Order 26, Rule 9 of the C.P.C.
ex parte. However, after the issuance of commission, it is the duty of the Court to
issue notice to the concerned party and the commission cannot be executed unless
the notice is given to all the parties. I am inclined to think that the provisions of
Order 26, Rule 18 are mandatory provision. If for any reason the Court fails to give
notice it becomes the duty of the commissioner to give notice to the other party. After
the notice is given if the parties fail to appear, the commissioner will be at liberty to
proceed in their absence."
27. This Court in Special Civil Application No. 8976 of 2007 (Hon'ble Mr. Justice S. R. Brahmbhatt,
J.), in para 7 has observed as under:
"In view of this prayer, it can well be said that the dispute in question for the
boundaries and over lapping boundaries of land, which would have warranted any
local investigation, in fact, the title of the suit land is to be determined and when such
a prayer is made, and especially when there is no dispute with regard to over lapping
boundaries or any dispute requiring local investigation as envisaged under order 26
Rule 9 of the CPC, the Court Commissioner could not have been appointed or else it
would C/SCA/2588/2020 CAV JUDGMENT DATED: 29/04/2022 amount to giving
an opportunity to parties to have the evidences or creating the evidences. The parties
are at before the Court and they will have to avail the opportunity of establishing
their case for all the contentions and therefore, in my view, the application for
appointment of Court commissioner has rightly been rejected"
28. In case of Rani Aloka Dudhoria and others v. Goutam Dudhoria and others, reported in 2009
SCC OnLine SC 507, iit is observed in para 68 to 70 that:
"68. It is not necessary for us to delve in detail in regard to the conduct of Shri Anand
Aggarwal, Advocate, but in view of Rule 18 of Order XXVI of the Code of Civil
Procedure, there cannot be any doubt, whatsoever that the Commissioner should
have issued notice to all the parties.
69. Mr. Manoj Goel has placed reliance on a large number of decisions before us to
contend that Rule 18 of Order XXVI is mandatory. We, however, need not advert to
the said decisions as atleast seven out of eight plaintiffs contend before us that they
did not have notice of bidding. None of the plaintiffs have been shown to have bid forGalatea Ltd. Through Authorised ... vs M. Kantilal Exports on 29 April, 2022

any of the three properties. It is unlikely that they would stay out even if they had
notice and allowed the defendants to bid behind their back. Sheema Dudhoria
evidently had been supporting the defendants. Even the learned Single Judge
recorded that she had given instructions to support the case of the defendants. Such a
notice was also necessary as in tion each party has an individual right. One of them
atleast is siding with the defendants. Even the plaintiffs admittedly had received
payment in part. Even the defendants did not offer the bid jointly. Defendant No.2 in
his individual capacity had offered his bid in one of the properties in his individual
name and only with defendant No.3 in respect of one of the properties.
70. It must also be placed on record that the High Court in its order dated 10th
March, 1997, categorically directed the C/SCA/2588/2020 CAV JUDGMENT
DATED: 29/04/2022 Commissioner of Partition to give at least 7 days' clear notice to
the parties before holding any such meeting so as to enable them to be present
personally or through their advocates. Issuance of such a notice was imperative in
character."
29. Again this court in Special Civil Application No. 110186 of 2012 (Hon'ble Mr. Justice GR
Udhwani, J.) has observed in para 12, 13 and 14 as under:
"12. Under O.26 R.9 what is required to be elucidated is a matter in issue and if
development takes place subsequently in relation to the subject matter of the suit
during the pendency of the suit which has relevance to the subject matter of the suit,
it can be said that even that development is a matter in issue, because finally the
rights and liabilities of the parties can be determined also on the basis of such
subsequent development. The trial Court mentioned in the impugned order the fact
that it has considered the contents of the application Exhibit-21, therefore, it cannot
be said that the trial Court was not conscious of the fact that for what the
Commission was being appointed. It is not necessary for the Court to elaborately
mention the reasons once it notes that it was convinced by the facts mentioned in the
application itself. Therefore, the argument that the Court did not come to the
conclusion as required under O.26 R.9 has no merits. Consequently, the argument
that the Court merely reasoned that no prejudice is going to be caused if the
commission is appointed also has no merits.
13. It is true that there is already a report on record of the Court with regard to
disputed property. But, that report was before the demolition took place and
therefore it cannot be said that on the same subject another Commission was being
appointed. If the condition of the land subsequent to demolition is brought on record,
it cannot be said that the respondents will be able to establish their possession
through such local inspection. Therefore, the argument that the intention of the
respondents is to collect the evidence and nullify the documents showing handing
C/SCA/2588/2020 CAV JUDGMENT DATED: 29/04/2022 over of the possession of
the suit property to the petitioner also has no merits.Galatea Ltd. Through Authorised ... vs M. Kantilal Exports on 29 April, 2022

14. It is, however, true that the Courts would not issuing Commission for recording
possession of a particular party. Therefore while dismissing this petition it is required
to be clarified that the Commissioner would not record anything which will assist the
respondents in establishing their possession before the trial Court or appellate
Court."
30. This Court in Special Civil Application No. 11890 of 2020 (Hon'ble Mr. Justice, A. Y. Kogje, J.)
has observed in Para 11, 14, 37 and 39 as under:
"11. The act on the part of the respondent Nos.4 and 5 is the act of suppression of
material facts and amounts to playing fraud with the Court in getting the order
passed below Exh7 passed in their favour. When the suppression and fraud was
brought on the record of the Court by an application Exh-10, the Civil Judge ought to
have considered such aspect. However, the Civil Judge as who has not taken into
consideration such aspect in correct perspective and without assigning any reasons,
has rejected an application Exh-10.
14. It is submitted that under Order-26 Rule-9 of the Code of Civil Procedure, which
pertains to the issue of drawing the panchnama does not put any other restriction or
even the Notice to the parties to be heard before passing of such order. It is submitted
that the only requirement under the law is that the intimation to the concerned
parties about the details regarding carrying out of the panchnama like the name,
time, etc.
37. The Court is of the view that at each stage of the suit, the litigant coming to the
Court, has to come with clean hands, it is not the case where the previous panchnama
was drawn was C/SCA/2588/2020 CAV JUDGMENT DATED: 29/04/2022 behind
back of the respondent Nos.1 to 5 or that they were unaware of drawing of such
panchnama and were therefore, precluded from bringing this aspect to the notice of
the Civil Judge in Special Civil Suit No.96 of 2020. The Court is also of the view that
had this aspect been brought to the notice at the stage of passing the Order below
Exh-7, then such material would have been of some relevance before passing of the
Order. Therefore, the Order below Exh-10, the Civil Judge has committed
jurisdictional error in not recalling the Order which was based on the suppression of
material fact.
39. Such reasons cannot be also justified as the Court is of the opinion that pending
the Special Civil Suit No.212 of 2019, there is an attempt on the part of the parties to
the suit in changing the status of the land in planned manner and filing of Second
Suit so as to create the evidence with regard to the possession of the suit land which
in the subsequent suit is now claimed by the respondent Nos.4 and 5 and to
substantiate such claim and pleadings, an application for drawing the panchnama
was made and ordered. This would amount to giving premium to the wrong."Galatea Ltd. Through Authorised ... vs M. Kantilal Exports on 29 April, 2022

31. In the present case, admittedly after passing the order by this court on 29.01.2020 issuing local
commissioner ex-parte against the respondent, it was mandatory for the court commissioner under
Order 26 Rule 18 of the Code to issue notice to the concerned parties. In the present case, no notice
of commission was issued to the respondent herein and petitioners alongwith its senior officials
entered into the premises of the respondent. It must be remembered that Rule 10(2) of Order 26 of
the code makes the report of the C/SCA/2588/2020 CAV JUDGMENT DATED: 29/04/2022
Commissioner evidence in the suit. Therefore, it is of importance that the report should not be
founded on representation made to the Commissioner or on matters brought to his notice by one
party to the suit alone. In fact, it is so manifestly improper that one party to a suit should be given a
commission and the advantage of a report by the Commissioner without the knowledge of the
opposite party. This Court is satisfied to interfere in the present proceedings so far admissibility of
the report submitted by the Court Commissioner.
32. It is principle of natural justice that it is only evidence taken in the presence of the party that can
be used against him. It appears that Order 26 Rule 18 contemplates that opportunity to be given to
the party to be present before the commissioner in the property at the time of investigation.
33. Even apart from the principles underlying order 26 Rule 18 of the Code, said provisions also is
imperative in nature. The presence of the parties is considered imperative by the very provision
contained in Order 26 Rule 18 of the Code. Consequently, non observance of the provision contained
in Order 26 Rule 18 will not justify reception of the report as part of the evidence under Order 26
Rule 10 Sub Rule 2 of the code.
34. It is not necessary for this court to deal in detailed C/SCA/2588/2020 CAV JUDGMENT
DATED: 29/04/2022 regarding he conduct of the court commissioner to part a view under Rule 18
of Order 26 of the Code, there cannot be any doubt arisen that commissioner should have issued
notice to all the parties.
35. It further appears from the record that the petitioners have received the report of the court
commissioner and they are in possession of the said report. No direction was issued by this court to
handover a copy of the report by the court commissioner to the present petitioners. The petitioners
have not disclosed before the court commissioner about pasing the order dated 3rd March 2020/4th
March 2020, this court has directed that court commissioner's report be kept in the custody of Nazir
and if same is required by the learned trial court then petitioners may approach the trial court which
would then decide the application in accordance with law.
36. Certain papers were produced by the petitioners during the course of hearing purporting to be of
an application supposedly made on 05.03.2020 for calling of the court commissioner's report
submitted to this Court. The said application preferred by the petitioner is still pending and not
heard by the court below, and however, report of the court commissioner is available with the
petitioners and in their possession. Further, it appears from the record that in total 11
C/SCA/2588/2020 CAV JUDGMENT DATED: 29/04/2022 sealed covers, court commissioner's
reports were sent to this court on 21st September 2020 to be kept in a custody of Nazir. Further,
there is no provisions of law much less under Order 26 Rule 10 of the Code that the copy of the courtGalatea Ltd. Through Authorised ... vs M. Kantilal Exports on 29 April, 2022

commissioner's report may be given to the parties against the directions of the court. It is supersized
that however, there was no direction issued by this court while passing an order on 29.01.2020 then
as to how and why such report is available into the hands of the petitioners.
37. It further appears from the record that after completion of the inspection of the premises of the
respondent by the court commissioner, the petitioners purposely circulated disparaging/defaming
articles regarding the respondent which featured in prominent trade magazines stating that the
respondent is carrying out infringing activities. Such deliberate acts of spreading and disparaging
information only shows that the petitioners are desperate and are trying their level best to damage
the goodwill of the respondent.
38. From the averments made in the plaint by the petitioners before the trial court, it appears that
there was no specific averments as to any particular product or model of the respondent which
allegedly infringes its rights under the Patent Act. As submitted by the respondent, application
dated C/SCA/2588/2020 CAV JUDGMENT DATED: 29/04/2022 21.02.2008 of the petitioners
under the Patent Application No. 876/CHENP/2008 was rejected vide order dated 13.10.2020
under Section 15, 25(1) of the Indian Patent Act, 1970 and appeal is pending before the Intellectual
Property Appellate Board. Another Patent Application No. 1606/MUMNP/2009 with PCT
Application No. PCT/IL2008/00032 was granted as Indian Patent No. 271425 on the basis of
priority of its Israel Patent Application No. 181484. As per the submissions of the respondent, this
Israel Patent Application No. 181484 was abandoned way back on 28.10.2010.
39. Learned advocate for the petitioners in support of his arguments has relied upon the judgments
passed by this Court in Special Civil Application No. 11240 of 2017 (Hon'ble Mr. Justice CL Soni, J.)
wherein ex-parte order was passed for appointment of court commissioner for local inspection for
the purpose of inventory of the chicaneries/devices at the premises of the respondents No. 1 to 12.
40. In another matter, Hon'ble Delhi High Court in case of Anant Construction (P) Limited v. Ram
Niwas, held that there was a question to be decided under order 6 read with order 8 of the Code
wherein it was observed that defendant has to specifically deny everything-every material averment
in written statement is presumed to be denied by the plaintiff and C/SCA/2588/2020 CAV
JUDGMENT DATED: 29/04/2022 for that purpose, he need not file a replication. In the present
case there is no question of under Order 6 or order 9 of the code.
41. In another case, Hon'ble High Court of Bombay at Goa, in Writ Petition No. 210 of 2015, in case
of UTV Motion Pictures and Ors v. Murphy Enterprises and Ors., there was a question under Order
6 Rule 14 of the Code, which clearly provides for pleadings shall mean plaint or written statement
containing of an affidavit in reply or rejoinder could not partake or nature of pleadings within
meaning of Order 6 Rule 1 of the Code.
Here also, facts of the cited case is quite different from the present case.
42. In another case, Hon'ble High Court of Andhra Pradeh in Second Appeal No. 511 of 2008, in
case of K. Sajjan Raj v. Gopisetty Chandramouli, same dispute of pleadings of written statement wasGalatea Ltd. Through Authorised ... vs M. Kantilal Exports on 29 April, 2022

involved. It was held therein that non filing of any answer by plaintiff to specific pleading of
defendant that there was fresh lease or renewal of lease could not be taken as admission made by the
plaintiff. Further, except self-serving statement of defendant, there was no iota of evidence to show
that there was oral agreement between plaintiff and defendant extending lease for another period of
C/SCA/2588/2020 CAV JUDGMENT DATED: 29/04/2022 20 years. However, defendant was in
possession of the property as lessee and it was not in dispute that plaintiff had issued quit notice and
inspite of receiving said notice, defendant did not vacate the premises. Therefore, it was held that
though the defendant had taken specific plea in his written statement and even if same was not
denied by way of filing rejoinder or additional written statement by plaintiff, same did not amount
to admission and appeal was dismissed.
43. In another case, Hon'ble High Court of Madras in Appeal No. 187 of 1967, in case of
Veerasekhara Varmarayar v. Amirthavalliammal and Ors, the issue is relating to Section 6
Explanation 1 of the Hindu Succession Act. In this case, death of coparcener leaving behind him
heirs mentioned in Section. Share of deceased notionally separated from date of his death from joint
family. It was held that Manager cannot represent heirs of deceased and deal with their interest.
Here the facts are completely contrary to the facts of this case.
44. In another case, this Court in Writ Petition (PIL) No. 42 of 2020 Civil Application Nos. 6, 8, 9,
10 and 11 of 2020 in case of Suo Motu v. State of Gujarat and Ors, it was a case of health issue and
opening of hospitals/clinics and relates to arrangements made with private hospitals for treatment
of Covid 19 patients. It was held that private C/SCA/2588/2020 CAV JUDGMENT DATED:
29/04/2022 clinics/hospitals/nursing homes closed by their owners/management. State
Government directed to ensure that all such private clinics/hospitals/nursing homes are
immediately opened up. It was further directed to make supplement health facilities available to non
Corona patients at large. The issue is not related to the present case.
45. In another case relied upon by the petitioners in Special Leave Petition (Civil) No. 2725 of 1988
in case of Union of India (UOI) and Ors. v. E. Bashyan, raising question of mega importance viz.
Whether failure to supply a copy of th report of the Enquiry Officer to the delinquent before the
Disciplinary Authority, makes up his mind and records the finding of guilt as against him would
constitute violation of Article 311(2) of the Constitution of India and violation of principles of
natural justice. The issue decided by Hon'ble Supreme Court of India in the cited case is not related
to the present case.
46. The Hon'ble Supreme Court of India in Civil Appeal No. 8285 of 2009 in the case of Ram Lal
and Ors v. Salig Ram and Ors, wherein it is the case of encroachment/demarcation of land. Suit of
the plaintiff was dismissed as well as Appeal. High Court was justified in setting aside decree of First
Appellate Court on the ground that Local Commissioner had C/SCA/2588/2020 CAV JUDGMENT
DATED: 29/04/2022 not carried out demarcation in accordance with applicable instructions. If the
report of the court commissioner was suffering from want of compliance of applicable instructions,
what course was to be adopted by High Court. In this judgment, Hon'ble Supreme Court has held in
para 5 as under:Galatea Ltd. Through Authorised ... vs M. Kantilal Exports on 29 April, 2022

"5. If report of Local Commissioner was suffering from on irregularity ie., want of
following applicable instructions, proper course for High Court was either to issue a
fresh commission or to remand matter for reconsideration but entire suit could not
have been dismissed for any irregularity on part of Local Commissioner. Plaintiffs
had been asserting encroachment by defendants on their land and had also adduced
oral and documentary evidence in that regard. First Appellate Court had allowed
appeal and decreed suit filed by plaintiff not only with reference to Commissioner's
report but also with reference to other evidence of parties. High Court appeared to
have overlooked other evidence on record."
47. From the record, court commission appointed by this court vide order dated 29.01.2020 has not
followed the provisions of the Code and has not issued any notice to the respondent before coming
to the premises of the respondent. The court commissioner has acted beyond what was directed by
this Court and has provided a copy of the report of the commissioner was never allowed to be parted
with as it was ordered to be kept in sealed cover with the Nazir of the court.
48. The fact that local commissioner's report and for that matter a properly drawn up report, is
requisite in the C/SCA/2588/2020 CAV JUDGMENT DATED: 29/04/2022 present case for the
purpose of elucidating the matter in dispute is not of any debate. The order dated 29.01.2020 passed
by this Court having attained finality as it was not challenged by the respondent.
49. In the given issue and circumstances, this court is of the view that if the report of the local
commissioner is suffering from irregularity ie. want of following applicable instructions and
mandatory provisions of the Code, the proper course for this Court would be either to issue a fresh
commission or to remand the matter for reconsideration.
50. For just and effectual determination of all questions involved in the matter, reports submitted by
the court commissioner shall be discarded by the court below and fresh commission shall be issued
by the trial court as per the order dated 29.01.2020 following requisite provisions of the Code.
51. After taking report of the local commissioner afresh and affording an opportunity to the parties
to submit their objections, if any, trial court to decide the suit in accordance with law.
With these observations, all the four petitions are disposed of.
(B.N. KARIA, J) C/SCA/2588/2020 CAV JUDGMENT DATED: 29/04/2022 FURTHER ORDER:
Learned advocate for the petitioners has requested to suspend the judgment and
order passed by this court today.
Learned advocate for the respondent has strongly objected the same and submitted
that this court has directed to issue fresh commission, and therefore, there is no need
to suspend the judgment and order passed by this court today.Galatea Ltd. Through Authorised ... vs M. Kantilal Exports on 29 April, 2022

Considering the peculiar facts of the case and the submissions made by learned
advocates for the respective parties and as the fact remains that this court has
discarded the reports of the local commissioner and directed to issue fresh local
commission, request of learned advocate for the petitioner cannot be accepted by this
court and hence, his prayer of suspending the judgment and order is hereby rejected.
(B.N. KARIA, J) K. S. DARJIGalatea Ltd. Through Authorised ... vs M. Kantilal Exports on 29 April, 2022

