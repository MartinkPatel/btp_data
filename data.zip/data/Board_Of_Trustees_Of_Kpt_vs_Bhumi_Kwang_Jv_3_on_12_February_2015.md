Board Of Trustees Of Kpt vs Bhumi - Kwang Jv & 3 on 12
February, 2015
Author: Akil Kureshi
Bench: Akil Kureshi, Sonia Gokani
          C/FA/1914/2014                                       JUDGMENT
           IN THE HIGH COURT OF GUJARAT AT AHMEDABAD
                       FIRST APPEAL NO. 1914 of 2014
                                   With
                     CIVIL APPLICATION NO. 6442 of 2014
                                    In
                       FIRST APPEAL NO. 1914 of 2014
FOR APPROVAL AND SIGNATURE:
HONOURABLE MR.JUSTICE AKIL KURESHI
and
HONOURABLE MS JUSTICE SONIA GOKANI
=================================================
1    Whether Reporters of Local Papers may be allowed to see the
     judgment ?
2    To be referred to the Reporter or not ?
3    Whether their Lordships wish to see the fair copy of the judgment ?
4    Whether this case involves a substantial question of law as to the
     interpretation of the Constitution of India, 1950 or any order made
     thereunder ?
5    Whether it is to be circulated to the civil judge ?
=================================================
                  BOARD OF TRUSTEES OF KPT....Appellant(s)
                                 Versus
                    BHUMI - KWANG JV & 3....Defendant(s)
=================================================
Appearance:
MR RS SANJANWALA, SR. ADV. with MR DHAVAL D VYAS, ADVOCATE for the
Appellant(s) No. 1
MR SN SOPARKAR, SR. ADV. with MR UTKARSH B JANI, ADVOCATE for theBoard Of Trustees Of Kpt vs Bhumi - Kwang Jv & 3 on 12 February, 2015

Defendant(s) No. 1
RULE SERVED BY DS for the Defendant(s) No. 1 - 4
=================================================
           CORAM: HONOURABLE MR.JUSTICE AKIL KURESHI
                  and
                  HONOURABLE MS JUSTICE SONIA GOKANI
                          Date : 12/02/2015
                          ORAL JUDGMENT
(PER : HONOURABLE MR.JUSTICE AKIL KURESHI)
1. This appeal is filed by the board of trustees of Kandla Port Trust (hereinafter referred to as "KPT")
challenging the judgment dated 31.5.2014 passed by the C/FA/1914/2014 JUDGMENT learned
Additional District Judge, Gandhidham at Kachchh in Civil Miscellaneous Application (Arbitration
Petition) No.12 of 2014 filed by respondent No.1 herein. By such judgment and order the learned
Judge partly allowed the application of respondent No.1 restraining KPT from encashing various
bank guarantees given by the said respondent drawn from three different banks. While doing so, the
trial Court directed the said respondent to periodically renew such bank guarantees till the decision
of the arbitrator is rendered.
2. The facts are as under:-
2.1 Appellant KPT is the trust constituted under the provisions of the Major Port
Trust Act, 1963 and undertakes and regulates various port related activities in the
area of Kandla port in exercise of powers contained under the said Act. Respondent
No.1 is a joint venture of Bumi Geo Engineering Limited and Pembinaan Kwang Sdn
Bhd. (hereinafter referred to as "Bumi"). Respondents No.2 to 4 are different banks.
3. KPT awarded a contract to Bumi for the purpose of modification and strengthening
of existing cargo C/FA/1914/2014 JUDGMENT berths at Kandla. Work order for
such purpose was issued on 10.2.2012 and envisaged the contract period of 30
months. The entire work, therefore, had to be completed by 9.8.2014. We may take
note of salient relevant features of the terms of this contract from the copy of the
tender documents. The estimated contract value was Rs.200 crores (rounded off).
The period of completion of the work was 30 months. The agency to whom the
contract would be awarded had to provide performance security in terms of clause
1.34 of the tender document, which reads as under:-
"1.34 Performance Security Security deposit shall consist of two parts;a) Performance
Guarantee to be submitted at award of work, and b) Retention money to be recovered
from Running Bills.
1.34.1 Performance Guarantee should be 10% of Contract price of which 5% of
contract price should be submitted as Bank Guarantee within 21 days of receipt ofBoard Of Trustees Of Kpt vs Bhumi - Kwang Jv & 3 on 12 February, 2015

letter of acceptance and balance 5% recovered as Retention Money from Running
Bills. Recovery of 5% of Retention Money to commence from the first bill onwards @
5% of bill value from each bill. Retention money be refunded within 14 days from the
date of payment of final bill. Balance SD to be refunded immediately not later than 14
days from completion of defect liability period. 1.34.2 Failure of the successful Bidder
to comply with the requirements of Sub-Clause 1.34.1 shall constitute sufficient
grounds for cancellation of the award of work and forfeiture of the Bid security.
         C/FA/1914/2014                                          JUDGMENT
3.1         As    per       this      condition,           therefore,       the
contractor, would have to give performance guarantee to the tune of 10% of the
contract price. 5% of such guarantee would come in the form of bank guarantee and
the balance 5% would be recovered as retention money from the running bills of the
contractor. Such recovery would be by way of retention of 5% of the value of the bill
and would commence from the first bill itself. Such retention money would be
refunded within 14 days from the date of payment of final bill.
4. It is undisputed that Bumi supplied such bank guarantee of Axis Bank Limited
dated 2.2.2012 for a sum of Rs.9,79,47,325/- against "any loss or damage caused to or
which would be caused to or suffered by the Board by reason of any breach by the
contractors of any of the terms and conditions of the said contract".
5. In such bank guarantee the Axis Bank further agreed as under:-
"2. We, Axis Bank Ltd. Corporate Banking Branch, Ground Floor, Karumuthu
Nilayam, No.192, Anna Salai, Chennai-600 002, do hereby undertake to pay the
amounts due and payable under this guarantee without any demur merely on a
demand from the Board stating that the C/FA/1914/2014 JUDGMENT amount
claimed is due by way of loss or damage caused to or which would be caused to or
suffered by the Board by reason of any breach by the Contractors of any of the terms
and conditions of the said contract or by reason of the Contractors failure to perform
the said contract. Any such demand made on the Bank shall be conclusive as regards
the amount due and payable by the Bank under this Guarantee. However, our liability
under this guarantee shall be restricted to any amount not exceeding
Rs.9,79,47,325/- (Rupees Nine Crore Seventy Nine Lakh Forty Seven Thousand and
Three Hundred and Twenty Five only).
3. We Axis Bank Ltd, undertake to pay to the Board any amount so demanded
notwithstanding any dispute or disputes raised by the Contractor(s) in any suit orBoard Of Trustees Of Kpt vs Bhumi - Kwang Jv & 3 on 12 February, 2015

proceedings pending before any court or Tribunal relating thereto our liability under
this present being absolute and unequivocal. The payment so made by us under this
bond shall be a valid discharge of our liability for payment there under and the
contractor(s) shall have no claim against us for making such payment."
6. Under clause 1.35 of the tender document it was envisaged that KPT would make advance
payment to Bumi as per the conditions stipulated in clause 3.51 of section 3. Clauses 3.51 and 3.52
read as under:-
"3.51 ADVANCE PAYMENTS The Employer shall make the following advance
payments:
3.51.1 Mobilisation Advance shall be paid upto 10% of Contract price, payable in two
equal instalments. The first instalment shall be paid after mobilisation has started
and next instalment shall be paid after satisfactory utilisation of earlier advance.
     3.51.2    Construction/ installation equipment
   C/FA/1914/2014                      JUDGMENT
Advance shall be paid upto 5% of Contract price.
3.51.3 Mobilisation Advance and Construction Equipment Advance shall be paid at
SBI PLR + 2% p.a.(as on date of payment) interest at the discretion of Employer and
against Bank Guarantee for such Advance and against hypothecation of Construction
Equipment to the Employer. However, availing of advance payment be optional with
the bidder exercising the option along with the tender.
3.51.4 Equipment advance shall be paid in two or more equal instalments. First
instalment shall be paid after Construction equipment has arrived at the site and next
instalment shall be paid after satisfactory utilisation of earlier advance (s).
3.51.5 Recovery of Mobilisation and Construction Equipment advance will start when
15% of the work is executed and recovery of total advance should be completed by the
time 80% of the original work is executed. 3.51.6 The Nodal Officer or his nominee
shall make advance payment in respect of materials and plant brought to site for but
not yet incorporated installed in the Works in accordance with conditions stipulated
in the Contract Data.
75% of cost of materials and plant brought to site for incorporation into the works only shall be paid
as secured advance. Materials which are of perishable nature should be adequately insured 3.51.7Board Of Trustees Of Kpt vs Bhumi - Kwang Jv & 3 on 12 February, 2015

Mobilisation advance shall be paid on production of Bank Guarantee of 110% of Payment of
Advance."
3.52 Performance Securities 3.52.1 Security deposit shall consist of two parts:
(a) Performance security to be submitted at award of the work.
(b) Retention money to be recovered from C/FA/1914/2014 JUDGMENT Running
Bills.
3.52.2 Performance Guarantee should be 10% of Contract price of which 5% of contract price should
be submitted as Bank Guarantee or demand draft within 21 days of receipt of letter of acceptance
and balance 5% recovered as Retention Money from Running Bills. Recovery of 5% of Retention
Money to commence from the first bill onwards @ 5% for each bill.
Retention Money be refunded within 14 days from the date of payment of final bill. Balance SD to be
refunded immediately not later than 14 days from completion of defect liability period."
7. KPT would thus provide mobilisation advance upto 10% of the contract price in two equal
installments to the contractor. First installment would be released after mobilisation has started and
the next installment would be paid after satisfactory utilization of earlier advance. Such mobilisation
advance would be recovered after 15% of the work is executed in such a manner that the total
advance would be recovered by the time 80% of the contract work is executed. To secure KPT
against mobilisation advance, the contractor in terms of clause 3.51.3 would provide bank guarantee
for such advance.
8. First installment of the mobilisation advance was released by KPT in favour of Bumi against four
separate bank guarantees, each dated 17.4.2012 for a C/FA/1914/2014 JUDGMENT sum of
Rs.2,69,35,514/- issued by ICICI Bank Limited. Under such bank guarantees, the ICICI Bank
Limited agreed as under:-
"Furthermore, we understand that, according to the condition of the contract, an
advance is to be made against an advance payment guarantee.
At the request of the contractor, we hereby irrevocably undertake to pay you any sum
or sums not exceeding in total an amount of Rs.2,69,35,514/-(Rupees Two Crore
Sixty Nine Lakh Thirty Five Thousand Five Hundred and Fourteen only) upon receipt
by us of your first demand in writing declaring that the contractor is in breach of its
obligation under the contract because the contractor used the advance payment for
the purpose other than for the purpose intended.
It is a condition for any claim and payment under this Guarantee to be made that the
advance payment referred to above must have been received by the contractor"Board Of Trustees Of Kpt vs Bhumi - Kwang Jv & 3 on 12 February, 2015

9. Likewise, second installment of mobilisation advance was released by KPT against four bank
guarantees each dated 25.7.2012 for identical sums of Rs.2,69,35,514/- drawn on ING Vysya Bank
Limited. The said bank under the bank guarantee, agreed as under:-
"Furthermore, we understand that, according to the condition of the contract, an
advance is to be made against an advance payment guarantee.
At the request of the contractor, we hereby irrevocably undertake to pay you any sum
or sums not exceeding in total an amount of Rs.2,69,35,514/-( Rupees Two Crore
Sixty Nine Lakh Thirty Five Thousand and Five Hundred and Fourteen only) upon
receipt by us of your first C/FA/1914/2014 JUDGMENT demand in writing declaring
that the contractor is in breach of its obligation under the contract because the
contractor used the advance payment for the purpose other than for the purpose
intended.
It is a condition for any claim and payment under this Guarantee to be made that the
advance payment referred to above must have been received by the contractor."
10. Thus, the total sum of Rs.19,58,94,648/- was released by way of mobilisation advance by KPT in
two installments.
11. Contract envisaged liquidated damages in terms of clause 3.49, relevant portion of which, reads
as under:-
"3.49 Liquidated damages 9A In-case of delay in completion of the contract,
liquidated damages (L.D) May be levied at the rate of 1/2% of the contract value per
week of delay or part thereof, subject to a maximum of 10 per cent of the contract
price.
9A(i) The owner, if satisfied, that the works can be completed by the contractor
within a reasonable time after the specified time for completion, may allow further
extension of time at its discretion with or without the levy of L.D. In the event of
extension granted being with LD, the owner will be entitled without prejudice to any
other right or remedy available in that behalf to recover from contractor as agreed
damages equivalent to half per cent (1/2%) of the contract value of the works for each
week or part of the week subject to the ceiling C/FA/1914/2014 JUDGMENT defined
in sub-clause 3.49 9(A)."
12. Clause 3.59 envisaged termination of contract under certain circumstances. As per clause 3.59.1
"Either the employer or the contractor could terminate the contract if the other party causes a
fundamental breach of the contract." Clause 3.51.2 listed several breaches which would be
considered as fundamental breaches but clarified that the list is not meant to be exhaustive. This
included a situation where the contractor stops work for 28 days when no stoppage of work is shown
on the current programme and the stoppage has not been authorised by the Nodal Officer. It alsoBoard Of Trustees Of Kpt vs Bhumi - Kwang Jv & 3 on 12 February, 2015

included sub-clause (g) which provided " the contractor has delayed the completion of works by the
number of days for which the maximum amount of liquidated damages can be paid as defined in the
contract data"
13. Clause 3.59.5 provided that if the contract is terminated, the contractor shall stop work
immediately, make the site safe and secure and leave the site as soon as reasonably possible.
14. Clause 3.60 pertained to payment upon termination C/FA/1914/2014 JUDGMENT and read as
under:-
"3.60 Payment upon Termination.
3.60.1 If the contract is terminated because of a fundamental breach of contract by
the contractor, the Nodal Officer or his nominee shall issue a certificate for the value
of the work done less advance payments received upto the date of the issue of the
certificate, less other recoveries due in terms of the contract, less taxes due to be
deducted at source as per applicable law and less the percentage to apply to the work
not completed as indicated in the contract data. Additional Liquidated Damages shall
not apply. If the total amount due to the Employers exceeds any payment due to the
Contractor, the difference shall be payable to the Employer.
3.60.2 If the contract is terminated at the employer's convenience or because of a
fundamental breach of the contract by the employer, the Nodal Officer or his
nominee shall issue a certificate for the value of the work done, the reasonable cost of
removal of equipment, repartition of the contractors personnel employed solely on
the works, and the contractor's costs of protecting and securing the works and loss of
profit on uncompleted works less advance payments received up to the date of the
certificate, less other recoveries due in terms of the contract and less taxes due to be
deducted at source as per applicable law."
15. During the process of execution of contract, multiple disputes arose between the parties.
According to KPT the work progress by Bumi was extremely slow and unsatisfactory. According to
KPT during the contract period, barely 7% of the work was completed C/FA/1914/2014 JUDGMENT
solely on account of slow progress and defaults on the part of Bumi. Bumi, of course, is unable to
dispute that very little work was actually done, but blames KPT and other external factors for
slowness in the work.
16. On 29.6.2012, KPT wrote to Bumi referring to earlier correspondence between the parties
pointing out that the work progress was extremely slow and disputed that such slow progress was on
account of the defaults by KPT. In such letter, KPT highlighted the factors which would go to show
that the slow progress was "because of poor planning, poor management" on the part of Bumi. It
was suggested that the progress achieved was extremely slow and work was lagging behind. The
progress was not hampered even for a single day for want of drawings but it was on account of poor
planning and management on the part of Bumi. Required manpower had not been arranged. TheBoard Of Trustees Of Kpt vs Bhumi - Kwang Jv & 3 on 12 February, 2015

work of labour colony was also not satisfactory. Cement sheds had not been constructed. Skilled
workers for preparing reinforcement cages had not been deployed in sufficient strength.
Dismantling work was not progressing at all since many days. It was asserted C/FA/1914/2014
JUDGMENT that KPT had ensured that each and every detail was furnished in time as and when
required and that the work had not been delayed even for a single day for want of handing over of
drawings, details etc. It was further suggested that:-
"The stage has reached when drastic steps are required to be taken, to ensure the
requisite progress of work and also further steps to compensate for the time lost till
date. If no serious efforts are taken even now, it shall not be possible to complete the
work in the scheduled time period. It is to bring to your notice that clause no.3.49(A)
of the conditions of contract stipulates liquidated damages levy of compensation for
delay in execution of work at the rate of ½% per week."
17. On 4.4.2013 KPT wrote to Bumi once again pointing out that the work progress was extremely
slow and that the reasons were attributable to Bumi. It was lastly conveyed as under:-
"In view of the above, please explain us that how you will be able to recoup existing
abnormal delay and boost up the progress of the work and complete the same well
within the time schedule, failing which you would not liable yourself; to seek any
extension of time limit and also to avoid the imposition of penalty i.e. Liquidated
Damage and initiation of any other action as per the relevant clauses(s) of the
contract."
18. On 14.2.2014 KPT issued a notice stating that by the reason of wrongful delay and slow progress
by C/FA/1914/2014 JUDGMENT Bumi, the work entrusted would not be completed within the
stipulated date of 9.8.2014. Bumi was given time of 15 days to show cause why action, under clauses
3.49 and 3.59.1 of the tender pertaining to termination of the contract should not be taken. Such
termination was based on the following breaches listed by KPT in the said letter:-
"a) As per section IV, which deals with "CONTRACT DATA", you failed to complete
300 mtrs length in all respect within 10 months from the date of issue of work order
No.EG/WK/4737-II/458 dt 10.02.2012.
b) Though, you had promised, vide your letter No.BK-JV/KPT/C-01/2012-13/192
dated 20.03.2013, to complete the four panels i.e. 48 to 51 in all respect and
handover the same to the Port Trust latest by 31.05.2013. However, you have been
failed to complete the same during the mutually agreed time.
c) Please note that in case no cause is shown by you within the stipulated period or
the cause shown is not to my satisfaction, I shall take such actions against you as are
contemplated under Clause No.3.49.9A (III) and clause No.3.59.1 and sub clauses
there under of the said contract and/or other clauses thereof without further Notice."Board Of Trustees Of Kpt vs Bhumi - Kwang Jv & 3 on 12 February, 2015

19. In view of such strained relations and inter alia on the premise that the contractor would be
under no capacity to complete the work and it would not be possible for KPT to recover the advances
and losses, KPT sent communications to the concerned banks for C/FA/1914/2014 JUDGMENT
invocation of the bank guarantees. On 18.2.2014 KPT wrote to ING Vysya Bank Limited and invoked
four bank guarantees in the following manner:-
" It is hereby informed that M/s. Bumi Kwang(JV) New Delhi has been given total
amount of Rs.9,79,47,324/-(Rs. Nine Crores Seventy nine lacs forty seven thousand
Three hundred twenty four) as mobilization advance against above said bank
guarantees as per contract condition.
Clause 3.51 of conditions of contract provides that recovery of mobilization advance
shall start when 15% of work is executed and full advance shall be recovered by the
time 80% of work is completed. However, M/s. Bumi Kwang(JV) has completed
approx.6% of work as against 78% of target till 31.12.2013, and the execution of work
has been stopped by the contractor since 01.01.2014.
The slow progress & stoppage of work has resulted into breach of contract condition
no.3.51- Advance payments and attracted clause 3.59 i.e.- termination of contract.
You are therefore requested to arrange encashment of above said Bank Guarantee
and the encashed amount may be sent by Demand Draft in favour of Financial
Advisor and Chief Accounts Officer, Kandla Port Trust, payable at Gandhidham
without any delay.
An immediate action in the above matter is solicited and will be highly appreciated."
20. Likewise, on 21.2.2014, KPT wrote to ICICI Bank Limited and invoked four bank guarantees,
noted above, in following terms:-
"The Contractor has given Advance payment in against of above said Bank
Guarantees. The C/FA/1914/2014 JUDGMENT Contractor has received advance
payment.
It is here by declared that, the contractor is in breach of its obligation under the
contract because the contractor used the advance payment for the purpose other than
for the purpose intended.
Hence, it is once again requested to arrange encashment of above said Bank
Guarantee and the encashed amount may be sent by Demand Draft in favour of
Financial Advisor and Chief Accounts Officer, Kandla Port Trust, payable at
Gandhidham without any delay."Board Of Trustees Of Kpt vs Bhumi - Kwang Jv & 3 on 12 February, 2015

21. On 27.3.2014 KPT invoked the bank guarantees of Axis Bank Limited for performance guarantee
as under:-
" Your attention is invited to Clause No.02 of the above said Bank Guarantee-"We,
Axis Bank Ltd., Corporate Banking Branch, Ground Floor, Karumuthu Nilayam,
No.192, Anna Salai, Chennai- 600 002, do hereby undertake to pay the amounts due
and payable under this guarantee without any demur merely on a demand from the
Board stating that the amount claimed is due by way of loss or damage caused to or
which would be caused to or suffered by the Board by reason of any breach by the
contractors of any of the terms and conditions of said contract or by reason of the
Contractors failure to perform the said contract. Any such demand made on the Bank
shall be conclusive as regards the amount due and payable by the Bank under this
Guarantee"
It is hereby declared that the contractor is in breach of the obligations under the contract as per the
clause stipulated above because the contractor has failed to abide by the terms and conditions of
contract which have been mutually agreed as per the agreement executed by the party and the Board
of Trustees of Port of Kandla.
Kandla Port therefore invokes the above mentioned Bank Guarantee and requests that the
C/FA/1914/2014 JUDGMENT amount may be sent in favour Financial Advisor & Chief Accounts
Officer Kandla Port Trust, payable at Gandhidham, without any delay."
22. It appears that in the first letter to ING Vysya Bank Limited dated 18.2.2014, KPT had not used
certain expressions for invocation of bank guarantee. To bring in tune with the bank guarantee
document, KPT issued further letter to the said bank on 27.3.2014 once again invoking the bank
guarantee in following terms:-
"In continuation of the above referred letter issued by this office for encashment of
Bank Guarantees provided by you in favour M/s. Bumi Kwang (JV) New Delhi.
The contractor has been given Advance payment against above said Bank
Guarantees. The Contractor has already received advance payment.
It is hereby declared that, the contractor is in breach of its obligation under the
contract because the contractor used the advance payment for the purpose other than
for the purpose mentioned.
It is requested invocation of Bank Guarantees in favour of Kandla Port Trust."
23. Likewise, fresh communication was issued to ICICI Bank Limited by KPT also on 27.3.2014
repeating invocation of the bank guarantee in following terms :-Board Of Trustees Of Kpt vs Bhumi - Kwang Jv & 3 on 12 February, 2015

" In continuation of the above referred letter issued by this office for invocation of
Bank Guarantees provided by you in favour M/s. Bumi Kwang (JV) New Delhi.
C/FA/1914/2014 JUDGMENT The contractor has been given Advance payment
against above said Bank Guarantees. The Contractor has already received advance
payment.
It is hereby declared that, the contractor is in breach of its obligation under the
contract because the contractor used the advance payment for the purpose other than
for the purpose intended.
It is requested for invocation of Bank Guarantees in favour of Kandla Port Trust."
24. At that stage, Bumi approached the learned Additional District Judge, Gandhidham by filing
Miscellaneous Civil Application under section 9 of the Arbitration and Conciliation Act, 1996 and
prayed for an injunction restraining KPT from encashing the above noted nine bank guarantees in
all four issued by ICICI Bank Limited of Rs.2,69,35,514/-each, four by ING Vysya Bank Limited of
the same amount and one by Axis Bank for a sum of Rs.9,79,47,325/-.
25. In such application, Bumi raised various issues of acts and omissions on the part of KPT
including not providing basic facilities, drawings and designs to start and complete the project
within time. Bumi also raised grievance about the delayed payments from KPT and attributed
climatic conditions such as unforeseen tidal conditions, heavy monsoon etc. for delay. It was stated
that the petitioner had suffered huge loss of C/FA/1914/2014 JUDGMENT Rs.117.43 crores on
account of idle cost of equipments and labour, price escalation, unauthorized deduction of interest
on mobilisation advance, interest on delayed payments, loss of overhead costs etc. It was contended
thus that Bumi had a strong case of special equity since KPT, though a public undertaking, had
displayed unfair and unreasonable conduct. Bumi referred to the arbitration clause contained in the
contract and prayed for injunction against invocation of bank guarantees pending such arbitral
proceedings.
26. KPT filed a reply and opposed the application contending inter alia that Bumi cannot oppose
encashment of guarantees which were payable by the banks on demand. It was alleged that from the
very inception and commencement of work, Bumi had cited unacceptable excuses and acted in
breach of the conditions of the contract and failed to perform its obligations. Bumi had failed to
meet with the schedule and the work had thus suffered.
27. After one round of remand the trial Court was requested to dispose of the application finally,
which was done by the impugned judgment dated 31.5.2014.
C/FA/1914/2014 JUDGMENT
28. Before the trial Court, it was argued on behalf of Bumi that power of invoking bank guarantees
was only with the Board of Trustees of KPT. In the present case, the invocation was done byBoard Of Trustees Of Kpt vs Bhumi - Kwang Jv & 3 on 12 February, 2015

Superintending Engineer. The learned Judge accepted the contention holding that Superintending
Engineer could not have written letters to various banks for invoking bank guarantees. To the
contention of KPT that the bank guarantees were unconditional and the banks had no power to stop
payment to KPT and that Bumi had no power to instruct the banks to stop payment, learned Judge
though agreed to the suggestion, stated that in view of Bumi having issued notice for appointment of
Arbitrator and such arbitrator having been appointed by the High Court, KPT could not have
encashed the bank guarantees of more than Rs.31 crores at that stage. Learned Judge took
cognizance of the stand of Bumi that it had already lost staggering Rs.117 crores and observed that if
the bank guarantee is encashed, such loss would be further increased to Rs.148 crores. Till the
arbitrator decides various issues, Bumi would have suffered such heavy losses and further loss of
interest on such amount. Learned Judge also observed that Bumi had issued notice claiming
compensation of C/FA/1914/2014 JUDGMENT Rs.117 crores, whereas KPT had not raised the
grounds of any loss and it was Bumi which had applied for appointment of arbitrator, whereas KPT
had not cared to do so. On such grounds, learned Judge was persuaded to grant stay against
encashment of bank guarantees observing that various judgments of High Courts and Supreme
Court were cited by KPT and he had gone through the ratio laid down in such judgments. However,
the same would not be useful for the purpose of the case. It was observed that the petitioner's claim
was genuine and was entitled to get relief as prayed for since, if KPT was not restrained from
encashing the bank guarantees, irreparable loss would be caused to Bumi.
29. Against this judgment, KPT has filed this appeal along with the civil application for interim
injunction in which the Court on 25.6.2014 passed the following order:-
"14. Hence, the following interim orders:-
(a) The judgement and decree of the lower Court is stayed so far as it relates to
granting stay against encashment of the bank guarantee for performance of contract
for Rs.9,79,47,325/-, on condition that the undertaking is filed by the authorized
person under the Resolution of the appellant Trust to the effect that in the event it is
found by the Arbitrator that there C/FA/1914/2014 JUDGMENT was no default on
the part of respondent No.1 and the damages are made recoverable by respondent,
the amount realized of the performance bank guarantee shall be refunded by the
appellant to respondent No.1 with interest, as may be ordered by the learned
Arbitrator within a period of three months from the order passed by the Arbitrator
without prejudiced to the rights to prefer appeal and the interim order, as may be
passed therein. The aforesaid order shall not be construed to mean that Arbitration
or arbitrability of the dispute is admitted by either side. Further, the judgement and
decree of the lower Court so far as it relates to encashment of the bank guarantee of
Rs.21,54,84,112/- shall continue on condition that;
(i) respondent No.1 keeps the bank guarantee alive by renewal thereof, at least one
month prior to its expiry with the further observation that in the event the bank
guarantee is not renewed one month prior to its expiry, the interim injunction shall
automatically stand vacated and the appellant shall be at liberty to encash the bankBoard Of Trustees Of Kpt vs Bhumi - Kwang Jv & 3 on 12 February, 2015

guarantee. It is further observed and directed that in the event the bank guarantee is
continued and the condition is complied with, the appellant shall be at liberty to
utilize the machineries and other infrastructure material procured by respondent
No.1 lying on the site for its performance of completion of the contract or otherwise
or in alternative it would also be open to the appellant to dispose of the machineries
and the materials lying on the site in association with respondent No.1 and the
amount so realized shall be kept in a separate bank account.
15. The aforesaid interim order shall operate, subject to final order, which may be passed in the
appeal. The appeal be fixed for hearing on 12.8.2014. R & P be called for.
16. After the pronouncement of the order, the learned Counsel for respondent No.1 Trust
C/FA/1914/2014 JUDGMENT prayed that the operation of this order be stayed for some time, so as
to enable his client to approach before the higher forum. Mr.Sanjanwala, learned Counsel objects to
such request.
17. Considering the facts and circumstances, status-quo as prevailing today shall continue for a
period of four weeks.
18. The Civil Application shall stand disposed of with liberty to respondent bank to apply, if they are
aggrieved by the order. Direct service is permitted."
30. Bumi, thereupon, filed SLP before the Supreme Court against such interim order of the High
Court. The Supreme Court disposed of such proceedings by following order:-
"Taken on Board.
Having heard learned counsel for the respective parties, we are convinced that the
main appeal itself, which is pending before the High Court and for which date has
been fixed for hearing on 12.08.2014, should be disposed of at the earliest possible
time. With that view this special leave petition stands disposed of without going into
the merits of the order impugned, only with the request to the High Court to dispose
of the appeal on or before 20.08.2014 and the status quo order shall continue to
remain in force till that date.
Needless to state that both parties should not ask for adjournment before the High
Court and the appellant shall keep the Bank Guarantee alive, pending further orders
to be passed by the High Court.
Learned counsel for the petitioner prays C/FA/1914/2014 JUDGMENT for
replacement of pages 177 and 178 in the petition filed by them, which, according to
them, have some typographical errors. Permission to replace the same is granted.
The special leave petition is, accordingly, disposed of."Board Of Trustees Of Kpt vs Bhumi - Kwang Jv & 3 on 12 February, 2015

31. Under such circumstances, this appeal is taken up for out of turn consideration.
32. Learned senior counsel Mr. Sanjanwala drew our attention to various documents
on record and raised following contentions:-
(1) Bumi had provided different bank guarantees, which were unconditional in
nature. KPT was thus authorized to encash the bank guarantees in background of
facts that Bumi had breached several important conditions of the contract, had not
been able to make any meaningful progress in the work and had thus caused huge
loss to KPT.
(2) Counsel submitted that on account of acts and omissions on the part of Bumi,
which resulted in slow progress and gross delay in execution of the work, KPT was
entitled to recover liquidated damages.
Performance security was offered for covering any such loss or damage to KPT on account of the
actions of C/FA/1914/2014 JUDGMENT Bumi.
(3) Counsel pointed out that during the entire period, only about 7% of the work was completed.
During such period, all running bills were paid by KPT to Bumi. Gross delay and inaction on the part
of Bumi caused great financial loss to KPT. Delay in execution of the project has caused further
damage. The action of KPT, therefore, to invoke performance bank guarantee was, thus, justified.
(4) Counsel submitted that the mobilisation advances were released for raising the working capital
for execution of the work. When Bumi failed to execute any significant portion of work due to which
KPT had to issue notice for termination of contract, Bumi had to refund the advances made by KPT.
Stage of recovering such advances from the running bills of the contractor, as envisaged in the
contract, never arrived since Bumi never executed the work beyond 15% after which recoveries
would start.
(5) Here also the bank guarantees were unconditional. By citing specific reasons envisaged in the
bank guarantees, invocation letters were issued. Subsequent C/FA/1914/2014 JUDGMENT
communications were merely for overcoming technical objection of not using specific expressions.
(6) Counsel submitted that before the trial Court, Bumi had raised oral contention of lack of
authority on the part of Superintending Engineer invoking the bank guarantees on the ground that
such powers lay only with the Board of KPT. He submitted that no such contention was ever taken in
the application under section 9 filed by Bumi nor in any other form of pleading before the trial
Court. Bumi was thus precluded from raising any such oral contention, which according to the
counsel, was raised for the first time in the written submissions and never ever orally canvassed.
(7) Counsel drew our attention to various documents produced before us along with an affidavit
dated 20.6.2014 filed by one Shri N.M. Parmar, Superintending Engineer to establish that the
powers of the Board were exercised by the Chairman and after due examination of materials on
record, Chairman had authorized to encash the bank guarantees. The Superintending Engineer, inBoard Of Trustees Of Kpt vs Bhumi - Kwang Jv & 3 on 12 February, 2015

turn, was merely authorized to communicate such decision to the C/FA/1914/2014 JUDGMENT
concerned Bank.
(8) Counsel relied on several decisions of the Supreme Court, reference to which would be made at a
later stage.
33. On the other hand learned senior counsel Mr. Soparkar strongly opposed the appeal raising
following contentions:-
(1) The performance bank guarantee could be encashed only if any loss or damage
was caused to KPT and such loss or damage was suffered by any breach by Bumi of
any terms and conditions of the contract or by reason of Bumi failing to perform such
contract. In the present case, there is nothing to suggest that KPT suffered any loss or
damage either by breach of contract by Bumi or by reason of its failure to perform the
contract. No such narration is found in the letter invoking bank guarantee. It was,
thus, simply not possible for KPT to encash the guarantee.
(2) With respect to bank guarantees for securing mobilisation advances, counsel
submitted that the same could be encashed only if Bumi was in breach of its
obligation, under the contract because it used the C/FA/1914/2014 JUDGMENT
advance payment for purpose other than for the purpose intended. He submitted that
such factors simply did not exist in the present case. Invocation of bank guarantees
was thus wholly unauthorized.
(3) In either case counsel urged that Superintending Engineer had no authority to
invoke the bank guarantees. Such authority was only with the Board of Trustees of
KPT. In the present case, it was not established that such powers were delegated to
the Executive Engineer.
(4) With respect to the additional documents filed before the High Court along with
the said affidavit dated 4.4.2014, Counsel initially raised a ground that in absence of
any application under Order XLI, Rule 27 of Code of Civil Procedure, no such
documents could be admitted by way of additional evidence. No such documents
could be taken on record without granting an application for taking additional
evidence before the appellate Court. He, however, later on changed his position and
suggested that such documents may be taken on record. He referred to such
documents to contend that even from such documents, it could not be established
that either the Chairman of KPT had the C/FA/1914/2014 JUDGMENT power to take
a decision which only the Board of Trustees could have or that the decision of the
Chairman was based on his satisfaction that the conditions necessary for invoking of
bank guarantees existed.
(5) Counsel relied on the decision of Supreme Court in the case of Hindustan
Steelworks Construction Ltd.Board Of Trustees Of Kpt vs Bhumi - Kwang Jv & 3 on 12 February, 2015

vs. State of Bihar. reported in AIR 1999 SC 3710, to contend that in case of bank guarantee which is
not unconditional which according to him was the present case, the recovery would depend on
satisfaction of the conditions envisaged in the bank guarantee.
34. We have noted the facts at length. We may briefly recount the salient features. KPT awarded the
contract in favour of Bumi for modification and strengthening of existing cargo berths at Kandla
port which had estimated contract value of more than Rs. 200 crores. The work had to be completed
within 30 months i.e. latest by 9.8.2014. According to KPT it is not seriously in dispute that right till
the date KPT issued the notice of termination on 14.2.2014, only about 7% of the work was
completed. It was also not in dispute that KPT paid all its remaining bills to Bumi C/FA/1914/2014
JUDGMENT as and when raised for completed work. Under the contract, Bumi had to provide
performance security of 10% of the contract price. 5% of this would be by way of bank guarantee and
remaining 5% would be secured through retention money from the running bills. In furtherance of
such requirement, Bumi issued its first bank guarantee through Axis Bank Limited on 2.2.2012 for a
sum of Rs.9,79,47,325/-. Under the contract, if so desired, Bumi would receive mobilisation
advances upto 10% of the contract price payable in two installments. To secure such advances from
KPT, Bumi would have to offer bank guarantees. In two installments KPT released Rs.9,79,47,324/-
each upon Bumi offering bank guarantees from ICICI Bank Limited and ING Vysya Bank Limited.
35. On the premise that Bumi had completely failed to discharge its contractual obligations and was
rather tardy in the work progress, after communications and notices, KPT invoked all bank
guarantees. First such invocation was through letter dated 18.2.2014 to ING Vysya Bank Limited
followed by a letter dated 21.2.2014 to ICICI Bank Limited. Another letter of invocation was issued
to Axis Bank Limited on C/FA/1914/2014 JUDGMENT 27.3.2014. To invoke same bank guarantees
letters were also issued to ICICI Bank Limited and ING Vysya Bank Limited both on 27.3.2014. The
question is whether under such facts on record, it was open for KPT to do so or whether Bumi could
resist encashment of such bank guarantees.
36. In many cases, issue of bank guarantee has been discussed by Supreme Court. In the case of
U.P.Cooperative Federation Ltd. vs. Singh Consultants & Engineers (P) Ltd. reported in (1988) 1
SCC 174, the Supreme Court observed that where the works contract bank guarantee was executed
by the bank on behalf of the contractor in favour of the principal, the Court would not issue
injunction restraining the principal from invoking and encashing bank guarantee except in case of
fraud or apprehension of irretrievable injustice to the contractor. Referring to the concept of special
equities, it was observed that term would mean a situation where the injunction was sought for to
prevent injustice, which was irretrievable. Jagannatha Shetty,J., in the concurring judgment,
observed as under:-
"54. The Court, however, should not lightly interfere with the operation of irrevocable
C/FA/1914/2014 JUDGMENT documentary credit. I agree with my learned brother
that in order to restrain the operation of irrevocable letter of credit, performance
bond or guarantee, there should be serious dispute to be tried and there should be a
good prima facie acts of fraud. As Sir John Donaldson M.R. said in Bolivinter oil SA
v. Chase Mannattan Bank :Board Of Trustees Of Kpt vs Bhumi - Kwang Jv & 3 on 12 February, 2015

"The wholly exceptional case where an injunction may be granted is where it is
proved that the bank knows that any demand for payment already made or which
may thereafter be made will clearly be fraudulent. But the evidence must be clear
both as to the fact of fraud and as to the bank's knowledge. It would certainly not
normally be sufficient that this rests on the uncorroborated statement of the
customer, for irreparable damage can be done to a bank's credit in the relatively brief
time which must elapse between the granting of such an injunction and an
application by the bank to have it discharged."
37. In the case of Hindustan Steelworks Construction Ltd. vs. Tarapore & Co. and anr. reported in
(1996)5 SCC 34, it was held and observed as under:-
"14. The High Court also committed a grave error in restraining the appellant from
invoking bank guarantees on the ground that in India only reasonable amount ca be
awarded by way of damages even when the parties to the contract have provided for
liquidated damages and that a term in a bank guarantee making the beneficiary the
sole judge on the question of breach of contract and the extent of loss or damages
would be invalid and that no amount can be said to be due till an adjudication in that
behalf is made either by a court or an arbitrator, as the case may be. In taking that
view the High Court has overlooked the correct position that a bank guarantees is an
independent and distinct contract between the bank and the beneficiary and is not
qualified C/FA/1914/2014 JUDGMENT by the underlying transaction and the
primary contract between the person at whose instance the bank guarantee is given
and the beneficiary. What the High Court has observed would applicable only to the
parties to the underlying transaction or the primary contract but can have no
relevance to the bank guarantee given by the bank, as the transaction between the
bank and the beneficiary is independent and of a different nature. In case of an
unconditional bank guarantee the nature of obligation of the bank is absolute and not
dependent upon any dispute or proceeding between the party at whose instance the
bank guarantee is given and the beneficiary. The High Court thus called to appreciate
the real object and nature of a bank guarantee. The distinction which the High Court
has drawn between a guarantee for due performance of a works contract and
guarantee given towards security deposit for that contract is also unwarranted. The
said distinction appears to be the result of the same fallacy committed by the High
Court of not appreciating the distinction between the primary contract between the
parties and a bank guarantee and also the real object of a bank guarantee and the
nature of bank's obligation thereunder. Whether the bank guarantee is towards
security deposit or mobilisation advance or working funds or for due performance of
the contract if the same is unconditional and if there is a stipulation in the bank
guarantee that the bank should pay on demand without a demur and that the
beneficiary shall be the sole judge not only on the question of breach of contract but
also with respect to the amount of loss or damages, the obligation of the bank would
remain the same and that obligation has to be discharged in the manner provided in
the bank guarantee. In General Electric Technical Services Company Inc. vs. PunjBoard Of Trustees Of Kpt vs Bhumi - Kwang Jv & 3 on 12 February, 2015

Sons (p) Ltd. while dealing with a case of bank guarantee given for securing
mobilisation advance it has been held that the right of a contractor to recover certain
amounts under running bills would have no relevance to the liability of the bank
under C/FA/1914/2014 JUDGMENT the guarantee given by it. In that case also the
stipulations in the bank guarantee were that the bank had to pay on demand without
a demur and that the beneficiary was to be the sole judge as regards the loss or
damage caused to it. This Court held that notwithstanding the dispute between the
contractor and the party giving the contract, the bank was under an obligation to
discharge its liability as per the terms of the bank guarantee. Larsen and Toubro
Limited vs. Maharashtra State Electricity Board and Hindustan Steel Workers
Construction Ltd. Vs. G.S. Atwal & Co (Engineers) Pvt. Ltd. were also cases of work
contracts wherein bank guarantees were given either towards advances or release of
security deposits or for due, performance of the contract. In both these cases this
Court held that the bank guarantees being irrevocable and unconditional and as the
beneficiary was made the sole judge on the question of breach of performance of the
contract and the extent of loss or damages an injunction restraining the beneficiary
from invoking the bank guarantees could not have been granted. The above referred
three subsequent decisions of this Court also go to show that the view taken by the
High Court is clearly wrong."
38. In the case of U.P. State Sugar Corporation vs. Sumac International Ltd. reported in (1997) 1
SCC 568, the Supreme Court observed as under:-
"12. The law relating to invocation of such bank guarantees is by now well settled.
When in the course of commercial dealings an unconditional bank guarantee is given
or accepted, the beneficiary is entitled to realize such a bank guarantee in terms
thereof irrespective of any pending disputes. The bank giving such a guarantee is
bound to honour it as per its terms irrespective of any dispute raised by its customer.
The very purpose of giving such a bank guarantee would otherwise be
C/FA/1914/2014 JUDGMENT defeated. The courts should, therefore, be slow in
granting an injunction to restrain the realization of such a bank guarantee. The courts
have carved out only two exceptions. A fraud in connection with such a bank
guarantee would vitiate the very foundation of such a bank guarantee. Hence if there
is such a fraud of which the beneficiary seeks to take advantage, he can be restrained
from doing so. The second exception relates to cases where allowing the encashment
of an unconditional bank guarantee would result in irretrievable harm or injustice to
one of the parties concerned. Since in most cases payment of money under such a
bank guarantee would adversely affect the bank and its customer at whose instance
the guarantee is given, the harm or injustice contemplated under this head must be of
such an exceptional and irretrievable nature as would override the terms of the
guarantee and the adverse effect of such an injunction on commercial dealings in the
country. The two grounds are not necessarily connected, though both may co-exist in
some cases. In the case of U.P. Cooperative Federation Ltd. v. Singh Consultants and
Engineers (P) Ltd., which was the case of works contract where the performanceBoard Of Trustees Of Kpt vs Bhumi - Kwang Jv & 3 on 12 February, 2015

guarantee given under the contract was sought to be invoked, this Court, after
referring extensively to English and Indian cases on the subject, said that the
guarantee must be honoured in accordance with its terms. The bank which gives the
guarantee is not concerned in the least with the relations between the supplier and
the customer; nor with the question whether the suppler has performed his
contractual obligation or not, nor with the question whether the supplier is in default
or not. The bank must pay according to the tenor of its guarantee on demand without
proof or condition. There are only two exceptions to this rule. The first exception is a
case when there is a clear fraud of which the bank has notice. The fraud must be of an
egregious nature such as to vitiate the entire underlying transaction. Explaining the
kind of fraud that may absolve a bank from honouring its C/FA/1914/2014
JUDGMENT guarantee, this Court in the above case quoted with approval the
observations of Sir John Donaldson, M.R. in Bolivinter Oil SA v. Chase Manhattan
Bank (All ER at p.352): (at SCCp.197) "The wholly exceptional case where an
injunction may be granted is where it is proved that the bank knows that any demand
for payment already made or which may thereafter be made will clearly be
fraudulent. But the evidence must be clear both as to the fact of fraud and as to the
bank's knowledge. It would certainly not normally be sufficient that this rests on the
uncorroborated statement of the customer, for irreparable damage can be done to a
bank's credit in the relatively brief time which must elapse between the granting of
such an injunction and an application by the bank to have it charged".
This Court set aside an injunction granted by the High Court to restrain the realisation of the bank
guarantee.
*** *** ***
14. On the question of irretrievable injury which is the second exception to the rule against granting
of injunctions when unconditional bank guarantees are sought to be realised the court said in the
above case that the irretrievable injury must be of the kind which was the subject-matter of the
decision in the Itek Corporation case (supra). In that case an exporter in the U.S.A. entered into an
agreement with the Imperial Government of Iran and sought an order terminating its liability on
stand by letters of credit issued by an American bank in favour of an Iranian Bank as part of the
contract. The relief was sought on account of the situation created after the Iranian revolution when
the American Government cancelled the export licences in relation to Iran and the Iranian
Government had forcibly taken 52 American citizens as hostages. The U.S. Government had blocked
all Iranian assets under the jurisdiction of United States and had cancelled the export contract. The
Court upheld the contention of the exporter that any claim C/FA/1914/2014 JUDGMENT for
damages against the purchaser if decreed by the American Courts would not be executable in Iran
under these circumstances and relisation of the bank guarantee/Letters of credit would cause
irreparable harm to the plaintiff. This contention was upheld. To avail of this exception, therefore,
exceptional circumstances which make it impossible for the guarantor to reimburse himself if he
ultimately succeeds, will have to be decisively established. Clearly, a mere apprehension that the
other party will not be able to pay, is not enough. In Itek case there was a certainty on this issue.Board Of Trustees Of Kpt vs Bhumi - Kwang Jv & 3 on 12 February, 2015

Secondly, there was good reason, in that case for the court to be prima facie satisfied that the
guarantors i.e. the bank and its customer would be found entitled to receive the amount paid under
the guarantee."
39. In the case of Dwarikesh Sugar Industries Ltd. vs. Prem Heavy Engineering Works(P) Ltd. and
another reported in (1997) 6 SCC 450, referring to the second exception to the rule of invariable
invocation of bank guarantee on special equities, the Supreme Court observed as under:-
"22. The second exception to the rule of granting injunction, i.e., the resulting of
irretrievable injury, has to be such a circumstance which would make it impossible
for the guarantor to reimburse himself, if he ultimately succeeds. This will have to be
decisively established and it must be proved to the satisfaction of due Court that
there would be no possibility whatsoever of the recovery of the amount from the
beneficiary, by way of restitution.
xxx xxx xxx xxx xxx xxx
31. It is unfortunate, that notwithstanding the authoritative pronouncements of this
C/FA/1914/2014 JUDGMENT Court, the High Courts and the courts subordinate
thereto, still seem intent on affording to this Court innumerable opportunities for
dealing with this area of law, thought by this Court to be well settled."
40. In background of such legal position, if we peruse the facts more closely, in the performance
guarantee, the bank had agreed and undertaken to pay the amount indicated under the guarantee
without any demur, merely on a demand from the Board stating that the amount claimed is due by
way of loss or damage caused to or which would be caused or suffered by the Board by reason of any
breach by the contractor of any of the terms and conditions of the said contract or of the contractor,
failing to perform the said contract. The bank further undertook to pay such money so demanded
"notwithstanding any dispute or disputes raised by the Contractor(s) in any suit or proceedings
pending before any court or Tribunal relating thereto our liability under this present being absolute
and unequivocal."
41. Thus in terms of such contract between KPT and Axis Bank Limited, KPT invoked the bank
guarantee under communication dated 27.3.2014. In such C/FA/1914/2014 JUDGMENT
communication, KPT drew the attention of the bank on the above noted terms of the guarantee,
which required the bank to pay the amount indicated in the guarantee without any demur merely on
a demand from the Board stating that the same was claimed by way of loss or damage or which
would be caused or suffered by the Board by reason of any breach of the contract of any other terms
and conditions of the contract or by the reason of the contractor's failure to perform the contract. In
this background it was conveyed to Axis Bank that " It is hereby declared that the contractor is in
breach of the obligations under the contract as per the clause stipulated above because the
contractor has failed to abide by the terms and conditions of contract which have been mutually
agreed as per the agreement executed by the party and the Board of Trustees of Port of Kandla."Board Of Trustees Of Kpt vs Bhumi - Kwang Jv & 3 on 12 February, 2015

42. It was in this background that KPT conveyed to Axis Bank that it invokes the said bank
guarantee and requests that the amount be sent either in favour of Financial Advisor & Chief
Accounts Officer, Kandla Port Trust payable at Gandhidham.
43. If we have understood correctly, main objection C/FA/1914/2014 JUDGMENT of Shri Soparkar
to this invocation was that this letter did not record in specific words that KPT had suffered loss or
damage due to the reason of Bumi having breached the terms of contract or having failed to perform
the contract and, that therefore, KPT could not have invoked the bank guarantee. In our opinion,
such a contention is wholly baseless. As noted above, Axis Bank Limited had, without any demur or
protest undertaken to pay sum indicated in the bank guarantee on a mere demand being made by
KPT claiming that such amount was due by way of loss or damage caused or would be caused by the
contractor breaching the terms of contract or failing to perform the contract. Such narration was
very much alive on the communication itself, may be in the form of reference to the terms of the
bank guarantee. Nevertheless, immediately after referring to such unconditional terms of the bank
guarantee, KPT instructed the Axis Bank to send over the amount in favour of KPT, since according
to KPT, the contractor was in breach of the obligations under the contract and had failed to abide by
the terms and conditions of the contract actually agreed between the parties. In interpreting this
communication, one would have to bear in mind the context and the overall C/FA/1914/2014
JUDGMENT purport of the action of KPT and the communication to the bank rather than take
narrow view of the expression not being found here and there. The precise communication of the
said letter was that Axis Bank Limited had agreed to pay over the sum indicated in the bank
guarantee without any demur merely on demand from KPT indicating that such amount was by way
of loss or damage caused or that could be caused on account of Bumi breaching the terms of the
contract or failing to perform the contract and in view of such understanding KPT invoked the
guarantee.
44. Coming to the invocation of bank guarantees for securing mobilisation advance, we may recall
that Bumi had received 10% of the contract price by way of mobilisation advance in two
installments. To secure such advances, Bumi had issued various bank guarantees from ING Vysya
Bank Limited and ICICI Bank Limited. The terms of such bank guarantees were common and
guaranting bank had agreed to pay such sum as indicated in the bank guarantee upon receipt of
demand in writing from KPT declaring that "the contractor is in breach of its obligation under the
contract because the contractor used the advance payment for the C/FA/1914/2014 JUDGMENT
purpose other than for the purpose intended."
45. It was under such agreements that KPT invoked the bank guarantees by writing different letters.
In the first letter written to ING Vysya Bank Limited on 18.2.2014, after narrating that there was
slow progress and stoppage of work by Bumi, it had resulted into breach of contract conditions
which would attract the termination clause, KPT requested the bank to arrange encashment of the
bank guarantee and send the amount in favour of KPT. It is true that in such communication there
was no specific recitation that the contractor was in breach of its obligation under the contract
because it had used the advance payment the purpose other than for the purpose intended.
Nevertheless, KPT wrote another letter to ING Vysya Bank Limited on 27.3.2014 invoking the same
set of bank guarantees declaring that the contractor was in breach of its obligation because it hadBoard Of Trustees Of Kpt vs Bhumi - Kwang Jv & 3 on 12 February, 2015

used the advance payment for the purpose other than the purpose intended. In case of ICICI Bank
Limited which had also given similar bank guarantees on same terms and conditions, KPT had first
written on 21.2.2014 and invoked the bank guarantee by declaring to the bank C/FA/1914/2014
JUDGMENT that the contractor was in breach of its obligations and used the advance payment for
the purpose other the purpose intended. Despite this, KPT wrote another letter to ICICI Bank
Limited on 27.3.2014 once again invoking the bank guarantees.
46. It is true that the bank guarantees were worded in such a manner that the same could be invoked
upon a declaration that the contractor was in breach of its obligation under the contract because it
had used the advance payment for the purpose other than the purpose intended. That KPT could
have issued second letter to ING Vysya Bank Limited even after first initial attempt at the invoking
of the bank guarantee in which such specific narration was not made, is really not in dispute. It was
merely an administrative action and KPT was not precluded from writing another letter to the bank
if for some reason the language used in the first one was not entirely to their satisfaction or did not
meet the technical or legal requirements. Once again, the question is of form and not substance. In
essence, therefore, if KPT held a bona fide belief that the conditions for invoking the bank guarantee
were satisfied, it was well within its right to insist C/FA/1914/2014 JUDGMENT on its encashment
and to direct the bank to release the payment indicated in such bank guarantees. Here also, in our
opinion, as per the terms of the bank guarantee and also the contract between KPT and Bumi, it was
primarily the satisfaction of KPT to the existence of such factors, which, at this interim stage of
encashment of bank guarantee till the arbitrator finally decides all the disputes between the parties,
would prevail. Unless it is pointed out that such decision is totally mala fide or baseless the terms of
the bank guarantee itself would demonstrate that it had to be the satisfaction of KPT that
mobilisation advances have become recoverable due to breach of the contract by the contractor by
utilisation of the same for the purpose other than for which it was advanced. In the bank guarantees
the banks irrevocably undertook to pay the agreed sum "upon receipt" "by first demand in writing
declaring that the contractor is in breach of its obligation under the contract because the contractor
used the advance payment for the purpose other than the purpose intended." Thus this satisfaction
that this condition has been satisfied had to be that of KPT .
C/FA/1914/2014 JUDGMENT
47. It may be true that as per the agreement, the second installment of the mobilisation advance had
to be utilized after KPT was satisfied that the first installment had been utilized. It is not even the
case of KPT that second installment was released upon an erroneous satisfaction that the first
installment of mobilisation advance was applied for the purpose for which it was released. However,
once the contractual relations were snapped and Bumi was precluded from carrying out any activity
and the work came to a halt; notice of termination was issued and it appears from the record that
new contract for the same work was already issued by KPT; the question of application of
mobilisation advance for the purpose for which it was given to Bumi would not survive. We agree
with the suggestion of the counsel for the appellant that such mobilisation advance was in the nature
of providing working capital for procurement of equipments, mobilisation of work force and such
other purposes since the initial investment required for execution of such project at such a scale
would be sizable. Such mobilisation advance, therefore, would take the shape of the working capitalBoard Of Trustees Of Kpt vs Bhumi - Kwang Jv & 3 on 12 February, 2015

advanced by KPT to the contractor. Terms of recovery during the currency of C/FA/1914/2014
JUDGMENT the contract were also significant. The recovery would start only after 15% of the work
was executed. It would be made from the running bills. It would be spread in such a manner that the
entire mobilisation advance would be recovered by the time 80% of the work is executed. This would
give the contractor initial financial support. 10% of the contract value would be loaned for working
capital. Such amount would be recovered from the running bills after execution of 15% of the
contract and would be completed latest by completion of 80% of the work beyond which the
contractor would be expected to have made sufficient profit and raised sufficient liquidity to
continue the work without the aid of mobilisation advance from KPT. When it is pointed out that for
over 2 ½ years, which was the total contract period, Bumi for whatever reasons, could complete
only 7% of the work, thereby denying any opportunity to KPT to even start the recovery of the
mobilisation advances, its action of encashing the bank guarantees issued by Bumi to secure such
advances, cannot be, by an interim injunction prevented.
48. In the present case, out of the two exceptions it C/FA/1914/2014 JUDGMENT is not even the
case of Bumi that there is any fraud which would vitiate the action of KPT. Fraud is neither pleaded
nor pressed in service. The other exception of special equity or irretrievable damage was also not
argued. The two exceptions recognized by the courts for granting injunction against invocation of
bank guarantees, thus do not arise in this case. It was primarily contended that in all cases, basis for
invocation of the bank guarantees did not exist. This may be an arguable ground to some extent,
nevertheless we have given our reasons to discard the same. To reiterate, under such situations, it
would primarily be the satisfaction of KPT in whose favour bank guarantees were issued about the
existence of such facts and circumstances. At the stage where both sides have made serious
allegations of acts and omissions and breach of terms of the contract, which the arbitrator appointed
by the Court, would certainly take care of, merely because Bumi has raised serious disputes against
KPT in such arbitral proceedings, would not permit us to injunct KPT from encashing the bank
guarantees.
49. The decision cited by Shri Soparkar in the case C/FA/1914/2014 JUDGMENT of Hindustan
Steelworks Construction Ltd. vs. Tarapore & Co. and anr. was rendered in special facts. The bank
guarantee in question in the said case was for the purpose of securing mobilisation advance. Terms
of bank guarantee provided that the advance shall be used by the contractor exclusively for
mobilisation expenditure. It was further provided that "should the contractor misappropriate any
portion of the advanced loan, it shall become due and payable immediately and no further loan will
be made to the contractor thereof". It was in this background the Supreme Court observed that in
clause 9 the bank had qualified its liability to pay the amount only if the obligations of the contract
were not fulfilled or the HSCL had misappropriated any portion of the advance mobilisation loan. It
was observed that the bank guarantee could be invoked only in circumstances referred to in clause 9
under which the amount would be payable only if the obligations are not fulfilled or there is
misappropriation. In the present case, the bank guarantee is worded rather more expansively.
50. The reasons cited by the learned trial Judge simply do not appeal to us. Mere fact that Bumi has
C/FA/1914/2014 JUDGMENT raised a claim of Rs.117 crores against KPT and if bank guarantees
worth Rs.31 crores are allowed to be encashed, such sum would swell to Rs.148 crores, would not beBoard Of Trustees Of Kpt vs Bhumi - Kwang Jv & 3 on 12 February, 2015

a ground enough to prevent encashment of bank guarantee. Merely, a prima facie case would not be
the ground for preventing invocation of bank guarantee. In fact, the learned Judge has not even
cited any reason why he found any prima facie case in the claims of Bumi. When such claims and
counter claims are raised by both the sides without any evidence on record, it was not even possible
for the learned Judge to even prima facie examine any such claims and come to the conclusion that
the claim of applicant had greater validity than that of the respondent. In fact, learned Judge was
not even called upon to decide the same.
51. Learned Judge also held that the Executive Engineer, KPT did not have authority to invoke the
bank guarantees. This would be the last surviving issue which was also pressed with a great degree
of seriousness before us by the counsel for Bumi. It is undisputed position that no such contention
was raised through pleadings on record before the trial Court. Neither in the plaint nor in any other
form, there was C/FA/1914/2014 JUDGMENT any averment made by Bumi to this effect. Being a
pure question of fact, it could not have been and ought not to have been allowed to be raised as a
contention for the first time by the Court. Even if we accept the version of Bumi that such contention
was not taken only in the written submissions but also raised during the oral arguments, in absence
of basic facts on record, such contention was simply not available to the applicant. It is not unknown
that large Government corporations and statutory bodies function through executive mechanism.
This set up sometimes permits delegation of powers and sometimes the task of communications or
signing letters, documents and affidavits is entrusted to designated officer. Therefore, merely
because the communications were issued by the Executive Engineer, it cannot be presumed that he
was the one who had taken the decision to invoke the bank guarantee. It was merely a question of
fact whether the communication was signed by him; the decision having already been taken by a
competent authority at appropriate level. This was thus a pure question of fact. Even if treated as a
mixed question of fact and law, the applicant had to lay the foundation to raise the contention before
the C/FA/1914/2014 JUDGMENT Court at the time of oral arguments. Only if it was a pure question
of law based on facts on record, Bumi could have raised such a contention before the Court below or
even before us for the first time at the appellate stage.
52. We are not unmindful of the decision of the Supreme Court in the case of Sardul Singh vs.
Pritam Singh & Ors. reported in JT 1999(2) S.C.498 in which it was observed that it is well settled
that notwithstanding the absence of pleadings before a Court or authority, still if an issue is framed
and the parties were conscious of it and went to trial on that issue and adduced evidence and had an
opportunity to produce evidence or cross examine the witnesses in relation to the said issue, no
objection as to want of a specific pleading can be permitted to be raised later. Such facts are
completely missing in the present case. There was no pleading, no issue on this aspect, no
opportunity to KPT to produce necessary rebuttal material and no occasion for the learned Judge to
entertain such a contention for the first time by way of oral arguments. Though in this First Appeal
certain documents have been produced by KPT, as C/FA/1914/2014 JUDGMENT noted above, in
absence of any application, we are not inclined to take such documents on record or refer to the
same. Order XLI, Rule 27 of Code of Civil Procedure relates to additional evidence in the appellate
Court. Sub-rule (1) of Rule 27 starts with expression that the parties to an appeal shall not be
entitled to produce additional evidence, whether oral or documentary, in the appellate Court.
Clauses (a), (aa) and (b) of sub-rule provide for exceptions where the appellate Court may allowBoard Of Trustees Of Kpt vs Bhumi - Kwang Jv & 3 on 12 February, 2015

such evidence or document to be produced or witness to be examined. Clause (a) pertains to a case
where the trial Court refused to admit the evidence. Clause (aa) pertains to a case where the party
seeking to produce additional evidence, establishes that notwithstanding the exercise of due
diligence, such evidence was not within his knowledge or could not, after the exercise of due
diligence, be produced. Clause (b) empowers the appellate Court if it requires any document to be
produced or any witness to be examined to enable it to pronounce judgment or for any other
substantial cause. Thus in this case the application of clauses (a) and (aa) is ruled out. In so far as
clause (b) is concerned, we have given our detailed consideration of C/FA/1914/2014 JUDGMENT
the issue on hand and do not find that such documents would be necessary to enable us to
pronounce the judgment or for any other substantial cause. Under the circumstances, the Court, in
our opinion, committed an error in striking down the action of KPT on the ground that the
Executive Engineer did not have the authority.
53. In the result, appeal is allowed. The judgment of the learned Additional District Judge,
Gandhidham at Kachchh dated 31.5.2014 in Civil Miscellaneous Application (Arbitration Petition)
No.12 of 2014 is set aside. The injunction against invocation of the bank guarantees granted by the
Court below is vacated. Appeal is disposed of accordingly.
54. In view of the order passed in First Appeal, Civil Application is disposed of accordingly.
55. At the request of learned counsel for opponent No.1 this judgment shall stand stayed for the
period of four weeks from today, however, on a condition that all bank guarantees shall be kept alive
at least upto 30.4.2015 in case any of the bank guarantees is expiring in the meantime.
          C/FA/1914/2014                         JUDGMENT
                                             (AKIL KURESHI, J.)
                                          (MS SONIA GOKANI, J.)
SUDHIRBoard Of Trustees Of Kpt vs Bhumi - Kwang Jv & 3 on 12 February, 2015

