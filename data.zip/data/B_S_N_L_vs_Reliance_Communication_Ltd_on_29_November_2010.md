B.S.N.L vs Reliance Communication Ltd on 29 November, 2010
Author: S.H. Kapadia
Bench: Swatanter Kumar, K.S. Panicker Radhakrishnan, S. H. Kapadia
                                                                   REPORTABLE
            IN THE SUPREME COURT OF INDIA
                CIVIL APPELLATE JURISDICTION
                CIVIL APPEAL NO. 6706 OF 2010
B.S.N.L.                                    ... Appellant (s)
                           Versus
Reliance Communication Ltd.                 ... Respondent(s)
                       JUDGMENT
S.H. KAPADIA, CJI
1. Whether clause 6.4.6 of the Interconnect Agreement between Bharat Sanchar Nigam Limited
(BSNL) and M/s. Reliance Infocomm Limited is penal or a pre-estimate of damages is the question
which arises for determination in this civil appeal?
Facts
2. On 18th March, 1997, Reliance had entered into BSO Interconnect Agreement with Department of
Telecommunications (DoT) for interconnection of their networks within their respective circles. In
October, 2000, with its establishment, the BSNL took over from DoT the aforementioned BSO
Agreement. In November, 2003, the BSO regime was replaced by Unified Access Services regime
which granted the licence to service providers for both basic and mobile telephony services as part of
a single unified licence. Reliance was allowed to operate as a Unified Access Service provider from
November 14, 2003 though it was formally granted the Unified Access Service Licence on 21st
September, 2004 with effect from 14th November, 2003. By an addenda dated 28th February, 2006,
the agreement was formally amended with retrospective effect from 14th November, 2003. The
Agreement deals with local calls, national long distance calls (NLDC) and international long
distance calls (ILD). Calls of each trunk group are connected through dedicated ports and are
chargeable at rates different from other trunk groups. Hence, depending on the number of calls
handled by a particular port, charges are levied by BSNL on Reliance, at the rate of the existing callB.S.N.L vs Reliance Communication Ltd on 29 November, 2010

charges payable for that particular trunk group.
3. On 24th June, 2003, the DoT issued a circular specifying that Calling Line Identification (CLI)
cannot be tampered with under any circumstances and also gave directions to service providers on
how to prevent such tampering. By its circular dated 28th January, 2004, the above circular of DoT
coupled with IUC Regulations dated 29 th October, 2003 issued by Telecom Regulatory Authority of
India (TRAI) was made effective.
4. In September, 2004, BSNL received several complaints from its subscribers in Gujarat that they
were receiving ILD calls with local CLI Numbers. On the basis of these reports, BSNL made its own
enquiries by calling the local CLI number, i.e., 0281-3041000. This was on 5th October, 2004, 6th
October, 2004 and 7th October, 2004. Each time the number was called the response from the other
end was that the number did not exist. Therefore, on 8th October, 2004, BSNL reported the matter
to Reliance at which time Reliance had sent its report to DoT regarding the same. In the said report
to DoT, Reliance stated that the wrong routing of ILD calls was being done by one of its subscribers,
viz., M/s. Raj Enterprises (who was given 60 calls circuits). The series of numbers allotted to Raj
Enterprises was from 2813041000 - 2813041199, i.e., 200 numbers.
5. On 13th October, 2004, BSNL gave notice to Reliance saying that Reliance is having POIs at
various Exchanges in Vadodra; that on monitoring incoming traffic to BSNL as indicated in CDRs at
the above POIs, it was found that there were numerous calls with CLI as 281 3041000; that, such
calls have been received from 4th September, 2004 and, therefore, BSNL will charge at Rs. 5.65 per
minute for all incoming calls at POI of Reliance from July, 2004. It may be noted that Rs. 5.65 per
minute is the rate of incoming ISD calls at TAX POI of Reliance (the word `TAX' stands for Trunk
Automatic Exchange).
6. On 25th October, 2004, BSNL issues its circular to all its officers by which continuation of
unauthorized diversion in routing of ILD calls is brought to their notice with specific reference to the
case of Reliance. In the circular, it is highlighted that although Reliance claims that tampering of
CLI has been stopped w.e.f. 16th September, 2004, it is found that international calls have been
delivered on the local POI of Reliance, at trunk group meant for intra circle terminating traffic, at
various SDCC tandem exchanges, with CLI of Reliance network of other SDCAs which is different
from STD Code and 3039xxxx.
7. On 21st March, 2005, BSNL raised its bill on Reliance (RIL) levying "penalty" of Rs. 9,17,27,746
with interest from 15th October, 2004 to 15th April, 2005 at 21% p.a. for months of July, 2004 to
October, 2004 in all amounting to Rs. 9,89,68,892/- for illegal routing of calls. This bill dated 21st
March, 2005 superseded the provisional bill dated 15th October, 2004 raised by the Vadodra Unit of
BSNL for Rs. 6.89 cr. for the said period July, 2004 to September, 2004. In the said bill, the rate
applied was Rs. 5.65 per minute. This demand was made on the basis that numerous calls have been
detected in the POI with CLI as 281 3041000 which pertained to ISDNB PRI connection given to
M/s. Raj Enterprises of Rajkot. According to Reliance, the calls received in its POIs were "grey
market" calls. That, they were neither wrongly routed nor their CLIs were tampered. Ultimately,
after detailed correspondence between BSNL and Reliance, petition No. 275 of 2009 was filed byB.S.N.L vs Reliance Communication Ltd on 29 November, 2010

Reliance against the above impugned demand.
8. By the impugned judgment, TDSAT has held that the impugned demand of BSNL under clause
6.4.6 of the Interconnect Agreement is penal in nature; that under the said clause unauthorized calls
had to be detected by BSNL and that in case of such detection charges were to be levied on such calls
at the highest applicable IUC; that BSNL was under
an obligation to draw distinction between unauthorized calls and calls without/
modified CLI in the impugned demand which in the present case has not been done;
that no opportunity of hearing was given to Reliance and, lastly, the amount of
penalty was not commensurate with actual damage suffered by BSNL. Accordingly,
the impugned demand was set aside. Aggrieved by the impugned judgment of TDSAT
dated 24th May, 2010, BSNL has come to this Court by this civil appeal.
Submissions
9. On interpretation of clause 6.4.6, Shri Gopal Subramanium, learned senior counsel appearing for
BSNL submitted that the said clause merely prescribes the payment of a sum by Reliance on the
happening of an event other than breach and, consequently, the distinction between penalties and
liquidated damages would not apply because such distinction applies only to sums payable on
breach of the contract and not when a clause prescribes payment of a sum on the happening of an
event other than breach. In this regard, learned senior counsel submitted that the Agreement
pertains to telecommunication services which is capital intensive venture and which requires
seamless and uninterrupted service. A disruption in such services would result not only in financial
loss to BSNL and Reliance but also to a large number of subscribers of both the companies.
Moreover, learned senior counsel submitted that it is technically impossible for BSNL to trace or
block a call with a tampered (masked) CLI. That, on a given day a single POI handles millions of
minutes of calls which are handed over to BSNL and in such a situation it is not commercially
feasible to decipher which call is genuine and which call is without CLI/tampered CLI. Thus, clause
6.4.6 should be interpreted against the background knowledge referred to above and, if so read, it
becomes clear that the said clause is inserted in the Agreement for commercial prudence as a thumb
rule and should as such be interpreted in that manner. According to the learned counsel, the onus of
proving the nature of a clause as penal is on the party who has sued upon it. According to the
learned counsel, clause 6.4.6 gives BSNL an option of terminating the contract or to prolong the
contract on the payment of an additional sum and thus the same cannot be characterized as penalty
but must be classified as representing the price for the option of continuing the contract. Thus,
according to the learned counsel clause 6.4.6 represents a condonable default under the contract as
payment under the said clause results in continuance of the contract. Consequently, the amount
paid under the said clause cannot be brought under Section 74 of the Contract Act. According to the
learned counsel the situation in clause 6.4.6 amounts to an alternative mode of performance of the
contract. Lastly, according to the learned counsel where a contract prescribes payment of a sum on
default, even if the sum payable may be larger than the actual loss, when the contract is between
parties with equal bargaining power, and as long as the sum payable is not extravagant, it should not
be characterized as penalty. Similarly, where an agreed sum is payable upon a default if the lossB.S.N.L vs Reliance Communication Ltd on 29 November, 2010

accruing to the claimant from the default in question cannot be accurately or even reasonably be
ascertained, then such sum cannot be classified as penalty and once a stipulation is held not to be a
penalty, there is no need for actual proof of loss.
10. On interpretation of clause 6.4.6 of the Interconnect Agreement, Shri C.S. Vaidyanathan, learned
senior counsel for Reliance and Shri Ramji Srinivasan, learned senior counsel for Tata Teleservices
Limited, submitted that there is no dispute between the parties regarding the existence of the grey
market and its operations by miscreants who use the telecom facilities provided by various telecom
service providers, including government operators, like BSNL and MTNL. In this connection
learned counsel placed reliance on the compilation submitted by BSNL. Learned counsel also placed
reliance on the statistical data in support of his above contention. The learned counsel has also
relied upon directions dated 25.10.2004 issued in the form of a circular by BSNL to its field offices
suggesting steps to be taken by them to detect what is called as "gateway bypass scam". On the
interpretation of clause 6.4.6, learned counsel submitted that the said clause carries a heavy penalty;
that the said clause is attracted in cases of tampering/wrong routing of calls attributable to some
fault on the part of the operator and not otherwise, and since in the present case the actions
complained are attributable to an unscrupulous subscriber and not to Reliance, clause 6.4.6 cannot
be invoked. In other words, according to the learned counsel, grey market operations of telecom are
a reality affecting all telecom service operators and cannot become a ground for invoking clause
6.4.6 which is a unilateral clause regardless of the fault of the private operator. Learned senior
counsel further submitted that the contention of BSNL regarding "strict civil liability" is entirely
misplaced as BSNL does not possess any statutory power to impose such liability. On applicability of
Section 74 of the Contract Act, learned counsel submitted that interconnection between different
telecom service providers is essentially in the interest of the subscribers. That, such interconnection
is mandated by the license; that the interconnection charges are regulated by TRAI under Section 11
of the 1997 Act; that no service provider can charge interconnection charges more than what is
specified by the regulator; and that clause 6.4.6 of the Interconnection Agreement between BSNL
and Reliance is a one sided penal provision insisted upon by BSNL. That, what BSNL can recover is
either consideration for services rendered by their interconnection or compensatory damages in
case of breach of any of the clauses of the said Agreement. This is because the Contract Act does not
contemplate any other amount being received by one contracting party (BSNL) from the other
contracting party (Reliance). That, the consideration for services rendered by interconnection is
regulated by TRAI it is not open to BSNL to charge what they like. On the other hand, the TRAI
regulations do not provide for quantum of damages or a penalty in case of breach of the
interconnection agreement. Therefore, if clause 6.4.6 is attracted before breach, as submitted by
learned counsel for BSNL, and if clause 6.4.6 is not compensatory, then the amount demanded is
without consideration and would be unconscionable. According to the learned counsel clause 6.4.6
in the Interconnect Agreement confers only a contractual right. BSNL, according to the learned
counsel, is neither the sovereign exercising legislative or executive or police powers nor is BSNL a
regulator. It is not vested with any powers to impose any penalty for breach of contractual terms nor
can BSNL be vested with such powers as BSNL is one of the several operators in the National
Telecom Policy of 1994 and 1999. That, DoT or the TRAI may exercise regulatory or police powers
imposing a penalty or strict civil liability for violation of any of the terms and conditions of the
license when public interest so requires. However, BSNL does not have any statutory, regulatory orB.S.N.L vs Reliance Communication Ltd on 29 November, 2010

police powers to impose strict civil liability. That, strict civil liability has been recognized and upheld
where it is imposed by the State exercising legislative power in respect of violation of tax liabilities.
It has also been recognized and enforced by courts in tortuous action in regard to ultra hazardous
activity or product liability but even in such cases the liability is strict in the sense that no negligence
need be proved but quantum of damages will have to be proved and it will be only compensatory
and not penal because penal liability can be imposed only by legislation. According to the learned
counsel the concept of strict civil liability or absolute liability is alien to the scheme, purport and
intent of the law of contracts. On clause 6.4.6 learned counsel submitted that the said clause occurs
in Chapter 8 relating to interconnection charges and it is in respect of "wrongly routed calls".
According to the learned counsel the said clause 6.4.6 is premised entirely on the breach of
contractual term requiring calls being handed over in the specific trunk route or calls being handed
over with an appropriate CLI. That, clause 6.4.6
(d) is a pointer to sub-clause (a) and sub-clause (b) being the remedy for breach, in addition to the
rights that BSNL has for disconnection of POI or temporary suspension of Interconnect Agreement
for misuse. Thus, sub-clauses (a) and (b) and (d) can be invoked only in case of a breach of the term
requiring handing over of calls in the specified trunk route or handing over of calls with appropriate
CLI and, therefore, it is incorrect to say that clause 6.4.6 is attracted before the breach of contract
and that the provision for remedy of breach is only in clause 8.2 or 8.3. That, it is equally incorrect
to contend that the provision for breach or damages is only what is contained in clause 11 of the
general terms. According to the learned counsel clause 6.4.6 can be in the nature of reasonable
compensation or compensatory damage only if the charges are recovered in respect of the offending
calls and not in respect of the legitimate calls. Any other interpretation will militate against the
compensatory nature of damages and will amount to imposition of a penalty without legislative
sanction and by one party to the contract usurping sovereign, police and regulatory powers. Learned
counsel submitted that the two months time limit cannot make clause 6.4.6 reasonable or
compensatory, if all calls, irrespective of whether they are rightly or wrongly routed, or with CLI or
without CLI or disguised CLI are charged at the highest IUC rates. Such a provision, according to the
learned counsel, will be ex facie penal in nature. Learned counsel submitted that there is no merit in
the contention of BSNL that technology does not enable tracing of every disguised call. According to
the learned counsel this argument of lack of technology would be available to BSNL only to the
extent that all calls of the offending subscriber, such as Raj Enterprises, may be treated as
unauthorized calls. However, beyond that, calls of other subscribers, in respect of whom there is not
even a whisper of illegality, cannot be clubbed with the offending calls because that would amount to
imposition of penalty. Learned counsel submitted that under the Contract Act no party is entitled to
recover punitive damages for any breach of contract. That, in terms of Section 73 of the Act, the
party which suffers by any breach of contract is entitled to receive, from the party who has broken
the contract, compensation for any loss or damage caused to him thereby, which naturally arose in
the usual course of things from such breach. Such compensation is not to be given for any remote or
indirect loss or damage. According to the learned counsel in terms of section 73 of the Contract Act
in order to receive compensation for loss or damage, the party claiming such compensation must
prove the alleged loss or damage. However, section 74 carves out an exception to the ordinary legal
requirement of proving loss or damage. In terms of section 74 when a contract is breached, if a sum
is named in the contract as the amount to be paid in case of such breach or if the contract containsB.S.N.L vs Reliance Communication Ltd on 29 November, 2010

no other stipulation by way of penalty, the party complaining of the breach is entitled, whether or
not actual loss or damage is proved to have been caused thereby, to receive from the party who has
broken the contract, reasonable compensation not exceeding the amount so named or, as the case
may be, the penalty stipulated for. It thus follows, according to the learned counsel, from section 74
of the Contract Act that regardless of whether the contract specifies a sum to be paid in the event of
breach or whether it contains any other penal provision, the party complaining of the breach is only
entitled to receive reasonable compensation. In the alternative, learned counsel submitted that
inasmuch as clause 6.4.6 provides for payment of an amount beyond reasonable compensation for
loss or damage, it is to that extent unenforceable in law. In this connection learned senior counsel
has placed reliance on the judgments, Fateh Chand v. Balkishan Das [(1964) 1 SCR 515]; Bharat
Sanchar Nigam Limited v. Motorola India Private Limited [(2009) 2 SCC 337]; Maula Bux v. Union
of India [(1969) 2 SCC 554] and Union of India v. Raman Iron Foundry [(1974) 2 SCC 231].
According to the learned counsel clause 6.4.6 is wholly one sided penal provision inasmuch as it
entitles the appellant to receive moneys from Reliance on account of breach and not vice-a-versa.
Learned counsel further submitted that in the instant case BSNL has alleged that international calls
have been delivered on its network as local/national calls from a particular number (02813041000),
belonging to a particular subscriber (Raj Enterprises), of the network of Reliance and are
consequently wrongly routed/tampered calls. However, BSNL is unable to precisely identify such
calls. In other words, BSNL is not in a position to prove which precise calls delivered from the said
number were, in fact, international calls delivered as local/national calls. However, applying clause
6.4.6 BSNL seeks to charge for not only all calls delivered from said number at the highest possible
IUC rates, but, additionally seeks to charge at the highest rate for all calls delivered at the concerned
POI for the relevant month as also all calls for the preceding two months from entirely different
numbers belonging to other subscribers where there is no allegation whatsoever by BSNL of wrong
routing or tampering. In other words, even for numbers and calls with respect to which there is no
allegation of breach, wrong routing or tampering, BSNL seeks to charge at the highest IUC rates
which bears no nexus whatsoever with the loss or damage suffered by BSNL. It is submitted that to
this extent clause 6.4.6 falls foul of section 74 and is therefore unenforceable. Charging for numbers
and calls which have no nexus whatsoever with the number identified by BSNL as having been
misused is to impose in terrorem penalty upon Reliance bearing no connection with the loss
suffered by BSNL on account of alleged wrong routing or tampering and therefore the amount
claimed by BSNL does not fall within the ambit of "compensation" and is legally unrecoverable. At
the highest reasonable compensation in terms of section 74 might cover charging at the rate
prescribed by clause 6.4.6 for all calls received from the number of Raj Enterprises, without having
to prove that all such calls were, in fact, international calls delivered as local/national calls, but no
more. In this connection, learned counsel pointed out that in the instant case the calls from Raj
Enterprises are about one lakh for the month of September and October 2004. However, the total
number of calls on the POI for September and October are about 34 lakhs and if one adds the entire
calls for July and August 2004 also there are about 35 lakh calls in addition and, therefore, the
charges in terms of clause 6.4.6 at the highest rate can be only for 69 lakh calls in addition to one
lakh calls from the subscribe in respect of whose number the allegation of wrong routing/tampering
is leveled by BSNL. Lastly, learned counsel submitted that there is no merit in the contention of the
BSNL that clause 6.4.6 prescribes the payment of a sum on the happening of an event other than
breach and consequently section 74 would have no application. According to the learned counsel ifB.S.N.L vs Reliance Communication Ltd on 29 November, 2010

such contention is accepted it would lead to absurd consequence because it would mean that wrong
routing of calls and tampering of CLI would amount to performance of the contract rather than its
breach. Moreover, according to BSNL the bills raised by them are by way of penalty. It is clear from
the bill dated 21.03.2005. For the aforestated reason it is submitted that there is no merit in any of
the above contentions. Coming to the validity of the demand notice and disconnection notice issued
by BSNL, learned counsel submitted that the demand notices issued by BSNL are invalid since the
same have been raised in 2004 without any provision in the Interconnect Agreement. That, the bills
raised by BSNL were admittedly issued not in terms of any provision in the Interconnect Agreement
but in terms of the letter of BSNL(Headquarters) dated 28.1.2004 which was issued only for
implementation of IUC regulations of TRAI dated October, 2003. Therefore, according to the
learned counsel bills dated 13.10.2004, 15.10.2004 and 21.3.2005 are invalid. Learned counsel
submitted that clause 6.4.6 was inserted through an Addenda signed on 28.2.2006. The said
Addenda was made applicable retrospectively with effect from 14.11.2003 with the exception of
applicable IUC charges including ADC and interconnection arrangements made between the parties
during the intervening period which included ICU charges. That, the said clause 6.4.6 is covered in
the IUC charges which was carved as an exception. Admittedly, at the relevant time, TRAI had
prescribed applicable IUC charges whereby depending on the nature of the call (local, national,
international) certain identified charges were applicable. The applicable IUC charges did not
however contemplate charges for local/national call at the highest available international rate,
which the BSNL now seeks to do purportedly by invoking clause 6.4.6. Thus, according to the
learned counsel from the express terms of the Addenda itself it is clear that clause 6.4.6 falls within
the chapter entitled Interconnection Charges "which is expressly excluded from retrospective
operation". Learned counsel submitted that in any event such purported retrospective application of
a penal provision such as clause 6.4.6 violates Article 20(1) of the Constitution. It is submitted that
BSNL could not have validated the bills issued illegally in 2004 on the basis of the provisions
introduced in the Interconnect Agreement subsequently in 2006 when clause 6.4.6 was not given
retrospective effect and in the absence of any express provision in the subsequent Addenda the bills
cannot be validated. In any case, according to the learned counsel the disconnection notice dated
2.2.2009 was for alleged illegal routing under NLD interconnect agreement; that the said NLD
interconnect agreement was signed on 1.11.2002 which did not have clause 6.4.6 as it exists in the
Addenda dated 28.2.2006; that clause 6.4.6 in the interconnect agreement for NLD was different
from clause 6.4.6 in the Addenda dated 28.2.2006 of the Interconnect Agreement and that clause
6.4.6 of the NLD interconnect agreement did not provide for charging at the highest rate and that
too for the previous two months. Learned counsel submitted that the Addenda to the NLD
agreement was signed on 17.11.2005 incorporating therein clause 6.4.6 (a), (b), (c) and (d) but the
said agreement was not retrospective and was effective from the date of signing of the Addenda
dated 17.11.2005. Consequently, according to the learned counsel the impugned bills raised by BSNL
were illegal and invalid inasmuch as they were not raised in accordance with the provisions of the
Interconnect Agreement between the parties. For the afore-stated reasons, learned counsel
submitted that there was no merit in the civil appeal filed by BSNL and the same needs to be
dismissed. Relevant provisions of:
11.(i) Interconnect Agreement dated 18th March, 1997 2.4 Numbering Plan 2.4.1 The
same area codes for SDCAs will be used for both DoT and LICENSEE network.B.S.N.L vs Reliance Communication Ltd on 29 November, 2010

However, distinguishing exchange codes will be used for the DoT and the LICENSEE's exchanges
i.e. linked numbering scheme will be followed within the SDCA as per the latest National
Fundamental Plan.
2.4.5 Separate exchange codes or number ranges shall be allocated to the DoT and the LICENSEE's
exchanges by the TELECOM AUTHORITY. Utilisation of unused exchange codes or number ranges
out of those allocated to the DoT and the LICENSEE's exchanges shall be reviewed by TELECOM
AUTHORITY from time to time for optimum utilisation. 2.5 Calling Line Presentation 2.5.1
LICENSEE's network shall be capable of transmitting and receiving calling line identification which
shall include Access code, Area code and Subscriber number.
Chapter 6 Interconnection Charges 6.1 Interconnectivity to DOT Network 6.1.1 Provision of links to
interconnect LICENSEE's network with DoT's network will be the responsibility of the LICENSEE
as provided under Clause 2.1.2 and 2.1.3.
6.2 Detailed Billing 6.2.1 For every STD/ ISD call originating from the LICENSEE's network and
accepted by DoT, a detailed billing and/ or bulk billing record will be generated in the LDCC TAX.
For this purpose calling subscriber's identity shall be supplied by the LICENSEE for detailed billing
purpose.
6.4 Access Charges 6.4.1 For purposes of calculating the access charge, the point at which the calls
are delivered to DoT's network is treated as originating point. The calls will be measured from the
point of entry to the destination at the applicable rate of DoT.
6.4.3 The traffic delivered on any DOT LDCC TAX from LICENSEE's LDCC TAX/ SDCC tandem/
local exchange will be measured on the incoming junctions of the DOT's LDCC TAX at the
destination wise pulse rates applicable to the calls generated locally at the same station where the
DOT's LDCC TAX is located.
6.4.5 For international calls originating in the LICENSEE's network and accepted by DoT (ref. para
6.2.1), DoT will bill the LICENSEE on monthly basis as ISD Access charge at a rate of Rs. 0.70 per
unit measured call at the point of interconnection. The responsibility of paying to the international
carrier (presently Videsh Sanchar Nigam Limited) will lie with the DoT.
(ii) Addenda to interconnect agreement after migration dated 28th February, 2006 Whereas M/s
Reliance Infocomm Limited (previously known as M/s. Reliance Telecom Private Limited) has
signed an Interconnect Agreement on 18.3.1997 with Department of Telecommunications {now
Bharat Sanchar Nigam Limited [hereinafter called the BSNL (previously called as DOT]} for
interconnection of their Basic Service network with the network of BSNL in Gujarat Circle Service
Area.
Whereas the President of India granted to M/s. Reliance Infocomm Limited [hereinafter called the
UASL (previously called as LICENSEE)] a License No. 17-6/95-BS-II/GUJARAT on 18th March
1997 under Section 4(1) of the Indian Telegraph Act, 1885 to provide Basic Telephone Service in theB.S.N.L vs Reliance Communication Ltd on 29 November, 2010

Service Area of Gujarat Circle on the terms and conditions specified in such License.
AND whereas the UASL has, upon permission of Licensor, migrated to Unified Access Service
License regime on 14th November 2003 for above stated Service Area, whereupon the said license
agreement was amended and revised on 21st September 2004 with effect from 14th November 2003
on the terms and conditions specified in such amended License No.10-
05/2004-BS-II/RIL/GUJARAT and therefore the said Interconnect agreement is required to be
amended and revised as described in Chapters, Annexures and Schedules appended hereto with
effect from 14th November 2003. AND whereas Interconnect Usage Charges (IUC) Regulation
become effective from 1st May 2003 which was amended on 29th October 2003 to become effective
from 1st February 2004 and further amended on 6th January 2005 to become effective from 1st
February 2005.
IT IS NOW FURTHER AGREED AS FOLLOWS:
1. Each party, i.e. BSNL as well as the UASL, does hereby agree to the terms &
conditions as described herein which shall append as Addenda to the original
agreement and the combined agreement, hereinafter called "AGREEMENT", will
become effective from 14th November 2003 except the applicable Interconnection
Usage Charges (IUC) including ADC, Interconnection arrangements and associated
bill arrangements as prescribed by BSNL Corporate Office, during this intervening
period till date of signing of this Addenda.
2. Each party, i.e., BSNL as well as the UASL, does hereby agree to:
a) Interconnect its Network to the Network facilities of the other party; and
b) Make available to the other party the services, facilities and information as
specified in this Interconnect Agreement.
c) Provide the other interconnected party with interconnection traffic carriage and
fault detection of a technical and operational quality that is equivalent to that which
each party provides to itself.
2(2) The UASL shall ensure that its interconnect facilities delivered at each point of
interconnection (POI) conform to the applicable quality of service (QOS) standards
and technical specifications for interconnection by the relevant delivery date
determined pursuant to the provisions of this Agreement.
2(3) UASL shall be responsible to provide, install, test, make operational and maintain all
interconnection facilities on its side of point of interconnection (POI) unless otherwise mutually
agreed.B.S.N.L vs Reliance Communication Ltd on 29 November, 2010

2(11) It is further agreed that any kind of breach of any of the terms of this agreement by the UASL
shall entitle BSNL to levy damages on the UASL. Quantum of damages assessed and levied by BSNL
shall be final and not challengeable by the UASL.
Chapter - 1 Definitions In this Agreement, words and expressions will have the following meanings
as are respectively assigned to them unless repugnant to the subject or context:
"UASL" means a registered Indian Company, which has been awarded License for providing the
UNIFIED ACCESS SERVICE.
CLI or "CALLING LINE IDENTIFICATION":
means the information generated by the Network capability which identifies and
forwards the calling number through the interconnected BSNL's / UASL's Network.
"FUNDAMENTAL PLAN": means Numbering Plan, Traffic Routing and Switching
Plan and transmission Plan issued by Department of Telecom as amended from time
to time.
"GATEWAY SWITCH": Gateway switch is defined as a switch, which has the
capability to perform gateway functions like functional capability to send and receive
signals based on CCS7 signaling system of ITU-T, functional capability to send and
receive various types of information to other operators' network in a multi operator
environment such as operator identity, charging area information etc. as well as
transport of calling line identification, generating call data record for an off line
billing system giving all necessary details of the call for proper settlement of accounts
in a multi operator environment and Security monitoring functions.
"NATIONAL LONG DISTANCE SERVICE OPERATOR (NLDO)": means the telecom
operator providing the required digital capacity to carry long distance
telecommunication service within the scope of LICENSE for National Long Distance
Service, which may include various types of tele services defined by ITU, such as
voice, data, fax, text, video, and multi media etc. "POINT OF INTERCONECTION
(POI)" is a point at which the GMSC of Fully Mobile network of UASL and Gateway
Switch of BSNL or local / tandem / TAX exchange of the basic service network of
UASL and local / Tandem / TAX of BSNL are interconnected by the facility of
interconnection seeker and where the specified Network-Network Interface
Standards are applicable.
"PSTN" means Public Switched Telephone Network.
"SHORT DISTANCE CHARGING CENTRE (SDCC)": It means a particular Exchange
in a Short Distance Charging Area declared as such for the purpose of charging of
long distance trunk calls as defined in the National Fundamental Plan.B.S.N.L vs Reliance Communication Ltd on 29 November, 2010

"UNIFIED ACCESS SERVICES": means telecommunication service provided by
means of a telecommunication system for the conveyance of messages through the
agency of wired or wireless telegraphy. The Unified Access Services refer to
transmission of voice or non-voice messages over LICENSEE's Network in real time
only. SERVICE does not cover broadcasting of any messages voice or non-voice,
however, Cell Broadcast is permitted only to the subscribers of the service. The
subscriber (all types, pre-paid as well as post-paid) has to be registered and
authenticated at the network point of registration and approved numbering plan
shall be applicable.
The following abbreviations shall bear the full expression as mentioned below:
   UASP:   UNIFIED         ACCESS       SERVICE
   PROVIDER"
                  Chapter - 2
Technical Issues pertaining to Interconnection 2.1 Interconnectivity to BSNL
Network 2.1.1 As per clause 2.6 of License agreement The LICENSEE (UASL) will
have to make his own arrangements for the entire infrastructure required for
providing the SERVICE. Therefore the UASL may develop its own independent
network with its own transmission links within each of its service area.
2.1.3 The UASL shall not, directly or otherwise, extend any type of service to BSNL
subscribers through the access provided by BSNL except for those services which are
permitted as per the license agreement and are further mutually agreed between both
the parties.
2.1.4 Interconnectivity between UASL's network as specified in the license and the
overseas communication network operated by licensed ILDOs shall be through the
TAXs of BSNL or of any other operator duly licensed for the purpose.
2.1.5.2 Calls from fully mobile subscribers of other telecom service providers of
different service area (National Roaming) or other country (International Roaming),
roaming in the network of UASL shall be treated separately for the purpose of
charging and routing.
2.1.9.1 Any facility obtained by the UASL from BSNL shall not be resold or leased in
any manner to a third party.
2.1.9.2 No by pass of traffic shall be resorted to by any party by delivering the traffic
at any point other than as permitted or agreed to under this agreement. In case
unauthorized diversion in routing comes to notice, BSNL shall be free to disconnectB.S.N.L vs Reliance Communication Ltd on 29 November, 2010

the POI in that area, after intimating UASL one week in advance. Moreover, the
resources of BSNL shall be used for the purpose for which these have been earmarked
and no other service shall be offered by utilizing such resources without agreement or
the explicit written consent of BSNL.
2.1.12The interconnection arrangement shall be in accordance with the National
Fundamental Plan related to Switching, Routing, Charging and Numbering.
2.1.13 The Fully Mobile, Limited Mobile and Fixed services network of UASL shall be
having separate POIs with BSNL, which shall be, treated independently for all
purposes, including setup costs, port charges etc. The formation of separate POIs and
various trunk groups therein is to be done as prescribed in relevant tables in Schedule
I - Appendix A. The tables for POIs and trunk groups as prescribed for CMTS
network shall be applicable for fully Mobile network of UASL.
2.1.15.3 INTERCONNECTIVITY FOR STD/ ISD CALLS 2.1.15.3.1 Interconnectivity
for STD/ISD calls shall be between BSNL's LDCC TAX and UASL's LDCC TAX. In
case UASL does not have his own TAX in the LDCC, STD/ISD calls from UASL's
SDCC Tandem/local exchange in an SDCA in the LDCA shall be handed over to
BSNL's LDCC TAX by the UASL.
2.1.15.3.3 For the purpose of Inter circle and International call, the UASL shall
handover the call to BSNL at the originating LDCC TAX.
2.1.16 For the purpose of transit calls originated by UASL's subscriber and meant for
termination in network of any other service provider, the UASL may transmit such
traffic as per rates given in Schedule I, on separate trunk groups at SDCC Tandem for
local calls and originating LDCC TAX for intra and inter circle STD calls. However,
BSNL reserves the right to amend the rates from time to time and also to selectively
withdraw transit facility to other networks. BSNL will also be at liberty to transit and
offer calls originated from other networks to UASL network. Either party shall not
suppress the CLI for transit traffic also. If rates for any transit service are not
available in the Schedule, the same shall be mutually agreed separately. Detailed
technical arrangements will be agreed separately.
2.4 NUMBERING PLAN 2.4.1 For Basic Services the same area codes for SDCAs /
LDCAs will be used for both BSNL and UASL network. However, distinguishing
exchange codes will be used for the BSNL and the UASL's exchanges i.e. linked
numbering scheme will be followed as per the latest National Fundamental Plan.
2.4.3 All the digits received from calling party including `0' shall be passed across the
interface (ROD=1). In case of CCS7 signaling, leading `0' will be appropriately coded
in Nature of Address Indicator (NAI).B.S.N.L vs Reliance Communication Ltd on 29 November, 2010

2.4.5 For Basic services separate exchange codes or number ranges shall be allocated
to the BSNL and the UASL's exchanges by the LICENSOR. Utilization of unused
exchange codes or number ranges out of those allocated to the BSNL and the UASL's
exchanges shall be reviewed by LICENSOR from time to time for optimum
utilization.
2.5 CALLING LINE PRESENTATION 2.5.1 BSNL's and UASL's network shall
wherever technically possible, transmit and receive Calling Line Identification (CLI).
The Calling Line Identification from UASL's fully mobile/ CMTS network shall
contain mobile subscriber number including 93 and from its basic services network
the CLI shall contain Access code, Area code and subscriber number. The Calling
Line Identification from BSNL shall contain area code and subscriber number
depending on the technical feasibility.
2.5.4 No tampering/ alteration of CLI of calls handed over at the POI with BSNL shall
be done by UASL. Instructions of Licensor in this regard shall be followed by UASL
failing which the concerned POI of UASL shall be disconnected under misuse after
giving one week notice in addition to other actions prescribed in this agreement
elsewhere.
2.5.5 The switches of BSNL, which do not have CLI based call barring capability or
are not having CDR based offline-billing capability, shall be technically non feasible
for provision of point of Interconnection. However, UASL undertakes that in the
absence of such capabilities in BSNL's switches, it shall abide by all terms and
conditions including MCU based arrangements for the purpose of measurement and
billing of interconnect traffic as mutually agreed and thus mentioned in this
agreement and that this arrangement will not be a matter of dispute, then BSNL shall
provide POIs to UASL in such switches, if otherwise feasible to do so.
It is further agreed that in case of any regulatory/ judicial intervention on the above
matters, the UASL shall be entitled to and be extended the same relief/ benefit given
to any other operator to the extent it is applicable to the UASL under this agreement.
2.9 NETWORK INTEGRITY AND SCREENING 2.9.1 It is the responsibility of the
UASL to prevent the transmission of any signaling message across the connecting
network, which does not comply with, inter working specification of TEC
No.G/PNI-03/01 Sept. 95 or as modified from time to time.
Similarly BSNL shall also ensure the same in its network.
2.9.2 Efficient arrangement for screening function shall be established by the UASL
at his Gateway exchange or elsewhere in his network to detect signals outside the
inter- working specification of TEC No. G/PNI-03/01 Sept. 95 referred above.
Similarly BSNL shall also ensure the same in its network.B.S.N.L vs Reliance Communication Ltd on 29 November, 2010

2.9.3 Screening arrangement shall include rejection of communications or discarding
information fields, which do not comply with the specification. It will be the
responsibility of the UASL/BSNL that network integrity is protected and maintained.
CHAPTER 6 INTERCONNECTION CHARGES 6.2 DETAILED BILLING 6.2.1 For
every STD/ISD call originating from the UASL's network and accepted by BSNL, a
detailed billing record wherever possible and/or bulk billing record will be generated
in the LDCC TAX. For this purpose the UASL shall supply calling subscriber's
identity for detailed billing purpose.
6.4. Interconnect Usage Charges 6.4.1 Interconnect Usage Charges (IUC) shall be
payable by UASL to BSNL for the calls originating in UASL network and handed over
to BSNL network. Likewise Interconnect Usage Charges shall be payable by BSNL to
UASL for the calls handed over by BSNL network and terminating in UASL network.
Interconnect Usage charges include termination charge, carriage charge, transit
charge and access deficit charge (ADC) as applicable.
6.4.3 The traffic from / to fully mobile network delivered on any BSNL's LDCC TAX from UASL's
GMSC will be measured on the incoming / outgoing junctions of the BSNL's LDCC TAX.
6.4.6 WRONGLY ROUTED CALLS
(a) Unauthorised calls i.e. calls other than specified for that trunk group if detected, for which the
applicable IUC is higher than the IUC applicable for calls prescribed in that trunk group, then BSNL
shall charge the UASL the highest applicable IUC, as applicable for such unauthorised calls, for all
the calls recorded on this trunk group from the date of provisioning of that POI or for the preceding
two months whichever is less.
(b) the CLI based barring facility shall be activated at the POIs wherever technically feasible to
ensure that the traffic handed over by BSNL is in the appropriate trunk groups only. Wherever it is
technically not feasible to activate CLI based barring, periodic monitoring of the incoming trunk
group shall be done by BSNL to ensure this objective. The calls received by BSNL without CLI or
modified/tampered CLI from UASL shall be charged at the highest slab i.e. as for ISD Calls. In case
such calls are received by BSNL on any trunk group, then all the calls recorded on this trunk group
shall be charged at the rates applicable for IUC of incoming ISD calls from the date of provisioning
of that POI or for the preceding two months, whichever is less.
(c) When CDR based billing is introduced in BSNL's network some of the trunk groups shall be
merged. In such cases also, in case unauthorised or Incoming International Call, without CLI call,
call with tampered CLI is handed over to BSNL at the merged trunk group, then BSNL shall charge
the UASL the highest applicable IUC, as prescribed in clauses 6.4.6(a) above for unauthorised calls
& 6.4.6(b) above for incoming International call, without CLI call, call with tampered CLI, for all
calls recorded on this merged trunk group from the date of provisioning of that POI or for theB.S.N.L vs Reliance Communication Ltd on 29 November, 2010

preceding two months whichever is less.
(d) In addition, BSNL shall also have the right for taking other legal actions including disconnection
of POIs or temporary suspension of the interconnection arrangements under misuse.
6.4.7 All the required information in monthly certificate of details of traffic (in minutes) as
prescribed in Schedule I shall be submitted by UASL to BSNL in a timely manner. This information
includes outgoing STD and ISD traffic from its limited mobile/ fully mobile/ cellular access network
handed over to each of private NLDOs/ ILDOs separately and incoming STD and ISD traffic to its
network accepted from each of private NLDOs/ ILDOs separately.
6.5 Billing 6.5.2 At present CDR based billing system for POIs is not available in BSNL's network at
all locations. Wherever BSNL is having CDR based billing system for POIs, BSNL shall bill the IUC
based on processing of CDRs. However, wherever CDR based billing system is not available in
BSNL's network, the billing of IUC shall be done based on IUC pulses as described in Schedule I.
The per MCU charge for these IUC pulses being Rs 0.10 for all types of calls except originating ISD
calls and any other call specially specified in which case per MCU charge shall be Rs 1.20. BSNL
reserves the right to charge Access Deficit Charge (ADC) based on distance from originating SDCC
to terminating SDCC as and when necessary technical arrangements are put in place by BSNL.
8.2 Termination 8.2.1 This Agreement shall continue for the period indicated in Clause 8.1 above
unless any of the following events occur:
(a)Either Party ceases to hold a licence under Section 4 of the Indian Telegraph Act.
(b)An order is entered by a court of competent jurisdiction mandating the
winding-up or dissolution of a Party, or appointing a receiver or liquidator for such
Party or having a comparable effect;
(c)If in the interest of national security or otherwise, it is ordered by a Competent
Authority such as Licensor/ TRAI, that the agreement may be terminated.
(d)If there is a breach of any of the technical and financial obligations as covered in
clauses 2.1.3, 2.1.5.1, 2.1.8, 2.1.9.1, 2.1.9.2, 2.5, 2.11 and 6.4.6.
In which case this Agreement shall immediately be terminated, without any further
notice.
8.2.2 This Agreement also may be terminated by either Party giving 30 days notice to the other in
the event that either Party.
(a) breaches any provision of this Agreement; provided, however, that the breaching Party has been
notified in writing of its failure by the non-breaching Party and the breaching Party has not
remedied its failure within twenty (20) Working Days; and the approval of Licensor or TRAI, as theB.S.N.L vs Reliance Communication Ltd on 29 November, 2010

case may be, has been obtained for such termination. In the event, the approval is accorded with
conditions, regard being had to the general interest of the customers, the same will be fully complied
with before the final act of disconnection of interconnection arrangements becomes effective.
Provided, however, in the event no intervention is made by the Regulator/ Licensor during the
notice period, the approval shall be deemed to have been accorded.
(b) ceases to carry on business.
(c) Either Party is unable to discharge its obligation under this agreement. However, in case of Force
Majeure procedure as indicated below shall be followed:
FORCE MAJEURE Neither party shall be liable for any breach of this Agreement
(other than a breach for non payment) caused by an act of God, insurrection or civil
disorder, war or military operations, national emergency, fire, flood, lightning,
explosion, subsidence, industrial dispute of any kind. The Party affected by such force
majeure shall promptly notify the other Party of the conditions and the details
thereof. If as a result of force majeure, the performance by affected Party of its
obligation under this agreement is only partially affected, such Party shall
nevertheless remain liable for the performance of those obligations not affected by
such force majeure. If the force majeure lasts for more than the continuous period of
90 calendar days from the date of the notification, and continues to prevent the
affected Party from performing its obligation in a whole or in material part, the either
party shall be entitled to, terminate this agreement by giving not less than 30
calendar days written notice to the other Party.
8.3 Withdrawal of Interconnection
(a) For Non-payment: In case of default in payment, BSNL reserve the right for
withdrawal/ suspension of services at the POI.
This will be in addition to other remedies available under the agreement.
   (b)    Under misuse or instructions for the
Licensor.    Either Party may suspend or
withdraw the services if the other party misuses or indulges in any act which will constitute misuse
of POI or will result in violation of instructions issued by Licensor/ Regulator.
The notice period for (a) and (b) above, if any, shall be as specified in the respective clause of the
agreement.
SCHEDULE I Interconnection Usage Charge (IUC)B.S.N.L vs Reliance Communication Ltd on 29 November, 2010

3. Due to non-availability of CDR based billing plateform, IUC applicable for the calls handed-over
to BSNL at the PoI (Point of Interconnect) have been converted into different pulse rates as per
Appendix B. The pulse rates have been calculated at a per MCU (Metered Call Unit) rate of Rs 0.10
for all calls except outgoing ISD calls which shall be measured at a rate of Rs 1.20 per MCU. The bills
for IUC shall be raised by BSNL to the interconnecting operator based on the bulk billing of MCUs
on the incoming trunk groups. The pulse duration with an accuracy of 10 milli seconds shall be
applied at the POIs of all UASL with BSNL as prescribed in Appendix B (in brackets) wherever
technically feasible in BSNL switches. At present the implementation of 10 milli seconds accuracy in
pulse duration is possible in new technology switches of BSNL i.e. EWSD, AXE-10, OCB-283 and
5ESS.
5. The bills for IUC raised by access providers to BSNL shall accompany with a certificate that they
have submitted a signed certificate to circle office BSNL regarding the volume of intra circle, NLD
and ILD traffic as per the Appendix-C. Further processing of these bills, for payment to access
providers for the traffic terminated in their network, shall be done only on receipt of this certificate
from them. In case called upon, the complete record of traffic will be produced by access providers
for verification by the technical audit team constituted by BSNL. The procedure for billing and
recovery of ADC in respect of inter- circle STD calls from cellular / WLL (M) and outgoing /
incoming ISD calls routed through a NLDO or ILDO other than BSNL and intra-
circle traffic from cellular/ WLL(M) to fixed networks are enclosed in Appendix-D.
11. The CLI based barring facility has been activated by BSNL at the PoIs wherever technically
feasible to ensure that the traffic handed over to BSNL is in the appropriate trunk groups only.
Wherever it is technically not feasible to activate CLI based barring, periodic monitoring of the
incoming trunk groups shall be done by BSNL to ensure this objective. In case of wrongly routed
calls IUC shall be charged as below:
(a) Unauthorised calls i.e. calls other than specified for that trunk group if detected,
for which the applicable IUC (including ADC) is higher than the IUC (including ADC)
applicable for calls prescribed in that trunk group, then BSNL shall charge the
concerned private operator the highest applicable IUC (including ADC), as applicable
for such unauthorized calls, for all the calls recorded on this trunk group from the
date of provisioning of that POI or for the preceding two months whichever is less.
(b) Wherever it is technically not feasible to activate CLI based barring, the calls
received by BSNL without CLI or modified/ tampered CLI from concerned private
operator, shall be charged the IUC applicable for the highest slab (i.e. as for ISD Calls
including ADC applicable for ISD calls) for all the calls recorded on this trunk group
from the date of provisioning of that POI or for the preceding two months, whichever
is less.
(c) When CDR based billing is introduced in BSNL's network some of the trunk
groups shall be merged. If unauthorized or Incoming International call or withoutB.S.N.L vs Reliance Communication Ltd on 29 November, 2010

CLI call or call with tampered CLI is handed over to BSNL at the merged trunk group,
then BSNL shall charge the concerned private operator the highest applicable IUC
(including ADC), as prescribed in clauses 11(a) above for unauthorized calls & 11(b)
above for Incoming International call, without CLI call, call with tempered CLI, for
all calls recorded on this merged trunk group from the date of provisioning of that
POI or for the preceding two months whichever is less.
(d) In addition, BSNL shall also have the right for taking other legal actions including
disconnection of POIs or temporary suspension of the Interconnection arrangements
under misuse.
Appendix - C CERTIFICATE OF TRAFFIC ROUTED VIA OTHER NLD / ILD OEPRATORS AND
INTRA CIRCLE TRAFFIC {to be given by cellular operators and basic operators} For the Month of
....................., 200 Licensed Service Area ......................... Name of Operator.................................
Type of Service (Cellular / WLL-M/Fixed).... Period: From .......................to .....................
Dated ................... at ........................... This is to certify that the details of traffic routed other than
through BSNL as NLDO/ ILDO/ transit operator in respect of:
(a) inter circle calls (both originating and terminating) except those originated from
fixed networks but including calls terminating in own network in other circles;
(b) international long distance calls (both incoming and outgoing) except those
originated from fixed networks; and
(c) intra circle calls (both originating and terminating) from cellular/ WLL (M) to
fixed networks and including calls terminating in own network during the above
period are as under:
*** *** *** B. Details of Traffic (in Minutes) through M/s Reliance Infocomm Ltd
NLDO & ILDO) Call Type ........... ........... .......... ............
                  Circle        Circle        Circle        Circle
I    Inter
     circle
     outgoing
     calls
 II Inter
     circle
     incomin
     g calls
III Outgoing
    ILD calls
IV Incoming
    ILD calls
            ***                 ***               ***B.S.N.L vs Reliance Communication Ltd on 29 November, 2010

                                                           Appendix - D
Procedure for billing and recovery of ADC in respect of inter circle cellular / WLL (M)
originated calls, ISD calls (incoming and outgoing both) and intra circle cellular
(WLL(M) to fixed networks routed other than other than through BSNL as NLDO/
ILDO/ transit operator.
1. As per TRAI's IUC Regulation dated 6th January, 2005 for such inter and intra circle calls that are
routed through the BSNL as either NLDO or transit operator, the ADC amount is received directly
by BSNL from the call originating operator. For ILD calls routed through BSNL as NLDO, it receives
ADC from call originating operator in case of outgoing calls and the ILD operator for the incoming
calls. However, BSNL has also to receive ADC from cellular/ WLL(M) originating inter circle calls,
the originating ILD calls in cellular/ WLL (M) networks and terminating ILD calls carried by other
NLDO/ ILDO, or a combination thereof for the ILD calls. In addition to above BSNL has also to
receive ADC from cellular/ WLL (M) originating intra circle calls to fixed networks not routed
through BSNL...
(iii) NLD Interconnect Agreement between BSNL and Reliance dated 1st November, 2002 Chapter -
1 Definitions In this Agreement, words and expressions will have the following meanings as are
respectively assigned to them unless the contrary intention appears from the context:
"SHORT DISTANCE CHARGING AREA (SDCA)": means one of the several areas into which a Long
Distance Charging Area is divided and declared as such for the purpose of charging for long distance
calls and within which the local call charges and local numbering scheme is applicable. SDCAs, with
a few exceptions, coincide with revenue tehsil / taluk.
Chapter 2 Technical Issues Pertaining to Interconnection 2.1 Interconnectivity to BSNL Network
2.1.5 RIL shall terminate its traffic on to the network of BSNL as mandated by TRAI from time to
time. RIL and BSNL shall deliver all calls on each other's network with CLI in the terminating
SDCA. Both parties reserve the right to reject calls without CLI.
2.4 Numbering Plan 2.4.1 RIL shall be allocated carrier selection code by the LICENSOR for
dynamic selection of carrier for long distance calls. All calls for which dynamic carrier selection code
has been dialed shall be routed accordingly subject to technical feasibility.
Chapter 6 Interconnection Charges 6.1 Interconnectivity to BSNL Network 6.1.1 Provision of links to
interconnect RIL's network with BSNL's network at the technically feasible SDCC Tandem exchange
will be the responsibility of the RIL as provided under Clause 2.1.2 and 2.1.3.
6.4 Access Charges 6.4.6 If BSNL detects that Incoming International calls are being handed over or
have been made over to BSNL at any other port which is not meant for carrying such calls, BSNL
shall be free to charge RIL minimum access charge for Incoming International calls as at clause
6.4.2 above for all the calls recorded on these ports from the date of provisioning of that POI or for
the preceding two months whichever is less apart from taking other legal actions includingB.S.N.L vs Reliance Communication Ltd on 29 November, 2010

disconnection of POIs or temporary suspension of the Interconnection Agreements. No terminating
calls other than International calls shall be accepted from RIL without CLI. In case of calls without
CLI, termination charge as per clause 6.4.2 above shall be charged from RIL.
6.6.1 Access charges shall be billed by BSNL based on bulk billing of traffic recorded by BSNL at the
point of interconnection. For every STD/ ISD call carried by RIL and accepted by BSNL at POI, a
detailed billing record wherever possible or bulk billing record will be generated in the SDCC
Tandem. The RIL shall supply calling subscriber's identity for detailed billing purpose.
Findings
(i)    Introduction
12. Telecommunication is all about transferring information from one location to another. This
includes telephone conversations, television signals, computer files and other types of data. To
transfer the information, you need a channel between the two locations. This may be a wire pair,
radio signal, optical fiber, etc. Telecommunication companies receive payment for transferring their
customer's information, while they themselves pay to establish and maintain the channel.
(ii) Relevant technical terms used in the Interconnect Agreement r/w the addenda
(a) Gateway Mobile Switching Centre (GMSC): It is a special kind of MSC that is used to route calls
outside the mobile network. Whenever a call for a mobile subscriber comes from outside the mobile
network or the subscriber wants to make a call to somebody outside the mobile network, the call is
routed through GMSC. In short, it serves as an interconnection between MSC and PSTN (network).
(b) PSTN: It means Public Switched Telephone Network.
The term `PSTN' refers to inter-connection of switching systems in the PSTN (Exchange). Switching
network refers to the component inside a switching system that switches one circuit to another
circuit.
(c) Point Of Interconnection (POI): It is a point at which the GMSC of a mobile network of UASL
and the Gateway Switch of BSNL are inter-connected by a facility of inter-connection seeker
(Reliance in this case).
(d) Trunk Group: It consists of several trunks (lines) provided as a group by the local telephone
company or any other carrier. Trunk group is a part of POI (see clause 2.1.13).
(e) Unified Access Services: It means a telecommunication service provided by a telecommunication
system for conveyance of messages through wired or wireless telegraphy. The Unified AccessB.S.N.L vs Reliance Communication Ltd on 29 November, 2010

Services refer to transmission of voice or non- voice messages over the network of the licensee
(Reliance in this case). It, however, does not cover broadcasting of messages. However, the
subscriber has to be registered and authenticated at the network point of registration and approved
numbering plan shall be applicable. Thus, UASP is the abbreviated term for the expression "Unified
Access Service Provider".
(f) International Gateway: A Gateway is a network point that acts as an entrance to another network.
Conceptually, it is the point of inter-connection (POI), i.e., the point of entry for the international
calls to the telecom network of India. A POI is a mutually agreed upon point of demarcation where
the Exchange of traffic between the two telecom networks takes place. In the case of international
calls traffic, i.e., inter-country telecommunications, the POI is the International Gateway. In this
case, we are concerned with the international gateway of BSNL. However, for intra- country calls
traffic, every local telecom network provider (Reliance in this case) is supposed to set up a local POI
which acts as the entry point for all incoming telecom traffic. The local POI has got to be under the
care and control of the local telecom provider for whose network the local POI acts as an entry point.
This local POI is the location where details of all incoming landing telecom traffic, namely, the CLI
number, their destination number, their time-stamp details, their duration, etc. have to be logged
for future accounting and tracing requirements. Thus, we have two kinds of POIs, namely,
international POIs and local POIs. Similarly, we also have two kinds of CLIs, namely, local and
international CLIs.
(g) Calling Line Identification (CLI): CLI means information generated by the Network capability
which identifies and forwards the calling number through the interconnected BSNL's/ UASL's
network.
(h) Gateway Switch: It is a switch which has the capability to perform Gateway functions like
sending and receiving signals, sending and receiving various types of information to the other
operators' network in a multi- operator environment such as operators' identity, charging area
information, etc. as well as transportation of CLI, generating call data records (CDRs) for an off line
billing system giving all necessary details of the call for proper settlement of accounts in a
multi-operator environment and security monitoring functions.
(i) National Long Distance Service Operator (NLDO):
means the telecom operator who provides the required digital capacity to carry long
distance telecommunication service within the scope of license which may include
various types of services such as voice, data, fax, text, video and multimedia, etc.
(j) Short Distance Charging Centre (SDCC): It is an Exchange in a Short Distance
Charging Area declared as such for the purpose of charging long distance trunk calls
as defined in the National Fundamental Plan.
(k) Long Distance Charging Centre (LDCC): It means a Trunk Exchange in the Long
Distance Charging Area declared as such for the purposes of charging long distanceB.S.N.L vs Reliance Communication Ltd on 29 November, 2010

calls.
(l) TAX: It means Trunk Automatic Exchange.
(m) Billing: It is defined in Clause 6.2.1 of the Interconnect Agreement. For every
STD/ISD calls originating from the network of the licensee (Reliance) and accepted
by BSNL, a detailed billing record is generated in the LDCC Exchange. For this
purpose the subscriber's identity shall be supplied by the licensee (Reliance) for
detailed billing purpose.
(n) Inter-connect Usage Charges (IUC): IUC is payable by UASL (Reliance) to BSNL
under the Interconnect Agreement for the calls originating in the network of UASL
and which calls are in turn handed over to the network of BSNL. IUC includes
termination charge, carriage charge, transit charge and access deficit charge (ADC) as
applicable.
(o) Access Deficit Charge (ADC): The Access Deficit Charge is an amount given to an
operator to compensate for the difference between the actual cost of providing a
particular service and the mandated lower tariff for providing the service to a class of
subscribers, usually rural. ADC is compensatory in the sense that ADC is meant to
subsidize the rural infrastructural projects of BSNL by the private service providers
who at the relevant time did not cater to the rural areas. IUC consisted of carriage,
termination and access deficit charges (see clause 6.4.1).
(iii) Obligations of the UASL Licensees under the Agreement
13. For the sake of easy understanding, we need to discuss the above terms in the Agreement in the
light of international call(s) coming to India and not vice-versa.
14. The basic underlying principle of clause 6.4.6 is that an international call shall remain
international right from the point of origination to the point of termination.
15. At the outset one needs to ascertain the contractual obligations of the UASL (Reliance in this
case) under the Agreement as modified by the addenda dated 28th February, 2006.
16. Interconnection agreement prescribes terms and conditions under which two licensees or service
providers interconnect their networks to allow their respective subscribers to have seamless access
to each other's networks. It is a binding contract that binds each contracting party with respect to
interconnection arrangements including commercial, technical and operational. However, the scope
and content of each such contract may vary. Under the said Agreement, IUC payments are divided
into four heads: (i) originating charges; (ii) carriage charges; (iii) termination charges; and (iv) ADC
payments. ADC payment, as a concept, is a fee paid by cellular, UAS, national long distance and
international long distance subscribers. This payment is in the nature of tax as no service is
rendered in return. ADC payments are to cross subsidize BSNL for developing its fixed network inB.S.N.L vs Reliance Communication Ltd on 29 November, 2010

non-lucrative areas. The licensee(s) makes ADC payments based on their adjusted gross revenues.
These payments are later on transferred to BSNL. An IUC charge is, thus, a payment by one service
provider to another for the use of network elements to originate, transit or terminate calls. BSNL
receives ADC payments for international calls made to fixed numbers. These payments are made by
either national long distance licensee(s) or international long distance licensee(s) that collects them.
BSNL receives ADC payments for all international calls from cellular and limited mobility numbers.
These payments are collected by ILDOs and given to BSNL. Similarly, ADC payments on calls from
international roaming subscribers are collected by host service providers and paid to BSNL. ADC
payments for international calls are higher than similar payments for national long distance or local
calls. This has tempted some licensees to engage in ingenious schemes to avoid making ADC
payments. One such scheme is masking. Call masking takes place when a licensee deliberately alters
the identity of an incoming international call before handing it over to another service provider at an
interconnection point, i.e., POI. The international calling party's identity is obliterated (i.e.
international CLI is wiped out) and the said international call is made to appear as it were from a
domestic/ national number. This technique enables evasion of ADC payments at enhanced rates for
international calls. Today, all private automated branch exchanges (PBX) are computerized. It is
important to note that a Caller ID (CID) is a signal. Most subscribers have a caller ID display unit at
their residence to receiver caller ID signals which also indicates the nature of the call - whether it is
local/ national or international. As stated, whenever a call for a mobile subscriber comes from
outside the mobile network or vice-versa, the call is routed through a special kind of gateway switch
which is called as GMSC. It serves as an interconnection between mobile switching centre and
PSTN, which is a network. However, it is at the POI (point of interconnection) that the GMSC of the
mobile network of UASL gets interconnected to the GMSC of BSNL by a facility of the
interconnection seeker (which in this case happens to be Reliance). Broadly speaking, we have two
types of POI, namely, international and local POI. Under the Agreement, UASL agrees to ensure that
its interconnect facilities delivered at each POI conforms to the specified standards for
interconnection and that UASL shall be responsible to provide, install, test, etc. all such
interconnection facilities on its side of POI. Therefore, every POI has two sides. Eg. in our case, one
side of POI is that of BSNL and the other side is that of Reliance. The Calling Line Identification
(CLI) means information generated by the network capability which identifies and forwards the
calling number through the interconnected BSNL's network. Under clause 2.1.13, Trunk Group is a
part of POI. One must keep in mind that the above aspects are not only technological, they are
maintained for billing and accounting purposes. They generate data(s) in the form of CDRs and
billing records in detail at the International Gateway Exchange of ILDO (International POI), at the
NLDO Trunk Automatic Exchange of NLDO (National POI) and Local Telephone Exchange of BSO
(Local POI for our understanding). At each stage, the billing record is generated so that if an UASL
is riding on the network of BSNL, the former has to pay for the incoming international call in terms
of duration, etc. and even in the case of local calls or national calls which includes the distance
parameter. Under clause 2.1.13, the fully mobile, limited mobile and fixed services network of UASL
shall be having separate POIs with BSNL, which shall be treated separately for set up costs, port
charges, etc. Under clause 2.1.15.3.3, for the purpose of international call the UASL shall handover
the call to BSNL at the originating Long Distance Charging Centre (i.e. LDCC TAX). Lastly, under
clause 6.4.7, all the required information shall be submitted in the form of monthly certificate as
prescribed in Schedule I shall be submitted to BSNL by UASL. It will indicate details of the trafficB.S.N.L vs Reliance Communication Ltd on 29 November, 2010

routed other than through BSNL as NLDO/ILDO in respect of international long distance calls (both
incoming and outgoing). It also indicates procedure for billing and recovery of ADC inter alia in
respect of ISD calls (both incoming and outgoing). This is relevant also because under clause 2.1.5.2
calls from fully mobile subscribers of other Telecom Service Providers of the different service area
(national roaming) or Other Country (international roaming) have got to be handed over by UASL to
BSNL on separate trunk groups at the Gateway TAX of BSNL of that service area. Under clause
2.1.9.2, no by pass of traffic shall be resorted to by any party by delivering the traffic at any POI
other than the specified POI and in case unauthorized diversion in routing comes to notice, BSNL
shall be free to disconnect that POI in that area. Thus, under the Agreement if UASL like Reliance
receives an international call at its exchange, its primary duty will be under the contract to identify it
and to forward it to the appropriate trunk group of BSNL. Now, as alleged if the international call(s)
falls on the local POI of Reliance, the latter is obliged under the contract to identify the call, whether
it is local or national or international, and accordingly forwards it to the appropriate trunk group of
BSNL. For the above reasons, it is also stipulated in clause 2.9.1 (which deals with network integrity
and screening) that it shall be the duty of the UASL to prevent wrong transmission. In fact, under
clauses 2.9.2 and 2.9.3 the establishment of proper screening function at its Gateway shall be the
obligation of the UASL so as to detect signals outside the inter-working specification of TEC. As a
corollary, clause 6.4.6(a) inter alia provides that calls on non-specified trunk groups (like
international calls landing on the local POIs), if detected, for which the IUC rate applicable is higher
(for example, for international calls the IUC rate is much higher than IUC rates for local/national
calls), then the higher IUC rate would be applicable for such unauthorized calls. In such a case,
BSNL would be free to charge the UASL the higher IUC for all calls recorded on these POIs from the
date of provisioning of that POI [at Vadodara in this case] or for preceding two months, whichever is
less. Similarly, under clause 6.4.6(b), if the UASL masks or disguises the international call as local
call that UASL will have to pay the higher IUC rate meant for international calls to BSNL from the
date of provisioning of that POI or for preceding two months, whichever is less. Thus, if there is
masking of CLI for the calls generated and forwarded from the telephone of UASL, then it would be
the primary duty of that UASL to prevent such misuse and failing which BSNL would be free to
invoke clause 6.4.6. It is important to note that clause 6.4.6 restricts the charge to last two preceding
months. The charge under clause 6.4.6 is not dependent upon number of calls and even the period
of misuse of services is restricted to last two preceding months. Thus, when an international call, as
in this case, lands on the local POI of the UASL it knows the nature of the call. There is a difference
between an international CLI and the local/national CLI. The billing record of that POI indicates the
nature of the call. It is the contractual obligation of the UASL to maintain the billing records in
detail (including the CDR and the monthly certificate in the prescribed form). Further, when the
international call(s) lands at the local POI of the UASL, the incoming traffic bypasses the authorized
route - international gateway exchange of BSNL, the NLDO trunk exchange of NLDO and the local
telephone exchange of BSO. Thus, the defaulting UASL fails to maintain the billing records
(including CDRs at each stage). This results in concealment of details which results in reduced
payment of IUC charges by the defaulting UASL, thus, giving him the unauthorized benefit of paying
less ADC which was the major component of IUC at the relevant time and which reduces the cost of
providing services which in turn results in destroying the "principle of level playing" which is so
important in the regulatory regime because pricing of the services in the international market plays
an important role. The above modus operandi enables the defaulting UASL to sell his productB.S.N.L vs Reliance Communication Ltd on 29 November, 2010

(services) abroad at a rate which may be less as compared to the rates charged by BSNL (who is also
a Competitor Service Provider). The unauthorized call(s) gets for the defaulting UASL not only more
profits by cost reduction, he also gets more business at the rates below the competitive rates. Same
is the position in case of masking of international calls as local calls. In this connection, it is
important to note that when an international call(s) lands on the local POI of the UASL, the latter
knows from the display mechanism at his end (like the subscriber at his end) that call bears the
international CLI and that is the reason for masking. Otherwise one needs no masking of the CLI. In
both the cases i.e. under clauses 6.4.6(a) and 6.4.6(b) the same economic and financial
consequences flows and that is the reason why clause 6.4.6 provides for reasonable pre- estimate of
damage. There is one more reason. It is not possible to trace each such unauthorized call,
particularly its nature, as to from which place it originated and if it was possible the cost of tracing
such call(s) may be much more than actual damage, if ascertainable, and therefore, a "rough and
ready measure" is provided in clause 6.4.6 which measure is a reasonable pre-estimate of damage.
(iv) Whether clause 6.4.6 represents penalty or pre-
estimate of reasonable compensation for the loss?
17. According to Chitty on Contracts "whether a provision is to be treated as a penalty is a matter of
construction to be resolved by asking whether at the time the contract was entered into the
predominant contractual function of the provision was to deter a party from breaking the contract
or to compensate the innocent party for breach. The question to be always asked is whether the
alleged penalty clause can pass muster as a genuine pre-estimate of loss". (See para 26-126 of Chitty
on Contracts, 30th edition) The fact that damage is difficult to assess with precision strengthens the
presumption that a sum agreed between the parties represents a genuine attempt to estimate it and
to overcome the difficulties of proof at the trial. According to the Law of Contract by G.H. Treitel
(10th edition), a clause is penal if it provides for "a payment stipulated as in terrorem of the
offending party to force him to perform the contract. If, on the other hand, the clause is an attempt
to estimate in advance the loss which will result from the breach, it is a liquidated damages clause.
The question whether a clause is penal or pre-estimate of damages depends on its construction and
on the surrounding circumstances at the time of entering into the contract". Lastly, the fact that a
sum of money is payable on breach of contract is described by the contract as "penalty" or
"liquidated damages" is relevant but not decisive as to categorization.
18. Applying the above tests to facts of this case, we find that the Interconnect Agreement in
question should be viewed in the context of the regulatory regime. In this case, we are concerned
with telecom as a service. This is the most important circumstance to be considered as one of the
main surrounding circumstances to the Interconnect Agreement. Under the Interconnect
Agreement, the UASL is obliged to maintain the integrity of its exchange/POI. It is important to
note that each service provider, including BSNL, is a market player/stakeholder. Each UASL is
entitled to a level playing field. The nature of the call, be it local or national or international, as
indicated by corresponding CLI, is the basis for the levy of IUC (including ADC). If by wrong routing
of calls or by masking the cost of providing services is reduced, the concerned operator gets an
undue advantage not only in the Indian market over other competing operators but also in theB.S.N.L vs Reliance Communication Ltd on 29 November, 2010

international market. Billing is one of the most vital aspects of this case. With technology, an
international call could fall on the local POI but then the concerned operator is responsible for the
identity of the call. In the case of calls which are correctly routed, the display screen with the
subscriber clearly indicates whether the call bears international or local/national CLI. Similarly,
when the Gateway Bypass Scam takes place and the international call(s) lands on the local POI
which is not forwarded to the specified trunk group/POI, there is not only bypassing of
International Gateway/ POI and National POI but also evasion of duty to maintain billing records in
detail at each POIs.
19. All this results in payment of IUC at a lower rate. All this leads to reduced cost for the defaulting
UASL which provides not only increase in its profit but also gives it an advantage in international
market vis-a-vis other competitors (including BSNL) because the defaulting UASL can easily price
its product in the international market at a lower rate and in that sense loss is caused to BSNL.
Similarly, as stated above, masking takes place as international CLI can easily be identified even
when an international call lands on the local POI of the UASL, hence, the defaulting UASL resorts to
masking. Hence, an international call coming from the masked number alone cannot be taken into
account. Thus, in our view, clauses 6.4.6(a) and 6.4.6(b) provide for pre-estimate of damages. It is
so also for one more reason. The clause, as stated above, restricts the higher IUC rate made
applicable for calls only for last two preceding months and not for last three years or the longer
period. These time lines is an indicia showing that clause 6.4.6 is not penal but a pre-estimate of
reasonable compensation for the loss foreseen at the time of entering into the agreement. Lastly, it
may be noted that liquidated damages serve the useful purpose of avoiding litigation and promoting
commercial certainty and, therefore, the court should not be astute to categorize as penalties the
clauses described as liquidated damages. This principle is relevant to regulatory regimes. It is
important to bear in mind that while categorizing damages as "penal" or "liquidated damages", one
must keep in mind the concept of pricing of these contracts and the level playing field provided to
the operators because it is on costing and pricing that the loss to BSNL is measured and, therefore,
all calls during the relevant period have to be seen. [See Communications Law in India by Vikram
Raghavan at page 639]. Since clause 6.4.6 represents pre-estimate of reasonable compensation,
Section 74 of the Contract Act is not violated. Thus, it is not necessary to discuss various judgments
of this Court under Section 74 of the Contract Act.
Conclusion
20. We need to clarify that in this case our judgment is restricted only to the interpretation of clause
6.4.6 of the Interconnect Agreement read with the Addenda. As stated above, we have held that
clause 6.4.6 represents pre-estimate of reasonable compensation for the loss suffered by BSNL.
Thus, we set aside the impugned judgment and remit the matter to TDSAT to decide the matter de
novo in accordance with the law laid down hereinabove. However, we need to highlight one aspect.
In the letter dated 13th October, 2004 addressed by BSNL to Reliance, it has been alleged that the
calls have landed at the POIs of M/s. Reliance Infocomm. Ltd. at Karellbaug, Panigate, Alkapuri,
Makarpura, Padra, Dabhoi and Miyagam exchanges in Vadodara SSA. The said letter highlights one
more important aspect. It is alleged that the number 2813041000 was an unallocated number with
Reliance during the relevant period. This aspect needs to be examined by TDSAT on facts.B.S.N.L vs Reliance Communication Ltd on 29 November, 2010

21. Accordingly, the civil appeal is allowed with no order as to costs.
........................................CJI (S. H. Kapadia) ...........................................J. (K.S. Panicker
Radhakrishnan) ...........................................J. (Swatanter Kumar) New Delhi;
November 29, 2010B.S.N.L vs Reliance Communication Ltd on 29 November, 2010

