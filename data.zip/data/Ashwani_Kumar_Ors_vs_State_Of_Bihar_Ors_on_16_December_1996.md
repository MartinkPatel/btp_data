Ashwani Kumar & Ors vs State Of Bihar & Ors on 16 December,
1996
Equivalent citations: AIR 1997 SUPREME COURT 1628, 1997 AIR SCW 509,
1997 LAB. I. C. 578, 1997 (2) SCC 1, (1997) 1 JT 243 (SC), 1997 (2) BLJR 1772,
1997 (1) JT 243, 1998 (2) UPLBEC 1550, 1997 BLJR 2 1772, (1998) 2 UPLBEC
1550, (1997) 1 PAT LJR 59, (1997) 1 SCT 573, (1997) 2 BLJ 762, (1997) 6
SUPREME 66, 1997 SCC (L&S) 267
Author: S.B. Majmudar
Bench: S.B. Majmudar, Sujata V. Manohar
           PETITIONER:
ASHWANI KUMAR & ORS.
        Vs.
RESPONDENT:
STATE OF BIHAR & ORS.
DATE OF JUDGMENT:       16/12/1996
BENCH:
S.B. MAJMUDAR, SUJATA V. MANOHAR
ACT:
HEADNOTE:
JUDGMENT:
WITH [C.A. Nos. 10760-11058/95; 11062-66/95; C.A. No. 16746 of 1996 (arising out of S.L.P.(C)
No.6174/92; C.A. No. 16747 of 1996 (arising out of S.L.P.(C) No.14275/94; C.A. No. 16748 of 1996
(arising out of S.L.P.(C) No.7410/95; and C.A., No. 16749 of 1996 (arising out of S.L.P.(C) No. 24553
(C.C. 4638/95] J U D G M E N T S.B. Majmudar. J.
Leave granted in S.L.P.(C) Nos.6174 of 1992, 14275 of 1994. 7410 of 1995 and S.L.P.(C) No. 24553
(CC 4638/95).Ashwani Kumar & Ors vs State Of Bihar & Ors on 16 December, 1996

This group of appeals, on grant of special leave to appeal against the common judgment of Patna
High Court in CWJC No.5163 of 1993 and batch decided on 6th May 1994, has been placed before
this larger Bench by the orders of Hon'ble the Chief Justice on account of difference of opinion
between two learned judges of this Court, K. Ramaswamy, J. and Hansaria, J., constituting the
Division Bench which earlier heard this group of matters. Before the main points for difference are
highlighted and the contentions of respective contesting parties are noted, it would be necessary to
note at the outset the backdrop facts leading to these proceedings.
Backdrop Facts One Dr. A.A. Mallick, Deputy Director, Health Department of the Government of
Bihar, was in charge of Tuberculosis for a number of years while he was working as a member of the
medical service of the State of Bihar. He was Director of the Tuberculosis Centre at Patna.
Eradication of Tuberculosis was taken up as a part of 20-Point Programme in planned expenditure.
The activities in the Tuberculosis Centre at Patna were extended to various districts. Since Dr.
Mallick happened to be the Director of the Centre, he was made Deputy Director of the Scheme. The
Government had also issued directions to the District Medical Officers to abide by the instructions
of Dr. Mallick in implementation of the programme. He was made the Chairman of Selection
Committee constituted by the Government consisting of himself. Assistant Director of Pilaria and a
senior officer representing Scheduled Castes/Scheduled Tribes to recruit 2250 class III and Class IV
employees on posts created to implement the Scheme in addition to around 800 to 900 staff in
Patna Centre in all categories. Taking advantage thereof, the undisputed fact is that, he appointed
around 6000 (as found by the Committee) while the Government asserts them to be approximately
7000. Be that as it may, not less than 6000 persons were appointed by Dr. Mallick without any
written orders. He directed many of them to be adjusted by transfer by District Medical Officers and
some of them had produced fabricated appointment orders. He shuffled their payment of salaries by
turns. Another device adopted in the macabre episode was to make the employees go on strike and
when some sensitive M.L.As. raised the question, on the floor of the State Legislative Assembly, off
illegal appointments made by Dr. Mallick, the Government initially posed the appointments to be
legal and justified his action to be valid. Later, when facts themselves proved their faulty admission,
they made amends before the Assembly and the Government made an elaborate statement apprising
the House that the information furnished earlier was not correct.
Due to the agitation, the Director an Joint Secretary to the Government. Health Department had
issued directions to regularise the services of daily-rated Class III and Class IV employees. Taking
aid thereof, it is claimed that regularisation of many of them including most of the appellants, was
made. When alarming bells rang around portals of Patna High Court by filing petitions under Article
226 of the Constitution seeking payment of salaries, the High Court, though initially in some cases
directed to enquire into the cases and to pay salaries, later found it difficult to cope up with the
situation. So an Enquiry Committee was constituted to find out whether the appointments made by
Dr. Mallick were valid and whether salaries could be paid to such employees.
In the meanwhile, the Government also directed the Vigilance Department to enquire into the
matter and on 7th May 1991, the Vigilance Department in its report pointed out that Dr. Mallick had
violated the rules of recruitment and in collusion with other officers had appointed daily-rated Class
III and Class IV employees. Pursuant to the direction of the High Court, a Screening Committee wasAshwani Kumar & Ors vs State Of Bihar & Ors on 16 December, 1996

constituted which sought to serve notice on the employees. When the Deputy Director went to the
Centre at Patna to serve the notice on the employees, he was min-handled resulting in an ugly law
and order situation. In consequence, notices were published on two different dates in different
newspapers inviting submission of the claims by all the employees appointed by Dr. Mallick,
together with supporting material justifying their appointments. Different dates of hearing by the
Committee were staggered. About 987 employees appeared before the Committee and submitted
their statements. In the meanwhile, relevant records were burnt out. The High Power Committee in
the absence of authentic record was constrained to depend upon the statements made by the
employees before it. After hearing them and considering the record placed before it, the Committee
found that Dr. Mallick did not make any order of appointment on daily wage basis by following due
procedure. It found it difficult to accept even the orders of confirmation. In that view, the
Committee found that the initial appointments made by Dr. Mallick were in violation of the
instructions issued by the Government. Therefore, they were found to be illegal appointments. The
Committee also found that Dr. Mallick circumvented the rules by making adjustment by transfer
without verifying the qualifications, eligibility or disclosing previous places where at the candidates
appointed had worked and dates of their appointment and by transferring them to the respective
places by cyclostyled orders. He directed the District Medical Officers to verify the credentials and
then to appoint them temporarily. The Committee also noted that the third category was of persons
who were appointed by producing fabricated orders of appointment. Consequently, it directed to
cancel all the appointments made by Dr. Mallick. On receipt of the report and on its consideration,
the Government found them to be invalid and illegal and all the appointments were canceled. When
their legality was questioned in the writ petitions filed under Article 226, the High Court upheld the
Government action. Thus these appeals by special leave.
When this group of appeals was finally heard by the Division Bench of this Court consisting of K.
Ramaswamy, J. and Hansaria, J., as noted earlier, on hearing the arguments of learned counsel
appearing for the contesting parties, there arose a difference of opinion between the two learned
judges. K. Ramaswamy, J., came to the following conclusions:
1. Even though it was open to the Government to create posts or to fill up the posts
independently of existence of any law or statutory rules made under the proviso to
Article 309 of the Constitution to that effect, the said exercise had to be consistent
with the right guaranteed under Articles 14 and 16(1) of the Constitution of India.
2. When planned expenditure is required to be spent, budgetary sanction is
mandatory. In the present cases when some of the employees were sent for one
month's training posts were created and budgetary sanction was obtained. The cases
at hand were unique and the device adopted by Dr. Mallick was in flagrant violation
of all norms of administrative procedure known to law. He had given decent burial to
procedure prescribed by the Government. Abusing the absolute power secured in his
hands, he appointed 6000 persons at his whim and wagery.
3. Procedure for appointment to Class III and Class IV posts was given a go-by.
Instead casual appointments were made without any letters of appointment to fill upAshwani Kumar & Ors vs State Of Bihar & Ors on 16 December, 1996

even non-existing vacancies.
4. Existence of post or vacancy was a sine qua non for making appointments to such
existing posts or vacancies and as there were no 6000 posts or vacancies available,
the recruitment made by Dr. Mallick to these posts was patently illegal and without
authority of law.
5. When initial appointments were in violation or in negation of the rules or in other
words when there were no orders for appointment there would remain no question of
regularisation of such initially illegal appointments. To confer permanency of
appointment to the posts by regularisation in violation of the executive instructions
or rules is itself subversive of the procedure.
6. Without following due procedure prescribed under the circulars, regularisation of
services of daily wage employees could not be effected.
7. Principles of natural justice were not required to be followed in the present cases.
Even otherwise there was due compliance with these principles.
8. As all the appointments were made in flagrant breach of the procedure and the
executive instructions and amounted to blatant abuse of the centralised power held
by Dr. Mallick and subversive of discipline, it was futile to issue writs as prayed for.
9. However Ramaswamy, J. was inclined to issue 11 directions in para 36 of his
judgment for future recruitment of class III and IV employees in the Tuberculosis
Eradication Programme, providing certain safeguards for considering the feasibility
of recruiting the present appellants on these posts.
In view of the aforesaid findings and conclusions K. Ramaswamy, J. was inclined to dispose of the
appeals by confirming, subject to the aforesaid directions, the order of the High Court dismissing
the writ petitions.
On the other hand Hansaria, J., reached the following conclusions and findings :
1. For the purpose of recruiting Class III and Class IV employees in the 20-Point
Programme the procedure prescribed by Office Memorandum dated 3rd December
1980 was not required to be followed.
2. It could not be said that the procedure visualised by Office Memorandum dated
3rd December 1980 was not followed at all while regularising the appellants.
3. Non-advertisement of posts in newspapers did not cause any infirmity to the
regularisation.Ashwani Kumar & Ors vs State Of Bihar & Ors on 16 December, 1996

4. Non-information to the Employment Exchange had caused no dent to the
appointments.
5. The question of illegality in appointment of general candidates on the ground of
non-reservation did not arise as the material showed that there was reservation of
SC/ST candidates.
6. Material on record showed that in some cases regularisation was in pursuance of
the recommendations of a properly constituted Selection Committee.
7. Merit list/panel was prepared in some cases pursuant to O.M. of 3rd December
1980. But it could not be said that it was done in all cases. However, there was no
justification in finding infirmity in all the appointments because of lack of material
on record.
8. Principles of natural justice were not fully compelled with before terminating the
services of the appellants.
However, that had no nullifying effect so far as the present proceedings are concerned as they were
heard by this Court and consequently on that ground termination orders could not be set aside.
9. Even though Dr. Mallick was not justified in giving direct appointment to about 6000 persons
when there were only 2500 sanctioned posts, all the persons so employed hand not abetted, aided or
instigated Dr. Mallick in doing so, and, therefore, even though a wrong doer or a sinner has to be
punished and also those who aid, abet or instigate them but not those regarding whom only a doubt
existed.
10. About 2500 persons could have been appointed by Dr. Mallick and as there was material on
record to show that regular appointments had also been made (how many, we do not know) and as it
is not possible to know who the regularly appointed persons were the appellants, whose number is
1363, may be among those who were regularly appointed.
Consequently in view of the aforesaid findings Hansaria, J. was inclined to hold that justice had to
be tempered with mercy in the light of Article 21 of the Constitution of India and as it was doubtful
whether these 1363 appellants could be said to have been irregularly appointed, termination orders
qua them were required to be set aside. It was made clear by Hansaria, J., that the said order would
not in any way be taken advantage of except by the 1363 appellants before the Court. As noted
earlier it is this difference of opinion between the two learned judges constituting the Division
Bench, that has triggered off the present proceedings before this larger Bench.
Rival Contentions Learned counsel for the appellants vehemently submitted that there was ample
evidence on the record of these cases to show that Dr. Mallick was the appointing authority and was
duly empowered to appoint Class III and Class IV employees on the programme regarding
eradication of Tuberculosis which was taken up as a part of 20-Point Programme in the PlannedAshwani Kumar & Ors vs State Of Bihar & Ors on 16 December, 1996

Expenditure by the State of Bihar. It was further contended that the Government Order of 3rd
December 1980 did not apply to such appointments. That looking to the urgency of the Programme
the appointments had to be made on a war-footing and that is how 6000 appointments were made
by Dr. Mallick in due exercise of his authority so that the Tuberculosis Eradication Programme
could be put on an effective and strong footing. It was further submitted that these were not posts
born on any regular cadre in State Service and consequently the detailed method of recruitment for
filling up vacancies for such a Programme was not required to be followed. It was next contended
that Dr. Mallick had given due importance to the policy of reservation as applied by the State while
effecting these appointments. That in any case these appointments on ad-hoc basis were ultimately
duly approved by the State when the Committee constituted for the purpose had found them to be
valid and accordingly the employees were regularised. That thereafter it was not open to the State of
Bihar to nullify these appointments by one stroke of pen. Even that apart all the appointments
effected by Dr. Mallick which were about 6000, could not have been invalidated in a wholesale
manner which was contrary to the basic principles of the natural justice. That the so-called hearing
given by the Committee even prior to its constitution could not be said to be a hearing at all and
hence termination orders were null and void. It was ultimately submitted that for no fault of theirs
these employees who had continued for more than 10 years in service in many cases and who were
even subsequently promoted could not have been removed wholesale and hence on the principle of
fairness, equity and even invoking mercy jurisdiction of the Court they should have been continued
in service. That, if at all, they were victims at the hands of Dr. Mallick but could not be said to be
abetters and should have been dealt with in a humanitarian manner. It was contended that on the
same lines on which this Court in the case of H.C. Puttaswamy & Ors. v. The Hon'ble Chief Justice of
Karnataka High Court. Bangalore & Ors. JT 1990 (4) S 474 permitted the irregularly appointed
employees to continue in service without a break, the present appellants also should be directed to
be so continued in service after giving them reinstatement with all consequential benefits. Dr.
Dhavan, learned senior counsel appearing for the appellants in appeals which were earlier delinked
from this group but which were subsequently placed along with the group for disposal, namely, civil
appeal arising out of S.L.P.(C) No.14275 of 1994 and C.A. Nos. 10811-28 of 1995, submitted that 8
employees in civil appeal arising out of S.L.P.(C) No. 14275 of 1994 were not appointed by Dr.
Mallick but were appointed by Dr. Mithilesh Kumar and, therefore, their appointments stood on a
separate footing and could not have been nullified by adopting the general yardstick for voiding all
the appointments made by Dr. Mallick. So far as the Civil Appeals Nos. 10811-28 of 1995 were
concerned Dr. Dhavan submitted that appointments made by Dr. Mallick were in two phases, the
first phase was reflected by the Government Order dated 25th March 1983 wherein Dr. Mallick had
appointed number of employees under the Scheme. But the second phase started pursuant to the
Government Order dated 31st January 1987 whereunder a programme was instituted for training
Tuberculosis Attendants and Tuberculosis Assistants and once they were given training such
candidates became entitled to be appointed on regular basis in the Programme and as they had been
so trained there was nothing wrong in continuing them in service. Dr. Dhavan also submitted that
the Tuberculosis Eradication Scheme under 20-point Programme was entirely a separate Scheme
undertaken by the State of Bihar in collaboration with the Central Government wherein the
expenses for the infrastructure were to be shared by the State Government as well as Central
Government and there was no question of any posts being created in the regular service of the State.
Under these circumstances the regiour of the procedure of recruitment to State service as laid downAshwani Kumar & Ors vs State Of Bihar & Ors on 16 December, 1996

by the Notification to State service as laid down by the Notification of 3rd December 1980 could not
be applied to fill up the vacancies on this Scheme. Consequently no fault could be found with the
manner of recruitment adopted by Dr. Mallick especially when a Committee, duly constituted under
the Scheme by the State Government, had cleared these appointments and directed regularisation of
these ad hoc employees as initially appointed by Dr. Mallick, Dr. Dhavan further submitted that
these posts where sanctioned from time to time by State Government. That there was nothing wrong
with the regularisation of these employees and all of them could not have been terminated by one
stroke of pen contrary to all the basic established principles of natural justice and fairplay.
Ultimately it was contended that in any case by tempering justice with mercy these employees who
have now become age-barred should not be thrown out of service after number of years when they
had been recruited in service for no fault of theirs. It was, therefore, submitted by Dr. Dhavan
towing the line of other learned advocates for the appellants that the appeals should be allowed and
all the prayers put forward in the writ petitions filed in the High Court should be granted. In the
written submissions filed in Civil appeal Nos. 10831-10985 of 1995 it was submitted that the
20-point programme announced by Government of India underscored the need for eradicating the
dreaded disease Tuberculosis (T.B.). In Bihar State alone as per Government information in 1976
about half the population (current population 10 crores) was striken with T.B. and the annual death
toll was feared to be in excess of 1 lakh with 3 Lakh new cases reported every year. It was in this
background that the S.L.P. petitioners who numbered 581 were all appointed (initially ad-hoc/daily
wagers) in Class III and Class IV posts in connection with the T.B. Eradication programme in the
State of Bihar from the year 1980 onwards and were regularised on various dates thereafter (p.
146-166 S.L.P. paper book). By the additional affidavit dated 4.9.1994 particulars of the petitioners,
their dates of ad-hoc/daily-rated appointments and their dates of regularisation, and (in many
cases) subsequent promotion have been set out (pages 146-169 S.L.P. paper book). It was submitted
that the initial appointments and regularisation of these employees were valid and proper. It was
next submitted that by a letter dated 25th March 1988 the Joint Secretary (Health) confirmed and
appointed Dr. A.A. Mallick as ex-officio Chairman of the Selection Committee and by a directive
dated 24th July 1984 the Joint Secretary had directed the said Dr. Mallick to regularise the
appointments made by him and to the same effect was the subsequent letter dated 17th October
1984 to the Chairman, T.B. Hospital directing regularisation of the daily wagers. In short similar
contentions were sought to be raised in the written submissions as were advanced by learned
advocates appearing for other appellants.
Shri Singh, learned counsel appearing for the respondent-State on the other hand submitted that all
the initial appointments on ad hoc or daily-rated basis made by Dr. Mallick were patently
unauthorised and illegal for the simple reason that though there were in all 2500 sanctioned posts,
Dr. Mallick for the reasons best known to him thought it fit to appoint 6000 Class III and Class IV
employees. He threw the established procedure for recruitment of such employees to the winds and
in a most arbitrary manner adopting a policy of 'pick and choose appointed these persons. These
appointments were not backed up by financial budgets. They were totally unauthorised and could
not have been countenanced at all. As there was nothing to show as to who could be fitted in against
the sanctioned posts the State was justified on the recommendation of the Enquiry Committee to set
aside all these appointments which were ex- officio contrary to the established norms of
recruitment. That as these appointments were illegal and void from their inception there was noAshwani Kumar & Ors vs State Of Bihar & Ors on 16 December, 1996

question of regularising them and the so-called regularisation was wholly arbitrary, null and void
and of no legal effect. That ample opportunity was given to these employees to put forward their
contentions before the committee. Public notices were given inviting them to have their say be
submitting all necessary datas before the Committee. Not only that but even 987 persons did appear
before the committee. Therefore, there was no question of violation of principles of natural justice.
It was next contended by Shri Singh that there is no question of tempering justice with mercy s all
these incumbents were illegally appointed by Dr. Mallick and that it was impossible to decide in the
absence of relevant material or data on record as to who were senior enough to be adjusted against
the sanctioned 2500 posts out of the 6000 employees. Hence the only solution to the problem was
to nullify all the appointments and to start on a clean slate de novo. In reference to the contentions
of learned counsel for the appellants placing reliance on decision of this Court in H.C. Puttaswamy
(supra) it was submitted that in that case the initial appointments by the Chief Justice of Karnataka
High Court were not illegal or unauthorised as the Chief Justice had enough financial power to
create any number of posts on the High Court establishment. That what was voided was the method
by which the employees recruited on the High Court establishment were subsequently transferred to
the establishments of subordinate courts and under these peculiar circumstances the appointees
were permitted to continue in service without break. That in the present case though Dr. Mallick
was authorised to recruit staff on the Tuberculosis Eradication Scheme, as there were only 2500
sanctioned posts, the wholesale appointments of 6000 persons made by him were clearly illegal and
an exercise in futility. It was next contended that even though these posts may not be posts born on
the regular cadres in the State service they were certainly to be vacancies which were required to be
supported by sufficient financial budgets and unless there were vacancies covered by the planned
expenditure budgeted for the purpose, no such appointments could be effected. Under these
circumstances such appointees who were illegal appointees from the very beginning could not have
been regularised. So far as the submissions of Dr. Dhavan were concerned it was submitted that
there were no two phases in which appointments were made by Dr. Mallick. So far as he was
concerned there was only one phase of recruiting persons at his whims and fancies on vacancies
which did not really exist and whatever training was given to these employees also remained an
exercise in futility. So far as 8 employees covered by Civil Appeal arising out of S.L.P. (C) No. 14275
of 1994 were concerned it was submitted that Dr. Mithilesh Kumar was also directed to effect
appointments under instructions of Dr. Mallick and hence their appointments also stood on the
same footing on which direct appointees of Dr. Mallick stood and, therefore, suffered from the same
vitiating consequences. It was accordingly submitted by Shri Singh that the appeals were required to
be dismissed.
In the light of the aforesaid rival contentions the following points arise for our determination:
Points for determination
1. Whether the appointments of Class III and Class IV employees on the Tuberculosis
Eradication Scheme as a part of 20-Point programme were legal and valid.
2. Whether the confirmation of these employees was legally justified.Ashwani Kumar & Ors vs State Of Bihar & Ors on 16 December, 1996

3. Whether principles of natural justice were violated while terminating services of all
these 6000 employees appointed by Dr. Mallick.
4. What relief, if any, can be granted to the appellants.
We shall deal with these points seriatim.
So far as the initial appointments of 6000 Class III and Class IV employees by Dr. Mallick are
concerned it has to be kept in view that Dr. Mallick was Director, Tuberculosis Centre at Patna.
Eradication of tuberculosis was taken up as a part of 20-Point Programme under the Planned
Expenditure. The activities of the Programme were extended to various districts. It cannot be
disputed that Dr. Mallick was the appointing authority for these classes of employees who had to
work on the Scheme. He was duly made Chairman of the Selection Committee constituted by the
Bihar State Government. The Committee consisted of Dr. Mallick, Assistant Director of Pilaria and a
senior officer representing Scheduled Castes/Scheduled Tribes. This Committee was entrusted with
the task of recruiting 2250 Class III and Class IV employees. These posts were created to implement
the Scheme in addition to 800-900 staff in Patna Centre in all categories. It goes without saying that
the budgeted expenditure for recruitment of 2250 employees on these sanctioned posts was a
planned expenditure. As these were the only sanctioned posts under the Scheme it passes one's
comprehension as to how Dr. Mallick could persuade himself to recruit 6000 employees on these
2250 sanctioned posts. Learned counsel for the appellants in written submissions tried to urge that
there were more sanctioned posts while the learned counsel for the State of Bihar tried to assert that
Dr. Mallick had appointed approximately 7000 persons. But as both the learned judges constituting
the Division Bench, namely, K. Ramaswamy, J. and Hansaria, J. proceeded on the accepted position
on record that Dr. Mallick unauthorisedly appointed 6000 employees on the sanctioned 2250 posts
we will proceed on that basis. It becomes, therefore, clear that at least 3750 employees were drafted
in the Scheme by Dr. Mallick without there being any vacancies to receive them. Under these
circumstances their initial entry must be held to be totally unauthorised, incompetent and void. It is
axiomatic that when these recruitments were not supported by any budgetary grants there will be no
occasion to make available finances to meet their salary expenses. Even apart from that, Dr. Mallick
threw all the discretion to the winds, acted as monarch of what he surveyed and in a most arbitrary
fashion adopting the principle of 'pick and choose', recruited these 6000 employees completely
violating the established norms and procedures for recruiting Class III and Class IV employees as
laid down by the State government from time to time. We agree with the contention of Shri Singh,
learned counsel for the respondent-State that all these recruitments made by Dr. Mallick were
arbitrary, capricious and were null and void as he did violence to the established norms and
procedures for recruiting such employees, Dr. Mallick was not giving appointments to these
employees on his private establishment. He was recruiting them in a government Programme which
was supported by Planned Expenditure. Such recruitment to Public services could not have been
effected in such a cavalier fashion in which it was done by Dr. Mallick. We are not in a position to
persuade ourselves to agree with the contention of learned counsel for the appellants that the
Government Order of 3rd December 1980 would not apply to these recruitments as this was a
unique and distinct Scheme under 20-Point Programme. Even if it was a scheme under 20-Point
Programme it was to be carried out as per planned expenditure. It is obvious that when plannedAshwani Kumar & Ors vs State Of Bihar & Ors on 16 December, 1996

expenditure is required to be incurred, budgetary sanction is a sine qua non. unfortunately Dr.
Mallick treated this Scheme as his private property. The device adopted by him was in flagrant
violation of all norms of administrative procedure known to law. In this connection we may
profitably refer to Government Order dated 3rd December 1980 which is found at page 344 of the
Paper Book in Civil Appeal Nos. 10758-59 of 1995. This Government Order deals with the procedure
of appointment to Class-3 Posts in Government offices. There is a similar Government Order of even
date for recruitment of Class-4 servants. That is annexed at page 352 in this very Paper Book. it is
issued by the Department of Personnel and Administrative reforms, Bihar State. As this recruitment
was done in a centralised manner at Patna for different districts under Tuberculosis Eradication
Scheme to be carried out in all the districts in a phased manner, we may refer only to that part of
this Government Order which referred to the procedure to be adopted for recruitment in Secretarial
Services at Patna. it has been in terms laid down that in the Secretariat and its attached offices, a
Selection committee shall be constituted. It will be chaired by the head of the concerned
establishment and one of the members of this committee will be any senior officer as nominated by
the Head of the Establishment. Other members of the committee will be officers belonging to SC/ST
working in the same department. As per this G.O. so far as recruitment to Class III posts is
concerned a merit list has to be prepared on the basis of marks obtained by the candidates at school
or college examinations and appointment to the vacant posts will be made according to the
instructions enclosed with the concerned Resolution. The vacancies will have to be communicated to
the nearest employment Exchange of respective areas wherein the concerned offices exist. so far s
G.O. concerning recruitment to Class IV servants is concerned, the Committee appointed for the
purpose has to publish the advertisement through the Employment Exchange as per the direction
contained in appointment Department Circular No. 8160 dated 21st June 1966. Government
instructions regarding reservation for SC/ST also have to be adhered to. It is not in dispute that
none of these instructions and the procedure laid down for recruiting Class III and class IV
employees were followed by Dr. Mallick while recruiting adhoc/daily wage employees at the initial
stage in the Tuberculosis Eradication Scheme supervised and monitored by him. However, learned
counsel for the appellants vehemently submitted that these two Government orders would not apply
and what applied for these recruitments was the government Resolution dated 25th March 1983. It
is found at page 404 of the Paper Book in these civil appeals. The said Resolution of the Bihar
Government in the Health Department issued under the signature of Joint Secretary to the
Government shows that in super session of all the previous orders, the State Government had
decided to constitute Selection Committee for regular appointment against the posts of class III and
class IV under Malaria, filaria and T.B. Programme. The officers noted against their names would
function as Chairman and members. A mere look at this Resolution shows that it indicates the
appointing authorities who have to recruit staff on the concerned programme mentioned therein.
Dr. Mallick would necessarily, therefore, be the Chairman of the Tuberculosis Control Programme
Recruitment Committee. But the very Resolution indicates that recruitment had to be for regular
appointments to be made by the Selection committees to Class III and Class IV posts under Malaria,
filaria and T.B. Programme. Therefore, recruitment was to be done in a regular manner against
available posts. It never gave a blanket power to Dr. Mallick to create new posts which were not
sanctioned and to make recruitment thereon. Nor did it give any authority to throw the recruitment
procedure for recruiting such class III and Class IV employees to the winds and to make recruitment
in an arbitrary manner at his whims and fancies. Nowhere this Resolution indicates that the earlierAshwani Kumar & Ors vs State Of Bihar & Ors on 16 December, 1996

Government Orders laying down the procedure regarding recruitment to Class III and Class IV posts
were to be given a go-by. Consequently the Resolution of 25th March 1983 has to be read along with
the government Orders dated 3rd December 180 and not de hors them. The supersession of the
previous orders as contemplated by the Resolution of 25 March 1983 was only to the limited extent
that the Selection committee mentioned in the said Resolution will be the committee for appointing
such persons on the concerned programmes and to that extent the recruiting authority as mentioned
in the earlier Government Orders would stand superseded but it did nothing more than that. The
procedure for recruitment, however, would remain the same even for the newly constituted
Selection committee as per the resolution of 25th March 183. consequently it is not possible to agree
with the contention of learned counsel for the appellants that this Resolution of 25th March 1983
displaced and gave a send-off to the recruitment procedure laid down by the Government Orders of
3rd December 1980. It is also equally not possible to agree with the contention of learned counsel
for the appellants that s the recruitment was to be made on Tuberculosis Eradication Scheme under
20- Point Programme and the appointments were not to be made to posts on any regular order of
Bihar State Service the recruitment procedure laid down by earlier government Orders of 3rd
December 1980 would not stand attracted. It is easy to visualise that though the vacancies or posts
as the case may be, may not be in the regular Bihar State Service but would be in the concerned
programmes or schemes, nonetheless there would have to be recruitment to the sanctioned
vacancies necessarily backed up by the financial budget support, to be made available by the State as
per 20-Point Programme under its liability to contribute towards the same along with Central
Government. It is axiomatic that unless there is vacancy there is no question of filling it up. There
cannot be an employee without a vacancy or post available on which he can work and can be paid as
per the budgetary sanctions. It appears that Dr. Mallick suffering from wrong nations of power and
authority under the said Government Resolution and without bothering to find out whether there
were vacancies or not under the Scheme indulged in self-help to recruit as many class III and Class
IV employees as suited him and the result was that he loaded a dead weight of burden of these
employees on the State exchequer by resorting to a completely unauthorised exercise. The State
authorities were justified in refusing to release salaries for paying this unauthorised army of staff
which represented a host of unwelcome guests. They were all persons non grata and were not
employees in the real sense of the term. It must, therefore, be held that the appointments of 6000
employees as made by Dr. Mallick in the Tuberculosis Eradication Scheme were ex facis illegal. As
they were contrary to all recognised recruitment procedures and were highly arbitrary, they were
not binding on the State of Bihar. The first point for determination, therefore, will have to be
answered in the negative.
So far as the question of confirmation of these employees whose entry itself was illegal and void, is
concerned. It is to be noted that question of confirmation of regularisation of an irregularly
appointed candidate would arise if the concerned candidate is appointed in an irregular manner or
on adhoc basis against an available vacancy which is already sanctioned. But if the initial entry itself
is unauthorised and is not against any sanctioned vacancy, question of regularising the incumbent
on such a non-existing vacancy would never service for consideration and even if such purposed
regularisation or confirmation is given it would be an exercise in futility. It would amount to
decorating a still-born baby. Under these circumstances there was no occasion to regularise them or
to give them valid confirmation. The so-called exercise of confirming these employees, therefore,Ashwani Kumar & Ors vs State Of Bihar & Ors on 16 December, 1996

remained a nullity. Learned counsel for the appellants invited our attention to the chart showing the
details of appointments of the concerned appellants as found at Annexure XXII at pages 243 to 255
of the Paper Book and also as a specimen a subsequent order of confirmation as found at page 256
in the case of Ashwani Kumar. It was submitted that such confirmation orders were also given to
number of employees who were initially appointed as daily wagers/T.B. Assistants by Dr. Mallick.
Our attention was also invited to the letter of Joint Secretary Shri Anant Shukla written to the
Superintendent, T.B. Hospital, Koelwar, Bhojpur on 17th October 1984 which is found as
Annexure-X at page 147 of the Paper Book to show that steps were taken for ratification of the
orders of appointment of the daily wage employees as per the direction of Deputy Director,
T.B./Health Services, Bihar. As we have seen earlier when the initial appointments by Dr. Mallick so
far as these daily wagers were concerned, were illegal there was no question of regularising such
employees and no right accrued to them as they were not confirmed on available clear vacancies
under the Scheme. It passes one's comprehension as to how against 2500 sanctioned vacancies
confirmation could have been given to 6000 employees. The whole exercise remained in the realm
of an unauthorised adventure. Nothing could come out of nothing. Ex nihilo nihil fit. Zero
multiplied by zero remained zero. consequently no sustenance can be drawn by the appellants from
these confirmation orders issued to them by Dr. Mallick on the basis of the directions issued by the
concerned authorities at the relevant time. It would amount to regularisation of back door entries
which were vitiated from the very inception of learned counsel for appellants that the vacancies on
the Scheme had nothing to do with regular posts. Whether they are posts or vacancies they must be
backed up by budgetary provisions so as to be included within the permissible infrastructure of the
Scheme. Any posting which is dehors the budgetary grant and on a non- existing vacancy would be
outside the sanctioned scheme and would remain totally unauthorised. No right would accrue to the
incumbent of such an imaginary or shadow vacancy.
In this connection it is pertinent to note that question of regularisation in any service including any
Government service may arise in two contingencies. Firstly, if on any available clear vacancies which
are of a long duration appointments are made on ad hoc basis or daily wage basis by a competent
authority and are continued from time to time and if it is found that the concerned incumbents have
continued to be employed for a long period of time with or without any artificial breaks, and their
services are otherwise required by the institution which employs them, a time may come in the
service career of such employees who are continued on ad hoc basis for a given substantial length of
time to regularise them so that the concerned employees can give their best by being assured
security of tenure. But this would require one pre-condition that the initial entry of such an
employees must be made against an available sanctioned vacancy by following the rules and
regulations governing such entry. The second type of situation in which the question of
regularisation may arise would be when the initial entry of the employee against an available
vacancy is found to have suffered from some flow in the procedural exercise though the person
appointing is competent to effect such initial recruitment and has otherwise followed due procedure
for such recruitment. A need may then arise in the light of the exigency of administrative
requirement for waiving such irregularity in the initial appointment by competent authority and the
irregular initial appointment may be regularised and security of tenure may be made available to the
concerned incumbent. But even in such a case the initial entry must not be found to be totally illegal
or in blatant disregard of all the established rules and regulations governing such recruitment. InAshwani Kumar & Ors vs State Of Bihar & Ors on 16 December, 1996

any case back door entries for filling up such vacancies have got to be strictly avoided. However,
there would never arise any occasion for regularising the appointment of an employee whose initial
entry itself is tainted and is in total breach of the requisite procedure of recruitment and especially
when there is no vacancy on which such an initial entry of the candidate could ever be effected. Such
an entry of an employee would remain tainted from the very beginning and no question of
regularising such an illegal entrant would ever survive for consideration, however competent the
recruiting agency may be. The appellants fall in this latter class of cases. They had no case for
regularisation and whatever purported regularisation was effected in their favour remained an
exercise in futility. Learned counsel for the appellants, therefore, could not justifiably fall back upon
the orders of regularisation passed in their favour by Dr. Mallick. Even otherwise for regularising
such employees will established procedure had to be followed. In the present case it was totally
by-passed. In this connection we may profitably refer to Government Order dated 31st December
1986 to which our attention was invited by learned counsel for the appellants. The said government
Order is found in the additional documents submitted in C.A. Nos. 10758-59 of 1995 at
Annexure-IV. Secretary to Government of Bihar, Health Department, by communication dated
31.12.1986 had informed all regional deputy directors, health Services; Tuberculosis civil
surgeon-cum-Chief Medical officer; and other concerned authorities in connection with the
compliance and implementation of the orders passed and instructions issued by Deputy director
(Tuberculosis) Bihar, Patna under the Tuberculosis control Programme covered under the 20-Point
programme. It was stated in the said Communication that steps will be taken to fill up sanctioned
Third and fourth Grade posts as soon as possible according to the prescribed procedure and all
possible efforts should be made to achieve the fixed targets in a planned and phased manner. Even
this letter clearly indicates that the posts had to be filled up by following the prescribed procedure.
Despite all these communications neither the initial appointments nor the confirmations were done
by following the prescribed procedure. On the contrary all efforts were made to bypass the
recruitment procedure known to law which resulted in clear violation of Articles 14 and 16(1) of the
Constitution of India both at the initial stage as well as at the stage of confirmation of these illegal
entrants. The so-called regularisations and confirmations could not be relied on as shields to cover
up initial illegal and void actions or to perpetuate the corrupt methods by which these 6000 initial
entrants were drafted in the Scheme by Dr. Mallick. For all these reasons, therefore, it is not
possible to agree with the contention of learned counsel for the appellants that in any case the
confirmations given to these employees gave them sufficient cloak of protection against future
termination from services. On the contrary all the cobwebs created by Dr. Mallick by bringing in this
army of 6000 employees under the Scheme had got to be cleared lock, stock and barrel so that
public confidence in government administration would not get shattered and arbitrary actions
would not get sanctified.
We may also at this stage to additional written submissions filed on behalf of the appellants in C.A.
Nos. 10831-10985 of 1995. In these written submissions reliance is placed on the judgment of one of
us, A.M. Ahmade, J. (as His Lordship then was), in the case of Jacob M. Puthuparambil & Ors. etc.
etc. v. Kerala Water Authority & Ors. etc. etc. (1991) 1 SCC 28. In the said decision it was held that
when ad hoc employees who were continued for two years or more (in some cases one year or more)
were entitled to be regularised subject to availability of vacancies. The aforesaid decision cannot be
of any avail to the appellants for the simple reason that once we find that there were no vacancies atAshwani Kumar & Ors vs State Of Bihar & Ors on 16 December, 1996

all on which the appellants could be regularised there was no occasion to undertake such an exercise
especially when the initial entries of these appellants in the service were found to be illegal and
vitiated.
Before we leave discussion on point no. 2 it is necessary to mention two additional aspects placed for
our consideration by Dr. Dhavan in support of the appellants. In Civil Appeal Nos. 10811-28 of 1995
Dr. Dhavan submitted that there were two phases in connection with recruitment for Tuberculosis
Eradication Programme. One phase was as per Government Order of 25th March 1983 wherein the
committee of recruitment headed by Dr. Mallick was entrusted with the task of recruitment. But the
second phase started on 31.1.1987 when Joint Secretary to Government of Bihar, Health Department
addressed a communication to the Deputy Director, Tuberculosis, Dr. Mallick. The said
communication is found as Annexure V to the Paper Book in civil Appeal no. 10811-28 of 1995. it
mentions that the signatory to the communication was directed to say that keeping in view the
necessity of one T.B. Assistant and T.B. Attendant for each of the 627 Primary Health centers, a
training programme should be launched for training the candidates in proportion to the number of
primary Health centres, which will have to compulsorily participate in the final examination
conducted by the Director, State T.B. Demonstration and Training Centre and shall have to pass
such examination so that they may be posted in the Primary Health centres in order of merit from
the list of trained candidates after approval of sanction of a posts by the Government in phases. Dr.
Dhavan contended that pursuant to the said direction Dr. Mallick appointed number of candidates
under the Training Programme and these candidates were trained for being ultimately absorbed in
primary health centres under the Scheme. We fail to appreciate how this communication which is
styled as beginning of the second phase by Dr. Dhavan, can change the situation. Even though some
training was given under the direction of the Government to certain candidates the recruitment
made by Dr. Mallick in excess of the available vacancies would still remain unauthorised and illegal
and cannot improve the situation for the said trainees in any manner. Even after training when
recruitment is to be made it must be made on available vacancies or sanctioned posts under the
Scheme and that too after following due procedure of recruitment. That was never done by Dr.
Mallick. Therefore, the so-called second phase cannot improve the position for the appellants in any
manner. Dr. Dhavan then submitted that at least so far as 8 appellants in Civil Appeal arising out of
S.L.P (C) No. 14275 of 1994 ar concerned, they were not appointed by Dr. Mallick but were
appointed by Dr. Mithilesh Kumar. In para 3 of S.L.P. (C) No. 14275 of 1994 it has been stated that
one letter was issued by the then Deputy Director (T.B.), Dr. Mallick on 23rd November 1989 by
which the Civil Surgeon-cum-chief Medical Officer, Madhubani was directed to absorb petitioner
no. 2 according to his qualification against a Class III post and accordingly he was appointed. At
page 83 is found the recital as regards petitioner nos. 7 and 8, to the effect that with respect to them
Dr. Mallick, the then Deputy Director (T.B.) Health Services issued one letter dated 12th January
1990 recommending for their absorption against class III posts according to their qualification and
that is how they were appointed by Dr. Mithilesh Kumar. It was next submitted with reference to
paragraph 13 of the same special Leave Petition that with respect to the appointments which were
made by then Civil Surgeon-cum-Chief Medical Officer, Madhubani, like the petitioners a separate
letter was issued on 6th March 1993 wherein the incharge Medical Officers of Primary health
Centres were directed to issue show cause notices to such persons, who were appointed/absorbed by
the order of the then civil Surgeon- cum-Chief Medical Officer, but such show cause notices wereAshwani Kumar & Ors vs State Of Bihar & Ors on 16 December, 1996

never issued. In our view these averments cannot improve the case of the appellants. Even though
these concerned petitioners might have been actually appointed by Dr. Mithilesh Kumar their
appointments were recommended by Dr. Mallick who, therefore, remained the prime mover in their
cases also as in cases all other appellants. It is the hand of Dr. Mallick that brought them under the
Tuberculosis Eradication Scheme and but for him they would not have got their entry. Therefore,
actual appointments might have been made by Dr. Mithilesh Kumar but the real appointing agency
remained that of Dr. Mallick. Consequently the effort made by Dr. Dhavan to separate their cases
from the cases of other appellants who are tracing their direct linkage with Dr. Mallick remained an
abortive one. Similarly whether show cause notices were issued to them or not also would be besides
the point as we will see while deciding point no.3 that public notices were given to appointees to
have their say before the competent authority in connection with their appointments and basic
principles of natural justice were followed in these cases also. The second point, therefore, is
answered in the negative. This takes to the consideration of Point No.3 for determination.
Point No.3 So far as the principles of natural justice are concerned it has to be stated at the outset
that principles of natural justice cannot be subjected to any straight jacket formula. They will very
from case to case, from circumstance to circumstance and from situation to situation. Here is a case
in which 6000 employees were found squatting in the Tuberculosis Scheme controlled and
monitored by Dr. Mallick for the entire State of Bihar and there was no budgetary sanction for
defraying their expenditure. At least our of the 6000 employees as seen earlier 3750 were totally
unauthorised and were squatting against non-existing vacancies. A grave situation had arisen which
required immediate action for clearing the stables and for eradicating the evil effects of these
vitiated recruitments so that the Tuberculosis Eradication Scheme could be put on a sound footing.
When such a grave situation had arisen and when matters had gone up to the High Court wherein
the State was directed to appoint a Committee to thoroughly investigate the entire matter, the State
of Bihar had to appoint a committee to scrutinies these appointments and to filter them as directed
by the High court of Patna. For undertaking the said exercise public notices were issued by the
Director-in-Chief, Health Services, Bihar, Patna by Communication dated 4th July 1992. The said
communication which s found at page 147 of the Paper Book recites that Dr. Mallick, the then
Deputy Director (T.B.) presently retired, issued orders of appointment/posting/transfer/absorption
on a large scale against the Class III and Class IV posts in the T.B. Eradication Programme under the
Directorate of Health Services without following the procedure for appointments/without
publication of advertisement and by openly violating reservation policy in contravention of Article
16. While distributing such appointment letters, Dr. Mallick in many cases did not even care to see
whether even the posts were sanctioned or not. Reference was made to the order passed by High
Court of Patna which had directed the Government to require in all such matters and after
considering the representations, pass a final order within 6 weeks. It was in the light of the Patna
High Court's direction that the Government called upon all the concerned persons to submit their
representations, show cause replies before the signatory to the communication positively by 25th
July 1992 so that appropriate decision might be taken after examining the legality of their
appointments. Six types of informations were sought for from the concerned persons. The
employees appointed from 1980 to 1987 were called upon to appear before the Director in Chief,
Health Services, Bihar. Patna in his office situated at Vikas Bhawan, Secretariat at 11.00 a.m.
positively with a copy of show-cause reply on different dates ranging from 17th august 1992 to 19thAshwani Kumar & Ors vs State Of Bihar & Ors on 16 December, 1996

September 1992 and the employees appointed from May 1988 to December 1988 and from January
1989 to December 1989-1990 were to appear in person on 29th September 1992. It is not in dispute
that pursuant to the aforesaid communication duly published, out of 6000 employees who were the
creatures of Dr. Mallick, 987 did appear. The appellants in C.A. Nos. 10758-59 of 1995 and others
did submit details of their service bio-data to the concerned authority as per the said
communication. A sample copy of the show cause reply sent to the Director-in-Chief, Health
Services, in response to the said communication is at page 151 of the Paper Book. Query wise replies
are found in the said return. It was thereafter that a written order was passed by Director-in-chief on
12th November 1992 appointing a committee of officers for scrutinising these replies and for coming
to the correct conclusion in the light of the data supplied by the concerned employees who remained
present for personal hearing before the authority in response to the earlier communication. The said
order dated 12th November 1992 is at page 402 of the Paper Book. it clearly recites that after due
consideration of all the facts, the Government had decided that the validity of all the appointments
made by Dr. Mallick after 1.1.1980 should be examined. Accordingly all the concerned officials were
given opportunity to submit show cause replies before the director-in-chief, Health Services Bihar,
Patna by 25.7.92, after getting the notice to show cause advertised on 4.7.92 and also were given
opportunity for personal hearing after fixing separate dates for officials appointed year wise from
1980 till August- September 1992. A committee of the officers mentioned in paragraph 4 was
appointed to review the show cause replies mentioned in paragraph 3 and information received in
course of personal hearings. The committee had to review the merits/demerits of the appointments
under question in the light of policy and procedures prescribed by Government from time to time
for appointment in Public Service and submit its recommendation to the Government. the learned
counsel for the appellants submitted that appointment of this review committees was after the
personal hearing before the Director-in-Chief, Health Services, Bihar, Patna and, therefore, this
violated the basic principles of natural justice. It is difficult to agree. all the concerned appointees
whose appointments by Dr. Mallick were to be filtered were given personal hearing by the
Director-in- Chief. The data which they had to submit was duly received and it was thereafter that
the Review committee was entrusted with the task of going through the data submitted by these
employees along with their replies and their say during the personal hearing. Therefore, the said
review Committed was only to scrutinies the data collected during the personal hearing by the
Director-in-Chief, Health Services and on that bases the Committee decided the question of legality
and validity of their appointments. Thus the basic principles of natural justice cannot be said to have
been violated by the Committee which ultimately took decision on the basis of the personal hearing
given to the concerned employees and after considering what they had to say regarding their
appointments. Whatever was submitted by the concerned employees was taken into consideration
and than the committee came to a firm decision to the effect that all these appointments made by
Dr. Mallick were vitiated from the inception and were required to be set aside and that is how the
impugned termination orders were passed against the appellants. On the facts of these cases,
therefore, it cannot be said that principles of natural justice were violated or full opportunity was
not given to the concerned employees to have their say in the matter before their appointments were
recalled and terminated. Point no.3 is, therefore, is answered in the negative.
Point No.4 Now is the tie for us to take stock of the situation in the light of our answers to the
aforesaid three points. As a logical corollary to these answers the appeals are liable to be dismissedAshwani Kumar & Ors vs State Of Bihar & Ors on 16 December, 1996

as the decision of the High Court is found to be well sustained. The submission made by learned
counsel for the appellants to sustain services of these appellants on humanitarian grounds cannot be
countenanced. When 6000 appointees are found to have been illegally loaded on the State
exchequer by Dr. Mallick and when there were only 2250 sanctioned posts, in the absence of clear
data as to who were the senior most and which were the sanctioned posts available at the relevant
time against which they could be fitted it would be impossible to undertake even a jettisoning
operation to off load the removable load of excess employees amounting to 3750 by resorting to any
judicial surgery. Once the source of their recruitment is found to be tainted all of them have to go by
the board. Nor can we say tat benefit can be made available only to 1363 appellants before us as the
other employees similarly circumscribed and who might not have approached the High Court or this
Court earlier and who may be waiting in the wings would also be entitled to claim similar relief
against the State which has to give equal treatment to all of them otherwise it would be held guilty of
discriminatory treatment which could not be countenanced under Articles 14 and 16(1) of the
Constitution of India. Everything, therefore, must start on a clean slate. Reliance placed by learned
counsel for the appellants on the doctrine of tempering justice with mercy also cannot be pressed in
service on the peculiar facts of these cases as mercy also has to be based on justice. The decision of
this Court in the case of H.C. Puttaswamy (supra) also can be of no assistance to the appellants on
the facts of the present cases as in that case the Chief Justice of the High Court had full financial
powers to create any number of vacancies on the establishment of the High Court as required and to
fill them up. There was no ceiling on his such powers. Therefore, the initial entry of the appointees
could not be said to be unauthorised or vitiated or tainted. The fault that was found was the manner
in which after recruitment they were passed on to the establishments of subordinate courts. That
exercise remained vitiated. But as the original entries in High Court service were not unauthorised
these candidates/employees were permitted to be regularised. Such is not the present case. The
initial entry of the employees is itself unauthorised being not against sanctioned vacancies nor was
Dr. Mallick entrusted with the power of creating vacancies or posts for the schemes under the
Tuberculosis Eradication Programme. Consequently the termination of the services of all these
appellants cannot be found fault with. Nor any relief as claimed by them of reinstatement with
continued service can be made available to them.
However there is one human aspect which calls for our attention on the facts of the present cases.
These 6000 employees got employed by Dr. Mallick over at least a decade. Many of them served for
number of years and got confirmed. They would naturally have their families to support. For no
fault of theirs they found themselves stranded in life midstream. Many might have got over aged. As
Dr. Dhavan pointed out, many of them also got trained under the second phase of the Programme,
as he would like to style it, pursuant to the Government Order dated 31.1.1987 referred to by us
earlier. Under these circumstances justice would require that some effort to salvage their situation if
possible may be made when the State undertakes a fresh exercise to fill up the sanctioned posts
under the Tuberculosis Eradication Programme which has come to stay. We are informed that
tuberculosis is still not eradicated in the State of Bihar and the Programme is to last for couple of
more years and may be it may assume a semi-permanent status. It was also not disputed that there
are 2250 sanctioned posts or it may be that some more sanctioned posts may see the light of the day
in near future. Shri Singh learned counsel for the respondent-State informed us that the State
proposes to start on a clean slate and after following due procedure of recruitment would certainlyAshwani Kumar & Ors vs State Of Bihar & Ors on 16 December, 1996

recruit Class III and Class IV employees on the sanctioned vacancies and posts which will have to be
filled up for making the Tuberculosis Eradication Scheme effective and fully operative. When that is
the need of the day, it would be appropriate to direct the State to undertake that exercise at the
earliest and while doing so after following the due procedure of recruitment and the rules governing
the same, given an opportunity to these 6000 unfortunate creatures of Dr. Mallick to compete for
the said posts in the future recruitment that may be undertaken by the State and in the process
because of the experience which they have gathered in their past service under the Tuberculosis
Programme and the training which they might have received pursuant to the Government Order
dated 31.1.1987, due weight age also be given to them while considering their eligibility for being
recruited in service as and when such future exercise is undertaken. Consequently we deem it fit to
issue the following directions to the respondent State of Bihar in this connection :
1. Respondent-State of Bihar may start at the earliest a fresh exercise for recruiting
Class III and Class IV employees in the Tuberculosis Eradication Programme
undertaken by the State as a part of 20-Point Programme on the available 2250
vacancies or even more vacancies, as the case may be, preferably within three months
from the receipt of a copy of this order.
2. Towards the said exercise the State will publish a notice in all the newspapers
having circulation in the State inviting applications for direct recruitment to Class III
and Class IV posts for filling up these vacancies in the said Programme.
3. Similarly names may also be called for from the concerned Employment Exchange
for such recruitment.
4. If no statutory body composed of high-ranked officials for recruitment to Class III
and Class IV employees is in vogue, the State is directed to constitute a committee
consisting of three members, viz., (a) a member of the Public Service Commission;
(b) a senior IAS officer, i.e., the Additional or Joint Secretary of the Health
Department; and (c) a senior officer, i.e., the Director or Additional Director of
Health Services, to select the candidates. The Additional or Joint Secretary of Health
Department shall be the Chairman of the Committee.
5. The respondent-State will constitute such a committee preferably within three
months of the receipt of this order.
6. It would be open to all the appellants or those appointed by Dr. Mallick who might
not have challenged their termination orders before any competent court up till now,
to apply for selection to the concerned Class III and Class IV posts. The committee
would in their cases as first step, verify and satisfy itself of the credentials of such
candidates whether they were appointed by Dr. Mallick and had worked a least for
three years continuously. The committee would also satisfy itself that such candidate
or candidates honestly and meritoriously discharged their duties as Class III and
Class IV appointees, at least for the said period.Ashwani Kumar & Ors vs State Of Bihar & Ors on 16 December, 1996

7. The committee may fix total number of marks to be obtained by the candidates for
being treated to have passed the selection test. Any relaxation in the minimum
eligibility marks to be obtained by the Scheduled Casts, Scheduled Tribes and Other
Backward Classes candidates as found necessary may also be decided by the
committee. The committee if satisfied about the credentials and other particulars of
the appellants or those appointed by Dr. Mallick as mentioned in paragraph (6)
above, may allot additional marks to them for each of the three years and more for
which they might have worked, at the rate of 2 marks for each completed year of
continuous working, upto the maximum of 6 marks, for each candidate. Candidates
appointed by Dr. Mallick who are found to have undertaken training pursuant to the
Government direction dated 31.1.1987 may be awarded 2 additional marks for the
training so received. Those 2 marks will be in addition to the 6 marks which are to be
awarded on completion of meritorious and honest service by the concerned
employees as mentioned above.
8. If the concerned candidates who were earlier appointed by Dr. Mallick are found
by the committee to be otherwise eligible for being appointed to Class III and Class
IV posts as per the relevant rules and regulations and if on the basis of the marks
allotted to them as aforesaid they become eligible to be appointed besides other
competing candidates, then if they are found to have become age barred the
condition of age for recruitment of such candidates should be relaxed appropriately
so as to entitle such candidates to be considered for selection.
9. The State Government shall arrange sittings of the Selection Committee preferably
within two months from the last date prescribed for submitting the applications and
for completion of the preliminary scrutiny of such applications. The committee shall
select all candidates on merits following the prescribed procedure in the appropriate
circulars and rules and shall also follow the rules of reservation as in vogue and
prepare the merit list and should submit it to the Government. While doing so the
eligible candidates who were earlier appointed by Dr. Mallick and who received the
marks for their past meritorious service and training as aforesaid will be considered
for selection qua the other candidates in the light of the weight age of the marks as
aforesaid and in that light the committee will select all the candidates on merits and
will prepare the select list of candidates found fit to be appointed to the concerned
posts.
10. The committee will complete the process of selection preferably within three
months from the date of its sittings for selection.
11. An appropriate authority or the government, as the case may be, will appoint
preferably within three months from the date of the receipt of the merit list from the
committee, the selected candidates as per roster and the merit list, on available
vacancies, after due identification of the credentials of the candidates concerned as
per its legally permissible procedure.Ashwani Kumar & Ors vs State Of Bihar & Ors on 16 December, 1996

12. In the event of selection and appointment of erstwhile daily-rated employee or
employees, who were inducted by Dr. Mallick, the entire proved period during which
they had worked as daily wager and/or confirmed employees will be computed for
the purpose of pensionary and other retrial benefits but they will not be entitled to
claim any inter se higher seniority in the selection made by the committee or for any
promotion on the basis of their previous service.
The appeals are disposed of in the above terms. In the facts and circumstances of the case there will
be no order as to costs.Ashwani Kumar & Ors vs State Of Bihar & Ors on 16 December, 1996

