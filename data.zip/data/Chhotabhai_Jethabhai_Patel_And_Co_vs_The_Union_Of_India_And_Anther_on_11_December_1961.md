Chhotabhai Jethabhai Patel And Co vs The Union Of India And
Anther on 11 December, 1961
Equivalent citations: 1962 AIR 1006, 1962 SCR SUPL. (2) 1, AIR 1962
SUPREME COURT 1006
Author: N. Rajagopala Ayyangar
Bench: N. Rajagopala Ayyangar, Syed Jaffer Imam, J.L. Kapur, K.C. Das
Gupta, Raghubar Dayal
           PETITIONER:
CHHOTABHAI JETHABHAI PATEL AND CO.
        Vs.
RESPONDENT:
THE UNION OF INDIA AND ANTHER,
DATE OF JUDGMENT:
11/12/1961
BENCH:
AYYANGAR, N. RAJAGOPALA
BENCH:
AYYANGAR, N. RAJAGOPALA
IMAM, SYED JAFFER
KAPUR, J.L.
GUPTA, K.C. DAS
DAYAL, RAGHUBAR
CITATION:
 1962 AIR 1006            1962 SCR  Supl. (2)   1
 CITATOR INFO :
 R          1963 SC 104  (9)
 C          1963 SC1667  (15)
 R          1967 SC1512  (40,67)
 RF         1971 SC2039  (17)
 RF         1972 SC1061  (48)
 RF         1972 SC2563  (24)
 R          1973 SC1034  (13)
 RF         1984 SC 420  (41)
 R          1984 SC1194  (31)
 RF         1985 SC 537  (15)
 E          1989 SC1829  (14)
ACT:
     Excise duties-Retrospective  Levy-Validity ofChhotabhai Jethabhai Patel And Co vs The Union Of India And Anther on 11 December, 1961

enactment-Legislative  competence  of  Parliament-
Constitutional validity-Finance  Act 1951  (23  of
1951),  s.   7(2)-Constitution  of   India   Arts.
19(1)(f), 31, 265, Seventh Schedule, List I, Entry
84, List II, Entry 60.
HEADNOTE:
     The appellants  who were carrying on business
in  tobacco   had  in   their  licenced  warehouse
considerable quantity  of tobacco  on February 28,
1951. On the same day a Bill was introduced in the
House  of  the  People  containing  the  financial
proposals of  the  Government  of  India  for  the
fiscal year  beginning April  1, 1951. Clause 7 of
the Bill  made provision  for the amendment of the
Central Excises  and Salt  Act, 1944,  by  way  of
alteration   of    duties,    inter    alia,    on
unmanufactured tobacco  by imposing an excise duty
of 8  annas per  1b. Under  the provisions  of the
Provisional Collection  of Taxes  Act,  1931,  the
duty could become leviable as from the date of the
introduction of  the Bill  and it  was so made. In
accordance therewith  the appellants  paid  excise
duty on  tobacco in  their possession at the rates
mentioned  in  the  Bill  and  obtained  clearance
certificates. On  April 28,  1951,  the  Bill  was
passed and became Finance Act, 1951, but as passed
changes were effected as regards the duty proposed
in the Bill. Under s. 7(1) of the Finance Act, the
duty on unmanufactured tobacco was increased to 14
annas per  lb. Section 7 (2) thereof provided that
"the amendments  made in  the Central  Excises and
Salt Act,  1944, shall be deemed to have effect on
and after  March 1,  1951 and  accordingly........
recoveries shall  be made of all duties which have
not been  collected  but  which  would  have  been
collected  if  the  amendment  had  so  come  into
force." In  pursuance of s. 7(2) a demand was made
upon the  appellants on June 22, 1951, for payment
of the excess of the
2
excise duty  payable on tobacco cleared out of the
warehouse from  March 1,  1951, to April 28, 1951.
The appellants  challenged  the  legality  of  the
demand on the grounds, inter alia, that (1) excise
duty was  a tax  on goods  which must exist at the
time when the tax was levied and it must have been
intended and  expected by  the legislature that it
would be  passed on  to the  consumer, and  as the
retrospective operation of the duties deprived the
tax of  these qualities  they did  not fall withinChhotabhai Jethabhai Patel And Co vs The Union Of India And Anther on 11 December, 1961

the term "duties of excise" in Entry 84, List I of
the Seventh Schedule to the Constitution of India,
and, therefore,  s. 7(2) of the Finance Act, 1951,
in  so   far  as   it  imposed   an  excise   duty
retrospective before the date of its enactment was
beyond the  legislative competence  of  Parliament
and  (2)   the  impugned   levy  contravened  Art.
19(1)(f),  because  a  retrospective  levy  of  an
excise duty deprived the tax payer of the right of
passing it  on and  recovering it  from his buyer,
and that this constituted a restraint on the right
to hold property, which was not saved by cl.(5) of
Art. 19.
^
     HELD: (1)  Parliament acting  within its  own
legislative field  had the  powers of  a sovereign
legislature and  could make a law prospectively as
well retrospectively and the duties leviable under
the  Central   Excises  and  Salt  Act,  1944 ,  as
provided by  s. 7(2)  of the  Finance  Act,  1951,
notwithstanding     their      imposition     with
retrospective effect  and even  if it be that they
were incapable  of being passed on to a buyer from
the taxpayer,  were "duties  of excise" within the
meaning  of  Entry  84,  List  I  of  the  Seventh
Schedule to the Constitution of India.
     (2) The levy of the tax retrospectively under
s. 7(2)  of the  Finance Act,  1951, was valid and
did  not   contravene   Art.   19(1)(f)   of   the
Constitution.
     Per Kapur,  J.-(1) Entry  84 in  List I deals
with taxes  on  goods  manufactured  or  produced,
while Entry  60 in List II deals with the carrying
on of  trade i.e.,  an activity  in the  nature of
buying and  selling, and  the Central  Excises and
Salt Act,  1944, in its pith and substance relates
to duty  on goods manufactured or produced and has
no relationship with Entry 60.
     (2)  Reasonableness   of  tax   laws  is  not
justiciable and  therefore they cannot fall within
cl.(5) of  Art. 19. Art. 19(1)(f)  and the cl.(5)
are part of one scheme and the former is incapable
of operating  where the  latter is inoperative. If
considerations of Art. 19(5) are foreign to taxing
laws Art.  19(1)(f) can  have  no  application  to
them.
     Case law reviewed.
3
JUDGMENT:Chhotabhai Jethabhai Patel And Co vs The Union Of India And Anther on 11 December, 1961

CIVIL APPELLATE JURISDICTION: Civil Appeals Nos. 140 to 142 of 1952.
Appeals from the judgment and order dated March 24, 1953, of the former Nagpur High Court in
Misc. Petitions Nos. 1795-1796 of 1951 and 1 of 1952.
WITH Petitions Nos. 24, 25 and 93 of 1952. Petition under Art. 32 of the Constitution of India for
enforcement of Fundamental Rights.
G.S. Pathak, S.N. Andley, J.B. Dadachanji and Rameshwar Nath, for the Appellants/petitioners.
H.N. Sanyal, Additional Solicitor General of India, N.S. Bindra, R.H. Dhebar and T.M. Sen, for the
respondents.
C.R. Pattabhi Raman and R. Ganapathy Iyer, for the interveners (in C.A. No. 141 of 1954).
1961, December 11. The judgment of S.J. Imam, K.C. Das Gupta, Raghubar Dayal and N. Rajagopala
Ayyangar, JJ., was delivered by Rajagopala Ayyangar, J., J.L. Kapur, J., delivered a separate
judgment.
AYYANGAR, J.-The appellants in Civil Appeal 140 of 1954 are tobacco merchants and
manufacturers of biris. They own private warehouses licensed under r. 140 of the Excise Rules, 1944
at Gondia and other places in Madhya Pradesh.
On the 28th of February, 1951 a Bill was introduced in the House of the People, being Bill 13 of 1951
containing the financial proposals of the Government of India for the fiscal year beginning the 1st of
April, 1951. Clause 7 of the Bill made provision for the amendment of the Central Excise Act (Act 1 of
1944) by way of alteration of duties on "tobacco manufactured and unmanufactured." In particular,
it provided that "unmanufactured tobacco other than flue-cured and ordinarily used otherwise than
for the manufacture of cigarettes" (which included tobacco intended for manufacture into biris)
should be charged to an excise duty of 8 annas per lb. and it also imposed a new duty of excise on
biris varying from 6 to 9 annas per lb. depending upon the weight of tobacco contained in the biris.
Section 3 of the Provisional Collection of Taxes Act, 1931 (Act XVI of 1931) enacted "Where a bill
introduced into the Indian Parliament provided for the imposition or increase of a duty of excise the
Central Government might cause to be inserted in the bill a declaration that it was expedient in the
public interest that any provision of the bill relating to such imposition or increase shall have
immediate effect under this Act". A declaration under this section was made in respect of the
provision for imposing the duties on tobacco under cl. 7 of the bill already adverted to. The effect of
such a declaration was stated in s. 4 of Act XVI of 1931 in the following terms:-
"4. (1) A declared provision shall have the force of law immediately on the expiry of
the day on which the Bill containing it is introduced.Chhotabhai Jethabhai Patel And Co vs The Union Of India And Anther on 11 December, 1961

(2) A declared provision shall cease to have the force of law under the provisions of
this Act-
(a) When it comes into operation as an enactment with or without amendment, or
(b) when the Central Government in pursuance of a motion passed by parlia-
ment, directs, by notification in the Official Gazette, that it shall cease to have the force of law, or
(c) if it has not already ceased to have the force of law under clause (a) or clause (b), then on the
expiry of the sixtieth day after the day on which the Bill containing it was introduced." In
compliance with this law the appellants paid the excise duty at the rates imposed under cl. 7 of the
bill and obtained clearance certificates in regard to the tobacco moved out from their warehouses
from and after March 1, 1951. Bill 13 of 1951 was passed into law as the Indian Finance Act 1951 (Act
XXIII of 1951 on April 28, 1951 but as passed, changes were effected in the duty proposed in the bill,
as a result of certain alterations suggested by the Select Committee. Under s. 7 (1) of the Finance Act
1951 while the excise duty on biris was abandoned, the duty on unmanufactured tobacco (other than
flue-cured and used in the manufacture of cigarettes) was increased to 14 annas per lb. from the rate
of 8 annas per lb. in the bill. Consequential provisions were enacted in s. 7 (2) of the Finance Act
which read:
"The amendments made in the Central Excise and Salt Act 1944, sub-cl. 1 shall be
deemed to have effect on and from the 1st March, 1951 and accordingly:-
(a) refund shall be made of all duties collected which would not have been collected,
if the amendment had come into force on that day, and
(b) recoveries shall be made of all duties which have not been collected but which
would have been collected if the amendment had so come into force."
In pursuance of s. 7 (2) a demand was made upon the appellants on June 22, 1951 for the payment
of the duty payable by them, after giving credit for the refund of the duty paid on biris which had
been deleted by the Act. The appellants contested the legality of this demand by a petition under Art.
226 which they filed in the High Court at Nagpur urging that the retrospective operation given to s.
7(1) by sub-s.(2) thereof was illegal, ultra vires and unconstitutional, and besides that the provision
in r. 10 of the Excise Rules which contained the machinery for enforcing the demand was not
adequate to meet the situation arising out of the change in the law from the provisions of the bill to
those of the Act. The learned Judges of the High Court repelled all the contentions disputing the
legislative competence and the constitutionality of the legislation contained in s. 7(2) of the Finance
Act of 1951, but they upheld the objection to the adequacy of the procedure for recovery based on the
limited scope of r. 10 of the Excise Rules. Thereafter the Central Government, by a notification dated
December 8 1951, amended the Central Excise Rules, 1944 by the addition of a new r. 104 providing
machinery specially designed f r the enforcement of a demand like the one arising in the
circumstances of the present case. On December 12, 1951 a further and a fresh demand was made forChhotabhai Jethabhai Patel And Co vs The Union Of India And Anther on 11 December, 1961

the payment of the duty in terms of s. 7(2)(b) of the Finance Act quoted earlier, and the appellants
thereupon once again moved the High Court of Nagpur under Art. 226 challenging the validity of the
demand on the very same grounds as before. This petition was heard by a Full Bench of the Court
and every contention raised by the appellants including that based on the adequacy of the new r.
10A to cover the present case was rejected. The learned Judges granted a certificate under Art. 132
of the Constitution which was enabled the appellants to file this appeal. Before proceeding further it
is only necessary to state that there is no material difference between the facts of the cases covered
by Civil Appeals 141, 142 as well as the points raised in the Writ Petitions and that this judgment will
cover and dispose of the other appeals and the petitions. We might also, at this stage mention that
other parties who were similarly situated as the appellants in Civil Appeals 140 to 142 of 1954 and
who had filed petitions under Art. 226 of the Constitution in the High Court of Madras which arc
pending there, raising the same points as the appellant's before us, have intervened in these appeals
and they have also been heard. Learned Counsel appearing for the interveners adopted the
arguments urged in support of the appeal.
Mr. Pathak, learned Counsel who appeared for the appellants urged three point in support of the
appeals(1) Section 7 (2) of the Finance Act, 1951 in so far as it imposed an excise duty retrospectively
before the date of its enactment (April 28, 1951) was beyond the legislative competence of
Parliament. The contention on this head was briefly this: The impugned tax was imposed by
Parliament in purported exercise of the power to levy "a duty of excise on tobacco" within Legislative
Entry 84 of Union list which reads:
"Duties of excise on tobacco and other goods manufactured or produced in India
except An "excise" was basically an indirect tax, i.e., a tax or duty not intended by the
taxing authority to be borne by the person on whom it is imposed and from whom it
is collected but is intended to be passed on to those who purchased the goods on
which the duty was collected; but when such a tax was imposed with retrospective
effect it could not be passed on, so such a levy deprived the tax of its essential
characteristic of being indirect. It therefore ceased to be a "duty of excise" and
became a personal tax of a category quite distinct from "excise" and so was beyond
the legislative power of Parliament under that Entry. (2) That the impugned levy was
unconstitutional in that it contravened the fundamental right guaranteed to the
citizens of India to hold property under Art. 19(1)(f), the point urged being that a
retrospective levy of an "excise duty" deprived the tax-payer of the right of passing it
on and recovering it from his buyer, that this constituted a restraint on "the right to
hold property" (the amount of the tax-levy) conferred by Art. 19(1)(f) and was not
saved by cl. 5 of that Article as being a reasonable restraint and should, therefore, be
struck down under Art. 13(2). (3) That the terms of r. 10A of the Excise Rules 1944
were insufficient to cover the cases of the appellants and that in consequence the
demand made on them and the attempt to recover the sums by resort to the coercive
process provided for by s. 11 of the central Excise Act was illegal and without
statutory authority.Chhotabhai Jethabhai Patel And Co vs The Union Of India And Anther on 11 December, 1961

We shall now proceed to consider these points in that order. (1) Want of legislative
competence:
To appreciate the submission of learned Counsel it is necessary to set out the steps in
the reasoning by which he sought, to establish that a "duty of excise" when imposed
with retrospective effect ceased to be a "duty of excise" as used in Entry 84 of the
Union List. The submission of learned Counsel was this: The term "duty of excise" on
goods was universally recognized as a tax on home produced goods and as a typical
instance of an indirect tax. It was a tax on the activity of production or manufacture
of goods within the country and that it was levied on or collected from tho producer
or manufacturer or from those who held such goods. It was, further, not a personal
tax but its essential and characteristic nature, which distinguished it from other types
of taxes was that it was levied on goods. It had, therefore, in order that it might truly
be "duty of excise", to satisfy two tests:
(a) It had to be an indirect tax, i.e. levied in such a manner that the person from
whom the tax was collected was in a, position to pass it on to those who acquired the
goods from him or at least the taxing authority expected him to pass it on, and laid no
impediment on his ability to do it.
(b) Being a tax on goods, it was levied on the producer or manufacturer or person in
possession of the goods at the time when the person taxed was the owner or had
possession and control over the goods. Where neither of these essential elements or
attributes was present, and in the present, case, according to learned Counsel neither
condition was satisfied, the tax-levy would not fall under the category of "duty of
excise."
The same argument was Presented in a slightly different from by saying that though Parliament,
generally speaking, had the power to legislate in respect of everyone of the subjects included in the
relevant legislative entries whether prospectively, or retrospectively including legislation with regard
to taxation, still if the retrospective levy of a taxes, altered its essential nature and identity, then the
power to legislate retrospectively would be open to Parliament only if the tax in its altered from- i.e.,
a tax direct and personal-would be open to Parliament to impose. In the case of a "duty of excise" as
the tax in the present case was, if imposed retrospectively, deprived it of its essential characteristic
of being in indirect tax and a tax on goods, and so the power of Parliament to enact such
retrospective legislation would depend upon whether Parliament could impose a tax on a person
merely because he happened to produce goods at an antecedent date, or, happened to have had in
his control goods of indigenous production at a prior date and if this could not be done, it would
follow that Parliament could not impose a "duty of excise" with retrospective effect.
In support of his submission regarding the nature of an excise duty and that meaning that ought to
be attributed to the expression as it occurs in Entry 84 of the union List, Mr. Pathak placed before us
judgments of the Privy Council in appeals from Canada and some decisions of the American
Supreme Court and of the Australian High Court.Chhotabhai Jethabhai Patel And Co vs The Union Of India And Anther on 11 December, 1961

First as to the decisions relating to the Canadian constitution though learned Counsel referred us to
several decisions on the interpretation of the word "excise" in connection with the distinction
between direct and indirect taxes in most of the British North America Act, 1867, we do not think it
necessary to refer to all of them.
The general line of approach of the Privy Council decisions referred by learned Counsel could be
gathered from the observations of Lord Cave in City of Halifax v. Fairbanks' Estate. The impugned
tax legislation was a business tax imposed by the Province of Nova Scotia to be paid by every
occupier of real property for the purposes of any trade, profession, or other calling carried on for the
purpose of gain, the assessment being according to the capital value of the premises. This was
challenged inter alia on the ground that it was an indirect tax and therefore not within the legislative
competence of the Provincial Legislature. Lord Cave said:
"Thus, taxes on property or income were everywhere treated as direct taxes; and John
Stuart Mill himself, following Adam Smith, Ricardo and James Mill, said that a tax on
rents falls wholly on the landlord and cannot be transferred to any one else............
On the other hand, duties of customs and excise were regarded by every one as
typical instances of indirect taxation. When therefore the Act of Union allocated the
power of direct taxation for Provincial purposes to the Province, it must surely have
intended that the taxation, for those purposes, of property and income should belong
exclusively to the Provincial legislatures, and that without regard to any theory as to
the ultimate incidence of such taxation. To hold otherwise would be to suppose that
the framers of the Act intended to impose on a Provincial legislature the task of
speculating as to the probable ultimate incidence of each particular tax which it
might desire to impose, at the risk of having such tax held invalid if the conclusion
reached should afterwards be held to be wrong........... The imposition of taxes on
property and income, of death duties and of municipal and local rates is, according to
the common understanding of the term, direct taxation, just as the exaction of a
customs or excise duty on commodities............ would ordinarily be regarded as
indirect taxation; and although new forms of taxation may from time to time be
added to one category or the other in accordance with Mill's formula as a ground for
transferring a tax universally recognised as belonging to one class to a different class
of taxation."
Similar passages in relation to a "duty of excise"
being an indirect tax occur in other judgments of the Judicial Committee to which
learned Counsel drew our attention. Of these, it is sufficient to refer to one
more-Attorney-General for British Columbia v. Kingcome Navigation Company,
Limited which raised the question as to whether a tax which was imposed upon every
consumer of fuel-oil according to the quantity which he had consumed imposed by
the Fuel-Oil Tax Act of 1930 of British Columbia was a direct tax under s. 92, head 2,
of the British North America Act, 1867. After extracting the following passage from
Bank of Toronto v. Lambe:Chhotabhai Jethabhai Patel And Co vs The Union Of India And Anther on 11 December, 1961

"A direct tax is one which is demanded from the very persons who it is intended or
desired should pay it. Indirect taxes are those which are demanded from one person
in the expectation and intention that he shall indemnify himself at the expense of
another; such are the excise or customs.
Lord Moulton who delivered the judgment of the Board referred to the passage from
the judgment of Lord Cave in City of Halifax v. Fairbanks' Estate just now quoted and
went on to add: "The ultimate incidence of the tax in the sense of the political
economist, is to be disregarded, but where the tax is imposed in respect of a
transaction, the taxing authority is indifferent as to which of the parties to the
transaction ultimately bears the burden ........... Similarly, where the tax is imposed in
respect of some dealing with commodities, such as their import or sale, or production
for sale, the tax is not a peculiar contribution upon the one of the parties to the
trading in the particular commodity who is selected as the tax payer. This is brought
out in the second paragraph of Mill's definition, and is true of the typical custom and
excise duties referred to by Lord Cave." The tax was therefore held to be valid.
We consider that not much assistance could be derived from these decisions for the
interpretation of the scope or content of the term "duties of excise" in Entry 84 of the
Union List. The line of division in Canada between those taxes which a Province
could impose and those which it could not was, whether it was direct or indirect. In
Canada, taxing powers are divided between the Dominion and the Provinces on the
basis of the incidence of the tax, the Dominion power extending to "any mode or
system of taxation" (vide s. 91 (3) British North America Act, 1867) while that of the
Provinces is restricted to "direct taxation within the Province in order to the raising
of revenue for provincial purposes" (Section 92(2) ibid).
When therefore the validity of any Provincial tax legislation is challenged in Canada the enquiry is as
regards the normal incidence of the tax whether it is "direct" or "indirect." As these expressions had
a settled meaning in economic theory, the Courts had necessarily to find out whether the particular
tax imposed by the Province fell within the class of "indirect" taxes or not. In such a situation
naturally the classification by economists of taxes as those which are "direct" as distinct from those
which are "indirect" assumed a vital role in deciding whether the tax impugned is or is not within
Provincial power. As pointed out by Gwyer, C.J. in the Province of Madras v. Boddu Paidanna:
"The Canadian cases which were cited do not seem to afford any assistance, since
analogous problems in Canada are always concerned with questions of direct and
indirect taxation; and if a Provincial tax is held to be an indirect tax, it is unnecessary
for the Court to consider whether it may not also be a duty of excise: see, for example
Att.-Gen. for British Columbia v. The Canadian Pacific Railway Co. (1927 A.C. 934),
where a tax on every person purchasing within the Province fuel oil for the first time
after its manufacture in, or importation into, the Province was held to be invalid as
an indirect tax, and the question whether it might not also be bad as an excise duty
was left unanswered. In contrast to the case just cited we may refer to Att. Gen. forChhotabhai Jethabhai Patel And Co vs The Union Of India And Anther on 11 December, 1961

British Columbia v. Kingcome Navigation Co. (1934 A.C. 45) in which a fuel oil tax
imposed by a Province upon every consumer of fuel oil according to the quantity
which he had consumed was held to be valid as a direct tax, because it was demanded
from the very persons who it was intended or desired should pay it."
Similarly, Lord Simonds observed in Governor General in Council v. Province of Madras:
"little assistance is to be derived from the consideration of other federal constitutions
and of their judicial interpretation. Here there is no question of direct and indirect
taxation, nor of the definition of specific and residuary powers."
Under the Indian Constitution the scheme of division of the taxing powers between the Union and
the States is not based on any criterion dependent on the incidence of the tax. Sir Maurice Gwyer in
In re the Central Provinces and Berar Act XIV of 1938 speaking of the word "excise" as occurring in
the legislative lists in the Government of India Act (and for this purpose there is no variation in the
lists in Schedule VII of the Constitution) said:
"Its primary and fundamental meaning in English is that of a tax on articles produced
or manufactured in the taxing country and intended for home consumption. I am
satisfied that this is also its primary and fundamental meaning in India; and no one
has suggested (corresponding to Entry 84 in the Union List).
It was then contended on behalf of the Government of India that an excise duty is a duty which may
be imposed upon home produced goods at any state from production to consumption; and that
therefore the federal legislative power extended to imposing excise duties at any stage. This is to
confuse two things, the nature of excise duties and the extent of the federal legislative power to
impose them ......... There can be no reason in theory why an excise duty should not be imposed even
on the retail sale of an article, if the taxing Act so provides. Subject always to the legislative
competence of the taxing authority, a duty on home- produced goods will obviously be imposed at
the stage which the authority find to be the most convenient and the most lucrative, wherever it may
be; but that is a matter of the machinery of collection, and does not affect the essential nature of the
tax. The ultimate incidence of an excise duty, a typical indirect tax, must always be on the consumer,
who pays as he consumes or expends; and it continues to be an excise duty, that is, a duty on
home-produced or home- manufactured goods, no matter at what stage it is collected."
As Lord Simonds said in the decision, to which reference has already been made after referring to
the decision of the Federal Court in the C.P. Petrol case:-
"Consistently with this decision their Lordships are of opinion that a duty of excise
primarily a duty levied on a manufacturer or producer in respect of the commodity
manufactured or produced. It is a tax on goods not on sales or the proceeds of sale of
goods,"
and then speaking about taxes on sale of goods the learned Lord continued:Chhotabhai Jethabhai Patel And Co vs The Union Of India And Anther on 11 December, 1961

"The two taxes, the one levied on a manufacturer in respect of his goods, the other on
a vender in respect of his sales, may, as is there pointed out, in one sense overlap. But
in law there is no overlapping. The taxes are separate and distinct imposts. If in fact
they overlap, that may be because the taxing authority, imposing a duty of excise,
finds it convenient to impose that duty at the moment when the exciseable article
leaves the factory or workshop for the first time on the occasion of its sale. But that
method of collecting the tax is an accident of administration; it is not of the essence
of the duty of excise, which is attracted by the manufacture itself."
In view of this clear exposition of the content of the term "duty of excise" in the Indian setting we
think, no assistance can be derived for the meaning ascribed and the characteristics attributed to it
in the decision construing the relative taxing powers of the Dominion and the Provinces under the
British North America Act 1867.
Before dealing with the Australian decision to which Mr. Pathak drew our attention, we could
conveniently dispose of the American cases which were referred to by the learned counsel bearing
on the meaning of the word "excise". We might point out that the American decisions do not assist
the appellant in the least since under the Constitution of the United States practically every tax other
than a capitation, a poll tax or a tax on land is termed an "excise duty" and even income-tax was held
to be an 'excise' until the decision of the Supreme Court of the United States in Pollock v. Farmers
Loan & Trust Co. It has to be borne in mind that the American Constitution provides that direct
taxes have to be apportioned among the States according to their respective populations (Art. 1, s. 2,
and Art. 1, s. 9, cl.
4). Hence the attempt in the United States has been to bring taxes which according to the
classification of economists would be direct taxes within the category of excise or indirect taxes
which need not follow the rule as to apportionment among the States. It follows, therefore, that
neither the American decisions, nor the understanding by the Courts of that country as to what a
duty of excise connotes can be of any utility for deciding the content of that entry in the Indian
Constitution. The relevance of the American decisions is, therefore, even remoter than the decisions
from Canada which were relied on by the learned Counsel.
Mr. Pathak referred us to some of the decisions in Australia and in particular to Parton v. Milk
Board (Victoria) in support of his submission that the characteristic of being an indirect tax and
therefore the capability of being passed on was an essential ingredient and pre- requisite of an excise
duty. In this connection it is necessary to point out that the decisions in Canada which were relied
on by Mr. Pathak as aids for understanding the import of the expression "duty of excise" in Entry
84, have been treated by the Australian Courts as not helpful to determine the meaning of "excise"
in s. 90 of the commonwealth of Australia Act. As explained by Wynes:
"In Canada, the distribution of taxation is based upon the direct and indirect
character thereof, the Provincial power being limited to direct taxation within the
Province. Hence Canadian cases such as the Bank of Toronto v. Lambe are of very
little use in settling the question whether or not a tax is a duty of customs or exciseChhotabhai Jethabhai Patel And Co vs The Union Of India And Anther on 11 December, 1961

within the meaning of the Australian Constitution. It may be pointed out that under
the Australian Constitution taxes levied on commercial dealings in goods produced,
such as taxes on sales, have been held to fall within the category of excises. Several of
the decisions of the Australian High Court rendered before Parton v. Milk Board
(Victoria dealing with what constituted an excise under s. 90 of the Commonwealth
of Australian Act were cited to the Federal Court in the Province of Madras v. Boddu
Paidanna and the learned Chief Justice, after referring to them in detail, observed:
"We find it impossible to say that the expression 'duties of excise' even in Australia is
limited to duties imposed in connection with the production of a commodity alone.
We should be disposed to say on the contrary that in Australia all taxes on the sale of
commodities are, or may be regarded, as, duties of excise............ Under the
Australian Constitution power to impose duties of excise is, as we have said, the
exclusive right of the Commonwealth Parliament; the residuary taxing power remains
in the States. In the Indian Constitution Act the whole of the taxing power in this
particular sphere is expressly apportioned between the Centre and the Provinces, to
the one being assigned the power to impose duties of excise, to the other taxes on the
sale of goods."
The decision in the Milk Board case follows in general the same lines as did the earlier decisions
which have been detailed and discussed by Sir Maurice Gwyer C. J. in Paidanna's case. In these
circumstances we do not consider it useful or necessary to discuss these decisions. Undoubtedly,
there are passages in these judgments in the Australian Courts which refer to the fact that an excise
duty is an instance of an indirect tax. As regards the general proposition, however, there is little
controversy, but these decisions did not lay down that if by reason of the tax being levied
retrospectively the duty cannot be passed on it ceased to be a duty of excise. On the other hand,
there is express and high authority for the position that a duty of excise could be validly levied with
retrospective effect under the Australian Constitution. The question for consideration before the
privy Council in Colonial Sugar Refining Company Ltd. v. Irving related to the constitutional validity
of the Excise Tariff Act, 1902, passed by the Commonwealth Parliament. One of the objections
raised to the levy was that on the terms of the enactment which was passed on the 26th of July,
1902, the imposition of the duty could be as and from October 8, 1901, the day on which the
Minister had moved a resolution to that effect in the committee of Ways & Means of the House of
Representatives. The respondent before the Board who were manufacturers of refined sugar in
Brisbane in the State of Queensland questioned the legality of the tax which had been demanded
and paid by them in respect of the sugar produced by them between October 8, 1901, and July 26,
1902. Lord Davey delivering the judgment of the Board observed:
"It is a little difficult to understand the first point taken by the appellants. The
Parliament had undoubted power to impose taxation under the express words of s. 51
of the Constitution, and it is not now disputed that the Parliament could, if it thought
fit, make the Act retrospective and impose the duties from the date of the resolution.
That practice is (it is believed) universally followed in the imperial Parliament, and
(their Lordships were told) is common in the Colonial Legislatures in Acts of thisChhotabhai Jethabhai Patel And Co vs The Union Of India And Anther on 11 December, 1961

description, and for obvious reasons it is convenient and almost necessary. There was
nothing, therefore, in either the subject matter of the Act, or in the mode of dealing
with it, which was beyond the power of the Parliament."
In our opinion, the above aptly describes and covers the point raised by the appellants in the appeals
now before us.
There is no doubt that excise duties have been referred to by the economists and in the judgments of
the Privy Council as well as in the Australian decisions as an instance of an "indirect tax", but in
construing the expression "duty of excise" as it occurs in Entry 84 we are not concerned so much
with whether the tax is "direct" or "indirect" as upon the transaction or activity on which it is
imposed. In this context one has to bear in mind the fact that the challenge to the legislative
competence of the tax-levy is not directed to the imposition as a whole but to a very limited and
restricted part of it. This challenge is confined (a) to the operation of the tax between the period
March 1, 1951, and April 28, 1951, and (b) even in regard to this limited period, it is restricted to the
imposition of the additional duty of six annas per lb. which was levied, beyond the eight annas per
lb. collected from the appellants by virtue of the Finance Bill under the provisions of the Provisional
Collection of Taxes Act, 1931. It would seem to be rather a strange result to achieve that the tax
imposed satisfies every requirement of a "duty of excise" in so far as the tax operates from and after
April 28, 1951, but is not a "duty of excise" for the duration of two months before that date.
Learned Counsel conceded, as he had to, that even on the decision relied upon by him, the fact that
owing to the operation of economic forces it was not possible for the taxpayer to pass on the burden
of the tax, did not alter the nature of the imposition and detract from its being a "duty of excise". For
instance, the state of the market might be such that the duty imposed upon and collected from the
producer or manufacturer might not be capable of being passed on to buyers from him. Learned
Counsel urged that this would not matter, as one had to have regard to "the general tendency of the
tax" and "the expectation of the taxing authority" and to the possibility of its being passed on and
not to the facts of any particular case which impeded the operation of natural economic forces.
The impediment to the duty being passed on might be due not merely to private bargains between
the parties or abnormal economic situations such as the market for a commodity being a buyers'
market. Such impediments may be brought about by the operation of other laws which Parliament
might enact, such for instance, as control over prices. If in such a situation were the price which the
producer might charge his buyer is fixed by the statute, say under the Essential Supplies Act, and a
"duty of excise" is later imposed on the manufacturer, it could not be said that the duty imposed
would not answer the description of an "excise duty". Learned Counsel had really no answer to the
situation created by such a control of economy except to say that it would be an abnormal economic
situation. It could hardly be open to argument that a tax levied on a manufacturer could be stated
not to be a "duty of excise", merely because by reason of the operation of other laws the tax payer
was not permitted to pass on the tax-levy. The retrospective levy of a tax would be one further
instance of such inability to pass on, which doses not alter the real nature or true character of the
duty.Chhotabhai Jethabhai Patel And Co vs The Union Of India And Anther on 11 December, 1961

It might further be pointed out that the submission of the learned Counsel that a tax which
according to economic theory is an indirect tax or a tax on goods becomes a direct and a personal tax
and a tax of a different nature or category if imposed retrospectively because it was then incapable of
being passed on, does not correctly represent the law as laid down by this Court. In common with
duties of customs and excise, a tax on the sale of goods is another instance of a typical indirect tax
Indeed Lord Thankerton pointed out in Attorney- General for British Columbia v. Kingcome
Navigation Company Ltd.:
"The ultimate incidence of the tax in the sense of political economist is to be
disregarded and referred to a tax imposed in respect of some dealings in commodities
such as their import or sale or production for sale as instances of indirect taxes, the
tax not being a peculiar contribution upon one of the parties to the trading in the
particular commodity selected as the tax-payer."
The question of the validity of the imposition of a sales tax with retrospective effect came up for
consideration before this Court in the Tata Iron & Steel Co. Ltd. v. The State of Bihar. An argument
similar to the one now presented before us was submitted to this Court in challenge of that levy
which was summarized by Das, C.J., in these terms:
"The retrospective levy by reason of the amendment of s. 4(1) (of the Bihar Sales tax
Act which was impugned) destroys its character as a sales tax and makes it a direct
tax on the dealer instead of an indirect tax to be passed on to the consumer."
Dealing with this point the learned Chief Justice said :
"The argument is that sales-tax is an indirect tax on the consumer. The idea is that
the seller will pass it on to his purchaser and collect it from them. If that is the nature
of the sales-tax then, urges the learned Attorney-General, it cannot be imposed
retrospectively after the sale transaction has been concluded by the passing of title
from the seller to the buyer, for it cannot, at that stage, be passed on to the
purchaser............... Once that time goes past, the seller loses the chance of realising it
from the purchaser and if it cannot be realised from the purchaser, it cannot be called
sales-tax. In our judgment this argument is not sound. From the point of view of the
economist and as an economic theory, sales-tax may be an indirect tax on the
consumers, but legally in need not be so......... This also makes it clear that the
sales-tax need not be passed on to the purchasers and this fact does not alter the real
nature of the tax which, by the express provisions of the law, is cast upon the seller
.......... If that be the true view of sales-tax then the Bihar Legislature acting within its
own legislative field had the powers of a sovereign legislature and could make the law
prospectively as well as retrospectively. We do not think that there is any substance
in this contention."
In our judgment this passage covers the argument regarding a duty of excise getting its essential
nature altered and ceasing to be a duty of excise if imposed retrospectively. The submission,Chhotabhai Jethabhai Patel And Co vs The Union Of India And Anther on 11 December, 1961

therefore, lacks any force and is rejected.
It is also necessary to refer to one further matter : Even assuming that the learned Counsel is right in
his submission, that to be a duty of excise within Entry 84 of the Union List the taxing authority
should have expected the tax to be passed on, we consider that learned Counsel is not right in
submitting that condition is not satisfied in the case of the levy now impugned. The provisions of the
impugned enactment have to be read in the light of s. 64A of the Sale of Goods Act which enacts:
"In the event of any duty of customs or excise on any goods being imposed, increased
decreased or remitted after the making of any contract for the sale of such goods
without stipulation as to the payment of duty where duty was not chargeable at the
time of the making of the contract, or for the sale of such goods duty-paid where duty
was chargeable at that time:-
(a) if such imposition or increase so takes effect that the duty or increased duty, as
the case-may be or any part thereof, is paid, the seller may add so much to the
contract price as will be equivalent to the amount paid in respect of such duty or
increase of duty, and he shall be entitled to be paid and to sue for and recover such
addition, and
(b) if such decrease or remission so takes effect that the decreased duty only or no
duty, as the case may be, is paid, the buyer may deduct so much from the contract
price as will be equivalent to the decrease of duty or remitted duty and he shall not be
liable to pay, or be sued for or in respect of, such deduction."
This provision originally formed s. 10 of the Tariff Act VIII of 1894 and was subsequently enacted as
s. 10 in the Indian Tariff Act of 1934 (cl Act XXXII of 1934). The object of the statutory provision is
that where contracts for the sale of goods are entered into and the price payable therefor determined
on the basis of existing rates of duty-either of excise or of customs-neither party shall be prejudiced
or advantaged by reason of the increase or decrease of the duty. The question as to the scope of s. 10
of the Tariff Act of 1894 came up for consideration before a Bench of the Madras High Court whose
decision is reported in Narayanan v, Kadir Sahib (1). The suit out of which the second appeal before
the High Court arose was by a buyer of salt for the refund of salt-excise duty which had been
reduced after the date of the contract. The transaction of sale between the plaintiff and the
defendant took place on March 5, 1922, and the price payable by the plaintiff was based on the rate
of duty prevailing on that date. Subsequent thereto the Government of India reduced the duty on
salt from Rs. 5/- to Rs. 2/8/- per bag and this was to have effect from a date prior to March 5, 1922.
The defendant-firm (the sellers) had obtained from the Government refund of the duty on the salt
sold by them to the plaintiff. It was to recover this amount of duty that the suit was filed by the
buyer. The learned Judges held that on the terms of s, 10 of the Tariff Act of 1894 (indentical with s.
64A of the Sale of Goods Act) the fact that the contract was no longer executory but that delivery had
been made and the price paid, was no bar to the plaintiff succeeding in his suit.
It will be seen that s. 64A is in two parts:Chhotabhai Jethabhai Patel And Co vs The Union Of India And Anther on 11 December, 1961

the first cl. (a) dealing with the case of an increase in duty and conferring on the
seller the right to recover the amount of the increased duty from the buyer, and the
second limb (cl. b) making provision regarding the correlated case of a reduction in
the duty with corresponding rights to the buyer to obtain the benefit of a reduction.
Whatever argument might be raised baned upon the language of the second limb of
the section, it is not open to doubt that in the case of an increase in duty, the seller
would be entitled to recover the duty from the buyer provided: (a) there was no
contract to the contrary by which he had precluded himself from claiming such
enhanced duty, i. e., the contract having negatived or limited the seller's right to
prefer such a claim, or was at least silent as regards what was to happen in the event
of the duty being increased, (b) the change in the rate of duty was effected after the
date of the contract. In these circumstances, it appears to us that there might not be
even a factual basis for the complaint of learned Counsel for the appellants that in the
case of a retrospective increase in duty, the duty ceases to be a duty of excise by
becoming a "direct" tax because it was incapable of being passed on. The answer of
learned Counsel to this point regarding the operation of s. 64A of the Sale of Goods
Act was merely that the Court could not take account of the provisions of another
statute for dealing with the validity of a provision of the Finance Act 1911. The
submission has no force at all because s. 64A of the Sale of Goods Act refers in
express terms to "duties of excise" and has therefore, to be read as part and parcel of
every legislation imposing a duty of excise. In view of our conclusion, however, that
the duty in the present case, notwithstanding its imposition with retrospective effect,
and even if it be that it was incapable of being passed on to a buyer from the
tax-payer, was a duty of excise within Entry 84 as properly understood it is not
necessary to rest it upon this narrower ground.
In our view, a duty of excise is a tax-levy on home produced goods of a specified class
or description, the duty being calculated according to quantity or value of the goods
and which is levied because of the mere fact of the goods having been produced or
manufactured and unrelated to and not dependent on any commercial transaction in
them. The duty in the present case satisfies this test and therefore it is unnecessary to
seek other grounds for sustaining the validity of the tax.
One further aspect of the matter on which some emphasis was laid by Mr. Pathak was
that a duty of excise was in its essence a tax on goods and not a personal tax a levied
on the tax payer such as an income-tax. He urged that being a tax levied on goods
notwithstanding that it was collected from the producer or manufacturer, it followed
that the essential attribute or characteristic of that duty was that the producer or
manufacturer must own or have possession and control over the goods at the
moment of the levy. If this element of ownership, possession or control over the
goods by the tax-payer was lacking, learned Counsel urged the duty would not be a
duty on the goods but a personal tax levied on the tax-payer.Chhotabhai Jethabhai Patel And Co vs The Union Of India And Anther on 11 December, 1961

This is really another aspect of the same argument that a duty of excise is in its nature
an indirect tax but learned Counsel submitted that viewed from this angle it would be
seen that the duty imposed by the impugned enactment was shown to be not a duty of
excise. The grounds upon which the submission of learned Counsel that a duty of
excise levied retrospectively was converted into a direct tax and therefore not a duty
of excise have been repelled by us which ought to suffice to repel the contention in
this form also. Besides, it may also be pointed out that even in strict theory there is
no basis for the submission now under consideration. The duty imposed by the
impugned Act being retrospective, it operates as from a previous date and admittedly
on the date when by force of the enactment the duty was levied the tax-payer was the
owner or was in possession and control of the goods. To deny this, would in effect
deny the legal effect of the tax being imposed retrospectively and fictionally deemed
to be in force on an earlier date.
In dealing with the arguments of learned Counsel on the scope and content of Entry
84 of the Constitution and of the meaning of the expression "duty of excise" in that
entry we have also covered the special argument questioning the right of Parliament
to impose retrospectively a duty of excise. It was conceded, that Parliament has
power to enact laws with retrospective effect and as it was not suggested that laws
dealing with taxation are any exception to that rule the only ground upon which the
learned Counsel could rest this submission was that being an indirect tax, capability
of being passed on was an essential characteristic or requirement of a duty of excise,
and so its imposition with retrospective effect deprived it of that essential character
and therefore rendered it a duty of a different nature and for that reasons a
retrospective imposition of an excise duty was not permissible. It would be seen that
this is really the same argument which we have dealt with earlier presented in
another form. For the reasons already stated, we find no substance in this form of
argument either and we have no hesitation in rejecting it. It need only be mentioned
that the passage in judgment of Lord Davey in the Colonial Sugar Refining Company
Ltd. v. Irving, already extracted, is sufficient precedent, if authority were needed, to
reject this argument.
The second point raised by learned Counsel was that the impugned s. 7(2) of the Act
was unconstitutional in that it contravened the fundamental rights guaranteed under
Arts. 19(1)(f) and 31(1) and (2) of the Constitution. It was urged that even if the
impugned provision was within the legislative competence of Parliament as being
covered by Entry 84 of the Union List, the retrospective levy of an excise duty
violated the freedom guaranteed by Art. 19 (1)(f)-the right to hold property-and was
not saved by Art. 19(5) since the same was not "a reasonable restraint" on the rights
of the appellant. If Counsel was right so far, his next submission was that the threat
to deprive the appellant of the amount of the tax levy was a deprivation without
authority of law- Art. 31(1) and was further a compulsory acquisition of that property
without compensation (Art. 31(2)) which was not saved by Art. 31(5)(b)(i) because
the law contemplated by that sub-article was a valid law for the imposition of a taxChhotabhai Jethabhai Patel And Co vs The Union Of India And Anther on 11 December, 1961

which satisfied the requirements both of legislative competence and of the rights
guaranteed by Part III of the Constitution.
The submission of Mr. Pathak on this part of the case was briefly as follows. A law
which imposes a tax and provides for its levy and collection is as much a law, as a law
under other non-taxation entries of the legislative list. All laws including laws
imposing taxes are within Part III of the Constitution being laws under Art. 13(2)
thereof and unless any particular Article was inapplicable to such laws by reason of
obvious irrelevance every Article in the Part would apply to them and without such a
law satisfying the test of reasonableness or constitutionality laid down in the various
Articles guaranteeing the several. Fundamental rights the statute in question could
not be pronounced valid and enforceable.
We shall be referring to the manner in which Mr. Pathak sought to urge that the
impugned provision offended Art. 19(1) (f), but before doing so, it is necessary to
notice the submission which Mr. Sanyal invited us to accept.
He raised a broad contention that no law imposing a tax could be impugned on the
ground of violation of Part III of the Constitution in general and in particular of Art.
19(1) (f) or Art. 31. His submission was that the validity of tax laws were governed
solely by Art. 265 and that such laws were not governed by Part III of the
Constitution and specially because the money sought to be taken by the State as tax
by virtue of a fiscal enactment was not "property" within Art. 19(1) (f) and that the
expression "laws for the purpose of imposing a tax" used in Art. 31(5)
(b) (i) saved all laws from the operation of Art.
31 whether such laws be within legislative competence or not, as also whether or not such laws were
repugnant to Part III of the Constitution.
Before adverting to the decisions on which reliance was placed for this position two things might he
pointed out: (1) that Art. 265 merely enacts that all taxation-the imposition, levy and collection shall
be by law; and (2) that the Article beyond excluding purely executive action does not by itself lay
down any criterion for determining the validity of such a law to justify any contention that the
criteria laid down exclude others to be found elsewhere in the Constitution for laws in general. If by
reason of Art. 265 every tax has to be imposed by "law" it would appear to follow that it could only
be imposed by a law which is valid by conformity to the criteria laid down in the relevant Articles of
the Constitution. These are that the law should be (1) within the legislative competence of the
legislature being covered by the legislative entries in Schedule VII of the Constitution; (2) the law
should not be prohibited by any particular provision of the Constitution such as for example, Arts.
276(2), 286 etc., and (3) the law or the relevant portion thereof should not be invalid under Art. 13
for repugnancy to those freedoms which are guaranteed by Part III of the Constitution which are
relevant to the subject matter of the law. The reference therefore to Art. 265 does not lead
necessarily to the result envisaged by Mr. Sanyal.Chhotabhai Jethabhai Patel And Co vs The Union Of India And Anther on 11 December, 1961

The entire argument of Mr. Sanyal on this part of the case was rested on the observations contained
in two decisions of this Court, Ramjilal v. Income-tax Officer, Mohindargarh and Laxmanappa
Hanumantappa Jamkhandi, v. The Union of India. We do not understand these decisions as laying
down any such broad proposition. We are further satisfied that the learned Judges could not have
meant that if a law imposing a tax was outside the legislative competence of the legislature enacting
it, as the argument before us appeared to suggest it could be a law under which a person could be
deprived of his property under Art. 31(I) or regarding which a person could not move this Court for
relief under Art. 32. Such a proposition would be contrary to a long catena of cases of this Court of
which it is sufficient to refer to Mohammad Yasin v. The Town Area Committee, Jalalabad, State of
Bombay v. The United Motors (India) Ltd., The Bengal Immunity Company Limited v. The State of
Bihar and Ch. Tika Ramji v. The State of Uttar Pradesh. In all these cases the legislation imposing
the tax or the fee which had been held not to have been within the legislative competence of the
authority imposing the tax or the fee was struck down on the ground that those laws violated the
freedom guaranteed by Part III of the Constitution. Learned Counsel laid some stress on the fact
that in these cases the tax or fee was held to be unconstitutional as imposing an unreasonable
restraint on the right to carry on a trade or business guaranteed by Art. 19(1)(g) and not as an
infringement of the right to hold "property" under Art. 19(I)(f). In our opinion nothing turns on this,
for it is the deprivation of the freedom "to hold property" that is the direct result of the tax and the
restraint on the business by reason of the collection of the illegal tax or the procedures prescribed
for such collection is only an indirect and incidental effect thereof.
Nor do we find it possible to accept even the more limited proposition that whatever be the position
in regard to tax laws which lack legislative competence, once a tax law is covered by an entry in the
Legislative List and does not contravene direct prohibitions like those in Arts. 276 (2) or 286 etc.,
such a law is immune from the limitations imposed by Part III of the Constitution.
Mr. Sanyal is right in his submission that the levying of taxes though it might involve taking private
property for a public use is entirely distinct from the power of eminent domain which is covered by
Art. 31(1)(2) and that the saving in Art. 31(5)(b) (i) of such laws is really by way of abundant caution.
It has been stated that where "property is taken under a taxing power, the persons so taxed may be
said to be compensated for their contribution by the general benefits which they receive from the
existence and operation of Government. But this is not to say that the burden of a tax that may be
constitutionally laid upon an individual needs to be justified by a showing that he, individually will
receive benefit from the expenditure of the proceeds of the tax, and much less that the degree of that
burden may be measured by the amount of benefit that the tax payer is excepted to receive (1)". It
would, therefore, be obvious that a tax law need not satisfy the tests of Art. 31(2).
But it does not follow that every other Article of Part III is inapplicable to tax law. Leaving aside Art.
31(2) that the provisions of a tax law within legislative competence could be impugned as offending
Art. 14 is exemplified by such decisions of this Court as Suraj Mal Motha v. Sri A. V. Visvanatha
Sastri and Shree Meenakshi Mills Ltd., Madurai, v. Sri A. V. Visvanatha Sastri. In Moopil Nair v.
State of Kerala the Kerela Land Tax Act was struck down as unconstitutional as violating the
freedom guaranteed by Art. 14. It also goes without saying that if the imposition of the tax was
discriminatory as contrary to Art. 15, the levy would be invalid.Chhotabhai Jethabhai Patel And Co vs The Union Of India And Anther on 11 December, 1961

It might very well be that a distinction might have to be drawn between the legality of the quantum
of a tax levied which might not be open to challenge under Art. 19(1)(f) and the incidence of the tax
or the procedure prescribed therein either for the assessment or the collection which might be open
for being tested with reference to all the freedoms including that contained in Art. 19(1)(f). In fact in
Moopil nair v. State of Kerala (1) already referred to, certain provisions of the Act therein challenged
which prescribed the procedure for the levy of the tax were struck down on the ground of being
obnoxious to Art. 19(1)(f). Having regard to the very limited controversy before us we do not
consider it necessary to embark on any further or more detailed examination of this question, except
to say that we cannot accept the argument of the learned Additional Solicitor General that by reason
of Art. 265 tax laws are outside Part III of the Constitution.
In support of the submission that a tax levied with retrospective effect was unconstitutional as being
an unreasonable restriction on this right to hold property (Art. 19(1)(f)). Mr. Pathak relied on the
decisions in Nichols v. Coolidge (2). The tax in question was an estate duty on property passing on
death and in the items to be included for computing the value of the estates was included not merely
all property of which the deceased died possessed, on the date of his death but also that which he
had transferred by gifts within a period of two years fore his death. This inclusion of property
transferred to third persons not in contemplation of death but by the grantor in the ordinary and
natural course of the transaction of his affairs so that the donees might enjoy the properties
absolutely, was held to be unconstitutional as offending the rule as to "due process" contained in
fifth amendment to the constitution. Justice McReynolds delivering the opinion of the Court said:
"Under the theory advanced for the United States, the arbitrary, whimsical and
burdensome character of the challenged tax is plain enough .....Real estate
transferred years ago, when of small value, may be worth an enormous sum at the
death. If the deceased leaves no estate there can be no tax; if, on the other hand, he
leaves ten dollars both that and the real estate become liable. Different estates must
bear disproportionate burdens determined by what the deceased did one or twenty
years before he died. This Court has recognised that a statute purporting to tax may
be so arbitrary and capricious as to amount to confiscation and offend the fifth
Amendment. We must conclude that s. 402(c) of the statute here under
consideration, in so far as it requires that there shall be included in the gross estate
the value of property transferred by a deceased prior to its passage merely because
the conveyance was intended to take effect in possession or enjoyment at or after his
death, is arbitrary, capricious and amounts to confiscation."
Learned Counsel also referred us to a few later decisions of the American Supreme Court in which
retrospective taxation has been held arbitrary and capricious and to amount to a violation of the due
process clause contained in the 5th Amendment. In regard to these decisions, two points have to be
noted: (1) that the decisions of Supreme Court of the United States are not uniform and there are
undoubtedly decisions of the Court of a later date which speak the other way. In Third National
Bank v. White (1) the Supreme Court upheld an estate tax which operated retrospectively. It is in
view of these decisions that Mr. Ballard states in an article in the Harvard Law Review (*), referring
to White's case (1) "It seems accurate to say that the decision marks for practical purposes theChhotabhai Jethabhai Patel And Co vs The Union Of India And Anther on 11 December, 1961

passing of 'arbitrary retroactivity' in the field of the estate tax...........And the present status of
Nichols v. Coolidge is not entirely clear......... Since the Nichols case can be distinguished on its facts,
it may well give way.........In any event.......it would seem that after the White case no application of
the estate tax can be successfully resisted on the score of retroactivity."
For instance in Welch v. Henry (1) which related to an enactment imposing income tax which had
retrospective operation, Justice Stone delivering the Judgment of the Court referring to Nichols v.
Coolidge (2) and other cases in which observations broadly stating that any retrospective tax
legislation was obnoxious to the requirement of due process, stated:
"Even a retroactive gift tax has been held valid where the donor was forewarned by
the statute books of the possibility of such a levy. In each case it is necessary to
consider the nature of the tax and the circumstances in which it is laid before it can
be said that its retroactive application is so harsh and oppressive as to transgress the
constitutional limitation."
"Any classification for taxation is permissible which has reasonable relation to a
legitimate end of governmental action. Taxation is but the means by which
government distributes the burdens of its cost among those who enjoy its benefits.
And the distribution of a tax burden by placing it in part on a special class which by
reason of the taxing policy of the State has escaped all tax during the taxable period is
not a denial of equal protection.
Nor is the tax any more a denial of equal protection because retroactive..........A tax is
not necessarily unconstitutional because retroactive. Milliken v. United States and
cases there cited. Taxtation is neither a penalty imposed on the taxpayer not a
liability he assumes by contract. It is but a way of apportioning the cast of
government among those who in some measure are privileged to enjoy its benefits
and must bear its burdens. Since no citizen enjoys immunity from that burden, its
retroactive imposition does not necessarily infringe due process, and to challenge the
present tax is not enough to point out that the taxable event, the receipt of income,
antedated the statute."
In Untermyer v. Anderson (1) which was concerned with the validity of a tax on gifts which was
made to operate from a date before it was enacted, Justice Holmes stated:
"........I find it hard to state to myself articulately the ground for denying the power of
Congress to lay the tax. We all know that we shall get a tax bill every year. I suppose
that the taxing act may be passed in the middle as lawfully as at the beginning of the
year. A tax may be levied for past privileges and protection as well as for those to
come,"
and Justice Brandeis made the added observations which have been repeatedly quoted in later
decisions as well as in text books:Chhotabhai Jethabhai Patel And Co vs The Union Of India And Anther on 11 December, 1961

"For more than half a century, it has been settled that a law of Congress imposing a
tax may be retroactive in its operation...... Each of the fifteen income tax acts adopted
from time to time during the last sixty-seven years has been retroactive, in that it
applied to income earned, prior to the passage of the act, during the calendar
year........ The need of the government for revenue has hitherto been deemed a
sufficient justification for making a tax measure retroactive whenever the imposition
seemed consonant with justice and the conditions were not such as would ordinarily
involve hardship. On this broad ground rest the cases in which a special assessment
has been upheld...... Liability for taxes under retroactive legislation has been 'one of
the notorious incidents of social life'........ Recently this Court recognized broadly that
'a tax may be imposed in respect of past benefit'."
It would thus be seen that even under the constitution of the United States of America the
unconstitutionality of a retrospective tax is rested on what has been termed "the vague contours of
the 5th Amendment." Whereas under the Indian Constitution that grounds on which infraction of
the rights a property is to be tested not by the flexible rule of "due process" but on the more precise
criteria set out in Art. 19(5), mere retrospectivity in the imposition of the tax cannot per se render
the Law unconstitutional on the ground of its infringing the right to hold property under Art.
19(1)(f) or depriving the person of property under Art. 31(1). If on the one hand, the tax enactment
in question were beyond legislative competence of the Union or a State necessarily different
considerations arise. Such unauthorised imposition would undoubtedly not be a reasonable
restriction on the right to hold property beside being an unreasonable restraint on the carrying on of
business, if the tax in question is one which is laid on a person in respect of his business activity.
Mr. Pathak also presented his argument on this head in a slightly different form. He submitted that
the Constitution-makers had contemplated that a duty of excise would be imposed only when the
manufacturer or the producer was in possession and control of the goods at the moment of the
imposition, and therefore would be in a position to pass it on and obtain payment from the
purchaser of the duty paid by him to State. The imposition of the levy retrospectively however
deprive him of this benefit of passing on the burden which he would normally have. This restriction
or impairment of his right to pass on the duty, he urged rendered the restriction imposed on him in
the shape of the obligation to pay the duty unreasonable. Learned Counsel admitted that as the
imposition would yield to the Exchequer more money, the restriction on appellants' right to hold
property could not be denied to be in the 'interest of the general public" within Art. 19(5) but his
submission was that it lacked the character of "reasonableness" because it deprived him of the right
to pass on the tax to others. It was further admitted that it was only if learned Counsel was right in
his submission regarding the infraction of Art. 19 (1)
(f) that any question of the violation of Art. 31 (1) could arise. It would be seen that it is the same
argument as was presented to challenge the legislative competence of Parliament to enact the
legislation. Only the nomenclature employed is different and adapted to suit the need of bringing it
into the fold of an impairment of fundamental rights under Part III of the Constitution. As Evatt, J.
observed in Broken Hill South Limited (Public Officer) v. The Commissioner of Taxation (New
South Wales) (1) "It is not proper to deny to the legislature the right of solving taxation problemsChhotabhai Jethabhai Patel And Co vs The Union Of India And Anther on 11 December, 1961

unfettered by legal categories." If notwithstanding that according to economic theory or doctrines
propounded by economists a duty of excise does not cease to be such, merely because it is imposed
at a time or in circumstances (as pointed out earlier in conjunction with a system of price control) in
which it cannot be passed on one fails to see any substance in the argument that the imposition of
such a tax is an unreasonable restriction on the exercise of the fundamental rights to hold property
guaranteed by Art. 19 (1) (f).
The last of the points urged was that r. 10A was not apt to cover the recovery of the duty which was a
subject of demand dated December 12, 1951. The learned Judges of the High Court rejected this
submission and, in our opinion, correctly. Rule 10 under which the first demand of June 22, 1951,
was made ran:
"10. Recovery of duties or charges short levied or erroneously refunded.-When duties
or charges have been short-levied through inadvertence, error, collusion or
misconstruction on the part of an officer, or through mis-statement as to the
quantity, description or value of such goods on the part of the owner, or when any
such duty or charge, after having been levied, has been owing to any such cause,
erroneously refunded the person chargeable with the duty or charge, so short-levied,
or to whom such refund has been erroneously made shall pay the deficiency or repay
the amount paid to him in excess, as the case may be, on written demand by the
proper officer being made within three months from the date on which the duty or
charge was paid or adjusted in the owners account-current, if any, or from the date of
making the refund."
The contention which was then urged was that the short-levy which led to the demand was not
caused through inadvertence, error etc., which are set out in this rule and that consequently there
was a defect in the operative machinery for collection of the refund. This objection of the present
appellants was upheld by the Full Bench of the Nagpur High Court and it was as a result of this
decision that rule 10 A was framed. This rule reads:
10A. Residuary powers for recovery of sums due to Government.-Where these rules
do not make any specific provision for the collection of any duty, or of any deficiency
in duty if the duty has for any reason been short-levied, or of any other sum of any
kind payable to the Central Government under the Act or these Rules, such duty
deficiency in duty or sum shall, on a written demand made by the proper officer, be
paid to such person and at such time and place, as the proper officer may specify."
The words "deficiency in duty if the duty has for any reason been short-levied" are in
our opinion, wide enough to include cases of deficiency arising like those in the
circumstances of the present case, viz., where 8 annas out of the 14 annas of the duty
has been collected in the first instance but 6 annas remains to be collected. We
consider, therefore, that there is no substance in the objection that r. 10A is not wide
enough to cover the recovery of the duty from the appellants.Chhotabhai Jethabhai Patel And Co vs The Union Of India And Anther on 11 December, 1961

The result is that these appeals fail and are dismissed with costs. There will, however,
be only one hearing fee for all the cases. The writ petitions also fail and are dismissed,
without any order as to cost.
KAPUR J.- The appellants are manufacturers, warehousemen and merchants of
tobacco and they have private licensed warehouses which are governed by r. 140 of
the Rules made under the Central Excise & Salt Act (Act 1 of 1944), hereinafter
termed the "Act."
According to their allegations in the petition under Art. 226 of the Constitution, the
appellants had a considerable quantity of tobacco in their licensed warehouses on
February 28, 1951. On the same day the Central Bill (Bill No. 13 of 1951) was
introduced in the House of the People, one of the clauses of which related to the duty
of excise for the financial year beginning April 1, 1951. According to the Bill, on
unmanufactured tobacco a duty of 8 As. per Ib. and 6 to 9 As. (per 1000) Biris was to
be imposed. This Bill was amended and by this amendment the duty on tobacco other
than Biri tobacco was fixed at 6 As. per Ib. On Biri tobacco 14 As. per Ib. and no duty
was imposed on manufactured Biris. As a result of the operation of ss. 3 & 4 of the
provisional Collection of Taxes act (Act XVI of 1931) the duty became leviable as from
the date of the introduction of the Bill. The petitioner have stated that in accordance
with the provisions of the Bill that was introduced, they paid excise duty on tobacco
in their possession at the rates mentioned in the Bill and obtained clearance
certificates in accordance with the Rules under the Act. On April 28, 1951, the
Finance Bill was passed and became Finance Act, 1951 (Act XXIII of 1951). By s. 7 of
that Act the first schedule to the Central Excise and Salt Act was amended in
accordance with what has been stated above. By s. 7. (2) of the Finance Act. 1951, it
was provided that the amendment made in the first schedule to the Act shall be
deemed to have effect on and from the first day of March 1951. A demand was
subsequently made from the appellants in respect of excess duty payable on tobacco
cleared out of the store houses from March 1, 1951, to April 28, 1951.
Thereupon the appellants filed a petition under Art. 226 of the Constitution in the
High Court at Nagpur. The grounds of the attack as to the constitutionality of the tax
were decided against the appellants but the petition succeeded on the ground that
there was no machinery provided under the Act for recovery of the tax. This
judgment is reported as Chhotabhai Jethabhai Patel & Co. v. The Union of India (1).
On December 8, 1951, the Central Government by a notification amended the Central
Excise Rules by adding r. 10A which provided machinery for the collection of tax. The
rule was :-
"10-A. Residuary powers for recovery of sums due to Government.-Where these rules
do not make any specific provision for the collection of any duty or of any deficiency
in duty if the duty has for any reason been short levied, or of any other sum of any
kind payable to the Central Government under the Act or these Rules, such duty,Chhotabhai Jethabhai Patel And Co vs The Union Of India And Anther on 11 December, 1961

deficiency in duty or sum shall on a written demand made by the proper officer be
paid to such person and at such time and place as the proper officer may specify."
After the introduction of this rule a fresh demand was made on December 12, 1951, for excess duty
on the tobacco cleared. The appellants again filed a petition in the High Court of Nagpur which was
decided against them and against that judgment the appellants have come to this court on a
certificate under Art. 132 of the Constitution. The question submitted to this Court is as to the
validity of the said tax on the ground of its repugnancy to the Constitution of India.
Counsel for the appellants has raised two questions against the legality of the taxes; (1) The
Parliament had no power to make a retrospective legislation while making a law under item 84 of
List I so as to affect goods that had been cleared from the warehouses after payment of proper duties
at the rates prevailing on the date that the goods were cleared because (a) Parliament's power to
make retrospective laws is subject to constitutional limitations, namely, the language of item 84 of
List I; (b) duty of excise as defined in the Constitution and its nature and character is such that it is
not capable of being exercised after the goods on which it is imposed are no longer in possession of
the warehousemen and after they have passed into the common stock of the country; (2) legislation
of this character imposes an unreasonable restriction under Art. 19 (1) (f); and (3) r. 10-A does not
apply to the facts of the case and does not authorise the collection of the duty imposed.
The first point relates to the legislative competency of Parliament. Item 84 of List I provides: Item
84 "Duties of excise on tobacco and other goods manufactured or produced in India..." In the
corresponding item under the Government of India Act, 1935, the same language was used so that
the nature of the duties remains the same both under the Constitution and under the Government of
India Act, 1935 Section 3 of the Act empowers the levying of duties specified in the First Scheduled.
The relevant portion of that section is as follows:-
Section 3(1) "There shall be levied and collected in such manner as may be prescribed
duties of excise on all excisable goods other than salt which are produced or
manufactured in India and a duty on salt manufactured in, or imported by land into,
any part of India as, and at the rates set forth in the First Schedule."
By s. 7 (2) of the Act retrospective effect was given to the duties imposed by the
Finance Act taking effect as and from the First day of March, 1951.
S. 7(2) "The amendment made in the Central Excises and Salt Act, 1944, by sub-
section (1) shall be deemed to have had effect on and from the first day of March
1951......."
The effect of this deeming provision is that the new rates of duties must be taken to
have been imposed and become operative as if they were in the bill as and when the
bill was introduced in Parliament: Venkatachalam v. Bombay Dyeing &
Manufacturing Co. Ltd.(1).Chhotabhai Jethabhai Patel And Co vs The Union Of India And Anther on 11 December, 1961

The contention raised is as to the nature of the duty of Excise. It was argued that
Excise Duty is a tax on goods which must exist at the time when the tax is levied and
it must have been intended and expected by the legislature that it will be passed on to
the consumer and as retrospective operation of such duties has not got these qualities
when the goods are no longer in possession of the person sought to be taxed they do
not fall within the term "duty of excise" and therefore they are beyond the legislative
competence of Parliament. To support his contention, counsel for the appellants
relied on Bank of Toronto v. Lambe (2) where the question for decision was as to
whether certain taxes imposed on commercial corporations carrying on business
were direct taxes or indirect taxes of the Provinces or the Dominion. Lord Hobhouse
at p. 582 relying upon the definitions given by John Stuart Mill said:-
"Taxes are either direct or indirect. A direct tax is one which is demanded from the
very persons who it is intended or desired should pay it. Indirect taxes are those
which are demanded from one person in the expectation and intention that he shall
indemnify himself at the expense of another; such are the excise or customs."
The same distinction was brought out in some other Canadian cases decided by the Privy Council;
City of Halifax v. Estate of J. P. Fairbanks (3) which related to the nature of "Business Tax"
which was held to be a direct tax; Attorney- General for British Columbia v. Mc
Donald Murphy Lumber Company Ltd. (1); & Attorney-General for British Columbia
v. Kingcome Navigation Comapny Limited (2) Attorney-General for Manitoba v.
Attorney-
General for Canada (3) and Brewers & Malster's Association of Onatario v. The Attorney-General for
Ontario (4) Reference was next made to an Australian case Parton v. Milk Board (Victoria) (5) where
two necessary qualities of the duty of Excise were stated to be that it must be levied on goods which
are in existence and the taxpayer should be able to pass it on to the consumer.
But as was pointed out by Gwyer, C.J., in the Province of Madras v. Boddu Paidanna (6):
"The Canadian cases which were cited do not seem to afford any assistance since
analogous problems in Canada are always concerned with direct and indirect
taxation...."
Dealing with the same distinction the Privy Council said in Governor-General in Council v. Province
of Madras (7):-
"Little assistance is to be derived from the consideration of other federal
constitutions and of their judicial interpretations. Hence there is no question of direct
and indirect taxation..." The Indian Constitution is unlike any that have been called
to their Lordships' notice in that it contains what purports to be an exhaustive
enunciation and division of legislative powers between the Federal and ProvincialChhotabhai Jethabhai Patel And Co vs The Union Of India And Anther on 11 December, 1961

Legislatures."
The Excise duty in England came to be imposed as a scheme of revenue and taxing device by Pym
and approved by the Long Parliament. It consisted of charges on wine and tobacco and some other
articles were added later. The basic principle of duties of Excise was that they were taxes on the
production and manufacture of articles which could not be taxed through the customs house. The
revenue derived from that source is called excise revenue proper. In England it was later on
extended to comprise other taxes but the fundamental conception of the term is that it is a tax on
articles produced or manufactured in the country. It was in this sense that the word "duty of excise"
was understood in Australia (Peterswalad v. Bartley (1).
The importance of legislative practice of a country was pointed out by the Privy Council in a
Canadian case Croft v. Dunphy (2) where it was held that when a power is conferred to legislate on a
particular topic it is important in determining the scope of the power to have regard to what is
ordinarily treated as embraced within that topic in the legislative practice in England, U.S.A. and the
Dominions and of India, the Federal Court considered the nature of duty of Excise in Re The Central
Provinces & Berar Sales of Motor Sprit & Lubricants Taxation Act (In re A Special Reference under
s. 213 of Government of India Act, 1935) (3), generally known as the "Central Provinces" case. In
that case the Act of the Provincial legislature levying a tax on retail sale of motor spirit was held to
fall within item 48 in List II of the 7th Schedule of the Constitution Act and not a duty of Excise
within the meaning of entry 45 of List I of that Schedule. The nature of the duty was considered by
the Court. Gwyer, C. J., after referring to the distionary meaning of the word "excise" said at p. 41:-
"But its primary and fundamental meaning in English is still that of a tax on articles
produced or manufactured in the taxing country and intended for home
consumption. I am satisfied that is also its primary and fundamental meaning in
India; and no one has suggested that it has any other meaning in entry No. 45."
At p. 47 the learned Chief Justice said:-
"The expression "duties of excise", taken by itself conveys no suggestion with regard
to them time or place of their collection. Only the context in which the expression is
used can tell us whether any reference to the time or manner of collection is to be
implied. It is not denied that laws are to be found which impose duties of excise at
stages subsequent to manufacture or production; but so far as I am aware, in none of
the cases in which any question with regard to such a law has arisen was it necessary
to consider the existence of a competing legislative power such as appears in entry
No. 48."
But Mr. Pathak relied on the observations of the learned Chief Justice at p. 50 where he said:-
"Thus the Central Legislature will have the power to impose duties on excisable
articles before they become part of the general stock of the Province, that is to say at
the stage of manufacture or production, and the Provincial Legislature an exclusiveChhotabhai Jethabhai Patel And Co vs The Union Of India And Anther on 11 December, 1961

power to impose a tax on sales thereafter."
But these observations only mean this that when there is a competition between the duty, imposed
at the stage of manufacture of production and a tax imposed on sales thereafter, the sphere of the
Central and the Provincial Legislatures comes into operation but, as the previous passages, show, it
does not in any manner vary the meaning of the word "excise" nor does it accept a further
qualification which is sought to be included in that phrase as a necessary quality of that tax that
unless it is capable of being passed on to the consumer or the person taxed can indemnify, himself,
it is not a duty of excise. At p. 47, the learned Chief Justice observed that in the expression "duties of
excise"
no suggestion as to time or place of collection was implied. Sulaiman, J., pointed out
at p. 73 that in the Indian Constitution it was not necessary to go into the fine niceties
of distinction between direct and indirect taxation because in the Indian Act no such
division existed and that ultimate incidence of tax was not a crucial test under the
Indian Constitution. Again at p. 77, Sulaiman, J., said:-
"The essence of a tax on goods manufactured or produced is that the right to levy it
accrues by virtue of their manufacture or production. It is immaterial whether the
goods are actually sold or consumed by the owner or even destroyed before they can
be used. If a duty is imposed on the goods manufactured or produced when they issue
from the manufactory then the duty becomes leviable independently of the purpose
for which they leave it and irrespective of what happens to them later."
In a subsequent case The Province of Madras v. Messrs. Boddu Paidnna & Sons(1) Gwyer, C. J.,
again went into the question of the nature of the duty of excise under the expression "duties of
excise" and said at p. 101:-
"There is in theory nothing to prevent the Central Legislature from imposing a duty
of excise on a commodity as soon as it comes into existence, no matter what happens
to it afterwards, whether it be sold, consumed, destroyed or given away. A taxing
authority will not ordinarily impose such a duty, because it is much more convenient
administratively to collect the duty (as in the case of most of the Indian Excise Acts)
when the commodity leaves the factory for the first time, and also because the duty is
intended to be an indirect duty which the manufacturer or producer is to pass on to
the ultimate consumer, which he could not do if the commodity had, for example
been destroyed in the factory itself. It is the fact of manufacture which attracts the
duty, even though it may be collected later; and we may draw attention to the Sugar
Excise Act in which it is specially provided that the duty is payable not only in respect
of sugar which is issued from the factory but also in respect of sugar which is
consumed within the factory."
The Privy Council described the nature of the duty of Excise in Governor-General in Council v.
Province of Madras (1) as a duty which is primarily levied on a manufacturer or producer in respectChhotabhai Jethabhai Patel And Co vs The Union Of India And Anther on 11 December, 1961

of the commodity manufactured or produced. At p. 103 Lord Simonds referred to In re Central
Provinces & Berear case (2) and to Baddu Paidanna case (3) and said:-
"The two taxes, the one levied on a manufacturer in respect of his goods, the other on
a vendor in respect of his sales, may as is there pointed out in one sense overlap. But
in law there is no overlapping.- The taxes are separate and distinct imposts. If in fact
they overlap, that may be because the taxing authority, imposing a duty of excise
finds it convenient to impose that duty at the moment when the excisable article
leaves the factory or workshop for the first time on the occasion of its sale. But that
method of collecting the tax is an accident of administration; it is not of the essence
of the duty of excise, which is attracted by the manufacture itself. That this is so is
clearly exemplified in those excepted cases in which the Provincial, not the Federal
legislature has power to impose a duty of excise."
Thus according to the Indian cases decided on the nature of duties of excise ultimate incidence is not
of any importance or relevance. In dealing with excise duty (1) there is no mention of a direct or
indirect taxes; the Indian Legislature has avoided this incidence to be characteristic of the tax; (2)
taxable event is the manufacture or production of goods; it is immaterial what happens to them
afterwards whether they are sold, consumed, destroyed or given away; (3) it is not a necessary
incidence that the manufacturer must be able to pass it on to the consumer or indemnify himself;
(4) the general tendency of its being passed on may be there but it may be prohibited by the
circumstances, economic or otherwise. The fact that the manufacturer has no chance to get the tax
from the buyer does not affect the legality of the tax; it was so held in the case of sales tax in The
Tata Iron & Steel Co. Ltd. v. The State of Bihar (1) where the nature of the excise duty was discussed.
At page 1369 the observations of Gwyer C. J. in Boddu Paidanna case (2) and of the Privy Council in
Governor-General in Council v. Province of Madras (3) were quoted with approval. It may be noted
that in the Tata Iron & Steel Co. case (1) the tax was a retrospective tax and was imposed at a time
when in the Sales Tax Act no provision was made for passing on the Sales Tax to the purchaser. In
the Union of India v. Madan Gopal Kabra (4) it was pointed out that Parliament was not precluded
from exercising the power of imposing a retrospective tax and therefore it was competent to make a
law imposing a tax on the income of any year prior to the commencement of the Constitution. As
was pointed out in that case under Arts. 245 and 346 of the Constitution read with the relevant entry
in List I of Schedule VII Parliament is empowered to make laws with regard to taxes and no
limitation or restriction is imposed in regard to retrospective legislation. See Sargood Bros. v. The
Commonwealth (1) where retrospective laws about the levying of Customs were held valid. See also
Welch v. Henry (2) On the ground of retrospectivity alone therefore the tax is not unconstitutional.
In view of what has been said above the cases decided in Canada or Australia cannot have any
application.
It was next contended that a retrospective tax purporting to be a duty on goods when the goods had
been disposed of would be a tax not under item 84, List I of the Seventh Schedule but one under
item 60 of List II, i.e., tax on profession, trade, calling and employment-the submission being that
the word "trade" would include manufacture. This contention was sought to be supported by theChhotabhai Jethabhai Patel And Co vs The Union Of India And Anther on 11 December, 1961

observations of Lords Davey in Commissioner of Taxation v. Kirk (3):-
"The word `trade' no doubt primarily means traffic by way of sale or exchange or
commercial dealing, but may have a larger meaning so as to include manufactures."
In National Association of Local Government Officers v. Bolton Corporation (4) Lord Wrights in
interpreting the word "trade" in s. 11 of the Industrial Courts Act, 1919, said:-
"Sect. 11 of the Act of 1919 shows that `trade' used as including `industry' because it
refers to a trade dispute in the industry of agriculture."
But this letter case has no application because there the word "trade" was interpreted in relation to a
section of a particular Act and trade in that context has quite a different meaning. In Skinner v. Jack
Breach Limited (5), Lord Hewart, C. J. in interpreting the word "trade" in Trade Boards Act held
that the word "trade" indicates a process of buying and selling but it was by no means an exhaustive
definition. It might also mean a calling or industry or class of skilled labour.
The duty of Excise in item 84 should be given the widest construction unless for some reason it is
cut down either by the terms of that item itself or by other Parts of the Constitution. The legislative
history of the duty of Excise shows the nature of the tax. The word "trade" in item 60 of List II has
reference to the carrying on of an activity in the nature of buying and selling and may in a different
context mean a calling or an industry. Therefore reading the two items together it is obvious that
item 84 deals with taxes on goods manufactured or produced and item 60 deals with the carrying on
of trade i.e., an activity in the nature of buying and selling and the Act in its pith and substance
relates to duty on goods manufactured or produced and has no relationship with item 60 of List II.
Even assuming that the nature and tendency of the duty of Excise is, as contended by Mr. Pathak
that it can be passed on to the consumer, even than the complaint of the appellants that they have
been deprived of that opportunity is not well founded, because of s. 64-A of the Indian Sale of Goods
Act (3 of 1930), which was s. 10 in the Indian Tariff Act, 1934. It was originally taken from the
British Tariff Act, 1901, 1 Edw. VII Ch.
7. Section 64A of the Indian Sale of Goods Act is as follows :-
S. 64-A. "In the event of any duty of customs or excise on any goods being imposed,
increased, decreased or remitted after the making of any contract for the sale of such
goods without stipulation as to the payment of duty where duty was not chargeable at
the time of the making of the contract, or for the sale of such goods duty-paid where
duty was chargeable at that time,-
(a) if such imposition or increase so takes effect that the duty or increased duty, as
the case may be, or any part thereof, is paid, the seller may add so much to the
contract price as will be equivalent to the amount paid in respect of such duty or
increase of duty, and he shall be entitled to be paid and to sue for and recover suchChhotabhai Jethabhai Patel And Co vs The Union Of India And Anther on 11 December, 1961

addition; and
(b) if such decrease or remission so takes effect that the decreased duty only or no
duty, as the case may be, is paid, the buyer may deduct so much from the contract
price as will be equivalent to the decrease of duty or remitted duty, and he shall not
be liable to pay, or be sued for or in respect of, such deduction."
This section provides for the recovery by the seller of the amount of increase in duty from the
purchaser where the increase takes effect subsequent to the contract and for the right of the
purchaser to recover from the seller the duty in cases where there is a similar decrease and this right
exists both before the delivery is given, taken and price received or paid as the case may be :
Narayanan Chettiar v. Kidar Sahib(1). Counsel for the appellants attempted to counter this
submission by relying upon a judgment of the Privy Council in Prbhudas v. Ganidada (2). In that
case the Government duty had not been reduced but the Buyer claimed that it had constructively
been decreased because the tariff valuation had been reduced and so constructively it must be
reckoned that there was a decrease in the duty on the goods sold. This contention was negatived by
the Privy Council and it was held that a change of duty means a change in the rate of duty, and not a
change of tariff value. Thus assuming that the contention of the appellants is correct as to the nature
of the excise duty it cannot be said that in the present case the appellants were deprived of the
opportunity of recovering the additional duty from the purchaser and therefore the duty lost its
character of being excise duty and was transformed into a different tax. This argument of the
appellants is therefore without substance and must be overruled.
The constitutionality of the tax and retrospective imposition of enhanced duty on tobacco was
further challenged on the ground of violation of the fundamental rights of the appellants under Art.
19(1)(f) of the Constitution which it was submitted is not saved by cl. (5) of that article because it is
not a reasonable restriction in the interest of the general public. The grounds of attack may be stated
in this way :
(1) that the nature of an excise duty is such that normally it is passed on to the
purchaser by the manufacturer or the producer and it has that tendency and quality;
(2) as the impugned duty was enhanced at a time when the appellants had cleared
their goods after paying the then prevailing duty, it was not possible for them to
realize the excise duty from any purchaser and (3) at the time of the clearance of the
goods the appellants had paid all the taxes under the then existing law and the new
liability rendered them liable to pay an illegal exaction or in the alternative to suffer
the consequences of non-payment which are of a drastic nature. On this basis it was
submitted that the imposition was an unreasonable restriction on the fundamental
rights of the appellants guaranteed under Art. 19(1) (f).
At this stage an examination of the extent of the State's power of taxation will be helpful. This power
is one of the three governmental powers of the State; the other two being police power and power of
eminent domain.Chhotabhai Jethabhai Patel And Co vs The Union Of India And Anther on 11 December, 1961

The power of taxation is the legal capacity of government to impose charges upon persons or their
property to raise revenue for governmental purposes. A tax is neither a penalty imposed on the
taxpayer nor a liability which he assumes by contract. It is but a way of apportioning the cost of
government among those who in some measure are privileged to enjoy its benefits and must bear its
burdens. Welch v. Henry (1), but the constitutionality of a tax does not depend upon a showing of
benefits ; protection and taxation are not correlative terms. Willis Constitutional, Law, p. 224 : Tax
is levied against the person and not against property. Property only serves as a basis for computing
the measure of each person's liability. Weaver on Constitutional Law, p. 513 :
"The power of taxation is one so unlimited in force and so searching in extent, that
the courts scarcely venture to declare that it is subject to any restrictions whatever,
except such as rest in the discretion of the authority which exercises it. It reaches to
every trade or occupation to every object of industry, use, or enjoyment; to every
species of possession; and it imposes a burden which, in the case of failure to
discharge it, may be followed by seizure and sale or confiscation of property. No
attribute of sovereignty is more pervading and at no point does the power of the
government affect more constantly and intimately all the relations of life than
through the exactions made under it."
(Cooley's Constitutional Limitations, Vol. 2, 8th Ed.p. 987.) Chief Justice Marshall said in M'Culloch
v. Maryland (2) :-
"The power of taxing the people and their property is essential to the very existence of
government, and may be legitimately exercised on the objects to which it is applicable
to the utmost extent to which the government may choose to carry it. The only
security against the abuse of this power is found in the structure of the government
itself." (See Willough by on the Constitution of the United States, Vol. 2 at p. 666).
As the exigencies of the government cannot be limited, no limits can be prescribed to
the exercise of the right of taxation. Every individual must bear a portion of public
burden and that portion is determined by the legislature. According to the American
Supreme Court the power of taxation is very wide and uncontrolled. In M'Culloch v.
Maryland(1) Chief Justice Marshall said :-
"....................it is unfit for the judicial department to inquire what degree of taxation
is the legitimate use, and what degree may amount to the abuse of the power."
See also Graves v. Schmidlapp(2) (per Chief Justice Stone).
In Pacific Insurance Co. v. Soule(3) the Court said:-
"Congress may prescribe the basis fix the rate, and require payment as it may deem
proper within the limits of the constitution it is supreme in its action. No power of
supervision or control is lodged in either of the other departments of theChhotabhai Jethabhai Patel And Co vs The Union Of India And Anther on 11 December, 1961

government."
Again in Veazie Bank v. Fenno (4), it was said :-
"It is insisted........that the tax in this case is excessive and so excessive as to indicate a
purpose on the part of the congress to destroy the franchise of the bank, and is,
therefore beyond the constitutional power of congress..............The first answer to this
is that the judicial cannot prescribe to the legislative department of the Government
limitations upon the exercise of its acknowledged powers. The power to tax may be
exercised oppressively upon persons, but the responsibility of the legislature is not to
the Courts but to the people by whom its members are elected."
In Patton v. Brady(1), the Court observed:-
"It is no part of the function of a Court to enquire into the reasonableness of the
exercise of the power of taxation either as respects the amount or the property on
which it is imposed."
In Welch v. Henry(2), at p. 94 it was observed :-
"The equitable distribution of the costs of government through the medium of an
income tax is a delicate and difficult task. In its performance experience has shown
the importance of reasonable opportunity for the legislative body, in the revision of
tax laws, to distribute increased costs of government among its tax payers in the light
of present need for revenue and with knowledge of the sources and amounts of the
various classes of taxable income during the taxable period preceding revision.
Without that opportunity accommodation of the legislative purposes to the need may
be seriously obstructed if not defeated."
Thus according to American view (1) the power to tax is an attribute of sovereignty; (2) tax is an
rateable contribution of each individual in a State towards the amount of revenue which is essential
for the existence and operation of a public governing body; (3) it being essential for the very
existence of an organised State, it may be exercised on objects to the utmost extent to which the
legislature may choose to carry it and (4) the needs of the revenue are only known to the legislature
and the court cannot enquire into the necessity of imposing a tax or the objects on which the
imposition should be made or the extent of the imposition. In the very nature of things the courts
are unable to go into the propriety, extent or economics of a particular tax or the policy underlying
it, which must depend upon a multitude of circumstances, which can only be known to the
government or the legislature.
As the appellants have relied on certain American decisions where certain taxing laws operating
retrospectively were tested on the touchstone of "due process of law" clause it becomes necessary to
examine the extent of that doctrine. "The taxing power of Federal Government," says Prof. Willis
(Constitutional Law, p. 378), "is limited by the procedural requirements of the due process clause.Chhotabhai Jethabhai Patel And Co vs The Union Of India And Anther on 11 December, 1961

Notice and hearing, though not a judicial tribunal, are required where the tax is based on the value
of the property. Jurisdiction, also, is a requirement for all forms of taxation, though the rules as to
jurisdiction vary with the kind of tax levied." According to Willoughby, Constitution of the United
States, Vol. III, p. 1875, the due process of law obliges the exercise of the taxing power to conform to
the following rules :-
1. That the tax shall be for a public purpose.
2. That it shall operate uniformly upon those subject to it.
3. That either the person or the property taxed shall be within the jurisdiction of the
government levying the tax.
4. That in the assessment and collection of the tax certain guarantees against
injustice to individuals, especially in the case of specific as distinguished from ad
valorem taxes, by way of notice and opportunity for a hearing shall be provided.
These principles of taxation are not peculiar to America but are accepted in all countries which have
parliamentary democracies and govern the Indian taxation system also.
In some American decisions retroactive tax laws were held to be inconsistent with due process :
Nichols v. Coolidge(1); Helvering v. Helwholz(2) Blodgett v. Holden (3). But the decision in those
cases rested on the ground that the tax could not reasonably be anticipated by the taxpayer at the
time of the voluntary act which the statute later made the taxable event e.g., the gift by the
descendent of the whole or a part of his interest in property. As was explained in Welch v. Henry(4)
at p. 93 :
"Since, in each of these cases, the donor might freely have chosen to give or not to
give the taxation, after the choice was made of a gift which he might will have
refrained from making had he anticipated the tax, was thought to be so arbitrary and
oppressive as to be a denial of due process. But there are other forms of taxation
whose retroactive, imposition cannot be said to be similarly offensive, because their
incidence is not on the voluntary act of the taxpayer. And even a retroactive gift tax
has been held valid where the donor was forewarned by the statute books of the
possibility of such a levy, Milliken v. United States, 75 L. Ed.
809.............."
In that case the retroactive operation of a tax on dividends was upheld and the objection on the
ground of inconvenience in being called upon, after the customary time for levy and payment of the
tax had passed, to bear a governmental burden of which he had no warning and which he did not
anticipate was held to be unsustainable. The contention that the retroactive application of the
Revenue Acts is a denial of the due process guaranteed by the Constitution has not been accepted in
America as an invariable rule. Welsh v. Henry(1) and the other cases there cited.Chhotabhai Jethabhai Patel And Co vs The Union Of India And Anther on 11 December, 1961

The doctrine of due process of law has received various interpretations in America which have not
always been consistent. Sometimes it has favoured personal liberty and sometimes social control
sometimes personal liberty as a matter of substance. Sometimes it has protected personal liberty by
extending due process to matters of substance and sometimes it has protected social control by
broadening the scope of police power or the power of taxation or the power of eminent domain.
Willis' Constitutional Law, p. 659. Brandeis J., in Untermyer v. Anderson(2) dealing with the
presumption of validity of a taxing statute observed :
"The presumption should be particularly strong where as here the objection to an act
arises not from a specific limitation or prohibition on congressional power but only
out of the `vague contours of the 5th Amendment prohibiting the depriving any
person of liberty or property without due process of law'. Holmes J., in Adkins v.
Children's Hospital, 76 L. Ed. 785, 800."
It was because of the varying meanings and concepts which have from time to time been attached to
"due process of law" that the framers of the Indian Constitution did not adopt it in the Constitution;
on the other hand they tried to give more defined boundaries to the area of fundamental rights in
Arts. 19 and 31 which deal with rights of property and in Arts. 19, 20, 21 and 22 which relate to
protection of personal liberty and this Court rejected it in A. K. Gopalan's case (1) and in the State of
West Bengal v. Subodh Gopal Bose (2).
The constitutionality of the duty of excise was challenged in the present case on the ground of
violation of Art. 19 (1) (f) of the Constitution. he argument is that a taxing law under Art. 265 is as
much a law as any other and therefore falls within the definition of law under Art. 13(3)(a), and if it
contravenes any of the fundamental rights under Part III, then to the extent of the contravention it
is void. Counsel relied on the second Kochuni case (3).
Article 19 guarantees personal freedoms subject to certain restrictions. Its relevant portion is as
follows:
Art. 19(1)(f). "All citizens shall have the right to acquire, hold and dispose of property;
Art. 19(5). "Nothing in sub-clauses
(d), (e) and (f) of the said clause shall affect the operation of any existing law in so far
as it imposes or prevent the State from making any law imposing reasonable
restrictions on the exercise of any of the rights conferred by the said sub-clauses
either in the interests of the general public or for the protection of the interests of any
Scheduled Tribe."
As has already been said the power to tax is the legal capacity of the State to raise from all those
subject to its authority a certain amount of revenue essential so the existence and operation of
government. A tax is not a penalty but a contribution of monies for governmental purposes by
persons who may be residents or non-residents citizens or non citizens, living persons or legalChhotabhai Jethabhai Patel And Co vs The Union Of India And Anther on 11 December, 1961

personae who are privileged to enjoy its benefits, but those are not co-relative. It implies an equality
of burden and regular distribution of expenses of government among the persons taxed. It is levied
by authority of law equitably, uniformly or in echelons on all persons subject to it.
The appellants alleged that they had sold their goods during the period when the Finance Bill was
before Parliament. Variations in the rates of duties are not unexpected, it being within the power of
Parliament to do so both prospectively and retrospectively. It is not suggested that such variations
are unknown in legislative practice or that the legislators were not entitled to amend a money bill as
introduced. If the appellants' contention is sustained then it will mean the deprivation of Parliament
of its right to choose the objects of taxation and therefore Parliament will only vary the rates of
duties proposed by the Executive or the time of their effectiveness at the peril of their being declared
invalid although they may be within its legislative competence and may in its opinion be necessary
for the carrying out of its policies or subserve the proper governance of the country.
In the Indian Constitution there is an exhaustive enunciation and distribution of legislative powers,
including powers as to taxation, between the State Legislatures and Parliament. Subjects of taxation
are distributed in the three Legislative Lists and areas of the respective fields of Parliament and
State Legislatures as to taxes are defined. In Parts XII and XIII limitations on legislative competence
of the various legislatures as to taxation are indicated and emphasis is placed on the preservation of
the economic unity of India. Article 265 is in Chapter XII and provides :-
"No tax shall be levied or collected except by authority of law," which means that all
taxation has to be under a law enacted by a legislature of competent jurisdiction and
subject to constitutional limitations. This Court in 1950 rejected the applicability of
the doctrine of "due process of law" to Indian constitutional problems:
A. K. Gopalan's case (1); The state of West Bengal v. Subodh Gopal Bose (2). In the
latter case it was also held that the Indian Constitution recognises no fundamental
right to immunity from taxation and that is why presumably no constitutional
protection is provided against the exercise of that power. Per Patanjali Sastri, C.J., p.
614. Das, J. (as he then was), held the power of taxation to be distinct from police
power (i.e. regulatory power of the State) and the power of Eminent Domain (i.e. the
power of the State of compulsory acquisition of property). Dealing with protection
against taxation he said in Subodh Gopal's case (2) at p. 652 :-
"Our Constitution makers evidently considered the protection against deprivation of
property in exercise of police power or of the power of eminent domain by the
executive to be of greater importance than the protection against deprivation of
property brought about by the exercise of the power of taxation by the executive, for
they found a place for the first mentioned protection in Art. 31 (1) and (2) set out in
Part III dealing with fundamental rights while they placed the last mentioned
protection in article 265 to be found in Part XII dealing with finance etc. So with
regard to all the three sovereign powers we have complete protection against the
executive organ of the State."Chhotabhai Jethabhai Patel And Co vs The Union Of India And Anther on 11 December, 1961

Again at p. 653 he observed :-
"Apart from this, what I ask is, our protection against the legislature in the matter of
deprivation of property by the exercise of the power of taxation ? None whatever. By
exercising its power of taxation by law the State may deprive us, citizen or non-citizen
of almost sixteen annas in the rupee of our income." (See also p. 654). In Ramjilal v.
Income Tax Officer (1) Das, J. (as he then was), observed at pp. 136-137 :-
"Reference has next to be made to article 265 which is in Part, XII, Chapter 1, dealing
with 'Finance'. That article provides that no tax shall be levied or collected except by
authority of law. There was no similar provision in the corresponding chapter of the
Government of India Act, 1935. If collection of taxes amounts to deprivation of
property within the meaning of article 31(1), then there was no point in making a
separate provision again as has been made in article 265. It, therefore, follows that
clause (1) of article 31 must be regarded as concerned with deprivation of property
otherwise than by the imposition or collection of tax, for otherwise article 265
becomes wholly redundant. In the United States of America the power of taxation is
regarded as distinct from the exercise of police power or eminent domain. Our
Constitution evidently has also treated taxation as distinct from compulsory
acquisition of property and has made independent provision giving protection
against taxation save by authority of law. When Dr. Tek Chand was asked if that was
not the correct position, he did not advance any cogent or convincing answer to
refute the conclusion put to him. In our opinion, the protection against imposition
and collection of taxes save by authority of law directly comes from article 265, and is
not secured by clause (1) of article 31. Article 265 not being in Chapter III of the
Constitution, its protection is not a fundamental right which can be enforced by an
application to this court under article 32. It is not our purpose to say that the right
secured by article 265 may not be enforced. It may certainly be enforced by adopting
proper proceedings. All that we wish to state is that this application in so far as it
purports to be founded on article 32 read with article 31(1) to this court is
misconceived and must fail."
A similar decision was given and similar language used by Mahajan, C.J., in Laxmanappa
Hanumantappa v. Union of India (1) :-
"It was held by this Court in Ramjilal v. Income Tax Officer, Mohindergarh (2), that
as there is a special provision in article 265 of the constitution that no tax shall be
levied or collected except by authority of law, clause (1) of article 31 must therefore be
regarded as concerned with deprivation of property otherwise than by the imposition
or collection of tax, and inasmuch as right conferred by Article 265 is not a right
conferred by Part III of the constitution, it could not be enforced under article 32."
Ramjilal's case (2) was quoted with approval in Bengal Immunity Co. Ltd. v. State of Bihar (3). Thus
early after the establishment of this Court opinion was expressed excluding the applicability ofChhotabhai Jethabhai Patel And Co vs The Union Of India And Anther on 11 December, 1961

fundamental rights in Part III to taxing Statutes. But it is important to notice that the Article which
was sought to be applied in those cases was Art. 31 (1) which deals with deprivation of property and
not Art. 19 which is regulatory of the rights of a citizen of personal liberty, property and avocation.
It was contended that the impugned tax illegally deprives the appellants of their property and was
therefore unconstitutional. In support reference was made to Suraj Mal Mohta & Co. v. A. V.
Viswanatha Sastri (1) (under Art.
14); Shree Meenakshi Mills Ltd. v. Sri A. V. Viswanatha Sastri (2) (under Art. 14); Purshottam
Govindji Halai v. Shree B. M. Desai, Additional Collector of Bombay (3) (under Arts. 14 and 21); M.
Ct. Muthiah v. The Commissioner of Income-tax, Madras (4) (under Art. 14); A. Thangal Kunju
Mudaliar v. M. Venkatchalam Potti (5) (under Art.
14); Bidi Supply Co. v. The Union of India (6) (under Art. 14); Panna Lal Binjraj v. Union of India (7)
(under Arts. 14 and 19(1)(g);) and Collector of Malabar v. Erimal Ebrahim Hajee (8). These are the
cases in which the validity of taxation laws was attacked under the Articles above mentioned.
In Panna Lal Binjraj v. The Union of India (7), the assault was not against the imposition or the vires
of the tax but against the vires of s. 5(7A) of the Indian Income-tax Act which empowers the
Commissioner of Income-tax to transfer any case from one Income-tax Officer subordinate to him to
another and empowers the Central Board of Revenue to transfer any case from one Income-tax
officer to another. This attack was based on the contravention of Arts. 14 and 19(1)(g). It was held
that the discretion vested in the authorities empowered to make the transfer is not discriminatory
and there was no interference with the right of the citizen to carry on his trade or calling. In collector
of Malabar v. Erimal Ebrahim Hajee (8) the attack against the recovery of income-tax under s. 46
(2) of the Income-tax Act was based on Arts. 14, 19 and 22. There again the question for decision
was not the imposition of the tax but the mode of recovery and at Page 976 this ground of attack was
rejected and reference was there made to the State of Punjab v. Ajaib Singh (1); Purshottam Govindji
Halai v. Shree B. M. Desai, Additional Collector of Bombay (2). Another case relied upon by the
appellant's counsel was Western India Theatres v. The Cantonment Board, Poona, (3) in which the
tax was imposed on cinema houses with larger seating capacity and the attack was on the ground of
Art. 14 but that was repelled. The appellant's counsel also referred to the Bengal Immunity Co. Ltd.
v. State of Bihar (4) where the vires of the sales tax imposed on inter- State transactions was
attacked. The High Court in the case had held that the petition under Art. 226 was misconceived
overlooking the fact that the contention raised was that in so far as the tax purported to act on
non-residents in respect of inter-State sales it was ultra vires of the Constitution. At. p. 619, Das, C.
J., observed :-
"It is also true that article 31 which protects citizens and non-citizens alike cannot be
availed of as it deals with deprivation of property otherwise than by way of levying or
collecting taxes as held by this Court in Ramjilal v. Income-tax Officer, Mohindergarh
[1951] S. C. R. 127, and that, therefore the Act does not constitute an infringement of
the fundamental right to property under that article. It is, however, clear from article
265 that no tax can be levied or collected except by authority of law which must meanChhotabhai Jethabhai Patel And Co vs The Union Of India And Anther on 11 December, 1961

a good and valid law. The contention of the appellant company is that the Act which
authorises the assessment, levying and collection of sales tax on inter- State trade
contravenes and constitutes an infringement of Art. 286 and is, therefore, ultra vires,
void and unenforceable. If, therefore, this contention be well founded, the remedy by
was of a writ must, on principle and authority, be available to the party aggrieved.
The next case relied upon by counsel for the appellants was Kailash Nath v. State of
U. P. (1) which was a case under the U. P. Sales Tax Act, the plea of the petitioners
was that the goods sought to be taxed had been exported overseas and therefore not
liable to sales tax. It was held that if a tax is levied without due legal authority on any
trade or business then it is open to the citizen to approach this Court under Art. 32,
since his right to carry on trade is violated or infringed by the imposition of the tax
and Art. 19 (1)(g) "comes into play". There again the taxation law itself was not
challenged on the ground of violation of any fundamental right which has reference
to property, but the imposition of the tax was assailed on the ground that it was not
imposeable on the transactions which had been entered into.
In support of the proposition that the taxation laws are assailable under the
provisions of Art. 19(1) State of Travancore-Cochin v. Shanmuga Vilas Cashew Nut
Factory (2) was relied upon. That was not a petition under Art. 32 or a matter under
Art. 19(1)(f) but one under Art. 286(1) and the question in dispute was whether the
transaction was in the course of inter-State trade. Himatlal Harilal Mehta v. The State
of Madhya Pradesh (3) was also a similar case. Article 19(1)(g) was applied because of
the unconstitutionality of the tax under Art. 286(1)(a). M/s. Ram Narain Sons Ltd. v.
Asst. Commissioner of Sales Tax (4) was also a case under Art. 286 of the
Constitution and was not a matter falling under Art. 19(1) of the Constitution.
In all these cases relied upon by counsel for the appellants the basis of attack was (1)
that the tax was not within the legislative competence of the legislature imposing the
tax and therefore the tax was being illegally recovered from the assessee or (2) an
objection was taken to the differential mode of imposition and collection and use of a
more stringent procedure i.e., illegal discrimination between persons similarly
situated e.g., under Taxation on Income (Investigation Commission) Act. The
imposion of an illegal tax not within the legislative competence of the legislature, a
colourable piece of legislature imposing a tax which is not a tax but is an imposition
of a confiscatory nature, a breach of principles of natural justice or imposing an
unimposeable tax have all been held to be violative of the right to carry on trade
under Art. 19(1)(g). But they do not support the proposition that the tax if otherwise
valid can be declared unconstitutional and can be subject to judicial review on the
ground of being excessive or being retrospective in operation or being imposed on
one article rather than another. These cases do not support the proposition which has
been contended for by the appellants that the very imposition of the tax is a
contravention of the right of the assessee to acquire, hold (or own) or dispose of
property or on the ground of contravention of Art. 31.Chhotabhai Jethabhai Patel And Co vs The Union Of India And Anther on 11 December, 1961

In the State of Bombay v. Bhanji Munji (1), it was also held that Art. 19(1)(f) read with
cl. (5) postulates the existence of the property which can be enjoyed and over which
rights can be exercised because otherwise the reasonable restriction contemplated by
cl.(5) cannot be brought into play. That was the uniform view held in this Court till
the majority judgment in Moopil Nair's case(2) which relied on the second Kochuni
case i.e., Kavalappara Kottarathil Kochunni etc. etc. v. The State of Madras (3). But
the latter was not a taxation case. It was held in that case (Kochuni case) that all laws
within Art. 13 are subject to Part III and that for a law to be valid it must satisfy two
tests (1) of being enacted by a legislature having legislative competence and (2) it
should not contravene any of the fundamental rights.
The above opinion is not in accord with the opinion of this court in A. K. Gopalan's case (1); Ram
Singh v. State of Delhi (2); State of Bombay v. Bhanji Munji (3); The Daily Express case (4) and The
Hamdard Dawakhana case (5).
The question of the applicability of Art. 19(1)(f) of the Constitution to taxing matters was considered
in K. T. Moopil Nair v. The State of Kerala (6). That was a case in which a tax at a flat rate was levied
on forest lands in the State of Kerala and this Court by majority held that the tax so imposed was
unconstitutional on the ground of infringement of Arts. 14 and 19(1)(f). The reasons given by the
learned Chief Justice were:
(a) In the procedure to be adopted for the levying of the tax, there was no provision
for a notice to be given to the assessee;
(b) There was no procedure for rectification of mistakes committed by the assessing
authorities;
(c) There is no procedure for obtaining the opinion of a superior Civil Court on a
question of law as is generally found in all taxing stautes
(d) No duty was cast upon the assessing authority to act judicially; and
(e) There was no right of appeal provided to the assessee.
The provisions of the Act were held in the majority judgment to be confiscatory. It was observed by
the learned Chief Justice at p. 559:-
"That the provisions aforesaid of the impugned Act are in their effect confiscatory is
clear on their face. Taking the extreme case, the facts of which we have stated in the
early part of this judgment, it can be illustrated that the provisions of the Act, without
proposing to acquire the privately owned forests in the State of Kerala after satisfying
the conditions laid down in Art. 31 of the Constitution, have the effect of eliminating
the private owners through the machinery of the Act."Chhotabhai Jethabhai Patel And Co vs The Union Of India And Anther on 11 December, 1961

Thus the impugned statute in that case was held to be violative of Art. 19(1)(f) because its procedural
part made no provision for giving a hearing to the assessees or for appeal nor was the Assessing
Authority required to act judicially and the imposition though called a tax was in effect confiscatory
and therefore a colourable piece of legislation. Sarkar, J., in his minority judgment remarked that
reasonableness of the rate was not assailed but what was assailed was the imposition of a flat rate
per acre without any reference to productivity.
Undoubtedly Moopil Nair's case (1) did hold that a law under Art. 265 was also a law within Art. 13
and if it contravened Art. 14, it was liable to be struck down and that such law must also pass the test
of the limitations prescribed in Part III of the Constitution but it did not lay down that all Articles in
Part III would be applicable to taxation laws nor did it decide contrary to Ramjilal's case (2) that Art.
31 (1) would apply to taxation law which is otherwise invalid. But it is difficult to hold that a
regulatory Article like Art. 19(1) was intended to limit the powers of the Legislature to impose taxes
and thus to discharge its duty in regard to country's financial needs and policies.
The contention of infringement of the appellants' right under Art. 19(1) (f) is unsound and must be
rejected and the reasons are these:-
Firstly: Clause (5) of Art. 19 allows the enacting of laws which impose "reasonable
restrictions"
in the interests of the general public. The use of the term "reasonable restrictions" is
indicative of regulation of the right to the personal rights mentioned in sub-cl. (f) of
the first clause. It must have relation to the existence of the thing to be regulated.
There can be no regulation of things not in existence. Therefore where an Act is
deprivatory as the imposition of a tax is it cannot fall within Art. (19)(1) but under the
specific Art. 31, which relates to deprivation of property. Imam, J., in The Collector of
Malabar v. E. Ebrahim Hajee (1) said at p. 976:- "If the property itself is taken
lawfully under Art. 31, the right to hold or dispose of it perishes with it and Art.
19(1)(f) cannot be invoked."
That was a case where the Income-tax Officer issued a certificate under s. 46 (2) of the Income-tax
Act and the Collector proceeded to recover under s. 48 of Madras Revenue Recovery Act.
Secondly: All taxation, as shown by its very nature and object, is in the interest of the general public
because it is a contribution for governmental expenditure from all persons who in some measure are
entitled to its benefit.
Thirdly: There is no means or measure for determining the reasonableness of the restrictions which
is an objective determination. The needs of the revenue cannot be known to the courts and cannot
be determined by them, and the sources of revenue are entirely within the knowledge of the
legislature and it is for that department of the State to determine how the burden will be distributed
and why, because that department is the policy making body and is familiar with the economics and
the resources of the country and its needs. It is for that department in its discretion to selectChhotabhai Jethabhai Patel And Co vs The Union Of India And Anther on 11 December, 1961

anything for taxation or to exclude it. Cooley's Constitutional Limitations, Vol. II, p. 986 (note).
Fourthly: The power to tax is an attribute of sovereignty and it is an accepted principle that the
exercise of that power is not subject to judicial control because no Constitutional Government can
exist without the power to raise money for its needs and the only security against abuse is in the
structure of the Government. That power carries with it the power to determine when and how the
tax shall be levied. S. Ananthakrishnan v. The State of Madras (1), M'Culloch v. The State of
Maryland (2). There is no indication that the Indian Constitution has rejected or modified the
American concept of the sovereignty of the State in regard to the power of taxation.
Fifthly: Article 19 (1) declares the right of a citizen and cl. (5) prescribes its limits. If a taxation
statute is within Art. 19(1)(f) it must be capable of being upheld as a reasonable restriction on the
holding of property etc. On the submission of the appellants all taxes will be restrictions. If they are
restrictions then their reasonableness will be justiciable depending upon the appreciation of
established facts. How are the courts to judge ? All the necessary data for determining
reasonableness can never be before a court which in the very nature of things is available only to the
legislature. Can the court say that a particular tax is excessive or unreasonable or can the court say
which particular source should be taxed and which particular income group should bear the burden
of taxation or what the policy of the State as to taxation should be. It would seem therefore that the
reasonableness of tax laws is not justiciable and therefore they cannot fall within clause (5) of Art.
19. Article 19(1)(f) and cl. 5 are part of one scheme and the former is incapable of operating where
the latter is inoperative. If considerations of Art. 19(5) are foreign to taxing laws Art. 19(1)(f) can
have no application to them.
Sixthly: Applicability of Art. 19(1)(f) to taxation laws will mean that laws which are otherwise valid
will be inapplicable to citizens but will be applicable to non-citizens. At any rate such law will
operate differentially between one set of taxpayers and another i.e., between citizens and
non-citizens. This will violate the very principles of due process relied upon by the appellants.
Seventhly: In American due process which has a variable concept has not been applied to
retrospective operation of tax laws except to tax on voluntary gifts of property and that also was
doubted in Welch v. Henry (1).
Eighthly: Retroactive duty of excise will be a valid imposition in the case of persons who have not
sold their tobacco between the period of the introduction of the bill and the enactment of the
Finance Act but will be invalid in the case of persons placed as the appellants.
Ninthly: The acceptance of the appellants' argument would mean that they can recover any excess
duty paid, excess because of subsequent decrease, but would not be liable to pay any similar increase
in duty in spite of s. 64-A of the Indian Sale of Goods Act under which variations in the rates of
duties become operative on contracts of sale and purchase.
Tenthly: It has been held that Art. 31 is inapplicable to deprivation by taxation. Ramjilal's case (2);
Lakshmanppa Hanumantappa v. The Union of India (3); and taxation laws are expressly excludedChhotabhai Jethabhai Patel And Co vs The Union Of India And Anther on 11 December, 1961

from the operation of Art. 31(2) by cl. 5(b)(i) of that Article. If the appellants' contention is correct
then deprivation although not protected under Art. 31 will be subject to regulatory control under
Art. 19(1)(f).
Eleventhly: To put it in the words of the American Supreme Court in Odgen v. Saunders(1) "It is but
a decent respect due to the wisdom the integrity and the patriotism of the legislative body, by which
law is passed to presume in favour of its validity, until its violation of the Constitution is proved
beyond all reasonable doubt".
Twelfthly: The challenge to the legality of the tax in dispute is not based and is unsustainable on the
ground of specific limitation or prohibition on Parliamentary power but has been raised on the
ground of the infringement of an article containing the principles of the State's power of control. The
cases dealing with legislative incapacity are inapplicable to the latter ground of assault. Cases such
as Mohammad Yasin v. The Town Area Committee, Jalalabad(2) (a case of a licence fee which is not
a tax), The State of Bombay v. United Motors India Ltd.(3)(a case of inter-State trade) and Bengal
Immunity Co. case (4) (which was also a case of inter-State trade and some of the provision of the
impugned Act there were held to be unreasonable restriction on the right to carry on trade) and Ch.
Tika Ramji's case (5) (a case dealing with the imposition of the restriction on the right to purchase
except through a particular society) were not cases in which the imposition of a tax was challenged
on the ground of infringement of Art. 19(1)(f).
I, therefore, agree that appeals be dismissed with costs. One hearing fee.
Appeal dismissed.Chhotabhai Jethabhai Patel And Co vs The Union Of India And Anther on 11 December, 1961

