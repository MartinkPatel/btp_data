Bhuwalka Steel Indus. Ltd vs Bombay Iron & Steel Labour Bd. &
Anr on 17 December, 2009
Author: V.S. Sirpurkar
Bench: V.S. Sirpurkar, Tarun Chatterjee
                                            1
              IN THE SUPREME COURT OF INDIA
               CIVIL APPELLATE JURISDICTION
             CIVIL APPEAL NO. 8452         OF 2009
            (Arising out of SLP (C) No. 1982 of 2007)
Bhuwalka Steel Indus. Ltd.                         .... Appellant
                               Versus
Bombay Iron & Steel Labour
Bd. & Anr.                                         .... Respondents
                                WITH
             CIVIL APPEAL NO. 8453         OF 2009
            (Arising out of SLP (C) No. 3624 of 2007)
Century Textiles & Industries Ltd.                 .... Appellant
                               Versus
Grocery Markets & Ors.                             .... Respondents
                                WITH
                 SLP (C).... CC No. 4065 of 2007
Steel Re-Rollers Association
of Maharashtra                                     .... Appellant
                               Versus
The Bombay Iron & Steel
Labour Board                                       .... Respondent
                              2Bhuwalka Steel Indus. Ltd vs Bombay Iron & Steel Labour Bd. & Anr on 17 December, 2009

                              WITH
                SLP (C).... CC No. 4046 of 2007
Kamgar Utkarsha Sabha                             .... Appellant
                            Versus
Bhuwalka Steel Industries
Ltd. & Ors.                                       .... Respondents
                              WITH
          CIVIL APPEAL NOS. 8454-8455        OF 2009
       (Arising out of SLP (C) Nos. 13462-13463 of 2007)
Raymond Limited                                   .... Appellant
                            Versus
Cloth Market and Shops
Board & Ors.                                      .... Respondents
                              WITH
             CIVIL APPEAL NO. 8457         OF 2009
           (Arising out of SLP (C) No. 20206 of 2007)
Kalyan Ambernath Manufacturing
Association & Ors.                                .... Appellants
                            Versus
The State of Maharashtra & Ors.                   .... Respondents
                                   3
                                   WITH
                CIVIL APPEAL NO. 8458 OF 2009
              (Arising out of SLP (C) No. 9600 of 2008)
Valiant Glass Works Pvt. Ltd.                          .... Appellant
                                 Versus
State of Maharashtra & Anr.                            .... RespondentsBhuwalka Steel Indus. Ltd vs Bombay Iron & Steel Labour Bd. & Anr on 17 December, 2009

                           JUDGMENT
V.S. SIRPURKAR, J.
1. This judgment will dispose of SLP (Civil) No. 1982 of 2007, SLP (Civil) No. 3624 of 2007, SLP
(Civil).... CC No. 4065 of 2007, SLP (Civil).... CC No. 4046 of 2007, SLP (Civil) Nos. 13462-13463 of
2007, SLP (Civil) No. 20206 of 2007, and SLP (Civil) No. 9600 of 2008.
2. Leave granted in SLP (Civil) No. 1982 of 2007, SLP (Civil) No. 3624 of 2007, SLP (Civil) Nos.
13462-13463 of 2007, SLP (Civil) No. 20206 of 2007, and SLP (Civil) No. 9600 of 2008
3. Two concurrent judgments of the Full Bench of the Bombay High Court, one written by Hon'ble
J.N. Patel and Hon'ble Roshan Dalvi, JJ. and a separate but concurrent judgment authored by
Hon'ble Deshmukh, J. have fallen for consideration. The reference to Full Bench was occasioned on
account of the two Learned Judges of the Bombay High Court, principally not agreeing with another
Division Bench Judgment reported in the case of Century Textiles & Industries Ltd. Vs. State of
Maharashtra [2000 II CLR 279] in its interpretation of the term "unprotected worker"
provided by Section 2(11) of the Maharashtra Mathadi, Hamal and other Manual
Workers (Regulation of Employment and Welfare) Act, 1969 (hereinafter referred to
as `Mathadi Act') and term "worker" provided by Section 2(12) of the Mathadi Act.
The referring Bench was of the opinion that the interpretation given to those two
terms in the decision in Century Textiles & Industries Ltd. Vs. State of Maharashtra
(cited supra) was in conflict with the statutory provisions enacted by the Legislature
in the said Mathadi Act. The question referred to the Full Bench was as under:-
"In view of the statutory definition of the expression "unprotected worker" in Section
2(11) of the Maharashtra Mathadi, Hamal and other Manual Workers (Regulation of
Employment and Welfare) Act, 1969 is the interpretation placed by the Division
Bench in Century Textiles & Industries Ltd. Vs. State of Maharashtra, 2000 II CLR
279 on the aforesaid expression that it is only casually engaged workers who come
within the purview of the Act, correct and proper?"
In the two aforementioned judgments of the Bombay High Court, the Learned Judges, writing the
majority judgment, recorded as under:-
"For the aforesaid reasons, we find that the interpretation placed by the Division
Bench in Century Textile and Industries Ltd. & Ors. Vs. State of Maharashtra & Ors.,
2000 II CLR 270 on the definition of the words "unprotected worker" and "worker"
for the purpose of applicability to Mathadi Act, 1969 that it is only the casual
workmen who come within the purview of the Act, is not correct and proper and it is
erroneous which deserves to be ignored and is overruled."Bhuwalka Steel Indus. Ltd vs Bombay Iron & Steel Labour Bd. & Anr on 17 December, 2009

The Learned Single Judge (Hon'ble Deshmukh, J.) gave his final verdict in the following words:-
"To conclude, therefore, to my mind it is clear that within the meaning of Section
2(11) of the Act "unprotected worker"
means every manual worker who is engaged or to be engaged in any scheduled employment,
irrespective of whether he is protected by other labour legislations or not and "unprotected workers"
within the meaning of the Act are definitely not only those manual workers who are casually
engaged."
4. The above two judgments are challenged basically on the contention that the judgment in the case
of Century Textiles & Industries Ltd. Vs. State of Maharashtra (cited supra) is essentially a correct
judgment, while the view taken by the Full Bench and the interpretation put forth by the same of the
Sections 2(11) and 2(12) of the Mathadi Act, is erroneous inasmuch as the impugned judgments have
ignored to take into account the context in which these provisions have been enacted and they also
ignored the intention of the Legislature, which is reflected from the Preamble and the other
provisions of this Act.
5. Lengthy arguments were advanced before us. While arguments on the side of appellants were led
by Shri J.P. Cama, Learned Senior Counsel, the arguments on behalf of respondents were led by Shri
K.K. Singhvi and Ms. Indira Jaising, Learned Senior Counsel.
6. Before taking up the issue, the short history of the legislation is a must.
7. A Bill was introduced in the Maharashtra Legislature, being Bill No. XCIX of 1968 for regulating
the employment of unprotected manual workers employed in certain employments in the State of
Maharashtra to make provision for their adequate supply and proper and full utilization in such
employments and for matters connected therewith. This Bill was first introduced in the Winter
Sessions of Maharasthra Legislature at Nagpur. It was then referred to the Joint Committee for its
report. The basic idea behind bringing this legislation, as it is reflected in Statement of Objects and
Reasons, was that persons engaged in occupations like mathadi, hamals, fishermen, salt pan
workers, casual labour, jatha workers and those engaged in similar manual work elsewhere, were
not receiving adequate protection and benefits within the ambit of existing labour legislation.
Therefore, with a view to studying the conditions of the work of the persons engaged in these
occupations, the Government had appointed a Committee on 15.7.1965 to examine whether relief
could be given to these workers within the ambit of the existing labour legislation and make
recommendation as to how such relief could be given. The Statement of Objects and Reasons
mentions that report was made by the Committee to the Government on 17.11.1967. In that report, it
was mentioned that the persons engaged in vocations like mathadi, hamals, casual workers
employed in docks, lokhandi jatha workers, salt pan workers and other manual workers mostly work
outside fixed premises in the open and are mostly engaged on piece-rate system in a number of
cases. They are not employed directly, but are either engaged through Mukadum or Toliwalas or
gangs as and when there is work and they also work for different employers on one and the same
day. The volume of work is not always constant. In view of the peculiar nature of work, its variety,Bhuwalka Steel Indus. Ltd vs Bombay Iron & Steel Labour Bd. & Anr on 17 December, 2009

the precarious means of employment and the system of payment and the particular vulnerability to
exploitation of this class of labour, the Committee had come to the conclusion that the application of
the various labour laws to such workers was impracticable and regulation of their working and other
conditions by introducing amendments to the existing labour laws was not possible. Therefore, the
Committee recommended that the working and the employment conditions of such unprotected
workers should be regulated by a special enactment.
8. The Statement of Objects and Reasons further mentions that after holding series of meetings with
the representatives of the interests affected by the proposed legislation and after considering all
these suggestions and examining the recommendations of the Committee, Government had decided
to bring the Bill which seeks to regulate the employment of mathadis, hamals and other manual
workers employed in certain employments, to make better provision for their terms and conditions
of employment, to provide for their welfare, for health and safety measures, where such
employments require those measures, to make provision for ensuring an adequate supply to, and
full and proper utilization of such workers in such employments, to prevent avoidable
unemployment and for such purposes to provide for the establishment of Boards in respect of these
employments and (where necessary) in the different areas of the State and to provide for purposes
connected with the matters aforesaid. Ultimately, the Act came on the legal anvil vide Act No. XXX
of 1969 after it received assent of the Vice President, acting on behalf of the President on 5.6.1969. It
was extended to the whole State of Maharashtra. It was clarified in Section 1 that it applies to the
employments specified in the Schedule and that it shall come into force on such date as the State
Government may, by notification in the Official Gazette, appoint and different dates may be
appointed for different areas, and for different provisions of the Act. The Act was amended from
time to time by Maharashtra Act Nos. 27 of 1972, 40 of 1974, 27 of 1977, 62 of 1981, 28 of 1987 and
27 of 1990. To begin with, it came into force in Thane District in various areas. (Emphasis supplied)
9. It will be better to see a few provisions of the Act. Section 2, which is the definition clause, defines
"Board" in sub-Section (1), to mean a Board established under Section 6. Some other sub-Sections of
Section 2 runs as under:-
2(2) "contractor", in relation to an unprotected worker, means a person who
undertakes to execute any work for an establishment by engaging such workers on
hire or otherwise, or who supplies such worker either in groups, gangs (tollis), or as
individuals; and includes a sub- contractor, an agent, a mukadum or a tolliwala;
2(3) "employer", in relation to any unprotected worker engaged by or through
contractor, means the principal employer and in relation to any other unprotected
worker, the person who has ultimate control over the affairs of the establishment,
and includes any other person to whom the affairs of such establishment are
entrusted, whether such person is called an agent, manager or is called by any other
name prevailing in the scheduled employment;
2(4) "establishment" means any place or premises, including the precincts thereof, in
which or in any part of which any scheduled employment is being or is ordinarilyBhuwalka Steel Indus. Ltd vs Bombay Iron & Steel Labour Bd. & Anr on 17 December, 2009

carried on;
2(7) "principal employer" means an employer who engages unprotected workers by
or through a contractor in any scheduled employment;
2(11) "unprotected worker" means a manual worker who is engaged or to be engaged
in any scheduled employment;
2(12) "worker" means a person who is engaged or to be engaged directly or through
any agency, whether for wages or not, to do manual work in any scheduled
employment, and includes any person not employed by any employer or a contractor,
but working with the permission of, or under agreement with the employer or
contractor; but does not include the members of an employer's family;
2(13) "wages" means all remunerations expressed in terms of money or capable of
being so expressed which would, if the terms of contract of employment, express or
implied were, fulfilled, be payable to an unprotected worker in respect of work done
in any scheduled employment, but does not include-
(i) the value of any house accommodation, supply of light, water, medical attendance;
or any other amenity or any service excluded from the computation of wages by
general or special order of the State Government;
                (ii)    any contribution paid by the employer to any
                        pension fund or provident fund or under any
                        scheme of social insurance and the interest which
                        may have accrued thereon;
                (iii)   any travelling allowance or the value of any
                        travelling concession;
                (iv)    any sum paid to the worker to defray special
                        expenses entailed on him by the nature of his
                        employment; or
                (v)     any gratuity payable on discharge."
Some other Sections of the Act, which were referred to by the Learned Senior Counsel
during the arguments are as under:-
3(1) For the purpose of ensuring an adequate supply and full and proper utilization of
unprotected workers in scheduled employments, and generally for making better
provision for the terms and condition of employment of such workers, the State
Government may by means of a scheme provide for the registration of employers andBhuwalka Steel Indus. Ltd vs Bombay Iron & Steel Labour Bd. & Anr on 17 December, 2009

unprotected workers in any scheduled employment or employments and provide for
the terms and conditions of work of registered unprotected workers and make
provision for the general welfare in such employments.
3(2) In particular, a scheme may provide for all or any of the following matters that is
to say:-
       (a)-(c)         x      x     x      x      x     x
       (d)       for regulating the employment of registered
                 unprotected workers, and the terms and
conditions of such employment, including rates of wages, hours of work, maternity
benefit, overtime payment, leave with wages, provision for gratuity and conditions as
to weekly and other holidays and pay in respect thereof;
(e) for securing that, in respect of periods during which employment or full
employment is not available to registered unprotected workers though they are
available for work, such unprotected workers will, subject to the conditions of the
scheme, receive a minimum wage;
(f) for prohibiting, restricting or otherwise controlling the employment of
unprotected workers to whom the scheme does not apply, and the employment of
unprotected workers by employers to whom the scheme does not apply;
(g) for the welfare of registered unprotected workers covered by the scheme insofar
as satisfactory provision therefor, does not exist, apart from the scheme;
(h) for health and safety measures in place where the registered unprotected workers
are engaged, insofar as satisfactory provision therefor, is required but does not exist,
apart from the scheme;
5. If any question arises whether any scheme applies to any class of unprotected workers or
employers, the matter shall be referred to the State Government and the decision of the State
Government on the question, which shall be taken after consulting the Advisory Committee
constituted under Section 14, shall be final. 7(1) The Board shall be responsible for administering a
scheme, and shall exercise such powers and perform such functions as may be conferred on it by the
scheme.
7(2) The Board may take such measures as it may deem fit for administering the scheme.
7(3) The Board shall submit to the State Government, as soon as may be, after the 1st of April every
year, and not later than the 31st day of October, an annual report on the working of the scheme
during the preceding year ending on the 31st day of March of that year. Every report so received
shall be laid as soon as may be after it is received before each House of the State Legislature, if it isBhuwalka Steel Indus. Ltd vs Bombay Iron & Steel Labour Bd. & Anr on 17 December, 2009

in session, or in the session immediately following the date of receipt of the report. 7(4) In exercise
of the powers and discharge of its functions, the Board shall be bound by such directions, as the
State Government may, for reason to be stated in writing, give to it from time to time.
15(1) The Board may appoint such persons as it thinks fit to be Inspectors possessing the prescribed
qualifications for the purpose of this Act or of any scheme and may define the limits of their
jurisdiction.
15(2) Subject to any rules made by the State Government in this behalf, an Inspector may-
(a) enter and search at all reasonable hours, with such assistants as he thinks fit, any premises or
place, where unprotected workers are employed, or work is given out to unprotected workers in any
scheduled employment, for the purpose of examining any register, record of wages or notices
required to be kept or exhibited under any scheme, and require the production thereof, for
inspection;
(b) examine any person whom he finds in any such premises or place and who, he has reasonable
cause to believe, is an unprotected worker employed therein or an unprotected worker to whom
work is given out therein;
(c) require any person giving any work to an unprotected worker or to a group of unprotected
workers to give any information, which is in his power to give, in respect of the names and addresses
of the persons to whom the work is given, and in respect of payments made, or to be made, for the
said work;
(d) seize or take copies of such registers, records of wages or notices or portions thereof, as he may
consider relevant, in respect of an offence under this Act or scheme, which he has reason to believe
has been committed by an employer; and
(e) exercise such other powers as may be prescribed:
Provided that, no one shall be required under the provisions of this section to answer
any question or make any statement tending to incriminate himself.
15(3) Every Inspector appointed under this section shall be deemed to be public
servant within the meaning of section 21 of the Indian Penal Code.
21. Nothing contained in this Act shall affect any rights or privileges, which any
registered unprotected worker employed in any scheduled employment is entitled to,
on the date on which this Act comes into force, under any other law, contract, custom
or usage applicable to such worker, if such rights or privileges are more favourable to
him than those to which he would be entitled under this Act and the scheme:Bhuwalka Steel Indus. Ltd vs Bombay Iron & Steel Labour Bd. & Anr on 17 December, 2009

Provided that such worker will not be entitled to receive any corresponding benefit
under the provisions of this Act and the scheme.
22. The State Government may, after consulting the Advisory Committee, by
notification in the Official Gazette, and subject to such conditions and for such period
as may be specified in the notification, exempt from the operation of all or any of the
provisions of this Act or any scheme made thereunder, all or any class or classes of
unprotected workers employed in any scheduled employment, or in any
establishment or part of any establishment of any scheduled employment, if in the
opinion of the State Government all such unprotected workers or such class or classes
of workers, are in the enjoyment of benefits which are on the whole not less
favourable to such unprotected workers than the benefits provided by or under this
Act or any scheme framed thereunder:
Provided that before any such notification is issued, the State Government shall
publish a notice of its intention to issue such notification, and invite objections and
suggestions in respect thereto, and no such notification shall be issued until the
objections and suggestions have been considered and a period of one month has
expired from the date of first publication of the notice in the Official Gazette:
Provided further that the State Government may, by notification in the Official
Gazette, at any time, for reasons to be specified, rescind the aforesaid notification.
10. It is in the backdrop of these provisions generally that it has to be seen as to
whether the interpretation put forward by the Full Bench in two separate but
concurrent judgments, is correct or not. Though the question referred to the Full
Bench was restricted to the correctness of the interpretation of the term `unprotected
worker' in Section 2(11) of the Mathadi Act as given in the case of Century Textiles &
Industries Ltd.
Vs. State of Maharashtra (cited supra), in our opinion, the scope of the question has to be properly
understood. In that case, it was held by the Division Bench of that Court that the workers who were
working in the factory of the petitioner could not be termed as `unprotected workers'. It was held
specifically that the Mathadi Act did not deal with the employees engaged on monthly basis, as such
workers were protected under the Shops and Establishments Act and other enactments. It was
further held that it was only the casually engaged workmen, who would come within the purview of
the Mathadi Act. The High Court further said that where the material produced on record clearly
show that the workmen are protected workmen, more particularly, with reference to the Agreement
under Section 2(p) of the Industrial Disputes Act, 1947, the Act in question would not apply.
Therefore, the referred question was whether it was only casually engaged workers, who came
within the purview of the Act. The majority judgment gave a straight answer to this question that the
meaning of the term `unprotected worker' was only the casual workman, was not correct, while the
Learned Single Judge did not stop at that and gave a broader answer interpreting Section 2(11) of
the Mathadi Act and held that every manual worker engaged or to be engaged in any scheduledBhuwalka Steel Indus. Ltd vs Bombay Iron & Steel Labour Bd. & Anr on 17 December, 2009

employment, irrespective of whether he is protected by other labour legislations or not, would be
termed as `unprotected worker', and further that the definition was not restricted to those manual
workers who are casually engaged. Though the judgment of the Learned Single Judge was criticized
by Shri J.P. Cama, Learned Senior Counsel for the appellants that it went beyond the reference
made, we feel that the Learned Single Judge has not travelled beyond the reference. The reference
has to be read as requiring the correct interpretation of Section 2(11) of the Mathadi Act and the
term `unprotected worker' and, therefore, in our opinion, it would have to be explained as to what is
the true scope and meaning of the term `unprotected worker' as envisaged by Section 2(11) of the
Mathadi Act. In that, the debate cannot be restricted to the narrower question as to whether the
term means only the casually engaged workers. In our opinion, the true impact of the term
`unprotected worker' has to be considered and it will have also to be pointed out as to who can be
said to be `unprotected worker'. The objection in that behalf raised by the appellant to the Full
Bench judgment is not correct. When we see the judgment in Kay Kay Embroideries Pvt. Ltd. Vs.
Cloth Market and Shops Board, Mumbai & Ors. [2006 III LLJ 824 Bom], it is clear that the Court
had posed two questions:-
(i) Whether the expression `unprotected worker' means a worker not protected by
labour legislation or whether the expression means a manual worker who is engaged
or to be engaged in any scheduled employment as defined in Section 2(11) of the
Mathadi Act?
(ii) Whether a Mathadi worker, who has been engaged directly by an employer, would
fall outside the purview of the Mathadi Act?
The Division Bench in this case did not agree with the judgment in the case of Century Textiles &
Industries Ltd. Vs. State of Maharashtra (cited supra). The referring judgment clearly goes on to
show that it did not agree with the narrower judgment in the case of Century Textiles & Industries
Ltd. Vs. State of Maharashtra (cited supra), but it cannot be forgotten that the two questions framed
by it clearly show that the consideration could not be restricted to the narrower question as to
whether the view taken in the case of Century Textiles & Industries Ltd. Vs. State of Maharashtra
(cited supra) was correct or not, instead the question which arose for consideration on account of
the two Benches not agreeing was as to what was the true scope of the definition of the expression
`unprotected worker' in Section 2(11) of the Mathadi Act. Considering the clear language and the
questions considered in the referring judgment by Hon'ble F.K. Rebello and Dr. D.Y. Chandrachud,
JJ., we feel that the Learned Single Judge did not exceed the question referred in considering the
full scope of the Section 2(11) of the Mathadi Act and the term `unprotected worker'. We will,
therefore, proceed on the basis that the Full Bench had to decide the true scope of the term
`unprotected worker' as defined in Section 2(11) of the Mathadi Act and to point out as to who could
be covered under that definition.
11. Basically, the contentions raised by the parties are as follows:
Legal Submissions on behalf of the Appellants A. Section 2(11) of the Mathadi Act
cannot be interpreted independently of Section 2(12) of the Mathadi Act, which is theBhuwalka Steel Indus. Ltd vs Bombay Iron & Steel Labour Bd. & Anr on 17 December, 2009

definition of `worker' and conjoined reading of these two Sections in the light of
other provisions of the Act would clearly bring out that those workers who are
regularly employed and who have the protection of other labour legislations, cannot
be termed as `unprotected workers'. For that purpose, the two Sections cannot be
interpreted merely on the basis of plain meaning of the language of the Sections,
instead the interpretation has to be done taking into consideration the context of the
Mathadi Act, the Statement of Objects and Reasons and legislative history of the Act.
Shri J.P. Cama, Learned Senior Counsel for the appellants further contended that the
Full Bench had erred in interpreting the said definition in isolation and not in the
context of the Act. According to the Learned Senior Counsel, the Mathadi Act was
intended to cover only itinerant workers doing manual works for short time periods.
B. The Learned Senior Counsel further argued that if the literal interpretation is
accepted, as has been done by the Full Bench, number of other provisions in the Act
like Section 15(2)(b) would be rendered otiose and redundant, so also other
anomalies would creep in. The Learned Senior Counsel also urged that the Full Bench
had erred in ignoring the doctrine of stare decisis, inasmuch as the provision had
received consistent interpretation for a considerable period and hence, that
interpretation was liable to be respected, particularly because the rights and
obligations of the parties covered by this Act had remained settled for a long period of
time. Therefore, even if the earlier interpretation might not be strictly correct or
where two views were possible, the settled principle of law could not be unsettled.
The Learned Senior Counsel contended that the law was settled by two judgments of
the Bombay High Court by Hon'ble Rege, J. in C. Jairam Pvt. Ltd. Vs. State of
Maharashtra [Misc. Petition No. 150 of 1973] pronounced on 19.4.1974 and S.B. More
& Ors. Vs. State of Maharashtra & Ors. [Misc. Petition No. 414 of 1973] pronounced
on 24.4.1974 and four other Division Bench Judgments in Lallubhai Kevaldas & Anr.
Vs. The State of Maharashtra & Ors. [Writ Petition No. 119 of 1979] pronounced on
16.1.1980, Irkar Sahu's & Anr. Vs. Bombay Port Trust [1994 I CLR 187], Century
Textiles & Industries Ltd. Vs. State of Maharashtra (cited supra) including this Court
judgment in Maharashtra Rajya Mathadi Transport and Central Kamgar Union Vs.
State of Maharashtra & Ors. [1995 Supp. 3 SCC 28].
C. The Learned Senior Counsel further relied on the Rule of Contemporanea
Expositio Est Optima Et Fortissima In Lege.
According to the Learned Senior Counsel, the Full Bench should have considered how
the authorities themselves construed and understood the law. In that behalf, the
ruling in Godawat Pan Masala Products I.P. Ltd. & Anr. Vs. Union of India & Ors.
[2004(7) SCC 68] was relied upon heavily.
Reference was made by the Learned Senior Counsel to few letters to show as to how
the authorities themselves understood the term `unprotected worker'. In this behalf
the judgment in Irkar Sahu's & Anr. Vs. Bombay Port Trust [1994 I CLR 187] wasBhuwalka Steel Indus. Ltd vs Bombay Iron & Steel Labour Bd. & Anr on 17 December, 2009

heavily relied.
D. Reference was also made to Article 254 of the Constitution of India and it was
suggested that in the matters falling in the Concurrent List, the Central Legislation
will supersede the State Legislation if both cover the same field. It was suggested that
there was no need for direct conflict between the two enactments and the repugnancy
arises even if obedience to both laws is possible. Further, the Learned Senior Counsel
suggested that specific contradictions between the two Statutes is not the only
criteria. It is enough if Parliament had evinced the intention to cover the whole field.
It was also suggested that the Presidential assent given to this Act was irrelevant to
those Central Acts, which were enacted after the assent, for example, the Contract
Labour (Regulation and Abolition) Act, 1970. Therefore, it was pointed out that State
Act cannot survive if the Central Act covers the same category of workers. It was tried
to be pointed out that there was nothing on record to indicate as to what extent the
Presidential assent was obtained. It was, therefore, contended that Central labour
enactments, which firstly create and regulate the employer-employee relationship
and those which confer the benefits to such employees, would exclude the operation
of Mathadi Act and as a result, those workers who enjoy the benefits under the
Central labour legislation and whose rights are regulated by the Central legislation
would not be covered by the present State legislation. Reliance was also placed on
various reports like 1963 Committee Report, the Report of the Lokhandi Jatha
Kamgar Enquiry Committee to harp upon the real object of the enactment and it was
suggested that the definition read in the light of these reports would clearly bring out
the interpretation suggested by the appellant. Various Sections were referred like
Section 4(a), Sections 15, 21 and 22 to show that the interpretation given by the Full
Bench would lead to absurdity.
12. As against this, Shri K.K. Singhvi and Smt. Indira Jaising, Learned Senior Counsel assisted by
Shri Vimal Chandra S. Dave, Learned Counsel appearing on behalf of the respondents raised various
contentions. Legal Submissions on behalf of the respondents A. Learned Senior Counsel for the
respondents contended that in the absence of any ambiguity, no harm can be caused to the plain
language of the Statute. According to all the Learned Counsel, impugned judgments of the Full
Bench of the Bombay High Court were in accordance with the plain language of the Sections 2(11)
and 2(12) of the Mathadi Act. Numbers of authorities for this proposition were relied upon. Reliance
was also placed on Sections 21 and 22 of the Mathadi Act and Clauses 4(c), 11(3), 16(3), 16(4), 16(5),
33, 35(6) and 36 of the Scheme framed under the Mathadi Act. In short, it was contended that under
Section 21, the workmen could retain the privileges and benefits under any Act, Award or Contract,
if such privileges were better than the ones offered by the Act and in that sense, even if the manual
worker was protected under the various labour laws, he could still be governed by the Mathadi Act.
Same argument was in respect of Section 22 of the Mathadi Act, providing that a manual worker,
who is in receipt of better benefits from his employer either on the date of commencement of this
Act or at any time thereafter, he could seek exemption from all or any of the provisions of the
Mathadi Act. Reference was made to Clauses 4(c), 11(3), 16(3), 16(4), 16(5), 33, 35(6) and 36 of the
Scheme framed under the Mathadi Act.Bhuwalka Steel Indus. Ltd vs Bombay Iron & Steel Labour Bd. & Anr on 17 December, 2009

B. It was further contended that the argument on behalf of the appellant that the intention of the
Legislature should be ascertained with reference to the history of legislation, the reports of the
Committee, notes on the Clauses of the Bill and debates in Assembly, was erroneous as the plain
meaning of the Section was not susceptible to any other meaning. It was, however, further
contended that the language of the Section was clear and unequivocal and even if such extraneous
aids of the interpretation were to be relied upon, no other interpretation could be obtained. It was
pointed out that though in the Bill, as originally introduced, the words "is not adequately protected
by legislation" were to be found and though the note on the Clauses also mentioned about such
non-protection by the welfare Legislature, the amended Bill omitted those words, so also the
necessary amendments were made in Item 5 of the Schedule attached to the Bill. Therefore, the
Learned Counsel argued that there was a clear, deliberate and cautious intendment to include all
manual workers engaged in the scheduled employment, whether protected by any labour law or not,
in the definition of "protected worker". The Learned Counsel further argued that there could be no
practical difficulties in such workers being registered with the Board and the fear expressed by the
Learned Senior Counsel on behalf of the appellant was not realistic. It was pointed out that if the
service conditions of a workman were better before the commencement of the Mathadi Act, he
would still continue to be benefited by those better conditions and as such, there was no anomaly
created by giving the plain meaning to the Section depending upon its language. The argument that
giving the plain meaning would deprive the workers of the protection under Bombay Industrial
Relations Act, 1946 of raising industrial disputes before the Labour Court and the Industrial Court,
was also termed as incorrect argument, as firstly, there was no vested right for selecting the forum
and secondly, the Legislature had the competence to enact special laws for a class or section of
workmen for improving their conditions of service and such special law would always prevail over
any general law covering the same field. The cases relied upon by the appellants were distinguished
on various grounds. This was especially done in the case of Krantikari Suraksha Rakshak
Sangathana Vs. Bharat Sanchar Nigam Limited & Ors. [2008(10) SC 166]. It was also pointed out
that the scheme of Security Guards was different from the scheme of the Act, as in the scheme of the
Act, a directly recruited Security Guard was specifically excluded from the provisions of the Security
Guards Act. C. As regards the doctrine of stare decisis relied upon by the appellants, it was pointed
out that in both the judgments of Hon'ble Rege, J. in C. Jairam Pvt. Ltd. Vs. State of Maharashtra
(cited supra) and S.B. More & Ors. Vs. State of Maharashtra & Ors. (cited supra), the Learned Judge
has called upon the constitutionality of the certain provisions of the Cotton Merchants Unprotected
Workers (Regulation of Employment and Welfare) Scheme, 1972 and in that sense, the question of
interpretation of Section 2(11) did not fall for consideration in those cases. Similarly in the matter of
Lallubhai Kevaldas & Anr. Vs. The State of Maharashtra & Ors. (cited supra) decided by a Division
Bench of the Bombay High Court on 16.1.1980, the Division Bench was not called upon to decide the
interpretation of Section 2(11). Therefore, it could not be said that that case depended upon the
interpretation of Section 2(11). Even as regards the decision in Century Textiles & Industries Ltd. Vs.
State of Maharashtra (cited supra), the question was limited to the extent whether a manual worker
engaged by the petitioner therein through a contractor was an unprotected worker although he was
covered by various labour acts. It was pointed out that the referring judgment itself differed with the
view expressed in the decision in Century Textiles & Industries Ltd. Vs. State of Maharashtra (cited
supra). It was, therefore, pointed out that it could not be said that there was a breach of doctrine of
stare decisis in giving a contrary meaning of Section 2(11) as it was pointed out that the doctrine ofBhuwalka Steel Indus. Ltd vs Bombay Iron & Steel Labour Bd. & Anr on 17 December, 2009

stare decisis was not an absolute doctrine and that it was for this Court to lay down the correct law
under Article 141 of the Constitution of India.
D. As regards the Rule of Contemporanea Expositio Est Optima Et Fortissima In Lege, the argument
was that there was no evidence that the law makers, or as the case may be, the Government
understood the scheme in the particular manner. Even otherwise, it was pointed out that such
interpretation, if it was palpably correct, could not be accepted. To the same effect, was the
argument by Smt. Indira Jaising, Learned Senior Counsel appearing on behalf of the respondents.
13. It is on the basis of these conflicting arguments that we have to proceed to decide the true
interpretations of the Section. In the referring judgment by the Division Bench of the Bombay High
Court, consisting of Hon'ble F.K. Rebello and Dr. D.Y. Chandrachud, JJ. In the case of Kay Kay
Embroideries Pvt. Ltd. Vs. Cloth Market and Shops Board, Mumbai & Ors. (cited supra), the
Division Bench made reference to paras 31 and 41 of the judgments. The Division Bench accepted
the contentions raised on behalf of the Board that the Division Bench in the decision in Century
Textiles & Industries Ltd. Vs. State of Maharashtra (cited supra) adopted a meaning, which could be
attributed in common parlance to the expression "unprotected worker", totally ignoring the plain
meaning of the expression as defined in Section 2(11) of the Mathadi Act. Relying on Section 2(12) of
the Mathadi Act, wherein the expression "worker" was defined, the Bench further held that when the
Legislature uses the `means and includes' formula, the intention of the legislature is to provide an
exhaustive definition, and in such a case, the inclusive part of the definition brings within the fold of
the expression objects or activities which would ordinarily not fall within the purview of the
definition. Carrying the logic further, the Bench held that by the inclusive part, the definition
included a person who is not employed by any employer or a contractor, but who works with the
permission or under agreement with the employer or contractor. On the same logic, the Bench went
on to hold that:-
"Once the Act defines the expression `unprotected worker', the definition in the Act
provides a statutory dictionary which the Court is under the bounden duty to apply in
construing the provisions of the Act. It is not open to the Court to adopt a meaning of
the expression `unprotected worker' at variance with what has been legislated by the
competent legislature."
It was pointed out further that if the legislature intended that the benefit of Act could not be
available to workers who were otherwise governed by some other industrial legislation, it was open
to the legislature to legislate accordingly and it was, therefore, that the Division Bench did not agree
with the decision in Century Textiles & Industries Ltd. Vs. State of Maharashtra (cited supra). It was
also pointed out by the Division Bench that the notes on Clauses appended to the Bill did not
override express statutory provisions. A reference was then made to Section 22 of the Mathadi Act
and the same logic was used as was relied and argued by the Learned Counsel for the respondents
before us.
14. On these conflicting claims, we have to interpret Section 2(11) of the Mathadi Act and also the
scope of the definition in the Section. We have already quoted the provisions of Sections 2(11) andBhuwalka Steel Indus. Ltd vs Bombay Iron & Steel Labour Bd. & Anr on 17 December, 2009

2(12) of the Mathadi Act in the earlier part of the judgment. There can be no dispute that the term
"worker" is used in the definition of "unprotected worker" in Section 2(11) of the Mathadi Act.
Therefore, while considering the Section 2(11), the scope of the term "worker", which is separately
defined by Section 2(12) of the Mathadi Act, would have to be taken into consideration. The
definition of the term "worker" is an inclusive definition. It includes a worker, who is engaged by the
employer directly or through any agency and it is not necessary that such worker gets the wages or
not. The term "wages" is also defined vide Section 2(13) of the Mathadi Act. Therefore, even if such
person does not earn the wages, as contemplated in Section 2(13), such person who is engaged to do
manual work in any scheduled employment, would be a worker. Further, even if such worker is not
employed in the strict sense of the term by an employer or a contractor, but is working with the
permission or under the agreement with the employer or contractor, even then such worker would
be a "worker" within the meaning of Section 2(12) of the Mathadi Act. The only exception is that
such worker should not be a member of employer's family. As per the plain meaning, when such
worker is engaged or is to be engaged in the scheduled employment, he becomes the unprotected
worker. It has been correctly held in the judgment of the Learned Single Judge (Hon'ble Deshmukh,
J.) that these two definitions ("worker" and "unprotected worker") given in Sections 2(11) and 2(12)
of the Mathadi Act would have to be read together for realizing the scope of the Section 2(11) of the
Mathadi Act. Therefore, insofar as the language of Section 2(11) is concerned, it is plain,
unambiguous and clear. It means that every worker, who is doing manual work and is engaged or to
be engaged in any scheduled employment, would be covered by that definition and would become an
unprotected worker. The question is whether we should accept this plain language. The appellants
take strong exception to this approach.
15. Shri Cama, Learned Senior Counsel appearing on behalf of the appellants contended in no
uncertain terms that the reliance on the plain meaning of the Section, as it appears, would not only
be hazardous, but would also lead to absurdity. According to him, while interpreting Section 2(11) of
the Mathadi Act, it cannot be done bereft of the context of the legislation. Our attention was invited
to Statement of Objects and Reasons, as also the legislative history of the legislation. According to
the Learned Senior Counsel, the acceptance of such plain meaning would result in rendering some
other provisions of the Act, otiose. Further, such interpretation would also hit doctrine of stare
decisis, as the interpretation of this doctrine prior to the impugned Full Bench Judgment and more
particularly given in various judgments of the Bombay High Court including judgment in Century
Textiles & Industries Ltd. Vs. State of Maharashtra (cited supra) has remained intact for more than
25 years, which is a long period. The further contention is that such interpretation would also be
violative of the doctrine of Contemporanea Expositio Est Optima Et Fortissima In Lege, since the
relevant authorities have consistently understood the meaning of that definition in a particular way
and now, there would be no justification to disturb that understanding. It was also suggested by Shri
Cama that the provisions of State Act cannot survive if the Central Act covers the same category of
workers and in this case, such workers who were covered by the other Central Acts could not have
been brought under the cover of the definition in Section 2(11) of the Mathadi Act, it being a State
Act. The Learned Senior Counsel, therefore, suggested that those workers, who enjoy the benefits
under the Central labour legislation and whose rights were regulated by the Central legislations,
have to be held outside the definition in Section 2(11) of the Mathadi Act.Bhuwalka Steel Indus. Ltd vs Bombay Iron & Steel Labour Bd. & Anr on 17 December, 2009

16. The respondents, however, relied on the principle that where the language of the Statute is clear
and unequivocal, there would be no need to go to the extraneous aids of the interpretation and the
plain meaning of the language has to be accepted as the correct interpretation. In fact, according to
Shri Singhvi, Learned Senior Counsel appearing on behalf of the respondents, it was not necessary
to interpret the provision of Section 2(11) of the Mathadi Act, since the language of that Section was
extremely clear, which clearly expressed the deliberate and the cautious intention of the legislature
to include all manual workers engaged in scheduled employment, whether protected by any labour
law or not, in the definition of "unprotected worker". Shri Singhvi also dispelled the argument that
the number of other provisions in the Act would be rendered otiose by acceptance of the clear and
unequivocal meaning displayed by the language of Section 2(11) of the Mathadi Act.
17. As regards the argument on the principle of stare decisis, the Learned Senior Counsel pointed
out that there will be no question of allowing a totally wrong interpretation to remain on the
legislative scene, particularly in view of the clear cut meaning, which could be attached because of
the plain and unequivocal language of Section 2(11) of the Mathadi Act. At any rate, the Learned
Senior Counsel contended that the doctrine of stare decisis was not an absolute doctrine.
18. Even as regards the rule of Contemporanea Expositio Est Optima Et Fortissima In Lege, the
Learned Senior Counsel argued that there was no evidence that the law makers, or as the case may
be, the Government, understood the scheme in a particular manner.
19. We have already pointed out that the plain meaning of the language is almost a rule and it is only
by way of an exception that the external aids of interpretation can be used. In the case of Bhaiji Vs.
Sub-Divisional Officer, Thandla & Ors. [2003(1) SCC 692], this Court has reiterated that where the
language of the Statue is clear and unambiguous, the external aids for interpretation should be
avoided. In Cable Corporation of India Vs. Addl. Commissioner of Labour [2008 (7) SCC 680], this
Court observed in Para 16 that when the language is plain and unambiguous and admits of only one
meaning, no question of construction of a statute arises, for the Act speaks for itself. There can be no
dispute that the language of Section 2(11) of the Mathadi Act is not capable of any other meaning
since it is clear and unambiguous. Some debate went on about the use of the word "means", which is
to be found in the concerned Section. It was contended by Shri Singhvi, Learned Senior Counsel for
the respondents that when a definition of the word begins with "means", it is indicative of the fact
that the meaning of the word is restricted, that is to say, it would not mean anything else, but what
has been indicated in the definition itself. In support of this proposition, he relied on the decision in
Feroz N. Dotivala Vs. P.M. Wadhwani [2003(1) SCC 433]. The Learned Senior Counsel also pointed
out that in the decision in P. Kasilingam & Ors. Vs. P.S.G. College of Technology & Ors. [AIR 1995
SC 1395], it has been held by this Court that the use of the word "means" indicates that the
definition is a hard and fast definition and no other meaning can be assigned to the expression than
that is put down in the definition. We have already referred to the decision in Bhaiji Vs.
Sub-Divisional Officer, Thandla & Ors. (cited supra). All these three judgments indicate that, firstly,
where the language of the provision is plain and unambiguous, than that is the only avenue available
while interpreting the same. We may also say as we have already expressed that once the language of
the Section is absolutely clear, there is hardly any scope for interpretation. This position is then
further crystallized by the user of the word "means", which then positively rules aside any otherBhuwalka Steel Indus. Ltd vs Bombay Iron & Steel Labour Bd. & Anr on 17 December, 2009

meaning than the one which is dependent upon the plain and unambiguous language of the
provision. One more decision of this Court, which was heavily relied upon by the respondents was
Baldev Singh Bajwa Vs. Monish Saini [2005(12) SCC 778], wherein in para 21, it was observed:-
"The golden rule of construction is that when the words of the legislation are plain
and unambiguous, effect must be given to them. The basic principle on which this
rule is based is that since the words must have spoken as clearly to legislatures, as to
judges, it may be safely presumed that the legislature intended what the words
plainly say. The legislative intent of the enactment may be gathered from several
sources which are, from the statute itself, from the preamble to the statute, from the
Statement of Objects and Reasons, from the legislative debates, reports of
committees and commissions which preceded the legislation and finally from all
legitimate and admissible sources from where they may be allowed. Reference may
be had to legislative history and latest legislation also. But, the primary rule of
construction would be to ascertain the plain language used in the enactment which
advances the purpose and object of the legislation............"
(Emphasis supplied)
20. However, Shri Cama, Learned Senior Counsel for the appellants submitted that in this case,
unless the context is taken into account, it would lead to absurd and unintended result. The Learned
Senior Counsel urged that the definition cannot and should not be mechanically applied. He has
relied on the decision in Printers (Mysore) Ltd. & Anr. Vs. Asstt. Commercial Tax Officer & Ors.
[1994 (2) SCC 434]. About the principles to be borne in mind while interpreting a definition, the
Learned Senior Counsel has relied on the decision in K.V. Muthu Vs. Angamuthu Ammal [1997(2)
SCC 53], wherein in para 11, this Court has observed that the interpretation placed on a definition
should not only be repugnant to the context, but it should also be such as would aid the achievement
of the purpose, which is sought to be served by the Act. This Court further held that a construction
which would defeat or is likely to defeat the purpose of the Act, has to be ignored and not accepted.
The Learned Senior Counsel also relied on the decision in Gujarat Steel Tubes Ltd. & Ors. Vs.
Gujarat Steel Tubes Mazdoor Sabha & Ors. [1980(2) SCC 593] and contended that the statutory
construction, which fulfills the mandate of the statute, must find favour with the judges, except
where the words and the context rebel against such flexibility. This Court, in this case observed:-
"We would prefer to be liberal rather than lexical when reading the meaning of
industrial legislation which develops from day to day in the growing economy of
India."
Once it is held that the meaning of the Section is clear on the basis of the unambiguous language
used, it should ordinarily be end of the matter. However, Shri Cama and his other colleagues Shri
C.U. Singh, Shri Sudhir Talsania and Shri S.S. Naganand, Learned Senior Counsel and Shri Manish
Kumar, Shri Gopal Singh, Ms. Pragya Baghel, Shri Debmalya Banerjee, Shri Animesh Sinha, Smt.
Manik Karanjawala, Ms. Nandini Gore, Shri Raghvendra S. Srivatsav, Shri T.R. Venkat
Subramanium, Shri Abhijit P. Medh, Shri P.V. Dinesh, Ms. Sindhu T.P. and Shri P.S. Sudheer,Bhuwalka Steel Indus. Ltd vs Bombay Iron & Steel Labour Bd. & Anr on 17 December, 2009

Learned Counsel argued that the legislative history of the statute would militate against the
language and to accept the meaning from the plain language would be completely out of context.
Shri Cama and his colleagues also heavily relied upon the history, which led to the introduction of
the Bill, as also the Statement of Objects and Reasons for introducing the Bill in the legislature by
the then Hon'ble Labour Minister. We were also taken through the debates, as also the Statement of
Objects and Reasons presented to the State legislature on 19.12.1968 by the then Hon'ble Labour
Minister. Our attention was invited to the basic definition of the "unprotected worker", which was as
follows:-
"2(11) `Unprotected worker' has been defined to mean a manual worker, who but for
the provisions of this Act, is not adequately protected by legislation for welfare and
benefits of the labour force in the State."
21. Relying heavily on the Report of the "Mathadi Labour Enquiry Committee, Greater Bombay,
1963", Shri Cama, Learned Senior Counsel invited our attention to para 2 thereof, which refers to
"such labourers", who are deprived of regular wage-scales, permanency, earned leave, bonus,
provident fund, gratuity, medical benefits, compensation, pension etc. It was argued by Shri C.U.
Singh, Learned Senior Counsel appearing on behalf of the appellants that in Chapter 6 thereof,
under the heading "Employer and Employee relationship", there is expression "the real difficulty is
that there is no `employer' as such". It was also pointed out that the difficulty, which was felt was
that the employment of the worker was only through the contractor and technically, there was no
direct relationship of employer and employee, as between the Mills of Factories and the Mathadi
workers. Similar was the case with the merchants, traders and other concerns as they engage the
labour through Mukadam or Toliwala and such Mukadam or Toliwala engaged his men or the
workers with him and paid wages to them and, therefore, technically, there was no direct
relationship of the employer and employee, as between the merchants or concerns and the workers.
It was also argued that if the direct relationship was established, such benefits would flow to the
Mathadi workers. From this, the Learned Senior Counsel argued that where there is a direct
relationship in case of the monthly workers, there would be no question of applying this broad
definition to such workers. It was also pointed out that the Committee considered that there was a
positive reluctance to appoint these workers as the direct employees and only a few merchants
expressed their willingness to accept the workers as their direct employees, and there was also
reluctance on the part of the workers to be employed directly. This was obviously with a view to
argue that what was contemplated by the Committee was not for the direct workers and, therefore,
the directly appointed workers would be outside the definition of "unprotected worker". Shri Singh
also carried on his argument further relying on the para 13 under the head "Adjudication" and
pointed out the following observations:-
"13. The labour laws in force are not applicable to the Mathadi workers and thus they
are without any remedy at law. To obtain amelioration of the conditions of their work
and wages, they are inevitably led to organize `Morchas' or stage `Strikes'. To avoid
such exigencies as also to enable them to obtain the other benefits, it is necessary to
provide for them a remedy at law."Bhuwalka Steel Indus. Ltd vs Bombay Iron & Steel Labour Bd. & Anr on 17 December, 2009

22. Our attention was also invited to some portions of the Report of the "Lokhandi Jatha Kamgar
Enquiry Committee, December, 1965" and its working. We were also taken through para 13 of
Chapter IV thereof titled "Application of labour laws".
23. We were also taken through the Report of the "Committee for Unprotected Labour, 1967" and
more particularly, through Chapter II thereof titled "Conditions existing in the Avocations", as also
Chapter IV titled "Reasons, Conclusions and Recommendations and draft outline of the legislation".
The contents, which were heavily relied upon are:-
"The persons engaged in the avocations like hamals, mathadis, casual workers
employed in Docks, Lokhandi Jatha workers, Salt Pan workers mostly work outside
fixed premises in open space. Most of the persons are engaged on piece rate system.
In a number of cases they are not employed directly but are either engaged through
Mukadams or Tolliwalas as and when there is work. The persons in a number of
cases, work for different persons on one and the same day. In view of the peculiar
nature of work and the system of payment, the application of the various labour laws
to such workers has become difficult. The rickshaw pullers who are not self employed
are also pulling the rickshaw taken on hire. The question of regulation of the working
and other conditions of such persons, therefore, is not possible by introducing
amendments to the existing labour laws. The object can be achieved if a special
legislation is prepared for the purpose by incorporating beneficial provisions of the
important labour enactments applicable to similar workers employed in regular
establishments and factories."
From this, the argument was tried to be developed by Shri Cama and Shri Singh that the objective
was very clear and under the same what was contemplated was only the cases of those workers who
were not directly engaged and as such, the term "unprotected worker" should be interpreted to
exclude all the directly appointed workers employed in the factories, even if they are working in the
scheduled employments.
24. We were also taken through the Objects and Reasons and Preamble and a very strong argument
was advanced that if the definition is read in that light, there would be no question of accepting the
literal interpretation. In our opinion, in view of the clear and settled law of interpretation, it would
really not be necessary to go into these contentions, particularly, because the law is very clear that
where the language is clear and admits of no doubts, it is futile to look for the meaning of the
provision on the basis of these external aids. It is possible where the plain meaning rungs counter to
the objects or creates absurdity or doubts by attributing that plain language. In our considered
opinion, it is very difficult to find out any such absurdity or contradiction if the plain language of the
Section 2(11) is accepted and acted upon for the purposes of interpretation. It must, at this juncture,
be noted that inspite of Section 2(11), which included the words "but for the provisions of this Act is
not adequately protected by legislation for welfare and benefits of the labour force in the State",
these precise words were removed by the legislature and the definition was made limited as it has
been finally legislated upon. It is to be noted that when the Bill came to be passed and received the
assent of the Vice President on 5.6.1969 and was first published in Maharashtra GovernmentBhuwalka Steel Indus. Ltd vs Bombay Iron & Steel Labour Bd. & Anr on 17 December, 2009

Gazette Extraordinary Part IV on 13.6.2009, the aforementioned words were omitted. Therefore,
this would be a clear pointer to the legislative intent that the legislature being conscious of the fact
and being armed with all the Committee Reports and also being armed with the factual data,
deliberately avoided those words. What the appellants are asking was to read in that definition,
these precise words, which were consciously and deliberately omitted from the definition. That
would amount to supplying the casus omissus and we do not think that it is possible, particularly, in
this case. The law of supplying the casus omissus by the Courts is extremely clear and settled that
though this Court may supply the casus omissus, it would be in the rarest of the rare cases and thus
supplying of this casus omissus would be extremely necessary due to the inadvertent omission on
the part of the legislature. But, that is certainly not the case here. [See Decision in State of
Jharkhand & Anr. Vs. Govind Singh (2005 (10) SCC 437)]. Reliance was also placed on the decision
in Ramesh Mehta Vs. Sanwal Chand Singhvi & Ors. [2004 (5) SCC 409 (Paras 27 and 28)], wherein
it was held that the definition is not to be read in isolation and it must be read in the context of the
phrase which would define it. It should not be vague or ambiguous and the definition of the words
must be given a meaningful application; where the context makes the definition given in the
interpretation clause inapplicable, the same meaning cannot be assigned. We must point out here
that this ratio will not apply for the simple reason that the definition given in Section 2(11) of the
Mathadi Act is extremely clear and there is no vagueness or ambiguity about it. We have already
pointed out that even if it is read in the context, we cannot ignore the fact that the legislature had
deliberately deleted the words "but for the provisions of this Act is not adequately protected by
legislation for welfare and benefits of the labour force in the State". The other decision in U.P. State
Electricity Board Vs. Shiv Mohan Singh & Anr. [2004(8) SCC 402 (Para 11)] would be of no
consequence in the present controversy. The omission of the words as proposed earlier from the
final definition is a deliberate and conscious act on the part of the legislature, only with the objective
to provide protection to all the labourers or workers, who were the manual workers and were
engaged or to be engaged in any scheduled employment. Therefore, there was a specific act on the
part of the legislature to enlarge the scope of the definition and once we accept this, all the
arguments regarding the objects and reasons, the Committee Reports, the legislative history being
contrary to the expressed language, are relegated to the background and are liable to be ignored.
25. Shri Cama, Learned Senior Counsel for the appellants relied on decision in Maharashtra State
Road Transport Corporation Vs. State of Maharashtra & Ors. [2003(4) SCC 200], in which
observation in para 16 was relied upon, which is as follows:-
"16. ...........If certain provisions of law, construed in one way, would make them
consistent with the Constitution and another interpretation would render them
unconstitutional, the Court would lean in favour of the former construction."
The case is clearly not applicable, since there is no constitutional matter involved. We would
comment regarding Article 254 of the Constitution of India, in the later part of the judgment. To the
same effect is the reading in the decision in The State of M.P. & Ors. Vs. M/s. Chhotabhai Jethabhai
Patel and Co. & Anr. [1972 (1) SCC 209], relied upon by the Learned Senior Counsel. We do not see
any such problem about two interpretations. We have already stated that there may not be two
interpretations. Therefore, contention of the Learned Senior Counsel based upon this decision isBhuwalka Steel Indus. Ltd vs Bombay Iron & Steel Labour Bd. & Anr on 17 December, 2009

also incorrect. One more decision was relied upon by the Learned Senior Counsel in R.D. Goyal &
Anr. Vs. Reliance Industries Ltd. [2003 (1) SCC 81 (Paras 33 and 34)]. This decision is also of no
consequence, since the Paras relied upon in this decision deal with the words "Notes and Clauses"
while interpreting the provision. That is not the case here.
26. We were also taken through the Preamble of the Mathadi Act, which is as under:-
"An Act for regulating the employment of unprotected manual workers employed in
certain employments in the State of Maharashtra, to make provision for their
adequate supply and proper and full utilization in such employments, and for matters
connected therewith.
WHEREAS, it is expedient to regulate the employment of unprotected manual
workers, such as, Mathadi, Hamal etc., engaged in certain employments, to make
better provision for their terms and conditions of employment, to provide for their
welfare, and for health and safety measures where such employments require these
measures; to make provision for ensuring an adequate supply to, and full and proper
utilization of, such workers in such employments to protect avoidable
unemployment; for these and similar purposes, to provide for the establishment of
Boards in respect of these employments and (where necessary) in the different areas
of the State; and to provide for purposes connected with the matters aforesaid; It is
hereby enacted in the Twentieth Year of the Republic of India as follows:-................"
Great stress was led on the words "such as" and it was tried to be suggested that the Preamble carves
out a class of the unprotected manual workers. Further, it was stressed that the object of the law is
to provide for the welfare, health and safety measures, where such employments require those
measures. From this, it was suggested that it is only where the other legislations are unable to
provide for the welfare and the better conditions, then alone this Act (Mathadi Act) would be
brought into and, therefore, necessarily the unprotected workmen would be such workmen, who are
deprived of the better conditions of service and further, therefore, if the workers were adequately
protected, there would be no question of applying the provisions of the Mathadi Act to them and
they cannot be covered under Section 2(11) of the Mathadi Act. The argument is clearly incorrect for
the reason that the mention of "unprotected manual workers"
is clearly in the wider sense and even the Preamble of the Mathadi Act displays the
intentions of the State Government to make better provision for the unprotected
manual workers. Merely because some workmen are manual workers and not casual
workers, that by itself, would not make any different. It is to be noted that in the
Preamble, terminology of "casual workers" is not to be found. Therefore, even on this
basis, the definition cannot be restricted. The argument is, therefore, rejected.
27. Shri C.U. Singh, Learned Senior Counsel for the appellants referred to the Reports of the three
Committees in 1963, 1965 and 1967. We have already referred to those Reports and we find nothing
contradictory in those Reports in view of our finding on the plain language of the Section.Bhuwalka Steel Indus. Ltd vs Bombay Iron & Steel Labour Bd. & Anr on 17 December, 2009

28. We were also taken through the decision in Printers (Mysore) Ltd. & Anr. Vs. Asstt. Commercial
Tax Officer & Ors. (cited supra), more particularly, Para 18 therein providing the principles for
interpreting the definitions, as also the decision in Pandey & Co. Builders (P) Ltd. Vs. State of Bihar
& Anr. [2007(1) SCC 467]. We have examined this decision. Para 30 makes a reference to 3
decisions. They are Mukesh K. Tripathi Vs. Senior Divisional Manager, LIC [2004(8) SCC 387],
Ramesh Mehta Vs. Sanwal Chand Singhvi (cited supra) and State of Maharashtra Vs. Indian Medical
Association [2002 (1) SCC 589]. In the first mentioned decision, the word "include" was used, which
would make all the difference and thereby, it was held that the definition may deserve a broader
meaning and, therefore, it was necessary to keep in view the scheme of the object and purport of the
statute. That is not the case here. We have already referred to the second mentioned case of Ramesh
Mehta Vs. Sanwal Chand Singhvi (cited supra). Expressions in Para 27 cannot, however, be read in
isolation. Again, it is not that every definition has to be read in the context of the phrase, which
would define it. We have again pointed out that even the context does not require us to restrict the
meaning of Section 2(11). The third mentioned case of State of Maharashtra Vs. Indian Medical
Association (cited supra) is of no consequence, as the phraseology therein was entirely different. As
regards decision in Printers (Mysore) Ltd. & Anr. Vs. Asstt. Commercial Tax Officer & Ors. (cited
supra), we do not think that the case is helpful to the appellants. Therein, the controversy was about
the definition of "goods" in Section 8(3)(b) of the Central Sales Tax Act and the controversy was as
to whether the word "goods" could be read in a different manner. Such is not the controversy here.
29. We also find no absurdity, inconsistency or any contradiction with the other provisions of the
Act. Shri Singhvi, Learned Senior Counsel for the respondents alongwith his colleagues Ms. Indira
Jaising, Learned Senior Counsel, Ms. Lata Desai, Ms. Pallavi Divekar and Shri Vimal Chandra S.
Dave, Shri Nitin S. Tambwekar, Shri B.S. Sai, Shri K. Rajeev, Ms. Bharathi, Ms. Mehak G. Sethi, Shri
Naveen R. Nath, Shri Arun R. Pendekar, Shri Sanjay Kharde, Ms. Asha Gopalan, Shri Vishnu
Sharma, Shri Shrish Kumar Misra and Shri Rajesh Kumar, Learned Counsel invited our attention to
Section 21 of the Mathadi Act and pointed out that there was absolutely no inconsistency because
where a directly appointed worker was having better rights or privileges, then those rights or
privileges remains unaffected and in that case, such worker would have the choice for those more
favourable rights and privileges under other beneficial legislations, the only rider being that such
worker would not be entitled to receive any corresponding benefit under the provisions of the
Mathadi Act and the scheme. According to the Learned Senior Counsel, this provision was enough to
repel the arguments of the appellants that the directly employed workers were enjoying the better
benefits and they would be deprived of the same in case they are included in the wider definition
under Section 2(11) of the Mathadi Act.
30. We were also taken through Section 22 of the Mathadi Act, which provides for the exemptions.
The Section provides that the State Government may exempt from the operation of all or any of the
provisions of the Act or any scheme, all or any of the classes of unprotected workers employed in any
scheduled employment or the establishment or part of any establishment, if in the opinion of the
State Government, all such unprotected workers are in the enjoyment of benefits, which are, on the
whole, not less favourable to such unprotected workers than the benefits provided by or under the
Mathadi Act, of course, subject to certain conditions and after the consultation with Advisory
Committee. If this is the position, then there would be no question of accepting the argument that byBhuwalka Steel Indus. Ltd vs Bombay Iron & Steel Labour Bd. & Anr on 17 December, 2009

the acceptance of the plain meaning of the wider definition given out in Section 2(11) of the Mathadi
Act, there would be creations of contradictions. A Statement of Objects and Reasons for introducing
the Bill is of course an external aid, which should be of no consequence if the language is clear.
However, even if we read the Statement of Objects and Reasons, it does not further the cause of the
appellants. We have very carefully gone through the Statement of Objects and Reasons and find
nothing therein to support the contention raised herein. Shri Cama, Learned Senior Counsel for the
appellants, while relying on the Statement of Objects and Reasons, firstly urged that it was because
the workers in various employments were not receiving adequate protection and benefits within the
ambit of existing labour legislation that this Bill was introduced alongwith Statement of Objects &
Reasons. Our attention was also invited to read clause 2. From this, it was pointed out that the
adequacy of the protection was the main issue. Now, if inspite of this, the legislature went on to
delete those words, which we have already quoted, the intention of the legislature must be loud and
clear and we cannot persuade ourselves to hold that there is anything contradictory to the definition
in the Statement of Objects and Reasons. In our opinion, even if that was so, when the legislature
consciously deletes certain words, then there will be no question of relying and insisting upon those
words.
31. We were taken through some alleged inconsistencies, for example, Section 15 of the Mathadi Act.
It was expressed that Section 15(2)(b) would become redundant if we accept the interpretation put
forward by the respondents. Sub-Section (1) of Section 15 provides for the appointment of
Inspectors, possessing prescribed qualifications for the purposes of the Mathadi Act or of any
scheme. Sub-Section (2) of Section 15 and more particularly, clause (a) thereof defines the powers of
the Inspector. Clause
(b), on which great stress was led by Shri Cama runs as under:-
"15(2)(b) examine any person whom he finds in any such premises or place and who,
he has reasonable cause to believe, is an unprotected worker employed therein or an
unprotected worker to whom work is given out therein."
According to Shri Cama, when all the persons working in a scheduled industry, doing manual work,
become the unprotected workers, then there is no question of the Inspector examining any such
person, because everybody would be an unprotected worker. The argument is clearly wrong. What is
required is that every unprotected worker has to be registered with the Board. If the Inspector
suspects that any such worker, though an unprotected worker, is either not registered or does not
get the protection of the Board and is engaged by the employer, then he can examine such a person.
We do not think that the Section would become unworkable, as has been argued. The argument is,
therefore, clearly incorrect.
32. Shri S.S. Naganand, Learned Senior Counsel also referred to Sections 17G, 18, 19 and 20 of the
Mathadi Act. Section 17G provides that the provisions of Bombay Industrial Relations Act, 1946
would be applicable in case of trial of offences under this Act. Similarly, Section 18 provides that
provisions of Workmen's Compensation Act, 1923 shall mutatis mutandis apply to registered
unprotected workers and they shall be deemed to be workmen within the meaning of that Act.Bhuwalka Steel Indus. Ltd vs Bombay Iron & Steel Labour Bd. & Anr on 17 December, 2009

Section 19 makes the similar provision regarding the Payment of Wages Act, 1936 to the workers,
while Section 20 provides the application of Maternity Benefit Act, 1961. We do not see any
relevance of these Sections, particularly, to arrive at the correct meaning of Section 2(11) of the
Mathadi Act. In all these Sections, the words used are "registered unprotected workers". There is a
provision for creation of the Boards under Section 6 of the Mathadi Act and every unprotected
worker has to register himself with the Board. Therefore, the reliance on these provisions would be
no consequence. The terminology of "registered unprotected workers" in Sections 18, 19 and 20 of
the Mathadi Act was brought into force by Maharashtra Act No. 40 of 1974 and under that, these
words deemed always to have been substituted for the original terminology of "unprotected
workers". We do not, therefore, see any reason to take any different view in the light of these
Sections.
33. Shri Sudhir Talsania, Learned Senior Counsel arguing on behalf of the appellants also argued
about the nature of Sections 2(11) and 2(12) of the Mathadi Act. He contended that while Section
2(12) is a general provision, Section 2(11) is a specific provision. We have no quarrel with that. We
would only observe that so long as that language of Section 2(11) of the Mathadi Act is clear enough,
there will not be any question of cutting the scope of the term "unprotected workman". He further
argued that this interpretation would lead to absurd results, whereby Sections 2(11) and 2(12) would
be identical. We have already explained that such is not the possibility. This is true that the Sections
have to be read together. Section 2(12) specifies the worker, which in turn is used in Section 2(11)
further. Therefore, they would not be identical under any circumstances.
34. It was argued by Shri C.U. Singh, Learned Senior Counsel for the appellants that as per Sections
3(13) and 3(14) of the Bombay Industrial Relations Act, all the employees are covered and any
reduction from those employees has to be only after the notice of change is given. Our attention was
also invited to Section 44 of the Bombay Industrial Relations Act. We have no difficulty with the
provisions of the Bombay Industrial Relations Act, as that Act operates in different spheres
altogether. We do not think that there is any relevance of those provisions, particularly, while
interpreting the terms of the Mathadi Act and more particularly of Section 2(11) of the Mathadi Act.
All the Learned Counsel for the appellants expressed their apprehension about the working of
Section 3 of the Mathadi Act and posed a question as to who will decide as to whether an industry
has or has not adequate employees, whether it would be Board or employer or employee union. In
our view, such argument is clearly incorrect for the simple reason that such question does not come
within the scope of the Mathadi Act. Once a workman is engaged to do the manual work, he
automatically becomes an unprotected workman and would have to be registered with the Board. In
our opinion, such argument has to be rejected. Our attention was invited to the decision in
Chairman, Indore Vikas Pradhikaran Vs. Pure Industrial Coke & Chemicals Ltd. & Ors. [2007(8)
SCC 705], particularly, paras 79, 80 and 81 thereof. The term "at any time" in Section 50(1) of the
Madhya Pradesh Nagar Tatha Gram Nivesh Adhiniyam (No. 23 of 1973) had fallen for
consideration. Hon'ble Sinha, J. had held that the term will have to be interpreted in a particular
manner, otherwise it would lead to manifest injustice and absurdity, which is not contemplated by
the statute. We have absolutely no quarrel with the proposition, however, we have already held that
the interpretation that we propose to give, does not make any of the provision absurd and does not
lead to manifest the injustice or the absurdity.Bhuwalka Steel Indus. Ltd vs Bombay Iron & Steel Labour Bd. & Anr on 17 December, 2009

35. Similarly, reliance was placed by Shri C.U. Singh, Learned Senior Counsel for the appellants on
the decision in National Insurance Co. Ltd. Vs. Laxmi Narain Dhut [2007 (3) SCC 700]. The
provisions of Motor Vehicles Act, 1988 and more particularly, Sections 147, 145 (d) and 149 fell for
consideration therein. There also, the Court held that the golden rule of interpretation is that the
statutes are to be interpreted according to grammatical and ordinary sense of the word in
grammatical or literal meaning unmindful of consequence of such interpretation. It was only when
such grammatical and literal interpretation leads to unjust results which the legislature never
intended that the said rule has to give place to the "rule of legislative intent". We have already
pointed out that in this case, the golden rule of interpretation would not lead to any injustice.
Therefore, this ruling is more helpful to the respondents than the appellants. Another ruling, which
was relied upon was Bombay Dyeing & Mfg. Co. Ltd. Vs. Bombay Environmental Action Group &
Ors. [2006(3) SCC 434]. Reliance was placed on the observations made in para 176. Hon'ble Sinha,
J. therein had quoted paras 1392, 1477 and 1480 of Halsbury's Laws of England (4th Edn.), Vol.
44(1) (Reissue). Those paras are as under:-
"1392. Common-sense construction rule: It is a rule of the common law, which may
be referred to as the common- sense construction rule, that when considering, in
relation to the facts of the instant case, which of the opposing constructions of the
enactment would give effect to the legislative intention, the Court should presume
that the legislator intended common sense to be used in construing the enactment.
1477. Nature of presumption against absurdity: It is presumed that Parliament
intends that the Court, when considering, in relation to the facts of the instant case,
which of the opposing construction of an enactment corresponds to its legal meaning,
should find against a construction which produces an absurd result, since this is
unlikely to have been intended by Parliament. Here `absurd' means contrary to sense
and reason, so in this context the term `absurd' is used to include a result which is
unworkable or impracticable, inconvenient, anomalous or illogical, futile or pointless,
artificial or productive of a disproportionate counter-mischief.
1480. Presumption against anomalous or illogical result:
It is presumed that Parliament intends that the Court, when considering, in relation
to the facts of the instant case, which opposing constructions of an enactment
corresponds to its legal meaning, should find against a construction that creates an
anomaly or otherwise produces an irrational or illogical result. The presumption may
be applicable where on one construction a benefit is not available in like cases, or a
detriment is not imposed in like cases, or the decision would turn on an immaterial
distinction or an anomaly would be created in legal doctrine. Where each of the
constructions contended for involves some anomaly then, insofar as the Court uses
anomaly as a test, it has to balance the effect of each construction and determine
which anomaly is greater. It may be possible to avoid the anomaly by the exercise of a
discretion. It may be, however, that the anomaly is clearly intended, when effect must
be given to the intention. The Court will pay little attention to a proclaimed anomalyBhuwalka Steel Indus. Ltd vs Bombay Iron & Steel Labour Bd. & Anr on 17 December, 2009

if it is purely hypothetical, and unlikely to arise in practice."
It will be seen that the absurdity which the appellants are referring again and again has to be such
that it should be contrary to the sense and reason and, therefore, should include a result, which is
unworkable or impracticable, inconvenient, anomalous or illogical, futile or pointless, artificial or
productive of a disproportionate counter-mischief. We do not think that such absurdity could be
arrived at if the literal interpretation is given to the term. We, therefore, reject the argument of Shri
C.U. Singh in this behalf. Once we accept the literal construction, there will be no further question of
holding otherwise on the basis of the intent of the legislature. We have already pointed out that
there would arise no absurdity of any kind if the literal interpretation is given.
36. That takes us to the next argument regarding stare decisis. Shri Cama, Learned Senior Counsel
for the appellants urged that under this rule, where a particular enactment has received a consistent
interpretation by Courts of law for a considerable period of time, that interpretation must be
respected because the rights and obligations by parties covered by such interpretation have
remained settled thereby during the long period of time involved. It was urged by him that if the
settled interpretation is upset, then it would do a greater injustice to all the parties concerned. The
Learned Senior counsel went to the extent of saying that the rule of stare decisis should be honoured
even in case where the earlier interpretation, though consistently upheld for a long time, may not
strictly be correct or may produce two possible views. Our attention was invited to the decisions in
Mishri Lal (Dead) by Lrs. Vs. Dhirendera Nath (Dead) by Lrs. & Ors. [1999 (4) SCC 11], Pradeep
Kumar Biswas Vs. Indian Institute of Chemical Biology & Ors. [2002 (5) SCC 111], Union of India &
Anr. Vs. Azadi Bachao Andolan & Anr. [2004 (10) SCC 1] and State of Gujarat Vs. Mirzapur Moti
Kureshi Kassab Jamat & Ors. [2005 (8) SCC 534]. It was urged by the Learned Senior Counsel that
there was a consistent line of judgments starting from year 1974 right upto the present judgment of
the Full Bench in 2006, covering period of 32 years, wherein the Bombay High Court has taken a
consistent view in interpretation of the term "unprotected workers" to mean only casual workers, or
as the case may be, the workers, who did not enjoy the protection of the other labour welfare
legislations. It was pointed out that firstly, the challenge to the constitutional validity was rejected
by Hon'ble Rege, J. in his two judgments cited supra, solely on the ground that the said Act applied
to a special class of workmen, who needed special protection and classification and, therefore, such
persons were entitled to the special treatment. The reliance was placed on the judgments passed by
Hon'ble Rege, J. in C. Jairam Pvt. Ltd. Vs. State of Maharashtra (cited supra) on 19.4.1974 and in
S.B. More & Ors. Vs. State of Maharashtra & Ors. (cited supra) on 24.4.1974 and four other Division
Bench Judgments in Lallubhai Kevaldas & Anr. Vs. The State of Maharashtra & Ors. (cited supra),
Irkar Sahu's & Anr. Vs. Bombay Port Trust (cited supra), Century Textiles & Industries Ltd. Vs. State
of Maharashtra (cited supra) including this Court judgment in Maharashtra Rajya Mathadi
Transport and Central Kamgar Union Vs. State of Maharashtra & Ors. (cited supra). Very heavy
reliance was placed on the decision in Irkar Sahu's & Anr. Vs. Bombay Port Trust (cited supra),
where the Division Bench has specifically rejected the employers' arguments under Article 254 of
the Constitution of India solely on the ground that in the docks, the expression "mathadis" would be
limited to only such workers doing loading and unloading operations as were not protected by
legislation under the Dock Workers' Act, 1948.Bhuwalka Steel Indus. Ltd vs Bombay Iron & Steel Labour Bd. & Anr on 17 December, 2009

37. Heavy reliance was placed on paras 34, 35 and 36 of that decision. On the other hand, Shri
Singhvi, Learned Senior Counsel for the respondents urged that the rule of stare decisis was not and
could not be viewed as an absolute rule. Reliance was also placed on the decision in Sarva Shramik
Sanghatana (KV), Mumbai Vs. State of Maharashtra & Ors. [2008 (1) SCC 494]. So also Smt. Indira
Jaising, Learned Senior Counsel for the respondents repelled this argument relying on the decisions
in Maharashtra State Road Transport Corporation Vs. State of Maharashtra & Ors. (cited supra) and
Danial Latifi & Anr. Vs. Union of India [2001 (7) SCC 740]. Our attention was also invited to treatise
by Justice G.P. Singh, (11th Edition). It was urged by Shri Singhvi that in the aforementioned
judgments of the Bombay High Court, excepting the judgment in Century Textiles & Industries Ltd.
Vs. State of Maharashtra (cited supra), this question has not fallen for consideration at all. The Full
Bench and more particularly, the Learned Single Judge (Hon'ble Deshmukh, J.) has rejected this
argument that this question was not squarely before Hon'ble Rege, J. in his two judgments in C.
Jairam Pvt. Ltd. Vs. State of Maharashtra (cited supra) and S.B. More & Ors. Vs. State of
Maharashtra & Ors. (cited supra) nor was it before the Division Benches in Judgments in Lallubhai
Kevaldas & Anr. Vs. The State of Maharashtra & Ors. (cited supra), Irkar Sahu's & Anr. Vs. Bombay
Port Trust (cited supra), Century Textiles & Industries Ltd. Vs. State of Maharashtra (cited supra)
including this Court judgment in Maharashtra Rajya Mathadi Transport and Central Kamgar Union
Vs. State of Maharashtra & Ors. (cited supra). The Learned Single Judge noted the argument that it
was expressed in Lallubhai Kevaldas & Anr. Vs. The State of Maharashtra & Ors. (cited supra) that
the Act did not apply to the manual workers in the scheduled employment, who were protected by
the other labour legislations and the said judgment was followed thereafter in the case of Century
Textiles & Industries Ltd. Vs. State of Maharashtra (cited supra) and, therefore, on principle of stare
decisis, the settled position of law should not be disturbed. The Learned Judge has also noted the
decision in State of Gujarat Vs. Mirzapur Moti Kureshi Kassab Jamat & Ors. (cited supra). The
Learned Single Judge then, relying on the judgment of this Court in M/s. Good Year India Ltd. Vs.
State of Haryana [AIR 1990 SC 781], commented that the precedent is an authority only for what it
actually decides and not for what may remotely or logically follow from it. The Learned Single Judge
then went on to hold that what is binding is the ratio decidendi of the judgment. The Learned Judge
noted that this question did not fall for consideration either in the two judgments by Hon'ble Rege,
J. in C. Jairam Pvt. Ltd. Vs. State of Maharashtra (cited supra) and S.B. More & Ors. Vs. State of
Maharashtra & Ors. (cited supra) or even in the judgment in Lallubhai Kevaldas & Anr. Vs. The
State of Maharashtra & Ors. (cited supra). In our view, the Learned Judge was absolutely correct in
so holding. Close examination of judgments by Hon'ble Rege, J., as also judgment in Lallubhai
Kevaldas & Anr. Vs. The State of Maharashtra & Ors. (cited supra) will show that the question about
the correct interpretation and scope of the Section 2(11) of the Mathadi Act did not fall for
consideration in those cases.
38. This Court, in Sarva Shramik Sanghatana (KV), Mumbai Vs. State of Maharashtra & Ors. (cited
supra) has specifically quoted from the decision in Quinn Vs. Leathem [1901 Appeal Cases 495] as
follows:-
"Before discussing Allen Vs. Flood [1898 Appeal Cases 1] and what was decided
therein, there are two observations of a general character, which I wish to make; and
one is to repeat what I have very often said before - that every judgment must be readBhuwalka Steel Indus. Ltd vs Bombay Iron & Steel Labour Bd. & Anr on 17 December, 2009

as applicable to the particular facts proved or assumed to be proved, since the
generality of the expressions which may be found there are not intended to be
expositions of the whole law, but are governed and qualified by the particular facts of
the case in which such expressions are to be found. The other is that a case is only an
authority for what it actually decides. I entirely deny that it can be quoted for a
proposition that may seem to follow logically from it. Such a mode of reasoning
assumes that the law is necessarily a logical code, whereas every lawyer must
acknowledge that the law is not always logical at all." (Emphasis supplied) The Court
therein again referred to the decision in Ambica Quarry Works Vs. State of Gujarat
[1987 (1) SCC 213] and upheld the observations therein to the effect that:-
"18. The ratio of any decision must be understood in the background of the facts of
that case. It has been said long time ago that a case is only an authority for what it
actually decides and not what logically follows from it."
The Court further relied upon the decisions in Bhavnagar University Vs. Palitana Sugar Mill (P) Ltd.
[2003 (2) SCC 111], Bharat Petroleum Corpn. Ltd. Vs. N.R. Vairamani [2004 (8) SCC 579] and
finally, the decision in British Railways Board Vs. Herrington [All ER 761] and has quoted the
following observations therefrom:-
"There is always peril in treating the words of a speech or a judgment as though they
were words in a legislative enactment, and it is to be remembered that judicial
utterances are made in the setting of the facts of a particular case.
11. Circumstantial flexibility, one additional or different fact may make a world of
difference between conclusions in two cases. Disposal of cases by blindly placing
reliance on a decision is not proper."
Now, when we examine all the Bombay High Court's judgments on the basis of this ratio, it is clear
that excepting the decision in Century Textiles & Industries Ltd. Vs. State of Maharashtra (cited
supra), such position could not be obtained. There can be no dispute about the importance attached
by this Court in the above mentioned cases, as relied upon by the appellants, which favour the
consistency of law. Further, it is to be seen, particularly, from the decision in State of Gujarat Vs.
Mirzapur Moti Kureshi Kassab Jamat & Ors. (cited supra). In paras 111 and 112, this Court
observed:-
"111. ................ However, according to Justice Frankfurter, the doctrine of stare
decisis is not `an imprisonment of reason' (Advanced Law Lexicon, P. Ramanatha
Aiyer, 3rd Edn., 2005, Vol. 4, P 4456). The underlying logic of the doctrine is to
maintain consistency and avoid uncertainty. The guiding philosophy is that a view
which has held the field for a long time should not be disturbed only because another
view is possible.Bhuwalka Steel Indus. Ltd vs Bombay Iron & Steel Labour Bd. & Anr on 17 December, 2009

112. The trend of judicial opinion, in our view, is that stare decisis is not a dogmatic
rule allergic to logic and reason; it is a flexible principle of law operating in the
province of precedents providing room to collaborate with the demands of changing
times dictated by social needs, State policy and judicial conscience."
Again, in para 113, this Court observed:-
"113. According to Professor Lloyd, concepts are good servants but bad masters.
Rules, which are originally designed to fit social needs, develop into concepts, which
then proceed to take on a life of their own to the detriment of legal development. The
resulting `jurisprudence of concepts' produces a slot-machine approach to law,
whereby new points posing questions of social policy are decided, not by reference to
the underlying social situation, but by reference to the meaning and definition of the
legal concepts involved. This formalistic a priori approach confines the law in a
straitjacket instead of permitting it to expand to meet the new needs and
requirements of changing society (Salmond on Jurisprudence, 12th Edn. At P. 187).
In such cases, the Courts should examine not only the existing laws and legal
concepts, but also the broader underlying issues of policy......................."
In para 114, quoting from the Salmond on Jurisprudence, 12th Edn., the Court saw the need of the
Judge looking at existing laws, the practical social results of any decision he makes and the
requirements of fairness and justice. In para 116 again, the Court observed:-
"116. Stare decisis is not an inexorable command of the Constitution or
jurisprudence. A careful study of our legal system will discern that any deviation from
the straight path of stare decisis in our past history has occurred for articulable
reasons, and only when the Supreme Court has felt obliged to bring its opinions in
line with new ascertained facts, circumstances and experiences. (Precedent in Indian
Law, A. Laxminath, 2nd Edn. 2005, P. 8)"
In para 118, this Court observed that:-
"118. The doctrine of stare decisis is generally to be adhered to, because well-settled
principles of law founded on a series of authoritative pronouncements ought to be
followed. Yet, the demands of the changed facts and circumstances, dictated by
forceful factors supported by logic, amply justify the need for a fresh look."
Tested on the basis of this logic in the celebrated decision of State of Gujarat Vs. Mirzapur Moti
Kureshi Kassab Jamat & Ors. (cited supra), we have no hesitation, but to hold that the application of
doctrine of stare decisis cannot help the appellants in this case. We must express here that while
rejecting the arguments of appellants, we have in our minds, those thousands of workmen who are
otherwise exploited by Toliwalas, Mukadams and at times, the employers. The enactment is a
beneficial enactment, providing the protection to such workers, who do not have the honest
representation and it is with this lofty idea that a progressive State like State of Maharashtra hasBhuwalka Steel Indus. Ltd vs Bombay Iron & Steel Labour Bd. & Anr on 17 December, 2009

brought about this legislation. Viewed from these angles, it will have to be held that the definition
would have to be all the more broad, engulfing maximum area to the advantage of a workman. It is
with this idea that we reject the argument of the stare decisis, though very ably put by Shri Cama,
Shri C.U. Singh, Learned Senior Counsel and other Learned Counsel appearing on behalf of the
appellants.
39. The other argument raised was on the basis of maxim of Contemporanea Expositio Est Optima
Et Fortissima In Lege, shortly stated, Contemporanea Expositio. According to the Black's Law
Dictionary, this is the doctrine that the best meaning of a statute or document is the one given by
those who enacted it or signed it, and that the meaning publicly given by contemporary or long
professional usage is presumed to be the true one, even if the language may have a popular or an
etymological meaning that is very different. Shri Cama, Learned Senior Counsel for the appellants
argued that in the Committee's Reports, right from 1963 clearly only those workers were viewed,
who did not have the protection of the other labour laws and the Committee had identified only
those manual workers who were engaged in loading and unloading operations. The reliance was
made on a letter No. (c) 20206 dated 7.9.1992, written by one Shri G.K. Walawalkar, Desk Officer,
informing that in an establishment till the workers doing Mathadi type work are on their muster roll
as direct workers and they are getting total protection and benefits under the various labour laws,
till then such establishment shall not be included in the Mathadi Act or the schemes thereunder.
Two other letters were also referred to by the Learned Senior Counsel. First Letter was dated
10.5.1990 addressed to the Western India Corrugated Box Manufacturers' Association, authored by
one Divisional Officer, informing to the Chairman, Western India Corrugated Box Manufacturers'
Association that the provisions of Mathadi Act are not applicable to the directly employed workers
(employed no permanent basis) by the company. Another letter was dated 3.10.1991 addressed to
the Secretary, Mumbai Timber Merchants Association Ltd., specifying that the direct labourers of
the employer doing loading/unloading work would not be covered by the said Act. Though these two
letters were never procured, they were produced before us. Further, a reference is made to the letter
of Mathadi Board (Bombay Iron and Steel Labour Board) dated 17.11.1983, wherein the Mathadi
Board understood and applied the Act only to that special class of workers doing loading and
unloading operations in scheduled employments, who were in the regular employments of an
employer and, therefore, were not protected by other applicable labour legislations. It was also
urged that only after the impugned judgment was passed, the Mathadi Boards have started asking
the employers to register them under the Act even if they are engaging regular full time workers. It
was urged that in Irkar Sahu's & Anr. Vs. Bombay Port Trust (cited supra), the Mathadi Board had
taken such a position and they could not now turn back from their stance. From this, the Learned
Senior Counsel urged that since the State Government itself understood the provision in a particular
manner, such understanding should be honoured by the Courts.
40. The argument is clearly erroneous for the simple reason that it is not the task of the State
Government, more particularly, the Executive Branch to interpret the law; that is the task of the
Courts. Even if the State Government understood the Act in a particular manner, that cannot be a
true and correct interpretation unless it is so held by the Courts. Therefore, how the State
Government officials understood the Act, is really irrelevant. The Learned Senior Counsel, in his
address, relied on the decision in Godawat Pan Masala Products I.P. Ltd. & Anr. Vs. Union of IndiaBhuwalka Steel Indus. Ltd vs Bombay Iron & Steel Labour Bd. & Anr on 17 December, 2009

& Ors. [2004(7) SCC 68] and more particularly, para 32 therein. There, Hon'ble Srikrishna, J.
accepted the meaning of the concerned provision as it was understood by the State authorities.
However, the Learned Judge was careful enough to say that:-
"While this may not be really conclusive, it certainly indicates the manner of the State
authority viewing its power and the Rules under which it was exercising the power.
The Court can certainly take into account this situation on the doctrine of
contemporanea expositio.
(Emphasis supplied) Therefore, this cannot be viewed to be an absolute doctrine.
There are number of authorities, which speak about the powers of the Court, vis-
`-vis, this doctrine. It has been held in Clyde Navigation Trustees Vs. Laird [1883 (8)
Appeal Cases 658], Assheton Smith Vs. Owen [1906 (1) Ch 179], Goldsmiths' Co. Vs.
Wyatt [1907 (1) KB 95], Senior Electric Inspector Vs. Laxminarayan Chopra [AIR
1962 SC 159], Raja Ram Jaiswal Vs. State of Bihar [AIR 1964 SC 828], J.K. Cotton
Spinning & Weaving Mills Ltd. Vs. Union of India [AIR 1988 SC 191], Doypack
Systems Ltd. Vs. Union of India [AIR 1988 SC 782] that even if the person who dealt
with the Act understood it in a particular manner, that does not prevent the Court in
giving to the Court, its true construction.
It is pointed out in the decision in Doypack Systems Ltd. Vs. Union of India (cited supra) that the
doctrine is confined to the construction of ambiguous language used in very old statutes where
indeed the language itself have had a rather different meaning in those days. The Learned author
Justice Shri G.P. Singh, in his celebrated treatise quoted that:-
"Subject to use made of contemporary official statements and statutory instruments
the principle of contemporanea expositio is not applicable to a modern statute."
Same subject has been dealt with in Punjab Traders Vs. State of Punjab [1991 (1) SCC 86].
Considering this settled position, we do not think we are in a position to accept the contention
raised. Same logic applies that even if the Mathadi Board's stand was somewhat contradictory in the
case of Irkar Sahu's & Anr. Vs. Bombay Port Trust (cited supra), it did not really create a bar against
it from changing its stance for a correct interpretation of Section 2(11) of the Mathadi Act.
41. The next argument was based on Article 254 of the Constitution of India. It was suggested that
the said Article prescribes that in the matters falling in the Concurrent List, any Central legislation,
whether made before or after a State legislation, supersede such State legislation, if they both cover
the same field. An exception to this lies in sub-Article (2), which preserves and protects a State
enactment to the extent it has received the assent of the Vice President. Needless to say that this
challenge is in the nature of a challenge to the constitutional validity of the provision of the State
Act. Such was not the challenge. The appellants never urged that the Act was constitutionally invalid
and in fact, the constitutional validity of the Act has already been upheld. Article 254 does not
provide a guide for the interpretation of a State statute. The appellants are also not certain about theBhuwalka Steel Indus. Ltd vs Bombay Iron & Steel Labour Bd. & Anr on 17 December, 2009

proposal of the assent of the Vice President, which was received on 5.6.1969, since the said proposal
could not be located by them. Therefore, all the arguments must fall to the ground once the
Presidential assent under Article 254(2) is received to the Act. This is apart from the fact that the
grounds on the basis of Article 254 cannot be used for the interpretation of the Act. In strict sense,
this question was never before the Full Bench and in our opinion, the Full Bench rightly rejected this
argument on the ground that this was not the case of the appellants. Therefore, reliance placed on
the decisions in Kaiser-I-Hind Pvt. Ltd. Vs. National Textile Corporation Ltd. [2002 (8) SCC 182]
and Thirumuruga Kirupa Nanda Variyar Thavathiru Sundara Swamigal Medical Educational and
Charitable Trust Vs. State of Tamil Nadu & Ors. [1996 (3) SCC 15] is of no consequence. The
argument is thus rejected.
42. Thus, in our considered opinion, the Full Bench was absolutely correct in coming to the
conclusions that it did.
43. Before parting with the judgment, we must refer to the fact that this legislation, which came way
back in 1969, have in its view, those poor workmen, who were neither organized to be in a position
to bargain with the employers nor did they have the compelling bargaining power. They were mostly
dependent upon the Toliwalas and the Mukadams. They were not certain that they would get the
work everyday. They were also not certain that they would work only for one employer in a day.
Everyday was a challenge to these poor workmen. It was with this idea that the Board was created
under Section 6 of the Mathadi Act. Deep thoughts have gone into, creating the framework of the
Boards, of the schemes etc. With these lofty ideas that the Act was brought into existence. In these
days when Noble Laureate Professor Mohd. Yunus of Bangladesh is advocating the theory of social
business as against the business to earn maximum profits, it would be better if the employers could
realize their social obligations, more particularly, to the have-nots of the society, the workers who
are all contemplated to be the inflicted workers in the Act. Again, before parting, we must appreciate
the valuable contributions made on behalf of the appellants and the respondents, more particularly,
Shri J.P. Cama, Shri C.U. Singh, Shri Sudhir Talsania, Shri K.K. Singhvi and Ms. Indira Jaising,
Learned Senior Counsel. In the result, all the appeals are dismissed and under the circumstances,
there shall be no orders as to the costs.
And Permission to file Special Leave Petition in these two cases is not granted. Dismissed.
......................................J. (Tarun Chatterjee) ......................................J. (V.S. Sirpurkar) New Delhi;
December 17, 2009Bhuwalka Steel Indus. Ltd vs Bombay Iron & Steel Labour Bd. & Anr on 17 December, 2009

