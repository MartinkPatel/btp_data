Bihar Board's Miscellaneous Rules, 1958
BIHAR
India
Bihar Board's Miscellaneous Rules, 1958
Rule BIHAR-BOARD-S-MISCELLANEOUS-RULES-1958 of 1958
Published on 14 June 1904• 
Commenced on 14 June 1904• 
[This is the version of this document from 14 June 1904.]• 
[Note: The original publication document is not available and this content could not be
verified.]• 
Bihar Board's Miscellaneous Rules, 1958
Chapter I
Powers of Officers
(A)Preliminary
1. Powers specified in this chapter.
- The powers specified in this chapter do not include those relating to matters dealt with in separate
manuals or in other chapters of the present volume. They do not purport to be a complete list of the
powers of the various revenue authorities mentioned; they show for the most part powers conferred
by rules rather than by law.
2. Powers assigned by competent authority.
- Those specified in this chapter are assigned by competent legal and executive authority.
3. Relation of higher to lower authority.
- A higher authority has all the powers of any lower authority and, further may, with or without
appeal, modify or reverse any orders passed by a lower authority, in a matter primarily within the
competence of the lower authority, unless, by any law, the order of the lower authority are final.Bihar Board's Miscellaneous Rules, 1958

4. Reference to authority superior to two different authorities.
- A lower authority dissatisfied with the orders of the authority, immediately above him may move
that authority to refer the matter for the consideration of an authority superior to both. The
responsibility in such a case rests with the referring officer.
5. Officers to act upon their powers.
- Officers are to be very careful to submit no matter for the decision to superior authority which they
are competent to dispose of themselves.
6. Heads of Departments.
- The term "Heads of departments" includes the* following authority engaged in revenue
administration in this State-
1. Board of Revenue.
2. Commissioners of Divisions.
3. Commissioners of Excise.
4. Director of Land Records and Surveys.
Note. - The duties of the post of the Director of the Land Records and Surveys have been
temporarily transferred to the Member, Board of Revenue.
7. Important circulars not to be issued without sanction of Government.
- Heads of Departments should not issue any important circular, which is more than routine or
explanatory or which is capable of being interpreted wrongly by the general public, without the
previous approval of Government.
8. Division of work in the Board's office.
- The following are the departments administered by the Board :Land Revenue Side
1. Budget.Bihar Board's Miscellaneous Rules, 1958

2. Butwara (Partition).
3. Certificate procedure.
4. Cess.
5. Civil and rent suits and processes.
6. Drainage embankments and Irrigation.
7. Establishments, leave and pension.
8. Government estates.
9. Land acquisition (including Railways).
10. Land Improvement and Agriculturists Loans.
11. Land registration.
12. Land revenue (including sales, records and malikana).
13. Miscellaneous (including office inspection, tours, escheats, treasure
trove, defalcation, forms, etc.)
14. Revenue Agents,
15. Surveys and settlements.
16. Tauzi.
17. Tenancy Acts.
18. Treasury.
19. Wards, attached and encumbered estates.Bihar Board's Miscellaneous Rules, 1958

20. Waste lands,
Miscellaneous Revenue Side
21. Customs.
22. Excise.
23. Stamps.
24. Supply of Chubb's locks.
(B)Powers of Government
9. Government can issue orders where power is not given to a lower
authority.
- Government have power to issue orders, at their discretion, in any matter in which the power to
pass orders has not yet been conferred by law upon a lower authority.(C)Powers of Commissioners
10. Commissioners may issue circular orders.
- Commissioners are authorized to issue circular orders to their subordinates on questions of
procedure and general practice. A copy of every such circular should, when it relates to revenue
matters, be transmitted to the Board of Revenue, and, in other cases to Government.
11. Transfer of Deputy Collectors.
- All orders about transfer of Deputy Collectors and Sub-Deputy Collectors will be passed by
Government. Only in cases of emergency such as the sudden illness or death of an officer, can
Commissioner and Collectors of districts, transfer a Deputy Collector or Sub-Deputy Collector
within their divisions or districts respectively. Such transfer should be notified in the Bihar Gazette
and immediate intimation be sent to Government in the Appointment Department.
12. to 13.
Deleted.(D)Powers of a Collector
14. Collectors not to introduce new practices.
- A Collector should not introduce a new practice in the district without the sanction of the
Commissioner, whose duty it is to preserve uniformity of practice in the districts of his division.Bihar Board's Miscellaneous Rules, 1958

15. Powers of a Collector.
- A Collector has power to act in all matters not reserved by any law or order for the orders of higher
authority.
16. Payments to legal representatives of deceased creditors of the State.
- A Collector may satisfy the undisputed claims of parties claiming to be legal representatives of
deceased creditors of the State to sums of Rs. 100 and under without requiring the production of a
certificate under Part X of the Indian Succession Act, XXXIX of 1925. There must be, of course no
doubt as to the money being due to the estate of the deceased and as to the right of the claimant. In
no case more than Rs. 100 be paid away without a certificate except where the Collector has satisfied
himself that the claim is made on behalf of the survivors of a joint Mitakshra family by a person
entitled to represent such survivors and in respect of joint property of the family. On so certifying
himself, the Collector should require the claimant to execute in his representative capacity a bond of
indemnity in favour of the Collector.
Chapter II
Miscellaneous functions and duties of officers
17. Channel of communication between State Governments and (i) Foreign
Missions in India, (ii) Indian Missions in overseas countries, and (iii) Foreign
Governments.
- (I) Between State Government and Foreign Missions in India. - (1) All official communication with
Foreign Missions in New Delhi should normally be addressed to and by the Ministry of External
Affairs. Should any communication be addressed by Foreign Missions direct to State Governments,
the latter should consult the Ministry of External Affairs at the earliest opportunity. A reply will be
sent by the Ministry of External Affairs themselves or they will ask the State Governments to send a
reply adding a polite request that such communications should in future be addressed to the
Ministry of External Affairs.(2)There is no objection to direct correspondence between the Counsel,
Consuls-General and Trade Representatives of Foreign Governments and Deputy High
Commissioners of U.K. in India on the one hand and State Governments on the other, on routine
matters such as a request for factual information of a non-confidential nature on technical subjects.
When in doubt the advice of the Ministry of External Affairs should invariably be obtained. If
security considerations arise, the Ministry of Home Affair should be consulted.(3)Correspondence
which relates to a matter involving directly or indirectly a question of policy or one which, though
not initially, may eventually lead to a policy decision should be sent through the diplomatic
representatives of the countries concerned and the Ministry of External Affairs.(II)Between the
State Governments and Indian Missions in Foreign Countries. - (a) There is no objection to direct
correspondence between State Governments and Indian Missions abroad on purely routine matters
provided copies of the correspondence is endorsed to the Ministry of External Affairs as well as toBihar Board's Miscellaneous Rules, 1958

the administrative Ministry concerned. Correspondence on questions involving policy should
invariably be sent through the Ministry of External Affairs.Exceptions. - Correspondence in respect
of the following will continue to be sent through the Ministry of External Affairs :(i)Completion of
D.I.91. N.R.P. 78 and 127 Forms in respect of relatives of Indian Residents in South Africa, Northern
Rhodesia and Southern Rhodesia respectively.(ii)Entry of educated entrants into South
Africa.(iii)Applications for temporary visits and entry into South Africa and any of the East and
Central African territories.(b)Subordinate officers of State Governments are not authorised to
correspond directly with Indian Missions abroad.(III)Between State Governments and Foreign
Governments. - State Governments should not correspond directly with Foreign Governments.
Normally such communications are not acted upon by the Foreign Government concerned and are
made over by them to the appropriate Indian or British diplomatic authority. The proper channel of
communication with Foreign Governments is the Government of India in the Ministry of External
Affairs and the Indian diplomatic post in the country concerned, or where there is no India
Representatives the British Representative.There is no objection to any communication of a purely
routine nature being addressed by the Ministries of the Government of India, and their attached and
Subordinate Offices, State Governments and other Governmental Organisations in India directly to
private individuals or organisations abroad. It is not necessary to send copies of such
communication to the Indian Mission concerned abroad unless it is felt that the matter will be
pursued with the Mission.
18. Procedure for placing of indents on Director-General, Indian Stores
Department.
- All indents on the Director-General, Indian Stores Department, for stores to be obtained from the
United Kingdom should be placed through the Director-General, Indian Stores Department, New
Delhi, subject to the provisions that stores of highly specialised nature can be obtained by placing
indents directly on the Director-General, Indian Stores Department, Blackpool (England). List of
such specialised stores should be furnished to the Government of India, Department of Industries
and Supplies for prior approval.
19. Petitions to Indian Government.
- The instructions for the submission of petitions to the Governor-General in Council will be found
in Appendices A, B and C.
20. Memorials to King Emperor or Secretary of State for India.
- The instructions for the submission, receipt and transmission of memorials and other papers of
His Majesty the King-Emperor of India or to the Right Hon'ble the Secretary of State for India will
be found in Appendices D, E and F.Bihar Board's Miscellaneous Rules, 1958

21. Local Government Pleaders to be consulted.
- District Officers should take the opinion of their Government pleaders invariably before sending
up any case in which legal advice is required.
22. Advocate-General.
- Revenue Officers may consult the Advocate-General on points of English law through the Board
only.
23. Authority of notification in Gazette of appointments, removals, leave, etc.
- The announcement in the Government Gazette of an appointment, removal, leave of absence, etc.
over the signature of a Secretary to Government is sufficient authority for all officers concerned to
recognize and act upon without any particular orders.
24. Civil Officers to bring to notice anything in any law or system injurious to
public interests.
- Officers exercising important civil functions are expected to bring to notice anything injurious to
the public interest in the operation of any law or system, after communicating with the officers of
the department concerned.
25. Special reports on specific orders.
- The performance of any specific order of a superior officer is always to be specially reported.
26. Communication of remarks of superior to inferior officers.
- The communication to inferior officers of the remarks and correspondence of their superior in
authority and position is always a matter of discretion.
27. Copies of report regarding officers.
- If distinct charges are made against officers, or special praise awarded to them, they will, as a
matter of course, be furnished with the remarks of their superiors, but they have no right to demand
a copy of every official report made concerning them.
28. Delays.
- The Board is held responsible by Government for all delays in the despatch of business, although
these may be due to the dilatoriness of some one or more officers subordinate to it. In like mannerBihar Board's Miscellaneous Rules, 1958

the Board holds each Commissioner responsible for delay in his division, even though it be due
directly to the misconduct of a Collector, unless the Commissioner distinctly reports such
misconduct. Collectors, in the same way, are entirely responsible for any delay by officers under
them.
29. Journeys on duty to any part within the jurisdiction of the State
Government.
- The Commissioners of divisions and the Collectors of districts are authorized to allow their
subordinates to go on duty to any part of the territories of the State Government.
30. Sub-Divisional and District Officers to report promptly agricultural
deterioration.
(1)It is the duty of Sub-Divisional Officers and District Officers to report promptly the existence of
any agricultural deterioration, and such reports should be forwarded by the Commissioners, with
their views thereon, to the Board of Revenue for orders. In the case of temporarily settled and
Government estates and ward's estates it would be a matter for consideration whether abatements
or suspension of revenue or rent should be granted. In the case of permanently-settled estates, the
question of abatement of revenue cannot arise, while that of suspension will seldom need
consideration. In the case of all classes of estates the reports will be forwarded, when this appears to
the Board to be necessary, to the Director of Agriculture whose duty it is to watch over and foster
agriculture.(2)Agricultural deterioration has been described by the Government of India as
including (i) occasional failure that is, sudden distress due to unforeseen calamity such as failure of
rain, hailstorms, inundations, etc., requiring, as a rule, immediate relief; (ii) gradual failure, that is
gradual deterioration due to ascertainable causes requiring early and special measures of prevention
and relief, instances of which are cattle murrain, swamping due to the interference of drainage by
railway embankments or canals, the growth of noxious weeds and other causes which gradually
reduce the value of land or affect the prosperity of the people; and (iii) persistent failure that is
failure to reach the highest attainable standard of production, due to causes or defects of a more or
less persistent character and requiring prolonged investigation, such as want of irrigation, frequent
liability to failure of rain, insufficiency in the wood or fuel-supply, cattle diseases, plant diseases and
blights; want of drainage, the prevalence of saline efflorescence, proved imperfections in agricultural
practices, the want of suitable manures, and so on.
31. Immediate report of sudden calamities.
- Besides the immediate report of inundations, which include floods and storm-waves, and of
droughts, which is directed by paragraph just above, other calamities, such as earthquakes and
tornadoes, should also be reported immediately. The rules regulating these reports are summarized
in Government Order No. 587-P. - D., dated the 14th June, 1904, which is reproduced below and
which must be closely observed :-No. 587-P.D., Darjeeling, dated the 14th June, 1904.From-W.C.
Macpherson, Esq., Chief Secretary to the Government of Bengal.To-All Commissioners ofBihar Board's Miscellaneous Rules, 1958

Divisions.In consolidation and amendment of all previous orders regarding the prompt
communication to Government of information relating to matters of political and administrative
importance, Lieutenant Governor desires me to communicate for your guidance and for
communication to District Officers the following instructions.
2. District Officers should promptly report to Commissioners of divisions, by
telegram when the offices are not in the same station, all matters coming
under the following heads:
(1)riots which involve a serious breach of the public peace and which indicate a disturbed condition
over a wide area or are likely to be followed by disturbances elsewhere, unless prompt measures are
taken by the authorities;(2)collisions between European, of all classes and Natives which have a
political importance as affecting the relations between the two communities in the part of the
province where they occur or over the entire province, but not cases of alleged assaults, regarding
which there is no confirmation, or assaults, of a positively insignificant character;(3)outrages, which
have a political aspect;(4)calamities, such as floods or earthquakes, which cause serious damage to
life or property; and(5)all other events which have a political or administrative importance.The
preliminary report of District Officers should always be followed, as soon as possible by a later
report dealing fully with the facts.
3. On receipt of the District Officer's preliminary report you should yourself at
once send a preliminary report to Government in the Political Department,
and when you are not in the same station with the Government, this should
invariably be by telegram. Your preliminary report should be followed, as
soon as possible, by a later report dealing fully with the facts, and this
should be addressed to that department of Government which ordinarily
deals with matters of the kind reported. If, however, it is discovered from
later information received from the District Officer that the case is not of a
serious nature, it will be sufficient to intimate the fact to the Political
Department.
32. Action to be taken in the case of sudden calamities.
- District and Sub-Divisional Officers on hearing of any serious general calamity within the area
under their jurisdiction should report to their immediate superior by telegram and proceed at once
to make such local enquiry, and take measures for such immediate relief as may be advisable. The
assistance of the Executive or District Engineer may be invited. Endeavour must be made to
ascertain, as exactly as possible, what is the extent of the damage done and, as far as possible, to
render immediate effective assistant, for instance, on the occasion of a flood there may be lives to
save; people or cattle who have taken refuge on island or high land to be rescued; dead bodies and
carcasses of animals to be removed and disposed of; and the collection of boats and scavengers toBihar Board's Miscellaneous Rules, 1958

carry out these measures to be attended to. If there is danger of starvation owing to the destruction
of local stores of food, necessary measures should be taken.The higher authorities must be kept
promptly informed of the progress of the enquiry, and recommendations should be made as to
action which may be taken on the part of Government. An officer who fails to act in accordance with
these instructions incurs a very serious responsibility.
33. Collector's duties in relation to his subordinates.
- The communication between a Collector and his deputies should be close, constant and personal,
not confined to the interchange of official orders and reports.The careful supervision of the
proceeding of his deputies, both at headquarters and at sub-divisions, is one of the most important
of a Collector's duties.
34. Absence from illness.
- If a Collector or Deputy Collector is unable, on account of illness, to attend office for more than
week in one month, or for more than three consecutive days at any time, the circumstances should
be reported for the information of the Commissioner without delay.
35. Procedure when taking charge.
- An officer taking charge of a collectorate should examine particularly the state of the camp
equipage and of the library.
36. Memorandum when delivering over charge.
- An officer delivering over charge, whether of Collectorship or a Commissionership, otherwise than
as a purely temporary measure must leave for his successor a note of all pending matters of
importance and a memorandum of his opinion of the official character and conduct of the gazetted
and other principal officers who are directly subordinate to him.
37. Officers to whom money is entrusted are personally responsible.
- Officers to whom advances have been made, or to whom public money has been in any way
entrusted, shall as a general rule, be held personally responsible for such money, if it happens to be
lost or stolen while in their immediate custody, or from a police station in which it may have been
placed by their order, unless they can clearly show that every reasonable precaution was taken by
them for its safe custody.
Chapter III
Tours and InspectionsBihar Board's Miscellaneous Rules, 1958

1. General
38. Duration of tour and sketch of inspection to be made.
- Commissioners, District Officers, and Sub-Divisional Officers should be personally acquainted
with all parts of their respective jurisdictions, and should inspect with reasonable frequency, all
public institutions therein situated, and should make from time to time in person, such local
enquiries as may be necessary to enable them to conduct their duties with satisfaction to themselves
and Government or supply any information specially required by Government.
39. Commissioner's tour programme.
-
All Commissioners should be on tour inspectingeach
year every Magistrate's and Collector's office in all
itsbranches, every sub-divisional office, every
registration officeand dispensary at district or
sub-divisional headquarters, everyJail, subsidiary Jail
or lockup; also every settlement mentionedin the
settlement report of the Director of Land Records
andSurveys which is under their orders; and so far as
possible thesummary of unprofessional settlements of
Government ortemporarily settled estates, which are
made by the districtstaff. They should pay special
attention to the working of theCourt sub-inspector's
office, the regularity of attendance ofhonorary
Magistrates, the disposal of criminal cases
bystipendiary Magistrates, the frequency of
remands,the work of therecord-room, the certificate
department, the land acquisitiondepartment and the
tauzi department. All Commissioner are to exercise a
sounddiscretion in arranging the
length and character of their
owntour programme, subject to the
minimum prescribed by note
below.They are expected to attend to
the various matters specified
inParagraph 2 of the resolution of
the Government of Bengal,General
Department No. 398 T.G., dated the
17th October, 1891 butin doing so are
at liberty to arrange their work for
anyparticular year. They will in
future be under no obligation togive
up more important duties in order to
visit yearly everysub-divisional
office, registration office, subsidiary
jail orlock-up. They will, however, in
their annual land revenue
reportexplain what they have
omitted to do showing what places
they andthe officers subordinate to
them have visited and what
specialmatters have engaged their
attention.
Note. - The minimum number of days spent on tour and nights spent away from headquarters by
each Divisional Commissioner should be as follows :-
 Period Days on tour.Nights spent away from
headquarters.Bihar Board's Miscellaneous Rules, 1958

1. Period of 12 months from 1st April to 31st March. 120 96
2. Every quarter 25 18
40. Tours of District and Sub-Divisional Officers.
(1)The duration of the District Officer's tour should be fixed annually by the Commissioner provided
that the minimum to be spent on tour by a District Officer should be 60 nights. He should spend a
considerable portion of the cold weather in touring in those parts of his district which are not
accessible at other times of the year. A reasonable proportion of the touring must be of this nature
and conducted in a manner which gives villagers an opportunity of access to him. At the beginning
of the cold weather each District Officer should plan out his touring for the reason so as to cover an
adequate area of his district. It is possible for him to spend five or six days in tents, moving camp
two or three times and then return to headquarter's. He should submit his tour programme for the
following month to the Commissioner, some time before the end of the month.(2)The District
Officers should fix annually the duration of the tours of the Sub-Divisional Officers under him and
should ensure that they spend an appreciable amount of time in less accessible parts of their
subdivisions. Each Sub-Divisional Officer should submit his tour programmes for the following
month to the Collector, but they should submit their programme for their cold weather touring well
in advance and should plan out their tours so as to cover the more inaccessible parts of their charge.
District Officers should, if necessary revise these programmes in order to attain this end and should
take steps to ensure that the touring of the Sub-Divisional Officers complies substantially with the
scheme which they have laid down.
41. Half-yearly review of the touring of District and Sub-Divisional Officers.
- A half-yearly review should be made by Commissioners of the touring of Districts and
Sub-Divisional Officers particular attention being paid to the quality and not to the quantity of
touring and communicated to Government, Board of Revenue and District Officer, by the end of
January and July each year. It will be enough if a summarised opinion be recorded on each Officer's
touring quality and quantity.
42. Miscellaneous matters of revenue administration which require attention
of Inspecting Officers.
- Revenue matters, which should have the attention of Commissioners and Collectors, are the
accuracy of the preparation of price-lists; rainfall gauges and registers; weather and crop reports;
the state of the crops; crop statistics; experimental crop cuttings; calamities of seasons; agricultural
deterioration; famine warning; cattle disease; agricultural and veterinary institutions and
experiments; agricultural banks; co-operative banks and societies, camping grounds; boundary
marks; embankments, relations of landlords, and tenants, rise or decay of local industries.Bihar Board's Miscellaneous Rules, 1958

43. Matters which require attention in all offices.
- Matters which require attention in all offices are the sufficiency of the arrangements of public
offices and the buildings for the accommodation of the public and the Government officers; the
condition of public buildings and furniture; the state of Kachahari and office compounds and the
arrangements made for lease and licence of shops in such compounds, prohibition of erection of
inflammable buildings in the vicinity of public offices; preventions of blocking of verandahs, doors
and windows with almirah, etc., the training of young officers; programmes of work for Sub-Deputy
Collectors, Kanungoes, and similar touring officers; prevention of cliques in officers; communal
representation in Government offices; recruitments of probationary clerks; the distribution of work
both as regards officers and clerks; the observance of the prescribed hours of attendance;
arrangements for taking petitions; entry of dates for cases in forward diaries, and punctual dealing
with cases on due dates; detention of witnesses; full use of the order sheets; examination of case
records as the most important test of work; arrangements for records of pending case in serial order
in bundles of convenient size; punctual submission of returns; books of reference and manuals with
a view to check that all correction and addition slips have been duly pasted; tidiness and methods.
The Inspecting Officer should always ascertain whether his subordinate officers are making
adequate inspection; whether orders passed at previous inspections have been carried out; whether
stock and store registers are properly kept up; whether departments in which public money is
received observe carefully the Rule regarding the custody of receipt book (see Rule 303 et seq of this
volume).
44. Diaries.
- Collectors are required to submit monthly, or less frequently, as may be prescribed by the
Commissioner, diaries of their tours. These should be written by the Collectors themselves on half
margin in a bound book and copies should be submitted to the Commissioner on half margin. The
Commissioner will record orders on the margin and return the paper to the Collector for
information and return (to Commissioner's office), or retain it in his office, forwarding only copies
of his orders as in each case may be most convenient. The Collector will then cause the
Commissioner's remarks, if any, to be entered on the margin of his original diary book. Should the
Collector happen to accompany the Commissioner on any tour, no diary will be required.
45. Their object.
- It is not intended that these diaries should be so elaborate as to impose on the Collector any
serious labour in addition to his ordinary duties. The object is to give the Commissioner information
of a general nature as to the condition of those parts of his jurisdiction which the Commissioner is
unable to visit himself.
46. Subjects to be noticed.
- The diary should contain remarks on such of the following points as may call for notice; date; nameBihar Board's Miscellaneous Rules, 1958

of place visited; general condition of the country; state of crop; public feeling and health; any
interesting facts elicited in conversation with persons of influence and position or with other classes;
relations between landlords and tenants; state of roads; wards and Government estates; progress of
local work; anything remarkable in connection with movements of people or traffic in food staples,
and the like; rise and decay of local industries, etc.
47. Inspection of institution.
- On inspecting institutions which keep visitors or inspection books, the Collector will, of course,
record his remarks therein, but may insert in his diary a few notes as to the general condition of the
institution, whenever necessary. In the case of institutions which do not keep visitor's books a fuller
report should be given.
48. Irregularities.
- Any abuses or irregularities deserving special reports need not be reported in full in the diary but
brief remarks may be made to effect that a report is under preparation.
49. Sub-Divisional Officers' diaries.
- Sub-Divisional Officers will in like manner submit diaries to the Collector, who will return them
after perusal with his notes, unless he considers it necessary to submit them for the information of
the Commissioner. These diaries should enter somewhat more into detail than those submitted by
the Collectors and should contain in addition to the points noted in the Rule 46 above, references to
minor local institutions such as cattle pounds, ferries, village roads, and the like.
50. Other touring officers diaries.
- All Gazetted Officers under a Collector who have from time to time to make tours should keep tour
diaries. These diaries should be filled as the Collector may direct.
51. District Officers' Inspection of their own offices.
- Government attach much importance to careful inspection by Magistrate-Collectors of their own
offices. It will suffice if there is one detailed inspection of the work in all department annually by the
District Officer. The treasury must be inspected according to the Bihar Treasury Code by the District
Officer. A good Magistrate-Collector will be constantly inspecting one branch or other of his office
work, and if this duty is systematically undertaken, one department after another being gone into in
turn, there is the less need for repeated over-turning of the office as a whole to the detriment of
current work. The names of District Officers who fail to inspect their offices thoroughly in person or
who postpone the bulk of their inspection till a late period of the year when there is not sufficient
leisure for it, are to be mentioned in the Commissioner's Land Revenue Administration Report:
District Officers should furnish explanations of failure in this respect in their own Land RevenueBihar Board's Miscellaneous Rules, 1958

Reports. The Commissioner shall pass suitable orders on that and in his own report state his
opinion as to the care and efficiency with which each District Officer has carried out his annual
inspection [see Rule 24(2)(i)(b), page 92 of the Bihar and Orissa Register and Return Manual].
52. Half-yearly and quarterly inspection of revenue.
- Complete inspection of their offices should be made by Deputy Collectors, Sub-Deputy Collectors
and Assistant Collectors at least once each half-year so as to answer the questions prescribed for the
departments in their charge. Ordinarily the questions should be dealt with during the each half year,
some in one month, others in the next, in convenient instalments, so as to permit of a thorough and
careful examination. But a Collector can, if he thinks fit require such inspections to be made
quarterly. In such inspection the questions prescribed for the department should be made use of the
Collector, when necessary should require that answers to questions should show what practical test
was applied by the Inspecting Officer before answering the questions. The names of Revenue
Officers, who fail without due cause to inspect their departments thoroughly in person at least once
in each half-year should be noticed and explanation of failure furnished with necessary remarks, in
the Collector's annual report on the Land Revenue Administration of the year. This report should
not be forwarded to the Board. But the Commissioner should pass suitable orders on all cases and
mention in his Land Revenue Administration Report instances of decided failure in this respect,
which have not been explained to his satisfaction, and should take this matter into consideration in
classifying an officer.
53. Inspections of District Offices.
- Ordinarily the District Officer cannot take up and answer all inspection questions prescribed for a
department though he may find it desirable to take up a portion or occasionally the whole for the
sake of example or instruction to the officer-in-charge. Usually his inspection must be chiefly or
largely directed to seeing that this officer is doing his work efficiently. It is especially, important to
ascertain whether he is making his inspection in a thorough and complete manner, and that before
answering those questions which require the making of a practical test, he has actually carried out
the test. Accordingly the District Officer will find it advisable to select one or more of such questions
and make the practical test for himself. In this way he will simultaneously check the work both of the
office and of the officer-in-charge.
54. Difficulties to be explained and defect to be corrected at inspections.
(1)An inspection gives opportunity for representation and explanation of difficulties, and for
discussion of question of importance; and this opportunity should be fully utilised by the Deputy
Collector in immediate charge of an office in explaining difficulties felt by his clerk, and the
Commissioners and District Officers explaining matters on which their instructions may be required
and specially introducing better practices and standards of other offices into offices where practices
and standards may be defective.(2)A good inspecting officer will not only find fault, but, will indicate
the remedy. It should be the aim of an inspecting officer, as far as possible to set right, then and
there, anything which he finds wrong, and not to originate a correspondence. One of the chiefBihar Board's Miscellaneous Rules, 1958

objects of inspection should in fact be to prevent the necessity for correspondence.(3)It has been
useful for an officer when hearing appeals to keep a note or defects noticed in procedure. These
should sometimes be set right by issue of immediate order, but can sometimes be gone into during
inspection.
55. Young officers should attend senior officers inspections.
- It is very advantageous to young officers to be present during inspections by more experienced
officers.
56. Inspection questions.
- The inspections will be facilitated by the use of questions suggested for the purpose in the Board's
Manuals relating to the several departments of a Collectorate. Questions relating to the
Munshikhana and Nazir's office and Malkhana are given in Appendix G. A set of questions under the
authority of Accountant-General has been prescribed for inspection of the Treasury and Accounts
Departments.
57. The prescribed questions are not exhaustive.
- The prescribed questions and instruction are not intended to limit the points into which the
inspecting officer should enquire. If he finds that any question shows the state of the office or
register to be such that further enquiry is required on any point he should follow up such enquiry
further, although specific questions may not have been prescribed for it. It is also not intended that
answer to the questions in the Manual should be specially recorded and transmitted for the
consideration of the Board. Commissioners will exercise a discretion in calling for the submission of
answers, if they should think it necessary. But primarily for object of the question is to assist officers
in inspection.These inspections should not be made a fixed times, but irregularly and without
notice.
58. Statistics of work to be got ready for Inspecting Officers.
- Inspection will be useful if statistics of the work of an office be prepared before-hand for the
inspecting officer in such forms as may be prescribed; or, if answer to statistical question be
prepared before-hand. This will also give the inspecting officer more time for examination and
disposal of matters of importance and difficulties. Comparison of statistics for similar districts will
sometime enable an inspecting officer to discover defects of practice and procedure and to suggest
improvements.
59. Inspection book-Register 26.
- Inspection book is to be kept at each headquarters and sub-divisional station. The remarks of high
inspecting officer such as Member of the Board and Commissioner are to be entered in separateBihar Board's Miscellaneous Rules, 1958

paragraphs in this register upon each visit, as well as those of Collector made in his yearly
inspection. All such orders should be recorded on the left half of a foolscap sheet, the right hand half
being reserved for the record of measures taken by the station officer in consequence. This record
should contain a condensed and clearly written memorandum showing merely the important points
noted by the inspecting officer. Commissioner's orders, passed upon inspection of sub-divisions,
should be always sent in at once for the Collector's information.On inspecting the district officers the
District Officers should send to the Board of Revenue, Bihar, extracts, from their notes of inspection
on the sale and storage of maps, and also on subjects with which the Board is concerned as
mentioned in Rule 8 of these rules.
60. Guard file to be kept of inspections.
- The ministerial head of each department in a Collectorate should maintain different Guard files
according to the class of Inspecting Officers like the Deputy Collector-in-Charge, Collector,
Commissioner, Member, Board of Revenue, High Court and the Hon'ble Ministers, in which should
be placed properly arranged in chronological order, copies of inspection notes relating to his
department. These copies should be made on half margin and, against any defect noticed or
suggestion made by the inspecting Officer should be noted the action taken.Five blank pages for the
index should be provided in each Guard file and the index should be in the following form :
(i) Serial No. -1 inch
(ii) Name of office inspected -2 inches
(iii) Name of Inspecting Officer -3 inches
(iv) Date of inspection -1 and half inches
(v) Page number -1 and half inches
(vi) Remarks-about date of receipt and issue -1 inch
The pages meant for the index should be ruled, the line being one inch apart.The important points
noted by the inspecting officer should be abstracted in Register 26 mentioned in the preceding
rule.[Compliance report on inspection notes of the Board of Revenue and the Ministers should be
submitted to the Board within one month from the receipt of the inspection notes. Compliance
report on other inspection notes should be similarly submitted to the Inspecting Officers concerned
whose business it should be to pursue the compliance of their remarks. A copy of the compliance
report should always be kept with the inspection note in the guard file of the department
concerned.] [Substituted by C.S. No. 8 dated 10.6.1965.]Inspecting Officers while recording the
inspection notes should also record whether actions suggested in the previous Inspection Notes have
been given effect to.
2. Inspection of Offices
61. Commissioner's offices.
- It is expected that Divisional Commissioner will require their Personal Assistants to makeBihar Board's Miscellaneous Rules, 1958

thorough inspection at least once a year of every department of their offices and specially of their
record rooms and that Commissioners will themselves make such inspections of their offices as may
be required.
62. Inspection should be personal.
- Rules 63 to 73 following indicate some of the chief points to which a Commissioner is expected to
pay attention in inspection of revenue offices at headquarters of districts and sub-divisions; but
these rules are not intended to be exhaustive. The inspection of Commissioner should be conducted
in person. There is, however, no objection to his having certain specified registers or returns
examined by his own clerk under his special order. It is desirable that he should spend at least a
month annually in each district of his division.
63. Unauthorised reports and returns.
- The Commissioner should, when he inspects, note the extent to which District Officers call for
unauthorised reports and returns from their subordinates and take such steps as he may think fit to
check this practice, if such is found to exist. He should also endeavour to secure uniformity of result
in the matter of disposals, and as a means towards this, he should have prepared before he
commences his yearly inspection a statement showing for each district in regard to each department
for which such figures are procurable :(a)the number of items of work disposed of during the
previous year;(b)the number of clerks employed in such work;(c)the average outturn of a clerk.Care
will have to be taken in regard to the figures under (a) since experience has shown that many items
are wrongly entered as such, especially in regard to the record-room and treasury.
64. Examination of registers.
- He is to examine carefully all the registers, ascertaining that they are punctually and neatly kept
and pointing out any error or wrong practice that may come to light.
65. Measures for keeping these registers in order.
- Special attention is to be paid to registers prescribed by Bengal Act VII of 1876 and Act XI of 1859
(Registers A to K). He should propose immediately any measures that may appear necessary for
keeping these important registers in thorough order. Inquiry should be particularly made whether in
the general register B, Part I, due entry is made of estates of which the revenue is redeemed, or
which are declared revenue free. He should ascertain that the rules in the Land Registration Manual
are properly followed.
66. Registry of new estates.
- He should inquire whether the immediate registry of new estates is carried forth.Bihar Board's Miscellaneous Rules, 1958

67. Securities of ministerial officers.
- He should ascertain that the securities of the ministerial officers have been properly tested.
68. English correspondence.
- He should inquire whether the rules for the simplification of the English correspondence (vide
Records Manual) are carried out.
69. Record-room.
- He should examine the record room, ascertain that survey records are properly kept and see that
the record rules (Record Manual) are adhered to, and that the English correspondence in the district
and sub-divisional offices is intelligently classified and periodically sorted, destroyed, etc., under the
rules of the said manual.
70. Library.
- He should examine the office library, and see that the rules on the subject (vide Records Manual)
are attended to.
71. Rules for taking evidence and for the service of process.
- He should ascertain that the rules for taking evidence are suspended in each court in the district,
and that the rules for the service of processes of revenue Courts (vide Practice and Procedure
Manual) in English and in the vernacular are suspended in some conspicuous place in the offices of
the Collector, Deputy Collector and Nazir respectively, where they can be read by the general public.
72. Diary and state of business.
- He should examine the diary kept by each officer in the form prescribed by the High Court in their
Circular Order No. 8 and General letter No. 6 of the 10th September, 1892; inquire minutely into the
state of business before the Collector: provide for the disposal of arrears and prevent the neglect of
any particular branch of duty, or of any of the rules for the conduct of business, such as the rules for
taking evidence, etc.
73. Confidential note-book.
- He should also enquire whether the confidential note-book is suitably maintained by the District
Officers (Bengal Government Order No. 42, dated the 5th November, 1908).Bihar Board's Miscellaneous Rules, 1958

74. File of general powers of attorney.
- He should ascertain that the file of copies of general powers of attorney is properly kept and that
the powers are attested.
75. Correction slips for Board's Rules and Manuals.
- He should ascertain that the correction slips furnished by the Board are regularly and intelligently
inserted in this volume and other Manuals.
76. Excise Department.
- He should inquire into the working of the Excise Department, and ascertain that the Collector and
his staff visit the distilleries regularly and frequently.
77. Inspection notes of Commissioners.
- The Commissioners will forward to the Board and to Government copies of all their inspection
notes relating to subjects referred to in Rule 8 of the Board's Miscellaneous Rules with which they
are concerned.The will also send to the Board extracts of their inspection-notes on other subjects,
which they wish the Board to peruse. Extracts should be sent as soon as convenient after the
inspections have been made.
78. District Officer's Inspection of his own Office.
- The District Officer's inspection of his own office should ordinarily be made in the hot weather and
rains, except when the bulk of the Collector's touring has to be done in the rainy season. An
inspection, when it comes very closely after the one made by a Commissioner, may, as a rule, be
directed mainly to an examination into the way in which the suggestions or orders given at previous
inspections have been carried out.
79. District Officer's Inspection of Sub-Divisional Offices.
- The Collector should always ascertain at his inspection of a sub-division how the revenue work is
being done, and should consider whether any of it should be transferred to headquarters or whether
work of the sub-divisions done by the headquarter's staff could be transferred to the sub-divisional
staff.
80. Inspection of Sub-Divisional Office.
- Sub-Divisional Officers should make a detailed inspection of their own offices annually in every
branch, and should answer the questions prescribed for the various revenue offices as far as they
may be applicable.Bihar Board's Miscellaneous Rules, 1958

80A.
(i)Every disbursing officer should make at least one detailed inspection once a month of his office
and particularly examine the accounts with a view to see that the accounts have been maintained in
the prescribed manner and in the prescribed registers and should go into the reasons for undue
fluctuations in receipts and expenditure, particularly into the reasons for rapid flow of expenditure
and for possible excess over budget allotments. A report should be submitted in each quarter after
his monthly inspection in the third month of the quarter stating the irregularities noticed and action
taken to regularise them. Where a Senior Deputy Collector is a disbursing officer and is incharge of
the budget work, the Collector should scrutinise the accounts once in each quarter.(ii)Every
controlling officer should make a thorough inspection once a year or as suitable in each case, of the
office of each of the disbursing officers under him and his own office, and in cases where the number
of such disbursing officers is larger and it is not practicable to make an annual inspection of the
whole office, the controlling officers should make at least an inspection of the accounts side of the
office of the disbursing officers with special reference to the points mentioned in sub-rule (i) above.
To facilitate the inspection, the controlling officer should take with him the monthly statements of
expenditure submitted by the disbursing officers and those received from the Accountant-General
for a period of at least twelve months up to the date of the inspection and also the periodical reports
received from the disbursing officers. A consolidated report on the inspection of the offices of all
disbursing officers under each controlling officer should be submitted by him to Government in the
administrative department every year before 31st July alongwith his comments as to whether the
accounts are being properly maintained in all the offices subordinate to him.Those controlling
officers who have under them a large number of disbursing officers and who cannot find time for
making annual inspections themselves should arrange for such inspection by their subordinates
adopting the safeguard that such inspection is made by a subordinate officer other than the
disbursing officers concerned in each individual case. The controlling officers should, however,
include the remarks of the inspecting officers in their annual consolidated report to Government.If
the Personal Assistant to the Commissioner is a drawing officer and deals with the accounts work of
the Commissioner's office, the Commissioner should make an inspection of the accounts of his
office. A copy of the inspection note should be sent to the Board.
3. Inspection of treasuries
81. Inspection of treasuries.
- The general orders for the inspection of treasuries are contained in Chapter II, Section III of the
Bihar Treasury Code, 1948, Volume I. The Board directs the attention of inspecting officers to the
importance of satisfying themselves that the personal assurances which are periodically given by
officers incharge of money and stamps are strictly and literally in accordance with fact. In this
respect instances of laxity are constantly coming to light. An officer certified that a certain sum
(which had actually been paid out) was in his custody, in the shape of pice; and in another case.
Treasury Officer was found to have periodically certified to the effect that he held certificate from
the Sub-Divisional Officers, that they had themselves counted the money in their charge on a certain
date and found it to be so much, whereas in fact, the Sub-divisional Officer had not certified to thatBihar Board's Miscellaneous Rules, 1958

effect. It is evident that if these personal certificates are not given in strict accordance with fact, not
only are they useless, but they are mischievous, as creating an impression of security on the part of
the controlling officers for which there is no ground. If in any case, the requirement of these
personal certificates impose on an officer a duty which practically he cannot perform, the proper
course is obviously to point out the difficulty to a superior authority and not to allow certificates to
be submitted which comply with the requirement in form only. In any case in which an inspecting
officer finds that the treasury management is not satisfactory, he should necessarily go very much
deeper into details in his inspection.
82. Periodical examination by District Officers.
- Every Collector should make a systematic inspection of the working of his treasury once in six
months. The periodical examination of the stock of cash, deposits, stamps, opium, securities, bill,
draft and cheque forms by the Collector should be made according to the rules prescribed in Chapter
II, Section I of the Bihar Treasury Code, 1948 Volume I. He is also bound to satisfy himself that the
tahsil balances are verified once a year by an Assistant or Deputy Collector in the case of
Government estates lying within a mufassil sub-division by the Sub-Divisional Officer, under rule
109 of the Government Estates Manual, 1941.Note 1. - The yearly verification of stamps etc., by the
District Officer should not be made within a period of four months from the date of his last annual
verification nor within a period of 2 months from the verification by the Treasury Officer made on
the last open day of March and September in accordance with Rule 35 of the rules prescribed by the
Government of India for the supply and distribution of stamps.Note 2. - Under Government Order
No. 1381-85-F, dated the 29th January, 1915, District Officers are authorised to delegate the duty
imposed on them of verifying the deposit registers of the district treasury to an Assistant or Deputy
Collector not in personal charge of the treasury.
83. Collector's duty in looking to the safety of the strong-room, etc.
- It is the duty of the Collector of a district to see that the strong-room is safe, the chest substantial,
the hinges, hasps, etc., in good order and unremovable, and the locks sufficient. He shall report
whether the padlocks and all keys (except the strongroom lock's duplicate keys deposited elsewhere)
are correct and deposited in accordance with rules.
84. Verification of cash balance in the morning of 1st April.
- When the Collector inspects his treasury for the second time on the 31st of March, the Collector is
authorised to verify the cash balance of the treasury either on date, or in the morning of the 1st of
April.
85. Sub-Divisional or other treasury inspection.
- Every Collector shall also inspect every sub-divisional treasury or treasury other than the district
treasury under him once a year.Note. - Under Government Order No. 7703-F, dated the 14th July,Bihar Board's Miscellaneous Rules, 1958

1944, the Additional Magistrate of Saharsa has been declared to be the Collector for the purposes of
the inspection of the sub-treasuries at Supaul and Madhepura.
86. Sub-treasury inspections by Commissioners.
- Report to the Board of material irregularities detected in the course of a treasury or sub-treasury
inspection. - Commissioners are relieved of the duty of inspection of district treasuries. When
inspecting a sub-divisional office the Commissioner should enquire how far the treasury rules are
attended to, examining carefully the treasury records and accounts and should ascertain by personal
inspection that the custody of treasury, currency notes, stamps and opium is provided for according
to rules. He should issue orders for the correction of irregularities detected to the officer incharge of
the sub-treasury concerned, through the Collector. Material irregularities should be brought to the
notice of the Board.
87. Sub-treasury inspection by Sub-Divisional Officer.
- The Sub-Divisional Officer shall make a systematic inspection of the working of his treasury once
in six months. When a second officer is attached to a sub-division and is placed in charge of the
sub-treasury he must still satisfy himself by an inspection at least once in three months that the
work is being done according to rules.
88. Treasury and sub-treasury inspection questions.
- Printed forms of questions to be used in inspection of treasuries and sub-treasuries should be
obtained on indent from the Superintendent, Government Printing, in-charge of Press and Forms,
Gaya.
89. Communication of inspection memoranda on treasuries and
subtreasuries.
- The inspection of his own treasury by a Collector is for his own satisfaction, as the officer directly
responsible for the proper management of treasury and no copy of his inspection note need
ordinarily be submitted to any superior officer. When inspecting a sub-treasury he will merely
record an inspection note and send a copy to the Sub-Divisional Officer concerned. Should,
however, any important defect be detected either by himself or the Sub-Divisional Officer, the
Collector should report the defect to the Commissioner and the Accountant General separately. No
date for this return can be fixed as it is not desired that the inspection shall be made on any fixed
date. Sub-Divisional Officers are to transmit copies of their inspection memoranda to the Collector
who will pass such orders on them as may appear to him necessary.Bihar Board's Miscellaneous Rules, 1958

90. Treasury inspection by Audit Officers.
- Under the orders of the Government of India, a Gazetted Officer of the Audit Department is
required to visit each treasury in turn, overhaul the system and methods of work generally and
advise District Officers as to the defects noticed and their remedies. District Officers should take the
opportunity to discuss with him any administrative difficulties in connection with the treasury or
financial matters. All correspondence relating to treasury Inspection Reports will be carried on
direct between the District Officer concerned and the Accountant-General, who will, however,
forward a copy of each inspection report to the Divisional Commissioner for information, and
continue to bring any matter of special importance to the notice of the Provincial Government
through the Board. The Accountant-General will only refer to the Divisional Commissioner in
special cases or when he is dissatisfied with the action taken by the District Officer.It should be
understood clearly that it is not intended by this arrangement to weaken in any way. the
responsibility of District Officers in the matter of treasury work.
Chapter IV
Training of Junior Officers
91. Employment in cold weather.
- [Assistant Collectors] [See Regulation IV of 1821.] may be employed during the cold weather
entirely upon revenue duties in the interior, taking up only such criminal duties in neighbourhood of
their encampment as will not interfere with their revenue duties. It is very desirable that Assistants
should be as much in the interior of their districts as possible, in the cold season, performing
settlement for other duties.
92. Examination of returns.
- Assistant Collectors may be very usefully employed in examining and attesting the periodical
returns despatched from the office.This will give them a good practical knowledge of their duties.
93. Training in survey and settlement work.
- Junior officers are given training in survey and settlement work so that they may be able to check
the proceedings of their subordinates in future.
Chapter V
Rules relating to the conduct of Government ServantsBihar Board's Miscellaneous Rules, 1958

94.
The principal general rules governing the conduct of Government servants will be found in the
pamphlet, entitled the Government Servant's Conduct Rules, a copy of which will be supplied to
every non-gazetted, Government servant (excluding menials) on his first appointment.The rules in
this chapter relate to miscellaneous matters not dealt with in the general rules."Principles to be
followed in ordering suspension of Government servants are incorporated in Appendix J."
95. Pecuniary transactions on behalf of estate under Government
management.
- Collectors are prohibited from entering into any pecuniary transaction with public servant on
behalf of an estate under the management of the revenue authorities.
96. Collectors not to borrow money.
- Collectors are strictly forbidden to borrow money from land-holders, or managers of wards, estates
or guardian of wards.
97. Commission on purchases for Government forbidden.
- Any commission on purchase made by a public servant on account of Government or any
gratification or payment, the receipt of which is not specially sanctioned by Government, has been
by notification in the Gazette, dated 16th July, 1865, declared not be a, "legal remuneration" within
the meaning of [Section 161, Act XLV of 1860] [Section 161 of IPC, now repealed by Prevention of
Corruption Act, 1988.], (The Indian Penal Code).
98. Deputy Collectors may not employ creditor, borrow in the district, take a
farm in the district, buy land, or engage in trade.
- Deputy Collectors are forbidden, on pain of dismissal or removal:-(i)to employ or retain on their
establishment any person being their private creditor, or any relative, dependent or surety of such
creditor;(ii)to borrow money from, or, in any way, incur debt to any zamindar, talukdar, raiyat, or
other person possessing real property, or residing in, or having a commercial establishment within
the city, district or division to which their authority may extend;(iii)to take a farm of any estate
borne upon the revenue roll of, or situate in, or belong to a ward, of the district in which they are
employed;(iv)to purchase lands sold at public sales by the Collector in the district in which they are
employed;(v)engage in any commercial transaction within the district in which they are employed.
99. Ministerial officers not to be employed in two offices.
- Ministerial officers shall not take service in two offices at once or give part of their time to private
service; and are forbidden to employ their official subordinates upon their private concerns.Bihar Board's Miscellaneous Rules, 1958

100. Ministerial officers forbidden to take lease.
- Ministerial officers may not take farms or Mukarraris from any land-holders in the district in
which they are employed.There is no objection to ministerial officers acquiring, as well as holding,
immovable property in the districts in which they are employed provided that such purchases are
made openly and are effected in the ordinary course, and that the officers in question neither
purchase nor take any part in the sale of property which has been the subject of litigation in the
courts in which they are employed, or in courts subordinate to those Courts.
101. Insolvency of ministerial officers.
- All heads of officers having establishments in the pay of Government should make their
subordinates distinctly understand that all public servants arrested for debt or having recourse to
the Insolvent Court will be deemed to have forfeited their appointments unless it can be shown that
their embarrassments have been the result of unforeseen misfortunes, or of circumstances over
which they could exercise no control, and have not proceeded from dissipated or extravagant
habits.The same principle will apply in the case of officers whose salary is constantly under
attachment for debt. All heads of departments and gazetted heads of offices are authorized to pass
final orders, subject to appeal to Government, in the case of serious indebtedness and insolvency of
non-gazetted officers subordinate to them.
102. Annual verification of list of landed property owned by ministerial
officers.
- Register 45 should be kept up in the offices of all Commissioners, Collectors and Sub-divisional
Officers, and it should be brought up to date in January of each year. In the first week of that month
every ministerial officer should be called on to state whether the list of landed property owned by
him as entered in Register 45 is correct and complete. If it is not, he should submit not later than the
15th idem a return, in the form prescribed in Government Circular No. 50, dated the 26th August,
1879. The entry in the register will be revised according to this return, and will then be signed and
certified by him to be correct. If however, the list does not require any alteration or addition, no
return need be submitted, but the ministerial officer must sign his name (with the date) below the
last certificate in column 7 of the register.This will be repeated every year until a change in his
entries is required, when a return should be submitted as above prescribed. The head of the office
will impose on some specified subordinate the duty of annually carrying out these orders in respect
of every ministerial subordinate concerned
103. Responsibilities of Superintendent.
- The Superintendent or head ministerial officer of Collectorate is generally responsible for the
conduct of every branch of the duties of the establishment, and is bound to bring immediately to the
notice of the District Officer with the express purpose of obtaining the effectual interference of
higher authority, any malpractices among the ministerial officers of which he may become aware. IfBihar Board's Miscellaneous Rules, 1958

he neglects to do so, he is liable to instant dismissal for connivance. A plea of ignorance of such
malpractices will be received as an admission of unfitness for the high and responsible duties of his
office
104. Prosecution, dismissal and suspension of Deputy and Sub-Deputy
Collectors.
- On a prima facie case being made out against a Deputy or Sub-Deputy Collector of having
committed an offence as a public servant, an immediate report should be submitted to the
Government and sanction of Government obtained under Section 197 of the Criminal Procedure
Code before the prosecution begins. Similarly if a District Officer considers it necessary that a
Deputy or Sub-Deputy Collector should be suspended he should submit an immediate report to
Government through the Commissioner, but pending the orders of Government, it is open to him to
relieve the officer concerned of the charge of the Department which has been placed under his
control.
Chapter VI
Office Practice and Routine
105. Hours of attendance.
- The hours during which a magisterial and revenue officer is expected to be present in his office for
the despatch of business are from 10.30 a.m. to 5 p.m. unless with the sanction of the Commissioner
some other hours are fixed. When offices are held in the morning, the exact dates being settled in
consultation with the heads of other offices or court in the station, the hours of attendance should be
from 7.30 a.m. to 11.30 a.m. leaving it open to the head of the office to require attendance after 11.30
a.m. until the day's work is finished or for an hour or two later in the day, according to the general
convenience of the staff.District Officers at district headquarters and Sub-Divisional Officers at
Mufassil Sub-Divisions are responsible for seeing that the gazetted officers subordinate to them
attend court punctually, and should make surprise visit to the courts concerned occasionally to
enforce this. At headquarters this may also be done by the Additional District Magistrate, where
there is one, or by the Senior Deputy Collector.The following procedure regarding the attendance of
clerks in offices should also be strictly followed :-The attendance register for the clerks of the office
should be placed before the gazetted officer-in-charge of the office within 10 minutes of the time
fixed for its opening. He will mark all clerks who have not signed the attendance register by then and
will keep a monthly record of the number of days in each month for which each particular clerk has
been late in office. Where it is found from this record that a clerk is late in attending office on more
than three days in any one month, without good reason, a remark to this effect should be entered in
his character roll.Bihar Board's Miscellaneous Rules, 1958

106. Diary to be kept by all Revenue Officers.
- All revenue officers shall keep a diary in the form prescribed by the High Court in their Circular
Order No. 8 and General Letter No. 6 of the 10th September, 1892, and shall insert therein on the
cause lists, immediately after the lists of criminal cases, a statement showing the details of the
different kinds of revenue work done during the day.
107. Case diaries.
- In case diaries maintained by revenue officers a list of the year's holidays should be posted on the
inside of the cover and at the end of each month the clerk concerned should note in the diary each of
the days in next month but one that is a holiday. Care should be taken to see that cases are not fixed
for hearing on holidays.
108. Officers to be in proximity to their respective Department.
- The Collector should see that a Deputy Collector or Sub-Deputy Collector in charge of a revenue
department sits in proximity to that department (though this, owing to existing structural defects in
office buildings, may not always be possible) so that he may exercise control and simultaneously
save the time of clerks, which is otherwise wasted in journeys to and fro. Care should likewise be
taken to see that a Deputy Collector or Sub-Deputy Collector in charge of a department knows what
is the standard out-turn of work which he should expect from his subordinates.
109. Distribution of work among Deputy and Sub-Deputy Collectors.
- In distributing work among Deputy and Sub-Deputy Collectors, the Collector should bear in mind
that the services of an officer can be more fully utilised by a combination of revenue and judicial
functions than by restricting him to one particular kind of work. It is permissible to depart from this
principle in the case of rent-suit officers should a Collector or Deputy Commissioner think such a
course advisable but it has to be remembered that it is essential that every officer should have a
thorough training in general administrative work, and long confinement to a particular branch
would militate against the attainment of the object.
110. Change of Charges.
- At the same time constant changes in the charge of departments cannot be too strongly
deprecated. Corruption and dishonest practices on the part of the subordinate staff are facilitated
and the officers themselves have not the same incentive to work as under a definite policy of
continuity which brings home to each officer from the outset that he will get the future credit or
blame for the state of his departments. An officer should be appointed to a department or group of
departments while he remains in the same district for as long as experience shows that he can give
best work there. If he goes away temporarily on leave before a change of charge is called for, he
should resume charge on his return.Bihar Board's Miscellaneous Rules, 1958

111. Deputy Collector not to be employed on trifling duties.
- A Deputy Collector is not to be employed upon duties which cannot possibly pay for his salary, or
even travelling allowances which as for instance, searching for small estates. A Collector is
responsible for any waste of time of his sub-ordinates in unnecessary travelling or profitless employ.
112. Duties of Sub-Deputy Collectors.
- Sub-Deputy Collectors are ordinarily vested with criminal powers and, their duties, whether
magisterial, executive or revenue, are similar in kind though lower in degree to those ordinarily
entrusted to Deputy Magistrates and Deputy Collectors
113. Duties of the Superintendent of a Collectorate.
- The Superintendent is responsible for the conduct of business in every branch of the Collectorate
as laid down in Rule 103 above. In addition to general supervision he should also perform the
following duties, in particular, with a view to ensuring smooth working and effective control over the
entire office :
1.Distribution of daily dak and files returned
fromthe Collector. [SeeRule 124 of the Bihar
Records Manual, 1941.]
[Substituted by C.S. No. 21, dated
16.2.1970.]
2.Dealing with files relating to appointments,
leaveand transfer, etc., of the ministerial staff
of the Collectorate.  
3.(i) Distribution of work among the clerks and
tosee that each clerk is fully employed.  
 (ii) Signing orders of the following description:-   
 (a) to file papers in a case or record them in
theoffice; [SeeRules 130 (3) of the Bihar
Board's MiscellaneousRules,
1958.] [Substituted by C.S. No.
21, dated 16.2.1970.]
 (b) to return exhibit, etc., to the owners;  
 (c) to give copies of decrees, judgements
orpapers; 
 (d) to call for a report or explanation from
anyministerial officer; and 
 (e) to make over papers of any description to
theministerial officer concerned. 
4.Checking of bills, budget and monthly
statements ofexpenditure.  Bihar Board's Miscellaneous Rules, 1958

5. Checking ofNazarataccounts-  [SeeRules 332 and 333 (Note 2)
of the Bihar
Board'sMiscellaneous Rules,
1958.] [Substituted by C.S. No.
21, dated 16.2.1970.]
 (i) General Cash Book.   
 (ii) Subsidiary Registers.   
 (iii) Registers of saleable forms and maps.   
 (iv) Contract Contingent Registers,
GeneralTreasury, processes etc., (including
maintenance of furniture).  
 (v) Non-contract Contingent Registers.   
 (vi) Cheque receipt books.   
 (vii) Register 43-A.   
 (viii) Bills relating to typists' and
Copyists'remuneration.  
6. Checking of Attendance Registers.   
7.Checking ofTauzi, Cess and
Khasmahalaccounts. [SeeRules 15 and 16 at pages
41-42 of the Bihar andOrissa
Tauzi Manual, 1923, relating to
Tauzi and Cess accountsonly and
Rule 112 at page 45 of the Bihar
Government EstatesManual,
1941.]
8.Checking of all departmental registers
(includingfine registers). [SeeRule 6(i) at page 1 of the
Bihar and OrissaRegister and
Return Manual, 1932.]
9.Checking of all reports and returns before
theirsubmission to higher authorities.  
10.Checking of indents for forms and stationery
madeby the various departments. [SeeRule 124 of the Bihar Board's
Miscellaneous Rules,1958,
relating to stationery indents.]
11. [
[Substituted by
C.S. No. 21,
dated
16.2.1970.]Half-yearly inspection of all departments
ofCollectorate and Sub-Divisional Offices and
annual inspection ofall Anchal/Block Offices.]  
11-A. Periodical inspections of the offices of
theManagers of the Ward and Encumbered
Estates which are located atthe headquarters
stations of the districts in the Chota [SeeRule 216-A of the Bihar
Wards Manual, 1941, asinserted
by Correction Slip No. 38, dated
the 28th February,1947.]Bihar Board's Miscellaneous Rules, 1958

NagpurDivision.
12.Comparing of Register A of the
CertificateDepartment with Register IX of the
requiring officers with a viewto see that all
realisations in certificate cases are dulyentered
in the registers and the orders passed on the
caserecords are duly complied with. [SeeInstruction 46(1) of Board's
Instructions ChapterVI, page 124
of the Bihar Certificate Manual
1937, read with Rule6(i) at page 1
of the Register and Return
Manual.]
13.Checking of the correctness of court-fee
stampsaffixed to all plaints and petitions in
Rent Suits, RentExecution, Rent Miscellaneous
and Rent Deposit cases, petitionsunder the
Demarcation Act; requisition for
certificates;petitions under the House Rent
Control Order, etc.  
14.Checking the daily progress of temporary clerks
ofLoans and Landlord's Fee Departments.  
15.Affidavits by parties in all Revenue
cases,particularly relating to Rent Suits.  
16.Supervision of the preparation of Annual
LandRevenue Administration Report.  
17. Dealing with Elections.   
18.Work relating to village headman under
Section 45,Criminal Procedure Code and the
Bihar Village CollectiveResponsibility Act.  
19. Checking of pending list of various department.   
20. Supply of uniforms and liveries of peons.   
The Collector may, in his discretion, allot any other duties to the Superintendent in addition to those
enumerated above.[Note 1. - The Head Clerks of Sub-Divisional and Anchal Offices will be deemed
to be Office Superintendents for purposes of Rules 103 and 113 in respect of their relative offices
except that they will not be concerned with items 11 and 11-A under Rule 113 but they will do
half-yearly inspection of all Sections of their respective offices. [Inserted by C.S. No. 21, dated
16.2.1970.]Note 2. - Where there are more than one Office Superintendent in a Collectorate, the
Collector will divide the work outlined in Rules 103 and 113 among them equitably keeping the
Establishment Section under the Senior Office Superintendent in accordance with Chief Secretary's
letter No. R-2-302/56-C.R. - 366, dated the 9th July, 1958.]
113A. [ [Inserted by C.S. No. 21, dated 16.2.1970.]
A statement of inspections of ministerial officers should be submitted on or before 30th April each
year to the Divisional Commissioner concerned by a District Officer in the form below:Statement of
Inspections by Ministerial Officers in the district of..........of the year......](A)For Anchal OfficesBihar Board's Miscellaneous Rules, 1958

Name of
AnchalDate of inspection by Head Clerk of
the AnchalDate of inspection by Office
SuperintendentRemarks
 
(B)For Sub-Divisional Offices
Name of
Sub-DivisionName of
DepartmentDate of inspection by the Head
Clerk of the Sub-DivisionDate of inspection
by the OfficeRemarks
 
(C)For District Offices
Name of District Name of Department Date of inspection by the Office Superintendent Remarks
  
Failure to do the prescribed inspections by the aforesaid ministerial officers should be viewed as a
serious dereliction of duty in a particular year and visited with suitable punishment.
114. List of officers and ministerial heads-in-charge.
- In each department should be kept hung up a statement showing the names of gazetted officers
and ministerial heads-in-charge of such department, and the date when each took and relinquished
charge. Care should be taken that this statement is kept upto date.
115. Work Card.
- Since cases have occurred in which, it being necessary to prove who was directly responsible for
the entries in a particular register, such proof was not forthcoming owing to the absence of any
record fixing such responsibility. Government direct that in future, each clerk or moharrir in a
Collector's office shall keep a card showing the particulars given in the following form :-
{|
Name of| MoharriarClerk
| Department|}
Nature of work
Authorised registers Unauthorised registers Miscellaneous duties Remarks
 
This card is to be signed by the Superintendent and the clerk or moharrir concerned, and a duplicate
of the same, similarly signed, is to be kept by the ministerial head of the department to which the
clerk or moharrir belongs. Such ministerial head of the department will be responsible for having all
charges in the nature of the work of each officer under him duly entered on the cards affected.
116. Registers and books on clerk's table.
- On a clerk's table, registers and book must so far as possible be arranged vertically and use should
be made of movable iron supports to keep the volumes upright. On the back of each register, when
they are arranged vertically, should be a label showing what the register is, and where they areBihar Board's Miscellaneous Rules, 1958

arranged lengthwise, this should be entered in ink on the edges of the leaves of the short side facing
the clerk.Correction slips to be inserted in their proper places. - Correction and addition slips should
be forthwith inserted in their proper places as soon as received, a note being at the same time made
in the form given at the end of each manual.
117. Note-books.
- The ministerial head of each department should keep a note-book, alphabetically arranged in
which should be entered references-as for instance, the number and year of the collection and file-to
important orders and precedents relating to his department. This note-book should be handed on by
the head of the department to his successors. The Deputy Collector-in-charge and the Collector
should occasionally examine the book in order to test the nature of the entries and in order also to
obtain some fair idea of the officer's business capabilities. Such a book properly maintained and
referenced would diminish considerably the labours of the record-keeper, who is often called upon
to search blindly for correspondence and precedents.
118. Note-book to be kept by Personal Assistant to Commissioners, etc.
- The Personal Assistants to Commissioners of divisions should each have a lettered note-book,
chronologically arranged in which note should be made (with suitable cross references and with
reference to the appropriate collections and files) of important rulings and precedents not to be
found in the Board's Manuals or the "Handy book of Reference" and of orders of Government the
Board and the Commissioner in important matters affecting the division.The note-book should be
handed on by each Personal Assistant to his successor and the fact recorded in the report of making
over charge. This Rule also applies to Personal Assistant to Commissioner of Excise.
119. Confidential note-book.
- District and Sub-Divisional Officers are also required to maintain a confidential note-book to be
passed on by each officer to his successor.
120. Guard file of Government Circular Orders.
- Two guard files of general circulars arranged chronologically, one for those of the Government of
India and the other for those of the Provincial Government, should be kept by the English Head
Clerk.The circular orders of the Board should be kept carefully in files and new circulars received
should at once be added to the files.
121. Typewriter and its use.
- Every typewriter must be in the charge of a particular clerk, and when anyone other than such
clerk uses the machine, the latter must take from the former an acknowledgement that he takes over
the machine in good order, and must, on taking the machine back, satisfy himself that it is in properBihar Board's Miscellaneous Rules, 1958

order, if it is not, report the fact at once to the head of his department.
122. Care of typewriting machines.
- In many offices typewriting machines are not kept in proper order with the result that the
machines wear out much sooner than they ought to. The attention of clerks in charge of typewriter
should be called to the following instructions :-(a)Each machine must be thoroughly tested every
morning before the work commences;(b)The rods on which the carriage runs should be cleaned with
a slightly oiled cloth;(c)Nothing but the typewriter oil provided for the purpose should be used
(thick oil clogs the working parts of the machine);(d)All types must be cleaned each morning,
especially, the letters a, e, o, b, c, g, p and q;(e)The "full stop" and "comma" are sharp pointed
characters and should, therefore, be hit lightly when typing;(f)The wheels on which the carriage
runs should oiled once a week;(g)Never try to re-ink a ribbon worn out, get a new one. A ribbon
should last 3, and a pad 12 months at least;(h)When requiring to raise the carriage, raise with the
left hand "Carriage lift". This should not be done more than necessary; it wastes time.The above
work will take five minutes, and should be carried out every morning before commencing work,
except where otherwise provided. Failure to carry out these instructions should be treated as
disobedience of orders. A copy of these instructions should be affixed to a file-board and kept hung
up near each machine in use.
123. Use of pen carbon process of duplication.
- The system of duplication by pen carbon paper should be adopted in all departments of the
Collectorate, where duplication of receipt, notices and the like is required.
124. Maintenance and verification of stationery register.
- The system of issue of Government stationery on any purpose other than public service is strictly
prohibited. The stores of stationery are to be placed in charge (under lock and key) of a responsible
clerk and are to be issued by him. He should keep an account of the receipts and issues of stationery
in a book (Form No. 113 in Schedule LIII) in which all issues must be acknowledged by the signature
of the officer who receives the articles. The account is to be balanced monthly by the clerk incharge
and checked by the ministerial head of the office who shall note in the book that he has done so with
any remarks as to defects which may have been disclosed.
125. Prompt drawal of certain bills.
(1)Charges on account of travelling allowance shall be billed for during the month in which they are
incurred or during the following month.Arrear travelling allowance bills shall be sternly discouraged
and before being admitted, the bill for the month concerned shall be examined to see whether
theclaim has been noted as outstanding. If admitted, bill no. in which the arrear charge is being
drawn shall be noted thereon, and the accountant shall certify on the office copy of the arrear bill
that-"the charge was or was not shown as outstanding for the bill for the month concerned and hasBihar Board's Miscellaneous Rules, 1958

not since been drawn."The travelling allowance bills of non-gazetted staff, e.g., clerks and peons of
different departments should be checked by the bill clerk of the Collectorate and certified by the
officer-in-charge of the department concerned before they are put up for counter signature to the
Senior Deputy Collector or the Collector.(2)Bills for compensation paid to proprietors for rent of
lands appropriated for military cantonments must be submitted for adjustment within three months
from the date of the first sanction of the compensation by the competent authority.
126. Bill Clerks to retain Acquittance Rolls.
- The pay of establishment of District Officers should be disbursed ordinarily by treasurers but in
districts where there are no treasurers, the Nazirs should distribute it. They should not retain in
their custody the acquittance rolls which should be made over to the bill clerk of the office.The bill
clerk and the treasurer or the Nazir, as the case may be, are required at least once in every alternate
month to make a joint examination of undisbursed pay in order to ensure that the provisions of
Financial Rule 77 of the Bihar and Orissa Account Code are complied with.Note. - In order to
prevent frauds in connection with the preparation of establishment bills and the disbursement of
their proceeds, the Provincial Government have prescribed the following instructions for the
guidance of disbursing officers:-(1)When a drawing officer signs an establishment bill, he should
satisfy himself that its total agrees with the total of the acquittance roll. Before the proceeds of the
bill are actually paid out to the recipients, the acquittance roll should be checked either by the
drawing officer or a responsible subordinate who should not be the clerk who prepared the bill. In
checking the acquittance roll, he should satisfy himself that the component items are correct and
that the total is correct and agrees with the total of the establishment bill and the money received
from the treasury.(2)When the drawing officer signs an absentee statement accompanying an
establishment bill, he should see that a diagonal line is drawn cross the blank space, if any, below
the last entry. Similarly, if the statement is blank he should see that a diagonal line is drawn across it
with the word "blank" in brackets in the middle of the line.(3)It should be arranged, wherever
practicable, that disbursements are not made by the clerk who prepared the establishment bills.
127. [ Order-sheet. [Substituted by C.S. No. 7 dated 27.8.1963.]
- For all records of revenue cases and proceedings there shall be an order-sheet, in the prescribed
printed form. In the first column of the order-sheet, which is meant for the entry of the serial
number of the order with date, the serial number of the order must invariably, be noted, and below
the serial number should be noted not only the date, but also the month and year. In the second
column of the order-sheet, the writings in the pen of the clerk, if any, should be confined to a bare
statement of facts, or orders of a purely routine character, e.g., "so and so, has petitioned for time"
or "so and so has applied for L.l. Loan for such and such amount. Forward the application for
enquiry to, so and so", etc., but the effective and operative part of the order must be written out in
the officer's own hand or typed to his dictation (to be duly corrected and certified by him) and the
officer should sign his name in full and not merely initial below the order. If the officer's signature is
not easily legible, he should also write his name in block capitals below the signature so that there is
no difficulty in knowing at any time on reference to the order-sheet, which particular officer has
passed the order. The slovenly practice, unfortunately increasingly frequent, of initialling only, or ofBihar Board's Miscellaneous Rules, 1958

merely noting the date and month (and not the year) in the order-sheet should cease. The third
column of the order-sheet meant for noting compliance of the order, must invariably be filled up by
noting details of compliance, e.g., number, date, month and year of process issued, or number, date,
month and year of the letter despatched and officers should insist on the compliance column being
duly and properly filled in, as it will enable the officer-in-charge as well as Inspecting Officers, to see
at a glance how promptly or with what laxity, the order passed are complied with, and will serve as a
test of the efficiency of the peshi and clerical work.]
128.
[x x x x] [Deleted by C.S. No. 46 dated 10.11.1956.],
129. Procedure for issue of letters from the Commissioner's office over
signature of their Personal Assistants.
- In order to relieve the pressure of work of Divisional Commissioners, the Personal Assistants,
besides addressing Government in certain matters, may also sign fair copies of the drafts approved
by the Commissioners. As Government desires to have benefit of the views of the officers of the
seniority and experience of Commissioners of Divisions, they should not rest content with recording
their views on their files only but should finally approve the drafts also which should record their
views in their entirety; fair copies of such finally approved drafts may be signed by their Personal
Assistants, if the Commissioner is unable to do so due to the pressure of work or due to his absence
on tour. In special cases when the Commissioner is out on tour and an urgent communication has be
to issued based on an order passed by him, the letter should be issued in the name of the Personal
Assistant and should open with the words- "In the absence of the Commissioner on tour, etc". The
Personal Assistant may issue and sign a letter on his own responsibility in routine matter.
130. Relief of Officers.
- In order to relieve revenue officers as far as possible of the mechanical labour of signing papers,
the following practice is authorised:-(1)Board's and Commissioner's offices. - The Superintendent of
the Board's office and Personal Assistant to Commissioners are authorised to sign reminders,
dockets and other formal letters and to authenticate copies, etc.(2)Head clerks. - The Head clerks in
a Commissioner's and Collector's office may authenticate, with his English Signature, copies of
letters, statements, decisions, etc.(3)Superintendent of Collectorate may sign orders of the following
descriptions-(i)to file papers in a case or record them in the office;(ii)to return exhibits, etc., to the
owners;(iii)to give copies of decrees, judgements, or papers;(iv)to call for a report or explanation
from any ministerial officer; and(v)to make over papers of any description to the ministerial officer
concerned.Note. - The Superintendent is entirely responsible for every order he signs, if in any case
he has doubt what order ought to be passed, he will of course, obtain the orders of the presiding
officer. If however, from adventitious circumstances the date of character of an order is likely to be
important, the executive officer should himself sign it.(4)Receipts for registered letter. - Receipts for
registered letters addressed to the Collector of a district may be signed by any person connected withBihar Board's Miscellaneous Rules, 1958

the Collector's office, or who may be authorised by the Collector to sign. District Officers are to issue
a formal office order naming the person or persons whom they may authorize to sign post receipts
for registered covers. The person signing a receipt for a registered cover is invariably to open it
himself and satisfy himself in regard to its contents. The responsibility for its content will then rest
with him, unless he can show how he has disposed of them.
131. Responsibilities of ministerial officers to be enforced.
- Collectors are to be careful that no ministerial officer is permitted to evade his obligations,
particularly in the way of authenticating books, documents, accounts, etc., by his signature.
132. No report.
- Report from one branch of an office to another should be avoided.
133. Procedure for excluding public from rooms occupied by clerks etc. in
Collectorates.
- With the view to the better conduct of business in Collectorate offices, Government have directed
that a wicket gate with a spring shall be placed at the entrance to each office room occupied by clerks
or Muharrirs or copyists. Inside each such office is to be kept a list showing who are officers entitled
to occupy the room; outside the entrance to the room should be hung, in a conspicuous place a
board having printed on it both in English and the Vernacular"No admittance for the public". The
Collector and the Deputy Collector-in-charge of a department should visit at unstated times during
office hours the room occupied by his subordinates and call the roll, and in the event of his finding
any outsider within the room the ministerial head of the department should be punished since he is
to be held responsible that the public do not enter the room.
134. Communications regarding their leave, etc., by Government Officer at
public expense prohibited.
- Government officers are not entitled to send communications regarding their leave, pay transfer,
allowance funds, subscriptions and analogous matters at the expense of the State. Such
communications are private and not official and should not therefore be sent at public
expense.Chapter-VII Kanungos
135. to 146.
- Rules 135 to 146 deleted vide C.S. No. 48 dated 12.3.1957.Chapter-VIII Ministerial and
Non-Gazetted OfficersBihar Board's Miscellaneous Rules, 1958

147. Probationary clerks in divisional, district and sub-divisional offices.
- The posts of probationers in district and divisional offices were converted into probationary clerks
with effect from the 1st September, 1944, in district and sub-divisional offices and from the 1st
February, 1945, in divisional offices. The ministerial cadre in these offices was in consequence
permanently increased by fifteen per cent. In divisional offices, the posts of probationary clerks are
temporary or permanent according to the nature of corresponding posts of probationers in the
General and the Wards Department of those offices. Each of these posts will carry a pay of *Rs.
50-2-70-EB-2-90 a month. Appointments to these posts will be made after advertisement, at the
discretion of the head of the office as laid down in Rule 151, only when vacancies actually occurs in
the cadre of the office concerned. The Commissioner or the District Officer may fill any vacancy after
considering the suitability of the temporary clerks already employed in his office alongwith other
candidates. Preference should however, be given to the temporary clerks when other things are
equal or almost equal. [Now 1200-30-1800 as per Revised Pay Scales.]Note. - In case of an
appointment in the upper division requiring special qualifications it is open to the Commissioner or
the District Officer to appoint an outsider possessing such qualifications.
148. Selection of ministerial officers.
- All probationary clerks in Commissioner's Offices should be selected by Commissioner and in
district and sub-divisional offices by District Officers with due regard to the orders of Government
relating to the representation in Government service of members of scheduled castes and backward
classes and tribes, provided that suitable candidates belonging to these castes, classes and tribes are
available. A candidate for a vacant post must fulfil the following conditions:(a)He must have passed
the Matriculation Examination or must hold the School leaving certificate for high schools. He must
also have a good knowledge of Hindi written in Devanagri script, which is language of the
State.Note. - (i) Government recognise the final passing out of examination of the Indian Mercantile
Marine Training Ship "Dufferin" and certain examinations of National Universities mentioned in
Appendix Z and also the Junior Cambridge Examination and the Indian Army first class English
Certificate as equivalent to the Matriculation examination for purposes of entry into public service
in this province.(ii)[ As knowledge of typewriting is valuable for almost all clerks it should count as
an additional but not indispensable qualification.] [Substituted by C.S. No. 31 dated
20.1.1984.](iii)Preference will be given to candidates who are natives of the province or domiciled
therein, if otherwise qualified.(b)He must not be over 25 years of age.(c)He must produce a
certificate of good moral character from the school or college in which he was last educated or from
some respectable householder to whom he is well known in private life and who is himself known to
a gazetted officer of Government, the last fact being certified by the counter signature of the officer
in question.Exception. - If no candidate is available with the qualification prescribed in clause (a)
above, an examination of candidates qualified under clauses (b), (c) and (d) above will be held after
due notice.This examination will be in English composition to test, (i) handwriting, (ii) knowledge of
English, and (iii) general ability. It will be held by the District Officer or Commissioner, as the case
may be, or by any subordinate gazetted officer to whom he may delegate the duty.Bihar Board's Miscellaneous Rules, 1958

149. Period of probation.
- A probationary clerk will ordinarily remain on probation for two years. He can draw the first
increment one year after the appointment, but if not confirmed at the end of the second year he will
draw no further increments till he is confirmed when he will draw pay at the stage he would have
drawn if his increment had not been withheld.
150. Conditions of service of ministerial officers in district and sub-divisional
offices.
- All clerks including probationary clerks are appointed for the district as a whole and are liable to
serve in any department and in any sub-division in which their services may be required.
151. Filling up vacancies in ministerial posts.
- The rules for the guidance of officers making appointments to ministerial or other posts in Bihar
will be found in Appendix H. They apply to all appointments not made under any special rules and
orders. In the case of every vacancy either in the upper or lower division in which the Commissioner
or the District Officer contemplates introducing an outsider, a notice of the vacancy should, in
addition to the advertisement made in the Bihar Gazette and in the principal newspapers circulating
in the province as enjoined in the said rules, be suspended in some prominent place in their offices
and a date which shall not be less than 15 days after the issue of the notice shall be fixed for filling up
the vacancy. It should also be made clear in the notice and the advertisement that travelling
allowance will not be given to the successful candidate.On the date fixed for filling up the vacancy,
the Commissioner or the District Officer shall examine all the applications or wherever possible
shall see and examine all applicants and the certificates and shall record a proceeding stating that he
has done so, noting in detail the claims of all eligible candidates and giving his reasons for the
selection ultimately made. This proceeding together with the applications and certificates filed and
the notices of the vacancy shall be made into a regular record bundle for reference in case of any
appeal being made against the appointment. An officer's choice in appointing ministerial officer is
not limited to his own district or division. No appeal shall lie to the Commissioner from an outsider
or a ministerial officer, dissatisfied with an appointment made by a District Officer, on the ground
that his merits and claims have not been duly considered.Note. - The people of a district should
receive preferential treatment in the matter of ministerial appointments to be made in that district,
provided their qualifications for the posts to be filled are sufficient for the purpose of appointment
to those posts, provided that this can be done without sacrificing the requisite standards of
efficiency of the public service. The Rule obtaining in Chota Nagpur district and in the district of the
Santhal Parganas in regard to giving preference to the aboriginals should therefore be made
applicable to other inhabitants also of those districts and to inhabitants of other districts in the
province, though between the aboriginals and the non-aboriginals, the aboriginals should be given
preference.In any district when a vacancy in the first grade appointment occurs and that district has
a competent staff which has already enjoyed a fair degree of promotion, the Commissioners of
divisions in filling the vacancy are empowered to assign to it the pay of second or third gradeBihar Board's Miscellaneous Rules, 1958

appointment and to assign the pay of a first grade appointment to some district which is graded as
second or third and where there is a deserving man who ought to receive promotion.
152. Stamp duty on applications for appointments.
- Application for appointment in revenue offices are not liable to stamp duty.
153. Relationship of applicants to any Government servant to be stated.
- All candidates for employment either as a probationary clerk or in a temporary or permanent post
in the offices of Commissioners and District Officers should be required to state whether they are
related to any person already in service of Government in all the offices of the divisions or district or
elsewhere, and if so, to specify the names of such employees and the nature of employment, held by
each of them. Relationship to any such person does not disqualify a candidate, but there must be no
concealment of truth. Any incorrect or incomplete statement will render the maker, if appointed in
due course, liable to summary dismissal.
154. Medical certificates.
- When called upon by a competent authority, Civil Surgeons are required to examine and grant
health certificates to selected candidates for Government service, free of charge in the form
prescribed for the purpose. A fee of Rs. 4 is however, payable for the health certificate by a
probationary clerk and, in other cases, by a person who is a candidate for an office. No person
appointed permanently or temporarily to a post even on probation, can be permitted to join without
producing a medical certificate of health under Rule 52 of the Bihar Service Code.Note. - The term
"selected candidates" includes only those persons who can produce a requisition for medical
examination from an officer who is making an appointment to a post under Government, supported
by a certificate to the effect that they have been selected for that post subject to their obtaining a
medical certificate.
155. Appointment of ministerial officers.
- Ministerial officers should not be kept acting on probation for an indefinite period; one or two
months should suffice to test a man's fitness for office nor are they to be employed on lower salaries
than those sanctioned for the offices to which they are appointed.
156. Division of ministerial appointments into upper and lower.
- Ministerial establishments under Commissioners and District Officers comprise upper and lower
divisions. The former consists of specific posts for which special salaries have been fixed. The lower
division in district office contains appointments on time-scale of pay which is independent of the
post occupied. Appointments in the upper division are to be made with regard to special fitness for
the post and unless other considerations are equal, seniority is not to be regarded in filling them.Bihar Board's Miscellaneous Rules, 1958

Appointment and promotion in the lower division of Commissioner's offices depend upon seniority
subject to approved service. In the matter of appointment and promotion the district staff is to be
treated as a whole and care must be taken that the staff at sub-divisions shall receive equal
consideration with that at headquarters. Although the district and sub-divisional establishments are
amalgamated. District Officers are not at liberty to inter-change the salaries attached to particular
appointments in the upper division among the different branches of their own and sub-divisional
offices in such manner as may from time to time be found convenient.Note. - A clerk on the
time-scale in district offices deputed to a post outside the time-scale should retain a lien on his post
in time-scale.
156A. [ [Substituted by C.S. No. 22 dated 16.2.1970.]
All permanent and temporary clerks in the Lower Division Scale of Rs. [1200-30-1800], in the
District and Sub-Division Offices will be allowed to cross the first efficiency bar at [Rs. 770] [Now
there is no E.B. in the Revised Pay Scales.] if they have passed the preliminary examination in
accounts. Crossing of the second efficiency bar at [Rs. 145] [Now there is no E.B. in the Revised Pay
Scales.] will be allowed by the Head of Office on the basis of satisfactory work of the concerned if he
is found to be efficient.The ministerial officers in the Collector's and Commissioner's Offices will be
allowed to cross the efficiency bar at the Upper Division or Selection Grade if their work is found to
be satisfactory and they are considered to be efficient.]
156B. Conditions for crossing the efficiency bar in the prescribed scales of
pay applicable to clerks of the Divisional Forest Offices.
- (i) For crossing the efficiency bar in scale IV, [Rs. 1200-30-1800] [Vide Revised Pay Scales.] the
clerks will have to pass the preliminary accounts examination prescribed under Rule 157 of the
Board's Miscellaneous Rules, 1958.(ii)For crossing the efficiency bar in scale III, [Rs.
1200-30-1800] [Vide Revised Pay Scales.] the clerks will be required to pass the final examination
in accounts prescribed under Rule 157 of the Board's Miscellaneous Rules, 1958.
156C. [ Appointment to Lower and Upper Division posts of Assistants in the
office of the Conservator of Forests, incharge of Circles. [Inserted by C.S. No.
26 dated 4.1.1976.]
- (i) Appointment to posts of Lower Division Assistant in Conservator of Forest Office will be made
by the respective Conservators from the list of successful candidates. The candidates will be
examined in two papers viz., (i) Precis writings and Essays, and (ii) General Knowledge.And will be
required to obtain at least 50 per cent marks in each subject to qualify for appointment. The
selection will be made by the Selection Board constituted by the Chief Conservator of Forests, Bihar
for the respective circles.(ii)For promotion to the post of Upper Division Assistants in Circle Officer,
Rule 157(3)(J) corrected will be followed.]Bihar Board's Miscellaneous Rules, 1958

157. Rules for the Examination in Accounts.
(1)The following rules have been prescribed by Government for Examination at which all ministerial
officers of Muffasil Departments under the administrative control of Government will be eligible to
appear and those who secure therein 60 per cent marks or above will be declared to have passed the
final examination while those who secure marks 40 per cent and above but below 60 per cent will be
declared to have passed preliminary examination.Note. - Permanent assistants and permanent Class
I Stenographers in all Departments of Secretariat and all offices of the Head of Department as listed
in Appendix 3 to the Bihar Service Code, with the approval of the respective heads of these offices,
may also sit for the examination in accounts, provided that they will not be allowed more than two
chances to pass the examination.
2. Every candidate for examination shall at least six weeks before the date
fixed for examination give through his immediate superior notice to the
District Officer, who will be incharge of the examination, of his intention to
appear at the ensuing examination by application in writing in his own hand
containing the following particulars:-
(i)Name.(ii)The Department of Government to which he belongs.(iii)The time-scale of pay with
present pay.(iv)A general description of the work in which he has gained experience. The District
Officer will then prepare a consolidated statement, including the candidates of the Collectorate and
Sub-Divisional Offices and other offices situated in the District and send a copy of the same to the
Board one month before the date of the examination.
3. There will be two papers of three hours each. The arrangement for
examination will be as under:-
(A)Questions will be set for the first paper by the Secretary, Board of Revenue from-(a)Introduction
to the Indian Government Audit and Accounts, Chapters 2(a), 6, 7, 8, 10, 12 and 16.(b)Accounts
Code Vol. I-Chapter 6 only.(c)Bihar Treasury Code Vols. I and II.(d)Board's Miscellaneous
Rules-Chapters I to XVII and XXVI.(e)Budget Manual-Chapters I, II, III and IV.(B)Questions for
the second paper will be set by the Finance Department to Government in consultation with the
Accountant General, Bihar, if necessary, from-(a)Bihar Service Code-All Chapters except VIII and
appendices 6, 9,12 and 13.(b)Bihar T.A. Rules.(c)Bihar Pension Rules including Liberalised Pension
Rules.(d)Bihar General Provident Fund Rules.(e)Bihar Financial Rules Volume I and Volume II
(Appendices 1 to 9 only).The use of books will be allowed in answering questions in both the
papers.(C)An additional paper will be added for the candidates of the Forest Department for which
the following books are prescribed:-(1)Forest Manual.(2)Forest Account Code.(3)Forest Department
Code.(4)Bihar Treasury Code Vol. I, Chapter VII, Section II, Forest Department Rules 478 to
511.(5)Accounts Code Vol. III, Part III, Forest Accounts, Chapters V to VII, Articles 240 to 297.The
questions will be set by the Accountant General, Bihar.(D)The total number of marks to be assigned
to each paper will be 150. Marks will also be separately assigned for a full answer to each question
set for the paper. There will be two parts in each of the two papers. The first part will be for 75 marksBihar Board's Miscellaneous Rules, 1958

and will contain simpler question and the second part will be for the remaining marks and will
contain other questions.(E)It will be the duty of the Board to have sets of questions prepared and to
forward a sufficient number of copies of each set in sealed packets to each of the District Officers
concerned. The District Officer in receiving the questions will keep them under lock and key and will
not open them till the time of examination.(F)The examination will be held under the supervision of
the Collector of the District at such places including the premises of the Accounts Training Schools
and under such supervision as he may direct.(G)The examination will be held twice a year and it will
commence on the 2nd Monday of March and September every year or on such other dates as may be
fixed by the Board.(H)On the day of examination the District Officer will himself take questions into
the examination room and distribute copies to the candidates or have the same distributed under his
supervision. When the time allotted for the examination has expired, he will collect the answer
papers and forward them in sealed packets to the respective authorities which set the
questions.(I)The answer books forwarded to the Accountant-General and the Finance Department
will after examination be returned to the Board together with a list showing the names of
candidates, the offices to which they belong and the marks obtained by each. The Board will then
report to Government in the Finance Department the names in order of merit of the clerks who have
passed and offices to which they belong for publication in the Bihar Gazette.(J)[(a) Any clerk, who
has not passed the preliminary examination in Accounts, will be neither confirmed nor be allowed to
cross the efficiency bar; [Substituted by S.O. 401 dated 29.4.1985.](b)A clerk, who has not passed
the final examination, will not be promoted to the selection grade;(c)In case of non-availability of
senior clerk, finally passed in Accounts Examination, any junior clerk, having passed the final
Accounts Examination may be temporarily promoted to the Selection Grade;Provided that the
junior clerk temporarily promoted to the selection grade shall be reverted to the post of clerk if the
clerk senior to him passes the final Accounts Examination within two years from the date of his first
supersession and is promoted with effect from any date within the said two years, otherwise the
senior clerk would be treated junior to all the clerks promoted to the selection grade prior to
him.Explanation. - Under proviso to (c), the date of passing the Examination of Accounts would be
the date on which the examination was held and the post of selection grade held by the junior clerk
shall be deemed to be vacant from that very date for the purpose of promoting senior clerk. But, for
the fixation of pay etc. the junior clerk shall be deemed to have been reverted from the date with
effect from which the senior clerk will be promoted. The seniority of the reverted junior clerk shall
be effective from the date on which he will again be promoted permanent to the selection
grade.](K)Clerks attending these examinations will be treated as on duty and will be allowed
travelling allowance according to the T.A. Rules for the first two examinations only, but there will
however be no limit to the number of times a candidate may appear at such examinations.(L)Clerks
who pass in one paper and fail in the other shall be required to take up the paper in which he failed
at the next examination.
158. Acting allowance permissible in Commissioner's and District Officers'
establishments.
- It is permissible to appoint any officer holding substantively one of the posts in the upper division
of Commissioners, or District Officers' establishments to officiate in any other post carrying higher
pay. An officer so officiating will, in the absence of any special order to the contrary, draw as actingBihar Board's Miscellaneous Rules, 1958

allowance the full amount whereby the pay of the post in which he officiates exceeds the pay of the
post which he holds substantively. Similarly a lower division clerk, officiating in a post in the upper
division will draw the allowance. It will however not be admissible for any officer other than the one
actually performing, whether in a substantive or officiating capacity, the duties of a particular post,
to draw the pay attached to that post.Illustration 1. - The Treasurer of a district officer drawing a pay
of Rs. 150 dies. The man appointed to do the work of Treasurer will draw Rs. 150, the pay of the
post, and no other post in the office will be effected in any way thereby unless the actual work of
treasurer is given to some existing member of the establishment.Illustration 2. - The Head Assistant
in a district office on Rs. 150, goes on six month's leave, and the Revenue Peshkar on Rs. 100 is
appointed to perform his duties. The latter will draw [Rs. 50] [Now Rs. 1200.] as acting allowance, if
a lower division clerk does the Revenue Peshkar's work he will draw his time-scale pay plus acting
allowance equal to the difference between that and Rs. 100. No other change will be made in the
upper division i.e., it will not, for instance be permissible to show the second correspondence clerks
of Rs. 90 as acting in the post of Revenue Peshkar and the lower division clerk as acting as second
correspondence clerk.Exceptions to this principle must not be allowed, even as a temporary
measure, otherwise there will be not merely a breach of the rules but also a grave risk of most
undesirable confusion. Cases may, however, occasionally arise in which a junior may be appointed
to act in a post carrying more pay than the lowest post in the upper division with the result that the
incumbents of these posts feel aggrieved at the grant of higher emoluments to their junior. In such
cases the officer making the appointment should consider in each case whether the full pay should
not be allowed.
159. Temporary ministerial establishment for Additional Deputy or
Sub-Deputy Collectors.
- There is a sanctioned scale of Deputy and the Sub-Deputy Collectors for each headquarters and
sub-divisional office and the permanent ministerial establishments are fixed with reference to the
normal work of the office and the sanctioned scale of Deputy and Sub-Deputy Collectors. When
Additional Deputy or Sub-Deputy Collectors are posted on general duty to district or sub-divisional
headquarters additional temporary ministerial establishment is admissible at a rate not exceeding
one clerk for each provided that no clerk should be appointed for any such officer whilst under
training--an officer being considered under training until he passed the departmental examination
by the lower standard completely. A temporary clerk may, however, be appointed for every
additional temporary or probationary Deputy or Sub-Deputy Collector vested with magisterial
powers irrespective of the fact whether he has passed the departmental examination by, the lower
standard or not. The pay of these clerks will be at a fixed rate of [Rs. 50] [Now Rs. 1200.] each a
month but if the posts of temporary clerks are likely to exist for more than a year they will draw the
time-scale of pay of [Rs. 50-2-70-EB-2-90] [Now Rs. 1200-30-1800.] each a month. When an
Additional Deputy or Sub-Deputy Collector is transferred and is not replaced his extra
establishment may not be retained for more than two months unless his place is filled at the end of
that period.This Rule does not apply in the cases of Deputy Collectors engaged on settlement,
partition or land acquisition for whose special temporary establishments separate rules exist in the
Manuals relating to those branches of work.Bihar Board's Miscellaneous Rules, 1958

160. Powers of Collectors and Commissioners in sanctioning temporary
establishments.
- District Officers are empowered to sanction additional clerks required for additional officers
posted to district and sub-divisional headquarters referred to in the preceding Rule and they should
communicate these appointments direct to the Accountant-General, Bihar. In cases where it is
preferred to entrust the actual duties of the temporary post to a clerk of the permanent
establishment, a temporary post on the time-scale of pay drawn by him may be created for the clerk
concerned and he may be allowed to draw on that scale the pay he would from time to time have
drawn on the same scale in his substantive post provided that if the post of clerk so deputed is filled
up by outside recruitment the pay of the outside will be limited to [Rs. 50] [Now Rs. 1200 vide New
Pay Scales.], but where this post is likely to exist for more than a year he will draw the time-scale of
pay of [Rs. 50-2-70-EB-2-90] [Now Rs. 1200-30-1800 vide New Pay Scales.] a
month.Commissioners are competent to sanction charges on account of establishment retained at a
sub-division for arranging the records of the office left vacant by the removal or death of a Deputy
Collector. Each cases as it occurs, should be reported to Government in the Finance Department for
communication to the Accountant-General.
161. Claim of the members of the temporary establishment to permanent
posts.
- If the officers of temporary establishments working under Additional Deputy or Sub-Deputy
Collectors have a good character, they are to be regarded as having a special claim to re-employment
in case of any vacancy occurring in the permanent establishment in the district. An Additional
Deputy or Sub-Deputy Collector should, therefore, when leaving a sub-division, always report to the
District Officer the manner in which each officer of his establishment has performed his duty.
162. [ Maintenance and custody of Service Books. [Substituted by C.S. No. 1,
dated 16.8.1966.]
- A Service Book with necessary leave account should be opened and maintained for every
Government servant from the date of first appointment. Every step in the Government servant's
official life including interruptions of service, promotions and reductions in rank and pay
(temporary, officiating and permanent), transfer to and return from foreign service, all cases of
suspension, discharge or dismissal, in fact all entries required for verification of service and
determination of amount for pension must be noted in it with full details. A separate register for
service books should also be maintained in the manner prescribed by Rule 299 of the Bihar Service
Code, First Edition, 1952.The Service Books and the Register of Service Book shall be kept in double
locks, one key being in the custody of the Establishment Deputy Collector and the other, of the
Office Superintendent, at district headquarter. In the Sub-Divisions, one key should be kept by the
S.D.O. and the other, by his Head Clerk.Entries in the Service Books should be attested by the
Establishment Deputy Collector at Sadar, and the S.D.O. in the Sub-Divisions. Erasures and
overwriting are strictly prohibited : corrections should be made neatly and attested as above. ThereBihar Board's Miscellaneous Rules, 1958

should be annual verification of the entries, as provided in Rule 298 of the Bihar Service Code, by
the Establishment Deputy Collector at Sadar, and the S.D.O. in the Sub-Divisions. Personal
certificates of character should not be entered in the Service Book unless directed by the Head of the
Department.The Service Book shall not be returned to the Government servant on retirement,
resignation or discharge from service even in cases where he might have paid for it already.]
163. Character Roll.
- Every ministerial or non-gazetted officer should also have (i) a permanent character roll containing
entries, on which an opinion of the value of an officer's works can be properly judged, and (ii) an
ephemeral character roll in which instance of good or bad work can be jotted down as they occur.
The entries in the permanent character roll should relate to the year ending the 31st March each
year and should be recorded not later than the 15th May each year. In order to afford a greater sense
of security against unfair remarks being recorded under the existing system of making available to
the reporting officer the whole character report, the reporting officer should record their annual
remarks on all ministerial and non-gazetted officers using separate sheets each year, which will have
the following columns;
1. Name of the office.
2. Period.
3. Post held during the period.
4. Annual remarks.
When a ministerial or non-gazetted officer has served under more than one officer during the period
under report, all the officers will record their remarks on the same sheet. Before recording their
remarks they will not look into the remarks for the previous year. Where an officer has to serve
under one or more officers who are subordinate to the Head of the office, the remarks will also be
recorded on a single sheet beginning from the juniormost officer in the Office or Department. After
the remarks have been recorded the sheets containing the remarks will be pasted in the permanent
Character Roll of the officer concerned. No subsequent entries need, however, be made in cases
when the head of the office or the officer who had made such entries after March proceeds on leave
or transfer before the end of the following July.In addition entries should continue to be made
whenever the head of the office or the officer empowered to make such entries is changed or when a
ministerial or non-gazetted officer does good or bad work of such a nature that it ought to be placed
on permanent record.Each entry in the ephemeral character roll, as soon as it is made, should be
initialled by the officer who ordered it to be made and by the clerk concerned, who would thus have
an opportunity of knowing what is entered against him. These entries will give the reporting officer
materials on which to base a considered report; it will prevent instances of good or bad work from
being forgotten; and it will keep the permanent roll free from instances of good or bad work which
does not deserve permanent record but are useful as materials on which a permanent record may beBihar Board's Miscellaneous Rules, 1958

based. On the other hand, it will furnish the officer making entries in the permanent roll with data
for estimating the work of those officers who do not personally come before him. This roll should be
destroyed when the reporting officer has made his entry in the permanent character roll after the
end of March or at the time of his transfer as the case may be.The permanent character roll should
be maintained separate from the service book and treated as strictly confidential. It should be kept
in safe custody by the ministerial Head of the office who will communicate only adverse remarks to
the Government servant concerned under the orders of the immediate Head of the office. Copies of
remarks or extracts from the character roll should not be given to the Government servant
concerned either during service or after retirement. The character roll should be retained in office if
and when the service-book is given to the Government servant concerned on resignation or
discharge without fault. A retired Government servant applying for any post may give as a reference
to the Head of the office in which he was previously employed or may submit his application
through the Head of that office to enable the latter to add his recommendations, if any.
163A. [ Procedure for recording remarks in the permanent Character Roll.
[Inserted by C.S. No. 14 dated 9.4.1966.]
- No authority, inferior to a Sub-Divisional Officer should record remarks in respect of ministerial
officers although he may get reports from his subordinate officers before recording his remarks. At
the district level, the Additional Collector and/or the D.D.O. will record remarks in respect of
ministerial officers working under him, after the Sub-Divisional Officer concerned has recorded his
remarks. The Character Roll will then be placed before the District Officer who may record such
remarks as he may like but he is not bound to record remarks in all cases, except in the case of
ministerial head of offices.In the case of Grade IV employees, the officer-in-charge of the office and
in the case of Anchal/Blocks, the Anchal Adhikari/Block Development Officer, will record remarks
about them.An officer recording remarks should not merely depend on the reports received from
subordinate officers but should avail of sufficient opportunities to justify the remarks from his
personal knowledge either through inspections or otherwise.]
164. Distinction between "removal" or "discharge" and "dismissal".
- There is a broad distinction between "removal" or "discharge" and "dismissal". "Removal" or
"discharge" does not bar future re-employment under Government, but the effect of an order for
"dismissal" is to preclude the dismissed officer from being employed again in public service except
with the express sanction of Government. "Removal" should be the penalty in such cases as
unfitness for the duties of an office where it is not thought necessary to bar future re-employment
under Government. The sanction of the provincial Government is required for the re-employment of
a person who has been dismissed. Precautions should be taken that it will prevent the inadvertent
re-employment of such a person. Ordinary cases of dismissal of non-gazetted officers need not be
notified in the Gazette (vide Appendix 1).Note. - (i) The discharge of a person appointed on
probation during or at the end of the period of probation, on grounds arising out of the specific
conditions laid down by the appointing authority, e.g. want of a vacancy, failure to acquire
prescribed special qualification or to pass prescribed test, does not amount to removal or
dismissal.(ii)The discharge of a probationer, whether during or at the end of the period of probationBihar Board's Miscellaneous Rules, 1958

for some specific fault or on account of his unsuitability for the service, amounts to removal or
dismissal within the meaning of this rule.
165. Principle as regards dismissal laid down by the Court of Directors.
- The Court of Directors in their Dispatch No. 42 dated the 6th August, 1851, laid down the following
principle:"We would establish it as a principle that when persons are appointed to permanent
situations in any department, they should not be dismissed upon light grounds. Fraud and
dishonesty, continued and wilful negligence, and all offences involving moral disgrace meet with
their appropriate punishment in dismissal and our position is that in every case in which that
punishment is inflicted upon just grounds the individual should be considered to be permanently
excluded from Government employ."These views have been endorsed by the Government of India in
Resolution No. 37-1309-1404, dated the 29th July, 1879 (vide Appendix J.).
166. Dismissal, removal or reduction in rank.
- (i) Without prejudice to the provisions of the Public Servants Enquiries Act, 1850, no order of
dismissal, removal or reduction shall be passed on a Government servant unless he has been
informed in writing of the grounds on which it is proposed to take action and has been afforded a
reasonable opportunity of defending himself. The grounds on which it is proposed to take action
shall be reduced to the form of a definite charge or charges, which shall be communicated to the
person charged together with a statement of the allegations on which each charge is based and of
any other circumstances which it is proposed to take into consideration in passing orders on the
case. He shall be required, within a fortnight, to put in a written statement of his defence and to
state whether he desires to be heard in person. If he so desires or if the authority concerned so
directs, an oral enquiry shall be held. At that enquiry, oral evidence shall be heard as to such of the
allegations as are not admitted and the person charged shall be entitled to cross-examine the
witnesses called, as he may wish. Provided that the officer conducting the enquiry may for special
and sufficient reasons to be recorded in writing refuse to call a witness.The examination and
cross-examination of prosecution and defence witnesses will be completed within a month.(ii)[ After
the enquiry against the person charged has been completed to impose a penalty has arrived at a
conclusion with regard to the penalty to be imposed, he shall pass such orders as he deems fit.]
[Substituted by S.O. 567 dated 19.4.1989.]Note. - When the orders for punishment are passed by an
authority other than the persons conducting the enquiry it shall be sufficient for the authority
passing orders of punishment to record his agreement or disagreement with the person conducting
the enquiry. Provided that due regard shall be paid to the provisions of Rule 3 of Bihar and Orissa
Subordinate Services Discipline and Appeal Rules.(iii)With a view to securing prompt initiation and
speedy disposal of all departmental proceedings the officers entrusted with the conduct of
disciplinary enquiries particularly in cases of bribery and corruption, while giving reasonable
facilities to the accused to make their defence, should mainly confine themselves to the essentials of
the prescribed procedure and should firmly resist any tendency on the part of accused officers to
adopt dilatory tactics. Detailed instructions regarding the manner in which disciplinary cases are to
be dealt with have been laid down in Mr. L.R Singh's letter No. A-189, dated the 9th January,1953,
which is incorporated in Appendix J. These instructions should be meticulously followed by allBihar Board's Miscellaneous Rules, 1958

officers required to conduct departmental proceedings.(iv)In departmental proceedings the option
of engaging a lawyer at their own cost should be allowed to gazetted officers when formal enquiries
are conducted after the framing of a charge or charges against them. In the case of a non-gazetted
officer, the officer conducting the enquiry should be allowed discretion whether to allow the officer
concerned the option of engaging a lawyer at his own cost or not.
167. Proceedings.
- The proceedings shall be drawn up in the form given in Appendix K and shall contain the following
particulars:-(a)Name, rank and grade of the officer proceeded against.(b)Details of charges. - Each
charge must be specific. Charges should be drawn up and separately numbered and should give the
date, occasion and nature of the offence committed. A copy of the charges should be given to the
officer charged.(c)Defence. - If the officer charged can write, he should be permitted to submit his
defence in writing. The defence submitted in writing should be attached to the proceedings. In cases
of illiterate men the enquiring officer may himself record the defence. The written statement of
defence should be submitted within a fortnight from the date of communication of the charges to the
officer accused.(d)Evidence. - A memorandum of evidence should be prepared. Where the full
statement of witnesses has been recorded in English or Hindi, it should be attached to the
proceedings.(e)Character of the officer charged. - The character roll of the officer should be
examined and a note made regarding the good and bad work done by the officer in the
past.(f)Findings. - The enquiring officer must conclude the proceedings and submit his final report
within two weeks after cause has been shown by the officer proceeded against. Each charge should
be examined in the light of the defence and the evidence and a clear finding on each charge should
be recorded by the enquiring officer.(g)[ Order. - The Officer who is competent to pass orders of
dismissal, removal or reduction in rank should consider the findings alongwith the past records of
the person concerned and if he is of the opinion that any of these penalties should be imposed, he
shall record an order imposing such penalty. If the penalty imposed is other than dismissal or
removal, the order should clearly indicate how the period of suspension if any, should be treated and
at what rate subsistence allowance together with cost of living allowance, house rent etc. is to be
paid.] [Substituted By S.O. No. 567 dated 19.4.1989.]Note. - Final order in a case in which an officer
has been prosecuted should issue as soon as the judicial proceedings have concluded without
waiting for the result of an appeal, if any, in a higher Court of law.](h)Appeal. - (i) If appeal has been
preferred, order of the appellate authority should form part of the record.(ii)An order-sheet should
invariably be used from the beginning and the record of the proceedings should be prepared as the
case is gone into from day to day and not after the case has been decided. The order-sheet shall form
part of the proceedings.(iii)In order that copies of whole of proceedings may without objection be
supplied to officers punished, authority conducting such a proceeding must base his findings and
orders on facts and inferences appearing in or deduced from the record and should not refer to
confidential papers which cannot be embodied, in the record.Note. - All or any of the provisions of
clause (i) above may, in exceptional cases for special and sufficient reasons to be recorded in writing,
be waived where there is a difficulty in observing exactly the requirements of the Rule and those
requirements can be waived without injustice to the person charged.(iv)The full procedure indicated
above need not be followed in the case of a probationer discharged in the circumstances described in
explanation II to Rule 2 of the Subordinate Service Discipline and Appeal Rules, 1935, or theBihar Board's Miscellaneous Rules, 1958

corresponding provisions in the Civil Services (Classification, Control and Appeal) Rules. In such
cases it will be sufficient if the probationer is given an opportunity to show cause in writing against
the discharge after being apprised of the grounds on which it is proposed to discharge him and his
reply against the discharge duly considered before orders are passed.(v)If from the facts elicited in a
criminal case brought against a Government servant in which he has not been convicted or in a civil
suit instituted against him, it is apparent that his retention in the public service is prima facie no
longer desirable, such facts may be used as the basis of an order calling on him to show-cause why
he should not be punished by dismissal or otherwise. In such a case the officer concerned should
have an opportunity of submitting his defence and tendering such further evidence as he may see fit
to produce.
168. Censure, withholding of increments, etc. and recovery from pay.
(a)Without prejudice to the provisions of Rule 166 no order imposing the following penalties viz:.
-(a)censure,(b)withholding of increments or promotions including stoppage at an efficiency
bar,(c)recovery from pay of the whole or part of any pecuniary loss caused to Government by
negligence or breach of order or (other than an order based on facts which have led to his conviction
in a criminal Court or by a court Martial, or an order superseding him for promotion to a higher post
on the ground of his unfitness for the post).on a Government servant shall be passed unless he has
been given an adequate opportunity of making a representation that he may desire to make and
such representation, if any, has been taken into consideration before the order is passed:Provided
that the requirements of this paragraph may, for sufficient reasons to be recorded in writing, be
waived where there is difficulty in observing them and where they can be waived without injustice to
the officer concerned.Note. - The full procedure indicated in clauses (i) and (ii) of Rule 166 need not
be followed and in such cases. It will be sufficient if the officer concerned is given an opportunity of
explaining the charges against him and the explanation so submitted is taken into consideration
before orders are passed.(b)Compulsory retirement of officers. - A ministerial officer may be
retained in service till he reaches the age of 60, provided he continues to be physically fit and
efficient.A ministerial officer who has completed 25 years of total service of which 21 years must be
of actual duty may be compulsorily retired from service if he has grown inefficient or if his conduct
is not such as to justify his retention in service. Such compulsory retirement being in accordance
with the conditions of service of ministerial officer does not account to removal and the ministerial
officer concerned is not entitled to a show-cause notice before he is ordered to retire. Such an officer
may, however, be allowed to submit representation against such retirement and such
representation, if any should be taken into constitution, before passing final orders.Further
instructions to be followed before ordering the compulsory retirement to Government servants are
embodied in Appointment Department Memo No. Ill/ RI/5011/51A-3794, dated the 4th May, 1953
which is incorporated in Appendix J.(c)Suspensions. - Government servants should not be placed
under suspension for inadequate reasons or kept under suspension for a long period. The principles
to be followed in ordering suspension are explained in Mr. L.P. Singh's letter no.
III/RI/2033/52-A-188, dated the 9th January, 1953 and letter No. III/RI/209/ 60-A-4968, dated
4.4.1960 by Mr. M.S. Rao which are incorporated in Appendix J.(d)Discharge of temporary
Government servants. - The Bihar and Orissa Subordinate Services Discipline and Appeal Rules,
1935, do not apply to Government servant subject to discharge on one month's notice or less. TheBihar Board's Miscellaneous Rules, 1958

Civil Services (Classification, Control and Appeal) Rules also so far as they are applicable to
Government servants under the Rule making control of the State Government do not apply to
Government servants subject to discharge on one month's notice or less. Therefore, the full
departmental proceedings contemplated by rule 55 of the Civil Services (Classification, Control and
Appeal) Rules are not necessary when such temporary Government servants are discharged from
service.(2)When the term of appointment of temporary Government servant provides for the
termination of service by either party giving notice of a specified period, either party can serve such
notice at any time and the service should be considered to have been terminated on expiry of the
specified period of notice.The termination of service in such circumstances does not amount to
"removal" from service under Article 311 of the Constitution.(3)When a temporary appointment
expressly stated to be on a temporary basis is sanctioned until further orders and is subject to the
condition that the service may be terminated at any time without notice, the termination of service
does not amount to "removal" from service under Article 311 of the Constitution and the service can
be terminated at any time without notice.(4)In all other cases which are not covered by the
foregoing provisions, Article 311 of the Constitution is attracted and full departmental proceedings
are necessary before the temporary service can be terminated Words [* * *] ['But in cases........are
passed deleted by u.b. No. 17 dated 4.11.1968.].
169. Defects in the procedure for investigation of charges.
- The Government of India has drawn attention to the standing orders contained in their Resolution
No. 37-1389-1404, dated the 29th July, 1879 (Appendix J), regarding the investigation of charges of
misconduct against Government servants, and has noticed that the most common defects of
procedure observed are as follows :-(1)Officers frequently fail to comply with the prescribed
procedure requiring a written charge and a written defence in respect of each offence;(2)after
framing charges they often fail to give a specific finding on each charge; and(3)sometimes they do
not even discuss the charges framed but confine their remarks on the whole case to some major
charge which has not even been framed against the person who is the subject of the inquiry.The
necessity of conducting departmental inquiries in conformity with the standing orders, so as to
avoid the defects of procedure mentioned above and other similar defect, is impressed upon all
officers concerned.
170. Orders inapplicable to persons judicially convicted.
- The provisions of clauses (i) and (ii) of the rule 166 shall not apply-(a)where a person is dismissed
or removed or reduced in rank on the ground of conduct which has led to his conviction on a
criminal charge;(b)where the authority empowered to dismiss or remove a person or to reduce him
in rank is satisfied that for some reason to be recorded in writing, it is not reasonably practicable to
give to that person an opportunity of showing cause against the action proposed to be taken in
regard to him;(c)where the Governor is satisfied that in the interest of the security of the State it is
not expedient to give to the accused person an opportunity to show-cause against the action
proposed to be taken in regard to him.Note. - If any questions arises whether it is reasonably
practicable to give to any person an opportunity of showing cause under clauses (i) and (ii) of rule
166 against the particular penalty proposed to be inflicted, the decision thereon of the authorityBihar Board's Miscellaneous Rules, 1958

empowered to impose the penalty shall be final.
171. Free copy of the order.
- When any orders of punishment have been passed the officer punished shall be entitled to receive
a copy of the order of punishment free of cost, and shall also be allowed to take a copy of the rest of
the record, paying for the copy at the usual copy rate or providing his own paper and copyist.
172.
(1)The Rules regarding the discipline and right of appeal of members of subordinate Services in
Bihar are contained in Appendix V. The Subordinate Services under the administrative control of
the Board are the following :Land Revenue
1. Supervisors of the Bihar Survey Office.
2. Collecting staff of Government Estates.
3. Ministerial service in the Bihar Survey Office.
4. Lower ministerial service in the Bihar Survey Office including posts of
photo assistants, photomen, grainers and printers.
Miscellaneous Revenue
5. Excise Inspectors, Sub-Inspectors and petty officers.
6. Ministerial service of the office of the Commissioner of Excise.
7. Ministerial service of District Excise Officers.
General Administration
8. Ministerial service of the office of the Board of Revenue.
9. Ministerial service of office of Commissioners of Divisions.
10. Ministerial service of District and Sub-Divisional offices.Bihar Board's Miscellaneous Rules, 1958

11. The General Subordinate Service (as defined in the rule promulgated by
the Government of Bihar and Orissa, Appointment Department notification
no. 1978 AR., dated the 13th June, 1935).
(2)Petitions of the appeal presented under these rules need not be stamped but applications and
petitions, when presented to a Commissioner or to the Board with a request to exercise some power
of revision conferred on them by any law or by any rule having the force of law, are required to be
stamped under the Court-fees Act, VII of 1870.(3)In cases other than statutory cases (for which see
rule 83 on page 112 of the [Bihar and Practice and Procedure Manual, 1939)] [Now, see Bihar
Practice and Procedure Manual.], no executive authority of rank lower than the Provincial
Government has power to withhold a petition for revision, presented by a Government servant for
transmission to, higher authority, asking for revisions of an order passed by a subordinate authority,
affecting such officer. Such a petition should therefore be transmitted to the higher authority by the
officer to whom the petition is presented with such remarks, if any, as may be deemed
necessary.(4)An authority to whom such a petition is presented, may withhold it if it contains
improper or disrespectful remarks.
173. Appellate authority to deal with points pressed.
- An appellate authority should ordinarily deal, as is customary, with those points only that are
raised or pressed in the appeal.
174. Papers to be sent up in certain cases.
- When the Board calls for a report in cases of appeal or revision in which public officers have been
removed or dismissed from the service of Government, the Commissioner should invariably submit
the original proceeding (or copies of the written charge, defence and decision thereon) which are
required by rules 167 and 168.
175. Reasons for not instituting criminal prosecution should be recorded.
- Cases occasionally occur in which it is considered inexpedient to undertake the prosecution of
Government servants who are dismissed on account of offences for which they are liable to be
criminally prosecuted. In future, the reasons which render it inexpedient to undertake criminal
prosecution in such cases should be recorded at the time the order of dismissal is passed. When
there is no objection to such a course, the reasons should be included in the order of dismissal, of
which the dismissed servant receives a copy; but in every case a copy of the recorded reasons for not
instituting a prosecution when the offender was liable to one should be forwarded with any report
that may afterwards be made on the case to the Board or to Government.Bihar Board's Miscellaneous Rules, 1958

176. [ Certificates to Subordinates. [Substituted by C.S. No. 46 dated
10.11.1956.]
- If any Government official gives a certificate to his subordinate, who has been dismissed or
removed from service, he should mention therein all the grounds leading to his dismissal or
removal].
177. Allowance or salary to suspended or reinstated officer.
- Rules 96 and 97 of the Bihar Service Code,1952 regulate the grant of subsistence allowance or
salary to an officer under, or reinstated after, suspension.When an officer is reinstated after
suspension with forfeiture of any part of his allowance the authority who reinstates him should
always declare at the time whether the period of suspension is to count towards pension (vide
Article 417 of the Civil Service Regulations).[Rules 96 and 97 of the Bihar Service Code being given
have for ready reference:-"Rule 96. - (1) A Government servant under suspension shall be entitled to
the following payments, namely:-(a)Subsistence grant at an amount equal to the leave-salary which
the Government servant would have drawn, if he had been on leave, on half average pay, or on half
pay and in addition cost of living allowance based on such leave salary :Provided that where the
period of suspension exceeds twelve months, the authority which made or is deemed to have made
the order of suspension, shall be competent to vary the amount of subsistence grant for any period
subsequent to the period of the first twelve months, as follows :-(i)the amount of subsistence grant
may be increased by a suitable amount not exceeding 50 per cent of the subsistence grant admissible
during the period of the first twelve months, if in the opinion of the said authority the period of
suspension has been prolonged, for reasons to be recorded in writing, not directly attributable to the
Government servant.(ii)the amount of subsistence grant may be reduced by a suitable amount, not
exceeding 50 per cent of the subsistence grant admissible during the period of the first twelve
months, if in the opinion of the said authority, the period of suspension has been prolonged, due to
reasons to be recorded in writing directly attributable to the Government servant.(iii)the rate of cost
of living allowance will be based on the increased or as the case may be, the decreased amount of
subsistence grant admissible under sub-clauses (i) and (ii) above.(b)Any other compensatory
allowance to which a Government servant may be entitled from time to time on the basis of pay,
which he received on the date of suspension :Provided that the Government servant shall not be
entitled to that compensatory allowance unless the said authority is satisfied that the Government
servant continues to meet the expenditure for which they are granted.(2)No payment under sub-rule
(i) shall be made unless the Government servant furnishes a certificate that he is not engaged in any
other employment, business, profession or vocation.(3)The Subsistence grant shall be subject to a
minimum limit of Rs. 10 per month.Note 1. - It is obligatory under this rule that in sufficient time
before the expiry of the first year of suspension, the competent authority should review each case in
which the period of suspension is likely to exceed one year and even if the competent authority
comes to the conclusion that the rate is not to be altered having regard to all the circumstances of
the case, specific orders to that effect are to be passed placing on record the circumstances under
which the decision had to be taken.Note 2. - When the subsistence grant is increased or decreased
by an amount not exceeding 50 per cent of subsistence grant under proviso to rule 96(1)(a) the
increase or decrease will be calculated on the amount of the subsistence grant initially fixed and willBihar Board's Miscellaneous Rules, 1958

not be subject to any minimum or maximum limit of leave salary on half average pay or on half
pay.Rule 97. - (1) When a Government servant who has been dismissed, removed or suspended is
reinstated, the authority competent to order the reinstatement shall consider and make specific
order:-(a)regarding the pay and allowance to be paid to the Government servant for the period of his
absence from duty, and(b)whether or not the said period shall be treated as a period spent on
duty.(2)Where the authority mentioned in sub-rule (1), is of opinion that the Government servant
has been fully exonerated, or in the case of suspension that it was wholly unjustified, the
Government servant be given full pay and allowance to which he would have been entitled, had he
not been dismissed, removed or suspended as the case may be.(3)In other case, the Government
servant shall be given such proportion of such pay and allowance as such competent authority may
prescribe:Provided that the payment of allowances under clause (2) or clause (3) shall be subject to
all other conditions under which such allowances are admissible.(4)In a case falling under clause (2)
the period of absence from duty shall be treated as a period spent on duty for all purposes.(5)In a
case falling under clause (3) the period of absence from duty shall be treated as a period spent on
duty unless such competent authority specifically directs that it shall be so treated for any specified
purpose :Provided that if the Government servant so desires such authority may direct that the
period of absence from duty shall be converted into leave of any kind due and admissible to the
Government servant.]
178. Effect of imprisonment.
- When any servant of Government is committed to prison, either for debt or on a criminal charge,
he is to be considered as under suspension from the date of his arrest and not allowed to draw any
pay until the termination of the proceedings against him, when an adjustment of his allowances will
be made according to the circumstances of the case-the full amount being given only in the event of
the officer being acquitted of blame, or, if the imprisonment was for debt, his being proved that the
officer's liability arose from circumstances beyond his control.
179. Officers are attached to their respective offices.
- Ministerial officers are attached to their respective offices, and heads of offices are forbidden to
carry them about with them when they are transferred to other districts. The transfer by officers of
one department, of ministerial officers in the employ of other departments, without the concurrence
of their immediate superiors is forbidden.
180. Transfer of services to another Government office or department.
(1)It is the duty of a Government officer, who wishes to transfer his services to a different
Government office or department, to obtain the consent of the authority which appoints to his
existing post before taking up the new employment. If he takes up the new employment without
such consent, he commits a breach of discipline and is liable to be punished, in the last resource, by
dismissal from his former post and consequent loss of pensionable service. Resignation of his
former appointment will not, it should be noted, protect him from this penalty. In granting or
withholding consent to the acceptance by a subordinate of other Government employment, the headBihar Board's Miscellaneous Rules, 1958

of an office or department must consider whether the transfer will be consistent with the interests of
the public service. Permission should not be refused, however, without strong reason, which should
be recorded in writing. The head of an office or department shall not employ, either temporarily or
permanently, an officer whom he knows, or has reason to believe, to belong to another
establishment without previous consent of the head of the office or department in which he is
employed. In the rare cases in which, for reasons which appear satisfactory to the new employer, an
officer cannot obtain the required consent before taking up the new appointment, the employment
may be made conditional on consent being obtained at the earliest opportunity.(2)When an
application for permission to apply for an appointment in another Government office or department
is received, the question whether the applicant can be allowed to take up the appointment, if offered
to him, must be settled before his application can be forwarded, regard being had, if the
appointment is a temporary one, or on probation, to possible inconvenience from the officer's return
as well as to possible inconvenience from sparing him initially. If the officer cannot be spared, the
head of his department must refuse definitely to forward his application. If, however, permission be
given to apply, that permission carries with it permission to accept the appointment, if offered, and
the officer or the head of the department giving such permission is debarred from objecting to the
officer taking up the appointment, though of course his convenience must be consulted, within
reason, as regards the date of taking it up.(3)The foregoing instructions apply equally to officers on
leave whether with or without allowances. All leave allowances must ipso facto cease on the taking
up of new employment other than work of a purely casual nature.
181. [ Transfer of ministerial officers. [Substituted by C.S. No. 20 dated
4.10.1969.]
(1)Subject to the general control and direction of the Board, and to the condition that a ministerial
officer may not be transferred to a post on a lower salary except in accordance with an order of
punishment passed after proceedings. Commissioners shall have full powers to transfer ministerial
officers from one office, headquarters or sub-division to another within their division as they may
think expedient-for the public service. Collectors should invariably submit such proposals once a
year to reach the Commissioner by 20th February, giving reasons in support thereof.(2)All transfer
of ministerial officers within the district should be approved by an Establishment Committee
consisting of the Collector, all officers of the rank of Additional Collector or Additional District
Magistrate, District Development Officer (not otherwise eligible), District Establishment Deputy
Collector, all Sub-Divisional Officers and Senior Office Superintendent in accordance with the
following principles:-(a)Every ministerial officer should spend at least three years in a Block or
Anchal Office, not situated at district or sub-divisional headquarters.(b)Ministerial officers in the
Lower Division scale who are over 40 years of age or have put in 15 years of service are exempt from
(a) above.(c)The period of stay in a bad or unhealthy station should not, however, be more than 2
years at a stretch. A list of such bad or unhealthy stations in each district should be prepared, a copy
of which should be sent to the Divisional Commissioner concerned and the Board for record. No
change should be made in that list without the approval of the Board through the
Commissioner.(d)No clerk should be allowed to forego his claim to promotion to the next higher
scale unless any special case can be made out to the satisfaction of the Commissioner of the
Division.(e)No assistant should be allowed ordinarily to stay in any particular Anchal or Block OfficeBihar Board's Miscellaneous Rules, 1958

for more than three years at a stretch, but their transfer is compulsory from that Anchal after five
years.(f)Attempts should be made to give every ministerial officer wider experience by transferring
him from one branch of office to another.(g)All ministerial officers shall be liable to transfer after
three years, their transfer shall be compulsory after three years. No departure from this rule is
permissible in any circumstances in the case of ministerial officers dealing with money and
accounts.(h)Representations, if any, against transfer should be effectively discouraged and disposed
of quickly.(3)Subject to the provisions of rules 182, the Board in special cases may sanction mutual
transfer of permanent ministerial officers from one district to another within the State in the
interest of public service. This will not apply to temporary ministerial officers.]
182. Exchange of appointments.
- Appointments should be exchanged, or transfers made, between those officers only who draw
equal salaries, or who belong to the same grade of ministerial employee in the sanctioned scale of
the establishments to which they severally belong. Transfers are not to be made without definite
reasons in each case.The rule applies to compulsory transfers as well as to voluntary
exchanges.Note. - This rule will apply to the IVth Grade Government servants also.
183.
[x x x] [Rule 183 deleted by C.S. No. 20 dated 4.10.1969.]
184. The District Officers to report names of officers liable to transfer.
- The names of officers liable to transfer under the above rule after they have served for five years in
one appointment, should be reported by the Collector for the orders of the Commissioner and
should be entered in a list to be kept in the Commissioner's office.The Collector's report should
reach the Commissioner on the 20th February each year. If in the case of any such officers, the
Commissioner and Collector are unable to arrange a transfer within the division before the lapse of
seven years, the matter should be reported to the Board who will arrange it in communication with
other Commissioners.
185. Subordinates under Magistrates, etc.
- In the case of subordinates employed under other officers, the required report will be submitted to
the heads of departments, as the case may be, on whom will rest the responsibility imposed on the
Board in regard to revenue subordinates.
Chapter IX
Treasuries and Custody of Keys and Valuables
Note. - The general rules for the management of treasuries are contained in the following booksBihar Board's Miscellaneous Rules, 1958

:-Civil Account Code, Volumes I and II.The Resource Manual.The Bihar and Orissa Treasury
Manual.The Bihar Treasury Code..Rules for the custody, supply and sale of stamps and stamped
papers.
186. Appointment of Assistant or Deputy Collectors and officers of the Bihar
Finance Service as treasury officers.
(a)District Officers are empowered to transfer to any Assistant or Deputy Collector, any, or all of the
Administrative duties connected with the treasury. The officer so selected must be thoroughly
conversant with the rules issued for the guidance of treasury officers.The instructions contained in
Board's Circular Order No. 8 of April, 1896, reproduced below, should be carefully noted :"It having
been brought to the notice of the Board that officers who have not passed their departmental
examination are sometimes placed in charge of district treasures, the Board invite the attention of
all Commissioners and District Officers to the subjoined extracts (paragraphs 6 and 7) of Resolution
no. 355, dated the 18th January, 1882, by the Government of India, in the Department of Finance
and Commerce, published in the Gazette of India Part IA dated the 21st idem,.and republished in
the Calcutta Gazette, Part I dated the 25th idem."2. The resolution does not contemplate an
unpassed officer being placed in charge of a treasury otherwise than for purposes of training for the
limited periods prescribed in Clause 2 of paragraph 7 of the resolution, subject to the supervision of
a qualified treasury officer who is responsible, though allowed to relieve himself of the chief labour
of the charge by utilizing the services of the unpassed officer. The latter officer, therefore, should not
be gazetted as placed in charge of the treasury. The provisions of the resolution, should be carefully
observed in future."Extract of Paragraphs 6 and 7 of the Resolution"6. The appointment of young
civilians and of supernumerary and probationary Deputy Collectors, who have not passed all or any
of their examinations, appears to have been a fruitful source of laxity and irregularities on the part
of subordinate officials. His Excellency the Governor-General in Council directs that this practice
may be discontinued, and that (except as provided in paragraph 7) no Deputy Collector remains
hereafter in charge of district treasury, unless he has passed the departmental examination
according to the higher standard, and has also been not less than three years in the service of
Government.""7. In order to ensure a better acquaintance with the system of treasury accounts, and
of the revenue accounts which in some provinces are an important contributory to the accuracy of
the latter, His Excellency the Governor-General in Council is pleased to direct-"1st. - That
examination in treasury and local fund accounts and in departmental revenue-accounts, shall form a
part of the test obligatory on all Assistants and Deputy Collectors or other officers, at the
departmental examination, according to both the lower and higher standards.The scope of the
questions at the former will necessarily be somewhat elementary, but at the latter the candidate
should be required to exhibit a satisfactory general acquaintance with the whole system of accounts
as prevailing in the province in which he is employed. A paper of questions on treasury and local
fund accounts, set by the local Accountant-General and Comptroller, should form a part of the
examination under each standard.""2nd. - That every Assistant Magistrate, Deputy Magistrate, or
Sub-Deputy Collector shall undergo a training in treasury work, and shall, for that purpose, be
placed in charge of a district treasury under the general supervision of the Deputy Collector
ordinarily in charge for a period of not less than six weeks continuously. He will not be held to have
passed the examination in accounts by either standard, until the Collector of the District, to whichBihar Board's Miscellaneous Rules, 1958

he is attached, shall have furnished a certificate that he has under the above provisions, duly
attended to, and satisfactorily discharged, the duties of treasury officer for the prescribed period of
six weeks within one year prior to the date on which he appeared for examination in accounts. If a
candidate has passed by the Lower Standard only a second certificate will be required before he can
be considered to have passed by the Higher Standard, unless at the time at which he presents
himself for examination by the Higher Standard, less than a year has lapsed since the candidate was
last in charge of a treasury. The Collector will see that this certificate is forwarded to the Central
Examination Committee at each departmental examination."(b)[ A certain proportion of officers of
the Bihar Finance Service will be entrusted with one or all of the administrative duties connected
with Treasury. Officers of the Senior Branch of the service will be eligible for appointment as a
District Treasury Officer after they have put in at least 3 years of service and have been confirmed
and have passed the Departmental Examination by Higher Standard. Officers of the Junior Branch
of the service will be in charge of selected sub-divisional treasuries, subject to their passing the
prescribed Departmental Examination by Higher Standard.] [Substituted by C.S. No. 27 dated
22.1.1952.]
187. Drawing bills.
- The Collector of a district is empowered to authorise any Assistant or Deputy Collector in charge of
a treasury to draw bills on other treasuries by publishing a notification to the effect, over his
signature in the Gazette. Until the notification is published an Assistant or Deputy Collector in
charge of a treasury cannot draw such a bill.
188. Report of defalcation.
- District Officers should report to the Accountant General, as laid down in Rule 44, Chapter II
Section I of the Bihar Treasury Code, Volume I all cases of defalcation or embezzlement in an office
or treasury and will correspond with him direct in regard to such cases. Immediately such a case is
discovered, the District Officers should send a short report to the Accountant-General and to the
Board of Revenue through the Commissioner or the Commissioner of Excise in case of a defalcation
by a ministerial officer or any other non-gazetted officer including a peon of the Excise Department.
In the latter case, a copy of the report should also be sent to the Commissioner of the Division for his
information.This report should afterwards be supplemented as soon as possible by a detailed report
from the District Officer after personal enquiry into the case. It should be specially noted whether
any defect has been found in the existing practice or system of administration and how it can be
remedied, whether any gazetted officer is to blamed and whether the loss should be written off or
recovered from the officer or officers responsible. The Accountant-General will report to the Board
his own remarks.The Board will then after a further correspondence with the District Officer or the
Commissioner as may be found necessary, submit a complete report to Government together with
its own views of the case.Bihar Board's Miscellaneous Rules, 1958

189. Assistance of audit officer in investigating loss of public money.
- (i) Where loss of public money occurs through the negligence or fraud of individuals, and the
District Officer requires the assistance of the audit officer in the investigation of the loss, he may call
on that officer for all vouchers and other documents that may be relevant to the investigation; and if
the investigation is complex and he needs the assistance of an expert audit officer to unravel it, he
should apply forthwith for that assistance to Government who will then arrange with the audit
officer for the service of an Investigating Officer.(ii)Officers responsible for loss or irregularity not to
be allowed to retire on pension. - Steps should be taken to ensure that an officer likely to be held
responsible for any loss or irregularity, which is the subject of an enquiry is not inadvertently
allowed to retire on pension while the enquiry is in progress. Accordingly when a pensionable
Government servant who is likely to apply for pension is so concerned, the authority investigating
the case should immediately inform both the audit officer who is responsible for reporting on his
title to pension and the authority competent to sanction the pension. It will be the duty of the latter
to make a note of the information and to see that pension is not sanctioned before either a
conclusion is arrived at as regard the Government servant's culpability or it has been decided by the
sanctioning authority that the result of the investigation need not be awaited.
190. Treasury Officer not to be placed in-charge of refunds of deposits, etc.
- Treasury Officer should not also be placed in-charge of the certificate department or the refunds of
deposits so as to deal in a dual capacity with refunds or payment of money. Such a combination of
duties may easily give rise to frauds.
191. Treasury establishment.
- Proposals affecting treasury establishment should be submitted by District Officers through the
Commissioner to the Board. The Board should consult the Accountant-General, if necessary.
192. Treasuries.
- Treasurers are classified into first, second and third grade officers according to the importance of
the transactions in the treasuries to which they are attached.There are no treasuries at the
headquarters of the district of the province except at Dumka in the Santhal Parganas, Hazaribagh,
Palamau, Manbhum and Singhbhum where the treasurers are third grade officers.
193. Temporary vacancy in the post of treasurer-how to be filled up.
- When there is a temporary vacancy in the post of a treasurer caused by the resignation on short
notice or dismissal of the permanent incumbent, the vacancy should, if possible, be filled in by an
officer holding a responsible post, who has already given security. If that is impossible, the officer
who may be appointed to officiate, should be required to produce two respectable persons of known
probity and wealth to stand as personal sureties for him. Acting treasurers should in all cases beBihar Board's Miscellaneous Rules, 1958

required to record their formal agreement to the continuance of the subordinate staff for the period
of their incumbency accepting the same responsibility for them as the permanent treasurers.When
the permanent incumbent goes on leave, none other than his nominee or one acceptable to him
should be appointed in the acting vacancy. In other words he should not be granted leave unless he
offers a substitute for himself and gives an undertaking in the annexed form before proceeding on
leave :-Undertaking to be taken from the treasurer before he proceeds on leave.I hereby place on
record that, with the approval of the District Officer I have in terms of my Agreement, dated
the.........with the Government appointed.......a specimen of whose signature is given below, to act as
my substitute and at my risk and responsibility to discharge all duties of the Treasurer at and in
connection with treasury from the until this letter is cancelled by me and notice of such cancellation
is received by Government or any officer authorised on that behalf.Signature verified by me
Treasury OfficerNote. - The first sub-paragraph of this rule should be followed in filling up
temporary vacancies in the posts of Head clerks of Sub-Divisional Offices, who are sub-treasurers.
194. Distribution of duties in sub-divisional treasuries.
- As a general rule one and the same clerk should not work both as treasurer and accountant. In
sub-divisional treasuries the head clerk should be the treasurer and the second clerk, the
accountant, unless otherwise expressly ordered by the Commissioner of the Division, who is
authorised to issue such orders as may seem advisable in special cases, where difficulty may be
experienced in giving effect to the general rule. The Commissioner is also to determine, for each
sub-divisional treasury, what security the head clerk treasurer should give.
195. Working balance in custody of treasurer.
- A separate chest should be placed at the sole disposal of the treasury, in which a working balance is
to be kept. Its maximum should be fixed at the lowest convenient figure, and must never, including
cash, notes, stamps, etc. exceed the amount for which the treasurer has given security. The
maximum value of stamps left with the treasurer is not to exceed one week's supply. In the largest
treasury, the cash in the treasurer's possession need never exceed Rs. 3,000, and in a sub-divisional
treasury the cash in the treasurer's possession need not exceed Rs. 300. The sum so held by the
treasurer should be roughly verified night and morning.
196. Responsibilities of treasurer.
- The treasurer is to make payments only on orders of payment passed by the accountant, and
signed by the treasury officer. He is responsible for any loss by the receipt of light weight or
uncurrent coins.
197. Treasurer not to receive public money except at treasury.
- The treasurer may receive no public money, except at the public treasury upon pain of immediate
dismissal.Bihar Board's Miscellaneous Rules, 1958

198. On private money for deposit in treasury.
- The treasurer may receive no private cash or valuables for deposit in the public treasury.
199. May appoint subordinates.
- The treasurer should be allowed to appoint subordinates.Note. - Owing to the absorption of the
posts of the treasury muharrirs into the lower division of the Collector's office establishment under
the reorganization scheme of 1909, the treasury muharrirs are now ordinarily appointed by the
Collector in consultation with the treasurer from eligible candidates among the lower grades or
probationers, and all future appointments of treasurers should be made on the understanding that
this is the regular practice. When treasurers, already appointed, insist on their prerogative of
appointing outsiders under this rule, it must be understood that such clerks will not come within the
operation of reorganization scheme, will have no claim to promotion to any higher grade, and will be
removed when the treasurer who appointed them ceases to hold his office.
200. Treasurers to receive only salary.
- The treasurers do not receive any emoluments other than salary. They do not get any commission
on sales of opium at the treasuries or sub-treasuries nor any discount on the sale of stamps.Note. -
The word "treasurer" in Rules 195, 196, 197, 198, 199 and 200 includes ministerial officers in charge
of sub-treasuries.
201. Poddars not to do clerical work.
- Treasury poddars must not do any of the clerical work of treasuries or sub-treasuries either in the
Accountant's or in the Treasurer's Department.
202. Treasury work during Durga Puja and Christmas holiday for the
convenience of the postal department.
- District Officers must make the necessary arrangements, in communication with Postmasters for
receiving money in the treasury from the money-order branch of the postal department once or
twice during the Durga Puja and Christmas holidays. The money so received must be deposited by
the Postmaster in sealed bags, which for safe custody, will be kept in a box in the strong-room of the
treasury. The box itself will be under the single lock of the Postmaster, and no responsibility for its
contents will be taken by the treasury.Postmasters should be allowed access to the boxes and
permitted to remove money on their own responsibility from them. A Postmaster may be authorised
by the Postmaster-General to draw immediately before the holidays such a sum as may be thought
sufficient, and to deposit this in the treasury-room in the same way as he deposits other receipts. As
all money deposited in the treasury strong-room is kept under double lock, the treasury officer and
treasurer must attend at the treasury when any money is received from, or taken out of, deposit by
Postmaster.Bihar Board's Miscellaneous Rules, 1958

203. Custody of duplicate keys.
- The following rules regarding the custody of duplicate keys of treasury strong-rooms and chests
have been prescribed by the Board on the basis of Article 12(a) of the Resource Manual. They apply
also to the duplicate keys of Chubb's padlocks used in other departments, but under Rule 84 of
Chapter XII of the Bihar Stationery Manual, 1951, the use of these locks in other departments is
confined to receptacles for documents of extreme importance.(1)Register of locks in use and their
keys. - A register of all padlocks in use in the headquarters and sub-treasuries and treasure chests or
in other departments shall be maintained in the Form No. 48 and kept in the strong-room of the
district treasury. Separate pages shall be assigned to the headquarters treasury and to each
sub-treasury or treasure chest or other department. A list of the padlocks in use in subtreasuries
should be procured every year by the district treasury and compared with this register so that any
discrepancies may be readily detected and enquired into. Each sub-treasury shall also keep a list of
its own padlocks and keys in the above form. The District Officers at the time of their annual
inspection of sub-treasuries should verify the accuracy of this list by actual count of the padlocks in
use there.(2)Numbering of locks and keys. - Every padlock shall have a number impressed upon it or
attached to it by a metal or other label, and the same number shall be impressed on or attached to
each key belonging to it. No two padlocks in the same district shall bear the same number. Every key
other than those belonging to treasury strong-rooms or chests shall have a label attached to it
showing what almtran or chests it opens.(3)Unserviceable and spare locks. - If a padlock becomes
unserviceable or ceases to be required, or if one of its keys is damaged or lost, it shall be returned to
the [Government Stationery Stores and Publications, Bihar, Patna-7] [Substituted by C.S. No. 3
dated 20.12.1961.]. If a lock is required to replace an old and useless lock, a certificate in the
following form should accompany the indent. -"I hereby certify that I have personally ascertained
that the Chubb's lock now indented for is required to replace another which will be returned to the
[Government Stationery Stores and Publications Bihar, Patna-7 for disposal] [Substituted by C.S.
No. 3 dated 20.12.1961.]".No spare locks shall be kept at a sub-treasury or, except with the
permission of the Collector, at a district treasury, and duplicate keys shall not be kept at
sub-treasuries. [x x x x] [Deleted by C.S. No. 3 dated 20.12.1961.],(4)Loss of keys. - When the key of
any padlock is lost, a seal shall forthwith be placed on the lock, so that it cannot be unlocked without
breaking the seal and steps shall be taken to obtain the duplicate key as soon as possible. Such other
precautions as considerations of safety may require, e.g., the addition of another padlock should also
be taken and if the key is the key of a treasury strong-room or chest the loss should be at once
reported to the Commissioner. When the lock has been opened by the duplicate key the lock and key
shall be immediately forwarded to the [Government Stationery Stores and Publications, Bihar,
Patna-7] [Substituted by C.S. No. 3 dated 20.12.1961.], In a case of great urgency, or where some
malpractice is suspected the lock should be broken open.(5)Repairs etc. - No local mechanic shall
ever be allowed to repair a Chubb's Padlock or to make a new key for one.(6)Register of spare
padlocks and keys. - A register of spare padlocks which are held in the district treasury with the
permission of the District Officer shall be maintained in form 48-A. When issued, these padlocks
shall be transferred to Register 48.(7)Custody of duplicate keys and their annual inspection. - All
spare padlocks with their keys and all duplicate keys of padlocks belonging to the headquarters and
sub-treasuries and treasure chests or other departments with the exception of those belonging to the
locks of the headquarters's strong-room door shall be kept in the headquarters strong-room underBihar Board's Miscellaneous Rules, 1958

double locks, the key of one lock being in the hands of the Treasury Officer and of the other in the
hands of the treasurer. The duplicate keys of the strong-room door shall be secured under the seat of
the Treasury Officer and Treasurer and deposited in the district treasury strong-room at Purulia, the
duplicate keys of which shall be kept under double lock in the district treasury at Gaya. They shall be
sent for once a year in the month of April, examined by actual insertion in the locks and returned to
the places fixed under fresh seal of the Treasury Officer and Treasurer, a note being made in
Register 48 that they have been examined and found correct. The duplicate keys kept in the
strong-room of the several district treasuries shall be similarly tested.Note 1. - In districts where the
treasury is worked by a branch of the [State Bank of India] [Substituted for 'Imperial Bank of
India'.] and consequently where there is no Treasurer, the Nazir or such other officer, as the District
Officer directs will discharge the functions of the Treasurer for the purpose of the above rule.Note 2.
- The duplicate keys of each set of locks in use in the strong-room and in other rooms and
receptacles, if any, shall be kept in a separate sealed packet, each packet containing the duplicates of
all the keys in the custody of one officer and bearing the seal not only of that officer but also of the
officer who is in-charge of the keys of the other set of locks. The sealed packets shall be deposited in
two separate receptacles in the places mentioned in this rule. At the time of verification care should
be taken not to send for the duplicate keys of both sets of locks at the same time. One packet
containing the duplicates of keys in charge of one officer shall be sent for and returned after
verification before the other packet containing the duplicates of the keys in charge of the other
officer is sent for. The essential point to be borne in mind is that the keys of both sets of locks may
not fall simultaneously into the hands of one and the same person.(8)Examination of locks and keys
on transfer of charge of treasury. - Whenever the charge of a treasury is transferred or a treasurer is
changed, all padlocks and duplicate keys belonging to or kept in the treasury including the duplicate
key of the strong-room door kept at Purulia and Gaya shall be examined and compared with the
registers and a certificate shall be signed that they have been found to be correct.
204. Where title deeds to be deposited.
- Title deeds, conveyances and other similar legal documents belonging to Government, connected
with property, should be deposited with the Inspector-General of Registration.
205. Valuables for safe custody.
- Valuables of the following kind only may be received by the treasury officer for safe custody, and
they should be kept in the same way as cash:-(1)Books of bill forms.(2)Books of money-order
forms.(The books in current use remaining in the treasury officer's personal possession).(3)Advices
of bills.(4)Opium.(5)Stamps of all kinds.(6)Promissory notes or bonds deposited with a Government
Officer as security for the due performance of official duties.(7)Promissory notes, bullion, jewellery
or other Valuables connected with any case, executive or judicial, and directed by the District Officer
to be placed in the treasury for safe custody.(8)Church plate.Bihar Board's Miscellaneous Rules, 1958

206. Register to be kept.
- All valuables for which separate registers have not been prescribed will be entered in a register to
be kept in manuscript in the form given in Rule 80(c) on page 25 of the Bihar Treasury Code,
Volume I.Chapter-X Security of OfficersRules for taking security from Ministerial and Non-Gazetted
OfficersNote. - Under Government Circular No. 13006-E dated the 21st September, 1981, the rules
in this Chapter are applicable mutatis mutandis to all Departments of Government which have no
special rules of their own on the subject herein dealt with.
207. All payments to be made direct into Treasury.
- As a general rule, all payments should be made direct to the treasury by the person from whom
they are due and should not pass through the hands of any Government official.Exceptions. - No
exception to this rule should be allowed without the special sanction of the Board. An exception has
been sanctioned in the case of collections of all kinds made by Government Officers in the mufassil
and brought to headquarters. When money cannot be paid in on the day when it is brought, owing to
the treasury being closed, or to other sufficient cause, it should be deposited with the Nazir, who
should give a receipt for it. On the next open day the Nazir, should pay in the money and should
attach a copy of the receipt to the chalan.
208. All officers handling public money to give security.
- Every officer through whose hands public money passes is to furnish security, which should, as a
rule, be 10 per cent in excess of the maximum amount likely to be in his custody at one time. He
shall also furnish two sureties.Special cases. - In special cases in which the application of this rule
would cause hardship, and where the amount of money under the officer's control cannot be
diminished by administrative arrangements, the Commissioners are authorised, for reasons to be
recorded in each case, to reduce the amount of security as far as they think necessary but where the
amount which would otherwise be required as security does not exceed Rs. 100, this power of the
Commissioner to reduce such amount may be exercised by the Collector with the same
limitations.The guarantee bonds referred to in Rule 222 below may also be accepted in lieu of cash if
the pay of the officer is Rs. 70 or under and the security required from him does not exceed Rs. 300.
209. Security bonds of peons.
- Every peon need not be required to give security. But a peon who handles public money, should
not be appointed unless he gives a security bond (executed by some person of known respectability
and solvency) for his good and honest conduct. The amount of such security shall be Rs. 250. The
amount of money handled by such peon should be limited to the amount of the security. The form of
the bond is given below :-"I know A, B, to be an honest man, and I agree to forfeit Rs if called upon
to do so, should he be proved to have embezzled Government money up to or beyond that amount,
or, having received money on behalf of Government failed within fifteen days of demand to credit it
to Government or to account for the same for any cause whatever."Exceptions. - Indian militaryBihar Board's Miscellaneous Rules, 1958

pensioners employed in civil capacities as peons, messengers, etc., are exempted from the operation
of this rule, provided that such pensioners do not come under the provisions of Act XII of 1850
(Public Accountant's Defaults Act).
210. Date of security bond and names of sureties to appear in Register 30.
- The dates of security bonds for peons and the names of sureties should always be noted in the
"remarks" column of "Register 30-peons' and the Nazir should test the entries once in two years and
note the result with the date in the same column of the register. If the security bond is invalid the
Nazir should bring the fact to the notice of the Collector for the execution of a fresh bond.
211. Amount of security general principle.
- The general principle of fixing security at 10 per cent above the amount likely to be in their hand at
one time, and not on the amount of their salaries, or at a fixed sum, applies to the following
officers:-
Head Clerks of Sub-Divisional Officers.Stamp Clerk (where there is
no treasurer).
Nazirsand other officers of theNazaratDepartment (except peons)
through whose hands public moneypasses.Money-order agents and
their sureties.
Tahsildars, who are not gazetted officers.Managers of estates which
are the property of
Government.
Concessions. - The Government allows to these officers the concession already granted to Public
Works employees by Resolution No. 152-T.G. of the 29th September, 1894, namely, that the security
of officers of 20 years' pensionable service or upwards may be diminished by a sum calculated on
their monthly pay, multiplied by 25 with the proviso that the security shall in no case be diminished
by more than one half.The acting incumbents of posts other than Sub-Divisional Head Clerks
mentioned in this rule should be required to produce two respectable persons of known probity and
wealth to stand as personal sureties for them.The forms of bond to be used under this rule are given
in Appendices L, M and N.Note 1. - The concession allowed by this Rule is not to be extended to
Head Clerks of Sub-Divisional Officers who are also sub-treasurers.Note 2. - Nazirs in certain
districts are required to disburse the pay of establishments of District Officers. In fixing the amounts
of their security under this rule the fact that they will have in their hands for short periods sums on
account of the pay of the establishment in excess of the amount of their security, may be left out of
consideration.Note 3. - In the case of acting incumbents of posts other than Sub-Divisional Head
Clerks no bond need be taken where the acting period is limited to two months or less.
212. Exception in case of treasurers.
- The amount of the security of treasurers is not regulated by the principles enunciated in the
preceding rule but is determined by the number of treasury transactions in the district where theyBihar Board's Miscellaneous Rules, 1958

serve. The scale of security is as follows:
  Rs.
Treasurers of 1st class districts ...20,000
Treasurers of 2nd class districts ...15,000
Treasurers of 3rd class districts ...10,000
213. Security in promissory notes.
- Treasurers, and all officers who have to furnish security in excess of Rs. 5,000 shall give it in the
form of promissory notes and/or stock certificates of the Central Government or of State
Government. If it is given in cash, the sum will be invested in as many promissory notes, and/or
stock certificates of the Central Government or of State Government as it will purchase, the balance,
if any, being placed in the savings bank as a security deposit.Note 1. - The purchase of promissory
notes is to be made through the Reserve Bank of India for which the usual commission will be
charged by the Bank. No commission, will however, be charged for drawing and remitting
interest.[Vide para 110(b) and note 1 below para 111 of the Government Securities Manual, 1939
(third edition).Note 2. - Whenever promissory notes are deposited as security their realizable cash
value should be approximate to the amount of the security required. These orders will apply to the
cases, not only of treasurers, but to all officers who deposit promissory notes and/or stock
certificates of the Central Government or of State Government when cash security to a specified
amount is required under the rules (Vide Government of Bihar and Orissa, Finance Department,
Circular Memo No. 2942-F.B., dated the 6th October, 1920).
214. Security in Savings Bank deposit.
- Officers who have to give security of Rs. 5,000 or less shall give it either in the form of Post Office
Savings Bank deposits or Promissory notes and/or stock certificates of the Central Government or of
State Government.Note 1. - Post Office 5-year cash certificates may be accepted as security deposit
for the amount at which the certificates were purchased (and not for their face value), provided the
depositor formally transfers the certificates, with the sanction of the Postmaster-General, to the
Reserve Bank of India (Vide Rule 229). The certificates should be re-transferred at the end of the
period for which the security is given.Note 2. - Purchasers of twelve-year post office National
Savings Certificates may transfer their holdings of National Savings Certificates to Government
Officers in their official capacity to be treated as security or authorise or consent to the purchase of
National Savings Certificates out of money retained by Government Officers as security. The value of
the security shall be the amount at which the certificates were purchased or their conversion value
on the date on which they are transferred. In all such cases, the certificate must be formally
transferred to the Government officers concerned with the sanction of the Head Postmaster of the
Office in which or any of the Sub-Offices attached to which, they are for the time being
registered.The certificates may be re-transferred to the original holders with the permission of the
Head Postmaster at the end of the period for which the security is given. Government Officers
accepting National Savings Certificates as security must satisfy themselves that the total face value
of the National Savings Certificates in the name of any person pledging these does not exceed Rs.Bihar Board's Miscellaneous Rules, 1958

5,000.
215. Payment by instalments.
- If an officer is unable to furnish the full amount of security due from him, in a single payment, he
may, at the discretion of the Collector, be permitted to pay it by monthly instalments of not less than
one-fourth of his pay, within a maximum period of five years:Provided that where such officer has to
contribute 6¼ per cent to a provident fund constituted under the orders of the Board in any Ward's,
Attached, Trust or Encumbered estate, the contribution to security shall, at the discretion of the
Collector, not be less than 18¾ per cent of his pay, but, subject to special exemption by the Board,
when the officer is employed in an estate with a current rent and cess demand of over a lakh of
rupees, and, by the Commissioner in all other cases, the total amount of the security must still be
paid within a maximum period of five years :Provided further that if the pay of the officer be Rs. 70
or under the Collector may accept a security bond with two sureties. In any case in which this is
allowed the officer shall be required to place 6¼ percent of his pay in the Savings Bank as a security
deposit and be entitled to have the security bond cancelled as soon as the deposit is equal to the
amount of the security required.The forms of bond to be used for payments of security in
instalments are given in Appendices N and Q.Note. - This rule does not apply to treasurers whether
in charge of sadar or sub-treasuries.
216. Officers newly appointed.
- No officer appointed to any post requiring security be permitted to furnish it in the form of landed
property:Provided that if the pay of the officer be Rs. 70 or under, the Collector may allow the
security to be given in landed property. In any case in which security in landed property is allowed
under this proviso, the officer shall be required to place 6¼ per cent of his pay in the savings bank
as a security deposit and will be entitled to have the security bond on the landed property cancelled,
as soon as the deposit is equal to the amount of the security required.The form of bond and the form
of mortgage to be used in the case of the ministerial officers who are allowed to give security in
landed property are given in Appendices T and U.
217. Prohibition of house property as security.
- House property may in no case be accepted as security.
218. When notes need not be endorsed in favour of a Government officer.
- The following rules regulate the treatment of securities in promissory notes held by Government
officers in their official capacities:(1)When promissory notes are to be deposited with a Government
officer for 12 months or less, or when they are deposited for more than 12 months but the depositor
does not desire to draw any interest during the period they will remain in the name of the depositor
and should not be endorsed by him to any Government officer. The Government officer receiving
the deposit will see that the notes stand in the name of the depositor and that the contract or otherBihar Board's Miscellaneous Rules, 1958

document executed by the depositor conveys authority to Government to appropriate or cancel the
notes if the contract is not fulfilled. After satisfying himself on these points the Government officer
receiving the deposit will lodge the notes for safe custody at the nearest treasury.(2)The depositor
may draw interest on the notes by tendering receipts in the usual form, countersigned by the officer
with whom he deposited the notes.
3. When endorsement necessary. - (i) When the promissory notes are
deposited for more than twelve months but less than five years and the
depositor desires to draw the interest on them during the period of the
deposit, the latter should be required to endorse them in favour of the
Treasury Officer of the nearest treasury.
[Vide Paragraph 107 (a) of the Government Securities Manual, 1939 (third edition)].(ii)When the
promissory notes are deposited for five years or more and the depositor desires to draw interest on
them during the period of the deposit, the procedure laid down in paragraph 101(b) of the
Government Securities Manual, 1939 (third edition), should be followed.
219. Form of security bond.
- The form of security bond prescribed for treasurers is given in Appendix R and for acting
treasurers in Appendix S. In the case of treasurers of district treasuries no modification should be
made in the form except after communication with the Government solicitor.Note (i). - It is not
necessary for acting treasurers nominated by permanent treasurers in leave vacancies to execute a
separate bond as the latter are held responsible for all acts of their substitutes under Rule 193.Note
(ii). - Head Clerks of sub-divisional offices, who are also sub-treasurers, should use the form of
bonds given in Appendices R and S which are prescribed for all treasurers whether in charge of
sadar treasuries or sub-treasuries.
220. Security from officers in-charge of public documents.
- Security bonds for good and honest conduct, in the sum of Rs. 1,500 should be taken from
record-keepers and in the sum of Rs. 250 from the other officers named below, the amount being
reduced, if desired, after 20 years pensionable service, as laid down in Rule 211:-Designation of
OfficersAccountants (do not include Assistant Accountants).Assistant Record-keepers (including the
ministerial officers referred to in the Record Manual).Head Clerks, except in the Registration
Department.Librarians.Superintendents.Tauzinavises.Tauzi muharrirs.Clerks confidentially
employed (whether a shorthand writer or otherwise) at the discretion of the Head of the Department
or in the case of a clerk employed under a District Officer, at the discretion of the District
Officer.Any officer may, if he prefers it, deposit security in cash or in Government promissory notes
with a bond without sureties, in lieu of a security bond for the amount prescribed above.The forms
of bond to be used under this rule are given in Appendices O, P and Q.Bihar Board's Miscellaneous Rules, 1958

221. One officer not to stand surety for another.
- The practice of one officer standing surety for another in the same office is forbidden.
222. Certain guarantee bonds accepted in lieu of personal security.
- Guarantee bonds, in the form given in Appendix V, of the National Guarantee and Suretyship
Association Limited, Calcutta, may be accepted in lieu of personal security.This arrangement is,
however, liable to be cancelled by Government at any time.
223. Obligation of officers to report change in the status of their securities.
- It is obligatory on all officers on whose behalf security bonds are furnished under this Chapter to
report without loss of time any change in the status of their sureties which is calculated to render
their security invalid or insufficient. Apart from any special inquiries which may be made upon
receipt of such information the solvency of the sureties should be verified at intervals of three years
by responsible officers under the Collector's orders, but the necessary enquiries should not be of an
inquisitorial nature. The result of the verification should be noted in Register No. 73-Securities of
ministerial and non-gazetted officers.
224. Security bond of officers transferred to other posts.
- When an officer is transferred to another appointment and it becomes necessary to demand a
higher amount of security from him owing to the increased responsibilities of the new post, no fresh
bond need be executed, but a memorandum (to be signed by the principal and his sureties) should
be endorsed on the bond, giving particulars of the additional security and the manner in which it has
or will be deposited. It should also be expressly stipulated that the terms of the bond with regard to
the security originally deposited are to be applicable to the additional security.When any addition is
made to a bond, it should be presented for fresh registration. The registering officer will make note
on the copy of the original document kept in his office that it has been so modified. In the copy of
the addition to be kept in the registration office, it will be noted that it is an additional made to the
original document, the number and year of which should be mentioned :Provided that when any
such officer is appointed to act in a higher post for a period of not more than three months, the
security already deposited by him whether in the form of cash or Government promissory notes, or
in the form of personal security as required by Rule 220 shall generally be deemed to be good and
sufficient:Provided also that if an officer so appointed holds a post in which no security is
demanded, he need not give security, if the period of his acting appointment does not exceed three
months.
225. Explanation of terms of bond to sureties ignorant of English.
- When the sureties are unable to read English, care should be taken that the provisions of the bond
are explained to them before execution, and the person doing this should in every such case attestBihar Board's Miscellaneous Rules, 1958

the signatures of the sureties and make a note at the foot of the attestation clause that the terms of
the bond were so explained.
226. Testing of security in landed property.
- In all cases in which the security consists, in whole or in part, of landed property, the validity of
such security shall be tested in January-February of each year in the following manner:-(1)A
proclamation shall issue and be affixed at the mufassil Kachahri or residence of the surety, or in a
conspicuous place in the village where the land or other property pledged in the bond is situate, in
the presence of not less than two respectable residents of the village, and also at the police thana
within the jurisdiction of which the property is situate (the receipt of the Inspector or Sub-Inspector
in-charge of the thana being obtained through his superiors) calling upon all persons who have
claims upon, or who deny the right of the proposed surety to, the property mentioned in the bond
(which is to be carefully set forth in the proclamation) to come forward within one month and prefer
their claims or objections in respect to it, on failure of which the inadmissibility of any pleas of
objection will be pleaded by the revenue authorities in bar of any future claim whensoever preferred.
On the expiration of the month, the return evidencing due service of the proclamation as above will
be put up, and any claims or objections made will be considered.(2)Search will also be made in the
registration office in which any transaction affecting such landed property would be registered with
the view of ascertaining if the right and title of the surety to the land have remained
unchanged.(3)Local enquiry will also be made in the localities in which the landed property is
situated by a revenue officer not inferior in standing to a Nazir or Kanungo, who will report fully as
to the sufficiency of the security given.(4)The officer who has furnished the security shall also
submit a declaration in writing, setting forth distinctly the circumstances (if any) that have affected
the value of the landed property as security since the date of the last testing of the same. The head of
the office after duly weighing any claim or objection made on proclamation issued, the result of
search in the registration office, and of the local enquiry, with the declaration of the officer giving
security, shall pass orders accepting or rejecting the security. The result of the annual testing of
securities should be noted in column 11 of Register No. 73-Securities of ministerial and non-gazetted
officers.
227. Promissory notes when to be returned.
- Promissory notes and/or stock certificates of the Central Government or of State Government, and
savings bank deposits lodged as security shall not be returned until after 6 months from the date of
vacation of the office, but security bonds should be retained permanently or until it is certain that
there is no necessity for keeping them any longer.
228. Special bonds.
- If the bond required from an officer be of a special character such as to require the employment of
an English solicitor for its preparation, it is optional with the officer to employ the Government
solicitor or any other. Heads of offices may accept a bond without taking the advice of the solicitor to
Government on their own responsibility. Persons actually in the employ of Government are notBihar Board's Miscellaneous Rules, 1958

liable to any charge for the preparation of any documents connected with their appointments. The
Government law officers will draw up any such documents which the heads of offices may require.
229. Securities to be entrusted to the Reserve Bank of India for safe custody.
- Public securities lodged with Government officers as a guarantee for the due performance of
official duties or as a pledge for the payment of revenue or rent must be sent to the Reserve Bank of
India for safe custody unless Government directs otherwise in a particular case.[Vide note 1 to
paragraph 101 of the Government Securities Manual, 1939 (third edition)].
230. Exemption of bonds from stamp duty and registration fee.
- Security bonds executed by non-gazetted officers are exempted from payment of stamp duty and
registration fees.
231. Security bonds to be deposited with the Inspector-General of
Registration.
- The security bonds of all officers except peons are to be sent for safe custody to the
Inspector-General of Registration. They should be sent in registered covers, and copies on plain
paper should be retained in the Collectorate for reference whenever necessary.
232. Register of securities.
- A Register of securities should be kept in Register No. 73 (Vide Register and Return Manual) at
sub-divisions as well as the district headquarters. In the register should be inserted an index and a
certificate in the forms appended to the register.The register and index will be in the charge of a
Deputy Collector designated by the Collector, who will each year certify that the register is full and
complete and that the name of every officer liable to give security has been entered in the register
whether he has given security or not.When filling in the certificate the Deputy Collector will also
initial and date the last entry in the index.Chapter-XI PensionPreliminaryNote. - The rules
governing service pensions, extraordinary pensions and gratuities for service not entitling to
pension in respect of the members of the services under the rule making control of the Provincial
Government are contained in the Bihar Pension Rules published under the authority of the
Government of Bihar. Part I below contains instructions for prompt preparation and submission of
pension papers.As for territorial and political pensions disbursed through revenue authorities, the
rules governing them are contained in Part II.
Part I – Instructions for Prompt Preparation and Submission of
Pension PapersBihar Board's Miscellaneous Rules, 1958

233. Prompt preparation of pension papers.
- (i) A statement on plain paper and in the handwriting of the applicant should be furnished,
supported by the evidence of his contemporary employees, if available, in respect of such periods of
service as are not susceptible of verification from local records. These affidavits should be made
before a gazetted officer and attested by him.(ii)The affidavit of the applicant and evidence of
contemporary employees should state in full detail (a) whether the applicant was in permanent
employ, and (b) whether there were any breaks in the service or any leave granted.(iii)Age. - When
the precise date of birth is not known, the 1st of July of the year of birth should be taken to be the
date of birth.(iv)Age as given in the service book, if subsequently amended, should be supported by
an order of competent authority, approving the alteration.(v)Alteration in service books and other
pension papers should be made in red ink and attested.(vi)Average emoluments. - A statement of
the calculation should invariably be furnished with reference to Rules 151, 153, 154 and 156 of the
Bihar Pension Rules.(vii)Character and conduct. - Against item no. 1 on the second page of the
application for pension merely 'good', 'bad', 'fair', or 'indifferent' should be noted without any
remarks, which should be made only when absolutely necessary for a right understanding of the
case.(viii)The specific opinion of the head of the office should invariably be stated in each case
against item no. 6 on the second page of the application for pension.(ix)Cancelled.(x)Any delay in
the submission of the pension case for report of the audit office exceeding three months should be
explained.(xi)An officer, whose service has been for some time inferior and for some time superior,
may either count-(a)the whole as inferior towards pension or gratuity on the inferior scale, or(b)the
superior portion towards pension or gratuity on the superior scale, and the inferior portion towards
gratuity on the inferior scale.(xii)Service books and service rolls. - These records should be complete
in every respect:(a)the date, month and year of the various appointments, promotions and
cessations should be clearly shown;(b)if an officer without a substantive appointment officiated or
was appointed substantive pro tempore period should or should not count towards pension under
Rule 64 of the Bihar Pension Rules;(c)similarly, in cases of officers holding temporary
appointments' it should be clearly stated whether the requirements of Rule 63 of the Bihar Pension
Rules have been fulfilled.(xiii)Identification marks. - A few conspicuous marks should be
specified.(xiv)Medical certificate. - (a) If granted after the applicant has ceased to perform duty, it
should be stated whether it has been accepted under Note below Rule 194(iv) of the Bihar Pension
Rules.(b)Medical certificates should be granted by commissioned medical officers and Civil
Surgeons and not by an assistant surgeon or sub-assistant surgeon except when in medical charge of
a district.The medical certificate should be in the form laid down in Rule 128(a) of the Bihar Pension
Rules.(c)In the case of an officer invalided as unfit for employment only in the department to which
he belongs, it should be stated whether every effort was made to find for such an officer other
employment suited to his particular capacity.(d)In the case of an inferior servant who is invalided
before he has attained 60 years of age, a medical certificate should be furnished as required by Rules
123 and 124 of the Bihar Pension Rules.(xv)The date of retirement as shown in the service book, first
page of the application for pension and the last pay certificate should correspond.(xvi)Verification of
service. - A statement of services should be prepared in Pension Form No. 4 of the Bihar Pension
Rules, in chronological order showing the periods of interruptions, if any. In the column "how
verified" of this statement periods of services verified under Rule 197(iv) of the Bihar Pension Rules
from local records (such as pay bills, acquittance rolls) and by the audit offices should be clearly andBihar Board's Miscellaneous Rules, 1958

separately shown in chronological order. The original verification report of the audit offices should
be attached to the pension case.(xvii)If during the last three years of service, an officer was
appointed substantive pro tempore in another appointment, the nature of the original vacancy in the
claim of arrangements of which he was appointed as such should invariably be stated.(xviii)A
memorandum of all periods of leave (except casual leave) taken by the officer should be appended to
the pension case.(xix)If an officer's service has been partly rendered in non-gazetted and partly in
gazetted appointments, the non-gazetted portion should be verified as laid down in Rule 197 of the
Bihar Pension Rules. The gazetted portion need not be verified as it is verified from the "History of
Services of gazetted and other officers" compiled in the office of the Accountant-General, Bihar.
234. Prompt submission of pension papers.
(a)The Provincial Government feel that a Government servant should move straight from pay to
pension and that the amount of his pension should be determined and intimated to him not later
than the date of his retirement. To ensure this all cases relating to verification of services and
applications for pension should be dealt with as immediate at all stages in all offices through which
such cases pass. Attention is invited to the provisions of Rule 188 of the Bihar Pension Rules, to the
effect that everything should be done to prevent delays in the payment of pension on the due date.
An interim remedy for delay in sanctioning pension is provided in Rules 204-208 of the Bihar
Pension Rules relating to anticipatory pensions, but this remedy should in no case be made a ground
for any avoidable delay in adjudicating the full amount of pension admissible.(b)Delay in settlement
of pension cases in audit office is generally due to defects inherent in the pension papers. Defects
commonly noticed are indicated below:(i)Continuity of service should be carefully recorded in the
service book and any break or interruption of service fully explained, e.g., if the date of termination
of one appointment is shown, say 1st January, 1920, and the date of commencement of the next
appointment is shown as 10th January, 1920, and no reason for the break of nine days is recorded in
the service book, this is wrong and results in delay in sanctioning the pension. Such omissions
should be carefully checked and rectified.(ii)Temporary and officiating services should be
scrutinized and the certificates required under Rules 63 and 64 of the Bihar Pension Rules should be
given in the service book.(iii)In the event of reinstatement after suspension the date of
reinstatement and the declaration under Rule 100 of the Bihar Pension Rules should be recorded in
the service book.(iv)When an officer in receipt of special pay takes leave during the last three years
of service, the necessary declaration of the Head of the Department should be furnished, [vide
Paragraph 39(6)(f) at page 19 of the Pension Manual as inserted by correction slip no. 348 dated the
3rd August, 1936].(v)Average emoluments should be correctly calculated under Rule 156 of the
Bihar Pension Rules. Only pay should be taken into account in such calculation and not leave
allowances.(c)It has also been noticed that one or other of the documents required for the purpose
of certificate and report are sometimes not received by the audit office alongwith the pension
papers.To avoid such omission and consequent delays and correspondence the pension papers
should always be sent to the audit office with a forwarding letter, a specimen of which is appended
below, after attaching the relevant documents mentioned therein:-Specimen of the Forwarding
LetterSir,I have the honour to forward herewith the pension papers of Mr..............late a...........of this
office as per list enclosed for favour of report on his title to pension.List of enclosuresBihar Board's Miscellaneous Rules, 1958

1. Application for pension in Form No. 4 of the Bihar Pension Rules.
2. Invalid certificate (if the claim is for invalid pension).
3. Service book duly completed [when service begins with temporary or
officiating appointment, the information as to whether the conditions of Rule
63 or 64 of the Bihar Pension Rules have been fulfilled should be furnished.
When officiating allowance is drawn during the last three years of service,
which is taken into account in calculating pension, the information as to
whether the conditions of Rules 151 (e) and 151 (f) of the Bihar Pension
Rules, were fulfilled in respect of the officiating allowance drawn should also
be furnished.]
4. Statement of services in the form given at 'second page' of the Pension
Form No. 4 of the Bihar Pension Rules, showing the periods verified.
5. Memo of average emoluments.
6. Last pay certificate, when the pension papers are submitted after
retirement.
7. A copy of the first page of the application for pension duly attested.
8. (a) Two specimen signatures duly attested.
(b)Two slips bearing the left hand thumb and finger impression and passport size photo (where
necessary) duly attested in the case of non-gazetted officers in addition to (a) above.
9. (a) Declaration from the pensioner regarding non-receipt of any pension or
gratuity, required under the Note below Rule 193 of the Bihar Pension Rules.
(b)Declaration from the pensioner regarding grant of anticipatory pension required under Rule
204(a) of the Bihar Pension Rules, if some delay is anticipated in the verification of his
services.(c)Declaration from the Head of the Department to the effect that the special pay included
in the average emoluments was of the nature of special pay as defined in Rule 37 of the Bihar
Pension Rules (here state reasons therefor) and that had the Government servant not been on leave
or officiated in a higher post during the last three years of his service he would have drawn the
special pay which he was drawing before proceeding on leave or officiating in the higher post, if the
benefit is intended to be given to the pensioner.Bihar Board's Miscellaneous Rules, 1958

Part II – Territorial and Political Pensions
235.
The following rules were framed by the Board with the consent of the Lieutenant-Governor in
Council under Section 14, Act XXIII (The Pensions Act), 1871, for Bengal, including Bihar and
published in the Board's Notification No. 3971-B, dated the 7th August, 1911, on page 1163, Part I of
the Calcutta Gazette of 9th August, 1911:-[I. Political pensions. - 'Political' pensions are governed by
Rule 46, Part II, Chapter IV of the Book of Financial Powers of the Government of India. These are
pensions to non-officials whose services descent or connections are such that it is on general
grounds of policy very desirable that the Government should extend to them some measure of
assistance or recognition. Only Rules II to XXI of the Rules below apply to these pensions, their
renewal, distribution etc., being regulated under the Rule cited above.] [Vide Board of Revenue,
Bihar and Orissa, Notification No. 7-32-4, dated the 25th May, 1931, Published in Part II, page 787,
of the Bihar and Orissa Gazette of the 27th idem.]Territorial pensions. - 'Territorial' pensions
represent payment on account of some obligation arising out of land, including certain special
payments to religious institutions dating from the time of the permanent settlement or earlier.
When such pensions are permanent, hereditary, and transferable without restrictions, they are to be
dealt with under the Rules of permanent malikana. All others are governed by the rules below.II.
Place of payment. - Except as provided in Rule III, all pensions shall be payable at the district
treasury upon which a permanent pay order has been issued by the Accountant-General.III. At
Sub-Divisions. - Pensioners residing within any sub-division of a district may obtain payment of
their pensions from the sub-divisional treasury in the same way as from the district treasury.IV.
Transfer of payment. - A Commissioner of a Division may, on application and on sufficient cause
shown, permit transfer of payment from a treasury in his division to any other treasury in British
India:Provided that this rule shall not extend to political pensions in cases where the pensioner
resides, by order of the Government, in a particular place.V. Particulars to be submitted in case of
transfer of payment. - A copy of the order directing the transfer referred to in Rule IV shall be
forwarded by the Commissioner to the Accountant-General, together with a brief narrative of the
origin and particulars of the pension; and the district officer of the district from which the payment
is transferred shall be instructed to return his and the pensioner's portion of the permanent pay
order to the Accountant-General. The Accountant-General shall then issue a fresh permanent pay
order to the officer who will in future, pay the pension, or if that officer belongs to another province,
shall move the Accountant-General of such province to do so.VI. Monthly payment. - Except as
otherwise provided in these Rules, all pensions shall be paid monthly.VII. Arrears of pension. - If a
pension remains undrawn for more than six months the Collector or other disbursing officer must at
once make enquiry into the cause of the non-appearance of the pensioners and must return the pay
order to the Accountant-General. When the inquiry has been completed the result shall be
communicated to the Accountant-General.If the pensioner afterwards appears, the Collector or
other disbursing officer may reclaim the pay order and renew his payments, and the payment of
arrears that have accumulated, not exceeding Rs. 1,000/- may be sanctioned by the Collector or
other disbursing officer. If the amount of arrears exceeds Rs. 1,000/- the previous sanction of the
Commissioner must be obtained.VIII. Personal appearance at time of payment and exemptions
therefrom. - (1) Except as provided in sub-rules (2) and (3) and Rule IX a pensioner must takeBihar Board's Miscellaneous Rules, 1958

payment in person after identification by comparison with the permanent pay order.(2)The
following person, namely,-(a)pensioner specially exempted by Commissioners, Heads of
Departments or the Collectors from personal appearance;(b)a female pensioner not accustomed to
appear in public, and(c)a male or female pensioner, who is unable to appear in consequence of
bodily illness or infirmity,may receive his or her pension, upon the production of a life certificate
signed by a responsible officer of Government, or by some other well known and trustworthy
person.(3)A pensioner of any description, who produces a life certificate signed by some person
exercising the powers of a Magistrate of any class under the [Code of Criminal Procedure, 1898]
[Now See Cr.P.C., 1973.] or by any Registrar or Sub-Registrar under the Indian Registration Act,
1908 or by any pensioned officer who before retirement, exercised the powers of a Magistrate, is also
exempted from personal appearance.(4)In all cases referred to in sub-rules (2) and (3) the
disbursing officer must take precautions to prevent imposition, and must at least once a year,
require proof, independent of that furnished by the life certificate, of the continued existence of the
pensioner. For this purpose he shall [except in cases of exemption from personal appearance
granted by the [(Commissioners of Divisions, Heads of Departments or Collectors)] [Inserted by
Bihar and Orissa Board's Notification Nos. 7-47-6, dated the 12th April, 1915, Published in Part II,
Page 459 of the Bihar and Orissa Gazette of the 14th idem.] require the personal attendance and due
identification of all male or female pensioners who are not incapacitated by bodily illness or
infirmity from so attending, and in all cases where such inability may be alleged, he shall require
proof thereof in addition to the proof submitted of the pensioner's existence.IX. Pensioners of rank.
- Pensions of pensioners of rank, who are specially exempted by the Commissioners of Divisions,
Heads of Departments or Collectors from personal appearance, shall be paid to an agent holding a
power of attorney on their behalf upon the production of the permanent order and of a separate
receipt.X. Payment to an agent. - Pensions of pensioners exempted from personal appearance under
sub-rule (2) or (3) of Rule VIII (except in cases mentioned in Rule IX) may be paid to an agent on
their behalf on the production of the permanent pay order, of a life certificate as prescribed by those
sub-rules, respectively, and of a separate receipt.XI. Arrears of deceased pensioners. - On the death
of a pensioner, payment of any arrear actually due may be made to his heirs provided that they
apply within six months from his death, after which period no such payment shall be made without
the sanction of the Commissioner.Collectors of districts are empowered to sanction the payment of
arrears of pension due to deceased pensioners to their heirs. Even if the pension has been
sanctioned before the death of the pensioner, the payment may be made under the orders of the
authority who would have been competent to sanction the pension if the pensioner had not died.XII.
Making over of permanent pay order to pensioner. - On the receipt by the disbursing officer of the
permanent pay order, he shall summon the pensioner, and, on his appearing, shall make over to him
his portion of the permanent pay order, and shall explain to him at what times he can draw his
pension and how he must proceed for the purpose. No other certificate need be given.XIII. Making
over of permanent pay order to agent. - When the pensioner is exempted from appearance in
person, the permanent pay order may be made over to any person authorised to act on the
pensioner's behalf.XIV. Worn permanent payment order. - When the reverse of a pension payment
order is filled up, or when the pensioner's half is found to be worn or torn, both halves may be
renewed by the Treasury Officer.XV. Loss of pensioner's portion of payment order. - If a pensioner
loses his half of the pension payment order, a new order may be issued by the Treasury Officer who
should see that no payment is made on the half alleged to be lost by a strict observance of Rule 2Bihar Board's Miscellaneous Rules, 1958

under Article 943 of the Civil Service Regulations. The necessary note should be made in the
remarks column of the register in form 40, Civil Account Code.XVI. Registry of applications. - In
each collectorate a list of pensions granted shall be kept up in Register No. 64 of the Register and
Return Manual Applications for pensions are to be entered in Register 8 of "Miscellaneous
cases".XVII. Pensions undrawn for two years. - All pensions not drawn for two years shall be
struck-off the said register. If such pensions are renewed under Rule VII, a fresh entry shall be made
in the register in respect thereof.XVIII. Death of pensioners. - Upon the death of a pensioner the
district officer shall at once report the circumstances to the Accountant-General and shall return the
original permanent pay order to his office.XIX. Permanent pay order. - When a pension is granted,
the Accountant-General shall issue a permanent pay order to the disbursing officer of the station at
which the pension is payable, directing him to pay periodically, until further notice, the amount of
the pension upon the production of the counterpart of the order and a separate receipt according to
the prescribed form. This order shall be entered in the register of permanent orders prescribed in
Article 327 of the Civil Account Code, Volume II [Form No. 40, Civil Account Code],XX. Register to
be kept at sub-division. - When payment of any pension is permitted at a sub-division, a copy of the
permanent order in respect of such pension shall be forwarded to the sub-division, a note to that
effect being made in the register of permanent orders at the headquarters station. At each
sub-division a register of permanent orders so received shall be kept up in the same form as the
register prescribed for the headquarters station.XXI. Payment to be recorded. - Upon representation
of a claim for payment, the district officer shall at once record the sum paid upon the permanent
order, enter the amount in the cash-book, and submit the separate receipt, in the form given below,
with his treasury account, to the Accountant-General as a voucher in support of the charge.Form of
Receipt for PaymentBill for pensions chargeable to.....................(major head) paid at
the.......................treasury between and 20We do hereby acknowledge to have received the amount
set against our respective names as pensions due for the periods noted under the orders quoted in
our respective permanent pay orders.
1 2 3 4 5 6 7
PaymentNumber of
permanent pay
orderName of
pensionerMonthly
amountPeriod of
claimAmount
paidSignature of payee with
stamp, if payment
exceedsRs. 20
Date No.       
        
XXII. Continuance of hereditary pensions. - The Board of Revenue is competent to sanction the
continuance of hereditary pensions when the hereditary title has been already recognised by the
Government or decreed by a competent Court of Justice. But it is to be borne in mind that the
Government never undertook, absolutely, to pay the pensions included in the permanent settlement,
and that if a pension has been unadvisedly continued to heirs, the hereditary nature of the gratuity
may, on the death of the incumbent, again be questioned.XXIII. Hereditary pensions not to be
ordinarily allowed. - As a general principle, pecuniary grants will not be continued after the death of
the parties in whose favour they were originally made. Pensioners whose pensions are granted for
life only, and are resumable at their decease, are to be in no way encouraged by the local officers to
hope that their pensions will be continued to their heirs, and thereby induced to neglect making aBihar Board's Miscellaneous Rules, 1958

proper provision for their families. The Board is to submit to Government for decision any case in
which it may be of opinion, on the decease of a life pensioner that the pension or any part thereof,
should be continued to the heirs.XXIV. General principles. - The principles laid down in the
memorandum by Mr. F. Millett, printed below, are under the orders of Government, to be followed
in recommending, or deciding upon the continuance or discontinuance to heirs of the various
classes of pensions with which the memorandum deals.[Memorandum by Mr. F. Millett on pensions
and charitable or other allowances, dated 12th May, 1845] [Bengal Regulations XXIV of 1793,
XXXIV of 1795, XXIV of 1803, XXII of 1806 and XI of 1813, referred to in this memorandum, were
repealed by Act XXIII of 1871 (Pensions), Section 2 and Schedule, subject to a saving as to rules
made thereunder.]The Government never undertook absolutely to pay the pensions included in the
permanent settlement.Section 74, [2] [Section 74 of Bengal Regulation VIII of 1793 was repealed by
Act XV of 1847.] Regulation VIII, 1793, provided "with respect to any of the existing established
zamindari charges, such as pensions, charitable or other allowances which it may be thought proper
to continue they shall be paid by the Collector, etc."Regulation XXIV, 1793, prescribed the rules for
determining their continuance, or discontinuance, the fundamental principle being that all such
pensions and allowances were gratuitous.The following are the principal provisions of that
Regulation:"Pensions received by virtue of sanads, granted before the dewanny or since granted
with the sanction of Government, and pensions received from before 1173 (country era), to be
continued to the grantees or original holders. But if the grantees or original holders be dead, the
pensions not to be continued to their heirs or descendants without the sanction of Government;
and"No pension after the death of the person then entitled to it to be continued to his descendants
without the like sanction, whether the grant was, in either case, according to the terms of it,
hereditary or otherwise.""Whenever Government orders the continuance of a pension, whether to
the original holder or his heir, the Collector to give him a certificate, stating the title of the party
thereto during his or her life.""The Collector to keep a register of these certificates, noting therein
such personal identifications of the parties as might detect any attempt to transfer the certificates to
others.""The pensions and allowances being gratuitous, the determining upon the continuance or
discontinuance of them under the Rules prescribed is reserved to Government.It appears to me
plain that according to this Regulation every pension confirmed was to be confirmed as a
life-pension only, and that on the death of any pensioner the case of any new claimant was to be
submitted to Government for its determination.Section 6 of Regulation XXIV, 1803 (Ceded
Provinces), provided that pensions granted to fakeers and other religious persons for the purpose of
lighting mausoleums or mosques, or for that of repairing them, as also to enable them to perform
their religious ceremonies, usual in the Muharram, were to be continued; but that pensions of this
description were not to be considered as of a personal nature and that the Collector was to be
responsible for their being applied to the purpose for which they were bestowed.Certificates were
under this Regulation, to be granted for pensions renewed on the death of pensioners, and registers
of certificates to be kept as under Regulation XXIV, 1793, and Section 16 declared that the
continuance or discontinuance of pensions was after the death of the persons then receiving them,
to depend solely on the pleasure of Government.I reconcile Sections 6 and 16 in this way. Pensions
received by fakeers at the date of the Regulation for certain purposes were to be continued to them;
but if they applied them to other purposes they would be resumed. On the death of the then holders,
the pensions were to be continued to their successors or not as Government might determine, each
renewal requiring a specific order.By Section 30, Regulation XII, 1805, the provisions of RegulationBihar Board's Miscellaneous Rules, 1958

XXIV, 1793, were made applicable to pensions and allowances granted for religious purposes in
Cuttack, with these provisos:I. That pensions obtained from the Government of Berar under grants
prior to October 1803, should be continued to the then incumbents, and on their death should
descend to their heirs and successors or revert to Government, as should appear to the
Governor-General in Council [1] [The words 'Governor-General in Council' in Section 30 of Bengal
Regulation XII of 1805 are now to be read as if the words 'Local Government' were substituted
therefor (See Act I of 1903, Schedule 2).] on a consideration of the tenor of the grant and all the
circumstances of the case to be proper, under Section 4 of the said Regulation [2] [The words and
figure 'under Section 4 of the said Regulation' are omitted since the words and figures under Section
4, Regulation XXIV, 1793' in Section 30 of Bengal Regulation XII of 1805 were repealed by Act XII
of 1891.],II. Pensions received, under whatever authority, for three or more years before October,
1803, to be continued to the then incumbents for life; but on their death to revert to Government,
unless any particular reasons should appear to Governor-General in Council to exist for continuing
them to their heirs and successors.In the terms 'on a consideration of the tenor of the grant'
contained in the proviso I, we find the first indication of Government prescribing a Rule to itself
respecting the continuance of a pension to heirs and successors or incumbents. Section 4,
Regulation XXIV, 1793, to which reference is made, contains no such rule [2] [The words and figure
'under Section 4 of the said Regulation' are omitted since the words and figures under Section 4,
Regulation XXIV, 1793' in Section 30 of Bengal Regulation XII of 1805 were repealed by Act XII of
1891.].By Section 7, Regulation XXII, 1806, the Board were instructed in determining whether, on
the death of a pensioner, the pension, or any part of it, should be continued to heirs or successors,
'to ascertain particularly the situation and circumstances of the person claiming the continuance of
the pension, and not to comply with any applications of that nature, unless on the ground of poverty
or other substantial reason, the party claiming it shall have a strong claim on the indulgence of
Government".This relates to pensions to a certain amount (fifty rupees) left to the Board's decision;
but I presume the principle was applicable to all.Section 8 enjoined Collectors to discontinue the
payment of all pensions where the persons to whom they had been adjudged had died, until it could
be determined whether they were to be continued to heirs.Section 9 had in view the commutation of
money pensions for grants of waste land or property.It begins by repeating the declaration that
pensions are gratuitous, and that the continuance or discontinuance of them is to depend on the
pleasure of Government.It then enacts that adjudged pensions are not to be commuted for grants of
land except with the consent of the pensioner, and adds these further provisos:-That pensions
granted for and bona fide appropriated to the support of institutions, either of the Hindu or
Muhammadan religion, shall be continued for the support of such institutions, unless the present
incumbents or their successors shall of their own free will and accord, agree to accept waste lands in
lieu of the said pensions, and that no pensions which are declared to be hereditary either by the
terms of the grant or by any existing regulation, shall be commuted without the consent of the
present pensioners or their successors.The first proviso has been quoted as containing an abstract
Rule that pensions for the support of the institutions therein described shall be continued in
perpetuity, but considering the whole scope of the Section, it seems to me rather to mean that so
long as the allowances are continued by the pleasure of Government, they shall be continued in the
shape of money payments, unless the incumbent for the time being consents to a commutation for
land.So also in respect of pensions which, in consideration of the terms of the grant, the
Government may hereafter continue to the heirs of present incumbents. These shall likewise beBihar Board's Miscellaneous Rules, 1958

continued in the shape of money payments, unless with the consent of the heirs to whom it is
continued, it shall be commuted for land.The same Rule to apply to pensions declared hereditary by
the Regulation i.e., those described in Section 2, Regulation XXXIV, 1795, and Section 2, Regulation
XXIV, 1803, which are declared to be property, and liable to be used for and inherited as such, and
are distinct from the gratuitous pensions.Suppose, then a case in which the grant was not hereditary
by the terms of it but which the Government thought it right to continue to the heir of a deceased
incumbent, they might insist on his taking land in lieu of it or renouncing all claim to the
allowance.Sections 2 and 3, Regulation XI, 1813, enact that all pensions shall be stopped until those
receiving them prove that they are either the original grantees, or that they have been regularly
declared entitled to succeed to the enjoyment of the pensions, and that new registers shall be made
and corrected as often as any pensions revert wholly or in part to Government, or whenever other
individuals than those by whom the pensions are at present received, shall be adjudged entitled to
the reversion of them.So far, then as the law is concerned, it appears to me that the continuance or
discontinuance of any pension or allowance on the death of an incumbent rests entirely in the
discretion of Government, that when continued it should be for the life of the applicant only.In
practice, I believe, the Government has very much fettered itself in the exercise of this
discretion.XXV. Distribution of pensions. - As a Rule, the distribution of pensions is irrespective of
Hindu or Muhammadan law, and dependent on the pleasure of the Government only.In cases where
the original grant of a pension to two or more persons was joint and undivided, the survivor or
survivors shall be considered entitled to retain only an exact half, or a lesser share, according to
circumstances of the whole sum without reference to sex.XXVI. Grant of certificate. -
Notwithstanding anything contained in Rule XXV when the grant was of a specific sum annually,
payable in perpetuity and unconditionally, the district officer may, with the sanction of the
Commissioner and the Board, grant a certificate to the civil court under Section 6 of the Pensions
Act, XXIII of 1871, where the question at issue is the right of one or other of two parties to receive
any portion of such grant.
Chapter XII
Holidays
236. Classes of holidays.
- The holidays given in public offices are divided by the Government of India into four
classes:-(i)those prescribed by Section 25 of the Negotiable Instruments Act, XXVI of 1881;(ii)those
declared by the Provincial Government by Notification under Section 25 of the Negotiable
Instruments Act to be public holidays;(iii)those announced by the Provincial Government to take
effect in Government offices either in respect of all classes of Government servants or in respect of
the class who observe the fast or festival on account of which the holiday is announced; and(iv)those
not announced by the Provincial Government, but given at the discretion of the Commissioners of
Divisions subject to the general control of the Board of Revenue, on the occasion of a local fair or
festival or for some other reason i.e., local holidays.Bihar Board's Miscellaneous Rules, 1958

237. Holidays under class I.
- The holidays in class I are all Sundays, New Year's Day, and Christmas Day (and, if either of the
two days last mentioned falls on a Sunday, the next following Monday) and Good Friday.
238. Holidays under class II.
- Since holidays in class II shall be notified under the Negotiable Instruments Act on such date as
may be appointed for the celebration of the King's birthday in India. If on any special occasion an
additional State holiday should be required for a particular purpose it will be notified by the
Provincial Government at the request of the Government of India.
239. General holidays.
- The general holidays which are given for the observance of Christian, Hindu and Muslim festivals
and sacred days are distributed between classes (ii) and (iii).
240. Christmas holidays.
- In accordance with the instructions of the Government of India regarding the Christmas holidays,
the 24th (or the 23rd, if the 24th is a Sunday), the 26th, the 27th and the 31st of December will in
future be included to class (ii) and be notified under the Negotiable Instruments Act to be public
holidays and the 28th, 29th and 30th of December will be included in class (iii) and be announced
as holidays in Government offices.
241. Easter holidays.
- As regards the holidays as Eastertide, both the Saturdays before Easter and Easter Monday will be
included in class (ii) and notified under the Negotiable Instruments Act. No further holidays will be
either notified under the Act or otherwise announced for Eastertide.
242. Hindu holidays and Muslim Holidays.
- The Hindu holidays are distributed between holidays notified under the Negotiable Instruments
Act and those declared to be such by executive order of Government. The Muslim holidays except
Muharram, Id-uz-Zuha and Id-ul-Fitr are included in class (iii) and will be annually announced by
Government as heretofore.
243. Conditions under which public holidays should be observed in
Government offices.
- With regard to the conditions under which public holidays should be observed in Government
offices, the Government of India have expressed the following opinions:(1)That all public holidaysBihar Board's Miscellaneous Rules, 1958

under the Negotiable Instruments Act should be given as holidays to all Government servants,
subject to the single condition that it should be open to the head of an office to stop such a holiday in
the case of any person guilty of idleness or in attention to duty, unless the day in question is deemed
specially sacred by the members of the religion which the offender professes.(2)[x x x x x](3)That [x
x x x] the general rule on holidays announced under executive order should be to close an office only
when the absence of the persons, on whose behalf the holiday is given, will not prevent the work of
the office from being properly done.(4)That an exception to the rule in last preceding clause should
be made in the case of Christian holidays all of which should, if possible, be given to all
establishments, whatever their race or creed.Provision must always be made for urgent office work
even when, owing to the staff being nearly all Hindus, it is not practicable to carry on the regular
work on a Hindu holiday given by executive order.
244. [] [Vide Bihar and Orissa Government Circular No. 4-A, dated 22nd April,
1915.]
Full discretion to grant local holidays shall be allowed to the Commissioners of Divisions, subject to
the general control of the Board of Revenue and to the following conditions:-(a)The total number of
local holidays shall be limited to seven days over and above the days notified by the Provincial
Government under the Negotiable Instruments Act or declared by them to be holidays by executive
order.(b)With the approval of the Board of Revenue the Commissioner may sanction the observance
of local holidays in any district in excess of the prescribed limit of seven days in the year provided
that a corresponding number of gazetted holidays be given up as a set-off against the excess in the
number of local holidays.These orders are merely intended to allow a discretion to the local
authorities to grant holidays, not otherwise admissible, on occasions of particular sanctity and
importance. The additional holidays admissible under them should only be granted when and to the
extent, really necessary on public grounds.These orders do not affect the grants:-(a)by the head of
an office where it has actually been enjoyed in practice of a holiday on the last Saturday of each of
the months of May and June;(b)of holidays by local officers on the special occasion of solar or lunar
eclipse;(c)to Brahmo and Jain Officers of the special holidays permissible to them under Rules 248
and 249 below which will continue in force;(d)of holidays in the civil courts, which are regulated by
the orders of the Chief Judicial authorities;(e)of a local holiday on the 11th day of the Muharram in
the Patna, Tirhut and Bhagalpur Divisions; or(f)by Commissioners of local holidays to the gazetted
and ministerial staff at District and sub-divisional offices for the purpose of a by-election to the
Council or the Assembly.
245.
The head of any office may, subject to the control of his superior officers, give a holiday to his
subordinates on the last Saturday of each of the months of May and June provided that the state of
work admits of it.Bihar Board's Miscellaneous Rules, 1958

246.
For the guidance of Commissioners in fixing local holidays under these orders two lists are given
below: List (A) showing the holidays that will ordinarily be notified by the Provincial Government
under the Negotiable Instruments Act or by executive orders, and List (B) showing the local holidays
that will ordinarily be observed in each district.List AHolidays which will ordinarily be notified as
Gazetted HolidaysI. Under The Negotiable Instruments Act
A-Prescribed by the Act-  
 Days
(In addition to Sundays) New Year's Day, Christmas Day, (ifeither of the two latter days fall
on a Sunday, the nextfollowing Monday) and Good Friday3
B-To be notified by Government-  
Id-ul-Fitr 1
Basant Panchami 1
Falgun Shivaratri 1
Holi 1
Easter Saturday 1
Easter Monday 1
Chaitra Sankranti 1
Ram Nawami 1
Birthday of Lord Mahavira 1
Birthday of Lord Buddha 1
Id-uz-Zuha 1
Muharram 1
Ganga Dasahara 1
King Emperor's Birthday 1
Janmastami 1
Birthday of Mahatma Gandhi 1
Mahalaya 1
Dasahara [Durga and Lakshmi Pujas] 5
Diwali 1
Dawat Puja 1
Chhat 1
Christmas Eve 1
The first and second days following Christmas 2
Last day of the year 1
II. By Executive OrdersBihar Board's Miscellaneous Rules, 1958

Hindu-  
Holi 1
Dasahara (Durga and Lakshmi Pujas) 6
Diwali 1
Muslim-  
Id-ul-Fitr 1
Muharram 1
Chehlum 1
Id-uz-Zuha 1
Fatiha Dwazdahum 1
Christian-  
Third, fourth and fifth days afterChristmas 3
List BLocal holidays that will ordinarily be observed in each District of Bihar
Division DistrictNames of local
holidaysNumber
of daysTimeHolidays under the Negotiable
Instruments Act orby executive
order to be replaced by the local
holidays in excessof seven
1 2 3 4 5 6
Patna Patna GayaShivaratri
(extra)1February or
March 
 Shahabad Holi (extra) 1 March  
  Janmastami
(extra)1August or
September 
  Ananta Puja 1August or
September 
  Ramnavami
(extra)1 April  
  Sonepur Fair 2 November  
  Total 7   
Tirhut Saran Tilsankranti ½ January  
  Makrama wasya ½ January  
  Holi (extra) 1 March  
  Janmastami ½August or
September 
  Anant Puja ½August or
September 
  Sonepur Fair 4 November  
  Total 7   
     Days.Bihar Board's Miscellaneous Rules, 1958

 Champaran Til Sankranti 1 January Chhath 1
  Ramnavami
(extra)1 April Diwali 1
  Holi (extra) 2 March Total 2
  Anant Puja 1August or
September 
  Sonepur Fair 4 November  
  Total 9   
 Muzaffarpur Holi (extra) 2 March  
  Ramnavami
(extra)1 April  
  Sonepur Fair 4 November  
  Total 7   
Tirhut Darbhanga Pous Sankranti 1 January  
  Holi (extra) 1 March  
  Ramnavami
(extra)1 April  
  Sonepur Fair 4 November  
  Total 7   
Bhagalpur Munger Maghi Purnima 1 February  
  Ramnavami
(extra)1 April  
  Ananta Puja 1August or
September 
  Sonepur Fair 4 November  
  Total 7   
 Bhagalpur Baunsi Fair 1 January  
  Ramnavami
(extra)1 April  
  Ananta Puja 1August or
September 
  Sonepur Fair 4 November  
  Total 7   
 PurneaRamnavami
(extra)1 April  
  Ananta Puja 1August or
September 
  Khagra Fair 1December or
January Bihar Board's Miscellaneous Rules, 1958

  Sonepur Fair 4 November  
  Total 7   
Chota
NagpurSanthal
ParganaBaunsi Fair 1 January  
  Bandana 1 January  
  Hijla Mela 1January or
February 
  Maghi Purnima 1 February  
  Baha 1March or
April 
  Rath Jatra 1 June or July  
  Bhadra Purnima 1 August  
  Total 7   
 Hazaribagh Holi (extra) 1 March  
  Rajbi 1 June  
  Karma 1 September  
  Jitia 1September
or October 
  Kartik Purnima 1 November  
  Muharram
(extra)1   
  Total 6   
 Ranchi* Pous Sankranti 1 January  
  Shivaratri 1February or
March 
  Holi (extra) 1 March  
  Rath Jatra 1 June or July  
  Ananta Puja 1August or
September 
  Karma 1 September  
  Koljatra 1 November  
  Total 7   
 PalamauMakar
Sankranti1 January  
  Shivaratri
(extra)1 February  
  Chehlum 1 May  
  Rath Jatra 1 June or July  
  1  Bihar Board's Miscellaneous Rules, 1958

Janmastami
(extra)August or
September
  Ananta Puja 1 Ditto  
  Muharram
(extra)1   
  Total 7   
 Manbhum Pous Sankranti 1 January Diwali (Annakut Puja) 1 day
  Basant
Panchami1 February
  Rath Jatra 1 June or July
  Jagadhatri Puja 1October or
November
  Kali Puja 1 Ditto
  Bhratridwitiya 1 November
  Shab-e-Barat 1 ---
  Total 7   
 SinghbhumMakar
Sankranti1 January Diwali (Annakut Puja 1 day)
  Basant
Panchami1January or
February
  Holi 1 March
  Rath Jatra 1 June or July
  Rakhi
(Purnima)
(Goma)1 August
  Ananta Puja 1August or
September 
  Karma 1 September  
  Kali Puja 1October or
November 
  Total 8   
* In exchange for the local holidays allowed in the rest of this district for 'Karma' and 'Koljatra'
festivals, a local holiday of one day in each of the months of January and May is allowed in the
Khunti Sub-Division and of two days in the month of November the Simdega Sub-Division on
account of 'Khunti Jatra' and 'Sriramrekha Asnan' respectively.
247. Special holidays for Muslim Officials.
- Muslim officers and employees attached to the magisterial courts and revenue offices may be
allowed to absent themselves from office on the following days in addition to the Muslim holidaysBihar Board's Miscellaneous Rules, 1958

annually announced by Government:
Id-ul-Fitr .........1
Muharram .........3
Id-uz-Zuha .........1
Shab-e-barat .........1
Note. - In Patna,Tirhut and Bhagalpur Divisions the eleventh days of Muharram is declared to be a
local holiday and in the rest of the province, it may be allowed as a holiday for Muslim employees
only.
248. And for Brahmo officials.
- Revenue officers should allow Brahmo officials to absent themselves from their duties on the 11th
day of Magh in each year, when possible, and, as a rule, should not fix cases in which Brahmo
suitors or witnesses are concerned for hearing on that day or on the days immediately preceding or
following it.
249. And for Jain officials.
- Revenue officers should, when possible, allow Jain officials to absent themselves from their duties
on the day on which their annual festival "Kartik Purnima" falls, and, as a rule should not fix cases
in which Jain suitors or witnesses are concerned for hearing on that day.
Chapter XIII
Leave
250.
The rules for the absence on leave of members of the All India Services are contained in the
Fundamental Rules and those in respect of members of the Provincial and Subordinate Services and
Special Officers under the administrative control of the Provincial Government are contained in the
Bihar Service Code.
251. Mode of application by Subordinate Officer.
- An Assistant, Deputy or Sub-Deputy Collector requiring leave of absence, must make his
application to the Collector, who will forward it to the Commissioner with an endorsement stating
whether or not leave may unobjectionably be granted. The Commissioner will exercise his discretion
in submitting the application, through the Accountant-General to Government or declining to do
so.Note. - The Commissioner is himself competent to grant leave to a Deputy Collector and
Sub-Deputy Collector employed on general duty, for a period not exceeding one month and six
weeks respectively, if local arrangement can be made for carrying on the absentee's work.Bihar Board's Miscellaneous Rules, 1958

252. Commissioner to suggest arrangements.
- Whenever a Commissioner submits to Government an application for a short leave of absence from
any of his subordinates, he must suggest the arrangements which should in his opinion be made for
carrying on the duties of the absentee during his absence.Note. - Rules for the grant of casual leave
and quarantine leave, and permission to leave the station or province during casual leave or on
gazetted holidays will be found in Appendix 13 to the Bihar Service Code.
253. Absence on volunteer duty.
- Absence on volunteer duty should be treated as time spent on duty and not as absence on casual
leave.
Chapter XIV
Public Buildings and Lands
254. Plans of lands.
- Plans of all lands in a district which are in the possession of any department of Government for
public purpose, or are held by municipalities, district boards and local boards from Government and
for which the maintenance of plans is not provided for by the Land Acquisition Manual are to be
deposited in the Collector's office, except plans of lands in the direct occupation of the Public Works
Department.
255. Register of lands.
- A Register (No. 6) of all lands used for public purposes is to be kept. Lands in the occupation of
municipalities, district boards and local boards should be entered in Register 6-A. Detailed
instructions regarding these two registers are given in the Register and Return Manual.
256. Selection of sites for Central and Provincial buildings cost of which is
less than Rs. 5,000.
- The following rules have been laid down for selection of sites for Central and Provincial buildings
when cost is less than Rs 5,000:-[Public Works Department Circular Memo No. 5367-B, dated the
31st March, 1920].(1)The selection of a site for a proposed building must be dealt with as soon as a
demand is received for an estimate from an officer authorised to call for it.When a rough estimate is
called for a general report regarding the proposed site will be given which will accompany the
estimate when it is sent up for administrative approval.(2)As soon as demand for an estimate as in
paragraph (1) or administrative approval to an estimate sent under (1)(a) is received the Executive
Engineer shall in consultation with the District Magistrate and the local Head of the Department
concerned select a site for the proposed building and make out the usual plans.If the building is inBihar Board's Miscellaneous Rules, 1958

the compound of an existing Government building a block plan only will be required.This must
show the whole compound and all the buildings existing or proposed within it.In a case where land
has to be acquired, the Executive Engineer will at once apply to the Collector for an estimate and
draft declaration for the land.In outlying stations, the District Magistrate, Executive Engineer and
the local Head of the Department concerned may delegate their subordinates to represent
them.(3)The Executive Engineer will be responsible that the site selected is suitable for building
on.In case the Executive Engineer has any doubt as to the suitability of the proposed site on sanitary
grounds, he should consult the Civil Surgeon on this point.(4)If the site selected is on land already in
charge of the Public Works Department, the site plan will be signed by the Superintending Engineer
before the estimate is sent up for technical sanction.When the land is in charge of the department
concerned, the signature of the head of that department on the plan will be necessary.(5)In cases
where there is difference of opinion regarding the suitability for a site among the officers referred to
in Rule (2) the matter will be referred by the Superintending Engineer to the Commissioner of the
Division, whose decision shall be final in the case of provincial buildings but in the case of central
buildings the decision of the Government of India is necessary.(6)When the site is within a
municipality or controlled area, the signature of the Chairman of the municipality or of the
President of the local committee, will be necessary before technical sanction is given.Note 1. - In the
case of buildings proposed to be constructed at Ranchi and Doranda (including Hinoo) the site plan
or the proceedings of the site committee or both, as the case may be, should be submitted through
the administrative department concerned for the approval of the Provincial Government.Note 2. -
The Public Works Department (Road and Buildings) representative on site committee is there to
advice the committee on the engineering aspects of the site just as the Civil Surgeon is there to
advise on the hygiene aspects. Generally speaking in the province, the more important engineering
points are :(a)Is the site swampy, low or liable to flood?(b)Is the soil suitable for foundations or will
special treatment be necessary in the case of-(1)soil liable to expansion and contraction, or soil of an
abnormal nature.(2)made ground.(c)Is the building oriented in the right direction with reference
to-(1)the view,(2)ventilation,(3)verandah protection,(4)orientation of rooms required for specific
purposes.(d)Is the site suitable for excavation of a well?Sufficient attention has not been paid to
these points resulting in some cases in (1) building having been faced the wrong way rendering
unsightly and expensive additions necessary, (2) heavy unforeseen expenditure in expensive
foundations, and (3) buildings having been built on soil which expands and contracts without
precautions having been taken to counteract this, resulting in some cases, in the building having had
to be condemned.Steps should be taken to ensure that the Public Works Department representative
examines the site and advises the site committee from an engineering point of view completely and
thoroughly. Trial pits should invariably be dug at several points and the soil examined by a
responsible officer and the section shown on the site plan with a correct description of the soil.
Where a notification under Section 4 has not yet issued, owners of land can legally object to trial pits
being dug, but this is not often the case in practice.
257. Selection of sites for Central and Provincial buildings cost of which is
Rs. 5,000 or more.
- The following rules have been laid down for the selection of sites for Central and Provincial
buildings when cost is Rs. 5,000 or more:-[Public Works Department Circular Memo No. 5363-B,Bihar Board's Miscellaneous Rules, 1958

dated the 31st March, 1920].(1)Paragraph 205, Chapter II, Public Works Department Code, Tenth
Edition lays down that "the site of every building should, if possible, be definitely settled before the
detailed designs and estimates are prepared" but in the orders contained in Government of India's
Circular No. 6 RW., dated the 20th August, 1913, permission was given to proceed with the
acquisition of a site as soon as administrative approval is accorded. The Executive Engineer should,
therefore, unless instructed to the contrary, take steps to have a site selected as soon as requisition is
received from a competent authority for an approximate estimate for a building project.(2)On
receipt of administrative approval to a project for which a site has not yet been duly selected, the
Executive Engineer shall at once ask the District Magistrate to convene a site committee and as soon
as the site has been selected, he will apply for an estimate for the acquisition of land, if necessary,
and submit it with the draft declaration, through the usual channel, to the authority competent to
sanction it. The amount of this estimate should be subsequently incorporated in the detailed
estimate for the project.(3)The selection of sites for buildings at places other than the New Capital
Area, Patna and Ranchi shall ordinarily be made by a committee composed of-
The District Officer ...President
The Civil Surgeon ... 
The Executive Engineer ...] Members
An officer representing the department concerned ...
If the proposed site is within a municipality or controlled area, the Chairman of the municipality or
President of the station committee shall be a member "ex officio". Where the question of sanitary
fittings and (or) pipe water-supply has to be considered, an intimation should be given to the
Superintending Engineer, Public Health Engineering Department, to enable him to arrange that the
Public Health Engineering Department is represented at the site committee.In outlying stations
members may, on their own responsibility, depute subordinates not below the rank of a gazetted
officer, to represent them.If for any reason any member of the committee cannot attend on the date
fixed his opinion may be taken separately, the plans and proceedings being sent to him for the
purpose by the District Officer.This committee will be assembled by the District Officer at the
request of Executive Engineer."The committee should meet on the first Monday of every month, or,
if the first Monday be a public holiday, on the first working day thereafter, whenever there is
business to be transacted. In urgent cases the committee should meet oftener, and the meeting
should be held within ten days of a requisition being received from the Executive Engineer.(4)The
Executive Engineer will prepare a plan of the site selected embodying such information on the above
points as may be necessary in each case, e.g., if the site is on land liable to be flooded, the highest
flood level should be shown with reference to the general level of the site. He will forward this plan
with the proceedings of the Committee after both have been countersigned by the members, to the
Superintending Engineer of the circle.He will be responsible for any action required under
Paragraphs 206 and 207 of the Public Works Department Code and will place before the site
committee an expression of opinion received from the Military Department.(5)The Superintending
Engineer will, if he agrees with the conclusion of the committee both as regards the site and
arrangement of the buildings countersign the papers and forward them to the Head of the
Department concerned for counter-signature and transmission to the Commissioner of the Division
for signature and return to the Executive Engineer.(6)If the members of the committee are unable toBihar Board's Miscellaneous Rules, 1958

agree or if the Superintending Engineer differs from their conclusions, he will in the event of failing
to come to an agreement with the President of the Committee, submit the case to the Commissioner
of the Division for decision, attaching his note to the proceeding of the Committee. After deciding
the case so referred, the Commissioner will communicate his decision to the Superintending
Engineer and to the President of the site committee, forwarding the plans as approved to the
Superintending Engineer for disposal by the Head of the Department. Whenever possible, the
Superintending Engineer should discuss the matter personally with the President before forwarding
the case to the Commissioner.(7)In cases where the views of the Head of the Department differ from
those of the local authorities, the matter should be referred for the decision of Government. Decision
of the Government of India is required in the case of central buildings.(8)In the case of important
buildings the Governor desire that Heads of Departments will, before countersigning the plan send
it to the Director of Public Health and Superintending Engineer, Public Health Engineering
Department, for opinion.(9)Two plans are required-(a)A block plan, scale 41¼ to the inch, or, if this
is too large 82½ to the inch, showing the relative position of all buildings, wells etc., included in the
project as well as all existing buildings, wells, etc., in the same compound.(b)An index plan, scale 16
or 32 inches to the miles, showing the site and its surroundings on north, south, east and
west.(10)Selection of sites for Government buildings in the New Capital Area, Patna and Ranchi
(including Doranda and Hinoo). - In view of the importance of sites at the State headquarters and at
Ranchi, Government have decided that a Site Selection Committee consisting of the following
should be constituted for selection of sites for public buildings to be constructed in the New Capital
Area, Patna and Ranchi (including Doranda and Hinoo).
1. President. - The Commissioner of Patna or Chotanagpur Division as the
case may be.
2. Members. - (i) Secretary to Government of Public Works Department.
(ii)Head of Administrative Department concerned or any officer nominated by him.(iii)Chief
Engineer, Public Works Department (R. and B.) or Superintending Engineer nominated by
him.(iv)Chief Engineer, Public Health Engineering Department or an officer nominated by
him.(v)Superintending Engineer, South Bihar Circle or Chotanagpur Circle as the case may
be.(vi)Government Architect or the Assistant Government Architect nominated by him.(vii)Civil
Surgeon, Patna or Ranchi as the case may be.(viii)Town Planner or the Assistant Planner nominated
by him.(ix)The Chief Executive Officer, Patna Municipal Corporation or Chairman, Ranchi
Municipality, Doranda Notified Area Committee, as the case may be or any of his nominees.In view
of the importance of the site selection at Patna and Ranchi, Government desire that the Divisional
Commissioner should personally preside over the meetings for selection of sites in the New Capital
Area, Patna or Ranchi unless, due to exceptional reason, he has to go out of the headquarters on the
date such a meeting is fixed. In that case the Collector, Patna or the Deputy Commissioner, Ranchi,
who should be briefed by the Commissioner shall attend the meeting of the Site Selection
Committee on behalf of the Divisional Commissioner. Similarly if for exceptional reason the
Secretary, Public Works Department is unable to attend a meeting of the Committee personally, an
officer of the Department briefed up by him shall attend the Committee meeting in his place.The
Site Selection Committee for the New Capital Area, Patna and Ranchi shall be convened by theBihar Board's Miscellaneous Rules, 1958

Divisional Commissioner on a requisition from the Superintending Engineer. The Committee
should meet on the first Friday of every month, or if the first Friday is a public holiday on the first
working day thereafter, whenever there is a business to be transacted; but in urgent cases the
committee should meet within ten days of a requisition being received from the Superintending
Engineer.
258. Thatched buildings forbidden.
- Thatched buildings may not be erected upon the premises surrounding any public building without
a reference to the department in whose charge the building is.
259. Inflammable buildings not allowed within a radius of 50 yards of a
permanent building.
- No building with roofs composed of thatch or other inflammable material should be constructed
within a radius of 50 yards of a building constructed of permanent materials. When circumstances
admit, inflammable buildings of a temporary nature should be placed at a greater distance than 50
yards from permanent buildings, more specially in the case of court houses or record buildings or
other buildings of a valuable nature (Board's Circular No. 4 of February, 1906).
260. Senior officer to countersign plans.
- When it is proposed to enlarge kachahris or other buildings for the accommodation of offices or
courts other than those by which they are occupied, or to erect building near other public buildings,
the senior officers of the department occupying the existing buildings should countersign the plans,
in token that there is no objection on their part to the proposed arrangement. (Bengal Government
Circular Order No. 48, dated the 24th June, 1896).
261. Duties of officers-in-charge of public buildings.
- All civil officers, who have public buildings in their charge, are frequently to inspect them and to
see that they are kept clean. Some person of the establishment should be made answerable for the
general condition of the building, including the glass in each room and the fixtures, also for keeping
a watch on the attacks of white ants, for paying strict attention to the cleanliness of the interior and
the neatness of the exterior of the building and its surroundings etc., and for keeping the rain water
down-pipes and surface drains (where such exist) free from all obstructions. The charge for such
items and for petty repairs of doors and windows (including the replacement of broken glass) shall
be made by the officer concerned in his contingent bills. Repairs of all other kinds will be carried out
by the Public Works Department. The estimates for such repairs will be sanctioned by the Executive
Engineer in the beginning of the repair year and funds allotted. These instructions do not apply to
residential building, all repairs to which should be executed and accounted for by the Public Works
Department, whether rents for the buildings are recovered from the occupier or not.Bihar Board's Miscellaneous Rules, 1958

262. Execution of leases of houses.
- When a house or office is leased for the use of departments subordinate to the Board, the deeds
and instruments should be executed by the Collector or Deputy Commissioner [vide Item D-3(a) of
the resolution of Government of Bihar in the Judicial Department, No. 1827J, dated the 14th April,
1951, issued under Section 175 (3) of the Government of India Act, 1935], Under Item D-2(a) and
3(a) of the resolution, Collectors and Deputy Commissioners are empowered to execute deeds of
contracts and other instruments in matters connected with the lease or sale of land also.
263. Sub-Divisional Officer's residence.
- An officer appointed to the charge of a Sub-Division is entitled to be provided with accommodation
for his residence free of cost, or to house allowance in lieu thereof.
264. When not provided with a house at a Sub-Division.
- When there is no Government residence at the Sub-Division, he will, for the first three months,
draw the daily allowance to which he is entitled by the rules of his service when out in camp. After
that period he will draw Rs. 50 per mensem until accommodation is provided for him.Note 1. - Rules
263 and 264 do not apply to Sadr Sub-Divisional Officers Government Order No. 934-A, dated the
10th March, 1916-Note 2. - The officers holding charge of Manbhum Sadr Sub-Division shall be
entitled to a rent-free house or, if no quarters are available, a house rent allowance of 10 per cent of
pay or the actual rent paid, whichever is less.[Vide Appointment Department letter No.
A/M-1-3014/54-AR/201, dated, the 31st May, 1955, to the Commissioner of the Chotanagpur
Division].
265. When absent on tour.
- If during the three months mentioned in Rule 264, an officer leaves his headquarters and marches
in the interior of his district, the allowance under that clause will cease; and during the period of his
absence on tour, he will be entitled to draw house allowance only at the rate of Rs. 50 a month in
addition to the mileage or daily travelling allowance to which he may be entitled.
266. When the residence is under repair.
- When an officer-in-charge of a sub-division is obliged to vacate his residence for any extensive
repairs or alterations to the building between the 1st of April and the 1st of November, he will be
entitled to the same allowances as an officer taking charge of a sub-division at which there is no
Government residence, that is, he will draw the daily allowance according to the rules of his service
for the first three months and Rs. 50 a month afterwards, until his residence is again ready for
occupation.Bihar Board's Miscellaneous Rules, 1958

267. Period when repairs to be made.
- The Department of Public Works will, however, always endeavour to make such repairs between
the 1st of November and 1st April, when the Sub-Divisional Officer can reside in his tent, and when
he will draw no allowance, unless he is out in the interior of the sub-division.
268. Assistant or Deputy Magistrates and Collectors temporarily stationed in
the interior.
- Occasions frequently arise on which it is necessary to depute Assistant or Deputy Magistrates and
Collectors from their headquarters into the interior of the District on duties which enable them to
make their temporary headquarters at a sub-division or elsewhere, and which do not require
constant marching about. On such occasions the officers will draw full travelling allowance
according to the Rules in force for the first month of their halt at any spot and half the allowance for
the second and third months. After the third month this halting allowance will cease altogether. This
rule is not meant to interfere with the right of the officers to draw full mileage or travelling
allowance during the second, third and subsequent months, for days on which they may be
marching to make tours of inspection, etc.
269. Free quarters not meant for pecuniary gain.
- Persons living in Government building free of rent cannot utilize such buildings or portions of such
buildings to their own pecuniary advantage by subletting and appropriating the rent.
270. Resumption of grants.
- All civil or military grants of land either revenue free or at favourable rates, shall contain a
condition for forfeiture in the event of misconduct or failure of loyal behaviour or failure to render
active support to Government. Such grants shall also contain a condition that if the grantee alienates
the land it shall immediately become liable to the full revenue demand.
271. Committee of arbitration in cantonments.
- The Collector is to be a member of the committee of arbitration for valuing premises, the property
of individuals, in cantonments, in case of necessity, according to the military law.
272.
The procedure in connection with works executed by the agency of the Public Works Department is
laid down in Paragraphs 77, 204, 222-229, 247-250 and 251-255 of the Bihar Financial Rules.Bihar Board's Miscellaneous Rules, 1958

273. Division of works into major and minor.
- Works whether new, or additions or alterations to existing works, are divided into two main
divisions : (A) works other than residences, and (B) residence of Government officials and each of
these classes into; (1) major works estimated to cost more than Rs. 10,000, and (2) minor works
estimated to cost not more than Rs. 10,000.[Revenue Department Resolution No. 2026-T.R., dated
the 30th October, 1911].
274. Powers of administrative approval of Civil and Public Works Officers.
- In supersession of the previous orders on the subject, Government in the Public Works
Department has delegated the following powers of administrative approval to Civil and Public
Works Officers, and has also laid down the following rules and procedure regarding technical
sanction to estimates, the allotment of funds and the submission of Projects:-[Public Works
Department Resolution No. H/Code-202/55-PW. 14, dated the 12th March, 1955].Section IOriginal
works other than residential buildings and individual projects of water-supply and sanitary and
electrical installations
2. (A) Public Works Officers-
Authority to whom the
power is delegated Extent of powers delegated.
Chief Engineers (a)Rs. 10,000 for non-residential buildings belonging to
hisdepartment, the cost of which is debitable to the Public
WorksGrant.
 (b)Rs. 5,000 for Miscellaneous works belonging to his department,the
cost of which is debitable to the Public Works Grant.
Chief Engineer (B. and R.) (c)Rs. 10,000 for Communication Works.
Superintending Engineers (a)Rs.5,000 for non-residential buildings belonging to hisdepartment,
the cost of which is debitable to the Public WorksGrant.
 (b)Rs. 2,500 for Miscellaneous works belonging to his department,the
cost of which is debitable to the Public Works Grant.
Superintending Engineers
(B. & R.)(c)Rs. 10,000 for Communication Works.
(B)Civil Officers-
1.The Board of Revenue ...Rs. 10,000 for
non-residential buildings
belonging to hisdepartment,
the cost of which is
debitable to Public Works
Grant.
2. ...Bihar Board's Miscellaneous Rules, 1958

The Registrar, High Court,
Patna
3.The Director of Public
Instruction...
4.The Inspector-General of
Police...
5.The Inspector-General of
Prisons...
6.The Inspector-General of
Registration...
7.The Director of Health
Services...
8.The Commissioner of
Commercial Taxes...
9.The Commissioner of Labour ...
10.The Commissioner of Excise ...
11.The Chief Conservator of
Forests...
12.The Registrar of Co-operative
Societies...
13.The Director of Agriculture ...
14.The Director of Animal
Husbandry...
15.The Director of Industries ...
16.The Cane Commissioner ...
17.The Commissioners of
Divisions...
18.The District and Sessions
Judges, including
JudicialCommissioner, Chota
Nagpur DivisionRs.
5000]For non-residential
buildings belonging to his
department, thecost of
which is debitable to the
Public Works Grant.
19.The District Magistrates and
Collectors and
DeputyCommissioner.Rs.
2,500
Note. - (i) Power delegated is inclusive of water-supply, sanitary and electrical installations where
such works form part of the main buildings project.(ii)Communication works include works on
roadside Inspection Bungalows, Rest Houses, etc.(iii)In the case of State Highways, the approval of
the Commissioner of the Division should be obtained before any material change is made in the
alignment of roads.(iv)Power delegated to Commissioners of Divisions includes works on Circuit
Houses.(v)Power delegated will not apply to works on the following non-residentialBihar Board's Miscellaneous Rules, 1958

buildings:-(a)Secretariat buildings at Patna and Ranchi and temporary barracks adjoining the
Secretariat compound at Patna.(b)Legislature buildings (both Assembly and Council) at
Patna.(c)High Court buildings at Patna.(d)Buildings used for residential purpose but are classified
as non-residential, e.g., police barracks, hostels peons, barracks, etc.(vi)Government in the Public
Works Department will accord administrative approval to all works relating to buildings mentioned
at (v)(a) and (b). As regards works relating to the buildings mentioned at (v)(c) administrative
approval will be accorded by the Government in the Law Department and at (v)(d) by the
administrative department concerned.Section IIResidential Buildings
3. Government in the Public Works Department will accord administrative
approval to the projects relating to-
(a)residences in the New Capital Area at Patna;(b)chambers, quarters, flats (including Legislature's
club), etc. meant for the members of both houses of Legislature at Patna;(c)residences at Ranchi
intended for occupation by Ministers, the gazetted officers of the Secretariat, and the Heads of
Departments and the gazetted officers attached to their offices;(d)clerks' quarters at Ranchi
intended for occupation by the ministerial staff accompanying Government and Heads of
Departments to Ranchi.Note 1. - The area of the New Capital is defined in the map forwarded with
this Department Memo No. 9577-85.A.R., dated the 7th June, 1927, to all Departments of
Government and includes the residences in the Patna-Gaya Road, Chhajubagh and near about the
Race Course (now Gandhi Maidan), Bankipur.Note 2. - The word "Residence" does not include the
clerks' quarters at Patna.
4. The following officers only are given powers of administrative approval in
respect of residential buildings, occupied by officers of their own
departments, the cost of which is debitable to the Public Works Grant,
subject to the proviso that the total cost of the buildings is not allowed to
exceed the monetary limits, noted against each and that the standard rent of
the buildings calculated under Fundamental Rules or Bihar Service Code
Rules as the case may be, shall not exceed 10 per cent of the average
emoluments of the class of tenants for whom it is intended and subject to the
further proviso that the projects conform to the type plans duly approved by
Government:-
 Authority to whom the power is delegated  Extent of power delegated
1.The Board of Revenue ...Rs. 7,500
2.The Registrar, High Court, Patna ...
3.The Director of Public Instruction ...
4.The Inspector-General of Police ...
5.The Inspector-General of Prisons ...Bihar Board's Miscellaneous Rules, 1958

6.The Inspector-General of Registration ...
7.The Director of Health Services ...
8.The Commissioner of Commercial Taxes ...
9.The Commissioner of Excise ...
10.The Commissioner of Labour ...
11.The Chief Conservator of Forests ...
12.The Registrar of Co-operative Societies ...
13.The Director of Agriculture ...
14.The Director of Animal Husbandry ...
15.The Director of Industries ...
16.The Cane Commissioner ...
17.The Transport Commissioner ...
18.The Commissioners of Divisions ...
19.The Chief Engineers ...
20.The Superintending Engineers ...Rs. 5,000
Note 1. - The Inspector-General of Police has power to pass excess in the standard rent over 10 per
cent of the average emoluments of the officers, subordinate to him.[Vide Finance Department's
Memo No. 11361-F., dated the 26th November, 1935].Note 2. - (i) Power delegated is inclusive of the
Water-Supply, Sanitary and Electrical Installation where such works are parts of the main buildings
projects.(ii)Power delegated above will not apply to any new work and also of work of addition or
alteration to existing residential buildings and quarters occupied free of rent.Section IIIIndividual
projects of water-supply, sanitary and electrical installations(A)Non-Residential Buildings
5. Outlay on the first installations of Water-Supply, Sanitary and Electrical
Works in a building will require the sanction of Government. The authorities
mentioned below have, however, been empowered to accord administrative
approval for additions, improvements and alteration to existing
Water-Supply, Sanitary and Electrical Installations, up to the limits specified
against them, subject to the proviso that such addition or alteration is in
accordance with the scale and type fixed by Government for a particular
class of buildings and where no such scale and type have been fixed it
should be certified by the estimating officers concerned that the proposed
works of additions, improvements and alterations is not in excess of the
need for the class of buildings to which the work relates:-
 Authority to whom the power is delegated  Extent of
power
delegated
Electrical installationBihar Board's Miscellaneous Rules, 1958

Water-supply or
sanitary installation
1. The Board of Revenue ...Rs. 5,000Rs.
1,000
2. The Registrar, High Court ...
3. The Director of Public Instruction ...
4. The Inspector-General of Police ...
5. The Inspector-General of Prisons ...
6. The Inspector-General of Registration ...
7. The Director of Health Services ...
8. The Commissioner of Commercial Taxes ...
9. The Commissioner of Excise ...
10. The Commissioner of Labour ...
11. The Chief Conservator of Forests ...
12. The Registrar of Co-operative Societies ...
13. The Director of Agriculture ...
14. The Director of Animal Husbandry ...
15. The Director of Industries ...
16. The Chief Engineers ...
17. The Commissioners of Divisions ...
18. The Cane Commissioner ...
19.The Superintending Engineers and District and
Sessions Judges,including Judicial Commissioner,
Chota Nagpur Division...Rs. 2,500Rs.
500
20. District Magistrates and Deputy Commissioners ...Rs. 1,000Rs.
250
Note. - (i) Powers delegated will apply to those non-residential buildings only the cost of which is
debitable to the Public Works Grant.(ii)Powers delegated will not apply to non-residential buildings
mentioned in note (v)(d) below paragraph 2.(iii)Power delegated to Commissioners of Divisions
includes works in Circuit Houses.(B)Residential Buildings
6. Outlay on the first installation of Water-Supply, Sanitary and Electrical
Works will require the sanction of Government. The authorities mentioned
below are, however, empowered to accord administrative approval on
additions, improvements and alterations to the existing Water-Supply,
Sanitary and Electrical installation in residential buildings including
outhouses, up to the limit specified against each, subject to conditions (a)
that the standard rent of the buildings calculated under Fundamental Rules
or Bihar Service Code Rules, as the case may be, shall not exceed 10 perBihar Board's Miscellaneous Rules, 1958

cent of the average emoluments of the class of tenants for whom it is
intended, (b) that such additions, improvements and alterations are in
accordance with the scale and type fixed by Government for a particular
class of buildings, and (c) where no such scale and type have been fixed, it
should be certified by the estimating officers that the proposed work is not in
excess of the need for the class of buildings to which the work relates:
 Authority to whom the power is
delegated Extent of power
delegated
Water-supply or sanitary
installationElectrical Works
1. The Board of Revenue ...Rs. 2,500Rs.
500
2. The Registrar, High Court ...
3. The Director of Public Instruction ...
4. The Inspector-General of Police ...
5. The Inspector-General of Prisons ...
6.The Inspector-General of
Registration...
7. The Director of Health Services ...
8.The Commissioner of Commercial
Taxes...
9. The Commissioner of Excise ...
10. The Commissioner of Labour ...
11. The Chief Conservator of Forests ...
12.The Registrar of Co-operative
Societies...
13. The Director of Agriculture ...
14. The Director of Animal Husbandry ...
15. The Director of Industries ...
16. The Cane Commissioner ...
17. The Transport Commissioner ...
18. The Commissioners of Divisions ...
19. Chief Engineers ...
20. Superintending Engineers ...Rs. 1,000Rs.
250
Note. - (i) Powers delegated will apply to works on those residential buildings only, the cost of which
is debitable to the Public Works Grant.(ii)Powers delegated will not apply to residential buildings
mentioned at paragraph 3 and note (ii) below paragraph 4.Section IVBihar Board's Miscellaneous Rules, 1958

7. The following Public Works Officers can authorise undertaking of Deposit
works up to the limit mentioned against their names for each work, provided
the conditions laid down in paragraph 283 of the Public Works Department
Code for the execution of such works are fulfilled:-
   Rs.
(1)Chief Engineers ...10,000
(2)Superintending Engineers ...5,000
(3)Executive Engineers ...200
Note. - The above limits exclude departmental charges.Section VTechnical Sanction
8. The following Public Works Officers have powers to accord technical
sanction to the estimates to the limit noted against each provided that-
(i)administrative approval has been accorded by the competent authority.(ii)the report prefacing the
estimates and the principal plan attached thereto have been countersigned by the Civil Officers or
the Head of Department concerned-(a)All Executive Engineers (including P.H.E. and Electricity
Departments)-Rs. 5,000.(b)All Superintending Engineers (including P.H.E. and Electricity
Departments)-Rs. 1,00,000.(c)All Chief Engineers (including PH.E. and Electricity
Departments)-Full powers.Note 1. - The above limit excludes departmental charges.Note 2. - These
powers apply to Deposit works also.Section VIProcedure for calling plans and estimates for
purposes of Administrative approval
9. (a) The Civil Officers may call for plans and estimates from the Executive
Engineer, Public Works Department for works, the cost of which does not
exceed his power of administrative approval. For works which exceed the
limit of powers of Civil Officer he may not call for plan and an estimate of the
cost of the proposed work unless he has first obtained the consent of the
Head of the Department concerned.The requisition should be accompanied
by specific orders of Government in the Administrative Department
concerned in cases where the cost of project exceeds the power of
administrative approval of the Heads of Departments.
(b)The Civil Officer, with the consent of the Head of the Department or Administrative Department
concerned, may also call for plans and estimates for independent electrical project from the
Executive Engineer, Electrical Works Division and for Sanitary and Water-Supply projects from the
Executive Engineer, Public Health Engineering Department.Bihar Board's Miscellaneous Rules, 1958

10. In calling plans and estimates for a project the Civil Officer shall state
clearly whether funds are likely to be available within a reasonable period.
11. The Civil Officer shall furnish the Executive Engineer of the Public Works
(B. and R.) or Electricity or Public Health Engineering Departments with
particulars of the reasons for which the works is required including the
accommodation which is to be provided in the case of residential projects,
whereas the Public Works Department Officer's concerned shall show that
his plan will generally suit the Civil Officer's requirements. He shall give
particulars as to the class of work which it is proposed to provide and show
on what information his estimate of cost is based.
12. As a rule, rough plan and estimates only will be prepared in the first
instance if the work is likely to cost more than Rs. 10,000 unless there is a
likelihood of funds being available in the course of the year and the work is
within the power of administrative approval of the Civil Officer. A requisition
estimate need only be prepared for works costing less than Rs. 1,000 while a
detailed plan and estimate will be prepared for works costing from Rs. 1,000
to Rs. 10,000 if funds are likely to be available within a reasonable period.
Otherwise rough plans and estimates only will be prepared.
13. The Executive Engineer concerned shall not prepare rough or detailed
plans and estimates for works which appear to him to be of an abnormal
nature or which are not usually allowed. When requests for such works are
received, he shall obtain the orders of Government through his departmental
superior before taking any further action.
14. (a) When the total estimate for individual building or Electrical or Sanitary
or Water-Supply project is within Rs. 5,000 the Executive Engineer concerned
will send to the plans and estimates direct to the requisitioning officer. When
the estimate exceeds Rs. 5,000 and is within Rs. 1,00,000 the plans and
estimates will be sent by the Executive Engineer to the Superintending
Engineer, who after scrutiny and revision will forward them to the
requisitioning officer. Plans and estimates involving cost beyond Rs.
1,00,000 will be submitted by the Superintending Engineer to the Chief
Engineer who will then forward them to the requisitioning officer concerned.Bihar Board's Miscellaneous Rules, 1958

(b)Ordinarily, the Public Works Department Officer shall submit the plans and estimates to the
requisitioning officer within four months from the date of requisition.(c)Whenever a new building is
to be constructed or an existing building is to be extended or improved and it is intended to provide
with Electrical or Sanitary and Water-Supply installations or both, the requisitioning officer will call
for plans and estimates from the P.W. (R. and B.) officers. In such cases, the Executive Engineer in
charge of the buildings will obtain the estimated cost of the electrical and Public Health portion of
the project from the Executive Engineer, Electric Works Division and Executive Engineer, Public
Health Engineering Department and will include the same in the total cost of the project. Thereafter,
he will send the consolidated project to the requisitioning officer concerned. In case of works costing
above Rs. 5.000 and up to Rs. 1,00,000 the consolidated project will be prepared by the
Superintending Engineer. P.W. (R. and B.) Department who will send the same to the requisitioning
officer direct. For work costing above Rs. 1,00,000 the Superintending Engineers will submit plans
and estimates for their respective portions of work to the respective Chief Engineers and the Chief
Engineer, Public Health Engineering Department and the Chief Engineer, Electricity Department
will after necessary scrutiny and check forward their portions of the plans and estimates to the Chief
Engineer, Roads and Buildings, for consolidation. The latter will then forward the same to the
requisitioning Heads of Departments.
15. On receipt of the plan and estimates for any work which exceed the limit
of his power of administrative approval the requisitioning officer will submit
the project after signature to the Administrative Department concerned for
administrative approval. The latter will deal with such proposal in the manner
indicated below:-
(i)In case of residential projects, the Administrative Department shall refer the project to the P.W.D.
for examination with reference to the admissible outlay on the basis of average pay and the
provisional rent statement (both of which should invariably accompany the reference) and
thereafter accord administrative approval to the project with the concurrence of Finance
Department.(ii)In case of non-residential project, the concurrence of Finance Department will only
be necessary prior to giving administrative approval to the project.Note. - The cases, where only
Water-Supply and Sanitary Installations are to be provided in a building, shall be referred to the
Public Health Engineering Department by the Administrative Department for examination of rent
implication, etc., but in case of Electric installation to a building, Public Works (R. and B.)
Department will be consulted as usual for rent implications, etc.
16. When according administrative approval to any project costing up to Rs.
10.000 the requisitioning officer will return the plans and estimates direct to
the Superintending Engineer. If the project is a rough one, he will state
definitely whether detailed plans and estimates are to be prepared at once.Bihar Board's Miscellaneous Rules, 1958

17. In the case of work estimated to cost more than Rs. 10,000 the
administrative approval accorded by the requisitioning officer shall also be
communicated to the Public Works Department.
18. For all works which exceed the limit of power of Civil Officer, the
administrative approval will be accorded by Government in the
Administrative Department in the manner prescribed in Rule 15 above. When
the approval has been accorded by the Administrative Department, the plans
and estimates for work including those of Sanitary, Water-Supply and
Electric installations will be forwarded to the Public Works Department for
disposal, it being intimated whether detailed plans and estimates are to be
prepared at once, if administrative approval has been accorded to the work
on a rough plan and estimate.
19. Whenever orders according administrative approval for a building project
are received by the Superintending Engineer, Public Works (B. and R.)
Department, he will forward immediately a copy of the sanction order
together with a copy of the plan, site plan and relevant extracts of the
estimates to the Superintending Engineer and Executive Engineer of the
Public Health Engineering and Electricity Departments concerned in order to
enable them to take timely steps for the execution of their portion of work.
Section VIIAllotment of funds for Minor Works
20. Civil officers who have been given grants for minor works from the Public
Works Department budget should allot funds for minor works (i.e., works
costing up to Rs. 10,000), but for minor works in connection with their own
residences the previous approval of the authority according administrative
approval should be obtained to the allotment. For all works costing above
Rs. 10,000 Civil Officers cannot allot funds from their minor works grant.
21. Civil Officers shall record the sanction to the allotment in the following
form:-
   Rs. P.
Allotment available for the year ...... 
Less sanctioned previously ...... 
Amount of this sanction ...... Bihar Board's Miscellaneous Rules, 1958

Balance of allotment still available ...... 
22. When a civil officer has no grant for minor works at his disposal he
should move the Administrative Department concerned for augmentation of
the minor works grant in consultation with the P.W.D. and Finance
Departments.
Section VIIIFunds for Major Works
23. (i) Financing of new major works is the responsibility of the
Administrative Department and not that of Public Works Department. After
according administrative approval, the Administrative Department concerned
shall take steps for the provision of funds in one of the three supplementary
statements of expenditure for a particular financial year, or in the
forthcoming budget, as the case may be in the manner prescribed in the
Bihar Budget Manual, in case no provision for the purpose exists in the
budget for the year.
(ii)(a)The schedule of demand with regard to the building portion of the project or/and Electrical
installation thereto shall be referred to the Public Works (B. and R.) Department for concurrence as
usual as the Chief Engineer (B. and R.) is the controlling officer of the budget under the head
"50-Civil Works" to which the cost of electrification of Government building is also chargeable. No
reference to Public Works (B. and R.) Department will, however, be necessary in case of an
independent project concerning Water-Supply and Sanitary installation to a building.Note. - The
Chief Engineer (B. and R.) shall be competent to obtain demand from the Electrical Executive
Engineer in respect of funding of electricity projects.(b)The Administrative Department shall make
separate reference direct to the Public Health Engineering Department for concurrence in the
schedule of demand in respect of an independent Water-Supply and Sanitary installations to a
building as well as to the Public Health portion of a building project as the cost for such portion of
work is debitable to the Head "39-Public Health" the budget of which is controlled by the Public
Health Engineering Department.Section IXRevised administrative approval
24. When a revised administrative approval to work becomes necessary, in
accordance with Rule 225 of the Bihar Financial Rules, Volume I, the
procedure for the submission of revised plans and estimates for the purpose
of revised administrative approval shall be the same as outlined in the
preceding paragraphs.
25. No work is to be taken up by the P.W.D. officers when the necessity for a
revised administrative approval becomes apparent without obtaining the
revised administrative approval of the competent authority. In cases ofBihar Board's Miscellaneous Rules, 1958

special urgency, when delay in the preparation of revised estimate is
anticipated the Administrative Department in consultation with the Finance
Department and the Public Works Department, can authorise the P.W.D.
officers to take up such work in anticipation of revised administrative
approval.
Order. - Ordered that a copy of this resolution be forwarded to the Secretary, Board of Revenue,
Registrar, High Court, Patna, Inspector-General of Police, Inspector-General of Prisons,
Inspector-General of Registration, Director of Public Instruction, Director of Health Services,
Commissioner of Commercial Taxes, Commissioner of Labour, Commissioner of Excise, Chief
Conservator of Forest, Registrar of Co-operative Societies, Director of Agriculture, Director of
Animal Husbandry, Director of Industries, Cane Commissioner, Commissioners of Divisions,
District and Sessions Judges including Judicial Commissioner, Chota Nagpur Division, Magistrates
and Collectors of Districts and Deputy Commissioners, Transport Commissioner, for information
and guidance.Ordered also that a copy of this resolution be forwarded to all Chief Engineers, all
Superintending Engineers and all Executive Engineers, (B. & R., P.H.E. Department, Electric Works
Divisions), for information and guidance.Ordered also that a copy of this resolution be forwarded to
all Departments of Government, for information and to the (Consulted unofficially) Finance
Department, for information and favour of communication to the Accountant-General,
Bihar.Ordered also that this delegation of power will take effect from the 1st April, 1955.Ordered
also that the Resolution be published in the Bihar Gazette.
275.
For purposes of the provision of funds for major works in the Provincial Public Works budget, and
grant of administrative approval to such works according to their urgency, two lists, in the forms
hereto appended, should be maintained by each Commissioner of a Division and head of a
department. In these lists the works of the several districts should not be arranged separately, but
should be taken together and, after the degree of urgency of each has been carefully considered by
the Commissioner or the Head of the Department concerned, the various works should, in each part,
be arranged in the order of urgency so determined. The arrangement may from time to time be
altered, if necessary. A complete list of new projects which it is proposed to include in the ensuing
year's budget should be submitted to Government in the administrative department concerned
punctually by the 1st October each year. This list should be arranged in order of urgency and should
furnish the information required by paragraph 22 of the Bihar and Orissa Budget Manual. It is
recommended that similar lists may be maintained by Commissioners of Divisions and Heads of
Departments with regard to the minor works. They are not required by Government, but will
facilitate the provision or allotment of funds and submission of applications to higher authority for
administrative approval to projects beyond the limit of power of sanction of the officer
concerned.Proposal for new projects requiring the sanction of Government should be submitted to
Government in the administrative department concerned during the course of the year as soon as
the necessity for them comes to notice in order to ensure that there is ample time for their proper
examination, both from the administrative and financial points of view, before they are included inBihar Board's Miscellaneous Rules, 1958

the budget.Note. - With a view to present large savings occurring in the Provincial Public Works
budgets against the sanctioned grants the Government of Bihar in the Public Works Department
have, in accordance with the recommendations of the Public Accounts Committee, directed that in
case of large building projects costing Rs. 50,000 or more the budget provision should, in the year,
be ordinarily limited to the cost of acquisition of land (where land acquisition is involved) and half
the cost of collecting materials.List IWork administratively approved
Serial No. in order of
urgencyLocalityName of
worksNumber and date of Government order
grantingadministrative approval
1 2 3 4
    
Amount of
rough
estimateAmount of
detailed
estimateIf funds partially provided,
amount andparticulars of orders
making the grantRemarks explaining fully and
clearly thenecessity and degree of
urgency of the work
5 6 7 8
    
N.B. - When funds are fully allotted for any work, it should be removed from this list. If any work
administratively approved has been provided for in the budget of the department concerned, e.g.,
Agriculture, Forest, etc., the fact should be noted in column 8.List II[Works which are considered
desirable but have been] [As the context suggests, it should be not.] received administrative
approval
Serial No. in
order of urgencyLocalityName of
workAmount of
rough estimateRemarks explaining fully and clearly
thenecessity and degree of urgency of the
work
1 2 3 4 5
     
Imperial Public Works
276. Procedure for preparation of plans and estimates for Imperial works.
- Detailed plans and estimates for any central works which are beyond the powers of Heads of
Departments to sanction or administratively approve under the Public Works Department Code,
should not be prepared by the Executive Engineer until the project have received administrative
approval in the department concerned. All rough plans and estimates for works estimated to cost
over Rs. 50,000, should be submitted for the Chief Engineer's scrutiny and approval before being
sent on to the Head of Department.[G.O. No. 188-A., dated the 12th February, 1907 and G.O. No.
2397-A., dated the 11th October, 1911. Paragraph 1058 of Public Works Department Code II (7th
edition)].Bihar Board's Miscellaneous Rules, 1958

277.
The rules regulating the transfer of State lands and buildings between the Government of India and
the Provincial Government of any Governor's province are given in Appendix I to Land Acquisition
Manual, 1928.
Chapter XV
Budget and other estimates and sanctions
278.
The budget should be carefully prepared in accordance with the instructions contained in Chapter I
of the Bihar and Orissa Budget Manual. The following supplementary rules should also be observed.
279. Printed forms only to be used.
- Printed forms only should be used in the preparation of estimates. Forms relating to the provincial
heads of revenue and expenditure are supplied by the Superintendent, Government Printing, Bihar,
and those relating to the central heads by the Accountant-General, Bihar. If any provision is
required to be made under any detailed head not included in the printed forms, it should be entered
in manuscript.
280. Instructions for the preparation of estimate under "VII-Land Revenue."
- In order to secure uniformity in framing the budget estimate under "VII-Land Revenue", the
District Officers are requested to observe the following instructions:-(1)Fixed collections. - The
estimate under this head should be based on the current demands shown against cross-heads I
(estates permanently settled) and II(a) (estates settled for periods with proprietors) of the annual
return XLI for the financial year preceding that in which the estimate is prepared. To this
add-(i)Probable additions to the current demands up to the close of the year under
budget.(ii)Balance likely to remain unrealised out of the demand of the year in which estimate is
prepared, i.e., the anticipated arrear demand of the year under budget.(iii)Amounts expected to be
collected in advance during the year under budget on account of the demands of the following
year.(iv)Total balance likely to remain unrealised at the close of the year under
budget.(v)Anticipated deductions from the demands up to the close of the year under
budget.(vi)Portions of the demands of the year under budget to be adjusted from the advance
collections made in preceding years.(vii)Probable remissions to be made during the year under
budget.For all practical purposes the items (ii) and (iii) above will counter-balance items (iv) and
(vi) respectively, and the current demands of estates under classes I and II(a) plus and minus the
expected additions, deductions and remissions will form the basis of the estimate. When, however,
the District Officer has any reason to anticipate any abnormal variations in the arrear and advance
collections of the year under budget as compared with those of the preceding years, or when, fromBihar Board's Miscellaneous Rules, 1958

his knowledge of any circumstances, he considers that the estimates arrived at in the manner
indicated above will not represent sufficiently accurately the amounts expected to be actually
realized during the year, necessary changes should be made and details showing how the estimates
have been arrived at should be shown in the explanation sheets together with the reasons for
making the changes.(2)Collections from Government estates. - The estimate under this head should
be based on the current demands shown against cross-heads II(b) (Private estates leased to the
farmers for periods), II(c) (Government estates leased to the farmers for periods) and III(a) and (b)
(Estates held direct by Government) of Return No. XLI.The other considerations mentioned in the
case of "Fixed Collections" should be taken into account.(3)Collections of payments for services
rendered. - The estimate under this head should show (i) general rate for management of private
estates, (ii) other items (leave contribution, etc.) and (iii) recoveries on account of tauzi certificate,
partition, etc., establishments.(4)Refunds. - The practice of classifying refunds as "voted" and
"non-voted" and of including the former in the demands for grants under the respective expenditure
heads has been discontinued since the 1st April, 1937. All classes of refunds are therefore, treated as
not subject to the vote of the Legislature. The existing method of classification of refunds in the
accounts as deductions from revenue, however, remains unchanged.(5)As regards the other heads in
the budget form, the estimate against each should be ordinarily based on the average of the actuals
of the last three years provided there is no reason to anticipate any abnormal variation under any
head.
281. Estimates of disbursement.
- The estimates of disbursement in like manner show the amounts expected to be paid within the
year.These estimates are classified by units of appropriation comprising several detailed heads. The
expenditure, which is charged on the revenues of this province but is not submitted to the vote of the
Legislative Assembly is indicated in the budget by the word "charged". Expenditure which is
submitted to the vote of the Legislative Assembly is indicated by the word "voted". The following
indicates the mode to be ordinarily followed in arriving at the estimate under each unit:-(1)Pay of
officers (charged). - The estimate under this unit should show the pay and special pay (if any) of
officers whose pay is not subject to the vote of the Legislature. Overseas pay of such officers, if
drawn in India, should also be provided for under this unit.Note. - The pay and travelling allowance
of officers of the Bihar Civil Service holding listed posts, permanently, is debited to the head "Pay of
officers (charged)" and "allowances (charged)" respectively.(2)Allowances (charged). - This unit
comprises two distinct heads, viz., (i) travelling allowance and (ii) other allowances. The latter
includes "Compensatory allowances", "Cost of passages granted under the Superior Civil Service
Rules, 1924", "Rewards to I.C.S. Officers for passing the examination in tribal and oriental
languages" and "Payment on account of medical treatment of British Officers in superior service".
Provision should be made accordingly.(3)Pay of officers (voted). - Provision should be made under
this unit for the pay and special pay, if any, of the members of the Provincial and Junior Civil
Services (including officers holding listed post temporarily).(4)Pay of establishment. - The estimate
of establishments should provide for the gross sanctioned pay of each incumbent to be drawn on 1st
April of the year for which the estimate is framed as well as the amount of increment, if any, which
will fall due to him in course of the year. Provision on account of pay of new entrants should be
made at the revised rates of pay fixed by Government. A detailed list showing the rate of pay to beBihar Board's Miscellaneous Rules, 1958

drawn by each incumbent from time to time working up to the amounts provided for in the
estimates and the date on which the increment, if any, will fall due should be furnished with the
estimates. If any additional staff has been applied for, no provision for it should be made pending
sanction of competent authority but the number and date of the letter in which sanction has been
applied for and the amount that may be required may be entered separately in red ink in the list for
the information of the Board. In column "Numbers-current year" should be repeated the entry made
in the estimate submitted for that year without reckoning any increase in establishments sanctioned
after the submission of the estimate. The difference, if any, between the number shown in this
column and that proposed for the year under budget should be explained giving a copy of the order
of competent authority sanctioning the increase, if any, for reference.(5)Allowances (voted). - The
estimate under Travelling allowance" as well as other detailed heads within the unit should be based
generally on the average of the actual of the three preceding years. If unusually large expenditure on
this account is anticipated, the necessary provision for the same should be made in the estimate and
a note inserted in the column of remarks giving reasons.(6)Contingencies (contract). - The contract
grant for District Officers is confined only to the following sub-heads subordinate to the head
"25-General Administration":-(i)General Establishment;(ii)Treasury Establishment;(iii)Other
Establishment-(a)Process-Serving Establishment;(b)Staging Bunglows.A statement showing the
provision made under each of these sub-heads working up to the total grant fixed for a district under
the contract should be furnished with the estimates under each of these sub-heads.(7)Contingencies
(non-contract). - The instructions given in Rule 5(3) of the Budget Manual should be carefully
observed in framing estimates under the detailed heads comprising this unit.
282. Contract grant for purchase of tents.
- There is a separate contract grant for the purchase of tents, ordinarily to last for eight years, at the
disposal of each Commissioner. An estimate of probable requirements for each division will be
annually furnished by each Commissioner to the Accountant-General and to the Board not later
than the 15th November to be included in the ensuing year's budget. The Board should
communicate the final estimate to Government by the 1st December. These estimates should be
made with due regard to the allotment for the whole period of eight years.
283. Savings of one year cannot be utilised in the succeeding year.
- Savings in grants allotted for expenditure in a financial year cannot be utilized for expenditure in
the succeeding year. If however, it is desired to include in the estimates the demands sanctioned in
the preceding year's budget but not utilized, an explanation should be furnished of the necessity for
a regrant without which the demand will not be included.
284. Lump sum entries not allowed.
- The practice of making lump sum entries in the budget in view of anticipated expenditure the
details of which the officer preparing the budget is not immediately in a position to estimate, is open
to objection and should not be reported to.Bihar Board's Miscellaneous Rules, 1958

285. Budget estimate to be submitted punctually.
- District and Divisional Officers should personally see to the punctual submission of their budget
estimates to controlling officers on the prescribed dates.They are reminded that any delay in the
submission of the estimates prevents the completion of the consolidated budget estimate of the
province and necessarily leads to much inconvenience.
286. Corrections to estimates allowed till 15th November.
- The budget estimates of local offices for any particular year being prepared and submitted in the
middle of the previous year, emergencies not infrequently arise which were not foreseen and
therefore not provided for. It may also happen that, through inadvertence, or the non-receipt of the
necessary information duly sanctioned charges are omitted. In such cases corrections to estimates
become necessary which should be sent to the Board not later than the 15th November to enable it
to report such corrections to Government and the Accountant-General by the 10th December at the
latest, [cf. Rule 24 (b) of the Bihar and Orissa Budget Manual].
287. Proposal for expenditure without budget provision.
- Save for exceptional reasons, expenditure for which no provision has been made in the estimates of
the current year, should not be proposed. When it is proposed, the onus of making a definite
suggestion as to how the necessary funds may be provided ordinarily rests with the proposer. In all
applications for sanction to expenditure, it should therefore be distinctly stated whether provision
for the proposed charge has, or has not, been made in the budget estimate of the year, and if not,
whether it can be met from savings in existing grants; the fact that provision has not been made in
the estimate for the desired expenditure should be prominently set forth, as well as the particular
reasons why it is, nevertheless, considered necessary that the outlay should be incurred
immediately, and not postponed to the next financial year. Explanations should also be invariably
given as to why the need for the expenditure was not foreseen in time to obtain sanction for its
inclusion in the estimates. In the absence of any such explanation it will be assumed that the
proposed expenditure is intended to have effect from the beginning of the next financial year and
not earlier.
288. Transfer of savings from one detailed head to another.
- Disbursing officers are competent to transfer savings from one detailed head of expenditure to
meet the excess in another within the same unit of appropriation provided neither of the detailed
heads concerned has been declared to be a secondary unit; and so long as such a transfer is possible,
no application for additional grant under that unit should be made. It is only when an excess is
anticipated in the total grant under a unit that such an application or an application for a
reappropriation becomes necessary which should be submitted to Form No. 212 of Schedule
LIII-Common office forms.Exception. - Savings in the allotment for travelling allowance should not
be transferred to meet the excess in the other detailed heads within the unit"Allowances (voted)" orBihar Board's Miscellaneous Rules, 1958

"Allowances (charged)" except with the approval of the Board. Proposal for augmentation of the
provision for travelling allowance requires the sanction of Government.
289. Power of reappropriation delegated to the Board and the Director of
Land Records.
- The Board and the Director of Land Records have been empowered to make reappropriations
subject to certain restriction and general principles laid down by Government from one voted unit to
another voted unit within the same minor head, the latter in respect of "7-Land Revenue-Survey and
Settlement" and "Land Records" in respect of the sub-head "Charges on account of maintenance of
land records" only, and the former in respect of the rest of the budget heads "7-Land Revenue" and
"25-General Administration" controlled by it.
290. Verification of accounts and control of expenditure.
- The District Officers and the Commissioners of Divisions are to render to the Board the accounts of
expenditure under the major heads "1-Customs", "7-Land Revenue", "9-Stamps", "25-General
Administration" and "35-External Affairs".Instructions for verification of accounts and control of
expenditure are embodied in Appendix III to the Bihar and Orissa Budget Manual (2nd Edition).The
following supplementary instructions regarding control of expenditure, submission of revised
estimates and annual statements of expenditure should be carefully followed:-
1. The disbursing officers should make every possible endeavour to keep
within the Budget allotments. For this purpose they should make a rough
distribution of their allotments, which are intended for the whole year, into
twelve monthly allotments. The monthly allotments need not necessarily be
equal but should be fixed with reference to the requirements of each month.
Any excess in expenditure over such monthly allotment should be
scrutinized by a gazetted officer and steps taken to reduce the expenditure
during the succeeding month. This scrutiny is essential to a systematic
control and its omission generally leads to overspending.
2. To enable the Board to exercise an effective control over expenditure, the
disbursing officers should not only report their monthly expenditure in the
statement in Form II (Vide pages 67-69 of the Bihar and Orissa Budget
Manual, 1931) accurately and promptly on the date fixed but also forward two
revised estimates in the form appended to these instructions, the first on or
before the 15th September and the second on or before the 20th January.Bihar Board's Miscellaneous Rules, 1958

3. In order that the statements in Form II might also be a check on the revised
estimates, the disbursing officers should fill up in September, January and
February columns 3, 4 and 5 of these statements to the end of August,
December and January respectively. The last two statements will enable the
Board to watch possible overspending by the disbursing officers which will
be pointed out to them to see from whose budget allotments
re-appropriations might be possible and to send proposals to Government
for supplementary grants, if necessary. If after submission of the statements
to the end of December and the revised estimates due to the Board in
January, any disbursing officer finds that his budget allotments are likely to
be exceeded he should intimate the fact to the Board at once by a special
report.
4. Revised estimates should not be regarded as applications for additional
allotments which should be sent separately in the prescribed form.
5. After a year's account is closed, the disbursing officers should furnish the
Board by the 10th of June with a statement in Form II showing expenditure
incurred during the year under each detailed head comprising an unit of
appropriation and the sanctioned allotment to the end of the year for that unit
explaining clearly the cause of the difference, if any. If the original allotment
has been exceeded it should also be noted what steps were taken to prevent
the excess. This statement will be useful to the Board in furnishing
explanation of the savings or excesses in the sanctioned grant of the year to
the Accountant-General for inclusion in his appropriation report.
Revised estimate for the year 20....
DistrictDivision
Major head Minor head Sub-head
Primary units of
appropriation with
secondaryunitsAllotments for the
current yearActual for
first- months
of current
yearsRevised
estimate for
current yearRemarks (Here explain
fully the reasons for
thedifference between
the figures in columns 4
and 6)
OriginalAmount
subsequently
added or reduced
(+) (-)NetBihar Board's Miscellaneous Rules, 1958

1 2 3 4 5 67
       
Memo No.Forwarded to the Secretary to the Board of Revenue,
Bihar.Commissioner......................Collector......................Deputy Commissioner.Dated the 20........
291. Transfer in account.
- Collectors are authorized to sanction the transfer of items from one head of revenue to another
when such items have been wrongly adjusted in the first instance. No special report of these
transfers need be submitted by Collectors to the Accountant-General.
292. Reduction of establishment.
- Commissioners are authorized to carry out at once any reduction of establishment which they may
consider practicable, reporting the same for the formal sanction of Government through the Board.
293. Preparation of statement prior to deciding the necessity for extra
establishment.
- In order that the Commissioner may be in a position to decide whether any increase in an
establishment is needed or a reduction can be rightly enforced, it is necessary to compare the
various establishments and the volume of work with which they have to deal in the several districts
of his division. He should, therefore, cause to be prepared for each separate department of the
officers who are subordinate to him a statement showing (a) the value of work of the
department,(b)the number of officers employed to do the work. In the preparation of this statement
it is essential to make certain that the volume of work is computed on a uniform basis in every
district. Owing to the devices which are commonly adopted when a question arises about the
adequacy of an establishment, a most careful scrutiny by Collectors and Commissioners of the data
supplied and the methods adopted will be very necessary. From a comparison of the lists prepared
under such safeguards it will be possible to arrive at a standard of outturn which may be applied
with safety to demands for additional staff and may even justify a reduction in the existing staff in
some districts. Proposals are rarely initiated by local officers for the reduction of establishment, and
this is probably due to some extent to the absence of standards, or the culpable neglect of standards
already prescribed.
294. Form of application for increased establishment.
- All applications for any increase of establishment or for any additional allowances are to be
submitted in the manner and in the forms prescribed by Rule 69, page 23, of the Bihar and Orissa
Account Code. The necessity for the proposed increase should be fully explained in each case. As a
general rule, a statement of the present work, on an average of three years, as compared with the
proposition is for a permanent increase to an established office. Commissioner should have the
column "Present scale" verified by the Accounts Department before submission to the Board in casesBihar Board's Miscellaneous Rules, 1958

in which there is any doubt as to the correctness of that scale, and in all cases the number and date
of the order sanctioning the present scale must be cited.
295. Applications for renewal of sanction to be in time.
- Applications for sanction to the retention of temporary establishments beyond the period covered
by the original sanction should invariably be submitted in time to allow of due consideration and
issue of orders before the expiration of the term of sanction.A list of such temporary establishments
should be kept in each office and should be regularly scrutinized.
296. Condition of temporary appointment.
- In case of appointment of any person other than a menial on any temporary establishment by the
Board or Government, it is open to the Collector to make a condition that three-fourth pay only shall
be drawn during the period for which the establishment is entertained, and that the remainder can
be claimed at the expiry of the sanctioned period, provided the work be then completed or sufficient
cause shown for failure; otherwise the quarter pay will be forfeited to provide for the completion of
the work by the other persons.
297. Progress reports for special works.
- When any temporary establishment is employed on any special work or when any permanent
establishment is deputed to a special work to be completed within a fixed period, the progress of
work of clerks should be carefully watched by the District Officer. To enable him to do this, each
clerk should submit fortnightly to the Collector, through the Deputy Collector in-charge of the
Department, a progress report in simple form showing the total amount of work done up to date, the
amount done during the fortnight and the amount remaining to be done with explanations of any
failure to attain the standard expected. The Board does not consider it necessary to prescribe a
particular form of report or a standard, but leaves it to District Officers to adopt the form and the
standard, most suitable for the work in hand. These orders apply more especially to the work of
temporary establishments employed in copying registers, overhauling records and other work of a
similar nature; they do not apply to the major work like Cess Revaluation, Survey and Settlement or
Land Acquisition, for which progress reports are already prescribed.
298. Temporary menial establishment for joint and Assistant Magistrates and
Additional Deputy and Sub-Deputy Collectors.
- The number of orderly peons allowed to Joint Magistrates and Assistant Magistrates at
headquarters of a District and to Additional Deputy and Sub-Deputy Collectors at District and
sub-divisional headquarters is regulated by the following rules. The pay of a peon so employed shall
be the lowest pay given in the office concerned to holders of temporary posts of a similar
class:-(a)Two orderly peons are allowed to the Joint Magistrate, or the Senior Joint Magistrate,
where there are two Joint Magistrates, or the senior or only Assistant Magistrates where there is noBihar Board's Miscellaneous Rules, 1958

Joint Magistrate.(b)One orderly peon is allowed to any Joint Magistrate, not being the senior or only
Joint Magistrate, or where there is no Joint Magistrate, the Assistant Magistrate not being the
senior or only Assistant Magistrate.If one of the officers named at (a) or (b) above leaves the station,
his orderly peon or peons, as the case may be, should not be retained for more than two months in
expectation of another similar officer being sent to the station.(c)One orderly peon is allowed to an
Additional Deputy Collector or Sub-Deputy Collector on general duty provided that no peon is
allowed to any such additional officer while on probation except for the period he is employed on
case work or is absent from headquarters on tour to make local enquiries. When two or more
probationary officers at a station are employed on case work arrangements shall normally be made
for them to share one orderly peon for court work.District officers are empowered to sanction the
appointment of temporary peons to work under the officers mentioned at (a), (b) and (c) above. The
sanction should be communicated direct to the Accountant-General, Bihar.
299. Menial establishment for permanent staff of uncovenanted officers.
- Deputy Collectors on the sanctioned permanent staff of a district and Sub-Deputy Collectors on
that of a division are allowed one orderly peon each except that a Deputy Collector in-charge of a
sub-division is allowed two orderly peons.
300. Connection and disconnection of electric fans and duration of
employment of punkha-pullers.
- As a general rule electric fans in all Government non-residential buildings should be
connected:-(a)in the plains on the 15th March, and(b)in the hills (above 1,000) on the 31st
March,and disconnected-(a)in the plains on the 31st October, and(b)in the hills (above 1,000) on
the 16th October.Similarly punkha-pullers may be employed every year in Government offices in the
plains where electric fans are not in use during the period, the 15th March to the 31st October, and
in those in the hills (above 1,000) where there are no electric fans during the period, the 31st March
to the 16th October.
301. Supply of Maps.
- The Map Record and Issue Office, Calcutta printed maps published by the Survey of India on the
public service on book debit. That office also arranges for the mounting and colouring of maps when
required. All charges for freight and postage of parcels must be borne by applicants themselves.
Incidental charges for colouring, mounting and binding and maps and for packing are included in
the bills submitted. The rules as to the disposal of duplicate and triplicate copies of the invoice,
printed thereon, must be strictly adhered to.All applications for printed maps on the public service
should be made to the Officer-in-charge, Map Record and Issue Office, 13, Wood Street, Calcutta in
the form of the indent prescribed for the purpose and should give full and clear particulars as to the
kind of map required and its scale, and any other information that will guide that office in knowing
exactly what is required. The mode of transit and the address to which the maps are to be sent
should invariably be specified. All addresses should be clearly written.Indent forms for maps on theBihar Board's Miscellaneous Rules, 1958

public service can be obtained from the Officer-in-charge, Map Record and Issue Office, and also
from the Deputy Superintendent-in-charge of Press and Forms, Gaya.A catalogue of maps published
by the Survey of India is obtainable from the Map Record and Issue Office.
302. Indents for Maps.
- Indents for maps required from the Map Record and Issue Office must be duly approved and
countersigned by the authorised officers. The following officers under the Board are authorised to
countersign the indents:-Commissioner of Divisions.Collectors of Districts.Commissioner of
Excise.Director of Land Records and Surveys.Where the contract system in not in force, the charge
on account of maps is met from the ordinary contingent grant of the officer and adjusted accordingly
in the accounts.
Chapter XVI
Rules relating to the receipts and payments of money and to
refunds and the Nazir's Accounts
[The rules contained in this chapter do not apply to payments made into the Treasury under the
Bihar Treasury Code Rules.]
303. Form of receipt books.
- Receipt books in the form given below shall be kept in all departments of revenue offices requiring
them from which a receipt duly filled in and signed shall be given to every person making any
payment whether in court-fee stamps or in cash.Book No. .............of.................. No. .................From
whom received......................... 20.......On what account............................
 AmountRs. P.
In cash .......  
In stamps ....... __________
Total .......  
(Rupees.......................and Paise......................only)DateReceiving Officer
304. Receipt books to contain uniform number of pages and to be written in
pencil.
- Receipt books shall contain 100 forms each, every two of which will contain the same serial
number printed on them. Each book will, therefore, have 50 such consecutive serials. Receipts shall
be written in pencil using carbon paper so that a duplicate may be prepared automatically to be kept
in the book. The original or the upper receipt shall be made over to the payer as his receipt and the
lower one kept in the book.Bihar Board's Miscellaneous Rules, 1958

305. Receipt books to be kept in treasury.
- Receipt books shall not be kept with other forms in the forms department of a Collectorate. They
should be indented for separately and kept in the treasury alongwith the local fund cheque books.
On receipt of a stock of these books, the Treasury Officer shall number each book by hand according
to a district annual consecutive series entering such number on the outside of the cover of the book,
thus-No. 17 of 1926-27.and sign each such entry. He shall also sign a certificate on the cover stating
the number of forms in the book. Before issue to a department each receipt form shall also be
stamped with the Collector's seal.
306. Account to be kept in Register 71.
- The receipt in and issue from the treasury of these books shall be properly accounted for in
Register 71 (vide Register and Return Manual) the numbers issued being specified in column 3 of
the Register, thus-Nos. 50, 51 and 52 of 1925-26.Nos. 1, 2 and 3 of 1926-27.
307. Custody of receipt books in a department.
- The store of receipt books in the custody of the Deputy Collector in charge of each department
should be kept under lock and key. He is responsible for deciding what number of receipt books
each officer requires to carry on his work; and after the number has been issued no further issues
are to be made except in exchange for a corresponding number of returned books.
308. A clerk to be appointed to keep accounts of receipt books.
- In the departmental order book, the Deputy Collector in charge of the department should record
the name of the clerk in whose custody the receipt books are placed. Their receipt and issue are to be
property accounted for in Register 71 as in the treasury.
309. Examination of books used up.
- Whenever a receipt book is returned to the department which issues it, a careful examination
should be made by the clerk (appointed for that purpose by the Deputy Collector in charge) to see
that in the case of each cancelled form its duplicate has been retained and cancelled. The clerk
should also count the number of forms to see that no duplicates have been removed and record a
certificate on the cover to that effect.
310.
The procedure to be followed by the officer who issues receipt books to collecting agents, as a nazir
to his peons, is prescribed in the Practice and Procedure Manual.Bihar Board's Miscellaneous Rules, 1958

311. Authorisation of agent.
- No payment of money is on any account to be made to an agent for another party until the
disbursing officer, or his assistant or deputy, has thoroughly satisfied himself that the agent is
authorised to receive it. Particular attention should be directed to the signature and attestation and
the disbursing officer should take the greatest care to assure himself of their genuineness.
312. Refunds of current deposits.
- Refunds of current deposits be made upon the authority of the officer who ordered the acceptance
of the deposits. The Collector or Deputy Commissioner may sanction refunds rendered necessary by
any order that he or the Commissioner of a Division has passed including refunds in cases of
erroneous payments, and of payments on account of lands released by competent authority.The
Commissioner of Excise has been authorised to sanction refunds in excise cases. The Commissioners
of Divisions and the Director of Land Records and Surveys are competent to sanction refunds from
deposits made in respect of survey and settlement proceedings carried out under their respective
supervision. All other refunds require the authority of the Commissioners of Divisions, who will
inform the Accountant-General of any refunds that they may authorise. They may also sanction
interest upon sums refunded.
313. Refunds by postal money-orders.
- Refunds of revenue credits or deposited in excess, where the amount involved does not exceed Rs.
100, may be paid by postal money-order subject to the following rules:-(1)On receipt of a refund
order passed by the Collector or other officer concerned, the Treasury Officer may, at his discretion,
issue a notice (a) inviting the person to whom the refunds is to be made, to receive payment at the
treasury, and (b) intimating that on failure to comply with the invitation within one month (or such
longer period as may appear necessary) the amount of the refund will be remitted to the payee by
postal money-order at his expense.(2)When the payee appears in person at the treasury, the
Treasury Officer should see that no avoidable delay occurs in getting the voucher for the refund
signed by the payee, who may then receive the payment personally, or by a duly authorised agent, or
by money-order at his own expense.(3)When a money-order is issued under clause (b) of the notice
referred to in Rule (1), the purpose of the remittance should be stated briefly by the Treasury Officer
on the acknowledgement portion of the money-order form in continuation of the printed entry
there. "Received the sum specified above on" sufficient space being left below the manuscript entry
thus made for the signature or thumb impression of the payee. The amount of the money-order
should not be remitted in cash to the post office, but the Treasury Officer should send a
money-order form duly filled in together with a certificate that the amount of the order and the
money-order fee thereon have been credited to the Post Office in the treasury accounts by per contra
transfer. The Post Office will accept the money-order on the authority of the Treasury Officer's
certificate.(4)On receipt of the money-order acknowledgement duly signed by the payee, it should be
attached to the usual receipt in T.C. Form No. 59 or 74 of the Bihar Treasury Code, as the case may
be, in which the full amount of the refund and the deduction made therefrom on account of the
money-order fee should be clearly shown; the receipt will then be disposed of in the usual way. TheBihar Board's Miscellaneous Rules, 1958

Accounts Department will accept such voucher with the money-order acknowledgement as a valid
receipt for the full amount of the refund entered therein.
314. Refunds of lapsed deposits.
- If an application for the refund of a deposit that has been credited to Government appears to
require special orders, it should be submitted to the Commissioner, who has the power to pass final
orders on it. If he sanctions it he will forward it, after sanction, to the Accountant-General;
otherwise and ordinarily, it should be addressed direct to the Accountant-General. The following
particulars must be given in all such applications;-(a)Reference to the registers showing the number
of original deposit and of any subsequent entry in which it has been included.(b)Nature of
deposit.(c)Date of deposit.(d)Reasons why it has not hitherto been applied for.(e)Name of present
applicant, and, if he be not the original depositor, the ground upon which it is proposed to pay the
money to him.(f)Certificate of Collector that after due enquiry he finds the refund applied for to be
just and proper.
315. Collector's signature to certificate.
- The Collector may delegate the duty of passing the repayment orders and of signing of repayment
cheques to a covenanted or the Senior Deputy Collector. The certificate required by heading (f)
mentioned in the preceding rule must be invariably signed by the Collector himself. Should an
application be preferred during the Collector's absence from his headquarters and should he be
unable in consequence to make the necessary inquiries into the propriety of the refund applied for,
its disposal must await his return.
316. Delay to be reported.
- In recommending refunds the Collector must ascertain the cause of any delay which has occurred,
and report the name of the officer responsible.
317. Collectorate procedure in dealing with application for refund of current
or lapsed revenue deposits.
- The following procedure is prescribed in the Collectorate for dealing with applications for current
and lapsed revenue deposits:-(1)Applications. - All applications for refund of revenue deposits,
whether current or lapsed, filed by claimants, or by their authorised agents (vide Rule 311 above)
will, on receipt, be dealt with in the Collectorate Munshikhana or the Certificate Department and
entered in Register 25 (separate volumes of which are maintained in the Certificate Department and
in the Rent Suit Department where rent suits are tried by Revenue officers). The clerk in charge of
the Register shall then obtain in form no. 928 of Scheduled XIV reports (a) from the department in
which the deposit was received, or from the Record Keeper, if the record has been consigned to the
Record Room, as to whether the claim is correct, (b) from the clerk-in-charge of "attached" cases as
to whether the deposit is under attachment, and (c) from the Accountant to the effect that theBihar Board's Miscellaneous Rules, 1958

deposit is actually in existence.(2)Current deposits. - In case of applications for refund of current
deposits the application, with Register 25 and the reports referred to above, will be laid before the
Deputy Collector in charge, who after satisfying himself that all the necessary reports are in order,
shall, if there is no objection to the payment, pass the order of refund in his own handwriting.The
clerk in charge of Register 25 shall then prepare the necessary voucher in T.C. Form No. 74 of the
Bihar Treasury Code, and submit it to the Deputy Collector incharge who shall sign the voucher, on
the claimant being duly identified before him and hand over or have the signed voucher handed over
in his presence to the claimant for presentation to the Treasury. The order for refund shall be noted
by the clerk both on the record and in column 7 of the Register 25 stating the amount in words as
well as in figures and shall be signed or initialled by the Deputy Collector in charge and also by the
Accountant.(3)Lapsed deposits. - In the case of applications for refunds of lapsed deposits, the
application with Register 25 and the reports referred to in Clause (1) above, shall similarly be placed,
in the first instance, before the Deputy Collector in charge who after satisfying himself that every
thing is in order and that there is no objection to the payment shall have a voucher in T.C. Form No.
74 of the Bihar Treasury Code prepared. He shall then sign the application and initial the voucher in
token of his having made the necessary check. The application together with the voucher, the record
of the case and Register 25 will then be laid before the Collector who after seeing that the necessary
scrutiny has been made by the Deputy Collector in charge, and satisfying himself as to the identity of
the applicant and after making any other enquiry necessary, will sign the voucher, which shall then
be sent to the Accountant-General for his sanction. On being received back from the
Accountant-General it will be made over to the claimant by the Deputy Collector in charge after
satisfying himself as to the identity of the former and the order for refund noted on the record and in
column 7 of Register 25 as in the case of current deposits [Vide clause (2) above],(4)Treatment in
Treasury. - In either case (i.e. refunds of current or lapsed deposits) the Treasury Officer shall follow
the procedure contained in Chapter IX of the Bihar Treasury Code (Vide also Rule 189, Chapter V.,
Section 1, sub-section II, of Bihar Treasury Code Volume I). He has to satisfy himself that the
voucher is in order, and he must also be in a position to prove that the payee has actually received
the sum noted in the voucher. Particular attention should be paid to Rule 311 above in cases of
payments to agents. On no account should the Accountant or any of his subordinates be allowed to
take payment of the money on behalf of the applicant.(5)Procedure subsequent to payment. - After
the date of refund has been noted in column 8 of Register 25 and in the record of the refund case, a
note of payment shall be made in the original record by the clerk in charge of that record, and a note
to the effect that this has been done shall be made in column 9 of Register 25 by the clerk in charge
of the register after proper verification. This entry shall be initialled and dated by the Deputy
Collector in charge.(6)Procedure in sub-divisions. - In sub-divisions the Revenue Peshkar shall keep
Register 25 in his custody and the necessary voucher prepared by a clerk who is not attached to the
Accounts Department of sub-treasury. The Sub-divisional Officer will discharge the functions of the
Collector in respect of refund applications.(7)Refunds of other than Revenue deposits. - In dealing
with applications for refunds of other than revenue deposits, e.g., custody fees, criminal deposits,
fines, forfeitures, sale proceeds of unclaimed intestate properties, etc., the procedure laid down at
pages 118-125 of the Patna High Court Rules and Orders, Volume I (Criminal) and pages 204-211,
Volume I (Civil), should be followed.Bihar Board's Miscellaneous Rules, 1958

318. Excess payments of revenue not to be refunded.
- A proprietor or co-proprietor of an estate paying revenue to Government is not entitled to a refund
of any such which may have been paid by him on account of the estate of which he is proprietor or
co-proprietor, in excess of the amount due from the estate up to the date of such payment, unless
such payment shall have been specially made as a deposit under Section 15, Act XI of 1859.
319. Claims to surplus sale-proceeds.
- Deposits on account of surplus sale-proceeds of estates sold under Act XI of 1859 should be treated
in the manner laid down in Rules 554 and 557, Chapter IX, Section III, of the Bihar Treasury Code,
Volume I. The claims of ex-proprietors to sale-proceeds of their estates should never be rejected on
the ground of limitation. When, however, they are submitted after a long interval, the enquiry for
the purpose of ascertaining whether the amount claimed has never been paid, and whether the
claimants are the persons legally entitled to the refund should be made with special care.
Explanations of the delay in applying should be taken from the claimants in such cases, and where
the evidence of the amount being still unpaid or of the right of the claimants to receive payment is
unsatisfactory, the applications should be rejected.Note. - The procedure laid down in the above rule
applies to sale-proceeds of estates sold under the Certificate Act, compensation for lands acquired
by Government, security for estates farmed, remuneration of Batwara Amins and deposits of rents.
320. Refunds to be noted in the register of receipts.
- In the case of land revenue receipts, a note attested by the initial of the officer making the refund,
should be made in the column of remarks against the original entry in the treasury registers in
which the receipt is shown.
321. Notice of refund and payment in certain cases.
- Whenever a refund or disbursement of money has been sanctioned on account of law charges or
other account, a notice should be served, free of charge, on the party entitled to receive it, requiring
him to make immediate application for payment, on pain of forfeiture of interest from a given date,
which should be fixed with reference to the distance of the party's residence from the Collector's
treasury.
322. Direct payments to treasury.
- No money should be un-necessarily allowed to pass through the Nazir's hand. Direct payment into
the treasury should be insisted on, and direct payment made whenever this is possible.Bihar Board's Miscellaneous Rules, 1958

323. Books to be kept.
- The Nazir shall keep the following books:-A. - A cash book (Register 94) with subsidiary registers
as described in rule 324.B. - A treasury remittance book (Register 95).C. - A stock and store register
(Register 96).D. - A receipt book.E. - Daily account of saleable forms sold.
324. [ Entry in Cash book. [Substituted by C.S. No. 9 dated 3.8.1965.]
- Every item received must be entered in the Cash Book (Register 94 of the Register and Return
Manual Schedule XIV, Form 528) or in some register subsidiary thereto (kept in T.C. Form No. 6 of
the Bihar Treasury Code Volume II) and numbered in a consecutive monthly series for each register.
Instructions in Rule 86 of the Bihar Treasury Code, Volume I shall be observed in the maintenance
of Nazarat accounts.]
325. How to be kept.
- In the general cash-book should be shown the details of all receipts and payments not included in
any subsidiary register, and the daily totals of receipts and payments included in such a register. The
number of subsidiary registers to be kept must vary in different districts. One subsidiary register
should show realisations under process. When realisations under process of any particular kind are
numerous, there may be more than one such register. In it should appear disbursements on account
of stamps representing process fees not paid before the issue of process. On no account any sums,
which has not passed through the Nazir's hand (such as sums realised by peons on process and paid
direct into the treasury) be entered in this cash-book or its subsidiary registers.
326. Stamps for process fees.
- It should be noted, with reference to the rule, that whenever a process has issued without previous
payments of fee for the realization of any sum, the Nazir, out of the first amount which he recovers
should purchase stamps to the amount of the process fees due, and affix them to his report of
recovery. If payment is offered to the officer by whom a process was issued, he should require a
report from the Nazir that the process fees have been paid before accepting payment. To such report
stamps to the amount of the fee should be affixed. It is the record-keeper's duty to report the fact if
the record of any case in which process fees were recoverable should be sent to him without stamps
denoting the proper fee.
327. Initialling of treasury remittance book.
- Each entry in the treasury remittance-book is to be initialled by the Accountant. Each entry of Rs.
500 or over it to be also initialled by the Treasury Officer, and each entry below Rs. 500 is to be also
initialled by the Treasurer as an acquittance to Nazir.Bihar Board's Miscellaneous Rules, 1958

328. Stock and store register.
- The stock and store register is to be kept by every civil officer, showing the live-stock, European
and other stores, and movable property in his custody, including iron safes, European locks,
European scales and weights, tents, ordinance stores machines of European manufacture, scientific
and mathematical instruments boats, vehicles, horses and elephants*; but books and articles of
petty value stores (such as stationery) supplied for consumption, and stamps, opium and other
stores supplied for sale, for the audit of which there are independent arrangements, should not be
shown in stock and store register. A separate volume of the stock and store register is to be kept for
articles of ordinary office furniture (such as benches, tables, racks, wooden and tin boxes, etc.). All
new purchases and sales, etc., of old stock should be entered at the time with the initials of the civil
officer who should check the balance as shown in the book at least once a year.* Note. - The
information required for elephants is to be given under three heads showing for each elephant (1)
name, (2) when purchased or otherwise obtained by Government and (3) cost of monthly keep,
including servant's and food-Head 1. - Elephant in the possession of the reporting officer throughout
the years.Head 2. - Elephants received during the year.Head 3. - Elephants removed from the list
during the year (showing what has become of them).
329. Stock and sale of saleable forms.
- The duty of keeping the stocks of all saleable forms excepting the cheque-book forms and carrying
on the sale of such forms should be entrusted to the Nazir who should keep his daily account of the
sales in Register 99 (vide Register and Return Manual) of which sufficient number of pages should
be allotted to each kind of saleable form, the name of particular form being entered by hand.The
stock and account of cheque books will be kept by the officer in charge of stamps in Register 90 on
page 60 of the Register and Return Manual.
330. Procedure for Sale.
- Applicants for saleable forms will obtain them for cash direct from the Nazir, who will give receipt
for the price paid, preserve the duplicate receipts and remit the money to the treasury to be credited
under"Sale of saleable forms".
331. The stock of saleable forms and cheque books.
- The stock of saleable forms and cheque books in all offices subordinate to the Board should be
verified once in every six months, the saleable forms by the Deputy Collector or other
officer-in-charge of the Nazarat and the cheque books by the Treasury Officer who should also verify
that the sale proceeds of the saleable forms and cheque books sold during the period have been
deposited into the treasury. The certificates in the forms noted below should be annexed by the
officers concerned to the half-yearly return of saleable forms and cheque books submitted to the
Press and Forms Department, Bihar:-(1)Form of certificate of the Deputy Collector or other
officer-in-charge of the Nazarat.Certified that stock of saleable forms other than the cheque booksBihar Board's Miscellaneous Rules, 1958

shown in this return to be in hand on the............ 20.............. has been duly verified and found
correct.
(Sd.)Nazir (Sd.)Deputy Collector or otherOfficer-in-Charge of the Nazarat
(2)Form of certificate of the Treasury Officer.Certified that the stock of cheque books shown in this
return to be in hand on the................ 20................... has been duly verified and found correct and
that the sale-proceeds as shown in it have been deposited into the treasury.
(Sd.)Clerk-in-charge of cheque books. (Sd.)Treasury Officer
332. [ Nazir under Superintendent's supervision. [Substituted by C.S. No. 10
dated 3.8.1965.]
- The Nazir shall be under the general supervision of the Superintendent who will examine his
accounts and initial his cash books daily, even if there are no transactions on any day. He shall check
daily the account of sales of saleable forms kept by the Nazir in Register 99 of the Register and
Return Manual along with the receipt book. It will be the duty of the Superintendent to see that no
money is being unnecessarily kept in the Nazir's hands. After the checking of accounts by the
Superintendent, the cash book and the subsidiary register along with the documents in support of
receipts and payments shall be placed before the Nazarat Deputy Collector who will check the
accounts once again and verify the cash daily.]
332A. [ Custody of cash. [Inserted by C.S. No. 10 dated 3.8.1965.]
- Whenever the cash balance in Nazarat unavoidably exceeds the permissible limit having regard to
the security of the Nazir, and for any reason cannot be deposited into the Treasury, sub-treasury the
Nazarat Deputy Collector shall place the bulk of cash in the double lock one key of which shall be
held by him and the other by Nazir. In no circumstances, the cash in the custody of the Nazir shall
exceed the amount which he is authorised to hold having regard to the security deposited by him.
The surplus shall be deposited into the Treasury/Sub-treasury, on the next working day, without
delay.]
333. [ Certificate of correctness of Nazir's Accounts. [Substituted by C.S. No.
15 dated 15.7.1968.]
(a)At the close of each month, the Nazarat Deputy Collector must satisfy himself and certify to the
Collector that the Nazir's Accounts have been duly kept and the cash balance including vouchers had
been verified by him daily throughout the month.(b)The Collector or the Additional Collector in case
of the District Nazarat and the Sub-divisional Officer in case of the Sub-divisional Nazarat shall
personally verify the balance in cash and vouchers once every month and also at each regular
inspection of Nazarat/Nazarats under him and shall record the result of his verification on the cash
book concerned sending a note of irregularities detected, if any, to the next Superior Officer.(c)The
Sub-divisional Officer or the Land Reforms Deputy Collector in case of every Anchal Nazarat shall
likewise verify the balance in cash and vouchers of every Anchal Nazarat in the sub-division
quarterly and send a note of irregularity detected,-if any, to the Collector of the District.Note 1. - TheBihar Board's Miscellaneous Rules, 1958

above Rules shall apply mutatis mutandis to Sub-divisional and Anchal Offices, the Head clerks of
which are also Superintendents for the purpose of Rule 332 and the Anchal Adhikaris are also
Nazarat Deputy Collectors in respect of the Anchal Officer for purpose of these Rules.Note 2. - For
the purpose of discharging their duties under Rules 332 and 333 above, the Office Superintendent
and the Nazarat Deputy Collector must examine:(i)Register 43-A-Register of processes for
realization of money,(ii)The cheque receipt books used by the Nazir and the Naib-Nazir etc.,
and(iii)at least 4 per cent and 2 per cent respectively of the cheque receipt books used by the process
servers.]
334. Supply and sale of maps.
- The following rules for the supply and sale to the public of village settlement maps, skeleton and
detailed thana maps and thana lists should be observed in those districts in which copies of such
maps are available.These Rules relate to maps which are intended for sale to the public and do not
apply to maps supplied to the District Officer for administrative purposes. These latter should on no
account be sold. The district maps are kept in stock for sale in the Survey Office, Gulzarbagh, and
their prices are fixed by the Director of Land Records and Surveys:-(a)Village settlement maps,
skeleton and detailed thana maps and thana lists will be supplied to the Collectors by the Director of
Land Records and Surveys. The price fixed for the sale of village map is [annas twelve per copy of
each sheet.] [New Paise.] The price of the skeleton and the detailed thana maps is [eight annas and
one rupee] [New Paise.] [four annas per sheet] [New Paise.] respectively and that of a thana list,
which is an index to the skeleton thana map, is rupee one per copy.(b)The main depot for maps
supplied for sale will be the headquarters of each district, but some copies of maps of villages and
thanas situated within each sub-division should be kept for sale at the sub-divisional office
also.(c)The maps will be kept in the custody of the Collectorate or sub-divisional Nazir. In the case
of thana maps they should be kept unfolded and between stiff covers; and separate bundles should
be made, one for each thana, the name of the thana being written on the board. To enable the maps
of a particular thana being found out at once, a ticket, bearing the name of the thana, should be
hung outside each bundle attached to it by a piece of tape. In regard to the village maps, the maps of
villages in each thana should be kept in separate bundles serially arranged according to the thana
number-all maps of the same village being kept together unfolded and between stiff covers; and a
ticket, bearing the thana number and name of the village to which the maps in the particular bundle
relate, should be hung outside the bundle attached to it by a piece of tape. In case of village maps
consisting of more than one sheet, similar arrangements should be made to keep in separate
subsidiary bundles copies of the same sheet, the village thana number and the sheet number being
written on stiff cover (e.g., 2/1, 3/2, 5/1, 5/2, 5/3, etc., the numerators showing the village thana
number and the denominators showing the sheet number) and corresponding tickets being hung
outside each subsidiary bundle attached to it by a piece of tape. The Nazir will maintain Registers 91
and 92 which should be balanced quarterly. The supply received and the stock balance should be
entered in red, ink, and the sales in black.The Nazir keeping the registers should see that, before
they are opened, type-written copies of the instructions (at the foot of the forms of registers) are
pasted inside the covers of the respective registers.(d)Applicants for copies of maps will obtain them
for cash direct from the Nazir, who will give receipts for the price paid, preserve the duplicate
receipts and remit the money to the treasury to be credited under "Sale of cadastral maps."(e)ThereBihar Board's Miscellaneous Rules, 1958

will be a quarterly verification between the treasury and the nazarat stock account of maps, and the
Treasury Officer will certify in the account that the sale-proceeds, as entered, have been duly
credited in the treasury.(f)The Deputy Collector in charge of the nazarat will examine the stock
account of maps at the close of each quarter and will see that all new supplies have been duly
entered, that the account of sales has been properly made up, that the certificate of Treasury Officer
has been given.He will also annex to the half-yearly return mentioned in rule (i) below a certificate
in the following form:-"Certified that the stock account of maps and lists as shown in the return to
be in hand on the 20.................................. has been duly verified and found correct. The Treasury
Officer has also given a certificate that the sale-proceeds, as entered, have been duly credited in the
treasury."(g)When the stock of a particular sheet is found to be nearly exhausted, the Nazir is
personally responsible for reporting the fact to the Deputy Collector in charge of the nazarat, who
will report to the District Officer.The District Officer should then, except in case of maps which are
about to become obsolete, indent for a fresh supply from the Deputy Director of Surveys, Bihar.
These subsequent supplies should be shown in the registers prescribed and maintained under rule
(c) above and also in the next half-yearly returns which District Officers have to submit under rule
(i) below. The cost of supplying these additional copies is met from the provision made in the budget
of the Bihar Survey Office. If this is not sufficient, in any year, to cover the cost, the Director of Land
Records and Surveys should apply for special provision.(h)(i)A Gazetted officer, other than the
officer incharge of the Department, appointed by the Collector, will also check the stock of the
balance of maps in hand each year according to the scale prescribed below:-
Number of maps in stock. Number to be checked.
Greater than but less than  
0 5,000 All.
5.000 10,000 5,000 + 30 per cent of the excess over 5,000.
10.000 15,000 6,500 + 20 percent of the excess over 10,000.
15.000 20,000 7,500 + 10 per cent of the excess over 15,000.
20.000 ... 8,000 + 5 per cent of the excess over 20,000.
The officer will certify on the account as to the correctness or otherwise of the balance in hand in the
following form :-
Total number of maps in stock ...
Total number of villages concerned ...
Total number of maps checked ...
Total number of villages checked ...
Note. - It is essential that the maps of those villages which are excluded from verification in one year
should be checked in the following year or years so that the maps of all the villages in stock are
verified in rotation.(ii)The result of this verification may be of great use to the District Officers in
furnishing the half-yearly return of maps, prescribed in rule (i) below. Some of the District Officers
may therefore, prefer to do checking in April or in October. But neither of these months is entirely
suitable, the weather being very hot in April in most districts and the first fortnight of October is not
infrequently a period of heavy rains. It is, therefore, left to the Commissioner to fix the month in
which the verification in each District is to be carried out, provided that the work is not allowed toBihar Board's Miscellaneous Rules, 1958

interfere with touring.(i)The Director of Land Records and Surveys and the Deputy Director of
Surveys, Bihar should be supplied by District Officers within the month following the half year to
which the return relates, with a consolidated half-yearly return No. LVII, in the form given at the
end of this Chapter, in respect of village, skeleton and detailed thana maps and thana lists. The
Director of Land Records should verify the supply of maps and list. He should also verify the
amounts realised by sale during the half year as shown in the return with those brought to credit in
the district cash accounts, which will be communicated to him by Accountant General monthly by
treasuries."The District Officers should send to the Deputy Director of Surveys, Bihar a list of village
maps sold during the half year along with the return mentioned above."(j)The amount of security of
the nazirs may, if necessary, be increased by District Officers on the principles laid down in Chapter
X.
Return No. LVII of| skeleton thana mapsdetailed thana mapsthana listsvillage maps| in stock,
received and sold at during the half year ending the....... of........ 20.....
 Number of maps Cost Remarks
Rs. P.
Skeleton thana maps-    
Previous balance ....   
Received during the half year ....   
Total ....   
Sold during the half year ....   
Balance ....   
Detailed thana maps-    
Previous balance ....   
Received during the half year ....   
Total ....   
Sold during the half year ....   
Balance ....   
Thana lists-    
Previous balance ....   
Received during the half year ....   
Total ....   
Sold during the half year ....   
Balance ....   
Village maps-    
Previous balance ....   
Received during the half year ....   
Total ....   
Sold during the half year ....   
Balance ....   Bihar Board's Miscellaneous Rules, 1958

Memo No.Forwarded to the Director of Land Records and Surveys, Bihar for favour of verification of
the supply and of the amount realized by sale.Collectorate:The.................. 20...................Collector.
Chapter XVII
Money-Orders other than Revenue and Cesses
335.
The following rules relating to money-orders other than revenue money-orders, in favour of
Government and local bodies entitled to bank at treasuries or sub-treasuries, were published under
the Government of Bengal notification No. 1209-L.S.G., dated the 17th February, 1906.
Part 1 – Procedure in the Office of Issue
1. Use of proper form of money-order. - Whenever a money-order presented
for issue is drawn in favour of any officer of Government or of a local body
on his official capacity, it will be the duty of the money-order clerk or sub or
branch postmaster to see that the proper form of money-order is used.
2. [Revenue money-order form] [The revenue money-order form and the
revenue money-order rules are given in the Tauzi Manual and the form and
the rules and the tacavi money-order are given in the Loans Manual.]. - If the
remittance is for land revenue, or the local cesses, the revenue money-order
form must be used, and the rules relating to revenue money-orders must be
observed. If the remittance is for rent due on Government land, the rent
money-order form must be used. If is for re-payment of a tacavi loan, the
tacavi money-order form should be used. If it is for payment of Sales Tax, the
sales tax money-order form should be used. If it is for the payment of
decretal amount, the money-order form of decretal amount should be used.
3. Inland money-order form. - If the remittance is for any other purpose the
ordinary inland money-order form must be used.
Note 1. - Special forms of coupon to be pasted on the coupon part of the ordinary money-order
forms are prescribed for remittance of Income-Tax and excise licence fees. See paragraphs (7) and
(8) below.Bihar Board's Miscellaneous Rules, 1958

4. Fraction of an anna* may be included but no fraction of a pie*-Limit of
amount. - The rule prohibiting the inclusion of pie* (fraction of an anna*) is
not applicable to money-orders in favour of any officer of Government or
local body in his official capacity. Such money-orders may contain any
fraction of an anna*, not less than one pie*. Remittances of amounts,
including fraction of pies*, are not allowed. The limit of the amount of a
single money-order is the same as of any other ordinary money-order.
*Now Rupees and Paise.
5. Form of different kinds of remittances. - If a remitter of a land revenue or
the local cesses, Public work cess or Zamindari Dakcess of rent due on
Government land or of a tacavi loan desires to remit at the same time any
sum due to Government on any other account, he must use a revenue
money-order form for the remittance of land revenue and local cesses, or for
so many of these dues as he wishes to remit or a rent money-order or a
tacavi money-order form, as the case may be, and use a separate ordinary
inland money-order form for each of the remittances.
6. Separate form to be used for each Government due. - A separate
money-order form must be used for each Government due remitted by the
ordinary inland money-order, and remittances on two accounts may not be
included in one ordinary money-order.
7. Filling up of ordinary inland money-order coupon-Remittance by
telegraphic money-orders. - When an ordinary inland money-order form is
used for remittance on any account other than that mentioned in rule 2 or
income tax for which there is special coupon (form 1-G.M.O.) the
money-order clerk or sub or branch postmaster must see that particulars of
the object of the remittance are entered clearly on the ordinary coupon of the
form. If the object of the remittance is not clearly stated on the coupon, the
money-order clerk or sub or branch postmaster should not accept the order
until the omission is rectified and object clearly stated. The money-order
clerk or sub or branch postmaster should give any aid that the remitter may
require to fill up the coupon and may not demand or accept any gratification
in return on pain of dismissal. In the case of a telegraphic money-order the
remitter should be requested to advise, the nature of the remittance by a
separate telegram to the payee:-Bihar Board's Miscellaneous Rules, 1958

(a)if the remittance is on account of Income tax the remitter must be furnished with one of the
Special Income-tax Coupons (Forms 1/ G.M.O.) and must fill up all particulars indicated thereon.
The remitter is responsible for the correctness of the entries, but it is the duty of the money-order
clerk or sub or branch postmaster to refuse any money-order in which all the particulars are not
entered;(b)if the remitter is illiterate, the money-order clerk or sub or branch postmaster should
give him any aid he may require to fill up the entries. The money-order clerk or sub or branch
postmaster must give this aid gratis and may not demand or accept any gratification in return on
pain of dismissal;(c)the income tax coupon should then be carefully and securely pasted by the
money-order clerk or sub or branch postmaster to the blank space provided on the coupon of the
money-order form. Care must be taken that the coupon is not pasted over any part of the
acknowledgement;(d)the coupon will be detached and kept in the treasury or sub-treasury at the
time of payment.
8. Treatment of telegraphic money-orders. - After the money-order has been
properly filled up, it should be received and dealt with in the same way as
any other ordinary inland money-order.
9. Receipt for money-order. - Every remitter of a money-order, other than a
rent or revenue money-order, or excise money-order, in favour of an officer
of Government or of a local body, should be informed that instead of the
usual money-order acknowledgement, signed by payee, he will ordinarily
receive the usual departmental receipt, which will be forwarded to him direct
by post, and that he should address the payee regarding it if he does not
receive it in due course. He should also be advised to keep the carbonic
receipt carefully until he receives either the formal departmental receipt from
the payee or the usual money-order acknowledgement.
Part II – Procedure in The Post-Office of Payment
N.B. - The rules in this part apply only to post offices (head or sub) at the headquarters of districts
and sub-divisions. Other Post-offices which receive for payment ordinary money-order in favour of
offices of Government or of local bodies in their official capacity will pay them in cash under the
procedure applicable to money-orders in favour of private individuals.
10. Payment by book transfer. - Money-orders will be paid by book transfer:
(1)for rent, if in favour of District Officer, Sub-divisional Officer, Certificate officer or other gazetted
officer, excepting the khas tahsildars, tahsildars and managers who are Deputy or Sub-Deputy
Collectors;(2)on other account than rent, if in favour of the Magistrate or Collector (or Deputy
Commissioner), or in favour of the Deputy Collector or other officer in charge of any department
under the Magistrate or Collector (or Deputy Commissioner), or in favour of the Sub-divisionalBihar Board's Miscellaneous Rules, 1958

Officer, or any officer in charge of any department under the sub-divisional officer;(3)upon a written
requisition received by the post-office from the treasury or sub-treasury officer, if in favour of any
other Government officer in his official capacity, and(4)if in favour of any local body (other than a
cantonment committee) entitled to bank at the treasury or sub-treasury.Explanation. - A
money-order issued by any local body and returned unpaid by the post office shall be treated in the
same way as a money-order issued in its favour.
11. List of money-orders. - When the rent and other money-orders to be paid
by book transfer under rule 10 above are in all respects ready [to be handed
over to the postman,] [[Only the total number and amount of official
money-orders received for payment need be entered in the register of
money-orders received. In order, however, that the record may be complete it
will be necessary to make a note in the last column of the register whenever
all the official money-orders received in one day are not included in the list of
that date. For example, if in the register of money-orders received on the 5th
July there are shown 500 official money-orders for Rs. 10,000 but 300 of
these orders for Rs. 7,000 were received too late for inclusion in the list sent
to treasury on the 5th there should be an entry in the last column of register
in this form:-
200. for Rs. 3,000 included in the list of 5th
300. for Rs. 7,000 included in the list of 6th.]] they should be examined with
reference to the name of the audit office, stamped on them, and a separate
list in [triplicate] [The duplicate and triplicate will be prepared by carbonic
paper, and a hard pencil must be used in writing the list.] (Form 2-G.M.O.)
should be made out by the money-order clerk for each audit office, [the name
of the audit office] [If on any date official money-orders stamped with names
of all for audit offices are received for payment, it will be necessary to
prepare four separate lists, each in triplicate.] being noted in red ink at the
head of the list. The entries in the money column of the list should be
carefully totalled.The original copy of the list will take the place of the
Journal of money-orders paid, the duplicate of the list will be sent to the
treasury under the procedure described below, and the triplicate of the list
will be the list for the audit office. No money-order which is not a telegraphic
money-order should be included in the list, unless the object of the
remittance is entered on the coupon.Bihar Board's Miscellaneous Rules, 1958

Note. - When it is necessary to prepare one or more separate lists in addition to the lists for the
home audit office, the total of each other list should be entered below in the total of the list for the
audit office, and a grand total made both in words and figures. In that case, too, after the words
"detailed above" in the printed entry to be signed by the postmaster at foot of the original and
duplicate of the list for the home audit office, should be inserted in manuscript the words "and in the
accompanying list" or "and the accompanying two lists" as the case may require.
12. Documents to be made over to the postman. - The Postmaster should
then check the entries in the list or lists with those on the money-orders and
also check the total of the money-column. He will then give the postman the
duplicate of the list or lists, the money-order and a treasury or sub-treasury
voucher representing the total value of the money-order, as entered at the
foot of the list for the home audit office as directed in Rule 11 above. The
amount represented by treasury or sub-treasury voucher will not be charged
against the letter of credit, and will be paid quite independently of the
balance of any letters of credit held by the treasury in favour of the post
office.
13. Documents to be taken to accountant and to be received back from him. -
The postman will take the duplicate list or lists the money-orders, and the
treasury or sub-treasury voucher to the accountant and will receive back
from him the money-orders without the coupons and the acknowledgements
except in the case of "rent" money-orders paid by book transfer, from which
the coupons only will be detached by the accountant and not the
acknowledgements. The postman will be careful to see that he receives back
all money-orders, and that they are all duly receipted by the accountant and
in the case of money-orders for amounts exceeding Rs. 500 by the treasury
or sub-treasury officer also.
14. Disposal of paid money-orders. - The paid money-orders received back
from the treasury or sub-treasury will be examined by the money-order clerk
in the same way as other ordinary money-orders, and the total amount of the
money-orders will be entered in the journal of money-orders paid by single
entry thus: As per G.M.O. list-Rs. A. P.; "The classification column of the
triplicate list will then be filled up" and the money-order will be disposed of in
the usual way. As the payees of officials money-orders, other than rent
money-orders and excise money-orders will furnish the remitters with
departmental receipts the acknowledgements other than those pertaining toBihar Board's Miscellaneous Rules, 1958

rent money orders and excise money-orders will not be returned by the
accountant for transmission to the remitter. The original and the triplicate
lists will be kept with the journal of money-orders paid until the next list of
ordinary money-order paid is sent to the audit office, when the
corresponding (triplicate list of official money-order paid will also be sent,
the paid money-orders being arranged in order and attached to the
appropriate lists. The original list will then be filed, a separate file of original
lists being kept with each journal of money-orders paid so that the dates of
the journal and file of official money-order lists correspond.
15. Entries in account of post office. - The amount of treasury or sub-treasury
voucher will be entered in the post office accounts on the receipt side as
drawn from the district or sub-treasury, as the case may be, and will be
included in the sum entered on the payment side under the head. "Amount of
money-orders paid". In the case of a head office the amount will also appear
in column II of the head office pass book (A/c. 8). All these entries must be
made on the same date.
16. Procedure in respect of money-orders without the object of remittance on
coupons. - If it should happen that a money-order for any officer or local
body named or indicated in rule 10 is received at the office of payment
without the object of the remittance being entered on the coupon, the money
order will as stated in rule 11, not be included in the day's list. The
postmaster will retain the money-order in deposit and make a reference to
the office of issue to ascertain the object of the remittance. On receipt of a
reply he will attach it to the coupon, and the reply will be considered as part
of the coupon. The money order will then be included in the next list sent to
the treasury or sub-treasury. If, notwithstanding a reference to the office of
issue, the object of the money-order cannot be ascertained, the postmaster
of the office of payment will treat the money-order as refused, and return it
under the usual procedure to the office of issue, noting across the coupon
the words "Refused, as object of remittance not stated." Every case in which
a money-order is received without the object being entered on the coupon
should be reported by the office of payment to the Superintendent of the
division in which the office of issue is situated.Bihar Board's Miscellaneous Rules, 1958

17. Monthly return of official money-orders. - On the first of every month the
money-orders clerk or sub-postmaster of the headquarters or sub-divisional
post office will prepare a return (Form 3-G.M.O.) of official money-orders,
other than revenue and rent money-orders, received during the previous
month.The returns of post master at sub-divisional stations will be submitted
to the postmaster of the district headquarters of the 1st of the month, and the
return of the headquarters post-office will be submitted to the head of the
circle on the 5th of the month, together with the returns of any offices at
sub-divisional stations in the district.
Part III – Procedure to be Followed in the Treasury Or
Sub-Treasury
18. Requisition for payment of money-orders by book transfer. - When any
officer of Government, not specified in rule 10, requests that money-orders in
his favour may be paid by book transfer, a written requisition to that effect
will be addressed by the treasury or sub-treasury officer to the postmaster at
the treasury or sub-treasury station.
19. Duties of treasury officer. - On receipt of the list or lists of money-orders
and treasury or sub-treasury voucher (see Rule 13) the accountant will check
and compare the documents. If there is any error, he will return all the
documents to the post-office with a note of the error or errors. When the
documents are correct, the accountant will at once cut off from the
money-order form coupon in the case of rent money-orders and the strip
containing the coupon and acknowledgement in the case of all other orders;
he will sign and date the money-orders as payee and return them to the
postman. In the case of money-orders for amount exceeding Rs. 500, the
treasury or sub-treasury officer also should sign and date the money-orders
as payee. The accountant will retain the coupons of rent money-orders, the
coupons, and acknowledgements of all other money-orders, the duplicate list
or lists of money-orders (Form 2 G.M.O.) and the treasury or sub-treasury
voucher.
Note. - In the case of rent money-orders the acknowledgements should not be cut off by the
accountant, but should be returned to the postman duly signed.Bihar Board's Miscellaneous Rules, 1958

20. Entries in treasury and sub-treasury accounts. - The treasury or
subtreasury officer will on the same day adjust the amount of the treasury or
subtreasury voucher by transfer debiting the amount to the post-office and
crediting the amounts of several money-orders as shown in the list or lists
and on the coupons to the appropriate departments or local bodies. If the
amount of any money-order cannot, for any reason, be credited at once to
the proper head of account it should be entered in the body of cash-book
with such particulars as are available, and a reference should be at once
made through the department concerned for further particulars, on receipt of
which credit to the proper head should be effected in communication with
the Accountant-General. In the case of telegraphic money-orders, the
reference should be made direct by post from the treasury or sub-treasury.
In the case of sub-treasuries a note should be made in the "remarks" column of the duplicate list
showing on what account each money-order was sent as indicated on the coupon. The column will
be blank when received from the post-office. The duplicate list or lists will be forwarded to the
district treasury with the subtreasury "daily sheet".Note. - When money-orders, other than revenue
money-orders, are received at a sub-treasury for any amount for which a certificate has been filed,
the certificate department will prepare chalans in triplicate, one for the accounts department, one
for the certificate department (to be filed with the coupon in the records of the case) and the third
for the requiring department. When money-orders, other than revenue money-orders, are received
at a sub-treasury for an amount for which no certificate has been filed, chalans in duplicate will be
prepared, one for the sadar treasury and the other for the department in whose accounts the
payment is to be credited. In the case of money-orders in payment of pound and ferry rent, chalans
in triplicate will be prepared, two for transmission to the sadar treasury and one for the local
board.To save time the duplicate and triplicate chalans should be prepared by pen-carbon
reproduction.
21. Advice list of money-orders. - To each department or local body in favour
of which money-order or money-orders have been received and credited the
treasury or sub-treasury officer will on the same day send an advice-list in
the form (4-G.M.O.) together with the corresponding strips consisting of the
coupons, and acknowledgements or, if rent money-orders are concerned,
together with the corresponding coupons. In the case of officers and local
bodies to whom daily advice-lists are sent of other receipts on their
accounts, the total amount of each money-order advice-list will be entered
with a reference to the money-order advice-list in the daily advice-list.
In the case of unpaid money-orders credited to local bodies, the number and date of the
money-order issued, and the party in whose favour it was originally issued, as well as the cause ofBihar Board's Miscellaneous Rules, 1958

non-payment, shall be distinctly shown in red ink in Column 2 of the advice list (4-G.M.O.).The
treasury or sub-treasury officer will be responsible that the total of the amounts of the money-order
advice-lists is equal to the amount of the treasury or sub-treasury voucher received from the post
office and debited to the postal department.
22. Money-orders not to be refused. - No money-order received from the
post-office may be refused.
Part IV – Procedure in the Office of the Payers of the
Money-Order
23. Request for payment of money-orders by book transfer. - When any
officer of Government, not separately specified in rule 10, desires that
money-orders in his favour be paid by book transfer, he will make a written
request to that effect to the treasury officer or sub-treasury officer for
communication to the postmaster.
24. Entries in registers. - Sending of receipts to remitter. - On receipt of an
advice-list (see Rule 21) with the corresponding coupons or strips of
coupons and acknowledgements, the usual entries will be made in the
prescribed register, and in the case of all money-orders, other than rent
money-orders and excise money-orders, the prescribed receipt will be sent
to the remitters by post, the postage being prepaid by service or ordinary
stamps, according as the department or local body is or is not entitled to use
service stamps. In the case of excise money-orders the acknowledgement
portions, duly signed, will be made over to the nearest post-office by the
Excise Deputy Collector or Sub-Divisional Officer for despatch to the
remitters.
25. Receipts where to be sent. - The prescribed form of receipt should be
sent to each remitter at the latest on the first open day after the receipt of the
advice- list from the treasury or sub-treasury.
26. Procedure in respect of remittances which do not tally with accounts or
specify the period for which made. - If the amount of a money-order is more
than is due from the remitter, the excess should be entered as an advance on
account of future dues or be dealt with in such other way as the rules of the
department of local body may prescribe; if the amount is less than is due, itBihar Board's Miscellaneous Rules, 1958

should be credited as a payment in part; if the period on account of which
the remittance is made is specified, the amount should be credited on
account of the period; if the period is not specified, the remittance should be
set off against those dues which have been longest outstanding.
List of Forms Appertaining to Money-Orders other than Revenue Money Orders, in Favour of
Government and Local Bodies
Number of each form Name of each form Remarks
1 2 3
{|
1G.M.O.
| Income-tax money-order coupon.| Loose form.|-|
2G.M.O.
| List of ordinary official money-orders sent from post-officeto Treasury.| In triplicate. Loose form
(to be used by all post-offices athead-quarters and sub-divisions).|-|
3G.M.O.
| Treasury return showing the total number of money-orders,other than rent and revenue
money-orders, received at thepost-office.| Loose form (to be used by all post-offices at
theheadquarters).|-|
4G.M.O.
| Advice-list of money-orders received in the Treasury.| Loose form (to be used by Treasury).|-|| (1)
M.O. (sales Tax)... ... ...| ...Loose form.|-||
(2)| LM.O.6| ... ... ...*
||}* Rent Money-Orders.
{|
Form| 1G.M.O.
| Income-tax Money-Order Coupon No. and date ofM.O.|}
1.Name of Assessee ... ...
2.Father's name ... ...
3.Village ... ...
4.Thana ... ...
5.Number of list K or notice L ... ...
6.Sources of income ... ...
7.Amount of TaxPenaltyCost ......
8.Period for which paid ... ...
9.Date ... ...
10.Signature of the remitter ... ...
OriginalBihar Board's Miscellaneous Rules, 1958

{|
Form| 2G.M.O.
||}For.................... Audit Office.This list will be filled in this Post OfficeList of the Ordinary Official
Money-orders sent from........................
Post Office to the............| TreasurySub-treasury| on.....................20
Serial
numberPost-office of issue (When the
Post-office ofissue is a Branch
office, the name of the
Account office must
beentered also in
parenthesis).Number of
money-orderDate of
money-orderAmount of
money-orderRemarks
1 2 3 4 5 6
 Rs. P.
Total
amount in
figures and
words  
Date stamp of Post Office. Signature of M.O. Clerk
   
The money-orders detailed above for Rs. ........ have been paid by| TreasurySub-treasury| .........
Voucher No. .............
Signature of Post-masterDuplicate
{|
Form| 2G.M.O.
||}For.................... Audit Office.This list will be filled in this Post OfficeList of the Ordinary Official
Money-orders sent from........................
Post Office to the............| TreasurySub-treasury| on.....................20
Serial
numberPost-office of issue (When the
Post-office ofissue is a Branch
office, the name of the
Account office must
beentered also in
parenthesis).Number of
money-orderDate of
money-orderAmount of
money-orderRemarks
1 2 3 4 5 6
 Rs. P.
Total
amount in
figures and
words  
Date stamp of Post Office. Signature of M.O. Clerk
   Bihar Board's Miscellaneous Rules, 1958

The money-orders detailed above for Rs. ........ have been paid by| TreasurySub-treasury| .........
Voucher No. .............
Signature of Post-masterTriplicate
{|
Form| 2G.M.O.
||}For.................... Audit Office.This list will be filled in this Post OfficeList of the Ordinary Official
Money-orders sent from........................
Post Office to the............| TreasurySub-treasury| on.....................20
Serial
numberPost-office of issue (When the
Post-office ofissue is a Branch
office, the name of the
Account office must
beentered also in
parenthesis).Number of
money-orderDate of
money-orderAmount of
money-orderRemarks
1 2 3 4 5 6
 Rs. P.
Total
amount in
figures and
words  
Date stamp of Post Office. Signature of Post-master
   
{|
Form| 3G.M.O.
||}
Return showing the total number of money-orders other thanrent and revenue money-orders for
officer's named or indicated inrule 11 of the Official Money-order Rules received at
Post-Officeduring the month of....... 20 
    Total number of official
money-ordersTotal value of official
money-orders
1.Remaining undisposed of at the close of
the last month......___________ ___________
2.Received during the month ......___________ ___________
3.Total to be accounted for ......___________ ___________
4.Paid by Treasury or Sub-treasury
vouchers......___________ ___________
5.Finally treated as refused and returned to
offices of issuefor repayment to remitters......___________ ___________
6.Remaining undisposed of at the close of
the month......___________ ___________Bihar Board's Miscellaneous Rules, 1958

7.Total of items (4), (5) and (6) ......___________ ___________
8.Reasons for non-disposal of any money
orders entered against(6)......___________ ___________
Note. - The entries in lines (3) and (7) should agreeThe............................... 20....Postmaster
{|
Form| 4G.M.O.
||}
Advice list of.........Money-orders received in the| TreasurySub-treasury| on....... and credited to........
on the same day by book transfer.
[The coupons and acknowledgements are annexed.]
Serial no. in post-office list of this
datePost-office of issueNumber of
money-orderAmount of
money-order
1 2 3 4
 Total......  Rs. P.
   
Total number of money-orders-Total amount of money-orders (in words)-Signature of Treasury
OfficerThe........ 20....District......Rent Money-Orders
336. Rent money-orders.
- The following rules of the Postal Department relating to rent money-orders were published under
the Government of Bengal Notification No. 846 T.R., dated the 22nd May, 1905 :
Part I – The Form of Rent Money-Orders
1. Parts of rent money-order form. - The rent money-order form is divided
into three parts, viz. -
(a)The money-order.(b)The acknowledgement (this is the tenant's receipt).(c)The coupon (This is
the counterfoil of landlord's portion in the receipts).
2. Description of parts. - Part (a) requires no description, as it is exactly like
the corresponding portion of the ordinary inland money-order form. Part (b)
is much larger than the acknowledgement of an ordinary money-order form.
On one side of this part are printed headings to provide for the entry of full
particulars of the remittance, and on the other side fare spaces for the name
and address of the remitter. Part (c) is of the same size as the
acknowledgement, and contains the same headings as in part (b). On the
back of part (c) are special instructions relating to rent money- orders.Bihar Board's Miscellaneous Rules, 1958

3. For rent money-orders only. - This form is to be used for rent
money-orders only and for no other purpose.
4. Free distribution of form. - Forms of rent money-order should be freely
distributed among the rent-paying classes, and every facility should be given
to tenants to obtain these forms.
5. Supply of the form. - Every postmaster, sub-postmaster and branch
postmaster will be personally responsible that a sufficient supply of rent
money-order forms is always available in his offices. In case of emergency,
supplies may be obtained by telegraph direct from the stock depot.
Divisional Superintendents and Inspectors, when visiting offices, will see
that a sufficient supply of rent money-order forms is available, and mention
the fact in their inspection reports.
5.
-A. There is a special form of rent money-order numbered Rent-1 (a) for remitting rents in respect of
estates, tenures or holdings situated in the District of Chotanagpur Division (Palamau, Ranchi,
Hazaribagh, Singhbhum and Manbhum Districts)*.
Part II – Issue of Rent Money-Orders
6. Districts in which rent money-orders are payable. - Rent money-orders are
issued from all heads, sub and branch post-offices under the rules which
govern the issue of ordinary inland money-orders provided they are prepared
in the prescribed form and are payable in the following districts in the
Province of Bihar on which the Bihar Tenancy Act or the Chota Nagpur
Tenancy Act, 1908 is in force or any other districts to which the Local
Government may, from time to time, extend the provisions of the said Acts.
Bhagalpur, Champaran, Darbhanga, Gaya, Hazaribagh*, Manbhum*, Munger, Muzaffarpur,
Palamau*, Patna, Purnea, Ranchi*, Saran, Shahabad, Singhbhum*".Note 1. - There is a special form
of rent money-order numbered rent-1(a) for remitting rents in respect of estates, tenures or holdings
situated in the district of the Chota Nagpur Division (vide Bihar and Orissa Government Notification
No. 909-IIT-10-R.T., dated the 22nd September, 1924).Note 2. - Special care should be taken in
indenting for the correct rent money-order form.Note 3. - Rent due on Government land may be
remitted by rent money-order.Bihar Board's Miscellaneous Rules, 1958

7. Treatment of fractions of an anna. - The Rule prohibiting the inclusion of
pies (fractions of an anna) in the amount of an ordinary money-order does
not apply to rent money-orders, which may contain any fraction of an anna
not less than one pie**.
Note. - The sub-items which go to make up the total of the rent money-order may contain fractions
of a pie**.
8. Separate money-order for each tenure or holding. - There must be a
separate money-order for each tenure or holding. Rent for two tenures or
holdings may not be sent by one money-order.
* Now, part of Jharkhand State.** Now, New Paise.
9. Post-office to help the remitter to make the necessary entries. - The office
of issue, when requested to do so, will help the remitter to make the requisite
entries, and if necessary, will make entries for him in the form of rent
money-order; but no fee or any gratification for this service may be
demanded or accepted, either directly or indirectly, by any official of the
Postal Department.
10. Address of the payee. - Person remitting money by rent money-orders
should be informed that unless they have received special instructions from
the landlord, on the subject, they should make the orders payable to the
landlord, or to his agent, or to the manager (if one has been appointed),
according as the rent has previously been paid to the landlord, or to his
agent, or to a manager. The name of the payee must in each case be entered
on the money-order. In the absence of special instructions from the landlord,
a rent money-order should always be made payable at the place at which the
tenant has previously paid rent. If the rent has previously been collected in
the tenant's village by an agent whose office is not in the village, the
money-order should be made payable at the agent's permanent office, or at
such other place as the landlord may appoint.
11. Post office to see that entries are made against each heading of the form
and that there is no erasure or correction. - The office of issue is responsible
that no rent money-order is issued of which the coupon and
acknowledgement are blank, or are not completely filled up.The post-officeBihar Board's Miscellaneous Rules, 1958

has no means of ascertaining the correctness of the information supplied by
the remitter; all that is necessary is that the postmaster or money-order clerk
should see that entries are made against every heading in the coupon and
acknowledgement. No rent money-order may be accepted for issue in which
there is any erasure or correction in the name or month or year of the kist for
which a remittance is made. If the remitter wishes to make any alteration or
tender a money-order in which there is any alteration or erasure in the entry
of the name or month or year of kist, he must be instructed to fill up a fresh
money-order. When a rent money-order with deficient entries on the coupon
or no entry at all is presented for issue, the issuing post-master should point
out the omission and help the remitter to the best of his power to supply
them.
12. No entry to be made beyond those provided in the form. - The office of
issue must also see that no entry is made by the remitter beyond the entries
provided for in the form of rent money-order. In some cases the tenant enters
the annual rent or the area or the nature of his holding. Such entries are not
provided for in the form, and were intentionally not provided for and should
not be allowed. If a remitter tenders a rent money-order containing any entry
for which the form does not provide, the postmaster or money-order clerk
should refuse to accept the form and should ask the remitter to fill up
another form. Under Rule 9 the postmaster or money-order clerk will, if
requested to do so, help the remitter to fill up a fresh form correctly.
13. Mode of distinguishing rent money-order forms. - The word "rent" should
be written before the number of every rent money-order, and this mode of
distinguishing rent money-order should be adopted when ever the number is
entered. The number assigned to a rent money-order by the head office or
sub-office of issue will also be entered at the top of the acknowledgement
and coupon by the money-order clerk of the head office or the
sub-postmaster of the sub-office of issue, as the case may be.
14. Return of rent money-orders. - One line of the return of rent money-orders
issued (form 2-Rent) should be filled in by every head and sub-office at the
close of each day. On the 1st of the following month the return should be
totalled and sent to the head-postmaster. The head-postmaster will compile a
general return (form 3-Rent) and submit it to the Postmaster-General not laterBihar Board's Miscellaneous Rules, 1958

than the 10th of the month following that to which it relates. Branch offices
will not submit any returns, as rent money-orders issued from such offices
will be included in the returns of their account offices.
14.
-A. Rent money-orders are not payable in Angul, Santhal Parganas.
Part III – Payment of Rent Money-Orders
15. Careful examination of the name of month and the year of the Kist. -
Before a rent money-order is made over to the postman for payment, the
money-order clerk or postmaster of the office of payment will carefully
examine the name of month and year of the kist entered in the coupon and
acknowledgement, and satisfy himself that they have been clearly entered
and bear no marks of erasure or correction.
16. Procedure when the examination shows any discrepancy. - If the
examination prescribed in rule 15 shows any discrepancy or alteration in the
entries of the kist in the coupon and the acknowledgement, the money-order
must not be paid to the payee but should be returned to the office of issue
for repayment to the remitter with the following certificate endorsed in red
ink by the postmaster of the office of payment across the
acknowledgement-"Entry of kist defective returned for payment to
remitter-(signature) post master". The office of payment will at the same time
note the error in the error book, and send a copy of the entry to the
Superintendent in whose jurisdiction the office of issue is situated, in order
that the official in fault may be punished.
17. Action on the part of the Superintendent.- On receipt of the copy of the
entry in the error book, the Superintendent will take such action as appears
to him suitable, having regard to the special instructions to offices of issue in
rule 21 of these Rules.
18. Payment to the landlord. - A rent money-order should always be paid at
the landlord's office at the place of payment entered in the money-order. If
the money-order is drawn out as payable to the landlord himself, payment
may be made to him or to any person authorised by him in writing to act asBihar Board's Miscellaneous Rules, 1958

his agent, or to receive payment of money-order in his favour. If the
money-order is drawn out as payable to two or more joint landlords the
receipt and acknowledgement must be signed by both or all the landlords, or
by an agent authorised in writing by both or all the landlords. If the
money-order is drawn out as payable to an agent or manager, payment may
only be made to the payee named and not to any one else. In making over
money to postmen for payment of rent money-orders, the post master of the
office of payment must observe the limit fixed for the amount to be entrusted
at one time to a single postman or village postman. The date stamp of the
office of payment should be impressed on the reverse of the
acknowledgements just before the money-orders are given to the postman
for payment.
Note. - Rent money-orders in favour of a District Officer, Sub-divisional Officer, Certificate Officer,
or other Gazetted Officer of Government (excepting the khas, tahsildars and managers who are
Deputy or Sub-Deputy Collectors), should be paid not in cash but by book transfer under the rules
contained in Part II of the "Rules relating to money-orders in favour of Government or local bodies
entitled to bank at treasuries or sub-treasuries."
19. Rent money-orders like ordinary money-orders. - In all other respects rent
money-orders will be dealt with in the office of payment exactly like ordinary
inland money-orders.
20. Return of rent money orders paid and refused. - One line of the return of
rent money-orders paid and refused (Form 4-Rent) should be filled in by
every head and sub-office at the close of each day. On the 1st of the
following month the return should be totalled and sent to the head
postmaster.The head postmaster will compile a general return (Form 5 Rent)
and submit it to the Postmaster-General not later than the 10th of the month
following that to which it relates. Branch office will not submit any returns.
The rent money-orders paid by branch offices will be included in the returns
of their account offices. All rent money orders paid, whether paid to the
original payees in cash or by book transfer or repaid to the remitters, are to
be shown in these forms under "Rent money-order paid."
Part IV – Disposal of Rent Money-Orders not Accepted by the
PayeeBihar Board's Miscellaneous Rules, 1958

21. Certificate of the postmaster when the payee refuses payment. - If a rent
money-order is refused by the payee, the postmaster of the office of payment
will certify in red ink across both the coupon and acknowledgement that the
payee has declined to receive payment. This certificate must always be
recorded on refused rent money-orders whether the payee has or has not
noted his refusal in writing and the certificate will be signed by the
postmaster. The postman who presented the order with the amount thereof
to the payee will write his name and the date of presentation under the
postmaster's signature. This certificate will be record in the form given
below. The refused money-order will then be treated in the usual way and
returned to the office of issue (with the coupon stitched to it) for repayment
to the remitter. The coupon will be made over to the remitter (tenant) when
the amount of the order is repaid to him. The acknowledgement will, when
the office of payment is a head office, be retained in that office. In the case of
any other office of payment, the acknowledgement for a refused money-order
will be retained by that office until the 1st of the following months, when it
will be attached to the return of rent money-orders paid and refused, and be
forwarded to the head office.The acknowledgements relating to refused
money orders will be filed in monthly bundles in the head office and should
be kept in the post-office safe. The postmaster will be responsible for their
safe custody for three years from the last day of the agricultural year in
which the money-orders were issued. On the expiry of three years the
acknowledgements should be destroyed.
Form of CertificatePresented to the payee, but refused on...................
(Date) Postman (Date) Postmaster.
22. In all other cases refused rent money-orders treated like ordinary
money-orders. - In all other respects refused rent money-orders will be dealt
with exactly like ordinary inland refused money-orders.
Part V – Disposal of Rent Money-Order Acknowledgements
23. Acknowledgements of paid rent money orders. - The acknowledgements
of rent money-orders paid by head and sub-offices should, if they are to be
delivered from the offices of payment, be made over to the postmen or
village postmen at the next delivery and be dealt with as prescribed in ruleBihar Board's Miscellaneous Rules, 1958

25. Acknowledgements to be delivered from any office other than the head or
sub-office of payment should be sent to it in rent acknowledgement
envelopes (Rent 8); duly entered in the registered list. The disposal of the
acknowledgements in such cases should be noted in form Rent-6 (book of
rent money-order acknowledgements returned) which should be maintained
in head and sub-offices. The acknowledgement portion of the rent
money-orders by a branch office should not be cut off by that office, but the
paid money orders should be forwarded with the acknowledgements
attached to them to the account office. It is, therefore, not necessary for a
branch office to keep the form Rent-6.
24. Special book of rent money-orders. - Head and sub-offices should keep
the form 'Rent-7' (book of rent money orders acknowledgements delivered).
The acknowledgements of all rent money orders to be delivered from a
branch office should be sent by the head office of payment to the account
office of the branch office. These acknowledgements should be detailed by
the account office in the special book of rent money-order
acknowledgements delivered (form Rent-7), and be forwarded by the account
office to the branch office entered on the reverse of the branch office daily
account. The branch postmaster will note the numbers of the
acknowledgements in the branch office journal, obtain the postman or village
postman's signature against each entry and then hand over the
acknowledgements to the postman or village postman for delivery or deliver
the acknowledgements himself in the case of offices in which the delivery
work is performed by the branch postmaster.
25. Acknowledgements to be entered in the postman's book or register.-
Postman or village postman will enter the acknowledgements in detail in his
book or register, as the case may be, and will obtain the remitter's signature
or mark therein when delivering each acknowledgement.
26. Acknowledgement beyond the delivery range. - Acknowledgements
appertaining to rent money-orders, the remitters of which have removed
beyond the delivery range of the original office of issue, will be forwarded
direct to the remitters at their new addresses (if known) enclosed in postal
service registered covers.Bihar Board's Miscellaneous Rules, 1958

27. Non-deliverable acknowledgements. - Acknowledgements which cannot
be delivered in consequence of the remitters not being found will be returned
by the postman or village postman to the postmaster or money-order clerk
(as the case may be), who will sign for them in the postman's book or village
postman's register.
28. Undelivered acknowledgements to be kept in the office of issue for six
months. - Undelivered acknowledgements will be kept in office of issue (if a
head office) for a period of six months, and, if still unclaimed, will be
forwarded under a postal service registered cover to the Postmaster-General.
29. Undelivered acknowledgements to be retained for ten days in sub and
branch offices. - In sub and branch offices undelivered acknowledgements
will be retained for a period of ten days, and, if still unclaimed, will be
forwarded to the head office under a postal service registered cover. Such
acknowledgements will be kept in the head office for a further period of six
months, and, if still undelivered, will be forwarded under a postal registered
cover to the Postmaster-General.
30. Rent money-order acknowledgements to be preserved for three years. - A
rent money-order acknowledgement received by the Postmaster-General
under the provisions of the two preceding paragraphs will be kept by him for
a period of three years from the last day of the agricultural year in which the
money-order was issued and, if not claimed within that period, will be
destroyed.
31. Responsibility of post-off ice officers. - Postmasters, sub-postmasters
and branch postmasters of offices of issue will be responsible that
acknowledgements are delivered to remitters of rent money-orders without
any unnecessary delay and free of charge. It will be useful to make enquiries
as to the punctual and free delivery of acknowledgements from tenants who
may call at post offices to have rent money-orders issued.
32. Rules for void rent money-orders. - Void rent money-orders are to be
dealt with in accordance with rules 300, 301 and 302 of the Posts and
Telegraphs Manual, Vol. VI.
List of Forms Appertaining to Rent Money-OrdersBihar Board's Miscellaneous Rules, 1958

No. of
each formName of each form Remarks
1 2 3
1Rent Rent money-order Loose form printed in black or green paper.
1(a)RentRent money-order in Nagri Hindi
for use in the districts ofthe Chota
Nagpur Division.Ditto.
2Rent Return of rent money order issued.Loose form. To be supplied to all head and
sub-offices whichare authorised to issue rent
money-orders.
3RentDistrict return of rent
money-orders issued.Loose form. To be supplied to all head offices.
4RentReturn of rent money-orders paid
and refused.Loose form. To be supplied to all head and
sub-offices.
5RentDistrict return of rent
money-orders paid and refused.Loose form. To be supplied to all head offices.
6RentBook of rent money-order
acknowledgements returned.Bound in books of 20 pages each. Supplied to all
head officeswhich pay money-orders.
7RentBook of rent money-order
acknowledgements delivered.Bound in books of 20 pages each. Supplied to all
head officesand sub-offices which issue
money-orders except those markedN.D. in the
quarterly lists of Indian Post Offices.
8Rent Rent acknowledgement envelope.To be used by all offices which pay money-orders.
Printed inblack ink on white paper.
Rent - Rent money-order(Authorised for the Bihar and Orissa Circle excluding Chota Nagpur
Division).ToThe Postmaster,
 S.O.H.O.
Received the sum specified on
thereverse.Date........
Signature of witness to be taken when the
payee is illiterateor known to the post-office,
and in all cases when payment ismade by a
village postman or to aparda nashinwoman
onher own signature.Signature (in ink) of payee
orthumb-impression, if payee is
illiterate.Signature of
witnesspaid by meon.......
Round M.O. Stamp authorising payment   
  Signature and
designation of
officer who
paidthe amount
Oblong M.O. Stamp on payment   
       Bihar Board's Miscellaneous Rules, 1958

Date stamp of the office of payment Name stamp of the office of issue  
Received the sum specified on the reverse on........ on account of Rent particularised there.Signature
of witnessSignature (in ink) of Landholder or his Agent authorised in writing.Instructions for the
Remitter's Guidance
1. The amount of a rent money-order may include rupees, annas and pies but
not a fraction of a pie.
2. There must be a separate money-order for each tenure or holding. Rent for
two tenures or holdings may not be sent by one money-order.
3. In the absence of special instructions from the landlord, the remitter
should make the money-order payable at the place at which rent has
previously been paid and to the landlord himself or his agent, according as
rent has previously been paid to the landlord or an agent.
4. The limit of amount of rent money order and the rates of commission are
the same as for ordinary money orders.
Month stamp Oblong M.O. stamp on issue A.O. Stamp
{|
 
|
 
||}No. .................. Rent...................Date.......................Rs. P.For.........................................(in
words)............................M.O. ClerkIssuing PostmasterRemitter to fill up all entries below except the
Money Order No. on the acknowledgement.Amount (in words)
.......................................................Name and address of the payee (in
full)...............................................................Date.................................Signature of remitterSignature
and address of remitterAcknowledgement-(On Postal Service)No. ......... Rent
........................................Name of Landlord ..................................................................." of Estate
......................................................................" of Recorded Tenant
..............................................................Village in which tenure or holding is
situated......................................Thana...............................................................................Khatian No.
of Tenancy ..............................Details of remittance.................. Rent Local Cess Total amount
remitted by this money-order.
For-Kistof yearFor*Kistof year**For*Kistof
year**Total...........Principal Interest Principal Interest  
Rs. - P. (inwords)…...............................…...............................
Coupon.To be retained by the Payee   
No. Rent..................  Bihar Board's Miscellaneous Rules, 1958

Signature and address of
remitter .......
Name of landlord................Date Stamp of office of
issue 
" of Estate..............................  .....................................
" of Recorded Tenant..................... .....................................
" of Remitter............................ .....................................
Village in which tenure or holding
issituated.................... 
Thana ..................................  
Khatian No. of Tenancy..............  
 RentLocal
cess 
Details of remittanceFor
Kist of
year..................For*-Kist
of year**Principal Interest Principal InterestTotal amount
remitted by
this
money-order
Rs. P. (in
words)
    ….................................….................................….................................….................................
Total      
*In word  **In
figures
and
words 
Rent-1 (a) Rent money-order[Authorised for Chota Nagpur Division]To,The Postmaster
 S.O.H.O.
--------------------------------------------------------------------------------------------------------------------------------------------------Foldhere--------------------------------------------------------------------------
Signature of witness to be taken below when the payee isilliterate and in all cases when payment is made by a villagepostman or to apardanashinwoman on her own signature.Received the sum specified
on
thereverse.Date...................
Signature of
witness Signature (in ink) of payee orthumb impression, if payeeis illiterate.Paid by
me.
{|
 
||-| Oblong M.O. Stamp on payment| Round M.O. stamp authorising payment| Signature and
designation of officer who paid the
amount|}-----------------------------------------------------------------------------------------------------------------------------------Fold
here---------------------------------------------------------------------------------------------
  Received the sum specified on the reverse on ....... onaccount of rentBihar Board's Miscellaneous Rules, 1958

particularised there.
 Signature of
WitnessSignature (in ink) of Landlord or his Agent authorised inwriting.
 {|
 
|-| Date stamp of the office of payment| Name stamp of the office of
issue.|}-----------------------------------------------------------------------------------------------------------------------------------Fold
here---------------------------------------------------------------------------------------------Instructions For
the Remitter's Guidance
1. The amount of a rent money-order may include rupees, annas and pies but
not a fraction of pie.
2. There must be a separate money-order for each tenure or holding. Rent for
two tenures or holdings may not be sent by one money-order.
3. In the absence of special instructions from the landlord, the remitter
should make the money-order payable at the place at which rent has
previously been paid and to the landlord himself or his agent, according as
rent has previously been paid to the landlord or an agent.
4. The limit of amount a rent money-order and the rates of commission are
the same as for ordinary money-orders.
{|
 
|
 
||-| Month stamp| Oblong M.O. stamp on issue| Stamp|}
No. Rent...............Date.......................................
 Rs. p. (in
words)........................
For     ......................................
M.O. Clerk Issuing Postmaster
Remitter to fill up all entries below except the money-order no. and the entries on the right side of
the AcknowledgementAmount (in words)........................Name and address of the payee (in
full)..............................Date......................Signature of Remitter.Acknowledgement (Tenant's receipt)
On Postal Service
No. Rent......................................... Signature and
address ofBihar Board's Miscellaneous Rules, 1958

remitter
Name of
landlord.................................................
" of Estate or Tenure.....................................
" of Recorded Tenant....................................
" ofRemitter.................................................
Village in which tenure or holding is
situated.....
Thana in which tenure or holding is
situated.......
Khatian no. of
Tenancy.......................................
Details of remittance-For*-Kist of
Year**........For*- Kist of
Year**.......For*-Kist of
year**........Total--------------{|
Rent Local Cess Miscellaneous
Principal Interest Principal Interest
     
     
|-| Total amount sent by this money orderRs..............P..........(in words)|}
Coupon to be retained by the payee.  
No. Rent .........................................Date of Stamp
of Office of
issue
Name of
landlord.................................................
" of Estate orTenure.....................................
" of RecordedTenant....................................
" ofRemitter.................................................
Village in which tenure or holding is
situated.....
Thana in which tenure or holding is
situated.......
Khatian no. of
Tenancy.......................................
Details of remittance-For*........Kist of
Year**For*........Kist of
Year**For*........Kist of
year**Total--------------{|Bihar Board's Miscellaneous Rules, 1958

Rent Local Cess Miscellaneous
Principal Interest Principal Interest
     
     
|-| Total amount sent by this moneyorder Rs..............P..........(in words)|}Signature and address of
remitter*In words **In figures and words
Chapter XVIII
Malikana and other Periodical Payments
337. Description of malikana.
- Malikana is of two kinds :(i)Malikana or proprietary allowance is granted for estates of which the
settlement is not made with the proprietors under Section 5 (2) of Regulation VII of 1822. This is
fixed for the term of the settlement-(a) when tender of settlement is made to the proprietor and his
offer is not accepted, in which case the malikana is calculated on the amount of his offer, and (b)
when tender of settlement is made to the proprietor but the settlement is refused absolutely without
any offer being made, in which case the net collections of the year immediately preceding form the
basis of the calculation of the malikana. In both these cases also the amount of malikana is not
dependent on collections. Malikana is fluctuating-(c) when, as contemplated by the last clause of
Section 3, Regulation VII of 1822, it is considered inexpedient to offer the settlement to the
proprietor,the malikana should then be not less than 5 per cent of the net amount realized by
Government from the lands, vide Rule 617 (II) of the Bihar and Orissa Survey and Settlement
Manual, 1927.(ii)Malikana, which was allowed to Zamindars in virtue of their right as Proprietors, in
consequence of the settlement of their estates or lands out of their estates, with others. The Bihar
Malikana falls under this class, and is a compensation permanently granted to proprietors-(a) on
account of the settlement of their estates with others, on their refusal, (b) for lands given out of their
estates rent-free to others, by royal or other grants, which were never subsequently resumed, and (c)
for such lands which were subsequently resumed, and assessed to revenue by Government and
settled with the holders. It is of a pensionary nature, and does not depend on collections.Malikana of
the first class is payable for a term of years only, that is, during the currency of settlement. In cases
(a) and (b) the amount is fixed while in case (c) it may vary from year to year. Malikana of the
second class is permanent.
338. Malikana of the first class payable in one instalment for the whole year
and register to be maintained.
- The payment of malikana due to proprietors during the currency of settlement, whether the
amount is fixed or dependent on net collections will be made only in one instalment for the whole
year. A record of recipients and of payment of such malikanas will be maintained in Register No. 65
in the Register and Return Manual.This register will be in charge of a Deputy Collector, whose duty
it will be to see that all entries are correctly made. The amounts payable and the payments must beBihar Board's Miscellaneous Rules, 1958

checked with great care. No payment will be made without a special order of the Collector or the
officer-in-charge in his absence. The instructions at foot of the register must be carefully observed.
They will not appear on every page, but one of the pages on which they are printed will be placed at
the beginning of each register.
339. Permanent Malikana.
- Permanent or pensionary malikana will be paid on permanent payable orders issued by the
Collectors.
340. Register.
- A register of recipients of permanent malikana will be kept by each Collector in Form No. 66 of the
Register and Return Manual. All malikana grants relating to the same estate (where there are more
than one) should follow one another in the register,that is, the register should be written up estate
by estate, and the same course should be followed whenever the register has to be rewritten at any
future time. The register provides also for the recording of mutations, whether due to sale, gift or
inheritance. On a mutation occurring the necessary particulars will be filled in the mutation
columns against the original item affected and whether the whole or only a portion of such item is
transferred, the original entry will be scored through (i.e., Columns 1 to 4) by a line in red ink, and
entries of the transferred amount and of the balance, if any, of the original amount will be made at
the end of the register in continuation of the last serial number in the register. By thus recording
changes a continuous and clear record of all items payable in a district will be maintained in the
register. When malikana is payable to joint sharers, all their names will be entered in the register
under a single number, and mutations of any of the names will not be accompanied by the entry of
the new sharer's name under a separate number at the end of the register. The addition of such new
and separate numbers is to be made only when the transfer is of a share to be held separately in
future. The register will in the first instance be prepared under the personal supervision of a Deputy
Collector, who will initial every item in token of his having satisfied himself that the malikana is
payable. Every subsequent entry of a mutation and of a new serial number in continuation of the
register will similarly be initialled by a Deputy Collector.
341. Supervision of registers.
- Both the registers prescribed by Rules 338 and 340 will be kept under the supervision of the
Superintendent for daily reference.
342. Roll of malikanadar.
- For each item in Register No. 66 a roll in the following form will be drawn up under the signature
and seal of the Collector, and made over to the recipient, who will present it half-yearly for payment
at the District treasury on or about the 1st April and the 1st October respectively.Roll of recipients of
permanent malikanaBihar Board's Miscellaneous Rules, 1958

Serial number in the
general register
ofrecipients of
malikanaName of
recipientFather's
nameResidence,
thana and
villageAmount of
annual
malikanaHalf- yearly
instalmentRemarks
1 2 3 4 5 6 7
       
In columns 5 and 6 the figures are to be entered in words as well as in figures.Memorandum of
actual payment
Date of payment For what period Amount paid Signature of the Treasury Officer Remarks
  Rs.   
343. Duplicate roll.
- Duplicate copies of rolls [which will contain four additional columns between 4 and 5 for
identification, showing (1) the height, (2) the date or approximate date of birth, (3) the signature or
the thumb impression and (4) any marks borne by the recipient] will be prepared for record in the
treasury and when applications are made for payment the Treasury Officer must satisfy himself of
the validity of the claims by comparing both copies of the rolls in every case and will then order
payment, noting the fact in both rolls in the memorandum form on their reverse. When no space is
left in this form to note the payments, fresh duplicate rolls should be prepared and given to the
recipients under the Collector's seal and signature, care being taken to have the old rolls first
returned by the recipients for cancellation, unless the Collector is satisfied that they are
irrecoverable.Note. - Particulars concerning malikanadars, who are pardanashin ladies for Columns
5, 6 and 8 of the duplicate roll should be furnished by their authorised agents and their signature or
thumb impression taken in Column 7 of the roll in the presence of Gazetted officer on proper
identification.
344. Transfer of malikana.
- Whenever any transfer of malikana by sale, gift or inheritance occurs, the roll given to the old
recipient must similarly be recalled and cancelled, a new roll being then drawn up and given to the
transferee. If for any reasons the old roll is not produced and the Collector thinks that it is
irrecoverable the duplicate of the old roll in treasury should forthwith be cancelled. In every case of
mutation an intimation should be sent to the treasury whether the new roll is taken delivery of by
the transferee or not.. If the transfer is of a portion only of the malikana, the old recipient must still
be required to give up his roll for cancellation. A new roll for payment of the balance of the malikana
returned by him will then be supplied to him and a roll will be also given to the transferee for the
share acquired by him. Care must be taken on no account to give a new roll for malikana until the
old roll has been surrendered and cancelled, unless the Collector is satisfied that it is irrecoverable.
345. Exemption of malikanadar from personal appearance.
- A recipient of malikana, especially exempted by Commissioners of Divisions from personal
appearance, a female malikanadar not accustomed to appear in public or, a male malikanadar whoBihar Board's Miscellaneous Rules, 1958

is unable to appear in consequence of bodily illness or infirmity, may receive his or her malikana
upon his or her causing to be produced before the Treasury Officer a life certificate signed by a
responsible officer of Government or by some other well-known and trustworthy person.
346. Life certificate and necessary precaution.
- A recipient of malikana of any description, who causes to be produced before the Treasury Officer a
life certificate signed by some person exercising the powers of a Magistrate of any class under the
Criminal Procedure Code, or by any Registrar or Sub-Registrar under the Registration Act, or by any
pensioned officer, who, before retirement exercised the powers of a Magistrate, or by a Chaplain, or
any other Gazetted Officer of Government, is also exempted from personal appearance and the
malikana due to him can be paid to the presenter; provided the Treasury Officer has no doubt as to
the latter's (bona fides) of the bill, which should be accompanied by the life certificate above referred
to, without requiring a formal power-of-attorney.In all cases referred to above,the disbursing officer
must take precautions to prevent [imposition] [As the context suggests, it should be ], and must, at
least once a year, require proof, independent of that furnished by the life certificate, of the continued
existence of the recipient of malikana.
347. Time-barred malikana claims.
- The period of limitation fixed for a claim for malikana is prescribed by Article 132 of Schedule I of
Act IX of 1908 at twelve years. No claim to malikana, which is barred by limitation, should be
entertained unless the claimant can show good cause to the contrary. The onus must rest entirely
upon him to make good his claim and account for the delay in applying for payment of
malikana.Note. - The Government do not take the advantage of the law of limitation in case of
claims for malikanas, but when there is no clear evidence of the amount claimed being still due, or
when there is the risk of paying it more than once, the claim should be disallowed. In cases of claims
extending over 12 years the order of the Commissioner should be obtained.
348. Payment of proprietary allowances to share-holders.
- If a joint receipt from all the share-holders cannot be obtained, proprietary allowance may be paid
separately to the individuals entitled, if there is a record of their share in general register A and if
their right to receive the allowance is undisputed.
349. Sair compensation.
- The sair compensations granted to land-holders on the resumption of certain internal duties and
taxes under Regulation XXVII of 1793 are in the nature of permanent annuities like malikana; and
the rules relating to payment of permanent malikana apply, mutatis mutandis to them.Bihar Board's Miscellaneous Rules, 1958

350. Method of calculating capitalised value of all permanent periodical
payments to or by Government.
- The Government of India in their Resolution No. 3744-A, dated the 24th August, 1898 have
prescribed the following rules for calculating the capitalised value of all permanent periodical
payments to or by Government:(1)When Government is entitled to receive a periodical payment in
perpetuity and existing orders authorise the commutation of that payment for a single payment, the
said single payment should not be less than thirty times the amount annually paid. If the payer is
not willing to commute at this rate the right to receive periodical payment should not be given
up.(2)When Government is under an obligation to make a periodical payment in perpetuity and
existing orders authorize the commutation of that payment for a single payment, the said single
payment should not be more than twenty times the amount annually paid. If the payee is not willing
to commute at this rate, the system of periodical payment should continue.These rules apply only to
cases of actual commutation of payment. They do not affect any orders relating to the valuation of a
grant, assessment, or other concession or demand, when such valuation is made for official
purposes only, and not for the calculation of an actual payment.
Chapter XIX
Statutory Revenue Fines
351. Legal Procedure to be followed in imposing revenue fines.
- The procedure prescribed by law e.g., the Bengal Landholders Attendance Act (XX of 1848),
Section 1, the Bengal Survey Act (V of 1875), Section 51, the Bihar Tenancy Act (VIII of 1885),
Sections 26-E (3) (d) and 58 (5), the Land Registration Act (VII of 1876), Section 65, the Estates
Partition Act (V of 1897), Section 107, the Cess Act (IX of 1880), Sections 18, 24, 33 and 72-A and
the Bengal Troops Transport Regulation (VI of 1825), Section 2, for the imposition of fines by
Revenue officers must in each case be carefully followed. The report to the Commissioner, where
prescribed by the law, should be made, if possible, on the day on which the fine is imposed.
352. Return to Commissioners (Register 37).
- The report, when one is required, should be in the accompanying form and should specify
distinctly the nature and object of the order and the law under which it was made.Statement of
Statutory Revenue FinesDistrict.............
Name of
estate with
Tauzi No. of
Register B.
No.ThanaName of
ZamindarObject of
order
disobeyedLaw
under
which
order
passedAccount
of daily
fineDate of
order
imposing
fineDate from
which fine
is payableRemarks
1 2 3 4 5 6 7 8 9Bihar Board's Miscellaneous Rules, 1958

         
353. Powers of Collector.
- A Deputy Collector can exercise the powers of a Collector under the Bengal Landholders'
Attendance Act (XX of 1848).
354. Realisation.
- Immediate measures should be adopted for realising the fine, which is payable daily, and must not
be allowed to accumulate. The fines should be realized according to the procedure laid down for the
purpose in the respective enactments.
355. Registers.
- As soon as an order to impose a fine is passed by any competent revenue authority, the necessary
entries in the appropriate case register and also in Register No. 37 (vide Register and Return
Manual) should at once be made, and a certificate that the entries have been made should be given
by the muharrir in charge of the register and filed with the record in the case. The record keeper
should never receive into his department any record in which a fine has been imposed, unless the
papers contain this certificate.
Chapter XX
Escheats
General Rules
356. Government claims.
- (i) All property, whether real or personal, to which there is no legal claimant, belongs to the
State.How, kutcha, tiled or thatched houses are to be treated. - (ii) It has been ruled that kutcha,
tiled or thatched houses are immovable property and such houses left by persons dying intestate are
to be dealt with as immovable property.Real or immovable property
357. Civil Court's Jurisdiction.
- When real property is left without a claimant it does not appear that the intervention of the Civil
Courts is in any way necessary; or can be, by any law, invoked.
358. Duties of the Board and of Collectors.
- By Section 8, Regulation XIX of 1810, the Board is vested with the general superintendence of all
escheats, and is required to inform itself fully through the local agents of any property of thatBihar Board's Miscellaneous Rules, 1958

description, and to direct whether it should, in its opinion, be sold on the public account, or in what
other mode it should be disposed of. The Collector being an ex officio local agent, should report, for
the orders of the Commissioner and the Board, all cases, subject to the exceptions mentioned in
Rule 359, in which he learns the existence of unclaimed real property. He should take immediate
possession of such property on the part of Government, take measures at the same time to invite
claimants to the property as publicity as possible. Should the Collector's action be opposed by any
person actually in possession, he must desist from occupying the property and report the
circumstances, with the opinion, in regard to the propriety of instituting a suit for the establishment
of the right of Government. Notices inviting claimants to the property should remain open for six
months.
359. Occupancy tenures will not be claimed by Government.
- Government has, however, decided not to act upon its right of taking possession as escheats of
mere occupancy tenures (whether transferable or not) of cultivators dying without heirs and in such
cases Collectors should not put forward any claim on behalf of Government, and no report to the
Board need be made.
360. Procedure in cases of tenures worth less than Rs. 500.
- In the case of any tenure of a middle man or cultivator which, though of a permanent character, is
worth less than Rs. 500, according to the valuation of such tenures in the District for the time being,
the Collectors should report all particulars to the Board as hitherto, but should retrain from taking
possession until the orders of the Board are received, as in respect of such tenures, the Government
will not, as a matter of course in every case, act on its right to claim the escheat.
361. Property escheated not to be ordinarily sold for twelve years.
- With reference to the provisions of the law of limitation [Act IX of 1908] [See now Limitation Act,
1963.], the Board will not ordinarily direct the sale of any such property until it has been in full
possession of it for twelve years except in the case of Lakhiraj and rent-free tenures valued at less
than Rs. 500, of which the sale will be sanctioned at the end of six months after the declaration of
escheat.
362. Appropriation to local improvement.
- Small patches of land in the neighbourhood of towns, or such escheats as shops, tanks, and
gardens similarly situate, may, with the special sanction of the Board in each case, be, appropriated
to total improvements.Bihar Board's Miscellaneous Rules, 1958

363. Illegitimate claimants to be liberally dealt with.
- On the occurrence of the escheat or estates which may have belonged to Hindus, Muhammedans,
or others, to whom the Indian Succession Act does not apply, the Government will deal in a liberal
spirit with the claims of persons, who, except for the fact of illegitimacy, would have been entitled to
succeed, or who for any reasons have a moral, though not a legal, claim to consideration. Such cases
will be reported to Government for final orders.
364. Illegitimate European claimants.
- In dealing with the escheated property of illegitimate Europeans who may die intestate in India, it
has been customary for the Government of India to be guided by the principles applicable to the
disposal of similar escheats in England, under which the property, or a portion thereof, is
distributed, as a matter of grace and bounty, to the next-of-kin of the deceased, after deducting the
expenses incurred and a proportion as the Government share according to a certain scale.Personal
or Movable Property
365. Duties of the Magistrate and District Judge.
- The mode of procedure, where personal property is left without a claimant, is described in Section
7, Regulation V of 1799 which requires that such property should be advertised, and if unclaimed
within twelve months, following the date of advertisement, an inventory with a report should be
submitted by the District Judge to the Board. It is not necessary that each case should be reported to
the Board immediately on expiry of the period of twelve months, nor is it desirable that report
should be unduly delayed. It is, therefore, left to the discretion of the Judge to decide at what
intervals the inventory and the report (in Form A given below) should be submitted, subject,
however, to the condition that in no instance should their submission be delayed beyond six months
after the expiry of the twelve months' term. In regard to the personal property, the duty of the
Magistrate is confined to informing the Judge concerning it whenever he becomes aware of its
existence. It follows of course that he should take such measures as lie in his powers to make himself
acquainted with the existence of such property.[Form A] [Bengal Government (Judicial
Department) Circular No. 22-J, dated the 22nd April 1881, to all District Judges (modified in
Bihar).]Inventory of articles under the seal of the Judge of.........the property of persons, who have
died intestate, and to which no claims have been advanced within twelve months following the date
of the publication of the advertisement prescribed by law, submitted to the Secretary to the Board of
Revenue, in accordance with the circular of the Government of Bihar and Orissa in Judicial
Department No. 508 19-J., dated the 26th March, 1915, with the request that the Board may be
moved to authorise the property to be sold, and the proceeds thereof, together with the cash in
hand, to be carried to the credit of Government.DatedDistrict Judge
Name Date of proclamation Property Estimated value Total Remarks
1 2 3 4 5 6
      Bihar Board's Miscellaneous Rules, 1958

District JudgeRules for Reporting, Transmitting and Disposal of Intestate Movable Property
366. Duties of the Police.
(1)In all cases in which intestate movable property is taken possession of by the police, the officer
incharge of the police station in which the occurrence takes place shall submit a report to the
Magistrate of the District or Division of the District within which his station is situated. The report
shall be in Form I at the end of this chapter. All cases of intestate movable property should be
reported by the police in this form, unless a claimant has appeared to claim the property by reason
of such relationship as prima facie constitutes heirship-at-law to the deceased and unless the fact of
such relationship is undoubted. Columns 4 and 5 of Form I should give the names of claimants
whose claims do not seem to the police to be founded on heirship or the fact of whose heirship is
doubtful together with particulars of their claims.(2)Report in Form 1 to be sent to District Court. -
The report in Form 1, when received by the Magistrate of the District or Division of the District,
should be forwarded with a memorandum to the District Court having jurisdiction in the case, and
the orders of the Court should be requested.(3)Property to be dealt with in accordance with District
Judge's order. - On receipt of the Magistrate's report, the District Judge will reply in a separate
communication and the property will be dealt with in accordance with his orders. In practice, there
are only two ways in which the property is dealt with. It is either ordered to be sold on,the spot and
the money remitted to the Court, or the property itself is ordered to be sent to the
Court.(4)Procedure for selling the property on the spot. - When, in the case of property that very
rapidly deteriorates and perishes, the police assume the responsibility of selling it in anticipation of
orders, or when the Court directs that the property shall be sold on the spot, an account of the sale
in Form II hereto annexed, shall be prepared in triplicate by the police. The three copies shall be
sent to the Magistrate of the District or Division of the District who shall send two copies to the
Judge, and the third to the District Treasurer. One of the two copies forwarded to the Judge shall be
returned with his signature to the police station at which it was originally prepared.(5)Procedure
when the property itself is sent to the Court. - When the District Judge directs that the property
itself is to be sent to the Court, a Chalan in Form III shall be prepared in triplicate by the police. As
in Rule 4 above one copy shall be returned by the District Judge with his signature to the police
station at which it was originally prepared.(6)Money and valuables to be remitted to the treasury as
soon as they reach the Court. - All money and valuables sent to the District Judge by the police
should under the existing rules be remitted to the treasury as soon as they reach the Court, and in
the event of the Treasurer not receiving within due time the cash or valuables entered in the form
received by him under Rule 4 or Rule 5 above, he should immediately report the matter to the Judge
by a note at the foot of the daily advice list of payments now sent to Civil Courts.(7)Horses, cattle,
etc. not to be sold without the orders of the District Judge. - Horses, cattle, ponies, sheep and goats
should not be sold by the police without the orders of the District Judge.They should be placed in
the nearest pound and the Judge should pass orders as soon as he receives the report so as to
prevent the possibilities of the cost for keep exceeding the value of the animal. The animal should,
when it is ordered to be sold, be disposed of, if possible, at a public market.(8)Charge for transport
or for keep of live animals. - The cost of keep in cases referred to in Rule 7 above will be deducted
from the sale-proceeds and paid to the pound-keeper, and only the net proceeds will be remitted to
the Judge, as provided in Form II. Similarly, the cost of transport of such intestate movable propertyBihar Board's Miscellaneous Rules, 1958

as is sent up to the District Court should be entered in the chalan forwarding the property (Form
III). This cost should be paid at once from the amount at credit on account of property sold. In cases
in which a claim to the property is afterwards judicially allowed, the successful claimant will
generally be required to satisfy the charge for transport, or for keep of live animals, or for any other
necessary expenses incurred for the safe custody of the property before receiving the property or its
proceeds. The bona fide expenses incurred by a municipality on account of the cost of the burial or
cremation of the corpses of persons dying intestate within municipal limits should also be included
in Form III, and should be paid at once from the estate of the deceased to the Vice Chairman of the
Municipality on his presenting a duly receipted bill for the amount to the Judge.(9)The Rules 1 to 8
above lay down generally the action to be taken in regard to movable property of all persons dying
intestate with no bona fide claimant.
367. Government interest to be watched.
- In cases where personal property under attachment of Civil Court is claimed by persons alleging
themselves to be heirs of deceased intestate persons, the Collector should be represented before the
Judge by the Government Pleader, where the interests of Government require such cases to be
watched.
368. Property of persons dying intestate either in or out of hospital.
- Section 7, Regulation V of 1799 applies without distinction to the movable property of persons
dying intestate, either in or out of hospitals.
369. Indian Succession Act and the Administrator General's Act have
superseded Section 7, Regulation V of 1799, as regards European Citizens of
India.
(1)Indian Succession Act and the Administrator General's Act have superseded Section 7 of
Regulation V of 1799 as regards European Citizens of India. As the law now stands a District Judge
is bound to keep the property of a deceased European citizen of India under Rs. 1,000 in value, until
some person comes forward to claim it. The inconvenience of District Officers can be obviated by
selling the property and remitting the funds to the Judge, who will place them in the Treasury to the
account of the estate. The Judge would be perfectly justified in giving orders for the sale of the
property after some time has elapsed as such a course would be for the benefit and protection of the
estate.(2)The following procedure should be observed for the distribution of escheated estates of
Europeans dying intestate devolving upon the Government:-(1)Grants should not be made to the
persons who would have been entitled but for the illegitimacy as such.(2)Grants should be made to
natural relatives only in so far as they were in fact dependent, or are persons for whom the intestate
might reasonably have been expected to make provision.(3)In ascertaining such persons the blood
relationship alone should not be recognised as sufficient justification for a grant except prima facie
in the case of issue, parent, brothers and sisters.(4)Grants to natural relatives more remote than
these should not be precluded but the applicants should be required to show some ground forBihar Board's Miscellaneous Rules, 1958

reasonable expectation over and above the blood relationship.(5)It should not be regarded as
obligatory to pay or distribute the whole of the residue less Government share. Reasonable
expectations may in many cases fairly be met by lump sum grants less than shares of residue so
ascertained.Form IReport of intestate movable property from............................... station district
...................................dated
1 2 3 4 5 6 7
Annual
No.Date and
place of
deathName and residence
of deceased, if
knownName of
claimant or
claimantsParticulars of
each claimList of
propertyRemarks
 
Memo No.............................datedForwarded to the District Judge of ........... for information and
orders.Signature of MagistrateSignature of Police OfficerForm IIAccount sales of intestate movable
property sold at .................................. station .................District..............................
dated..........................
1 2 3 4 5
Number and year of original report, with
the name of deceased,if knownNumber and
description of
article as per
original reportWeight or
measure
(where
possible)Price at
which
soldRemarks
Less cost of feeding as permemorandum at
foot......No.......Horse....... days at....per
day.......Cow or buffaloGoatTotal...Rs. P.Total......Net
proceeds
forwardedRs. P.  
Signature of Police OfficerSignature of Receiving OfficerDatedForm IIIChalan of intestate movable
property from....................... station.................District.............................
1 2 3 4 5 6
Number and year of
original report, with name
ofdeceased, if knownNumber and description
of article as per
originalreportWeight or
measureDate of
despatchCost of
despatchRemarks
Rs. P.
 
Signature of Police OfficerDatedSignature of Receiving Officer
Chapter XXI
[Rules under the Indian Treasure-Trove Act (VI of 1878)] [Vide
Government Notification No. 1052-111T.4-80 R.R. dated the 10th
October, 1930, on pages 752-756, Part II, of the Bihar and Orissa
Gazette of the 15th October, 1930.]Bihar Board's Miscellaneous Rules, 1958

370. Definitions.
(1)In these rules :-(a)"Committee" means the Committee of the Bihar Coin Cabinet.(b)"Section"
means a Section of the Indian Treasure-Trove Act, 1878.(2)Publication of notification. - Every
notification under Section 5(a) shall be published at the local police station, at the Courts of the
Collector, Sub-divisional Officer, and Munsif within whose jurisdiction the treasure was found, and
also at some conspicuous spot in the village in which it was found.(3)Collector's report. - On receipt
of any notice under Section 4, or on receipt of information from any person other than the finder
that treasure has been found, the Collector shall report the fact direct to the Provincial Government,
the Bihar Coin Cabinet, and the Superintendent, Department of Archaeology, Mid Eastern Circle,
Patna, stating as far as the information at his disposal permits :-(1)the name of the finder;(2)the
nature of the treasure and the number of coins (if any);(3)the approximate value of the treasure
;(4)the date of the finding of the treasure ;(5)the origin, surroundings and exact nature of the find ;
and(6)whether, in the case of treasure consisting of coin, it is recommended-(a)that Government
should acquire the whole of such treasure; or(b)that for any special reasons, such as the largeness of
the quantity found or the coins being known to be of merely metal value, Government should not
acquire the whole of such treasure, but only a portion thereof, or(c)that Government should not
acquire any portion of the treasure.(4)Cost of service of notice. - All notices issued under Section 5
or in pursuance of any rules framed under the Act, shall be served at the cost of
Government.(5)Acquisition of treasure. - The acquisition under Section 16 of the whole or any part
of the treasure by the Collector, whether such treasure consists of coins or not, shall be subject to the
orders of the Provincial Government.(6)Examination of coins and report by the Bihar Coin Cabinet.
- (i) When the Collector recommends under Rule 3 the acquisition of any treasure-trove consisting
of coins he shall forward to the Secretary of the Bihar Coin Cabinet for inspection-(a)if the find is
small, all the coins ;(b)if the find is large, a few specimens of each type of such coins.(ii)The
Committee may, in the case of large finds, request the Collector to forward to it all the coins or such
and so many specimens thereof as they think fit, in addition to those already forwarded by the
Collector, and the Collector shall comply with such request.(iii)The Committee shall cause all coins
forwarded to it under this rule to be examined and shall submit reports in Forms A and B appended
to these rules, to the Provincial Government stating the number and nature of the coins and their
probable numismatic value and shall advise the Provincial Government whether the coins or any
part of them should be acquired.(iv)The committee shall send a copy of every report submitted by it
to the Provincial Government, to the Superintendent, Department of Archaeology, Mid Eastern
Circle, Patna.(7)Examination and acquisition of treasure, not coins. - (1) In the case of
treasure-trove not consisting entirely of coins and on receiving a report under Rule 3, the
Committee shall, if it appears from such report that inspection is desirable, arrange for an
inspection of the treasure either by the Secretary or by some expert selected by it and shall in any
case advise Government without delay as to the desirability of acquiring the treasure under Section
16.(2)If Government decide to acquire such treasure, whether on the report of the Committee or
otherwise, Government shall so inform the Collector who, after making the said declaration and
complying with the provisions of Section 16, shall as soon as possible, forward the treasure so
acquired either to the Bihar Coin Cabinet, Bankipur, or to any other centre which Government may
direct.(3)The Committee shall keep the Superintendent, Department of Archaeology, Mid Eastern
Circle, Patna, informed of the results of the examination and acquisition of treasure.(4)TheBihar Board's Miscellaneous Rules, 1958

Committee may, whenever it appears to be necessary, apply for the assistance or advice of the
Superintendent, Department of Archaeology, Mid Eastern Circle, Patna, in the examination or
disposal of the treasure-trove.Form AReport no........ of........ on........ Coins found at........,
District......... received with Collector's/G.O. no........ dated...........[This form is used for Mughal
Coins only]
Number
and
metal.Name
of
Kind.Mint. Type.Benzal
or Hahi.Hijri. Month.The Patna
Museum,
Patna.The National
Museum of
India, New
Delhi.The Indian
Museum,
Calcutta.
1 2 3 4 5 6 7 8 9 10
          
The
Delhi
Fort
Museum
(in
respect
of coins
of
thePathan
and
Moghal
periods).The
Madras
Museum,
Madras.The
Prince of
Wales
Museum,
Bombay.The State
Museum,
Lucknow.The
Hyderabad
Museum,
Hyderabad.The
Archaeological
Museum,
Gwalior.Ajmer
Museum,
Ajmer.The
Bharat
Kala
Bhavan,
Banaras.The
Nagpur
Museum,
Nagpur.The
Central
Museum,
Jaipur.
11 12 13 14 15 16 17 18 19 20
          
The Mysore
Government
Museum,
Bangalore.The
Government
Museum,
Trivendrum.The State
Museum,
Trichur.The
provincial
Museum,
Gauhati.The
Provincial
Museum,
Cuttack.Watson
Museum,
Rajkot.The Deccan
College
Post-Graduate
ResearchInstitute,
Poona.The
Asutosh
Museum
of Indian
Art,
Calcutta.For
sale
at.
21 22 23 24 25 26 27 28 29
         
Form BReport no.......... of.......... on........... Coins found at.........., District.........., received with
Collector's/G.O. no........ dated.........[This form is used for all classes of coins but the Mughal series]
Number
of
metal.Obverse. Reverse. Reference
and
remarks.The
Patna
Museum,
Patna.The
National
Museum
of India,
New
Delhi.The
Indian
Museum,
Calcutta.The
Delhi
Fort
Museum
(in
respectThe
Madras
Museum,
Madras.The
Prince of
Wales
Museum,
Bombay.The State
Museum,
Lucknow.The
Hyderabad
Museum,
Hyderabad.The
Archaeological
Museum,
Gwalior.Bihar Board's Miscellaneous Rules, 1958

of coins
of
thePathan
and
Mughal
periods).
1 2 3 4 5 6 7 8 9 10 11 12 13
             
The
Ajmer
Museum,
Ajmer.The
Bharat
Kala
Bhawan,
Banaras.The
Nagpur
Museum,
Nagpur.The
Central
Museum,
Jaipur.The Mysore
Government
Museum,
Bangalore.The
Government
Museum,
Trivendrum.The State
Museum,
Trichur.The
Provincial
Museum,
Gauhati.The
Provincial
Museum,
Cuttack.Watson
Museum,
Rajkot.The
Deccan
College
Post
Graduate
ResearchInstitute,
Poona.The
Asutosh
Museum
of Indian
Art,
Calcutta.For
sale
at.
14 15 16 17 18 19 20 21 22 23 24 25 26
             
371. Acquisition of old coins, not treasure-trove.
- All Collectors are empowered to purchase, otherwise than when proceeding under the provisions of
the Act, any coins, whether gold, silver or copper, which appear to be old and not of British mintage,
when they are less than Rs. 10 in value on payment of a sum equal to the value of the materials of
the coins, together with one fifth of such value. A report of the coins so purchased shall be submitted
to Government in the Revenue Department, the coins themselves being forwarded either to the
Bihar Coin Cabinet, Bankipore or to any other centre which Government may direct for distribution
in the manner prescribed in Rule 372 below.In order to obviate the hardship which the law, as it at
present stands, may inflict on individuals when finds of distinct historical or archaeological interest
are acquired under Section 16 of the Act and in order to ensure that museums are not deprived of
valuable relics, special rewards should be made in addition to the amount legally payable under
Section 16. When a find is judged by the Collector to be deserving of a special reward, he should
refer it to the Superintendent, Archaeological Survey, Central Circle, for his opinion. The Provincial
Government will address the Director-General of Archaeology forwarding the opinion of the
Superintendent, Archaeological Survey. The Director-General will, if he considers that there is a
reason for giving a special reward, assess the amount which will be debited to his budget allotment
for the purpose.
372. Distribution of coins.
- One coin or more coins than one of the same variety acquired or purchased by Government shall,
unless Government otherwise direct, be distributed to the following coin cabinets in the following
order after distributing to such cabinets lists of duplicate coins that are available and ascertaining
the requirements of each :-(1)The Patna Museum, Patna.(2)The National Museum of India, New
Delhi.(3)The Indian Museum, Calcutta.(4)The Delhi Fort Museum (in respect of coins of the PathanBihar Board's Miscellaneous Rules, 1958

and Mughal periods).(5)The Madras Museum, Madras.(6)The Prince of Wales Museum,
Bombay.(7)The State Museum, Lucknow.(8)The Hyderabad Museum, Hyderabad.(9)The
Archaeological Museum, Gwalior.(10)Ajmer Museum, Ajmer.(11)The Bharat Kala Bhawan,
Banaras.(12)The Nagpur Museum, Nagpur.(13)The Central Museum, Jaipur.(14)The Mysore
Government Museum, Bangalore.(15)The Government Museum, Trivendrum.(16)The State
Museum, Trichur.(17)The Provincial Museum, Gauhati.(18)The Provincial Museum,
Cuttack.(19)Watson Museum, Rajkot.(20)The Deccan College Post-Graduate Research Institute,
Poona.(21)The Asutosh Museum of Indian Art, Calcutta.
373. Retention of specimen coins by non-official examiner.
- No official who is entrusted with the examination of coins as part of his ordinary duties shall in any
circumstances, retain a specimen of any coins. Non-official examiners, may, however, retain one
specimen only of each variety, provided that specimens remain over after all the Cabinets named
above have been supplied. In such cases a statement shall be furnished to Government by the
examiner or examiners concerned.
374. Proceeds of sales and fines to be credited to Government.
(1)Any surplus coins still left over after distribution in accordance with Rule 372 shall be kept in the
Bihar Coin Cabinet for sale. Notices containing particulars thereof, shall be published annually in
the Gazette and the Gazette of India, copies of the notices being sent to the Asiatic Society, to the
other institutions mentioned and to other registered numismatic societies both in India and abroad.
If any coins so kept for sale remains unsold, Government may at the end of every fifty years, pass
orders for their return to the Mint for melting.(2)All fines levied under the Act and all proceeds from
the sale of coins shall be credited to the head "Treasure-Trove" subordinate to the main head
"Miscellaneous",(3)The Mint will deduct all costs of refining, etc. incurred by it for any surplus coins
that may be received by it for melting and assay and for the issue of an out turn certificate for the
value of the metal contained therein in favour of the Local Government before credit is afforded.
375. Subject to be noticed in the Land Revenue Administration Report.
- All Collectors shall append a paragraph to their Land Revenue Administration Reports stating
whether, during the year under report, any notices have been presented under Section 4 of the
Treasure-Trove Act or any proceedings taken before the Magistrate under Section 20 or Section 21
of it or any action taken under Rule 371. All Commissioners shall, in their own reports, mention the
result of the working of the Act as reported by Collectors.
376. Procedure when the finder does not give notice.
- The information of the finding of treasure is given by a person other than the finder, and the
Collector is satisfied that the information as given is substantially correct, the Collector should, in
addition to issuing the notice required under Section 5, consider whether the prosecution of theBihar Board's Miscellaneous Rules, 1958

finder under Section 20 of the Act is necessary or desirable. Similarly, the Collector should also
consider whether the prosecution of the owner under Section 21 of the Act is necessary or desirable
and take such further action or institute such further proceedings in the matter as may be deemed
necessary.
Chapter XXII
Chaukidari Chakran Lands
377. Settlement of transferred chaukidari land.
- Chaukidari Chakran lands dealt with under Part II of the Bengal Chaukidari Act, VI of 1870, are
not to be considered as separate "estates" within the meaning of the Bengal Land Registration Act
VII of 1876. Under Section 41 of Regulation VIII of 1793, they form part of the estate in which they
are situated. Under Sections 48 and 51 of the Chaukidari Act, they are to be transferred to
the"zamindar" of such estate or tenure, who is defined in Section 1; and it has been ruled (vide
Government Letter No. 3020, J., dated 23rd July, 1894) that they are not to be treated as
amalgamated with such estate or tenure. Under General Clauses Act, the singular includes the
plural, so that the word"zamindar" in Section 48 etseq means all the registered proprietors.
Transferred Chaukidari Chakran lands are the property of the zamindar to whom they are
transferred, but are hypothecated for the payment of the amount due to the "Village Chaukidari
Fund". The settlement of them is offered at half rates to the zamindar in the first instance, because
half the services of the chaukidar were legally supposed to be his. If he does not take settlement,
after having had the opportunity which Section 50 gives him, of contesting the assessment, the
Collector should make absolute the order of transfer in the form given in Schedule C to Act VI of
1870 and, if the assessment is not paid, should deal with the lands under Sections 54 to 56. Even if
such lands are subsequently transferred by sale under Section 55, Bengal Act VI of 1870, this does
not create them an estate within the meaning of that word as used in the Land Registration Act.
Chapter XXIII
Trust Monies
378. Trust fund to be kept in the treasury as a deposit.
- All trust money received by an officer in his official capacity shall, unless a trust fund has been
created, be lodged in the treasury, where it will be credited as a deposit.
379. Intimation of money received.
- The fact that the money has been received, together with the nature of the trust, shall be at once
reported to his official superior and by him to Government, if necessary, through the usual channel.Bihar Board's Miscellaneous Rules, 1958

380. No expenditure to be incurred without sanction.
- No expenditure shall be incurred from such funds except with the sanction of the authority
competent to sanction the payment, if made from general revenue.
381. Work of public utility.
- If the money is to be expended on some work of public utility, the work shall be carried out in the
same manner and with the same sanction as if it were undertaken at Government expense.
382. Sanction must be in accordance with the terms of the trust.
- The officer sanctioning any expenditure from such funds must satisfy himself that it is in
accordance with terms of the trust.
383. Investment of public and charitable funds.
- Government officers are forbidden to invest public and charitable funds otherwise than in
Government securities, or to deposit such funds save in Government Treasury, the Now [Imperial
Bank of India] [State Bank of India.], or one of its branches.
384. Personal responsibility for any misapplication of trust money.
- The above rules must be strictly adhered to; and officers must be held personally responsible for
any misapplication of trust money which may result from its neglect.
Chapter XXIV
Tents
385. General scale.
- The following general scale of tents is fixed for Commissioners of divisions and the officers under
them :-For Commissioners
2. Single-poled regulation tents, 16 feet square
2. Servants' pals, 12 feet square
2. Necessary tentsBihar Board's Miscellaneous Rules, 1958

1. Bechoba tent, 12 feet square
For District Officers
2. Single-poled regulation tents, 15 feet square
2. Servants' pals, 10 feet square
3. Necessary tents
1. Bechoba tent, 10 feet square
Note. - These tents will provide also for the Joint Magistrate (or if there be no Joint Magistrate, for
one Assistant) as well as for the Magistrate and Collector, as it is not expected that the two officers
will ordinarily be out at the same time.Reserve for each district
1. Swiss cottage tent, 12 feet square
1. Servant's pal, 10 feet square
1. Necessary tent
For Sub-divisional Officers
1. Swiss cottage tent, 12 feet square
1. Servants' pal, 10 feet square
1. Necessary tent
386. Extra tents for certain Officers.
- One extra tent is allowed to the Commissioner of Patna and Bhagalpur, to the Deputy
Commissioners of the Santhal Parganas and of all the Districts in the Chota Nagpur Division, and
two extra tents to the Commissioners of Chota Nagpur.
387. Extra tents for Sub-divisional Officers.
- Only one set of tents is to be supplied to Sub-divisional officers. In special cases a sleeping pal or
bechoba tent and occasionally an additional tent can be supplied by District Officers from the
headquarters reserve.Bihar Board's Miscellaneous Rules, 1958

388. Where reserve to be kept.
- The reserve of tents is to be kept at the headquarters of a district, where they will be at the disposal
of the Magistrate-Collector, but it will also be at the discretion of the Commissioner to sanction their
transfer from one district to another, if occasion should arise.
389. To be purchased from Buxar Jail.
- All tents required for official use are to be purchased from the Buxar Jail. Without the special
sanction of Government, no tent required for official use is to be purchased elsewhere.
390. Powers of Commissioners.
- The Commissioners of Divisions have full discretion in respect of the size and the number of the
tents to be purchased by any officer provided that the total divisional allotments placed at their
disposal for the purchase of tents are not exceeded.
391. Allotments to be treated separately.
- The allotment made by Government for the purchase of tents is to be treated separately from the
rest of the grants for contract contingencies, a saving being carried forward from year to year during
the contract period and made available for expenditure on that account only.
392. To last eight years.
- A tent remains serviceable with periodical repairs for at least eight years.
393. Record to be kept.
- A record should be kept of the dates on which any tents are purchased and annual report of the
disbursements should be submitted by the Commissioners of Divisions through the
Accountant-General, to the Board of Revenue within three months after the close of the year in
which they are made. The Board will submit to Government an abstract of the report, division by
division, by the 1st of September every year.
394. Sale proceeds to be credited to Government.
- The sale proceeds of old tents are to be credited to Government.
395. Care to be taken.
- All tents are to be carefully preserved and frequently examined and aired when not in use.Bihar Board's Miscellaneous Rules, 1958

396. Carriage of tents at Government expense.
- An officer in camp is entitled to charge to Government the cost of carrying one office tent for
himself, one tent for his establishment while engaged in official work, one tent for chaprasis and one
for his police guard in cases where he is entitled to a guard. When Government tents are used only
for office purposes by an officer on tour, they are carried at Government expense. When
Government tents are used partly for office and partly for private purposes, the officer so using them
must pay half the cost of carriage. When Government tents are used wholly for private purposes, the
officer so using them must pay the whole cost of their carriage. The travelling allowance paid by
Government to civil officers is intended to cover expenses of this character.
Chapter XXV
Troops
Preliminary
397. Landholders etc. liable to provide supplies for troops.
- Under Section 3, Regulation XI of 1806 any landholder, farmer, tahsildar or other person in the
possession or management of land may be required by a Collector or any officer acting in that
capacity to provide supplies for a body of troops about to proceed by land or water through any part
of India or to make preparations by the provision of boats, the construction of temporary bridges, or
otherwise, for enabling the troops, to cross rivers or nala intersecting their march. Should such
person, after receipt of such requisition wilfully disobey or neglect to carry out orders or without
sufficient cause fail to exert himself for the duty assigned, the Collector may having regard to the
provisions of Section 2 of Regulation VI of 1825, impose a fine which shall not in any case exceed the
sum of one thousand rupees. Patindars or other under-tenants are, under these Regulations,
included in the obligation to furnish supplies, but this does not imply that the existence of any kind
of tenure in an estate exempts the actual landholder from the obligation. Holders of revenue free
estates are also liable to furnish supplies when called upon to do so.Note. - The obligation under
Section 3 of Regulation XI of 1806 to provide supplies does not extend to carriage.Encamping
Grounds
398. Civil authorities responsible for maintenance of established encamping
grounds outside cantonment.
- District Officers are responsible for the maintenance in good order of all established encamping
grounds, outside cantonments within their jurisdiction. These encamping grounds, when not
occupied, should be kept clear and free from jungle growth and generally in order, as they are
intended for the use of private travellers as well as troops, the expense of demarcating them is a
charge upon the Civil Department, which is also responsible for seeing that the boundary pillars are
kept in repair.At the commencement of the marching season, it is the duty of each District orBihar Board's Miscellaneous Rules, 1958

Sub-divisional Officer, to see that every encamping ground within his jurisdiction is made clear and
fit for the encamping of troops. Whenever movements are ordered, the Brigade Commander will
intimate to the Civil Officers concerned the routes which will be used, in order that the wells, etc.
may be thoroughly cleaned beforehand.On receipt of this notice a ministerial officer should be
specially deputed to see that the grounds and wells, and also incinerators where provided, are in
proper condition. Any petty expenditure incurred on this account should be charged in a contingent
bill.In addition to entry in Register No. 6 as prescribed in Rule 255, all established camping grounds
are to be entered in the appendix to that Register specially prescribed for camping grounds, the form
of which will be found in the Register and Return Manual after that of Register 6.The rules in this
chapter issued by the Board, are based on "Army Regulations' India" Volume X (1912), pages 106 to
112 and Appendix VIII, pages 139-140 and on Government of India, Army Department Circular No.
14977-2 (Q.M.G. - 1), dated 1st November, 1916. [Board's File No. 14-33 of 1917],All such camping
grounds are to be inspected once a year by the Sub-divisional Officer. The District Officer should
also endeavour to visit such camping grounds as are situated in the neighbourhood of his tours.The
charges to be incurred on maintaining camping grounds under the control of the Military authorities
and keeping the grounds clear of jungle should not be debited to the Provincial budget estimates.
Applications for the provisions of funds for the purpose should be made to the Commanding Officer,
Royal Engineers, Presidency and Assam District, Calcutta through the Political Department of
Government. The estimates may be prepared by the District Officer after consultation with the
Executive Engineer.General Arrangement before a March
399. District or Brigade Commander to communicate to District Officers an
itinerary of the march.
- On receipt of final movement orders, the district or Brigade Commander, in whose area the
movement originates, will communicate to each District Officer on the line of march an itinerary of
the march through his jurisdiction, the strength of the party, and the probable date of arrival at
ferries or other points where special assistance is required from the civil authorities. The District
Officer will make such arrangements as he considers necessary to assist the troops and detail an
official to accompany them and carry out the wishes of the District or Brigade Commander.
400. Duties of District Officer.
- Whenever a District Officer receives from the Officer in Command intimation of the approach of
troops, he must acknowledge it at once and communicate to the Officer in Command any
information that he thinks is likely to facilitate the progress of the detachment or promote the
comfort of the troops. He will take steps to prevent the irregular sale of liquor or fruits to the troops
on or near the route, and to exclude from the camp or its vicinity all women of loose character. He
will also arrange for the deputation of police officer, or other official, who will report himself to the
Officer in Command the day before the troops enter the limits of the district and remain with them
until they leave it.Bihar Board's Miscellaneous Rules, 1958

401. Duties of police officer or other official attached to troops.
- The police officer or other official will be provided with written instructions by the District Officer
defining his duties and powers, which he will show to the officer commanding the troops. It will be
his duty to give all the assistance in his power to the Officer Commanding the troops, to settle, in
communication with that officer, all disputes between the soldiers and the inhabitants or with any
transport establishments engaged by the civil authorities, or to report cases beyond his powers to his
superiors; to arrange that, in addition to the usual military precautions, proper measures are taken
to prevent theft and the irregular sale of liquor; and to act generally as the medium of
communication between the Officer Commanding and the subordinate civil officials and
inhabitants. The Officer Commanding will not interfere with or exercise any authority over the
officer deputed in the performance of his duties, but will report any neglect or intention on his part
to the District Officer concerned. He is responsible for damage to Government or private property
whether by troops, followers or hired transport personnel and for the investigation and disposal of
complaints by inhabitants before the camping ground is vacated by the troops.
402. Formal reception of troops on special occasions.
- When a regiment is on the march through routes infrequently used, or when the special object of
the march is to impress the people with the strength and importance of the Military arm of
Government, the following arrangements should be made to receive the regiment with due
honour-(1)Unless prevented by a urgent business in another part of the district, the District Officer
should make a point of being present at his headquarters to receive the regiment.(2)The higher
officer of the several departments serving in the district, or present on tour in it, should be informed
of the coming of the regiment so that they may have an opportunity of participating in its
reception.(3)The Chairman and Commissioners of the local municipality should be invited to meet
the regiment at the entrance of the town.(4)The educational authorities should be informed that it is
desirable that the children in school on the line of march should be afforded an opportunity of
seeing the troops march by.Supply of Carriage
403. Officers of the Indian Army Service Corps responsible for supply of
carriage.
- As a rule the officers of the Indian Army Service Corps supply all carriage needed by troops on the
march, making their own arrangements, if possible, but applying to the civil authorities for such
assistance as they need. When the aid of the civil authorities is required, the following rules will be
observed.
404. Requisitions for carriage to be in writing.
- Requisitions on the civil authorities for hired carriage required for the movements of troops or
stores will be prepared in writing in quadruplicate L.A.F.S. 1675 form to be seen at the end of this
Chapter, giving full details of requirements, and be sent so as to reach the District Officer concerned,Bihar Board's Miscellaneous Rules, 1958

if possible, not less than 15 days before the carriage is required. District Officers are forbidden to
supply carriage on verbal orders, but in cases of emergency, when the applicant has not the means at
hand for preparing requisitions, they will furnish printed forms which will be kept in stock in
communication with the General Officer Commanding, Presidency and Assam District, Fort
William, Calcutta and the necessary writing materials.
405. Requisition to state distinctly whether charges are to be paid by the
State or by troops.
- The requisition for the carriage required for that portion of the men's baggage for the conveyance
of which Government are responsible must invariably be distinct from the requisition for the
carriage required for the rest of the men's baggage and for that of the officers. Each requisition must
state distinctly whether the charges for the carriage demanded will be paid by the State or by the
troops themselves, so that there may be no question as to the quarter from which payment is to be
claimed.
406. Employment of chowdris or contractors for the supply of carriage.
- The District Officer will, whenever possible and conveniently make arrangements for the supply of
carriage with chowdris or, contractors who will be held responsible for its proper quality and for the
good conducts of those incharge of it.The chowdris etc., should not be allowed to use badges or other
signs of office, or to seize carriage; they should, as far as possible, be the representative men of the
classes who nominate them and interference in their nomination or deposition should be avoided as
much as possible. When the services of such men are required continuously they may be paid a
regular salary; otherwise and ordinarily they should be paid by a commission, which should be
generally at the rate of one [anna in the rupee] [Now Paise.]. These fees will be paid by the Army
Department.
407. Procedure when contractor is not available.
- If no suitable contractor is available, the District Officer will arrange for the supply of carriage
through the police or the Collectorate Nazir, or in such other way as may be convenient. Under the
latter part of Section 3 of Regulation XI of 1806 the officer deputed to accompany the troops may
always apply to the nearest police officer for assistance in procuring carriage.
408. Procedure for payment of hired carriage.
- Hired carriage will not ordinarily be required to proceed beyond the limits of the next civil district
on the route. Except in cases of emergency, such as the breaking down of carriage, the death of
cattle, etc., carriage is not to be exchanged save at such stations as may be fixed by District Officer,
but this does not preclude the discharge of cattle at any intermediate point with the consent of the
owner.The hired carriage will be paid for at the authorised local rates from the date on which it is
engaged for the march to the date of its discharge, both inclusive. Half hire will be paid for returnBihar Board's Miscellaneous Rules, 1958

journey from the exchanging station to the place where the carriage was engaged. If the carriage is
taken beyond the exchanging station, full hire will be paid for return journey from the place where
carriage is released to the place where it was engaged without any allowance for halts. If the carriage
has to be collected before the date on which it is required, the civil authorities will inform the
indenting officer of the time required for collection before the start, and the probable extra expenses
that will be incurred. Carriage, which ordinarily plies for hire and is on the list to be kept by the
District officer will first be called upon and the balance will be made up by impressment. Carriage
indented for in excess of requirements, and discharged, will be paid for at the full hire rates for each
day or part of a day for which it is retained. If carriage is declared unserviceable through deliberate
fault or culpable negligence of the cartman by a committee of officers (which will include the civil
officer), it will not be paid for. When cart carriage can only be procured with difficulty, it will be
supplied for that portion of the baggage, which the indenting officer certifies as being unsuited for
pack transport, the balance being made up by the equivalent in such pack animals or such other
kind of transport as may be available.
409. Indenting officer to be warned that full hire is to be paid.
- The Indenting officer should be warned to the effect that full hire is to be paid from the date on
which the carriage is engaged by the Collector to the date on which it is discharged, and that no
reductions are allowed in cases of halts or on account of demurrage rates.
410. Procedure when carriage is engaged.
- On engagement of the carriage, the civil officer will advance to the owners half the estimated hire
for the full journey, and obtain a receipt for the same. To enable the civil officials to make these
advances, the indenting officer, when submitting his requisition for carriage, will remit to the civil
officers concerned a sum sufficient to cover the amount which the latter will be required to advance.
A receipt will be obtained for this advance which will be subject to adjustment.
411. Advance and handing over of carriage.
- The carriage will be sent to the place required in charge of a civil official who will hand over to the
indenting officer a detail of the composition of the carriage, authorised loads, owner's name, amount
advanced and the receipt for the same, and intimation as to the station at which the carriage should
be exchanged (See Indian Army Form S-1675). The advance remitted to the civil official will then be
adjusted at once.
412. Arrangement for the relief of transport.
- The civil officer, supplying carriage will, at the same time, warn the civil officer at the first
exchanging station of the transport requiring exchange, and the date and place at which it will be
required. A copy of this should be furnished to the indenting officer to enable an advance to be
remitted. The civil officer at the first exchanging station will then proceed as in Rule 410 and warnBihar Board's Miscellaneous Rules, 1958

the next exchanging station. Similar action will be taken at each exchanging station on the route.
413. Procedure when any change is required enroute.
- Should any change be required en route in the original quantity and description of transport
supplied the Officer Commanding the troops must give the District Officer at the exchanging station
concerned as early notice as possible.
414. Treatment of animals and parties in charge.
- The Officer Commanding will be responsible that animals are not overladen nor ill treated; that the
cartman and parties in charge are properly treated and that on arrival at destination at an
exchanging station, all carriage is released as early as possible. Animals must always by unloaded
when crossing rivers in boats. In cases of baggage animals dying as the result of injuries inflicted by
soldiers or regimental followers, Government will not bear the cost of compensation to the owners.
In such cases the owners should make their claims to the Officer Commanding. District Officers are
responsible to Government that the carriage rules are fairly adhered to and, if they fail in inducing
adherence to them, they should at once report the matter for the orders of superior authority.
415. Procedure when carriage breaks down between exchanging stations.
- Carriage breaking down between exchanging stations should be replaced on the spot and paid off.
If the advance received has not been liquidated, the owners must refund the amount then due.
416. Payment of carriage on arrival at destination or at exchanging station.
- On arrival at an exchanging station or at destination, the carriage will be released at once and paid
off by the Indian Army Service Corps, if there is one, otherwise, by an officer of the marching unit in
the presence of the Civil Officer attached to the troops, the acquittance roll being signed by both in
token that every cartman and cooly has been paid up in full. The acquittance roll will then be
countersigned by the Officer Commanding. Any dispute will be referred to, and settled by the police
or other officer deputed to attend the troops by the District Officer having jurisdiction at the place,
at which the transport is released.
417. Carriage ordinarily not to be detained at camps lasting for five days, full
hire to be paid, if detained.
- If carts are brought from a distance and detained at camp of exercise, etc., the full rate of hire will
be paid for each day of such detention. Carriage should not, however, be detained at a camp which
lasts for five days or over except in very special circumstances.Bihar Board's Miscellaneous Rules, 1958

418. Certificate to be given when carriage is discharged.
- When carriage is discharged a certificate in English and the Vernacular should be given by the civil
officer at the exchanging station, or by the police officer or other official accompanying the troops, to
each person in charge thereof, to protect the carriage from being taken for the use of troops while on
its return journey, unless such troops are marching in the direction of the own home. If so
employed, the full hire rate will be paid.Supply of Provisions
419. Indian Army Service corps to make rationing arrangement.
- Rationing arrangements for all troops and animals are made by the Indian Army Service Corps
under the orders of the General Officer Commanding concerned. A suitable detachment of supply
personnel will be in supply charge of the units whilst on the march. The civil authorities may be
called upon to provide supplies of the kind mentioned in Indian Army Form S-1526 given at the end
of this Chapter and such articles are not ordinarily kept in stock (e.g. sheep, fowls and eggs) or
which are rapidly perishable (e.g. milk), other ration articles will not be demanded from the civil
authorities.When the assistance of the civil authorities is necessary, and in the case of pre-arranged
marches, i.e. when marches are not due to a sudden emergency, the General Officer Commanding
concerned will detail an advance party consisting of personnel of the supply service, or of the unit
marching to go ahead of the troops and associate themselves with the civil official in the purchase of
supplies.The civil authorities should be informed that an advance party is being sent to assist in the
necessary purchases.
420. Requisitions to civil authorities and change of date or requirements.
- All indents on the civil authorities, for the class and quantity, of articles which they are required to
supply, should be preferred on them a fortnight before they are actually required. Any changes in
dates, routes or quantities of supplies must be communicated at once to all concerned. Losses due to
these circumstances will only be borne by the State when the competent financial authority is
satisfied that they were unavoidable due to circumstances beyond the control of the responsible
authority or unit. Losses due to excessive estimates will be borne by the unit responsible.
421. Procedure for meeting the cost of supplies requisitioned.
- To enable the civil officials to purchase supplies, the military authorities, when submitting their
indents for supplies will arrange to pay in advance to the responsible civil authorities a sum to cover
the cost of the supplies requisitioned. This advance will be obtained from the Controller of Military
Accounts concerned. If time does not permit of an advance being obtained from the Controller of
Military Accounts, it should be obtained from the civil treasury on the authority of a station orders
as provided for in Paragraph 16(viii) of Pay and Allowance Regulations, Part II.Bihar Board's Miscellaneous Rules, 1958

422. Acceptance or rejection of supplies.
- The advance party is responsible for the actual acceptance of supplies, the passing in of which
should be done in the presence of the civil official. The military authorities will then be responsible
for the payment of the demand made by the civil official for the above accepted supplies. Rejections
should only be made when the articles tendered are unfit for consumption owing to their being
below the standard usually consumed by the persons or animals for whom they are intended.
Supplies which have been accepted by the advance party will not be subject to further passing in the
decision of the Officer Commanding the advance party being final. If the supplies become unfit for
consumption owing to the late arrival of the unit or to causes outside the control of the supplier, a
receipt for the supplies must be granted by the officer commanding the troops to the civil official
concerned.
423. Grant of receipt of supplies.
- The military officer who takes over supplies from the civil official will furnish the latter with a
receipt for the supplies actually received and will send a duplicate of this receipt to the military
authority responsible for the submission of the original indent.When supplies of a quality inferior to
that which might reasonably have been expected are provided, a report to this effect will be made by
the officer commanding the troops to the District Civil Officer.
424. Supply of perishable articles and those not ordinarily kept in stock.
- If shops are, or can be, established on or near the camping grounds, articles such as sheep, fowls,
eggs, milk, etc., will be retailed by the shopkeepers; if shops neither exist nor can be arranged for,
these articles will be supplied in the usual way and arrangements made for their retail issue and the
subsequent disposal of any surplus.
425. Individuals and small parties to purchase from bazars.
- Individuals or small parties will ordinarily purchase their own supplies from bazars, applying to
the local police officer for any assistance required.
426. Rejection of supplies arranged in emergent cases.
- In the case of marches due to sudden emergencies, when sufficient notice of the arrival of a unit in
a district cannot be given, or an advance party sent ahead of the troops and the supplies have
consequently to be arranged by the civil authorities in a hurry, the Indian Army Service Corps
Officer or, in his absence, the Officer Commanding the troops should bear in mind the following
factors before rejecting supplies arranged for by the civil authority :-(a)The notice given and the
circumstances in which the supplies were purchased.(b)The quality which might reasonably be
expected in the district traversed.(c)Whether the supplies are fit for consumption though below the
unusual standard.If it is necessary to reject supplies on account of unfitness for consumption, theBihar Board's Miscellaneous Rules, 1958

Officer Commanding the troops will furnish the civil official concerned with a statement showing the
nature and quantity of supplies so rejected and will furnish a duplicate copy of this statement to the
military originally responsible for making the demand, who will arrange with the Controller of
Military Accounts concerned to obtain a refund from the civil authorities in respect of such supplies.
427. Officer Commanding responsible to see that no article is taken without
payment and no dasturi is exacted.
- The Officer Commanding will be responsible that whenever any article is taken without payment or
when dasturi is exacted, the responsible person is severely dealt with. He will cause the officer of the
day to visit the bazar frequently to see that the guard or military police, which should be posted
thereon, are doing their duty and that no irregularities are permitted. The Officer Commanding will
ensure that he is readily accessible to any civil official or inhabitant who may be desirous of lodging
a complaint. To ensure prompt adjustment of demands, the civil officer in attendance will have all
the accounts ready for adjustment by 4 O' clock in the afternoon of each day and report to the
Officer Commanding each evening whether any claims remain unsettled, and, if so, the latter will
personally see to their immediate settlement. The civil officer should endorse all receipts given for
payments made, and the Officer Commanding should not accept receipts unless so endorsed.
428. Acknowledgement of full settlement and procedure for settlement of
unadjusted demands.
- When all demands have been satisfied the civil officer in attendance must give an
acknowledgement to the Commanding Officer that all the demands of the day have been settled,
when from any particular circumstances the demands have not been adjusted, a statement to the
effect, specifying the amount and the nature of the demand, must be obtained from the
Commanding Officer, on which is to be distinctly stated the proper officer to whom the document
should be forwarded for adjustment.Discipline
429. Discipline among troops.
- Notwithstanding the presence of a police officer, the Officer Commanding the troops is responsible
to see that the strictest discipline is maintained among his men to protect the people from exaction
and outrage, and that all possible military precautions are taken to prevent damage to trees, crops
telegraph wires and posts, trespass in Government forest or private enclosure, or irregularities of
any kind.
430. Arrangements and payment for local labour.
- Any assistance required from the local population should ordinarily be obtained through the
medium of the police officer and paid for at local rates.Bihar Board's Miscellaneous Rules, 1958

431. Procedure when irregularities are discovered after the troops have
marched.
- If irregularities committed by the troops are not discovered until they have proceeded outside the
limits of the District, the District Officer will send a full report of the occurrence to the General
Officer Commanding the Brigade area in which it occurred, who will investigate the matter and take
all necessary action for its disposal
432. Breach of discipline by hired transport establishments.
- Hired transport establishments not being amenable to military discipline any serious
misbehaviour on their part must be dealt with in communication with the District Officer of the first
station reached.The District Officer will afford every legal redress in his power.Miscellaneous
433. Soldiers using dak bungalows to pay usual fees.
- All soldiers using dak bungalows or serais must pay the usual fees.
434. Exemption from payment of tolls.
- Under the Indian Tolls (Army) Act II of 1901, which applies to the whole of India-(a)all officers and
soldiers of Government Regular Forces and local corps, or Government Service Troops ; when on
duty or on the march,(b)all members of corps of volunteers when on duty, or when proceeding to or
returning from duty,(c)all officers and soldiers of Indian Reserve Forces when proceeding from their
place of residence on being called out for training or service, or when proceeding back to their place
of residence after such training or service,(d)all grass-cutters when employed in the service of
Government Regular Forces, any local corps, Government Service Troops, or any corps of
volunteers,(e)all other authorized followers of Government Regular Forces, any local corps,
Government Service Troops, or any corps of volunteers, when they accompany any body of such
forces, troops or volunteers, or any members of such corps on the march, or when they are otherwise
moving under the orders of military authority,(f)all members of the families of officers, soldiers, or
authorised followers of Government Forces, or any local corps, when accompanying any body of
troops, or any officer, soldier, or authorised follower thereof, on duty or on the march,(g)all
prisoners under military escort,(h)the horses and baggage, and the persons (if any) employed in
carrying the baggage of, any persons exempted under the foregoing clauses, when such horses,
baggage, or persons accompany the persons so exempted in the circumstances mentioned in those
clauses, respectively,(i)all carriages and horses belonging to Government, or employed in
Government military service, and all persons incharge of or accompanying the same, when
conveying any of the persons above-mentioned, or when conveying baggage or stores or when
returning unladen from conveying such persons, baggage or stores,(j)all carriages and horses, when
moving under the orders of military authority for the purpose of being employed in Government
military service,(k)all animals, accompanying any body of troops, which are intended to be
slaughtered for food or kept for any purpose connected with the provisioning of such troops,Bihar Board's Miscellaneous Rules, 1958

and(l)all persons in charge of any carriage, horse or animal exempted under any of the foregoing
clauses, respectively,are exempted from the payment of any tolls, on embarking or disembarking or
on being shipped or landed from or upon any landing place, or in passing along or over any
turnpikes or other road or bridge, or on being carried by means of any ferry, other than a railway
ferry. But boats, barges, or other vessels employed in conveying the above persons or property along
any canal will pay the usual tolls.
435. Vessels when exempted from payment of tolls.
- Any vessel employed by the Government solely for the transport of troops, or the horses, baggage
or other effects of any troops embarking or disembarking at any port, or carriages, belonging to
Government, or employed in Government military service embarking or disembarking at any port,
are also exempt from tolls levied by any local authority.
436. When toll authorities should not realise tolls.
- Officers not in uniform need only furnish the toll keeper in writing with their names, rank and
nature of the duty on which they are travelling, but in all other cases unless the individual is in
uniform, or followers, horses, baggages, carriages and slaughter animals are accompanying
individuals in uniform, exemption from tolls will only be admitted on the presentation of a pass.
(I.A.F.Z. 2114) to the toll authorities.Note. - "Horses" includes mules and beasts of any description
used for burden, draught, or the conveyance of individuals.
Form No.| IAFS-1675Gratis
(Rule 404)Requisition on the Civil Authorities for hired
carriageTo....The.......................................Please supply the undermentioned hired carriage-
Quantity and description of carriage
requiredAlternative carriage which will be accepted if that indentedfor
is not available
  
which should be delivered at........................(Place and station) by................................(hour) on .........
(date) to the........................with a view to its proceeding with the.........................................(Corps,
etc.) which is marching from.......................................on..................(date) en route for
2. [The above..............(Corps, etc.) will be at the following stations (here enter
main, civil or exchanging stations, if known, in each civil district which will
be passed through en route and dates).] [In the case of a long series of
marches, an itinerary of the movement can be attached instead.]
Station.............Date .................... 20.....(Rank and appointmentof Indenting Officer).II. Supplying
OfficerToThe...........................Herewith a detail of the transport supplied :-
Quantity and Authorised Authorised hire rates Owners' Amounts SignatureBihar Board's Miscellaneous Rules, 1958

description loads and date from which
duenames advanced to
ownersor seal of
owners to
advance
1 2 3 4 5 6
      
[I. The above carriage should be exchanged at ...........................on........................and the.........has
been requested to arrange accordingly.] [Score through I or II according to whether used for
indenting or exchange officer.]
2. Please remit to me the amount advanced.
[II. Forwarded to the...........with the request that arrangements may be made for the relief of the
above carriage at on the...............] [Score through I or II according to whether used for indenting or
exchange officer.]Place.........Signature of Civil Officer(District Officer)Date............. 20III. First
Exchanging StationThe carriage referred to in II was exchanged at.............................. on
............................................... for the following transport....
2. The above will require exchange at on............................................................
Place.........................Date..........................20..........................................Signature of First Exchanging
Officer.ToThe........................................................(Second Exchanging Officer)IV. Second Exchanging
StationThe carriage referred to in III was exchanged
at......................................................on..................................for the following transport
...................................................................
2. The above will require exchange
at.....................................on..........................................................................
Place.....................Date.....................20.....................................Signature of Second Exchanging
OfficerToThe.........................................................(Third Exchanging Officer)
FirstSecond| Exchanging Station
ToThe O.C.Herewith a detail of the exchange transport supplied :
Quantity and
descriptionAuthorised
loadsAuthorised hire rates
and date from which
dueOwners'
namesAmounts
advanced to
ownersSignature
or seal of
owners to
advance
1 2 3 4 5 6
      
The above carriage should be exchanged at..............on.......and the... ... ... has been requested to
arrange accordingly.Bihar Board's Miscellaneous Rules, 1958

2. Please cause the amount advanced to be remitted to me.
PlaceDate 20
Signature of| firstsecond| Exchanging Officer.
Instructions For Filling Up the Form of RequisitionsI.A.F.S. - 1675
1. This indent will be submitted in quadruplicate, with page 1 of the form
completed by the original indenting officer, to the District or Political Officer
concerned. This letter will complete page 2 in all the copies, retain one copy
for his own use, return two copies with the carriage-one for the Officer
Commanding troops and one for the local Supply and Transport Officer-and
send one copy to the Civil Officer at the first exchanging station.
2. The Civil Officer at the first exchanging station will complete page 5,
remove it and send it with the transport to the Officer Commanding the
troops and then pass on the form endorsed on page 3 to the Civil Officer at
the second exchanging station who will then take similar action as regards
pages 6 and 3.
3. If there are more than two exchanging stations on the route, the original
indenting officer will attach as many spare sheets of pages 3 to 6 as are likely
to be required. The object of the form is to admit of the details given on page
1, being passed along the route and not rewritten for each exchanging
station.
4. Should any change be required en route in the original quantity and
description of transport supplied, or in the details of the movement given on
page I, the officer commanding the troops must give the civil officer at the
exchanging station concerned as much notice as possible, and the latter will
correct the form accordingly before passing it on to the next Civil Officer
concerned.
Form No.| I.A.F.S.-1526Gratis
(Rules 419 and 420)Requisition on the......... for supplies required at.............20......, for the men and
animals of the......... en route from...........to..........Dated at...........20...
ArticlesQuantity
requiredArticlesQuantity
required
Public PrivateBihar Board's Miscellaneous Rules, 1958

For Officers and other  Straw   
Eggs  Tent pegs   
Fowls  Turmeric   
Milk  For Public and Private
animals  
Kids  Atta for elephants   
Sheep  Barley   
For British troops  Bajara   
Baskets  Bhusawhite   
Charcoal  Bhusamissa   
Cotton for wicks  Bran   
Flour, wheat, 1st sort  Kurthi   
Firewood  Dhan   
Ghurras, earthen  Fodder green   
Hemp  Fodder dry   
Oil*  Gowar   
Onions  Gram, 1st sort   
Potatoes  Grass, green   
Rice*  Grassdry for rations   
Salt  Grasshorses bedding   
Straw or grass for bedding,  Indian corn   
Tent-pegs  Jowar,   
Tinning cooking utensils.  Kurbi, dry   
Vegetable, fresh  Kurbigreen   
For Native Troops and Public
Followers Lobea   
Atta  Mot   
Dal*  Mat   
Firewood  Oats   
Ghee  Oil   
Ghurras, earthen  Salt   
Salt*  Sugarcane   
Forwarded to the.................Supply and
TransportOfficer,for favour of
compliance.Comdg.....................
(where necessary)
*Description to be specified.InstructionsBihar Board's Miscellaneous Rules, 1958

1. In the case of British troops, or of native troops marching with
Government animals, the public supplies required will be filled in by the
Supply and Transport Officer or subordinate concerned, whenever
necessary, on the application of the Officer Commanding, who will then enter
the other supplies required and send the complete requisition to the District
or Civil or other officer concerned whom it should ordinarily reach a fortnight
beforehand.
2. Only actual requirements are to be requisitioned for as the State will not
bear any loss on account of other than public supplies that may be caused
by overestimating. The articles enumerated can alone be demanded; any
others required must be arranged for by the Supply and Transport Corps to
the Officer Commanding. The articles demanded for animals should accord
with those admissible under the local forage scales and only articles locally
procurable should be requisitioned.
Chapter XXVI
Miscellaneous
437. Contracts and agreements by the Central and State Governments.
- Rules for the grant of contracts and agreements by State Government are contained on pages 6-9,
Volume I of the General Statutory Rules and Orders, 1915.A list of the officers empowered to execute
deeds, contract and other instruments on behalf of the President of India is given in the Government
of India, Ministry of Law, Notification No. SRG 215, dated the 9th February, 1952. Under Article 299
of the Constitution of India all contracts made in the exercise of the executive authority of the State
shall be expressed to be made by the Governor of Bihar and all such contracts and all assurances of
property shall be made on behalf of the Governor by officers mentioned in the Notification No.
1827-J., dated the 14th April, 1951 of the Law Department of the Government of Bihar.
438.
Rules regulating the method of recruitment of the Bihar Civil Service (Executive Branch) and the
Junior Civil Service are contained in Appendix W.
439. Compulsory retirement of officers.
- The Provincial Government reserve to themselves the power to remove from the service any officer
proved to be unfit for further advancement. Officers of the Executive Branch are recruited mainly in
order to fill what are known as inferior charges at headquarters of districts and in sub-divisions, andBihar Board's Miscellaneous Rules, 1958

an officer who after a reasonable number of years is found not to be fit to perform the duties
ordinarily expected from a Deputy Collector ought not to be retained in the service. Promotion in
the time-scale above the first efficiency bar at the end of twelve years' service will be regulated by
this test, and an officer who is permanently kept behind that bar will be considered unfit for further
advancement and therefore, liable to removal. It does not follow, however, that once an officer has
been allowed to pass the bar he should no longer be liable to removal, and Government reserve to
themselves the right to remove any officer whom they consider unfit for the duties naturally falling
to an officer of his seniority and standing.
440. Removal of officers from service.
- No steps will however, be taken to remove an officer from service until he has been given an
opportunity by warning and censure to effect an improvement, and the essential condition of
security of tenure will be sufficiently guaranteed by providing that no officer shall be retired until he
has had full notice of the grounds on which inefficiency is alleged against him and of being heard in
his defence.The State Government will be prepared to consider proposals for the grant to all officers
compulsorily retired of a pension which would ordinarily be adjusted in accordance with the scale of
invalid pensions admissible to members of the service who are forced to retire prematurely on
account of ill health. The pension to be granted, however, on retirement on these grounds will not be
defined by any precise account rules, and the local Government will reserve to themselves in any
given instance the right to determine its account on a full consideration of the merits of the
particular case.
441. Unauthorised funds not to be created.
- The creation of unauthorised funds by fines and deductions of pay or in any other way is strictly
forbidden.
442. Government Officers to pay tolls.
- All officers of Government, when proceeding on the public service, should, under all
circumstances, pay on demand the amount of all tolls (whether road or ferry) other than canal tolls,
for which next succeeding rule provides, which may be demanded of them, the sums thus paid being
subsequently recovered by being charged in their contingent bills. Only police officers proceeding on
duty, who might be detained inconveniently by not having money with them, should be permitted to
pass without paying at all.
443. Vessels exempted from payment of toll or demurrage.
- All vessels which are being used exclusively by revenue officers travelling on duty are exempted
from the payment of toll or demurrage on canals or canalized rivers.Bihar Board's Miscellaneous Rules, 1958

444. Passes to maintain accurate statistics of traffic.
- In order to maintain accurate statistics of traffic, passes must in all cases be given which in the case
of vessels used by officers must specify the nature of the vessel and the name of the occupant.
445. Fractions of an [anna] [Now new paise.] to be avoided.
- In all settlements, revisions of settlements, grants of compensation, takavi advances, balances of
all kinds and in every species of accounts, charge, or receipt, the use of pies, the fractional parts of
an anna, should be avoided. If the fraction is below six pies, it should be omitted altogether, if six
pies or above, one [anna] [Now new paise.] should be entered.
446. Use of [annas] [Now new paise.] to be dispensed with where possible.
- Further in all settlements, revisions of settlements, grants of compensation, takavi advances and
other revenue transactions as distinguished from those of account, the use of [annas] [Now new
paise.] should be dispensed with as far as possible. In assessments they should never be used ; and
in the distribution of assessments, either into instalments, or shares, their use should be avoided,
where possible.Note. - The word "assessment" in the above rule should be understood to mean
assessment of land revenue payable by proprietors "and not rent paid by raiyats in a Government
estate" though both are defined as "land revenue" by Section 2, Act II (B.C.) of 1894.
447. Exceptions.
- The only exceptions which can be allowed to the above rules are in (1) fines and forfeitures, (2)
savings of establishments, (3) deposits, (4) interest, (5) deductions for the funds and (6)
pensions.Appendix A(See Rule 19)Instructions regarding the submission of petitions to the
Governor General in Council**** Note. - Submission, receipt and transmission of memorials to His
Majesty and of petitions to His Excellency the Governor-General for pardon are regulated by rules
promulgated with the Notification No. 361/37. Judicial (G), dated the 28th April, 1938, by the
Secretary to the Governor-General (Public) and not reprinted in the Board's Miscellaneous Rules.
Part I – Preliminary
1. Definitions. - In these instructions :-
(1)"civil employment" means employment by Government or by a local authority;(2)"Local
Government" includes the authorities mentioned in the Schedule; and(3)"petition" includes
memorials, letters and applications of the nature of petitions.Bihar Board's Miscellaneous Rules, 1958

2. Scope of Instructions. - (1) Save as hereinafter provided, these instructions
shall apply, so far as may be, to all petitions addressed to the Governor
General in Council.
(2)They shall apply only in so far as they are not inconsistent with the conditions of Army, [Royal
Air Force,] [Now, Indian Air Force.] or [Royal Indian Marine Service] [Now, Indian Navy.] to
petitions of the nature referred to in sub-instruction (1) from persons who are or have in such
service in respect of matters arising therefrom.(3)They shall not apply to-(a)petitions relating to
matters arising in a State in India, such petitions are governed by separate instructions issued by the
Foreign and Political Department:(b)petitions relating to bills pending before the Indian
Legislature; such petitions are governed by the Standing Orders of the Council of State and the
Legislative Assembly;(c)petitions submitted by, or on behalf of, convicts under sentence of
death.(4)They shall not affect any rules or orders made by the Governor-General in Council in
respect of representations submitted by recognized associations of Government Servants.
Part II – Form and manner of submission of petitions
3. Form of petition. - (1) A petition may be either in manuscript, or in print.
(2)Every petition shall be authenticated by the signature of the petitioner, or, when the petitioners
are numerous, by the signatures of one or more of them.(3)Every petition, and the documents
accompanying it, shall, if possible, be in English; if not, they shall be accompanied by an English
translation authenticated in the manner provided in sub-instruction (2).
4. Contents of petition. - Every petition shall-
(a)contain all material statements and arguments relied upon by the petitioner;(b)be complete in
itself;(c)if any recorded order of a public authority is complained against, be accompanied by a copy
of the order and by a copy of any order in the case passed by a subordinate authority ; and(d)end
with a specific prayer.
5. Method of submission. - (1) Every petition shall be submitted through-
(a)the local Government mentioned in the Schedule in respect of the petitioner; or(b)if no local
Government is mentioned in the Schedule in respect of the petitioner, the local Government of the
province in which the petitioner is or has last been residing or employed,and shall be accompanied
by a letter requesting the local Government to transmit the petition to the Governor-General in
Council.(2)If there is no local Government such as is referred to in sub-instruction (1), the petition
shall be submitted to the Governor-General in Council direct.Bihar Board's Miscellaneous Rules, 1958

6. Submission of petitions by persons in civil employment. - (1) Every person
in civil employment, and every person who has been in civil employment,
shall, if he desires to petition the Governor-General in Council in respect of
the termination of such employment, submit a separate petition on his own
behalf.
(2)Every such petition shall be submitted through the authority provided in instruction 5 through
the head of the office or department to which the petitioner belongs or belonged.(3)The head of an
office or department, on respect of any petition submitted through him in accordance with
sub-instruction (2), shall forward the petition by means of the usual official channel to the authority
provided in instruction 5.
Part III – Withholding of petitions by the Local Government
7. Circumstances in which petitions may be withheld. - The local Government
may, at discretion, withhold a petition when-
(1)the petitioner has not complied in full with the provisions of Part II of these instructions;(2)the
petition is illegible, unintelligible or contains language which is, in the opinion of the local
Government, disloyal, disrespectful or improper;(3)a previous petition from the petitioner on the
same subject has been disposed of by the Secretary of State for India in Council or the
Governor-General in Council, and the petition, in the opinion of the local Government, discloses no
new facts or circumstances which afford grounds for a reconsideration of the subject;(4)the petition
is a representation against a decision which is declared to be final by any law or statutory Rule
;(5)the law provides a different or specific remedy in respect of the subject matter of the petition,
whether or not any period of limitation prescribed for the prosecution of such remedy has
expired;(6)the petition is an appeal from a judicial decision;Provided that, if the petition-(a)is an
appeal from a judicial decision in a case in which Government has reserved any discretion of
interference;(b)is an appeal from a judicial decision in a suit to which Government was a party;
or(c)is a prayer for the suspension or remission of a sentence under Chapter XXIX of the [Code of
Criminal Procedure, 1898 (V of 1898)] [Now, See Cr.P.C 1973];the petition shall not be withheld
unless it falls under clause (12);(7)the petition is a mere application for relief, pecuniary or other
which is-(a)presented by a person manifestly possessing no claim or advancing a claim of an
obviously unsubstantial character; or(b)so belated that its consideration is clearly impossible.(8)the
petition is-(a)an application for employment in Government service not made in pursuance of any
rule or announcement regarding application for such employment; or(b)a request for exemption
from the provisions of any law or rule prescribing the qualifications to be possessed by persons in
the service of Government or by persons engaging in any profession or employment;(9)the petition
makes a proposal regarding legislation which the local Government is not prepared to
support;(10)the petition is a representation against the action of a private individual or of a body of
private individuals regarding the private relations of the petitioner and such individual or body
;(11)the petition, not being petition such as is referred to in the proviso to clause (6), relates toBihar Board's Miscellaneous Rules, 1958

matters in which the petitioner has no direct personal interest;(12)the petition relates to a subject on
which the local Government is competent to pass orders and no application for redress has been
made by petitioner to the local Government;(13)the petition is a representation against an order
communicated to the petitioner more than six months before the submission of the petition, and no
satisfactory explanation of the delay is given ;(14)the petition is a representation against a failure to
exercise a discretion vested in local Government:Provided that no petition submitted by-(a)a
member of an All India Service ;(b)an officer holding the King's Commission on the active list of the
Regular Army, the Royal Air Force or the Royal Indian Marine ; or(c)a person appointed by the
Secretary of State for India in Council on the ground that he has not been selected for a selection
post;shall be withheld;(15)the petition is a representation against the discharge of a
person-(a)appointed on probation during such probation ;(b)appointed, otherwise than under
contract, to hold a temporary appointment, on the expiration of the period of such appointment;
or(c)engaged under contract, in accordance with the terms of such contract;(16)the petition is a
representation by a Government servant against an order-(a)from which he has exercised, or
possesses, a right of appeal under-(i)rules or orders regulating the conditions of service; or(ii)the
terms of his contract of service;(b)passed by any authority in the exercise of appellate or revisional
powers conferred by any rule, order or contract such as is referred to in sub-clause (a); or(c)from
which, not being an order of punishment passed by the Governor-General in Council on an officer
appointed by the Governor-General in Council, an appeal is expressly barred by any rule, order or
contract such as is referred to in sub-clause (a);(17)the petition is a representation relating to-(a)the
application of-(i)rules made by the Secretary of State for India in Council under sub-section (2) of
Section 96-B of the Government of India Act;(ii)orders made by the Secretary of State for India in
Council; or(iii)the terms of the contract of service of the petitioner; or(b)an order of the local
Government refusing to grant or to recommend:-(i)a special pension ;(ii)a compassionate pension ;
or(iii)any pecuniary or other concession to which the petitioner is not entitled under any law or
statutory rule :Provided that, subject to the provisions of clause (4), no petition against the
interpretation by any authority other than the Secretary of State for India in Council of any rule,
order or contract-(A)such as is referred to in sub-clause (a); or(B)approved by the Secretary of State
for India in Council, shall be withheld;(18)the petition is submitted, otherwise than in accordance
with any rule, order or contract such as is referred to in sub-clause (a) of clause (16), by a person in
Government service with regard to his prospective claim to pension ; or(19)the petition is a
representation with regard to any matter connected with the official prospects or position of a
person in Government service, and is not submitted by such person.
8. Petitioner to be informed when petition is withheld. - The local Government
shall, when a petition is withheld under Instruction 7, inform the petitioner of
the withholding and the reason thereof.
9. List of petitions withheld. - The local Government shall send a quarterly
return to the Governor-General in Council specifying all petitions withheld
under Instruction 7 by the local Government, and the reasons for withholding
them.Bihar Board's Miscellaneous Rules, 1958

Part IV – Transmission of Petitions by the Local Government
10. Procedure for transmission. - (1) The local Government shall transmit to
the Governor-General in Council all petitions not withheld under Instruction
7, together with a concise statement of facts material thereto and, unless
there are special reasons to the contrary, an expression of the opinion of the
local Government thereon.
(2)When the petition of any document accompanying it is not in English-(a)if it is accompanied by
an English translation the local Government shall examine the translation and, when transmitting
the petition, notify the Governor-General in Council of any defects found in the translation; and(b)if
it is not accompanied by an English translation, the local Government shall prepare such a
translation and transmit it together with the petition.
Schedule
List of Authorities included in the words "Local Government"[See Instruction 1(2)]
1. Chief Commissioners.
2. The Commander-in-Chief in India and Army, District and Independent
Brigade Commanders.
Note. - In the case of petitioners who are ex-soldiers and have served under more than one Army,
District or Independent Brigade Commander, the local Government for the purposes of these
instructions shall be the Army, District or Independent Brigade Commander who from his
knowledge of the petitioner or the subject-matter of the petition is best able to make
recommendations on the petition.
3. The Air Officer Commanding, Royal Air Force in India.
4. The Flag Officer Commanding, Royal Indian Navy.
5. Heads of Departments who are directly under the Government of India.
6. In respect of persons serving under the Railway Board :-
(a)As regards non-pensionable subordinate staff:-
(i) Agents,of the N.W., E.B., E.I., G.I.P. and
Burma RailwaysBihar Board's Miscellaneous Rules, 1958

(ii) Chief Engineers,
(iii)Chief Operating and Transportation
Superintendents,
(iv) Chief Traffic and Commercial Managers,
(v)Locomotive and Carriage & Wagon
Superintendents,
(vi) Chief Mechanical Engineers,
(vii) Superintendents of Mechanical Workshops,
(viii) Chief Accounts Officers,
(ix) Divisional Superintendents,
(x) Controller of Railway Accounts,
(b)As regards other staff:-The Railway Board.Appendix B(See Rule 19)Instructions for the
submission, receipt and transmission of petitions to the Governor-General in Council from persons
who are, or have been, in the Civil Service of the Crown.
Part I – Preliminary
1. Definitions. - In these instructions :-
1. "Provincial Government" includes the authorities mentioned in the
Schedule; and
2. "Petition" includes memorials, letters and application of the nature of
petitions.
2. Scope of Instructions. - (1) Save as hereinafter provided, these instructions
shall apply, so far as may be, to all petitions addressed to the
Governor-General in Council, by persons who are, or have been, in the Civil
Service of the Crown in India other than those employed under the Crown
Representative in respect of matters arising out of such employment or in
respect of the termination of such employment.
(2)They shall apply only in so far as they are not inconsistent with the conditions of Royal Indian
Navy, Army, or Royal Air Force Service to petitions of the nature referred to in sub-instruction (1)
from persons who are or have been in such service in respect of matters arising therefrom.(3)They
shall not affect any rules or orders made by the Governor-General in Council in respect of
representations submitted by recognized associations of Government servants.Bihar Board's Miscellaneous Rules, 1958

Part II – Form and Manner of Submission of Petitions
3. Form of petition. - (1) A petition may be either in typescript or in print.
(2)Every petition shall be authenticated by the signature of the petitioner, and submitted by the
petitioner in his own behalf.(3)Every petition, and the documents accompanying it, shall be in
English.
4. Contents of petition. - Every petition shall-
(a)contain all material statements and arguments relied upon by the petitioner;(b)be complete in
itself;(c)if any recorded order of a public authority is complained against, be accompanied by a copy
of the orders and by a copy of any order in the case passed by a subordinate authority ; and(d)end
with a specific prayer.
5. Method of submissions. - (1) Every petition shall be submitted through-
(a)the Provincial Government mentioned in the Schedule in respect of a petitioner; or(b)if no
Provincial Government is mentioned in the Schedule in respect of the petitioner, the Provincial
Government of the province in which the petitioner is or has last been residing or employed,and
shall be accompanied by a letter requesting the Provincial Government to transmit the petition to
the Governor-General in Council.(2)If there is no Provincial Government such as is referred to in
sub-instruction (1), the petition shall be submitted to the Governor-General in Council direct.
6.
(1)Every petition shall be submitted to the authority provided in Instruction 5 through the head of
the office or department to which the petitioner belongs or belonged.(2)The head of an office or
department, on receipt of any petition submitted through him in accordance with sub-instruction
(1), shall forward the petition by means of the usual official channel, to the authority provided in
Instruction 5.
Part III – Withholding of petitions by the Provincial Government
7. Circumstances in which petitions may be withheld. - The Provincial
Government may, at discretion, withhold a petition when-
(1)the petitioner has not complied in full with the provisions of Part II of these instructions ;(2)the
petition is illegible or unintelligible or contains language which is in the opinion of the Provincial
Government, disloyal, disrespectful or improper;(3)a previous petition from the petitioner on the
same subject has been disposed of by the Secretary of State for India or the Governor-General in
Council, and the petition, in the opinion of the Provincial Government, discloses no new facts orBihar Board's Miscellaneous Rules, 1958

circumstances which afford grounds for a reconsideration of the subject;(4)the petition is a
representation against a decision which is declared to be final by any law or statutory Rule :(5)the
petition is :-(a)an application for employment in Government service not made in pursuance of any
rule or announcement regarding applications for such employment; or(b)a request for exemption
from the provisions of any law or rule prescribing the qualifications to be possessed by the persons
in the service of Government or by persons engaging in any profession or employment;(6)the
petition relates to a subject on which the Provincial Government is competent to pass orders, and no
application for redress has been made by the petitioner to the Provincial Government;(7)the petition
is a representation against an order communicated to the petitioner more than six months before
the submission of the petition, and no satisfactory explanation of the delay is given;(8)the petition is
a representation against a failure to exercise a discretion vested in the Provincial
Government:Provided that no petition submitted by an officer appointed by the Secretary of State in
Council or the Secretary of State or a Commissioned Officer on the Active List of the Royal Indian
Navy, or an officer holding the King's Commission on the Active List of the Regular Army or the
Royal Air Force or an officer appointed substantively to a reserved post, or an officer appointed by
the Governor-General in Council to a Central Service, shall be withheld;(9)the petition is a
representation against the discharge of a person-(a)appointed on probation, during such probation
;(b)appointed, otherwise than under contract, to hold a temporary appointment on the expiration of
the period of such appointment; or(c)engaged under contract in accordance with the terms of such
contract;(10)the petition is a representation against an order(a)from which the petitioner has
exercised, or possesses right of appeal under:-(i)rules or orders regulating his conditions of service ;
or(ii)the terms of his contract of service ;(b)passed by any authority in the exercise of appellate or
revisional powers conferred by any rule, order or contract such as is referred to in sub-clause (a);
or(c)from which, not being an order of punishment passed by the Governor-General in Council on
an officer appointed by the Governor-General in Council, an appeal is expressly barred by any rule,
order or contract such as is referred to in sub-clause (a);(11)the petition is a representation relating
to-(a)the application of-(i)rules or orders made by the Secretary of State for India in Council or the
Secretary of State for India ; or(ii)the terms of the contract of service of the petitioner; or(b)an order
of the Provincial Government refusing to grant or to recommend-(i)a special pension ;(ii)a
compassionate pension ; or(iii)any pecuniary or other concession to which the petitioner is not
entitled under any law or statutory Rule :Provided that no petition submitted by an officer
appointed by the Secretary of State in Council or the Secretary of State or a Commissioned Officer
on the Active List of the Royal Indian Navy or an officer holding the King's Commission on the
Active List of the Regular Army or the Royal Air Force or an officer appointed substantively to a
reserved post or an officer appointed by the Governor-General in Council to a Central Service, shall
be withheld ;(12)the petition is submitted, otherwise than in accordance with any rule, order or
contract such as is referred to in sub-clause (a) of clause (10), with regard to the prospective claim of
the petitioner to pension ;(13)the petition is a representation against the withholding of a petition by
an authority competent to do so.
8. Petitioner to be informed when petition is withheld. - The Provincial
Government shall, when a petition is withheld under Instruction 7, inform the
petitioner of the withholding and the reason therefor.Bihar Board's Miscellaneous Rules, 1958

9. List of petitions withheld. - The Provincial Government shall send a
quarterly return to the Governor-General in Council specifying all petitions
from officers under the rule-making control of that authority or an authority
subordinate thereto, withheld under Instruction 7 by the Provincial
Government and the reasons for withholding them.
Note. - Returns need be made only in respect of memorials and petitions received from persons who
are not under the rule-making control of the Provincial Government.
Part IV – Transmission of petitions by the State Government
10. Procedure for transmission. - The State Government shall transmit to the
Governor-General in Council all petitions not withheld under Instruction 7,
together with a concise statement of facts material thereto and, unless there
are special reasons to the contrary, an expression of the opinion of the State
Government thereon.
Schedule 2
List of Authorities included in the term "Provincial Government"[See Instruction 1(1)]
1. Chief Commissioners.
2. The Commander-in-Chief in India and Army, District and Independent
Brigade Commanders.
Note. - In the case of petitioners who are ex-soldiers and have served under more than one Army,
District or Independent Brigade Commander, the local Government for the purposes of these
instructions shall be the Army, District or Independent Brigade Commander who from his
knowledge of the petitioner or of the subject-matter of the petition is best able to make
recommendations on the petition.
3. The Air Officer Commanding, Royal Air Force in India.
4. The Flag Officer Commanding, Royal Indian Navy.
5. Heads of Departments who are directly under the Government of India.Bihar Board's Miscellaneous Rules, 1958

6. In respect of persons serving under the Railway Board :-
(a)as regards non-pensionable non-gazetted staff
(i) General Manager, of the N.W., B.A., E.I., G.I.P. Railways
(ii) Chief Engineers,
(iii) Chief Operating and Transportation Superintendents,
(iv) Chief Traffic and Commercial Managers,
(v) Locomotive and Carriage & Wagon Superintendents,
(vi) Chief Mechanical Engineers,
(vii) Superintendents of Mechanical Workshops,
(viii) Financial Advisers and Chief Accounts Officers,
(ix) Divisional Superintendents,
(x) Controller of Railway Accounts,
(b)as regards other staff:-The Railway Board.Appendix C(See Rule 19)Instructions for the
submission of certain classes of petitions to the Governor-General in Council*
Part I – Preliminary
* Note. - Submission, receipt and transmission of memorials to His Majesty and petitions to His
Excellency the Governor-General for pardon are regulated by rules promulgated with the
Notification No. 361/37 Judi. (G), dated the 28th April, 1938, by Secretary to the Governor-General
(Public) and not reprinted in the Board's Miscellaneous Rules.
1. Definition. - For the purposes of these Instructions, "petition" includes
memorials, letters and applications of the nature of petitions.
2. Scope of instructions. - These Instructions shall apply, so far as may be, to
all petitions addressed to the Governor-General in Council relating to matters
to which the executive authority of the Governor-General in Council extends
excepting-
(i)petitions submitted by, or on behalf of, persons sentenced by a Court of law to death or to any
other punishment;(ii)petitions submitted by, or on behalf of, persons who are or have been in the
service of the Crown in respect of matters arising out of such service or in respect of the termination
of such service ; and(iii)petitions relating to bills pending before the Indian Legislature.Bihar Board's Miscellaneous Rules, 1958

Part II – Form and Manner of Submission of Petitions
3. Form of petition. - (1) A petition may be either in type or in print.
(2)Every petition shall be authenticated by the signature of the petitioner, or when the petitioners
are numerous by the signatures of one or more of them.(3)Every petition and the documents
accompanying it, shall, if possible, be in English; if not, they shall be accompanied by an English
translation authenticated in the manner provided in sub-instruction (2).
4. Contents of petition. - Every petition shall-
(a)contain all material statements and arguments relied upon by the petitioner;(b)be complete in
itself;(c)if any recorded order of a public authority is complained against, be accompanied by a copy
of the order and by a copy of any order in the case passed by the subordinate authority ; and(d)end
with a specific prayer.
5. Method of submission. - Every petition shall be submitted,-
(a)if it relates to a matter directly administered by the Governor-General in Council, through the
Head of Department concerned ;(b)if it emanates from a Chief Commissioner's Province and is not
covered by the preceding clause, through the Chief Commissioner; and(c)in any other case to the
Governor-General in council in the Home Department;and shall be accompanied by a letter
requesting the authority to submit the petition to the Governor-General in Council.
Part III – Withholding of petitions by subordinate authorities
6. Circumstances in which petitions may be withheld. - The petitions received
by any authority under sub-instructions (a) and (b) of Instruction 5 may, if it
is an authority specified in the Schedule be withheld by that authority, when-
(1)the petitioner had not complied in full with the provisions of Part II of these instructions;(2)the
petition is illegible, or unintelligible, or contains language which is, in the opinion of the authority
disloyal, disrespectful or improper;(3)a previous petition from the petitioner on the same subject
has been disposed of by the Secretary of State for India or the Governor-General in Council and the
petition, in the opinion of the authority, discloses no new facts or circumstances which afford
grounds for reconsideration of the subject;(4)the petition is a representation against a decision
which is declared to be final by any law or statutory rule ;(5)the law provides a different or specific
remedy in respect of the subject matter of the petition, whether or not any period of limitation
prescribed for the prosecution of such remedy has expired ;(6)the petition is in effect an appeal from
a judicial decision ;(7)the petition is a mere application for relief, pecuniary or other, which
is-(a)presented by a person manifestly possessing no claim or advancing a claim of an obviously
unsubstantial character; or(b)so related that its consideration is clearly impossible ;(8)the petitionBihar Board's Miscellaneous Rules, 1958

makes a proposal regarding legislation which the authority is not prepared to support;(9)the
petition is a representation against the action of a private individual or of a body of private
individuals regarding the private relations of the petitioner or such individual or body;(10)this
petition relates to a matter in which the petitioner has no direct personal interest;(11)the petition
relates to a subject on which the authority is competent to pass orders and no application for redress
has been made by the petitioner to the authority ;(12)the petition is a representation against an
order communicated to the petitioner more than six months before the submission of the petition
and no satisfactory explanation of the delay is given ;(13)the petition is a representation against a
failure to exercise a discretion vested in the Governor-General in Council or any other authority
;(14)the petition is a representation relating to orders made by the Secretary of State for India.
7. Petitioner to be informed when petition is withheld. - When a petition is
withheld under Instruction 6, the authority shall inform the petitioner of the
withholding and the reasons therefor.
8. List of petitions withheld. - The authorities mentioned in the Schedule shall
send a quarterly return to the Governor-General in Council specifying all
petitions withheld under Instruction 6 and the reasons for withholding them.
Part IV – Transmission of petitions by subordinate authorities
9. Procedure for transmission. - (1) The authorities referred to in
sub-instructions (a) and (b) of Instruction 5 shall transmit to the
Governor-General in Council all petitions not withheld under Instruction 6
together with a concise statement of facts material thereto and an expression
of the opinion of the authority concerned thereon.
(2)Where the petition or any document accompanying it is not in English-(a)if it is accompanied by
an English translation, the authority shall examine the translation and report any defects found
therein while transmitting the petition;(b)if it is not accompanied by an English translation the
authority shall prepare such a translation and transmit it together with the petition.
Schedule 3
List of subordinate authorities who may withhold petitions(See Instruction 6)
1. All Heads of Departments directly administered by the Governor-General in
Council including-
(a)The Commander-in-Chief in India ;(b)The Flag Officer Commanding, Royal Indian Navy;(c)The
Air Officer Commander-in-Chief, Air Headquarters, India, and(d)The Railway Board.Bihar Board's Miscellaneous Rules, 1958

2. Army, District and Independent Brigade Commanders.
3. Chief Commissioners.
Appendix D(See Rule 20)Instructions regarding the submission of memorials and other papers of
the same class to His Majesty the King, Emperor of India, or to the Right Honourable the Secretary
of State for India** Note. - Submission, receipt and transmission of memorials to His Majesty and of
petitions to His Excellency Governor the General for pardon are regulated by Rules promulgated
with the Notification No. 361/37 Judi. (G), dated the 28th April, 1938, by the Secretary to the
Governor-General (Public) and are not reprinted in the Board's Miscellaneous Rules.
Part I – Preliminary
1. Definitions. - In these instructions;-
(1)"Civil employment" means employment by Government or by a local Authority;(2)"local
Government" includes the authorities mentioned in the Schedule; and(3)"memorial" includes
petitions, letters and applications of the nature of memorials.
2. Scope of Instructions. - (1) Save as hereinafter provided, these instructions
shall apply, so far as may be, to all memorials addressed to His Majesty the
King, Emperor of India, or the Secretary of State for India.
(2)They shall apply only in so far as they are not inconsistent with the conditions of Army, [Royal
Air Force] [Now Indian Air Force.], or [Royal Indian Marine Service] [Now Indian Navy.] to
memorials of the nature referred to in sub-instruction (i) from persons who are or have been in such
service in respect of matters arising therefrom.(3)They shall not apply to memorials relating to
matters arising in a State in India; such memorials are governed by separate instructions issued by
the Foreign and Political Department.(4)They shall not apply to memorials submitted by, or on
behalf of convicts under sentence of death.(5)They shall not affect any rules or orders made by
competent authority in respect of representations submitted by recognised association of
Government servants.
Part II – Form and Manner of Submission of Memorials
3. Form of memorials. - (1) A memorial may be either in manuscript or in
print.
(2)Every memorial shall be authenticated by the signature of the memorialist, or when the
memorialists are numerous, by the signature of one or more of them.(3)Every memorial and the
documents accompanying it, shall, if possible, be in English : if not, they shall be accompanied by an
English translation authenticated in the manner provided in sub-instruction (2).Bihar Board's Miscellaneous Rules, 1958

4. Contents of memorial. - Every memorial shall-
(a)contain all memorial statements and arguments relied upon by the memorialist;(b)be complete in
itself;(c)if any recorded order of a public authority is complained against, be accompanied by a copy
of the order and by a copy of any order in the case passed by subordinate authority ; and(d)end with
a specific prayer.
5. Method of submission. - Every memorial shall be submitted through-
(a)the local Government mentioned in the Schedule in respect of the memorialist;(b)if no local
Government is mentioned in the Schedule in respect of the memorialist, the local Government of the
province in which the memorialist is or has last been residing or employed ; or(c)if there is no local
Government such as is referred to in Clause (a) or clause (b), the Governor-General in Council,and
shall be accompanied by a letter requesting the local Government or the Governor-General in
Council, as the case may be, to transmit the memorials to His Majesty or the Secretary of State for
India in Council, as the case may be.
6. Submission of memorials by persons in civil employment. - (1) Every
person in civil employment, and every person who has been in civil
employment, shall, if he desires to memorialise His Majesty or the Secretary
of State for India in respect of such employment, or in respect of termination
of such employment, submit a separate memorial on his own behalf.
(2)Every such memorial shall be submitted through the authority provided in instruction 5 through
the head of the office or department to which the memorialist belongs or belonged.(3)The head of an
office or department, on receipt of an memorial submitted through him in accordance with
sub-instruction (2), shall forward the memorial, by means of the usual official channels, to the
authority provided in instruction 5.
Part III – Withholding of Memorials by the Governor-General in
Council or Local Governments
7. Circumstances in which memorials may be withheld. - Memorials received
by-
(a)the Governor-General in Council-(i)under clause (c) of Instruction 5 ; or(ii)under sub-instruction
(1) of Instruction 10 from an authority such as is referred to in Article 6 of the Schedule,may, at
discretion, be withheld by the Governor-General in Council,(b)a local Government may, at
discretion, be withheld by the local Government, when-(1)the memorialist has not complied in full
with the provisions of Part II of the instructions ;(2)the memorial is illegible or unintelligible, or
contains language which is, in the opinion of the Governor-General in Council or the localBihar Board's Miscellaneous Rules, 1958

Government, disloyal, disrespectful or improper;(3)a previous memorial from the memorialist on
the same subject has been disposed of by his Majesty or the Secretary of State for India, and the
memorial, in the opinion of the Governor-General in Council or the local Government discloses no
new facts or circumstances which afford grounds for a reconsideration of the subject;(4)the
memorial is a representation against a decision which is declared to be final by any law or statutory
rule;(5)the law provides a different or specific remedy in respect of the subject matter of the
memorial, whether or not any period of limitation prescribed for the prosecution of such remedy has
expired ;(6)the memorial is an appeal from a judicial decision :Provided that, if the memorial-(a)is
an appeal from a judicial decision in a case in which Government has reserved any discretion of
interference ;(b)is an appeal from a judicial decision in a suit to which Government was a party ;
or(c)is a prayer for the exercise of a royal prerogative, such as that of pardon, the memorial shall not
be withheld unless-(i)not being a prayer for the exercise of a royal prerogative, it falls under clause
(12); or(ii)being a prayer for the exercise of a royal prerogative it has been granted by His Excellency
the Viceroy in virtue of his authority to exercise the royal prerogative in question, in which case it
may be withheld by the Governor-General in Council;(7)the memorial is a mere application for
relief, pecuniary or other, which is-(a)presented by a person manifestly possessing no claim or
advancing a claim of an obviously unsubstantial character; or(b)so belated that its consideration is
clearly impossible ;(8)the memorial is-(a)an application for employment in Government service not
made in pursuance of any rule or announcement regarding applications for such employment;
or(b)a request for exemption from the provisions of any law or rule prescribing the qualification to
be possessed by persons in the service of Government or by persons engaging in any profession or
employment;(9)the memorial makes a proposal regarding legislation which the Governor-General
in Council or the local Government is not prepared to support;(10)the memorial is a representation
against the action of a private individual or of a body of private individuals regarding the private
relation of the memorialist and such individual or body ;(11)the memorial, not being a memorial
such as is referred to in the proviso to Clause (6), relates to matters in which the memorialist has no
direct personal interest;(12)the memorial relates to a subject on which the Governor-General in
Council or the local Government is competent to pass orders, and no application for redress has
been made by the memorialist to the Governor-General in Council or the local Government, as the
case may be;(13)the memorial is a representation against an order communicated to the memorialist
more than six months before the submission of the memorial, and no satisfactory explanation of the
delay is given ;(14)the memorial is a representation against a failure to exercise a discretion vested
in Governor-General in Council or the local Government:Provided that no memorial submitted
by-(a)a member of an All-India Service ;(b)an officer holding the King's Commission on the active
list of the Regular Army, [the Royal Air Force] [Now Indian Air Force.] or [the Royal Indian
Marine;] [Now Indian Navy.] or(c)a person appointed by the Secretary of State for India on the
ground that he has not been selected for a selection post; shall be withheld;(15)the memorial is a
representation against the discharge of a person-(a)appointed on probation, during such probation
;(b)appointed, otherwise than under contract, to hold a temporary appointment on the expiration of
the period of such appointment; or(c)engaged under contract, in accordance with the terms of such
contract;(16)the memorial is a representation by a Government servant against an order-(a)from
which he has exercised, or possesses, a right of appeal under-(i)rules or orders regulating his
conditions of service ; or(ii)the terms of his contract of service ;(b)passed by any authority in the
exercise of appellate or revisional powers conferred by any rule, order or contract such as is referredBihar Board's Miscellaneous Rules, 1958

to in sub-clause (a);(c)from which an appeal is expressly barred by any rule, order, contract such as
is referred to in sub-clause (a); or(d)passed by the Governor-General in Council on a petition against
an order of punishment passed by the Governor-General in Council or an officer appointed by the
Governor-General in Council;(17)the memorial is a representation relating to-(a)the application
of-(i)rules made by the Secretary of State for India under subsection (2) of Section 96-B of the
Government of India Act;(ii)orders made by the Secretary of State for India ; or(iii)the terms of the
contract of service of the memorialist; or(b)an order of the Governor-General in Council or the local
Government refusing to grant or to recommend-(i)a special pension ;(ii)a compassionate pension ;
or(iii)any pecuniary or other concession to which the memorialist is not entitled under any law or
statutory Rule :Provided that, subject to the provisions of Clause (4), no memorial against the
interpretation by any authority, other than the Secretary of State for India, of any rule, order or
contract-(A)such as is referred to in sub-clause (a); or(B)approved by the Secretary of State for
India, shall be withheld, unless the Governor-General in Council is satisfied that there is no
reasonable doubt of the correctness of such interpretation;(18)the memorial is submitted, otherwise
than in accordance with any rule, order or contract such as is referred to in sub-clause (a) of Clause
(16), by a person in Government service with regard to his prospective claim to pension; or(19)the
memorial is a representation with regard to any matter connected with the official prospects or
position of a person in Government service, and is not submitted by such person.
8. Memorialist to be informed when memorial is withheld. - The
Governor-General in Council or the local Government shall, when a memorial
is withheld under instruction 7, inform the memorialist of the withholding and
the reason therefor.
9. List of memorials withheld. - (1) The local Government shall send a
quarterly return to the Governor-General in Council specifying all memorials
withheld under Instruction 7 by the local Government and the reasons for
withholding them.
Note. - Returns need be made only in respect of memorials and petitions received from persons who
are not under the rule-making control of the Provincial Government.(2)The Governor-General in
Council shall send a quarterly return to the Secretary for India specifying all memorials withheld
under instruction 7 by the Governor-General in Council or by a local Government, and the reasons
for withholding them.
Part IV – Transmission of memorials by Governor-General in
Council or Local Government
10. Procedure for transmission. - (1) The local Government shall transmit to
the Governor-General in Council all memorials not withheld under clause (b)
of Instruction 7, together with a duplicate copy thereof.Bihar Board's Miscellaneous Rules, 1958

(2)The Governor-General in Council shall, ordinarily within one month after receipt, transmit, in
original, to His Majesty or the Secretary of State for India, as the case may be, all memorials
received by the Governor-General in Council-(a)under clause (c) of Instruction 5, and not withheld
under sub-clause (i) of clause (a) of Instruction 7 ; and(b)under sub-instruction (1) of this
instruction, and not withheld under sub-clause (ii) of clause (a) of Instruction 7.(3)Memorials
transmitted under this instruction shall be accompanied by a concise statement of facts material
thereto, and, unless there are special reasons to the contrary, an expression of the opinion of the
Governor-General in Council or the local Government, as the case may be, thereon, or in the case of
a memorial received by the Governor-General in Council under sub-instruction (1), of the opinions
of both the Governor-General in Council and the local Government thereon.(4)Where the memorial
or any document accompanying it is not in English the Governor-General in Council or the local
Government, as the case may be, shall when transmitting it under this instruction-(a)if it is
accompanied by an English translation, examine the translation and notify the authority to which it
is transmitted of any defects found in the translation ; or(b)if it is not accompanied by an English
translation, prepare such a translation and transmit it together with the memorial.
Schedule 4
List of Authorities included in the words "Local Government"[See Instruction 1 (2)]
1. Chief Commissioners.
2. The Commander-in-Chief in India and Army, District and Independent
Brigade Commanders.
Note. - In the case of memorialists who are ex-soldiers and have served under more than one Army,
District or Independent Brigade Commander, the local Government for the purposes of these
instructions shall be the Army, District or Independent Brigade Commander who from his
knowledge of the memorialist or of the subject-matter of the memorial is best able to make
recommendations on the memorial.
3. The Air Officer Commanding, Royal Air Force in India.
4. The Flag Officer Commanding, Royal Indian Navy.
5. The Railway Board.
6. Save for the purposes of Part III of the Instructions, Heads of Departments
who are directly under the Government of India.
Appendix E(See Rules 18-20)Instructions for the submission, receipt and transmission of
memorials to His Majesty the King, Emperor of India, or the Right Honourable the Secretary of
State for India from persons who are or have been in the Civil Service of the CrownBihar Board's Miscellaneous Rules, 1958

Part I – Preliminary
1. Definitions. - In these instructions-
(1)"Provincial Government" include the authorities, mentioned in the Schedule; and(2)"memorial"
includes petitions, letters and applications of the nature of memorials.
2. Scope of Instructions. - (1) Save as hereinafter provided, these instructions
shall apply, as far as may be, to all memorials addressed to His Majesty the
King, Emperor of India, or the Secretary of State for India by persons who
are, or have been in the Civil Service of the Crown in India other than those
employed under the Crown Representative, in respect of matters arising out
of such employment or in respect of the termination of such employment.
(2)They shall apply only in so far as they are not inconsistent with the conditions of Royal Indian
Navy, Army or [Royal Air Force Service] [Now Indian Air Force.] to memorials of the nature
referred to in sub-instruction (1) from persons who are or have been in such service in respect of
matters arising therefrom.(3)They shall not affect any rules or orders made by competent authority
in respect of representations submitted by recognised associations of Government servants.
Part II – Form and manner of submission of Memorials
3. Form of Memorial. - (1) A memorial may be either in typescript or in print.
(2)Every memorial shall be authenticated by the signature of the memorialist, and submitted by the
memorialist on his own behalf.(3)Every memorial and the documents accompanying it shall be in
English.
4. Contents of Memorial. - Every memorial shall-
(a)contain all material statements and arguments relied upon by the memorialist;(b)be complete in
itself;(c)if any recorded order of a public authority is complained against, be accompanied by a copy
of the order and by a copy of any order in the case passed by a subordinate authority ; and(d)end
with a specific prayer.
5. Method of submission. - Every memorial shall be submitted through-
(a)the Provincial Government mentioned in the Schedule in respect of the memorialist;(b)if no
Provincial Government is mentioned in the Schedule in respect of the memorialist, the Provincial
Government of the province in which the memorialist is or has last been residing or employed ;
or(c)if there is no Provincial Government such as is referred to in clause (a) or clause (b), theBihar Board's Miscellaneous Rules, 1958

Governor-General in Council;and shall be accompanied by a letter requesting the Provincial
Government or the Governor-General in Council, as the case may be, to transmit the memorial to
His Majesty or the Secretary of State for India, as the case may be.
6.
(1)Every memorial shall be submitted to the authority provided in Instruction 5 through the head of
the office or department to which the memorialist belongs or belonged.(2)The head of an office or
department, on receipt of any memorial submitted through him in accordance with sub-instruction
(1) shall forward the memorial by means of the usual official channels, to the authority provided in
Instruction 5.
Part III – Withholding of Memorials by the Governor-General in
Council or Provincial Governments
7. Circumstances in which memorials may be withheld. - Memorials received
by-
(a)the Governor-General in Council-(i)under clause (c) of Instruction 5 ; or(ii)under sub-instruction
(1) of Instruction 10 from an authority such as is referred to in Article 16 of the Schedule,may, at
discretion, be withheld by the Governor-General in Council;(b)a Provincial Government may, at
discretion, be withheld by that Government;when-(1)the memorialist has not complied in full with
the provisions of Part II of these instructions;(2)the memorial is illegible or unintelligible, or
contains language which is, in the opinion of the Governor-General in Council or the Provincial
Government, disloyal, disrespectful or improper;(3)a previous memorial from the memorialist on
the same subject has been disposed of by His Majesty or the Secretary of State for India and the
memorial in the opinion of the Governor-General in Council or the Provincial Government,
discloses no new facts or circumstances which afford grounds for a reconsideration of the
subject;(4)the memorial is a representation against a decision which is declared to be final by any
law or statutory rule ;(5)the memorial is-(a)an application for employment in Government service
not made in pursuance of any rule or announcement regarding applications for such employment;
or(b)a request for exemption from the provisions of any law or rule prescribing the qualifications to
be possessed by persons in the service of Government or by persons engaging in any profession or
employment;(6)the memorial relates to a subject on which the Governor-General in Council or the
Provincial Government is competent to pass orders, and no application for redress has been made
by the a a memorialist to the Governor-General in Council or the Provincial Government, as the case
may be ;(7)the memorial is a representation against an order communicated to the memorialist
more than six months before the submission of memorial and no satisfactory explanation of the
delay is given;(8)the memorial is a representation against a failure to exercise a discretion vested in
the Governor-General in Council or the Provincial Government:Provided that no memorial
submitted by an officer appointed by the Secretary of State in Council or the Secretary of State ora
Commissioned Officer on the Active List of the [Royal Indian Navy] [Now, Indian Navy.], or an
officer holding the King's Commission on the Active List of the Regular Army, or the [Royal AirBihar Board's Miscellaneous Rules, 1958

Force] [Now, Indian Air Force.], or an officer appointed substantively to a reserved post shall be
withheld ;(9)the memorial is a representation against the discharge of a person-(a)appointed on
probation, during such probation ;(b)appointed otherwise than under contract to hold a temporary
appointment on the expiration of the period of such appointment; or(c)engaged under contract, in
accordance with the terms of such contract;(10)the memorial is a representation against an
order-(a)from which the memorialist has exercised, or possesses a right of appeal under-(i)rules or
orders regulating his conditions of service;or(ii)the terms of his contract of service ;(b)passed by any
authority in the exercise of appellate or revisional powers conferred by any rule, order or contract
such as is referred to in sub-clause (a); or(c)from which an appeal is expressly barred by any rule, or
order or contract such as is referred to in sub-clause (a); or(d)passed by the Governor-General in
Council on a petition against an order of punishment passed by the Governor-General in Council on
an officer appointed by the Governor-General in Council;(11)the memorial is a representation
relating to-(a)the application of-(i)rules or orders made by the Secretary of State for India in Council
or the Secretary of State for India ; or(ii)the terms of the contract of service of the memorialist;
or(b)an order of the Governor-General in Council or the Provincial Government refusing to grant or
to recommend-(i)a special pension ;(ii)a compassionate pension ; or(iii)any pecuniary or other
concession to which the memorialist is not entitled under any law or statutory rule :Provided that no
memorial submitted by an officer appointed by the Secretary of State in Council or the Secretary of
State or a Commissioned Officer on the Active List of the [Royal Indian Navy] [Now, Indian Navy.]
or an officer holding the King's Commission on the Active List of the Regular Army or the [Royal Air
Force] [Now, Indian Air Force.], or an officer appointed substantively to a reserved post shall be
withheld ;(12)the memorial is submitted, otherwise than in accordance with any rule, order or
contract such as is referred to in sub-clause (a) of clause (10), with regard to the prospective claim of
the memorialist to pension ; or(13)the memorial is a representation against the withholding of a
memorial by an authority competent to do so.
8. Memorialist to be informed when memorial is withheld. - The
Governor-General in Council or the Provincial Government shall, when a
memorial is withheld under Instruction 7, inform the memorialist of the
withholding and the reason therefor.
9. List of memorials withheld. - (1) The Provincial Government shall send a
quarterly return to the Governor-General in Council specifying all memorials
from officers under the rule, making control of the Secretary of State
withheld under Instruction 7 by the Provincial Government, and the reasons
for withholding them.
(2)The Governor-General in Council shall send a quarterly return to the Secretary of State for India
specifying all memorials from officers under the rule-making control of that authority withheld
under Instruction 7 by the Governor-General in Council or by a Provincial Government, and the
reasons for withholding them.Bihar Board's Miscellaneous Rules, 1958

Part IV – Transmission of memorials by the Governor-General in
Council or Provincial Governments
10. Procedure for transmission. - (1) The Provincial Government shall
transmit to the Governor-General in Council all memorials not withheld under
clause (b) of Instruction 7 together with a duplicate copy thereof.
(2)The Governor-General in Council shall, ordinarily within one month after receipt transmit, in
original, to His Majesty or the Secretary of State for India, as the case may be, all memorials
received by the Governor-General in Council-(a)under clause (c) of Instruction 5, and not withheld
under sub-clause (i) of clause (a) of Instruction 7 ; and(b)under sub-instruction (1) of this
instruction, and not withheld under sub-clause (ii) of clause (a) of Instruction 7.(3)Memorials
transmitted under the instruction shall be accompanied by a concise statement of facts material
thereto, and unless there are special reasons to the contrary, an expression of the opinion of the
Governor-General in Council or the Provincial Government, as the case may be, thereon, or, in the
case of a memorial received by the Governor-General in Council under sub-instruction (1) of the
opinions of both the Governor-General in Council and the Provincial Government thereon.
Schedule 5
List of Authorities included in the term "Provincial Government"[See Instruction 1(2)]
1. Chief Commissioners.
2. The Commander-in-Chief in India and Army, District and Independent
Brigade Commanders.
Note. - In the case of memorialists who are ex-soldiers and have served under more than one Army,
District or Independent Brigade Commander, the Provincial Government for the purposes of these
instructions shall be the Army, District or Independent Brigade Commander who from his
knowledge of the memorialist or of the subject-matter of the memorial is best able to make
recommendations on the petition.
3. The Air Officer Commanding, [Royal Air Force] [Now, Indian Air Force.] in
India.
4. The Flag Officer Commanding, [Royal Indian Navy.] [Now, Indian Navy.]
5. The Railway Board.Bihar Board's Miscellaneous Rules, 1958

6. Save for the purposes of Part III of the instructions, Heads of Departments
who are directly under the Government of India.
Appendix F[See Rules 18-20]Instructions for the submission, receipt and transmission of certain
classes of memorials to His Majesty the King, Emperor of India or to the Right Honourable the
Secretary of State for India** Note. - Submission, receipt and transmission of memorials to His
Majesty and of petitions to His Excellency the Governor General for pardon are regulated by Rules
promulgated with the Notification No. 361/37 Judi. (G), dated the 28th April, 1938, by the Secretary
to the Governor-General (Public) and are not reprinted in the Board's Miscellaneous Rules.
Part I – Preliminary
1. Definitions. - For the purposes of these Instructions, "memorial" includes
petitions, letters and applications of the nature of memorials.
2. Scope of instructions. - These instructions shall apply, so far as may be, to
all memorials addressed to His Majesty the King, Emperor of India, or the
Secretary of State for India, relating to matters to which the executive
authority of the Governor-General in Council extends, excepting-
(i)memorials submitted by, or on behalf of, persons sentenced by a Court of law to death or to any
other punishment; and(ii)memorials submitted by, or on behalf of, persons who are or have been in
the service of the Crown in respect of matters arising out of such service or in respect of the
termination of such service.
Part II – Form and Manner of Submission of Memorials
3. Form of memorial. - (1) A memorial may be either in manuscript, in type, or
in print.
(2)Every memorial shall be authenticated by the signature of the memorialist or when the
memorialists are numerous by the signature of one or more of them.(3)Every memorial, and the
documents accompanying it, shall, if possible, be in English; if not, they shall be accompanied by an
English translation authenticated in the manner provided in sub-instruction (2).
4. Contents of memorial. - Every memorial shall-
(a)contain all material statements and arguments relied upon by the memorialist;(b)be complete in
itself;(c)if any recorded order of a public authority is complained against, be accompanied by a copy
of the order and by a copy of any order in the case passed by a subordinate authority ; and(d)end
with a specific prayer.Bihar Board's Miscellaneous Rules, 1958

5. Method of submission. - Every memorial shall be submitted,-
(a)if it relates to a matter directly administered by the Governor-General in Council through the
Head of the Department concerned ;(b)if it emanates from a Chief Commissioner's province and is
not covered by the preceding clause, through the Chief Commissioner; and(c)in any other case, to
the Governor-General in Council in the Home Department,and shall be accompanied by a letter
requesting the authority to submit the memorial to the Governor-General in Council for
transmission to His Majesty the King, Emperor of India, or the Secretary of State for India, as the
case may be.
Part III – Withholding of Memorials by the Governor-General in
Council or Subordinate Authorities
6. Circumstances in which Memorials may be withheld. - Memorials received
by the Governor-General in Council under sub-instruction (c) of Instruction 5
and sub-instruction (1) of Instruction 9 may, at discretion, be withheld by the
Governor-General in Council, and memorials received by any authority under
Instruction 5 may, if it is an authority specified in the Schedule, be withheld
by that authority, when-
(1)the memorialist has not complied in full with the provisions of Part II of these instructions;(2)the
memorial is illegible or unintelligible, or contains language which is, in the opinion of the
Governor-General in Council or the authority, disloyal, disrespectful or improper;(3)a previous
memorial from the memorialist on the same subject has been disposed of by His Majesty or the
Secretary of State for India, and the memorial, in the opinion of the Governor-General in Council or
the authority, discloses no new facts or circumstances which afford grounds for a reconsideration of
the subject;(4)the memorial is a representation against a decision which is declared to be final by
any law or statutory rule ;(5)the law provides a different or specific remedy in respect of the subject
matter of the memorial, whether or not any period of limitation prescribed for the prosecution of
such remedy has expired ;(6)the memorial is in effect an appeal from a judicial decision ;(7)the
memorial is a mere application for relief, pecuniary or other which is-(a)presented by a person
manifestly possessing no claim or advancing a claim of an obviously unsubstantial character;
or(b)so belated that its consideration is clearly impossible ;(8)the memorial makes a proposal
regarding legislation which the Governor-General in Council or the authority is not prepared to
support;(9)the memorial is a representation against the action of a private individual or of a body of
private individuals regarding the private relations of the memorialist and such individual or body
;(10)the memorial relates to matters in which the memorialist has no direct personal interest;(11)the
memorial relates to a subject on which the Governor-General in Council or the authority is
competent to pass orders, and no application for redress has been made by the memorialist to the
Governor-General in Council or the authority ;(12)the memorial is a representation against an order
communicated to the memorialist more than six months before the submission of the memorial, and
no satisfactory explanation of the delay is given ;(13)the memorial is a representation against aBihar Board's Miscellaneous Rules, 1958

failure to exercise a discretion vested in the Governor-General in Council or any other authority.
7. Memorialist to be informed when memorial is withheld. - When a memorial
is withheld under Instruction 6, the Governor-General in Council or other
authority shall inform the memorialist of the withholding and the reason
therefor.
8. List of memorials withheld. - (1) The authorities mentioned in the Schedule
shall send a quarterly return to the Governor-General in Council specifying
all memorials withheld under Instruction 5 and the reasons for withholding
them.
(2)The Governor-General in Council shall send a quarterly return to the Secretary of State for India
specifying all memorials withheld and the reasons for withholding them.
Part IV – Transmission of Memorials by the Governor-General in
Council and Subordinate Authorities
9. Procedure for transmission. - (1) The authorities referred to in
sub-instructions (a) and (b) of Instruction 5 shall transmit to the
Governor-General in Council all memorials not withheld under Instruction 6,
together with a duplicate copy thereof. Where the memorial or any document
accompanying it is not in English, the authority shall, when transmitting it
under this instruction-
(a)if it is accompanied by an English translation, examine the translation and report any defects
found therein ; or(b)if it is not accompanied by an English translation, prepare such a translation
and transmit it together with the memorial.(2)The Governor-General in Council shall ordinarily
within one month after receipt, transmit, in original, to His Majesty or the Secretary of State for
India, as the case may be, all memorials received under sub-instruction (1) of this instruction and
sub-instruction (c) of Instruction 5 and not withheld under Instruction 6.(3)Memorials transmitted
under this instruction shall be accompanied by a concise statement of facts material thereto, and
unless there are special reasons to the contrary, an expression of the opinion of the
Governor-General in Council thereon.
Schedule 6
List of Subordinate Authorities who may withhold Memorials(See Instruction 6)Bihar Board's Miscellaneous Rules, 1958

1. The Commander-in-Chief in India and Army, District and Independent
Brigade Commanders.
2. The Flag Officer Commanding, [Royal Indian Navy.] [Now, Indian Navy.]
3. The Air Officer Commanding-in-Chief, Air Headquarters, India
4. The Railway Board.
5. Chief Commissioners.
Appendix G(Vide Rule 56)Inspection questions relating to the Munshikhana and the Nazir's Office
and MalkhanaMunshikhanaEstablishment
1. (a) Who is in subordinate charge of district establishment? How long has
he been in charge?
(b)What is the name of the Office Superintendent? How long has he held the appointment?(c)Is
there a gradation list of the ministerial officers for the whole District arranged according to seniority
within each grade? Is it kept up to date? Are the orders stopping the promotion of any clerk noted
against his name in the gradation list?
2. (a) Who distributes work among the ministerial officers of each
department? Does the Deputy Collector or the Sub-Deputy Collector in
charge or the Office Superintendent see that the distribution is proper?
(b)Is the allotment of clerks to the several departments in accordance with the distribution list given
in the Salaries Committee's report rigidly adhered to or redistribution made as necessity arises.
3. Has any ministerial officer been arrested for debt, or had recourse to
insolvent Court? If so, why has he been retained in the service?
4. Do Muhammadans get their fair share of appointments (vide Government
Resolutions, dated the 8th October, 1886 and 30th August, 1888)?
5. (a) How are vacancies filled up and paid probationers appointed?
(b)Is there any unauthorized probationer in any department?(c)How many paid probationers are
there? How many are holding temporary or acting appointments?Bihar Board's Miscellaneous Rules, 1958

6. Is the attendance register of clerks maintained ? Is it put up before the
Deputy Collector every day at 10.30. a.m.? What action is taken against
clerks for being late in attendance?
7. Are service books maintained for all clerks? Are they kept up to date by
the Bill Clerk? Does any gazetted officer supervise this and attest the entries
in the service books? Are promotion, reversion, suspension and leave
promptly entered? Are the service books kept in the treasury?
8. Has each clerk been supplied with a copy of the Government Servants'
Conduct Rules?
9. Is it the accommodation for the establishment sufficient and suitable? If
not, what steps are being taken to remedy the deficiencies?
10. How many clerks are on extension of service? Who are they? Are they
still mentally and physically fit for further service?
ProcedureGeneral (for all Courts and Offices)
1.
(1)Do all Revenue officers keep a diary in the form prescribed by the High Court in their Circular No.
8 and General Letter No. 6 of the 10th September, 1892? (2) Do they insert therein on the cause list,
immediately after the list of criminal cases, if any, a statement showing the revenue case-work done
during the day and the time occupied by it, as required by Rule 106 of the Board's Miscellaneous
Rules?
2. Are revenue cases entered forward in the diaries?
3. Are order sheets kept in all revenue cases as prescribed in Rule 129 of the
Bihar and Orissa Records Manual, 1941?
4. Has any limit of time been prescribed for each step in routine work?
5. Does the officer in charge of each department invariably mention the dates
by which action other than routine is to be carried out?Bihar Board's Miscellaneous Rules, 1958

6. Are the rules for the punching of Court fee stamps strictly observed?
7. Are cases decided during a month made over to the record-keeper in the
next month? (See also questions under record-room in the Records Manual).
Registers (For All Offices)
8. Does the Office Superintendent regularly examine all office registers, and
attach his signature thereto as evidence of his having done so?
9. Is a list hung up in each department showing the registers kept in that
department, and is it signed by the Deputy Collector in charge and kept up to
date? (Rule 4, page 1, of the Register and Return Manual, 1932).
10.
(1)Are all the registers properly bound either in red khurwa cloth or as books? (2) Is there a label
pasted outside both on sides and backs, giving the number and description of each volume and a
reference to the page of the Register and Return Manual, or if the register be not prescribed in that
Manual, to other proper authority (with citation of prescribing letter and Collection and File when
necessary)? (3) Are any unauthorised registers kept? If so, and if they be required, is action being
taken to get them authorised?
11. Are registers kept vertically arranged in shelves or between supports for
ready selection?
12.
(1)Are the registers clean and neat, or dirty, and blotted? (2) Is the writing in them fairly good? (3)
Are there many alterations and erasures and when there are any, are they neatly made or smudged,
and (4) is each initialled by a superior officer or the Superintendent?
13. Are the registers kept in English or in what character? Are English figures
used?
14. Are register volumes used till they are exhausted or are new registers
unnecessarily opened every year.Bihar Board's Miscellaneous Rules, 1958

15. Have instructions in Rule 119, page 32 of the Bihar and Orissa Records
Manual, 1941, regarding destruction of old registers after they are re-written,
been complied within the current and preceding years?
16. Are all entries relating to pending cases or warrants at the close of the
year brought forward in the new register or are only their number and date
entered in red ink with a column for the date of disposal? (Vide Rule 12, page
4 of the Register and Return Manual, 1932).
Registers A, B, C and DVide Land Registration ManualRegister 1(Settlements)Vide Settlement
ManualRegister 2(Partitions)Vide Batwara ManualRegister 3(Tauzi roll)Vide Tauzi ManualRegister
4(Mutations)Vide Land Registration ManualRegister 5(Land Acquisition cases under Act I of
1894)Vide Land Registration ManualRegisters 6 and 6-A(Land used for public purposes)
1. (a) Are these Registers kept in accordance with the Board's Circular No. 17
of March, 1904?
(b)Are the corrections of the entries in those registers ever tested by a gazetted officer? If so, when
and by whom? Did he consult all the departments in the district?
2. (a) Has the land been properly described and do duly authenticated maps
exist? If not, cause maps to be prepared (Sub-Divisional Officers should have
copies of such maps).
(b)In the cases of lands acquired are the number and date of the land acquisition case noted? Have
the registers been corrected and written up after the completion of the last land acquisition
proceedings?
3. Has a lease been taken for lands rented?
4. Can any of the lands rented be given up at pleasure?
5. Have full particulars about camping grounds in the district been recorded
properly in the prescribed appendix to Register 6?
6. Have all the camping grounds been inspected by the Sub-Divisional
Officers?
Register 7(Persons admitted and enrolled as Revenue Agents)Bihar Board's Miscellaneous Rules, 1958

1. Has date of renewal been duly entered?
2. Are enquiries made about agents whose certificates are not renewed?
Register of Revenue Agent's Clerks(See Rules 102-111, Pages 122-128 of the Practice and Procedure
Manual, 1939)
1. Is a register (in two parts, if necessary) of all recognised clerks employed
by Revenue Agents properly maintained and kept up to date?
2. Has any Revenue agent more than one recognized clerks? If so, was the
express permission of the authorized officer taken?
3. Does any Revenue Agent, who is also a Mukhtar, keep a recognized clerk
in addition to the clerk employed by him as Mukhtar? If so, was the express
permission of the authorised officer taken?
4. Is a card in the prescribed form given to each recognized clerk of Revenue
Agent and are the cards renewed at the close of year?
5. Is the procedure indicated in Rule 107 followed when any recognized clerk
is removed from the register?
6. Were the certificates required by Rule 109 furnished when names of clerks
were reported by the Revenue Agent for registration?
7. In each department is one of the clerks responsible for reporting the
names of persons other than registered clerks trying to do business with
such department?
Register 8(Miscellaneous Cases)This register should be inspected in the various departments in
which it is kept?Note the number of cases in this Register and the number pending. Take some of
the longest pending cases and ascertain the causes of delay.Registers 9 and 10(Requisitions for
certificates and certificates made under the Bihar and Orissa Public Demands Recovery Act, IV of
1914)Vide Bihar Certificate ManualRegister 11(Process of all departments made over to the Nazir for
service)Is this Register kept in each department making over process to the Nazir for service?(See
also the Certificate Manual)Register 11A(Guard file of lists of processes for service received from
courts or office other than those of the receiving Collector or Sub-Divisional Officer)Is the procedure
laid down for the treatment of foreign processes by Rule 36 et seq Page 101, Practice and Procedure
Manual, 1939, followed?Register 12(Applications for separate accounts under Sections 10 and 11 of
Act XI of 1859, and Section 70 of Bengal Act VII of 1876)Bihar Board's Miscellaneous Rules, 1958

1. How many applications received this year up to date under each class?
2. Is care taken to show correctly in the proceedings what Section is
applicable? (Note that the petitions may mis-state the section applicable).
3. Was the record-keeper's report taken previous to the issue of notice to see
whether the applicant's name has been registered or not?
4. Any case referred to Civil Court?
5. In how many have orders for separation of accounts been passed?
6. Of these, how many by Collector and how many by Civil Court?
7. Has a precept been written in each case?
8. Has the notice of separation been sent to the tauzi muharrir and the
record-keeper?
9. Has the prescribed fee of Rs. 2 been realised and credited in each case?
[See charge made by Section 13 of Act II (Bengal) of 1906]
10. Has any separate account been opened within three weeks of the last day
of kist? (Vide Rule 11, Page 188 of the Sale Law Manual, 1936).
Register 12A(Separate accounts opened)Vide Land Registration ManualRegister 13(Deposits made
under Section 15, Act XI of 1859)
1. For how many estates have such deposits been made?
2. Has the agreement alluded to in Section 15 been signed?
3. Deposits how made?
4. Any amount paid from any deposit?
5. Any deposit withdrawn?Bihar Board's Miscellaneous Rules, 1958

6. If so, was receipt of the depositor properly taken?
Register 14(Applications for registry, common or special, under Sections 40 to 44, Act XI of 1895)
1. How many applications received for common registry?
2. How many for special?
3. In the case of common registration, has the record-keeper's report been
taken in order to ascertain the area of the village or villages in which the
property is situated?
4. Any case referred to Civil Court?
5. How many common registrations ordered by Collector?
5. How many by Civil Court?
7. When the order of registration was passed, was the information sent to the
record-keeper?
8. In the case of special registration, has the preliminary enquiry under
Section 42 been completed?
9. Has the Commissioner's sanction been obtained?
Register 15(Appeals of all kinds from the decisions of the Collector and his subordinates)How many
appeals preferred to Collector, and how many to Commissioner? Examine some of the oldest
pending cases and see whether there is undue delay.Register 16(Applications for Waste Lands)
1. How many applications have been received?
2. Have they all been attended to?
3. Have the entries relating to area, local division, etc., been made in
accordance with the particulars given in the applications?
4. Have the survey fees and value of timber on the land been fully paid?
Registers 17 and 18(Notices of enhancement and relinquishment)Bihar Board's Miscellaneous Rules, 1958

1. How many notices since the last inspection?
2. Have they been properly served?
Register 19(Sales for arrears of revenue)(If this register and the sale records are kept in the Arrear
Collection Department, the questions below can be answered there)
1. How many estates were sold on last sale day or during the year? Compare
with figures of preceding year.
2. Has column 14 been duly signed by Treasurer and Treasury Officer?
3. Are steps taken to ascertain the real causes of sale as required by Rule 10,
page 165 of the Sale Law Manual, 1936?
4. Are sales for the arrears of one kist always concluded before the next
"latest day" even in the cases in which special notices under Section 5 have
to be served?
5.
(1)Examine how applications for exemption under Section 18, Act XI of 1859, are dealt with. (2)
Have any applications been refused? (3) If so, were the orders recorded by the Collector himself and
were the reasons for any refusal of receipt of arrears adequate?
6. In the case of estates sold (1) have notices under Sections 6 and 5, if
necessary, been served in the manner specified in those Sections, and (2)
have the costs of these notices been realised? (See Rule 9, page 181 of the
Sale Law Manual, 1936).
7. Does the Head Clerk of the Arrear Collection Department certify on the
final sale list that he has examined all such service returns and found them
correct? (Rule 15, page 166 of the Manual).
Register 19B(Sales held under the Bihar and Orissa Public Demands Recovery Act, IV of 1914)Vide
Certificate ManualRegister 20(Sales of Patni Taluqs under Regulation VII of 1819)
1. Has the application for sale been presented at the prescribed date, viz., 1st
Vaisakh or 1st Kartika?Bihar Board's Miscellaneous Rules, 1958

2. Were notices served as required by Section 8?
3. Has the prescribed fee of one per cent on sale-proceeds been realized and
credited in each case?
Registers 21 and 22Vide Loans ManualRegister 23(Of under-tenures sold under Bengal Act VIII of
1865)
1. What number of tenures was brought to sale during the past twelve
months?
2. Was notice served as required by Sections 4 and 5?
3. Has any sale been stopped on account of payment made?
4. Have certificate and possession been given to purchaser?
5. Have proceeds of sale been appropriated as required by Section 12?
6. Enquire whether any class of tenure which is not saleable has been sold
or, where the sanction of any authority is necessary to the sale, whether
such sanction has been obtained.
Register 25(Claims to money in deposit)(Ascertain that a separate volume of this Register is kept as
prescribed in Board's Circular 17 of December, 1892 for deposits connected with rent suits)
1. How many claims brought?
2. Examine a few claims and see (1) whether the reports of officers
concerned have been duly taken; (2) whether the claims have been properly
disposed of; (3) whether the nature of the deposit has been rightly entered;
(4) that Government claims are always deducted before refund of deposits;
(5) that the order for refund on the record states the amount in words as well
as in figures and is signed by the covenanted or Senior Deputy Collector to
whom the duty of passing orders of refund may have been delegated by the
Collector, and also by the Accountant.Bihar Board's Miscellaneous Rules, 1958

3. Is there undue delay in disposal of claims?
4. Is the record of refund noted in this register as well as in the record
showing the deposit and initialled by the clerk and the Deputy Collector who
deals with applications for refund?
5. Is the date of payment in Column 3 of the register initialled by the
accountant?
6. If the deposit was of longer date than three years, has the Commissioner's
or Accountant-General's sanction been obtained to refund?
Register 26(Inspection Book)
1. Is this Register kept in all departments?
2. Has every department a guard file of copies of the inspection remarks
relating to it made by the Collector, Commissioner or higher authority,
arranged in chronological order?
3.
(1)Has necessary action been taken on the orders passed? And (2) has brief note of action taken
been entered against the inspection notes?Register 26A(Standing order-book)
1. Is it properly kept up?
2. Are orders issued, carried out, and noted?
Register 27(Petitions)(To be examined in each office in which it is kept)
1. Examine some cases and see whether petitions have been entered in this
register in accordance with the instructions given at the top of the register
form.
2. Were receipts taken from the officers who received the papers after
registry?Bihar Board's Miscellaneous Rules, 1958

3. Are petitions in each Court taken as laid down in Rules 1 and 2, pages
88-89 of the Practice and Procedure Manual, 1939?
Register 28(Register of papers received other than process for service for which no other register is
prescribed)]
1. How kept? In what state?
2. Does an officer who receives papers after registry affix his signature to
Column 5?
Register 29(Precepts)1. How many received?
2. In how many cases has money been realised in full?
3. In how many parts?
4. What steps taken to realise the remainder?
5. Any precept countermanded in consequence of payments made
voluntarily into Court?
Register 30See under process-serving, page 273 postRegister 31(Admitted Probationers)Is the
register properly maintained?Registers 32 and 33(Government Estates)See Government Estates
ManualRegister 34(Estates managed by Revenue Authorities under Acts XXV of 1858, XL of 1858
and Bengal Act IX of 1879 or Act VIII of 1890)
1. Has the nature of disqualification been properly entered?
2. Has the number of dependent tenures been entered?
Register 35(Attached Estates)
1. Has the order of attachment been properly quoted?
2. Has it been ascertained from time to time whether disputes have come to
an end and whether attachment may cease or has ceased?
Register 35A(Ledger of sums received and expended on account of estates attached under Section
146 of the [Code of Criminal Procedure, 1898] [Now See Cr.P.C., 1973.])Bihar Board's Miscellaneous Rules, 1958

1. Is the register properly kept up?
2. Is general consolidated account prepared in case of large estates?
Register 36(Petty Estates)
1. How many redeemed?
2. Has the Commissioner's sanction been obtained in each case?
3. Is any application still pending?
4. Has the purchase-money been paid into the treasury?
Register 37(Revenue Fines)(To be examined in each Court in which fines are imposed)
1. Examine some records to ascertain that fines are properly imposed?
2. Ascertain steps taken to realize long outstanding fines and whether they
are sufficient.
3. See whether fines imposed under Section 58 of the Bihar Tenancy Act are
entered in this register.
Register 38(Prisoners)1. How many, and have warrant of arrest or imprisonment been properly
ordered?
2. Are dates of imprisonment and release properly entered?
Register 39 (New estates) and Register 40 (Alternations of Assessments)Vide Tauzi
ManualRegisters 41, 41 A, 41B, 41C, 41D and 42See Records ManualRegisters 43 and 44See under
process serving page [273] [Substituted for 325 by C.S. No. 4 dated 9.2.1963.] postRegister
45(Lands and houses owned by Ministerial Officers)
1. Have the landed properties of all ministerial officers (or held or managed
by their wives or dependants living with them) been entered in this register?
2. Are there any officers owing property situated within this District?Bihar Board's Miscellaneous Rules, 1958

3. Is the register revised every year as prescribed by Rule 102 of the Board's
Miscellaneous Rules, 1958? -
Register 58(Daily Register of Court-fees)
1. Is the register properly kept up?
2. Are the provisions of Rules 12 and 13 of the Rules issued under the
Court-fees Act observed? (Page 58 of the Bihar and Orissa Stamp Manual,
1940)
Register 64(of Territorial and political pensions)
1. Are the permanent-payable orders carefully kept in office?
2. Is it accurately noted in each case whether the pension is for life,
hereditary or perpetual and transferable?
3. Have the pensions been drawn regularly?
4. Has entry been properly made on each occasion?
5. Whenever a delay of more than one year has occurred in drawing a
pension, was the permanent-payable order forwarded to the Accountant
General?
6. Has the date of decease of any pensioner been noted?
Register 65(Recipients of malikana due to proprietors during the currency of a settlement and of
payment of such malikana)
1. Has the interest of each malik been carefully entered in the register?
2. Has the amount of malikana been properly distributed?
3. Do the maliks regularly draw their shares?
Register 66(Recipients of permanent malikana)Bihar Board's Miscellaneous Rules, 1958

1. Are all mutations properly noted?
Register 67(of particulars of newly-formed islands)
1. Have all newly-formed islands belonging to Government been entered in
this register?
2. Are enquiries made from time to time as to the fitness of the unsettled
islands for settlement?
Register 69
(Applications for| prospecting licencesmining leases| )
1. Have registers of applications for prospecting licences and mining leases
been opened (in mining districts)?
2. Are they properly kept up?
Register 69-A(Payments of Commission on account of khasmahal collections)See Government
Estates ManualRegister 70(of Witnesses)See in each Court and ascertain that witnesses are not
unduly detained.Register 73(Securities of ministerial and non-gazetted officers)
1. Have all officers who are required to furnish security under Chapter X of
the Board's Miscellaneous Rules, 1958 done so?
2. Have bonds in the prescribed forms been executed in all cases and has the
amount of the security been calculated upon a proper basis?
3. Have the security bonds of all the officers, except peons, been sent to the
Inspector-General of Registration? If not, what are the exceptions and why
have they not been sent to the Inspector-General?
4. In cases in which security is being deposited by instalments, have all
payments been made regularly up to date?
5. In cases in which security has been given in landed property, has proper
action taken to test it and steps taken to replace it, if found inadequate or
invalid?Bihar Board's Miscellaneous Rules, 1958

6. Has periodical enquiry been made regarding the validity of security bonds
and steps taken to replace the bonds which have been found to be
inadequate or invalid?
7. Is one officer allowed to stand surety for another in the same office?
(Rule 221, Board's Miscellaneous Rules, 1958).
8.
(1)Is an index showing the names of officers liable to give security whether they have given security
or not, kept and entered in the register and has the last entry in Part I been signed by the Deputy
Collector incharge of the Security Register?(2)Has the Deputy Collector incharge certified that the
index is complete and that no names have been omitted and has he signed Part II of the index?
(Rule 232 of the Board's Miscellaneous Rules, 1958).Register 81(Chaukidari Chakran lands)See
what progress is made in transfer of such lands and whether the procedure followed in the case
record is correct.Register 86(Register of valuation of property for probate)
1. Is Rule 4 of the Board's Circular Order No. 3 of March, 1902 (page 72 of the
Stamp Manual, 1940), as to careful election of officers to make enquiries in
these cases observed?
2. Examine the procedure in some of the case records and ascertain that it is
correct.
(See page 60 of Register and Return Manual)Register 8(Of rent suits and applications under the
Chota Nagpur Tenancy Act)
1. Number of cases in these registers.
2. How many disposed of and how many pending?
3. What are the arrears, if any, due to.
4. Examine some of the records and ascertain (1) whether in cases decreed
ex parte notices have been properly served, (2) whether exhibits have been
properly marked, (3) whether evidences have been properly recorded, (4)
whether the judgements are sound and sufficient, (5) whether costs have
been correctly calculated, and (6) whether procedure is generally correct.Bihar Board's Miscellaneous Rules, 1958

5. Examine some cases where damages have been awarded and see whether
the Deputy Collector has stated his reasons for such award and whether the
reasons are adequate.
Register 9(Register of Decrees)
1. How many cases instituted?
2. In how many was objection made?
3. How many are pending, and has there been unusual delay in any case.
4. Examine some records of sale of tenure or holding and ascertain that the
procedure has been correct.
Registers 10 and 11(Notices of deposit)
1. For how many cases have deposits of rent been made?
2. Is there an increase during the past twelve months? If so, why ?
3. Examine a few cases and see if applications for withdrawal are promptly
disposed of ?
Bihar Tenancy Act Registers(See page 67 of the Register and Return Manual)Register
II(Applications for commutation of rent under Section 40)Examine some of the case records and see
whether the procedure has been proper and equitable.Register III(Appraisement or division of
crops, Sections 69 and 70)Examine some of the case records and see whether the procedure has
been proper and equitable.Register IV(Applications for registration of improvements under Section
80)
1. Examine some of the case records and see whether the procedure has
been proper and equitable.
2. Is the officer careful to record the tenants' contribution to any
improvement in labour or otherwise, as well as the landlord's contribution?
Register V[Applications to record evidence of improvements under Section 81 (1) and to decide
questions of right to make improvements under Section 78(a) and 78(b)]Examine some of the case
records and see whether the procedure has been proper and equitable.Register VI[Notices of
landlord's intention to enter an abandoned holding under Section 87 (2)]Examine some of the caseBihar Board's Miscellaneous Rules, 1958

records and see whether the procedure has been proper and correct.Register VII[Applications for
record-of-rights under Sections 101(2)(a) or 103]1.1Examine some of the case records and see
whether the procedure has been proper and equitable.
2. Are such applications encouraged and promptly dealt with?
Register VIII(Applications for determination of proprietor's private land, Section 118)Examine some
of the case records and see whether the procedure has been proper and equitable.Register
IX(Notices of annulment of encumbrances)Examine some of the records of notices and see whether
the procedure has been correct.Miscellaneous Registers(Prescribed for maintenance by the Collector
under rules not issued by the Board).Register of Civil Suits
1. Were the circumstantial report and draft plaint drawn up by the
Government Pleader submitted to the Legal Remembrancer?
2. Was sanction to the suit given by him?
3. Number instituted?
4. Number decided and with what result?
5. Number pending?
6. Is any Deputy Collector in charge of this department?
Register of Government Decrees
1. How many decrees registered?
2. What is the total amount?
3. How much has been realised?
4. Amount unrealised?
5. What steps have been taken to realise the arrears?
Register of Pauper SuitsBihar Board's Miscellaneous Rules, 1958

1. Number registered?
2. Total amount?
3. Amount realised?
4. Arrears?
5. What steps taken to get in the balances?
Files of Powers-of-Attorney
1. Are they duly maintained?
Nazir's Office and Malkhana(1)Nazir's Accounts and Stock(The Nazir should keep a cash-book with
subsidiary registers, a treasury remittance book, a Stock and Store-Register, a daily account of
saleable forms sold and receipt book).IA. (a) In the last three years how often has the
officer-in-charge been changed?(b)In the last three years how often has the head ministerial officer
been changed?(c)What is the name of the officer in charge and how long has he been in
charge?(d)What is the name of the head ministerial officer and how long has he held the
appointment?
1. Does the cash in hand correspond with the balance as per cash book?
2. Does the cash-book show, in addition to other entries, the daily totals of
receipts and payments included in the several subsidiary registers kept up
by the Nazir?
3. Is the acquittance-roll kept in the proper form, and are all receipts for sums
above [Rs. 500] [Substituted for Rs. 20 by Finance Act, 1994 (Act 32 of 1994).]
duly stamped?
4.
(1)Are the stock and store register and Register 48 (of locks and keys) duly kept up?(2)And is a list
kept of office furniture, tents and tent-equipages?(3)Are they signed by a responsible officer?
5. Are the tents in good condition?Bihar Board's Miscellaneous Rules, 1958

6. What precautions are taken to protect them from white-ants and damp?
7. Are there any surveying instruments in store, and, what is their present
condition?
8.
(1)Is the account of contingent charges properly kept, and is the permanent advance recouped at
intervals?(2)Is the monthly statement prescribed by Government Order No. 1394 TF dated the 6th
July, 1903, kept up and is expenditure watched as therein directed?(3)Notice any unusual
expenditure and consider whether the annual grant will suffice ?
9.
(1). Are the accounts of receipt and sale of (1) printed forms, (2) law books, and (3) zincographed
maps properly kept, and does the balance shown in the account tally with actual number in stock?
10. Are the sale-proceeds regularly paid into the treasury and accounted for
in the treasury remittance book?
11.
(1)Does the Nazir keep an account of service postage stamps?(2)Does the stock in hand tally with
the balance?(3)Is the service postage account regularly examined and initialled by the
Superintendent?
12.
(1)Does the Accountant initial each entry in the Nazir's treasury remittance book?(2)Are the entries
of Rs. 500 and over also initialled by the Treasury Officer and those below Rs. 500 by the Treasurer?
13. What kinds of fines are recovered by the Nazir?
14. Are the recoveries duly recorded in the registers and paid into the
treasury?
15.
(1)Is a cheque receipt-book kept for all process-fees and for sums paid in as travelling allowances of
witnesses?(2)If unexpended, are the amounts transferred to deposit after the interval of a month
from the final disposal of the case?Bihar Board's Miscellaneous Rules, 1958

16. Is a notice suspended in the Nazir's department, stating that he must give
receipts for process-fees, and that payment without such receipt is at the risk
of the payee?
17. What kinds of payments are received from other districts, and how are
they disposed of?
18. Are sums paid in satisfaction of decrees properly and promptly disposed
of?
19. 1s money paid for witnesses and civil prisoners accounted for and
properly disposed of?
20. What is the longest period during which any public money (except the
permanent advance) has been in the Nazir's custody?
21. Does the Superintendent examine the Nazir's books and accounts? When
did he do so last, and with what result?
22. Does the Assistant or Deputy Collector in charge of the Nazir's
department, at the close of each month, satisfy himself and certify to the
Collector that the Nazir's accounts and stock and store registers are properly
kept?
(2)Process-serving(Registers 30, 43 and 44; see also the peon's diaries)
23. How many salaried and occasional peons are under the Nazir?
24. Does each peon wear, when on duty, a badge bearing the number by
which he is shown in the register?
25.
(1)What number of processes was served by each during the past three months?(2)Does it come up
to the prescribed standard?(3)And is there sufficiently high percentage of personal service?
(Circular No. 18 of September, 1904).Bihar Board's Miscellaneous Rules, 1958

26. Does the establishment admit of reduction?
27. Are the peons able to read and write their vernacular language and has
each a copy of the Rules for the service of process?
28. Are the Rules for the service of processes suspended in the Nazir's room,
and are they understood by him and his peons?
29. Are the Rules for the issue of processes and guidance of Nazir's
prescribed in Part III, Chapter II of the Practice and Procedure Manual, 1939,
observed?
30.
(1)Are the peons' diaries properly kept in loose sheets, and promptly submitted?(2)Are suitable
orders passed on them?(3)Who examines the diaries and checks them against column 13 of Register
43?
31.
(1)Are peons fined who do bad work and are the fines distributed among peons who do well?(2)Are
fines and rewards of peons noted in their service books at the end of the year? (Circular Order No. 2
of April, 1907).
32.
(1)Are the registers of processes and peons Nos. 43, 44 and 30 properly kept up?(2)And are they
examined by the Superintendent regularly?
33. Are original and duplicate processes entered in Register 43 in
accordance with Board's Circular No. 5 of April, 1907?
34. Compare Columns 12 and 15 of Register 43 to see if processes are
usually returned by due date to offices in and outside the District and when
necessary check Register 11 (kept in other departments) against Register 43.
34.
-A. Are all processes for the realisation of money entered in Register 43-A, and not in Register 43?Bihar Board's Miscellaneous Rules, 1958

35. What is the arrangement for service of processes in the sub-divisions?
36. Does the Nazir know the district and has he a map?
37.
(1)Are cheque books supplied to the peons properly numbered and certified by a Gazetted
Officer?(2)Are cheque books kept under lock and key with the register showing the cheque books
issued to the peons and the date of their return?(3)Does the Nazir initial the counterfoils
representing payment on return of any processes for recovery of money by a peon?Appendix H(See
Rule 151)Rules for the guidance of officers making appointments to ministerial or other posts in
Bihar.N.B. - These Rules apply to all appointments not made under any special Rules and orders.
Part I
1. All vacancies, whether permanent or temporary, which are not filled by
promotion from within the same office or by the appointment of a probationer
already admitted to the office in conformity with these Rules, should be duly
advertised in the Bihar Gazette.
The notification in the Gazette will be in the following form;-
1. Office.
2. Post vacant and pay.
3. Qualifications required.
4. Officer to whom application should be made.
5. Date by which application should be submitted.
The date given in Column 5 must not be less than 14 days from the date of the publication of the
Gazette, and it shall be the duty of the Press Reader-in-Charge of the Gazette to see that date is
correct and to bring to notice of the office issuing an advertisement any case in which this Rule is
not observed. All such advertisements should reach the Press at Gulzarbagh not later than 4 p.m. on
Monday preceding the date of publication.The press will supply 40 spare copies of the
advertisement to the officer concerned, who will send copies to the Secretaries of all Bar Libraries
throughout the province. Vacancies must also be advertised in the Press. In order to avoid needless
expenditure, advertisements in the Press should be in a considerably shortened form and may, if
necessary, refer applicants for details to the Gazette advertisement.Bihar Board's Miscellaneous Rules, 1958

2. No person, who is not a native of, or domiciled in the State should be
appointed to any post, whether permanent or temporary, carrying a pay of
Rs. 25 a month or over without the sanction of the local Government,
obtained through the proper channel; nor should any such person be
appointed to any post carrying a pay of less than Rs. 25 a month without the
sanction of the authority immediately superior to the officer making the
appointment. This Rule is equally applicable to the case of all non-domiciled
persons whatever be the country of their origin, including such of them as
may already hold an appointment in another Government office in Bihar.
3. A statement in Form A giving full particulars relating to all applicants
together with a copy of the notice advertising the vacancy, should be
submitted with the applications for sanction under Rule 2.
4. The operation of Rules 1 and 2 may be suspended temporarily in cases of
a really urgent nature, the circumstances of each such case being reported
as soon as possible to the authority, whose sanction ought to have been
obtained under Rule 2, whose decision shall prevail.
5. No person should be regarded as domiciled in the province unless he can
produce a certificate to that effect from the District Officer of the district in
which he claims to be resident.
6. A list should be prepared and maintained in each office of all new
appointments, whether permanent or temporary, made since its first
establishment on the creation of the province and a return in Form B of the
appointment made during each year should be submitted to the local
Government in the Administrative Department on or before the 15th of
February of the following year.
Form A(Referred to in Rule 3)Statement giving particulars of candidates
1. Serial number.
2. Description of post to which it is proposed to appoint.Bihar Board's Miscellaneous Rules, 1958

3. Name of applicant.
4. Home district and district of domicile, if any.
5. Age.
6. Educational or other qualifications.
7. Previous experience, if any.
8. Summary of certificate of character, mentioning names of persons who
gave them.
9. Remarks of the officer authorised to make the appointments as to why he
wishes to appoint or reject the candidate.
Form B(Referred to in Rule 6)Annual return showing nationality of officers selected to fill new
appointments during 20
Period Biharies AboriginalEuropean and
Anglo-IndiansOthersReference orders of
Government or of
any othersuperior
authority in the cases
shown in Columns 5,
6 & 7
Hindus Muhammadans Christian Non-Christian Domiciled Non-domiciled
1 2 3 4 5 6 789
Up to the end
of[20] [The
year preceding
that for which
the return is
due.]        
During[20]
[The year for
which the
return is due.]        
Total         
N.B. - The information in column 8 is required only in respect of the year for which the return is
due.Bihar Board's Miscellaneous Rules, 1958

Part II – Rules regarding Certificate of Domicile
N.B. - These rules apply to certificates of domicile granted under Rule 5 above and also to those
granted under any special rules or orders of the local Government.
7. An application for a certificate of domicile must be made in Form D and
must bear a court-fees stamp of 12 [annas] [Now, New paise.] under Article
1(b) of Schedule II of the Court-fees Act. If any incorrect statement is made in
the application and privilege or appointment given in consequence to the
applicant will be liable to be cancelled summarily.
8. No certificate should be given unless :-
(1)the applicant is a candidate for a specified appointment under Government or a local body or
intends to file an application for such an appointment within the next six months.(2)he intends to
apply for a scholarship or a vacancy in an educational institution.
9. When a District Officer receives an application he should, if the conditions
of Rule 8 are fulfilled, draw up a regular proceeding, require the applicant to
state fully the grounds of his claim, if these are not fully stated in the
application and ascertain the evidence on which the claim is based.
The burden of proof lies on the applicant and no certificate should be granted unless he is able to
satisfy the District Officer that he is permanently settled in the province, that he has adopted it as
his home, and that he had no intention of returning to reside in his country of origin.
10. Special care is necessary in scrutinizing applications where the domicile
claimed is of recent origin. The fact that the family owns a place of residence
in the province or that the children have been educated in the province,
though relevant, is by no means conclusive but should be considered
alongwith all the circumstances of the case. Residence merely for the
purpose of carrying on a business or trade, or subject to the provisions of
rule 11, for the performance of duties of a public office, should not be
regarded as establishing a claim to domicile. The requirement that the
domicile should be permanent necessitates evidence of the persistence of
the intention over some period of time ;the mere declaration of intention is
not sufficient there should be continuing evidence of actual effect having
been given to it.Bihar Board's Miscellaneous Rules, 1958

11. Where the applicant is the son of a Government servant, who served in
Bihar and Orissa continuously since the partition of 1912, and where there
are good grounds for believing that the Government servant in question has
settled in the province, but owing to lack of means or the circumstances of
his service, has been unable to acquire a residence of his own, the fact that
he has not acquired a residence does not preclude the grant of a domicile
certificate.
12. The District Officer may entrust to a reliable subordinate officer the duty
of verifying the evidence upon which the claim rests, but in all cases the
District Officer must himself consider the evidence and decide whether a
certificate should be granted.
13. The reasons which have satisfied the District Officer as to the validity of
the claim should be fully stated in the proceeding and should also be briefly
recited in the certificate itself.
14. A register in Form C should be maintained in every district showing the
certificates granted and briefly the reasons for the grant.
15. A grant of a certificate must depend on proved facts and not on favour
and recommendations from non-official gentlemen in favour of applicants
should be discouraged.
Form CRegister of Certificates of Domicile(Referred to in Rule 14)(Government Circular No.
3500-A. R. dated the 8th October, 1936)
Serial No.Name of person to whom granted
and father's namePlace of
residenceBrief statement of reasons which
are held tojustify the grant of a
certificate
1 2 3 4
    
Form D(Referred to in Rule 7)Application for a certificate of domicile(1)Name of applicant and
father's name.(2)Place in which domicile is claimed.(3)The number of generations for which the
family has been domiciled in Bihar.(4)Whether he or any member of his family has made an
application previously for a domicile certificate. If so, whether the certificate was granted.(5)The
purpose for which the applicant requires a certificate.(6)Whether the applicant or his parents
possess a residence in the province. If so, the situation and date of acquisition must be
stated.(7)State all the educational institutions at which the applicant has been educated.(8)Grounds
upon which a certificate is claimed.Note. - Applicants are warned that all particulars stated in thisBihar Board's Miscellaneous Rules, 1958

application must be given in full and that, if any incorrect statement is made in the application, any
privilege or appointment given in consequence to the applicant will be liable to be cancelled
summarily.Appendix I(See Rule 164)General principles to be observed in regard to public servants,
who have been removed or dismissed.
No.| 10-Public919| Simla, dated the 15th June, 1895.
From-J.P. Hewett, Esq. C.L.E., Officiating Secretary to the Government of India, Home
Department.To-The Chief Secretary to the Government of Bengal
In the circular letter from this Department No.| 10-Public1085-1094| , dated the
21st. June, 1894, the Government of India enquired what rule was observed
with regard to giving Government officers necessary information as to
dismissals of public servants; whether any difference was made between
cases where reemployment is prohibited and where it is not; and whether in
any case of dismissal, in which it is decided to issue a public notification, the
cause which led to the dismissal is specified. The replies received to the
letter of 21st June show that a uniform practice is not observed in the
different provinces in dealing with this matter. The Governor-General in
Council accordingly deems it desirable to state the general principles which
should be observed in disposing of such cases.
2. In the first place, His Excellency in Council desires to direct attention to
the distinction that exists between the removal or discharge and the
dismissal, of a public servant. Removal from the office for such a cause as
unfitness for the duties of the office need not usually entail any further
consequences. It ought not bar reappointment to another office, for the
duties of which the person may be suited and it should not be accompanied
by any subsidiary orders which would operate as such a bar or otherwise
prejudice the person in question. Removal should be the penalty in all cases
where it is not thought necessary to bar future re-employment under
Government.
3. In cases of dismissal, on the other hand, the effect of the order should be
to preclude the dismissed officer from being re-employed. Ordinary cases of
the dismissal of non-gazetted officers need not be notified in the Government
Gazette. As a precaution against the inadvertent re-employment of men who
may have been dismissed, it would be sufficient to rule that officers should
ascertain whether an applicant for a post has been in Government service,
before, and should refer to his previous employer if the circumstances
connected with his discharge are not clear. The applicant should be requiredBihar Board's Miscellaneous Rules, 1958

to produce a copy of his character book or other record of service, and a
person who succeeds in obtaining employment by the concealment of his
antecedents would obviously merit dismissal on the true facts being
discovered. The sanction of the local Government or Administration should
always be required to the re-employment of persons dismissed.
4. The dismissal of public servants, should the Governor-General in Council
considers, be notified in the Gazette only in the following cases, viz. (1) when
it is necessary to notify the public of the removal from service of an officer,
whether because his appointment was previously gazetted or from any other
cause, and (2) when it is specially desired to exclude from re-employment in
the service of Government a public servant who has been dismissed for a
heinous offence, such as fraud or falsification of accounts.
5. The reason for the dismissal of a public officer should not be stated in the
notification regarding his dismissal, even in cases in which a conviction has
been obtained in a Criminal Court. It will be sufficient to announce in the
case of any person whose dismissal will be notified in accordance with the
principle laid down in Paragraph 4 of this circular, that the Government has
dispensed with his services, except in those cases in which the cause of
dismissal constitutes a disqualification under the terms of the law regulating
the tenure of a particular appointment, and it is for this reason necessary to
couple with the announcement of the dismissal a statement of the grounds
upon which it has been ordered.
6. The Government of India leave it to the local Governments to make such
arrangements as they think necessary for securing that officers serving
under them are informed what Government servants, other than those whose
dismissals have been gazetted, have been dismissed.There is not before the
Government of India sufficient evidence to show that it is necessary to
communicate such information between provinces, if the precautions
abovementioned are taken by officers when making appointments to vacant
posts.
[Appendix -J] [Substituted by C.S. No. 19, dated 28th July, 1969.](See Rules 165-168)No.
III/RI-2033/52A/188Government of BiharAppointment DepartmentFrom,L.P. Singh, Esq., I. C.
S.,Chief Secretary to Government.To,All Departments of Government.All Heads of Departments.All
District Officers (including the Additional Deputy Commissioners, Dhanbad and Chaibasa, and theBihar Board's Miscellaneous Rules, 1958

Additional District Magistrate, Saharsa).Dated Patna, the 9th January, 1953.Subject. - Principles to
be followed in ordering suspension.Sir,I am directed to say that instances have come to the notice of
Government in which Government servants required to answer charges in Courts of law or in
departmental enquiries had to remain under suspension for inordinately long periods. The
procedure prescribed for conducting departmental proceedings is elaborate, and makes some delay
in their disposal inevitable. While Government are anxious that departmental proceedings should be
disposed of speedily, they are equally keen to ensure that a Government servant should not be
placed under suspension for inadequate reasons or kept under suspension for a long period. The
practice of keeping Government servants under prolonged suspension is not in the interest of the
public service. Some of the disadvantages of this practice are noted below :-(i)Under the Rules the
vacancy caused by the suspension of a Government servant cannot be filled substantively, with the
result that no stable arrangements can be made for the disposal of work.(ii)Prolonged suspension of
a Government servant even if followed by dismissal or removal entails considerable financial loss to
Government as he received subsistence allowance until final orders are passed in the
proceedings.(iii)Where the suspended Government servant is finally acquitted of the charges against
him, his prolonged suspension causes needless harassment to him. The stigma attached to
suspension is not wholly removed, even if the Government servant is finally exonerated.To the
public, he appears as something of an ex-convict with the result that his utility to Government is
reduced, if not for his whole service, at least for some years.(iv)If a Government servant is under
suspension for a long time he begins to receive sympathy which, in most cases, considering the
nature of the offence, he does not deserve, and it sometimes happens that the authority passing final
orders is, consciously or unconsciously influenced by this sympathy, and awards a lenient
punishment. The net result is the continued association with the public service of a person who is
not really fit to be retained in the public service.
2. While the prolonged suspension of a Government servant is undesirable, it
is often difficult for the competent authority while placing him under
suspension, to anticipate whether or not the period of his suspension would
be prolonged. There have also been cases in which Government servants
were suspended as a matter of routine when proceedings against them were
ordered, without regard to the nature of the charges against them and the
evidence available to support the charges. With a view to ensure that
suspension is ordered only in cases where it is fully justified, the State
Government have been pleased to order that the following principles should
be followed while taking a decision to suspend a Government servant.-
I. Cases in which a Government servant is facing trial in a criminal Court.-(i)If a Government
servant is being prosecuted on a criminal charge, he should be placed under suspension if he has
been refused bail by the Court and has been committed to prison.(ii)In cases of criminal
prosecution, a Government servant should be suspended if the charges against him are such that on
being found guilty of it, he is likely to be sentenced to a term of imprisonment, or on which he
should be dismissed or removed from a service, in a departmental enquiry. In such cases, however,Bihar Board's Miscellaneous Rules, 1958

the order of suspension need not be passed in every case immediately after cognizance has been
taken. In suitable case it may be passed after charges have been framed.II. Cases in which
Government servants are proceeded against, either departmentally or under the Public Servants'
(Inquiries) Act, 1850. - Where a Government servant is being proceeded against departmentally or
under the provisions of the Public Servants' (Inquiries) Act, 1850, on charges of gross misconduct or
bribery or corruption the question of suspension should be considered with reference to the prima
facie evidence available against him. If there are good reasons to believe, on the basis of the material
available at the time of the initiation of the proceedings, that the Government servant has been
guilty of gross misconduct or of bribery or corruption which, if proved, would lead to his dismissal
or removal, he should be placed under suspension. In cases in which such prima facie evidence is
lacking at the start the question of suspension of the Government servant may be kept pending till
the findings of the Enquiring Officer are available. In such cases it should be considered whether the
accused officer should be required to proceed on such leave as may be due to him and if there is no
leave to his credit, on extraordinary leave. On the conclusion of the enquiry, if it is found that the
Government servant is guilty of gross misconduct, or of bribery or corruption which would entail his
dismissal or removal from service, he should be immediately placed under suspension, even though
some further steps, such as giving him an opportunity to show cause against a particular
punishment, and consultation with the Public Service Commission, have to be taken before final
orders can be passed.
3. In all cases where there are reasons to believe that the Government
servant, if allowed to continue in active service, might attempt to tamper with
the evidence, he should be required to proceed on such leave as may be due
to him or if there be no leave to his credit, on extraordinary leave. If he
refuses to proceed on leave, he may be suspended.
4. I am to request that these instructions should be carefully followed in
future and should be brought to the notice of all officers subordinate to you
who have not been informed direct.
Yours faithfully,L.P. Singh,Chief Secretary to Government.Memo. No. III/R
I-209/60-A-4698Government of BiharAppointment DepartmentTo,All Departments of
Government.All Heads of Departments.District Officers.Patna, the 15th Chaitra 1882/4th April,
1960.Subject. - Principles to be followed in ordering suspension.The undersigned is directed to say
that in supersession of all previous instructions on the above subject, the State Government have
been pleased to order that the following principles should be followed while taking a decision to
suspend a Government servant:-(1)If a Government servant is facing trial in a criminal Court, he
should be suspended if he has been refused bail and committed to prison.(2)If a criminal charge
made against him is such that on being found guilty, he is likely to be sentenced to a term of
imprisonment or on which he is likely to be dismissed or removed in a departmental enquiry, he
should be suspended immediately after charges have been framed.(3)In cases where a Government
servant is being proceeded against departmentally, if there are good reasons to believe on the basis
of materials available at the time of initiation of the proceedings that he has been guilty of grossBihar Board's Miscellaneous Rules, 1958

misconduct or corruption which if proved, will lead to dismissal or removal, he should be suspended
even if the suspension is likely to continue for long time.(4)In all cases where there are reasons to
believe that a Government servant if allowed to continue in active service might tamper with the
evidence, he should be required to proceed on leave as may be due to him, or if there be no leave to
his credit, on extraordinary leave. If he refuses to proceed on leave, he may be suspended.(5)Even in
cases which do not fall into any of the categories mentioned above, the power and discretion of
Government or of the appointing authority to order suspension will remain unimpaired if there are
special circumstances warranting such action.(6)Although suspension during the pendency of an
enquiry is not a punishment, there is a stigma attached to it which is not wholly removed, even if the
officer is later exonerated. An order of suspension should, therefore, be passed only after very
careful consideration. Care should also be taken to see that the period of suspension is not unduly
prolonged because of delay in the disposal of the enquiry or proceedings. Attention is invited in this
connection to Rule 28(ix) of the Rules of Executive Business, according to which any proposal to
suspend a gazetted officer is to be submitted to the Chief Minister through the Chief Secretary
before the issue of orders.The above instructions should be followed carefully in future and should
be brought to the notice of all officers subordinate to you.M.S. Rao,Chief Secretary to
Government.No. A-189Government of BiharAppointment DepartmentFrom,L.P. Singh, Esq., I. C.
S.,Chief Secretary to Government.To,All Secretaries to Government.All Heads of
Departments.Commissioners of Divisions.District Officers (including Additional Deputy
Commissioner, Dhanbad and Additional District Magistrate, Saharsa).Patna, the 9th January,
1953.Subject. - Speedy disposal of disciplinary cases against Government servants.Sir,I am directed
to say that Government have noted with grave concern the inordinate delays which are frequently
coming to their notice in the disposal of disciplinary cases against Government servants.
Government attach great importance to the prompt investigation and speedy disposal of disciplinary
cases and have issued instructions from time to time emphasising the desirability of expeditious
disposal of such cases. Judging from the instances which have come to their notice, Government,
however, feel that these instructions are not being followed. They, therefore, desire that all officers
entrusted with the conduct of disciplinary enquiries should meticulously follow the instructions
contained in the following paragraphs.
2. Delays in the disposal of disciplinary cases are generally to be attributed
to the tendency on the part of the enquiring officer to allow the same
privileges to the accused in departmental proceedings as would be
admissible to him in a criminal trial. Taking advantage of this attitude of the
enquiring officer, the accused officer resorts to dilatory tactics and manages
to prolong the enquiry and, at times, to tamper with the evidence. The
procedure prescribed in Rule 55 of the Civil Services (Classification, Control
and Appeal) Rules, Rule 2 of the Subordinate Services (Discipline and
Appeal) Rules and other Rules on the subject should certainly be followed by
the officers conducting departmental proceedings. The essential
requirements of these rules are that the charges against the accused shall be
reduced to writing, that he shall be given adequate opportunity of puttingBihar Board's Miscellaneous Rules, 1958

forward his defence, both orally and in writing, and that he shall be allowed
to cross-examine the prosecution witnesses and to call witnesses, in his
defence. In cases where it is proposed to impose the penalty of dismissal,
removal or reduction, the accused has, after the completion of the enquiry, to
be given a further opportunity of showing cause against the particular
penalty proposed to be imposed on him. In such cases after the enquiry
against a Government servant has been completed and the authority
empowered to pass final orders has arrived at a provisional conclusion in
regard to the penalty to be imposed, the. accused officer has to be supplied
with a copy of the report of the enquiring authority and has to given an
opportunity to show cause against the penalty proposed to be inflicted.
Government feel that expedition in the conduct of departmental proceeding
can be secured without departing from the prescribed procedure or doing
injustice to the accused, if all officers who have to deal with disciplinary
cases adhere to the following timetable through the different stages of the
proceedings-
(i)After the accused Government servant has been furnished with a copy of the charges on which it
is proposed to take action against him, he should be required within a fort night to put in a written
statement of his defence and to state whether he desires to be heard in person. Save for exceptional
reasons no adjournment should be allowed if the accused fails to submit his written statement of
defence within this time-limit.(ii)If it is decided to hold an oral enquiry, the examination and
cross-examination of the prosecution and the defence witnesses should be completed within a
month. Save for exceptional reasons to be recorded by the enquiring officer in writing,
cross-examination of witnesses must follow immediately their examination-in-chief. A date should
be fixed by the enquiring officer within the time-limit on which the accused be asked to call his
witnesses and he should be warned that if he does not produce his witnesses on the date fixed, the
proceedings will be concluded.(iii)After the completion of the evidence, the enquiring officer must
record his finding on each charge within a period of two weeks.(iv)If it is provisionally decided to
impose the penalty of dismissal, removal or reduction the accused officer should immediately be
supplied with a copy of the report of the enquiring officer and be called upon to show cause within
two weeks against the penalty proposed to be inflicted. Final orders should be passed within two
weeks of the date on which cause is shown.(v)Where orders of Government are required in a
disciplinary case, the following procedure should be adopted by the Secretariat Department
concerned.As soon as the report of the enquiring officer is received in the department the Registrar
will scrutinise it to see that the correct procedure has been followed in the enquiry. He will also
collect, and put with the record, any previous papers and precedents merely giving references to
these and not commenting on the merits of the case. The case will not be sent to the office for notice.
The Registrar will then submit the case to the Secretary, whose duty will be to comment on the
findings of the enquiring officer and recommend the punishment to be awarded, noting whether or
not the Public Service Commission has to be consulted. If a reference to another department isBihar Board's Miscellaneous Rules, 1958

considered necessary the case should be sent to that department with a clear indication of the
precise points on which advice is sought and a summary of the case, to save that Department from
the trouble of going through all the papers. In that Department the Secretary only will deal with the
case. When a reference to the Public Service Commission is not necessary, it should normally be
possible for the orders of Government to be obtained and issued within one month of the receipt of
enquiring officer's report in the Secretariat. If consultation with the Public Service Commission is
required, it should be possible to issue final order within 1½ months. If these time-limits are
exceeded, the Department should submit an explanation to the Minister-in-charge. These cases
should be treated as "immediate" at all stages.
3. Government desire that the time-limits indicated above, should be
rigorously enforced and in exceptional cases where an extension of the time
is allowed, full justification for the extension should be recorded in the
order-sheet of the proceedings. Government also trust that ail officers
entrusted with the conduct of departmental proceedings will firmly resist any
tendency on the part of an accused officer to adopt dilatory tactics, and will
constantly bear in mind the necessity of expeditious disposal of the
proceedings, particularly of those relating to charges of bribery and
corruption.
4. I am to request that these instructions may be communicated to all officers
subordinate to you who have not been informed direct. I am also to request
that whenever an officer is asked to conduct a departmental proceeding a
copy of these instructions should be furnished to him. I am to add that
Government will take disciplinary action against any officer who delays the
disposal of such proceedings, and that in fact, such action has already been
taken against an officer of an All India Service.
Yours faithfully,L.P. Singh,Chief Secretary to Government.No. III/RI-1026-63-A-10192Government
of BiharAppointment DepartmentFrom,Shri S.J. Majumdar,Chief Secretary to Government.To,All
Secretaries to Government.All Heads of Departments.Commissioners of Divisions.All District
Officers.Patna, the 23rd August, 1963.Subject. - Speedy disposal of disciplinary cases against
Government servants.Sir,I am directed to repeat with slight modifications the instructions issued
with Sri L.P. Singh's Letter No. A-189, dated the 9th January, 1953. Government desire that you
should ensure that these orders are carried out properly; take firm action (including institution of
departmental proceedings) against any one neglecting to carry out these instructions and report to
Government any lapse serious enough to call for Government's notice. Government have noted with
grave concern instances of inordinate delay in disposal of disciplinary cases against Government
servants. Government attach great importance to prompt investigation and speedy disposal of
disciplinary cases, and have issued instructions from time to time emphasising the desirability of
expeditious disposal of such cases. Yet these instructions are not being followed. Government,Bihar Board's Miscellaneous Rules, 1958

therefore, desire that all officers entrusted with the conduct of disciplinary enquiries should
meticulously follow the instructions contained in the following paragraphs.
2. Delays in the disposal of disciplinary cases are generally to be attributed
to the tendency on the part of the enquiring officer to allow the same
privileges to the accused in departmental proceedings as would be
admissible to him in a criminal trial. Taking advantage of this, the accused
officer resorts to dilatory tactics and manages to prolong the enquiry and, at
times, to tamper with the evidence. The procedure prescribed in Rule 55 of
the Civil Services (Classification, Control and Appeal) Rules, Rule 2 of the
Subordinate Services (Discipline and Appeal) Rules, and other Rules on the
subject should certainly be followed by the officers conducting departmental
proceedings. The essential requirements of these rules are that the charges
against the accused shall be reduced to writing, that he shall be given an
adequate opportunity of putting forward his defence, both orally and in
writing, and that he shall be allowed to cross-examine the prosecution
witnesses and to call witnesses in his defence. In cases where it is proposed
to impose the penalty of dismissal, removal or reduction, the accused has,
after the completion of the enquiry to be given a further opportunity of
showing cause against the particular penalty proposed to be imposed on
him. In such cases after the enquiry against a Government servant has been
completed and the authority empowered to pass final orders has arrived at a
provisional conclusion in regard to the penalty to be imposed the accused
officer has to be supplied with a copy of the report of the enquiring authority
and has to be given an opportunity to show cause against the penalty
proposed to be inflicted. Government feel that expedition in the conduct of
departmental proceedings can be secured without departing from the
prescribed procedure or doing injustice to the accused, if all officers who
have to deal with disciplinary cases adhere to the following time-table
through the different stages of the proceedings:-
(i)After the accused Government servant has been furnished with a copy of the charges on which it
is proposed to take action against him, he should be required within four weeks to put in a written
statement of his defence and to state whether he desires to be heard in person. Save for exceptional
reasons no adjournment should be allowed if the accused fails to submit his written statement of
defence within this time-limit.(ii)The Enquiring Officer will make sure that copies of all relevant
documents required in defence are made available to the accused officer, as quickly as possible. The
Head of the Office will please ensure there is no delay whatever in making copies of relevant papers
available to the accused Government servant. Experience suggests that the Head of the Office mayBihar Board's Miscellaneous Rules, 1958

make someone personally responsible for seeing that this is done. Decision on which papers are to
be made available should be arrived at quickly, bearing in mind that the proceedings are apt to be
set aside, and much time and trouble wasted, if the accused is prejudiced in his defence. Detailed
instructions on this subject were issued with Mr. B.K. Dubey's Letter No. A-5532, dated the 29th
April, 1963.(iii)If it is decided to hold an oral enquiry, the examination and cross-examination of the
prosecution and the defence witnesses should be completed within a month. Save for exceptional
reasons to be recorded by the enquiring officer in writing, cross-examination of witnesses must
follow immediately their examination-in-chief. A date should be fixed by the enquiring officer within
the time-limit on which the accused be asked to call his witnesses and he should be warned that if he
does not produce his witness on the date fixed, the proceedings will be concluded. As in Courts, list
of witnesses should be obtained in advance, and attempts to prolong the enquiry by calling useless
witnesses at a later stage checked. Any witness under Government control neglecting to appear,
should be punished.(iv)After the completion of the evidence, the enquiring officer must record his
finding on each charge within a period of two weeks.(v)If it is provisionally decided to impose the
penalty of dismissal, removal or reduction, the accused officer should immediately be supplied with
a copy of the report of the enquiring officer and be called upon to show cause within two weeks
against the penalty proposed to be inflicted.In the interest of justice, the accused may have to be
given slightly longer time, at some stages, than what the above programme prescribes. But this must
be only under very exceptional circumstances, at the enquiring officer's discretion :The present drift
in the proceedings must stop.(vi)Final orders should be passed within two weeks of the date on
which cause is shown.(vii)Where orders of Government are required in a disciplinary case, the
following procedure should be adopted by the Secretariat Department concerned.As soon as the
report of the enquiring officer is received in the Department, the Registrar will scrutinise it to see
that the correct procedure has been followed in the inquiry. He will also collect, and put up with the
record, any previous papers and precedent, merely giving references to these and not commenting
on the merits of the case. The case will not be sent to the office for noting. The Registrar will then
submit the case to the Secretary, whose duty will be to comment on the findings of the enquiring
officer and recommend the punishment to be awarded, noting whether or not the Public Service
Commission has to be consulted. If a reference to another department is considered necessary, the
case should be sent to the Secretary of the Department with a clear indication of the precise points
on which advice is sought, and a summary of the case, to save that Department from the trouble of
going through all the papers. In that Department the Secretary only will deal with the case. When a
reference to the Public Service Commission is not necessary it should, normally, be possible for the
orders of Government to be obtained and issued within one month of the receipt of the enquiring
officer's report, in the Secretariat. If consultation with the Public Service Commission is required, it
should be possible to issue final orders within 1½ months. If these time-limits are exceeded, the
Department should submit an explanation to the Minister-in-Charge with a copy to the Additional
Secretary, Cabinet Secretariat (O and M).These cases should be treated as 'immediate' at all stages.
3. Government desire that the time-limits indicated above, should be
rigorously enforced, and in exceptional cases where an extension of the time
is allowed, full justification for the extension should be recorded in the
order-sheet of the proceedings. Inspecting Officers will kindly make it a pointBihar Board's Miscellaneous Rules, 1958

to check some of the order-sheets during their inspections, and on other
occasions.
Government also trust that all officers entrusted with the conduct of departmental proceedings will
firmly resist any tendency on the part of an accused officer to adopt dilatory tactics, and will
constantly bear in mind the necessity of expeditious disposal of the proceedings, particularly to
those relating to charges of bribery and corruption.
4. I am to request that these instructions may be communicated to all officers
subordinate to you who have not been informed direct. I am also to request
that whenever an officer is asked to conduct departmental proceedings, a
copy of these instructions should be furnished to him. The Head of the Office
will kindly ensure that this is invariably done and any negligence or slip is
immediately corrected. I am to add that Government will take disciplinary
action against any officer who delays the disposal of such proceedings.
Heads of Departments are requested to pay personal attention to this matter
and bring suitable cases to Government's notice for action under this
Paragraph. Where the prescribed time-table cannot be adhered to, and there
is considerable delay, the enquiring officer must keep his superior authority
fully informed of the reasons for the delay, and steps taken to expedite the
proceedings. Government desire that the superior authorities should
exercise proper check and give necessary directions so that the proceedings
may be terminated as quickly as possible.
Yours faithfully,S.J. Majumdar,Chief Secretary to Government.No.
III/RI-1026-61-A-5532Government of BiharAppointment DepartmentFrom,Shri B.K.
Dubey,Deputy Secretary to Government.To,Ail Secretaries to Government.All Departments of
Government.All Heads of Departments.All Commissioners of Divisions.All District Officers.Patna,
the 9th Vaisakha 1885/29th April, 1963.Subject. - Speedy disposal of disciplinary cases against
Government servants-Supply of copies of documents to the delinquent Government servant.Sir,I am
directed to invite your attention to Sri L.P. Singh's letter No. A-i 89, dated the 9th January,1953,
regarding speedy disposal of disciplinary cases against Government servants. Considerable time is
usually taken in furnishing to the Government servant under proceeding with copies of relevant
papers on which the charges against him are based. As a result the filing of written statement by the
charged Government servants gets considerably delayed. Rule 55 of Civil Services (Classification,
Control and Appeal) Rules provides that the grounds on which it is proposed to take action shall be
reduced to the form of definite charge or charges, which shall be communicated to the person under
proceeding, together with a statement of the allegations, on which each charge is based and of any
other circumstances which it is proposed to take into consideration in passing orders in the case.
Accordingly all relevant papers are to be supplied while communicating the charge. It would cut
short delay in disposal of proceedings if the appointing authorities supply quickly to the chargedBihar Board's Miscellaneous Rules, 1958

officers copies of such papers as are connected with the charges and/or any other papers regarding
supply of which specific orders may be passed by the Enquiring Officer.
2. The State Government have carefully considered the questions as to-
(a)the categories of documents which should or which should not be supplied to Government
servant under the proceeding;(b)the stage of the proceeding at which copies of permissible
documents should be supplied.
3. The following categories of documents are generally required by the
charged Government servant-
(1)Documents to which reference has been made in the charge-sheet;(2)Documents and records not
so referred to in the statement-of allegations, but which the Government servant concerned
considers relevant for the purpose of his defence ;(3)Statement of witnesses recorded in the course
of-(a)a preliminary enquiry conducted by the Department;(b)investigation made by the Police
;(4)Reports submitted to Government or competent authority by an officer appointed to hold a
preliminary enquiry to ascertain facts ;(5)Reports submitted to Government or other competent
authority by the Police after investigation.
4. The right of access to official records is not unlimited and it is open to
Government to deny such access if in its opinion such records are not
relevant to the case or it is not desirable in the public interest to allow such
access. The question of relevancy should be looked at from the point of view
of the defence and if there is any possible line of defence to which the
document may, in some way, be relevant the request for access should not
be rejected. The power to deny access on the ground of public interest
should be exercised only when there are reasonable and sufficient grounds
to believe that public interest will clearly suffer. It has to be remembered that
serious difficulties will arise when the Courts do not accept as correct the
refusal on this ground by the disciplinary authority of access to document. In
any case, where it is decided to refuse access, reasons for refusal should be
cogent and substantial and should invariably be recorded in writing.
5. The list of documents which are proposed to be relied upon to prove the
charge and the facts stated in the statement of allegation should be drawn up
at the time of framing the charge.The list should normally include documents
like the First Information Report, if there be any on record. Anonymous and
pseudonymous complaints on the basis of which enquiries were started
need not be included in the list. The list so prepared should be supplied toBihar Board's Miscellaneous Rules, 1958

the Government servant along with the charge-sheet.
6. If the Government servant requests for any official records other than
those included in the list, the request should ordinarily be acceded to in the
light of what has been stated in Paragraph 4 above.
7. Doubt very often arises whether official records include the documents
mentioned at Items 3, 4 and 5 in Paragraph 3 above. Reports made after a
preliminary enquiry or the reports made by the Police after investigation
other than those referred to in clause (a) of sub-section (1) of Section 173 of
the [Code of Criminal Procedure, 1898] [Now, Cr. P.C., 1973.], are usually
confidential and intended only to satisfy the competent authority whether
further action in the matter of a regular departmental enquiry or any other
action is called for.These reports are not usually made use of or considered
in the inquiry. Ordinarily, even a reference to what is contained in these
reports will not be made in the statement of allegations. In that case it is not
necessary to give access to the Government servant to these reports. It is
necessary to strictly avoid any reference to the contents of such reports in
the statement of allegations because if any reference is made, copies of
these reports should be supplied to the Government servant proceeded
against.
8. The next point is whether access should be given to the statements of
witnesses recorded in course of the preliminary enquiry conducted by the
department or investigation made by the Police. The Government servant
concerned need not be given access to the statements of all witnesses
examined in the preliminary enquiry or investigation made by the Police and
access should be given to the statements of only those witnesses who are
proposed to be examined in proof of the charges or the facts stated in the
statement of allegations. In some cases the Government servant may require
copies of the statements of some witnesses on which no reliance is
proposed to be placed by the disciplinary authority on the ground that he
proposes to examine such witnesses on behalf of his defence and that he
requires the previous statement to corroborate the testimony on such
witnesses before the enquiring authority. Previous statements made by a
person examined as a witness is not admissible for the purpose of
corroboration and access to such statements can safely be denied. However,Bihar Board's Miscellaneous Rules, 1958

the law recognises that if the former statement was made at or about the time
when the fact took place and the person is called to give evidence about
such facts in any proceedings, the previous statement can be used for
purposes of corroboration. In such cases, it will be necessary to give access
to the previous statements.
9. The further point is the stage at which the Government servant should be
permitted to have access to the statements of witnesses proposed to be
relied upon in proof of the charges or of the facts stated in the statement of
allegation. As stated earlier, the copies of the statements of the witnesses
can be used only for the purpose of cross-examination and, therefore, the
demand for copies must be made when witnesses are called for examination
at the oral enquiry. If such a request is not made, the inference would be that
the copies were not needed for that purpose. The copies cannot be used at
any subsequent stage as those statements are not to be taken into
consideration by the enquiring authority also. Copies should be made
available within a reasonable time before the witnesses are examined. It
would be strictly legal to refuse access to the copies of the statement prior to
the evidence stage in the departmental enquiry. However, if the Government
servant made a request for supply of copies of statements referred to in
sub-paragraph (3) of Paragraph 3 above before he files a written statement,
the request should be acceded to.
10. Government servant involved in departmental proceedings when
permitted to have access to official record, sometimes seeks permission to
take photostat copies thereof. Such permission should not normally be
acceded to specially if the officer proposes to make the photostat copies
through a private photographer and thereby third parties would be allowed to
have access to official records which is not desirable. If, however the
documents of which photostat copies are sought for are so vitally relevant to
the case (e.g., where proof of the charge depends upon the proof of the
handwriting or a document the authenticity of which is disputed),
Government should itself make Photostat copies and supply the same to the
Government servant. In cases which are not of this or similar type (the
example given above is only illustrative and not exhaustive) it would be
sufficient if the Government servant is permitted to inspect official records
and take extracts thereof. If any record is required for inspection by theBihar Board's Miscellaneous Rules, 1958

charged Government servant on the orders of enquiring officer in cases
where record is bulky and supply of copy thereof is not possible, such
records should be produced by the authority concerned before the enquiring
officer.
11. The above instructions may kindly be brought to the notice of all
appointing authorities and it may be impressed upon them that they should
keep themselves alert in this regard. Serious notice should be taken if the
disposal of the departmental proceeding is delayed beyond the prescribed
time-limit due to non-availability of relevant papers to the charged
Government servant. Every enquiring officer should be supplied with a copy
of these instructions and he should report direct to the appointing authority
any case of delay in order that suitable action may be taken against those
who are responsible for such delay.
12. Receipt of this letter may kindly be acknowledged.
Yours faithfully,B.K. Dubey,Deputy Secretary to Government.Memo No. III/RI-5011/51
A-3794Government of BiharAppointment DepartmentTo,All Departments of Government.All Heads
of Departments.Patna, the 4th May, 1953.Subject. - Compulsory retirement of Government servants
on account of inefficiency or misconduct.The undersigned is directed to refer to the instructions
conveyed in the Appointment Department Circular Memo Nos. RL 59/48A-528, dated the 22nd
January, 1951 and III/RI-5011/51-3133, dated the 29th March, 1952 explaining the amendments to
Rule 75(d) of the Bihar and Orissa Service Code and the delegations made thereunder to enable
Departments of Government and Heads of Departments to retire compulsorily such Government
servants as had completed at least 25 years of total service and 21th years of duty and were
considered to be either corrupt or inefficient. In accordance with the delegations in Circular Memo
No. A-3133, dated the 29th March, 1951 Departments of Government were given full power to order
compulsory retirement of Government servants under their administrative control and similar
delegation was also made to Heads of Departments to order compulsory retirement of non-gazetted
Government servants, both superior and inferior, who were not appointed by Government. Rule 75
(d) of the Bihar and Orissa Service Code has since been replaced by Rule 74 of the Bihar Service
Code, 1952 and the delegations thereunder have been specified under Item 9-A of Appendix I of the
new compilation.
2. In Paragraph 7 of the Appointment Department's Memo No. RL-59/48A-
528, dated the 22nd January, 1951, it was stated that compulsory retirement
effected under Rule 75(d) of the Bihar and Orissa Service Code would
amount to "removal" from service and would therefore, attract the provisions
of clause (2) of Article 311 of the Constitution of India. It was therefore, laidBihar Board's Miscellaneous Rules, 1958

down that it would be necessary to give to the Government servant
concerned reasonable opportunity of showing cause against the action
proposed to be taken in regard to him and to take any representation made
by him into consideration before passing final orders of his compulsory
retirement. Provision to this effect was also made in the Note I below Rule 74
of the Bihar Service Code, 1952 which runs as follows :-
"Compulsory retirement effected in pursuance of this Rule amounts to removal from service within
the meaning of clause (2) of Article 311 of the Constitution of India and a Government servant so
compulsorily retired shall be given a reasonable opportunity to show cause against the action
proposed to be taken against him. It shall, however, not be necessary in such cases to follow the
procedure laid down for the institution of departmental proceedings against a Government servant
before removing him from Government service."
3. The question whether compulsory retirements under Rule 74 of the Bihar
Service Code [or those already effected under Rule 75 (b) of the Bihar and
Orissa Service Code] could attract the provisions of Article 311 (2) of the
Constitution of India has since been carefully considered by the State
Government.The true scope and significance of the provisions of Section 240
(3) of the Government of India Act and of the corresponding provisions of
Article 311 (2) of the Constitution have been adjudged by many High Courts.
The State Government are now advised that compulsory retirements effected
under Rule 74 of the Bihar Service Code would be deemed to have been
ordered by Government by virtue of the conditions of service of the
Government servants concerned to whom the said Code applies and would
not amount to 'dismissal' or 'removal' within the meaning of Article 311 (2) of
the Constitution or Rules 49 and 55 of the Civil Services (Classification,
Control and Appeal) Rules. Consequently the officer proposed to be retired
cannot claim as a matter of right that he should be given an opportunity to
show cause against his proposed compulsory retirement. In pursuance of
this decision, Note below Rule 74 of the Bihar Service Code has now been
amended in the Finance Department Notification No. 1216-F, dated the 30th
January, 1953. The amended Note now reads as follows :-
Note 1. - Compulsory retirement effected in pursuance of this Rule does not amount to dismissal or
removal from service within the meaning of clause (2) of Article 311 of the Constitution and a
Government servant so retired cannot claim as a matter of right that he should be given a reasonable
opportunity of showing cause against the action proposed to be taken in regard to him. It shall also
not be necessary, in such cases, to follow the procedure laid down for institution of departmentalBihar Board's Miscellaneous Rules, 1958

proceedings against the Government servant before retiring him compulsorily from Government
service."
4. The State Government have considered the question whether in view of
there being no statutory obligation to give to a Government servant an
opportunity to show cause against compulsory retirement and Rule 74 of the
Service Code having been amended as stated above, the opportunity of
making a representation against compulsory retirement should still be
provided to a Government servant' against whom action is proposed to be
taken under Rule 74.They are of the opinion that while it is in the public
interest to dispense with the service of Government servants who are corrupt
or grossly inefficient, it is equally desirable, in this transitional period, not to
undermine Government servants sense of security. They feel that unless
Government servants are given an opportunity to show cause against
compulsory retirement, this extraordinary power may in some cases be
exercised harshly or capriciously. It has accordingly been decided that the
existing instructions requiring Government servants to be given an
opportunity to submit representation against compulsory retirement and for
these representations to be considered by the Committees of Senior Officers
which have been specially constituted to examine proposals regarding
compulsory retirement of Government servants of Class I, Class II and Class
III shall remain in force. In accordance with these orders, when the
representation from the Government servant concerned has been received,
his case should be referred to the Committee concerned along with his
character roll, and other reports etc., on the basis of which the provisional
decision to retire the officer compulsorily was taken. Final orders will be
passed in each case after the recommendations of the Committee are
received.
5. In exceptional cases, if the authority empowered to retire a Government
servant compulsorily is satisfied, for reasons to be recorded by him in
writing, that it will not be expedient, or in the public interest, to give to that
Government servant an opportunity of showing cause against the action
proposed to be taken in regard to him, such opportunity may not be given. If,
however, the Committee, of Senior Officers authorised to examine the case
of compulsory retirement decides that the opportunity of showing cause
should be given to that Government servant, such an opportunity shall beBihar Board's Miscellaneous Rules, 1958

given.
6. These orders should be noted carefully for future guidance and
communicated to appointing authorities subordinate to you:
B.N. Sinha,Deputy Secretary to Government.Memo No. III/RI-509/56-A-4518Government of
BiharAppointment DepartmentTo,All Departments of Government.All Heads of
Departments.Patna, the 30th April, 1956Subject. - Compulsory retirement of Government servants
on account of inefficiency or misconduct.The undersigned is directed to invite a reference to
Appointment Department's Confidential Memo No. RL-59/48-A-528 (copy enclosed), dated the
18th/22nd January, 1951. Compulsory retirement of dishonest or inefficient officers has been made
during the past few years, according to the procedure laid down in that memo. Government have
since made a detailed review of the whole position, and have decided that in future compulsory
retirement need not be confined to corrupt Government servants, or to those who are grossly
inefficient. Inefficiency, even though not gross, may be considered as a sufficient ground for
compulsory retirement. For this purpose every Department of Government and every Head of
Department is requested to prepare in July each year, a list of Government servants who have
completed 25 years of service and whose records, in the matter of integrity or of efficiency, are not
satisfactory. This would enable a systematic selection to be made, of cases in which compulsory
retirement should be ordered.
2. The present practice of giving the Government servant an opportunity to
show cause why he should not be compulsorily retired will continue
although as explained in Appointment Department's Memo No. 3794, dated
the 4th May, 1953, it is not legally obligatory to afford such an opportunity.
Only one month's time should, however, be allowed for showing cause, and
only for very exceptional reasons further time, not exceeding another month,
may be allowed.
3. The orders previously in force provided that compulsory retirement of
Government servants in Classes I, II and III, should be made on the advice of
committees of senior officers specially constituted for the purpose.
Government have now decided to discontinue this procedure. When these
committees were first constituted, it was thought that there might be a large
number of compulsory retirements and that therefore, the cases should be
examined by committees to ensure uniformity. In future the number of
compulsory retirements is not likely to be so large, and it should be possible
for each Department of Government to deal with such cases without seeking
the advice of a committee.Bihar Board's Miscellaneous Rules, 1958

4. After a case of compulsory retirement of a gazetted officer has been
examined by the Department concerned, the Appointment Department
should be consulted. When it is proposed to retire a gazetted officer
compulsorily on the ground of dishonesty or corruption, the Anti-Corruption
section of the Political Department should also be consulted. As required
under the Rules of Executive Business, proposal for compulsory retirement
of gazetted officers appointed by Government will be placed before the Chief
Minister and the Council of Ministers before the issue of orders. Cases of
compulsory retirement of gazetted officers appointed by authorities
subordinate to Government should also be submitted to the
Minister-in-charge, and then to the Chief Minister, before issue of orders.
5. A Head of Department may pass orders of compulsory retirement of a
Government servant in class III or class IV. No appeal will lie to Government
against such order passed by a Head of Department. Government may,
however, at any time, call for the papers relating to a case of compulsory
retirement of a Government servant in class III or class IV, and pass such
orders thereon as Government may deem fit. Government have the powers of
making such a review at any time but in order to ensure that permanent
arrangements in vacancies caused by compulsory retirements are not unduly
delayed, an application for such review will not ordinarily be entertained by
Government, unless it is received within one month of the issue of the orders
of compulsory retirement.
L.P. Singh,Chief Secretary to Government.Memo No. RL-59/48-A-528Government of
BiharAppointment DepartmentTo,All Departments of Government.All Heads of Departments.Patna
the 18th/22nd January 1951.Subject.-Compulsory retirement of Government servants on account of
inefficiency or misconduct.The undersigned is directed to say that with a view to deal effectively
with corruption and inefficiency in the public services Government had been considering a proposal
to arm themselves with powers, in exercise of which they could retire compulsorily dishonest or
inefficient officers who had outlived their usefulness.
2. The existing provisions for compulsory retirement of Government servants
are contained in Note I to Article 465-A of the Civil Service Regulations and
Rule 75 (c) of the Bihar and Orissa Service Code. Under the former, the State
Government have an absolute right to retire an officer, after he has
completed 25 years of qualifying service, without giving any reasons. It has,
however, been made clear in the Article that its provisions apply to theBihar Board's Miscellaneous Rules, 1958

categories of officers specified in Article 349-A of the Civil Service
Regulations. A reference to Article 349-A shows that the provision for
compulsory retirement prescribed in Article 465-A applies only to officers of
certain All-India Services and the Provincial Services. It does not for example
apply to Sub-Deputy Collectors, Police Officers below the rank of Deputy
Superintendents, Sub-Registrars and Excise Inspectors and Sub-Inspectors.
3. The only provision for the compulsory retirement of officers to whom Note
1 of Article 465-A of the Civil Service Regulations does not apply, was
contained in [Rule 75(d) of the Bihar and Orissa Service Code] [Now, see
Rule 74 of Bihar Service Code, 1952.]. This Rule runs as follows :-
"The Provincial Government may require any Government servant who has completed twenty-one
years of duty and twenty-five years of total service calculated from the date of first appointment to
retire from Government service if it considers that his efficiency is not such as to justify his retention
in the service:Provided that the provisions of this clause shall not apply to any person who is in
Government service at the time when these rules came in force unless such person was liable, under
the rules previously in force, to be called upon to retire after completing twenty-five years' service."
4. This Rule did not apply to Government servants who had entered service
before the 1st June, 1929 the date on which the Bihar and Orissa Service
Code came into force. Compulsory retirements under the Rule could,
therefore, be ordered only in cases of Government servants who had entered
service after the 1st June, 1929. Since the Rule also provided that only such
Government servants as had completed 25 years of qualifying service could
be made to retire compulsorily, no compulsory retirement in terms of this
Rule could be made until 1954.
5. With a view to remove the difficulties mentioned above [Rule 75 (d)] [Now,
see Rule 74 of Bihar Service Code, 1952.] of the Bihar and Orissa Service
Code has now been amended. The amendment has been notified in
Notification No. 14682-F, dated the 24th October, 1950.The effect of this
amendment is that Government have now powers to retire compulsorily any
Government servant under their rule-making control who has completed 21
years of duty and twenty-five years of total service, calculated from the date
of his first appointment, if they are satisfied that his efficiency and conduct
are not such as to justify his further retention in service.Bihar Board's Miscellaneous Rules, 1958

6. According to the amendment contained in Notification No. 14682-F, dated
the 24th October, 1950, no Government servant can be compulsorily retired,
unless he is inefficient and his conduct has been objectionable.There may,
however, be cases in which an officer's conduct is entirely satisfactory, but
he is grossly inefficient or vice versa ; and it is obviously desirable that
Government should have the power to retire compulsorily either category of
Government servants. Steps are, therefore, being taken to remove this
difficulty by a further amendment of [clause (d) of Rule 75] [Now, see Rule 74
of Bihar Service Code, 1952.] of the Bihar and Orissa Service Code, which
will be notified in due course.
7. Compulsory retirement effected under [Rule 75(d)] [Now, see Rule 74 of
Bihar Service Code, 1952.], as amended in Notification No. 14682F, dated the
24th October, 1950, would amount to 'removal' from service and would,
therefore, attract the provisions of clause (2) of Article 311 of the
Constitution of India. It would therefore, be necessary to give the
Government servant concerned reasonable opportunity of showing cause
against the action proposed to be taken in regard to him, and to take any
representation made by him into consideration before passing final orders. It
will, however, not be necessary to follow the procedure laid down for the
institution of departmental proceedings before retiring an officer
compulsorily in pursuance of the aforesaid rule.
8. Government are anxious to purify the administration by "compulsorily
retiring such of their employees as are corrupt or as are" grossly inefficient.
The emphasis for the present, will however be on retirement of corrupt
officers ; inefficient officers may have to be tolerated until younger officers
have been fully trained. But those who are grossly inefficient must also be
weeded out. It has, accordingly, been decided that all departments of
Government should, in consultation with the Heads of Departments, prepare
list of Class I and II officers, as also of officers of other categories who are
appointed by Government, who should be compulsorily retired on account of
their unsatisfactory conduct or gross inefficiency. These lists should be
forwarded to the undersigned by the 28th February, 1951.Bihar Board's Miscellaneous Rules, 1958

9. Similarly, all Heads of Departments should prepare lists of officers of
Class III whom they propose to retire compulsorily, and forward the lists to
the Department of Government concerned by the 28th February, 1951. A copy
of the list should also be forwarded to the undersigned.
10. As regards Government servants of Class IV, it has been decided that the
Heads of Departments themselves should pass final orders about their
compulsory retirement and send a report to the Department of Government
concerned for information. A notification delegating the power of compulsory
retirement under [Rule 75(d)] [Now, see Rule 74 of Bihar Service Code, 1952.]
of the Bihar and Orissa Service Code (as amended) to the Heads of
Departments is being issued separately. The Heads of Departments should
pass orders for compulsory retirement of officers subordinate to them only
after the delegation has been notified.
11. While Government are keen to weed out corrupt and grossly inefficient
Government servants, they are also anxious to ensure that the extraordinary
power of compulsory retirement is not exercised indiscriminately, or
capriciously. It has, accordingly, been decided to provide, by an executive
order that compulsory retirements of Government servants of Classes I, II
and III during the next two years, would be made on the advice of Committee
of senior officers to be constituted for the purpose. When the lists of officers
of these categories, whom it is proposed to retire compulsorily, are received
by Government, they will take a final decision about the exact composition of
these Committees. It is, however, not proposed to refer to these Committees,
the cases of compulsory retirement of Government servants of Class IV who
are mostly appointed by District officers and other officers of equivalent
rank. With a view to guard against any possibility of the appointing
authorities retiring Government servants of this class capriciously it has
been decided that compulsory retirements of Government servants of Class
IV would be made by the Heads of Departments. Government feel that this
precaution is adequate to guard against unjustified compulsory retirement of
Government servants of class IV.
12. A report on the preliminary action taken on these orders, may kindly be
sent to the undersigned by the 7th February, 1951.Bihar Board's Miscellaneous Rules, 1958

L. P. Singh,Chief Secretary to Government.Memo No. RL-59/48-A-528Patna, the 18th/22nd
January, 1951.Copy forwarded to the Secretary, Bihar Legislative Assembly/the Secretary, Bihar
Legislative Council/the Secretary, Bihar Public Service Commission for information with the request
that the information asked for, may kindly be furnished by the 28th February, 1951. A report on the
preliminary action taken, may also be sent by the 7th February, 1951.L. P. SinghChief Secretary to
Government.Memo No. III/RI-102/63-A--10158Government of BiharAppointment
DepartmentTo,All Departments of Government.All Heads of Departments.Patna, the 23rd August,
1963.Subject. - Government servants involved in criminal misconduct- Departmental proceedings
and prosecution.The undersigned is directed to say that Government have decided, in supersession
of all previous orders on the point, that the following procedure should be adopted in dealing with
Government servants involved in criminal misconduct:-
1. As soon as sufficient evidence is available, in course of departmental
investigation, etc., of criminal misconduct on the part of any Government
servant, disciplinary action should be initiated forthwith and disposed of
according to the rules.
2. In suitable cases criminal proceedings should be instituted
simultaneously. Where the conduct of a Government servant discloses some
grave offence, criminal prosecution must be the rule and not the exception. If
a prima facie case has been made out prosecution should not be avoided
merely on the ground that the case might end in acquittal.
3. Government have noticed that a number of departmental proceedings have
been kept pending for long periods because the person concerned was being
prosecuted before a criminal court. It is necessary to check this tendency; it
is by no means necessary that the final order in departmental proceedings
must await disposal of the same or connected issues by a Court of Law. In
Delhi Cloth and General Mills Ltd. vs. Kushal Bhan, AIR 1960 SC 806, the
Supreme Court observed :
"It is true that very often employers stay enquiries into the misconduct of the employees pending the
decision of the criminal trial Courts dealing with the same facts and that is fair but we cannot say
that principles of natural justice require that an employer must wait for the decision, at least of the
criminal trial Court, before taking action against an employee." This was followed in Jhulan Singh
vs. Ghatak and another, AIR 1962 Cal. 386.
4. Government are advised that (even apart from cases under the Public
Servant Enquiries Act) there is no contempt if departmental proceedings are
carried on and finally decided under the Civil Services (Classification,Bihar Board's Miscellaneous Rules, 1958

Control and Appeal) Rules, the Bihar and Orissa Subordinate Services
Discipline and Appeal Rules, All India Services (Discipline and Appeal) Rules,
1955, Rule 828 of the Police Manual and other statutory rules while police
investigation, enquiry or trial is in progress in respect of the same or allied
subject matter.
5. It would be desirable to hold the departmental proceedings in camera
when the Government servant concerned is being prosecuted in a Court of
law on similar charges.
6. Only if the criminal case against the Government Servant is of a grave and
complicated nature would it be advisable to await the conclusion of the
criminal case before disposing of the departmental proceedings.
7. If the criminal Court acquits the accused Government servant who has
earlier been punished in departmental proceedings, the appointing authority
must immediately review the case. Two considerations will be relevant. First,
the departmental and legal proceedings, may not have covered the same
ground, so that, the Court's findings may leave untouched the decisions
arrived at in the departmental proceedings. Second, while the Court may
have held that there was no offence, the appointing authority may decide that
the accused Government servant was guilty of departmental misdemeanour
and has not behaved in a manner expected of him as Government servant. In
such circumstances a Government servant held not guilty by the Court may
still be dismissed from service.
8. On the other hand the review may disclose that the trial has brought out
facts and circumstances in the light of which the decision taken earlier in the
departmental proceedings ought to be reversed.
9. Under proviso (a) to Article 311 (2) of the Constitution a Government
servant may be dismissed or reduced in rank without being put through
departmental proceedings on the ground of conduct which has led to his
conviction on a criminal charge. Government desire that this proviso should
be fully utilised. But an appeal being continuation of the trial, action under
this proviso should not be taken until (1) the criminal appeal has been
disposed of or (2) the time limit for filing an appeal has expired.Bihar Board's Miscellaneous Rules, 1958

S. J. Majumdar,Chief Secretary to Government.Memo No. II/C-103/68-A-3286.Government of
BiharAppointment DepartmentTo,All Departments of Government.All Heads of Departments.Patna
15, the 16th Phalguna, 1890/7th March, 1969.Subject. - Disciplinary proceeding-Consideration of
past bad records for the purpose of imposition of punishment.A question has arisen whether past
bad records of service of a Government servant can be taken into account in deciding the penalty to
be imposed on the officer in disciplinary proceedings, and whether the fact that such record has
been taken into account should be mentioned in the orders imposing the penalty. This has been
examined by the State Government, keeping in view the judgement of the Supreme Court in the
State of Mysore vs. K. Konche Gowda (AIR 1964 SC 506).Under Article 311 (2) of the Constitution of
India as amended by Constitution (Fifteenth Amendment) Act, 1963 the Government servant has to
be given a reasonable opportunity of making representation on the penalty proposed to be awarded,
at the stage of a second show cause notice and it limits the right of representation only on the basis
of evidence adduced during the enquiry. Accordingly, if past bad records were proposed to be taken
into consideration in determining the penalty to be imposed, it should be made subject matter of a
specific charge in the charge-sheet itself. If it not so done, it cannot be relied upon after the enquiry
is closed and the report is submitted by the enquiring officer.This may kindly be brought to the
notice of all concerned for guidance.P.P. Nayyar,Secretary to Government.No.
E/LIII-1032/61-2609-IR.Government of BiharRevenue DepartmentFrom,Shri K.K. Mitra,
I.A.S.,Secretary to Government.To,All District Officers,Patna, the 17th/20th March, 1961.Subject. -
Procedure to be followed in dealing with the Departmental proceedings against the Subordinate
Field and Ministerial Staff.Sir,I am directed to say that it has come to the notice of Government that
in several cases the correct procedure has not been followed in disciplinary cases particularly in the
matter of terminating temporary services of Government servants as a result of which the orders
had to be set aside on technical grounds and the proceedings had to be revived after a considerable
interval.
2. The procedure to be followed in disciplinary cases has been explained in
the Board's Miscellaneous Rules, 1958, the Bihar and Orissa Subordinate
Services (Discipline and Appeal) Rules, 1935 and also the printed procedure,
"Procedure to be followed in Disciplinary cases" forwarded with
Appointment Department's Letter No. A-10997, dated the 12th December,
1953. It should be clearly understood that there should be strict observations
of the prescribed procedure as otherwise the order is likely to be either set
aside by the Superior authorities or challenged in Courts.
3. It has been held by the Supreme Court in Civil Appeal No. 65 of 1957,
Parshottam Lal Dhingra vs. Union of India, as follows :-
"Where, however, the termination of service is founded on the right flowing from contract or the
Service Rules then prima facie the termination is not a punishment and carries with it no evil
consequences and so Article 311 is not attracted. But even if the Government has, by contract or
under the Rules, the right to terminate the employment without going through the procedureBihar Board's Miscellaneous Rules, 1958

prescribed for inflicting punishment of dismissal or removal or reduction in rank, the Government
may, nevertheless, choose to punish the servant and if the termination of service is sought to be
founded on misconduct, negligence, inefficiency or other disqualification, then it is punishment and
the requirement of Article 311, must be complied with."
4. In the case of Government servants whose appointments are subject to the
condition that the services are liable to be terminated without notice or on
the expiry of a notice of one month the order dispensing with the services of
such Government servants should merely state that their services would no
longer, be required and their appointments would stand terminated from a
particular date or on the expiry of the notice of one month, as the case may
be. No reason should be given for termination of the services in the order
which will be communicated to the Government servant concerned.
5. Government or the appellate authority may, however, like to know the
circumstances in which the services have been terminated. For such
purposes, a separate confidential note should be kept and this note should
not form a part of any record dealing with the termination of services.
6. It is requested that these instructions may be carefully followed in future
by all appointing authorities in disciplinary cases. Kindly acknowledge
receipt of this letter.
Yours faithfully,K. K. Mitra,Secretary to Government.Memo No. E/LII-1032/61-2609-LR.Patna, the
17th/20th March, 1961.Copy with 5 spare copies, forwarded to all Divisional Commissioners, for
information and necessary action.
2. An acknowledgement of receipt of the letter is requested.
K. K. Mitra,Secretary to Government[Extract of Memo No. 3405, dated 12.2.1982]Subject. -
Proposals for action against officers.Under Rule 32 (a)(vii) of the Rules of Executive Business when
there is any proposal to suspend any officer of the State Service-other than those covered by Rule 22
(2)(i) or to impose on him the penalty of censure, stoppage of efficiency bar, holding up of
increments or of promotions, or reduction in rank the case has to be submitted to the Chief Minister
through the Chief Secretary by the Principal Secretary of the Department, after consideration by the
Minister-in-charge but before the issue of orders.
2. With the increase on one hand in the number of officers in almost all
Departments, and general tightening of administration (in regard to matters
such as suspected corruption, indiscipline, etc.) number of cases falling withBihar Board's Miscellaneous Rules, 1958

this group coming to the undersigned, for submission to the Chief Minister,
has naturally been increasing.
3. Experience gained so far in dealing with such files suggests firstly that the
Principal Secretary of the Department concerned, must before submitting the
case (to his Minister) bring on record certain essential details regarding the
particular officer, apart from the substance of the facts elicited through
enquiry on the basis of which the proposals are made.
4. For instance regarding each such officer, it is obviously necessary to
record and thus take into account, before final decision, the following details
:-
(a)When did the impugned officer initially enter in the service of the State Government;(b)When
has he been confirmed (in any particular rank) if at all;(c)Date since which he has been officiating
(in his present rank);(d)What is his date of superannuation ;(e)Whether he is a promotee, or a direct
recruit, to the rank at which he is at present working;(f)If a direct recruit, whether he is an ad
hoc/temporary employee or is he a regular recruit.
5. Regarding each particular officer, these facts are obviously needed also
for assessing whether, in view of the charges against him, action to
discharge or remove from service might not ultimately become necessary.
6. Secondly, it is noticed, the operative recommendation made on many such
files, for consideration at higher levels, is "departmental proceeding to be
instituted". Surely the Principal Secretary must specifically state whether the
proposed departmental proceeding will or will not be, for major penalty
(discharge or removal from service), or will it be for minor penalty (such as
censure etc.)
7. Thirdly, the Principal Secretary must realise that over and above institution
of departmental proceeding, suspension in some cases could be
counter-productive because, for instance-
(a)during the period of suspension the officer would not be doing any work at all,(b)on the other
hand, he would be a charge on public revenue, because he would be entitled to a subsistence
allowance under the rules,(c)to that extent, he might use all his time and energy to delay the
conclusion of the departmental proceedings against him while,(d)on the other hand, the work of the
Department would continue to suffer because, while that particular officer will not be doing any
work, the Department will not have any "vacancy" to fill up.Bihar Board's Miscellaneous Rules, 1958

8. Fourthly, while instituting departmental proceedings, other administrative
steps can surely be recommended/taken, short of suspension, so as to
ensure that the departmental proceedings are infact concluded within
reasonable time (which would be in the interest of the officer also, in case, he
can prove himself to be not guilty) the Principal Secretary must demonstrate
on record, how best this can be done in the particular case without detriment
to the public interest (including the proper scrutiny of charges against him
and collection of evidence); by way of example;
(a)while instituting the departmental proceedings, without suspending the officer, he can surely be
transferred simultaneously to another place wherefrom he cannot have access to the records, etc., in
his original office (on which the result of the departmental proceeding would depend);(b)the
departmental proceeding itself could be entrusted to a suitable senior officer at his next station of
posting so that, without permission of that officer, he cannot leave station, (and thus delay the
departmental proceeding);(c)such controlling officer, at his next station of posting, could be
expected in his own interest, to complete that departmental proceeding within a reasonable time
because, till such proceeding is completed (and decided one way or the other), the officer proceeded
against would be on his strength and without such controlling officer having either the flexibility to
allot him certain kinds of work (till his alleged integrity, indiscipline, etc. remains under doubt).In
short, it is necessary to ensure that suspension does not become substitute for substantive action,
substantive action is not unwillingly delayed by suspension, and the suspension remains a
supplement (to other substantive action) to be used for good reasons in certain cases only.
9. All that has been stated above is, equally required while the Principal
Secretary submits such files, to his Minister, for final orders in regard to the
other cases covered by Rule 22(2)(1) of the Rules of Executive Business
which do not have to be submitted to the Chief Minister. In such files also
above mentioned particulars are desirable so that there is proof on record (1)
of application of mind for the necessary recommended action and (ii)
consequently, proof on record of particulars having been taken into account
while final orders are passed.
After issuance of these self-contained and comprehensive instructions, any file that is hereafter
received by the undersigned without these particulars from any Principal Secretary under Rule
32(a)(vii), for final submission to the Chief Minister might either have to be returned to that
Principal Secretary or, while submitting the file to the Chief Minister, this failure on the part of the
Principal Secretary brought to the notice of the Chief Minister.Bihar Board's Miscellaneous Rules, 1958

10. Two spare copies are enclosed, for internal use in your Department.
[Memo No. 3405 dated 12.2.1982.]
Appendix K(See Rule 167)
Instructions for
drawing up
proceedings.Proceedings
The proceeding shall
be drawn up with the
followingparticulars
:- 
(1) Name, rank and gradeof the officer proceeded against. Against
(2)Details of charges. - Each charge must be specific
andseparately numbered. 
(3)Defence.- The defence submitted in writing should
beattached to the proceedings. In case of illiterate men,
theenquiring officer may himself record the defence.Commenced
(4) Evidence.- A memorandum of evidence should beprepared.Concluded by
District Officer.
(5)Character of officer charged.- A note regarding thegood and
bad work done by the officer in the past, as elicitedfrom his
character roll, should be recorded. 
(6)Findings.- A clear finding on each charge should
berecorded.Concluded by
Appellate
Authority
(7) [ [Substituted by
S.O., 567, dated
19.4.1989.]Order.- The order will be passed by the
competentauthority.]Order of
District Officer.
 [Note.- Final order in a case in which an officer hasbeen
prosecuted should issue as soon as the judicial
proceedingshave concluded without waiting for the result of
an appeal, ifany in a higher Court of Law.] [Substituted by
S.O., 567, dated 19.4.1989.]Final order of
Appellate
Authority.
District Officer's OrderDistrictOfficer,Dated..........  
Commissioner's OrderCommissioner Date of issue of copy of order byDistrict Officer-
Dated.........An appeal against this order lies to........................................(See Rule 4, Appendix Y)
whichmust be made within 30 days from......(Vide rules 79, 80 and 81 of the Practice and Procedure
Manual, 1939).Rules 171 and 167(i) and (iii), ante relate to the supply of the copies of the record.A
copy of the appellate order will be filed with the proceedings.Name, Rank and Grade of Officer
Proceeded Against ChargesCharges must be specific. Each charge should be drawn up and
separately numbered and should give the date, occasion and nature of the offence committed. ABihar Board's Miscellaneous Rules, 1958

copy should be given to the officer charged.
No. Particulars of charges
  
DefenceIf the officer charged can write, he should be permitted to submit his defence in writing.The
defence submitted in writing should be attached to the proceedings. In cases of illiterate men the
enquiring officer may himself record the defence.The written statement of defence should be
submitted within a fortnight from the date of communication of the charges to the officer accused.
Charge No. Plea
  
Evidence(A memorandum of evidence to be recorded. Where the full statements of witnesses has
been recorded in English or Hindi, they should be attached to the proceedings).
Charge No. Particulars of evidence
  
FindingsThe enquiring officer must conclude the proceedings and submit his final report within two
weeks after cause has been shown by the officer proceeded against. Each charge should be examined
in the light of the defence and the evidence and a clear finding on each charge should be recorded by
the enquiring officer.
Charge No. --
  
CharacterDate of appointment and a note regarding good and bad work done by the officer in the
past as elicited from his character roll should be recorded.Order["The Officer who is competent to
pass orders of dismissal, removal or reduction should consider the findings alongwith the past
record of the person concerned and if he is of the opinion that any of these penalties should be
imposed, then an order imposing such penalty shall be recorded.If the penalty imposed is other than
dismissal or removal, the order should clearly indicate how the period of suspension, if any, should
be treated, and what subsistence allowance is to be allowed."] [Substituted by S.O., 567, dated
19.4.1989.]Note. - All provisions of Appendix"J" shall continue to apply mutatis mutandis in
relation to the above concerned amendments.
Charge
No.Finding and sentence by District Officer. The attention of the District Officers is drawn to
rule 167 (a) and rule 170 of the Board's Miscellaneous Rules.
  
Order of the Commissioner or Other Appellate CourtN.B. - The attention of the Appellate Authority
is drawn to rule 173 of the Board's Miscellaneous Rules.Appendix L(See Rule 211)Form of Security
Bond to be executed by the officers named in Rule 211 who handle Government money, but who
have not the power of nominating their own subordinates and who deposit the whole of their
security at the time of execution.Know all men by these presents that(1)[] [Principal] .................. son
of......... resident of................ village............... thana............ in the District of.................(2)[] [First
surety] .................. son of......... resident of................ village............... thana............ in the District
of.................(3)[] [Second surety] .................. son of......... resident of................ village...............
thana............ in the District of.................are held and firmly bound unto the Governor of Bihar in the
sum of Rs................to be paid to the Governor of Bihar, his successors, or assigns or his or their
certain attorney or attorneys for which payment well and truly to be made we bind ourselves, ourBihar Board's Miscellaneous Rules, 1958

heirs, executors, administrators and representatives jointly and every two of us bind ourselves, our
heirs, executors, administrators, and representatives jointly and each of us binds himself, his heirs,
executors, administrators and, representatives severally firmly by these presents sealed with our
seals dated this...........day of..................20 ..................and each of us the said [................] [Principal
and sureties.] doth hereby for himself, his heirs, executors, administrators and representatives
covenant with the said Governor of Bihar, his successors or assigns; that if any suit shall be brought
touching the subject matter of this obligation or the condition hereunder written in any Court, other
than a High Court of Judicature in its ordinary original jurisdiction, the same shall and may at the
instance of the said Governor of Bihar, be removed into, tried and determined in its extra-ordinary
original jurisdiction by the High Court to whose superintendence the Court in which the suit has
been brought, is subject.Whereas the above bounden (1)*.....................................was on the
..................day of...................20 ...............appointed to and now holds and exercised the office of
............................................... atAnd Whereas the said
(1)*.......................................................................................... may hereafter from time to time be
appointed to some other office and it is expressly intended and agreed that the obligation of the
above written bound and the liability to the said
(2)*................................................................................ and (3)*..................shall not be affected by
reason of any such new appointment.AND WHEREAS the said (1) has and during the time during
which he shall continue to in the services of or employed by the Government of
.......................................will have amongst other duties the care, charge and oversight of and
responsibility for the safe and proper storing and keeping in the place appointed for the custody
thereof respectively of all moneys, specie, bullion, coin, jewels, Government currency notes, stamps,
and Government securities of whatsoever description, gold, silver, copper, lead, goods, stores,
chattels and effects stored and used at received into, or despatched from the
.................................................for the time being of which he the said
(1)*.............................................................................................................shall be the or paid,
deposited or brought into such by any person or persons whomsoever and for any purpose or
purposes whatsoeverAnd Whereas the said (1)* ...................................................................................
as such .................................................... aforesaid is also, responsible that...............all such moneys,
specie, bullion, coin, jewels, Government currency notes, stamps and Government securities of
whatsoever description, gold, silver, copper, lead, goods, stores, chatties, and effects, (hereinafter
together only called the said property) are and is of full measure and good quality when received
into such ..................................... and until he has duly accounted therefor and for every part thereof
in manner hereinafter referred toAnd Whereas the said
(1)*.................................................................is bound whenever called upon so to do to show to his
superior officers that the said property and every part thereof save so much thereof as he has duly
accounted for is at all times intact in the place aforesaid and is also bound to attend for the purpose
of discharging his duties aforesaid at such times and places as his superior officers may appointAnd
Whereas the said (1)*................................is further bound to keep true and faithful accounts of the
said property and of his dealings under written orders of his superior officers therewith respectively
in the form and manner that may from time to time be prescribed under the authority of
Government and also to prepare and submit such returns and such accounts as he may from time to
time be called upon to do but as between the said (1)* and the said Governor of Bihar be the said (1)*
....................................................... is also responsible and answerable therefor and for every partBihar Board's Miscellaneous Rules, 1958

thereofAnd Whereas the responsibility of the said (1)*...........................................for the said
property and every part thereof does not cease until the same has been duly used under the written
orders aforesaid and accounted for or been duly despatched from the said
............................................................................ and delivered over to and a full and complete
discharge therefor obtained from such persons and places as the District Officer of...........or other
person exercising his functions for the time being under the sanction of the Government of
........................................................may directAnd Whereas the said (1)*........................in
consideration of his said appointment has delivered to and deposited with [and endorsed over to] [If
the officer deposits cash as security, the words in single brackets must be omitted throughout the
bond; if Government securities, the words in double brackets must be omitted.]
.................................as such District Officer as aforesaid(the sum of Rs. ...................................
)[Government securities to the extent of Rs. ............................................. of which the numbers,
amounts and other particulars are set forth and specified in the schedule hereunder written] for the
purpose of in part securing and indemnifying the said Governor of Bihar, his successors and assigns
against all loss and damage to which he or they might or may in any way suffer by reason of the said
property or any part or parts thereof being in any way consumed, wasted, embezzled, stolen,
mis-spent, misapplied; or otherwise dishonestly, or negligently or by or through oversight, or
violence made away or parted with by him the said
(1)*.....................................................................And Whereas the said (2)* .......... and (3)*
......................... as his the said (1)* ......................... sureties in that behalf have entered into the above
bond in the penal sum of Rs conditioned for due performance by him the said
(1)*......................................of the duties of the said office aforesaid and of other the duties
appertaining thereto or which may lawfully be required of him and for the due performance by him
the said (1)* .......................................of the duties of any other office to which he the said
(1)*.......................................................................... may from time to time be appointed and for the
purpose of security and indemnifying the said Governor of Bihar and his servants against all loss
from or by reason of the acts or defaults of him the said (1)...............................................Now the
condition of the above written bond is such that if the said (1)* [has whilst he has held the said office
of .................................................................................... as aforesaid always duly performed and
fulfilled the said duties of the said office and other the duties aforesaid and if the said (1)* ...] [If the
officer has not held office previous to signing of the bond the words in brackets may be omitted.]
shall whilst he shall be in the service of or employed by the Government of Bihar always duly
perform and fulfill all and every the duties of the said office or other the office for the time being
held by him the said (1)*...........................................and further that if the said (2)*................and
(3)*...................do and shall indemnify and save harmless the said Governor of Bihar, his successors
and assigns the Government of.........................................................and all and every the person or
persons who from time to time has or have held or shall hold or exercise the said office of District
Officer of..............................and other the District Officers from time to time having control over the
office for the time being held by the said (1)*.........of and from all and every loss and damage [during
the time the said (1)* ..........................has held, executed and enjoyed the said office has happened or
been sustained] or shall or may at any time or times hereafter during the time that he the said
(1)*......................................... shall be in ..................................................the service of or employment
by the Government of...................shall happened to or be sustained by the said Governor of Bihar,
his successors or assigns, the Government of or the said District Officers by, from or through theBihar Board's Miscellaneous Rules, 1958

means of the neglect, failure, misconduct, disobedience, omission, or insolvency of the said (1)*
.........................or by, from or through the consuming, wasting, embezzling, stealing, mis-spending,
losing, misapplying or otherwise dishonestly, or negligently, or through oversight or violence,
making away or parting with the said property or any part or parts thereof by the said (1)
...................................... during the whole of the time during which the said (1)* [has been and] [If
the officer has not held office previous to signing of the bond the words in brackets may be omitted.]
shall continue to be in the service of or employed by the Government of
.......................................................... whatever the nature of the office for the time being held by him
may be and wheresoever such office may be situate.Then this obligation to be void and of no effect
otherwise the same shall be and remain in full force and virtueProvided Always and it is hereby
agreed and declared that neither of them the said (2)* and (3)* ...................shall be at liberty to
terminate their suretyship" except upon giving to the District Officer for the time being of the
Government of .....................................six calendar months' notice in writing of his or their intention
so to do and their joint and several liability under this bond shall continue in respect of all omissions
and defaults on the part of the said (1)* ...................................................................... until the
expiration of the said period of six monthsProvided Always and it is hereby declared and agreed by
the said (2)*................................... and (3) the said Governor of Bihar, his successors and assigns
that the said [Government promissory notes of Rs.......................................................]
................................. [(sum of Rs............ )] so deposited as aforesaid respectively or such
Government security or securities to the same value as the District Officer for the time being of the
Government of ........................................may consent from time to time to accept and receive and
shall accordingly receive in exchange for the same and the interest thereof respectively shall be and
remain with the said District Officer for the time being of the Government
of...........................................as and for part and additional security to the said Governor of Bihar, his
successors and assigns, for the purpose aforesaid with full power to the said Governor of Bihar, his
successors or assigns, or his or their officers and servants duly authorised in that behalf from time to
time as occasion shall require to [sell and] dispose of the said [(sum of Rs...............)] Government
promissory notes for Rs.] or any notes that may be substituted therefor or a sufficient portion
thereof with the interest thereon and to apply the proceeds thereof in and towards the indemnity as
aforesaid of the said Governor of Bihar, his successors and assigns, as the case may require, but
nevertheless the interest of the said [(sum of Rs................] Government securities or any notes that
may be substituted therefor may in the meantime be paid over as the same shall be realised by the
said District Officer for the time being of the Government of if he shall think fit to the said
(1)*Provided Further and it is hereby expressly agreed and declared between and by the said (2)*
......................and (3)*.......................................................... with the said Governor of Bihar, his
successors, and assigns, that it shall be lawful for the said (1)*
..................................................................................................................................................with the
consent of the said District Officer or of other the person exercising his functions for the time being
under the sanction of the Government of
..................................................................................................................first has and obtained to
change and substitute for the said deposit of [(Rs in cash)] Government promissory notes for Rs ] or
any part thereof or for any substituted notes from time to time [(Government promissory notes)
[other notes of the same or other loans] of the same or greater value without in any way affecting the
obligation of the said bond or the liability of the said (2)*Bihar Board's Miscellaneous Rules, 1958

............................................................................................................ and (3)*..........................as such
sureties as aforesaid................................................And it is hereby lastly agreed and declared by and
between the said (1)* ........................................and the said (2)*.......... and (3)* ................. as his the
said (1)*............................................................................ sureties and the said Governor of Bihar, his
successors and assigns that on the said
(1)*.......................................................................................................... ceasing to be in the
employment of the Government of ............... the above mentioned [(sum of
Rs................................................)] Government promissory notes for Rs...................] or any notes
that may have been substituted therefor as aforesaid shall not be at once returned to him but shall
be and remain with the [said] [The authority with whom the security is
deposited.]...........................as for the term six months as security against any loss that may have
been incurred by the said Government of Bihar, his successors and assigns, owing to the neglect or
default of the said (1)*.........................which may not have been discovered until after the vacation of
his appointment by the said (1)* .....................................................................Provided Always that the
return at any time of the said [(sum of Rs..................)] [Government promissory notes for Rs ....] or
any notes that may have been substituted therefor shall not be deemed to affect the right of the
said........................his successors and assigns to take proceedings upon the said bond against the
said (1)*................and (2)* and (3)* ...........in case any....................breach of the condition of the said
bond shall be discovered after the return of the [(said sum of Rs......................)] [(Government
promissory notes for Rs...................................]or any notes that may have been substituted therefor
as aforesaid.*(1) Principal *(2) First surety *(3) Second surety[The Schedule above referred
to.]Appendix M(See Rule 211)Form of security bond to be executed by acting incumbents of posts
(other than Sub-divisional Head Clerks) mentioned in Rule 211 who handle money but who have not
the power of nominating their own subordinates.Know all men by these presents
that...............................................(1)* ..................................son of resident of................village, thana
............................. in the district of........................(2)* ..................................son of resident
of................village, thana................................ in the district of........................(3)*
..................................son of resident of................village, thana................................ in the district
of........................are held and firmly bound unto the Governor of Bihar in the sum of
Rs.......................................to be paid to the Governor of Bihar, his successors or assigns or his or
their certain attorney or attorneys for which payment well and truly to be made we bind ourselves,
our heirs, executors, administrators and representatives jointly and every two of us bind ourselves,
our heirs, executors, administrators and representatives jointly and each of us binds himself, his
heirs, executors, administrators and representatives severally firmly by these presents sealed with
our seals, dated this.................day of.............20 and each of us the said**............... doth hereby for
himself his heirs, executors, administrators and representatives covenant with the said Governor of
Bihar, his successors and assigns, that if any suit shall be brought touching the subject-matter of this
obligation or the condition hereunder written in any Court subject to the High Court of Judicature at
Patna, the same shall and may at the instance of the said Governor of Bihar be removed into, tried
and determined by the said High Court in its extra-ordinary original jurisdiction.Note. - When the
sureties are unable to read English, care should be taken that the provisions of the bond are
explained to them before execution, and the persons doing this should in every such case attest the
signature of the sureties and make a note at foot, of the attestation clause that the terms of the bond
were so explained.Whereas the above bounden (1)*............................on the................. day ofBihar Board's Miscellaneous Rules, 1958

.........................20 appointed to and now holds and exercises the office of
acting......................at................ :And Whereas by virtue of such office the said
(1)*...........................had amongst other duties the care, charge and oversight of, and responsibility
for the safe and proper storing and keeping in the places appointed for the custody thereof
respectively of all moneys, specie, bullion, coin, jewels, Government currency notes, stamps and
Government securities of whatsoever description, gold, silver, copper, lead, goods, stores, chattels or
effects stored and used at, received into or despatched from the ................ stored and used, and
received into, or despatched from the ..............or the time being of which he the said (1)*........... shall
be the.....................or paid, deposited or, brought into such....................... by any person or persons
whatsoever and for any purpose or purposes whatsoever,And Whereas the said (1)* ..................as
such ................................... aforesaid is also responsible that all such moneys, specie, bullion, coin,
jewels, Government currency notes, stamps and Government securities of whatsoever description,
gold, silver, copper, lead, goods, stores, chattels and effect (hereinafter together called the said
property) are and is of full measure and good quality when received into such.................and until he
has duly accounted therefor and for every part thereof in manner hereinafter referred to.And
Whereas the said (1)*....................... is bound whenever called upon so to do to show to his superior
officers that the said property and every part thereof save so much thereof as he has duly accounted
for is at all times intact in the places aforesaid and is also bound to attend for the purpose of
discharging his duties aforesaid at such time and places as his superior officers may appoint.And
Whereas the said (1)*................is further bound to keep the true and faithful accounts of the said
property and of his dealing under written orders of his superior officers therewith respectively in the
form and manner that may from time to time be prescribed under the authority of Government and
also to prepare and submit such returns and such accounts as he may from time to time be called
upon to do but as between the said (1)*.................................and the said Governor of Bihar he the
said (1)*.............................. is alone responsible and answerable therefor and for every part
thereof.And Whereas the responsibility of the said (1)*.......................for the said property and every
part thereof does not cease until the same has been duly used under the written orders aforesaid and
accounted for or been duly despatched from the said ...........................and delivered over to and a full
and complete discharge therefor obtained from such persons and places as the District Officer of
.......................or other person or other person exercising his functions from the time being under the
sanction of the Government of may direct.And Whereas the said (1)* in consideration of his said
appointment has entered into this Bond for the purpose of in part securing and indemnifying the
said Governor of Bihar, his successors and assigns, against all loss and damage which he or they
might or may in any way suffer by reason of the said property or any part or parts thereof being in
any way consumed, wasted, embezzled, stolen, misspent, lost, misapplied or otherwise dishonestly,
or negligently or by or through oversight or violence made away or parted with.......................by him
the said (1)* ......................And Whereas the said (2)* and (3)* ...............at his the said
(1)*.................................................. sureties in that behalf have entered into the above Bond in the
penal sum of Rs............................................conditioned for the due
performance............................................by him the said (1)* of the duties of the said office aforesaid
and of the other duties appertaining thereto or which may lawfully be required of him and for the
purpose of securing and indemnifying the said Governor of Bihar and his servants against all loss
from or by reason of the acts of defaults of him the said (1)*....................Now the conditions of the
above written head is such that if the said (1)*............. [has whilst he has held the said officeBihar Board's Miscellaneous Rules, 1958

of.......................as aforesaid always duly performed and fulfilled the said duties of the said office and
other duties aforesaid and if he the said (1)* ................] shall whilst he shall be in the service of or
employed by the Governor of Bihar always duly perform and fulfil all and every duties of the said
office or other the office for the time being held by him the said (1)*...................and further that if
the said (2)*........and (3)* .......................do and shall indemnify and save harmless the said
Governor of Bihar, his successors and assigns the Government of .................................and all and
every the person or persons who from time to time has or have held or shall hold or exercise the said
office of District Officer of................and other the District Officers from time to time having control
over the office for the time being held by the said (1)*................... of and from and against all and
every loss and damage which **[during the time the said (1)*.......................has held, executed and
enjoyed the said office, has happened to or been sustained] or shall or may at any time or times
hereafter during the time that he the said (1)*........................shall be in the service of or employment
by the Government of .......................shall happen to or be sustained by the said Governor of Bihar,
his successors or assigns, the Government of or the said District Officers by, from or through the
means of the neglect, failure, misconduct, disobedience, omission or insolvency of the said (1)*
.................................................... or by, from or through consuming, wasting, embezzling,
mis-spending, losing, misapplying or otherwise dishonestly or negligently or through oversight, or
violence making away or parting with the said property or any part or parts thereof by the said
(1)*.........................................during the whole of the time during which the said (1)* ................[has
been and] [If the officer has not held office previous to signing of the bond the words in brackets
may be omitted] shall continue to be in the service of or employed by the Government of...................
whatever the nature of office for the time being held by him may be and wheresoever such office
may be situate; then this obligation shall be void and of no effect. Otherwise the same shall be and
remain in full force and virtue. Provided always and it is hereby agreed and declared that neither of
them the said (2)*............. and (3)*......................shall be at liberty to terminate their suretyship
except upon giving to the District Officer for the time being of the Government of ...............six
calendar months' notice in writing of his or their intention so to do and the liability under this bond
in the event of any such notice being given, of the surety by whom it shall be given shall be thereby
determined in respect only of acts and omissions happening after the expiration of the said period of
six months.
(1)Principal Signed, sealed and
delivered by the
abovenamedinthe presence
of(2)1st surety Signed, sealed and
delivered by the
abovenamedinthe presence
of(3)2nd surety Signed, sealed
and delivered by the
abovenamedinthe presence
of
*(1) Principal *(2) First surety (3) Second surety**Principal and sureties.Appendix N(See Rules 211
and 215)Form of security bond to be executed by the officers named in Rule 211 who handle
Government money, but who have not the power of nominating their own subordinates and who
deposit their security in instalments.Know all men by these presents that (1)*...................... son
of................ resident of............... village................ thana............. in the District
of..........(2)*...................... son of................ resident of............... village................ thana............. in the
District of..........(3)*...................... son of................ resident of............... village................
thana............. in the District of..........are held and firmly bound unto the Governor of Bihar in the
sum of Rs...............to be paid to the said Governor of Bihar, his successors or his or their certain
attorney or attorneys for which payment well and truly to be made we bind ourselves, our heirs,Bihar Board's Miscellaneous Rules, 1958

executors, administrators and representatives jointly and every two of us bind ourselves, our heirs,
executors, administrators and representatives jointly and ourselves, our heirs, executors,
administrators and representatives jointly and each of us binds, himself, his heirs, executors,
administrators and representatives severally firmly by these presents sealed with our seals, dated
this................................day of.20 and each of us the said** .....................................doth hereby for
himself, his heirs, executors, administrators and representatives covenant with the said Governor of
Bihar, his successor and assigns, that if any suit shall be brought touching the subject matter of this
obligation or the condition hereunder written in any Court than High Court of Judicature in its
ordinary original jurisdiction, the same shall and may at the instance of the said Governor of Bihar
be removed into, tried and determined in its extraordinary original jurisdiction by the High Court to
whose superintendence the Court in which the suit has been brought, is subject ........*(1) Principal
*(2) First surety (3) Second suretyWhereas the above bounden (1)*...................was on
the.................day of.................20 ..........appointed to................and now holds and exercises the office
of...............at..................ANDWHEREAS the said (1)*...................may hereafter from time to time be
appointed to some other office and it is expressly intended and agreed that the obligation of the
above written bond and the liabilities of the said (2)*.......and (3)*................. shall not be affected by
reason of any such new appointment AND WHEREAS the said (1)*.........................has and during
the time during which he shall continue to be in the service of or employed by the Government
of................ will have amongst other duties the care, charge and oversight of and responsibility for
the safe and proper storing and keeping in the places appointed for the custody thereof respectively
of all moneys, specie, bullion, coins, jewels, Government currency notes, stamps and Government
securities of whatever description, gold, silver, copper, lead, goods, stores, chattels and effects stored
and used at, received into or despatched from the.................said (1)*...............for the time being of
which he the said (1)*............shall be the.........................or paid, deposited or brought into
such.................by any person or persons whomsoever and for any purpose or purposes whatsoever
AND WHEREAS the said (1)*..............as such..................aforesaid is also responsible that all such
money, specie, bullion, coins, jewels, Government currency notes, stamps and Government
securities of whatsoever description, gold, silver, copper, lead, goods, stores, chattels and effects
(hereinafter together only called the said property) are and is of full measure and good quality when
received into such .............and until he has duly accounted therefor and for every part thereof in
manner hereinafter referred to AND WHEREAS the said (1)*......................is bound whenever called
upon so to do to show to his superior officers that the said property and every part thereof save so
much thereof as he has duly accounted for is at all times intact in the places aforesaid and is also
bound to attend for the purpose of dischargings his duties aforesaid at such times and places as his
superior officers may appoint.AND WHEREAS the said (1)* is further bound to keep true and
faithful accounts of the said property and of his dealings under written orders of his superior officers
therewith respectively in the form and manner that may from time to time be prescribed under the
authority of Government and also to prepare and submit such returns and such accounts as he may
from time to time be called upon to do but as between the said (1)*.............................and the said
Governor of Bihar he the said (1)* ..................................is alone responsible and answerable therefor
and for every part thereof AND WHEREAS the responsibility of the said (1)*...............................for
the said property and every part thereof does not cease until the same has been duly used under the
written orders aforesaid and accounted for or been duly despatched from the [said] [Principal and
sureties.]......................and delivered over to and a full and complete discharge therefor obtainedBihar Board's Miscellaneous Rules, 1958

from such person and place as the District Officer of ..................or the persons exercising his
functions for the time being under the sanction of the Government or may direct.AND WHEREAS
the said (1)*.................................the consideration of his said appointment has agreed to deliver to
and deposit with **[and endorse over to] ..............................as such District Officer as aforesaid
[(the sum of Rs..................)] [Government securities to the extent of Rs...................] for the purpose
of in part securing and indemnifying the said Governor of Bihar, his successors and assigns against
all loss and damage which he or they might or may in any way suffer by reason of the said property
or any part or parts thereof being in any way consumed, wasted, embezzled, stolen, mis-spent,
misapplied or otherwise dishonestly or through oversight or violence made away or parted with by
him the said (1)*................................................................AND WHEREAS the said
(1)*.................................has already delivered to and deposited with [and endorsed over
to].........................as such District Officer as aforesaid [the sum of Rs....................)] [Government
securities to the extent of Rs....................................of which the numbers, amounts and other
particulars are set forth and specified in the schedule hereunder written] part of the said security so
to be deposited as aforesaid and it has been agreed that the said (1)*................shall deliver to and
deposit with [and endorsed over to] the said...............as such District Officer as aforesaid the
balance of the said [(sum of Rs )] [Government securities to the extent of Rs. .............] so to be
deposited as aforesaid in monthly instalments of Rs. ........................such monthly instalments to be
deducted from the salary of the said (1)*.......................the said District Officer shall so think fit AND
WHEREAS the said (2)*...............................and (3)*...................as his the said
(1)*...................sureties in that behalf have been entered into the above bond in the penal sum of
Rs............................ conditioned for the due performance by him the said (1)*...........................of the
duties of the said office aforesaid and of other the duties appertaining thereto or which may lawfully
be required of him and for the due performance by him the said (1)*................ of the duties of any
other office to which he the said (1)*....................... may from time to time be appointed for the
purpose of securing and indemnifying the said Governor of Bihar and his servants against all loss
from or by reason of the acts or defaults of him the said (1)*.....................Now the condition of the
above written bond is such that if the said (1)* ................................... **[has whilst he has held the
said office of....................as aforesaid always duly performed and fulfilled the said duties of the said
office and other the duties aforesaid and if he the said (1)*..................shall whilst he shall be in the
service of or employed by the Government of...........................always duly perform and fulfil all and
every one duties of the said office or other the office for the time being held by him the said
(1)'..................and further that if the said (2)*....and (3)*............do and shall indemnify and save
harmless the said Governor of Bihar, his successors and assigns the Government
of.............................and all and every the person or persons who from time to time has or had held
or shall hold or exercise the said office of District Officer of.............. and other the District Officers
from time to time having control over the office for the time being held by the said (1)*.................of
and from all and every loss and damage which "[during the time the said (1)* has held, executed and
enjoyed the said office has happened or been sustained or] shall or may at any time or times
hereafter during the time that he said (1)*.................shall be in the service of or employed by the
Government of...................shall happen to or be sustained by the said Governor of Bihar, its
successors or assigns the Government of ..............or the said District Officers by, from or through
the means of the neglect, failure, misconduct, disobedience, omission or insolvency of the said
(1)*...........or by from or through the consuming, wasting, embezzling, stealing, mis-spending,Bihar Board's Miscellaneous Rules, 1958

losing, misapplying or otherwise, dishonestly, negligently or through oversight or violence making
away or parting with the said property or any part or parts thereof by the said (1)*.................during
the whole of the time during which the said (1)*................[has been and] shall continue to be in the
service of or employed by the Government of Bihar whatever the nature of the office for the time
being held by him may be and wheresoever such office may be situate.Then this obligation to be void
and of no effect otherwise the same shall be and remain in full force and virtue. PROVIDED
ALWAYS and it is hereby agreed and declared that neither of them the said (2)*...............and
(3)*............. shall be at liberty to terminate their suretyship except upon giving to the District Officer
for the time being of the Government of.................................six calendar month's notice in writing of
his or their intention so to do and their joint and several liability under this bond shall continue in
respect of all omissions and defaults on the part of the said (1)*..............until the expiration of the
said period of six months. PROVIDED ALWAYS and it is hereby declared and agreed by the said
(2)*.................and (3)*................with the said Governor of Bihar, his successors and assigns that the
said [Government promissory notes for Rs..................] [(sum of Rs........................)] or so much
thereof as shall for the time being be deposited as aforesaid respectively or such Government
security or securities to the same value as the District Officer for the time being of the Government
of.......................... may consent from time to time to accept and receive and shall accordingly receive
in exchange for the same and the interest thereof respectively shall be and remain with the said
District Officer for the time being of the Government of........................may consent from time to
time to accept and receive and shall accordingly receive in exchange for the same and the interest
thereof respectively shall be and remain with the said District Officer for the time being of the
Government of...................... as and for part and additional security to the said Governor of Bihar,
his successors and assigns for the purpose aforesaid with full power to the said Governor of Bihar,
his successors or assigns or his or their officers and servants duly authorised in that behalf from
time to time as occasion shall require to (sell and) dispose of the said [(sum of Rs........................)]
[Government promissory notes for Rs.] or so much thereof as shall for the time being have been
deposited or any notes that may have been substituted therefor or a sufficient portion thereof with
the interest thereon and to apply the proceeds thereof in and towards the indemnity as aforesaid of
the said Governor of Bihar, his successors and assigns as the case may require but nevertheless the
interest of the said [(sum of Rs.............................)] [(Government promissory note for Rs.
..................)] or so much thereof as shall for the time being have been deposited or any notes that
may have been substituted therefor may in the meantime be paid over as the same shall be realised
by the said District Officer for the time being of the Government of........................ if he shall think fit
to the said (1)*.........................PROVIDED FURTHER and it is hereby expressly agreed and declared
between and by the said (2)* ....................... and (3)* .....................with the said Governor of Bihar
that it shall be lawful for the said (1)* with the consent of the said District Officer or of other the
person exercising his functions for the time being under the sanction of the Government
of....................first has and obtained to change and substitute for the said deposit of [(Rs............. in
cash)]. [Government promissory notes for Rs ] or so much thereof as shall for the time being have
been deposited or for any substituted notes from time to time [Government promissory notes]
[other notes of the same or other loans] of the same or greater value without in any way affecting the
obligation of the said bond or the liability of the said (2)* ..............and (3)* as such sureties as
aforesaid ................. AND it is hereby lastly agreed and declared by and between the said
(1)*..............................and the said (2)*.................. and (3)*.......and his the saidBihar Board's Miscellaneous Rules, 1958

(1)*................sureties and the said Governor of Bihar, his successors and assigns that on the said
(1)*................ ceasing to be in the employ of the Government the abovementioned [(sum of Rs.
..................)] [Government promissory notes for Rs .................or so much thereof as shall have been
deposited or any notes that may have been substituted therefor as aforesaid shall not be at once
returned to him but shall be and remain with the said (1)*......................for the term of six months as
security against any loss that may have been incurred by the said Governor of Bihar, his successors
and assigns owning to the neglect or default of the said (1) ......................................which may not
have been discovered until after the vacation of his appointment by the said (1)*
.................................PROVIDED ALWAYS that the return at any time of the said [(sum of
Rs....................)] [(Government promissory notes for Rs....................)] or so much thereof as shall
have been deposited or any notes that may have been substituted therefor shall not be deemed to
affect the right of the said Governor of Bihar to take proceedings upon the said bond against the
(1)*.............and (2)* ................ and (3)*........,......in case any breach of the condition of the said bond
shall be discovered after the return of the said [(sum of Rs. ..................)] [(Government promissory
notes for Rs........................)] or so much thereof as shall have been deposited or any notes that may
have been substituted therefor as aforesaid.*(1) Principal *(2) First surety (3) Second surety**If the
officer has not held office previous to signing of the bond the words in brackets may be
omitted.Note. - When the sureties are unable to read English, care should be taken that the
provisions of the bond are explained to them before execution, and the persons doing this should in
every such case attest the signature of the sureties and make a note at the foot of the attestation
clause that the terms of the bond were so explained.[The Schedule above referred to.]Appendix
O(See Rule 220)Form of security bond to be executed with sureties by the officers named in Rule
220 who have not the handling of Government money.Know all men by these presents
that.....................(1)*............................................................................................. resident
of............................. son of................................................
Village..........................................................................................thana..............................in the district
of........................................'(2)*........................................................................................Son
of................................................................................. resident of...................................
village.................................................. thana....................................................................... in the
district of...............................................................................................(3)*.................................... son
of................................................. resident of........................... village...................................................
thana....................................................................in the district of .....................are held and firmly
bound unto the Governor of Bihar in the sum of Rs................................................................... to be
paid to the said Governor of Bihar, his successors or assigns or his or their, certain attorney or
attorneys for which payment well and truly to be made we bind ourselves, our heirs, executors,
administrators and representatives, jointly and every two of us bind ourselves, our heirs, executors,
administrators and representatives jointly and each of us binds himself, his heirs, executors,
administrators and representatives severally firmly by these presents sealed with our seals, dated
this day of ................20....................................................and each of us the said** doth hereby for
himself, his heirs, executors, administrators and representatives covenant with the said Governor of
Bihar, his successors and assigns, that if any suit shall be brought touching the subject-matter of this
obligation or the condition hereunder written in any Court other than a High Court of Judicature in
its ordinary original jurisdiction the same shall and may at the instance of the said Governor of
Bihar be removed into, tried and determined in its extraordinary original jurisdiction by the saidBihar Board's Miscellaneous Rules, 1958

High Court to whose superintendence the Court in which the suit has been brought, is subject.*(1)
Principal *(2) First surety (3) Second surety** Principal and sureties.WHEREAS the above bounded
(1)* .........................was on the...... day of..............20............................. appointed to and now holds
and exercises the office of.............at in the district of....................AND WHEREAS the said
(1)*.........................may hereafter from time to time be appointed to some other office and it is
expressly intended and agreed that the obligation of the above written bond and the liability of the
said (2)*...........and (3)* shall not be affected by reason of any such new appointment
..................................AND WHEREAS the said (1)*....................has and during the time during which
he shall continue to be in the service of or employed by the Government of.................will have
amongst other duties the care, charge and oversight of, and responsibility for the safe and proper
storing in the places (if any) appointed for the custody thereof and keeping of all papers, property,
chattels and effects (hereinafter together only called "the said property") received by or made over to
him the said (1)*...................in the course of business entrusted to him in respect of the office for the
time being held by any person or persons whomsoever and for any purpose or purposes whatsoever
................AND WHEREAS the said (2)*...........and (3)*................as his the said
(1)*...................sureties in that behalf have entered into the above bond in the penal sum of
Rs.........................conditioned for the due performance by him the said (1)*..................of the duties
of the said office aforesaid and of other the duties appertaining thereto which may lawfully be
required of him and for the due performance by him the said (1)*.............of the duties of any other
office to which he the said (1)*.............may from time to time be appointed for the purpose of
securing and indemnifying the said Governor of Bihar and his servants against all loss from or by
reason of the acts or defaults of him the said (1)*........Now the condition of the above written bond is
such that if the said (1)* .......... [has whilst he has held the said office of ........................as aforesaid
always duly performed and fulfilled the said duties of the said office and other duties aforesaid and if
he the said (1)*] [If the officer has not held office previous to signing of the bond the words in
brackets may be omitted.] shall whilst he shall be in the service of or employed by the Government
of.......................always duly perform and fulfil all and every the duties of the said office or other the
office for the time being held by him the said (1)*....................and further that if the said (2)*.............
and (3)* ....................do and shall indemnify and save harmless the said Governor of Bihar, his
successors and assigns the Government of........................and all and every the person or persons
who from time to time has or have or shall hold or exercise the said Office of District Officer of
..................:.......and other the District Officers from time to time having control over the office for
the time being held by the said (1)*..................from all and every loss and damage which 1[during
the time of and the said (1)* has held, executed and enjoyed the said office has happened or been
sustained or] shall or may at any time or times hereafter during the time that he the said
(1)*...................shall be in the service of or employed by the Government of
........................................................... shall happen to or be sustained by the said Governor of Bihar,
his successors or assigns the Government of or the said.................District Officers by, from or
through the means of the neglect, failure, misconduct, disobedience, omission or insolvency of the
said (1)* or by, from or through the consuming, wasting, embezzling, stealing, mis-spending, losing,
misapplying or otherwise dishonestly or negligently or through oversight or violence making away
or parting with the said property or any part or parts thereof by the said (1)* ................. during the
whole of the time during which the said (1)*................... [has been] [If the officer has not held office
previous to singing of the bond, the words in bracket may be omitted.] and shall continue to be inBihar Board's Miscellaneous Rules, 1958

the service of or employed by the Government of..........................whatever the nature of the office
may for the time being held by him may be and wheresoever such office may be situate then this
obligation to be void and of no effect otherwise the same shall be and remain in full force and virtue.
Provided always and it is hereby agreed and declared that neither of them the said
(2)*..................and (3)*............ shall be at liberty to terminate their suretyship except upon giving to
the District Officer for the time being of the Government of ..........................................................six
calendar months' notice in writing of his or their intention so to do and joint and their several
liability under this bond shall continue in respect of all omissions and defaults on the part of the
said (1)*.............until the expiration of the said period of six months.*(1) Principal *(2) First surety
(3) Second suretyNote. - When the sureties are unable to read English, care should be taken that the
provisions of the bond are explained to them before execution and the persons doing this should in
every such case attest the signature of the sureties and make a note at the foot of the attestation
clause that the terms of the bond were so explained.Appendix P(See Rule 220)Form of security bond
to be executed without sureties by the officers named in Rule 220 who have not the handling of
Government money and who deposit the whole of their security at the time of execution.Know all
men by these presents that .............................................................................son
of...................................resident of....................................................
....................village............................................ ................................................thana........................in
the district of...................................is held and firmly bound unto the Governor of Bihar in the sum
of Rs......................to be paid to the said Governor of Bihar, his successors or assigns or his or their
certain attorney or attorneys for which payment well and truly to be made I bind myself, my heirs,
executors, administrators and representatives firmly by these presents sealed with my seal, dated
this...........day 20.....................and I do hereby for my heirs, executors, administrators and
representatives covenant with the said Governor of Bihar his successors and assigns that if any suit
shall be brought touching the subject-matter of this obligation or the condition hereunder written in
any Court other than a High Court of Judicature in its ordinary original jurisdiction the same shall
and may at the instance of the said Governor of Bihar be removed into, tried and determined in its
extraordinary original jurisdiction by the High Court to whose superintendence the Court in which
the suit has been brought is subject.WHEREAS the above bounden was on the...day
of.............20................appointed to and now holds and exercise the office of..................at................in
the district of............................ AND WHEREAS the said .. may hereafter from time to time be
appointed to some other office and it is expressly intended and agreed that this security shall remain
in force during the whole of the time during which the said .....................shall be in the service of or
employed by the Government of........................whatever the nature of the office for the time being
held by him may be and wherever such office may be situate and whereas the said ......................has
and during the time during which he shall continue to be in the service of or employed by the
Government of will have amongst other duties the care, charge and oversight of and responsibility
for the safe and proper storing in the places (if any) appointed for the custody thereof and keeping of
all papers, property, chattels and effects (hereinafter together only called the "said property")
received by or made over to him the said......................... in the course of the business entrusted to
him in respect of the office for the time being held by him by any person or persons whomsoever and
for any purpose or purposes whatsoever and whereas the said..........................in consideration of his
said appointment has delivered to and deposited with [and endorsed over to] [If the officer deposits
cash as security, the words in single brackets must be omitted throughout; If Government securities,Bihar Board's Miscellaneous Rules, 1958

the words in double brackets must be omitted.] ......... as the District Officer of [(the sum
of..........................Rs........................)] [(Government securities to the extent of Rs........................... of
which the number, amounts and other particulars are specified in the schedule hereunder written]
for the purpose of in part securing and indemnifying the said Governor of Bihar, his successors and
assigns against all loss and damage which he or they might or may in any way suffer by reason of the
said property or any part or parts thereof being in any way consumed, wasted, embezzled, stolen,
mis-spent, misapplied or otherwise dishonestly or negligently or by or through oversight or violence
made away or parted with by him the said..................AND WHEREAS the said has entered into the
above bond in the penal sum of Rs.............................. conditioned for the due performance by him of
the duties of the said office aforesaid and to the other duties appertaining thereto which may
lawfully be required of him and for the due performance by him of the duties of any other office
which he may from time to time be appointed and for the purpose of securing and indemnifying the
said Governor of Bihar, his successors and assigns and his and their servants against all loss and
damage which he or they might or may in any way suffer by reason of any act or default or neglect of
the said.Now the condition of the above written bond is such that if he the said [has whilst he has
held the said office of as aforesaid always duly performed and fulfilled the said duties of the said
office and other the duties aforesaid and if he the said ...................) shall whilst he shall be in the
service of or employed by the Government of..............always duly perform and fulfil all and every the
duties of the said office or other the office for the time being held by him the said..................and
further if he the said........do and shall indemnify and save harmless the said Governor of Bihar, his
successors and assigns the Government of............... and all and every the person or persons who
from time to time has or have held or shall hold or exercise the office of District Officer
of................and other the District Officers from time to time having control over the office for the
time being held by the said from and against all and every loss and damage which [during the time
the said............ has held executed and enjoyed the said office has happened or been sustained or] [If
the officer has not held office provisions to signing the bond, the words in brackets are
unnecessary.] shall or may at any time or times hereafter during the time that he the said
.................shall be in the service of or employed by the Government of................ happen to or be
sustained by the said Governor of Bihar, his successors or assigns the Government of ............. or the
said District Officer or Officers by, from or through the means of the neglect, failure, misconduct,
disobedience, omission or insolvency of him the said ............... by, from or through the consuming,
wasting, embezzling stealing, mis-spending, losing, misapplying or otherwise dishonestly or
negligently or through over-sight or violence making away or parting with the said property or any
part or parts thereof by him the said............during the whole of the time during which he the said1
[has been and] shall continue to be in the service of or employed by the Government of whatever the
nature of the office for the time being held by him may be and wherever such office may be situate
then this obligation to be void and of no effect otherwise the same shall be and remain in full force
and virtue.PROVIDED ALWAYS and it is hereby agreed and declared that the [(said sum of
Rs....................)] [Government promissory notes for Rs ...........] so deposited as aforesaid or such
Government security or securities to the same amount as the District Officer of the Government
of............ may consent from time to time to accept and receive and shall accordingly receive in
exchange for the same and the interest thereof shall be and remain with the said District Officer for
the time being of the Government of..............as and for part and additional security to the said
Governor of Bihar his successors or assigns for the purposes aforesaid with full power to the saidBihar Board's Miscellaneous Rules, 1958

Governor of Bihar, his successors or assigns or his or their officers and servants duly authorised in
that behalf from time to time as occasion shall require to [sell and] dispose of the said [(sum of
Rs........)] [Government promissory notes for Rs............. [or any notes that may have been
substituted therefor or a sufficient portion thereof with the interest thereon and to apply the
proceeds thereof in and towards the indemnity as aforesaid of the said Governor of Bihar, his
successors and assigns the Government of................or the said District Officer or Officers as the case
may require but nevertheless the interest of the said [(sum of Rs...........)] [(Government promissory
notes for Rs..........)] or any notes that may have been substituted therefor may in the meantime be
paid over as the same shall be realised by the said District Officer of the Government of ... if he shall
think fit to the said.and it is hereby lastly agreed and declared that on the said..........ceasing to be in
the employ of the Government of........................the said [(sum of Rs )] [Government promissory
notes for Rs ] or any notes they may have been substituted therefor as aforesaid shall not be at once
returned to him but shall be and remain with the said (4) [............] [The authority with whom the
security is deposited.]for the term of six months as security against any loss that may have been
incurred by the said Governor of Bihar, his successors or assigns the Government of .....................or
other said District Officer or Officers owing to the neglect or default of the said........which may not
have been discovered until after the vacation of his appointment by the said.......PROVIDED
ALWAYS that the return at any time of the said [(the sum of Rs.......................)] [Government
promissory notes for Rs.] or any notes that may have been substituted therefor as aforesaid shall not
be deemed to affect the right of the Governor of Bihar, his successors and assigns to take
proceedings upon the said bond against the said in case any breach of the conditions of the said
bond shall be discovered after the return of the said [(sum of Rs..............)] [Government promissory
notes for Rs.............] or any notes that may have been substituted therefor as aforesaid.[The
Schedule above referred to]Appendix Q(See Rules 215 and 220)Form of security bond to be
executed without sureties by the officers named in Rule 220 who have not the handling of
Government money and who deposit their security in instalments.Know all men by these presents
that...................................................son of.....................................'...........................................
residence
of...............................'............................................village.................................................thana
..............................................in the district of is held and firmly bound unto the said Governor of
Bihar, his successors or assigns or his or their certain attorney or attorneys for which payment well
and truly to be made I bind myself, my heirs, executors, administrators, and representatives firmly
by these presents sealed with my seal, dated this................day of..............20 ....................and I do
hereby for my heirs, executors, administrators and representatives covenant with the said Governor
of Bihar his successors and assigns that if any suit shall be brought touching the subject-matter of
this obligation or the condition hereunder written in any Court other than a High Court of
Judicature in its ordinary original jurisdiction, the same shall and may at the instance of the said
Governor of Bihar be removed into, tried and determined in its extraordinary original jurisdiction
by the High Court to whose superintendence the Court in which the suit has been brought is
subject.WHEREAS the above bounden.................was on the......................day of..............20
appointed to and now holds and exercises the office of...........at in the district of.............AND
WHEREAS the said..............may hereafter from time to time be appointed to some other office and
it is expressly intended and agreed that this security shall remain in force during the whole of the
time during the said shall be in the service of or employed by the Government of................whateverBihar Board's Miscellaneous Rules, 1958

the nature of the office for the time being held by him may be and wherever such office may be
situate AND WHEREAS the said.................... has and during the time during which he shall
continue to be in the service of or employed by the Government of..............will have amongst other
duties the care, charge and Oversight of and responsibility for the safe and proper storing in the
places (if any) appointed for custody thereof and keeping of all papers, property, chattels and effects
(hereinafter together only called "the said property") received by or made over to him the
said,................in the course of the business entrusted to him in respect of the office for the time
being held by him by any person or persons whomsoever and for any purpose or purposes
whatsoever AND WHEREAS the said......................... in consideration of his said appointment has
agreed to deliver to and deposit with [and endorse over to] [If the officer deposits cash as security,
the words in single brackets must be omitted throughout; If Government securities, the words in
double brackets must be omitted.]...............as the District Officer of...............[(the sum of
Rs..................)] [Government securities to the extent of Rs.............] for the purposes of in part
securing and indemnifying the said Governor of Bihar, his successors and assigns against ail loss
and damage which he or they might or may in any way suffer by reason of the said property or any
part or parts thereof being in any way consumed, wasted, embezzled, stolen, mis-spent, misapplied
or otherwise dishonestly or negligently or by or through oversight or violence made away or parted
with by him the said........................AND WHEREAS the said.................has already delivered to and
deposited with [and endorsed over to] as such District Officer as aforesaid [(the sum of
Rs.....................)] [(Government security to the extent of Rs...............of which the numbers, amounts
and other particulars are specified in the schedule hereunder written] part of the said security so to
be deposited as aforesaid and it has been agreed that the said...................shall deliver to and deposit
with [and endorse over to] the said ...................... as such District Officer as aforesaid the balance of
the said [(sum of Rs...........)] [Government securities to the extent of Rs ................] so to be
deposited as aforesaid in monthly instalments of......................such monthly instalment to be
deducted from the salary of the said if the said District Officer shall so think fit AND WHEREAS the
said................has entered into the above bond in the penal sum of Rs..................conditioned for the
due performance by him of the duties of the said office aforesaid and of other the duties
appertaining thereto or which may lawfully be required of him and for the due performance by him
of the duties of any other office to which he may from time to time be appointed and for the purpose
of securing and indemnifying the said Governor of Bihar his successors and assigns and his and
their servants against all loss and damage which he or they might or may in any way suffer by reason
of any act or default or neglect of the said .......................Now the condition of the above written
bond is such that if he the said.............*[has whilst he has held the said office of................as
aforesaid always duly performed and fulfilled the said duties of the said office and other duties
aforesaid and if he the said............), shall whilst he shall be in the service of or employed by the
Government of.....................always duly performed and fulfil all and every the duties of the said
office or other the office for the time being held by him the said..................and further that if he the
said .................do and shall indemnify and save harmless the said Governor of Bihar, his successors
and assigns the Government of........................all and every person or persons who from time to time
has or have held or shall hold or exercise the office of District Officer of................. and other the
District Officers from time to time having control over the office for the time being held by the
said................ from and against all and every loss and damage which [during the time the
said................ has held executed and enjoyed the said office has happened or been sustained or] [IfBihar Board's Miscellaneous Rules, 1958

the officer has not held office previous to signing the bond, the words in brackets are unnecessary.]
shall or may at any times or time hereafter during the time that he the said...............shall be in the
service of or employed by the Government of...................... happen to or be sustained by the said
Governor of Bihar, his successors or assigns, the Government ................. of the said District Officer
or Officers by, from or through the means of the neglect, failure, misconduct, disobedience,
omission or insolvency of the said................or by, from or through the consuming, wasting,
embezzling, mis-spending, losing, mis-applying or otherwise dishonestly or negligently or through
oversight or violence making away or parting with the said property or any part or parts thereof by
him the said................ during the whole of the time during which he the said [has been and] shall
continue to be in the service of or employed by the Government of...................whatever the nature of
the office for the time being held by him may be and wherever such office may be situate then the
obligation to be void and of no effect otherwise the same shall be and remain in full force and virtue.
PROVIDED ALWAYS and it is hereby agreed and declared that the [(said sum of Rs...................)]
[Government promissory notes for Rs................. or so much thereof as shall for the time being have
been deposited or such Government security or securities to the same amount as the District Officer
of the Government of may consent from time o time accept and receive and shall accordingly receive
in exchange for the same and the interest thereof shall be and remain with the said District Officer
for the time being of the Government of..................... as and for part and additional security to the
said Governor of Bihar, his successors or assigns for the purposes aforesaid with full power to the
said Governor of Bihar, has successors or assigns or his or their officers and servants duly
authorised in this behalf from time to time as occasion shall require to {sell and) dispose of the said
(sum of Rs...........) Government promissory notes for Rs................... or so much thereof as shall for
the time being have been deposited or any notes that may have been substituted thereof or a
sufficient portion thereof with the interest thereon and to apply the proceeds thereof in and towards
the indemnity of aforesaid of the Governor of Bihar his successors and assigns the Government
of.................. or the said District Officer or Officers as the case may require but nevertheless the
interest of the said (sum of Rs....................... Government promissory notes for Rs. ..............) or so
much thereof as shall for the time being have been deposited or any notes that may have been
substituted therefor may in the meantime be paid over as the same shall be realised by the said
District Officer of the Government of ...............if he shall think fit to the said...........and it is hereby
lastly agreed and declared that on the said.................ceasing to be in the employ of the Government
of ..................the said (sum of Rs.......................) .................[Government promissory notes for Rs
..............] or so much thereof as shall have been deposited or any notes that may have been
substituted therefor as aforesaid shall not be at once returned to him but shall be and remain with
the said [(4)] [The authority with whom the security is deposited.]............... for the term of six
months as security against any loss that may have been incurred by the said Governor of Bihar, his
successors or assigns the Government of................or the said District Officer or Officers owing to the
neglect or default of the said................which may not have been discovered until after the vacations
of his appointment by the said ...............PROVIDED ALWAYS that the return at any time, of the said
[(sum of Rs................)] [Government promissory notes for Rs..................] or so much thereof as
shall have been deposited or any notes that may have been substituted therefor as aforesaid shall
not be deemed to affect the right of the said Governor of Bihar, his successors and assigns to take
proceedings upon the said bond against the said in case any breach of the condition of the said bond
shall be discovered after the return of the said [(sum of Rs...............)] [Government promissoryBihar Board's Miscellaneous Rules, 1958

notes for Rs................] or so much thereof as shall have been deposited or any notes that may have
been substituted therefor as aforesaid.[The Schedule above referred to]Appendix R(See Rule
219)Form of Security Bond for TreasurersKnow all men by these presents
that...................................(Principal) of ................................... (1st surety) (2nd surety)
................................................................... are held and firmly bound unto the Governor of Bihar in
the sum of Rs....................to be paid to the said Governor of Bihar, his successors or assigns or his or
their certain attorney or attorneys for which payment well and truly to be made we bind ourselves,
our heirs, executors, administrators, and representatives jointly and each of us binds himself, his
heirs, executors, administrators and representatives severally firmly..................these presents sealed
without seals, dated this ...............day of...................20................and each of us the said doth hereby
for himself, his heirs, executors, administrators and representatives covenant with the said
Governor of Bihar, his successors and assigns, that if any suit shall be brought touching the
subject-matter of this obligation or the condition hereunder written in any Court other than a High
Court of Judicature in its ordinary original jurisdiction the same shall and may at the instance of the
said Governor of Bihar be removed into, tried and determined by the said High Court in its
extraordinary original jurisdiction.WHEREAS the above bounden........................was on
the................day................ of................20..................appointed to and now holds and exercises the
office of treasurer at..................AND WHEREAS by virtue of such office the said................has
amongst other duties the care, charge and oversight of and responsibility for the safe and proper
storing and keeping in the places appointed for the custody thereof respectively of all money, specie,
bullion, coins, jewels, Government currency notes, stamps and Government securities of whatever
description, gold, silver, copper, lead, goods, chattels or effects stored and used at, received into or
despatched from the Treasury of ...............or paid, despatched or brought into the said treasury by
any person or persons whomsoever and for any purpose or purposes whatsoever AND WHEREAS
the said ....................... as such treasurer as aforesaid is also responsible that all such moneys, specie,
bullion, coin, jewels, Government currency notes, stamps and Government securities of whatsoever
description, gold, silver, copper, lead, goods, stores, chattels or effects (hereinafter together called
"the said property") are and is of full measure and good quality when received into said treasury and
until he has duly accounted therefor and for every part thereof in manner hereinafter referred to
AND WHEREAS the said......................... is bound from time to time whenever called upon so to do
to show to his superior officer that the said property and every part thereof save so much thereof as
he has duly accounted for is at all times intact in the places aforesaid and is also bound to attend for
the purpose of discharging his duties aforesaid at such times and places as his superior officers may
appoint AND WHEREAS the said..........................is further bound to keep true and faithful accounts
of the said property and of his dealings under written orders of his superior officers therewith
respectively in the form and manner that may from time to time be prescribed under the authority
of Government and also to prepare and submit such returns and such accounts as he may from time
to time be called upon to prepare and submit AND WHEREAS the bulk of the said property remains
as well in the care, charge and custody of the treasury officer for the time being at................ as of the
said...............but as between himself and the said Governor of Bihar he the said....................is alone
responsible and answerable therefor as the every part thereof AND WHEREAS the responsibility of
the said....................for the said property and every part thereof does not cease until the same has
been duly used under the written orders aforesaid and accounted for or been duly despatched from
the said treasury and delivered over to and a full and complete discharge therefor obtained fromBihar Board's Miscellaneous Rules, 1958

such persons and at such places as the District Officer of............................................. or other the
person exercising his functions for the time being under the sanction of the Government of
....................... may direct AND WHEREAS the said ................in consideration of his said
appointment has delivered to and deposited with and endorsed over to....................... as such
District Officer as aforesaid Government securities to the extent of Rs....................... of which the
numbers, amounts and other particulars are set forth and specified in the schedule hereunder
written for the purpose of the part securing and indemnifying the said Governor of Bihar, his
successors and assigns against all loss and damage which he or they may in any way suffer by reason
of the said property or any part or parts thereof being in any way consumed, wasted, embezzled,
stolen, mis-spent, lost, misapplied or otherwise dishonestly or negligently or by or through oversight
or violence made away or parted with by himself the said .................................... of any person acting
for him in his said office during his absence or otherwise who has been nominated or accepted by
him or by any sub-treasurer, servants, clerks, sircars, cash-keepers, poddars, coolies or other
persons nominated or accepted by and serving under him the said.....................or any person acting
for him in his said office as aforesaid AND WHEREAS the said ......................................................
hereby acknowledges that he is bound by all the conditions, rules and regulations of Civil Account
Code of the Government of India for the time being in force and such departmental rules and order
as may from time to time be issued by authority and may be in force and specially those with
reference to his relations and dealing with and the rights of his subordinates and his own
subordination to his superior officers and that it is his duty to keep himself acquainted at all times
with the contents of such Code and such departmental rules and orders as aforesaid and all or any
alterations made from time to time therein AND WHEREAS the
said...............(principal).................and the said (1st surety...................and (2nd
surety).....................as his the said..................sureties in that behalf have entered into the above
bond in the penal sum of ..................................conditioned for the due performance by him the
said.......................and of any such person as aforesaid acting for him in his said office during his
absence or otherwise of the duties of the said office as aforesaid and of other the duties appertaining
thereto or which may lawfully be required of him or such other persons and the indemnity of the
said Governor of Bihar, and his servants against loss from or by reason of the acts or defaults of the
said and of all and every the persons and the persons aforesaid.Now the condition of the above
written bond is such that if the said................and every person acting for him in his said office as
aforesaid has whilst they respectively have held or exercised the duties of the said office of treasurer
as aforesaid always duly performed and fulfilled the said duties of the said office and other the
duties aforesaid and if he the said ,.............................................and every person acting for him in his
said office as aforesaid shall whilst respectively shall hold or exercise the duties of.....................the
said office always duly perform and fulfil all and every the duties thereof aforesaid and perform and
observe all and every the conditions, rules and regulation of the said Code and the said departmental
rules and orders and further if the said ..................and do and shall indemnify and save harmless the
said Governor of Bihar, his successors and assigns the Government of..................and all and every
person or persons who from time to time has or have held or shall hold or exercise the said office of
District Officer and all other servants of the said Governor of Bihar or the said Government
of.................from and against all and every loss and damage which during the time the
said.................or any person acting for him during his said office as aforesaid has held, executed and
enjoyed the said office has happened or been sustained shall or may at time or times happen to or beBihar Board's Miscellaneous Rules, 1958

sustained by the said Governor of Bihar his successors or assigns the Government of.................or the
said District Officer for the time being or any such servant as aforesaid by, from or through the
means of the neglect, failure, misconduct, disobedience, omission or insolvency of the said
..............or of any person acting for him in his said office as aforesaid or any of the sub-treasurers,
servants, clerks, sircars, cash-keepers, poddars, coolies or other persons nominated or accepted by
and serving under him the said.............or any person acting for him in his said office as aforesaid or
by, from or through the consuming, wasting, embezzling, stealing, mis-spending, losing,
misapplying or otherwise dishonestly or negligently or through oversight or violence making away
or parting with the said property or any part or parts thereof by any such person or persons
aforesaid whilst he the said...............or any person acting for him in his said office as aforesaid has
held or executed the duties of the said office or shall hold or execute the duties of the said office
;THEN this obligation shall be void and of no effect. Otherwise the same shall be and remain in full
force and virtue :PROVIDED ALWAYS and it is hereby agreed and declared that neither of them the
said................and.................shall be at liberty to terminate their suretyship except upon giving to the
District Officer for the time being of the Government of................six calendar months' notice in
writing of his or their intention so to do and the liability under this bond in the event of any such
notice being given shall be thereby determined in respect only of acts and omissions happening after
the expiration of the said period of six months. PROVIDED ALWAYS and it is hereby declared and
agreed by the said .....................and.............. and ................with the said Governor of Bihar that the
Government promissory notes for Rs..................so deposited as aforesaid or such other Government
security or securities to the same amount as the District Officer for the time being of the
Government of................may consent from time to time to accept and receive and shall accordingly
receive in lieu of or exchange for the same and the interest thereof respectively shall and remain
with the said District Officer for the time being of the Government of ........... as and for further part
and additional occasion shall require to sell and dispose of the said Government securities or his
successors or assigns for the indemnity and other purposes aforesaid with full powers to the said
Governor of Bihar, his successors or assigns or his or their officers and servants duly authorised in
that behalf from time to time as occasion shall require to sell and dispose of the said Government
securities or any part thereof and to apply the proceeds thereof together with any interest receivable
or received in respect of such Government securities in and towards the indemnity as aforesaid of
the said Governor of Bihar, his successors or assigns as the case may require but nevertheless the
interest of the said Government securities may in the meantime be paid over as the same shall be
realised by the said District Officer for the time being or the Government of................if they shall
think fit to the said.............PROVIDED ALWAYS and it is hereby expressly agreed and declared
between and by the said.................and.................and.....................and the Governor of Bihar that it
shall be lawful for the said................with the consent of the said District Officer or of other person
exercising his functions for the time being under the sanction of the Government
of......................first had and obtained to change and substitute for the said Government promissory
notes for Rs........................so deposited as aforesaid or any part thereof or for any notes substituted
therefor under the present provisions from time to time other notes of the same or other loans of the
same or greater value without in any way affecting the obligations of the said bond or the liability of
the said................and..................as such securities as aforesaid...................AND it is hereby lastly
agreed and declared by and between the said........................(one surety)...............(other surety) as
his the said.................(Principal's) sureties and the said Governor of Bihar that in the event of theBihar Board's Miscellaneous Rules, 1958

death of the said................(Principal's) or the vacation by him of his said office of Treasurer the
abovementioned Government promissory notes for Rs....................or any notes that may be
substituted therefor as aforesaid shall be retained with the said District Officer for the time being for
the term of six months after the date of such death or such vacation as the case may be as security
against any loss or damage that may have been or may thereafter be incurred by the said Governor
of Bihar, his successors and assigns and in respect of which the said ......................... (principal) and
his heirs, executors, administrators and representatives after his death is and or shall or may be
liable to indemnify the Governor of Bihar, his successors and assigns the Government of India and
all such persons aforesaid : PROVIDED ALWAYS that the return at any time of the said Government
promissory notes shall not be deemed to affect the right of the said Governor of Bihar to take
proceedings upon or under the said bond against the said.................... (principal)
and.....................(1st surety) .................and (2nd surety)..................or any of them in case any breach
of the conditions of the bond shall be discovered after the return of said Government promissory
notes but the responsibility of the said ........................ (principal) ................and of the said (1st
surety).....................and of the said (2nd surety) ..................shall at all times continue and the said
Governor of Bihar shall be fully indemnified against all such loss or damage as aforesaid at any
time.[The Schedule above referred to]Appendix S[See Rule 219]Form of Security Bond for Acting
TreasurersKnow all men by these presents that..........................................son
of.........................................(Principal)...............................................of...........................................(1st
surety) (2nd
surety)..............................................of.........................................................................and.....................................son
of................................................................son of............ are held and firmly bound unto the Governor
of Bihar in the sum of Rs.................to be paid to the Governor of Bihar, his successors or assigns or
his or their certain attorney or attorneys for which payment well and truly to be made we bind
ourselves, our heirs, executors, administrators and representatives jointly and every two of us bind
ourselves, our heirs, executors, administrators and representatives jointly and each of us binds
himself, his heirs, executors, administrators and representatives severally firmly by these presents
sealed with our seals, dated this ............................day of 20 and each of us the said doth hereby for
himself, his heirs, executors, administrators and representatives covenant with the said Governor of
Bihar, his successors and assigns that if any suit shall be brought touching the subject-matter of this
obligation or the condition hereunder written in any Court subject to the High Court of Judicature at
Patna, the same shall and may at the instance of the said Governor of Bihar be removed into, tried
and determined by the said High Court in its extraordinary original jurisdiction.WHEREAS the
above bounden ........................was on the................day of.................20................appointed to and
now holds and exercises the office of acting Treasurer at ; ANDWHEREAS by virtue of such office
the said ...............has amongst other duties the care, charge and oversight of, and responsibility for
the safe and proper storing and keeping in the places appointed for the custody thereof respectively
of all moneys, specie, bullion, coin, jewels, Government currency, notes, stamps and Government
securities of whatever description, gold, silver, copper, lead, goods, stores, chattels or effects stored
and used at, received into or despatched from the Treasury of or paid, deposited or brought into the
said Treasury by any person or persons whomsoever and for any purpose or purposes whatsoever;
AND WHEREAS the said.................as such................. acting Treasurer as aforesaid is also
responsible that all such moneys, specie, bullion, coin, jewels, Government currency notes, stamps
and Government securities of whatsoever description, gold, silver, copper, lead, goods, stores,Bihar Board's Miscellaneous Rules, 1958

chattels or effects (hereinafter together called "the said property") are and is of full measure and
good quality when received into the said Treasury and until he has duly accounted therefor and for
every part thereof in manner hereinafter referred to; AND WHEREAS the said.......................is
bound from time to time, whenever called upon so to do to show his superior officers that the said
property and every part thereof, save so much thereof as he has duly accounted for, is at all times
intact in the places aforesaid, and is also bound to attend for the purpose of discharging his duties
aforesaid, at such times and places as his superior officers may appoint; ANDWHEREAS the
said...................is further bound to keep true and faithful accounts of the said property and of his
dealings underwritten orders of his superior officers therewith respectively in the form and manner
that may from time to time be prescribed under the authority of Government and also to prepare
and submit such return and such accounts as he may from time to time be called upon to prepare
and submit; ANDWHEREAS the bulk of the said property remains as well as in the care, charge, and
custody of the Treasury Officer for the time being at.................as of the said................but as between
himself and the said Governor of Bihar he......................the said is alone responsible and answerable
therefor and for every part thereof : AND WHEREAS the responsibility of the said.....................for
the said property and every part thereof does not cease until the same has been duly used under the
written orders aforesaid and accounted for or been duly despatched from the said Treasury and
delivered over to and a full and complete discharge therefor obtained from such persons and at such
places as the District Officer of.................... or other person exercising his function for the time being
under the sanction of the Government of....................may direct ANDWHEREAS the
said.....................in consideration of his said appointment has entered into this bond.................. for
the purpose of in part securing and indemnifying the said Governor of Bihar his successors and
assigns against all loss and damage which he or they may in any way suffer by reason of the said
property or any part or parts thereof being in any way consumed, wasted, embezzled, stolen,
mis-spent, lost, misapplied or otherwise dishonestly or negligently or by or through oversight or
violence made away or parted with by himself the said...................or any person acting for him in his
said office during his absence or otherwise, who has been nominated or accepted by him, or by any
sub-treasurers, servants, clerks, sircars, cash-keepers, poddars, coolies or other persons nominated
or accepted by and serving under him the said ................or any person acting for him in his said
office as aforesaid, AND WHEREAS the said.....................hereby acknowledges that he is bound by
all the conditions, rules and regulations of the Civil Account Code of the Government of India for the
time being in force and such departmental rules and orders as may from time to time be issued by
authority and may be in force and specially those with reference to his relations and dealings with
and the rights of the subordinates and his own subordination to his superior officers, and that it is
his duty to keep himself acquainted at all times with the contents of such Code and such
departmental rules and orders aforesaid and all or any alterations made from time to time therein :
AND WHEREAS the said (Principal)...................................and the said (1st surety) and (2nd surety) .
as his the said ................sureties in that behalf have entered into the above bond in the penal sum
of..................conditioned for the due performance by him the said ................and of any such person
as aforesaid acting for him in this said offices during his absence or otherwise of the duties of the
said office aforesaid and of other the duties appertaining thereto or which may lawfully be required
of him or such other person and the indemnity of the said Governor of Bihar and his servants
against loss from or by reason and of all and every the persons and person aforesaid,..................Now
the condition of the above written bond is such that if the said................and every person acting forBihar Board's Miscellaneous Rules, 1958

him in his said office as aforesaid has, whilst they respectively have held or exercised the duties of
the said office of acting Treasury as aforesaid, always duly performed and fulfilled the said duties of
the said office and other the duties aforesaid, and if he the said ................and every person acting for
him in his said office as aforesaid shall, whilst they respectively shall hold or exercise the duties of
..............the said office, always duly performed and fulfil all and every duties thereof aforesaid, and
perform and observe all and every the conditions, rules and regulations of the said Code and the said
departmental rules and orders and further if the said................and...............do and shall indemnify
and save harmless the said Governor of Bihar, his successors and assigns the Government
of..................and all and every person or persons who from time to time has or have held or shall
hold or exercise the said office of District Officer and all other servants of the said Governor of Bihar
or the said Government of ..............from and against all and every loss and damage which during the
time the said ...............or any person acting for him during his said office as aforesaid has held,
executed and enjoyed the said office has happened or been sustained or shall or may or at any time
or times hereafter happened to or been sustained by the said Governor of Bihar, his successors or
assigns or the Government of ..................or the said District Officer for the time being or any such
servant as aforesaid by, from or through the means of the neglect, failure, misconduct disobedience,
omission or insolvency of the said ...............or of any person acting for him in his said office as
aforesaid or of any of the sub-treasurers, servants, clerks, sircars, cash-keepers, poddars, coolies or
other persons nominated or accepted by and serving under him the said................. or any person
acing for him in his said office as aforesaid or by, from, or through the consuming, wasting,
embezzling, stealing, mis-spending, losing, misapplying or otherwise dishonestly or negligently or
through oversight or violence making away or parting with the said property or any part or parts
thereof by such person or persons aforesaid whilst he the said or any persons acting for him in his
said office as aforesaid has held or executed the duties of the said office or shall hold or execute the
duties of the said office ;THEN this obligation shall be void and of no effect. Otherwise the same
shall be and remain in full force and virtue.PROVIDED ALWAYS and it is hereby agreed and
declared that neither of them the said...................and shall...............be at liberty to terminate their
suretyship except upon giving to the District Officer for the time being of the Government of six
calendar months' notice in writing of his or their intention so to do and the liability under this bond,
in the event of any such notice being given, of the surety by whom it shall be given shall be thereby
determined in respect only of acts and omissions happening after the expiration of the said period of
six months.
Signed, sealed and delivered by the abovenamed.  
in  
  
the presence of  
of  
of  
Signed, sealed and delivered by the abovenamed  
in  
  
the presence of  Bihar Board's Miscellaneous Rules, 1958

of  
of  
Signed, sealed and delivered by the abovenamed  
in  
  
the presence of  
of  
of  
Appendix T(See Rule 216)Form of Security Bond for Ministerial Officers allowed to give Security in
Landed PropertyKnow all men by these presents that I......................................, son
of...................................................... resident of................................ ................. village
thana..................in the district of..............is held and firmly bound unto the Governor of Bihar in the
sum of Rs......................... to be paid to the said Governor of Bihar, his successors and assigns or his
or their certain attorney or attorneys for which payment well and truly to be made I bind myself, my
heirs, executors, administrators, and representatives firmly by these presents sealed with my seal,
dated this day of ............ 20................and I do hereby for my heirs, executors, administrators and
representatives covenant with the said Governor of Bihar, his successors and assigns that if any suit
shall be brought touching the subject matter of this obligation or the condition hereunder written in
any Court other than a High Court of Judicature in its ordinary original jurisdiction the same shall
and may at the instance of the said Governor of Bihar be removed into, tried and determined in its
extraordinary original jurisdiction by the High Court to whose superintendence the Court in which
the suit has been brought is subject.WHEREAS the above bounden..................... was on the day
..................................................................... of................20................ appointed and now holds and
exercises the office of ..............at............... in the district of.............. AND WHEREAS the said
................... may hereafter from time to time be transferred to some other place or appointed to
some other office at.................aforesaid or elsewhere and it expressly intended and agreed that this
security shall extend as a security not only in respect of any loss and damage which may be suffered
by the Governor of Bihar, his successors and assigns and his and their servants by reason of any act,
default or neglect of the said..........during his employment in the capacity aforesaid whether
at...............aforesaid or at any other place to which he may from time to time be transferred but also
in respect of any loss and damage which may be suffered by the Governor of Bihar, his successors
and assigns and his and their servants by reason of any act, default or neglect of the
said...............during his employment by the Government
of............................................................................. in any other capacity whatever the nature of the
office for the time being held by him may be and at whatever place the said.......................may for the
time being be stationed while in the service of or employed by the Government of .........................
AND WHEREAS the said ................ has and during the time during which he shall continue to be in
the service of or employed by the Government of ................ will have amongst other duties care,
charge and oversight of and responsibility for the safe and proper storing in the place (if any)
appointed for the custody thereof and keeping of all papers, chattels, effects, and property
(hereinafter together only called "the said property") received by or made over to him the
said................. by any person or persons whomsoever for any purpose or purposes whatsoever in the
course of the business entrusted to him in respect of the office for the time being held by him. ANDBihar Board's Miscellaneous Rules, 1958

WHEREAS under the Government rules for taking security from ministerial and non-gazetted
officers the said................has in addition to above-written bond to furnish security to the extent of
Rs AND WHEREAS in pursuance of rule.............the Collector of has consented the said security
being furnished by the said ......................... in landed property and by an Indenture of even date
herewith the said has executed in favour of the said Governor of Bihar a mortgage of the land and
hereditaments specified in the schedule hereunder written for the sum of Rs. .........................by way
of additional security to the said Governor of Bihar his successors and assigns and his and their
servants against any loss and damage which he or they might or may in any way suffer by reason of
any act, default or neglect of the said............... ANDWHEREAS by Rule 216 of the said rules it is
provided that in any case in which security in landed property is allowed thereunder the officer shall
be required to place 6 ¼ per cent of his pay in the Savings Bank as a security deposit and will be
entitled to have the security bond on the landed property cancelled as soon as the deposit is equal to
the amount of the security required ANDWHEREAS the said.....................has entered into the above
bond in the penal sum of Rs.................... conditioned for the due performance of the duties of the
said office aforesaid and of other the duties appertaining thereto or which may lawfully be required
of him and for due performance by him of the duties of any other office to which he may from time
to time be appointed and for the purpose of indemnifying the said Governor of Bihar, his successors
and assigns and his and their servants against all loss and damage as aforesaid. NOW THE
CONDITION of the above written bond is such that if the said shall on the.. day of every month
commencing with the................. day of.................. pay to the credit of the security deposit account
opened or to be opened with the Post Office Savings Bank in the name of the said................. 6 ¼
percent of his monthly pay for the time being until the sums so paid to the credit of such account
shall amount in the aggregate to the sum of Rs................ and if the said.............. do and shall at all
times during the continuance of the said mortgage security duly and punctually pay all Government
revenue, cesses, rates, taxes and other impositions and outgoings for the time being payable in
respect of the land and hereditaments mentioned in the schedule hereto and further if the said
.............. has whilst he has held the said office of ................ as aforesaid always duly performed and
fulfilled the said duties of the said office and other the duties aforesaid and if he the
said................shall whilst he shall be in the service of or employed by the Government
of...............always duly perform and fulfil all and every the duties of the said office or other the office
for the time being held by him the said.................. and further that if he the said ................ do and
shall indemnify and save harmless the said Governor of Bihar his successors and assigns the
Government of ..................and all and every the person or persons who from time to time has or
have held or shall hold or exercise the office of District Officer of...........and other the District Officer
from time to time having control over the office for the time being held by the said ...............from
and against all and every loss and damage which (during the time the said ................. has held,
executed and enjoyed the office has happened to or been sustained by or which) shall or may at any
times or time hereafter during the time that he the said shall be in the service of or employed by the
Government of .................... happened to or be sustained by the said Governor of Bihar his
successors or assigns the Government of ................ or the said District Officer or Officers by, from or
through the means of the neglect, failure, misconduct, disobedience, omission or insolvency of him
the said ...................or by, from or through the consuming, wasting, embezzling, stealing,
mis-spending, losing, mis-applying or otherwise dishonestly or negligently or through oversight or
violence making away or parting with the said property or any part or parts thereof by him theBihar Board's Miscellaneous Rules, 1958

said................during the whole of the time during which he the said (has been and) shall continue to
be in the service or employed by the Government of....................whatever the nature of the office for
the time being held by him may be and wherever such office may be situate then this obligation to be
void and of no effect otherwise the same shall be and remain in full force and virtue : PROVIDED
ALWAYS and it is hereby agreed and declared that the moneys for the time being standing to the
credit of the said security deposit account shall be and remain with the ................... for the time
being of the Government of................ as and for part and additional security to the said Governor of
Bihar his successors or assigns for the purposes aforesaid with full power to the said Governor of
Bihar his successors or assigns or his or their officers or servants duly authorised in that behalf from
time to time as occasion shall require to resort to the moneys for the time being standing to the
credit of the said deposit account and apply the same or a sufficient portion thereof in or towards
the indemnity as aforesaid of the said Governor of Bihar his successors or assigns and his and their
servants or (if the Government of ..............shall so think fit) in paying any Government revenue,
cesses, taxes or other imposition or outgoings for the time being payable in respect of the said land
and hereditaments mentioned in the schedule hereto and which shall not have been paid by the
said............... but nevertheless the interest from time to time accruing on the said money for the
time being standing to the credit of the said deposit account may in the meantime be paid over to
the said............... by the said ................ of the Government of................... if he shall think fit to the
said............... and it is hereby lastly agreed and declared that on the said ................ceasing to be in
the employ of the Government of ................... the moneys then standing to the credit of the said
deposit account shall not be at once made over to the said..............but shall be and remain with the
said................for the term of six months as security against any loss that may have been incurred by
the said Governor of Bihar his successors or assigns or his or their servants owing to any act, default
or neglect of the said .................and which may not have been discovered until after the cessation of
the employment of the said ........................ by the Government of ..............; PROVIDED ALWAYS
that the making over at any time of the moneys then standing to the credit of the said deposit
account shall not be deemed to effect the right of the said Governor of Bihar his successors or
assigns to take proceedings upon the said bond against the said..................in case any breach of the
condition of the said bond shall be discovered after the making over of the said moneys.[The
Schedule above referred to]Appendix U(See Rule 216)Form of Mortgage for Ministerial Officer
allowed to give security in Landed PropertyThis Indenture made on the day of.....................20
...............between..................of................ son of............... of the one part and Governor of Bihar
(hereinafter called the mortgagee) of the other part WHEREAS the said .................. was on
the................ day of ...............20.................. appointed to and now holds and exercises the office
of...............at................ in the district of........................AND WHEREAS under the rules of the
Government of..................for taking securing from ministerial and non-gazetted officers the
said...............has in addition to signing a bond in the penal sum of Rs...............to furnish security to
the extent of Rs................AND WHEREAS in pursuance of [Rule 216 of the Board's Miscellaneous
Rules 1947] [Now 1958.] the Collector of.............consented to the said security being furnished by
the said in landed property AND WHEREAS by the said [Rule 216 of the Board's Miscellaneous
Rules 1947] [Now 1958.] it is provided that any case in which security in landed property is allowed
thereunder the Officer shall be required to place 6 ¼ per cent of his pay in the Post Office Savings
Bank as a security deposit and will be entitled to have the security bond on the landed property
cancelled as soon as the deposit is equal to the amount of security required ANDWHEREAS theBihar Board's Miscellaneous Rules, 1958

said..................... on the............... day of.................. entered into a bond with mortgagee in the sum
of Rs. ............... to secure the due performance by the said................. of his duties as such and of
other the duties of the office for time being held by the said ................. while in the service of or
employed by the Government of ................. AND WHEREAS the land and hereditaments described
in the Schedule hereto and the absolute and sole property of the said...............and are free from all
encumbrances and it has been arranged that the said shall execute such mortgage of the said land
and hereditaments in favour of the mortgagee to secure the payment of the sum of Rs. ...............as is
hereinafter contained. NOW THIS INDENTURE WITNESSETH that in pursuance of and for
effectuating the said arrangement and in consideration of the premises he the said...............doth
hereby grant, convey and assigns into the mortgagee ALL that and those the lands and
hereditaments and premises in the said Schedule hereto described together with their respective
appurtenances and all the estate, right, title and interest whatsoever of the said.....................of into,
out of or upon the same premises or any part thereof and all deeds, pattahs, evidences and writings
or other monuments of title whatever relating to the said hereditaments and premises or any part
thereof and now in the custody, power or control of the said ................. to have and to hold the said
lands and hereditaments and all and singular other the premises hereinbefore expressed to be
hereby assured with their appurtenances (all which lands, hereditaments and premises are
hereinafter referred to as "the said mortgaged premises") unto the mortgagee for ever subject to the
proviso for redemption next hereinafter contained PROVIDED ALWAYS and it is hereby agreed and
declared that if the said................his heirs, executors, administrators, representatives or assigns or
some or one of them shall at all times carry out and perform all and every the conditions set forth in
the said bond and on his part to be performed and observed then and at any time not earlier than six
months after a final adjustment of account between the said...................or his representatives on the
one part and the mortgagee or his representatives or his or their successors in office on the other
part the mortgagee shall upon the request and at the costs and charges in all things of the said
..................... or his representatives reconvey the said mortgaged premises unto the said
........................... or his heirs, executors, administrators, representatives or assigns or as he or they
shall direct PROVIDED ALSO and it is hereby further agreed and declared that it shall be lawful for
the mortgagee at any time after the said...................shall have failed to carry out and perform any of
the conditions set forth in the said bond without any further consent on his part to give* notice in
writing to the mortgagor requiring payment of the principal money secured by these presents
pursuant to the provisions of Section 69 of the Transfer of Property Act, 1882, and upon default in
payment as mentioned in that Section to make, sell and dispose of the said mortgaged premises or
any part thereof either by public auction or private contract and either together or in parcels and
either subject or not subject to any special or other conditions or stipulations relative to title or
evidence of title or otherwise as may appear expedient and with full power to be in the same or any
part thereof at any auction and to rescind or vary the terms of any contract for sale and to resell
without being answerable for any loss occasioned thereby and otherwise to act in relation to such
sale or sales as may be deemed expedient for the purposes aforesaid or any of them to execute and
do all such assurances and things as to the mortgagee shall seem proper PROVIDED
NEVERTHELESS and it is hereby agreed and declared that upon any sale purporting to be made in
pursuance of the aforesaid power in that behalf the purchaser or purchasers shall not be bound to
see or enquire whether any such failure as aforesaid has happened or due notice has been given on
default made as aforesaid or as to the necessity or expediency or regularity of such sale andBihar Board's Miscellaneous Rules, 1958

notwithstanding any irregularity or impropriety whatsoever in any such sale the same shall as far as
regards the safety and protection of the purchaser or purchasers and whether he or they shall have
brought with notice thereof or not be within the aforesaid power of sale in that behalf and be valid
and effectful accordingly and the remedy of the said his heirs, executors, administrators,
representatives or assigns in respect of any impropriety or irregularity whatsoever in any such sale
shall be in damages only. And it is also agreed and declared that upon any such sale as aforesaid the
receipt of the mortgagee for purchase money of the premises sold shall effectually discharge the
purchaser or purchasers therefrom and from being concerned to see to the application or being
answerable for any loss or misapplication or non-application thereof and it is further agreed and
declared that the said mortgagee shall by and out of the moneys which shall arise from any such sale
as aforesaid in the first place reimburse himself or pay and discharge all the costs and expenses
incurred in or about such sale or otherwise in respect of the said premises and in the next place
apply such moneys in or towards the payment or satisfaction of the said sum of Rs and then hold the
surplus if any in trust for the said................... PROVIDED ALSO and it is hereby agreed and declared
that the mortgagee shall not be answerable or accountable for any involuntary losses which may
happen in or about the exercise of the aforesaid power and trusts of any of them PROVIDED ALSO
and it is hereby agreed and declared that all the rights and powers by the Indian Contract Act, 1872,
and by the Transfer of Property Act, 1882, respectively conferred upon a mortgagee or pledgee
which are in any way applicable to a security of the nature of these presents and which do not in any
way conflict with or restrict any of the powers herein expressly set forth shall be deemed as
incorporated herein and has hereby empowering the mortgagee his successors in office or assigns to
exercise the said rights and powers or any of them and the said .................doth hereby for himself
and his heirs, executors, administrators and representatives covenant with mortgagee his successors
in office and assigns as mentioned in Section 65 of the said Act IV of 1882 and that the covenant
mentioned in that Section shall be considered as embodied in and as forming part of these presents :
PROVIDED ALWAYS and it is hereby lastly agreed and declared that notwithstanding anything
hereinbefore contained in the said.................... shall, provided no steps shall in the meantime have
been taken to enforce this security, be entitled at his cost and expense to have the said mortgage
premises reconveyed to him when and so soon as the moneys to be deposited as aforesaid by the
said in the Post Office Savings Bank as a security deposit shall amount in the aggregate to the sum of
Rs...........................IN WITNESS WHEREOF the said parties to these presents have hereunto affixed
their hands and seals the day and year before written-Signed, sealed and delivered by the
.......................... abovenamed................in the presence of ...............* Under Section 69 of the
Transfer of Property Act a power of sale in favour of the Governor of Bihar is good but notice has to
be given calling for payment and default has to be made in payment of the whole or any part of the
mortgaged money for three months after giving such notice before the power of sale can be
exercised. The notice should require payment at once, otherwise, if it required payment within, say
three months, the defaulter would have not only this three months but an additional three months
of default, that is, six months in all before he could be brought to book.[The Schedule above referred
to]A mortgage requires to be witnessed by two witnesses and to be registered. The witnesses must
give their addresses and professions. The schedule must contain description of the property
sufficient to identify it.Appendix V(See Rule 222)Personal Security BondKnow all men by these
presents that we (A)................................................................ son of ................................. of village
........................................Police-station ............................................................ PostBihar Board's Miscellaneous Rules, 1958

Office....................District and the NATIONAL GUARANTEE AND SURETYSHIP ASSOCIATION,
LIMITED, having ..................our principal place of business in India at Calcutta are jointly and
severally held and firmly bond unto the Governor of Bihar in the sum of Rs................ to be paid to
the said Governor of Bihar, his successors or assigns or his or their certain attorney or attorneys, for
which payment well and truly to be made 1 the said (A) ............... for myself, my heirs, executors,
administrators and representatives and we the NATIONAL GUARANTEE AND SURETYSHIP
ASSOCIATION, LIMITED, for ourselves and our successors bind ourselves firmly by these presents,
dated the........................... day of ................. 20 ............... , AND each of us, the said (A) .................
for myself, my heirs, executors, administrators and representatives and the said NATIONAL
GUARANTEE AND SURETYSHIP ASSOCIATION, LIMITED, for ourselves and our successors
covenant with the said Governor of Bihar, his successors and assigns that if any suit shall be brought
touching the subject matter of this obligation or the condition hereunder written in any Court
subject to the High Court of Judicature at Patna other than the said High Court in the Ordinary
Original Civil Jurisdiction the same shall and may at the instance of the said Governor of Bihar be
removed into, tried and determined by the said High Court in its Extraordinary Original
Jurisdiction.WHEREAS the above bounden (A) was on the.... day of .................20...............................
appointed to and now holds the office of ................ in the Government service of the Province of
Bihar AND WHEREAS by virtue of his employment in the said .................... the said (A) .............. is
required to perform public duties in which the public are interested and has or is liable to have
amongst other duties to receive and deal with moneys as a servant of the Government and truly to
account for all moneys that come or ought to come into his hands as such servant, AND WHEREAS
the said (A) ................. has agreed and is bound to attend for the purpose of discharging his duties at
such times and places as his superior officers may appoint, AND WHEREAS the said (A)
...............and the NATIONAL GUARANTEE AND SURETYSHIP ASSOCIATION, LIMITED, as his
the said (A) ................ s' sureties in that behalf have entered into the above bond in the penal sum of
Rs................... for the due performance by him the said (A) .............. of the duties of his said office
and of all other the duties which may lawfully be required of him and for securing and indemnifying
the said Governor of Bihar, his successors and assigns, against all loss which he or they may in any
way suffer by reason of the acts or defaults of the said (A) ................................Now the condition of
the above written bonds is such that if the said (A) .... shall whilst he shall be in the employment of
Government always duly perform and fulfil all and every his duties aforesaid and shall not leave the
service without permission or without giving three month's notice in writing if the said (A)
;................. and the NATIONAL GUARANTEE AND SURETYSHIP ASSOCIATION, LIMITED, shall
indemnify the said Governor of Bihar, his successors and assigns from all loss which shall be
sustained by the said Governor of Bihar, his successors and assigns owing to the dishonesty,
negligence, default, disobedience (of the existence of which matters and of the amount of loss
sustained the decision of any Government officer who ordinarily has the power to determine and
deal with the same shall be conclusive proof but not the only means of proof), or on adjudication as
an insolvent of the said (A) .......... then this obligation is to be void and of no effect, otherwise the
same shall be and remain in full force and virtue PROVIDED ALWAYS and it is hereby agreed and
declared by and between the parties hereto that the said NATIONAL GUARANTEE AND
SURETYSHIP ASSOCIATION, LIMITED, shall not be at liberty to terminate their suretyship except
upon giving to the said Governor of Bihar, his successors or assigns for the time being six calendar
month's notice in writing of their intention so to do and the liability of the said NATIONALBihar Board's Miscellaneous Rules, 1958

GUARANTEE AND SURETYSHIP ASSOCIATION, LIMITED, under this Bond shall continue after
the expiration of the said period of six months in respect of all omissions and defaults on the part of
the said (A) .............. that may occur prior to the expiration of the said period of six months although
the same may not be discovered until after the expiration of the period of six months PROVIDED
ALWAYS as it is hereby expressly stipulated and agreed and held to form part of the contract
between the parties hereto that the Subscribed Capital Stock and Accumulated Funds in the
Guarantee Insurance Branch of the Company, at the time when any claim, under these presents
shall arise, shall alone be liable to meet such claim, and that none of the Directors or Share-holders
of the Company shall be liable therefor to any extent or effect whatever beyond their respective
interests in such Subscribed Capital Stock and Accumulated Funds in the Guarantee Insurance
Branch of the company at the time.Signed and delivered by the abovenamed in the presence
of(Signature of Principal)Witness.-Name.Father's
name.Occupation.Residence.Witness.-Name.Father's name.Occupation.Residence.The common
Seal of the abovenamed surety, the National Guarantee and Suretyship-Association, Limited, was
hereunto affixed in the presence
of............................................................Debtor.......................................................DebtorManaging
Agents.Appendix W(See Rule 438)Rules and Supplementary Instructions regulating the method of
recruitment to the Bihar Civil Service (Executive Branch) and the Junior Civil Service.Notification
No. III/IL-50-A-14697, dated the 17th December, 1951. - In exercise of the powers conferred by the
proviso to Article 309 of the Constitution of India, and in supersession of the rules published in the
Appointment Department's notification No. 426 A.R. dated the 24th June, 1937, as amended from
time to time, the Governor of Bihar is pleased to make the following rules for the regulation of
recruitment to the Bihar Civil Service (Executive Branch) and the Bihar Junior Civil Service:-
Part I
1. (a) Short title and commencement. - These rules may be called the Bihar
Civil Service (Executive Branch) and the Bihar Junior Civil Service
(Recruitment) Rules, 1951, and shall take effect from the date of this
notification.
(b)Definitions. - In these rules, unless there is anything repugnant in the subject or
context-(i)"Commission" means the Bihar Public Service Commission;(ii)"Government" means the
Government of Bihar;(iii)"Governor" means the Governor of Bihar;(iv)"Scheduled Castes" means
the castes specified in Part II of the Constitution (Scheduled Castes) Order, 1950; and(v)"Scheduled
Tribes" means the tribes specified in Part II of the Constitution (Scheduled Tribes) Order, 1950.
2. The Bihar Civil Service (Executive Branch) and the Bihar Junior Civil
Service shall be recruited-
(a)by direct recruitment in accordance with the rules in Part II and/or(b)by direct recruitment in
accordance with the rules in Part II-A and/or(c)by promotion or transfer of officers already in
Government service in accordance with the rules in Part III.Bihar Board's Miscellaneous Rules, 1958

3. The Governor shall decide in each year the number of vacancies in each of
the services to be filled in that year by direct recruitment and/or by
promotion respectively:
Provided that the number of vacancies to be filled by promotion in the Bihar Civil Service (Executive
Branch) in any one year shall not, unless the Governor is satisfied that there is not a sufficient
number of officers fit for promotion, be less than half the total number of vacancies to be filled in
any such year.
Part II – Direct Recruitment by Competitive Examination
4. The Commission shall announce in each year in such manner as they think
fit, the number of vacancies in each service to be filled by direct appointment
on the result of a competitive examination and shall invite applications, from
candidates eligible for appointment under Rules 6 and 7. The competitive
examination will be conducted by the Commission and will normally be held
between the months of November and February unless otherwise notified.
5. The Commission may fix a limit in any particular year as to the number of
eligible candidates to be admitted to the examination and if the number of
candidates exceeds the limit fixed, the Commission may make a preliminary
selection of candidates to be admitted to the written examination on the
basis of their academic records :
Provided that no member of the scheduled castes or the scheduled tribes who is eligible under the
rules shall be excluded from appearing at the written examination.
6.
(1)A candidate may either be a male or female, and-(a)be under 25 years and over 22 years of age on
the 1st day of August last preceding the month in which the examination is held :Provided that-(i)in
the case of candidates belonging to the Scheduled Castes or the Scheduled Tribes, the upper
age-limit shall be under 30 years :(ii)in the case of candidates who are bona fide displaced persons
from Pakistan, there shall be no upper age-limit, and [but no candidate shall be allowed to avail, in
consecutive year, only of the same number of chances to appear at the examination as permissible to
candidates to whom the normal age-limits apply"] [Added by Notification No. A-32104 dated
21.3.1957.] and(iii)in the case of "Political Sufferes" the upper age-limit shall be extended up to a
maximum period of five years :[Provided also that no candidate who does not belong to a Scheduled
Caste or a Scheduled Tribe shall be allowed to take more than four chances at the examination : ]
[Added by Notification No. A-2-206/59. T44 dated 18.11.1959.][Provided also that, for the first
examination to be held after 1st August, 1959, a candidate belonging to Scheduled Castes orBihar Board's Miscellaneous Rules, 1958

Scheduled Tribes must be under 36 years of age on that date and any other candidate must be under
31 years of age on that date.] [Added by Notification No. A-2-206/59. T44 dated 18.11.1959.]Note. -
(1) For a list of the Scheduled Castes and Scheduled Tribes in Bihar, see Appendix A to these
rules.(2)For persons failing under the category of "Political Sufferers", see Appendix-B to these
rules.(b)[ must hold a degree in Arts, Science, Commerce, Agriculture, Engineering, Medicine or
Veterinary Science of any statutory university or possess other qualifications which the Governor
may declare from time to time as equivalent to the said degrees.] [Substituted by G.S.R. 99 dated
16-9-1972.][Note. - Persons who hold posts in Government service in a temporary or officiating
capacity or on probation are eligible to offer themselves for the examination provided they possess
the educational and other equal qualifications, prescribed in the rule. Persons holding Non-Gazetted
posts substantively, whether technical or non-technical, are also eligible to offer themselves for the
examination provided they possess the requisite qualifications. This concession, will not, however
apply to such technical persons who have been trained at the expense of Government or those who
are by contract bound to serve in a technical post for a specific period. [Substituted by No.
III/PSC-5018/59-A-9452, dated 9.7.1960.]Applications for Government servants who are eligible
under the rules should be submitted through the authority empowered to forward the application
under the Bihar Government Servant's Applications or Posts Rules, 1956-"](2)[ A non-gazetted
non-technical Government servant or a temporary nontechnical Gazetted officer appointed against a
permanent or temporary post under the Government shall be eligible to appear in the examination if
he/she possesses the requisite qualification, has rendered at least three years of continuous service
under the State Government and is under 35 years of age (under 40 years of age in the case of
candidates belonging to the Scheduled Castes and Scheduled Tribes), on the first day of August, last
preceding the month in which the examination is held. Such a Government servant may submit
his/her application in the prescribed form and in the manner prescribed in the rules through the
Head of his/her Department to the Secretary to the Commission but he/she shall not be entitled to
sit at more than three Examinations. Such a Government servant can, however, send an advance
copy of his/her application direct, to the Commission. The Commission may, at the time of
interviewing such a candidate call for his/her service records. If such a candidate is actually
appointed to the Bihar Civil Service (Executive Branch) or to the Bihar Junior Civil Service, his/her
previous service under the Government shall not be taken into account for the purposes of
determining his/her seniority in the new cadre.] [Added by Notification No.
III/ARI-4017/60-A/14218, dated 30-10-1961.]Explanation. - The term 'technical' has been used in
its ordinary etymological sense and in case of any doubt, a reference should be made to the
Government in the Appointment Department for clarification.Note. - (1) The three chances for
which a candidate is eligible under this sub-rule shall be in addition to those which he/she can avail
of before attaining the age of 25 years (30 years in case of Scheduled Castes and Scheduled
Tribes.)(2)The Head of Department concerned shall make a note of forwarding such applications in
the Service Book of the Government servant concerned and may also call upon the Government
servant to submit a declaration of the number of chances which he/she has availed after attaining
the age of 25 years (30 years in case of Scheduled Castes and Scheduled Tribes).[6-A. [Added by
Notification No. I M/1022/55/1568-A.R., dated 8.8.1955.] (i) No male candidate shall be eligible for
appointment if he had married before attaining the age of [22 years] : Provided that this restriction
shall not apply to persons who had married on or before the 31st July, 1955.(ii)After appointment a
person shall not marry until he reaches the age of [22 years] [Substituted for 23 years byBihar Board's Miscellaneous Rules, 1958

Notification No. A2-406/59-44, dated 18.11.1959.], except with the permission of Government, and
if he marries before the age of [22 years] [Substituted for 23 years by Notification No.
A2-406/59-44, dated 18.11.1959.] without such permission, his service may be terminated.]
7. (a) A candidate must be of sound health, good physique and active habits
and free from any physical defect likely to interfere with the efficient
performance of the duties of a member of the Bihar Civil Service (Executive
Branch) and the Bihar Junior Civil Service. A candidate who is found after
examination by a Medical Board not to satisfy these requirements will not be
selected for appointment.
(b)A candidate must satisfy the Public Service Commission that his character is such as to qualify
him for employment in the service.
8. A candidate shall apply to be admitted to the examination in his own hand
writing in the prescribed form to the Secretary to the Public Service
Commission, not later than such date as may be notified by the Commission
in this behalf in each year. The prescribed form and a copy of these rules are
obtainable from the Secretary to the Public Service Commission.
9. With his application a candidate must submit-
(i)evidence that he holds one of the educational qualifications referred to in rule 6 (b);(ii)certificate
or character and conduct from the heads of all the colleges at which he has studied since he passed
the Matriculation examination;(iii)the name of two persons, as reference, who know him in private
life and are not his near relatives. A candidate must not file written testimonials of such persons and
the reference furnished by him should not include College Professors or Principals unless they know
the candidate at home ;(iv)a certificate from any Registered Medical practitioner in the prescribed
form which may be obtained from the Secretary to the Commission;(v)evidence of age, which should
ordinarily be a copy of the Matriculation Certificate or its equivalent;(vi)if he claims to be domiciled
in the State, a certificate of domicile granted by the District Officer of the District in which he claims
to be domiciled. -Note. - The certificate and other documents required should be true copies of the
originals bearing on each certificate a certificate from a Gazetted Officer stating that he has seen the
original and the copy is a true copy. The candidates may be required to produce the original
certificates before the Commission at the time of the viva voce test.Supplementary InstructionsThe
age of a candidate as recorded in his Matriculation Certificate will be regarded as correct unless
there is proof to the contrary. If a candidate will claim that his age is other than as so recorded, he
must submit with his application the evidence on which he bases his claim. In such a case, he will be
required to furnish, among other evidence satisfactory explanation, of the circumstances in which a
wrong age was recorded on his form of application for permission to appear at the Matriculation
Examination. He will also be required to submit a statement of any attempts made by him to have
the University records amended and of the results of such attempts.Bihar Board's Miscellaneous Rules, 1958

10. Except under the special orders of Government, preference will be given
to a candidate who is either a native of the State or a subject of the Indian
Union domiciled in the State.
A-To the Bihar Public Service Commission[11. A consolidated examination fee of Rs. 13.75 (in case
of candidates belonging to Scheduled Castes and the Scheduled Tribes) when they first submit their
application:Provided that Commission may, at their discretion, remit the prescribed fee in cases of
bona fide displaced persons from Pakistan who are not in a position to pay the prescribed fee.]
[Substituted by Notification No. A-3335 dated the 25.3.1957.]B-To the Medical BoardRs. 16 (Rupees
sixteen) only in cash at the time of examination by a Medical Board.Note 1. - The examination fee
shall be payable by means of a Treasury challan to be obtained only from any treasury in Bihar or
crossed Indian Postal Order, payable to the Secretary, Bihar Public Service Commission.The fee paid
by means of treasury chalan should be credited to the [Head "XXI] [See now new
head.]-Miscellaneous Departments-Examination Fees realised by the Bihar Public Service
Commission". The fee must not be sent by cheque on banks or in cash.
12.
(1)No candidate will be admitted to the examination unless he/she holds a certificate of admission
from the Commission.(2)Candidates must see that they are eligible and must decide definitely to
apply before depositing the fees in the treasury. In order to prevent disappointment, candidates are
advised to have themselves examined by a Government medical officer of and above the rank of a
Civil Assistant Surgeon before applying for admission to the examination. No claim for refund of any
of this fees will ordinarily be entertained except to the extent stated in Appendix C nor can they be
held in reserve for any other examination or selection.
13. Notwithstanding anything contained in the foregoing provisions of these
rules, the Commission may require a candidate to furnish any such
additional proof on any point as to his/her suitability as the Commission may
deem necessary.
14. Subject to the provision of these rules, the decision of the Commission
as to the eligibility or otherwise for admission to the examination shall be
final.
15. The examination shall be held according to the syllabus specified in
Appendix D to these rules which are liable to alteration from time to time by
the Commission with the prior approval of the State Government.
[15-A-If any candidate is found guilty of-(i)resorting to any irregular or improper means for
obtaining admission to the examination; or(ii)impersonating another candidate or beingBihar Board's Miscellaneous Rules, 1958

impersonated by any person at the written or viva voice examination ; or(iii)submitting fabricated
document or documents which have been tampered with; or(iv)making statements which are
incorrect or false, or suppressing material information;(v)communicating with any person for the
purpose of getting help or for aiding any other candidate; or(vi)using any other unfair means in the
examination hall; or(vii)unruly behaviour in the examination hall or violating any instruction issued
by the Commission;he may be expelled from the examination hall by the Commission by any person
authorised by them in this behalf. In such cases, the Commission may also invalidate his answer
book or deduct such marks as they consider fit and in addition to rendering himself liable to
criminal prosecution, the candidate may be debarred either permanently or for a specified
period-(a)by the Commission from admission to any examination or appearance at any interview
held by the Commission for selection of candidates; and(b)by the State Government from
employment under Government.][16. (a) The Commission shall have discretion to fix the qualifying
marks in any or all the subjects at the written examination.(b)The minimum qualifying marks for
candidates belonging to the Scheduled Castes and the Scheduled Tribes shall not be higher than 35%
for the Bihar Civil Service (Executive Branch), and 30% for the Bihar Junior Civil Service unless the
number of such candidates qualifying at the written test according to the standards applied for other
candidates is considerably in excess of the number of candidates required to fill all the vacancies
reserved for the Scheduled Castes and Scheduled Tribes;Provided that in determining the suitability
of a particular candidate for appointment, the total marks obtained at the written examination and
not the marks obtained in any particular subject shall be taken into consideration.(c)There shall be
no qualifying marks for the viva voce test.]
17. On the basis of the marks obtained at the written examination, the
Commission shall arrange for a viva voce test of the candidates who have
qualified at the written examination according to Rule 16 (a) or (b):
Provided that in exceptional circumstances and with the prior approval of Government, the
Commission may, at their discretion, admit candidates of the Scheduled Castes and Scheduled
Tribes to the viva voce test even though they may not have obtained the minimum qualifying marks
at the written test prescribed in Clause (a) or (b) of Rule 16.
18. The marks obtained at the viva voce test shall be added to the marks
obtained at the written examination. The names of candidates will then be
arranged by the Commission in order of merit. From the list of candidates so
arranged, the Commission shall nominate such number of candidates for
each service as may have been fixed by the Governor. This list shall be
submitted to the Governor by such date in each year as the Governor may
fix.Bihar Board's Miscellaneous Rules, 1958

19. The Commission shall, while submitting their recommendations under
Rule 18 consider the claims of qualified candidates belonging to the
Scheduled Castes and the Scheduled Tribes. If the list of nominees
submitted under Rule 18 does not contain an adequate number of candidates
belonging to the Scheduled Castes and the Scheduled Tribes who may be
appointed to the vacancies reserved for them in these services, the
Commission shall submit a supplementary list nominating a sufficient
number of such candidates as in their opinion attain the required standard of
qualifications and are in all respects suitable for appointment.
20. The Commission reserve the right to recommend a successful candidate
for any of the services for which he is considered suitable. Success at the
examinations confers no right for appointment unless Government is
satisfied after such enquiry as may be considered necessary, that the
candidate is suitable in all respects for appointment to the public service.
21. Candidates selected for written or viva voce test will present themselves
at their own expense at a time and place of which they will be informed in
due course.
22. A consolidated result of the examination will be prepared by the
Commission and a copy of the marks obtained both at the written and the
viva voce tests may be supplied immediately to each candidate, soon after
the results are compiled and the list referred to in Rule 18 is submitted to the
Governor.
Part II – A Direct Recruitment of Persons with Zamindari
Experience
22.
-A. The Commission shall announce in such a manner as they think fit the number of vacancies in
each service to be filled by direct recruitment in accordance with the rules in this Part, and shall
invite applications from candidates eligible for appointment under this rule.
22.
-B. A candidate may either be a male or a female and must-(a)be under 40 years and over 25 yearsBihar Board's Miscellaneous Rules, 1958

of age on the 1st day of August last preceding the month in which applications are invited
;(b)possess the educational qualifications laid down in Rule 6 (6) of Part II;(c)possess at least six
years' experience of managing a zamindari or tenure.
22.
-C. Rules 7 and 21 in Part II shall apply also to candidates eligible under this part.
22.
-D. Applications from candidates eligible under this Part shall be sent so as to reach the Commission
not later than such date as may be prescribed by the Commission in this behalf. Applications shall
be sent direct to the Commission but each candidate shall furnish to the Collector of his district a
copy of the application submitted by him to the Commission.
22.
-E. (1) With his application a candidate must remit to the Commission a sum of Rs. 50 (Rupees fifty)
only as application fee :Provided that candidates belonging to the Scheduled Castes and the
Scheduled Tribes shall be required to remit a sum of Rs. 12.50 paise (Rupees twelve and fifty paise)
only.(2)Out of the fee remitted to the Commission under sub-rule (1) a sum of Rs. 45 (Rupees
forty-five) only or in the case of candidates belonging to the Scheduled Castes and the Scheduled
Tribes, a sum of Rs. 11.25 paise (Rupees eleven and twenty-five paise) only, shall be refunded by the
Commission if after an enquiry by the Collector of his District or by the Commission, the candidate
is found to be eligible to apply under part, but not otherwise.
22.
-F. The Commission shall hold a written test consisting of one paper of 300 marks on general
knowledge, method and power of expression (either in English or in Hindi) and knowledge of
zamindari affairs.The Commission shall also hold a viva voce test which shall carry a maximum of
200 marks. Both the written test and the viva voce test shall be designed to test not the candidates'
academic knowledge, but his understanding of Zamindari affairs and his aptitude for the kind of
work that an Anchal Adhikari-cum-block Development Officer would be required to do.
22.
-G. The maximum qualifying marks for the written test shall be as follows :-
 For candidates belonging to the Scheduled Castes
and theScheduled Tribes.For other
candidates.
Bihar Civil Service
(Executive Branch)40 per cent: 45 per cent,Bihar Board's Miscellaneous Rules, 1958

Junior Civil Service ... 35 per cent: 40 per cent.
There shall be no qualifying marks for the viva voce test.
22.
-H. After holding the written test, viva voce test, the Commission shall submit their
recommendations to the Governor, arranging the names of candidates considered suitable by them
for each service in order of merit.
Part III – Promotion of Officers already in Government Service
23. (a) The Chief Secretary to the State Government shall in each year
communicate to the Board of Revenue the number of vacancies in the Bihar
Civil Service (Executive Branch) and the Bihar Junior Civil Service that may
be fixed by the Governor to be filled up from officers already in Government
Service. The Board of Revenue shall consult the Commissioners of
Divisions. After the Commissioners of Divisions have sent up their
recommendations to the Board of Revenue for promotion to the Bihar Civil
Service (Executive Branch) and the Bihar Junior Civil Service, these
recommendations along with any others which the Board may have received
shall be considered by a Selection Committee consisting of the Member,
Board of Revenue, as President and the Additional Member, Board of
Revenue, if there be one, the Food Production and Development
Commissioner, if there be one and all the Commissioners of Divisions, as
Members. The officers nominated by the Selection Committee shall be
arranged in order of preference:
Provided that where more than one officer is nominated for promotion from the same service, their
names shall be arranged in order of their position inter se in the service to which they belong.(b)The
Board of Revenue shall send all papers relating to the candidates nominated by the Selection
Committee direct to the Commission and shall at the same time submit a list of such candidates to
the Governor.Note. - Persons who hold posts in Government service either in a substantive capacity
or otherwise are eligible for appointment to the Junior Civil Service by promotion or transfer in
accordance with these Rules.Supplementary Instructions(i)The appointment to the Bihar Civil
Service (Executive Branch) by promotion of any officer other than a Sub-Deputy Collector is not
ordinarily desirable and no such appointments will be made save for reasons of an exceptional kind,
and on the express recommendation of the Head of the Department in which the officer is serving
and of the Board of Revenue.A recommendation made by a Head of Department should be
addressed to the Board and, unless supported by the Board, will not be submitted to the Public
Service Commission or to Government. Applications for such appointments received otherwise thanBihar Board's Miscellaneous Rules, 1958

through the Board will be returned to the applicants.(ii)No Sub-Deputy Collector is eligible for
promotion unless he has passed the departmental examinations in law and language by the higher
standard and in accounts [and development.] [Added by Notification No. III/RI-40/560-A-8052
dated 10.6.1960.](iii)The nominees of the Board for promotion to the Bihar Junior Civil Service
need not be graduates, but should be men of sufficient education to be able to pass the departmental
examination and thus qualify themselves for the work of a Sub-Deputy Collector (Such officers will
be eligible for promotion only if they are recommended after a personal interview both by the Board
of Revenue and the Public Service Commission).
24. The Commission shall advise the Governor in respect of each candidate
nominated whether his qualifications are sufficient and whether his record
proves him to have requisite character and suitability for the service to which
it is proposed to appoint him.
25. The final selection of officers to be promoted shall be made by the
Governor after considering the recommendations made by the Commission
under Rule 24.
Supplementary InstructionsOfficers finally selected, under Rule 25, for promotion to the Bihar Civil
Service (Executive Branch), will not, if already in permanent Government service, be required to
undergo further medical examination.GeneralNo recommendations except those invited in the form
of application will be taken into consideration. Any attempt on the part of a candidate to enlist
support for his application through person of influence (or in any other manner) will disqualify him
for appointment.[Every Sub-Deputy Collector on first appointment on probation will be required to
execute a bond in the form prescribed in Appendix 'E' with two good and sufficient sureties binding
himself and his sureties jointly and severally to refund to Government the amounts received by him
as pay and allowances during the period of probation, if during that period or within five years
thereafter he voluntarily resigns or otherwise quits the service on any ground other than that of
health, certified by a duly constituted Medical Board. In case of a promoted officer who holds any
substantive post elsewhere, the amount of refund will be limited to extra amounts drawn by him by
virtue of his appointment as a Sub-Deputy Collector.] [Added by Notification No. A-106 dated
5.1.1957.]Appendix AList of Scheduled Castes in Bihar
1. The castes, races or tribes, or parts of groups, within, castes or tribes,
specified below shall be deemed to be Scheduled Castes in the State of Bihar
in the localities specified in relation to them.
2. No person who professes a religion different from Hinduism shall be
deemed to be a member of a Scheduled Caste.Bihar Board's Miscellaneous Rules, 1958

3. Any reference to a district or other territorial division of the State shall be
construed as a reference to that district or other territorial division as
existing on the 26th January, 1950.
I. Throughout the State of Bihar.
1. Bauri
2. Bantar.
3. Bhogta
4. Chamar
5. Chaupal
6. Dhobi
7. Dome
8. Dusadh, including Dhari or Dharhi.
9. Ghasi.
10. Halalkhor.
11. Hari, including Mehtar.
12. Kanjar.
13. Kurariar
14. Lalbegi.
15. Mochi
16. MusaharBihar Board's Miscellaneous Rules, 1958

17. Nat
18. Pan
19. Pasi
20. Rajwar
21. Turi.
II. In Patna and Tirhut divisions and the districts of Munger, Bhagalpur, and Palamau-Bhumij.III.
In Patna, Shahbad, Gaya and Palamau Districts-Bhuiya.IV. In Shahabad District-Debgar.List of
Scheduled Tribes in BiharI. Throughout the State of Bihar.
1. Asur
2. Baiga
3. Bathudi
4. Bedia
5. Binjhia
6. Birhor
7. Birjia
8. Cnero
9. ChikAaraik
10. Gond
11. Goriat
12. HoBihar Board's Miscellaneous Rules, 1958

13. Karmali
14. Kharia
15. Kharwar
16. Khond
17. Kisan
18. Kora
19. Korwa
20. Lohara
21. Mahdli
22. Mai Paharia
23. Munda
24. Oraon
25. Parhaiya
26. Santal
27. Sauria Parharia
28. Savar
2. In the districts of Ranchi, Singhbhum, Hazaribagh, Santal Parganas and
Manbhum-Bhumij.
Note. - Any reference to a district or other territorial division of the State shall be construed as a
reference to the district or other territorial division as existing on the 26th January, 1950.Appendix
BThe term "Political Sufferer"defined for purposes of recruitment to services and posts under
Government (Vide Circular No. 237-A (124)/50/C-1447, dated the 26th January, 1951 and No.
237-A (124)/50/C-6480, dated the 23rd May, 1951.A "Political Sufferer" means up to and including
the 31st December, 1951, unless otherwise specified, a person who took part in the politicalBihar Board's Miscellaneous Rules, 1958

movement which started on the 9th August, 1942; and(1)who was injured as a direct result of his
participation in the movement or as a direct consequence of any action on the part of Government
officials ;or(2)who was tried and sentenced to imprisonment or fine for any offence connected with
the movement; or(3)who was detained without trial for three months or more; or(4)who was under
trial for six months or more, even though the cases ended in discharge or acquittal; or(5)who was
proclaimed as an offender in connection with the movement, but absconded;or(6)whose properties
were attached even though restored subsequently; or(7)whose properties were damaged or
destroyed on account of his participation in the movement; or(8)whose studies were interrupted
resulting in loss of one of more academic year on account of such participation ; or(9)sons and
daughters of those who lost their lives or were incapacitated as a direct result of their participation
in the movement or as a direct consequence of any action on the part of Government officials during
the movement; or(10)the son or son-in-law of a political sufferer on whom that political sufferer and
his family are dependent for their maintenance.
1. Special cases which would not be covered by the above definition should
be referred to the Secretary to the Government of Bihar in the Political
Department, Patna, for orders with a full statement of the facts. A person who
wishes to claim any of the concessions allowed under this order should
obtain from the District Magistrate of the district in which he normally
resides, a certificate to the effect that he was a Political Sufferer within the
meaning of this order.
2. No application for concession under the orders quoted above will be
entertained by the Bihar Public Service Commission unless accompanied by
the District Magistrate's certificate.
Appendix CInstructions Governing Refund of Admission and Examination FeesApplication fee will
not ordinarily be refunded. If however, for any reason a candidate is unable to sit at the
examination, half of the examination fee may be refunded on application to the Secretary to the
Commission :Provided that the Secretary to the Commission may sanction refund of:-(i)90 per cent
of the fees paid when a candidate after paying the fees does not submit an application.(ii)whose of
the application and/or examination fee paid, as the case may be, where an alteration is made in the
terms of advertisement or in the conditions of recruitment so that the candidate who would
otherwise have been eligible, becomes ineligible, due to such alteration; and(iii)whole of the
application and/or examination fee paid, as the case may be, if the vacancies advertised are decided
by Government to be abolished or kept in abeyance, before or after the candidates are
interviewed.Appendix D[Bihar Public Service Commission, 15 Bailey Road, Patna]Syllabus For the
Combined Competitive Examination(The Syllabus is liable to slight modification)Questions in all
non-language subjects may be answered either in English or in Hindi (Devnagri script)The following
will be the subjects for examination; each subject will carry the marks shown against it-Compulsory
 Subject Marks.Bihar Board's Miscellaneous Rules, 1958

1.General English 150
2.General Knowledge (including current affairs) 150
3.Elementary General Science 100
4.General Hindi 50
Optional(Candidates must take three and not more than three subjects, but not more than two from
any one of the groups, A, B, C or D).
Group A
5. Hindi Language and Literature 200
6. Sanskrit Language and Literature 200
7. Urdu Language and Literature 200
8. Persian Language and Literature 200
9. Arabic Language and Literature 200
10. English Language and Literature 200
10A. [] [Added by Notification no.
III/RI-4044/60-A-8664, dated
22.6.1960.]Pali Language and Literature 200
Group B
11.Indian History and Culture (including Modern and
MedievalIndia)200
12. World History 200
13. Geography 200
14. General Economics (including Public Finance) 200
15. Political Science 200
16.Philosophy (including Ethics and comparative study
ofreligions)200
17. Psychology 200
18. Sociology (including Anthropology) 200
19. Labour and Social Welfare 200
Group C
20. Public Administration 200
21.International law, Jurisprudence and Constitutional
Law (withspecial reference to the development of the
English and IndianConstitution)200
22.Hindu Law, Law of Transfer, Evidence Act, Procedure
Law andIndian Penal Code.200
Group D
23. Mathematics 200
24. Physics 200
25. Chemistry 200Bihar Board's Miscellaneous Rules, 1958

26. Botany (including Economic Botany) 200
27. Geology 200
28. Zoology 200
29. Accounts 200
30. Statistics 200
31. Agriculture 200
1. Every candidate must offer for all services, all subjects mentioned in the
Compulsory group. From the subjects in the Optional, candidate must take
three subjects, but not more than two from any one group.
2. General Economics, including Public Finance or Accounts will be
Compulsory subject for candidates for the Bihar Finance Service (Senior
Branch) and the Bihar Finance Service (Junior Branch).
3. Sociology or Psychology will be a compulsory subject for the Bihar Jail
Service.
4. Indian History and Culture will include three groups each carrying 100
marks, and a candidate can take any two up to 200 marks.
5. The paper on "Accounts" will include three divisions and a candidate can
offer any two up to 200 marks
6. The number of candidates to be admitted to the written examination shall
not exceed the limit as may be fixed by the Commission from time to time. If
the number of candidates exceeds the limit fixed the Commission shall make
a preliminary selection of candidates to be admitted to the written
examination and weed out those who are considered unsuitable :
Provided that candidates with Honour's or Master's degree who have fetched 50 per cent or more of
the aggregate marks in the subjects for the Honour's or the Master's degree shall not be excluded
from taking the written examination :Provided further that no member of the Scheduled Castes and
Scheduled Tribes, who is eligible under the Rules, shall be excluded from appearing at the written
examination.
7. There shall be one paper in each of the Compulsory, and Optional
subjects. All papers, excepting viva voce, shall be of three hours duration.
There is no time-limit for viva voce test. The Commission shall summon such
candidates for a viva voce test as qualify themselves at the writtenBihar Board's Miscellaneous Rules, 1958

examination. Viva voce examination shall carry a maximum of 200 marks for
all services except the Bihar Police Service. The maximum viva voce marks
for the Bihar Police Service shall be 250. The Commission has the discretion
to fix the qualifying marks by notification in advance in any or all of the
subjects for examination.
8. If a candidate's handwriting is not easily legible, a deduction to the extent
of 5 per cent, w/ill be made on this account from the total marks otherwise
accruing to him/her.
9. In all subjects of the examination candidates will be required to show a
sound, and not merely superficial knowledge of the subjects. The power of
an orderly, effective and exact expression, with the economy of words will
also be expected of the candidates.
10. Success in examination confers no right for appointment unless
Government are satisfied, after such inquiry as may be considered
necessary, that the successful candidate is suitable in all respects for
appointment to the Public Service.
11. The Commission reserve the right to recommend a successful candidate
for any of the service or posts which he/she has offered himself/herself if
considered suitable.
Standard and Syllabus of the ExaminationNote. - The standard of optional papers will be
approximately that of an Honour's Degree Examination of the Patna University which is two years'
course.
1. General English. - Questions will be set to test the understanding of and
the power to write English. A passage or passages will usually be set for
summary or precis. Questions will include letter writing on given subjects.
2. General Knowledge (including knowledge of current events). - The paper
will also include questions of Indian History, Culture and Geography of a
nature, which candidates should be able to answer without special study.Bihar Board's Miscellaneous Rules, 1958

3. Elementary General Science. - A paper of questions to test such matter of
every day observation and experience in their scientific aspects as may be
expected of an educated person, who has not made a special study of any
scientific subject.
4. General Hindi. - -The paper will be of a general character to test a
candidate's ability to understand and write Hindi grammatically and correctly.
Candidates will be asked to write an essay or to give a descriptive account of
something. A prose passage will also be set for summary or precis with the
object of testing comprehension of expression.
5. Viva voce. - The candidates will be interviewed by the Commission who
will have before them a record of his/her career. He/She will be asked
questions on matters of general interest. The object of the interview is to
assess his/her suitability for the service for which he/she is entered, and in
framing their assessment the Commission will attach particular importance
to his/her intelligence and alertness, his/her vigour and strength and his/her
potential qualities of leadership.The examination will be on matters of
general interest, not on matters of academic interest.
The marks obtained in viva voce will be added to the marks obtained in written papers and the
candidate's place will depend on the aggregate of both.
6. Hindi Language and Literature. - Candidates will be expected to show a
knowledge of the principal classical authors. Evidence of first-hand reading
will be required. The paper will include questions on Grammar, Philology,
Social and Political History and literary criticism. Answer should be in
Devnagri script.
7. Sanskrit Language and Literature. - (a) Translation from Sanskrit into
English and from English into Sanskrit; (b) Language, Literature and
Grammar.
Questions may be set to draw out what a candidate knows rather than to test his/her knowledge. It
is not expected that he/she should be an expert or a specialist in any branch of Sanskrit literature,
but he/she should have a grasp of both the classical language and literature, and a general
knowledge of the history of literature-classical period only.He/she should have a general knowledge
of Sanskrit Grammar. This knowledge will be tested not by asking him/her to quote rules, but by
their application to language. He/she will be required to translate an essay passage or passages intoBihar Board's Miscellaneous Rules, 1958

English from classical Sanskrit, to write an essay in Sanskrit, to summarise a given passage in
English or Sanskrit and to translate into either language.Answers required to be written in Sanskrit
must be written in Devnagri script.[7-A. Pali Language and Literature-] [Added by Notification No.
III/RI. 4044/60-A-8664 dated 22.6.1960.](a)Translation from Pali into English, from English into
Pali;(b)Pali Grammar and Composition ;(c)Pali Language and Literature.
8. Urdu Language and Literature. - The candidates are expected to show an
up-to-date general knowledge of the history of Urdu language and literature
of modern tendencies of its development and be able to answer critical
question, regarding some knowledge of Prosody, Philology and Rhetoric.
9. Persian Language and Literature. - (a) Translation from Persian into
English and from English into Persian; (b) Language, Literature and
Grammar.
Questions may be set to draw out what a candidate knows rather than to test his/her knowledge. It
is not expected that he/she should be an expert or a specialist in any branch of Persian Literature,
but he/she should have a grasp of both the classical language and literature and a general knowledge
of the history of Persian Literature-classical period only. He/she should have a general knowledge of
Persian Grammar/including elements of Persian Prosody and Rhetoric. This knowledge will be
tested not by asking him/her to quote rules but by their application to the language, he/she will be
required to translate essay passage or passages into English from classical Persian, to write an essay
in Persian, to summarise a given essay in Persian, and to translate from English into Persian and
from Persian into English.
10. Arabic Language and Literature. - (a) Translation from Arabic into English
and from English into Arabic; (b) Language, Literature and Grammar.
Question may be set to draw out what a candidate knows rather than to test his/her knowledge. It is
not expected that he/she should be an expert or a specialist in any branch of Arabic Literature, but
he/she should have a grasp of both the classical language and literature and general knowledge of
the history of Arabic literature-classical period only.He/she should have a general knowledge of
Arabic Grammar including the elements of Arabic prosody and Rhetoric. This knowledge will be
tested not by asking him/her to quote rules but by their application to language. He/she will be
required to translate an essay passage or passages into English from classical Arabic, to write an
essay in Arabic, to summarise a given passage in English or Arabic and translate into either
language.
11. English language and Literature. - Candidates will be expected to show a
general knowledge of the History of English literature from the time of
Spensor to 1910 with special reference to the works of the following authors-Bihar Board's Miscellaneous Rules, 1958

Shakespeare, Milton, Pope, Johnson, Dickens, Wordsworth, Keats, Tennyson, Hardy, and Bernard
Shaw.Evidence of first-hand reading will be required. The paper will also include question on
literary criticism.
12. Indian History and Culture. - This paper will include the following three
groups and candidates can take any two only-
(a)Ancient Indian History and culture up to 1,000 A.D. 100
(b)Medieval India-1000-1707 A.D. 100
(c)Modern India-1907-1947 A.D. 100
13. Ancient Indian History and Culture. - The Vedic Age, the Mauryan Age and
administration, foreign Invasions and their after effects, the age and culture
of Guptas, Hun invasions, Harshvardhana and his time, kingdoms in northern
India during 700 to 1200.
(The subjects may be studied with the help of following books :-Roy Chaudhari-Political History of
Ancient India.Tripathi-Ancient History of India.History of India, 1000-1707 A.D.(1)The Muslim
conquest of India.(2)The Delhi Sultanate-its establishment, growth and disruption.(3)Independent
kingdoms on disintegration of the sultanate.(4)Civilisation during Turko-Afghan
period-Government; social and economic conditions; growth of an Indo-Muslim culture (religion,
art and architecture, literature and education).(5)Political conditions in India in 1526.(6)Beginning
of the Mughal Empire (Baber and Humayun).(7)Afghan revival under Sher Shah and the
Suris.(8)From Akbar to Aurangzeb : Mughal territorial expansion, Mughal policy towards the N.W.
Frontier and Central Asia, the Deccan, the Rajputs, Sikhs and other nationalities, the Marathas and
Shivaji's work.(9)Civilisation during Mughal rule, System of Government, Civil and Military, Social
and Economic conditions, foreign traveller's accounts; religious history and religious policy of
Mughal Emperors, art and architecture, literature and education.History of India, 1700-1947
A.D.(1)European Trading nations in India, Anglo-French conflicts, growth of British political
supremacy in Bengal till 1765.(2)Expansion of the British dominion in India till middle of the 19th
century and foreign policy and relations of the E.l. Co.(3)Growth of Indo-British administration
from Warren Hasting to Dalhousie, Charter Acts and transformation in the position of the E.l.
Co.(4)Education and Social Reforms till 1856.(5)The Movement of 1857-59.(6)Administrative and
constitutional development in India.(7)Foreign policy and relation of the Government of
India.(8)History of Indian Nationalism and Independence.(9)Indian States.(10)Education, Social
and Religious reforms.(11)General Economic condition.(12)World History. - (General Knowledge)
from 1789-1939.(13)Geography. - The physical basis of Geography. Elements of Economic
Geography.Regional and Economic Geography of Asia with a detailed study of India including
Pakistan.Candidates will be required to show intimate knowledge of Indian Geography.Bihar Board's Miscellaneous Rules, 1958

14. General Economics. - Candidates will be expected to have a knowledge of
economic theory and should be prepared both to illustrate theory by fact and
to analyse facts by the help of theory. Questions may be set on the theory of
development of economic thought and Public Finance.
15. Political Science. - Candidates will be expected to show a knowledge of
political theory and its history as well as of Political Organisations (including
Public Administration and Local Government.) Candidates will be expected
to have knowledge also of the origin and development of existing Institutions
and of the Constitution of India.
16. Philosophy. - Philosophy including Metaphysics, Theory of Knowledge,
Ethics and Philosophy of Religion, a general acquaintance with the main
system of Indian Philosophy will be expected.
17. Psychology. - Candidates will be expected to show a knowledge of
psychological principles and their applications. Questions will also be set on
the structure and functions of Group morale-leadership-public opinion and
propaganda tensions. Personal selection and Psychology of management
and administration.
18. Sociology (including Anthrology)-
(a)Factors in the Social Life of man;(b)Human Nature. - Heredity and Personality; Group and
Personality and Personality Disorganisations.(c)Culture. - The Role of Culture; The contribution of
Biological Factors. The influence of Geographical Environment and Culture and Personality;(d)The
major Forms of Social Structure. - Types of Social Group, in social life. The Primary Group, Crowds
and Public, Caste and Class; The Family; Family problems of today and Associations and interests;
Prestige and Authority:(e)Social Institutions. - Organisation of societies, organisation of economic
activities in primitive and peasant communities, social control and authority systems in States and
Stateless societies; concept of sanction, relation of law to custom and morality; Religion, ritual,
magic, totem and taboo; interrelationship of Institutions.(f)Indian tribal populations and social
change. - A general idea of the tribal populations of India and the distribution of the various racial
types and of their characteristics. Concept of the society as a process; the patterns of social change;
the biological, technical and cultural factors of social change to be studied with particular reference
to the Indian tribes.(g)Social Evolution and Social Progress. - Misleading Trials in Social Evolution;
General view of Social Evolution.The place of the concept of progress in Sociology, and the
Interpretation of Social change from primitive to civilized society.(h)Media of Mass
Communication. - Propaganda and Public Opinion.Bihar Board's Miscellaneous Rules, 1958

19. Labour and Social Welfare. - (a) History and principles of Labour and
Social Legislation in England and India. Particular enactments like the
Factories Act, 1948, Minimum Wages Act, 1948, Employees' State Insurance
Act, 1948, Industrial Disputes Act, 1947,Trade Unions Act, 1926 and Maternity
Benefit Act of Bihar, 1947, [*Now Central Act.]
(b)Problems and principles of Social Administration; machinery for social service; problems arising
out of poverty, sickness, incapacity, accident, old age and unemployment with special reference to
India, their causes and remedies; Indian social customs and problems arising from them, Indian
standard of living- factors determining-planning-economic and social piecemeal reforms.
20. Public Administration. - The modern State and Pubic Administration,
Relations of administration with the Legislature, the Executive and the
Judiciary. Problems of organisation of the Administrator, Branch as a whole
of departments and of operating services. Advisory Councils, Tools and
administration, problems of personal, material and finance, Administrative
Law, Public Relations.
21. International Law, Jurisprudence and Constitutional Law.-
(a)International Law. - Public International Law-"History of International Law of Belligerents and
Neutrals in War only".(b)Jurisprudence. - Holland's Jurisprudence-Parts I and II.(c)Constitutional
Law. -(i)Constitutional Law of India, 1950 (Parts I and XI).(ii)British Constitutional Law,
Conventions; Limitations on the Sovereignty of Parliament; Rule of Law; Writs.
22. Hindu Law, Law of Transfer, Evidence Act, Procedure Law and Indian
Penal Code-
(a)Hindu Law. - Source of Hindu law, General Principles of Inheritance, Joint Family, Points of
different between the Mitakshara and Dayabhag: Hindu Widow's Estate and Stridhan.(b)Law of
Transfer. - Definition of Transfer of Property, Gifts to unborn persons (Section 13), Rule against
perpetuity (Section 14), Nature of vested contingent interest (Sections 19 and 21), Election (Section
35), Law of Lis Pendens (Section 52), Different kinds of Mortgages (Section 58).(c)Evidence Act. -
Sections 1 to 32.(d)Procedure Law. - Criminal Procedure.
Part 1 – Section 4, Parts II, VI omitting Chapters XXIII, XXVII,
XXVIII, XXXIX, Part IX, Chapters XXXIX and XLIV.
(e)Civil Procedure. - Sections 1 to 151.(f)Indian Penal Code. - Chapters I to VII, Chapter VIII
omitting Sections 143, 147, 160 : Chapter IX omitting Section 164 ; Chapter IX-A omitting SectionsBihar Board's Miscellaneous Rules, 1958

171-E; 171-F; Chapter X whole: Chapter XI omitting Sections 193 and 216-A; Chapter XII whole;
Chapter XIII whole ; Chapter XIV omitting Section 290 : Chapter XV whole; Chapter XVI omitting
Sections 302, 303, 304, 311, 323, 325, 341, 342, 352, 363, 376, Chapter XVII omitting Sections 379,
384, 392, 395, 400, 401, 406, 417, 419, 426, 438, 439, 447, 448, 453, 462; Chapter XVIII omitting
Sections 464, 482, 488. Chapter XIX whole ; Chapter XX whole, Chapter XXI omitting Section 500,
Chapter XXII omitting Section 506, Chapter XXIII whole,
23. Mathematics. - Mathematics will include :
(a)Algebra. - Determinants, theory of equations (volume 8 of Burnside) and Panton, simple
continued fractions, indeterminate equations of the first degree, recurring series and
inequalities.(b)Geometry. - Analytical Geometry of two dimensions. Analytical Geometry of three
dimensions up to Sections of Central conicoids.(c)Elementary Analysis and Trigonometry. -
Sequences and limits. Definition of an irrational number, Convergence of series by comparison and
ration tests, Absolute convergence, Binomial series, Exponential theorem, Series of trigonometric
and hyperbolic functions, Logarithmic series, Complex number, De-Morivre's theorem, Summation
of series. Properties of triangles and quadrilateral, Elements of Spherical Trigonometry and
properties of spherical triangles.(d)Calculus and Differential Equation. - Continuous and
discontinuous functions. Differentiation and successive differentiation. Rolles theorem. Mean value
theorem. Taylor's theorem. Partial differentiations. Maxima and Minima. Geometrical applications.
Definite and indefinite integrals, application to length of curves, areas, volumes, centroids and
moment of inertia. Linear differential equations of the first order. Differential equations of the
second order.(e)Mechanics. - Dynamics of particle including motion in a plane. Motion under
central forces are planatory orbits. Motion on plane curve. Motion of rigid body about an axis.
Compound pendulum.(f)Statics. - Equilibrium under co-planer forces. Friction Equilibrium on a
plane, curve, principle of virtual work, Stability Equilibrium of inelastic strings, Hook's law,
Elementary vector algebra and its application to mechanical problems.(g)Hydrostatics. - Fluid
pressure, thrusts on surfaces, centre of pressure, equilibrium and stability of floating bodies.
Rotating fluids, Gas laws, Atmospheric pressure.(h)Astronomy. - The celestial sphere; Transit
instrument, Equation of time, planetary motion, Refraction, parallax. Precession and mutation.
Lunar and Solar eclipse.Descriptive-Astronomy, planets stars, double stars, Magnitude and spectral
glasses, Temperature luminosity law and diameter, Clusters and nebulx.
24. Physics. - The paper will include question on General Physics, Heats,
Light, Sounds, Electricity and Magnetism.
25. Chemistry. - The paper will include question on General (including
Physical) Chemistry, Inorganic Chemistry and Organic Chemistry.
26. Botany. - An advanced knowledge of the main groups of the vegetable
kingdom, (prescribed for the Hons, course) both living and existing, viz.,
Algae, Fungi, Bryophyla, Petrodophyta, Gymnosperms and AngiospermsBihar Board's Miscellaneous Rules, 1958

with special reference to the Indian flora.
Anatomy. - Origin and development of plant issues and their distribution from ecological point of
view.Ecology. - Principal types of vegetation of Bihar, their distribution and importance of
vegetational study (of Hons, standard).Physiology. - A knowledge of the important physiological
processes of the plant body (of the Hons, standard).Plant Pathology. - A knowledge of the important
diseases of plants caused by Fungi together with the methods of control.Economy Botany. - A study
of the important economic plants (included in the Hons. Course) of India and their
distribution.General Biology. - A study, knowledge of the fundamentals in variation, heredity
evolution, cytology, genetics and principles of plant breeding.
27. Geology. - Physiography and Structural Geology Mineralogy Economic,
Geology and Petrology. - Interior of the earth and its constitution; Isostasy;
Continental Drift, Earth Movements : Origin of Mountains. Fluvial Cycle.
Geological works of snow and ice, Past Glaciation, Marine deposits, Coral
reef; types of fold and faults.
A detailed study of the important rock forming minerals and minerals of economic importance. Ore
genesis; important economic mineral deposits of India. Rock: Modes of occurrence of igneous rocks.
Principles controlling the formation of igneous rocks. Magnetic differentiation, Structures and
Textures. Classification of igneous rocks. Description of the more common igneous rocks.
Characters of different types of sedimentary rocks. Metamorphism, and the origin of different types
of metamorphic rocks. Classification of metamorphic rock. Igneous and metamorphic rock.
Classification of metamorphic rocks. Igneous and metamorphic rocks of India.Stratigraphy and
Palaeontology. - Detailed morphology of the important groups of invertebrates and study of
important genera under each group. Distribution in time of the leading genera. Fossils and organic
evolution with special reference to the Mammals. Petrological and palaeontogical features of the
main geological sub-divisions of India. Correlation of the different formations of India with each
other and with the standard stratigraphical scale.
28. Zoology. - (1) Animal cell (including its cytoplasmic inclusion and their
functions.). Reproduction (Sexual, a sexual and parthenogenesis), Histology
of Frog and Rabbit.
(2)Theories of evolution, Heredity, Cellin in inheritance, History of Zoology, and
Eugenics.(3)Economic Zoology with special reference to pisciculture, sericulture and Lac
culture.(4)Geographical and Geological distribution of animals.(5)The structure, habit, life-history
and classification of the following groups as illustrated by the types indicated against each
:-Protozoa : Amoeba, Entamoeba, Trypansome, Paramocecium, monocystis and malarial
parasite.Porifera : Different kinds of canal systems, skeleton and development, Coelenterate :
Hydra, Obelia, Aurelia and Coral formation.Platyhelminthes : Liverfluke and
taenia.Memathelminthes : Ascaris and Filaria.Echinodermata: Starfish.Annelida : Pheritima, NeriesBihar Board's Miscellaneous Rules, 1958

and Leech.Arthopoda : Prawn, Cockroach, Mouth parts of Mosquito, House-fly and
Sacculina.Mollusca : Mussel and Pila.Polyzos : Bugula Hemichordata: Balanoglossus Urochordata :
Herdmania, Sarpha and Doiiolum Cephalochordata : Branchiostoma (Amphious).Cyclostemata :
Petromyzon (external characters only).Pisces : Dogfish, A common bony fish and Dipnoi Amphibia :
Frog.Reptilia : Varanus and Snake (life-history included).Aves : Pigeon.Mammelia : Echidna,
Kangaroo, Guinea-pig or Rabbit Placentation
29. Accounts will include the following groups :-
A. Advanced Accounting. Auditing. Cost Accounting and Income Tax-100 marks.(a)Advanced
Accounting. - The principles of Accountancy and their practical application to all types of trading,
commercial, industrial, banking, insurance and investment undertakings. Accounts relating to the
flotations, amalgamation, absorption, reconstruction, reorganisation and liquidation of companies,
statutory and public utility undertakings, the accounts of educational, scientific, charitable and
religious endowments, trust and institutions, provident and superannuation funds : branch
accounts, foreign exchange, etc.Note. - Candidates will be expected to be acquainted with the basic
principles. Specialised knowledge of cost accounting will not be required.Note. - The accounts of
Executors and Trustees of the Estates of deceased person, Liquidators, Receivers, Official Assignee,
etc. will not be included.(b)Cost Accounts. - The main principles of cost accounting.The treatment
and control of stocks, material, labour, direct and indirect expenses and on cyst. Contract cost
accounts, process cost accounts, single costing, standard costing, multiple costing and operating
costing; Double Entry Cost Accounting; reconciliation of cost accounts with financial
accounts.(c)Auditing.-The principles and procedure of Auditing and their practical application to all
types of trading, commercial, industrial, banking, insurance, public utility and investment
undertaking; Rights and Duties of Auditors; Internal Audit Investigations of actual and suspected
frauds. Auditor's report, certificates and opinions, Limitations of Audit.(d)Income tax. - The main
Legal and Accountancy, Principles governing the computation of total world income for purposes of
income-tax.Note. - Special knowledge of Income-tax will not be expected. Candidates will be
required to have a sound grasp of the provisions of Section 10 of the Income-tax Act and a working
knowledge only of Sections 3 to 4-B, 6 to 15-A and 16 (1) & (a) (b), 16 (2), 17, 18-A, 22, 23 (1) to (3),
26-A, 42,49-B and 55 to 58 and the connected rules of the [Indian Income-tax Act, 1925] [Now,
Income Tax Act, 1961.]. Also the Indian Finance Acts of 1946 and subsequent years.B. Rural
Economics with special reference to Bihar and Co-operative in India: Partnership accounts : Receipt
and Payment Account and Income and Expenditure Account. Joint Stock Company accounts
including amalgamation, absorption and reconstruction. Banking Account-100 marks.C. Indian
Currency and Commercial Banking operation: Partnership account: Receipt and payment account
and income and expenditure account. Joint Stock Company accounts including amalgamation,
absorption and reconstruction. Banking Account-100 marks.A candidate can take any two from the
above three groups.
30. Statistics. - Elementary ideas of probability including Baye's hypothesis,
expected values, Lagran's and advancing interpolation formulae, derivation
of normal cure and some of its fundamental properties. Elementary Theory ofBihar Board's Miscellaneous Rules, 1958

Least Square.
Descriptive Statistics. - Tabulation, classification, graphical representation averages (including
index numbers in some details), dispersion, symmetry Kurtosis, elementary theory of Attributes and
Association, Distribution, function of mean and variance in a normal population, elementary
properties of some standard distributions, e.g., Binomial, rectangular Conchy's Personian,
Derivations of x2 distribution from independent normal variates. Properties of Bivariate normal
distributions. Theory of co-relation co-efficient including Personians co-efficient, rank and
inter-class correlation co-efficients, with two and three variables only. Concepts of sampling in
statistics (including random, purposive and stratified), elementary tests of hypothesis involving the
use of t, F x2 distribution without formal proofs, elementary idea of analysis of variance and
covariance (one way and two way classifications).
31. Agriculture
(1)Introduction. - Its brief history, scope and importance, relation to other industries and sciences;
some agricultural statistics of Bihar, such as classification of areas under different crop, irrigated
areas, and crops distribution of populations, etc.(2)Soils. - Soil and sub-soils texture and structure
of soil, soil moisture; soil air; soil temperatures; soil micro-organisms : physical properties of
soil.(3)Tillage and Farm Implements. - Definition, importance, objects and kinds of tillage, essential
differences in tillage in different types of soils, preparation of seed bed; control of weeds.A study of
the indigenous improved and introduced implements in Bihar in respect of assemblage, adjustment,
working cost, care and economics of operation.(4)Climatology. - Definition and scope; factors and
elements of climate; common meteorological instruments and their uses; Weather forecast, relation
of climate to the distribution of crops and systems of farming.(5)Irrigation, Drainage and Land
Development. - Importance of irrigation, Water requirements of crops, hydraulic terminology,
detailed study of different sources of Irrigation.Dry farming, its scope and relation to rainfall; dry
farm crops and tillage methods.Importances of drainage, kinds of drainage, reclamation of acid
alkali and kans infested lands or otherwise lying waste; soil conservations, pasture
management.(6)Manuring. - Fertility of land; principles underlying manuring of crops; detailed
study of F.Y. M., compost, green mixturing, oil-cakes and various inorganic fertilizers.(7)Principles
of crops production. - Crop rotations; crop mixtures ; seed selection ; multiplication and distribution
of pure seeds; classification of crops and detailed study of the following crops :-Paddy, Maize,
Wheat, Barley, Linseeds, Gram Arhar, Jute, Cotton, Sugarcane, Tobacoo, Jowar, Berseem,
Soyabeen, Turmeric, Onions-Chillies, Potatoes, Sweet Potatoes.(8)Farm management. - (1) Different
types of farming; lay-out of different types of farms; successful management of farms and
maintaining farm accounts.(9)Extension service for agricultural and rural development.Appendix
XAcknowledgement by Government of Meritorious Service of OfficersCircular letter no.
330-67-A.R. dated Ranchi, the 24th April, 1935 from the Government of Bihar and Orissa,
Appointment DepartmentI am directed to say that Government have decided that it is fitting that
the services of officers belonging to the Provincial and Subordinate Services in Bihar and Orissa who
have meritorious records should be recognised on their retirement by a letter of thanks on behalf of
Government. His Excellency the Governor has decided that the following conditions should be
observed in the issue of such letter:-(a)Officers of all ranks except menials should be entitled toBihar Board's Miscellaneous Rules, 1958

receive a letter of thanks on retirement after consistently meritorious service.(b)Service must be of
conspicuous merit. The possession of a title should not necessarily qualify nor absence of a title
necessarily disqualify.(c)The officer should have completed twenty-five year's service.(d)The head of
the department or office should on the retirement of each officer consider whether he merits a letter
of thanks and should submit his recommendation to the proper authority.(e)In the case of gazetted
officers, His Excellency the Governor will issue the letter of thanks after receiving the
recommendations of the Head of the Department and the Member or Minister in-charge of that
Department.(f)in the case of non-gazetted officers the letter should be issued by the Head of the
Department or the Commissioner of the Division.Appendix Y[Bihar Government Servants
(Classification, Control & Appeal) Rules, 2005] [Published in the Bihar Gazette (Extra-ordinary)
dated 13.7.2005.]Government of Bihar, PARD, Notification No. 3/M-1-16/2001-Ka-1112,
dated-12.7.2005. - In exercise of the powers conferred by the proviso to the Article 309 of the
Constitution of India, the Government of Bihar is pleased to make the following rules-Part-I General
1. Short title, extent and commencement. - (1) These Rules may be called
the"Bihar Government Servants (Classification, Control and Appeal) Rules,
2005.
(2)It shall extend to the whole of the State of Bihar.(3)These Rules shall come into force from the
date of its publication in the official Gazette.
2. Definition. - For the purposes of these Rules, unless there is any thing
repugnant in the subject or context. -
(a)'Government' means the Government of Bihar;(b)'Orders of the Government' means executive
orders passed in exercise of powers given under Rules of Executive Business framed under Article
166 of the Constitution of India;(c)'Probationer' means a person appointed to a service on
probation;(d)'Civil Services cadre' means all classes of Civil Services of the State and it includes also
all other similar cadre or extra cadre existing posts under the State Government of Bihar.(e)'Post'
means any existing post under the services of the State Government of Bihar.(f)'Appointing
authority' in relation to a Government servant means the authority-(i)who is empowered to make
appointments to the Service of which the government servant is for the time being a member,
or(ii)who is empowered to make appointments to the post which the government servant for the
time being holds, or(iii)who has appointed the government servant to such Service, grade or post, as
the case may be, or(iv)where the government servant having been a permanent member of any other
Service or having substantively held any other permanent post, has been in continuous employment
of the government, such authority who appointed him to that Service or to any grade in that Service
or to that post,(g)'Cadre authority' in relation to a service, has the same meaning as in the Rules
regulating that service;(h)'Commission' means the Bihar Public Service Commission;(i)'Department
of the Government of Bihar' means a department as specified in the Rules of Executive
Business;(j)Save as otherwise expressly provided in the Rules of a particular cadre, 'Disciplinary
Authority' means Appointing Authority or any other Authority authorised by it who shall be
competent under these Rules to impose on a government servant any of the penalties specified inBihar Board's Miscellaneous Rules, 1958

rule 14 of these Rules;(k)'Government servant' means a person who-(i)is a member of a service or
holds a civil post under the State and it includes any such person on foreign service or whose
services are temporarily entrusted to the Government, or a local or other authority;(ii)is a member
of a service or holds a civil post under the Government and whose services are temporarily entrusted
to the Union Government or any other State Government;(l)'Head of the department' for the
purpose of exercising the powers as appointing, disciplinary, appellate or revisional authority,
means such authority who is declared as the head of the Department under the Bihar Service
Code;(m)'Head of the office, for the purpose of exercising the powers as appointing disciplinary,
appellate or revisional authority, means such authority who is declared to be the Head of the
Office;(n)'Secretary' means a Secretary to the Government in any Department;(o)'Service' means a
civil service of the State;(p)'Valid notice' means a notice as provided under C.P.C. and the General
Clauses Act.
3. Application of these Rules. - (1) These Rules shall apply to every
government servant but shall not apply to-
(a)any member of the All India Services,(b)any person in casual employment,(c)any person subject
to discharge from service on less than one month's notice,(d)any person for whom special provision
is made, in respect of matter covered by these Rules, by or under any law for the time being in force
or by or under any agreement entered into with the previous approval of the Government before or
after the commencement of these Rules, in regard to matter covered by such special
provisions.(2)Notwithstanding anything contained in sub-rule (1), the Government of Bihar may, by
order, exclude any class of government servants from the operation of all or any of these Rules
against him.(3)Notwithstanding anything contained in sub-rule (1), these Rules shall apply to every
government servant temporarily transferred to a Service or post coming within (d) in sub-rule
(1).(4)If any doubt arises with respect to the provisions of these Rules the matter shall be referred to
the Government in the Department of Personnel & Administrative Reforms, whose decision shall be
final.
Part II – Classification
4. Classification of Civil Services. - The Civil Services of the State shall be
classified as follows:-
(i)Group-A(ii)Group-B(iii)Group-C(iv)Group-D
5. Constitution of Civil Services. - The Civil Services of the State shall be
constituted into Group-A, Group-B, Group-C and Group-D by a general or
special order of the Government.Bihar Board's Miscellaneous Rules, 1958

6. Classification of posts. - All the civil posts under the State shall, by a
general or special order of the Government, be classified as follows:-
(i)Group-A(ii)Group-B(iii)Group-C(iv)Group-DExplanation-All references to Civil Services/Civil
Posts of Group-A, Group-B, Group-C and Group-D in all Rules, Orders, Schedules, Notifications,
Regulations, Instructions and Directions in force, immediately before the commencement of these
Rules shall be construed as references to Civil Services/Civil posts, Group-A, Group-B, Group-C and
Group-D respectively.
Part III – Appointing Authority
7. Appointment in Group A and Group B of Civil Services. - All appointments
to Group-A and Group-B of Civil Services and Group-A posts shall be made
by the Government:
Provided that the Government may, by a general or a special order and subject to such conditions as
may be specified in such order, delegate the power to make such appointments to any other
authority.
8. Appointments to other Services and Posts. - All appointments to Group-B,
Group-C and Group-D posts shall be made by the authorities specified in that
behalf by a general or special order of the Government.
Part IV – Suspension
9. Order of Suspension. - (1) The appointing authority or any authority to
which the appointing authority is subordinate or the disciplinary authority or
any other authority empowered in that behalf by the Government by general
or special order, may place a government servant under suspension when-
(a)a disciplinary proceeding against the government servant is contemplated or is pending, or(b)in
the opinion of the authority aforesaid, the government servant has engaged himself or herself in
activities prejudicial to the interest of the security of the State, or(c)a case against the government
servant in respect of any criminal offence is under investigation, inquiry or trial and the competent
authority is satisfied that it is expedient to suspend the government servant in public interest.(2)A
government servant shall be deemed to have been placed under suspension by an order of
appointing authority with effect from the following date:-(a)from the date of his or her detention, if
he or she is detained in custody, whether on a criminal charge or otherwise for a period exceeding
forty-eight hours;(b)from the date of his or her conviction, if, in the event of a conviction for an
offence he or she is sentenced to a term of imprisonment exceeding forty-eight hours and is not
forthwith dismissed or removed or compulsorily retired consequent to such conviction.Explanation.Bihar Board's Miscellaneous Rules, 1958

- The period of forty-eight hours specified in clause (b) of this sub-rule shall be computed from the
date of commencement of the imprisonment after the conviction and for this purpose intermittent
periods of imprisonment, if any, shall be taken into account.(3)(i)After the custody period under
sub-rule (2), the period of deemed suspension shall be deemed to end when the government servant
gives his joining and the joining shall be accepted.(ii)If a decision is taken to suspend the
government servant again under sub-rule (1)(a), or (b) or (c), then such action may be taken only
after acceptance of joining and by issuing a separate order.(4)Where a penalty of dismissal, removal
or compulsory retirement from service imposed upon a government servant under suspension is set
aside in appeal or on revision under these Rules and the case is remitted for further inquiry or action
or with any other directions, the order of his suspension shall be deemed to have continued in force
on and from the date of the original order of dismissal removal or compulsory retirement and shall
remain in force until further orders.(5)Where a penalty of dismissal, removal or compulsory
retirement from service imposed upon a government servant is set aside or declared or rendered
void in consequence of or by a decision of a court of law and the disciplinary authority, on a
consideration of the circumstances of the case, decides to hold further inquiry against the
government servant to meet a situation where the court has passed an order purely on technical
grounds without going into the merits of the case, on the allegations on which the penalty of
dismissal, removal or compulsory retirement was originally imposed, the government servant shall
be deemed to have been placed under suspension by the Appointing Authority from the date of the
original order of dismissal, removal or compulsory retirement and shall continue to remain under
suspension until further orders.(6)(a)An order of suspension made or deemed to have been made
under this rule shall continue to remain in force until it is modified or revoked by the authority
competent.(b)Where a government servant is suspended or is deemed to have been suspended
(whether in connection with any disciplinary proceeding or otherwise), and any other disciplinary
proceeding is commenced against him or her during the continuance of that suspension, the
authority, competent to place him or her under suspension, may, for reasons to be recorded by it in
writing, direct that the government servant shall continue to be under suspension till the
termination of all or any of such proceedings.(c)An order of suspension made or deemed to have
been made under this rule may, at any time, be modified or revoked by the same authority who or
whose subordinate authority has passed such order.(7)Charge-sheet must be framed within three
months from the date of issue of suspension order failing which on expiry of three months, the
suspension order shall be revoked unless the authority, which issued the suspension order, passes
the order renewing the suspension alongwith reasons to be recorded in writing for the delay in
framing of charge-sheet for a further period of four months :Provided that after the expiry of
extended period of four months the suspension order shall stand revoked if the charge-sheet is not
framed.
10. Subsistence allowance during suspension-(1) A government servant
under suspension or deemed to have been placed under suspension shall be
entitled to receive a subsistence allowance an amount equal to the half
average pay and in addition, dearness allowance admissible on such half pay
:Bihar Board's Miscellaneous Rules, 1958

Provided that where the period of suspension has exceeded twelve months, the authority, who has
made such order of suspension, shall be competent to vary the amount of subsistence allowance for
any period subsequent to the period of first twelve months as follows:-(i)the amount of subsistence
allowance may be increased by such a suitable amount, which shall not be exceeding fifty per cent of
the subsistence allowance admissible during the period of the first twelve months, if in the opinion
of the said authority, the period of suspension has been prolonged for which, for reasons to be
recorded in writing, the government servant is not responsible.(ii)the amount of subsistence
allowance may be reduced by such a suitable amount which shall not be exceeding fifty per cent of
the subsistence allowance admissible during the period of first twelve months, if, in the opinion of
the said authority, the period of suspension has been prolonged, for which, for reasons to be
recorded in the writing, the government servant is responsible.(iii)the rate of dearness allowance
will be based on the rates increased or, the reduced amount, as the case may be, of subsistence
allowance admissible under sub-clause (i) or sub-clause (ii) of this rule :Provided further that the
government servant shall be entitled to receive subsistence allowance only for such period when he
is actually present at the headquarters during these suspension period. He shall be required to mark
his attendance in the attendance register meant for such government servant.Provided further that
since the headquarters cannot be fixed for the period of custody, therefore marking of such
attendance shall not be required for the period of custody.(2)No government servant shall be
entitled to receive payment under sub-rule (1) unless he furnishes a certificate that he is not engaged
in any other employment, business, profession or vocation.(3)Where suspension is under sub-rule
(2) of rule 9, in that case also the subsistence allowance shall be admissible in accordance with
sub-rule (1) above. As a result of deemed suspension due to detention in custody the payment of
subsistence allowance may be made to the dependent nominated by the government servant on the
basis of his authority. Such subsistence allowance shall be paid by the same establishment where the
government servant was posted at the time of detention.(4)The disciplinary authority shall be the
competent authority to grant subsistence allowance and to increase or decrease the same.
11. Treatment of service on reinstatement and admissibility of pay and
allowances after suspension. - (1) When a government servant under
suspension is reinstated or would have been so reinstated but for his
superannuation while under suspension, the disciplinary authority shall
consider and make specific order regarding the following-
(a)the pay and allowances to be paid to the government servant for the period of suspension ending
with reinstatement or the date of his retirement on superannuation, as the case may be,
and(b)whether or not the said period shall be treated as a period spent on duty.(2)Notwithstanding
anything contained in rule-10 of these Rules, where a government servant under suspension has
died before the disciplinary or court proceedings instituted against him are concluded, the period
between the date of suspension and the date of death shall be treated as on duty for all purposes and
his family shall be paid the full pay and allowances for that period to which he would have been
entitled had he not been suspended. While making such payment adjustment shall be made in
respect of subsistence allowance and other allowances already paid and the adjustment of
government dues or loans.(3)Where the disciplinary authority is of the opinion that the suspensionBihar Board's Miscellaneous Rules, 1958

was wholly unjustified, the government servant shall, subject to the provisions of sub-rule (8) of this
rule, be paid such full pay and allowances to which he would have been entitled, had he not been
suspended. While making such payment adjustment shall be made in respect of subsistence
allowance and other allowances already paid:Provided that where such authority is of the opinion
that the termination of the proceedings instituted against the government servant had been delayed
due to reasons directly for which the government servant is liable, it may, give the government
servant an opportunity to make his or her representation and consider the representation, if any,
submitted by him or her. After that it may direct, for reasons to be recorded in writing, that the
government servant shall be paid for the period of such delay only such proportion of such pay and
allowances as may be determined by it.(4)In cases falling under sub-rule (3) of this rule, the period
of suspension shall be treated as a period spent on duty for all purposes.(5)In cases other than those
falling under sub-rules (2) and (3) of this rule, the government servant shall subject to the
provisions of sub-rules (8) and (9), be paid such proportion of the full pay and allowances to which
he would have been entitled had he not been suspended, as the disciplinary authority may
determine. Such determination by the disciplinary authority shall be done after giving notice to the
government servant of the quantum proposed and after considering the representation, if any,
submitted by him in that connection within sixty days from the date on which notice aforesaid is
served on the government servant.(6)Where suspension is revoked pending finalisation of the
disciplinary proceeding or proceedings in a court, any order passed under sub-rule (1) of this rule
before the conclusion of the proceedings against the government servant, shall be reviewed on its
own motion after the conclusion of the proceedings by the disciplinary authority and an order shall
be made by him in accordance with the provisions contained in sub-rule (3) or sub-rule (5), as the
case may be.(7)In a case failing under sub-rule (5) of this rule the period of suspension shall not be
treated as a period spent on duty, unless the disciplinary authority specifically directs that it shall be
the period spent for any specified purposes.(8)The payment of allowances under sub-rule (2),
sub-rule (3) or sub-rule (5) of this rule shall be subject to all other conditions under which such
allowances are admissible.(9)The proportion of the full pay and allowances determined under the
proviso to sub-rule (3) or under sub-rule (5) of this rule shall neither be equal to full pay and
allowances nor shall it be less than the subsistence allowance.
12. Treatment of service on reinstatement and admissibility of pay and
allowances after dismissal, removal or compulsory retirement as a result of
appeal. - (1) When a government servant, who has been dismissed, removed
or compulsorily retired, is re-instated as result of appeal or would have been
so reinstated but for his retirement on superannuation while under
suspension or not, the disciplinary authority shall consider and pass a
specific order.
(a)regarding the pay and allowances to be paid to the government servant for the period of his
absence from duty including the period of suspension preceding his dismissal, removal, or
compulsory retirement, as the case may be; and(b)whether or not the said period shall be treated as
a period spent on duty?(2)The government servant shall, subject to the provisions of sub-rule (6) be
paid the full pay and allowances to which he would have been entitled, had he not been dismissed,Bihar Board's Miscellaneous Rules, 1958

removed or compulsorily retired or suspended prior to such dismissal, removal or compulsory
retirement, as the case may be, in cases-(i)where the disciplinary authority is of opinion that the
government servant who had been dismissed, removed or compulsorily retired has been fully
exonerated, or(ii)where the order of dismissal, removal or compulsory retirement from service is set
aside by the appellate authority solely on the ground of noncompliance of the requirement of these
Rules and no further inquiry is proposed to be held :Provided that where such authority is of the
opinion that the termination of the proceedings instituted against the government servant had been
delayed due to reasons directly attributable to the government servant, it may, after giving him an
opportunity to make his representation and after considering the representation, if any, submitted
by him, direct, for reasons to be recorded in writing, that the government servant shall, subject to
the provisions of sub-rule (7), be paid for the period of such delay, only such proportion of such pay
and allowances as it may be determined by him.(3)In a case falling under sub-rule (2), the period of
absence from duty including the period of suspension preceding dismissal, removal or compulsory
retirement, as the case may be, shall be treated as a period spent on duty for all purposes.(4)In cases
other than those covered by sub-rule (2) of this rule the government servant shall, subject to the
provisions of sub-rule (6) and (7), be paid such proportion of the full pay and allowances to which he
would have been entitled, had he not been dismissed, removed or compulsorily retired or suspended
prior to such dismissal, removal or compulsory retirement, as the case may be, as the disciplinary
authority may determine.The disciplinary authority shall determine the proportion of such payment
after giving notice to the government servant of the quantum proposed and after considering the
representation, if any, submitted by him, in that connection within sixty days from the date on
which the notice aforesaid is served on the government servant.(5)In a case falling under sub-rule
(4), the period of absence from duty including the period of suspension preceding his dismissal,
removal or compulsory retirement, as the case may be, shall not be treated as a period spent on
duty, unless the disciplinary authority specifically directs that it shall be so treated for any specified
purpose:Provided that if the government servant so represents, such authority may after
consideration, direct that the period of absence from duty including the period of suspension
preceding his dismissal, removal or compulsory retirement, as the case may be, shall be converted
into leave of any kind due and admissible to the government servant.(6)The payment of allowances
under sub-rule (2) or sub-rule (4) shall be subject to all other conditions under which allowances are
admissible.(7)The proportion of the full pay and allowances determined under the proviso to
sub-rule (2) or under sub-rule (4) shall neither be equal to the full pay and allowances nor less than
the subsistence allowance and other allowances admissible under rule 10, as the case may be.(8)Any
payment made under this rule to a government servant on his reinstatement shall be subject to
adjustment of the amount, if any, earned by him through an employment during the period between
the date of removal, dismissal or compulsory retirement, as the case may be, and the date of
reinstatement. Where the pay and allowances admissible under this rule are equal to or less than the
amounts earned during such employment elsewhere, nothing shall be paid to the government
servant.
13. Treatment of service on reinstatement and admissibility of pay and
allowances where dismissal, removal or compulsory retirement is set aside
by a court of law. - (1) Where the dismissal, removal or compulsoryBihar Board's Miscellaneous Rules, 1958

retirement of a government servant is set aside by a court of law and such
government servant is reinstated without holding any further inquiry, the
period of absence from duty shall be regularised and the government servant
shall be paid pay and allowances in accordance with the provisions of
sub-rule (2) or (3) of this rule subject to the directions if any, of the court.
(2)(i)In cases other than those covered by sub-rule (3) of this rule, the government servant shall be
paid such proportion of the full pay and allowances to which he would have been entitled had he not
been dismissed, removed or compulsorily retired, or suspended prior to such dismissal, removal or
compulsory retirement, as the case may be, and as the disciplinary authority may determine. The
disciplinary authority shall determine the proportion of such payment after giving notice to the
government servant of the quantum proposed and after considering the representation, if any,
submitted by him, in that connection, within sixty days from the date on which the notice aforesaid
is served on the government servant:Provided that the payment under this sub-rule to a government
servant shall neither be equal to the full pay and allowances nor less than the subsistence allowance
and other allowances admissible under rule 10, as the case may be.(ii)The period intervening
between the date of dismissal, removal or compulsory retirement including the period of suspension
preceding such dismissal, removal or compulsory retirement, as the case may be, and the date of
judgement of the court shall be regularised in accordance with the provisions contained in sub-rule
(5) of rule 12.(3)Where the dismissal, removal or compulsory retirement of a government servant is
set aside by a court on the merit of the case, or where the dismissal, removal or compulsory
retirement of a government servant is set aside by a court solely on the ground of non-compliance
with the requirements of these Rules and no further inquiry is proposed to be held, the period
intervening between the date of dismissal, removal or compulsory retirement as the case may be,
and the date of reinstatement shall be treated as on duty for all purposes. As a result the government
servant shall be paid full pay and allowances for the period to which he would have been entitled,
had he or she not been dismissed, removed or compulsorily retired or suspended prior to such
dismissal, removal or compulsory retirement, as the case may be.(4)The payment of allowances
under sub-rule (2) or sub-rule (3) shall be subject to all other conditions under which such
allowances are admissible.(5)Any payment made under this rule to a government servant on his
reinstatement shall be subject to adjustment of the amount, if any, earned by him or her through
any employment during the period between the dismissal, removal or compulsory retirement and
the date of reinstatement. Where the pay and allowances admissible under this rule are equal to or
less than those earned during such employment elsewhere, nothing shall be paid to the government
servant.Part-V Penalties and Disciplinary Authorities
14. Minor and Major Penalties. - The following penalties may, for good and
sufficient reasons and as hereinafter provided, be imposed on a government
servant, namely:-
Minor Penalties(i)censure;(ii)withholding of promotion;(iii)recovery from his pay of the whole or
part of any pecuniary loss caused by him to the Government by negligence or breach of
orders:(iv)reduction to a lower stage in the time-scale of pay for a period not exceeding three years,Bihar Board's Miscellaneous Rules, 1958

without cumulative effect.(v)withholding of increments of pay;Major Penalties(vi)Save as provided
for in clause (iv) reduction to a lower stage in time-scale of pay for a specified period, with further
directions as to whether or not the government servant will earn increments of pay during the
period of such reduction and whether on the expiry of such period the reduction will or will not have
the effect of postponing the future increments of his pay;(vii)reduction to a lower time-scale of pay,
grade, post or Service which shall ordinarily be a bar to the promotion of the government servant to
the time-scale of pay, grade, post or service from which he or she was reduced, with or without
further directions regarding conditions of restoration to the grade or post or service from which the
government servant was reduced and his seniority and pay on such restoration to that grade, post or
Service;(viii)compulsory retirement;(ix)removal from service which shall not be a disqualification
for future employment under the Government;(x)dismissal from service which shall ordinarily be a
disqualification for future employment under the Government:Provided that, in every case in which
the charge of acceptance from any person of any gratification, other than legal remuneration, as a
motive or reward for doing or forbearing to do any official act is established, the penalty mentioned
in clause (ix) or clause (x) shall be imposed:Provided further that in any exceptional case and for
special reasons to be recorded in writing, any other penalty may be imposed.Explanation- The
following shall not amount to a penalty within the meaning of this rule, namely:-(i)withholding of
increments of pay of a government servant for his failure to pass any departmental examination in
accordance with the Rules or orders governing the service to which he belongs or post which he
holds or the terms of his appointment;(ii)withholding of promotion of a government servant after
consideration of his case to a service, grade or post for which he is eligible, whether he is in a
substantive or in officiating capacity.(iii)non-promotion of a government servant, whether in a
substantive or officiating capacity, after consideration of his case, to a Service, grade or post for
promotion to which he is eligible:(iv)reversion of a government servant officiating in a higher
Service grade, or post to a lower Service, grade or post or on any administrative ground unconnected
with his conduct;(v)reversion of a government servant appointed on probation to any other Service
grade or post to his permanent Service, grade or post during or at the end of the period of probation
in accordance with the terms and conditions of his appointment or the Rules and order governing
such probation:(vi)replacement of the services of a government servant, whose services had been
borrowed from a State Government or an authority under the control of a State Government, at the
disposal of the State Government or the authority from which the services of such government
servant had been borrowed;(vii)compulsory retirement of a government servant in accordance with
the provisions relating to superannuation or retirement under rule 74 of the Bihar Service
Code;(viii)termination of the service-(a)of a government servant appointed on probation, during or
at the end of the period of his probation, in accordance with the terms and conditions of his
appointment or the Rules and orders governing such probation; or(b)of a government servant,
employed under an agreement, in accordance with the terms of such agreement.
15. Disciplinary Authorities. - (1) The Government may impose any of the
penalties specified in rule 14 on any government servant.
(2)Without prejudice to the provisions of sub-rule (1), any of the penalties specified in rule 14 may
be imposed on a government servant by the appointing authority or any authority to which the
appointing authority is subordinate or by any other authority empowered in this behalf by a generalBihar Board's Miscellaneous Rules, 1958

or special order of the Government.
16. Authority to institute proceedings. - (1) The Government or appointing
authority or any authority to which the appointing authority is subordinate or
any other authority empowered by general or special order of the
Government may-
(a)institute disciplinary proceedings against any government servant;(b)direct a disciplinary
authority to institute disciplinary proceedings against any government servant on whom that
disciplinary authority is competent to impose any of the penalties specified in rule 14 under these
Rules.(2)A disciplinary authority, competent under these Rules to impose any of the penalties
specified in clauses (i) to (v) of rule 14, may institute disciplinary proceedings against any
government servant for the imposition of any of the penalties specified in clauses (vi) to (x) of rule
14 notwithstanding that such disciplinary authority is not competent under these Rules to impose
any of the penalties under clauses (vi) to (x) of Rule 14.Part-VI Procedure for Imposing Penalties
17. Procedure for imposing major penalties. - (1) No order imposing any of
the penalties specified in clauses (vi) to (x) of rule 14 shall be made without
holding an inquiry, as far as may be, in the manner provided in these Rules.
(2)Wherever the disciplinary authority is of the opinion that there are grounds for inquiring about
the truth of any imputation of misconduct or misbehaviour against a government servant, he may
himself inquire into it, or appoint under these Rules an authority to inquire about the truth
thereof.Explanation. - Where the disciplinary authority himself holds the inquiry, any reference in
sub-rule (7) to sub-rule (20) and in sub-rule (22) of this rule to the inquiring authority shall be
construed as a reference to the disciplinary authority.(3)Where it is proposed to hold an inquiry
against a government servant under this rule, the disciplinary authority shall draw up or cause to be
drawn up-(i)the substance of the imputations of misconduct or misbehaviour as a definite and
distinct article of charge;(ii)a statement of the imputations of misconduct or misbehaviour in
support of each article of charge, which shall contain-(a)a statement of all relevant facts including
any admission or confession made by the government servant;(b)a list of such document by which,
and a list of such witnesses by whom, the articles of charge are proposed to be sustained.(4)The
disciplinary authority shall deliver or cause to be delivered to the government servant a copy of the
articles of charge, such statement of the imputations of misconduct or misbehaviour and a list of
documents and witnesses by which each article of charge is proposed to be sustained and shall
require the government servant to submit, within such time as may be specified, a written statement
of his defence and to state whether he desires to be heard in person.(5)(a)On receipt of the written
statement of defence, the disciplinary authority may himself inquire into such of the articles of
charge which are not admitted, or, if it thinks necessary to appoint, under sub-rule (2) of this rule,
an inquiry authority for the purpose he may do so and where all the articles of charges have been
admitted by the government servant in his written statement of defence, the disciplinary authority
shall record his findings on each charge after taking such evidence as it may think fit and shall take
action in the manner laid down in rule 18.(b)If no written statement of defence is submitted by theBihar Board's Miscellaneous Rules, 1958

government servant, the disciplinary authority may itself inquire into the articles of charge or may,
if it thinks necessary to appoint, under sub-rule (2) of this rule an inquiry authority for the purpose,
it may do so.(c)Where the disciplinary authority itself inquires into any article of charge or appoints
an inquiring authority for holding an inquiry about such charge, it may, by an order, appoint a
government servant or a legal practitioner to be known as the "Presenting officer' to present on his
behalf the case in support of the articles of charge.(6)The disciplinary authority shall, where it is not
the inquiring authority, forward the following records to the inquiring authority-(i)a copy of the
articles of charge and the statement of the imputations of misconduct or misbehaviour;(ii)a copy of
the written statement of defence, if any, submitted by the government servant:(iii)a copy of the
statement of witnesses, if any, specified in sub-rule (3) of this rule.(iv)evidence proving the delivery
of the documents specified to in sub-rule (3) to the government servant; and(v)a copy of the order
appointing the "Presenting officer".(7)The government servant shall appear in person before the
inquiring authority on such day and at such time within ten working days from the date of receipt by
him of the articles of charge and the statement of the imputations of misconduct or misbehaviour, as
the inquiring authority may, by a notice in writing, specify in this behalf or within such further time,
not exceeding ten days, as maybe specified by the inquiring authority.(8)(a)The government servant
may take the assistance of other government servant posted in any office, either at his headquarter
or at the place where the inquiry is to be held, to present the case on his behalf:Provided that he may
not engage a legal practitioner for the purpose, unless the Presenting Officer appointed by the
disciplinary authority is a legal practitioner, or the disciplinary authority, having regard to the
circumstances of the case, so permits:Provided also that the government servant may take the
assistance of any other government servant posted at any other station, if the inquiring authority
having regard to the circumstances of the case, and for reasons to be recorded in writing so
permits:Provided further that the government servant shall not take the assistance of any such other
government servant who has three pending disciplinary cases on hand in which he has to give
assistance.(b)The government servant may take the assistance of a retired government servant to
present the case on his behalf, subject to such conditions as may be specified by the Government
from time to time by general or special order in this behalf.(9)If the government servant, who has
not admitted any of the articles of charge in his written statement of defence or has not submitted
any written statement of defence, appears before the inquiring authority, such authority shall ask
him whether he is guilty or has to say any thing for his defence and if he pleads guilty to any of the
articles of charge, the inquiring authority shall record the plea, sign the record and obtain the
signature of the government servant thereon.(10)The inquiring authority shall return a finding of
guilt in respect of those articles of charge to which the government servant pleads guilty.(11)The
inquiring authority shall, if the government servant fails to appear within the specified time or
refuses or omits to plead, require the Presenting Officer to produce the evidence by which he
proposes to prove the articles of charge, and shall adjourn the case to a later date not exceeding
thirty days, after recording an order that the government servant may, for the purpose of preparing
his defence,-(i)inspect within five days of the order or within such further time not exceeding five
days as the inquiring authority may allow, the documents specified in the list in sub-rule
(3);(ii)submit a list of witnesses to be examined on his behalf;Note. - If the government servant
applies in writing for the supply of copies of the statements of witnesses mentioned in the list
referred to in sub-rule (3), the inquiring authority shall furnish him with such copies as early as
possible.(iii)give a notice within ten days of the order or within such further time as the inquiringBihar Board's Miscellaneous Rules, 1958

authority may allow for the discovery or production of any documents which are in the possession of
Government but not mentioned in the list specified in sub-rule (3) of this rule:Provided that the
government servant shall indicate the relevance of the documents required by him to be discovered
or produced by the Government.(12)The inquiring authority shall, on receipt of the notice for the
discovery or production of documents, forward the same or copies thereof to the authority in whose
custody or possession the documents are kept, with a requisition for the production of the document
by such date as may be specified in such requisition.Provided that the inquiring authority may, for
reasons to be recorded by it in writing, refuse to requisition such of the documents as are, in its
opinion, not relevant to the case.(13)On receipt of the requisition specified in sub-rule (12) of this
rule, every authority having the custody or possession of the requisitioned documents shall produce
the same before the inquiring authority:Provided that if the authority, having the custody or
possession of the requisitioned documents, is satisfied, for reasons to be recorded by it in writing,
that the production of all or any of such documents will be against public interest or security of the
State, he shall inform the inquiring authority accordingly and the inquiring authority shall, on being
so informed, communicate the information to the government servant and withdraw the requisition
made by it for the production or discovery of such documents.(14)On the date fixed for the inquiry,
the oral and documentary evidence by which the articles of charge are proposed to be proved shall
be produced by or on behalf of the disciplinary authority. The witnesses shall be examined by or on
behalf of the Presenting Officer and may be cross-examined by or on behalf of the government
servant. The Presenting Officer shall be entitled to re-examine the witnesses on any points on which
they have been cross-examined, but not on any new matter, without the leave of the inquiring
authority. The inquiring authority may also put such questions to the witnesses, as it thinks fit.(15)If
it shall appear necessary before the close of the case on behalf of the disciplinary authority, the
inquiring authority may, in his discretion, allow the Presenting Officer to produce evidence not
included in the list given to the government servant or may itself call for new evidence or recall and
re-examine any witness and in such case the government servant shall be entitled to have, if he
demands it, a copy of the list of further evidence proposed to be produced and an adjournment of
the inquiry for three clear days before the production of such new evidence, exclusive of the day of
adjournment and the day to which the inquiry is adjourned. The inquiring authority shall give the
government servant an opportunity of inspecting such documents before they are taken on the
record. The inquiring authority may also allow the government servant to produce new evidence, if
it is of the opinion that the production of such evidence is necessary in the interests of
justice:Provided that new evidence shall not be permitted or called for or any witness shall not be
recalled to supplement the evidence. Such evidence may be called for if there is any inherent lacuna
or defect in the evidence, produced originally.(16)When the case for the disciplinary authority is
closed, the government servant shall be required to state his defence, orally or in writing, as he may
prefer, if the defence is made orally, it shall be recorded and the government servant shall be
required to sign the record. In either case a copy of the statement of defence shall be given to the
Presenting Officer, if any, appointed.(17)The evidence on behalf of the government servant shall
then be produced. The government servant may examine himself in his own behalf if he so prefers.
The witnesses produced by the government servant shall then be examined and they shall be liable
to examination, cross-examination and, re-examination by the inquiring authority according to the
provisions applicable to the witnesses for the disciplinary authority.(18)The inquiring authority
may, after the government servant closes his case, and shall, if the government servant has notBihar Board's Miscellaneous Rules, 1958

examined himself, generally question him on the circumstances appearing against him in the
evidence for the purpose of enabling the government servant to explain any circumstances
appearing in the evidence against him.(19)The inquiring authority may, after the completion of the
production of evidence, hear the Presenting Officer, if any, appointed and the government servant,
or permit them to file written briefs of their respective case, if they so desire.(20)If the government
servant to whom a copy of the articles of charge has been delivered, does not submit the written
statement of defence on or before the date specified for the purpose or does not appear in person
before the inquiring authority or otherwise fails or refuses to comply with the provisions of this rule,
the inquiring authority may hold the inquiry ex-parte.(21)(a)Where a disciplinary authority
competent to impose any of the penalties specified in clauses (i) to (v) of rule 14 [but not competent
to impose any of the penalties specified in clauses (vi) to (x) of rule 14], has himself inquired into or
caused to be inquired into the article of any charge and that authority having regard to his own
findings or having regard to its decision on any of the findings of any inquiring authority appointed
by it, is of the opinion that the penalties specified in clauses (vi) to (x) of rule 14 should be imposed
on the government servant, that authority shall forward the records of the inquiry to such
disciplinary authority as is competent to impose the penalties mentioned in clause (vi) to (x) of rule
14.(b)The disciplinary authority to which the records are so forwarded may act on the evidence on
the records or may, if he is of the opinion that further examination of any of the witnesses is
necessary in the interests of justice, recall the witnesses and examine, cross-examine and
re-examine the witnesses and may impose on the government servant such penalties as it may deem
fit in accordance with these rules.(22)Whenever any inquiring authority, after having heard and
recorded the whole or any part of the evidence in an inquiry ceases to exercise jurisdiction therein,
and is succeeded by another inquiring authority which has and which exercises, such jurisdiction the
inquiring authority so succeeding may act on the basis of evidence so recorded by its predecessor, or
partly recorded by its predecessor and partly recorded by itself:Provided that if the succeeding
inquiring authority is of the opinion that further examination of any of the witnesses whose evidence
has already been recorded is necessary in the interest of justice, it may recall, examine,
cross-examine and re-examine any such witnesses as hereinbefore provided.(23)(i)After the
conclusion of the inquiry, a record shall be prepared and it shall contain:-(a)the articles of charge
and the statement of the imputations of misconduct or misbehaviour;(b)the defence of the
government servant in respect of each article of charge.(c)an assessment of the evidence in respect
of each article of charge,(d)the findings on each article of charge and the reasons
thereof.Explanation. - If in the opinion of the inquiring authority the proceedings of the inquiry may
establish any article of charge different from the original articles of the charge, he may record his
findings on such article of charge:Provided that the findings on such article of charge shall not be
recorded unless the government servant has either admitted the facts on which such article of
charge is based or has had a reasonable opportunity of defending himself against such article of
charge.(ii)The inquiring authority, where it is not itself the disciplinary authority, shall forward to
the disciplinary authority the records of inquiry which shall include-(a)the report prepared by it
under clause (i) of this sub rule;(b)the written statement of defence, if any, submitted by the
government servant;(c)the oral and documentary evidence produced in the course of the
inquiry;(d)written briefs, if any, filed by the Presenting Officer or the government servant or both
during the course of the inquiry; and(e)the orders, if any, made by the disciplinary authority and the
inquiring authority in regard to the inquiry.Bihar Board's Miscellaneous Rules, 1958

18. Action on the inquiry report. - (1) The disciplinary authority, if it is not
itself the inquiring authority may, for reasons to be recorded by it in writing,
may remit the case to the inquiring authority for further inquiry and report
and the inquiring authority shall thereupon proceed to hold the further
inquiry according to the provisions of rule 17 as far as may be.
(2)The disciplinary authority, after receipt of the enquiry report as per rule 17 (23)(ii) or as per
sub-rule (1), shall, if it disagrees with the findings of the inquiring authority on any article of charge,
record its reasons for such disagreement and record its own finding on such charge, if the evidences
on record is sufficient for the purpose.(3)The disciplinary authority shall forward or cause to be
forwarded a copy of the inquiry report, together with its own findings, if any, as provided in sub-rule
(2), to the government servant who may submit, if he or she so desires, his or her written
representation or submission to the disciplinary authority within fifteen days.(4)The disciplinary
authority shall consider the representation or submission, if any, submitted by the government
servant before proceeding further in the manner specified in sub rules (5) and (6).(5)If the
disciplinary authority having regard to its findings on all or any of the articles of charge, is of the
opinion that any of the penalties specified in clauses (i) to (v) of rule 14 should be imposed on the
government servant, it shall, notwithstanding anything contained in rule 19, make an order
imposing such penalty.(6)If the disciplinary authority, having regard to its findings on all or any of
the articles of charge and on the basis of the evidence adduced during the inquiry is of the opinion
that any of the penalties specified in clauses (vi) to (x) of Rule 14 should be imposed on the
Government servant, it shall make an order imposing such penalty and it shall not be necessary to
give the government servant any opportunity of making representation on the penalty proposed to
be imposed:(7)Notwithstanding anything contained in sub-rules (5) and (6), in every case where it is
necessary to consult the Commission, the Commission shall be consulted and its advice shall be
taken into consideration before making any order imposing any penalty on the government servant.
19. Procedure for imposing minor penalties. - (1) Subject to the provisions of
sub-rule (3) of rule 18, no order imposing on a government servant any of the
penalties specified in clauses (i) to (v) of rule 14 shall be made except after-
(a)informing the government servant in writing of the proposal to take action against him and of the
imputations of misconduct or misbehaviour on which it is proposed to be taken, and giving him
reasonable opportunity of making such representation as he may wish to make against the
proposal;(b)holding an inquiry in the manner laid down in sub-rules (3) to (23) of rule 17, in every
case in which the disciplinary authority is of the opinion that such inquiry is necessary;(c)taking the
representation, if any, submitted by the government servant under clause (a) and the record of
inquiry, if any, held under clause (b) into consideration;(d)recording a finding on each imputation
of misconduct or misbehaviour; and(e)consulting the Commission where such consultation is
necessary.(2)The record of the proceedings in such cases shall include-(i)a copy of the intimation to
the government servant of the proposal to take action against him;(ii)a copy of the statement of
imputations of misconduct or misbehaviour delivered to him:(iii)his representation if any:(iv)the
evidence produced during the inquiry;(v)the advice of the Commission, if any;(vi)the findings ofBihar Board's Miscellaneous Rules, 1958

each imputation of misconduct or misbehaviour; and(vii)the orders on the case together with the
reasons therefor.
20. Special procedure in certain cases. - Notwithstanding anything contained
in rules 17 to 19-
(i)where any penalty is imposed on a government servant on the ground of conduct which has led to
his conviction on a criminal charge, or(ii)where the disciplinary authority is satisfied for reasons to
be recorded by him in writing that it is not reasonably practicable to hold an inquiry in the manner
provided in these Rules, or(iii)where the Government is satisfied that in the interest of the State, it is
not expedient to hold any inquiry in the manner provided in these Rules,the disciplinary authority
may consider the circumstances of the case and make such orders thereon as it deems fit:Provided
that the government servant may be given an opportunity of making representation on the penalty
proposed to be imposed before any order is made in a case under clause (i):Provided further that the
Commission shall be consulted, where such consultation is necessary, before any orders are made in
any case under this rule.
21. Communication of Orders. - Orders made by the disciplinary authority
shall be communicated to the government servant who shall also be supplied
with a copy of its finding on each article of charge, or where the disciplinary
authority is not the inquiring authority, a statement of the findings of the
disciplinary authority together with brief reasons for its disagreement, if any,
with the findings of the inquiring authority and also a copy of the advice, if
any, given by the Commission, and where the disciplinary authority has not
accepted the advice of the Commission, a brief statement of the reasons for
such non-acceptance.
22. Common Proceedings. - (1) Where two or more government servants are
concerned in any case, the government or any other authority competent to
impose the penalty of dismissal from service on all such government
servants may make an order directing that disciplinary action against all of
them may be taken in a common proceeding.
Note. - If the authorities competent to impose the penalty of dismissal on such government servants
are different an order for taking disciplinary action in a common proceeding may be made by the
highest of such authorities with the consent of the others.(2)Any such order shall specify-(i)the
authority which may function as the disciplinary authority for the purpose of such common
proceeding;(ii)the penalties specified in rule 14 which such disciplinary authority shall be competent
to impose;(iii)whether the procedure laid down in rule 17 and rule 18 or rule 19 shall be followed in
the proceeding.Part-VII AppealsBihar Board's Miscellaneous Rules, 1958

23. Orders against which appeal lies. - A government servant may prefer an
appeal against order of suspension or order of punishment.
24. Appellate Authorities. - (1) A government servant, including a person who
has ceased to be in government service, may prefer an appeal against the
orders specified in rule 23 to the authority specified in this behalf by a
general or special order of the Government or, where no such authority is
specified:-
(i)where such government servant is or was a member of Civil Service, Group-A or Group-B or
holder of Civil Post, Group-A or Group-B,-(a)to the appointing authority, where the order appealed
against is made by an authority subordinate to it; or(b)to the Government where such order is made
by any other authority;(ii)where such Government servant is or was a member of a Civil Service,
Group-C or Group-D, to the authority to which the authority making the order appealed against is
immediately subordinate.(2)There shall be no appeal against the orders of the Government,
however, review petitions may be filed in the form of Memorials.(3)Where the person, who made
the order appealed against becomes, by virtue of his subsequent appointment or otherwise, the
appellate authority in respect of such order, an appeal against such order shall lie to the authority to
which such person is immediately subordinate or to an authority specially authorised for this
purpose by the Government.
25. Period of limitation for appeals. - No appeal preferred under this Part shall
be entertained unless such appeal is preferred within a period of forty five
days from the date on which a copy of the order appealed against is
delivered to the appellant:
Provided that the appellate authority may entertain the appeal after the expiry of the said period, if
he is satisfied that the appellant had sufficient cause for not preferring the appeal in time.
26. Forms and content of appeal. - (1) Every person preferring an appeal shall
do so separately and in his own name.
(2)The appeal shall be presented to the authority to whom the appeal may be filed and a copy of
appeal will be forwarded by the appellant to the authority which made the order appealed against. It
shall contain all material statements and arguments on which the appellant relies, shall not contain
any disrespectful or improper language, and shall be complete in itself.(3)The authority which made
the order appealed against, shall on receipt of a copy of the appeal, forward the same with its
comments thereon together with the relevant records to the appellate authority without any
avoidable delay, and without waiting for any direction from the appellate authority.Bihar Board's Miscellaneous Rules, 1958

27. Consideration of appeal. - (1) In the case of an appeal against an order of
suspension, the appellate authority shall consider whether in view of the
provisions of rule 9 and having regard to the circumstances of the case, the
order of suspension is justified or not and confirm or revoke or modify the
order accordingly.
(2)In the case of an appeal against an order imposing any of the penalties specified in rule 14, the
appellate authority shall consider-(a)whether the procedure laid down in these Rules has been
complied with and if not, whether such non-compliance has resulted in the violation of any
provisions of the Constitution of India or in the failure of justice,(b)whether the findings of the
disciplinary authority are warranted by the evidence on the record; and(c)whether the penalty
imposed is adequate, inadequate or severe; and pass orders-(i)confirming, enhancing, reducing, or
setting aside the penalty; or(ii)remitting the case to the authority which imposed the penalty or to
any other authority with such direction as it may deem fit in the circumstances of the case :Provided
that-(i)the Commission shall be consulted in ail cases where such consultation is necessary;(ii)if the
enhanced penalty which the appellate authority proposes to impose is one of the penalties specified
in clauses (i) to (v) of rule 14 and an inquiry under rule 17 has not already been held in the case, the
appellate authority shall, subject to the provisions, of rule 19, himself hold such inquiry or direct
that such inquiry be held in accordance with the provisions of rule 18 and thereafter on a
consideration of the proceedings of such inquiry and after giving the appellant a reasonable
opportunity, as far as may be in accordance with the provisions of clause (ii) of rule 18, of making a
representation against the penalty proposed on the basis of the evidence adduced during such
inquiry, make such orders as it may deem fit;(iii)if the enhanced penalty which the appellate
authority proposed to impose is one of the penalties specified in clauses (i) to (v) of rule 14 and an
inquiry under rule 17 has already been held in the case, the appellate authority shall, make such
orders as it may deem fit, after the appellant has been given a reasonable opportunity of making a
representation against the proposed penalty; and(iv)no order imposing an enhanced penalty shall
be made in any other case unless the appellant has been given a reasonable opportunity, as far as
may be, of making a representation against such enhanced penalty.(3)The appellate authority shall
consider all the circumstances of the case and make such orders as it may deem just and
equitable.Part-VIII Revision
28. Revision. - (1) Notwithstanding anything contained in these rules,-
(i)the Government, or(ii)the head of a department directly under the Government, in the case of a
Government servant serving in a department or office, under the control of such head of a
department, or(iii)the appellate authority, or(iv)any other authority specified in this behalf by the
Government by a general or special order, and within such time as may be prescribed in such
general or special order,may at any time within six months of the date of the order proposed to be
revised, either on his or its own motion or otherwise call for the records of any inquiry and revise
any order made under these Rules or under the Rules repealed by the rule 32 (from which an appeal
is allowed but from which no appeal has been preferred or from which no appeal is allowed), after
consultation with the Commission where such consultation is necessary, and may-(a)confirm,Bihar Board's Miscellaneous Rules, 1958

modify or set aside the order, or(b)confirm, reduce, enhance or set aside the penalty imposed by the
order, or impose any penalty where no penalty has been imposed, or(c)remit the case to the
authority, making the order or to any other authority, directing such authority, to make such further
inquiry as he may consider proper in the circumstances of the case, or(d)pass such other orders as it
may deem fit:Provided that no order imposing or enhancing any penalty shall be made by any
revising authority unless the government servant concerned has been given a reasonable
opportunity of making a representation against the penalty proposed and where it is proposed to
impose any of the penalties specified in clauses (vi) to (x) of rule-14 or to enhance the penalty
imposed by the order sought to be revised to any of the penalties specified in those clauses, no such
penalty shall be imposed without an inquiry in the manner laid down in rule-17 and after giving a
reasonable opportunity to the government servant concerned of showing cause against the penalty
proposed on the evidence adduced during the inquiry and except after consultation with the
Commission where such consultation is necessary:Provided further that no power of revision shall
be exercised by the head of department, unless-(i)the authority which made the order in appeal,
or(ii)the authority to which an appeal would lie, where no appeal has been preferred,is subordinate
to him.(2)No proceeding for revision shall be commenced until after(i)the expiry of the period of
limitation for an appeal, or(ii)the disposal of the appeal, where any such appeal has been
preferred.(3)An application for revision shall be dealt with in the same manner as if it were an
appeal under these Rules.Part-IX Miscellaneous
29. Power to relax time limit and to condone delay. - Save as otherwise
expressly provided in these Rules, the authority competent under these
Rules to make any order may, for good and sufficient reasons or if sufficient
cause is shown, extend the time specified in these Rules for anything
required to be done under these Rules or may condone any delay.
30. Over-riding effect of these Rules. - Notwithstanding contained any thing
contrary to these Rules in any other Rules, the provisions of these Rules
shall have over-riding effect.
31. Power of the Government to make regulation. - (1) The government may
make regulations to carry out all or any of the purposes of these Rules.
(2)All regulations made under these Rules shall be published in the official gazette.
32. Repeal and Savings. - (1) The notification No. - III/RI-101/63-8051 -A dated
3rd July, 1963 adopting the Civil Services (Classification, Control and
Appeal) Rules, 1930 and the Bihar and Orissa Subordinate Services
(Discipline and Appeal) Rules, 1935 as well as Notifications making
amendments in the said two Rules are hereby repealed.Bihar Board's Miscellaneous Rules, 1958

(2)All instructions issued under the Civil Services (Classification, Control & Appeal) Rules, 1930 and
the Bihar and Orissa Subordinate Services (Discipline and Appeal) Rules, 1935 from time to time are
hereby repealed.(3)Anything done or any action taken in exercise of the powers under the Civil
Services (Classification, Control & Appeal) Rules, 1930 and the Bihar and Orissa Subordinate
Service (Discipline & Appeal) Rules, 1935 shall be deemed to have been done or taken in exercise of
the powers conferred by or under those Rules as if those Rules were in force on the day on which
such thing or action was done or taken.(4)Nothing in these Rules shall operate to deprive any
person of any right of appeal, which he would have had if these Rules had not been made in respect
of any order passed before they came in force.(5)Notwithstanding anything contained in these Rules
any departmental proceedings initiated under the Rules repealed shall continue under those Rules
including the Appeal preferred against any punishment imposed as if those Rules were still in
existence.
33. Removal of doubts. - If any doubt arises as to the interpretation of any of
the provisions of these rules, the matter shall be referred to the Government
in the Department of Personnel & Administrative Reforms and its decision
shall be final.
[Substituted by Notification No. 3335 dated 25.3.1957.][Added by Notification No. 3335 dated
25.3.1957.]Bihar Board's Miscellaneous Rules, 1958

