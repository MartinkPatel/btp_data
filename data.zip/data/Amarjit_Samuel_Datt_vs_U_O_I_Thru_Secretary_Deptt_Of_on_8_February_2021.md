Amarjit Samuel Datt vs U.O.I. Thru. Secretary Deptt. Of ... on 8
February, 2021
Bench: Ritu Raj Awasthi, Manish Mathur
HIGH COURT OF JUDICATURE AT ALLAHABAD, LUCKNOW BENCH
AFR
Court No. - 1
Case :- P.I.L. CIVIL No. - 24271 of 2020
Petitioner :- Amarjit Samuel Datt
Respondent :- U.O.I. Thru. Secretary Deptt. Of Telecomm.,New Delhi & Ors.
Counsel for Petitioner :- Abhishek Singh,Prashant Kumar
Counsel for Respondent :- C.S.C.,A.S.G.
Hon'ble Ritu Raj Awasthi,J.
Hon'ble Manish Mathur,J.
1. Heard learned counsel for the petitioner as well as Mr. J.N. Mathur, learned Senior Advocate
assisted by Mr. Aakash Prasad, learned counsel for the opposite party no.7 and Mr. S.B. Pandey,
learned Assistant Solicitor General of India assisted by Mr. Ambrish Rai, learned Central
Government Counsel for opposite party nos. 1 to 4 and the learned Standing Counsel for the
opposite party nos. 5 and 6.
2. The writ petition has been filed seeking the following reliefs:-
i) Issue a writ of mandamus or a writ, order or direction in the nature of mandamus
commanding the opposite parties to remove the installation and operation of Mobile
Tower and 4G Base Transmitting Station (BTS) by the opposite party no.7 at the plot
of the opposite party no.8.Amarjit Samuel Datt vs U.O.I. Thru. Secretary Deptt. Of ... on 8 February, 2021

ii)  Issue a writ of mandamus or a writ, order or direction in the nature of mandamus
commanding the opposite parties to publish the result or conclusion of the study on
the possible impact of EMF radiation exposure from mobile tower and hand set on
life and related initiative conducted by opposite party no.1.
iii)  Issue a writ of mandamus or a writ, order or direction in the nature of mandamus
commanding the opposite parties to include the "Non-Ionizing Electromagnetic
Radiation" as pollutant under Environment (Protection) Act, 1986 and insert a
schedule therein detailing the safety norms/guidelines.
iv) Any other appropriate writ order or direction this Hon'ble Court may deem just
and necessary in the facts and circumstances of the case may also be passed; and
v) to allow this writ petition with costs."
3. Learned counsel for petitioner submits that opposite party no.7 has erected mobile tower and 4G
Base Transmitting Station at the adjacent plot of the residence of the petitioner. It is located in the
densely populated area and the emission of radiation from the tower has adverse effect on the health
of the petitioner and his family members and the people living nearby.
4. It is also submitted that no uniformed policy is being followed for installation of the mobile
towers and the advisory on use of mobile towers considering the impact on wildlife including birds
and bees, has not been considered as well as the questions raised in this regard before the
Parliament and the answers given by the Ministry of Telecommunication has also not been
considered. It is submitted that the petitioner had filed the instant writ petition in the nature of
Public Interest Litigation, however subsequently the writ petition has been treated in the
Miscellaneous Bench jurisdiction as the petitioner has come forward showing that the petitioner
himself is aggrieved with the action of the opposite parties in installation of 4G Base Transmitting
Station and mobile tower on the plot adjacent to the house of the petitioner.
5. Mr. J.N. Mathur, learned Senior Advocate appearing for the opposite party no.7, on the other
hand, submits that the controversy raised in the writ petition has been considered and decided by a
judgment of Division Bench of this Court in the case of Smt. Asha Mishra Vs. State of U.P. and
others;2017 (1) UPLBEC 261, which has been consistently followed in subsequent judgments and
orders of this Court. He has placed a compilation of the judgments passed in this regard by this
Court. The compilation placed before the Court is taken on record.
6. Learned counsel for petitioner tried to submit that the judgment passed by this Court in the case
of Smt. Asha Mishra (Supra) is distinguishable from the case of the petitioner on the ground that in
that case under challenge was the installation of mobile towers and 4G Base Transmitting Towers
being established in the entire State of U.P. whereas in the present case the petitioner has
specifically pleaded that the opposite party no.7 has installed mobile tower and 4G Base
Transmitting Station adjacent to the residence and area of the petitioner which is densely populated.
It is also submitted that the Court has not considered the earlier orders passed by the DivisionAmarjit Samuel Datt vs U.O.I. Thru. Secretary Deptt. Of ... on 8 February, 2021

Bench of this Court on 29.1.2015 in Writ-C No. 1626 of 2015; Chhedilal Vs. Union of India and
others wherein the writ petition was disposed of with direction that the mobile towers shall not be
established on the land in dispute in contravention of the guidelines issued by the Government from
time to time.
7. It is to be noted that the Division Bench of this Court headed by the then Hon'ble Chief Justice
while deciding the case of Smt. Asha Mishra (Supra) has framed the issues which have fallen for
consideration. The said issues have been noted in Paragraphs 5 of the judgment. For convenience
Paragraph 5 of the judgment is reproduced below:-
"5. Upon a review of the material placed before us and the submissions advanced we
find that the following broad issues fall for our consideration:
"I. Whether the contention of the petitioners including those related to the
deleterious effect of EMF radiation upon human health and safety is liable to be
sustained;
II. Whether the seventh respondent is in compliance with the statutory and
regulatory framework presently in vogue;
III. Whether the Court in exercise of its jurisdiction under Article 226 would be
justified in granting the reliefs as sought; and IV. Further directions if any."
8. The answer to these issues start from Paragraphs 19 onwards. The Court has answered each and
every issue in the judgment. Paragraphs 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31 and 32 of the
said judgment are reproduced below:-
"19.  Having traversed and noticed the vast field of scientific material gathered by
different committees and organisations, the precedents rendered on the subject we
now proceed to deal with the issues raised before us on merits.
F. ON MERITS I. Whether the contention of the petitioners including those related to
the deleterious effect of EMF radiation upon human health and safety is liable to be
sustained?
20.  The primary contention of the petitioners as noted above is based upon a
perceived present and imminent danger to human health and safety caused by EMF
radiation. The report of Prof. Girish Kumar forms the fundamental bedrock upon
which these submissions are based. We however find that this is not the first time
that this report has been utilized or pressed into service for laying a challenge to the
roll out and establishment of mobile towers. In fact this very report was noted by the
Division Bench of the Court at Lucknow in Shriram Singh Jauharia when taking note
of the said report the Bench constituted a committee to examine the conclusions and
undertake a comprehensive review on the subject of EMF radiation and the ill effectsAmarjit Samuel Datt vs U.O.I. Thru. Secretary Deptt. Of ... on 8 February, 2021

of mobile telephony on human health. As the record would reveal and as would be
evident from the findings of the committee that we have extracted above, the
conclusion arrived at was that there was no material which justified the conclusions
arrived at by Prof. Kumar. The Committee, in fact went to the extent of characterizing
the perceived threats as voiced by Prof. Kumar as being a misrepresentation. Once
that be the state of the record we find that the report of Prof. Kumar does not advance
the case of the petitioners any further.
21.  However since the issue raised in the petitions related to public health and safety
and bearing in mind the command of Article 21 we delved even further to consider
whether there was any material, which justified the invocation of our constitutional
powers to injunct the seventh respondent from establishing the mobile towers or
BTS's.
22.  We felt constrained to burden this judgment with various extracts of the findings
and recommendations of DOT, the Parliamentary Standing Committee as well as the
WHO in order to establish that a plethora of material gathered by experts clearly
negatives the perceived and alleged imminent threat and danger to health as was
sought to be canvassed before us. All the experts have unanimously voiced their
opinion that the present body of scientific research does not justify the threat to
health and life as is sought to be portrayed by some quarters including the petitioners
before us.
23.  On the above state of the record we find no merit in the challenge raised by the
petitioners on this score. Bearing in mind the present conclusions and findings on the
subject as expressed by experts across the board we find that there exists no
justification for the submission of a present and imminent danger or threat to human
health from the radiation emitted by mobile towers and BTS's. We further note that
the studies undertaken both in India as well as by other international organizations
have unanimously opined that the emissions from these equipments are minuscule
and do not warrant the anxiety or fear which is sought to be generated in this batch of
petitions. Our conclusion so recorded is of course not intended to relieve DOT or the
Union Government from its obligation of continuing a scientific review of the subject.
However in light of what we have found above, we rule against the petitioners insofar
as Issue No. I is concerned.
Issue No. 2 Whether the seventh respondent is in compliance with the statutory and
regulatory framework presently in vogue?
24.   We find that the petitioners have clearly failed to establish on the basis of any
material on record that the seventh respondent was in breach of the statutory
requirements placed and enforced by DOT. In order to be assured independently, we
as a matter of abundant caution called upon the TERM Cell to carry out a technical
audit of all the proposed sites. The report of the TERM Cell placed before us uponAmarjit Samuel Datt vs U.O.I. Thru. Secretary Deptt. Of ... on 8 February, 2021

affidavit did not find any of the sites to be in violation of the statutory and regulatory
norms governing the field. We further note that as per the regulatory provisions
prevalent, none of the mobile towers or BTS's of the seventh respondent would be
entitled to be energized for commercial operations unless and until the self
certification process is complied with and requisite papers filed before the TERM
Cell. We therefore and in light of the above, find no ground which may warrant a
restraint upon the establishment of the mobile towers and BTS's being established by
the seventh respondent.
Issue No. III. Whether the Court in exercise of its jurisdiction under Article 226
would be justified in granting the reliefs as sought?
25.  The submissions of learned counsel for the petitioners advanced on these
petitions on more than one aspect would require us to travel into the realm of testing
policy measures as well as evaluation of scientific material gathered by experts. The
Court in exercise of its powers of judicial review undertakes an exercise of testing
actions of the State on the touchstone of our Constitution and the laws of the land.
Articles 21 and 38 clearly mandate the State to take measures to ensure the safety,
health and well being of all citizens. Its measures and actions must be aimed at
alleviating the living conditions of all citizens and the environment of the nation as a
whole. The Court in exercise of its constitutional mandate is therefore obliged to
enquire into and test all actions of the State bearing in mind the breath and content
of Articles 21 and 38. However at the same time, it cannot loose sight of certain
inherent limitations placed upon the exercise of this power. The Court is not an arena
for scientific debate nor is it a forum for the testing of conflicting scientific studies
and findings of experts. That is surely not its province. The Courts exercise their
power of judicial review to test a lis or a cause necessarily against legal norms or legal
parameters. Legal norms and legal parameters do not, nay, cannot be left to rest upon
competing or nebulous scientific research or opinion.
26.  We may in this connection usefully refer to two causes, which travelled to the
Supreme Court for an amplification of what we have held. The first was a challenge to
the construction of the Tehri Dam. The second more recent and of far greater import
than the subject which falls for our determination - the use of nuclear energy. N.D.
Jayal Vs. Union of India10 dealt with a challenge to the establishment of the Tehri
Dam. The Supreme Court dealing with the challenge held: -
"20. This Court cannot sit in judgment over the cutting edge of scientific analysis
relating to the safety of any project. Experts in science may themselves differ in their
opinions while taking decisions on matters related to safety and allied aspects. The
opposing view points of the experts will also have to be given due consideration after
full application of mind. When the Government or the authorities concerned after
due consideration of all viewpoints and full application of mind took a decision, then
it is not appropriate for the court to interfere. Such matters must be left to the matureAmarjit Samuel Datt vs U.O.I. Thru. Secretary Deptt. Of ... on 8 February, 2021

wisdom of the Government or the implementing agency. It is their forte. In such
cases, if the situation demands, the courts should take only a detached decision based
on the pattern of the well settled principles of administrative law. If any such decision
is based on irrelevant consideration or non-consideration of material or is thoroughly
arbitrary, then the court will get in the way. Here the only point to consider is
whether the decision-making agency took a well informed decision or not. If the
answer is "yes", then there is no need to interfere. The consideration in such cases is
in the process of decision and not in its merits."
27. Dealing with the challenge to the establishment of a nuclear power plant in G. Sundarrajan Vs.
Union of India11 the Supreme Court ruled: -
"15. India's national policy has been clearly and unequivocally expressed by the
legislature in the Atomic Energy Act. National and international policy of the country
is to develop control and use of atomic energy for the welfare of the people and for
other peaceful purposes. NPP has been set up at Kundankulam as part of the national
policy which is discernible from the Preamble of the Act and the provisions contained
therein. It is not for courts to determine whether a particular policy or a particular
decision taken in fulfillment of a policy, is fair. The reason is obvious, it is not the
province of a court to scan the wisdom or reasonableness of the policy behind the
statute.
200. Much hue and cry has been raised by some sections of the people about the
possible impact of radiation from KKNP Units 1 and 2, a point which has been
addressed by AERB, NPCIL, MoEF and all the Expert Committees constituted to go
into the impact and effect of radiation from the units not only on humans but also on
ecology. The Experts Committees are of the unanimous opinion that there will not be
any deleterious effects due to radiation from the operation of KKNP, and that
adequate safety measures have already been taken. We cannot forget that there are
many potential areas of radiation reflected in many uses of radioactive materials.
Radioactive materials are used in hospitals, surgeries and so on. Mobile phone use,
though minor, also causes radiation. In a report of the Department of
Telecommunication "Mobile Communication -- Radio Wave and Safety" released in
October 2012, it has been stated that a human body is exposed to more
electromagnetic field radiation in case of a call from mobile phone in comparison to
the radiation from a mobile tower.
201. We have, therefore, to balance "economic scientific benefits" with that of "minor
radiological detriments" on the touchstone of our national nuclear policy. Economic
benefit, we have already indicated has to be viewed on a larger canvas which not only
augment our economic growth but alleviate poverty and generate more employment.
NPCIL, while setting up the NPP at Kundankulam, have satisfied the environmental
principles like sustainable development, corporate social responsibility,
precautionary principle, inter-/intra-generational equity and so on to implement ourAmarjit Samuel Datt vs U.O.I. Thru. Secretary Deptt. Of ... on 8 February, 2021

National Policy to develop, control and use of atomic energy for the welfare of the
people and for economic growth of the country. Larger public interest of the
community should give way to individual apprehension of violation of human rights
and right to life guaranteed under Article 21.
205. This Court in Chameli Singh v. State of U.P. [(1996) 2 SCC 549] held that in an
organized society, the right to live as a human being is not ensured by meeting only
the animal needs of man, but secured only when he is assured of all facilities to
develop himself and is freed from restrictions which inhibit his growth. Right to
shelter includes adequate living space, safe and decent structure, clean and decent
surroundings, sufficient light, pure air and water, electricity, sanitation and civil
amenities like road, etc. so as to have easy access to his daily avocation.
206. Nuclear power plant is being established not to negate right to life but to protect
the right to life guaranteed under Article 21 of the Constitution. The petitioner's
contention that the establishment of nuclear power plant at Kundankulam will make
an inroad into the right to live guaranteed under Article 21 of the Constitution,
therefore has no basis. On the other hand, it will only protect the right to life
guaranteed under Article 21 of the Constitution for achieving a larger public interest
and will also achieve the object and purpose of the Atomic Energy Act. "
28.  Bearing in mind the principles which must guide the exercise of the power of judicial review as
enunciated by the Supreme Court we are of the opinion that this Court while exercising its
jurisdiction under Article 226 would clearly not be justified in proceeding on the basis of the
conclusions of an author of a scientific study which itself has not found acceptance amongst its
peers.
29.  Our reluctance to accede to the submissions advanced by the learned counsel for the petitioners
also stemmed from the factual backdrop of the present proceedings. There was no conclusive
material which was brought to our attention which may have even remotely be read as evidencing,
underlining or supporting the perceived threat to human health voiced by the petitioners. Further
we note that the seventh respondent is in the process of rolling out and establishing its 4G network
on the basis of licenses and permissions granted by the Union Government which are not under
challenge before us. It is also not established from the record that the seventh respondent is in
breach of the conditions of its license or that its installations violate the regulatory framework put in
place by the Union and State governments.
30.  The present policy regime as approved by the Union Government grants authority to the
seventh respondent to establish a 4G mobile telephony and data network in accordance with the
license issued to it. Mobile telephony is an enterprise which is duly permitted and has the sanction
of the State. The subject of the so called and alleged effects of its usage on public health is a debate
which continues both at the national as well as the international level. The fact however remains
that as on date there is no conclusive material or scientific study which may justify or be read as
conclusive proof of the canvassed ill effects of EMF radiation on human health. We are also mindfulAmarjit Samuel Datt vs U.O.I. Thru. Secretary Deptt. Of ... on 8 February, 2021

of the fact that DOT has adopted and put in place national standards which peg the maximum
emission levels at 1/10th of the international norm prescribed by ICNIRP. This in our opinion
should have been sufficient to allay the fears and anxieties of the petitioners. Moreover the scientific
experts in the field have found no justification in the findings recorded by Prof. Girish Kumar. The
report of the Committee comprised of eminent persons who are experts in their field is liable to be
accorded judicial deference. We accordingly find no ground which would warrant the issuance of the
writs as prayed for.
Issue No IV Further directions
31.  Though having found no justification for the imposition of a prohibition or restraint upon the
installation of mobile towers and BTS's there remain certain issues which in our opinion do require
notice. As per the admitted stand of the Union, the TERM Cells carry out a random inspection of
10% of the mobile tower sites falling within their respective jurisdictions. No periodicity of
inspections appears to be fixed. There also does not appear to be in place a system for verification of
the self-certification which is filed by the prospective service provider. The other area of concern
appears to be, as was evident from the common refrain of all the petitioners, the lack of a complaint
redressal mechanism or at least the absence of an effective, robust and transparent grievance
redressal machinery.
32.  The absence of determinative scientific data does not lead us to hold that the technology and its
perceived effect on health and well being does not require a continuous monitoring or sustained
scientific study or research. It is evident from the body of material placed before us that
internationally a close watch is being maintained on the effects of EMF radiation. All studies
indicate that presently there appears to be no definitive scientific material or data which may
warrant EMF radiation being classified as endangering health. However the state of the research can
at present, as we have noted above, be best described as being still nebulous and tenuous. This is
perhaps the reason for research in the field being continued and ongoing. The standards adopted in
our country are stated to be more stringent than those suggested by the WHO. However the fixation
of a standard is but one aspect of the oversight mechanism which must necessarily be put in place.
The more important and fundamental issue appears to be the requirement of a system which
ensures the adherence to the standards fixed. This aspect, in our opinion, cannot be left to depend
solely upon a 10% random annual check carried out by TERM Cells. "
9. After answering the issues the Court has also considered the question of Grievance
Redressal Mechanism while delivering the aforesaid judgment and in this regard has
issued certain directions which are given in Paragraph 33. Paragraph 33 of the
judgment is reproduced below:-
"33. The other aspect as noted above relates to the grievance redressal mechanism. From the
submissions advanced and the material placed before us we find that there does exist the need for
the establishment of a grievance redressal and information dissemination mechanism which may
take note of complaints and allay the various doubts which stand raised in respect of the subject in
question. The absence of an effective machinery was also noted by the Parliamentary StandingAmarjit Samuel Datt vs U.O.I. Thru. Secretary Deptt. Of ... on 8 February, 2021

Committee which found the reply of DOT to be unsatisfactory and reiterated its recommendations
for the system being made more robust and responsive. Bearing in mind the serious concerns raised
in respect of the above two issues, we proceed to issue the following directions: -
1) DOT will expeditiously and not later than within 2 months from the date of this
judgment frame guidelines for the TERM Cells carrying out periodical inspection of
mobile towers and BTS stations falling within their respective jurisdictions;
2) DOT while framing the guidelines shall also consider and if thought feasible
incorporate appropriate provisions for inspection of all or such percentage of cell
towers as may be deemed appropriately by the TERM Cells;
3) DOT shall also consider and implement a mechanism where the testing of cell sites
is not left to depend upon the self certification procedure of the service provider
solely;
4) The directions issued shall mandate the TERM Cells to disclose their findings of
compliant and non-compliant mobile towers and BTS's for the information of the
general public;
5) The TERM Cells shall also make known to the general public the action taken
against erring and non-compliant mobile towers and BTS establishments;
6) DOT shall ensure that the particulars of TERM Cells including the particulars of its
Nodal Officer for different regions are made known to the members of the general
public;
7) DOT shall establish a complaint cell in the various regions details of which are
given wide publicity in the area concerned, to receive and address public complaints
relating to mobile towers and BTS;
8) DOT shall also issue necessary directions to ensure that the complaint cell duly
looks into, enquires and disposes of such complaints within a reasonable period of
time."
10. It is to be noted that this judgment has been followed by this Court in deciding the controversy
involved with respect to the installation and operation of mobile towers and 4G Base Transmitting
Stations in the subsequent writ petitions and all those writ petitions have been dismissed in terms of
the judgment passed in the case of Smt. Asha Mishra (Supra).
11. So far as the contention of learned counsel for the petitioner that the case of the petitioner is
different from the case of Smt. Asha Mishra (Supra) and as such that judgment is not to be
considered while deciding the present controversy involved in this writ petition is concerned, we are
of the considered view that pith and substance of the issues raised in the writ petition are by andAmarjit Samuel Datt vs U.O.I. Thru. Secretary Deptt. Of ... on 8 February, 2021

large the same as have been framed by the Court while deciding the case of Smt. Asha Mishra
(Supra) and as such the judgment of Smt. Asha Mishra (Supra) covers the controversy involved in
the instant writ petition.
12. It is also to be noted that so far as the contention of counsel for the petitioner that the advisory
on the use of mobile towers considering the impact on wildlife including birds and bees are not
followed is concerned, it is to be observed that they are only advisory and not mandatory in nature.
13. So far as the contention of learned counsel for the petitioner that the question raised in the
Parliament and the answers to those questions given by the Ministry of Telecommunication have
not been considered are concerned, we are of the considered view that the discussion made in the
Parliament are not to be considered while deciding the case in a judicial Court.
14. So far as the contention of learned counsel for the petitioner that the judgment of this Court in
the case of Chhedilal (Supra) is concerned, we are constrained to observe that the said judgment
does not lay any ratio decidendi. It only says that the erection of mobile towers shall be made as per
the guidelines issued by the Government from time to time.
15. Learned counsel for the petitioner has not been able to show that the erection and operation of
the impugned mobile tower and 4G Base Transmitting Station by the opposite party no.7 is in
contravention of any order or direction of the State Government or any other authority.
16. In this view of the matter, the writ petition lacks merit and is dismissed.
                   [Manish Mathur, J.]                     [Ritu Raj Awasthi, J.]
Order Date :- 8.2.2021
Arjun/-
 
      Amarjit Samuel Datt vs U.O.I. Thru. Secretary Deptt. Of ... on 8 February, 2021

